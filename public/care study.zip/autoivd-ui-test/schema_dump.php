<?php
require 'admin/config.php';
$res1 = $conn->query("SHOW CREATE TABLE purchase_order_final");
$row1 = $res1->fetch_row();
echo "purchase_order_final schema:\n" . $row1[1] . "\n\n";

$res2 = $conn->query("SHOW CREATE TABLE low_stocks");
$row2 = $res2->fetch_row();
echo "low_stocks schema:\n" . $row2[1] . "\n\n";
