<?php
require_once __DIR__ . '/vendor/autoload.php';
try {
    // Match the production export: allow Dompdf to use its own bundled default font.
    $dompdf = new \Dompdf\Dompdf();
    $dompdf->loadHtml('<h2>Purchase Management</h2><table><tr><th>Vendor</th></tr><tr><td>Example</td></tr></table>');
    $dompdf->render();
    echo "Success: " . strlen($dompdf->output()) . " byte PDF generated";
} catch (\Throwable $e) {
    echo "Error: " . $e->getMessage();
}
