<?php
date_default_timezone_set('Asia/Kolkata');
session_start();
require_once "db.php";
require_once 'constant.php';
include "functions.php";
require_once __DIR__ . '/../vendor/autoload.php';

define('CHATGPT_API_KEY', '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');

// if (isset($_POST["chatGptInputValData"]) && !empty($_POST["chatGptInputValData"])) {
//     header('Content-Type: application/json');
//     $question = trim($_POST['question'] ?? '');

// $createdBy = $_SESSION['user_id'] ?? 0;
// $createdAt  = date("Y-m-d H:i:s");

// if (empty($tenderNumber)) {
//     echo json_encode([
//         'status' => 'error',
//         'message' => 'Missing or invalid input.'
//     ]);
//     exit;
// }

// $stmt = $conn->prepare("INSERT INTO `tenders` 
//     (`tender_no`, `tender_title`, `created_by`, `created_at`) VALUES (?, ?, ?, ?)");

// if (!$stmt) {
//     echo json_encode([
//         'status' => 'error',
//         'message' => 'Failed to prepare insert: ' . $conn->error
//     ]);
//     exit;
// }

// $stmt->bind_param(
//     "ssis",
//     $tenderNumber, $tenderTitle, $createdBy, $createdAt
// );

// if ($stmt->execute()) {
//     echo json_encode([
//         'status' => 'success',
//         'message' => 'Tender added successfully.'
//     ]);
// } else {
//     echo json_encode([
//         'status' => 'error',
//         'message' => 'Error inserting tender: ' . $stmt->error
//     ]);
// }

// $stmt->close();
// $conn->close();
//     exit;
// }

// if (isset($_POST["chatGptInputValData"]) && !empty($_POST["chatGptInputValData"])) {
//     header('Content-Type: application/json');
//     $userId   = $_SESSION['user_id'] ?? 0;
//     $question = trim($_POST['question'] ?? '');

//     if ($userId <= 0) {
//         echo json_encode(['answer' => 'Unauthorized']);
//         exit;
//     }

//     if ($question === '') {
//         echo json_encode(['answer' => 'Please ask something']);
//         exit;
//     }

//     $apiKey = CHATGPT_API_KEY; // .env se

//     $payload = [
//         "model" => "gpt-4.1-mini",
//         "messages" => [
//             ["role" => "system", "content" => "You are an ERP assistant"],
//             ["role" => "user", "content" => $question]
//         ],
//         "max_tokens" => 5000
//     ];

//     $ch = curl_init('https://api.openai.com/v1/chat/completions');
//     curl_setopt_array($ch, [
//         CURLOPT_RETURNTRANSFER => true,
//         CURLOPT_POST => true,        
//         CURLOPT_SSL_VERIFYPEER => false,
//         CURLOPT_SSL_VERIFYHOST => false,
//         CURLOPT_HTTPHEADER => [
//             'Content-Type: application/json',
//             'Authorization: ' . 'Bearer ' . $apiKey
//         ],
//         CURLOPT_POSTFIELDS => json_encode($payload)
//     ]);

//     $response = curl_exec($ch);
//     if (is_resource($ch) || $ch instanceof CurlHandle) {
//         curl_close($ch);
//     }
//     $json   = json_decode($response, true);
//     $answer = $json['choices'][0]['message']['content'] ?? 'No response';

//     // $stmt = $conn->prepare(
//     //     "INSERT INTO chat_history (user_id, question, answer) VALUES (?, ?, ?)"
//     // );
//     // $stmt->bind_param("iss", $userId, $question, $answer);
//     // $stmt->execute();
//     // $stmt->close();

//     echo json_encode([
//         'success' => true,
//         'answer'  => nl2br(htmlspecialchars($answer))
//     ]);
//     exit;
// }

if (isset($_POST['chatGptInputValData'])) {
    header('Content-Type: application/json');
    $userId = $_SESSION['user_id'] ?? 0;
    $question = trim($_POST['question'] ?? '');
    $conversationId = intval($_POST['conversation_id'] ?? 0);

    if (!$userId || $question === '') {
        echo json_encode(['status' => 'error']);
        exit;
    }

    $answer = '';
    $status = 0;

    try {
        if ($conversationId === 0) {
            $title = mb_substr($question, 0, 60);

            $stmt = $conn->prepare("INSERT INTO chatgpt_conversations (user_id, title, created_at)
                VALUES (?, ?, NOW())
            ");
            $stmt->bind_param("is", $userId, $title);
            $stmt->execute();
            $conversationId = $stmt->insert_id;
            $stmt->close();
        }

        $stmt = $conn->prepare("INSERT INTO chatgpt_messages 
            (conversation_id, user_id, role, message, created_at)
            VALUES (?, ?, 'user', ?, NOW())
        ");
        $stmt->bind_param("iis", $conversationId, $userId, $question);
        $stmt->execute();
        $stmt->close();


        $ch = curl_init();
        $apiKey = CHATGPT_API_KEY;
        curl_setopt_array($ch, [
            CURLOPT_URL => 'https://api.openai.com/v1/chat/completions',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 40,
            CURLOPT_POST => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_POSTFIELDS => json_encode([
                "model" => "gpt-4.1-mini",
                "messages" => [
                    ["role" => "user", "content" => $question]
                ]
            ]),
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer ".$apiKey,
                "Content-Type: application/json"
            ]
        ]);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            throw new Exception('Curl error');
        }

        curl_close($ch);

        $data = json_decode($response, true);
        $answer = $data['choices'][0]['message']['content'] ?? '';

        if ($answer === '') {
            throw new Exception('Empty response');
        }

        $status = 1;
        if ($status === 1) {
            $stmt = $conn->prepare("INSERT INTO chatgpt_messages 
                (conversation_id, user_id, role, message, created_at)
                VALUES (?, ?, 'assistant', ?, NOW())
            ");
            $stmt->bind_param("iis", $conversationId, $userId, $answer);
            $stmt->execute();
            $stmt->close();
        }


    } catch (Exception $e) {
        $answer = null;
        $status = 0;
    }

    if ($status === 1) {
        $answer = nl2br(htmlspecialchars($answer, ENT_QUOTES, 'UTF-8'));
        echo json_encode([
            'status' => $status === 1 ? 'success' : 'error',
            'answer' => $answer,
            'conversation_id' => $conversationId
        ]);
    } else {
        echo json_encode(['status' => 'error']);
    }

    exit;
}

?>