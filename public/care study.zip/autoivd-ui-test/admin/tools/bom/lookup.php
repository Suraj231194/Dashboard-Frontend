<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/inventory_master.php';
require_once __DIR__ . '/db_catalog.php';

/**
 * Inventory lookup helper (products table).
 * Usage: php lookup.php "search text" [categoryPrefixFilter]
 */

$needle = strtoupper($argv[1] ?? '');
$categoryFilter = strtoupper($argv[2] ?? '');

$data = bom_inventory_workbook();
$catalog = bom_db_catalog();

$prep = [];
foreach ($data['prep'] as $row) {
    $prep[strtoupper($row['product_code'])] = $row['bom_available'] ? 'YES' : '-';
}

$hits = 0;

foreach ($catalog as $product) {
    $haystack = strtoupper($product['product_name'] . ' ' . $product['product_code'] . ' ' . $product['category']);

    if ($needle !== '' && !str_contains($haystack, $needle)) {
        continue;
    }

    if ($categoryFilter !== '' && strtoupper($product['code_prefix']) !== $categoryFilter) {
        continue;
    }

    $hits++;

    bom_out(sprintf(
        '%-28s | %-3s | %-46s | %-44s | id=%d',
        $product['product_code'],
        $prep[strtoupper($product['product_code'])] ?? '-',
        $product['product_name'],
        $product['category'],
        $product['id']
    ));
}

bom_out('-- hits: ' . $hits);
