<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/vendor/autoload.php';
require_once __DIR__ . '/bom_db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 * Parses the six BOM workbooks into a normalised structure.
 * Every sheet is one BOM: a finished/semi-finished item plus its component rows.
 *
 * bom_type follows Constant::STOCKS['BOM_TYPES']: 1 = SEMI (raw -> semi),
 * 2 = INTERMEDIATE (semi -> semi), 4 = FINISHED.
 */

const BOM_WORKBOOKS = [
    'BOMs - Biochemistry (Finished Kit) _ (Packaging BOM).xlsx' => ['key' => 'biochem_packaging', 'bom_type' => 4],
    'BOMs - Biochemistry (Reagent Manufacturing) (Semi Finished).xlsx' => ['key' => 'biochem_reagent', 'bom_type' => 1],
    'BOMs - Hematology.xlsx' => ['key' => 'hematology', 'bom_type' => 4],
    'BOMs - Rapid Tests.xlsx' => ['key' => 'rapid_tests', 'bom_type' => 4],
    'BOMs - Serology & Turbi.xlsx' => ['key' => 'serology_turbi', 'bom_type' => 4],
    'BOMs - Uncut Sheets (Semi Finished Goods for Rapid Tests).xlsx' => ['key' => 'uncut_sheets', 'bom_type' => 2],
];

function bom_clean(?string $value): string
{
    $value = (string)$value;
    $value = str_replace("\xC2\xA0", ' ', $value);

    return trim(preg_replace('/\s+/u', ' ', $value) ?? '');
}

function bom_parse_qty(string $raw): ?float
{
    $raw = str_replace([',', ' '], '', $raw);

    if ($raw === '' || !is_numeric($raw)) {
        return null;
    }

    return (float)$raw;
}

/** Splits an OVERAGES cell such as "PCS  0.00" into unit and overage. */
function bom_split_overage(string $raw): array
{
    $raw = bom_clean($raw);

    if ($raw === '') {
        return ['unit' => '', 'overage' => 0.0];
    }

    if (preg_match('/^(.*?)\s+(-?\d+(?:\.\d+)?)$/', $raw, $m) === 1) {
        return ['unit' => bom_clean($m[1]), 'overage' => (float)$m[2]];
    }

    return is_numeric($raw)
        ? ['unit' => '', 'overage' => (float)$raw]
        : ['unit' => $raw, 'overage' => 0.0];
}

function bom_extract_item_name(array $rows, int $headerIndex): string
{
    $fallback = '';

    for ($i = 0; $i < $headerIndex; $i++) {
        foreach ($rows[$i] ?? [] as $cell) {
            $text = bom_clean((string)$cell);

            if ($text === '') {
                continue;
            }

            if (preg_match('/^item\s*[:#-]\s*(.+)$/i', $text, $m) === 1) {
                return bom_clean($m[1]);
            }

            $upper = strtoupper($text);

            if (
                str_contains($upper, 'MANUFACTURING FORMULA RECORD')
                || str_starts_with($upper, 'BATCH SIZE')
                || str_starts_with($upper, 'FORMULA NO')
                || str_starts_with($upper, 'GENE.NAME')
                || str_starts_with($upper, 'CAT #')
            ) {
                continue;
            }

            if ($fallback === '') {
                $fallback = $text;
            }
        }
    }

    return $fallback;
}

function bom_extract_generic_name(array $rows, int $headerIndex): string
{
    for ($i = 0; $i < $headerIndex; $i++) {
        foreach ($rows[$i] ?? [] as $cell) {
            $text = bom_clean((string)$cell);

            if (preg_match('/gene\.?\s*name\s*[:#-]\s*(.+)$/i', $text, $m) === 1) {
                return bom_clean($m[1]);
            }
        }
    }

    return '';
}

function bom_extract_batch_size(array $rows, int $headerIndex): string
{
    for ($i = 0; $i < $headerIndex; $i++) {
        foreach ($rows[$i] ?? [] as $cell) {
            $text = bom_clean((string)$cell);

            if (preg_match('/^batch\s*size\s*[:#-]\s*(.+)$/i', $text, $m) === 1) {
                return bom_clean($m[1]);
            }
        }
    }

    return '';
}

function bom_extract_workbooks(): array
{
    $root = bom_project_root() . '/BOM/';
    $result = [];

    foreach (BOM_WORKBOOKS as $fileName => $meta) {
        $path = $root . $fileName;

        if (!is_readable($path)) {
            throw new RuntimeException('Missing workbook: ' . $fileName);
        }

        $reader = IOFactory::createReaderForFile($path);
        $reader->setReadDataOnly(true);
        $book = $reader->load($path);

        foreach ($book->getAllSheets() as $sheet) {
            $rows = $sheet->toArray(null, true, false, false);
            $headerIndex = null;
            $cols = ['cat' => null, 'desc' => null, 'claim' => null, 'qty' => null, 'over' => null];

            foreach ($rows as $i => $row) {
                foreach ($row as $c => $cell) {
                    if (strcasecmp(bom_clean((string)$cell), 'ITEM DESCRIPTION') === 0) {
                        $headerIndex = $i;
                        $cols['desc'] = $c;
                        break 2;
                    }
                }
            }

            if ($headerIndex === null) {
                $result[] = [
                    'workbook' => $fileName,
                    'workbook_key' => $meta['key'],
                    'bom_type' => $meta['bom_type'],
                    'sheet' => $sheet->getTitle(),
                    'item_name' => '',
                    'generic_name' => '',
                    'batch_size' => '',
                    'components' => [],
                    'skipped_rows' => [],
                    'error' => 'No ITEM DESCRIPTION header row found',
                ];
                continue;
            }

            foreach ($rows[$headerIndex] as $c => $cell) {
                $label = strtoupper(bom_clean((string)$cell));

                if ($label === 'CAT #' || $label === 'CAT#' || $label === 'CAT NUMBER') {
                    $cols['cat'] = $c;
                } elseif ($label === 'CLAIM') {
                    $cols['claim'] = $c;
                } elseif ($label === 'QUANTITY') {
                    $cols['qty'] = $c;
                } elseif ($label === 'OVERAGES') {
                    $cols['over'] = $c;
                }
            }

            $components = [];
            $skipped = [];

            for ($i = $headerIndex + 1, $n = count($rows); $i < $n; $i++) {
                $row = $rows[$i];
                $desc = bom_clean((string)($row[$cols['desc']] ?? ''));

                if ($desc === '' || strcasecmp($desc, 'ITEM DESCRIPTION') === 0) {
                    continue;
                }

                $qtyRaw = $cols['qty'] !== null ? bom_clean((string)($row[$cols['qty']] ?? '')) : '';
                $qty = bom_parse_qty($qtyRaw);

                if ($qty === null && $cols['claim'] !== null) {
                    $qty = bom_parse_qty(bom_clean((string)($row[$cols['claim']] ?? '')));
                }

                if ($qty === null) {
                    $skipped[] = ['excel_row' => $i + 1, 'description' => $desc, 'reason' => 'no quantity'];
                    continue;
                }

                $over = bom_split_overage((string)($row[$cols['over']] ?? ''));

                $components[] = [
                    'excel_row' => $i + 1,
                    'cat_number' => $cols['cat'] !== null ? bom_clean((string)($row[$cols['cat']] ?? '')) : '',
                    'description' => $desc,
                    'qty' => $qty,
                    'unit' => $over['unit'],
                    'overage' => $over['overage'],
                ];
            }

            $result[] = [
                'workbook' => $fileName,
                'workbook_key' => $meta['key'],
                'bom_type' => $meta['bom_type'],
                'sheet' => $sheet->getTitle(),
                'item_name' => bom_extract_item_name($rows, $headerIndex),
                'generic_name' => bom_extract_generic_name($rows, $headerIndex),
                'batch_size' => bom_extract_batch_size($rows, $headerIndex),
                'components' => $components,
                'skipped_rows' => $skipped,
                'error' => null,
            ];
        }

        $book->disconnectWorksheets();
        unset($book);
    }

    return $result;
}

if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === realpath(__FILE__)) {
    $sheets = bom_extract_workbooks();
    $components = 0;
    $skipped = 0;

    foreach ($sheets as $sheet) {
        $components += count($sheet['components']);
        $skipped += count($sheet['skipped_rows']);
    }

    $outPath = __DIR__ . '/_workbooks.json';
    file_put_contents($outPath, json_encode($sheets, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

    bom_out('Sheets parsed     : ' . count($sheets));
    bom_out('Component rows    : ' . $components);
    bom_out('Skipped (no qty)  : ' . $skipped);
    bom_out('Written           : ' . $outPath);

    foreach ($sheets as $sheet) {
        foreach ($sheet['skipped_rows'] as $row) {
            bom_out(sprintf('  SKIP [%s / %s] row %d: %s', $sheet['workbook_key'], $sheet['sheet'], $row['excel_row'], $row['description']));
        }
        if ($sheet['error'] !== null) {
            bom_out(sprintf('  ERROR [%s / %s]: %s', $sheet['workbook_key'], $sheet['sheet'], $sheet['error']));
        }
        if ($sheet['item_name'] === '') {
            bom_out(sprintf('  NO ITEM NAME [%s / %s]', $sheet['workbook_key'], $sheet['sheet']));
        }
    }
}
