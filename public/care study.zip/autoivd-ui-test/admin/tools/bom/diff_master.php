<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';
require_once __DIR__ . '/plan_repair.php';

$plan = bom_plan_repair();
$fields = ['name' => 0, 'category_id' => 0, 'finished_product_id' => 0, 'bom_type' => 0, 'status' => 0, 'bom_status' => 0];
$samples = [];

foreach ($plan['targets'] as $target) {
    $bomId = $target['bom_id'];

    if ($bomId === null) {
        continue;
    }

    $existing = $plan['existing'][$bomId];
    $sheet = $target['sheet'];

    if ($existing['name'] !== $sheet['finished_name']) {
        $fields['name']++;
        if (count($samples) < 15) {
            $samples[] = sprintf('bom#%-5d "%s"  ->  "%s"', $bomId, $existing['name'], $sheet['finished_name']);
        }
    }
    if ($existing['finished_product_id'] !== $sheet['finished_id']) {
        $fields['finished_product_id']++;
    }
    if ($existing['bom_type'] !== $sheet['bom_type']) {
        $fields['bom_type']++;
    }
    if ($existing['status'] !== 1) {
        $fields['status']++;
    }
    if ($existing['bom_status'] !== 'APPROVED') {
        $fields['bom_status']++;
    }
}

foreach ($fields as $field => $count) {
    bom_out(sprintf('%-22s %d', $field, $count));
}

bom_out('');
bom_out('=== sample name changes ===');
foreach ($samples as $sample) {
    bom_out('  ' . $sample);
}
