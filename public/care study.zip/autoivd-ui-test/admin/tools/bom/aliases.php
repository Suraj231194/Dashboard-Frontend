<?php

declare(strict_types=1);

/**
 * Curated crosswalks. Keys are normalised Excel text (see bom_normalize()).
 * Values are inventory CAT numbers, or null to deliberately drop the row.
 *
 * Nothing here may be guessed: every entry must be traceable to the
 * inventory master workbook.
 */

/** Sheet "Item :" text -> finished/semi-finished product code. */
function bom_finished_aliases(): array
{
    static $map = null;

    if ($map !== null) {
        return $map;
    }

    $map = require __DIR__ . '/alias_finished.php';

    return $map;
}

/** Component "ITEM DESCRIPTION" text -> raw material product code. */
function bom_component_aliases(): array
{
    static $map = null;

    if ($map !== null) {
        return $map;
    }

    $map = require __DIR__ . '/alias_components.php';

    return $map;
}

/** Workbook key -> inventory category codes the finished product must belong to. */
function bom_workbook_scope(): array
{
    return [
        'biochem_packaging' => ['FIN.BIOC'],
        'biochem_reagent' => ['SF.BR.BIOC'],
        'hematology' => ['FIN.HEMA'],
        'rapid_tests' => ['FIN.RAPID', 'FIN.POCT', 'FIN.SERO'],
        'serology_turbi' => ['FIN.SERO', 'FIN.SPCH', 'FIN.BIOC'],
        'uncut_sheets' => ['SF.US.RAPID', 'SF.US.URIN', 'SF.US.POCT'],
    ];
}

/** Excel unit text -> standard_units.short_name. */
function bom_unit_map(): array
{
    return [
        'PCS' => 'pcs',
        'PC' => 'pcs',
        'PIECE' => 'pcs',
        'PIECES' => 'pcs',
        'NOS' => 'pcs',
        'NO' => 'pcs',
        'EACH' => 'pcs',
        'UNIT' => 'unit',
        'UNITS' => 'unit',
        'GM' => 'g',
        'GMS' => 'g',
        'G' => 'g',
        'GRAM' => 'g',
        'GRAMS' => 'g',
        'MG' => 'mg',
        'KG' => 'kg',
        'ML' => 'ml',
        'MLS' => 'ml',
        'UL' => 'µl',
        'LTR' => 'ltr',
        'LTRS' => 'ltr',
        'LITRE' => 'ltr',
        'L' => 'ltr',
        'KU' => 'KU',
        'MU' => 'MU',
        'MTR' => 'm',
        'MTRS' => 'm',
        'METER' => 'm',
        'M' => 'm',
        'CM' => 'cm',
        'MM' => 'mm',
        'TEST' => 'test',
        'TESTS' => 'test',
        'KIT' => 'kit',
        'KITS' => 'kit',
        'SHEET' => 'sheets',
        'SHEETS' => 'sheets',
        'SHEE' => 'sheets',
        'SHE' => 'sheets',
        'STRIP' => 'strips',
        'STRIPS' => 'strips',
        'BOTT' => 'pcs',
        'BOX' => 'pcs',
        'BAG' => 'pcs',
        'VIAL' => 'pcs',
    ];
}
