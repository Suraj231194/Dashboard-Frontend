<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';

/**
 * Builds the resolved BOM model: every workbook sheet mapped to a finished
 * product (from the frozen crosswalk) and every component mapped to a product.
 */

function bom_sheet_key(array $sheet): string
{
    return $sheet['workbook_key'] . '::' . $sheet['sheet'];
}

function bom_duplicate_sheets(): array
{
    $path = __DIR__ . '/duplicate_sheets.php';

    return is_readable($path) ? require $path : [];
}

function bom_build_model(): array
{
    $sheets = bom_extract_workbooks();
    $catalog = bom_db_catalog();
    $byCode = bom_db_catalog_by_code();
    $resolver = new BomResolver($catalog);

    $finishedMap = bom_finished_aliases();
    $componentAliases = bom_component_aliases();
    $duplicates = bom_duplicate_sheets();
    $unitMap = bom_unit_map();
    $unitIds = bom_unit_ids();

    $model = [];

    foreach ($sheets as $sheet) {
        $key = bom_sheet_key($sheet);
        $code = $finishedMap[$key] ?? null;
        $product = $code === null ? null : ($byCode[strtoupper($code)] ?? null);

        $components = [];

        foreach ($sheet['components'] as $component) {
            $resolved = $resolver->resolve(
                $component['description'],
                $component['cat_number'],
                [],
                $componentAliases
            );

            $unitKey = strtoupper(bom_clean($component['unit']));
            $unitShort = $unitMap[$unitKey] ?? null;

            $components[] = $component + [
                'resolution' => $resolved['status'],
                'method' => $resolved['method'],
                'product_id' => $resolved['product']['id'] ?? null,
                'product_code' => $resolved['product']['product_code'] ?? null,
                'product_name' => $resolved['product']['product_name'] ?? null,
                'product_category_id' => $resolved['product']['category_id'] ?? null,
                'candidates' => $resolved['candidates'],
                'unit_short' => $unitShort,
                'unit_id' => $unitShort === null ? null : ($unitIds[strtoupper($unitShort)] ?? null),
            ];
        }

        $model[] = [
            'sheet_key' => $key,
            'workbook_key' => $sheet['workbook_key'],
            'workbook' => $sheet['workbook'],
            'bom_type' => $sheet['bom_type'],
            'sheet' => $sheet['sheet'],
            'item_name' => $sheet['item_name'],
            'generic_name' => $sheet['generic_name'],
            'batch_size' => $sheet['batch_size'],
            'duplicate_of' => $duplicates[$key] ?? null,
            'finished_status' => $product === null ? 'UNRESOLVED' : 'OK',
            'finished_code' => $product['product_code'] ?? null,
            'finished_id' => $product['id'] ?? null,
            'finished_name' => $product['product_name'] ?? null,
            'finished_category_id' => $product['category_id'] ?? null,
            'finished_category' => $product['category'] ?? null,
            'components' => $components,
            'skipped_rows' => $sheet['skipped_rows'],
        ];
    }

    return $model;
}

if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === realpath(__FILE__)) {
    $model = bom_build_model();

    file_put_contents(
        __DIR__ . '/_resolved.json',
        json_encode($model, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );

    $finishedStatus = [];
    $componentStatus = [];
    $componentMethod = [];
    $unitMissing = [];
    $totalComponents = 0;
    $activeSheets = 0;

    foreach ($model as $sheet) {
        $finishedStatus[$sheet['finished_status']] = ($finishedStatus[$sheet['finished_status']] ?? 0) + 1;

        if ($sheet['duplicate_of'] === null) {
            $activeSheets++;
        }

        foreach ($sheet['components'] as $component) {
            $totalComponents++;
            $componentStatus[$component['resolution']] = ($componentStatus[$component['resolution']] ?? 0) + 1;
            $componentMethod[$component['method']] = ($componentMethod[$component['method']] ?? 0) + 1;

            if ($component['unit_id'] === null) {
                $unitMissing[$component['unit']] = ($unitMissing[$component['unit']] ?? 0) + 1;
            }
        }
    }

    bom_out('=== SHEETS ===');
    bom_out('  total          : ' . count($model));
    bom_out('  active (BOMs)  : ' . $activeSheets);
    foreach ($finishedStatus as $status => $count) {
        bom_out(sprintf('  %-14s %d', $status, $count));
    }

    bom_out('');
    bom_out('=== COMPONENTS ===');
    bom_out('  total: ' . $totalComponents);
    foreach ($componentStatus as $status => $count) {
        bom_out(sprintf('  %-14s %d', $status, $count));
    }

    bom_out('');
    bom_out('=== MATCH METHODS ===');
    arsort($componentMethod);
    foreach ($componentMethod as $method => $count) {
        bom_out(sprintf('  %-20s %d', $method, $count));
    }

    bom_out('');
    bom_out('=== UNMAPPED UNITS ===');
    arsort($unitMissing);
    foreach ($unitMissing as $unit => $count) {
        bom_out(sprintf('  %-16s %d', '"' . $unit . '"', $count));
    }

    bom_out('');
    bom_out('=== UNRESOLVED / AMBIGUOUS COMPONENTS (unique descriptions) ===');
    $problems = [];
    foreach ($model as $sheet) {
        foreach ($sheet['components'] as $component) {
            if ($component['resolution'] === 'OK' || $component['resolution'] === 'IGNORED') {
                continue;
            }
            $key = $component['resolution'] . '|' . $component['description'];
            $problems[$key] ??= ['count' => 0, 'candidates' => $component['candidates'], 'sheets' => []];
            $problems[$key]['count']++;
            if (count($problems[$key]['sheets']) < 3) {
                $problems[$key]['sheets'][] = $sheet['sheet_key'];
            }
        }
    }
    ksort($problems);
    foreach ($problems as $key => $info) {
        [$status, $desc] = explode('|', $key, 2);
        bom_out(sprintf('  %-11s x%-4d %s', $status, $info['count'], $desc));
        bom_out('        norm: ' . bom_normalize($desc));
        bom_out('        seen: ' . implode(', ', $info['sheets']));
        foreach ($info['candidates'] as $candidate) {
            bom_out('        cand: ' . $candidate);
        }
    }
    bom_out('  unique problem descriptions: ' . count($problems));
}
