<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/inventory_master.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/scoring.php';

/**
 * Emits a compact, reviewable crosswalk proposal for every workbook sheet:
 *   sheet -> finished/semi-finished CAT number, with score and runner-up margin.
 * Rows flagged REVIEW must be confirmed by hand before they are frozen into
 * alias_finished.php.
 */

$sheets = bom_extract_workbooks();
$inventory = bom_inventory_workbook();
$catalog = bom_db_catalog();
$scopes = bom_workbook_scope();
$aliases = bom_finished_aliases();
$resolver = new BomResolver($catalog);

$preferred = [];
foreach ($inventory['prep'] as $row) {
    if ($row['bom_available']) {
        $preferred[strtoupper($row['product_code'])] = true;
    }
}

$minScore = 0.55;
$minMargin = 0.25;

$claimed = [];
$rows = [];

foreach ($sheets as $sheet) {
    $scope = $scopes[$sheet['workbook_key']] ?? [];
    $existing = $resolver->resolve($sheet['item_name'], '', $scope, $aliases);

    if ($existing['status'] === 'OK') {
        $rows[] = [
            'workbook' => $sheet['workbook_key'],
            'sheet' => $sheet['sheet'],
            'item' => $sheet['item_name'],
            'code' => $existing['product']['product_code'],
            'name' => $existing['product']['product_name'],
            'score' => 1.0,
            'margin' => 1.0,
            'decision' => 'MATCHED(' . $existing['method'] . ')',
            'runner_up' => '',
        ];
        $claimed[$existing['product']['product_code']][] = $sheet['sheet'];
        continue;
    }

    $ranked = bom_rank_candidates(
        [$sheet['item_name'], $sheet['generic_name'], $sheet['sheet']],
        $catalog,
        $scope,
        $preferred
    );

    $top = $ranked[0] ?? null;
    $second = $ranked[1] ?? null;
    $score = $top['score'] ?? 0.0;
    $margin = $score - ($second['score'] ?? 0.0);

    $decision = ($score >= $minScore && $margin >= $minMargin) ? 'AUTO' : 'REVIEW';

    $rows[] = [
        'workbook' => $sheet['workbook_key'],
        'sheet' => $sheet['sheet'],
        'item' => $sheet['item_name'],
        'code' => $top['product']['product_code'] ?? '',
        'name' => $top['product']['product_name'] ?? '',
        'score' => $score,
        'margin' => $margin,
        'decision' => $decision,
        'runner_up' => $second === null ? '' : sprintf('%.3f %s :: %s', $second['score'], $second['product']['product_code'], $second['product']['product_name']),
    ];

    if (($top['product']['product_code'] ?? '') !== '') {
        $claimed[$top['product']['product_code']][] = $sheet['sheet'];
    }
}

$counts = [];

foreach ($rows as $row) {
    $counts[$row['decision']] = ($counts[$row['decision']] ?? 0) + 1;

    $dupeFlag = count($claimed[$row['code']] ?? []) > 1 ? ' !!DUP' : '';

    bom_out(sprintf(
        "%-18s | %-30s | %-8s %.3f/%.3f | %-26s | %-46s | %s%s",
        $row['workbook'],
        substr($row['sheet'], 0, 30),
        $row['decision'],
        $row['score'],
        $row['margin'],
        $row['code'],
        substr($row['name'], 0, 46),
        substr($row['item'], 0, 46),
        $dupeFlag
    ));

    if ($row['decision'] === 'REVIEW' && $row['runner_up'] !== '') {
        bom_out('    runner-up: ' . $row['runner_up']);
    }
}

bom_out('');
foreach ($counts as $decision => $count) {
    bom_out(sprintf('%-22s %d', $decision, $count));
}

bom_out('');
bom_out('=== CODES CLAIMED BY MORE THAN ONE SHEET ===');
foreach ($claimed as $code => $sheetList) {
    if (count($sheetList) > 1) {
        bom_out('  ' . $code . ' <- ' . implode(' | ', $sheetList));
    }
}

file_put_contents(
    __DIR__ . '/_proposed_finished.json',
    json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
);
