<?php

declare(strict_types=1);

require dirname(__DIR__, 3) . '/vendor/autoload.php';
require __DIR__ . '/bom_db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$dir = bom_project_root() . '/BOM';
$files = glob($dir . '/*.xlsx') ?: [];

$only = $argv[1] ?? null;
$maxSheets = (int)($argv[2] ?? 2);
$maxRows = (int)($argv[3] ?? 30);

foreach ($files as $file) {
    $base = basename($file);

    if ($only !== null && stripos($base, $only) === false) {
        continue;
    }

    bom_out('#############################################################');
    bom_out('FILE: ' . $base);

    $reader = IOFactory::createReaderForFile($file);
    $reader->setReadDataOnly(true);
    $book = $reader->load($file);

    bom_out('SHEETS: ' . $book->getSheetCount());
    bom_out('NAMES: ' . implode(' | ', $book->getSheetNames()));
    bom_out('');

    $shown = 0;

    foreach ($book->getAllSheets() as $sheet) {
        if ($shown >= $maxSheets) {
            break;
        }
        $shown++;

        bom_out('--- SHEET: "' . $sheet->getTitle() . '" dims=' . $sheet->calculateWorksheetDimension());

        $rows = $sheet->toArray(null, true, false, false);

        foreach (array_slice($rows, 0, $maxRows) as $i => $row) {
            $cells = [];
            foreach ($row as $c => $v) {
                if ($v === null || trim((string)$v) === '') {
                    continue;
                }
                $cells[] = $c . ':' . preg_replace('/\s+/', ' ', trim((string)$v));
            }
            if ($cells !== []) {
                bom_out(sprintf('  r%-3d %s', $i + 1, implode(' || ', $cells)));
            }
        }

        bom_out('');
    }

    $book->disconnectWorksheets();
    unset($book);
}
