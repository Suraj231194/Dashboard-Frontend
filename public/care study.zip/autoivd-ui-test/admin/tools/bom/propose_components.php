<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';
require_once __DIR__ . '/propose_components_lib.php';

/**
 * Ranks product candidates for every component description that the deterministic
 * resolver could not match, so the crosswalk can be reviewed and frozen into
 * alias_components.php.
 */

$model = bom_build_model();
$catalog = bom_db_catalog();
$topN = (int)($argv[1] ?? 5);

$problems = [];

foreach ($model as $sheet) {
    foreach ($sheet['components'] as $component) {
        if ($component['resolution'] === 'OK' || $component['resolution'] === 'IGNORED') {
            continue;
        }

        $key = $component['description'];
        $problems[$key] ??= ['count' => 0, 'sheets' => [], 'units' => []];
        $problems[$key]['count']++;
        $problems[$key]['units'][strtoupper($component['unit'])] = true;

        if (count($problems[$key]['sheets']) < 4) {
            $problems[$key]['sheets'][] = $sheet['sheet_key'];
        }
    }
}

ksort($problems);

bom_out('Unique unresolved descriptions: ' . count($problems));
bom_out('');

foreach ($problems as $description => $info) {
    $ranked = [];

    foreach ($catalog as $product) {
        $ranked[] = ['score' => bom_component_score($description, $product['product_name']), 'product' => $product];
    }

    usort($ranked, static fn (array $x, array $y): int => $y['score'] <=> $x['score']);

    bom_out(sprintf('x%-4d %s', $info['count'], $description));
    bom_out('      norm : ' . bom_normalize_strict($description));
    bom_out('      units: ' . implode(',', array_keys($info['units'])));
    bom_out('      seen : ' . implode(', ', $info['sheets']));

    foreach (array_slice($ranked, 0, $topN) as $candidate) {
        bom_out(sprintf(
            '      %.4f %-28s %-52s %s',
            $candidate['score'],
            $candidate['product']['product_code'],
            $candidate['product']['product_name'],
            $candidate['product']['category']
        ));
    }

    bom_out('');
}
