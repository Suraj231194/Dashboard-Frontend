<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

/**
 * Restores bom_master / bom_items rows captured by a repair run.
 *
 * Usage: php rollback_repair.php <run-id> [--apply]
 */

$runId = $argv[1] ?? '';
$apply = in_array('--apply', $argv, true);

if ($runId === '' || str_starts_with($runId, '--')) {
    bom_out('Usage: php rollback_repair.php <run-id> [--apply]');
    bom_out('');
    bom_out('Available runs:');

    foreach (bom_pdo()->query('SELECT run_id, COUNT(*) rows_backed_up, MIN(created_at) started FROM bom_repair_backup GROUP BY run_id ORDER BY started DESC') as $row) {
        bom_out(sprintf('  %s  rows=%-6s %s', $row['run_id'], $row['rows_backed_up'], $row['started']));
    }

    exit(2);
}

$pdo = bom_pdo();

$statement = $pdo->prepare('SELECT source_table, source_id, row_json FROM bom_repair_backup WHERE run_id = ? ORDER BY id');
$statement->execute([$runId]);
$rows = $statement->fetchAll();

if ($rows === []) {
    bom_out('No backup rows found for run ' . $runId);
    exit(1);
}

bom_out($apply ? '*** APPLY MODE - restoring ' . count($rows) . ' rows ***' : '--- DRY RUN - ' . count($rows) . ' rows would be restored ---');

if ($apply) {
    $pdo->beginTransaction();
}

try {
    $restored = 0;
    $reinserted = 0;

    foreach ($rows as $row) {
        $table = (string)$row['source_table'];

        if (!in_array($table, ['bom_master', 'bom_items'], true)) {
            throw new RuntimeException('Refusing to restore unexpected table: ' . $table);
        }

        $data = json_decode((string)$row['row_json'], true, 512, JSON_THROW_ON_ERROR);
        $columns = array_keys($data);

        $exists = $pdo->prepare('SELECT COUNT(*) FROM `' . $table . '` WHERE id = ?');
        $exists->execute([$row['source_id']]);

        if ((int)$exists->fetchColumn() > 0) {
            $assignments = implode(', ', array_map(static fn (string $c): string => '`' . $c . '` = ?', $columns));
            $values = array_values($data);
            $values[] = $row['source_id'];

            if ($apply) {
                $pdo->prepare('UPDATE `' . $table . '` SET ' . $assignments . ' WHERE id = ?')->execute($values);
            }

            $restored++;
            continue;
        }

        $placeholders = implode(', ', array_fill(0, count($columns), '?'));
        $columnList = implode(', ', array_map(static fn (string $c): string => '`' . $c . '`', $columns));

        if ($apply) {
            $pdo->prepare('INSERT INTO `' . $table . '` (' . $columnList . ') VALUES (' . $placeholders . ')')->execute(array_values($data));
        }

        $reinserted++;
    }

    if ($apply) {
        $pdo->commit();
    }

    bom_out('  updated back : ' . $restored);
    bom_out('  re-inserted  : ' . $reinserted);
    bom_out($apply ? 'Rollback complete.' : 'Re-run with --apply to restore.');
} catch (Throwable $e) {
    if ($apply && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    bom_out('FAILED - transaction rolled back: ' . $e->getMessage());
    exit(1);
}
