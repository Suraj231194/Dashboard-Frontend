<?php

declare(strict_types=1);

require dirname(__DIR__, 3) . '/vendor/autoload.php';
require __DIR__ . '/bom_db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$file = bom_project_root() . '/BOM/Inventory Management - Final.xlsx';

$reader = IOFactory::createReaderForFile($file);
$reader->setReadDataOnly(true);
$reader->setLoadSheetsOnly(['BOM - Preparation']);
$book = $reader->load($file);

$rows = $book->getSheetByName('BOM - Preparation')->toArray(null, true, false, false);

$yes = 0;
$no = 0;

foreach ($rows as $i => $row) {
    $category = trim((string)($row[0] ?? ''));
    $code = trim((string)($row[1] ?? ''));
    $name = trim((string)($row[2] ?? ''));
    $avail = strtoupper(trim((string)($row[3] ?? '')));
    $remark = trim((string)($row[4] ?? ''));

    if ($code === '' && $name === '') {
        continue;
    }

    if ($avail === 'YES') {
        $yes++;
    } elseif ($i > 2) {
        $no++;
    }

    bom_out(sprintf('r%-4d | %-34s | %-26s | %-52s | %-4s | %s', $i + 1, $category, $code, $name, $avail, $remark));
}

bom_out('');
bom_out('AVAILABILITY YES: ' . $yes);
bom_out('AVAILABILITY BLANK/NO: ' . $no);
