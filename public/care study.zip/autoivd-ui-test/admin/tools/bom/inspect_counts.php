<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

$pdo = bom_pdo();

$checks = [
    'bom_master total' => '1=1',
    'ORIGINAL' => "source_type = 'ORIGINAL'",
    'ORIGINAL live' => "source_type = 'ORIGINAL' AND deleted_at IS NULL",
    'soft deleted' => 'deleted_at IS NOT NULL',
    'status = 0' => 'status = 0',
    'not APPROVED' => "bom_status <> 'APPROVED'",
];

foreach ($checks as $label => $where) {
    bom_out(sprintf('%-20s %s', $label, $pdo->query('SELECT COUNT(*) FROM bom_master WHERE ' . $where)->fetchColumn()));
}

bom_out('');
bom_out('distinct live ORIGINAL finished products: ' . $pdo->query("SELECT COUNT(DISTINCT finished_product_id) FROM bom_master WHERE source_type='ORIGINAL' AND deleted_at IS NULL")->fetchColumn());
bom_out('live bom_items: ' . $pdo->query('SELECT COUNT(*) FROM bom_items bi JOIN bom_master bm ON bm.id = bi.bom_id WHERE bi.deleted_at IS NULL AND bm.deleted_at IS NULL')->fetchColumn());

bom_out('');
bom_out('=== duplicate approved BOMs per product ===');
$sql = "SELECT finished_product_id, COUNT(*) c, GROUP_CONCAT(id) ids
        FROM bom_master
        WHERE deleted_at IS NULL AND bom_status = 'APPROVED' AND status = 1
        GROUP BY finished_product_id HAVING c > 1";
foreach ($pdo->query($sql) as $row) {
    bom_out(sprintf('  product %d -> %d boms (%s)', $row['finished_product_id'], $row['c'], $row['ids']));
}

bom_out('');
bom_out('=== rows referencing bom ids ===');
bom_out('  material_requisition: ' . $pdo->query('SELECT COUNT(*) FROM material_requisition WHERE bom_master_id > 0')->fetchColumn());
bom_out('  production_plans    : ' . $pdo->query('SELECT COUNT(*) FROM production_plans WHERE bom_master_id > 0')->fetchColumn());
