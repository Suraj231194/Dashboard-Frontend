<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

$pdo = bom_pdo();
$statement = $pdo->prepare('SELECT 1');

$start = microtime(true);

for ($i = 0; $i < 100; $i++) {
    $statement->execute();
    $statement->fetchColumn();
}

$elapsed = microtime(true) - $start;

bom_out(sprintf('100 round trips: %.3fs  (%.1f ms each)', $elapsed, $elapsed * 10));
