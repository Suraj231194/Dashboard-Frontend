<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

$pdo = bom_pdo();

foreach (['product_bom', 'bom_approval_history', 'production_plan_bom_backfill_audit'] as $table) {
    bom_out('=== ' . $table . ' ===');
    foreach ($pdo->query('SHOW COLUMNS FROM `' . $table . '`') as $row) {
        bom_out(sprintf('  %-26s %-22s null=%-3s key=%-3s default=%s', $row['Field'], $row['Type'], $row['Null'], $row['Key'], $row['Default'] ?? 'NULL'));
    }
    bom_out('  rows: ' . $pdo->query('SELECT COUNT(*) FROM `' . $table . '`')->fetchColumn());
    bom_out('');
}

bom_out('=== live BOM references ===');
foreach ($pdo->query('SELECT id, bom_master_id, status FROM material_requisition') as $row) {
    bom_out('  material_requisition id=' . $row['id'] . ' bom_master_id=' . var_export($row['bom_master_id'], true));
}
foreach ($pdo->query('SELECT id, bom_master_id FROM production_plans') as $row) {
    bom_out('  production_plans id=' . $row['id'] . ' bom_master_id=' . var_export($row['bom_master_id'], true));
}
foreach ($pdo->query('SELECT id, bom_master_id FROM bom_approval_history') as $row) {
    bom_out('  bom_approval_history id=' . $row['id'] . ' bom_master_id=' . var_export($row['bom_master_id'], true));
}

bom_out('');
bom_out('=== sample product_bom ===');
foreach ($pdo->query('SELECT * FROM product_bom LIMIT 3') as $row) {
    bom_out('  ' . json_encode($row, JSON_UNESCAPED_SLASHES));
}
