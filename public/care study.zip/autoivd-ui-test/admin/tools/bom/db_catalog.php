<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

/**
 * The products table is the authoritative catalogue: it is already de-duplicated
 * and re-coded (for example Hematology finished goods moved from AC.HEMA to
 * FIN.HEMA), so every BOM resolution must target it rather than the raw workbook.
 */

function bom_db_catalog(): array
{
    static $cache = null;

    if ($cache !== null) {
        return $cache;
    }

    $sql = 'SELECT p.id,
                   p.product_code,
                   p.product_name,
                   p.category_id,
                   p.unit_id,
                   p.status,
                   c.name AS category,
                   c.category_prefix
            FROM products p
            LEFT JOIN product_categories c ON c.id = p.category_id
            WHERE p.deleted_at IS NULL';

    $products = [];

    foreach (bom_pdo()->query($sql) as $row) {
        $code = (string)$row['product_code'];
        $parts = explode('/', $code);

        $products[] = [
            'id' => (int)$row['id'],
            'product_code' => $code,
            'product_name' => (string)$row['product_name'],
            'category' => (string)($row['category'] ?? ''),
            'category_code' => (string)($row['category_prefix'] ?? ($parts[1] ?? '')),
            'code_prefix' => $parts[1] ?? '',
            'category_id' => $row['category_id'] === null ? null : (int)$row['category_id'],
            'unit_id' => $row['unit_id'] === null ? null : (int)$row['unit_id'],
            'unit' => '',
            'status' => (int)$row['status'],
        ];
    }

    $cache = $products;

    return $cache;
}

/** product_code (upper) => row, for fast lookups. */
function bom_db_catalog_by_code(): array
{
    static $cache = null;

    if ($cache !== null) {
        return $cache;
    }

    $cache = [];

    foreach (bom_db_catalog() as $product) {
        $cache[strtoupper($product['product_code'])] = $product;
    }

    return $cache;
}

/** standard_units.short_name (upper) => id. */
function bom_unit_ids(): array
{
    static $cache = null;

    if ($cache !== null) {
        return $cache;
    }

    $cache = [];

    foreach (bom_pdo()->query('SELECT id, short_name FROM standard_units WHERE status = 1') as $row) {
        $cache[strtoupper((string)$row['short_name'])] = (int)$row['id'];
    }

    return $cache;
}
