<?php

declare(strict_types=1);

require dirname(__DIR__, 3) . '/vendor/autoload.php';
require __DIR__ . '/bom_db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$fileFilter = $argv[1] ?? 'Biochemistry (Finished Kit)';
$sheetFilter = $argv[2] ?? null;
$maxRows = (int)($argv[3] ?? 15);

foreach (glob(bom_project_root() . '/BOM/*.xlsx') ?: [] as $file) {
    if (stripos(basename($file), $fileFilter) === false) {
        continue;
    }

    $reader = IOFactory::createReaderForFile($file);
    $reader->setReadDataOnly(true);
    $book = $reader->load($file);

    foreach ($book->getAllSheets() as $sheet) {
        if ($sheetFilter !== null && stripos($sheet->getTitle(), $sheetFilter) === false) {
            continue;
        }

        bom_out('FILE: ' . basename($file) . ' SHEET: "' . $sheet->getTitle() . '"');
        bom_out('highestCol=' . $sheet->getHighestDataColumn() . ' highestRow=' . $sheet->getHighestDataRow());

        $rows = $sheet->toArray(null, true, false, false);

        foreach (array_slice($rows, 0, $maxRows) as $i => $row) {
            $parts = [];
            foreach ($row as $c => $v) {
                $parts[] = $c . '=[' . str_replace(["\r", "\n", "\t"], ['\r', '\n', '\t'], (string)$v) . ']';
            }
            bom_out(sprintf('r%-3d %s', $i + 1, implode(' ', $parts)));
        }

        bom_out('');
    }

    $book->disconnectWorksheets();
}
