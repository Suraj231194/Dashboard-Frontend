<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

$pdo = bom_pdo();

bom_out('=== standard_units ===');
foreach ($pdo->query('SELECT id, short_name, fullname, base_unit, factor, status FROM standard_units ORDER BY id') as $row) {
    bom_out(sprintf('  %-3d %-10s %-22s base=%-6s factor=%s status=%s', $row['id'], (string)$row['short_name'], (string)$row['fullname'], (string)$row['base_unit'], $row['factor'], $row['status']));
}

bom_out('');
bom_out('=== product_categories ===');
foreach ($pdo->query('SELECT id, name, category_prefix, inventory_group, status FROM product_categories ORDER BY name') as $row) {
    bom_out(sprintf('  %-4d %-55s %-14s grp=%-2s status=%s', $row['id'], (string)$row['name'], (string)$row['category_prefix'], (string)$row['inventory_group'], $row['status']));
}

bom_out('');
bom_out('=== bom_master summary ===');
foreach ($pdo->query("SELECT source_type, bom_status, COUNT(*) c FROM bom_master GROUP BY source_type, bom_status ORDER BY source_type, bom_status") as $row) {
    bom_out(sprintf('  %-10s %-18s %d', $row['source_type'], $row['bom_status'], $row['c']));
}

bom_out('');
bom_out('bom_master rows                 : ' . $pdo->query('SELECT COUNT(*) FROM bom_master')->fetchColumn());
bom_out('bom_master ORIGINAL             : ' . $pdo->query("SELECT COUNT(*) FROM bom_master WHERE source_type='ORIGINAL'")->fetchColumn());
bom_out('bom_items rows                  : ' . $pdo->query('SELECT COUNT(*) FROM bom_items')->fetchColumn());
bom_out('bom_items for ORIGINAL boms     : ' . $pdo->query("SELECT COUNT(*) FROM bom_items bi JOIN bom_master bm ON bm.id=bi.bom_id WHERE bm.source_type='ORIGINAL'")->fetchColumn());
bom_out('distinct finished products      : ' . $pdo->query("SELECT COUNT(DISTINCT finished_product_id) FROM bom_master WHERE source_type='ORIGINAL'")->fetchColumn());

bom_out('');
bom_out('=== bom_master by finished product category prefix (ORIGINAL) ===');
$sql = "SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(p.product_code,'/',2),'/',-1) AS pref, COUNT(*) c
        FROM bom_master bm JOIN products p ON p.id = bm.finished_product_id
        WHERE bm.source_type='ORIGINAL' GROUP BY pref ORDER BY pref";
foreach ($pdo->query($sql) as $row) {
    bom_out(sprintf('  %-16s %d', (string)$row['pref'], $row['c']));
}
