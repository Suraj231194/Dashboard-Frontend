<?php

declare(strict_types=1);

require_once __DIR__ . '/resolver.php';

/** Similarity score between an Excel component description and a product name. */
function bom_component_score(string $description, string $productName): float
{
    $a = array_values(array_filter(explode(' ', bom_normalize($description))));
    $b = array_values(array_filter(explode(' ', bom_normalize($productName))));

    if ($a === [] || $b === []) {
        return 0.0;
    }

    $shared = count(array_intersect($a, $b));
    $jaccard = $shared / count(array_unique(array_merge($a, $b)));
    $coverage = $shared / count(array_unique($a));

    similar_text(bom_normalize($description), bom_normalize($productName), $percent);

    return round(($jaccard * 0.4) + ($coverage * 0.35) + ($percent / 100 * 0.25), 4);
}
