<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';

/**
 * Produces the repair plan: which existing bom_master row serves each workbook
 * BOM, which rows are re-pointed, which components change, and which BOMs are
 * left over. Nothing is written to the database here.
 */

/** @return array{targets: list<array<string, mixed>>, orphans: list<array<string, mixed>>, summary: array<string, int>} */
function bom_plan_repair(): array
{
    $pdo = bom_pdo();
    $model = bom_build_model();

    $existing = [];

    $sql = 'SELECT id, name, finished_product_id, bom_type, status, bom_status, source_type, descriptions
            FROM bom_master
            WHERE deleted_at IS NULL AND source_type = \'ORIGINAL\'';

    foreach ($pdo->query($sql) as $row) {
        $existing[(int)$row['id']] = [
            'id' => (int)$row['id'],
            'name' => (string)$row['name'],
            'finished_product_id' => (int)$row['finished_product_id'],
            'bom_type' => (int)$row['bom_type'],
            'status' => (int)$row['status'],
            'bom_status' => (string)$row['bom_status'],
            'items' => [],
        ];
    }

    $itemSql = 'SELECT bi.id, bi.bom_id, bi.raw_product_id, bi.raw_product_category_id, bi.qty_unit_id, bi.qty_per_unit
                FROM bom_items bi
                JOIN bom_master bm ON bm.id = bi.bom_id
                WHERE bi.deleted_at IS NULL AND bm.deleted_at IS NULL AND bm.source_type = \'ORIGINAL\'';

    foreach ($pdo->query($itemSql) as $row) {
        $bomId = (int)$row['bom_id'];

        if (!isset($existing[$bomId])) {
            continue;
        }

        $existing[$bomId]['items'][] = [
            'id' => (int)$row['id'],
            'raw_product_id' => (int)$row['raw_product_id'],
            'raw_product_category_id' => $row['raw_product_category_id'] === null ? null : (int)$row['raw_product_category_id'],
            'qty_unit_id' => $row['qty_unit_id'] === null ? null : (int)$row['qty_unit_id'],
            'qty_per_unit' => (float)$row['qty_per_unit'],
        ];
    }

    // A BOM may legitimately list one material once only; older seeders inserted
    // the same material twice. Keep the oldest row and retire the rest.
    foreach ($existing as $bomId => $row) {
        usort($row['items'], static fn (array $a, array $b): int => $a['id'] <=> $b['id']);

        $kept = [];
        $duplicates = [];

        foreach ($row['items'] as $item) {
            if (isset($kept[$item['raw_product_id']])) {
                $duplicates[] = $item['id'];
                continue;
            }

            $kept[$item['raw_product_id']] = $item;
        }

        $existing[$bomId]['items'] = array_values($kept);
        $existing[$bomId]['duplicate_item_ids'] = $duplicates;
    }

    $byProduct = [];
    foreach ($existing as $id => $row) {
        $byProduct[$row['finished_product_id']][] = $id;
    }

    $targets = [];
    $claimed = [];

    // Pass 1: keep a BOM that already points at the right finished product.
    foreach ($model as $sheet) {
        if ($sheet['duplicate_of'] !== null) {
            continue;
        }

        $bomId = null;

        foreach ($byProduct[$sheet['finished_id']] ?? [] as $candidate) {
            if (!isset($claimed[$candidate])) {
                $bomId = $candidate;
                $claimed[$candidate] = true;
                break;
            }
        }

        $targets[] = [
            'sheet' => $sheet,
            'bom_id' => $bomId,
            'match' => $bomId === null ? null : 'finished_product',
        ];
    }

    // Pass 2: re-point a spare BOM whose component set still matches the sheet,
    // so the BOM id (and anything referencing it) survives the correction.
    $spare = array_values(array_diff(array_keys($existing), array_keys($claimed)));

    foreach ($targets as $index => $target) {
        if ($target['bom_id'] !== null) {
            continue;
        }

        $wanted = [];
        foreach ($target['sheet']['components'] as $component) {
            $wanted[$component['product_id']] = true;
        }

        $best = null;
        $bestScore = 0.0;

        foreach ($spare as $candidateId) {
            if (isset($claimed[$candidateId])) {
                continue;
            }

            $have = [];
            foreach ($existing[$candidateId]['items'] as $item) {
                $have[$item['raw_product_id']] = true;
            }

            $union = count($wanted + $have);
            if ($union === 0) {
                continue;
            }

            $score = count(array_intersect_key($wanted, $have)) / $union;

            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $candidateId;
            }
        }

        if ($best !== null && $bestScore >= 0.6) {
            $claimed[$best] = true;
            $targets[$index]['bom_id'] = $best;
            $targets[$index]['match'] = sprintf('components(%.2f)', $bestScore);
        }
    }

    $orphans = [];
    foreach ($existing as $id => $row) {
        if (!isset($claimed[$id])) {
            $orphans[] = $row;
        }
    }

    $summary = [
        'target_boms' => count($targets),
        'reused_by_product' => 0,
        'reused_by_components' => 0,
        'created' => 0,
        'product_repointed' => 0,
        'items_added' => 0,
        'items_removed' => 0,
        'items_changed' => 0,
        'items_deduplicated' => 0,
        'items_unchanged' => 0,
        'orphan_boms' => count($orphans),
    ];

    foreach ($targets as $index => $target) {
        $sheet = $target['sheet'];
        $bomId = $target['bom_id'];

        $wanted = [];
        foreach ($sheet['components'] as $component) {
            $key = $component['product_id'];
            $wanted[$key] ??= ['raw_product_id' => $key, 'qty_per_unit' => 0.0, 'qty_unit_id' => $component['unit_id'], 'raw_product_category_id' => $component['product_category_id']];
            $wanted[$key]['qty_per_unit'] += $component['qty'];
        }

        $current = [];
        if ($bomId !== null) {
            foreach ($existing[$bomId]['items'] as $item) {
                $current[$item['raw_product_id']] = $item;
            }
        }

        $added = array_diff_key($wanted, $current);
        $removed = array_diff_key($current, $wanted);
        $changed = [];
        $unchanged = 0;

        foreach (array_intersect_key($wanted, $current) as $key => $want) {
            $have = $current[$key];

            if (abs($have['qty_per_unit'] - $want['qty_per_unit']) > 0.0000005 || $have['qty_unit_id'] !== $want['qty_unit_id']) {
                $changed[$key] = ['from' => $have, 'to' => $want];
            } else {
                $unchanged++;
            }
        }

        if ($bomId === null) {
            $summary['created']++;
        } elseif ($target['match'] === 'finished_product') {
            $summary['reused_by_product']++;
        } else {
            $summary['reused_by_components']++;
            $summary['product_repointed']++;
        }

        $summary['items_added'] += count($added);
        $summary['items_removed'] += count($removed);
        $summary['items_changed'] += count($changed);
        $summary['items_unchanged'] += $unchanged;
        $summary['items_deduplicated'] += $bomId === null ? 0 : count($existing[$bomId]['duplicate_item_ids']);

        $targets[$index]['wanted_items'] = array_values($wanted);
        $targets[$index]['duplicate_item_ids'] = $bomId === null ? [] : $existing[$bomId]['duplicate_item_ids'];
        $targets[$index]['diff'] = [
            'added' => array_keys($added),
            'removed' => array_keys($removed),
            'changed' => array_keys($changed),
            'unchanged' => $unchanged,
        ];
        $targets[$index]['current_product_id'] = $bomId === null ? null : $existing[$bomId]['finished_product_id'];
    }

    return ['targets' => $targets, 'orphans' => $orphans, 'summary' => $summary, 'existing' => $existing];
}

if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === realpath(__FILE__)) {
    $plan = bom_plan_repair();
    $byId = bom_db_catalog_by_code();

    $products = [];
    foreach (bom_db_catalog() as $product) {
        $products[$product['id']] = $product;
    }

    bom_out('=== SUMMARY ===');
    foreach ($plan['summary'] as $key => $value) {
        bom_out(sprintf('  %-22s %d', $key, $value));
    }

    bom_out('');
    bom_out('=== BOMS POINTING AT THE WRONG PRODUCT ===');
    $wrong = 0;
    foreach ($plan['targets'] as $target) {
        if ($target['bom_id'] === null || $target['current_product_id'] === $target['sheet']['finished_id']) {
            continue;
        }
        $wrong++;
        bom_out(sprintf(
            '  bom#%-5d %-34s  %s  ->  %s',
            $target['bom_id'],
            substr($target['sheet']['sheet_key'], 0, 34),
            ($products[$target['current_product_id']]['product_code'] ?? '?') . ' ' . substr($products[$target['current_product_id']]['product_name'] ?? '?', 0, 34),
            $target['sheet']['finished_code'] . ' ' . substr((string)$target['sheet']['finished_name'], 0, 34)
        ));
    }
    bom_out('  count: ' . $wrong);

    bom_out('');
    bom_out('=== BOMS TO CREATE ===');
    foreach ($plan['targets'] as $target) {
        if ($target['bom_id'] !== null) {
            continue;
        }
        bom_out(sprintf('  %-34s -> %s %s', $target['sheet']['sheet_key'], $target['sheet']['finished_code'], $target['sheet']['finished_name']));
    }

    bom_out('');
    bom_out('=== ORPHAN BOMS (no workbook sheet) ===');
    foreach ($plan['orphans'] as $orphan) {
        bom_out(sprintf(
            '  bom#%-5d items=%-4d %s %s',
            $orphan['id'],
            count($orphan['items']),
            $products[$orphan['finished_product_id']]['product_code'] ?? '(missing product)',
            substr($orphan['name'], 0, 50)
        ));
    }
    bom_out('  count: ' . count($plan['orphans']));

    file_put_contents(
        __DIR__ . '/_repair_plan.json',
        json_encode($plan, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );
}
