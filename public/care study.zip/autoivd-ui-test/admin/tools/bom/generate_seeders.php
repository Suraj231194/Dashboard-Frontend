<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';

/**
 * Regenerates the six BOM seeders from the resolved model so a fresh install
 * reproduces the corrected catalogue instead of the old, mis-mapped one.
 *
 * The generated SQL is idempotent: it keys on product_code, reuses an existing
 * bom_master row for the finished product, and replaces that BOM's items.
 */

const BOM_SEEDER_FILES = [
    'biochem_packaging' => 'bom_biochemistry_seeder.sql',
    'biochem_reagent' => 'bom_biochemistry_reagents_seeder.sql',
    'hematology' => 'bom_hematology_seeder.sql',
    'rapid_tests' => 'bom_rapid_tests_seeder.sql',
    'serology_turbi' => 'bom_serology_turbi_seeder.sql',
    'uncut_sheets' => 'bom_uncut_sheets_seeder.sql',
];

function bom_sql_string(?string $value): string
{
    if ($value === null) {
        return 'NULL';
    }

    return "'" . str_replace(["\\", "'"], ["\\\\", "''"], $value) . "'";
}

function bom_sql_number(float $value): string
{
    return rtrim(rtrim(number_format($value, 6, '.', ''), '0'), '.') ?: '0';
}

$model = bom_build_model();
$outputDir = bom_project_root() . '/admin/seeders';

$grouped = [];
foreach ($model as $sheet) {
    if ($sheet['duplicate_of'] !== null) {
        continue;
    }

    $grouped[$sheet['workbook_key']][] = $sheet;
}

$totalBoms = 0;
$totalItems = 0;

foreach (BOM_SEEDER_FILES as $key => $fileName) {
    $sheets = $grouped[$key] ?? [];
    $workbook = $sheets === [] ? '' : $sheets[0]['workbook'];

    $sql = [];
    $sql[] = '-- =============================================================';
    $sql[] = '-- Seeder: ' . $fileName;
    $sql[] = '-- Workbook: ' . $workbook;
    $sql[] = '-- BOMs: ' . count($sheets);
    $sql[] = '--';
    $sql[] = '-- GENERATED FILE - do not edit by hand.';
    $sql[] = '-- Regenerate with: php admin/tools/bom/generate_seeders.php';
    $sql[] = '-- Every product_code below is resolved from the inventory master;';
    $sql[] = '-- unmatched codes are skipped rather than guessed.';
    $sql[] = '-- =============================================================';
    $sql[] = '';
    $sql[] = 'SET SESSION max_statement_time = 0;';
    $sql[] = '';

    $itemCount = 0;

    foreach ($sheets as $index => $sheet) {
        $items = [];

        foreach ($sheet['components'] as $component) {
            $code = $component['product_code'];
            $items[$code] ??= ['qty' => 0.0, 'unit' => $component['unit_short'], 'name' => $component['product_name']];
            $items[$code]['qty'] += $component['qty'];
        }

        $itemCount += count($items);

        $sql[] = '-- -------------------------------------------------------------';
        $sql[] = sprintf('-- BOM %d/%d: %s', $index + 1, count($sheets), $sheet['finished_name']);
        $sql[] = sprintf('-- Sheet "%s" | Product %s | Components %d', $sheet['sheet'], $sheet['finished_code'], count($items));
        $sql[] = '-- -------------------------------------------------------------';
        $sql[] = 'SET @f_code = ' . bom_sql_string($sheet['finished_code']) . ';';
        $sql[] = 'SET @f_name = ' . bom_sql_string($sheet['finished_name']) . ';';
        $sql[] = 'SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);';
        $sql[] = 'SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);';
        $sql[] = 'SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);';
        $sql[] = '';
        $sql[] = 'INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)';
        $sql[] = sprintf(
            'SELECT @f_name, @c_id, @f_id, %d, CONCAT(\'BOM for \', @f_name), 1, \'APPROVED\', \'ORIGINAL\', 1, NOW()',
            $sheet['bom_type']
        );
        $sql[] = 'WHERE @f_id IS NOT NULL AND @bom_id IS NULL;';
        $sql[] = '';
        $sql[] = 'SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));';
        $sql[] = '';
        $sql[] = 'UPDATE `bom_master`';
        $sql[] = sprintf(
            'SET `name` = @f_name, `category_id` = @c_id, `bom_type` = %d, `status` = 1, `bom_status` = \'APPROVED\', `deleted_at` = NULL, `deleted_by` = NULL',
            $sheet['bom_type']
        );
        $sql[] = 'WHERE `id` = @bom_id;';
        $sql[] = '';
        $sql[] = 'DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;';
        $sql[] = '';

        foreach ($items as $code => $item) {
            $sql[] = '-- ' . $item['name'];
            $sql[] = 'INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)';
            $sql[] = sprintf(
                'SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = %s LIMIT 1), %s, 1, 1, NOW()',
                bom_sql_string($item['unit']),
                bom_sql_number($item['qty'])
            );
            $sql[] = sprintf('FROM `products` p WHERE p.`product_code` = %s AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;', bom_sql_string((string)$code));
        }

        $sql[] = '';
        $sql[] = 'DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;';
        $sql[] = 'INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)';
        $sql[] = 'SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()';
        $sql[] = 'FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;';
        $sql[] = '';
    }

    file_put_contents($outputDir . '/' . $fileName, implode(PHP_EOL, $sql) . PHP_EOL);

    $totalBoms += count($sheets);
    $totalItems += $itemCount;

    bom_out(sprintf('%-40s boms=%-4d items=%-5d', $fileName, count($sheets), $itemCount));
}

bom_out('');
bom_out('Total BOMs : ' . $totalBoms);
bom_out('Total items: ' . $totalItems);
