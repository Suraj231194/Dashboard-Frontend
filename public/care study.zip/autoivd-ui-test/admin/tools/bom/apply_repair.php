<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';
require_once __DIR__ . '/plan_repair.php';

/**
 * Applies the BOM repair plan.
 *
 * Safety properties:
 *   - dry run by default; writing requires --apply
 *   - aborts before touching anything if a sheet or component is unresolved
 *   - snapshots every affected bom_master/bom_items row into bom_repair_backup
 *   - runs in a single transaction
 *   - idempotent: a second run reports zero changes
 *
 * Usage: php apply_repair.php [--apply] [--user=1]
 */

const BOM_BACKUP_TABLE = 'bom_repair_backup';

function bom_ensure_backup_table(PDO $pdo): void
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS `' . BOM_BACKUP_TABLE . '` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `run_id` CHAR(36) NOT NULL,
        `source_table` VARCHAR(64) NOT NULL,
        `source_id` INT NOT NULL,
        `row_json` LONGTEXT NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_run` (`run_id`),
        KEY `idx_source` (`source_table`, `source_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
}

function bom_run_id(): string
{
    $bytes = random_bytes(16);
    $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
    $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);

    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
}

$apply = in_array('--apply', $argv, true);
$userId = 1;

foreach ($argv as $arg) {
    if (str_starts_with($arg, '--user=')) {
        $userId = (int)substr($arg, 7);
    }
}

$pdo = bom_pdo();
$plan = bom_plan_repair();

// The flattened copy of every BOM, so it is only rewritten where it differs.
$currentFlat = [];

foreach ($pdo->query('SELECT finished_product_id, raw_product_id, qty_per_unit FROM product_bom WHERE deleted_at IS NULL') as $row) {
    $currentFlat[(int)$row['finished_product_id']][(int)$row['raw_product_id']] = (float)$row['qty_per_unit'];
}

// ---- Preconditions -------------------------------------------------------
$blockers = [];

foreach (bom_build_model() as $sheet) {
    if ($sheet['finished_id'] === null) {
        $blockers[] = 'unresolved finished product: ' . $sheet['sheet_key'];
    }

    foreach ($sheet['components'] as $component) {
        if ($component['product_id'] === null) {
            $blockers[] = 'unresolved component: ' . $sheet['sheet_key'] . ' / ' . $component['description'];
        }
        if ($component['unit_id'] === null) {
            $blockers[] = 'unmapped unit: ' . $sheet['sheet_key'] . ' / ' . $component['description'] . ' unit="' . $component['unit'] . '"';
        }
    }
}

if ($blockers !== []) {
    bom_out('ABORTED - unresolved data, nothing was written:');
    foreach (array_slice($blockers, 0, 40) as $blocker) {
        bom_out('  ' . $blocker);
    }
    bom_out('  total blockers: ' . count($blockers));
    exit(1);
}

bom_out($apply ? '*** APPLY MODE - the database will be modified ***' : '--- DRY RUN - no changes will be written ---');
bom_out('');

$runId = bom_run_id();
$stats = [
    'bom_master_updated' => 0,
    'bom_master_inserted' => 0,
    'items_inserted' => 0,
    'items_deleted' => 0,
    'items_updated' => 0,
    'items_deduplicated' => 0,
    'product_bom_rewritten' => 0,
];

if ($apply) {
    bom_ensure_backup_table($pdo);
    $pdo->beginTransaction();
}

try {
    $backup = $apply
        ? $pdo->prepare('INSERT INTO `' . BOM_BACKUP_TABLE . '` (run_id, source_table, source_id, row_json) VALUES (?, ?, ?, ?)')
        : null;

    $snapshot = static function (string $table, int $id) use ($pdo, $backup, $runId): void {
        if ($backup === null) {
            return;
        }

        $statement = $pdo->prepare('SELECT * FROM `' . $table . '` WHERE id = ?');
        $statement->execute([$id]);
        $row = $statement->fetch();

        if ($row !== false) {
            $backup->execute([$runId, $table, $id, json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
        }
    };

    foreach ($plan['targets'] as $target) {
        $sheet = $target['sheet'];
        $bomId = $target['bom_id'];

        $wanted = [];
        foreach ($target['wanted_items'] as $item) {
            $wanted[$item['raw_product_id']] = $item;
        }

        $current = [];
        if ($bomId !== null) {
            foreach ($plan['existing'][$bomId]['items'] as $item) {
                $current[$item['raw_product_id']] = $item;
            }
        }

        $masterNeedsUpdate = $bomId === null
            || $plan['existing'][$bomId]['finished_product_id'] !== $sheet['finished_id']
            || $plan['existing'][$bomId]['bom_type'] !== $sheet['bom_type']
            || $plan['existing'][$bomId]['name'] !== $sheet['finished_name']
            || $plan['existing'][$bomId]['status'] !== 1
            || $plan['existing'][$bomId]['bom_status'] !== 'APPROVED';

        if ($bomId === null) {
            $stats['bom_master_inserted']++;

            if ($apply) {
                $insert = $pdo->prepare(
                    'INSERT INTO bom_master (name, category_id, finished_product_id, bom_type, descriptions, status, bom_status, source_type, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, 1, \'APPROVED\', \'ORIGINAL\', ?, NOW())'
                );
                $insert->execute([
                    $sheet['finished_name'],
                    $sheet['finished_category_id'],
                    $sheet['finished_id'],
                    $sheet['bom_type'],
                    'BOM for ' . $sheet['finished_name'] . ' (source: ' . $sheet['workbook'] . ' / ' . $sheet['sheet'] . ')',
                    $userId,
                ]);
                $bomId = (int)$pdo->lastInsertId();
            }
        } elseif ($masterNeedsUpdate) {
            $stats['bom_master_updated']++;

            if ($apply) {
                $snapshot('bom_master', $bomId);

                $update = $pdo->prepare(
                    'UPDATE bom_master
                     SET name = ?, category_id = ?, finished_product_id = ?, bom_type = ?, descriptions = ?,
                         status = 1, bom_status = \'APPROVED\', updated_by = ?, updated_at = NOW()
                     WHERE id = ?'
                );
                $update->execute([
                    $sheet['finished_name'],
                    $sheet['finished_category_id'],
                    $sheet['finished_id'],
                    $sheet['bom_type'],
                    'BOM for ' . $sheet['finished_name'] . ' (source: ' . $sheet['workbook'] . ' / ' . $sheet['sheet'] . ')',
                    $userId,
                    $bomId,
                ]);
            }
        }

        foreach ($target['duplicate_item_ids'] as $duplicateId) {
            $stats['items_deduplicated']++;

            if ($apply) {
                $snapshot('bom_items', $duplicateId);
                $pdo->prepare('DELETE FROM bom_items WHERE id = ?')->execute([$duplicateId]);
            }
        }

        foreach (array_diff_key($current, $wanted) as $productId => $item) {
            $stats['items_deleted']++;

            if ($apply) {
                $snapshot('bom_items', $item['id']);
                $pdo->prepare('DELETE FROM bom_items WHERE id = ?')->execute([$item['id']]);
            }
        }

        foreach (array_diff_key($wanted, $current) as $productId => $item) {
            $stats['items_inserted']++;

            if ($apply && $bomId !== null) {
                $pdo->prepare(
                    'INSERT INTO bom_items (bom_id, raw_product_category_id, raw_product_id, qty_unit_id, qty_per_unit, status, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, 1, ?, NOW())'
                )->execute([
                    $bomId,
                    $item['raw_product_category_id'],
                    $item['raw_product_id'],
                    $item['qty_unit_id'],
                    $item['qty_per_unit'],
                    $userId,
                ]);
            }
        }

        foreach (array_intersect_key($wanted, $current) as $productId => $item) {
            $have = $current[$productId];

            if (abs($have['qty_per_unit'] - $item['qty_per_unit']) <= 0.0000005
                && $have['qty_unit_id'] === $item['qty_unit_id']
                && $have['raw_product_category_id'] === $item['raw_product_category_id']) {
                continue;
            }

            $stats['items_updated']++;

            if ($apply) {
                $snapshot('bom_items', $have['id']);
                $pdo->prepare(
                    'UPDATE bom_items
                     SET qty_per_unit = ?, qty_unit_id = ?, raw_product_category_id = ?, status = 1, updated_by = ?, updated_at = NOW()
                     WHERE id = ?'
                )->execute([
                    $item['qty_per_unit'],
                    $item['qty_unit_id'],
                    $item['raw_product_category_id'],
                    $userId,
                    $have['id'],
                ]);
            }
        }

        $flatWanted = [];
        foreach ($wanted as $item) {
            $flatWanted[$item['raw_product_id']] = round($item['qty_per_unit'], 3);
        }

        $flatCurrent = $currentFlat[$sheet['finished_id']] ?? [];
        ksort($flatWanted);
        ksort($flatCurrent);

        if ($flatWanted !== $flatCurrent) {
            $stats['product_bom_rewritten']++;

            if ($apply && $bomId !== null) {
                $pdo->prepare('DELETE FROM product_bom WHERE finished_product_id = ?')->execute([$sheet['finished_id']]);

                $values = [];
                $params = [];

                foreach ($wanted as $item) {
                    $values[] = '(?, ?, ?, ?, 1, ?, NOW())';
                    array_push(
                        $params,
                        $sheet['finished_id'],
                        $item['raw_product_category_id'],
                        $item['raw_product_id'],
                        $item['qty_per_unit'],
                        $userId
                    );
                }

                if ($values !== []) {
                    $pdo->prepare(
                        'INSERT INTO product_bom (finished_product_id, raw_product_category_id, raw_product_id, qty_per_unit, status, created_by, created_at) VALUES '
                        . implode(', ', $values)
                    )->execute($params);
                }
            }
        }
    }

    if ($apply) {
        $pdo->commit();
    }
} catch (Throwable $e) {
    if ($apply && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    bom_out('FAILED - transaction rolled back: ' . $e->getMessage());
    exit(1);
}

bom_out('=== CHANGES ' . ($apply ? 'APPLIED' : 'PENDING') . ' ===');
foreach ($stats as $key => $value) {
    bom_out(sprintf('  %-24s %d', $key, $value));
}

if ($apply) {
    bom_out('');
    bom_out('Backup run id: ' . $runId);
    bom_out('Restore with: php admin/tools/bom/rollback_repair.php ' . $runId);
}
