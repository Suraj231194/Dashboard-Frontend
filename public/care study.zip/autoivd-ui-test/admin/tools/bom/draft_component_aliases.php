<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';
require_once __DIR__ . '/propose_components_lib.php';

/**
 * Writes a draft alias_components.php for review: every still-unresolved
 * description mapped to its best candidate, annotated with the score and the
 * runner-up so each line can be confirmed or corrected by hand.
 */

$model = bom_build_model();
$catalog = bom_db_catalog();

$problems = [];

foreach ($model as $sheet) {
    foreach ($sheet['components'] as $component) {
        if ($component['resolution'] === 'OK' || $component['resolution'] === 'IGNORED') {
            continue;
        }

        $problems[$component['description']] ??= ['count' => 0, 'sheets' => []];
        $problems[$component['description']]['count']++;

        if (count($problems[$component['description']]['sheets']) < 2) {
            $problems[$component['description']]['sheets'][] = $sheet['sheet_key'];
        }
    }
}

ksort($problems);

$lines = [
    '<?php',
    '',
    'declare(strict_types=1);',
    '',
    '/**',
    ' * DRAFT - review every line before copying over alias_components.php.',
    ' * Key   : bom_normalize_strict(ITEM DESCRIPTION)',
    ' * Value : inventory product_code, or null to drop the row.',
    ' */',
    '',
    'return [',
];

foreach ($problems as $description => $info) {
    $ranked = [];

    foreach ($catalog as $product) {
        $ranked[] = ['score' => bom_component_score($description, $product['product_name']), 'product' => $product];
    }

    usort($ranked, static fn (array $x, array $y): int => $y['score'] <=> $x['score']);

    $top = $ranked[0];
    $second = $ranked[1] ?? null;

    $lines[] = sprintf('    // x%d  "%s"  [%s]', $info['count'], $description, implode(', ', $info['sheets']));
    $lines[] = sprintf(
        '    //     %.4f %s | runner-up %.4f %s',
        $top['score'],
        $top['product']['product_name'],
        $second['score'] ?? 0,
        $second['product']['product_name'] ?? '-'
    );
    $lines[] = sprintf(
        '    %s => %s,',
        var_export(bom_normalize_strict($description), true),
        var_export($top['product']['product_code'], true)
    );
    $lines[] = '';
}

$lines[] = '];';
$lines[] = '';

file_put_contents(__DIR__ . '/_draft_alias_components.php', implode(PHP_EOL, $lines));

bom_out('Draft entries: ' . count($problems));
bom_out('Written      : _draft_alias_components.php');
