<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

/**
 * Finds every table that stores a BOM reference, so the repair can be judged
 * against what production actually points at.
 */

$pdo = bom_pdo();
$database = $pdo->query('SELECT DATABASE()')->fetchColumn();

$sql = "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = :db
          AND (COLUMN_NAME LIKE '%bom%')
        ORDER BY TABLE_NAME, ORDINAL_POSITION";

$statement = $pdo->prepare($sql);
$statement->execute(['db' => $database]);

$byTable = [];

foreach ($statement->fetchAll() as $row) {
    $byTable[$row['TABLE_NAME']][] = $row['COLUMN_NAME'] . ' (' . $row['DATA_TYPE'] . ')';
}

foreach ($byTable as $table => $columns) {
    $count = $pdo->query('SELECT COUNT(*) FROM `' . $table . '`')->fetchColumn();
    bom_out(sprintf('%-34s rows=%-8s %s', $table, $count, implode(', ', $columns)));
}

bom_out('');
bom_out('=== tables named like bom ===');
foreach ($pdo->query("SHOW TABLES LIKE '%bom%'") as $row) {
    $table = current($row);
    bom_out('  ' . $table . ' rows=' . $pdo->query('SELECT COUNT(*) FROM `' . $table . '`')->fetchColumn());
}
