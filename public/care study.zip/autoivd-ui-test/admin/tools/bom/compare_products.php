<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/inventory_master.php';

/**
 * Compares the inventory workbook against the products table so code drift
 * (duplicate CAT numbers, renamed prefixes) is visible before anything is repaired.
 */

$pdo = bom_pdo();
$inventory = bom_inventory_workbook();

$excelByCode = [];
foreach ($inventory['products'] as $product) {
    $excelByCode[strtoupper($product['product_code'])][] = $product;
}

$dupExcel = array_filter($excelByCode, static fn (array $rows): bool => count($rows) > 1);

bom_out('Excel products            : ' . count($inventory['products']));
bom_out('Excel distinct CAT codes  : ' . count($excelByCode));
bom_out('Excel duplicate CAT codes : ' . count($dupExcel));
bom_out('');

$dbRows = $pdo->query('SELECT id, product_code, product_name, category_id, unit_id, status, deleted_at FROM products')->fetchAll();

$dbByCode = [];
foreach ($dbRows as $row) {
    $dbByCode[strtoupper((string)$row['product_code'])][] = $row;
}

$dupDb = array_filter($dbByCode, static fn (array $rows): bool => count($rows) > 1);

bom_out('DB products               : ' . count($dbRows));
bom_out('DB distinct product_code  : ' . count($dbByCode));
bom_out('DB duplicate product_code : ' . count($dupDb));
bom_out('');

$missingInDb = array_diff(array_keys($excelByCode), array_keys($dbByCode));
$missingInExcel = array_diff(array_keys($dbByCode), array_keys($excelByCode));

bom_out('Codes in Excel but not DB : ' . count($missingInDb));
foreach (array_slice($missingInDb, 0, 20) as $code) {
    bom_out('  ' . $code . ' -> ' . $excelByCode[$code][0]['product_name']);
}

bom_out('');
bom_out('Codes in DB but not Excel : ' . count($missingInExcel));
foreach (array_slice($missingInExcel, 0, 30) as $code) {
    bom_out('  ' . $code . ' -> ' . $dbByCode[$code][0]['product_name']);
}

bom_out('');
bom_out('=== DB prefix distribution ===');
$prefix = [];
foreach ($dbRows as $row) {
    $parts = explode('/', (string)$row['product_code']);
    $key = $parts[1] ?? '(none)';
    $prefix[$key] = ($prefix[$key] ?? 0) + 1;
}
ksort($prefix);
foreach ($prefix as $key => $count) {
    bom_out(sprintf('  %-16s %d', $key, $count));
}

bom_out('');
bom_out('=== Sample DB duplicates ===');
$shown = 0;
foreach ($dupDb as $code => $rows) {
    if ($shown++ >= 15) {
        break;
    }
    bom_out('  ' . $code);
    foreach ($rows as $row) {
        bom_out(sprintf('      id=%-5d %s', $row['id'], $row['product_name']));
    }
}
