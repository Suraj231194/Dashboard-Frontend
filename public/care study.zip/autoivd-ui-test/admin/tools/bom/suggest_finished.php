<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/inventory_master.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/scoring.php';

/**
 * Detailed candidate listing for a single sheet or a filtered set of sheets.
 * Usage: php suggest_finished.php [sheetFilter] [topN]
 */

$filter = $argv[1] ?? null;
$topN = (int)($argv[2] ?? 6);

$sheets = bom_extract_workbooks();
$inventory = bom_inventory_workbook();
$catalog = bom_db_catalog();
$scopes = bom_workbook_scope();
$aliases = bom_finished_aliases();
$resolver = new BomResolver($catalog);

$preferred = [];
foreach ($inventory['prep'] as $row) {
    if ($row['bom_available']) {
        $preferred[strtoupper($row['product_code'])] = true;
    }
}

foreach ($sheets as $sheet) {
    if ($filter !== null && stripos($sheet['sheet'], $filter) === false && stripos($sheet['item_name'], $filter) === false) {
        continue;
    }

    $scope = $scopes[$sheet['workbook_key']] ?? [];
    $resolved = $resolver->resolve($sheet['item_name'], '', $scope, $aliases);

    bom_out(sprintf(
        '[%s] sheet="%s" item="%s" gene="%s" status=%s',
        $sheet['workbook_key'],
        $sheet['sheet'],
        $sheet['item_name'],
        $sheet['generic_name'],
        $resolved['status']
    ));
    bom_out('    norm: ' . bom_normalize($sheet['item_name']) . '   sizes: ' . implode(',', bom_size_tokens($sheet['item_name'])));

    $ranked = bom_rank_candidates([$sheet['item_name'], $sheet['generic_name'], $sheet['sheet']], $catalog, $scope, $preferred);

    foreach (array_slice($ranked, 0, $topN) as $candidate) {
        bom_out(sprintf(
            '    %.4f %s%-26s %s',
            $candidate['score'],
            isset($preferred[strtoupper($candidate['product']['product_code'])]) ? '* ' : '  ',
            $candidate['product']['product_code'],
            $candidate['product']['product_name']
        ));
    }

    bom_out('');
}
