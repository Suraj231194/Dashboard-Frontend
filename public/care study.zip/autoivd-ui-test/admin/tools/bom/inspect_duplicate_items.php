<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';

$pdo = bom_pdo();

$sql = "SELECT bi.bom_id, bi.raw_product_id, COUNT(*) c, GROUP_CONCAT(bi.id) ids, GROUP_CONCAT(bi.qty_per_unit) qtys
        FROM bom_items bi
        JOIN bom_master bm ON bm.id = bi.bom_id
        WHERE bi.deleted_at IS NULL AND bm.deleted_at IS NULL
        GROUP BY bi.bom_id, bi.raw_product_id
        HAVING c > 1
        ORDER BY bi.bom_id";

$rows = $pdo->query($sql)->fetchAll();

foreach ($rows as $row) {
    bom_out(sprintf('  bom#%-5d product=%-6d x%d ids=%s qty=%s', $row['bom_id'], $row['raw_product_id'], $row['c'], $row['ids'], $row['qtys']));
}

bom_out('duplicate (bom, product) pairs: ' . count($rows));
bom_out('extra rows: ' . array_sum(array_map(static fn (array $r): int => (int)$r['c'] - 1, $rows)));
