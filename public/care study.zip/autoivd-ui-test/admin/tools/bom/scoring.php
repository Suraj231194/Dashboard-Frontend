<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/resolver.php';

/**
 * Similarity scoring used to propose finished-product candidates.
 * Scores are only ever used to build a reviewable crosswalk, never applied blindly.
 */

const BOM_STOPWORDS = [
    'BIOGENIX', 'BIOGE', 'BIO', 'REAGENT', 'REAGENTS', 'KIT', 'KITS', 'TEST', 'TESTS',
    'RAPID', 'UNCUT', 'SHEET', 'SHEETS', 'BULK', 'IN', 'THE', 'OF', 'FOR', 'AND',
    'PCS', 'NOS', 'NO', 'ML', 'MML', 'LTR', 'L', 'POCT',
];

function bom_size_unit(string $unit): string
{
    return match (strtoupper($unit)) {
        'L', 'LTR' => 'LTR',
        'T', 'TEST' => 'TEST',
        'G', 'GM' => 'GM',
        'MG' => 'MG',
        default => 'ML',
    };
}

/** Pulls pack-size signatures such as "100 ML", "4X50ML", "20 LTR", "25 TEST". */
function bom_size_tokens(string $value): array
{
    $norm = bom_normalize($value);
    $sizes = [];

    if (preg_match_all('/\b(\d+)\s*X\s*(\d+)\s*(ML|L|LTR|TEST|T)\b/', $norm, $m, PREG_SET_ORDER) > 0) {
        foreach ($m as $match) {
            $sizes[] = $match[1] . 'X' . $match[2] . bom_size_unit($match[3]);
        }
    }

    if (preg_match_all('/\b(\d+(?:\.\d+)?)\s*(ML|LTR|L|TEST|T|GM|G|MG)\b/', $norm, $m, PREG_SET_ORDER) > 0) {
        foreach ($m as $match) {
            $sizes[] = $match[1] . bom_size_unit($match[2]);
        }
    }

    return array_values(array_unique($sizes));
}

function bom_keywords(string $value): array
{
    $tokens = array_filter(
        explode(' ', bom_normalize($value)),
        static fn (string $t): bool => $t !== ''
            && !in_array($t, BOM_STOPWORDS, true)
            && preg_match('/^\d+$/', $t) !== 1
    );

    return array_values(array_unique($tokens));
}

function bom_score(string $sheetName, string $productName): float
{
    $a = bom_keywords($sheetName);
    $b = bom_keywords($productName);

    if ($a === [] || $b === []) {
        return 0.0;
    }

    $shared = count(array_intersect($a, $b));
    $jaccard = $shared / count(array_unique(array_merge($a, $b)));

    $sizesA = bom_size_tokens($sheetName);
    $sizesB = bom_size_tokens($productName);
    $sizeBonus = 0.0;

    if ($sizesA !== [] && $sizesB !== []) {
        $sizeBonus = array_intersect($sizesA, $sizesB) !== [] ? 0.45 : -0.35;
    }

    similar_text(bom_normalize($sheetName), bom_normalize($productName), $percent);

    return round(($jaccard * 0.55) + ($percent / 100 * 0.2) + $sizeBonus, 4);
}

/**
 * @param list<array<string,string>> $products
 * @return list<array{score:float, product:array<string,string>}>
 */
function bom_rank_candidates(array $texts, array $products, array $scopeCodes, array $preferredCodes): array
{
    $candidates = [];

    foreach ($products as $product) {
        if ($scopeCodes !== [] && !in_array($product['category_code'], $scopeCodes, true)) {
            continue;
        }

        $score = 0.0;
        foreach ($texts as $text) {
            if ($text === '') {
                continue;
            }
            $score = max($score, bom_score($text, $product['product_name']));
        }

        if (isset($preferredCodes[strtoupper($product['product_code'])])) {
            $score += 0.08;
        }

        $candidates[] = ['score' => $score, 'product' => $product];
    }

    usort($candidates, static fn (array $x, array $y): int => $y['score'] <=> $x['score']);

    return $candidates;
}
