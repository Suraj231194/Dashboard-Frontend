<?php

declare(strict_types=1);

/**
 * Shared PDO bootstrap for the BOM audit/repair tooling.
 * Reads credentials from the project .env so nothing is hard-coded.
 */

function bom_project_root(): string
{
    return dirname(__DIR__, 3);
}

function bom_env(): array
{
    static $env = null;

    if ($env !== null) {
        return $env;
    }

    $path = bom_project_root() . DIRECTORY_SEPARATOR . '.env';
    $localPath = bom_project_root() . DIRECTORY_SEPARATOR . '.env.local';

    if (!is_readable($path) && !is_readable($localPath)) {
        throw new RuntimeException('Unable to read .env at ' . $path);
    }

    $env = [];

    if (is_readable($path)) {
        foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
        $line = trim($line);

        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $pos = strpos($line, '=');
        if ($pos === false) {
            continue;
        }

        $key = trim(substr($line, 0, $pos));
        $value = trim(substr($line, $pos + 1));
        $len = strlen($value);

        if ($len >= 2) {
            $first = $value[0];
            $last = $value[$len - 1];
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $value = substr($value, 1, -1);
            }
        }

        $env[$key] = $value;
        }
    }

    $localPath = bom_project_root() . DIRECTORY_SEPARATOR . '.env.local';
    if (is_readable($localPath)) {
        foreach (file($localPath, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
            $line = trim($line);

            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $pos = strpos($line, '=');
            if ($pos === false) {
                continue;
            }

            $key = trim(substr($line, 0, $pos));
            $value = trim(substr($line, $pos + 1));
            $len = strlen($value);

            if ($len >= 2) {
                $first = $value[0];
                $last = $value[$len - 1];
                if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                    $value = substr($value, 1, -1);
                }
            }

            $env[$key] = $value;
        }
    }

    return $env;
}

function bom_pdo(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $env = bom_env();

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        $env['DB_HOST'] ?? '127.0.0.1',
        $env['DB_PORT'] ?? '3306',
        $env['DB_DATABASE'] ?? ''
    );

    $pdo = new PDO($dsn, $env['DB_USERNAME'] ?? '', $env['DB_PASSWORD'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 30,
    ]);

    return $pdo;
}

function bom_out(string $message = ''): void
{
    echo $message . PHP_EOL;
}
