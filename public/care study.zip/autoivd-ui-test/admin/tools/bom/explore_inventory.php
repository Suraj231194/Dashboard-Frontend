<?php

declare(strict_types=1);

require dirname(__DIR__, 3) . '/vendor/autoload.php';
require __DIR__ . '/bom_db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$file = bom_project_root() . '/BOM/Inventory Management - Final.xlsx';

$reader = IOFactory::createReaderForFile($file);
$reader->setReadDataOnly(true);
$book = $reader->load($file);

bom_out('SHEETS (' . $book->getSheetCount() . '): ' . implode(' | ', $book->getSheetNames()));
bom_out('');

$maxRows = (int)($argv[1] ?? 8);

foreach ($book->getAllSheets() as $sheet) {
    bom_out('--- ' . $sheet->getTitle() . ' dims=' . $sheet->calculateWorksheetDimension());
    $rows = $sheet->toArray(null, true, false, false);

    foreach (array_slice($rows, 0, $maxRows) as $i => $row) {
        $cells = [];
        foreach ($row as $c => $v) {
            $v = trim((string)$v);
            if ($v === '') {
                continue;
            }
            $cells[] = $c . ':' . preg_replace('/\s+/', ' ', $v);
        }
        if ($cells !== []) {
            bom_out(sprintf('  r%-3d %s', $i + 1, implode(' || ', $cells)));
        }
    }

    bom_out('  TOTAL ROWS: ' . count($rows));
    bom_out('');
}
