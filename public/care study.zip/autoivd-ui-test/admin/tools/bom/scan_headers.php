<?php

declare(strict_types=1);

require dirname(__DIR__, 3) . '/vendor/autoload.php';
require __DIR__ . '/bom_db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 * Scans every BOM worksheet and prints the pre-table header block
 * (everything above the ITEM DESCRIPTION row) so catalogue numbers,
 * item names and batch sizes can be reviewed in one pass.
 */

$dir = bom_project_root() . '/BOM';
$files = glob($dir . '/BOMs*.xlsx') ?: [];

$totalSheets = 0;

foreach ($files as $file) {
    bom_out('#############################################################');
    bom_out('FILE: ' . basename($file));

    $reader = IOFactory::createReaderForFile($file);
    $reader->setReadDataOnly(true);
    $book = $reader->load($file);

    foreach ($book->getAllSheets() as $sheet) {
        $totalSheets++;
        $rows = $sheet->toArray(null, true, false, false);
        $header = [];

        foreach ($rows as $row) {
            $first = trim((string)($row[0] ?? ''));

            if (stripos($first, 'ITEM DESCRIPTION') !== false) {
                break;
            }

            $line = [];
            foreach ($row as $v) {
                $v = trim((string)$v);
                if ($v !== '') {
                    $line[] = preg_replace('/\s+/', ' ', $v);
                }
            }

            if ($line !== []) {
                $header[] = implode(' ~ ', $line);
            }
        }

        bom_out(sprintf('[%s] %s', $sheet->getTitle(), implode('  //  ', $header)));
    }

    $book->disconnectWorksheets();
    unset($book);
    bom_out('');
}

bom_out('TOTAL SHEETS: ' . $totalSheets);
