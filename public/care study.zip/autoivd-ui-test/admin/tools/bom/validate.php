<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';

/**
 * Validates the live BOM catalogue against the six workbooks.
 * Exit code 0 = everything matches, 1 = at least one check failed.
 */

$pdo = bom_pdo();
$model = bom_build_model();

$failures = [];
$checks = [];

$check = static function (string $name, bool $passed, string $detail = '') use (&$checks, &$failures): void {
    $checks[] = ['name' => $name, 'passed' => $passed, 'detail' => $detail];

    if (!$passed) {
        $failures[] = $name . ($detail === '' ? '' : ': ' . $detail);
    }
};

// ---- Workbook side -------------------------------------------------------
$active = array_values(array_filter($model, static fn (array $s): bool => $s['duplicate_of'] === null));

$excelRows = 0;
$unresolvedFinished = 0;
$unresolvedComponents = 0;
$unmappedUnits = 0;

foreach ($model as $sheet) {
    if ($sheet['finished_id'] === null) {
        $unresolvedFinished++;
    }

    foreach ($sheet['components'] as $component) {
        $excelRows++;

        if ($component['product_id'] === null) {
            $unresolvedComponents++;
        }
        if ($component['unit_id'] === null) {
            $unmappedUnits++;
        }
    }
}

$check('workbook sheets = 218', count($model) === 218, (string)count($model));
$check('workbook BOMs = 217', count($active) === 217, (string)count($active));
$check('workbook component rows = 2347', $excelRows === 2347, (string)$excelRows);
$check('every sheet resolves to a product', $unresolvedFinished === 0, $unresolvedFinished . ' unresolved');
$check('every component resolves to a product', $unresolvedComponents === 0, $unresolvedComponents . ' unresolved');
$check('every component unit maps to standard_units', $unmappedUnits === 0, $unmappedUnits . ' unmapped');

// ---- Expected model ------------------------------------------------------
$expected = [];

foreach ($active as $sheet) {
    $items = [];

    foreach ($sheet['components'] as $component) {
        $key = $component['product_id'];
        $items[$key] ??= ['qty' => 0.0, 'unit_id' => $component['unit_id']];
        $items[$key]['qty'] += $component['qty'];
    }

    $expected[$sheet['finished_id']] = [
        'sheet_key' => $sheet['sheet_key'],
        'bom_type' => $sheet['bom_type'],
        'items' => $items,
    ];
}

$expectedItems = array_sum(array_map(static fn (array $b): int => count($b['items']), $expected));

// ---- Database side -------------------------------------------------------
$live = [];

$sql = "SELECT id, finished_product_id, bom_type, status, bom_status
        FROM bom_master
        WHERE deleted_at IS NULL AND source_type = 'ORIGINAL'";

foreach ($pdo->query($sql) as $row) {
    $live[(int)$row['id']] = [
        'finished_product_id' => (int)$row['finished_product_id'],
        'bom_type' => (int)$row['bom_type'],
        'status' => (int)$row['status'],
        'bom_status' => (string)$row['bom_status'],
        'items' => [],
    ];
}

$itemSql = "SELECT bi.bom_id, bi.raw_product_id, bi.qty_unit_id, bi.qty_per_unit
            FROM bom_items bi
            JOIN bom_master bm ON bm.id = bi.bom_id
            WHERE bi.deleted_at IS NULL AND bm.deleted_at IS NULL AND bm.source_type = 'ORIGINAL'";

$liveItemRows = 0;

foreach ($pdo->query($itemSql) as $row) {
    $bomId = (int)$row['bom_id'];

    if (!isset($live[$bomId])) {
        continue;
    }

    $liveItemRows++;
    $live[$bomId]['items'][(int)$row['raw_product_id']][] = [
        'qty' => (float)$row['qty_per_unit'],
        'unit_id' => $row['qty_unit_id'] === null ? null : (int)$row['qty_unit_id'],
    ];
}

$check('live ORIGINAL BOMs = 217', count($live) === 217, (string)count($live));
$check('live component rows = ' . $expectedItems, $liveItemRows === $expectedItems, (string)$liveItemRows);

$liveByProduct = [];
foreach ($live as $id => $row) {
    $liveByProduct[$row['finished_product_id']][] = $id;
}

$duplicateBoms = array_filter($liveByProduct, static fn (array $ids): bool => count($ids) > 1);
$check('no duplicate BOM per finished product', $duplicateBoms === [], (string)count($duplicateBoms));

$missing = [];
$typeMismatch = [];
$notApproved = [];
$itemMismatch = [];
$duplicateItems = [];

foreach ($expected as $productId => $want) {
    $bomIds = $liveByProduct[$productId] ?? [];

    if ($bomIds === []) {
        $missing[] = $want['sheet_key'];
        continue;
    }

    $bomId = $bomIds[0];
    $have = $live[$bomId];

    if ($have['bom_type'] !== $want['bom_type']) {
        $typeMismatch[] = $want['sheet_key'] . ' (' . $have['bom_type'] . ' != ' . $want['bom_type'] . ')';
    }

    if ($have['bom_status'] !== 'APPROVED' || $have['status'] !== 1) {
        $notApproved[] = $want['sheet_key'];
    }

    foreach ($have['items'] as $rawProductId => $rows) {
        if (count($rows) > 1) {
            $duplicateItems[] = $want['sheet_key'] . ' product#' . $rawProductId;
        }
    }

    foreach ($want['items'] as $rawProductId => $item) {
        $rows = $have['items'][$rawProductId] ?? [];

        if ($rows === []) {
            $itemMismatch[] = $want['sheet_key'] . ' missing product#' . $rawProductId;
            continue;
        }

        if (abs($rows[0]['qty'] - $item['qty']) > 0.0000005) {
            $itemMismatch[] = sprintf('%s product#%d qty %s != %s', $want['sheet_key'], $rawProductId, $rows[0]['qty'], $item['qty']);
        }

        if ($rows[0]['unit_id'] !== $item['unit_id']) {
            $itemMismatch[] = sprintf('%s product#%d unit %s != %s', $want['sheet_key'], $rawProductId, var_export($rows[0]['unit_id'], true), var_export($item['unit_id'], true));
        }
    }

    foreach ($have['items'] as $rawProductId => $rows) {
        if (!isset($want['items'][$rawProductId])) {
            $itemMismatch[] = $want['sheet_key'] . ' unexpected product#' . $rawProductId;
        }
    }
}

$check('every workbook BOM exists in the database', $missing === [], implode(', ', array_slice($missing, 0, 5)));
$check('bom_type matches the workbook', $typeMismatch === [], implode(', ', array_slice($typeMismatch, 0, 5)));
$check('every BOM is active and APPROVED', $notApproved === [], implode(', ', array_slice($notApproved, 0, 5)));
$check('no duplicate component inside a BOM', $duplicateItems === [], implode(', ', array_slice($duplicateItems, 0, 5)));
$check('components, quantities and units match', $itemMismatch === [], implode(' | ', array_slice($itemMismatch, 0, 8)));

// ---- Referential integrity ------------------------------------------------
$danglingItems = $pdo->query(
    'SELECT COUNT(*) FROM bom_items bi LEFT JOIN products p ON p.id = bi.raw_product_id WHERE bi.deleted_at IS NULL AND p.id IS NULL'
)->fetchColumn();
$check('no bom_items point at a missing product', (int)$danglingItems === 0, (string)$danglingItems);

$danglingBoms = $pdo->query(
    'SELECT COUNT(*) FROM bom_master bm LEFT JOIN products p ON p.id = bm.finished_product_id WHERE bm.deleted_at IS NULL AND p.id IS NULL'
)->fetchColumn();
$check('no BOM points at a missing product', (int)$danglingBoms === 0, (string)$danglingBoms);

$brokenPlans = $pdo->query(
    'SELECT COUNT(*) FROM production_plans pp LEFT JOIN bom_master bm ON bm.id = pp.bom_master_id WHERE pp.bom_master_id > 0 AND bm.id IS NULL'
)->fetchColumn();
$check('production plans still resolve their BOM', (int)$brokenPlans === 0, (string)$brokenPlans);

$brokenRequisitions = $pdo->query(
    'SELECT COUNT(*) FROM material_requisition mr LEFT JOIN bom_master bm ON bm.id = mr.bom_master_id WHERE mr.bom_master_id > 0 AND bm.id IS NULL'
)->fetchColumn();
$check('material requisitions still resolve their BOM', (int)$brokenRequisitions === 0, (string)$brokenRequisitions);

// ---- Report ---------------------------------------------------------------
foreach ($checks as $result) {
    bom_out(sprintf(
        '[%s] %-48s %s',
        $result['passed'] ? 'PASS' : 'FAIL',
        $result['name'],
        $result['detail']
    ));
}

bom_out('');
bom_out(sprintf('%d checks, %d failed', count($checks), count($failures)));

exit($failures === [] ? 0 : 1);
