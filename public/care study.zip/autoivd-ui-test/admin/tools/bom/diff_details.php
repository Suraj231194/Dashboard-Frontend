<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';
require_once __DIR__ . '/db_catalog.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/aliases.php';
require_once __DIR__ . '/build_model.php';
require_once __DIR__ . '/plan_repair.php';

/**
 * Human-readable component-level diff between the live BOMs and the workbooks.
 */

$plan = bom_plan_repair();

$products = [];
foreach (bom_db_catalog() as $product) {
    $products[$product['id']] = $product;
}

$units = [];
foreach (bom_pdo()->query('SELECT id, short_name FROM standard_units') as $row) {
    $units[(int)$row['id']] = (string)$row['short_name'];
}

$label = static function (?int $productId) use ($products): string {
    if ($productId === null) {
        return '(none)';
    }

    $product = $products[$productId] ?? null;

    return $product === null
        ? '(unknown id ' . $productId . ')'
        : $product['product_code'] . ' ' . $product['product_name'];
};

foreach ($plan['targets'] as $target) {
    $diff = $target['diff'];

    if ($diff['added'] === [] && $diff['removed'] === [] && $diff['changed'] === []) {
        continue;
    }

    bom_out(sprintf(
        'bom#%-5s %-36s %s',
        $target['bom_id'] ?? 'NEW',
        $target['sheet']['sheet_key'],
        $target['sheet']['finished_code'] . ' ' . $target['sheet']['finished_name']
    ));

    $wanted = [];
    foreach ($target['wanted_items'] as $item) {
        $wanted[$item['raw_product_id']] = $item;
    }

    $current = [];
    if ($target['bom_id'] !== null) {
        foreach ($plan['existing'][$target['bom_id']]['items'] as $item) {
            $current[$item['raw_product_id']] = $item;
        }
    }

    foreach ($diff['removed'] as $productId) {
        bom_out(sprintf('    - REMOVE  %-10s %s', rtrim(rtrim(number_format($current[$productId]['qty_per_unit'], 6, '.', ''), '0'), '.'), $label((int)$productId)));
    }

    foreach ($diff['added'] as $productId) {
        bom_out(sprintf(
            '    + ADD     %-10s %-6s %s',
            rtrim(rtrim(number_format($wanted[$productId]['qty_per_unit'], 6, '.', ''), '0'), '.'),
            $units[$wanted[$productId]['qty_unit_id']] ?? '?',
            $label((int)$productId)
        ));
    }

    foreach ($diff['changed'] as $productId) {
        bom_out(sprintf(
            '    ~ QTY     %s %s -> %s %s   %s',
            rtrim(rtrim(number_format($current[$productId]['qty_per_unit'], 6, '.', ''), '0'), '.'),
            $units[$current[$productId]['qty_unit_id']] ?? '?',
            rtrim(rtrim(number_format($wanted[$productId]['qty_per_unit'], 6, '.', ''), '0'), '.'),
            $units[$wanted[$productId]['qty_unit_id']] ?? '?',
            $label((int)$productId)
        ));
    }

    bom_out('');
}
