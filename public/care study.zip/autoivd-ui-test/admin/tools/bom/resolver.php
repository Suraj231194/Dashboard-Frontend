<?php

declare(strict_types=1);

require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';

/**
 * Deterministic resolution of Excel free-text descriptions to inventory products.
 *
 * Matching is strictly ordered and never guesses:
 *   1. explicit CAT # from the workbook
 *   2. curated alias (description -> product code)
 *   3. exact match including the GST annotation ("BSA @18%")
 *   4. exact match ignoring the GST annotation, disambiguated by tax preference
 *   5. loose match (packaging/unit noise removed), same disambiguation
 * Anything else is reported as UNRESOLVED or AMBIGUOUS.
 */

/** Returns the GST annotation found in a product/description name, or ''. */
function bom_tax_token(string $value): string
{
    $value = strtoupper(bom_clean($value));

    if (preg_match('/@\s*(\d+(?:\.\d+)?)\s*%?/', $value, $m) === 1) {
        return (string)(float)$m[1];
    }

    if (preg_match('/\b(\d+(?:\.\d+)?)\s*%\s*GST\b/', $value, $m) === 1) {
        return (string)(float)$m[1];
    }

    return '';
}

/** Token-level spelling equivalences that are purely formatting, never semantic. */
const BOM_TOKEN_SYNONYMS = [
    'TESTS' => 'TEST',
    'SHEETS' => 'SHEET',
    'SHEE' => 'SHEET',
    'PIECES' => 'PCS',
    'PIECE' => 'PCS',
    'PC' => 'PCS',
    'NOS' => 'NO',
    'GMS' => 'GM',
    'GRAMS' => 'GM',
    'GRAM' => 'GM',
    'LTRS' => 'LTR',
    'LITRE' => 'LTR',
    'LITRES' => 'LTR',
    'MTRS' => 'MTR',
    'CMS' => 'CM',
    'VIALS' => 'VIAL',
    'BOTTLES' => 'BOTTLE',
    'BOTT' => 'BOTTLE',
    'POUCHES' => 'POUCH',
    'CARTONS' => 'CARTON',
    'FIA' => '',
];

/** Strips GST/tax annotations, punctuation, casing and formatting differences. */
function bom_normalize(string $value): string
{
    $value = strtoupper(bom_clean($value));
    $value = str_replace(
        ['’', '‘', '“', '”', '–', '—', '×', 'µ', 'μ', 'Μ'],
        ["'", "'", '"', '"', '-', '-', 'X', 'U', 'U', 'U'],
        $value
    );

    // "735*485*400" is a dimension; a trailing "*" is only a footnote marker.
    $value = preg_replace('/(?<=\d)\s*\*\s*(?=\d)/', ' X ', $value) ?? $value;

    $value = preg_replace('/@\s*\d+(?:\.\d+)?\s*%?/', ' ', $value) ?? $value;
    $value = preg_replace('/\b\d+(?:\.\d+)?\s*%\s*GST\b/', ' ', $value) ?? $value;
    $value = preg_replace('/\bGST\b/', ' ', $value) ?? $value;

    $value = preg_replace('/[^A-Z0-9.]+/', ' ', $value) ?? $value;
    $value = preg_replace('/(?<![0-9])\.|\.(?![0-9])/', ' ', $value) ?? $value;

    // "2ML" -> "2 ML", "5Ply" -> "5 PLY", "NS1" -> "NS 1"
    $value = preg_replace('/(?<=[0-9])(?=[A-Z])/', ' ', $value) ?? $value;
    $value = preg_replace('/(?<=[A-Z])(?=[0-9])/', ' ', $value) ?? $value;

    $tokens = [];

    foreach (explode(' ', $value) as $token) {
        $token = BOM_TOKEN_SYNONYMS[$token] ?? $token;

        if ($token !== '') {
            $tokens[] = $token;
        }
    }

    return implode(' ', $tokens);
}

/** Normalised name with the GST annotation preserved as a trailing token. */
function bom_normalize_strict(string $value): string
{
    $tax = bom_tax_token($value);

    return bom_normalize($value) . ($tax === '' ? '' : ' @' . $tax);
}

/** Additionally drops trailing packaging/unit noise so "SODIUM CHLORIDE GM" matches "SODIUM CHLORIDE". */
function bom_normalize_loose(string $value): string
{
    $value = bom_normalize($value);

    $noise = ['NO', 'PCS', 'GM', 'MG', 'ML', 'LTR', 'MTR', 'KU', 'KG', 'TEST', 'SHEET', 'KIT', 'KITS', 'EACH', 'UNIT', 'UNITS', 'RAPID', 'POCT', 'URINALYSIS', 'NOS'];

    $parts = $value === '' ? [] : explode(' ', $value);

    while ($parts !== [] && in_array(end($parts), $noise, true)) {
        array_pop($parts);
    }

    return implode(' ', $parts);
}

/** Whitespace-insensitive form, for names broken mid-word such as "Bo x" vs "Box". */
function bom_normalize_squash(string $value): string
{
    return str_replace(' ', '', bom_normalize($value));
}

final class BomResolver
{
    /** @var array<string, list<array<string, mixed>>> */
    private array $byStrict = [];

    /** @var array<string, list<array<string, mixed>>> */
    private array $byExact = [];

    /** @var array<string, list<array<string, mixed>>> */
    private array $byLoose = [];

    /** @var array<string, list<array<string, mixed>>> */
    private array $bySquash = [];

    /** @var array<string, array<string, mixed>> */
    private array $byCode = [];

    /** @param list<array<string, mixed>> $products */
    public function __construct(array $products)
    {
        foreach ($products as $product) {
            $entry = $product + ['tax' => bom_tax_token((string)$product['product_name'])];

            $this->byCode[strtoupper((string)$product['product_code'])] = $entry;
            $this->byStrict[bom_normalize_strict((string)$product['product_name'])][] = $entry;
            $this->byExact[bom_normalize((string)$product['product_name'])][] = $entry;

            $squash = bom_normalize_squash((string)$product['product_name']);
            if ($squash !== '') {
                $this->bySquash[$squash][] = $entry;
            }

            $loose = bom_normalize_loose((string)$product['product_name']);
            if ($loose !== '') {
                $this->byLoose[$loose][] = $entry;
            }
        }
    }

    public function hasCode(string $code): bool
    {
        return isset($this->byCode[strtoupper(bom_clean($code))]);
    }

    /** @return array<string, mixed>|null */
    public function byCode(string $code): ?array
    {
        return $this->byCode[strtoupper(bom_clean($code))] ?? null;
    }

    /**
     * @param list<string> $allowedCategoryCodes
     * @param array<string, string|null> $aliasMap
     * @return array{status:string, product:?array<string, mixed>, candidates:list<string>, method:string}
     */
    public function resolve(string $description, string $catNumber = '', array $allowedCategoryCodes = [], array $aliasMap = []): array
    {
        $catNumber = bom_clean($catNumber);

        if ($catNumber !== '' && $this->hasCode($catNumber)) {
            return ['status' => 'OK', 'product' => $this->byCode($catNumber), 'candidates' => [], 'method' => 'cat_number'];
        }

        $aliasKey = bom_normalize_strict($description);

        if (array_key_exists($aliasKey, $aliasMap)) {
            $target = $aliasMap[$aliasKey];

            if ($target === null) {
                return ['status' => 'IGNORED', 'product' => null, 'candidates' => [], 'method' => 'alias_ignore'];
            }

            $product = $this->byCode($target);

            if ($product === null) {
                return ['status' => 'ALIAS_BROKEN', 'product' => null, 'candidates' => [$target], 'method' => 'alias'];
            }

            return ['status' => 'OK', 'product' => $product, 'candidates' => [], 'method' => 'alias'];
        }

        $wantedTax = bom_tax_token($description);
        $ambiguous = null;

        $buckets = [
            ['byStrict', $aliasKey, 'strict_name'],
            ['byExact', bom_normalize($description), 'exact_name'],
            ['bySquash', bom_normalize_squash($description), 'squash_name'],
            ['byLoose', bom_normalize_loose($description), 'loose_name'],
        ];

        foreach ($buckets as [$bucket, $key, $method]) {
            if ($key === '') {
                continue;
            }

            $matches = $this->scope($this->{$bucket}[$key] ?? [], $allowedCategoryCodes);

            if ($matches === []) {
                continue;
            }

            $picked = $this->disambiguate($matches, $wantedTax, $method);

            if ($picked['status'] !== 'AMBIGUOUS') {
                return $picked;
            }

            $ambiguous ??= $picked;
        }

        return $ambiguous ?? ['status' => 'UNRESOLVED', 'product' => null, 'candidates' => [], 'method' => 'none'];
    }

    /**
     * @param list<array<string, mixed>> $matches
     * @return array{status:string, product:?array<string, mixed>, candidates:list<string>, method:string}
     */
    private function disambiguate(array $matches, string $wantedTax, string $method): array
    {
        if (count($matches) === 1) {
            return ['status' => 'OK', 'product' => $matches[0], 'candidates' => [], 'method' => $method];
        }

        if ($wantedTax !== '') {
            $exactTax = array_values(array_filter($matches, static fn (array $m): bool => $m['tax'] === $wantedTax));

            if (count($exactTax) === 1) {
                return ['status' => 'OK', 'product' => $exactTax[0], 'candidates' => [], 'method' => $method . '_tax'];
            }
        }

        // No GST annotation in the workbook, or none of the candidates carry it:
        // the untaxed master record is the base product.
        $untaxed = array_values(array_filter($matches, static fn (array $m): bool => $m['tax'] === ''));

        if (count($untaxed) === 1) {
            return ['status' => 'OK', 'product' => $untaxed[0], 'candidates' => [], 'method' => $method . '_base'];
        }

        // Identical duplicate master records (same name, same category): keep the oldest id.
        $pool = $untaxed !== [] ? $untaxed : $matches;
        $names = array_unique(array_map(static fn (array $m): string => bom_normalize_strict((string)$m['product_name']), $pool));
        $categories = array_unique(array_map(static fn (array $m): string => (string)$m['category_id'], $pool));

        if (count($names) === 1 && count($categories) === 1) {
            usort($pool, static fn (array $a, array $b): int => $a['id'] <=> $b['id']);

            return ['status' => 'OK', 'product' => $pool[0], 'candidates' => [], 'method' => $method . '_dup'];
        }

        return [
            'status' => 'AMBIGUOUS',
            'product' => null,
            'candidates' => array_values(array_unique(array_map(
                static fn (array $m): string => $m['product_code'] . ' :: ' . $m['product_name'],
                $matches
            ))),
            'method' => $method,
        ];
    }

    /** @param list<array<string, mixed>> $matches */
    private function scope(array $matches, array $allowedCategoryCodes): array
    {
        if ($allowedCategoryCodes === [] || $matches === []) {
            return array_values($matches);
        }

        $scoped = array_values(array_filter(
            $matches,
            static fn (array $m): bool => in_array($m['category_code'], $allowedCategoryCodes, true)
        ));

        return $scoped === [] ? array_values($matches) : $scoped;
    }
}
