<?php

declare(strict_types=1);

require __DIR__ . '/bom_db.php';

$pdo = bom_pdo();

bom_out('Server: ' . $pdo->query('SELECT VERSION()')->fetchColumn());
bom_out('Database: ' . $pdo->query('SELECT DATABASE()')->fetchColumn());
bom_out('');

foreach (['bom_master', 'bom_items', 'products', 'product_categories', 'standard_units'] as $table) {
    bom_out('=== ' . $table . ' ===');

    try {
        $rows = $pdo->query('SHOW COLUMNS FROM `' . $table . '`')->fetchAll();
    } catch (Throwable $e) {
        bom_out('  MISSING: ' . $e->getMessage());
        bom_out('');
        continue;
    }

    foreach ($rows as $row) {
        bom_out(sprintf(
            '  %-28s %-24s null=%-3s key=%-3s default=%s',
            $row['Field'],
            $row['Type'],
            $row['Null'],
            $row['Key'],
            $row['Default'] ?? 'NULL'
        ));
    }

    $count = $pdo->query('SELECT COUNT(*) FROM `' . $table . '`')->fetchColumn();
    bom_out('  ROWS: ' . $count);
    bom_out('');
}
