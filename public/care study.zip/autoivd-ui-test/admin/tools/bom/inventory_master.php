<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/vendor/autoload.php';
require_once __DIR__ . '/bom_db.php';
require_once __DIR__ . '/extract_workbooks.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 * Loads the inventory master sheet (the authoritative product catalogue)
 * and the BOM - Preparation sheet (the list of items that should own a BOM).
 */

function bom_inventory_workbook(): array
{
    static $cache = null;

    if ($cache !== null) {
        return $cache;
    }

    $file = bom_project_root() . '/BOM/Inventory Management - Final.xlsx';

    $reader = IOFactory::createReaderForFile($file);
    $reader->setReadDataOnly(true);
    $book = $reader->load($file);

    $products = [];

    foreach ($book->getSheetByName('Inventory Management - Final')->toArray(null, true, false, false) as $i => $row) {
        if ($i === 0) {
            continue;
        }

        $code = bom_clean((string)($row[3] ?? ''));
        $name = bom_clean((string)($row[4] ?? ''));

        if ($code === '' || $name === '') {
            continue;
        }

        $products[] = [
            'excel_row' => $i + 1,
            'category' => bom_clean((string)($row[1] ?? '')),
            'category_code' => bom_clean((string)($row[2] ?? '')),
            'product_code' => $code,
            'product_name' => $name,
            'unit' => bom_clean((string)($row[5] ?? '')),
            'line_category' => bom_clean((string)($row[6] ?? '')),
        ];
    }

    $prep = [];

    foreach ($book->getSheetByName('BOM - Preparation')->toArray(null, true, false, false) as $i => $row) {
        $code = bom_clean((string)($row[1] ?? ''));
        $name = bom_clean((string)($row[2] ?? ''));

        if ($code === '' || strcasecmp($code, 'CAT Number') === 0) {
            continue;
        }

        $prep[] = [
            'excel_row' => $i + 1,
            'category' => bom_clean((string)($row[0] ?? '')),
            'product_code' => $code,
            'product_name' => $name,
            'bom_available' => strtoupper(bom_clean((string)($row[3] ?? ''))) === 'YES',
            'remarks' => bom_clean((string)($row[4] ?? '')),
        ];
    }

    $book->disconnectWorksheets();

    $cache = ['products' => $products, 'prep' => $prep];

    return $cache;
}

if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === realpath(__FILE__)) {
    $data = bom_inventory_workbook();

    bom_out('Inventory products: ' . count($data['products']));
    bom_out('BOM prep rows     : ' . count($data['prep']));
    bom_out('');

    $byCategory = [];
    foreach ($data['products'] as $product) {
        $key = $product['category_code'] . ' | ' . $product['category'];
        $byCategory[$key] = ($byCategory[$key] ?? 0) + 1;
    }
    ksort($byCategory);

    bom_out('=== Inventory categories ===');
    foreach ($byCategory as $key => $count) {
        bom_out(sprintf('  %-60s %d', $key, $count));
    }

    $prepCategory = [];
    foreach ($data['prep'] as $row) {
        $key = $row['category'];
        $prepCategory[$key] ??= ['yes' => 0, 'total' => 0];
        $prepCategory[$key]['total']++;
        if ($row['bom_available']) {
            $prepCategory[$key]['yes']++;
        }
    }
    ksort($prepCategory);

    bom_out('');
    bom_out('=== BOM - Preparation categories (yes/total) ===');
    foreach ($prepCategory as $key => $counts) {
        bom_out(sprintf('  %-60s %d/%d', $key, $counts['yes'], $counts['total']));
    }
}
