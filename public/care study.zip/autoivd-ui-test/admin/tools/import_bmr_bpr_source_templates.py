#!/usr/bin/env python3
"""Import the approved Microbiology and Urinalysis BMR/BPR source documents.

The importer converts DOCX files through Microsoft Word, renders PDF page
backgrounds, detects writable table cells, and updates the source-backed
template catalog. Run it from the project root:

    python admin/tools/import_bmr_bpr_source_templates.py <source-directory>
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import fitz
import numpy as np
from scipy import ndimage


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ASSET_ROOT = PROJECT_ROOT / "assets" / "bmr-bpr-templates"
CATALOG_PATH = ASSET_ROOT / "catalog.json"


@dataclass(frozen=True)
class SourceTemplate:
    source_name: str
    slug: str
    code: str
    template_name: str
    family: str
    form_type: str
    product_ids: tuple[int, ...]
    mfr_reference: str
    unmapped_reason: str = ""
    document_sequence: int = 1


def source(
    source_name: str,
    slug: str,
    code: str,
    template_name: str,
    family: str,
    form_type: str,
    product_ids: Iterable[int],
    mfr_reference: str,
    unmapped_reason: str = "",
    document_sequence: int = 1,
) -> SourceTemplate:
    return SourceTemplate(
        source_name=source_name,
        slug=slug,
        code=code,
        template_name=template_name,
        family=family,
        form_type=form_type,
        product_ids=tuple(product_ids),
        mfr_reference=mfr_reference,
        unmapped_reason=unmapped_reason,
        document_sequence=document_sequence,
    )


TEMPLATES = [
    source("Blood Culture (Aerobic) Automatic BMR.docx", "blood-culture-aerobic-automatic-bmr", "BLOOD_CULTURE_AEROBIC_AUTOMATIC_BMR_V02", "Automatic Blood Culture (Aerobic) BMR", "Blood Culture (Aerobic) Automatic", "BMR", [942, 1432, 1434], "BIPL-MFRIP-445"),
    source("Blood Culture (Aerobic) Automatic BPR.docx", "blood-culture-aerobic-automatic-bpr", "BLOOD_CULTURE_AEROBIC_AUTOMATIC_BPR_V02", "Automatic Blood Culture (Aerobic) BPR", "Blood Culture (Aerobic) Automatic", "BPR", [942, 1432, 1434], "BIPL-MFRFG-391"),
    source("Blood Culture (Aerobic) Manual BMR.docx", "blood-culture-aerobic-manual-bmr", "BLOOD_CULTURE_AEROBIC_MANUAL_BMR_V02", "Blood Culture (Aerobic) Manual BMR", "Blood Culture (Aerobic) Manual", "BMR", [951], "BIPL-MFRIP-445"),
    source("Blood Culture (Aerobic) Manual BPR.docx", "blood-culture-aerobic-manual-bpr", "BLOOD_CULTURE_AEROBIC_MANUAL_BPR_V02", "Blood Culture (Aerobic) Manual BPR", "Blood Culture (Aerobic) Manual", "BPR", [951], "BIPL-MFRFG-391"),
    source("Blood Culture ( Anaerobic) Automatic BMR.docx", "blood-culture-anaerobic-automatic-bmr", "BLOOD_CULTURE_ANAEROBIC_AUTOMATIC_BMR_V02", "Automatic Blood Culture (Anaerobic) BMR", "Blood Culture (Anaerobic) Automatic", "BMR", [941, 1019, 1684], "BIPL-MFRIP-446"),
    source("Blood Culture ( Anaerobic )  Automatic BPR.docx", "blood-culture-anaerobic-automatic-bpr", "BLOOD_CULTURE_ANAEROBIC_AUTOMATIC_BPR_V02", "Automatic Blood Culture (Anaerobic) BPR", "Blood Culture (Anaerobic) Automatic", "BPR", [941, 1019, 1684], "BIPL-MFRFG-392"),
    source("Blood Culture ( Pediatric) BMR.docx", "blood-culture-pediatric-manual-bmr", "BLOOD_CULTURE_PEDIATRIC_MANUAL_BMR_V02", "Blood Culture (Pediatric) Manual BMR", "Blood Culture (Pediatric) Manual", "BMR", [950], "BIPL-MFRIP-447"),
    source("Blood Culture ( Pediatric ) BPR.docx", "blood-culture-pediatric-manual-bpr", "BLOOD_CULTURE_PEDIATRIC_MANUAL_BPR_V02", "Blood Culture (Pediatric) Manual BPR", "Blood Culture (Pediatric) Manual", "BPR", [950], "BIPL-MFRFG-393"),
    source("Blood Culture (Pediatric) Automatic BMR CFP-03- Copy.docx", "blood-culture-pediatric-automatic-bmr", "BLOOD_CULTURE_PEDIATRIC_AUTOMATIC_BMR_V02", "Automatic Blood Culture (Pediatric) BMR", "Blood Culture (Pediatric) Automatic", "BMR", [940, 1433, 1685], "BIPL-MFRIP-447"),
    source("Blood Culture (Pediatric) Automatic BPR  CFP-03- Copy.docx", "blood-culture-pediatric-automatic-bpr", "BLOOD_CULTURE_PEDIATRIC_AUTOMATIC_BPR_V02", "Automatic Blood Culture (Pediatric) BPR", "Blood Culture (Pediatric) Automatic", "BPR", [940, 1433, 1685], "BIPL-MFRFG-393"),
    source("Blood Culture (L-Form Bacterial) BMR.docx", "blood-culture-l-form-bacterial-bmr", "BLOOD_CULTURE_L_FORM_BACTERIAL_BMR_V02", "Blood Culture (L-Form Bacterial) BMR", "Blood Culture (L-Form Bacterial)", "BMR", [], "BIPL-MFRIP-448", "No matching active product exists in the product catalog."),
    source("Blood Culture (L-Form Bacterial) BPR.docx", "blood-culture-l-form-bacterial-bpr", "BLOOD_CULTURE_L_FORM_BACTERIAL_BPR_V02", "Blood Culture (L-Form Bacterial) BPR", "Blood Culture (L-Form Bacterial)", "BPR", [], "BIPL-MFRFG-394", "No matching active product exists in the product catalog."),
    source("Blood Culture (Manual) BMR.docx", "blood-culture-medium-manual-bmr", "BLOOD_CULTURE_MEDIUM_MANUAL_BMR_V02", "Blood Culture Medium (Manual) BMR", "Blood Culture Medium (Manual)", "BMR", [2020, 2021], "BIPL-MFRIP-449"),
    source("Blood Culture (Manual)) BPR.docx", "blood-culture-medium-manual-bpr", "BLOOD_CULTURE_MEDIUM_MANUAL_BPR_V02", "Blood Culture Medium (Manual) BPR", "Blood Culture Medium (Manual)", "BPR", [2020, 2021], "BIPL-MFRFG-395"),
    source("LBC (Liquid based cytology) BMR.docx", "lbc-liquid-based-cytology-bmr", "LBC_LIQUID_BASED_CYTOLOGY_BMR_V02", "LBC (Liquid-Based Cytology) BMR", "LBC (Liquid-Based Cytology)", "BMR", [937], "BIPL-MFRIP-441"),
    source("LBC (Liquid based cytology) BPR.docx", "lbc-liquid-based-cytology-bpr", "LBC_LIQUID_BASED_CYTOLOGY_BPR_V02", "LBC (Liquid-Based Cytology) BPR", "LBC (Liquid-Based Cytology)", "BPR", [937], "BIPL-MFRFG-387"),
    source("Urine (pH) BMR-UN.pdf", "urine-ph-uncut-bmr", "URINE_PH_UNCUT_BMR_V02", "Urine pH Uncut Sheet BMR", "Urine pH Uncut Sheet", "BMR", [], "BIPL-MFRIP-123-D", "No matching active product and no BPR source document exist."),
    source("Urine (Protein) BMR-UN.pdf", "urine-protein-uncut-bmr", "URINE_PROTEIN_UNCUT_BMR_V02", "Urine Protein Uncut Sheet Component BMR", "Urine 2P Glucose and Protein Uncut Sheet", "BMR", [1422, 1863], "BIPL-MFRIP-123", document_sequence=2),
    source("Urine 10P BMR- UN.pdf", "urine-10p-uncut-bmr", "URINE_10P_UNCUT_BMR_V02", "Urine 10P Uncut Sheet BMR", "Urine 10P Uncut Sheet", "BMR", [1787], "BIPL-MFRIP-125"),
    source("Urine 10P BPR- UN.pdf", "urine-10p-uncut-bpr", "URINE_10P_UNCUT_BPR_V02", "Urine 10P Uncut Sheet BPR", "Urine 10P Uncut Sheet", "BPR", [1787], "BIPL-MFRFG-119"),
    source("Urine 11P BMR- UN.docx", "urine-11p-uncut-bmr", "URINE_11P_UNCUT_BMR_V02", "Urine 11P Uncut Sheet BMR", "Urine 11P Uncut Sheet", "BMR", [1342], "BIPL-MFRIP-214"),
    source("Urine 11P BPR- UN.docx", "urine-11p-uncut-bpr", "URINE_11P_UNCUT_BPR_V02", "Urine 11P Uncut Sheet BPR", "Urine 11P Uncut Sheet", "BPR", [1342], "BIPL-MFRFG-160"),
    source("Urine 2P (Glucose & Protein) BPR-UN.pdf", "urine-2p-glucose-protein-uncut-bpr", "URINE_2P_GLUCOSE_PROTEIN_UNCUT_BPR_V02", "Urine 2P Glucose and Protein Uncut Sheet BPR", "Urine 2P Glucose and Protein Uncut Sheet", "BPR", [1422, 1863], "BIPL-MFRFG-117"),
    source("Urine 3P (Glucose , Protein, ph)  BPR-UN.pdf", "urine-3p-glucose-protein-ph-uncut-bpr", "URINE_3P_GLUCOSE_PROTEIN_PH_UNCUT_BPR_V02", "Urine 3P Glucose, Protein and pH Uncut Sheet BPR", "Urine 3P Glucose, Protein and pH Uncut Sheet", "BPR", [], "BIPL-MFRFG-159", "No matching active product and no BMR source document exist."),
    source("Urine 4P BMR-UN.pdf", "urine-4p-uncut-bmr", "URINE_4P_UNCUT_BMR_V02", "Urine 4P Uncut Sheet BMR", "Urine 4P Uncut Sheet", "BMR", [1466], "BIPL-MFRIP-123-B"),
    source("Urine 4P BPR -UN.docx", "urine-4p-uncut-bpr", "URINE_4P_UNCUT_BPR_V02", "Urine 4P Uncut Sheet BPR", "Urine 4P Uncut Sheet", "BPR", [1466], "BIPL-MFRFG-118"),
    source("Urine 8P BMR- UN.pdf", "urine-8p-uncut-bmr", "URINE_8P_UNCUT_BMR_V02", "Urine 8P Uncut Sheet BMR", "Urine 8P Uncut Sheet", "BMR", [1705], "BIPL-MFRIP-124-A"),
    source("Urine 8P BPR- UN.pdf", "urine-8p-uncut-bpr", "URINE_8P_UNCUT_BPR_V02", "Urine 8P Uncut Sheet BPR", "Urine 8P Uncut Sheet", "BPR", [1705], "BIPL-MFRFG-118-A"),
    source("Urine Glucose BMR-UN.pdf", "urine-glucose-uncut-bmr", "URINE_GLUCOSE_UNCUT_BMR_V02", "Urine Glucose Uncut Sheet Component BMR", "Urine 2P Glucose and Protein Uncut Sheet", "BMR", [1422, 1863], "BIPL-MFRIP-122"),
    source("Urine Ketone BMR- UN.pdf", "urine-ketone-uncut-bmr", "URINE_KETONE_UNCUT_BMR_V02", "Urine Ketone Uncut Sheet BMR", "Urine Ketone Uncut Sheet", "BMR", [], "BIPL-MFRIP-123-A", "No matching BPR source document exists for the standalone product."),
    source("2P strip test kit (Glucose & Ketone) BMR.pdf", "urine-2p-glucose-ketone-bmr", "URINE_2P_GLUCOSE_KETONE_BMR_V02", "Urine 2P Glucose and Ketone BMR", "Urine 2P Glucose and Ketone", "BMR", [], "BIPL-MFRIP-122 & BIPL-MFRIP-123-A", "No separate matching active product exists in the approved workflow catalog."),
    source("2P strip test kit (Glucose & Ketone) BPR.pdf", "urine-2p-glucose-ketone-bpr", "URINE_2P_GLUCOSE_KETONE_BPR_V02", "Urine 2P Glucose and Ketone BPR", "Urine 2P Glucose and Ketone", "BPR", [], "BIPL-MFRFG-117-A", "No separate matching active product exists in the approved workflow catalog."),
    source("2P strip test kit (Glucose & Protein) BMR.pdf", "urine-2p-glucose-protein-bmr", "URINE_2P_GLUCOSE_PROTEIN_BMR_V02", "Urine 2P Glucose and Protein BMR", "Urine 2P Glucose and Protein", "BMR", [1048], "BIPL-MFRIP-122 & BIPL-MFRIP-123"),
    source("2P strip test kit (Glucose & Protein) BPR.pdf", "urine-2p-glucose-protein-bpr", "URINE_2P_GLUCOSE_PROTEIN_BPR_V02", "Urine 2P Glucose and Protein BPR", "Urine 2P Glucose and Protein", "BPR", [1048], "BIPL-MFRFG-117"),
    source("4P Urine Strips BMR.pdf", "urine-4p-bmr", "URINE_4P_BMR_V02", "Urine 4P BMR", "Urine 4P", "BMR", [1047], "BIPL-MFRIP-123-B"),
    source("4P Urine strip BPR.pdf", "urine-4p-bpr", "URINE_4P_BPR_V02", "Urine 4P BPR", "Urine 4P", "BPR", [1047], "BIPL-MFRFG-118"),
    source("Strip Test ( Ketone ) BMR.pdf", "urine-ketone-bmr", "URINE_KETONE_BMR_V02", "Urine Ketone BMR", "Urine Ketone", "BMR", [1049], "BIPL-MFRIP-123-A"),
    source("Strip test ( Ketone ) BPR.pdf", "urine-ketone-bpr", "URINE_KETONE_BPR_V02", "Urine Ketone BPR", "Urine Ketone", "BPR", [1049], "BIPL-MFRFG-124"),
    source("Uricheck 10P BMR.pdf", "urine-10p-bmr", "URINE_10P_BMR_V02", "Urine 10P BMR", "Urine 10P", "BMR", [1052], "BIPL-MFRIP-125"),
    source("Uricheck 10P BPR.pdf", "urine-10p-bpr", "URINE_10P_BPR_V02", "Urine 10P BPR", "Urine 10P", "BPR", [1052], "BIPL-MFRFG-119"),
    source("Uricheck 8P BMR.pdf", "urine-8p-bmr", "URINE_8P_BMR_V02", "Urine 8P BMR", "Urine 8P", "BMR", [1050], "BIPL-MFRIP-124-A"),
    source("Uricheck 8P BPR.pdf", "urine-8p-bpr", "URINE_8P_BPR_V02", "Urine 8P BPR", "Urine 8P", "BPR", [1050], "BIPL-MFRFG-118-A"),
    source("Urine 11 Prarameter BMR.pdf", "urine-11p-bmr", "URINE_11P_BMR_V02", "Urine 11 Parameter BMR", "Urine 11 Parameter", "BMR", [1051], "BIPL-MFRIP-214"),
    source("Urine 11 Parameter BPR.pdf", "urine-11p-bpr", "URINE_11P_BPR_V02", "Urine 11 Parameter BPR", "Urine 11 Parameter", "BPR", [1051], "BIPL-MFRFG-160"),
    source("Urine 3P Parameter strip test  (Glucose , Protein, ph)  BPR.docx", "urine-3p-glucose-protein-ph-bpr", "URINE_3P_GLUCOSE_PROTEIN_PH_BPR_V02", "Urine 3P Glucose, Protein and pH BPR", "Urine 3P Glucose, Protein and pH", "BPR", [], "BIPL-MFRFG-159", "No matching active product and no BMR source document exist."),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_directory", type=Path)
    return parser.parse_args()


def find_sources(root: Path) -> dict[str, Path]:
    by_name: dict[str, list[Path]] = {}
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".pdf", ".docx"}:
            by_name.setdefault(path.name.casefold(), []).append(path)

    resolved: dict[str, Path] = {}
    for template in TEMPLATES:
        matches = by_name.get(template.source_name.casefold(), [])
        if len(matches) != 1:
            raise RuntimeError(
                f"Expected one source named {template.source_name!r}; found {len(matches)}."
            )
        resolved[template.code] = matches[0]
    return resolved


def convert_docx_documents(docx_paths: list[Path], output_root: Path) -> dict[Path, Path]:
    if not docx_paths:
        return {}

    jobs = []
    converted: dict[Path, Path] = {}
    for index, source_path in enumerate(docx_paths, start=1):
        output_path = output_root / f"converted-{index:03d}.pdf"
        jobs.append({"source": str(source_path.resolve()), "target": str(output_path.resolve())})
        converted[source_path] = output_path

    jobs_path = output_root / "jobs.json"
    jobs_path.write_text(json.dumps(jobs), encoding="utf-8")
    script_path = output_root / "convert-docx.ps1"
    script_path.write_text(
        """param([Parameter(Mandatory=$true)][string]$JobsPath)
$ErrorActionPreference = 'Stop'
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
  $jobs = Get-Content -LiteralPath $JobsPath -Raw | ConvertFrom-Json
  foreach ($job in $jobs) {
    $document = $word.Documents.Open([string]$job.source, $false, $true)
    try { $document.ExportAsFixedFormat([string]$job.target, 17) }
    finally { $document.Close($false) }
  }
}
finally { $word.Quit() }
""",
        encoding="utf-8-sig",
    )
    completed = subprocess.run(
        [
            "powershell.exe",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script_path),
            "-JobsPath",
            str(jobs_path),
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "Microsoft Word could not convert the DOCX sources: "
            + (completed.stderr.strip() or completed.stdout.strip())
        )
    for output_path in converted.values():
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise RuntimeError(f"Converted PDF was not created: {output_path}")
    return converted


def table_regions(page: fitz.Page, scale: int = 2) -> list[fitz.Rect]:
    height = int(page.rect.height * scale) + 2
    width = int(page.rect.width * scale) + 2
    line_mask = np.zeros((height, width), dtype=bool)

    for drawing in page.get_drawings():
        color = drawing.get("fill") or drawing.get("color")
        if color is None:
            continue
        for item in drawing["items"]:
            rect: fitz.Rect | None = None
            if item[0] == "re":
                rect = fitz.Rect(item[1])
            elif item[0] == "l":
                start, end = item[1], item[2]
                stroke_width = max(float(drawing.get("width") or 0.5), 0.5)
                rect = fitz.Rect(
                    min(start.x, end.x) - stroke_width / 2,
                    min(start.y, end.y) - stroke_width / 2,
                    max(start.x, end.x) + stroke_width / 2,
                    max(start.y, end.y) + stroke_width / 2,
                )
            if rect is None:
                continue
            is_horizontal = rect.height <= 1.5 and rect.width >= 4
            is_vertical = rect.width <= 1.5 and rect.height >= 4
            if not (is_horizontal or is_vertical):
                continue
            x0 = max(0, int(rect.x0 * scale))
            x1 = min(width, int(rect.x1 * scale) + 1)
            y0 = max(0, int(rect.y0 * scale))
            y1 = min(height, int(rect.y1 * scale) + 1)
            line_mask[y0:y1, x0:x1] = True

    line_mask = ndimage.binary_dilation(line_mask, iterations=1)
    labels, _ = ndimage.label(~line_mask)
    regions: list[fitz.Rect] = []
    for label_number, slices in enumerate(ndimage.find_objects(labels), start=1):
        if slices is None:
            continue
        y_slice, x_slice = slices
        region_width = (x_slice.stop - x_slice.start) / scale
        region_height = (y_slice.stop - y_slice.start) / scale
        if (
            region_width < 12
            or region_height < 8
            or region_width > page.rect.width * 0.98
            or region_height > page.rect.height * 0.98
        ):
            continue
        component = labels[slices] == label_number
        if float(component.mean()) < 0.82:
            continue
        regions.append(
            fitz.Rect(
                x_slice.start / scale,
                y_slice.start / scale,
                x_slice.stop / scale,
                y_slice.stop / scale,
            )
        )
    return regions


def words_in(page: fitz.Page, rect: fitz.Rect) -> list[tuple[Any, ...]]:
    words = []
    for word in page.get_text("words"):
        word_rect = fitz.Rect(word[:4])
        overlap = word_rect & rect
        if word_rect.get_area() > 0 and overlap.get_area() / word_rect.get_area() >= 0.55:
            words.append(word)
    return words


def image_occupies(page: fitz.Page, rect: fitz.Rect) -> bool:
    for image in page.get_images(full=True):
        for image_rect in page.get_image_rects(image[0]):
            overlap = image_rect & rect
            if rect.get_area() > 0 and overlap.get_area() / rect.get_area() >= 0.35:
                return True
    return False


def locate_semantic_region(
    page: fitz.Page, regions: list[fitz.Rect], labels: tuple[str, ...]
) -> fitz.Rect | None:
    candidates: list[tuple[float, fitz.Rect]] = []
    for label in labels:
        for label_rect in page.search_for(label):
            for region in regions:
                vertical_overlap = max(
                    0.0,
                    min(region.y1, label_rect.y1) - max(region.y0, label_rect.y0),
                )
                if vertical_overlap <= 0 or region.x0 < label_rect.x1 - 2:
                    continue
                distance = region.x0 - label_rect.x1
                if distance <= page.rect.width * 0.5:
                    candidates.append((distance, region))
    return min(candidates, key=lambda item: item[0])[1] if candidates else None


def percent(value: float, total: float) -> float:
    return round(value * 100 / total, 5)


def field_from_rect(
    field_id: str,
    page_number: int,
    rect: fitz.Rect,
    page: fitz.Page,
    *,
    source_name: str | None = None,
) -> dict[str, Any]:
    return {
        "id": field_id,
        "page": page_number,
        "x": percent(rect.x0, page.rect.width),
        "y": percent(rect.y0, page.rect.height),
        "w": percent(rect.width, page.rect.width),
        "h": percent(rect.height, page.rect.height),
        "editable": source_name is None,
        "source": source_name,
        "erase_background": source_name is not None,
        "multiline": rect.height >= 25,
    }


def build_layout(template: SourceTemplate, document: fitz.Document) -> dict[str, Any]:
    pages = []
    semantic_labels = {
        "product_name": ("Product name", "Product Name", "ProductName"),
        "batch_number": ("Batch number", "Batch Number"),
        "batch_size": ("Batch size", "Batch Size"),
        "record_number": ("BMR No.", "BPR No.", "BMR No", "BPR No"),
        "pack_size": ("Pack size", "Pack Size"),
    }

    for index, page in enumerate(document, start=1):
        regions = table_regions(page)
        semantic_regions: dict[str, fitz.Rect] = {}
        for source_name, labels in semantic_labels.items():
            region = locate_semantic_region(page, regions, labels)
            if region is not None:
                semantic_regions[source_name] = region

        fields = []
        used_rects: list[fitz.Rect] = []
        for source_name, region in semantic_regions.items():
            if any((region & used).get_area() / region.get_area() > 0.8 for used in used_rects):
                continue
            fields.append(
                field_from_rect(
                    f"p{index}_source_{source_name}",
                    index,
                    region,
                    page,
                    source_name=source_name,
                )
            )
            used_rects.append(region)

        editable_number = 0
        for region in sorted(regions, key=lambda item: (item.y0, item.x0)):
            if any((region & used).get_area() / region.get_area() > 0.8 for used in used_rects):
                continue
            if words_in(page, region) or image_occupies(page, region):
                continue
            editable_number += 1
            fields.append(
                field_from_rect(
                    f"p{index}_field_{editable_number}", index, region, page
                )
            )

        pages.append(
            {
                "page": index,
                "width": round(page.rect.width, 2),
                "height": round(page.rect.height, 2),
                "image": f"page-{index:03d}.jpg",
                "fields": fields,
            }
        )

    return {
        "schema_version": 1,
        "template_code": template.code,
        "family": template.family,
        "form_type": template.form_type,
        "page_count": len(document),
        "pages": pages,
        "allow_custom_fields": True,
    }


def import_template(template: SourceTemplate, pdf_path: Path) -> dict[str, Any]:
    asset_directory = ASSET_ROOT / template.slug
    asset_directory.mkdir(parents=True, exist_ok=True)
    source_pdf = asset_directory / "source.pdf"
    shutil.copyfile(pdf_path, source_pdf)

    document = fitz.open(source_pdf)
    if len(document) == 0:
        raise RuntimeError(f"Source PDF has no pages: {pdf_path}")

    layout = build_layout(template, document)
    for index, page in enumerate(document, start=1):
        pixmap = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        pixmap.save(asset_directory / f"page-{index:03d}.jpg", jpg_quality=90)

    layout_path = asset_directory / "layout.json"
    layout_path.write_text(
        json.dumps(layout, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    checksum = hashlib.sha256(source_pdf.read_bytes()).hexdigest()
    editable_count = sum(
        1
        for page in layout["pages"]
        for field in page["fields"]
        if field["editable"]
    )
    return {
        "template_code": template.code,
        "template_name": template.template_name,
        "family": template.family,
        "form_type": template.form_type,
        "product_ids": list(template.product_ids),
        "document_sequence": template.document_sequence,
        "asset_directory": f"assets/bmr-bpr-templates/{template.slug}",
        "source_pdf_path": f"assets/bmr-bpr-templates/{template.slug}/source.pdf",
        "layout_path": f"assets/bmr-bpr-templates/{template.slug}/layout.json",
        "source_checksum": checksum,
        "page_count": len(document),
        "editable_field_count": editable_count,
        "document_no": "BIPL-BMR-01" if template.form_type == "BMR" else "BIPL-BPR-01",
        "issue_no": "01",
        "revision_no": "02",
        "effective_date": "03/04/2025",
        "mfr_reference": template.mfr_reference,
        **(
            {
                "mapping_status": "unmapped",
                "unmapped_reason": template.unmapped_reason,
            }
            if not template.product_ids
            else {}
        ),
    }


def update_catalog(entries: list[dict[str, Any]]) -> None:
    catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    imported_codes = {entry["template_code"] for entry in entries}
    mapped_entries = [entry for entry in entries if entry["product_ids"]]
    unmapped_entries = [entry for entry in entries if not entry["product_ids"]]

    catalog["templates"] = [
        entry
        for entry in catalog.get("templates", [])
        if entry.get("template_code") not in imported_codes
    ] + mapped_entries
    catalog["unmapped_templates"] = [
        entry
        for entry in catalog.get("unmapped_templates", [])
        if entry.get("template_code") not in imported_codes
    ] + unmapped_entries
    CATALOG_PATH.write_text(
        json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def main() -> int:
    args = parse_args()
    source_root = args.source_directory.resolve()
    if not source_root.is_dir():
        raise RuntimeError(f"Source directory does not exist: {source_root}")

    resolved = find_sources(source_root)
    with tempfile.TemporaryDirectory(prefix="bmr-bpr-import-") as temporary:
        temporary_root = Path(temporary)
        docx_paths = sorted(
            {path for path in resolved.values() if path.suffix.lower() == ".docx"}
        )
        converted = convert_docx_documents(docx_paths, temporary_root)
        entries = []
        for template in TEMPLATES:
            source_path = resolved[template.code]
            pdf_path = converted.get(source_path, source_path)
            entries.append(import_template(template, pdf_path))
            print(
                f"Imported {template.code}: {entries[-1]['page_count']} pages, "
                f"{entries[-1]['editable_field_count']} editable fields"
            )
    update_catalog(entries)
    print(f"Catalogued templates: {len(entries)}")
    print(f"Mapped templates: {sum(bool(entry['product_ids']) for entry in entries)}")
    print(f"Unmapped source references: {sum(not entry['product_ids'] for entry in entries)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
