#!/usr/bin/env python3
"""Replace legacy numeric product references with stable product codes."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
CATALOG = ROOT / "assets" / "bmr-bpr-templates" / "catalog.json"

PRODUCT_CODES: dict[int, tuple[str, ...]] = {
    937: ("BGX/FIN.MICR/2026/000023",),
    940: ("BGX/FIN.BCB/2026/000016",),
    941: ("BGX/FIN.BCB/2026/000001",),
    942: ("BGX/FIN.BCB/2026/000013",),
    950: ("BGX/FIN.BCB/2026/000005",),
    951: ("BGX/FIN.BCB/2026/000004",),
    1019: ("BGX/FIN.BCB/2026/000010",),
    1029: ("BGX/FIN.SERO/2026/000032", "BGX/FIN.SERO/2026/000033"),
    1032: ("BGX/FIN.SERO/2026/000030",),
    1034: ("BGX/FIN.SERO/2026/000029",),
    1035: ("BGX/FIN.SERO/2026/000028",),
    1039: ("BGX/FIN.SERO/2026/000013",),
    1040: ("BGX/FIN.SERO/2026/000012",),
    1041: ("BGX/FIN.SERO/2026/000011",),
    1043: ("BGX/FIN.SERO/2026/000009",),
    1044: ("BGX/FIN.SERO/2026/000008",),
    1045: ("BGX/FIN.SERO/2026/000007",),
    1047: ("BGX/FIN.URIN/2026/000012", "BGX/FIN.URIN/2026/000013"),
    1048: ("BGX/FIN.URIN/2026/000010",),
    1049: ("BGX/FIN.URIN/2026/000003",),
    1050: ("BGX/FIN.URIN/2026/000014", "BGX/FIN.URIN/2026/000015"),
    1051: ("BGX/FIN.URIN/2026/000008", "BGX/FIN.URIN/2026/000009"),
    1052: ("BGX/FIN.URIN/2026/000007",),
    1053: ("BGX/FIN.HEMA/2026/000021",),
    1055: ("BGX/FIN.HEMA/2026/000018",),
    1064: ("BGX/FIN.HEMA/2026/000009",),
    1067: ("BGX/PP.CON/2026/000097",),
    1071: ("BGX/FIN.HEMA/2026/000006",),
    1342: ("BGX/SF.US.URIN/2026/000017",),
    1422: ("BGX/SF.US.URIN/2026/000002",),
    1432: ("BGX/FIN.BCB/2026/000013",),
    1433: ("BGX/FIN.BCB/2026/000011",),
    1434: ("BGX/FIN.BCB/2026/000006",),
    1684: ("BGX/FIN.BCB/2026/000015",),
    1685: ("BGX/FIN.BCB/2026/000016",),
    1787: ("BGX/SF.US.URIN/2026/000016",),
    1863: ("BGX/SF.US.URIN/2026/000002",),
    2014: ("BGX/FIN.SERO/2026/000030",),
    2020: ("BGX/FIN.BCB/2026/000009",),
    2021: ("BGX/FIN.BCB/2026/000009",),
}


def upgrade(entry: dict) -> dict:
    product_codes = list(entry.get("product_codes", []))
    for product_id in entry.pop("product_ids", []):
        product_codes.extend(PRODUCT_CODES.get(int(product_id), ()))
    entry["product_codes"] = list(dict.fromkeys(product_codes))
    return entry


def main() -> None:
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
    mapped: list[dict] = []
    unmapped: list[dict] = []
    for raw in [*catalog.get("templates", []), *catalog.get("unmapped_templates", [])]:
        entry = upgrade(raw)
        if entry["product_codes"]:
            entry.pop("mapping_status", None)
            entry.pop("unmapped_reason", None)
            mapped.append(entry)
        else:
            entry["mapping_status"] = "unmapped"
            entry.setdefault(
                "unmapped_reason",
                "No matching active product exists in the current product catalog.",
            )
            unmapped.append(entry)
    catalog["templates"] = mapped
    catalog["unmapped_templates"] = unmapped
    CATALOG.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Mapped templates: {len(mapped)}")
    print(f"Unmapped templates: {len(unmapped)}")
    print(f"Mapped product codes: {len({c for e in mapped for c in e['product_codes']})}")


if __name__ == "__main__":
    main()
