#!/usr/bin/env python3
"""Import the approved Biochemistry BMR/BPR source-document set."""

from __future__ import annotations

import json
import hashlib
import re
import tempfile
from pathlib import Path

import fitz

from import_bmr_bpr_source_templates import (
    ASSET_ROOT,
    CATALOG_PATH,
    SourceTemplate,
    convert_docx_documents,
    import_template,
)

fitz.TOOLS.mupdf_display_errors(False)
fitz.TOOLS.mupdf_display_warnings(False)


def bioc(*numbers: int) -> tuple[str, ...]:
    return tuple(f"BGX/FIN.BIOC/2026/{number:06d}" for number in numbers)


FAMILIES: dict[str, tuple[str, tuple[str, ...]]] = {
    "ada": ("Adenosine Deaminase (ADA)", bioc(1, 2, 3, 4)),
    "albumin": ("Albumin", bioc(5, 6, 7, 8, 9)),
    "alp": ("Alkaline Phosphatase", bioc(10, 11, 12, 13, 14)),
    "ammonia": ("Ammonia", bioc(20, 21, 22, 23)),
    "amylase": ("Alpha Amylase", bioc(15, 16, 17, 18, 19)),
    "aso turbi": ("ASO Turbidimetric", ("BGX/FIN.SERO/2026/000010",)),
    "bilirubin direct": ("Bilirubin Direct", bioc(28, 29, 30, 31)),
    "bilirubin total": ("Bilirubin Total", bioc(32, 33, 34, 35, 36)),
    "calcium": ("Calcium", bioc(39, 40, 41)),
    "chloride": ("Chloride", bioc(42, 43, 44)),
    "cholesterol hdl direct": ("Cholesterol HDL Direct", bioc(74, 75, 76, 77, 78, 79, 80)),
    "cholesterol ldl direct": ("Cholesterol LDL Direct", bioc(88, 89, 90, 91, 92, 93)),
    "cholesterol total": ("Cholesterol Total", bioc(45, 46, 47, 110)),
    "ckmb": ("Creatine Kinase MB", bioc(48, 49)),
    "cknac": ("Creatine Kinase NAC", bioc(50)),
    "creatinine": ("Creatinine", bioc(51, 52, 53, 54, 55)),
    "crp turbi": ("CRP Turbidimetric", tuple(f"BGX/FIN.SERO/2026/{n:06d}" for n in (15, 16, 17, 18, 19))),
    "d dimer turbi": ("D-Dimer Turbidimetric", ()),
    "ferritin": ("Ferritin Turbidimetric", ("BGX/FIN.SERO/2026/000022",)),
    "g6pd": ("G6PD", bioc(59, 60)),
    "gamma gt": ("Gamma GT", bioc(61, 62, 63, 64)),
    "glucose": ("Glucose", bioc(65, 66, 67)),
    "hba1c": ("HbA1c", bioc(68, 69)),
    "hdl cholesterol ppt": ("HDL Cholesterol PPT", bioc(70, 71, 72, 73)),
    "ldh": ("Lactate Dehydrogenase", bioc(85, 86)),
    "lipase": ("Lipase", bioc(94, 95)),
    "magnesium": ("Magnesium", bioc(98, 99, 100, 101)),
    "micro protein": ("Micro Protein", bioc(102, 103, 104, 105)),
    "phosphorus": ("Phosphorus", bioc(106)),
    "potassium": ("Potassium", bioc(107, 108, 109)),
    "rf turbi": ("RF Turbidimetric", ("BGX/FIN.SERO/2026/000031",)),
    "sgot": ("SGOT", bioc(111, 112, 113, 114)),
    "sgpt": ("SGPT", bioc(115, 116, 117)),
    "sodium": ("Sodium", bioc(118, 119, 120)),
    "total protein": ("Total Protein", bioc(130, 131, 132)),
    "triglyceride": ("Triglyceride", bioc(133, 134, 135, 136)),
    "urea berthelot": ("Urea Berthelot", bioc(138, 139, 140)),
    "urea uv": ("Urea UV", bioc(142, 143, 144, 145, 146)),
    "uric acid": ("Uric Acid", bioc(147, 148, 149, 150, 151)),
}


def source_key(path: Path) -> tuple[str, str]:
    stem = path.stem.lower()
    match = re.search(r"\bb([mp])r\b", stem)
    if not match:
        raise RuntimeError(f"Unable to identify BMR/BPR type: {path.name}")
    form_type = "BMR" if match.group(1) == "m" else "BPR"
    key = re.sub(r"\bb[mp]r\b", " ", stem)
    key = re.sub(r"[^a-z0-9]+", " ", key).strip()
    return key, form_type


def mfr_reference(pdf_path: Path, form_type: str) -> str:
    with fitz.open(pdf_path) as document:
        text = "\n".join(page.get_text() for page in document[:3])
    references = re.findall(r"BIPL\s*[-–]\s*MFR(?:IP|FG)\s*[-–]\s*[0-9]+(?:\s*[-–]\s*[A-Z])?", text, re.I)
    if references:
        return re.sub(r"\s*[-–]\s*", "-", references[0]).upper()
    return "BIPL-MFRIP-SOURCE" if form_type == "BMR" else "BIPL-MFRFG-SOURCE"


def existing_entry(template: SourceTemplate) -> dict | None:
    asset_directory = ASSET_ROOT / template.slug
    source_pdf = asset_directory / "source.pdf"
    layout_path = asset_directory / "layout.json"
    if not source_pdf.is_file() or not layout_path.is_file():
        return None
    layout = json.loads(layout_path.read_text(encoding="utf-8"))
    page_count = int(layout.get("page_count", 0))
    if page_count <= 0 or any(
        not (asset_directory / f"page-{page:03d}.jpg").is_file()
        for page in range(1, page_count + 1)
    ):
        return None
    editable_count = sum(
        1
        for page in layout.get("pages", [])
        for field in page.get("fields", [])
        if field.get("editable")
    )
    return {
        "template_code": template.code,
        "template_name": template.template_name,
        "family": template.family,
        "form_type": template.form_type,
        "document_sequence": template.document_sequence,
        "asset_directory": f"assets/bmr-bpr-templates/{template.slug}",
        "source_pdf_path": f"assets/bmr-bpr-templates/{template.slug}/source.pdf",
        "layout_path": f"assets/bmr-bpr-templates/{template.slug}/layout.json",
        "source_checksum": hashlib.sha256(source_pdf.read_bytes()).hexdigest(),
        "page_count": page_count,
        "editable_field_count": editable_count,
        "document_no": "BIPL-BMR-01" if template.form_type == "BMR" else "BIPL-BPR-01",
        "issue_no": "01",
        "revision_no": "02",
        "effective_date": "03/04/2025",
        "mfr_reference": template.mfr_reference,
    }


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("source_directory", type=Path)
    root = parser.parse_args().source_directory.resolve()
    if not root.is_dir():
        raise RuntimeError(f"Source directory does not exist: {root}")

    found: dict[tuple[str, str], Path] = {}
    for path in root.iterdir():
        if path.suffix.lower() not in {".pdf", ".docx"}:
            continue
        key = source_key(path)
        if key in found:
            raise RuntimeError(f"Duplicate source for {key}: {path.name}")
        found[key] = path

    expected = {(family, form) for family in FAMILIES for form in ("BMR", "BPR")}
    if set(found) != expected:
        missing = sorted(expected - set(found))
        extra = sorted(set(found) - expected)
        raise RuntimeError(f"Biochemistry source mismatch; missing={missing}, extra={extra}")

    entries: list[dict] = []
    with tempfile.TemporaryDirectory(prefix="biochemistry-template-import-") as temporary:
        temporary_root = Path(temporary)
        docx_paths = [path for path in found.values() if path.suffix.lower() == ".docx"]
        converted = convert_docx_documents(docx_paths, temporary_root)
        for family_key, (family_name, product_codes) in FAMILIES.items():
            slug_base = re.sub(r"[^a-z0-9]+", "-", family_key).strip("-")
            code_base = re.sub(r"[^A-Z0-9]+", "_", family_key.upper()).strip("_")
            for form_type in ("BMR", "BPR"):
                source_path = found[(family_key, form_type)]
                pdf_path = converted.get(source_path, source_path)
                template = SourceTemplate(
                    source_name=source_path.name,
                    slug=f"biochemistry-{slug_base}-{form_type.lower()}",
                    code=f"SOURCE_BIOCHEMISTRY_{code_base}_{form_type}_V02",
                    template_name=f"{family_name} {form_type}",
                    family=family_name,
                    form_type=form_type,
                    product_ids=(1,),
                    mfr_reference=mfr_reference(pdf_path, form_type),
                    unmapped_reason="",
                    document_sequence=1,
                )
                entry = existing_entry(template) or import_template(template, pdf_path)
                entry.pop("product_ids", None)
                entry["product_codes"] = list(product_codes)
                if not product_codes:
                    entry["mapping_status"] = "unmapped"
                    entry["unmapped_reason"] = "No matching active product exists in the current product catalog."
                entries.append(entry)
                print(f"Imported {entry['template_code']}: {entry['page_count']} pages")

    catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    codes = {entry["template_code"] for entry in entries}
    existing = [entry for entry in catalog.get("templates", []) if entry.get("template_code") not in codes]
    existing_unmapped = [entry for entry in catalog.get("unmapped_templates", []) if entry.get("template_code") not in codes]
    catalog["templates"] = existing + [entry for entry in entries if entry["product_codes"]]
    catalog["unmapped_templates"] = existing_unmapped + [entry for entry in entries if not entry["product_codes"]]
    CATALOG_PATH.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Catalogued Biochemistry templates: {len(entries)}")


if __name__ == "__main__":
    main()
