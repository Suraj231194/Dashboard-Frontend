<?php

declare(strict_types=1);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '0');
date_default_timezone_set('Asia/Kolkata');
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../vendor/autoload.php';

define('HRMS_CONTEXT', true);
require_once __DIR__ . '/hrms/hrms_common.php';
require_once __DIR__ . '/hrms/annual_calendar_common.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$userId = hrmsRequireLogin();
if (!hrmsCan($conn, 'hrms_calendar_export')) {
    http_response_code(403);
    exit('You do not have permission to export Annual Calendars.');
}

$calendarId = filter_var($_GET['calendar_id'] ?? null, FILTER_VALIDATE_INT);
$format = strtolower(trim((string) ($_GET['format'] ?? 'pdf')));
if (!$calendarId || !in_array($format, ['pdf', 'csv', 'audit'], true)) {
    http_response_code(422);
    exit('Select a valid finalized calendar and export format.');
}

$calendar = acCalendarById($conn, (int) $calendarId);
if (!$calendar) {
    http_response_code(404);
    exit('Calendar not found.');
}
$scope = hrmsCurrentScope($conn, $userId);
hrmsAssertTenantAccess($scope, ['company_id' => (int) $calendar['company_id']]);

$companyStmt = $conn->prepare('SELECT company_name FROM erp_companies WHERE id = ? AND deleted_at IS NULL LIMIT 1');
$companyId = (int) $calendar['company_id'];
$companyStmt->bind_param('i', $companyId);
$companyStmt->execute();
$companyName = (string) ($companyStmt->get_result()->fetch_assoc()['company_name'] ?? ('Company ' . $companyId));
$companyStmt->close();

$safeCompanyName = preg_replace('/[^A-Za-z0-9_-]+/', '_', $companyName);

// The audit trail is exportable for any revision; the calendar itself only when finalized.
if ($format === 'audit') {
    $events = acGetAuditEvents($conn, $companyId, (int) $calendar['calendar_year'], 250);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $safeCompanyName . '_Calendar_Audit_' . (int) $calendar['calendar_year'] . '.csv"');
    header('X-Content-Type-Options: nosniff');
    $output = fopen('php://output', 'wb');
    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, ['Company', $companyName]);
    fputcsv($output, ['Year', $calendar['calendar_year']]);
    fputcsv($output, []);
    fputcsv($output, ['Changed At', 'Revision', 'Action', 'Field', 'Old Value', 'New Value', 'Reason', 'Changed By']);
    foreach ($events as $event) {
        $values = [
            $event['changed_at'], $event['revision_no'], $event['action'], $event['field_changed'] ?? '',
            $event['old_value'] ?? '', $event['new_value'] ?? '', $event['reason'] ?? '', $event['changed_by_name'],
        ];
        foreach ($values as &$value) {
            $value = (string) $value;
            if (preg_match('/^[=+\-@]/', $value)) {
                $value = "'" . $value;
            }
        }
        unset($value);
        fputcsv($output, $values);
    }
    fclose($output);
    exit;
}

if ($calendar['lifecycle_status'] !== 'finalized' || (int) $calendar['is_finalized'] !== 1) {
    http_response_code(409);
    exit('Only a finalized calendar revision can be exported.');
}

$finalizerName = '';
if (!empty($calendar['finalized_by'])) {
    $finalizerStmt = $conn->prepare('SELECT name FROM users WHERE id = ? LIMIT 1');
    $finalizedBy = (int) $calendar['finalized_by'];
    $finalizerStmt->bind_param('i', $finalizedBy);
    $finalizerStmt->execute();
    $finalizerName = (string) ($finalizerStmt->get_result()->fetch_assoc()['name'] ?? ('User ' . $finalizedBy));
    $finalizerStmt->close();
}

$dayStmt = $conn->prepare(
    'SELECT calendar_date, day_of_week, day_type, is_working, is_weekly_off, is_holiday, holiday_names, holiday_types
     FROM hr_annual_calendar_days WHERE calendar_id = ? ORDER BY calendar_date'
);
$dayStmt->bind_param('i', $calendarId);
$dayStmt->execute();
$days = $dayStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$dayStmt->close();
if (count($days) !== (int) $calendar['total_days']) {
    http_response_code(409);
    exit('The finalized calendar ledger is incomplete and cannot be exported.');
}

if (acColumnExists($conn, 'hr_annual_calendar_days', 'is_optional_holiday')) {
    $optionalStmt = $conn->prepare(
        'SELECT calendar_date, is_optional_holiday FROM hr_annual_calendar_days WHERE calendar_id = ?'
    );
    $optionalStmt->bind_param('i', $calendarId);
    $optionalStmt->execute();
    $optionalMap = array_column($optionalStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'is_optional_holiday', 'calendar_date');
    $optionalStmt->close();
    foreach ($days as &$dayRow) {
        $dayRow['is_optional_holiday'] = (int) ($optionalMap[$dayRow['calendar_date']] ?? 0);
    }
    unset($dayRow);
}

$weeklyOffLabels = ['1' => 'Mon', '2' => 'Tue', '3' => 'Wed', '4' => 'Thu', '5' => 'Fri', '6' => 'Sat', '7' => 'Sun'];
$weeklyOffSummary = implode(', ', array_map(
    static fn(int $day): string => $weeklyOffLabels[(string) $day] ?? (string) $day,
    acParseWeeklyOffDays($calendar['weekly_off_days'] ?? '7')
));

$safeBaseName = $safeCompanyName
    . '_Annual_Calendar_' . (int) $calendar['calendar_year'] . '_Rev_' . (int) $calendar['revision_no'];

if ($format === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $safeBaseName . '.csv"');
    header('X-Content-Type-Options: nosniff');
    $output = fopen('php://output', 'wb');
    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, ['Company', $companyName]);
    fputcsv($output, ['Year', $calendar['calendar_year']]);
    fputcsv($output, ['Revision', $calendar['revision_no']]);
    fputcsv($output, ['Weekly Off Days', $weeklyOffSummary]);
    fputcsv($output, ['Content Hash', $calendar['content_hash']]);
    fputcsv($output, ['Finalized By', $finalizerName]);
    fputcsv($output, ['Finalized At', $calendar['finalized_at']]);
    fputcsv($output, []);
    fputcsv($output, ['Date', 'Day', 'Classification', 'Working Day', 'Weekly Off', 'Holiday', 'Optional Holiday', 'Holiday Name(s)', 'Holiday Type(s)']);
    foreach ($days as $day) {
        $values = [
            $day['calendar_date'],
            date('l', strtotime($day['calendar_date'])),
            str_replace('_', ' ', $day['day_type']),
            (int) $day['is_working'] === 1 ? 'Yes' : 'No',
            (int) $day['is_weekly_off'] === 1 ? 'Yes' : 'No',
            (int) $day['is_holiday'] === 1 ? 'Yes' : 'No',
            (int) ($day['is_optional_holiday'] ?? 0) === 1 ? 'Yes' : 'No',
            $day['holiday_names'] ?? '',
            $day['holiday_types'] ?? '',
        ];
        foreach ($values as &$value) {
            $value = (string) $value;
            if (preg_match('/^[=+\-@]/', $value)) {
                $value = "'" . $value;
            }
        }
        unset($value);
        fputcsv($output, $values);
    }
    fclose($output);
    exit;
}

$escape = static fn(mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$monthly = acMonthlyBreakdownFromDays($days);
$summaryRows = '';
foreach ($monthly as $month) {
    $weeklyOffs = $month['weekly_offs'] ?? ((int) $month['sundays'] + (int) $month['sat_offs']);
    $summaryRows .= '<tr><td>' . $escape($month['month_name']) . '</td><td>' . (int) $month['total_days'] . '</td><td>'
        . (int) $weeklyOffs . '</td><td>' . (int) $month['sundays'] . '</td><td>' . (int) $month['sat_offs'] . '</td><td>'
        . (int) $month['holidays'] . '</td><td><strong>' . (int) $month['working_days'] . '</strong></td></tr>';
}
$dayRows = '';
foreach ($days as $day) {
    $class = $day['day_type'] === 'working_day' ? 'working' : ($day['day_type'] === 'holiday' ? 'holiday' : 'off');
    $classification = ucwords(str_replace('_', ' ', $day['day_type']));
    if ((int) ($day['is_optional_holiday'] ?? 0) === 1) {
        $classification .= ' (optional holiday)';
    }
    $dayRows .= '<tr class="' . $class . '"><td>' . $escape(date('d M Y', strtotime($day['calendar_date']))) . '</td><td>'
        . $escape(date('l', strtotime($day['calendar_date']))) . '</td><td>'
        . $escape($classification) . '</td><td>'
        . $escape($day['holiday_names'] ?? '') . '</td><td>' . $escape($day['holiday_types'] ?? '') . '</td></tr>';
}

$html = '<!doctype html><html><head><meta charset="utf-8"><style>
@page{margin:45px 38px 48px} body{font-family:"DejaVu Sans",sans-serif;color:#172033;font-size:9px;line-height:1.4}
h1{font-size:22px;color:#123047;margin:0 0 4px} h2{font-size:14px;color:#123047;border-bottom:2px solid #16805c;padding-bottom:4px;margin-top:18px}
.meta{color:#5c6d78;margin-bottom:12px}.status{display:inline-block;background:#dcfce7;color:#166534;padding:4px 9px;border-radius:10px;font-weight:bold}
.cards{width:100%;border-collapse:separate;border-spacing:6px}.cards td{background:#f4f8fa;border:1px solid #d8e2e7;padding:8px;text-align:center}.cards strong{font-size:16px;color:#123047;display:block}
table.data{width:100%;border-collapse:collapse;margin:8px 0 14px}table.data th{background:#123047;color:#fff;text-align:left;padding:5px;border:1px solid #aebfc8}table.data td{padding:4px 5px;border:1px solid #ced9df}.holiday td{background:#faf5ff}.off td{background:#fffbeb}
.hash{font-family:"DejaVu Sans Mono",monospace;font-size:7px;word-break:break-all}.keep{page-break-inside:avoid}
</style></head><body><h1>Annual Calendar &amp; Working Days</h1><div class="meta">' . $escape($companyName) . ' · ' . (int) $calendar['calendar_year']
    . ' · Revision ' . (int) $calendar['revision_no'] . ' <span class="status">Finalized</span></div>'
    . '<table class="cards"><tr><td>Calendar Days<strong>' . (int) $calendar['total_days'] . '</strong></td><td>Sundays<strong>'
    . (int) $calendar['total_sundays'] . '</strong></td><td>Additional Weekly Offs<strong>' . (int) $calendar['total_saturday_offs']
    . '</strong></td><td>Holidays<strong>' . (int) $calendar['total_holidays'] . '</strong></td><td>Working Days<strong>'
    . (int) $calendar['total_working_days'] . '</strong></td></tr></table>'
    . '<div class="keep"><p><strong>Weekly-off policy:</strong> ' . $escape(str_replace('_', ' ', $calendar['saturday_policy']))
    . '<br><strong>Weekly-off days:</strong> ' . $escape($weeklyOffSummary)
    . '<br><strong>Finalized by:</strong> ' . $escape($finalizerName) . ' on ' . $escape($calendar['finalized_at'])
    . '<br><strong>Content hash:</strong> <span class="hash">' . $escape($calendar['content_hash']) . '</span></p></div>'
    . '<h2>Monthly Summary</h2><table class="data"><thead><tr><th>Month</th><th>Days</th><th>Weekly Offs</th><th>Sundays</th><th>Other Offs</th><th>Holidays</th><th>Working</th></tr></thead><tbody>'
    . $summaryRows . '</tbody></table><h2>Date Ledger</h2><table class="data"><thead><tr><th>Date</th><th>Day</th><th>Classification</th><th>Holiday Name(s)</th><th>Type(s)</th></tr></thead><tbody>'
    . $dayRows . '</tbody></table></body></html>';

$options = new Options();
$options->set('isRemoteEnabled', false);
$options->set('defaultFont', 'DejaVu Sans');
$pdf = new Dompdf($options);
$pdf->setPaper('A4', 'portrait');
$pdf->loadHtml($html, 'UTF-8');
$pdf->render();
$canvas = $pdf->getCanvas();
$font = $pdf->getFontMetrics()->getFont('DejaVu Sans', 'normal');
$canvas->page_text(38, 817, $companyName . ' Annual Calendar | Page {PAGE_NUM} of {PAGE_COUNT}', $font, 7, [0.35, 0.4, 0.45]);
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $safeBaseName . '.pdf"');
header('X-Content-Type-Options: nosniff');
echo $pdf->output();
