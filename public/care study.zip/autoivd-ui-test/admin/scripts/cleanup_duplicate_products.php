<?php
/**
 * Deduplication and Transaction Re-linking Script
 * Safely merges duplicate active products, re-pointing all transaction and relation references to the primary keeper ID.
 */
require_once __DIR__ . '/../db.php';

$pairs = [
    ['name' => 'Anti-CCP (Uncut Sheet) POCT/FIA', 'keeper_id' => 3043, 'redundant_ids' => [3044]],
    ['name' => 'ASO (Uncut Sheet) POCT/FIA', 'keeper_id' => 3045, 'redundant_ids' => [3046]],
    ['name' => 'Boxes Common Rapid 40 Tests', 'keeper_id' => 2454, 'redundant_ids' => [2455]],
    ['name' => 'Boxes Dengue NS1', 'keeper_id' => 2463, 'redundant_ids' => [2464]],
    ['name' => 'Boxes ELISA', 'keeper_id' => 2465, 'redundant_ids' => [2466]],
    ['name' => 'Boxes Green 50 mL', 'keeper_id' => 2474, 'redundant_ids' => [2475]],
    ['name' => 'Boxes HIV', 'keeper_id' => 2492, 'redundant_ids' => [2494]],
    ['name' => 'CFP-03 Aerobic Culture Bottle 20 mL', 'keeper_id' => 1023, 'redundant_ids' => [1024]],
    ['name' => 'FSH FIA Test 10 Tests', 'keeper_id' => 1083, 'redundant_ids' => [1084]],
    ['name' => 'LH FIA Test 10 Tests', 'keeper_id' => 1097, 'redundant_ids' => [1098]],
    ['name' => 'PCT FIA Test 10 Tests', 'keeper_id' => 1102, 'redundant_ids' => [1103]],
    ['name' => 'Testosterone ELISA 96 Tests', 'keeper_id' => 940, 'redundant_ids' => [941]],
    ['name' => 'TSH (Uncut Sheet) POCT/FIA', 'keeper_id' => 3062, 'redundant_ids' => [3064]],
    ['name' => 'Urea UV 100 mL', 'keeper_id' => 556, 'redundant_ids' => [555]],
];

$directTables = [
    ['table' => 'order_received_items', 'col' => 'product_id'],
    ['table' => 'stock_inwards', 'col' => 'product_id'],
    ['table' => 'stock_outward_items', 'col' => 'product_id'],
    ['table' => 'finance_document_items', 'col' => 'product_id'],
    ['table' => 'material_requisition_items', 'col' => 'product_id'],
    ['table' => 'quotation_request_items', 'col' => 'product_id'],
    ['table' => 'pi_request_items', 'col' => 'product_id'],
    ['table' => 'crm_lead_products', 'col' => 'product_id'],
    ['table' => 'goods_received_from_production', 'col' => 'product_id'],
    ['table' => 'production_plans', 'col' => 'product_id'],
    ['table' => 'bmr_bpr_requests', 'col' => 'product_id'],
    ['table' => 'ip_coa_generation', 'col' => 'product_id'],
    ['table' => 'fg_coa_generation', 'col' => 'product_id'],
    ['table' => 'coa_inbound_queue', 'col' => 'product_id'],
    ['table' => 'low_stocks', 'col' => 'product_id'],
    ['table' => 'order_stock_reservations', 'col' => 'product_id'],
    ['table' => 'finance_product_commercials', 'col' => 'product_id'],
    ['table' => 'bpr_templates', 'col' => 'product_id'],
    ['table' => 'bmr_templates', 'col' => 'product_id'],
    ['table' => 'coa_templates', 'col' => 'product_id'],
    ['table' => 'stock_outward', 'col' => 'finished_product_id'],
];

$conn->begin_transaction();

try {
    echo "Starting duplicate products cleanup...\n";

    foreach ($pairs as $group) {
        $keeperId = (int)$group['keeper_id'];
        $name = $group['name'];
        echo "Processing '{$name}' -> Keeper ID: {$keeperId}\n";

        foreach ($group['redundant_ids'] as $redundantId) {
            $redundantId = (int)$redundantId;
            echo "  Merging redundant ID {$redundantId} -> {$keeperId}...\n";

            // 1. Direct re-links
            foreach ($directTables as $dt) {
                $table = $dt['table'];
                $col = $dt['col'];
                $conn->query("UPDATE `{$table}` SET `{$col}` = {$keeperId} WHERE `{$col}` = {$redundantId}");
                $aff = $conn->affected_rows;
                if ($aff > 0) {
                    echo "    Re-linked {$aff} rows in `{$table}`.`{$col}`\n";
                }
            }

            // 2. Salesperson responsibilities & expertise
            foreach (['salesperson_product_responsibility', 'salesperson_product_expertise'] as $spTable) {
                $conn->query("DELETE r FROM `{$spTable}` r 
                              INNER JOIN `{$spTable}` k ON r.salesperson_id = k.salesperson_id AND k.product_id = {$keeperId} 
                              WHERE r.product_id = {$redundantId}");
                $conn->query("UPDATE `{$spTable}` SET product_id = {$keeperId} WHERE product_id = {$redundantId}");
            }

            // 3. BOM & Template Mappings
            // bom_master
            $conn->query("DELETE FROM bom_master WHERE finished_product_id = {$redundantId} AND EXISTS (SELECT 1 FROM (SELECT id FROM bom_master WHERE finished_product_id = {$keeperId}) as t)");
            $conn->query("UPDATE bom_master SET finished_product_id = {$keeperId} WHERE finished_product_id = {$redundantId}");

            // bom_items
            $conn->query("UPDATE bom_items SET raw_product_id = {$keeperId} WHERE raw_product_id = {$redundantId}");

            // product_bom
            $conn->query("UPDATE product_bom SET finished_product_id = {$keeperId} WHERE finished_product_id = {$redundantId}");
            $conn->query("UPDATE product_bom SET raw_product_id = {$keeperId} WHERE raw_product_id = {$redundantId}");

            // Template mappings
            foreach (['bmr_template_product_mappings', 'coa_template_product_mappings'] as $mapTable) {
                $conn->query("DELETE m FROM `{$mapTable}` m 
                              INNER JOIN `{$mapTable}` k ON m.template_id = k.template_id AND k.product_id = {$keeperId} 
                              WHERE m.product_id = {$redundantId}");
                $conn->query("UPDATE `{$mapTable}` SET product_id = {$keeperId} WHERE product_id = {$redundantId}");
            }

            // 4. Live stock: inward/batch rows reassign to keeperId, unattached empty rows soft-delete
            $conn->query("UPDATE live_stock SET product_id = {$keeperId} WHERE product_id = {$redundantId} AND (stock_inward_id IS NOT NULL OR lot_batch_no IS NOT NULL OR coa_number IS NOT NULL)");
            $conn->query("UPDATE live_stock SET status = 3, deleted_at = NOW() WHERE product_id = {$redundantId} AND status != 3");

            // 5. Product Pack Sizes
            $conn->query("UPDATE product_pack_sizes p 
                          INNER JOIN product_pack_sizes k ON p.pack_size = k.pack_size AND p.pack_unit_id = k.pack_unit_id AND k.product_id = {$keeperId} AND k.status != 3 AND k.deleted_at IS NULL
                          SET p.status = 3, p.deleted_at = NOW()
                          WHERE p.product_id = {$redundantId} AND p.status != 3 AND p.deleted_at IS NULL");
            $conn->query("UPDATE product_pack_sizes SET product_id = {$keeperId} WHERE product_id = {$redundantId} AND status != 3 AND deleted_at IS NULL");

            // 6. Soft-delete redundant product record
            $conn->query("UPDATE products SET status = 3, deleted_at = NOW(), deleted_by = 1 WHERE id = {$redundantId}");
            echo "    Soft-deleted redundant product ID {$redundantId}.\n";
        }
    }

    $conn->commit();
    echo "\nAll duplicate records and transactions successfully cleaned up and re-linked!\n";

} catch (Throwable $e) {
    $conn->rollback();
    echo "ERROR during duplicate cleanup: " . $e->getMessage() . "\n";
    exit(1);
}
