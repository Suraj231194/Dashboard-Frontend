<?php
/**
 * cron_email_orders.php
 * 
 * Standalone cron entry point for email-to-order processing.
 * Should be invoked by the server's cron scheduler every 2 minutes.
 * 
 * Cron tab entry (Hostinger):
 *   * /2 * * * * /usr/bin/php /path/to/admin/cron_email_orders.php >> /path/to/logs/email_order_cron.log 2>&1
 * 
 * CLI flags:
 *   --test-connection   Test IMAP connectivity only
 *   --dry-run           Parse emails but don't create orders or send responses
 * 
 * Part of: Email-to-Order Processing Pipeline
 */

// ── Allow execution via CLI or Web browser ──
$isCli = (php_sapi_name() === 'cli' || php_sapi_name() === 'cli-server');
$isCronHttp = true; // Enabled for browser testing and cron execution


// ── Acquire file lock to prevent overlapping runs ──
$lockFile = __DIR__ . '/api/logs/email_cron.lock';
$lockDir  = dirname($lockFile);
if (!is_dir($lockDir)) {
    @mkdir($lockDir, 0755, true);
}

$lockFp = fopen($lockFile, 'c');
if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
    $msg = '[' . date('Y-m-d H:i:s') . '] SKIPPED: Another instance is already running.' . PHP_EOL;
    if ($isCli) {
        echo $msg;
    } else {
        echo json_encode(['status' => false, 'message' => 'Another instance is already running']);
    }
    exit;
}

// Write PID for monitoring
ftruncate($lockFp, 0);
fwrite($lockFp, (string) getmypid());
fflush($lockFp);

// ── Bootstrap ──
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';

// Load composer autoloader (for PHPMailer)
$composerAutoload = dirname(__DIR__) . '/vendor/autoload.php';
if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
}

// Load email services (autoload from api/services/)
$serviceDir = __DIR__ . '/api/services/';
$services = [
    'EmailOrderLogger.php',
    'EmailConfigService.php',
    'EmailParserService.php',
    'EmailResponderService.php',
    'ProductCatalogExportService.php',
    'OrderEmailService.php',
    'EmailPollerService.php',
];
foreach ($services as $svc) {
    $path = $serviceDir . $svc;
    if (file_exists($path)) {
        require_once $path;
    }
}

// Load API helpers
$helpersDir = __DIR__ . '/api/helpers/';
if (file_exists($helpersDir . 'common.php')) {
    require_once $helpersDir . 'common.php';
}

// ── Parse CLI flags ──
$isTestConnection = false;
$isDryRun         = false;

if ($isCli) {
    global $argv;
    $isTestConnection = in_array('--test-connection', $argv ?? []);
    $isDryRun         = in_array('--dry-run', $argv ?? []);
} else {
    $isTestConnection = isset($_GET['test']);
    $isDryRun         = isset($_GET['dryrun']);
}

// ── Execute ──
$startTime = microtime(true);
$timestamp = date('Y-m-d H:i:s');

try {
    $poller = new EmailPollerService($conn);

    if ($isTestConnection) {
        $result = $poller->testConnection();
        $output = "[{$timestamp}] CONNECTION TEST: " . json_encode($result) . PHP_EOL;
    } else {
        $result = $poller->pollAndProcess($isDryRun);
        $elapsed = round(microtime(true) - $startTime, 2);
        $output = sprintf(
            "[%s] POLL COMPLETE: %d processed, %d success, %d failed (%.2fs)%s\n",
            $timestamp,
            $result['processed'],
            $result['success'],
            $result['failed'],
            $elapsed,
            $isDryRun ? ' [DRY-RUN]' : ''
        );
        if (!empty($result['errors'])) {
            $output .= "  ERRORS: " . implode('; ', $result['errors']) . PHP_EOL;
        }
    }
} catch (Throwable $e) {
    $output = "[{$timestamp}] FATAL ERROR: " . $e->getMessage() . PHP_EOL;
    $result = ['status' => false, 'message' => $e->getMessage()];
}

// ── Output ──
if ($isCli) {
    echo $output;
} else {
    header('Content-Type: application/json');
    echo json_encode([
        'status'  => true,
        'message' => trim($output),
        'data'    => $result,
    ]);
}

// ── Release lock ──
flock($lockFp, LOCK_UN);
fclose($lockFp);
@unlink($lockFile);
