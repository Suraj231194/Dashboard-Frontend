<?php
function syncCategoryERPToWebsiteData($cat)
{
    global $webConn;
    $slug = $webConn->real_escape_string($cat['slug'] ?? '');
    $check = $webConn->query("SELECT `id` FROM `categories` WHERE `slug` = '$slug'");

    if ($check->num_rows) {

        $webConn->query("UPDATE `categories` SET
            `name`='".$webConn->real_escape_string($cat['name'])."',
            `sort_order`='".(int)$cat['sort_order']."',
            `updated_at`=NOW()
            WHERE `slug` ='$slug'");
        return 'update';
    } else {

        $webConn->query("INSERT INTO `categories`
            (`name`, `slug`, `sort_order`, `gst_rate`, `IsDisplayedOnHomePage`, `created_at`)
            VALUES
            (
                '".$webConn->real_escape_string($cat['name'])."',
                '$slug',
                '".(int)$cat['sort_order']."',
                '18',
                '0',
                NOW()
            )");

        return 'insert';
    }
}

function syncCategoryWebsiteToERPData($cat)
{
    global $conn;
    $slug = $conn->real_escape_string($cat['slug']);
    $check = $conn->query("SELECT `id` FROM `product_categories` WHERE `slug` = '$slug'");

    if($check->num_rows){
        $conn->query("UPDATE `product_categories` SET `name`='".$conn->real_escape_string($cat['name'])."', `sort_order`='".(int)$cat['sort_order']."', `status`='1', `updated_at`=NOW() WHERE `slug` ='$slug' ");
        return 'update';
    }else{
        $conn->query("INSERT INTO `product_categories`
            (`name`, `slug`, `sort_order`, `status`, `website_sync`, `created_at`)
            VALUES
            ('".$conn->real_escape_string($cat['name'])."', '$slug', '".(int)$cat['sort_order']."', '1', '1', NOW() )
        ");
        return 'insert';
    }
}

function getCategoryMaps()
{
    global $conn, $webConn;

    $webCategoryMap = [];
    $result = $webConn->query("SELECT `id`, `slug` FROM `categories`");
    while ($row = $result->fetch_assoc()) {
        $webCategoryMap[$row['slug']] = (int)$row['id'];
    }

    $erpCategoryMap = [];
    $result = $conn->query("SELECT `id`, `slug` FROM `product_categories`");
    while ($row = $result->fetch_assoc()) {
        $erpCategoryMap[$row['slug']] = (int)$row['id'];
    }

    return [
        'web' => $webCategoryMap,
        'erp' => $erpCategoryMap
    ];
}

function syncSubCategoryWebsiteToERPData($sub)
{
    global $conn;

    $maps = getCategoryMaps();

    $webCategoryMap = $maps['web'];
    $erpCategoryMap = $maps['erp'];

    $categorySlug = array_search((int)$sub['category_id'], $webCategoryMap);

    if (!$categorySlug || !isset($erpCategoryMap[$categorySlug])) {
        return false;
    }

    $erpCategoryId = $erpCategoryMap[$categorySlug];

    $slug = $conn->real_escape_string($sub['slug']);

    $check = $conn->query("SELECT `id` FROM `product_subcategories` WHERE `category_id` = '$erpCategoryId' AND `slug` = '$slug'");
    if($check->num_rows){
        $conn->query("UPDATE `product_subcategories` SET `name` = '".$conn->real_escape_string($sub['name'])."', `sort_order` = '".(int)$sub['sort_order']."', `updated_at` = NOW() WHERE `category_id` = '$erpCategoryId' AND `slug` = '$slug'");

        return 'update';
    }else{

        $conn->query("INSERT INTO product_subcategories
            (
                `category_id`,
                `name`,
                `slug`,
                `default_image_path`,
                `sort_order`,
                `website_sync`,
                `created_at`
            )
            VALUES
            (
                '$erpCategoryId',
                '".$conn->real_escape_string($sub['name'])."',
                '$slug',
                ".(
                    $sub['default_image_path']
                    ? "'".$conn->real_escape_string($sub['default_image_path'])."'"
                    : "NULL"
                ).",
                '".(int)$sub['sort_order']."',
                '1',
                NOW()
            )
        ");

        return 'insert';
    }
}

function syncSubCategoryERPToWebsiteData($sub)
{
    global $webConn;

    $maps = getCategoryMaps();

    $webCategoryMap = $maps['web'];
    $erpCategoryMap = $maps['erp'];

    $categorySlug = array_search((int)$sub['category_id'], $erpCategoryMap);

    if (!$categorySlug || !isset($webCategoryMap[$categorySlug])) {
        return false;
    }

    $webCategoryId = $webCategoryMap[$categorySlug];

    $slug = $webConn->real_escape_string($sub['slug']);

    $check = $webConn->query("SELECT `id` FROM `subcategories` WHERE `category_id` = '$webCategoryId' AND `slug` = '$slug'");

    if($check->num_rows){

        $webConn->query("UPDATE subcategories
            SET
                `name` = '".$webConn->real_escape_string($sub['name'])."',
                `default_image_path` = ".
                (
                    $sub['default_image_path']
                    ? "'".$webConn->real_escape_string($sub['default_image_path'])."'"
                    : "NULL"
                ).",
                `sort_order` = '".(int)$sub['sort_order']."',
                `updated_at` = NOW()
            WHERE
                `category_id` = '$webCategoryId'
            AND `slug` = '$slug'
        ");

        return 'update';

    }else{
        $webConn->query("INSERT INTO `subcategories`
            (
                `category_id`,
                `name`,
                `slug`,
                `default_image_path`,
                `sort_order`,
                `created_at`,
                `updated_at`
            )
            VALUES
            (
                '$webCategoryId',
                '".$webConn->real_escape_string($sub['name'])."',
                '$slug',
                ".(
                    $sub['default_image_path']
                    ? "'".$webConn->real_escape_string($sub['default_image_path'])."'"
                    : "NULL"
                ).",
                '".(int)$sub['sort_order']."',
                NOW(),
                NOW()
            )
        ");
        return 'insert';
    }
}
?>