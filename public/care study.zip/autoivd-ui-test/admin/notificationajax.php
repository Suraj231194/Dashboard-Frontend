<?php
date_default_timezone_set('Asia/Kolkata');
session_start();
require_once "db.php";
require_once 'constant.php';
include "functions.php";
require_once __DIR__ . '/../vendor/autoload.php';

if (isset($_GET["notificationListNavbar"])) {
    header('Content-Type: application/json');
    $userId = $_SESSION['user_id'] ?? 0;
    $roleId = $_SESSION['role_id'] ?? 0;
    $limit  = 10;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

    if ($userId == 0) {
        echo json_encode([
            'unread_count' => 0,
            'notifications' => [],
            'has_more' => false
        ]);
        exit;
    }
    // Deliver due employee reminders during the existing notification poll.
    // The cron route remains available for scheduled execution as well.
    cronCalendarReminders($conn);
    cronFinanceDueDateReminders($conn);
    cronTenderDueDateReminders($conn);
    $stmt = $conn->prepare("SELECT COUNT(*) 
        FROM notifications n
        LEFT JOIN notification_recipients nr 
            ON n.id = nr.notification_id AND nr.user_id = ?
        LEFT JOIN notification_roles rl 
            ON n.id = rl.notification_id AND rl.role_id = ?
        WHERE (nr.user_id IS NOT NULL AND nr.is_read = 0 AND nr.is_archive = 0) 
           OR (nr.id IS NULL AND rl.notification_id IS NOT NULL)
    ");
    $stmt->bind_param("ii", $userId, $roleId);
    $stmt->execute();
    $stmt->bind_result($unreadCount);
    $stmt->fetch();
    $stmt->close();
    $stmt = $conn->prepare("SELECT DISTINCT n.id AS notification_id,
                        nr.id AS recipient_id,
                        COALESCE(nr.is_read, 0) AS is_read,
                        COALESCE(nr.is_archive, 0) AS is_archive,
                        n.title,
                        n.message,
                        n.created_at,
                        n.severity
        FROM notifications n
        LEFT JOIN notification_recipients nr 
            ON n.id = nr.notification_id AND nr.user_id = ?
        LEFT JOIN notification_roles rl 
            ON n.id = rl.notification_id AND rl.role_id = ?
        WHERE (nr.user_id IS NOT NULL AND nr.is_archive = 0)
           OR (nr.id IS NULL AND rl.notification_id IS NOT NULL)
        ORDER BY n.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->bind_param("iiii", $userId, $roleId, $limit, $offset);
    $stmt->execute();

    $result = $stmt->get_result();
    $notifications = [];

    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();
    $hasMore = count($notifications) === $limit;

    echo json_encode([
        'unread_count' => (int)$unreadCount,
        'notifications' => $notifications,
        'has_more' => $hasMore,
        'next_offset' => $offset + $limit
    ]);
    exit;
}

if (isset($_POST["markAsReadNotification"]) && !empty($_POST["markAsReadNotification"])) {
    header('Content-Type: application/json');

    $userId = $_SESSION['user_id'] ?? 0;
    $notificationId = isset($_POST['notification_id']) ? (int)$_POST['notification_id'] : 0;

    if ($userId == 0 || $notificationId == 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }

    // Insert recipient record if not exists
    $stmt = $conn->prepare("INSERT IGNORE INTO `notification_recipients` (notification_id, user_id, is_read, read_at)
        VALUES (?, ?, 1, NOW())
    ");
    $stmt->bind_param("ii", $notificationId, $userId);
    $stmt->execute();
    $stmt->close();

    // Update existing record to mark as read
    $stmt = $conn->prepare("UPDATE `notification_recipients`
        SET is_read = 1, read_at = NOW()
        WHERE notification_id = ? AND user_id = ?
    ");
    $stmt->bind_param("ii", $notificationId, $userId);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
    exit;
}

if (isset($_POST["markAsArchiveNotification"]) && !empty($_POST["markAsArchiveNotification"])) {
    header('Content-Type: application/json');

    $userId = $_SESSION['user_id'] ?? 0;
    $notificationId = isset($_POST['notification_id']) ? (int)$_POST['notification_id'] : 0;

    if ($userId == 0 || $notificationId == 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }

    // Insert recipient record if not exists
    $stmt = $conn->prepare("INSERT IGNORE INTO `notification_recipients` (notification_id, user_id, is_archive, archived_at)
        VALUES (?, ?, 1, NOW()) ");
    $stmt->bind_param("ii", $notificationId, $userId);
    $stmt->execute();
    $stmt->close();

    // Update existing record to mark as read
    $stmt = $conn->prepare("UPDATE `notification_recipients`
        SET is_archive = 1, archived_at = NOW()
        WHERE notification_id = ? AND user_id = ?
    ");
    $stmt->bind_param("ii", $notificationId, $userId);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true, 'message' => 'Notification marked as archive']);
    exit;
}

if (isset($_POST["markAllAsReadNotifications"]) && !empty($_POST["markAllAsReadNotifications"])) {
    header('Content-Type: application/json');

    $userId = $_SESSION['user_id'] ?? 0;
    $roleId = $_SESSION['role_id'] ?? 0;

    if ($userId == 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid session']);
        exit;
    }

    // 1. Insert read records for any role-based notifications the user hasn't interacted with yet
    $insertSql = "INSERT INTO notification_recipients (notification_id, user_id, is_read, read_at)
        SELECT DISTINCT n.id, ?, 1, NOW()
        FROM notifications n
        INNER JOIN notification_roles rl ON n.id = rl.notification_id AND rl.role_id = ?
        LEFT JOIN notification_recipients nr ON n.id = nr.notification_id AND nr.user_id = ?
        WHERE nr.id IS NULL";
    $stmt = $conn->prepare($insertSql);
    if ($stmt) {
        $stmt->bind_param("iii", $userId, $roleId, $userId);
        $stmt->execute();
        $stmt->close();
    }

    // 2. Mark all existing recipient records for this user as read
    $updateSql = "UPDATE notification_recipients
        SET is_read = 1, read_at = NOW()
        WHERE user_id = ? AND is_read = 0";
    $stmt = $conn->prepare($updateSql);
    if ($stmt) {
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->close();
    }

    echo json_encode(['success' => true, 'message' => 'All notifications marked as read']);
    exit;
}

