<?php

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '0');
date_default_timezone_set('Asia/Kolkata');
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../vendor/autoload.php';

if (! isLoggedIn()) {
    http_response_code(401);
    exit('Your session has expired. Please sign in again.');
}
if (! checkPermission('sync_quotations_view', $conn)) {
    http_response_code(403);
    exit('You do not have permission to download synchronized quotations.');
}

$quotationId = (int) ($_GET['id'] ?? 0);
if ($quotationId <= 0) {
    http_response_code(422);
    exit('A valid quotation is required.');
}

$stmt = $conn->prepare("SELECT * FROM `quotation_requests` WHERE `id` = ? LIMIT 1");
if (! $stmt) {
    http_response_code(500);
    exit('The quotation snapshot migration must be applied before downloading PDFs.');
}
$stmt->bind_param('i', $quotationId);
$stmt->execute();
$quotation = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (! $quotation) {
    http_response_code(404);
    exit('Quotation snapshot not found.');
}

$itemStmt = $conn->prepare("SELECT * FROM `quotation_request_items` WHERE `quotation_request_id` = ? ORDER BY `id` ASC");
$itemStmt->bind_param('i', $quotationId);
$itemStmt->execute();
$itemResult = $itemStmt->get_result();
$items = [];
while ($row = $itemResult->fetch_assoc()) {
    $items[] = $row;
}
$itemStmt->close();

$escape = static fn ($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$money = static function ($value, string $currency) use ($escape): string {
    return $escape($currency) . ' ' . number_format((float) $value, 2, '.', ',');
};
$currency = trim((string) ($quotation['currency'] ?? 'INR')) ?: 'INR';
$sourceDate = $quotation['source_created_at'] ?? $quotation['created_at'] ?? '';
$sellerName = trim((string) ($quotation['owner_company_name'] ?? '')) ?: 'Biogenix Inc. Pvt. Ltd.';
$customerName = trim((string) ($quotation['target_company_name'] ?? '')) ?: trim((string) ($quotation['target_name'] ?? 'Customer'));
$safeNumber = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string) ($quotation['quotation_number'] ?? 'quotation')) ?: 'quotation';
$fileName = $safeNumber . '_website_snapshot.pdf';

$itemRows = '';
foreach ($items as $index => $item) {
    $itemRows .= '<tr>'
        . '<td>' . ($index + 1) . '</td>'
        . '<td><strong>' . $escape($item['product_name'] ?? '') . '</strong><br><span class="muted">' . $escape($item['sku'] ?? '') . '</span></td>'
        . '<td>' . $escape($item['variant_name'] ?? '') . '</td>'
        . '<td class="num">' . number_format((float) ($item['quantity'] ?? 0), 0) . '</td>'
        . '<td class="num">' . $money($item['unit_price'] ?? 0, $currency) . '<br><span class="muted">Tax ' . $money($item['unit_tax_amount'] ?? 0, $currency) . '</span></td>'
        . '<td class="num">' . number_format((float) ($item['discount_percent'] ?? 0), 2) . '%<br><span class="muted">' . $money($item['line_discount_amount'] ?? 0, $currency) . '</span></td>'
        . '<td class="num">' . $money($item['line_subtotal'] ?? 0, $currency) . '</td>'
        . '<td class="num">' . number_format((float) ($item['gst_rate'] ?? 0), 2) . '%</td>'
        . '<td class="num">' . $money($item['line_tax_amount'] ?? 0, $currency) . '</td>'
        . '<td class="num"><strong>' . $money($item['line_total'] ?? 0, $currency) . '</strong></td>'
        . '</tr>';
}
if ($itemRows === '') {
    $itemRows = '<tr><td colspan="10" class="empty">No synchronized line items.</td></tr>';
}

$html = '<!doctype html><html><head><meta charset="UTF-8"><style>
    @page { margin: 26px; }
    body { font-family: DejaVu Sans, sans-serif; color: #24372d; font-size: 10px; }
    h1 { margin: 0; color: #14532d; font-size: 22px; }
    h2 { margin: 0 0 5px; font-size: 12px; }
    .header { border-bottom: 2px solid #166534; padding-bottom: 12px; }
    .meta { margin-top: 6px; color: #64748b; font-size: 9px; }
    .grid { width: 100%; margin-top: 15px; border-collapse: separate; border-spacing: 8px 0; }
    .card { width: 50%; border: 1px solid #dfe9e3; padding: 10px; vertical-align: top; }
    .label { color: #64748b; font-size: 8px; font-weight: bold; text-transform: uppercase; }
    .value { margin-top: 4px; line-height: 1.5; }
    table.items { width: 100%; margin-top: 15px; border-collapse: collapse; }
    .items th { background: #ecfdf5; color: #166534; font-size: 8px; text-transform: uppercase; }
    .items th, .items td { border: 1px solid #dfe9e3; padding: 6px; }
    .num { text-align: right; white-space: nowrap; }
    .muted { color: #64748b; font-size: 8px; }
    .empty { padding: 18px; text-align: center; color: #64748b; }
    .totals { width: 42%; margin: 14px 0 0 auto; border-collapse: collapse; }
    .totals td { border-bottom: 1px solid #e5ece8; padding: 5px; }
    .totals .grand td { border-top: 2px solid #166534; color: #14532d; font-size: 12px; font-weight: bold; }
    .section { margin-top: 14px; border: 1px solid #dfe9e3; padding: 10px; }
    .footer { margin-top: 18px; border-top: 1px solid #dfe9e3; padding-top: 8px; color: #64748b; font-size: 8px; }
</style></head><body>'
    . '<div class="header"><h1>QUOTATION</h1><div class="meta">Website-owned synchronized snapshot - Read-only in ERP</div></div>'
    . '<table class="grid"><tr><td class="card"><div class="label">Seller / owner</div><div class="value"><strong>' . $escape($sellerName) . '</strong><br>' . $escape($quotation['owner_user_name'] ?? '') . '<br>' . $escape($quotation['owner_user_email'] ?? '') . '<br>GSTIN: ' . $escape($quotation['seller_gstin'] ?? $quotation['owner_company_gstin'] ?? '') . '</div></td>'
    . '<td class="card"><div class="label">Quotation</div><div class="value"><strong>' . $escape($quotation['quotation_number'] ?? '') . '</strong><br>Date: ' . $escape($sourceDate) . '<br>Status: ' . $escape($quotation['status'] ?? '') . '<br>Website ID: ' . (int) ($quotation['website_quotation_id'] ?? 0) . '</div></td></tr></table>'
    . '<table class="grid"><tr><td class="card"><div class="label">Bill to</div><div class="value"><strong>' . $escape($customerName) . '</strong><br>' . nl2br($escape($quotation['billing_address'] ?? '')) . '<br>' . $escape($quotation['target_email'] ?? '') . '<br>' . $escape($quotation['target_phone'] ?? '') . '<br>GSTIN: ' . $escape($quotation['customer_gstin'] ?? $quotation['target_company_gstin'] ?? '') . '</div></td>'
    . '<td class="card"><div class="label">Ship to</div><div class="value">' . nl2br($escape($quotation['shipping_address'] ?? '')) . '</div></td></tr></table>'
    . '<table class="items"><thead><tr><th>#</th><th>Product / SKU</th><th>Variant</th><th>Qty</th><th>Unit price / tax</th><th>Discount</th><th>Taxable</th><th>GST</th><th>Tax</th><th>Line total</th></tr></thead><tbody>' . $itemRows . '</tbody></table>'
    . '<table class="totals"><tr><td>Subtotal</td><td class="num">' . $money($quotation['subtotal'] ?? 0, $currency) . '</td></tr>'
    . '<tr><td>Discount</td><td class="num">' . $money($quotation['discount_amount'] ?? 0, $currency) . '</td></tr>'
    . '<tr><td>Tax</td><td class="num">' . $money($quotation['tax_amount'] ?? 0, $currency) . '</td></tr>'
    . '<tr><td>Freight</td><td class="num">' . $money($quotation['freight_charges'] ?? 0, $currency) . '</td></tr>'
    . '<tr><td>Freight tax</td><td class="num">' . $money($quotation['freight_tax_amount'] ?? 0, $currency) . '</td></tr>'
    . '<tr><td>Rounding</td><td class="num">' . $money($quotation['rounding_amount'] ?? 0, $currency) . '</td></tr>'
    . '<tr class="grand"><td>Total</td><td class="num">' . $money($quotation['total_amount'] ?? 0, $currency) . '</td></tr></table>'
    . '<div class="section"><div class="label">Terms</div><div class="value">' . nl2br($escape($quotation['terms'] ?? '')) . '</div></div>'
    . '<div class="section"><div class="label">Notes</div><div class="value">' . nl2br($escape($quotation['notes'] ?? '')) . '</div></div>'
    . '<div class="footer">Generated by ERP from immutable synchronized Website snapshot on ' . $escape(date('d M Y H:i:s')) . ' IST.</div>'
    . '</body></html>';

$options = new \Dompdf\Options();
$options->set('isRemoteEnabled', false);
$dompdf = new \Dompdf\Dompdf($options);
$dompdf->setPaper('A4', 'landscape');
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->render();

$auditTable = $conn->query("SHOW TABLES LIKE 'sync_document_activity_logs'");
if (! $auditTable || $auditTable->num_rows === 0) {
    http_response_code(503);
    exit('The document audit migration must be applied before downloading synchronized quotations.');
}
$action = 'generate_download';
$entityType = 'quotation';
$websiteId = (int) ($quotation['website_quotation_id'] ?? 0);
$userId = (int) ($_SESSION['user_id'] ?? 0);
$metadata = json_encode([
    'source_sync_version' => (int) ($quotation['source_sync_version'] ?? 0),
    'item_count' => count($items),
    'source_created_at' => $quotation['source_created_at'] ?? null,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$auditStmt = $conn->prepare("INSERT INTO `sync_document_activity_logs` (`entity_type`, `entity_id`, `website_id`, `action`, `file_name`, `user_id`, `metadata_json`, `created_at`) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
if (! $auditStmt) {
    http_response_code(500);
    exit('The quotation download could not be recorded in the ERP audit log.');
}
$auditStmt->bind_param('siissis', $entityType, $quotationId, $websiteId, $action, $fileName, $userId, $metadata);
if (! $auditStmt->execute()) {
    $auditStmt->close();
    http_response_code(500);
    exit('The quotation download could not be recorded in the ERP audit log.');
}
$auditStmt->close();

$dompdf->stream($fileName, ['Attachment' => true]);
exit;
