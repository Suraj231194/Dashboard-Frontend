<?php

date_default_timezone_set('Asia/Kolkata');
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/sync/SyncSettingsManager.php';
require_once __DIR__ . '/sync/SyncManager.php';
require_once __DIR__ . '/sync/SyncLogger.php';

header('Content-Type: application/json; charset=utf-8');

$respond = static function (bool $success, string $message, array $data = [], int $httpCode = 200): void {
    http_response_code($httpCode);
    echo json_encode([
        'success' => $success,
        'status' => $success ? 'success' : 'error',
        'message' => $message,
        'data' => $data,
    ], JSON_UNESCAPED_UNICODE);
    exit;
};

if (! isLoggedIn()) {
    $respond(false, 'Your session has expired. Please sign in again.', [], 401);
}

$hasPermission = static function (string $slug) use ($conn): bool {
    return checkPermission($slug, $conn);
};
$permissionIsDefined = static function (string $slug) use ($conn): bool {
    $stmt = $conn->prepare(
        "SELECT 1 FROM `permissions` WHERE `slug` = ? AND `status` != 3 LIMIT 1"
    );
    if (! $stmt) {
        return false;
    }
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
};

$action = trim((string) ($_POST['action'] ?? ''));
$entity = trim((string) ($_POST['entity'] ?? ''));
SyncLogger::write('system', 'AJAX_REQUEST', "syncAjax.php received action: {$action}" . ($entity !== '' ? " (entity: {$entity})" : ""));

$requestCsrfToken = (string) ($_POST['csrf_token'] ?? '');
$sessionCsrfToken = (string) ($_SESSION['csrf_token'] ?? '');
if ($sessionCsrfToken === '' || ! hash_equals($sessionCsrfToken, $requestCsrfToken)) {
    SyncLogger::write('system', 'CSRF_FAILURE', "CSRF token mismatch for action: {$action}");
    $respond(false, 'Your session token is invalid. Refresh the page and try again.', [], 419);
}
$settingsManager = new SyncSettingsManager($conn);

switch ($action) {
    case 'getSyncDashboard':
        if ($permissionIsDefined('sync_dashboard_view') && ! $hasPermission('sync_dashboard_view')) {
            $respond(false, 'You do not have permission to view sync activity.', [], 403);
        }

        $statusFilter = trim((string) ($_POST['status_filter'] ?? ''));
        $entityFilter = trim((string) ($_POST['entity_filter'] ?? ''));
        $allowedStatuses = ['', 'pending', 'success', 'failed'];
        if (! in_array($statusFilter, $allowedStatuses, true)) {
            $statusFilter = '';
        }
        if ($entityFilter !== '' && ! isset(SyncSettingsManager::definitions()[$entityFilter])) {
            $entityFilter = '';
        }

        $logs = ['total' => 0, 'data' => []];
        if ($settingsManager->hasTable('sync_logs')) {
            require_once __DIR__ . '/sync/SyncLogManager.php';
            $logManager = new SyncLogManager($conn);
            $logs = $logManager->getLogsForDashboard(50, 0, $statusFilter, $entityFilter);
        }

        $modules = $settingsManager->getModules();
        $enabledCount = count(array_filter(
            $modules,
            static fn (array $module): bool => (int) $module['is_enabled'] === 1
        ));
        $configuration = SyncManagerConfigurationStatus();
        $bioQueue = [
            'available' => false,
            'summary' => ['pending' => 0, 'failed' => 0],
            'pending' => [],
            'failed' => [],
            'message' => 'Bio queue visibility is unavailable until Website sync is configured.',
        ];
        if ($configuration['website_url'] && $configuration['website_token']) {
            $healthResult = SyncManager::getFromWebsite('/api/erp-sync/health?limit=50');
            if ($healthResult['success']) {
                $healthData = json_decode((string) $healthResult['body'], true);
                if (is_array($healthData) && ($healthData['status'] ?? '') === 'success') {
                    $bioQueue = [
                        'available' => true,
                        'summary' => is_array($healthData['summary'] ?? null) ? $healthData['summary'] : ['pending' => 0, 'failed' => 0],
                        'pending' => is_array($healthData['pending'] ?? null) ? $healthData['pending'] : [],
                        'failed' => is_array($healthData['failed'] ?? null) ? $healthData['failed'] : [],
                        'generated_at' => $healthData['generated_at'] ?? null,
                        'message' => '',
                    ];
                } else {
                    $bioQueue['message'] = 'Bio returned an invalid queue-health response.';
                }
            } else {
                $bioQueue['message'] = 'Bio queue-health endpoint is not reachable.';
            }
        }

        $respond(true, 'Sync dashboard loaded.', [
            'migration_ready' => $settingsManager->isReady(),
            'configuration_ready' => $configuration,
            'modules' => $modules,
            'summary' => $settingsManager->getDashboardSummary(),
            'enabled_count' => $enabledCount,
            'logs' => $logs,
            'bio_queue' => $bioQueue,
            'permissions' => [
                'manage' => $hasPermission('sync_settings_manage'),
                'retry' => $hasPermission('sync_failures_retry'),
            ],
        ]);
        break;

    case 'updateSyncSetting':
        if (! $hasPermission('sync_settings_manage')) {
            $respond(false, 'You do not have permission to manage sync settings.', [], 403);
        }
        $entity = trim((string) ($_POST['entity'] ?? ''));
        $enabled = filter_var($_POST['enabled'] ?? false, FILTER_VALIDATE_BOOLEAN);
        if ($enabled) {
            $configuration = SyncManagerConfigurationStatus();
            if (! $configuration['website_url'] || ! $configuration['website_token']) {
                $respond(false, 'Configure WEBSITE_SYNC_BASE_URL and WEBSITE_SYNC_TOKEN before enabling sync.', [], 409);
            }
        }
        $result = $settingsManager->setEnabled($entity, $enabled, (int) ($_SESSION['user_id'] ?? 0));
        $respond((bool) $result['success'], $result['message']);
        break;

    case 'retryBioQueueJob':
        if (! $hasPermission('sync_failures_retry')) {
            $respond(false, 'You do not have permission to retry Bio sync failures.', [], 403);
        }
        $uuid = trim((string) ($_POST['uuid'] ?? ''));
        if (! preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $uuid)) {
            $respond(false, 'A valid Bio failed-job reference is required.', [], 422);
        }
        $retryResult = SyncManager::postToWebsite('/api/erp-sync/health/retry', ['uuid' => $uuid]);
        $retryData = json_decode((string) ($retryResult['body'] ?? ''), true);
        $retryMessage = is_array($retryData) && ! empty($retryData['message'])
            ? (string) $retryData['message']
            : ($retryResult['success'] ? 'The Bio sync job was queued for retry.' : 'Bio could not retry the sync job.');
        $respond((bool) $retryResult['success'], $retryMessage, [], $retryResult['success'] ? 200 : max(400, (int) ($retryResult['http_code'] ?? 500)));
        break;

    case 'triggerEntitySync':
        $entity = trim((string) ($_POST['entity'] ?? ''));
        if (! in_array($entity, ['users', 'meetings', 'quiz', 'pi', 'quotations'], true)) {
            $respond(false, 'Only Website-to-ERP pull modules support this manual action.', [], 422);
        }

        $canSync = $hasPermission('sync_settings_manage')
            || ($entity === 'pi' && ($hasPermission('sync_pi_view') || $hasPermission('sales_billing_pi_generate_view')))
            || ($entity === 'quotations' && ($hasPermission('sync_quotations_view') || $hasPermission('crm_quote_menu_list')))
            || ($entity === 'users' && ($hasPermission('sync_users_view') || $hasPermission('customer_menu_list')))
            || ($entity === 'meetings' && $hasPermission('sync_meetings_view'))
            || ($entity === 'quiz' && $hasPermission('sync_quiz_view'));

        if (! $canSync) {
            $respond(false, 'You do not have permission to run a manual sync.', [], 403);
        }

        require_once __DIR__ . '/sync/BulkEntitySyncHandler.php';
        $result = (new BulkEntitySyncHandler($conn))->pullAndSyncEntity($entity);
        $respond((bool) $result['success'], $result['message'], [
            'synced_count' => (int) ($result['synced_count'] ?? 0),
        ]);
        break;

    case 'triggerInventorySync':
        if (! $hasPermission('sync_settings_manage')) {
            $respond(false, 'You do not have permission to run a manual sync.', [], 403);
        }
        if (! $settingsManager->isEnabled('inventory')) {
            $respond(false, 'Inventory sync is disabled.', [], 409);
        }

        require_once __DIR__ . '/sync/InventorySyncHandler.php';
        $pending = $conn->query(
            "SELECT DISTINCT ls.`product_id`
             FROM `live_stock` ls
             INNER JOIN `products` p ON p.`id` = ls.`product_id`
               AND p.`website_sync` = 1 AND p.`deleted_at` IS NULL
             INNER JOIN `product_categories` c ON c.`id` = p.`category_id`
               AND c.`website_sync` = 1
             WHERE ls.`sync_pending` = 1 AND ls.`deleted_at` IS NULL
             ORDER BY ls.`product_id` ASC
             LIMIT 20"
        );
        $handler = new InventorySyncHandler($conn);
        $processed = 0;
        $failed = 0;
        if ($pending instanceof mysqli_result) {
            while ($row = $pending->fetch_assoc()) {
                $result = $handler->pushProductStockToWebsite((int) $row['product_id']);
                if (! empty($result['success'])) {
                    $processed++;
                } else {
                    $failed++;
                }
            }
            $pending->free();
        }
        $respond($failed === 0, "Inventory run complete: {$processed} processed, {$failed} failed.", [
            'processed' => $processed,
            'failed' => $failed,
        ]);
        break;

    case 'retrySyncLog':
        if (! $hasPermission('sync_failures_retry')) {
            $respond(false, 'You do not have permission to retry sync failures.', [], 403);
        }
        if (! $settingsManager->hasTable('sync_logs')) {
            $respond(false, 'Sync migrations have not been applied.', [], 409);
        }

        require_once __DIR__ . '/sync/SyncLogManager.php';
        $logId = (int) ($_POST['log_id'] ?? 0);
        $log = (new SyncLogManager($conn))->getLogById($logId);
        if (! $log) {
            $respond(false, 'Sync log not found.', [], 404);
        }

        if ($log['entity_type'] === 'orders') {
            require_once __DIR__ . '/sync/OrderSyncHandler.php';
            $result = (new OrderSyncHandler($conn))->retryFromLog($logId);
        } elseif ($log['entity_type'] === 'inventory') {
            require_once __DIR__ . '/sync/InventorySyncHandler.php';
            $result = (new InventorySyncHandler($conn))->retryFromLog($logId);
        } else {
            $respond(false, 'This record uses Pull/Upsert/ACK; run its module pull instead.', [], 422);
        }
        $respond((bool) $result['success'], $result['message']);
        break;

    case 'syncCategories':
    case 'syncSubCategories':
        // Preserve the existing catalog sync entry points unchanged.
        require_once __DIR__ . '/syncFunction.php';
        if ($action === 'syncCategories') {
            echo json_encode(syncCategories(), JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode(syncSubCategories(), JSON_UNESCAPED_UNICODE);
        }
        exit;

    default:
        $respond(false, 'Invalid action.', [], 422);
}

/**
 * Return booleans only; never expose configured URLs or tokens to the browser.
 */
function SyncManagerConfigurationStatus(): array
{
    require_once __DIR__ . '/sync/SyncManager.php';

    $isUsable = static function (string $value): bool {
        $normalized = strtolower(trim($value));
        return $normalized !== ''
            && ! in_array($normalized, [
                'your-shared-sync-token-here',
                'test-token-123456',
                'change-me',
            ], true);
    };

    return [
        'website_url' => $isUsable(SyncManager::getWebsiteBaseUrl()),
        'website_token' => $isUsable(SyncManager::getWebsiteSyncToken()),
    ];
}
