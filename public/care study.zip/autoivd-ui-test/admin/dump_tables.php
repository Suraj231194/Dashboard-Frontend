<?php
require 'db.php';
if (!$conn) {
    echo "No connection\n";
    exit;
}

echo "--- users table ---\n";
$res = $conn->query('DESCRIBE users');
if ($res) {
    while($r = $res->fetch_assoc()) {
        echo $r['Field'] . ' (' . $r['Type'] . ")\n";
    }
} else {
    echo "Failed to query users table\n";
}

echo "\n--- employees table ---\n";
$res = $conn->query('DESCRIBE employees');
if ($res) {
    while($r = $res->fetch_assoc()) {
        echo $r['Field'] . ' (' . $r['Type'] . ")\n";
    }
} else {
    echo "Failed to query employees table\n";
}
