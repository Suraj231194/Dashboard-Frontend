<?php
// Local DB Connection
require 'db.php';
if (!$conn) {
    die("Local DB Connection failed.");
}

// Remote DB Connection
$remote_host = 'srv484.hstgr.io';
$remote_port = 3306;
$remote_db   = 'u706677387_dev_autoivd';
$remote_user = 'u706677387_dev_autoivd';
$remote_pass = 'D^06DSCr12s';

$remote_conn = new mysqli($remote_host, $remote_user, $remote_pass, $remote_db, $remote_port);
if ($remote_conn->connect_error) {
    die("Remote DB Connection failed: " . $remote_conn->connect_error);
}

echo "Connected to both local and remote databases.\n";

// 1. Create table on remote
$sql_create = "CREATE TABLE IF NOT EXISTS `user_appearance_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `theme_mode` enum('light', 'dark', 'auto') NOT NULL DEFAULT 'light',
  `accent_color` char(7) NOT NULL DEFAULT '#1A4D2E',
  `font_family` enum('Manrope', 'Inter', 'Roboto') NOT NULL DEFAULT 'Manrope',
  `base_font_size` tinyint(3) unsigned NOT NULL DEFAULT 15,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_appearance_settings_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

if ($remote_conn->query($sql_create) === TRUE) {
    echo "Table 'user_appearance_settings' created or already exists on remote.\n";
} else {
    die("Error creating table: " . $remote_conn->error);
}

// 2. Fetch data from local
$result = $conn->query("SELECT * FROM user_appearance_settings");
if ($result) {
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    echo "Found " . count($rows) . " rows in local db.\n";
    
    // 3. Sync to remote
    $synced = 0;
    foreach ($rows as $row) {
        $user_id = (int)$row['user_id'];
        $theme_mode = $remote_conn->real_escape_string($row['theme_mode']);
        $accent_color = $remote_conn->real_escape_string($row['accent_color']);
        $font_family = $remote_conn->real_escape_string($row['font_family']);
        $base_font_size = (int)$row['base_font_size'];
        
        $sql = "INSERT INTO user_appearance_settings (user_id, theme_mode, accent_color, font_family, base_font_size) 
                VALUES ($user_id, '$theme_mode', '$accent_color', '$font_family', $base_font_size)
                ON DUPLICATE KEY UPDATE 
                theme_mode='$theme_mode', accent_color='$accent_color', font_family='$font_family', base_font_size=$base_font_size";
        
        if ($remote_conn->query($sql) === TRUE) {
            $synced++;
        } else {
            echo "Error syncing user_id {$user_id}: " . $remote_conn->error . "\n";
        }
    }
    echo "Successfully synced $synced rows to remote db.\n";
} else {
    echo "Error fetching local data or table doesn't exist locally: " . $conn->error . "\n";
}

$conn->close();
$remote_conn->close();
