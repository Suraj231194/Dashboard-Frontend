<?php

declare(strict_types=1);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '0');
date_default_timezone_set('Asia/Kolkata');
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../vendor/autoload.php';

define('HRMS_CONTEXT', true);
require_once __DIR__ . '/hrms/hrms_common.php';
require_once __DIR__ . '/hrms/annual_calendar_common.php';
require_once __DIR__ . '/hrms/annual_calendar_api.php';

$userId = hrmsRequireLogin();
$action = trim((string) ($_POST['action'] ?? ''));

if ($action === '') {
    hrmsJson(['status' => 'error', 'message' => 'No HRMS action was supplied.'], 400);
}

$mutatingActions = [
    'submit_leave', 'review_leave', 'save_leave_type', 'save_leave_allocation', 'onboard_employee', 'save_employee_compensation',
    'link_employee_user', 'update_employee_section',
    'submit_resignation', 'review_resignation', 'save_offboarding_settings',
    'save_exit_question', 'delete_exit_question', 'reorder_exit_questions',
    'submit_exit_interview', 'save_biometric_device', 'configure_biometric_push', 'import_biometric_punches',
    'recalculate_attendance', 'mark_present_attendance',
    'create_hrms_shift', 'update_hrms_shift', 'delete_hrms_shift', 'save_shift_policy',
    'save_employee_shift_roster', 'delete_employee_shift_roster',
    'update_my_profile', 'upload_profile_photo', 'remove_profile_photo',
    'initialize_annual_calendar', 'update_saturday_policy', 'update_weekly_off_days',
    'add_calendar_holiday', 'update_calendar_holiday', 'delete_calendar_holiday',
    'toggle_calendar_holiday', 'finalize_annual_calendar', 'unfinalize_annual_calendar',
    'import_default_holidays', 'save_custom_weekly_offs',
    'save_calendar_day_override', 'delete_calendar_day_override',
    'copy_calendar_from_year', 'discard_calendar_draft', 'import_holiday_csv',
];
if (in_array($action, $mutatingActions, true)) {
    hrmsRequireCsrf();
}

$storedFiles = [];

try {
    if (acHandleApiAction($conn, $action, $userId)) {
        exit;
    }
    switch ($action) {
        case 'get_leave_balances':
            hrmsRequirePermission($conn, 'hrms_leave_manage');
            $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$employeeId) {
                throw new InvalidArgumentException('Select a valid employee.');
            }
            $employee = hrmsEmployeeById($conn, (int) $employeeId);
            if (!$employee) {
                throw new RuntimeException('Employee not found.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $employee);
            $balances = array_map(static function (array $balance): array {
                return [
                    'id' => (int) $balance['id'],
                    'name' => (string) $balance['name'],
                    'available' => (float) $balance['available'],
                    'current_booking' => (float) $balance['current_booking'],
                    'remaining' => (float) $balance['remaining'],
                    'eligible' => (bool) $balance['eligible'],
                    'can_apply' => (bool) $balance['can_apply'],
                ];
            }, hrmsLeaveBalances($conn, $employee));
            hrmsJson(['status' => 'success', 'balances' => $balances]);

        case 'submit_leave':
            $canManage = hrmsCan($conn, 'hrms_leave_manage');
            $targetEmployeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            if ($targetEmployeeId && $canManage) {
                $employee = hrmsEmployeeById($conn, (int) $targetEmployeeId);
            } else {
                $employee = hrmsCurrentEmployee($conn, $userId);
            }
            if (!$employee) {
                hrmsJson(['status' => 'error', 'message' => 'Your login is not linked to an employee record.'], 422);
            }

            $leaveTypeId = filter_var($_POST['leave_type_id'] ?? null, FILTER_VALIDATE_INT);
            $teamEmail = trim((string) ($_POST['team_email'] ?? ''));
            $reason = trim((string) ($_POST['reason'] ?? ''));
            if (!$leaveTypeId || $leaveTypeId <= 0) {
                throw new InvalidArgumentException('Select a leave type.');
            }
            if ($teamEmail !== '' && !filter_var($teamEmail, FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('Enter a valid team email address.');
            }
            if (mb_strlen($reason) < 5 || mb_strlen($reason) > 3000) {
                throw new InvalidArgumentException('Enter a reason between 5 and 3000 characters.');
            }

            $days = hrmsParseLeaveDays((string) ($_POST['leave_days'] ?? ''));
            $selectedStartDate = $days[0]['date'];
            $selectedEndDate = $days[count($days) - 1]['date'];
            $startDate = $selectedStartDate;
            $endDate = $selectedEndDate;
            if ((int) substr($startDate, 0, 4) !== (int) substr($endDate, 0, 4)) {
                throw new InvalidArgumentException('A leave request cannot span two leave years. Submit separate applications.');
            }
            $employeeCompanyId = (int) ($employee['company_id'] ?? 0);
            if ($employeeCompanyId <= 0) {
                $scope = hrmsCurrentScope($conn, $userId);
                $employeeCompanyId = (int) ($scope['company_id'] ?? 1);
                $employee['company_id'] = $employeeCompanyId;
            }
            if ($employeeCompanyId <= 0) {
                throw new RuntimeException('The employee is not assigned to an organization.');
            }
            $selectedDayCount = count($days);
            $days = acFilterChargeableLeaveDays($conn, $employeeCompanyId, $days);
            $excludedNonWorkingDays = $selectedDayCount - count($days);
            if ($days === []) {
                throw new InvalidArgumentException('The selected range contains no working days in the finalized Annual Calendar.');
            }
            $startDate = $days[0]['date'];
            $endDate = $days[count($days) - 1]['date'];
            $totalDays = array_sum(array_column($days, 'value'));
            $leaveYear = (int) substr($startDate, 0, 4);

            $conn->begin_transaction();
            $lockedEmployee = hrmsEmployeeById($conn, (int) $employee['id'], true);
            $balance = hrmsLeaveBalanceByType($conn, $lockedEmployee ?: $employee, (int) $leaveTypeId, $leaveYear);
            if (!$balance || !$balance['eligible']) {
                throw new RuntimeException('This leave type is not available for your employee profile.');
            }
            if ((int) $balance['allow_negative_balance'] !== 1 && $totalDays > (float) $balance['remaining']) {
                throw new RuntimeException('The selected dates exceed your remaining leave balance.');
            }

            $dateList = array_column($days, 'date');
            $placeholders = implode(',', array_fill(0, count($dateList), '?'));
            $overlapSql = "SELECT application.application_no, day.leave_date
                FROM hr_leave_application_days day
                INNER JOIN hr_leave_applications application ON application.id = day.application_id
                WHERE application.employee_id = ? AND application.status IN ('pending','approved')
                  AND day.leave_date IN ({$placeholders}) LIMIT 1";
            $overlapStmt = $conn->prepare($overlapSql);
            $overlapTypes = 'i' . str_repeat('s', count($dateList));
            $overlapParams = array_merge([(int) $employee['id']], $dateList);
            $overlapStmt->bind_param($overlapTypes, ...$overlapParams);
            $overlapStmt->execute();
            $overlap = $overlapStmt->get_result()->fetch_assoc();
            $overlapStmt->close();
            if ($overlap) {
                throw new RuntimeException('A pending or approved leave request already includes ' . $overlap['leave_date'] . '.');
            }

            $applicationNo = hrmsReference('LV');
            $employeeId = (int) $employee['id'];
            $companyId = !empty($employee['company_id']) ? (int) $employee['company_id'] : null;
            $branchId = !empty($employee['branch_id']) ? (int) $employee['branch_id'] : null;
            $insert = $conn->prepare(
                "INSERT INTO hr_leave_applications
                 (application_no, employee_id, company_id, branch_id, leave_type_id, start_date,
                  end_date, total_days, team_email, reason, status, submitted_at, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), ?)"
            );
            $insert->bind_param(
                'siiiissdssi',
                $applicationNo,
                $employeeId,
                $companyId,
                $branchId,
                $leaveTypeId,
                $startDate,
                $endDate,
                $totalDays,
                $teamEmail,
                $reason,
                $userId
            );
            if (!$insert->execute()) {
                throw new RuntimeException('Unable to submit the leave application.');
            }
            $applicationId = (int) $insert->insert_id;
            $insert->close();

            $dayStmt = $conn->prepare(
                'INSERT INTO hr_leave_application_days
                 (application_id, leave_date, calendar_day_type, is_chargeable, day_portion, day_value)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            foreach ($days as $day) {
                $date = $day['date'];
                $calendarDayType = $day['calendar_day_type'];
                $isChargeable = (int) $day['is_chargeable'];
                $portion = $day['portion'];
                $value = (float) $day['value'];
                $dayStmt->bind_param('issisd', $applicationId, $date, $calendarDayType, $isChargeable, $portion, $value);
                if (!$dayStmt->execute()) {
                    throw new RuntimeException('Unable to save the selected leave dates.');
                }
            }
            $dayStmt->close();

            $history = $conn->prepare(
                "INSERT INTO hr_leave_status_history (application_id, from_status, to_status, note, changed_by)
                 VALUES (?, NULL, 'pending', 'Submitted by employee', ?)"
            );
            $history->bind_param('ii', $applicationId, $userId);
            $history->execute();
            $history->close();
            $conn->commit();

            $managerIds = hrmsManagerUserIds($conn, 'hrms_leave_manage', $companyId, $branchId);
            $employeeName = trim($employee['first_name'] . ' ' . $employee['last_name']);
            hrmsNotify(
                $conn,
                '90',
                'hr_leave_applications',
                $applicationId,
                'New leave application',
                "{$employeeName} submitted {$totalDays} day(s) of {$balance['name']}.",
                $userId,
                $managerIds
            );
            if ($teamEmail !== '') {
                hrmsSendLeaveTeamNotification($conn, $applicationId, $teamEmail);
            }
            $message = 'Leave application submitted successfully.';
            if ($excludedNonWorkingDays > 0) {
                $message .= " {$excludedNonWorkingDays} holiday/weekly-off date(s) were excluded.";
            }
            hrmsJson(['status' => 'success', 'message' => $message, 'application_no' => $applicationNo]);

        case 'review_leave':
            hrmsRequirePermission($conn, 'hrms_leave_manage');
            $applicationId = filter_var($_POST['application_id'] ?? null, FILTER_VALIDATE_INT);
            $decision = (string) ($_POST['decision'] ?? '');
            $note = trim((string) ($_POST['note'] ?? ''));
            if (!$applicationId || !in_array($decision, ['approved', 'rejected'], true)) {
                throw new InvalidArgumentException('Select a valid leave application and decision.');
            }
            if ($decision === 'rejected' && mb_strlen($note) < 3) {
                throw new InvalidArgumentException('Enter a rejection reason.');
            }

            $conn->begin_transaction();
            $stmt = $conn->prepare(
                "SELECT application.*, employee.user_id, employee.gender
                 FROM hr_leave_applications application
                 INNER JOIN employees employee ON employee.id = application.employee_id
                 WHERE application.id = ? FOR UPDATE"
            );
            $stmt->bind_param('i', $applicationId);
            $stmt->execute();
            $application = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$application || $application['status'] !== 'pending') {
                throw new RuntimeException('This leave application is no longer pending.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $application);
            if ($decision === 'approved') {
                $employee = hrmsEmployeeById($conn, (int) $application['employee_id'], true);
                $balance = hrmsLeaveBalanceByType(
                    $conn,
                    $employee ?: $application,
                    (int) $application['leave_type_id'],
                    (int) substr((string) $application['start_date'], 0, 4)
                );
                if (!$balance || !$balance['eligible']) {
                    throw new RuntimeException('The employee is no longer eligible for this leave type.');
                }
                $availableExcludingRequest = (float) $balance['remaining'] + (float) $application['total_days'];
                if ((int) $balance['allow_negative_balance'] !== 1 && (float) $application['total_days'] > $availableExcludingRequest) {
                    throw new RuntimeException('The employee no longer has sufficient leave balance.');
                }
            }

            $update = $conn->prepare(
                'UPDATE hr_leave_applications SET status = ?, action_by = ?, action_at = NOW(), action_note = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND status = \'pending\''
            );
            $update->bind_param('sisii', $decision, $userId, $note, $userId, $applicationId);
            if (!$update->execute() || $update->affected_rows !== 1) {
                throw new RuntimeException('Unable to review the leave application.');
            }
            $update->close();
            $history = $conn->prepare(
                "INSERT INTO hr_leave_status_history (application_id, from_status, to_status, note, changed_by)
                 VALUES (?, 'pending', ?, ?, ?)"
            );
            $history->bind_param('issi', $applicationId, $decision, $note, $userId);
            $history->execute();
            $history->close();
            $conn->commit();

            if (!empty($application['user_id'])) {
                hrmsNotify(
                    $conn,
                    '90',
                    'hr_leave_applications',
                    $applicationId,
                    'Leave application ' . $decision,
                    'Your leave application ' . $application['application_no'] . ' was ' . $decision . '.',
                    $userId,
                    [(int) $application['user_id']]
                );
            }
            hrmsJson(['status' => 'success', 'message' => 'Leave application ' . $decision . ' successfully.']);

        case 'save_leave_type':
            hrmsRequirePermission($conn, 'hrms_leave_manage');
            $leaveTypeId = filter_var($_POST['leave_type_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
            $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
            $name = trim((string) ($_POST['name'] ?? ''));
            $description = trim((string) ($_POST['description'] ?? ''));
            $color = trim((string) ($_POST['color'] ?? '#10b981'));
            $genderEligibility = (string) ($_POST['gender_eligibility'] ?? 'all');
            $isPaid = (!empty($_POST['is_paid']) && (string) $_POST['is_paid'] === '1') ? 1 : 0;
            $allowNegativeBalance = isset($_POST['allow_negative_balance']) ? 1 : 0;
            $status = isset($_POST['status']) ? 1 : 0;
            if (!preg_match('/^[A-Z0-9_-]{2,40}$/', $code)) {
                throw new InvalidArgumentException('Leave type codes must use 2 to 40 letters, numbers, hyphens or underscores.');
            }
            if (mb_strlen($name) < 2 || mb_strlen($name) > 100 || mb_strlen($description) > 500) {
                throw new InvalidArgumentException('Enter a valid leave type name and description.');
            }
            if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $color) || !in_array($genderEligibility, ['all', 'female', 'male'], true)) {
                throw new InvalidArgumentException('Select a valid color and gender eligibility.');
            }

            $scope = hrmsCurrentScope($conn, $userId);
            $companyId = $scope['company_id'];
            if ($leaveTypeId > 0) {
                $existingStmt = $conn->prepare('SELECT id, company_id FROM hr_leave_types WHERE id = ? LIMIT 1');
                $existingStmt->bind_param('i', $leaveTypeId);
                $existingStmt->execute();
                $existingType = $existingStmt->get_result()->fetch_assoc();
                $existingStmt->close();
                if (!$existingType) {
                    throw new RuntimeException('Leave type not found.');
                }
                if ($scope['company_id'] !== null && ($existingType['company_id'] === null || (int) $existingType['company_id'] !== $scope['company_id'])) {
                    hrmsJson(['status' => 'error', 'message' => 'System and other organization leave types cannot be edited.'], 403);
                }
                $companyId = $existingType['company_id'] !== null ? (int) $existingType['company_id'] : null;
            } elseif ($scope['company_id'] === null) {
                $requestedCompanyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
                $companyId = $requestedCompanyId && $requestedCompanyId > 0 ? (int) $requestedCompanyId : null;
            }
            if ($companyId !== null) {
                $companyStmt = $conn->prepare('SELECT id FROM erp_companies WHERE id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1');
                $companyStmt->bind_param('i', $companyId);
                $companyStmt->execute();
                $validCompany = $companyStmt->get_result()->fetch_assoc();
                $companyStmt->close();
                if (!$validCompany) {
                    throw new InvalidArgumentException('Select a valid organization.');
                }
            }
            $duplicateStmt = $conn->prepare(
                'SELECT id FROM hr_leave_types WHERE code = ? AND id <> ? AND (company_id <=> ? OR (? IS NOT NULL AND company_id IS NULL)) LIMIT 1'
            );
            $duplicateStmt->bind_param('siii', $code, $leaveTypeId, $companyId, $companyId);
            $duplicateStmt->execute();
            $duplicate = $duplicateStmt->get_result()->fetch_assoc();
            $duplicateStmt->close();
            if ($duplicate) {
                throw new RuntimeException('That leave type code already exists for this organization.');
            }

            if ($leaveTypeId > 0) {
                $stmt = $conn->prepare(
                    'UPDATE hr_leave_types SET code = ?, name = ?, description = ?, color = ?, is_paid = ?, gender_eligibility = ?, allow_negative_balance = ?, status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?'
                );
                $stmt->bind_param('ssssisiiii', $code, $name, $description, $color, $isPaid, $genderEligibility, $allowNegativeBalance, $status, $userId, $leaveTypeId);
                $message = 'Leave type updated successfully.';
            } else {
                $stmt = $conn->prepare(
                    'INSERT INTO hr_leave_types (company_id, code, name, description, color, is_paid, gender_eligibility, allow_negative_balance, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->bind_param('issssisiii', $companyId, $code, $name, $description, $color, $isPaid, $genderEligibility, $allowNegativeBalance, $status, $userId);
                $message = 'Leave type created successfully.';
            }
            $stmt->execute();
            $stmt->close();
            hrmsJson(['status' => 'success', 'message' => $message]);

        case 'save_leave_allocation':
            hrmsRequirePermission($conn, 'hrms_leave_manage');
            $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            $leaveTypeId = filter_var($_POST['leave_type_id'] ?? null, FILTER_VALIDATE_INT);
            $year = filter_var($_POST['leave_year'] ?? null, FILTER_VALIDATE_INT);
            $allocated = filter_var($_POST['allocated_days'] ?? null, FILTER_VALIDATE_FLOAT);
            $carried = filter_var($_POST['carried_forward_days'] ?? 0, FILTER_VALIDATE_FLOAT);
            $adjustment = filter_var($_POST['adjustment_days'] ?? 0, FILTER_VALIDATE_FLOAT);
            if (!$employeeId || !$leaveTypeId || !$year || $year < 2000 || $year > 2100 || $allocated === false || $allocated < 0 || $allocated > 999) {
                throw new InvalidArgumentException('Enter a valid employee, leave type, year and allocation.');
            }
            $employee = hrmsEmployeeById($conn, (int) $employeeId);
            if (!$employee) {
                throw new RuntimeException('Employee not found.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $employee);
            $employeeCompanyId = !empty($employee['company_id']) ? (int) $employee['company_id'] : 0;
            $typeStmt = $conn->prepare('SELECT id, gender_eligibility FROM hr_leave_types WHERE id = ? AND status = 1 AND (company_id IS NULL OR company_id = ?) LIMIT 1');
            $typeStmt->bind_param('ii', $leaveTypeId, $employeeCompanyId);
            $typeStmt->execute();
            $visibleLeaveType = $typeStmt->get_result()->fetch_assoc();
            $typeStmt->close();
            if (!$visibleLeaveType) {
                throw new InvalidArgumentException('Select a leave type available to this employee organization.');
            }
            $employeeGender = (int) ($employee['gender'] ?? 0);
            $genderEligibility = (string) ($visibleLeaveType['gender_eligibility'] ?? 'all');
            if (($genderEligibility === 'female' && $employeeGender !== 2)
                || ($genderEligibility === 'male' && $employeeGender !== 1)) {
                throw new InvalidArgumentException('The selected leave type is not available for this employee profile.');
            }
            $stmt = $conn->prepare(
                "INSERT INTO hr_leave_allocations
                 (employee_id, leave_type_id, leave_year, allocated_days, carried_forward_days, adjustment_days, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE allocated_days = VALUES(allocated_days),
                   carried_forward_days = VALUES(carried_forward_days), adjustment_days = VALUES(adjustment_days),
                   updated_by = VALUES(created_by), updated_at = NOW()"
            );
            $stmt->bind_param('iiidddi', $employeeId, $leaveTypeId, $year, $allocated, $carried, $adjustment, $userId);
            $stmt->execute();
            $stmt->close();
            hrmsJson(['status' => 'success', 'message' => 'Leave allocation saved successfully.']);

        case 'onboard_employee':
            hrmsRequirePermission($conn, 'hrms_employee_master_manage');
            $firstName = trim((string) ($_POST['first_name'] ?? ''));
            $middleName = trim((string) ($_POST['middle_name'] ?? ''));
            $lastName = trim((string) ($_POST['last_name'] ?? ''));
            $dateOfJoin = trim((string) ($_POST['date_of_join'] ?? ''));
            $workEmail = strtolower(trim((string) ($_POST['work_email'] ?? '')));
            $mobile = trim((string) ($_POST['mobile'] ?? ''));
            $gender = filter_var($_POST['gender'] ?? null, FILTER_VALIDATE_INT);
            $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
            $branchId = filter_var($_POST['branch_id'] ?? null, FILTER_VALIDATE_INT);
            $designationId = filter_var($_POST['designation_id'] ?? null, FILTER_VALIDATE_INT);
            $departmentId = filter_var($_POST['department_id'] ?? null, FILTER_VALIDATE_INT);
            $workLocation = trim((string) ($_POST['work_location'] ?? ''));
            $portalAccess = isset($_POST['portal_access']) && (string) $_POST['portal_access'] === '1';
            $annualCtc = filter_var($_POST['annual_ctc'] ?? null, FILTER_VALIDATE_FLOAT);
            $hasPfCategoryPayload = array_key_exists('pf_category', $_POST);
            $pfCategory = strtolower(trim((string) ($_POST['pf_category'] ?? '')));
            $dob = trim((string) ($_POST['dob'] ?? ''));
            $fatherName = trim((string) ($_POST['fathers_name'] ?? ''));
            $panNo = strtoupper(trim((string) ($_POST['pan_no'] ?? '')));
            $personalEmail = strtolower(trim((string) ($_POST['personal_email'] ?? '')));
            $residentialAddress = trim((string) ($_POST['residential_address'] ?? ''));
            $differentlyAbled = isset($_POST['differently_abled']) && (string) $_POST['differently_abled'] === '1';
            $differentlyAbledType = $differentlyAbled ? trim((string) ($_POST['differently_abled_type'] ?? '')) : '';
            $isDirector = isset($_POST['is_director']) && (string) $_POST['is_director'] === '1';
            $addressLine2 = trim((string) ($_POST['address_line_2'] ?? ''));
            $city = trim((string) ($_POST['city'] ?? ''));
            $state = trim((string) ($_POST['state'] ?? ''));
            $postalCode = strtoupper(trim((string) ($_POST['postal_code'] ?? '')));
            $hasExtendedProfilePayload = array_key_exists('middle_name', $_POST)
                || array_key_exists('differently_abled_type', $_POST)
                || array_key_exists('address_line_2', $_POST)
                || array_key_exists('city', $_POST)
                || array_key_exists('state', $_POST)
                || array_key_exists('postal_code', $_POST)
                || array_key_exists('is_director', $_POST);
            $paymentMode = (string) ($_POST['payment_mode'] ?? '');
            $holderName = trim((string) ($_POST['bank_account_holder_name'] ?? ''));
            $bankId = filter_var($_POST['bank_id'] ?? null, FILTER_VALIDATE_INT);
            $accountNumber = trim((string) ($_POST['bank_account_number'] ?? ''));
            $confirmAccountNumber = trim((string) ($_POST['confirm_bank_account_number'] ?? ''));
            $ifscCode = strtoupper(trim((string) ($_POST['bank_ifsc_code'] ?? '')));
            $accountType = filter_var($_POST['bank_account_type'] ?? null, FILTER_VALIDATE_INT);
            $upiId = trim((string) ($_POST['upi_id'] ?? ''));
            $chequePayeeName = trim((string) ($_POST['cheque_payee_name'] ?? ''));
            $chequeBankId = filter_var($_POST['cheque_bank_id'] ?? null, FILTER_VALIDATE_INT);
            $componentsJson = (string) ($_POST['salary_components'] ?? '[]');

            if ($firstName === '' || mb_strlen($firstName) > 100 || mb_strlen($middleName) > 100 || $lastName === '' || mb_strlen($lastName) > 100) {
                throw new InvalidArgumentException('Enter the employee first and last name.');
            }
            if (!filter_var($workEmail, FILTER_VALIDATE_EMAIL) || mb_strlen($workEmail) > 255) {
                throw new InvalidArgumentException('Enter a valid work email address.');
            }
            if ($personalEmail !== '' && !filter_var($personalEmail, FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('Enter a valid personal email address.');
            }
            $joinDateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $dateOfJoin);
            $dobObject = DateTimeImmutable::createFromFormat('!Y-m-d', $dob);
            if (!$joinDateObject || $joinDateObject->format('Y-m-d') !== $dateOfJoin || !$dobObject || $dobObject->format('Y-m-d') !== $dob || $dob >= $dateOfJoin) {
                throw new InvalidArgumentException('Enter valid date of birth and joining dates.');
            }
            if (!in_array((int) $gender, [1, 2, 4], true) || !$companyId || !$branchId || !$designationId || !$departmentId) {
                throw new InvalidArgumentException('Select gender, organization, branch, designation and department.');
            }
            if (!preg_match('/^[0-9+()\-\s]{7,20}$/', $mobile)) {
                throw new InvalidArgumentException('Enter a valid mobile number.');
            }
            if ($residentialAddress === '' || mb_strlen($residentialAddress) > 255 || mb_strlen($addressLine2) > 255
                || mb_strlen($city) > 100 || mb_strlen($state) > 100 || mb_strlen($postalCode) > 20
                || mb_strlen($differentlyAbledType) > 100 || ($differentlyAbled && $differentlyAbledType === '')) {
                throw new InvalidArgumentException('Complete the residential and differently-abled details.');
            }
            if ($annualCtc === false || $annualCtc <= 0 || $annualCtc > 999999999999.99) {
                throw new InvalidArgumentException('Enter a valid annual CTC.');
            }
            $profilePfColumn = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'pf_category'");
            $salaryPfColumn = $conn->query("SHOW COLUMNS FROM employee_salaries LIKE 'pf_category'");
            $statutorySchemaReady = $profilePfColumn && $profilePfColumn->num_rows === 1
                && $salaryPfColumn && $salaryPfColumn->num_rows === 1;
            if ($statutorySchemaReady && !in_array($pfCategory, ['e', 'w', 'ew'], true)) {
                throw new InvalidArgumentException('Select Employee, Worker or Employee / Worker as the PF category.');
            }
            $allowedPaymentModes = ['direct_deposit', 'bank_transfer', 'upi', 'cheque', 'cash'];
            if (!in_array($paymentMode, $allowedPaymentModes, true)) {
                throw new InvalidArgumentException('Select a payment mode.');
            }
            if (in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true)) {
                if (!$bankId || $holderName === '' || $accountNumber === '' || $ifscCode === '' || !$accountType) {
                    throw new InvalidArgumentException('Complete the bank account details for the selected payment mode.');
                }
                if (!hash_equals($accountNumber, $confirmAccountNumber)) {
                    throw new InvalidArgumentException('The bank account numbers do not match.');
                }
            } elseif ($paymentMode === 'upi') {
                if ($upiId === '') {
                    throw new InvalidArgumentException('Enter the UPI ID for the employee.');
                }
                $upiHolder = trim((string) ($_POST['upi_holder_name'] ?? ''));
                if ($holderName === '' && $upiHolder !== '') {
                    $holderName = $upiHolder;
                }
            } elseif ($paymentMode === 'cheque') {
                if ($chequePayeeName !== '') {
                    $holderName = $chequePayeeName;
                }
                if ($chequeBankId) {
                    $bankId = $chequeBankId;
                }
            }

            $components = json_decode($componentsJson, true);
            if (!is_array($components) || $components === []) {
                throw new InvalidArgumentException('Add at least one salary component.');
            }
            $allowedCalculationTypes = ['ctc_percentage', 'basic_percentage', 'fixed'];
            $normalizedComponents = [];
            $basicAnnual = 0.0;
            foreach ($components as $index => $component) {
                $code = strtoupper(preg_replace('/[^A-Z0-9_]/', '', (string) ($component['code'] ?? '')));
                $name = trim((string) ($component['name'] ?? ''));
                $calculationType = (string) ($component['calculation_type'] ?? '');
                $calculationValue = filter_var($component['calculation_value'] ?? null, FILTER_VALIDATE_FLOAT);
                if ($code === '' || $name === '' || !in_array($calculationType, $allowedCalculationTypes, true) || $calculationValue === false || $calculationValue < 0) {
                    throw new InvalidArgumentException('One or more salary components are invalid.');
                }
                if (isset($normalizedComponents[$code])) {
                    throw new InvalidArgumentException("Salary component code {$code} is duplicated.");
                }
                $normalizedComponents[$code] = [
                    'code' => $code,
                    'name' => mb_substr($name, 0, 120),
                    'calculation_type' => $calculationType,
                    'calculation_value' => (float) $calculationValue,
                    'is_deduction' => !empty($component['is_deduction']) ? 1 : 0,
                    'sort_order' => $index,
                ];
            }
            if (!isset($normalizedComponents['BASIC'])) {
                throw new InvalidArgumentException('A Basic salary component is required.');
            }
            $basicDefinition = $normalizedComponents['BASIC'];
            $basicAnnual = $basicDefinition['calculation_type'] === 'fixed'
                ? $basicDefinition['calculation_value'] * 12
                : $annualCtc * $basicDefinition['calculation_value'] / 100;
            if ($basicAnnual <= 0) {
                throw new InvalidArgumentException('The Basic salary component must be greater than zero.');
            }
            foreach ($normalizedComponents as &$component) {
                $component['annual_amount'] = round(match ($component['calculation_type']) {
                    'fixed' => $component['calculation_value'] * 12,
                    'basic_percentage' => $basicAnnual * $component['calculation_value'] / 100,
                    default => $annualCtc * $component['calculation_value'] / 100,
                }, 2);
                $component['monthly_amount'] = round($component['annual_amount'] / 12, 2);
            }
            unset($component);
            $earningAnnualTotal = array_sum(array_map(
                static fn(array $component): float => $component['is_deduction'] ? 0.0 : (float) $component['annual_amount'],
                $normalizedComponents
            ));
            if (abs($earningAnnualTotal - (float) $annualCtc) > 0.05) {
                throw new InvalidArgumentException('Earning salary heads must equal the Annual CTC.');
            }

            if ($hasExtendedProfilePayload) {
                $profileColumnCheck = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'middle_name'");
                if (!$profileColumnCheck || $profileColumnCheck->num_rows !== 1) {
                    throw new RuntimeException('Apply the Care IO completion migration before using the extended onboarding fields.');
                }
            }
            if ($hasPfCategoryPayload) {
                if (!$statutorySchemaReady) {
                    throw new RuntimeException('Apply the Salary Statutory Rules migration before selecting a PF category.');
                }
            }

            $scope = hrmsCurrentScope($conn, $userId);
            if ($scope['company_id'] !== null && $scope['company_id'] !== (int) $companyId) {
                throw new RuntimeException('You cannot onboard an employee into another organization.');
            }
            if ($scope['branch_id'] !== null && $scope['branch_id'] !== (int) $branchId) {
                throw new RuntimeException('You cannot onboard an employee into another branch.');
            }
            $branchCheck = $conn->prepare('SELECT id FROM erp_branches WHERE id = ? AND company_id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1');
            $branchCheck->bind_param('ii', $branchId, $companyId);
            $branchCheck->execute();
            $validBranch = $branchCheck->get_result()->fetch_assoc();
            $branchCheck->close();
            if (!$validBranch) {
                throw new RuntimeException('The selected branch does not belong to the selected organization.');
            }

            $conn->begin_transaction();
            $duplicateStmt = $conn->prepare('SELECT id FROM employees WHERE email = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE');
            $duplicateStmt->bind_param('s', $workEmail);
            $duplicateStmt->execute();
            $duplicateEmployee = $duplicateStmt->get_result()->fetch_assoc();
            $duplicateStmt->close();
            if ($duplicateEmployee) {
                throw new RuntimeException('An employee with this work email already exists.');
            }

            $employeeCode = hrmsGenerateEmployeeCode($conn, (int) $companyId);
            $existingUserId = filter_var($_POST['existing_user_id'] ?? null, FILTER_VALIDATE_INT);
            $linkedUserId = null;
            $temporaryPassword = null;
            if ($existingUserId && $existingUserId > 0) {
                $userCheck = $conn->prepare('SELECT id, email FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1');
                $userCheck->bind_param('i', $existingUserId);
                $userCheck->execute();
                $existingUserRow = $userCheck->get_result()->fetch_assoc();
                $userCheck->close();
                if (!$existingUserRow) {
                    throw new RuntimeException('The selected user account does not exist.');
                }
                $linkedUserId = (int) $existingUserRow['id'];
                $portalAccess = true;
                $updUser = $conn->prepare('UPDATE users SET company_id = COALESCE(company_id, ?), branch_id = COALESCE(branch_id, ?) WHERE id = ?');
                $updUser->bind_param('iii', $companyId, $branchId, $linkedUserId);
                $updUser->execute();
                $updUser->close();
            } elseif ($portalAccess) {
                $roleResult = $conn->query("SELECT id FROM roles WHERE LOWER(name) = 'employee' AND status = 1 AND deleted_at IS NULL ORDER BY id LIMIT 1");
                $employeeRole = $roleResult ? $roleResult->fetch_assoc() : null;
                if (!$employeeRole) {
                    throw new RuntimeException('The Employee portal role is unavailable.');
                }
                $userCheck = $conn->prepare('SELECT id FROM users WHERE email = ? AND deleted_at IS NULL LIMIT 1');
                $userCheck->bind_param('s', $workEmail);
                $userCheck->execute();
                if ($userCheck->get_result()->fetch_assoc()) {
                    throw new RuntimeException('A portal user with this email already exists.');
                }
                $userCheck->close();
                $temporaryPassword = 'Emp@' . strtoupper(bin2hex(random_bytes(4)));
                $passwordHash = md5($temporaryPassword);
                $fullName = trim($firstName . ' ' . $middleName . ' ' . $lastName);
                $roleId = (int) $employeeRole['id'];
                $userStmt = $conn->prepare(
                    'INSERT INTO users (name, email, password, role_id, company_id, branch_id, is_active, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
                );
                $userStmt->bind_param('sssiiii', $fullName, $workEmail, $passwordHash, $roleId, $companyId, $branchId, $userId);
                $userStmt->execute();
                $linkedUserId = (int) $userStmt->insert_id;
                $userStmt->close();
            }

            $legacyResidentialAddress = mb_substr(implode(', ', array_filter([$residentialAddress, $addressLine2, $city, $state, $postalCode], static fn(string $part): bool => $part !== '')), 0, 255);
            $finalBankId = in_array($paymentMode, ['direct_deposit', 'bank_transfer', 'cheque'], true) && $bankId ? $bankId : null;
            $finalAccountNumber = in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true) ? $accountNumber : '';
            $finalIfscCode = in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true) ? $ifscCode : '';
            $finalAccountType = in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true) && $accountType ? $accountType : null;
            $finalUpiId = $paymentMode === 'upi' ? $upiId : null;

            $employeeStmt = $conn->prepare(
                "INSERT INTO employees
                 (emp_code, first_name, last_name, dob, gender, email, fathers_name,
                  local_address, permanent_address, contact_no, bank_id, bank_account_number,
                  bank_ifsc_code, bank_account_holder_name, bank_account_type, upi_id, pan_no,
                  date_of_join, status, company, designation_id, user_id, user_email,
                  is_login_allowed, created_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, NOW())"
            );
            $portalFlag = $portalAccess ? 1 : 0;
            $employeeStmt->bind_param(
                'ssssisssssisssisssiiisii',
                $employeeCode,
                $firstName,
                $lastName,
                $dob,
                $gender,
                $workEmail,
                $fatherName,
                $legacyResidentialAddress,
                $legacyResidentialAddress,
                $mobile,
                $finalBankId,
                $finalAccountNumber,
                $finalIfscCode,
                $holderName,
                $finalAccountType,
                $finalUpiId,
                $panNo,
                $dateOfJoin,
                $companyId,
                $designationId,
                $linkedUserId,
                $workEmail,
                $portalFlag,
                $userId
            );
            if (!$employeeStmt->execute()) {
                throw new RuntimeException('Unable to create the employee record.');
            }
            $employeeId = (int) $employeeStmt->insert_id;
            $employeeStmt->close();

            if ($linkedUserId > 0) {
                $unlinkOld = $conn->prepare('UPDATE employees SET user_id = NULL WHERE user_id = ? AND id != ?');
                $unlinkOld->bind_param('ii', $linkedUserId, $employeeId);
                $unlinkOld->execute();
                $unlinkOld->close();
            }

            $profileStmt = $conn->prepare(
                'INSERT INTO hr_employee_profiles (employee_id, company_id, branch_id, department_id, work_location, personal_email, differently_abled, portal_access, payment_mode, upi_id, annual_ctc, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            // The payment handle is text and the yearly cost is a number; the two
            // were declared the other way round, which turned any handle entered
            // into a nought.
            $profileStmt->bind_param('iiiissiissdi', $employeeId, $companyId, $branchId, $departmentId, $workLocation, $personalEmail, $differentlyAbled, $portalFlag, $paymentMode, $finalUpiId, $annualCtc, $userId);
            $profileStmt->execute();
            $profileStmt->close();
            if ($hasExtendedProfilePayload) {
                $profileDetailsStmt = $conn->prepare(
                    'UPDATE hr_employee_profiles SET middle_name = ?, is_director = ?, differently_abled_type = ?, address_line_1 = ?, address_line_2 = ?, city = ?, state = ?, postal_code = ? WHERE employee_id = ?'
                );
                $directorFlag = $isDirector ? 1 : 0;
                $profileDetailsStmt->bind_param('sissssssi', $middleName, $directorFlag, $differentlyAbledType, $residentialAddress, $addressLine2, $city, $state, $postalCode, $employeeId);
                $profileDetailsStmt->execute();
                $profileDetailsStmt->close();
            }
            if ($hasPfCategoryPayload) {
                $profilePfStmt = $conn->prepare('UPDATE hr_employee_profiles SET pf_category = ? WHERE employee_id = ?');
                $profilePfStmt->bind_param('si', $pfCategory, $employeeId);
                $profilePfStmt->execute();
                $profilePfStmt->close();
                $esicEnabled = hrmsCalculateEsicAmount((float) $annualCtc / 12) > 0 ? 1 : 0;
                $employeeStatutoryStmt = $conn->prepare('UPDATE employees SET is_pf_allowed = 1, is_esic_allowed = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $employeeStatutoryStmt->bind_param('iii', $esicEnabled, $userId, $employeeId);
                $employeeStatutoryStmt->execute();
                $employeeStatutoryStmt->close();
            }

            $componentStmt = $conn->prepare(
                'INSERT INTO hr_salary_components (employee_id, component_code, component_name, calculation_type, calculation_value, monthly_amount, annual_amount, is_deduction, sort_order, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            foreach ($normalizedComponents as $component) {
                $componentStmt->bind_param(
                    'isssdddiii',
                    $employeeId,
                    $component['code'],
                    $component['name'],
                    $component['calculation_type'],
                    $component['calculation_value'],
                    $component['monthly_amount'],
                    $component['annual_amount'],
                    $component['is_deduction'],
                    $component['sort_order'],
                    $userId
                );
                $componentStmt->execute();
            }
            $componentStmt->close();

            $monthly = static fn(string $code): float => isset($normalizedComponents[$code]) ? round((float) $normalizedComponents[$code]['monthly_amount'], 2) : 0.0;
            $basicSalary = $monthly('BASIC');
            $hra = $monthly('HRA');
            $conveyance = $monthly('CONVEYANCE');
            $medical = $monthly('MEDICAL');
            $special = $monthly('SPECIAL');
            $incentives = $monthly('INCENTIVE');
            $deductions = array_sum(array_map(static fn(array $component): float => $component['is_deduction'] ? (float) $component['monthly_amount'] : 0.0, $normalizedComponents));
            $baseSalaryPfEsi = $hasPfCategoryPayload ? hrmsPfCategoryBase($pfCategory) : $basicSalary;
            $salaryStmt = $conn->prepare(
                'INSERT INTO employee_salaries (employee_id, base_salary_pf_esi, basic_salary, hra, conveyance_allowance, medical_allowance, special_allowance, incentives, deductions, effective_from, status, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, NOW())'
            );
            $salaryStmt->bind_param('iddddddddsi', $employeeId, $baseSalaryPfEsi, $basicSalary, $hra, $conveyance, $medical, $special, $incentives, $deductions, $dateOfJoin, $userId);
            $salaryStmt->execute();
            $salaryId = (int) $salaryStmt->insert_id;
            $salaryStmt->close();
            if ($hasPfCategoryPayload) {
                $pfAmount = hrmsCalculatePfAmount($pfCategory);
                $esicAmount = hrmsCalculateEsicAmount((float) $annualCtc / 12);
                $salaryStatutoryStmt = $conn->prepare('UPDATE employee_salaries SET pf_category = ?, pf = ?, esi = ? WHERE id = ?');
                $salaryStatutoryStmt->bind_param('sddi', $pfCategory, $pfAmount, $esicAmount, $salaryId);
                $salaryStatutoryStmt->execute();
                $salaryStatutoryStmt->close();
            }

            if (isset($_FILES['resume'])) {
                $storedPath = hrmsStoreEmployeeDocument($conn, $employeeId, $_FILES['resume'], 'resume', $userId);
                if ($storedPath !== null) {
                    $storedFiles[] = $storedPath;
                }
            }
            $conn->commit();
            $storedFiles = [];
            $response = [
                'status' => 'success',
                'message' => 'Employee onboarded successfully.',
                'employee_id' => $employeeId,
                'employee_code' => $employeeCode,
            ];
            if ($temporaryPassword !== null) {
                $response['temporary_password'] = $temporaryPassword;
                $response['message'] .= ' Copy the one-time portal password now.';
            }
            hrmsJson($response);

        case 'link_employee_user':
            hrmsRequirePermission($conn, 'hrms_employee_master_manage');
            $empId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            $targetUserId = filter_var($_POST['user_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$empId || $empId <= 0) {
                throw new InvalidArgumentException('Invalid employee selected.');
            }
            if ($targetUserId && $targetUserId > 0) {
                $uCheck = $conn->prepare('SELECT id, email FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1');
                $uCheck->bind_param('i', $targetUserId);
                $uCheck->execute();
                $uRow = $uCheck->get_result()->fetch_assoc();
                $uCheck->close();
                if (!$uRow) {
                    throw new RuntimeException('User account not found.');
                }
                $userEmailVal = $uRow['email'];
                $upd = $conn->prepare('UPDATE employees SET user_id = ?, user_email = ?, is_login_allowed = 1, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $upd->bind_param('isii', $targetUserId, $userEmailVal, $userId, $empId);
                $upd->execute();
                $upd->close();
            } else {
                $upd = $conn->prepare('UPDATE employees SET user_id = NULL, is_login_allowed = 0, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $upd->bind_param('ii', $userId, $empId);
                $upd->execute();
                $upd->close();
            }
            hrmsJson(['status' => 'success', 'message' => 'Employee user account link updated successfully.']);

        case 'update_employee_section':
            hrmsRequirePermission($conn, 'hrms_employee_master_manage');
            $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            $section = trim((string) ($_POST['section'] ?? ''));
            if (!$employeeId || $employeeId <= 0) {
                throw new InvalidArgumentException('Invalid employee ID.');
            }

            $empCheck = $conn->prepare('SELECT id FROM employees WHERE id = ? AND deleted_at IS NULL LIMIT 1');
            $empCheck->bind_param('i', $employeeId);
            $empCheck->execute();
            $employeeExists = $empCheck->get_result()->fetch_assoc();
            $empCheck->close();
            if (!$employeeExists) {
                throw new RuntimeException('Employee record not found.');
            }

            $profCheck = $conn->prepare('SELECT employee_id FROM hr_employee_profiles WHERE employee_id = ? LIMIT 1');
            $profCheck->bind_param('i', $employeeId);
            $profCheck->execute();
            $hasProfile = $profCheck->get_result()->fetch_assoc();
            $profCheck->close();
            if (!$hasProfile) {
                $initProf = $conn->prepare('INSERT INTO hr_employee_profiles (employee_id, created_by, created_at) VALUES (?, ?, NOW())');
                $initProf->bind_param('ii', $employeeId, $userId);
                $initProf->execute();
                $initProf->close();
            }

            if ($section === 'contact') {
                $workEmail = strtolower(trim((string) ($_POST['work_email'] ?? '')));
                $personalEmail = strtolower(trim((string) ($_POST['personal_email'] ?? '')));
                $mobile = trim((string) ($_POST['mobile'] ?? ''));
                $residentialAddress = trim((string) ($_POST['residential_address'] ?? ''));
                $addressLine2 = trim((string) ($_POST['address_line_2'] ?? ''));
                $city = trim((string) ($_POST['city'] ?? ''));
                $state = trim((string) ($_POST['state'] ?? ''));
                $postalCode = strtoupper(trim((string) ($_POST['postal_code'] ?? '')));

                if ($workEmail !== '' && !filter_var($workEmail, FILTER_VALIDATE_EMAIL)) {
                    throw new InvalidArgumentException('Invalid work email address.');
                }
                if ($personalEmail !== '' && !filter_var($personalEmail, FILTER_VALIDATE_EMAIL)) {
                    throw new InvalidArgumentException('Invalid personal email address.');
                }

                $stmt1 = $conn->prepare('UPDATE employees SET email = ?, contact_no = ?, local_address = ?, permanent_address = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt1->bind_param('ssssii', $workEmail, $mobile, $residentialAddress, $residentialAddress, $userId, $employeeId);
                $stmt1->execute();
                $stmt1->close();

                $stmt2 = $conn->prepare('UPDATE hr_employee_profiles SET personal_email = ?, address_line_1 = ?, address_line_2 = ?, city = ?, state = ?, postal_code = ?, updated_by = ?, updated_at = NOW() WHERE employee_id = ?');
                $stmt2->bind_param('ssssssii', $personalEmail, $residentialAddress, $addressLine2, $city, $state, $postalCode, $userId, $employeeId);
                $stmt2->execute();
                $stmt2->close();

                hrmsJson(['status' => 'success', 'message' => 'Contact details updated successfully.']);
            } elseif ($section === 'personal') {
                $firstName = trim((string) ($_POST['first_name'] ?? ''));
                $lastName = trim((string) ($_POST['last_name'] ?? ''));
                $gender = filter_var($_POST['gender'] ?? null, FILTER_VALIDATE_INT);
                $dob = trim((string) ($_POST['dob'] ?? ''));
                $fatherName = trim((string) ($_POST['fathers_name'] ?? ''));
                $panNo = strtoupper(trim((string) ($_POST['pan_no'] ?? '')));
                $differentlyAbled = isset($_POST['differently_abled']) && (string) $_POST['differently_abled'] === '1' ? 1 : 0;
                $differentlyAbledType = $differentlyAbled ? trim((string) ($_POST['differently_abled_type'] ?? '')) : '';

                if ($firstName === '') {
                    throw new InvalidArgumentException('First name is required.');
                }

                $stmt1 = $conn->prepare('UPDATE employees SET first_name = ?, last_name = ?, gender = ?, dob = ?, fathers_name = ?, pan_no = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt1->bind_param('ssisssii', $firstName, $lastName, $gender, $dob, $fatherName, $panNo, $userId, $employeeId);
                $stmt1->execute();
                $stmt1->close();

                $stmt2 = $conn->prepare('UPDATE hr_employee_profiles SET differently_abled = ?, differently_abled_type = ?, updated_by = ?, updated_at = NOW() WHERE employee_id = ?');
                $stmt2->bind_param('isii', $differentlyAbled, $differentlyAbledType, $userId, $employeeId);
                $stmt2->execute();
                $stmt2->close();

                hrmsJson(['status' => 'success', 'message' => 'Personal details updated successfully.']);
            } elseif ($section === 'organization') {
                $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
                $branchId = filter_var($_POST['branch_id'] ?? null, FILTER_VALIDATE_INT);
                $departmentId = filter_var($_POST['department_id'] ?? null, FILTER_VALIDATE_INT);
                $designationId = filter_var($_POST['designation_id'] ?? null, FILTER_VALIDATE_INT);
                $workLocation = trim((string) ($_POST['work_location'] ?? ''));
                $dateOfJoin = trim((string) ($_POST['date_of_join'] ?? ''));
                $isDirector = isset($_POST['is_director']) && (string) $_POST['is_director'] === '1' ? 1 : 0;
                $status = filter_var($_POST['status'] ?? 1, FILTER_VALIDATE_INT);

                if (!$departmentId || !$designationId) {
                    throw new InvalidArgumentException('Department and Designation are required.');
                }

                $stmt1 = $conn->prepare('UPDATE employees SET designation_id = ?, date_of_join = ?, status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt1->bind_param('isiii', $designationId, $dateOfJoin, $status, $userId, $employeeId);
                $stmt1->execute();
                $stmt1->close();

                $stmt2 = $conn->prepare('UPDATE hr_employee_profiles SET company_id = ?, branch_id = ?, department_id = ?, work_location = ?, is_director = ?, updated_by = ?, updated_at = NOW() WHERE employee_id = ?');
                $stmt2->bind_param('iiisiii', $companyId, $branchId, $departmentId, $workLocation, $isDirector, $userId, $employeeId);
                $stmt2->execute();
                $stmt2->close();

                hrmsJson(['status' => 'success', 'message' => 'Employment and organization details updated successfully.']);
            } elseif ($section === 'banking') {
                $paymentMode = (string) ($_POST['payment_mode'] ?? 'bank_transfer');
                $allowedModes = ['direct_deposit', 'bank_transfer', 'upi', 'cheque', 'cash'];
                if (!in_array($paymentMode, $allowedModes, true)) {
                    $paymentMode = 'bank_transfer';
                }

                $bankId = filter_var($_POST['bank_id'] ?? null, FILTER_VALIDATE_INT);
                $holderName = trim((string) ($_POST['bank_account_holder_name'] ?? ''));
                $accountNumber = trim((string) ($_POST['bank_account_number'] ?? ''));
                $ifscCode = strtoupper(trim((string) ($_POST['bank_ifsc_code'] ?? '')));
                $accountType = filter_var($_POST['bank_account_type'] ?? null, FILTER_VALIDATE_INT);
                $upiId = trim((string) ($_POST['upi_id'] ?? ''));

                if ($paymentMode === 'upi') {
                    if ($upiId === '') {
                        throw new InvalidArgumentException('Enter a valid UPI ID.');
                    }
                } elseif (in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true)) {
                    if (!$bankId || $holderName === '' || $accountNumber === '' || $ifscCode === '') {
                        throw new InvalidArgumentException('Complete all required bank account details.');
                    }
                }

                $finalBankId = in_array($paymentMode, ['direct_deposit', 'bank_transfer', 'cheque'], true) && $bankId ? $bankId : null;
                $finalAccountNumber = in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true) ? $accountNumber : '';
                $finalIfscCode = in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true) ? $ifscCode : '';
                $finalAccountType = in_array($paymentMode, ['direct_deposit', 'bank_transfer'], true) && $accountType ? $accountType : null;
                $finalUpiId = $paymentMode === 'upi' ? $upiId : null;

                $stmt1 = $conn->prepare('UPDATE employees SET bank_id = ?, bank_account_holder_name = ?, bank_account_number = ?, bank_ifsc_code = ?, bank_account_type = ?, upi_id = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt1->bind_param('isssisii', $finalBankId, $holderName, $finalAccountNumber, $finalIfscCode, $finalAccountType, $finalUpiId, $userId, $employeeId);
                $stmt1->execute();
                $stmt1->close();

                $stmt2 = $conn->prepare('UPDATE hr_employee_profiles SET payment_mode = ?, upi_id = ?, updated_by = ?, updated_at = NOW() WHERE employee_id = ?');
                $stmt2->bind_param('ssii', $paymentMode, $finalUpiId, $userId, $employeeId);
                $stmt2->execute();
                $stmt2->close();

                hrmsJson(['status' => 'success', 'message' => 'Banking and payment details updated successfully.']);
            } else {
                throw new InvalidArgumentException('Unknown profile section.');
            }

        case 'save_employee_compensation':
            hrmsRequirePermission($conn, 'hrms_employee_master_manage');
            $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            $annualCtc = filter_var($_POST['annual_ctc'] ?? null, FILTER_VALIDATE_FLOAT);
            if (($annualCtc === false || $annualCtc <= 0) && isset($_POST['monthly_gross_salary'])) {
                $monthlyGross = filter_var($_POST['monthly_gross_salary'], FILTER_VALIDATE_FLOAT);
                if ($monthlyGross !== false && $monthlyGross > 0) {
                    $annualCtc = round($monthlyGross * 12, 2);
                }
            }
            $effectiveFrom = trim((string) ($_POST['effective_from'] ?? date('Y-m-d')));
            $hasPfCategoryPayload = array_key_exists('pf_category', $_POST);
            $pfCategory = strtolower(trim((string) ($_POST['pf_category'] ?? '')));
            $hasCustomComponentsPayload = array_key_exists('custom_salary_components', $_POST);
            $customComponentsJson = (string) ($_POST['custom_salary_components'] ?? '[]');
            $componentFields = [
                'BASIC' => ['Basic Salary', 'basic_salary'],
                'HRA' => ['House Rent Allowance', 'hra'],
                'CONVEYANCE' => ['Conveyance Allowance', 'conveyance_allowance'],
                'MEDICAL' => ['Medical Allowance', 'medical_allowance'],
                'SPECIAL' => ['Special Allowance', 'special_allowance'],
                'INCENTIVE' => ['Incentives', 'incentives'],
            ];
            if (!$employeeId || $annualCtc === false || $annualCtc <= 0) {
                throw new InvalidArgumentException('Select an employee and enter a valid annual CTC.');
            }
            $profilePfColumn = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'pf_category'");
            $salaryPfColumn = $conn->query("SHOW COLUMNS FROM employee_salaries LIKE 'pf_category'");
            $statutorySchemaReady = $profilePfColumn && $profilePfColumn->num_rows === 1
                && $salaryPfColumn && $salaryPfColumn->num_rows === 1;
            if ($statutorySchemaReady && !in_array($pfCategory, ['e', 'w', 'ew'], true)) {
                throw new InvalidArgumentException('Select Employee, Worker or Employee / Worker as the PF category.');
            }
            $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $effectiveFrom);
            if (!$dateObject || $dateObject->format('Y-m-d') !== $effectiveFrom) {
                throw new InvalidArgumentException('Select a valid salary effective date.');
            }
            $monthlyComponents = [];
            foreach ($componentFields as $code => [$name, $field]) {
                $amount = filter_var($_POST[$field] ?? 0, FILTER_VALIDATE_FLOAT);
                if ($amount === false || $amount < 0 || $amount > 9999999999.99) {
                    throw new InvalidArgumentException("Enter a valid {$name} amount.");
                }
                $monthlyComponents[$code] = ['name' => $name, 'amount' => (float) $amount];
            }
            if ($monthlyComponents['BASIC']['amount'] <= 0) {
                throw new InvalidArgumentException('Basic salary must be greater than zero.');
            }
            $customComponentRows = json_decode($customComponentsJson, true);
            if (!is_array($customComponentRows) || count($customComponentRows) > 50) {
                throw new InvalidArgumentException('The additional salary components are invalid.');
            }
            $customComponents = [];
            foreach ($customComponentRows as $index => $component) {
                $name = trim((string) ($component['name'] ?? $component['component_name'] ?? ''));
                $code = strtoupper(preg_replace('/[^A-Z0-9_]/', '', (string) ($component['code'] ?? $component['component_code'] ?? '')));
                if ($code === '' && $name !== '') {
                    $slug = strtoupper(preg_replace('/[^A-Z0-9_]/', '', str_replace(' ', '_', $name)));
                    $code = $slug !== '' ? substr($slug, 0, 30) : ('ADDL_' . ($index + 1));
                }
                if ($code !== '' && isset($componentFields[$code])) {
                    $code = 'ADDL_' . $code;
                }
                if (isset($customComponents[$code])) {
                    $code = $code . '_' . ($index + 1);
                }
                $monthlyAmount = filter_var($component['monthly_amount'] ?? null, FILTER_VALIDATE_FLOAT);
                if ($code === '' || $name === '' || mb_strlen($name) > 120 || $monthlyAmount === false || $monthlyAmount < 0 || $monthlyAmount > 9999999999.99) {
                    throw new InvalidArgumentException('One or more additional salary components are invalid.');
                }
                $calcType = in_array($component['calculation_type'] ?? '', ['fixed', 'basic_percentage', 'gross_percentage', 'ctc_percentage'], true) ? $component['calculation_type'] : 'fixed';
                $calcValue = filter_var($component['calculation_value'] ?? $monthlyAmount, FILTER_VALIDATE_FLOAT);
                if ($calcValue === false || $calcValue < 0) {
                    $calcValue = (float) $monthlyAmount;
                }

                $customComponents[$code] = [
                    'name' => $name,
                    'amount' => (float) $monthlyAmount,
                    'calculation_type' => $calcType,
                    'calculation_value' => (float) $calcValue,
                    'is_deduction' => !empty($component['is_deduction']) ? 1 : 0,
                    'sort_order' => count($componentFields) + $index,
                ];
            }
            $monthlyEarningTotal = array_sum(array_column($monthlyComponents, 'amount'))
                + array_sum(array_map(static fn(array $component): float => $component['is_deduction'] ? 0.0 : $component['amount'], $customComponents));
            if (abs($monthlyEarningTotal - ((float) $annualCtc / 12)) > 1.00) {
                throw new InvalidArgumentException('Monthly earning heads must equal the Annual CTC divided by 12.');
            }
            if ($hasPfCategoryPayload) {
                if (!$statutorySchemaReady) {
                    throw new RuntimeException('Apply the Salary Statutory Rules migration before selecting a PF category.');
                }
            }
            $conn->begin_transaction();
            $employee = hrmsEmployeeById($conn, (int) $employeeId, true);
            if (!$employee) {
                throw new RuntimeException('Employee not found.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $employee);
            $profileStmt = $conn->prepare(
                'INSERT INTO hr_employee_profiles (employee_id, company_id, branch_id, annual_ctc, created_by) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE annual_ctc=VALUES(annual_ctc), updated_by=VALUES(created_by), updated_at=NOW()'
            );
            $companyId = !empty($employee['company_id']) ? (int) $employee['company_id'] : null;
            $branchId = !empty($employee['branch_id']) ? (int) $employee['branch_id'] : null;
            $profileStmt->bind_param('iiidi', $employeeId, $companyId, $branchId, $annualCtc, $userId);
            $profileStmt->execute();
            $profileStmt->close();
            if ($hasPfCategoryPayload) {
                $profilePfStmt = $conn->prepare('UPDATE hr_employee_profiles SET pf_category = ? WHERE employee_id = ?');
                $profilePfStmt->bind_param('si', $pfCategory, $employeeId);
                $profilePfStmt->execute();
                $profilePfStmt->close();
                $esicEnabled = hrmsCalculateEsicAmount((float) $annualCtc / 12) > 0 ? 1 : 0;
                $employeeStatutoryStmt = $conn->prepare('UPDATE employees SET is_pf_allowed = 1, is_esic_allowed = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $employeeStatutoryStmt->bind_param('iii', $esicEnabled, $userId, $employeeId);
                $employeeStatutoryStmt->execute();
                $employeeStatutoryStmt->close();
            }
            $closeDate = (new DateTimeImmutable($effectiveFrom))->modify('-1 day')->format('Y-m-d');
            $closeStmt = $conn->prepare('UPDATE employee_salaries SET status=0, effective_to=?, updated_by=?, updated_at=NOW() WHERE employee_id=? AND status=1 AND deleted_at IS NULL');
            $closeStmt->bind_param('sii', $closeDate, $userId, $employeeId);
            $closeStmt->execute();
            $closeStmt->close();
            $basic = $monthlyComponents['BASIC']['amount'];
            $hra = $monthlyComponents['HRA']['amount'];
            $conveyance = $monthlyComponents['CONVEYANCE']['amount'];
            $medical = $monthlyComponents['MEDICAL']['amount'];
            $special = $monthlyComponents['SPECIAL']['amount'];
            $incentive = $monthlyComponents['INCENTIVE']['amount'];
            $deductions = array_sum(array_map(static fn(array $component): float => $component['is_deduction'] ? $component['amount'] : 0.0, $customComponents));
            $baseSalaryPfEsi = $hasPfCategoryPayload ? hrmsPfCategoryBase($pfCategory) : $basic;
            $salaryStmt = $conn->prepare('INSERT INTO employee_salaries (employee_id,base_salary_pf_esi,basic_salary,hra,conveyance_allowance,medical_allowance,special_allowance,incentives,deductions,effective_from,status,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,1,?,NOW())');
            $salaryStmt->bind_param('iddddddddsi', $employeeId, $baseSalaryPfEsi, $basic, $hra, $conveyance, $medical, $special, $incentive, $deductions, $effectiveFrom, $userId);
            $salaryStmt->execute();
            $salaryId = (int) $salaryStmt->insert_id;
            $salaryStmt->close();
            if ($hasPfCategoryPayload) {
                $pfAmount = hrmsCalculatePfAmount($pfCategory);
                $esicAmount = hrmsCalculateEsicAmount((float) $annualCtc / 12);
                $salaryStatutoryStmt = $conn->prepare('UPDATE employee_salaries SET pf_category = ?, pf = ?, esi = ? WHERE id = ?');
                $salaryStatutoryStmt->bind_param('sddi', $pfCategory, $pfAmount, $esicAmount, $salaryId);
                $salaryStatutoryStmt->execute();
                $salaryStatutoryStmt->close();
            }
            $componentStmt = $conn->prepare("INSERT INTO hr_salary_components (employee_id,component_code,component_name,calculation_type,calculation_value,monthly_amount,annual_amount,is_deduction,sort_order,status,created_by) VALUES (?,?,?,'fixed',?,?,?,0,?,1,?) ON DUPLICATE KEY UPDATE component_name=VALUES(component_name),calculation_type='fixed',calculation_value=VALUES(calculation_value),monthly_amount=VALUES(monthly_amount),annual_amount=VALUES(annual_amount),is_deduction=0,sort_order=VALUES(sort_order),status=1,updated_by=VALUES(created_by),updated_at=NOW()");
            $sortOrder = 0;
            foreach ($monthlyComponents as $code => $component) {
                $name = $component['name'];
                $monthlyAmount = $component['amount'];
                $annualAmount = $monthlyAmount * 12;
                $componentStmt->bind_param('issdddii', $employeeId, $code, $name, $monthlyAmount, $monthlyAmount, $annualAmount, $sortOrder, $userId);
                $componentStmt->execute();
                $sortOrder++;
            }
            $componentStmt->close();
            $customComponentStmt = $conn->prepare("INSERT INTO hr_salary_components (employee_id,component_code,component_name,calculation_type,calculation_value,monthly_amount,annual_amount,is_deduction,sort_order,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,1,?) ON DUPLICATE KEY UPDATE component_name=VALUES(component_name),calculation_type=VALUES(calculation_type),calculation_value=VALUES(calculation_value),monthly_amount=VALUES(monthly_amount),annual_amount=VALUES(annual_amount),is_deduction=VALUES(is_deduction),sort_order=VALUES(sort_order),status=1,updated_by=VALUES(created_by),updated_at=NOW()");
            foreach ($customComponents as $code => $component) {
                $name = $component['name'];
                $monthlyAmount = $component['amount'];
                $annualAmount = $monthlyAmount * 12;
                $calcType = $component['calculation_type'];
                $calcValue = $component['calculation_value'];
                $isDeduction = $component['is_deduction'];
                $sortOrder = $component['sort_order'];
                $customComponentStmt->bind_param('isssdddiii', $employeeId, $code, $name, $calcType, $calcValue, $monthlyAmount, $annualAmount, $isDeduction, $sortOrder, $userId);
                $customComponentStmt->execute();
            }
            $customComponentStmt->close();
            if ($hasCustomComponentsPayload) {
                $activeComponentCodes = array_merge(array_keys($monthlyComponents), array_keys($customComponents));
                $codePlaceholders = implode(',', array_fill(0, count($activeComponentCodes), '?'));
                $deactivateStmt = $conn->prepare("UPDATE hr_salary_components SET status = 0, updated_by = ?, updated_at = NOW() WHERE employee_id = ? AND component_code NOT IN ({$codePlaceholders})");
                $deactivateTypes = 'ii' . str_repeat('s', count($activeComponentCodes));
                $deactivateParams = array_merge([$userId, $employeeId], $activeComponentCodes);
                $deactivateStmt->bind_param($deactivateTypes, ...$deactivateParams);
                $deactivateStmt->execute();
                $deactivateStmt->close();
            }
            $conn->commit();
            hrmsJson(['status' => 'success', 'message' => 'Employee compensation setup updated successfully.']);

        case 'submit_resignation':
            $employee = hrmsCurrentEmployee($conn, $userId);
            if (!$employee) {
                throw new RuntimeException('Your login is not linked to an employee record.');
            }
            $reason = trim((string) ($_POST['reason'] ?? ''));
            $resignationDate = (string) ($_POST['resignation_date'] ?? date('Y-m-d'));
            if (mb_strlen($reason) < 10 || mb_strlen($reason) > 4000) {
                throw new InvalidArgumentException('Enter a resignation reason between 10 and 4000 characters.');
            }
            $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $resignationDate);
            if (!$dateObject || $dateObject->format('Y-m-d') !== $resignationDate) {
                throw new InvalidArgumentException('Select a valid resignation date.');
            }

            $companyId = !empty($employee['company_id']) ? (int) $employee['company_id'] : null;
            $branchId = !empty($employee['branch_id']) ? (int) $employee['branch_id'] : null;
            $settingsSql = 'SELECT * FROM hr_offboarding_settings WHERE company_id = ? AND status = 1 AND (branch_id = ? OR branch_id IS NULL) ORDER BY branch_id IS NULL ASC LIMIT 1';
            $settings = null;
            if ($companyId !== null) {
                $settingsStmt = $conn->prepare($settingsSql);
                $settingsStmt->bind_param('ii', $companyId, $branchId);
                $settingsStmt->execute();
                $settings = $settingsStmt->get_result()->fetch_assoc() ?: null;
                $settingsStmt->close();
            }
            $noticeDays = (int) ($settings['notice_period_days'] ?? $employee['notice_period_days'] ?? 30);
            $requestedLastWorkingDate = $dateObject->modify('+' . max(0, $noticeDays) . ' days')->format('Y-m-d');

            $conn->begin_transaction();
            $duplicate = $conn->prepare(
                "SELECT id FROM hr_resignation_requests WHERE employee_id = ? AND status IN ('pending','approved','exit_interview_pending') LIMIT 1 FOR UPDATE"
            );
            $employeeId = (int) $employee['id'];
            $duplicate->bind_param('i', $employeeId);
            $duplicate->execute();
            $existing = $duplicate->get_result()->fetch_assoc();
            $duplicate->close();
            if ($existing) {
                throw new RuntimeException('An active resignation request already exists.');
            }
            $requestNo = hrmsReference('RES');
            $insert = $conn->prepare(
                "INSERT INTO hr_resignation_requests
                 (request_no, employee_id, company_id, branch_id, resignation_date,
                  requested_last_working_date, reason, status, submitted_at, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), ?)"
            );
            $insert->bind_param('siiisssi', $requestNo, $employeeId, $companyId, $branchId, $resignationDate, $requestedLastWorkingDate, $reason, $userId);
            $insert->execute();
            $requestId = (int) $insert->insert_id;
            $insert->close();

            $answers = json_decode((string) ($_POST['answers'] ?? '{}'), true);
            if (is_array($answers) && $answers !== []) {
                $answerStmt = $conn->prepare(
                    'INSERT INTO hr_exit_interview_answers (resignation_request_id, question_id, answer_text, submitted_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE answer_text = VALUES(answer_text), submitted_by = VALUES(submitted_by), submitted_at = NOW()'
                );
                foreach ($answers as $qId => $ansVal) {
                    $questionId = (int) $qId;
                    $answerText = is_array($ansVal) ? json_encode(array_values($ansVal), JSON_UNESCAPED_UNICODE) : trim((string) $ansVal);
                    if ($questionId > 0 && $answerText !== '') {
                        $answerStmt->bind_param('iisi', $requestId, $questionId, $answerText, $userId);
                        $answerStmt->execute();
                    }
                }
                $answerStmt->close();
            }

            $conn->commit();

            $managerIds = hrmsManagerUserIds($conn, 'hrms_offboarding_manage', $companyId, $branchId);
            hrmsNotify(
                $conn,
                '91',
                'hr_resignation_requests',
                $requestId,
                'New resignation request',
                trim($employee['first_name'] . ' ' . $employee['last_name']) . " submitted resignation request {$requestNo}.",
                $userId,
                $managerIds
            );
            $thankYouMessage = trim((string) ($settings['thank_you_message'] ?? 'Thank you for your feedback. Your resignation request has been submitted to HR.'));
            hrmsJson([
                'status' => 'success',
                'message' => 'Resignation request submitted successfully.',
                'request_no' => $requestNo,
                'thank_you_message' => $thankYouMessage
            ]);

        case 'review_resignation':
            hrmsRequirePermission($conn, 'hrms_offboarding_manage');
            $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT);
            $decision = (string) ($_POST['decision'] ?? '');
            $note = trim((string) ($_POST['note'] ?? ''));
            $approvedLastWorkingDate = trim((string) ($_POST['approved_last_working_date'] ?? ''));
            if (!$requestId || !in_array($decision, ['approved', 'rejected'], true)) {
                throw new InvalidArgumentException('Select a valid resignation request and decision.');
            }
            if ($decision === 'rejected' && mb_strlen($note) < 3) {
                throw new InvalidArgumentException('Enter a rejection reason.');
            }

            $conn->begin_transaction();
            $stmt = $conn->prepare(
                'SELECT request.*, employee.user_id FROM hr_resignation_requests request INNER JOIN employees employee ON employee.id = request.employee_id WHERE request.id = ? FOR UPDATE'
            );
            $stmt->bind_param('i', $requestId);
            $stmt->execute();
            $request = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$request || $request['status'] !== 'pending') {
                throw new RuntimeException('This resignation request is no longer pending.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $request);
                        $approverStmt = $conn->prepare(
                                "SELECT settings.approver_user_id
                                 FROM hr_offboarding_settings settings
                                 WHERE settings.company_id = ? AND settings.status = 1
                                     AND (settings.branch_id = ? OR settings.branch_id IS NULL)
                                 ORDER BY settings.branch_id IS NULL ASC LIMIT 1"
                        );
                        $requestCompanyId = (int) ($request['company_id'] ?? 0);
                        $requestBranchId = !empty($request['branch_id']) ? (int) $request['branch_id'] : null;
                        $approverStmt->bind_param('ii', $requestCompanyId, $requestBranchId);
                        $approverStmt->execute();
                        $approverSettings = $approverStmt->get_result()->fetch_assoc() ?: [];
                        $approverStmt->close();
                        $configuredApproverId = (int) ($approverSettings['approver_user_id'] ?? 0);
                        $authorizedApproverIds = hrmsManagerUserIds($conn, 'hrms_offboarding_manage', $requestCompanyId, $requestBranchId);
                        if ($configuredApproverId > 0 && in_array($configuredApproverId, $authorizedApproverIds, true) && $configuredApproverId !== $userId) {
                                $conn->rollback();
                                hrmsJson(['status' => 'error', 'message' => 'This resignation is assigned to the configured approver.'], 403);
                        }
            if ($decision === 'approved') {
                if ($approvedLastWorkingDate === '') {
                    $approvedLastWorkingDate = (string) $request['requested_last_working_date'];
                }
                $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $approvedLastWorkingDate);
                if (!$dateObject || $dateObject->format('Y-m-d') !== $approvedLastWorkingDate || $approvedLastWorkingDate < $request['resignation_date']) {
                    throw new InvalidArgumentException('Select a valid approved last working date.');
                }
                $nextStatus = 'exit_interview_pending';
            } else {
                $approvedLastWorkingDate = null;
                $nextStatus = 'rejected';
            }
            $update = $conn->prepare(
                'UPDATE hr_resignation_requests SET status = ?, approved_last_working_date = ?, action_by = ?, action_at = NOW(), action_note = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND status = \'pending\''
            );
            $update->bind_param('ssisii', $nextStatus, $approvedLastWorkingDate, $userId, $note, $userId, $requestId);
            $update->execute();
            $update->close();
            if ($decision === 'approved') {
                $employeeUpdate = $conn->prepare(
                    'UPDATE employees SET date_of_resign = ?, is_resign_approved = 1, resign_approved_by = ?, resign_approved_date = NOW(), last_working_date = ?, updated_by = ?, updated_at = NOW() WHERE id = ?'
                );
                $employeeUpdate->bind_param('sisii', $request['resignation_date'], $userId, $approvedLastWorkingDate, $userId, $request['employee_id']);
                $employeeUpdate->execute();
                $employeeUpdate->close();

                $settingsStmt = $conn->prepare(
                    'SELECT * FROM hr_offboarding_settings WHERE company_id = ? AND status = 1 AND (branch_id = ? OR branch_id IS NULL) ORDER BY branch_id IS NULL ASC LIMIT 1'
                );
                $settingsStmt->bind_param('ii', $request['company_id'], $request['branch_id']);
                $settingsStmt->execute();
                $settings = $settingsStmt->get_result()->fetch_assoc() ?: [];
                $settingsStmt->close();
                $documentStmt = $conn->prepare(
                    "INSERT IGNORE INTO hr_offboarding_documents (resignation_request_id, document_type, status) VALUES (?, ?, 'pending')"
                );
                foreach (['experience_letter' => 'send_experience_letter', 'relieving_letter' => 'send_relieving_letter'] as $documentType => $settingKey) {
                    if ((int) ($settings[$settingKey] ?? 1) === 1) {
                        $documentStmt->bind_param('is', $requestId, $documentType);
                        $documentStmt->execute();
                    }
                }
                $documentStmt->close();
            }
            $conn->commit();

            if ($decision === 'approved') {
                try {
                    hrmsGenerateOffboardingDocuments($conn, $requestId, $userId);
                    hrmsSendOffboardingDocuments($conn, $requestId);
                } catch (Throwable $documentException) {
                    error_log('Approved offboarding document delivery failed: ' . $documentException->getMessage());
                }
            }

            if (!empty($request['user_id'])) {
                hrmsNotify(
                    $conn,
                    '91',
                    'hr_resignation_requests',
                    $requestId,
                    'Resignation request ' . $decision,
                    'Your resignation request ' . $request['request_no'] . ' was ' . $decision . '.',
                    $userId,
                    [(int) $request['user_id']]
                );
            }
            hrmsJson(['status' => 'success', 'message' => 'Resignation request ' . $decision . ' successfully.']);

        case 'save_offboarding_settings':
            hrmsRequirePermission($conn, 'hrms_offboarding_manage');
            $scope = hrmsCurrentScope($conn, $userId);
            $companyId = filter_var($_POST['company_id'] ?? $scope['company_id'], FILTER_VALIDATE_INT);
            $branchId = !empty($_POST['branch_id']) && (int) $_POST['branch_id'] > 0 ? (int) $_POST['branch_id'] : null;
            $noticePeriodDays = filter_var($_POST['notice_period_days'] ?? null, FILTER_VALIDATE_INT);
            $approverUserId = !empty($_POST['approver_user_id']) && (int) $_POST['approver_user_id'] > 0 ? (int) $_POST['approver_user_id'] : null;
            $hrPartnerUserId = !empty($_POST['hr_partner_user_id']) && (int) $_POST['hr_partner_user_id'] > 0 ? (int) $_POST['hr_partner_user_id'] : null;
            $interviewIntro = trim((string) ($_POST['interview_intro'] ?? ''));
            $thankYouMessage = trim((string) ($_POST['thank_you_message'] ?? ''));
            $sendExperienceLetter = isset($_POST['send_experience_letter']) ? 1 : 0;
            $sendRelievingLetter = isset($_POST['send_relieving_letter']) ? 1 : 0;
            if (!$companyId || !$noticePeriodDays || $noticePeriodDays < 0 || $noticePeriodDays > 365) {
                throw new InvalidArgumentException('Select an organization and enter a notice period between 0 and 365 days.');
            }
            if ($scope['company_id'] !== null && $scope['company_id'] !== (int) $companyId) {
                throw new RuntimeException('You cannot update another organization.');
            }
            if ($scope['branch_id'] !== null && (int) $branchId !== $scope['branch_id']) {
                throw new RuntimeException('You cannot update another branch.');
            }
            $findSql = 'SELECT id FROM hr_offboarding_settings WHERE company_id = ? AND ' . ($branchId ? 'branch_id = ?' : 'branch_id IS NULL') . ' LIMIT 1';
            $find = $conn->prepare($findSql);
            if ($branchId) {
                $find->bind_param('ii', $companyId, $branchId);
            } else {
                $find->bind_param('i', $companyId);
            }
            $find->execute();
            $existing = $find->get_result()->fetch_assoc();
            $find->close();
            if ($existing) {
                $settingsId = (int) $existing['id'];
                $stmt = $conn->prepare(
                    'UPDATE hr_offboarding_settings SET notice_period_days = ?, approver_user_id = ?, hr_partner_user_id = ?, interview_intro = ?, thank_you_message = ?, send_experience_letter = ?, send_relieving_letter = ?, status = 1, updated_by = ?, updated_at = NOW() WHERE id = ?'
                );
                $stmt->bind_param('iiissiiii', $noticePeriodDays, $approverUserId, $hrPartnerUserId, $interviewIntro, $thankYouMessage, $sendExperienceLetter, $sendRelievingLetter, $userId, $settingsId);
            } else {
                $stmt = $conn->prepare(
                    'INSERT INTO hr_offboarding_settings (company_id, branch_id, notice_period_days, approver_user_id, hr_partner_user_id, interview_intro, thank_you_message, send_experience_letter, send_relieving_letter, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)'
                );
                $stmt->bind_param('iiiiissiii', $companyId, $branchId, $noticePeriodDays, $approverUserId, $hrPartnerUserId, $interviewIntro, $thankYouMessage, $sendExperienceLetter, $sendRelievingLetter, $userId);
            }
            $stmt->execute();
            $settingsId = $settingsId ?? (int) $stmt->insert_id;
            $stmt->close();
            hrmsJson(['status' => 'success', 'message' => 'Offboarding preferences saved successfully.', 'settings_id' => $settingsId]);

        case 'save_exit_question':
            hrmsRequirePermission($conn, 'hrms_offboarding_manage');
            $questionId = filter_var($_POST['question_id'] ?? null, FILTER_VALIDATE_INT);
            $settingsId = filter_var($_POST['settings_id'] ?? null, FILTER_VALIDATE_INT);
            $questionText = trim((string) ($_POST['question_text'] ?? ''));
            $questionType = (string) ($_POST['question_type'] ?? 'long_text');
            $optionsText = trim((string) ($_POST['options'] ?? ''));
            $isRequired = isset($_POST['is_required']) ? 1 : 0;
            $allowedTypes = ['short_text', 'long_text', 'single_choice', 'multiple_choice', 'rating'];
            if (!$settingsId || mb_strlen($questionText) < 3 || mb_strlen($questionText) > 1000 || !in_array($questionType, $allowedTypes, true)) {
                throw new InvalidArgumentException('Enter a valid exit interview question and type.');
            }
            $settingsStmt = $conn->prepare('SELECT company_id, branch_id FROM hr_offboarding_settings WHERE id = ? AND status = 1 LIMIT 1');
            $settingsStmt->bind_param('i', $settingsId);
            $settingsStmt->execute();
            $settings = $settingsStmt->get_result()->fetch_assoc();
            $settingsStmt->close();
            if (!$settings) {
                throw new RuntimeException('Save the offboarding preferences before adding questions.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $settings);
            $options = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $optionsText))));
            if (in_array($questionType, ['single_choice', 'multiple_choice'], true) && count($options) < 2) {
                throw new InvalidArgumentException('Choice questions require at least two options.');
            }
            $optionsJson = $options ? json_encode($options, JSON_UNESCAPED_UNICODE) : null;
            if ($questionId) {
                $stmt = $conn->prepare(
                    'UPDATE hr_exit_interview_questions SET question_text = ?, question_type = ?, options_json = ?, is_required = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND settings_id = ? AND status = 1'
                );
                $stmt->bind_param('sssiiii', $questionText, $questionType, $optionsJson, $isRequired, $userId, $questionId, $settingsId);
            } else {
                $orderResult = $conn->query('SELECT COALESCE(MAX(sort_order), 0) + 1 AS next_order FROM hr_exit_interview_questions WHERE settings_id = ' . (int) $settingsId);
                $sortOrder = (int) ($orderResult->fetch_assoc()['next_order'] ?? 1);
                $stmt = $conn->prepare(
                    'INSERT INTO hr_exit_interview_questions (settings_id, question_text, question_type, options_json, is_required, sort_order, status, created_by) VALUES (?, ?, ?, ?, ?, ?, 1, ?)'
                );
                $stmt->bind_param('isssiii', $settingsId, $questionText, $questionType, $optionsJson, $isRequired, $sortOrder, $userId);
            }
            $stmt->execute();
            $stmt->close();
            hrmsJson(['status' => 'success', 'message' => 'Exit interview question saved successfully.']);

        case 'delete_exit_question':
            hrmsRequirePermission($conn, 'hrms_offboarding_manage');
            $questionId = filter_var($_POST['question_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$questionId) {
                throw new InvalidArgumentException('Select a valid exit interview question.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            $stmt = $conn->prepare(
                'UPDATE hr_exit_interview_questions question INNER JOIN hr_offboarding_settings settings ON settings.id = question.settings_id SET question.status = 0, question.updated_by = ?, question.updated_at = NOW() WHERE question.id = ? AND (? IS NULL OR settings.company_id = ?) AND (? IS NULL OR settings.branch_id = ?)'
            );
            $stmt->bind_param('iiiiii', $userId, $questionId, $scope['company_id'], $scope['company_id'], $scope['branch_id'], $scope['branch_id']);
            $stmt->execute();
            if ($stmt->affected_rows !== 1) {
                throw new RuntimeException('Question not found or access denied.');
            }
            $stmt->close();
            hrmsJson(['status' => 'success', 'message' => 'Exit interview question removed.']);

        case 'reorder_exit_questions':
            hrmsRequirePermission($conn, 'hrms_offboarding_manage');
            $settingsId = filter_var($_POST['settings_id'] ?? null, FILTER_VALIDATE_INT);
            $questionIds = json_decode((string) ($_POST['question_ids'] ?? '[]'), true);
            if (!$settingsId || !is_array($questionIds) || $questionIds === []) {
                throw new InvalidArgumentException('Invalid question order.');
            }
            $settingsStmt = $conn->prepare('SELECT company_id, branch_id FROM hr_offboarding_settings WHERE id = ? LIMIT 1');
            $settingsStmt->bind_param('i', $settingsId);
            $settingsStmt->execute();
            $settings = $settingsStmt->get_result()->fetch_assoc();
            $settingsStmt->close();
            if (!$settings) {
                throw new RuntimeException('Offboarding preferences not found.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $settings);
            $conn->begin_transaction();
            $stmt = $conn->prepare('UPDATE hr_exit_interview_questions SET sort_order = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND settings_id = ? AND status = 1');
            foreach (array_values(array_unique(array_map('intval', $questionIds))) as $index => $id) {
                $sortOrder = $index + 1;
                $stmt->bind_param('iiii', $sortOrder, $userId, $id, $settingsId);
                $stmt->execute();
            }
            $stmt->close();
            $conn->commit();
            hrmsJson(['status' => 'success', 'message' => 'Question order saved.']);

        case 'submit_exit_interview':
            $employee = hrmsCurrentEmployee($conn, $userId);
            $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT);
            $answers = json_decode((string) ($_POST['answers'] ?? '{}'), true);
            if (!$employee || !$requestId || !is_array($answers)) {
                throw new InvalidArgumentException('Invalid exit interview submission.');
            }
            $conn->begin_transaction();
            $requestStmt = $conn->prepare(
                "SELECT request.*, settings.id AS settings_id, settings.thank_you_message
                 FROM hr_resignation_requests request
                 LEFT JOIN hr_offboarding_settings settings
                   ON settings.company_id = request.company_id AND settings.status = 1
                  AND (settings.branch_id = request.branch_id OR settings.branch_id IS NULL)
                 WHERE request.id = ? AND request.employee_id = ? AND request.status = 'exit_interview_pending'
                 ORDER BY settings.branch_id IS NULL ASC LIMIT 1 FOR UPDATE"
            );
            $employeeId = (int) $employee['id'];
            $requestStmt->bind_param('ii', $requestId, $employeeId);
            $requestStmt->execute();
            $request = $requestStmt->get_result()->fetch_assoc();
            $requestStmt->close();
            if (!$request) {
                throw new RuntimeException('No exit interview is currently available.');
            }
            if (!empty($request['settings_id'])) {
                $questionStmt = $conn->prepare('SELECT id, is_required FROM hr_exit_interview_questions WHERE settings_id = ? AND status = 1 ORDER BY sort_order, id');
                $questionStmt->bind_param('i', $request['settings_id']);
                $questionStmt->execute();
                $questions = $questionStmt->get_result()->fetch_all(MYSQLI_ASSOC);
                $questionStmt->close();
                $answerStmt = $conn->prepare(
                    'INSERT INTO hr_exit_interview_answers (resignation_request_id, question_id, answer_text, submitted_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE answer_text = VALUES(answer_text), submitted_by = VALUES(submitted_by), submitted_at = NOW()'
                );
                foreach ($questions as $question) {
                    $questionId = (int) $question['id'];
                    $answer = $answers[(string) $questionId] ?? $answers[$questionId] ?? '';
                    $answerText = is_array($answer) ? json_encode(array_values($answer), JSON_UNESCAPED_UNICODE) : trim((string) $answer);
                    if ((int) $question['is_required'] === 1 && $answerText === '') {
                        throw new InvalidArgumentException('Please answer every required exit interview question.');
                    }
                    $answerStmt->bind_param('iisi', $requestId, $questionId, $answerText, $userId);
                    $answerStmt->execute();
                }
                $answerStmt->close();
            }
            $completeStmt = $conn->prepare("UPDATE hr_resignation_requests SET status = 'completed', updated_by = ?, updated_at = NOW() WHERE id = ? AND status = 'exit_interview_pending'");
            $completeStmt->bind_param('ii', $userId, $requestId);
            $completeStmt->execute();
            $completeStmt->close();
            $employeeStmt = $conn->prepare('UPDATE employees SET status = CASE WHEN last_working_date <= CURDATE() THEN 2 ELSE status END, updated_by = ?, updated_at = NOW() WHERE id = ?');
            $employeeStmt->bind_param('ii', $userId, $employeeId);
            $employeeStmt->execute();
            $employeeStmt->close();
            $conn->commit();
            try {
                $generatedDocuments = hrmsGenerateOffboardingDocuments($conn, $requestId, $userId);
            } catch (Throwable $documentException) {
                error_log('Offboarding document generation failed: ' . $documentException->getMessage());
                $generatedDocuments = [];
            }
            $documentsSent = hrmsSendOffboardingDocuments($conn, $requestId);
            $message = trim((string) ($request['thank_you_message'] ?? '')) ?: 'Thank you for completing your exit interview.';
            hrmsJson(['status' => 'success', 'message' => $message, 'documents_generated' => count($generatedDocuments), 'documents_sent' => $documentsSent]);

        case 'save_biometric_device':
            hrmsRequirePermission($conn, 'hrms_biometric_manage');
            $scope = hrmsCurrentScope($conn, $userId);
            $deviceId = filter_var($_POST['device_id'] ?? null, FILTER_VALIDATE_INT);
            $companyId = filter_var($_POST['company_id'] ?? $scope['company_id'], FILTER_VALIDATE_INT);
            $branchId = filter_var($_POST['branch_id'] ?? null, FILTER_VALIDATE_INT);
            $deviceCode = strtoupper(trim((string) ($_POST['device_code'] ?? '')));
            $deviceName = trim((string) ($_POST['device_name'] ?? ''));
            $vendor = trim((string) ($_POST['vendor'] ?? ''));
            if (!$companyId || $deviceCode === '' || mb_strlen($deviceCode) > 100 || $deviceName === '' || mb_strlen($deviceName) > 150) {
                throw new InvalidArgumentException('Enter a valid organization, device code and device name.');
            }
            if ($scope['company_id'] !== null && $scope['company_id'] !== (int) $companyId) {
                throw new RuntimeException('You cannot configure a device for another organization.');
            }
            if ($scope['branch_id'] !== null && (int) $branchId !== $scope['branch_id']) {
                throw new RuntimeException('You cannot configure a device for another branch.');
            }
            if ($deviceId) {
                $stmt = $conn->prepare('UPDATE hr_biometric_devices SET company_id = ?, branch_id = ?, device_code = ?, device_name = ?, vendor = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt->bind_param('iisssii', $companyId, $branchId, $deviceCode, $deviceName, $vendor, $userId, $deviceId);
            } else {
                $stmt = $conn->prepare('INSERT INTO hr_biometric_devices (company_id, branch_id, device_code, device_name, vendor, status, created_by) VALUES (?, ?, ?, ?, ?, 1, ?)');
                $stmt->bind_param('iisssi', $companyId, $branchId, $deviceCode, $deviceName, $vendor, $userId);
            }
            if (!$stmt->execute()) {
                throw new RuntimeException($conn->errno === 1062 ? 'This device code already exists for the organization.' : 'Unable to save the biometric device.');
            }
            $savedDeviceId = $deviceId ?: (int) $stmt->insert_id;
            $stmt->close();
            hrmsJson(['status' => 'success', 'message' => 'Biometric device saved successfully.', 'device_id' => $savedDeviceId]);

        case 'configure_biometric_push':
            hrmsRequirePermission($conn, 'hrms_biometric_manage');
            $columnCheck = $conn->query("SHOW COLUMNS FROM hr_biometric_devices LIKE 'ingest_token_hash'");
            if (!$columnCheck || $columnCheck->num_rows !== 1) {
                throw new RuntimeException('Apply the Care IO completion migration before enabling biometric push.');
            }
            $deviceId = filter_var($_POST['device_id'] ?? null, FILTER_VALIDATE_INT);
            $rateLimit = filter_var($_POST['ingest_rate_limit'] ?? 120, FILTER_VALIDATE_INT);
            $ingestEnabled = isset($_POST['ingest_enabled']) ? 1 : 0;
            $rotateToken = isset($_POST['rotate_token']);
            if (!$deviceId || $rateLimit === false || $rateLimit < 1 || $rateLimit > 10000) {
                throw new InvalidArgumentException('Select a device and enter a valid request rate limit.');
            }
            $deviceStmt = $conn->prepare('SELECT id, company_id, branch_id, ingest_token_hash FROM hr_biometric_devices WHERE id = ? AND status = 1 LIMIT 1');
            $deviceStmt->bind_param('i', $deviceId);
            $deviceStmt->execute();
            $device = $deviceStmt->get_result()->fetch_assoc();
            $deviceStmt->close();
            if (!$device) {
                throw new RuntimeException('Biometric device not found.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $device);
            $plainToken = null;
            if ($rotateToken || empty($device['ingest_token_hash'])) {
                $plainToken = bin2hex(random_bytes(32));
                $tokenHash = hash('sha256', $plainToken);
                $updateStmt = $conn->prepare('UPDATE hr_biometric_devices SET ingest_token_hash = ?, ingest_enabled = ?, ingest_rate_limit = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $updateStmt->bind_param('siiii', $tokenHash, $ingestEnabled, $rateLimit, $userId, $deviceId);
            } else {
                $updateStmt = $conn->prepare('UPDATE hr_biometric_devices SET ingest_enabled = ?, ingest_rate_limit = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $updateStmt->bind_param('iiii', $ingestEnabled, $rateLimit, $userId, $deviceId);
            }
            $updateStmt->execute();
            $updateStmt->close();
            hrmsJson([
                'status' => 'success',
                'message' => $ingestEnabled ? 'Biometric push access configured successfully.' : 'Biometric push access disabled.',
                'device_id' => $deviceId,
                'ingest_enabled' => $ingestEnabled,
                'ingest_token' => $plainToken,
                'endpoint' => 'biometric-push-api.php',
            ]);

        case 'import_biometric_punches':
            hrmsRequirePermission($conn, 'hrms_biometric_manage');
            $deviceId = filter_var($_POST['device_id'] ?? null, FILTER_VALIDATE_INT);
            $events = json_decode((string) ($_POST['events'] ?? '[]'), true);
            if (!$deviceId || !is_array($events) || $events === [] || count($events) > 5000) {
                throw new InvalidArgumentException('Select a device and provide between 1 and 5000 punch events.');
            }
            $deviceStmt = $conn->prepare('SELECT * FROM hr_biometric_devices WHERE id = ? AND status = 1 LIMIT 1');
            $deviceStmt->bind_param('i', $deviceId);
            $deviceStmt->execute();
            $device = $deviceStmt->get_result()->fetch_assoc();
            $deviceStmt->close();
            if (!$device) {
                throw new RuntimeException('Biometric device not found.');
            }
            hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $device);
            $employeeStmt = $conn->prepare(
                "SELECT employee.id FROM employees employee
                 LEFT JOIN users user ON user.id = employee.user_id
                 LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
                                 LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
                 WHERE employee.emp_code = ? AND employee.deleted_at IS NULL
                                     AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?
                   AND (? IS NULL OR COALESCE(profile.branch_id, user.branch_id) = ?)
                 LIMIT 1"
            );
            $insertStmt = $conn->prepare(
                "INSERT IGNORE INTO hr_biometric_punches
                 (device_id, external_event_id, employee_code, employee_id, punch_time, punch_type, raw_payload)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $inserted = 0;
            $ignored = 0;
            $dates = [];
            $conn->begin_transaction();
            foreach ($events as $event) {
                $externalEventId = trim((string) ($event['external_event_id'] ?? $event['id'] ?? ''));
                $employeeCode = trim((string) ($event['employee_code'] ?? ''));
                $punchTime = trim((string) ($event['punch_time'] ?? ''));
                $punchType = strtolower(trim((string) ($event['punch_type'] ?? 'unknown')));
                if ($externalEventId === '' || $employeeCode === '' || !in_array($punchType, ['in', 'out', 'unknown'], true)) {
                    throw new InvalidArgumentException('One or more punch events have invalid identifiers, employee codes or punch types.');
                }
                $dateTime = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $punchTime);
                if (!$dateTime || $dateTime->format('Y-m-d H:i:s') !== $punchTime) {
                    throw new InvalidArgumentException('Punch times must use YYYY-MM-DD HH:MM:SS format.');
                }
                $companyId = (int) $device['company_id'];
                $branchId = !empty($device['branch_id']) ? (int) $device['branch_id'] : null;
                $employeeStmt->bind_param('siii', $employeeCode, $companyId, $branchId, $branchId);
                $employeeStmt->execute();
                $matchedEmployee = $employeeStmt->get_result()->fetch_assoc();
                $employeeId = $matchedEmployee ? (int) $matchedEmployee['id'] : null;
                $rawPayload = json_encode($event, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $insertStmt->bind_param('ississs', $deviceId, $externalEventId, $employeeCode, $employeeId, $punchTime, $punchType, $rawPayload);
                $insertStmt->execute();
                if ($insertStmt->affected_rows === 1) $inserted++; else $ignored++;
                $dates[substr($punchTime, 0, 10)] = true;
            }
            $employeeStmt->close();
            $insertStmt->close();
            $updateDevice = $conn->prepare('UPDATE hr_biometric_devices SET last_synced_at = NOW(), updated_by = ?, updated_at = NOW() WHERE id = ?');
            $updateDevice->bind_param('ii', $userId, $deviceId);
            $updateDevice->execute();
            $updateDevice->close();
            $conn->commit();
            $processed = 0;
            foreach (array_keys($dates) as $date) {
                $processed += hrmsRecalculateAttendance($conn, $date, (int) $device['company_id'], !empty($device['branch_id']) ? (int) $device['branch_id'] : null);
            }
            hrmsJson(['status' => 'success', 'message' => "Imported {$inserted} punch event(s); {$ignored} duplicate(s) ignored.", 'attendance_rows' => $processed]);

        case 'recalculate_attendance':
            hrmsRequirePermission($conn, 'hrms_biometric_manage');
            $attendanceDate = trim((string) ($_POST['attendance_date'] ?? ''));
            $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $attendanceDate);
            if (!$dateObject || $dateObject->format('Y-m-d') !== $attendanceDate) {
                throw new InvalidArgumentException('Select a valid attendance date.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            $companyId = filter_var($_POST['company_id'] ?? $scope['company_id'], FILTER_VALIDATE_INT);
            $branchId = filter_var($_POST['branch_id'] ?? $scope['branch_id'], FILTER_VALIDATE_INT);
            if ($scope['company_id'] !== null && $scope['company_id'] !== (int) $companyId) {
                throw new RuntimeException('You cannot recalculate another organization.');
            }
            if ($scope['branch_id'] !== null && $scope['branch_id'] !== (int) $branchId) {
                throw new RuntimeException('You cannot recalculate another branch.');
            }
            $processed = hrmsRecalculateAttendance($conn, $attendanceDate, $companyId ? (int) $companyId : null, $branchId ? (int) $branchId : null);
            hrmsJson(['status' => 'success', 'message' => "Attendance recalculated for {$processed} employee(s)."]);

        case 'mark_present_attendance':
            hrmsRequirePermission($conn, 'hrms_attendance_mark');
            $tableCheck = $conn->query("SHOW TABLES LIKE 'hr_attendance_manual_marks'");
            if (!$tableCheck || $tableCheck->num_rows !== 1) {
                throw new RuntimeException('Apply the Care IO completion migration before confirming attendance.');
            }
            $employeeIds = [];
            if (isset($_POST['employee_ids'])) {
                $decodedEmployeeIds = json_decode((string) $_POST['employee_ids'], true);
                if (is_array($decodedEmployeeIds)) {
                    $employeeIds = array_values(array_unique(array_filter(array_map('intval', $decodedEmployeeIds), static fn(int $id): bool => $id > 0)));
                }
            } else {
                $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
                if ($employeeId) $employeeIds[] = (int) $employeeId;
            }
            $attendanceDate = trim((string) ($_POST['attendance_date'] ?? ''));
            $classification = (string) ($_POST['classification'] ?? '');
            $note = trim((string) ($_POST['note'] ?? ''));
            $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $attendanceDate);
            if ($employeeIds === [] || count($employeeIds) > 500 || !$dateObject || $dateObject->format('Y-m-d') !== $attendanceDate || !in_array($classification, ['full_day', 'half_day'], true) || mb_strlen($note) > 500) {
                throw new InvalidArgumentException('Select a present employee, date and valid attendance classification.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            $conn->begin_transaction();
            $attendanceStmt = $conn->prepare(
                "SELECT daily.id, daily.employee_id, daily.company_id, daily.branch_id,
                    daily.first_punch_at, daily.classification
                 FROM hr_attendance_daily daily
                 WHERE daily.employee_id = ? AND daily.attendance_date = ?
                   AND daily.first_punch_at IS NOT NULL AND daily.classification <> 'absent'
                 FOR UPDATE"
            );
            $markStmt = $conn->prepare(
                "INSERT INTO hr_attendance_manual_marks
                 (employee_id, company_id, branch_id, attendance_date, classification, note, marked_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE classification = VALUES(classification), note = VALUES(note),
                   updated_by = VALUES(marked_by), updated_at = NOW()"
            );
            $dailyStmt = $conn->prepare("UPDATE hr_attendance_daily SET classification = ?, source = 'manual', calculated_at = NOW() WHERE id = ?");
            foreach ($employeeIds as $employeeId) {
                $attendanceStmt->bind_param('is', $employeeId, $attendanceDate);
                $attendanceStmt->execute();
                $attendance = $attendanceStmt->get_result()->fetch_assoc();
                if (!$attendance) {
                    throw new RuntimeException('Attendance can only be marked for employees present in biometric data.');
                }
                if (($scope['company_id'] !== null && (int) ($attendance['company_id'] ?? 0) !== $scope['company_id'])
                    || ($scope['branch_id'] !== null && !empty($attendance['branch_id']) && (int) $attendance['branch_id'] !== $scope['branch_id'])) {
                    $conn->rollback();
                    hrmsJson(['status' => 'error', 'message' => 'One or more employees belong to another organization or branch.'], 403);
                }
                $companyId = !empty($attendance['company_id']) ? (int) $attendance['company_id'] : null;
                $branchId = !empty($attendance['branch_id']) ? (int) $attendance['branch_id'] : null;
                $markStmt->bind_param('iiisssi', $employeeId, $companyId, $branchId, $attendanceDate, $classification, $note, $userId);
                $markStmt->execute();
                $dailyClassification = $classification;
                if ($classification === 'full_day' && in_array($attendance['classification'], ['on_time', 'late', 'early_leave', 'full_day'], true)) {
                    $dailyClassification = $attendance['classification'];
                }
                $dailyId = (int) $attendance['id'];
                $dailyStmt->bind_param('si', $dailyClassification, $dailyId);
                $dailyStmt->execute();
            }
            $attendanceStmt->close();
            $markStmt->close();
            $dailyStmt->close();
            $conn->commit();
            hrmsJson(['status' => 'success', 'message' => count($employeeIds) . ' present employee attendance record(s) marked successfully.']);

        case 'create_hrms_shift':
        case 'update_hrms_shift':
            $editingShiftId = $action === 'update_hrms_shift'
                ? filter_var($_POST['shift_id'] ?? null, FILTER_VALIDATE_INT)
                : null;
            if ($action === 'update_hrms_shift' && !$editingShiftId) {
                throw new InvalidArgumentException('Select a shift to update.');
            }
            $name = trim((string) ($_POST['name'] ?? ''));
            $startTime = trim((string) ($_POST['start_time'] ?? ''));
            $endTime = trim((string) ($_POST['end_time'] ?? ''));
            $lunchStart = trim((string) ($_POST['lunch_start_time'] ?? '')) ?: null;
            $lunchEnd = trim((string) ($_POST['lunch_end_time'] ?? '')) ?: null;
            $lateGrace = filter_var($_POST['late_grace_minutes'] ?? 0, FILTER_VALIDATE_INT);
            $earlyLeave = filter_var($_POST['early_leave_minutes'] ?? 0, FILTER_VALIDATE_INT);
            $fullDayMinutes = filter_var($_POST['full_day_minutes'] ?? null, FILTER_VALIDATE_INT);
            $halfDayMinutes = filter_var($_POST['half_day_minutes'] ?? null, FILTER_VALIDATE_INT);
            $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
            $branchId = filter_var($_POST['branch_id'] ?? null, FILTER_VALIDATE_INT);
            $effectiveFrom = trim((string) ($_POST['effective_from'] ?? date('Y-m-d')));
            $workingDays = array_values(array_unique(array_filter(array_map('intval', $_POST['working_days'] ?? []), static fn(int $day): bool => $day >= 1 && $day <= 7)));
            if ($name === '' || mb_strlen($name) > 150 || !preg_match('/^\d{2}:\d{2}$/', $startTime) || !preg_match('/^\d{2}:\d{2}$/', $endTime)) {
                throw new InvalidArgumentException('Enter a shift name and valid start/end times.');
            }
            if ($startTime === $endTime) {
                throw new InvalidArgumentException('The shift start and end time cannot be identical.');
            }
            if (($lunchStart === null) !== ($lunchEnd === null)) {
                throw new InvalidArgumentException('Enter both a lunch start and lunch end time, or leave both empty.');
            }
            if ($lunchStart !== null && $lunchStart === $lunchEnd) {
                throw new InvalidArgumentException('The lunch start and end time cannot be identical.');
            }
            if ($lateGrace === false || $lateGrace < 0 || $lateGrace > 240 || $earlyLeave === false || $earlyLeave < 0 || $earlyLeave > 240) {
                throw new InvalidArgumentException('Late grace and early-leave minutes must be between 0 and 240.');
            }
            if (!$companyId || !$branchId || !$fullDayMinutes || !$halfDayMinutes || $halfDayMinutes > $fullDayMinutes || $fullDayMinutes > 1440 || $workingDays === []) {
                throw new InvalidArgumentException('Select tenant scope, working days and valid half/full-day thresholds.');
            }
            $effectiveDate = DateTimeImmutable::createFromFormat('!Y-m-d', $effectiveFrom);
            if (!$effectiveDate || $effectiveDate->format('Y-m-d') !== $effectiveFrom) {
                throw new InvalidArgumentException('Enter a valid policy effective date.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            if ($scope['company_id'] !== null && $scope['company_id'] !== (int) $companyId) {
                throw new RuntimeException('You cannot configure a shift for another organization.');
            }
            if ($scope['branch_id'] !== null && $scope['branch_id'] !== (int) $branchId) {
                throw new RuntimeException('You cannot configure a shift for another branch.');
            }
            $duplicate = $conn->prepare(
                'SELECT id FROM shifts WHERE name = ? AND company_id = ? AND branch_id = ? AND status = 1 AND deleted_at IS NULL AND id <> ? LIMIT 1'
            );
            $duplicateExclude = (int) ($editingShiftId ?? 0);
            $duplicate->bind_param('siii', $name, $companyId, $branchId, $duplicateExclude);
            $duplicate->execute();
            $duplicateExists = (bool) $duplicate->get_result()->fetch_assoc();
            $duplicate->close();
            if ($duplicateExists) {
                throw new InvalidArgumentException('A shift with this name already exists for the selected branch.');
            }

            $halfDayHours = round($halfDayMinutes / 60, 2);
            $startWithSeconds = $startTime . ':00';
            $endWithSeconds = $endTime . ':00';
            $lunchStartWithSeconds = $lunchStart ? $lunchStart . ':00' : null;
            $lunchEndWithSeconds = $lunchEnd ? $lunchEnd . ':00' : null;

            $conn->begin_transaction();
            try {
                if ($editingShiftId !== null) {
                    $existing = $conn->prepare('SELECT id, company_id, branch_id FROM shifts WHERE id = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE');
                    $existing->bind_param('i', $editingShiftId);
                    $existing->execute();
                    $existingShift = $existing->get_result()->fetch_assoc();
                    $existing->close();
                    if (!$existingShift) {
                        throw new InvalidArgumentException('Shift not found.');
                    }
                    if ($scope['company_id'] !== null && (int) $existingShift['company_id'] !== 0
                        && (int) $existingShift['company_id'] !== $scope['company_id']) {
                        throw new RuntimeException('This shift belongs to another organization.');
                    }
                    $shiftStmt = $conn->prepare(
                        'UPDATE shifts SET name=?, company_id=?, branch_id=?, start_time=?, end_time=?, lunch_start_time=?,
                         lunch_end_time=?, half_day_hours=?, late_grace_minutes=?, early_leave_minutes=?, updated_by=?, updated_at=NOW()
                         WHERE id = ? AND deleted_at IS NULL'
                    );
                    $shiftStmt->bind_param(
                        'siisssssiiii',
                        $name, $companyId, $branchId, $startWithSeconds, $endWithSeconds,
                        $lunchStartWithSeconds, $lunchEndWithSeconds, $halfDayHours,
                        $lateGrace, $earlyLeave, $userId, $editingShiftId
                    );
                    if (!$shiftStmt->execute()) {
                        throw new RuntimeException('Unable to update the shift.');
                    }
                    $shiftStmt->close();
                    $shiftId = (int) $editingShiftId;
                    $clearDays = $conn->prepare('UPDATE shift_days SET status = 3, deleted_at = NOW(), deleted_by = ? WHERE shift_id = ?');
                    $clearDays->bind_param('ii', $userId, $shiftId);
                    $clearDays->execute();
                    $clearDays->close();
                } else {
                    $shiftStmt = $conn->prepare(
                        'INSERT INTO shifts (name,company_id,branch_id,start_time,end_time,lunch_start_time,lunch_end_time,half_day_hours,late_grace_minutes,early_leave_minutes,status,created_by,created_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?,1,?,NOW())'
                    );
                    $shiftStmt->bind_param(
                        'siisssssiii',
                        $name, $companyId, $branchId, $startWithSeconds, $endWithSeconds,
                        $lunchStartWithSeconds, $lunchEndWithSeconds, $halfDayHours,
                        $lateGrace, $earlyLeave, $userId
                    );
                    if (!$shiftStmt->execute()) {
                        throw new RuntimeException('Unable to create the shift.');
                    }
                    $shiftId = (int) $shiftStmt->insert_id;
                    $shiftStmt->close();
                }

                $dayStmt = $conn->prepare(
                    'INSERT INTO shift_days (shift_id,day_of_week,is_working_day,status,created_by,created_at)
                     VALUES (?, ?, 1, 1, ?, NOW())'
                );
                foreach ($workingDays as $workingDay) {
                    $dayStmt->bind_param('iii', $shiftId, $workingDay, $userId);
                    $dayStmt->execute();
                }
                $dayStmt->close();

                $policyStmt = $conn->prepare(
                    'INSERT INTO hr_shift_policies (shift_id,company_id,branch_id,full_day_minutes,half_day_minutes,effective_from,created_by)
                     VALUES (?,?,?,?,?,?,?)
                     ON DUPLICATE KEY UPDATE full_day_minutes=VALUES(full_day_minutes), half_day_minutes=VALUES(half_day_minutes),
                       updated_by=VALUES(created_by), updated_at=NOW()'
                );
                $policyStmt->bind_param('iiiiisi', $shiftId, $companyId, $branchId, $fullDayMinutes, $halfDayMinutes, $effectiveFrom, $userId);
                $policyStmt->execute();
                $policyStmt->close();
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }

            // Recalculation is deliberately outside the transaction; it loops employees x dates.
            $recalculation = hrmsRecalculateAttendanceRange($conn, (int) $companyId, (int) $branchId, $effectiveFrom);
            hrmsJson([
                'status' => 'success',
                'message' => ($editingShiftId !== null ? 'Shift updated successfully. ' : 'Shift created successfully. ')
                    . 'Attendance was recalculated for ' . $recalculation['dates'] . ' affected date(s).',
                'shift_id' => $shiftId,
                'recalculated_dates' => $recalculation['dates'],
            ]);

        case 'delete_hrms_shift':
            $shiftId = filter_var($_POST['shift_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$shiftId) {
                throw new InvalidArgumentException('Select a shift to remove.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            $lookup = $conn->prepare('SELECT id, name, company_id FROM shifts WHERE id = ? AND deleted_at IS NULL LIMIT 1');
            $lookup->bind_param('i', $shiftId);
            $lookup->execute();
            $shiftRow = $lookup->get_result()->fetch_assoc();
            $lookup->close();
            if (!$shiftRow) {
                throw new InvalidArgumentException('Shift not found.');
            }
            if ($scope['company_id'] !== null && (int) $shiftRow['company_id'] !== 0
                && (int) $shiftRow['company_id'] !== $scope['company_id']) {
                throw new RuntimeException('This shift belongs to another organization.');
            }
            $inUse = $conn->prepare(
                'SELECT 1 FROM employee_shift_rosters WHERE shift_id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1'
            );
            $inUse->bind_param('i', $shiftId);
            $inUse->execute();
            $rosterExists = (bool) $inUse->get_result()->fetch_assoc();
            $inUse->close();
            if ($rosterExists) {
                throw new RuntimeException('This shift is still assigned to employees. Remove those roster entries first.');
            }
            $conn->begin_transaction();
            try {
                $deleteDays = $conn->prepare('UPDATE shift_days SET status = 3, deleted_at = NOW(), deleted_by = ? WHERE shift_id = ?');
                $deleteDays->bind_param('ii', $userId, $shiftId);
                $deleteDays->execute();
                $deleteDays->close();
                $deleteShift = $conn->prepare('UPDATE shifts SET status = 3, deleted_at = NOW(), deleted_by = ? WHERE id = ? AND deleted_at IS NULL');
                $deleteShift->bind_param('ii', $userId, $shiftId);
                if (!$deleteShift->execute() || $deleteShift->affected_rows !== 1) {
                    throw new RuntimeException('Unable to remove the shift.');
                }
                $deleteShift->close();
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Shift "' . $shiftRow['name'] . '" was removed.']);

        case 'save_employee_shift_roster':
            $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            $shiftId = filter_var($_POST['shift_id'] ?? null, FILTER_VALIDATE_INT);
            $startDate = trim((string) ($_POST['start_date'] ?? ''));
            $endDate = trim((string) ($_POST['end_date'] ?? '')) ?: null;
            if (!$employeeId || !$shiftId) {
                throw new InvalidArgumentException('Select an employee and a shift.');
            }
            $startObject = DateTimeImmutable::createFromFormat('!Y-m-d', $startDate);
            if (!$startObject || $startObject->format('Y-m-d') !== $startDate) {
                throw new InvalidArgumentException('Enter a valid roster start date.');
            }
            if ($endDate !== null) {
                $endObject = DateTimeImmutable::createFromFormat('!Y-m-d', $endDate);
                if (!$endObject || $endObject->format('Y-m-d') !== $endDate || $endDate < $startDate) {
                    throw new InvalidArgumentException('Enter a valid roster end date.');
                }
            }
            $employee = hrmsEmployeeById($conn, (int) $employeeId);
            if (!$employee) {
                throw new InvalidArgumentException('Employee not found.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            hrmsAssertTenantAccess($scope, $employee);
            $shiftLookup = $conn->prepare(
                'SELECT id, company_id, branch_id FROM shifts WHERE id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1'
            );
            $shiftLookup->bind_param('i', $shiftId);
            $shiftLookup->execute();
            $shift = $shiftLookup->get_result()->fetch_assoc();
            $shiftLookup->close();
            if (!$shift) {
                throw new InvalidArgumentException('The selected shift is no longer available.');
            }
            $employeeCompanyId = (int) ($employee['company_id'] ?? 0);
            $employeeBranchId = (int) ($employee['branch_id'] ?? 0);
            if ((int) ($shift['company_id'] ?? 0) > 0 && (int) $shift['company_id'] !== $employeeCompanyId) {
                throw new RuntimeException('The selected shift belongs to another organization.');
            }
            if ((int) ($shift['branch_id'] ?? 0) > 0 && (int) $shift['branch_id'] !== $employeeBranchId) {
                throw new RuntimeException('The selected shift belongs to another branch.');
            }
            $overlap = $conn->prepare(
                'SELECT id FROM employee_shift_rosters
                 WHERE employee_id = ? AND status = 1 AND deleted_at IS NULL
                   AND start_date IS NOT NULL
                   AND start_date <= COALESCE(?, "9999-12-31")
                   AND COALESCE(end_date, "9999-12-31") >= ?
                 LIMIT 1'
            );
            $overlap->bind_param('iss', $employeeId, $endDate, $startDate);
            $overlap->execute();
            $overlapExists = (bool) $overlap->get_result()->fetch_assoc();
            $overlap->close();
            if ($overlapExists) {
                throw new RuntimeException('This employee already has a shift assigned for an overlapping period.');
            }
            $insert = $conn->prepare(
                'INSERT INTO employee_shift_rosters (employee_id, shift_id, start_date, end_date, status, created_by, created_at)
                 VALUES (?, ?, ?, ?, 1, ?, NOW())'
            );
            $insert->bind_param('iissi', $employeeId, $shiftId, $startDate, $endDate, $userId);
            if (!$insert->execute()) {
                throw new RuntimeException('Unable to assign the shift.');
            }
            $insert->close();
            $rosterCompanyId = (int) ($employee['company_id'] ?? 0);
            $rosterBranchId = !empty($employee['branch_id']) ? (int) $employee['branch_id'] : null;
            $recalculation = ['dates' => 0];
            if ($rosterCompanyId > 0) {
                $recalculation = hrmsRecalculateAttendanceRange($conn, $rosterCompanyId, $rosterBranchId, $startDate, $endDate);
            }
            hrmsJson([
                'status' => 'success',
                'message' => 'Shift assigned. Attendance was recalculated for ' . $recalculation['dates'] . ' affected date(s).',
            ]);

        case 'delete_employee_shift_roster':
            $rosterId = filter_var($_POST['roster_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$rosterId) {
                throw new InvalidArgumentException('Select a roster entry to remove.');
            }
            $lookup = $conn->prepare(
                'SELECT roster.id, roster.employee_id, roster.start_date, roster.end_date
                 FROM employee_shift_rosters roster WHERE roster.id = ? AND roster.deleted_at IS NULL LIMIT 1'
            );
            $lookup->bind_param('i', $rosterId);
            $lookup->execute();
            $rosterRow = $lookup->get_result()->fetch_assoc();
            $lookup->close();
            if (!$rosterRow) {
                throw new InvalidArgumentException('Roster entry not found.');
            }
            $employee = hrmsEmployeeById($conn, (int) $rosterRow['employee_id']);
            if ($employee) {
                hrmsAssertTenantAccess(hrmsCurrentScope($conn, $userId), $employee);
            }
            $delete = $conn->prepare('UPDATE employee_shift_rosters SET status = 3, deleted_at = NOW(), deleted_by = ? WHERE id = ?');
            $delete->bind_param('ii', $userId, $rosterId);
            $delete->execute();
            $delete->close();
            hrmsJson(['status' => 'success', 'message' => 'Shift assignment removed.']);

        case 'save_shift_policy':
            $shiftId = filter_var($_POST['shift_id'] ?? null, FILTER_VALIDATE_INT);
            $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
            $branchId = filter_var($_POST['branch_id'] ?? null, FILTER_VALIDATE_INT);
            $fullDayMinutes = filter_var($_POST['full_day_minutes'] ?? null, FILTER_VALIDATE_INT);
            $halfDayMinutes = filter_var($_POST['half_day_minutes'] ?? null, FILTER_VALIDATE_INT);
            $effectiveFrom = trim((string) ($_POST['effective_from'] ?? ''));
            $effectiveTo = trim((string) ($_POST['effective_to'] ?? '')) ?: null;
            if (!$shiftId || !$companyId || !$fullDayMinutes || !$halfDayMinutes || $halfDayMinutes > $fullDayMinutes || $fullDayMinutes > 1440) {
                throw new InvalidArgumentException('Enter a valid shift, organization and half/full-day thresholds.');
            }
            $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $effectiveFrom);
            if (!$dateObject || $dateObject->format('Y-m-d') !== $effectiveFrom || ($effectiveTo !== null && $effectiveTo < $effectiveFrom)) {
                throw new InvalidArgumentException('Enter a valid policy effective period.');
            }
            $scope = hrmsCurrentScope($conn, $userId);
            if ($scope['company_id'] !== null && $scope['company_id'] !== (int) $companyId) {
                throw new RuntimeException('You cannot configure another organization.');
            }
            if ($scope['branch_id'] !== null && $scope['branch_id'] !== (int) $branchId) {
                throw new RuntimeException('You cannot configure another branch.');
            }
            $branchId = $branchId ?: 0;
            $overlap = $conn->prepare(
                'SELECT id FROM hr_shift_policies
                 WHERE shift_id = ? AND company_id = ? AND branch_id = ?
                   AND effective_from <> ?
                   AND effective_from <= COALESCE(?, "9999-12-31")
                   AND COALESCE(effective_to, "9999-12-31") >= ?
                 LIMIT 1'
            );
            $overlap->bind_param('iiisss', $shiftId, $companyId, $branchId, $effectiveFrom, $effectiveTo, $effectiveFrom);
            $overlap->execute();
            $overlapExists = (bool) $overlap->get_result()->fetch_assoc();
            $overlap->close();
            if ($overlapExists) {
                throw new RuntimeException('Another policy for this shift and branch already covers part of that period.');
            }
            $stmt = $conn->prepare(
                'INSERT INTO hr_shift_policies (shift_id, company_id, branch_id, full_day_minutes, half_day_minutes, effective_from, effective_to, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE full_day_minutes=VALUES(full_day_minutes), half_day_minutes=VALUES(half_day_minutes), effective_to=VALUES(effective_to), updated_by=VALUES(created_by), updated_at=NOW()'
            );
            $stmt->bind_param('iiiiissi', $shiftId, $companyId, $branchId, $fullDayMinutes, $halfDayMinutes, $effectiveFrom, $effectiveTo, $userId);
            if (!$stmt->execute()) {
                throw new RuntimeException('Unable to save the shift policy.');
            }
            $stmt->close();
            $recalculation = hrmsRecalculateAttendanceRange($conn, (int) $companyId, $branchId ?: null, $effectiveFrom, $effectiveTo);
            hrmsJson([
                'status' => 'success',
                'message' => 'Shift attendance policy saved successfully. Attendance was recalculated for ' . $recalculation['dates'] . ' affected date(s).',
                'recalculated_dates' => $recalculation['dates'],
            ]);

        case 'update_my_profile':
            $name = trim((string) ($_POST['name'] ?? $_POST['profile_name'] ?? ''));
            $firstName = trim((string) ($_POST['first_name'] ?? ''));
            $lastName = trim((string) ($_POST['last_name'] ?? ''));

            if ($firstName !== '' || $lastName !== '') {
                $name = trim($firstName . ' ' . $lastName);
            } elseif ($name !== '') {
                $nameParts = preg_split('/\s+/', $name, 2);
                $firstName = $nameParts[0] ?? $name;
                $lastName = $nameParts[1] ?? '';
            }

            if ($name === '' || mb_strlen($name) < 2 || mb_strlen($name) > 150) {
                throw new InvalidArgumentException('Please enter a valid full name (2 to 150 characters).');
            }

            $phone = trim((string) ($_POST['phone'] ?? $_POST['profile_phone'] ?? $_POST['contact_no'] ?? ''));
            if ($phone !== '' && (strlen($phone) < 7 || strlen($phone) > 20 || !preg_match('/^[0-9+\-\s()]+$/', $phone))) {
                throw new InvalidArgumentException('Please enter a valid phone number.');
            }

            $solutation = trim((string) ($_POST['solutation'] ?? ''));
            $dob = trim((string) ($_POST['dob'] ?? ''));
            $gender = !empty($_POST['gender']) ? (int) $_POST['gender'] : null;
            $bloodGroup = trim((string) ($_POST['blood_group'] ?? ''));
            $fathersName = trim((string) ($_POST['fathers_name'] ?? ''));
            $maritalStatus = !empty($_POST['marital_status']) ? (int) $_POST['marital_status'] : null;
            $husbandName = trim((string) ($_POST['husband_name'] ?? ''));
            $altContact = trim((string) ($_POST['alt_contact_no'] ?? ''));
            $altContact2 = trim((string) ($_POST['alt_contact_no2'] ?? ''));
            $localAddress = trim((string) ($_POST['local_address'] ?? ''));
            $permanentAddress = trim((string) ($_POST['permanent_address'] ?? ''));

            if ($gender !== null && !array_key_exists($gender, Constant::EMPLOYEES['GENDER'])) {
                throw new InvalidArgumentException('Select a valid gender.');
            }
            if ($maritalStatus !== null && !array_key_exists($maritalStatus, Constant::EMPLOYEES['MARITAL_STATUS'])) {
                throw new InvalidArgumentException('Select a valid marital status.');
            }

            $conn->begin_transaction();
            $userStmt = $conn->prepare('UPDATE users SET name = ?, updated_at = NOW() WHERE id = ? AND deleted_at IS NULL');
            $userStmt->bind_param('si', $name, $userId);
            $userStmt->execute();
            $userStmt->close();

            // Mirrors the profile loader: an employee row may still be matched by email and not yet linked.
            $empStmt = $conn->prepare('SELECT id, user_id FROM employees
                WHERE (user_id = ? OR (user_id IS NULL AND email = (SELECT email FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1)))
                  AND deleted_at IS NULL
                ORDER BY (user_id = ?) DESC, id DESC LIMIT 1 FOR UPDATE');
            $empStmt->bind_param('iii', $userId, $userId, $userId);
            $empStmt->execute();
            $linkedEmployee = $empStmt->get_result()->fetch_assoc();
            $empStmt->close();

            if ($linkedEmployee) {
                $employeeId = (int) $linkedEmployee['id'];
                if (empty($linkedEmployee['user_id'])) {
                    $linkStmt = $conn->prepare('UPDATE employees SET user_id = ?, updated_at = NOW() WHERE id = ?');
                    $linkStmt->bind_param('ii', $userId, $employeeId);
                    $linkStmt->execute();
                    $linkStmt->close();
                }
                $dobVal = !empty($dob) ? $dob : null;

                $empUpdate = $conn->prepare('UPDATE employees SET 
                    solutation = ?, first_name = ?, last_name = ?, dob = ?, gender = ?, blood_group = ?,
                    fathers_name = ?, marital_status = ?, husband_name = ?, contact_no = ?, alt_contact_no = ?, alt_contact_no2 = ?,
                    local_address = ?, permanent_address = ?, updated_at = NOW() WHERE id = ?');
                $empUpdate->bind_param(
                    'ssssississssssi',
                    $solutation,
                    $firstName,
                    $lastName,
                    $dobVal,
                    $gender,
                    $bloodGroup,
                    $fathersName,
                    $maritalStatus,
                    $husbandName,
                    $phone,
                    $altContact,
                    $altContact2,
                    $localAddress,
                    $permanentAddress,
                    $employeeId
                );
                $empUpdate->execute();
                $empUpdate->close();
            }

            $conn->commit();
            $_SESSION['user_name'] = $name;

            hrmsJson([
                'status' => 'success',
                'message' => $linkedEmployee
                    ? 'Profile updated successfully.'
                    : 'Your name was updated. Personal details need an employee record linked to this account.',
                'name' => $name,
                'phone' => $phone,
            ]);

        case 'upload_profile_photo':
            $file = $_FILES['profile_photo'] ?? $_FILES['photo'] ?? null;
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                throw new InvalidArgumentException('Please select a photo to upload.');
            }
            if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
                throw new RuntimeException('The photo upload did not complete successfully.');
            }
            $fileSize = (int) ($file['size'] ?? 0);
            if ($fileSize <= 0 || $fileSize > 5 * 1024 * 1024) {
                throw new InvalidArgumentException('Profile photos must be smaller than 5 MB.');
            }

            $tmpName = (string) ($file['tmp_name'] ?? '');
            if ($tmpName === '' || !is_uploaded_file($tmpName)) {
                throw new RuntimeException('The uploaded file is not valid.');
            }

            $originalName = basename((string) ($file['name'] ?? 'profile-photo'));
            $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
            $allowedExtensions = ['png', 'jpg', 'jpeg', 'webp'];
            if (!in_array($extension, $allowedExtensions, true)) {
                throw new InvalidArgumentException('Profile photos must be PNG, JPG, JPEG, or WEBP images.');
            }

            $mimeType = '';
            if (class_exists('finfo')) {
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mimeType = (string) $finfo->file($tmpName);
            }
            $allowedMimeTypes = ['image/png', 'image/jpeg', 'image/webp'];
            if (($mimeType !== '' && !in_array($mimeType, $allowedMimeTypes, true)) || @getimagesize($tmpName) === false) {
                throw new InvalidArgumentException('The selected file is not a valid image.');
            }

            $empStmt = $conn->prepare('SELECT id FROM employees WHERE user_id = ? AND deleted_at IS NULL LIMIT 1');
            $empStmt->bind_param('i', $userId);
            $empStmt->execute();
            $empRow = $empStmt->get_result()->fetch_assoc();
            $empStmt->close();

            if (!$empRow) {
                // Fallback: search unlinked employee by user's email or matching full name and auto-link
                $uStmt = $conn->prepare('SELECT name, email FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1');
                $uStmt->bind_param('i', $userId);
                $uStmt->execute();
                $uRow = $uStmt->get_result()->fetch_assoc();
                $uStmt->close();

                if ($uRow && !empty($uRow['email'])) {
                    $parts = explode(' ', trim((string)$uRow['name']), 2);
                    $fn = $parts[0] ?? '';
                    $ln = $parts[1] ?? '';
                    $mStmt = $conn->prepare("SELECT id FROM employees WHERE (email = ? OR (first_name = ? AND last_name = ?)) AND deleted_at IS NULL AND (user_id IS NULL OR user_id = 0) ORDER BY id DESC LIMIT 1");
                    $mStmt->bind_param('sss', $uRow['email'], $fn, $ln);
                    $mStmt->execute();
                    $empRow = $mStmt->get_result()->fetch_assoc();
                    $mStmt->close();

                    if ($empRow) {
                        $linkStmt = $conn->prepare("UPDATE employees SET user_id = ? WHERE id = ?");
                        $linkStmt->bind_param('ii', $userId, $empRow['id']);
                        $linkStmt->execute();
                        $linkStmt->close();
                    }
                }
            }

            if (!$empRow) {
                throw new RuntimeException('No employee profile is linked to your user account.');
            }
            $employeeId = (int) $empRow['id'];

            $projectRoot = dirname(__DIR__);
            $relativeDir = 'uploads/hrms-employees/' . $employeeId . '/';
            $uploadDir = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDir);
            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
                throw new RuntimeException('Unable to create profile photo storage directory.');
            }

            $storedName = 'profile_photo-' . bin2hex(random_bytes(8)) . '.' . $extension;
            $absolutePath = $uploadDir . $storedName;
            if (!move_uploaded_file($tmpName, $absolutePath)) {
                throw new RuntimeException('Unable to store the profile photo.');
            }
            $storedFiles[] = $absolutePath;
            $relativePath = $relativeDir . $storedName;

            $conn->begin_transaction();
            $delStmt = $conn->prepare("UPDATE employee_documents SET status = 3, deleted_by = ?, deleted_at = NOW() WHERE employee_id = ? AND document_type = 'profile_photo' AND status = 1 AND deleted_at IS NULL");
            $delStmt->bind_param('ii', $userId, $employeeId);
            $delStmt->execute();
            $delStmt->close();

            $docStmt = $conn->prepare("INSERT INTO employee_documents (employee_id, document_type, original_name, file_path, mime_type, file_size, status, created_by, created_at) VALUES (?, 'profile_photo', ?, ?, ?, ?, 1, ?, NOW())");
            $docStmt->bind_param('isssii', $employeeId, $originalName, $relativePath, $mimeType, $fileSize, $userId);
            if (!$docStmt->execute()) {
                throw new RuntimeException('Unable to register the profile photo.');
            }
            $photoDocId = (int) $docStmt->insert_id;
            $docStmt->close();
            $conn->commit();

            hrmsJson([
                'status' => 'success',
                'message' => 'Profile photo updated successfully.',
                'photo_id' => $photoDocId,
                'photo_url' => 'hrms-document.php?id=' . $photoDocId,
            ]);

        case 'remove_profile_photo':
            $empStmt = $conn->prepare('SELECT id FROM employees WHERE user_id = ? AND deleted_at IS NULL LIMIT 1');
            $empStmt->bind_param('i', $userId);
            $empStmt->execute();
            $empRow = $empStmt->get_result()->fetch_assoc();
            $empStmt->close();

            if (!$empRow) {
                $uStmt = $conn->prepare('SELECT name, email FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1');
                $uStmt->bind_param('i', $userId);
                $uStmt->execute();
                $uRow = $uStmt->get_result()->fetch_assoc();
                $uStmt->close();

                if ($uRow && !empty($uRow['email'])) {
                    $parts = explode(' ', trim((string)$uRow['name']), 2);
                    $fn = $parts[0] ?? '';
                    $ln = $parts[1] ?? '';
                    $mStmt = $conn->prepare("SELECT id FROM employees WHERE (email = ? OR (first_name = ? AND last_name = ?)) AND deleted_at IS NULL AND (user_id IS NULL OR user_id = 0) ORDER BY id DESC LIMIT 1");
                    $mStmt->bind_param('sss', $uRow['email'], $fn, $ln);
                    $mStmt->execute();
                    $empRow = $mStmt->get_result()->fetch_assoc();
                    $mStmt->close();

                    if ($empRow) {
                        $linkStmt = $conn->prepare("UPDATE employees SET user_id = ? WHERE id = ?");
                        $linkStmt->bind_param('ii', $userId, $empRow['id']);
                        $linkStmt->execute();
                        $linkStmt->close();
                    }
                }
            }

            if (!$empRow) {
                throw new RuntimeException('No employee profile is linked to your user account.');
            }
            $employeeId = (int) $empRow['id'];

            $conn->begin_transaction();
            $delStmt = $conn->prepare("UPDATE employee_documents SET status = 3, deleted_by = ?, deleted_at = NOW() WHERE employee_id = ? AND document_type = 'profile_photo' AND status = 1 AND deleted_at IS NULL");
            $delStmt->bind_param('ii', $userId, $employeeId);
            $delStmt->execute();
            $delStmt->close();
            $conn->commit();

            hrmsJson([
                'status' => 'success',
                'message' => 'Profile photo removed successfully.',
                'photo_url' => 'assets/img/avatars/14.png',
            ]);

        // Annual Calendar & Working Days actions are handled by acHandleApiAction().

        default:
            hrmsJson(['status' => 'error', 'message' => 'Unsupported HRMS action.'], 400);
    }
} catch (InvalidArgumentException $exception) {
    if ($conn->errno === 0) {
        @$conn->rollback();
    }
    foreach ($storedFiles as $storedFile) {
        @unlink($storedFile);
    }
    hrmsJson(['status' => 'error', 'message' => $exception->getMessage()], 422);
} catch (Throwable $exception) {
    @$conn->rollback();
    foreach ($storedFiles as $storedFile) {
        @unlink($storedFile);
    }
    error_log('HRMS action failed [' . $action . ']: ' . $exception->getMessage());
    hrmsJson(['status' => 'error', 'message' => $exception instanceof RuntimeException ? $exception->getMessage() : 'Unable to complete the HRMS request.'], 500);
}
