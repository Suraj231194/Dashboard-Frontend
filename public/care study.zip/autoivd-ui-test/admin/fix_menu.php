<?php
require __DIR__ . '/db.php';
$conn->query("UPDATE menus SET showmenu = 1, parent_id = 30 WHERE id = 23");
echo "Updated Product Categories to be visible under Store & SCM.";
