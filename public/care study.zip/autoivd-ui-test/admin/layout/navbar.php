<?php
$navbar_role_name = $_SESSION['role_name'] ?? '';
if (empty($navbar_role_name) && isset($_SESSION['role_id'])) {
  $stmtRole = $conn->prepare("SELECT name FROM roles WHERE id = ?");
  if ($stmtRole) {
    $stmtRole->bind_param("i", $_SESSION['role_id']);
    $stmtRole->execute();
    $resRole = $stmtRole->get_result();
    if ($rowRole = $resRole->fetch_assoc()) {
      $navbar_role_name = $rowRole['name'];
      $_SESSION['role_name'] = $navbar_role_name; // Cache it
    }
    $stmtRole->close();
  }
}
$navbar_role_name = $navbar_role_name ?: 'ADMIN';
$navbar_user_id = (int) ($_SESSION['user_id'] ?? 0);
$navbar_employee = null;
if ($navbar_user_id > 0) {
  $photoTable = $conn->query("SHOW TABLES LIKE 'employee_documents'");
  $profileTable = $conn->query("SHOW TABLES LIKE 'hr_employee_profiles'");
  $hasProfileTable = $profileTable && $profileTable->num_rows > 0;
  $middleNameColumn = $hasProfileTable ? $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'middle_name'") : false;
  $middleNameSelect = $middleNameColumn && $middleNameColumn->num_rows > 0 ? 'profile.middle_name' : 'NULL';
  $photoSelect = $photoTable && $photoTable->num_rows > 0
    ? "(SELECT document.id FROM employee_documents document
        WHERE document.employee_id = employee.id AND document.document_type = 'profile_photo'
          AND document.status = 1 AND document.deleted_at IS NULL
        ORDER BY document.id DESC LIMIT 1)"
    : 'NULL';
  $profileJoin = $hasProfileTable ? 'LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id' : '';
  $companySource = $hasProfileTable ? 'COALESCE(profile.company_id, user.company_id, legacy_company.id)' : 'COALESCE(user.company_id, legacy_company.id)';
  $branchSource = $hasProfileTable ? 'COALESCE(profile.branch_id, user.branch_id)' : 'user.branch_id';
  $stmtProfile = $conn->prepare(
    "SELECT user.email, employee.id AS employee_id, employee.emp_code, employee.first_name, {$middleNameSelect} AS middle_name,
            employee.last_name, employee.contact_no, company.company_name, branch.branch_name,
            {$photoSelect} AS profile_photo_id
     FROM users user
     LEFT JOIN employees employee ON employee.id = (
       SELECT MAX(linked.id) FROM employees linked
       WHERE linked.user_id = user.id AND linked.deleted_at IS NULL AND linked.status != 3
     )
    {$profileJoin}
     LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
    LEFT JOIN erp_companies company ON company.id = {$companySource} AND company.deleted_at IS NULL
    LEFT JOIN erp_branches branch ON branch.id = {$branchSource} AND branch.deleted_at IS NULL
     WHERE user.id = ? AND user.deleted_at IS NULL LIMIT 1"
  );
  if ($stmtProfile) {
    $stmtProfile->bind_param('i', $navbar_user_id);
    $stmtProfile->execute();
    $navbar_employee = $stmtProfile->get_result()->fetch_assoc() ?: null;
    $stmtProfile->close();
  }
}
$navbar_display_name = trim((string) (($navbar_employee['first_name'] ?? '') . ' ' . ($navbar_employee['middle_name'] ?? '') . ' ' . ($navbar_employee['last_name'] ?? '')))
  ?: (string) ($_SESSION['user_name'] ?? 'User');
$navbar_email = (string) ($navbar_employee['email'] ?? $_SESSION['user_email'] ?? '');
$navbar_employee_code = trim((string) ($navbar_employee['emp_code'] ?? '')) ?: 'USR-' . str_pad((string) $navbar_user_id, 4, '0', STR_PAD_LEFT);
$navbar_claim_href = !empty($navbar_employee['employee_id'])
  ? 'index.php?page=employee-profile&amp;open=claim-reimbursement'
  : (canDoThis('payroll_reimbursements_view') ? 'index.php?page=payroll-reimbursements' : '');
$navbar_initials = strtoupper(substr((string) ($navbar_employee['first_name'] ?? $navbar_display_name), 0, 1)
  . substr((string) ($navbar_employee['last_name'] ?? ''), 0, 1));
$navbar_initials = $navbar_initials ?: 'U';
?>
<nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
  id="layout-navbar">

  <!-- Mobile menu toggle -->
  <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
    <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
      <i class="ti ti-menu-2 ti-sm"></i>
    </a>
  </div>

  <!-- Logo in navbar (Biogenix style) -->
  <a href="index.php" class="biogenix-navbar-brand text-decoration-none">
    <span class="biogenix-navbar-logo-appearance" aria-label="Biogenix ERP"
      style="--navbar-logo-image: url('<?= asset('assets/img/biogenix-navbar-profile-logo.png') ?>');"></span>
  </a>

  <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

    <ul class="navbar-nav flex-row align-items-center ms-auto" style="gap: 0.5rem;">

      <!-- User Info (right-aligned, Biogenix Style) -->
      <li class="nav-item d-none d-md-flex align-items-center me-2">
        <span class="biogenix-user-name-label"><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?>
          (<?= strtoupper(htmlspecialchars($navbar_role_name)) ?>)</span>
      </li>

      <!-- Dashboard Button -->
      <!--
      <li class="nav-item d-none d-sm-flex">
        <a href="index.php?page=dashboard" class="biogenix-nav-btn-dashboard">Dashboard</a>
      </li>
      -->



      <!-- User Profile Dropdown -->
      <li class="nav-item navbar-dropdown dropdown-user dropdown">
        <a href="javascript:void(0);" class="biogenix-nav-btn-icon dropdown-toggle hide-arrow p-0 border-0 bg-transparent" data-bs-toggle="dropdown"
          data-bs-auto-close="outside" aria-expanded="false" title="My Profile">
          <?php if (!empty($navbar_employee['profile_photo_id'])): ?>
            <img src="hrms-document.php?id=<?= (int) $navbar_employee['profile_photo_id'] ?>" alt="Open profile settings" class="rounded-circle shadow-sm"
              style="width:36px;height:36px;object-fit:cover;border:2px solid #e2e8f0;" />
          <?php else: ?>
            <span class="avatar-initial rounded-circle bg-label-primary fw-bold d-inline-flex align-items-center justify-content-center shadow-sm"
              style="width:36px;height:36px;font-size:.8rem;border:2px solid #e2e8f0;"><?= htmlspecialchars($navbar_initials) ?></span>
          <?php endif; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-end mt-2 p-2 border-0 shadow-lg"
          style="min-width: 320px; max-width: 340px; border-radius: 1rem; background-color: #f1f5f9; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15), 0 10px 10px -5px rgba(0, 0, 0, 0.04); font-family: 'Public Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
          
          <!-- 1. Header User Card -->
          <div class="mb-2">
            <div class="rounded-3 overflow-hidden shadow-sm" style="border: 1px solid #cbd5e1;">
              <!-- Navy Blue Header Box -->
              <div class="p-3 text-white position-relative" style="background: linear-gradient(135deg, #1b355e 0%, #22427a 100%);">
                <!-- Close Button -->
                <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-2.5" style="font-size: 0.65rem; opacity: 0.75;" onclick="bootstrap.Dropdown.getInstance(document.querySelector('.dropdown-user .dropdown-toggle'))?.hide();" aria-label="Close"></button>
                
                <div class="d-flex align-items-center gap-3 pe-3">
                  <!-- Avatar -->
                  <div class="flex-shrink-0">
                    <?php if (!empty($navbar_employee['profile_photo_id'])): ?>
                      <img src="hrms-document.php?id=<?= (int) $navbar_employee['profile_photo_id'] ?>" alt="Profile photo" class="rounded-circle border border-2 border-white shadow-sm"
                        style="width: 56px; height: 56px; object-fit: cover;" />
                    <?php else: ?>
                      <span class="avatar-initial rounded-circle bg-white fw-bold d-inline-flex align-items-center justify-content-center shadow-sm"
                        style="width: 56px; height: 56px; font-size: 1.25rem; color: #1b355e !important;"><?= htmlspecialchars($navbar_initials) ?></span>
                    <?php endif; ?>
                  </div>
                  <!-- User Information -->
                  <div class="flex-grow-1 min-w-0" style="line-height: 1.3;">
                    <div class="fw-bold text-white text-truncate" style="font-size: 0.98rem;" title="<?= htmlspecialchars($navbar_display_name) ?>">
                      <?= htmlspecialchars($navbar_display_name) ?>
                    </div>
                    <div class="text-white-50 text-truncate" style="font-size: 0.8rem; opacity: 0.9;" title="<?= htmlspecialchars($navbar_email) ?>">
                      <?= htmlspecialchars($navbar_email ?: 'Email not provided') ?>
                    </div>
                    <div class="d-flex align-items-center gap-1 text-white-50 mt-1" style="font-size: 0.73rem; opacity: 0.85;">
                      <span>User Id: <?= htmlspecialchars($navbar_employee_code) ?></span>
                      <i class="ti ti-info-circle" style="font-size: 0.8rem; cursor: help;" title="Employee ID: <?= htmlspecialchars($navbar_employee_code) ?>"></i>
                    </div>
                    <div class="text-white-50 text-truncate mt-0.5" style="font-size: 0.73rem; opacity: 0.85;" title="<?= htmlspecialchars(($navbar_employee['company_name'] ?? 'Biogenix Inc Pvt Ltd.') . (!empty($navbar_employee['branch_name']) ? ' · ' . $navbar_employee['branch_name'] : '')) ?>">
                      My Organization : <?= htmlspecialchars($navbar_employee['company_name'] ?? 'Biogenix Inc Pvt Ltd.') ?><?= !empty($navbar_employee['branch_name']) ? ' (' . htmlspecialchars($navbar_employee['branch_name']) . ')' : '' ?>
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Sub-Bar: My Account & Sign Out -->
              <div class="bg-white px-3 py-2 d-flex justify-content-between align-items-center border-top border-slate-100">
                <a href="index.php?page=profile" class="fw-bold text-decoration-none d-inline-flex align-items-center" style="color: #2563eb; font-size: 0.85rem;">
                  My Account
                </a>
                <a href="<?= asset('./index.php') ?>" class="fw-bold text-decoration-none d-inline-flex align-items-center gap-1" style="color: #dc2626; font-size: 0.85rem;">
                  <i class="ti ti-power" style="font-size: 1rem;"></i> <span>Sign Out</span>
                </a>
              </div>
            </div>
          </div>
          <!-- 2. Remote Work / Leave & Status Card -->
          <div class="mb-2">
            <div class="bg-white rounded-3 p-2.5 shadow-sm border border-slate-200">
              <div class="d-flex justify-content-between align-items-center pb-2">
                <div class="d-flex align-items-center gap-2" style="font-size: 0.82rem;">
                  <a href="index.php?page=leave-management&amp;open=apply-leave" class="fw-bold text-decoration-none" style="color: #2563eb;">Apply Leave</a>
                  <span class="text-slate-300">|</span>
                  <span class="fw-bold text-slate-800">Remote Work</span>
                </div>
                <div class="form-check form-switch m-0 p-0 d-flex align-items-center">
                  <input class="form-check-input ms-0" type="checkbox" role="switch" id="navbarRemoteWorkSwitch" style="cursor: pointer; width: 34px; height: 18px;">
                </div>
              </div>

              <!-- Unified Status Selector with Live Color Dot -->
              <div class="dropdown pt-1">
                <div class="d-flex align-items-center gap-2" style="cursor: pointer;" data-bs-toggle="dropdown" aria-expanded="false" id="navbarStatusSelectorWrapper">
                  <!-- Left Color Indicator Box -->
                  <div class="btn btn-sm btn-light border border-slate-200 px-2 py-1 d-flex align-items-center gap-1.5 rounded-2 flex-shrink-0" style="height: 34px;">
                    <span id="navbarStatusDot" class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #10b981; transition: background-color 0.2s ease;"></span>
                    <i class="ti ti-chevron-down text-slate-400" style="font-size: 0.7rem;"></i>
                  </div>
                  <!-- Right Status Label Box -->
                  <div class="btn btn-sm btn-light border border-slate-200 px-3 py-1 flex-grow-1 d-flex justify-content-between align-items-center rounded-2 text-slate-700 fw-medium" style="height: 34px; font-size: 0.82rem;">
                    <span id="navbarUserStatusText">Available</span>
                    <i class="ti ti-chevron-down text-slate-400" style="font-size: 0.75rem;"></i>
                  </div>
                </div>
                <ul class="dropdown-menu w-100 py-1 shadow-sm border border-slate-200" style="font-size: 0.82rem; min-width: 200px;">
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="Available" data-color="#10b981">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #10b981;"></span>
                      <span class="fw-medium">Available</span>
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="In a Meeting" data-color="#ef4444">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #ef4444;"></span>
                      <span class="fw-medium">In a Meeting</span>
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="Busy" data-color="#f59e0b">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #f59e0b;"></span>
                      <span class="fw-medium">Busy</span>
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="Do Not Disturb" data-color="#dc2626">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #dc2626;"></span>
                      <span class="fw-medium">Do Not Disturb</span>
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="Working Remotely" data-color="#3b82f6">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #3b82f6;"></span>
                      <span class="fw-medium">Working Remotely</span>
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="On Break" data-color="#eab308">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #eab308;"></span>
                      <span class="fw-medium">On Break</span>
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item py-1.5 d-flex align-items-center gap-2.5 user-status-item" href="javascript:void(0);" data-status="Offline" data-color="#94a3b8">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: #94a3b8;"></span>
                      <span class="fw-medium">Offline</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <!-- 3. Quick Actions / Links Card -->
          <div>
            <div class="bg-white rounded-3 p-2.5 shadow-sm border border-slate-200">
              <div class="fw-bold text-slate-900 mb-2" style="font-size: 0.85rem;">
                Biogenix Hub
              </div>
              <div class="row g-1">
                <?php if ($navbar_claim_href !== ''): ?>
                <div class="col-6">
                  <a href="<?= $navbar_claim_href ?>" class="dropdown-item rounded-2 py-1 px-2 d-flex align-items-center gap-2 text-slate-700 hover:text-primary transition-colors" style="font-size: 0.78rem; font-weight: 500;">
                    <i class="ti ti-file-text text-slate-400" style="font-size: 0.95rem;"></i>
                    <span class="text-truncate">Claim Reimbursement</span>
                  </a>
                </div>
                <?php endif; ?>
                <div class="col-6">
                  <a href="index.php?page=account-settings" class="dropdown-item rounded-2 py-1 px-2 d-flex align-items-center gap-2 text-slate-700 hover:text-primary transition-colors" style="font-size: 0.78rem; font-weight: 500;">
                    <i class="ti ti-shield-lock text-slate-400" style="font-size: 0.95rem;"></i>
                    <span class="text-truncate">Password & Security</span>
                  </a>
                </div>
                <div class="col-6">
                  <a href="index.php?page=appearance" class="dropdown-item rounded-2 py-1 px-2 d-flex align-items-center gap-2 text-slate-700 hover:text-primary transition-colors" style="font-size: 0.78rem; font-weight: 500;">
                    <i class="ti ti-palette text-slate-400" style="font-size: 0.95rem;"></i>
                    <span class="text-truncate">Appearance</span>
                  </a>
                </div>
                <div class="col-6">
                  <a href="index.php?page=salary-account" class="dropdown-item rounded-2 py-1 px-2 d-flex align-items-center gap-2 text-slate-700 hover:text-primary transition-colors" style="font-size: 0.78rem; font-weight: 500;">
                    <i class="ti ti-wallet text-slate-400" style="font-size: 0.95rem;"></i>
                    <span class="text-truncate">Salary Account</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </li>

      <!-- Notification Bell -->
      <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-0">
        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown"
          data-bs-auto-close="outside" aria-expanded="false">
          <i class="ti ti-bell ti-md"></i>
          <span class="badge bg-danger rounded-pill badge-notifications">0</span>
        </a>

        <ul class="dropdown-menu dropdown-menu-end py-0">
          <!-- Header -->
          <li class="dropdown-menu-header border-bottom">
            <div class="dropdown-header d-flex align-items-center py-3">
              <h5 class="text-body mb-0 me-auto">Notification</h5>
              <a href="javascript:void(0)" class="dropdown-notifications-all text-body cursor-pointer" onclick="markAllNotificationsAsRead(event)" data-bs-toggle="tooltip"
                data-bs-placement="top" title="Mark all as read">
                <i class="ti ti-mail-opened fs-4"></i>
              </a>
            </div>
          </li>

          <!-- Notifications Container (Dynamic Content) -->
          <li class="dropdown-notifications-list scrollable-container">
            <ul class="list-group list-group-flush">
              <!-- AJAX se yahan notifications inject hongi -->
            </ul>
          </li>

          <!-- Footer -->
          <li class="dropdown-menu-footer border-top" id="loadMoreNotificationsList">
            <a class="dropdown-item d-flex justify-content-center btn-primary text-white p-2 h-px-40 mb-1 align-items-center cursor-pointer"
              id="loadMoreNotifications" onclick="loadNotifications(true)">
              <span class="btn-text">Load More</span>

              <span class="btn-loader d-none ms-2">
                <span class="spinner-border spinner-border-sm text-white"></span>
              </span>
            </a>
          </li>
        </ul>
      </li>

      <!--/ Notification -->
    </ul>
  </div>

  <!-- Search Small Screens -->
  <div class="navbar-search-wrapper search-input-wrapper d-none">
    <input type="text" class="form-control search-input container-xxl border-0" placeholder="Search..."
      aria-label="Search..." />
    <i class="ti ti-x ti-sm search-toggler cursor-pointer"></i>
  </div>
</nav>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const statusItems = document.querySelectorAll('.user-status-item');
  const statusText = document.getElementById('navbarUserStatusText');
  const statusDot = document.getElementById('navbarStatusDot');
  const remoteSwitch = document.getElementById('navbarRemoteWorkSwitch');

  function updatePresence(name, color) {
    if (statusText) statusText.textContent = name;
    if (statusDot) statusDot.style.backgroundColor = color;
    try {
      localStorage.setItem('user_presence_status', JSON.stringify({ name: name, color: color }));
    } catch (e) {}
  }

  // Restore presence on page load
  try {
    const saved = localStorage.getItem('user_presence_status');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.name && parsed.color) {
        updatePresence(parsed.name, parsed.color);
        if (remoteSwitch) {
          remoteSwitch.checked = (parsed.name === 'Working Remotely');
        }
      }
    }
  } catch (e) {}

  statusItems.forEach(function(item) {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const name = this.getAttribute('data-status') || 'Available';
      const color = this.getAttribute('data-color') || '#10b981';
      updatePresence(name, color);
      if (remoteSwitch) {
        remoteSwitch.checked = (name === 'Working Remotely');
      }
    });
  });

  if (remoteSwitch) {
    remoteSwitch.addEventListener('change', function() {
      if (this.checked) {
        updatePresence('Working Remotely', '#3b82f6');
      } else {
        updatePresence('Available', '#10b981');
      }
    });
  }
});
</script>
