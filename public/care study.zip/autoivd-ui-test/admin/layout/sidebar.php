<?php
global $conn;


$dbFile = __DIR__ . '/../db.php';
if (file_exists($dbFile) && is_readable($dbFile)) {
    require_once $dbFile;
} else {
    die("Critical error: Database config missing.");
}

// Load helper functions
$funcFile = __DIR__ . '/../functions.php';
if (file_exists($funcFile) && is_readable($funcFile)) {
    require_once $funcFile;
} else {
    die("Critical error: Helper functions missing.");
}

// Verify function and proceed
if (!function_exists('getUserMenus')) {
    die("Critical error: getUserMenus() not defined.");
}

// At this point, it's safe to use $conn and getUserMenus()

$allMenus = getUserMenus($conn);
$pageRaw = $_GET['page'] ?? '';
$currentPage = htmlspecialchars(strip_tags($pageRaw), ENT_QUOTES, 'UTF-8') ?: 'dashboard';
$crmPendingLeadCount = 0;
$crmLeadTable = $conn->query("SHOW TABLES LIKE 'crm_leads'");
if ($crmLeadTable && $crmLeadTable->num_rows === 1) {
    $crmLeadCountResult = $conn->query(
        "SELECT COUNT(*) AS total FROM crm_leads
         WHERE acceptance_status = 'Pending' AND deleted_at IS NULL"
    );
    if ($crmLeadCountResult) {
        $crmPendingLeadCount = (int) ($crmLeadCountResult->fetch_assoc()['total'] ?? 0);
    }
}

// Keep the already-built sync screens under the existing Sync submenu before
// the additive menu migration is deployed. Database menu rows take precedence.
$syncParentId = null;
foreach ($allMenus as $menu) {
    $menuName = strtolower(trim((string) ($menu['name'] ?? '')));
    $menuRoute = trim((string) ($menu['route'] ?? ''));
    if ($menuName === 'sync' || $menuRoute === 'index.php?page=sync') {
        $syncParentId = (int) $menu['id'];
        break;
    }
}

if ($syncParentId) {
    $syncMenuMigrationReady = false;
    $syncMenuCheck = $conn->prepare(
        "SELECT 1 FROM `menus`
         WHERE `parent_id` = ? AND `route` = 'index.php?page=sync' AND `status` != 3
         LIMIT 1"
    );
    if ($syncMenuCheck) {
        $syncMenuCheck->bind_param('i', $syncParentId);
        $syncMenuCheck->execute();
        $syncMenuMigrationReady = $syncMenuCheck->get_result()->num_rows > 0;
        $syncMenuCheck->close();
    }

    if (! $syncMenuMigrationReady) {
    $existingRoutes = array_column($allMenus, 'route');
    $syncFallbackItems = [
        ['name' => 'Sync Dashboard', 'route' => 'index.php?page=sync', 'icon' => 'ti ti-refresh'],
        ['name' => 'Customer Management', 'route' => 'index.php?page=customer-management', 'icon' => 'ti ti-users'],
        ['name' => 'Meeting Requests', 'route' => 'index.php?page=meeting-requests', 'icon' => 'ti ti-calendar-event'],
        ['name' => 'Quiz Activity Feed', 'route' => 'index.php?page=quiz-activity-feed', 'icon' => 'ti ti-help-circle'],
    ];

    foreach ($syncFallbackItems as $index => $fallback) {
        if (in_array($fallback['route'], $existingRoutes, true)
            && $fallback['route'] !== 'index.php?page=sync') {
            continue;
        }
        $hasDatabaseChild = false;
        foreach ($allMenus as $candidate) {
            if ((int) ($candidate['parent_id'] ?? 0) === $syncParentId
                && ($candidate['route'] ?? '') === $fallback['route']) {
                $hasDatabaseChild = true;
                break;
            }
        }
        if ($hasDatabaseChild) {
            continue;
        }

        $allMenus[] = [
            'id' => -1000 - $index,
            'name' => $fallback['name'],
            'route' => $fallback['route'],
            'icon' => $fallback['icon'],
            'parent_id' => $syncParentId,
            'sort_order' => ($index + 1) * 10,
            'permission_slug' => null,
            'showmenu' => 1,
            'status' => 1,
        ];
    }
    }
}

// 2. Build the menu tree grouped by parent_id (root = 0)
$menuTree = [];
foreach ($allMenus as $menu) {
    $parentId = $menu['parent_id'] ? (int) $menu['parent_id'] : 0;
    $menuTree[$parentId][] = $menu;
}

// 3. Sort each menu level by sort_order
foreach ($menuTree as &$siblings) {
    usort($siblings, fn($a, $b) => $a['sort_order'] <=> $b['sort_order']);
}
unset($siblings);

if (!function_exists('menuIconClasses')) {
    function menuIconClasses($icon)
    {
        $classes = preg_split('/\s+/', trim((string) $icon), -1, PREG_SPLIT_NO_EMPTY);
        if (!$classes) {
            return '';
        }

        $hasTablerIcon = false;
        $hasTablerBase = false;
        $hasFontAwesomeBase = false;

        foreach ($classes as $class) {
            if ($class === 'ti') {
                $hasTablerBase = true;
            } elseif (str_starts_with($class, 'ti-')) {
                $hasTablerIcon = true;
            } elseif (in_array($class, ['fa', 'fas', 'far', 'fal', 'fab'], true)) {
                $hasFontAwesomeBase = true;
            }
        }

        if ($hasTablerIcon && !$hasTablerBase && !$hasFontAwesomeBase) {
            array_unshift($classes, 'ti');
        }

        return htmlspecialchars(implode(' ', array_unique($classes)), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('fallbackMenuIcon')) {
    function fallbackMenuIcon($menu)
    {
    $name = strtolower(trim((string) ($menu['name'] ?? '')));
    $route = strtolower(trim((string) ($menu['route'] ?? '')));
    $routePage = '';

    if ($route !== '' && $route !== '#' && !str_starts_with($route, 'javascript:')) {
        if (str_contains($route, 'page=')) {
            parse_str(parse_url($route, PHP_URL_QUERY) ?: '', $query);
            $routePage = strtolower(trim((string) ($query['page'] ?? '')));
        } else {
            $routePage = strtolower(pathinfo($route, PATHINFO_FILENAME));
        }
    }

    $key = $routePage ?: $name;
    $icons = [
        'role-has-permissions' => 'fas fa-user-shield',
        'rolewise-permissions' => 'fas fa-user-shield',
        'rolewise permissions' => 'fas fa-user-shield',
        'menus' => 'fas fa-list-ul',
        'list-of-menus' => 'fas fa-list-ul',
        'list of menu(s)' => 'fas fa-list-ul',
        'coa-templates' => 'fas fa-file-signature',
        'c.o.a templates' => 'fas fa-file-signature',
        'production-plan' => 'fas fa-clipboard-list',
        'purchase-management' => 'fas fa-cart-shopping',
        'final-purchase-orders' => 'fas fa-file-invoice',
        'qa & qc' => 'fas fa-microscope',
        'qa-qc' => 'fas fa-microscope',
        'qa_qc' => 'fas fa-microscope',
        'qaandqc' => 'fas fa-microscope',
        'purchase-order-raw' => 'fas fa-file-pdf',
        'rapid' => 'fas fa-flask',
        'rapid-create' => 'fas fa-plus-square',
        'rapid-show' => 'fas fa-eye',
        'view rapid' => 'fas fa-eye',
        'transfer-ticket' => 'fas fa-right-left',
        'material-requisition' => 'fas fa-boxes-stacked',
        'daily-production-report-bseh' => 'fas fa-clipboard-check',
        'ip-coa-generation' => 'fas fa-certificate',
        'fg-coa-generation' => 'fas fa-file-circle-check',
        'raw-material-packing-material' => 'fas fa-file-medical',
        'sa-generation' => 'fas fa-vial-circle-check',
        'coa-generation' => 'fas fa-certificate',
        'products' => 'fas fa-box-open',
        'order-received' => 'fas fa-receipt',
        'stock-inwards' => 'fas fa-truck-loading',
        'material-request' => 'fas fa-boxes-packing',
        'low-stocks' => 'fas fa-cart-arrow-down',
        'stock-outwards' => 'fas fa-truck',
        'goods-issuance' => 'fas fa-dolly',
        'store-setting' => 'fas fa-gear',
        'settings' => 'fas fa-gear',
        'employees' => 'fas fa-users',
        'payroll-manual' => 'fas fa-money-check-dollar',
        'attendance-summary' => 'fas fa-calendar-check',
        'advance-salary' => 'fas fa-hand-holding-dollar',
        'pi-generator' => 'fas fa-file-invoice-dollar',
        'daily report (rapid)' => 'fas fa-flask',
        'create report (rapid)' => 'fas fa-plus-square',
        'transfer ticket' => 'fas fa-right-left',
        'material requisition' => 'fas fa-boxes-stacked',
        'daily report (b.s.e.h)' => 'fas fa-clipboard-check',
        'ip coa generation' => 'fas fa-certificate',
        'fg coa generation' => 'fas fa-file-circle-check',
        'c.o.a # generation' => 'fas fa-file-medical',
        's.a generation' => 'fas fa-vial-circle-check',
        'c.o.a generation' => 'fas fa-certificate',
        'list of products' => 'fas fa-box-open',
        'order management' => 'fas fa-receipt',
        'goods received' => 'fas fa-truck-loading',
        'purchase request form' => 'fas fa-cart-arrow-down',
        'goods dispatched' => 'fas fa-truck',
        'good issuance' => 'fas fa-dolly',
        'list of employees' => 'fas fa-users',
        'payroll manual' => 'fas fa-money-check-dollar',
        'attendance summary' => 'fas fa-calendar-check',
        'advance salary' => 'fas fa-hand-holding-dollar',
        'pi generator' => 'fas fa-file-invoice-dollar',
        'product-categories' => 'fas fa-layer-group',
        'product categories' => 'fas fa-layer-group',
        'labels' => 'fas fa-tags',
        'custom-import' => 'fas fa-file-import',
        'custom import' => 'fas fa-file-import',
        'tender-dashboard' => 'fas fa-chart-pie',
        'dashboard' => 'fas fa-chart-pie',
        'dasboard' => 'fas fa-chart-pie',
        'tenders' => 'fas fa-file-signature',
        'tender-settings' => 'fas fa-gear',
        'bmr' => 'fas fa-file-medical',
        'bpr' => 'fas fa-file-prescription',
        'production-bmr-bpr' => 'fas fa-file-waveform',
        'bmr/bpr' => 'fas fa-file-waveform',
        'bmr-bpr-form-request' => 'fas fa-file-circle-plus',
        'bmr/bpr form request' => 'fas fa-file-circle-plus',
        'bmr-bpr-issuance' => 'fas fa-file-circle-check',
        'bmr/bpr issuance' => 'fas fa-file-circle-check',
        'template-master' => 'fas fa-file-code',
        'template master' => 'fas fa-file-code',
        'template_master' => 'fas fa-file-code',
        'annual-calendar' => 'fas fa-calendar-days',
        'annual calendar' => 'fas fa-calendar-days',
        'annual calendar & working days' => 'fas fa-calendar-days',
        'company-setup' => 'fas fa-building',
        'company setup' => 'fas fa-building',
        'company-control-room' => 'fas fa-building-shield',
        'company control room' => 'fas fa-building-shield',
        'customer-management' => 'fas fa-address-book',
        'customer management' => 'fas fa-address-book',
        'meeting-requests' => 'fas fa-handshake',
        'meeting requests' => 'fas fa-handshake',
        'pi-requests' => 'fas fa-file-invoice-dollar',
        'pi request' => 'fas fa-file-invoice-dollar',
        'users' => 'fas fa-user-gear',
        'manage users' => 'fas fa-user-gear',
    ];

    return $icons[$key] ?? '';
    }
}

// 4. Recursive function to render menu items
// Helper: check if any descendant of a menu item is the current page
if (!function_exists('hasActiveChild')) {
    function hasActiveChild($menuId, $currentPage, $menuTree)
    {
        if (empty($menuTree[$menuId]))
            return false;
        foreach ($menuTree[$menuId] as $child) {
            $routePage = '';
            if (!empty($child['route'])) {
                if (strpos($child['route'], 'page=') !== false) {
                    parse_str(parse_url($child['route'], PHP_URL_QUERY), $q);
                    $routePage = $q['page'] ?? '';
                } else {
                    $routePage = pathinfo($child['route'], PATHINFO_FILENAME);
                }
            }
            $routePage = htmlspecialchars(strip_tags($routePage), ENT_QUOTES, 'UTF-8');
            if ($routePage === $currentPage)
                return true;
            // Check grandchildren
            if (hasActiveChild($child['id'], $currentPage, $menuTree))
                return true;
        }
        return false;
    }
}

// 4. Recursive function to render menu items
if (!function_exists('renderMenuItems')) {
    function renderMenuItems($items, $currentPage, $menuTree, $depth = 1, $crmPendingLeadCount = 0)
    {
        if ($depth > 3 || !is_array($items))
            return;

        foreach ($items as $menu) {
            // Determine route-based slug for highlighting
            $routePage = '';
            if (!empty($menu['route'])) {
                if (strpos($menu['route'], 'page=') !== false) {
                    parse_str(parse_url($menu['route'], PHP_URL_QUERY), $q);
                    $routePage = $q['page'] ?? '';
                } else {
                    $routePage = pathinfo($menu['route'], PATHINFO_FILENAME);
                }
            }
            $routePage = htmlspecialchars(strip_tags($routePage), ENT_QUOTES, 'UTF-8');

            $isActive = ($routePage === $currentPage);
            $hasChildren = !empty($menuTree[$menu['id']]);

            // Only add 'open' class if this parent contains the active child page
            $isOpen = $hasChildren && hasActiveChild($menu['id'], $currentPage, $menuTree);

            $liClass = 'menu-item'
                . ($isActive ? ' active' : '')
                . ($isOpen ? ' open' : '');
            echo "<li class='{$liClass}'>";

            $menuTitle = htmlspecialchars($menu['name'], ENT_QUOTES, 'UTF-8');
            $linkAttrs = $hasChildren
                ? "href='javascript:void(0);' class='menu-link menu-toggle' title='{$menuTitle}' aria-label='{$menuTitle}'"
                : "href='" . htmlspecialchars($menu['route'] ?: '#', ENT_QUOTES, 'UTF-8') . "' class='menu-link' title='{$menuTitle}' aria-label='{$menuTitle}'";
            echo "<a {$linkAttrs}>";

            // Always render an icon — use a default bullet icon for sub-items without one
            $fallbackIcon = fallbackMenuIcon($menu);

            if (!empty($menu['icon'])) {
                echo "<i class='menu-icon tf-icons "
                    . menuIconClasses($menu['icon'])
                    . "'></i>";
            } elseif ($fallbackIcon !== '') {
                echo "<i class='menu-icon tf-icons "
                    . menuIconClasses($fallbackIcon)
                    . "'></i>";
            } elseif ($depth > 1) {
                echo "<i class='menu-icon tf-icons ti ti-point'></i>";
            }

            echo "<div data-i18n='"
                . htmlspecialchars($menu['name'], ENT_QUOTES, 'UTF-8')
                . "'>"
                . htmlspecialchars($menu['name'], ENT_QUOTES, 'UTF-8')
                . "</div>";

            if ($routePage === 'lead-management' && $crmPendingLeadCount > 0) {
                $leadCountLabel = $crmPendingLeadCount > 99 ? '99+' : (string) $crmPendingLeadCount;
                echo "<span class='badge bg-danger rounded-pill ms-auto' title='Pending incoming leads'>"
                    . htmlspecialchars($leadCountLabel, ENT_QUOTES, 'UTF-8')
                    . "</span>";
            }

            if ($hasChildren) {
                echo "<i class='ti ti-chevron-right menu-caret'></i>";
            }
            echo "</a>";

            if ($hasChildren) {
                echo "<ul class='menu-sub'>";
                renderMenuItems($menuTree[$menu['id']], $currentPage, $menuTree, $depth + 1, $crmPendingLeadCount);
                echo "</ul>";
            }

            echo "</li>";
        }
    }
}


?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <button type="button" id="biogenixSidebarToggle" class="biogenix-sidebar-toggle" aria-label="Collapse sidebar"
        aria-expanded="true">
        <i class="ti ti-chevron-left"></i>
    </button>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">

        <?php
        if (!empty($menuTree[0])) {

            renderMenuItems($menuTree[0], $currentPage, $menuTree, 1, $crmPendingLeadCount);
        } else {
            echo "<li class='menu-item'><a class='menu-link'>No Menu Found</a></li>";
        }
        ?>
        <li class="menu-item">
            <a href="../logout.php" class="menu-link" title="Logout" aria-label="Logout">
                <i class="menu-icon tf-icons ti ti-logout"></i>
                <div data-i18n="Logout">Logout</div>
            </a>
        </li>
    </ul>
</aside>
