<?php
require_once __DIR__ . '/../common/Time.php';
mvConfigurePhpTimezone();
global $conn;
$appearanceSettings = getUserAppearanceSettings($conn, (int) ($_SESSION['user_id'] ?? 0));
$appearanceAccent = htmlspecialchars($appearanceSettings['accent_color'], ENT_QUOTES, 'UTF-8');
?>
<html
  lang="en"
  data-appearance-theme="<?= htmlspecialchars($appearanceSettings['theme_mode'], ENT_QUOTES, 'UTF-8') ?>"
  data-appearance-font="<?= htmlspecialchars($appearanceSettings['font_family'], ENT_QUOTES, 'UTF-8') ?>"
  style="font-size: <?= (int) $appearanceSettings['base_font_size'] ?>px !important; --appearance-accent: <?= $appearanceAccent ?>; --color-primary-50: color-mix(in srgb, <?= $appearanceAccent ?> 8%, #ffffff); --color-primary-100: color-mix(in srgb, <?= $appearanceAccent ?> 18%, #ffffff); --color-primary-200: color-mix(in srgb, <?= $appearanceAccent ?> 32%, #ffffff); --color-primary-500: color-mix(in srgb, <?= $appearanceAccent ?> 88%, #ffffff); --color-primary-600: <?= $appearanceAccent ?>; --color-primary-700: color-mix(in srgb, <?= $appearanceAccent ?> 78%, #000000); --color-primary-800: color-mix(in srgb, <?= $appearanceAccent ?> 60%, #000000); --color-primary-900: color-mix(in srgb, <?= $appearanceAccent ?> 42%, #000000); --ui-base-font-size: <?= (int) $appearanceSettings['base_font_size'] ?>px;">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title><?= $pageTitle ?? env('APP_NAME', 'AutoIVD') ?></title>

  <meta name="description" content="" />
  <meta name="csrf-token" content="<?= $_SESSION['csrf_token'] ?? '' ?>">

  <!-- Favicon -->
  <link rel="icon" type="image/png" sizes="32x32" href="<?= asset('assets/img/favicon/favicon-32x32.png') ?>" />
  <link rel="icon" type="image/png" sizes="16x16" href="<?= asset('assets/img/favicon/favicon-16x16.png') ?>" />
  <link rel="shortcut icon" type="image/x-icon" href="<?= asset('assets/img/favicon/favicon.ico') ?>" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?= asset('assets/img/favicon/apple-touch-icon.png') ?>" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&ampdisplay=swap"
    rel="stylesheet" />
  <link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&family=Roboto:wght@400;500;700&family=Sora:wght@400;500;600;700;800&display=swap"
    rel="stylesheet" />

  <!-- Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/fonts/fontawesome.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/fonts/tabler-icons.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/fonts/flag-icons.css') ?>" />

  <!-- Core CSS (Bootstrap/Template) -->
  <link rel="stylesheet" href="<?= asset('assets/vendor/css/rtl/core.css') ?>" class="template-customizer-core-css" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/css/rtl/theme-default.css') ?>" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="<?= asset('assets/css/demo.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/select2/select2.css') ?>" />

  <!-- Global Tailwind CSS & Theme Setup -->
  <?php $tailwindCssPath = dirname(__DIR__, 2) . '/assets/css/tailwind.css'; ?>
  <?php $themeCssPath = dirname(__DIR__, 2) . '/assets/css/theme.css'; ?>
  <link rel="stylesheet" href="<?= asset('assets/css/tailwind.css') ?>?v=<?= time() ?>" />
  <link rel="stylesheet" href="<?= asset('assets/css/theme.css') ?>?v=<?= time() ?>" />
  <link rel="stylesheet" href="<?= asset('assets/css/issue-3-fixes.css') ?>?v=<?= time() ?>" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/node-waves/node-waves.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/typeahead-js/typeahead.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/apex-charts/apex-charts.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/swiper/swiper.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css') ?>" />
  <!-- Page CSS -->
  <link rel="stylesheet" href="<?= asset('assets/vendor/css/pages/cards-advance.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/toastr/toastr.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/sweetalert2/sweetalert2.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/flatpickr/flatpickr.min.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/spinkit/spinkit.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/css/pages/page-faq.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/css/pages/app-chat.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/libs/fullcalendar/fullcalendar.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/vendor/css/pages/app-calendar.css') ?>" />
  <link rel="stylesheet" href="<?= asset('assets/css/firecracker.css') ?>" />
  <!-- Helpers -->
  <script src="<?= asset('assets/vendor/js/helpers.js') ?>"></script>
  <?php //loadJsConstants(); 
  if (function_exists('loadJsConstants') && !defined('JS_CONSTANTS_LOADED')) {
    define('JS_CONSTANTS_LOADED', true); loadJsConstants();
  }
  ?>
  <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
  <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
  <!-- <script src="../assets/vendor/js/template-customizer.js"></script> -->
  <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
  <script src="<?= asset('assets/js/config.js') ?>"></script>
  <!-- Page-specific styles -->
  <?php yieldSection('styles'); ?>

</head>
