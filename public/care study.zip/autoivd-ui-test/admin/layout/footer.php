<footer class="content-footer footer bg-footer-theme d-none">
  <div class="container-xxl">
    <div
      class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
      <div>
        ©
        <span id="currentYear"></span>
        
        <a href="#" class="footer-link text-primary fw-medium">Biogenix Inc Pvt Ldt</a>. All rights reserved.
        Made with ❤️ by
        <a href="#" class="footer-link text-primary fw-medium">Prateek Kumar Singh</a>
      </div>
      <div class="d-none d-lg-inline-block">
        <a href="#" class="footer-link me-4">License</a>
        <a href="#" class="footer-link me-4">More Themes</a>
        <a
          href="#"
          class="footer-link me-4">Documentation</a>

        <a href="#" class="footer-link d-none d-sm-inline-block">Support</a>
      </div>
    </div>
  </div>
</footer>
<!-- / Footer -->
 <script>
    document.addEventListener("DOMContentLoaded", function() {
      document.getElementById("currentYear").textContent = new Date().getFullYear();
    });
</script> 