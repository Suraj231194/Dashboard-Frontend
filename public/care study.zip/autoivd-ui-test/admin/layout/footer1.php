    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="<?= asset('assets/vendor/libs/jquery/jquery.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/popper/popper.js') ?>"></script>
    <script src="<?= asset('assets/vendor/js/bootstrap.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/node-waves/node-waves.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/hammer/hammer.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/i18n/i18n.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/typeahead-js/typeahead.js') ?>"></script>
    <script src="<?= asset('assets/vendor/js/menu.js') ?>"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?= asset('assets/vendor/libs/apex-charts/apexcharts.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/swiper/swiper.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js') ?>"></script>

    <!-- Main JS -->
    <script src="<?= asset('assets/js/main.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/select2/select2.js') ?>"></script>
    <script src="<?= asset('assets/js/forms-selects.js') ?>?v=<?= time() ?>"></script>

    <!-- Page JS -->
    <script src="<?= asset('assets/vendor/libs/flatpickr/flatpickr.js') ?>"></script>
    <script src="<?= asset('assets/js/dashboards-analytics.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/toastr/toastr.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/sweetalert2/sweetalert2.js') ?>"></script>
    <script src="<?= asset('assets/js/custom-script.js') ?>?v=<?= time() ?>"></script>
    <script src="<?= asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js') ?>"></script>
    <script src="<?= asset('assets/js/firecracker.js') ?>"></script>
    <?php if (defined('HRMS_CONTEXT')): ?>
    <script src="<?= asset('assets/js/hrms-modal-ux.js') ?>?v=<?= time() ?>"></script>
    <?php endif; ?>
    <script id="production-workflow-csrf">
      const productionCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
      $.ajaxPrefilter(function(options) {
        if (!productionCsrfToken || String(options.type || 'GET').toUpperCase() !== 'POST') return;
        let target;
        try {
          target = new URL(options.url, document.baseURI);
        } catch (error) {
          return;
        }
        if (target.origin !== window.location.origin || !target.pathname.endsWith('/ajax.php')) return;
        if (options.data instanceof FormData) {
          if (!options.data.has('csrf_token')) options.data.append('csrf_token', productionCsrfToken);
          return;
        }
        if (String(options.contentType || '').includes('application/json')) return;
        const parameters = new URLSearchParams(typeof options.data === 'string'
          ? options.data : $.param(options.data || {}));
        if (!parameters.has('csrf_token')) parameters.set('csrf_token', productionCsrfToken);
        options.data = parameters.toString();
      });
    </script>
    <script id="required-field-markers">
      function markRequiredFields(root) {
        $(root || document).find('[required]').each(function() {
          if (this.type === 'hidden' || this.disabled) return;
          let label = null;
          if (this.id && window.CSS && CSS.escape) {
            label = document.querySelector('label[for="' + CSS.escape(this.id) + '"]');
          }
          if (!label) label = this.closest('label');
          if (!label) label = $(this).closest('div').children('label').get(0);
          if (!label || label.querySelector('.required-marker') || label.textContent.includes('*')) return;
          label.insertAdjacentHTML('beforeend', '<span class="required-marker" aria-hidden="true">*</span>');
        });
      }

      $(function() {
        markRequiredFields(document);
        $(document).on('shown.bs.modal', '.modal', function() { markRequiredFields(this); });
      });
    </script>
    <script>
      let notificationOffset = 0;
      const notificationLimit = 10;

      $(document).ready(function() {

      });

      function loadNotifications(loadMore = false) {
        if (loadMore) {
          $('#loadMoreNotifications')
            .addClass('disabled')
            .css('pointer-events', 'none');

          $('#loadMoreNotifications .btn-text').addClass('d-none');
          $('#loadMoreNotifications .btn-loader').removeClass('d-none');
        }

        $.ajax({
          url: 'notificationajax.php',
          type: 'GET',
          data: {
            notificationListNavbar: 1,
            offset: notificationOffset
          },
          dataType: 'json',
          success: function(res) {
            if (res.unread_count > 0) {
              $('.badge-notifications').text(res.unread_count).show();
            } else {
              $('.badge-notifications').hide();
            }
            let html = '';
            res.notifications.forEach(function(n) {
              let readClass = n.is_read == 1 ? 'marked-as-read' : '';
              let dot = n.is_read == 0 ? '<span class="badge badge-dot"></span>' : '';
              if(n.is_archive == 0)
              {
              html += `<li class="list-group-item list-group-item-action dropdown-notifications-item ${readClass}" data-notification-id="${n.notification_id}">
                          <div class="d-flex">
                              <div class="flex-shrink-0 me-3">
                                  <div class="avatar">
                                      <span class="avatar-initial rounded-circle bg-label-`+APP_CONST['NOTIFIACTION_SEVERITY'][n.severity]['text-class']+`">
                                        <i class="ti ti-bell"></i>
                                      </span>
                                  </div>
                              </div>

                              <div class="flex-grow-1">
                                  <h6 class="mb-1">${n.title}</h6>
                                  <p class="mb-0">${n.message}</p>
                                  <small class="text-muted">${timeAgo(n.created_at)}</small>
                              </div>

                              <div class="flex-shrink-0 dropdown-notifications-actions">
                                  <a href="javascript:void(0)"
                                    class="dropdown-notifications-read"
                                    onclick="markAsRead(${n.notification_id})">
                                    ${dot}
                                  </a>
                                  <a href="javascript:void(0)" class="dropdown-notifications-archive" onclick="markAsArchive(${n.notification_id})"><span class="ti ti-x"></span></a>
                              </div>
                          </div>
                      </li>`;
              }
            });
            if (!loadMore) {
              $('.dropdown-notifications-list .list-group').html(html);
              notificationOffset = notificationLimit;
            } else {
              $('.dropdown-notifications-list .list-group').append(html);
              notificationOffset += notificationLimit;
            }
            if (res.has_more && res.notifications.length > 0) {
              $('#loadMoreNotificationsList').show();
            } else {
              $('#loadMoreNotificationsList').hide();
            }
          },
          complete: function() {
            $('#loadMoreNotifications')
              .removeClass('disabled')
              .css('pointer-events', 'auto');

            $('#loadMoreNotifications .btn-text').removeClass('d-none');
            $('#loadMoreNotifications .btn-loader').addClass('d-none');
          }
        });
      }

      function markAsRead(notificationId) {
        $.post('notificationajax.php', { 'markAsReadNotification':'markAsReadNotification', markAsRead: 1, notification_id: notificationId }, function(res) {
            if(res.success) {
                // Badge & UI update
                $('.dropdown-notifications-item').filter(function() {
                  return $(this).find('.dropdown-notifications-read').attr('onclick').includes(notificationId);
                }).addClass('marked-as-read')
                  .find('.badge-dot').remove();

                // Optional: update unread count
                let count = parseInt($('.badge-notifications').text()) || 0;
                count = Math.max(count - 1, 0);
                if(count > 0) {
                  $('.badge-notifications').text(count);
                } else {
                  $('.badge-notifications').hide();
                }
            }
        }, 'json');
      }

      function markAsArchive(notificationId) {
        $.post('notificationajax.php', { 'markAsArchiveNotification':'markAsArchiveNotification', notification_id: notificationId }, function(res) {
            if(res.success) {
                // Badge & UI update
                // $('.dropdown-notifications-item').filter(function() {
                //   return $(this).find('.dropdown-notifications-read').attr('onclick').includes(notificationId);
                // }).addClass('marked-as-read')
                //   .find('.badge-dot').remove();

                $('.dropdown-notifications-item[data-notification-id="' + notificationId + '"]')
                .slideUp(200, function () {
                  $(this).remove();
                });

                // Optional: update unread count
                let count = parseInt($('.badge-notifications').text()) || 0;
                count = Math.max(count - 1, 0);
                if(count > 0) {
                  $('.badge-notifications').text(count);
                } else {
                  $('.badge-notifications').hide();
                }
            }
        }, 'json');
      }



      function markAllNotificationsAsRead(e) {
        if (e && e.preventDefault) {
          e.preventDefault();
        }
        if (e && e.stopPropagation) {
          e.stopPropagation();
        }
        $.post('notificationajax.php', { 'markAllAsReadNotifications': '1' }, function(res) {
          if (res && res.success) {
            $('.dropdown-notifications-item').addClass('marked-as-read');
            $('.dropdown-notifications-item .badge-dot').remove();
            $('.badge-notifications').text('0').hide();
            if (typeof toastr !== 'undefined') {
              toastr.success(res.message || 'All notifications marked as read');
            }
          }
        }, 'json');
      }

      $(document).on('click', '.dropdown-notifications-all', function(e) {
        markAllNotificationsAsRead(e);
      });

      loadNotifications();
     
    </script>



    <!-- Yield custom scripts -->
    <?php yieldSection('scripts'); ?>

    </body>

    </html>
