<?php
require_once __DIR__ . '/common/Time.php';
mvConfigurePhpTimezone();
if (session_status() === PHP_SESSION_ACTIVE && empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
require_once 'constant.php';

/**
 * Default order for interactive record grids.
 *
 * This is deliberately not a global SQL replacement: callers opt in only for
 * paginated user-facing tables. The schema check keeps legacy tables safe.
 */
function mvRecentFirstOrder(mysqli $conn, string $table, string $alias = ''): string
{
    static $columnsByTable = [];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || ($alias !== '' && !preg_match('/^[A-Za-z0-9_]+$/', $alias))) {
        throw new InvalidArgumentException('Invalid table or alias for recency ordering.');
    }
    if (!isset($columnsByTable[$table])) {
        $columnsByTable[$table] = [];
        $result = $conn->query("SHOW COLUMNS FROM `{$table}`");
        if ($result instanceof mysqli_result) {
            while ($column = $result->fetch_assoc()) {
                $columnsByTable[$table][$column['Field']] = true;
            }
            $result->free();
        }
    }

    $columns = $columnsByTable[$table];
    $prefix = $alias === '' ? '' : "`{$alias}`.";
    if (isset($columns['updated_at'], $columns['created_at'])) {
        return "COALESCE({$prefix}`updated_at`, {$prefix}`created_at`) DESC, {$prefix}`id` DESC";
    }
    if (isset($columns['updated_at'])) {
        return "{$prefix}`updated_at` DESC, {$prefix}`id` DESC";
    }
    if (isset($columns['created_at'])) {
        return "{$prefix}`created_at` DESC, {$prefix}`id` DESC";
    }
    return "{$prefix}`id` DESC";
}

function redirect($url)
{
    header("Location: $url");
    exit;
}

function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

function requireLogin()
{
    if (!isLoggedIn()) {
        redirect('../index.php');
    }
}

// function env($key, $default = null)
// {
//     static $env = null;
//     if ($env === null) {
//         $envPath = __DIR__ . '/../.env';
//         $env = file_exists($envPath) ? parse_ini_file($envPath) : [];
//     }
//     return $env[$key] ?? $default;
// }

function env($key, $default = null)
{
    $constKey = strtoupper($key);
    return defined($constKey) ? constant($constKey) : $default;
}


function asset($path)
{
    return rtrim(env('APP_URL', ''), '/') . '/' . ltrim($path, '/');
}

function getDefaultAppearanceSettings()
{
    return [
        'theme_mode' => 'light',
        'accent_color' => '#1A4D2E',
        'font_family' => 'Manrope',
        'base_font_size' => 15,
    ];
}

function getUserAppearanceSettings(mysqli $conn, int $userId)
{
    $settings = getDefaultAppearanceSettings();

    if ($userId <= 0) {
        return $settings;
    }

    $stmt = $conn->prepare('SELECT theme_mode, accent_color, font_family, base_font_size FROM user_appearance_settings WHERE user_id = ? LIMIT 1');
    if (!$stmt) {
        return $settings;
    }

    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $savedSettings = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    if (!$savedSettings) {
        return $settings;
    }

    $validThemes = ['light', 'dark', 'auto'];
    $validFonts = ['Manrope', 'Inter', 'Roboto'];
    $themeMode = $savedSettings['theme_mode'] ?? '';
    $fontFamily = $savedSettings['font_family'] ?? '';
    $accentColor = $savedSettings['accent_color'] ?? '';
    $fontSize = (int) ($savedSettings['base_font_size'] ?? 0);

    if (in_array($themeMode, $validThemes, true)) {
        $settings['theme_mode'] = $themeMode;
    }
    if (in_array($fontFamily, $validFonts, true)) {
        $settings['font_family'] = $fontFamily;
    }
    if (preg_match('/^#[0-9A-Fa-f]{6}$/', $accentColor)) {
        $settings['accent_color'] = strtoupper($accentColor);
    }
    if ($fontSize >= 12 && $fontSize <= 18) {
        $settings['base_font_size'] = $fontSize;
    }

    return $settings;
}


function render($page, $data = [])
{
    extract($data);

    $base = __DIR__; // directory where this function resides

    include $base . "/layout/header.php";
    echo '<canvas id="firecracker-canvas"></canvas>';
    echo '<div class="layout-wrapper layout-content-navbar"><div class="layout-container">';
    include $base . "/layout/sidebar.php";
    echo '<div class="layout-page">';
    include $base . "/layout/navbar.php";
    echo '<div class="content-wrapper">';
    include $page;
    include $base . "/layout/footer.php";
    echo '<div class="content-backdrop fade"></div></div></div></div><div class="layout-overlay layout-menu-toggle"></div><div class="drag-target"></div></div>';
    include $base . "/layout/footer1.php";
}


// function getUserMenus($conn)
// {
//     $role_id = $_SESSION['role_id'] ?? 0;

//     $sql = "SELECT m.*
//         FROM menus m
//         LEFT JOIN permissions p ON m.permission_slug = p.slug
//         LEFT JOIN role_permissions rp ON rp.permission_id = p.id AND rp.role_id = ? AND rp.status = 1
//         WHERE m.showmenu = 1
//         AND (
//             m.permission_slug IS NULL               -- always allow label/group menus
//             OR rp.permission_id IS NOT NULL         -- allow if permission exists AND is active
//         )
//         ORDER BY m.parent_id, m.sort_order ASC
//     ";

//     $stmt = $conn->prepare($sql);
//     $stmt->bind_param("i", $role_id);
//     $stmt->execute();
//     $result = $stmt->get_result();

//     $menus = [];
//     while ($row = $result->fetch_assoc()) {
//         $menus[] = $row;
//     }

//     return $menus;
// }

function getUserMenus($conn)
{
    $user_id = $_SESSION['user_id'] ?? 0;
    $role_id = $_SESSION['role_id'] ?? 0;

    $sql = "SELECT DISTINCT m.*
    FROM menus m
    LEFT JOIN permissions p ON p.slug = m.permission_slug

    -- Role permission
    LEFT JOIN role_permissions rp 
        ON rp.permission_id = p.id 
        AND rp.role_id = ? 
        AND rp.status = 1

    -- User permission
    LEFT JOIN user_permissions up 
        ON up.permission_id = p.id 
        AND up.user_id = ?

    WHERE m.showmenu = 1
    AND (
        m.permission_slug IS NULL
        OR (
            (up.action = 1)          -- user allow
            OR (up.id IS NULL AND rp.permission_id IS NOT NULL)
        )
    )
    AND (
        up.action IS NULL OR up.action = 1   -- remove DENY menus
    )
    ORDER BY m.parent_id, m.sort_order ASC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $role_id, $user_id);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


// function checkPermission($slug, $conn)
// {
//     $role_id = $_SESSION['role_id'];
//     $stmt = $conn->prepare("SELECT 1 FROM role_permissions rp
//         JOIN permissions p ON rp.permission_id = p.id
//         WHERE rp.status = 1 AND rp.role_id = ? AND p.slug = ?
//     ");
//     $stmt->bind_param("is", $role_id, $slug);
//     $stmt->execute();
//     return $stmt->get_result()->num_rows > 0;
// }

function checkPermission($slug, $conn)
{
    $user_id = $_SESSION['user_id'] ?? 0;
    $role_id = $_SESSION['role_id'] ?? 0;

    // 🔴 STEP 1: User DENY check
    $stmt = $conn->prepare("SELECT 1 
        FROM user_permissions up
        JOIN permissions p ON p.id = up.permission_id
        WHERE up.user_id = ?
        AND p.slug = ?
        AND up.action = 0
        LIMIT 1
    ");
    $stmt->bind_param("is", $user_id, $slug);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return false; // ❌ force deny
    }

    // 🟢 STEP 2: User ALLOW check
    $stmt = $conn->prepare("SELECT 1 
        FROM user_permissions up
        JOIN permissions p ON p.id = up.permission_id
        WHERE up.user_id = ?
        AND p.slug = ?
        AND up.action = 1
        LIMIT 1
    ");
    $stmt->bind_param("is", $user_id, $slug);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return true; // ✅ force allow
    }

    // 🔵 STEP 3: Role permission check
    $stmt = $conn->prepare("SELECT 1 
        FROM role_permissions rp
        JOIN permissions p ON rp.permission_id = p.id
        WHERE rp.status = 1
        AND rp.role_id = ?
        AND p.slug = ?
        LIMIT 1
    ");
    $stmt->bind_param("is", $role_id, $slug);
    $stmt->execute();

    return $stmt->get_result()->num_rows > 0;
}


function checkPageAccess($slug, $conn)
{
    if (!isLoggedIn())
        redirect('../login.php');

    $isAllowed = false;
    if (is_array($slug)) {
        foreach ($slug as $s) {
            if (checkPermission($s, $conn)) {
                $isAllowed = true;
                break;
            }
        }
    } else {
        $isAllowed = checkPermission($slug, $conn);
    }

    if (!$isAllowed) {
        http_response_code(403);
        render(__DIR__ . "/403.php", ['pageTitle' => '403 - Forbidden']);
        exit;
    }
}

function getPermissionSlugForPage($conn, $page)
{
    // Specific multi-permission mapping for unified pages
    if (in_array($page, ['pi-requests', 'pi-generator'], true)) {
        return ['sync_pi_view', 'sales_billing_pi_generate_menu_list', 'sales_billing_pi_generate_view'];
    }
    if ($page === 'employee-master') {
        return ['hrms_employee_master_view', 'hr_employees_menu_list', 'hr_employees_view'];
    }

    $routesToTry = [
        "index.php?page=$page",
        "$page.php"
    ];

    foreach ($routesToTry as $route) {
        $stmt = $conn->prepare("SELECT permission_slug FROM menus WHERE route = ? LIMIT 1");
        $stmt->bind_param("s", $route);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            return $row['permission_slug'];
        }
    }
    error_log("⚠️ No permission slug found for page: $page");
    return null;
}

function createPageStub($page)
{
    $filepath = __DIR__ . "/pages/{$page}.php";

    if (!file_exists($filepath)) {
        $content = "<div class=\"container-xxl flex-grow-1 container-p-y\">\n";
        $content .= "    <h4 class=\"py-3 mb-2\"><span class=\"fw-light\"><?= \$pageTitle ?></span></h4>\n";
        $content .= "    <div class=\"row\">\n";
        $content .= "        <p>This is the {$page} screen.</p>\n";
        $content .= "    </div>\n";
        $content .= "</div>\n\n";

        $content .= "<?php startSection('scripts'); ?>\n";
        $content .= "<script>\n";
        $content .= "    // Write your script here\n";
        $content .= "</script>\n";
        $content .= "<?php endSection(); ?>\n";

        file_put_contents($filepath, $content);
    }
}



// Store page sections
$GLOBALS['__sections'] = [];

function startSection($name)
{
    ob_start();
    $GLOBALS['__current_section'] = $name;
}

function endSection()
{
    $name = $GLOBALS['__current_section'] ?? null;
    if ($name) {
        $GLOBALS['__sections'][$name] = ob_get_clean();
        unset($GLOBALS['__current_section']);
    }
}

function yieldSection($name)
{
    echo $GLOBALS['__sections'][$name] ?? '';
}

function loadJsConstants()
{
    if (!class_exists('Constant')) {
        return;
    }
    $ref = new ReflectionClass('Constant');
    $constants = $ref->getConstants();
    echo '<script>';
    echo 'window.APP_CONST = ' . json_encode($constants, JSON_UNESCAPED_UNICODE) . ';';
    echo '</script>';
}



function generateBatchNumber()
{
    $now = new DateTime();
    $date = $now->format('Ymd');        // e.g., 20250625
    $time = $now->format('His');        // e.g., 144520
    $rand = str_pad(mt_rand(0, 999), 3, '0', STR_PAD_LEFT);  // Always 3 digits
    return "B{$date}_{$time}_{$rand}";  // e.g., B20250625_144520_042
}

// function roleHasPermission($roleId, $permissionSlug)
// {
//     global $conn;
//     $query = "SELECT 1
//         FROM role_permissions rp
//         JOIN permissions p ON rp.permission_id = p.id
//         WHERE rp.status = 1 AND rp.role_id = ? AND p.slug = ?
//         LIMIT 1";

//     $stmt = $conn->prepare($query);
//     $stmt->bind_param("is", $roleId, $permissionSlug);
//     $stmt->execute();

//     $result = $stmt->get_result();

//     return $result->num_rows > 0;
// }

function roleHasPermission($roleId, $permissionSlug)
{
    global $conn;

    static $permissionCache = [];
    $userId = $_SESSION['user_id'] ?? '';
    $cacheKey = $roleId . '_' . $userId . '_' . $permissionSlug;

    if (isset($permissionCache[$cacheKey])) {
        return $permissionCache[$cacheKey];
    }

    if (!empty($userId)) {

        $sql = "SELECT up.action
            FROM user_permissions up
            JOIN permissions p ON p.id = up.permission_id
            WHERE up.user_id = ?
              AND p.slug = ?
            LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $userId, $permissionSlug);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($row = $res->fetch_assoc()) {
            $permissionCache[$cacheKey] = ($row['action'] == 1);
            return $permissionCache[$cacheKey];
        }
    }

    $query = "SELECT 1
        FROM role_permissions rp
        JOIN permissions p ON rp.permission_id = p.id
        WHERE rp.status = 1
          AND rp.role_id = ?
          AND p.slug = ?
        LIMIT 1";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $roleId, $permissionSlug);
    $stmt->execute();
    $result = $stmt->get_result();

    $hasPermission = $result->num_rows > 0;
    $permissionCache[$cacheKey] = $hasPermission;
    return $hasPermission;
}

function canDoThis($permission)
{
    $roleId = (int)($_SESSION['role_id'] ?? 0);
    if (in_array($roleId, [1, 11, 12])) {
        return true;
    }
    if ($permission === 'bom_approval' && $roleId === 8) {
        return true;
    }
    return roleHasPermission($roleId, $permission);
}



// function generateCoaNumber(string $type): string
// {
//     global $conn;
//     $prefix = "BIPL-COA-" . strtoupper($type) . "-";

//     // Get the last number for this type
//     $stmt = $conn->prepare("SELECT `coa_number` FROM `coa_rm_pm_table` WHERE `type` = ? ORDER BY id DESC LIMIT 1");
//     $stmt->bind_param("s", $type);
//     $stmt->execute();
//     $stmt->bind_result($lastCoaNumber);
//     $stmt->fetch();
//     $stmt->close();

//     if ($lastCoaNumber && preg_match('/(\d+)$/', $lastCoaNumber, $matches)) {
//         $nextNumber = intval($matches[1]) + 1;
//     } else {
//         $nextNumber = 25200; // starting number if none exists yet
//     }

//     return $prefix . $nextNumber;
// }

function generateCoaNumber(string $type): string
{
    global $conn;
    $prefix = "BIPL-COA-" . strtoupper($type) . "-";
    $currentYear = date('y');
    $stmt = $conn->prepare("SELECT `coa_number` 
        FROM `coa_rm_pm_table` 
        WHERE type = ? 
        ORDER BY `id` DESC 
        LIMIT 1
    ");
    $stmt->bind_param("s", $type);
    $stmt->execute();
    $stmt->bind_result($lastCoaNumber);
    $stmt->fetch();
    $stmt->close();
    if ($lastCoaNumber && preg_match('/(\d{2})(\d+)$/', $lastCoaNumber, $m)) {
        $lastYear = $m[1];           // e.g. 25
        $lastSeries = intval($m[2]);   // e.g. 299

        if ($lastYear === $currentYear) {
            $nextNumber = intval($lastYear . str_pad($lastSeries + 1, 3, '0', STR_PAD_LEFT));
        } else {
            $nextNumber = intval($currentYear . "001");
        }
    } else {
        $nextNumber = intval($currentYear . "001");
    }
    return $prefix . $nextNumber;
}


function coaRmPmGenerateAndEmail($data)
{
    $googleScriptUrl = 'https://script.google.com/a/macros/biogenix.in/s/AKfycbxU1x01gXS4z-TonaAY9tUF8VpX1hV686WzVvnw2JW1Y86fdvzjWbyksZUTxHKzqp5f/exec';

    $ch = curl_init($googleScriptUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $curlError = curl_error($ch);
    curl_close($ch);
    if ($curlError) {
        echo json_encode([
            'status' => 'error',
            'message' => 'cURL error: ' . $curlError
        ]);
        exit;
    }
    return $response;
}

function emailQCToAnyAndPdfGenerateSA($data)
{
    $googleScriptUrl = 'https://script.google.com/a/macros/biogenix.in/s/AKfycbwDP67QqlFnA5JirtFve4-Jo2RQdqWnU4T6jUll9UQuM_fO1AIOVsy-86zhByS0yniA/exec';

    $ch = curl_init($googleScriptUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $curlError = curl_error($ch);
    curl_close($ch);
    if ($curlError) {
        echo json_encode([
            'status' => 'error',
            'message' => 'cURL error: ' . $curlError
        ]);
        exit;
    }
    return $response;
}

function base64_encrypt($data)
{
    return base64_encode($data);
}

function base64_decrypt($encodedData)
{
    return base64_decode($encodedData);
}
function stripDuplicateUnitSuffix(string $value, string $unit): string
{
    $trimmedValue = trim($value);
    $trimmedUnit = trim($unit);
    if ($trimmedValue === '' || $trimmedUnit === '') {
        return $trimmedValue;
    }

    $unitVariants = [$trimmedUnit];
    if (strlen($trimmedUnit) > 1 && str_ends_with(strtolower($trimmedUnit), 's')) {
        $unitVariants[] = substr($trimmedUnit, 0, -1);
    } else {
        $unitVariants[] = $trimmedUnit . 's';
    }

    usort($unitVariants, static fn(string $left, string $right): int => strlen($right) <=> strlen($left));
    foreach (array_unique($unitVariants) as $variant) {
        $pattern = '/(?:^|\s)' . preg_quote($variant, '/') . '\.?$/iu';
        if (preg_match($pattern, $trimmedValue) === 1) {
            return trim((string) preg_replace($pattern, '', $trimmedValue));
        }
    }

    return $trimmedValue;
}

function formatDateDMY($date)
{
    if (!empty($date) && $date !== '0000-00-00' && strtotime($date)) {
        return date('d-m-Y', strtotime($date));
    }
    return ''; // or return 'N/A';
}
function formatDateSlashDMY($date)
{
    if (!empty($date) && $date !== '0000-00-00' && strtotime($date)) {
        return date('d/m/Y', strtotime($date));
    }
    return ''; // or return 'N/A';
}

function formatDateYMD($date)
{
    if (!empty($date) && $date !== '0000-00-00' && strtotime($date)) {
        return date('Y-m-d', strtotime($date));
    }
    return '';
}

function formatMonthYearToMY($monthYear)
{
    if (!empty($monthYear) && preg_match('/^\d{4}-\d{2}$/', $monthYear)) {
        [$year, $month] = explode('-', $monthYear);
        return $month . '-' . $year;
    }
    return '';
}

function formatDateToMonthYear($date)
{
    if (!empty($date)) {
        $dt = DateTime::createFromFormat('Y-m-d', $date);
        if ($dt) {
            // Example output: Aug-2025
            return $dt->format('M-Y');
        }
    }
    return '';
}
function formatDateDMYTime($date)
{
    if (!empty($date) && $date !== '0000-00-00 00:00:00' && strtotime($date)) {
        return date('d-m-Y h:i a', strtotime($date));
    }
    return ''; // or return 'N/A';
}

function formatTimeAmPm(?string $time): string
{
    if (empty($time) || $time === "00:00:00") {
        return "";
    }
    return date("h:i A", strtotime($time));
}

function fetch_table_records($conn, $table, $where = [], $orderBy = '', $orderType = 'ASC', $columns = '*')
{
    $table = mysqli_real_escape_string($conn, $table);
    // $sql = "SELECT * FROM `$table`";
    if (is_array($columns) && !empty($columns)) {
        $safeCols = [];
        foreach ($columns as $col) {
            if (!empty($col)) {
                $safeCols[] = "`" . mysqli_real_escape_string($conn, $col) . "`";
            }
        }
        $columns = !empty($safeCols) ? implode(", ", $safeCols) : '*';

    } elseif (is_string($columns) && trim($columns) !== '') {
        $columns = $columns;
    } else {
        $columns = '*';
    }

    $sql = "SELECT $columns FROM `$table`";
    // WHERE clause
    if (!empty($where)) {
        $conditions = [];

        foreach ($where as $col => $val) {
            $col = mysqli_real_escape_string($conn, $col);

            // Handle operator + value array
            if (is_array($val) && isset($val['op'])) {
                $op = strtoupper(trim($val['op']));

                // IS NULL / IS NOT NULL don't need values
                if (in_array($op, ['IS NULL', 'IS NOT NULL'])) {
                    $conditions[] = "`$col` $op";
                } elseif (isset($val['value'])) {
                    $value = mysqli_real_escape_string($conn, $val['value']);
                    $conditions[] = "`$col` $op '$value'";
                }
            } elseif (is_null($val)) {
                $conditions[] = "`$col` IS NULL";
            } else {
                $safeVal = mysqli_real_escape_string($conn, (string) $val);
                $conditions[] = "`$col` = '$safeVal'";
            }
        }

        $sql .= " WHERE " . implode(" AND ", $conditions);
    }

    if (!empty($orderBy)) {
        $orderBy = mysqli_real_escape_string($conn, $orderBy);
        $orderType = strtoupper(trim($orderType)) === 'DESC' ? 'DESC' : 'ASC';
        $sql .= " ORDER BY `$orderBy` $orderType";
    }
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    } else {
        return false;
    }
}


// 1. Basic Fetch (all records)
// $data = fetch_table_records('users');

//  2. WHERE status = 1
//  $data = fetch_table_records('users', ['status' => 1]);

//  3. WHERE deleted_at IS NULL
// $data = fetch_table_records('permissions', ['deleted_at' => null]);

// 4. WHERE deleted_at IS NOT NULL
// $data = fetch_table_records('permissions', [
//     'deleted_at' => ['op' => 'IS NOT NULL', 'value' => null]
// ]);

// 5. WHERE id > 5 AND status = 1
// $data = fetch_table_records('users', [
//     'id' => ['op' => '>', 'value' => 5],
//     'status' => 1
// ]);

// 6. ORDER BY name DESC
// $data = fetch_table_records('users', [], 'name', 'DESC');

// 7. WHERE name LIKE 'A%' ORDER BY id DESC
// $data = fetch_table_records('users', [
//     'name' => ['op' => 'LIKE', 'value' => 'A%']
// ], 'id', 'DESC');


function generateCategoryPrefix($conn, $categoryName)
{
    $words = preg_split('/[\s()\/]+/', $categoryName);
    $words = array_filter($words);
    $prefix = '';

    foreach ($words as $word) {
        $prefix .= strtoupper(substr($word, 0, 3));
        if (strlen($prefix) >= 6)
            break;
    }

    $originalPrefix = $prefix;
    $suffix = 1;

    $stmtPrefix = $conn->prepare("SELECT COUNT(*) FROM `product_categories` WHERE `category_prefix` = ?");
    if (!$stmtPrefix) {
        die("Prepare failed: " . $conn->error);
    }

    do {
        $checkPrefix = $prefix;
        $stmtPrefix->bind_param('s', $checkPrefix);
        $stmtPrefix->execute();

        // Store result in a separate variable
        $count = 0;
        $stmtPrefix->bind_result($count);
        $stmtPrefix->fetch();

        if ($count > 0) {
            $prefix = $originalPrefix . $suffix;
            $suffix++;
        } else {
            break;
        }
    } while (true);

    $stmtPrefix->close();
    return $prefix;
}

function count_table_records($conn, $table, $where = [])
{
    $table = mysqli_real_escape_string($conn, $table);
    $sql = "SELECT COUNT(*) as total FROM `$table`";

    if (!empty($where)) {
        $conditions = [];

        foreach ($where as $col => $val) {
            $col = mysqli_real_escape_string($conn, $col);

            if (is_array($val) && isset($val['op'])) {
                $op = strtoupper(trim($val['op']));

                switch ($op) {
                    case 'IS NULL':
                    case 'IS NOT NULL':
                        $conditions[] = "`$col` $op";
                        break;

                    case 'BETWEEN':
                        if (isset($val['value']) && is_array($val['value']) && count($val['value']) === 2) {
                            $val1 = mysqli_real_escape_string($conn, $val['value'][0]);
                            $val2 = mysqli_real_escape_string($conn, $val['value'][1]);
                            $conditions[] = "`$col` BETWEEN '$val1' AND '$val2'";
                        }
                        break;

                    case 'IN':
                        if (isset($val['value']) && is_array($val['value'])) {
                            $escapedVals = array_map(function ($v) use ($conn) {
                                return "'" . mysqli_real_escape_string($conn, $v) . "'";
                            }, $val['value']);
                            $conditions[] = "`$col` IN (" . implode(',', $escapedVals) . ")";
                        }
                        break;

                    case 'LIKE':
                    case '=':
                    case '!=':
                    case '>':
                    case '<':
                    case '>=':
                    case '<=':
                        if (isset($val['value'])) {
                            $value = mysqli_real_escape_string($conn, $val['value']);
                            $conditions[] = "`$col` $op '$value'";
                        }
                        break;

                    default:
                        // Skip unsupported operator
                        break;
                }
            } elseif (is_null($val)) {
                $conditions[] = "`$col` IS NULL";
            } else {
                $safeVal = mysqli_real_escape_string($conn, (string) $val);
                $conditions[] = "`$col` = '$safeVal'";
            }
        }

        $sql .= " WHERE " . implode(" AND ", $conditions);
    }

    $result = mysqli_query($conn, $sql);
    if ($result && $row = mysqli_fetch_assoc($result)) {
        return (int) $row['total'];
    }
    return 0;
}
//  1: Like
// count_table_records($conn, 'products', [
//     'product_name' => ['op' => 'LIKE', 'value' => '%bottle%']
// ]);

// 2. BETWEEN
// count_table_records($conn, 'products', [
//     'created_at' => ['op' => 'BETWEEN', 'value' => ['2024-01-01', '2024-12-31']]
// ]);

// 3. IN
// count_table_records($conn, 'products', [
//     'category_id' => ['op' => 'IN', 'value' => [1, 2, 3]]
// ]);

function generateAutoStringNumber($prefix = null)
{
    $now = new DateTime();
    $timestamp = $now->format('YmdHis'); // Combined date and time: e.g., 20250724103645
    $rand = str_pad(mt_rand(0, 9999), 4, '0', STR_PAD_LEFT); // 4-digit random number
    $base = "{$timestamp}{$rand}";
    return ($prefix ? $prefix : 'B') . $base;
}


// Smart Pagination function
function renderSmartPagination($totalPages, $currentPage, $callbackFuction)
{
    $html = '';
    $totalPages = max(1, (int) $totalPages);
    $currentPage = min(max(1, (int) $currentPage), $totalPages);
    $callbackFuction = preg_replace('/[^a-zA-Z0-9_$\.]/', '', (string) $callbackFuction);

    // Previous
    $prev = $currentPage - 1;
    $disabledClass = ($currentPage == 1) ? 'disabled' : '';
    $onclick = ($currentPage == 1) ? '' : 'onclick="' . $callbackFuction . '(' . $prev . ')"';
    $html .= '<li class="page-item ' . $disabledClass . '">
        <a class="page-link page-link-label" href="javascript:void(0)" ' . $onclick . '>Prev</a></li>';

    $pageCandidates = [1, $totalPages];
    for ($page = max(1, $currentPage - 2); $page <= min($totalPages, $currentPage + 2); $page++) {
        $pageCandidates[] = $page;
    }
    $pageCandidates = array_values(array_unique($pageCandidates));
    sort($pageCandidates);
    $previousRenderedPage = 0;
    foreach ($pageCandidates as $page) {
        if ($previousRenderedPage > 0 && $page > $previousRenderedPage + 1) {
            $html .= '<li class="page-item disabled"><span class="page-link">&hellip;</span></li>';
        }
        if ($page === $currentPage) {
            $html .= '<li class="page-item active" aria-current="page"><span class="page-link">' . $page . '</span></li>';
        } else {
            $html .= '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="' . $callbackFuction . '(' . $page . ')">' . $page . '</a></li>';
        }
        $previousRenderedPage = $page;
    }

    // Next
    $next = $currentPage + 1;
    $disabledClass = ($currentPage == $totalPages) ? 'disabled' : '';
    $onclick = ($currentPage == $totalPages) ? '' : 'onclick="' . $callbackFuction . '(' . $next . ')"';
    $html .= '<li class="page-item ' . $disabledClass . '">
        <a class="page-link page-link-label" href="javascript:void(0)" ' . $onclick . '>Next</a></li>';

    return $html;
}

function renderSmartPaginationTailwind($totalPages, $currentPage, $callbackFuction)
{
    $html = '';
    $totalPages = max(1, (int) $totalPages);
    $currentPage = min(max(1, (int) $currentPage), $totalPages);
    $callbackFuction = preg_replace('/[^a-zA-Z0-9_$\.]/', '', (string) $callbackFuction);

    // Previous
    $prev = $currentPage - 1;
    $disabledClass = ($currentPage == 1) ? 'pointer-events-none text-slate-300 bg-slate-50' : 'text-slate-500 hover:bg-slate-50 bg-white';
    $onclick = ($currentPage == 1) ? '' : 'onclick="' . $callbackFuction . '(' . $prev . ')"';
    $html .= '<a href="javascript:void(0)" ' . $onclick . ' class="relative inline-flex items-center rounded-l-md px-2 py-2 text-sm font-semibold ring-1 ring-inset ring-slate-300 focus:z-20 focus:outline-offset-0 ' . $disabledClass . '">
            <span class="sr-only">Previous</span>
            <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd" /></svg>
        </a>';

    $pageCandidates = [1, $totalPages];
    for ($page = max(1, $currentPage - 2); $page <= min($totalPages, $currentPage + 2); $page++) {
        $pageCandidates[] = $page;
    }
    $pageCandidates = array_values(array_unique($pageCandidates));
    sort($pageCandidates);
    $previousRenderedPage = 0;
    foreach ($pageCandidates as $page) {
        if ($previousRenderedPage > 0 && $page > $previousRenderedPage + 1) {
            $html .= '<span class="relative inline-flex items-center bg-white px-3 py-2 text-sm font-semibold text-slate-400 ring-1 ring-inset ring-slate-300">&hellip;</span>';
        }
        if ($page === $currentPage) {
            $html .= '<span aria-current="page" class="relative z-10 inline-flex items-center bg-indigo-600 px-4 py-2 text-sm font-semibold text-white focus:z-20">' . $page . '</span>';
        } else {
            $html .= '<a href="javascript:void(0)" onclick="' . $callbackFuction . '(' . $page . ')" class="relative inline-flex items-center bg-white px-4 py-2 text-sm font-semibold text-slate-700 ring-1 ring-inset ring-slate-300 hover:bg-slate-50 focus:z-20">' . $page . '</a>';
        }
        $previousRenderedPage = $page;
    }

    // Next
    $next = $currentPage + 1;
    $disabledClass = ($currentPage == $totalPages) ? 'pointer-events-none text-slate-300 bg-slate-50' : 'text-slate-500 hover:bg-slate-50 bg-white';
    $onclick = ($currentPage == $totalPages) ? '' : 'onclick="' . $callbackFuction . '(' . $next . ')"';
    $html .= '<a href="javascript:void(0)" ' . $onclick . ' class="relative inline-flex items-center rounded-r-md px-2 py-2 text-sm font-semibold ring-1 ring-inset ring-slate-300 focus:z-20 focus:outline-offset-0 ' . $disabledClass . '">
            <span class="sr-only">Next</span>
            <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" /></svg>
        </a>';

    return $html;
}

function generateUniquePoOrderNum($conn)
{
    $today = date('Ymd');

    // Get last PO number for today
    $sql = "SELECT po_order_num 
            FROM purchase_order_final 
            WHERE po_order_num LIKE ? 
            ORDER BY id DESC 
            LIMIT 1";
    $like = "BIPL-PO-{$today}-%";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
    $lastSeq = 0;
    if ($row = $result->fetch_assoc()) {
        $parts = explode("-", $row['po_order_num']);
        $lastSeq = intval(end($parts));
    }
    $nextSeq = str_pad($lastSeq + 1, 2, "0", STR_PAD_LEFT);

    return "BIPL-PO-{$today}-{$nextSeq}";
}

function formatDatePO($date): string
{
    try {
        $dt = new DateTime($date);
        // Format with ordinal suffix (st, nd, rd, th)
        $day = $dt->format('j'); // day without leading zero
        $suffix = date('S', mktime(0, 0, 0, 1, $day, 2000)); // ordinal suffix
        return $dt->format("d") . $suffix . $dt->format(" M-Y");
        // Example: 07th May-2025
    } catch (Exception $e) {
        return $date; // fallback if invalid date
    }
}

function POPdf(array $row): string
{
    $poNumber = htmlspecialchars($row['po_order_num'] ?? '');
    $vendor = htmlspecialchars($row['vendor'] ?? '');
    $currency_type = intval($row['currency_type'] ?? '1');
    $date = date("d-m-Y", strtotime($row['created_at'] ?? date('Y-m-d')));
    $row["id"] = 1;
    $companyAddressHtml = 'B19/A S.I.L. Ancillary Estate, Amausi<br>Industrial Area, Nadarganj-226008<br>(Lucknow)<br>GSTN: 09AACGB6941G1ZJ';
    if (trim((string) ($row['shipment_address_snapshot'] ?? '')) !== '') {
        $companyAddressHtml = nl2br(htmlspecialchars($row['shipment_address_snapshot'], ENT_QUOTES, 'UTF-8'));
        if (trim((string) ($row['shipment_gst_snapshot'] ?? '')) !== '') {
            $companyAddressHtml .= '<br>GSTN: ' . htmlspecialchars($row['shipment_gst_snapshot'], ENT_QUOTES, 'UTF-8');
        }
    }

    $html = '';
    $chunks = array_chunk($row['items'], 15);
    $html .= '<div class="row invoice-preview">';
    $html .= '<div class="col-xl-10 col-md-8 col-12 mb-md-0 mb-4">
                <div class="card border border-slate-200 !rounded-xl bg-white shadow-sm">
                    <div style="overflow-x: auto; width: 100%;">                        
                        <div style="font-family: Calibri, Arial, sans-serif !important; font-size: 14px; margin: 0; padding: 10px;">';
    $html .= '<div id="transferTicketContent-' . $row["id"] . '" style="width: 100%; max-width: 794px; padding: 15px !important; margin: auto;">';
    foreach ($chunks as $pageIndex => $pageProducts) {
        // start html

        // ===== HEADER SECTION =====
        $html .= '<div class="transfer-copy">                            
                    <div style="border: 2px solid #000; margin-bottom:10px;">
                        <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                            <tr>
                                <!-- Left side: Logo + Company Info -->
                                <td style="width: 30%; border-right: 2px solid #000; padding:0; vertical-align: top;">
                                    <table style="width:100%; border-collapse: collapse;">
                                        <tr>
                                            <td style="border-bottom: 2px solid #000; padding:5px;">
                                                <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 60px; vertical-align: middle; padding-left:10px;">
                                                <div style="font-size:11px; font-weight:700; margin-top:5px;">
                                                    CIN NO. U24304UP2016PTC082775
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="po-doc-company-address-view" style="padding:6px; font-size:12px; line-height:1.3;">
                                                ' . $companyAddressHtml . '
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td style="width: 30%; border-right: 2px solid #000; text-align:center; vertical-align: middle;">
                                    <strong style="font-size:16px;">TITLE: Purchase Order</strong>
                                </td>
                                <td style="width: 40%; vertical-align: top; padding:0px;">
                                    <table style="width: 100%; border-collapse: collapse; font-size:12px;">
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; width:50%; font-weight:700;">Document No.</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">BIPL-F-PO-01</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Issue No.</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">01</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Revision No.</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">02</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Effective Date</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">03/04/2025</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Review Date</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">02/04/2028</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Department</td>
                                            <td style="border-bottom:2px solid #000;padding:4px;">Purchase</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;padding:4px; font-weight:700;">Supersedes</td>
                                            <td style="padding:4px;">Nil</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>';

        // ===== BODY (example values inserted dynamically) =====
        $html .= '<div style="padding: 15px;">
            <table style="width: 100%; border-collapse: collapse; margin-top: 0px;">
                <tr style="line-height: 30px;">
                    <td style="width: 65%">' . $poNumber . '</td>
                    <td style="width: 25%;">Date: ' . $date . '</td>
                </tr>
                <tr style="line-height: 30px;">
                    <td style="width: 65%;">To : ' . $vendor . '</td>
                    <td style="width: 25%;"></td>
                </tr>
            </table>
        </div>';

        // ===== ITEMS TABLE (empty here, you can loop products) =====
        $html .= '<table style="border:2px solid #000; border-collapse:collapse; width:100%; text-align:center; font-size:14px;">
                <thead>
                    <tr>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Serial #</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Material(s)</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Pack Size</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Quantity Req.</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Price in ' . Constant::PURCHASE_MANAGEMENT['CURRENCY']["$currency_type"]['label'] . '</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($pageProducts as $p) {
            $html .= '<tr>
                        <td style="border:2px solid #000; padding:6px; text-align:center;">' . $p['serial'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['name'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['pack'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['qty'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['price'] . '</td>
                    </tr>';
        }
        $html .= '
                </tbody>
            </table>';

        if ($pageIndex === array_key_last($chunks)) {
            $html .= '<div style="margin-top:18px; font-size:14px;">
                            <div style="margin-bottom:10px;">Yours Sincerely,</div>
                            <img src="' . asset('assets/img/stamp_logo.jpeg') . '" style="height:80px;" />
                            <div style="margin-top:12px;">Biogenix Inc Pvt Ltd.</div>
                        </div>';
        }
        $html .= '<div style="margin-top:30px;">
                <table style="width:100%; border:2px solid #000; border-collapse:collapse; text-align:left; padding: 15px;">
                    <tr>
                        <td style="width:50%; border:2px solid #000; padding:15px;">
                            <b>Format Prepared by :</b> MR/QA
                        </td>
                        <td style="width:50%; border:2px solid #000; padding:15px;">
                            <b>Format Approved by:</b> Head of the organization
                        </td>
                    </tr>
                </table>
            </div></div>';
        $html .= '<br/><br/><br/>';
    }

    $html .= ' </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-xl-2 col-md-4 col-12 invoice-actions">
            <div class="card border border-slate-200 !rounded-xl bg-white shadow-sm">
                <div class="card-body p-4">
                    <button class="inline-flex h-10 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 pdfPurchaseOrderFinalDownloadBtn" data-id ="' . base64_encrypt($poNumber) . '">
                        <i class="ti ti-download text-base"></i> Download
                    </button>
                </div>
            </div>
        </div>';
    $html .= '</div>'; // closing tags


    return $html;
}

function materialRequisitionPdf(array $row): string
{
    $html = '';
    $footers = ['PRODUCTION', 'STORES'];

    $html .= '<div class="row invoice-preview">';
    $html .= '<div class="col-xl-10 col-md-8 col-12 mb-md-0 mb-4">
                <div class="card">
                    <div style="overflow-x: auto; width: 100%;">                        
                        <div style="font-family: Calibri, Arial, sans-serif !important; font-size: 14px; margin: 0; padding: 10px;">';
    $html .= '<div id="transferTicketContent-' . $row["id"] . '" style="width: 100%; max-width: 794px; padding: 15px !important; margin: auto;">';
    foreach ($footers as $index => $footerLabel) {
        $html .= '<div class="transfer-copy">                            
                    <div style="border: 1px solid #000;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 18px; ">
                        <td style="width: 35%; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                            <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 50px;">
                        </td>
                        <td rowspan="2" style="width: 30%; border-right: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">TITLE: MATERIAL <br/> REQUISITION FORM</strong></td>
                        <td rowspan="2" style="width: 15%; border-right: 1px solid #000; text-align:center;"><strong>Document No.</strong></td>
                        <td rowspan="2" style="text-align:center;">BIPL-F-MRF-01</td>
                    </tr>
                    <tr>
                        <td style="width: 35%; border-right: 1px solid #000;  padding-left:10px;">
                            B19/A S.I.L Ancillary Estate,<br>
                            Amausi Industrial Area,<br>
                            Nadarganj-226008 (Lucknow)
                        </td>
                    </tr>
                </table>
            </div>';


        $html .= '<div style="border-left: 1px solid #000;border-right: 1px solid #000;">
                <table style="width: 100%; border-collapse: collapse; ">
                    
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%; border-right: 1px solid #000;">
                            <strong>Requisition For</strong>
                        </td>
                        <td style="padding-left:5px;">
                            <div style="display: flex; justify-content: space-between; width:100%;">
                                <span style="flex:1;">
                                    ' . ($row['mr_raw'] == 1 ? "&#x2611;" : "&#x2610;") . ' Raw material
                                </span>
                                <span style="flex:1;">
                                   ' . ($row['mr_packing'] == 1 ? "&#x2611;" : "&#x2610;") . ' Packing material
                                </span>
                                <span style="flex:1;">
                                    ' . ($row['mr_consumable'] == 1 ? "&#x2611;" : "&#x2610;") . ' Consumables
                                </span>
                            </div>
                        </td>
                    </tr>

                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Date</strong></td>
                        <td style="padding-left:5px;">' . formatDateDMY(htmlspecialchars($row['date'] ?? "")) . '</td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Product Name</strong></td>
                        <td style="padding-left:5px;">' . htmlspecialchars($row['product_name'] ?? "") . '</td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Lot No./Batch No.</strong></td>
                        <td style="padding-left:5px;">' . htmlspecialchars($row['lot_batch_no'] ?? "") . '</td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Batch Size</strong></td>
                        <td style="padding-left:5px;">' . htmlspecialchars($row['batch_size'] ?? "") . " " . htmlspecialchars($batchSizeUnit ?? "") . '</td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Slip No.</strong><sub>(dept. code/date/sequence)</sub></td>
                        <td style="padding-left:5px;">' . htmlspecialchars($row['slip_no'] ?? "") . '</td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Requested By</strong></td>
                        <td style="padding-left:5px;">' . htmlspecialchars($row['requested_by'] ?? "") . '</td>
                    </tr>  
                </table>
            </div>';
        $html .= '<div>
                <table style="width: 100%; border-collapse: collapse;"> 
                    <tr style="line-height: 18px; background-color:#D3D3D3; border-bottom: 1px solid #000;">
                        <td style="width: 27%; border-left: 1px solid #000; border-right: 1px solid #000;"><div style="display: flex; justify-content: center; width: 100%; font-weight: bold;"><span>Description</span></div></td>
                        <td style="width: 15%; border-right: 1px solid #000;"><div style="display: flex; justify-content: center; width: 100%; font-weight: bold;"><span>Required <br> Quantity</span></div></td>
                        <td style="width: 15%; border-right: 1px solid #000;"><div style="display: flex; justify-content: center; width: 100%; font-weight: bold;"><span>Issued <br>Quantity</span></div></td>
                        <td style="width: 18%; border-right: 1px solid #000;"><div style="display: flex; justify-content: center; width: 100%; font-weight: bold;"><span>Returned Quantity / <br> Rejection Quantity</span></div></td>
                        <td style="width: 15%; border-right: 1px solid #000;"><div style="display: flex; justify-content: center; width: 100%; font-weight: bold;"><span>A.R/COA <br> Number</span></div></td>                        
                    </tr>';
        if (!empty($row['items'])) {
            foreach ($row['items'] as $p) {
                $html .= '<tr style="line-height: 18px; border-bottom: 1px solid #000;">
                                <td style="padding-left:5px; width: 27%; border-left: 1px solid #000;border-right: 1px solid #000;">' . ($p['description'] ?? '') . '</td>
                                <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">' . (($p['required_qty'] ?? 0) . ' ' . ($p['unit_name'] ?? '')) . '</td>
                                <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">' . ($p['issued_qty'] ?? 0) . '</td>
                                <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">' . ($p['returned_qty'] ?? 0) . ' / ' . ($p['rejected_qty'] ?? 0) . '</td>
                                <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">' . ($p['ar_coa_number'] ?? '') . '</td>
                                
                            </tr>';
            }
        } else {
            $html .= '<tr style="line-height: 18px; border-bottom: 1px solid #000;">
                            <td style="padding-left:5px; width: 27%; border-left: 1px solid #000;border-right: 1px solid #000;">-</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">-</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">-</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">-</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;">-</td>
                        </tr>';
        }

        $html .= ' 
                </table>
                <table style="width: 100%; border-collapse: collapse; margin-top: 30px; text-align: center;">
                    <tr>
                        <td style="padding-top: 40px; text-align: left;">
                            <strong style="font-weight:700;">Requisition By</strong> (Sign/Date)<br> _____________________
                        </td>
                        <td style="padding-top: 40px; font-weight:700;"></td>
                        <td style="padding-top: 40px;  text-align: right;">
                            <strong style="font-weight:700;">Issued By</strong> (Sign/Date)<br> _____________________
                        </td>
                    </tr>
                </table>
            </div>';
        $html .= '<div style="text-align:right; padding: 15px;">       
                <div style="margin-top: 30px; font-weight: bold;">' . $footerLabel . ' COPY</div>
            </div>';
        $html .= '';
        $html .= '</div>';
        $html .= '<br/><br/><br/><br/><br/>';
    }

    $html .= ' </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-xl-2 col-md-4 col-12 invoice-actions">
            <div class="card border border-slate-200 !rounded-xl bg-white shadow-sm">
                <div class="card-body p-4">
                    <button class="inline-flex h-11 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 pdfPurchaseOrderFinalDownloadBtn" data-id ="' . base64_encrypt($row['id']) . '">
                        <i class="ti ti-download text-lg"></i> Download
                    </button>
                </div>
            </div>
        </div>';
    $html .= '</div>';
    return $html;
}


function sampleAdvicePdf(array $row): string
{
    $html = '';
    $footers = ['STORES', 'PURCHASE', 'QA/QC'];

    $html .= '<div class="row invoice-preview">';
    $html .= '<div class="col-xl-10 col-md-8 col-12 mb-md-0 mb-4">
                <div class="card">
                    <div style="overflow-x: auto; width: 100%;">                        
                        <div style="font-family: Calibri, Arial, sans-serif !important; font-size: 14px; margin: 0; padding: 10px;">';
    $html .= '<div id="transferTicketContent-1" style="width: 100%; max-width: 794px; padding: 15px !important; margin: auto;">';
    foreach ($footers as $index => $footerLabel) {
        $html .= '<div class="transfer-copy">                            
                    <div style="border: 1px solid #000; margin-bottom:0px;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr style="line-height: 20px; ">
                                <td style="width: 35%; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                                    <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 50px;">
                                </td>
                                <td rowspan="2" style="width: 30%; border-right: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">TITLE: <br/> SAMPLING ADVICE</strong></td>
                                <td rowspan="2" style="width: 20%; border-right: 1px solid #000; text-align:center;"><strong>Document No.</strong></td>
                                <td rowspan="2" style="text-align:center;">BIPL-F-SA-01</td>
                            </tr>
                            <tr>
                                <td style="width: 35%; border-right: 1px solid #000; padding-left:10px;">
                                    B19/A S.I.L Ancillary Estate,<br>
                                    Amausi Industrial Area,<br>
                                    Nadarganj-226008 (Lucknow)
                                </td>
                            </tr>
                        </table>
                    </div>';
        $html .= '<div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 5px;">
                    <tr style="line-height: 20px; background-color: #e0e0e0">
                        <td colspan="2" style="border: 1px solid #000; font-size: 14px;">
                            <div style="display: flex; justify-content: center; align-items: center; width: 100%; font-weight: bold;">
                               Part A-Intimation from Stores to QA/QC
                            </div>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Category</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000; padding-left:10px;font-size: 14px;">
                            
                            <div style="display: flex; justify-content: space-between; width:100%;">
                                <span style="flex:1;">
                                    ' . ($row['category'] == 'RM' ? "&#x2611;" : "&#x2610;") . ' Raw material
                                </span>
                                <span style="flex:1;">
                                   ' . ($row['category'] == 'PM' ? "&#x2611;" : "&#x2610;") . ' Packing material
                                </span>
                                <span style="flex:1;">
                                    ' . ($row['category'] == 'CM' ? "&#x2611;" : "&#x2610;") . ' Consumables
                                </span>
                            </div>                        
                        </td>
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Name of the Material</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000; padding-left:10px;font-size: 14px;">
                        ' . ($row['nameOfMaterial'] ?? '') . '                        
                        </td>
                    </tr>
                    
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Material Code No.</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                           ' . ($row['materialCodeNo'] ?? '') . ' 
                        </td>
                    </tr>
                                      
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Manufacturer</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                           ' . ($row['manufacturer'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="vertical-align: top; border: 1px solid #000;padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Supplier</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['supplier'] ?? '') . '
                        </td>
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Invoice No./D.C. No. and Date</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['invoiceNoAndDate'] ?? '') . '
                        </td>
                    </tr>
                                      
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Date of Receipt</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['dateOfReceipt'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Quantity Received</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['quantityReceived'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>No. of Containers Received</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['noOfContainersReceived'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Batch No./Lot No.</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['batchNoOrLotNo'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Mfg. Date</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['mfgDate'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Exp. Date</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px; font-size: 14px;">
                            ' . ($row['expDate'] ?? '') . '
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Storage condition</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                           ' . ($row['storageCondition'] ?? '') . '
                        </td>
                    </tr>
                </table>
            </div>';
        $html .= '<div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                    <!-- First Row -->
                    <tr style="line-height: 20px;">
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Department In charge
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                           
                        </td>
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Receiving Signature
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            
                        </td>
                    </tr>
                   
                    <tr style="line-height: 20px;">
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                           
                        </td>
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">                            
                        </td>
                    </tr>
                </table>
            </div>';

        $html .= '<div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px; border: 1px solid #000;">
                    <tr style="line-height: 20px; background-color: #e0e0e0;">
                        <td colspan="2" style="border: 1px solid #000; font-size: 14px;">
                            <div style="display: flex; justify-content: center; align-items: center; width: 100%; font-weight: bold;">
                               Part B-Intimation From QA/QC to Stores
                            </div>
                        </td>
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>No. of Containers Sampled</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000; padding-left:10px;font-size: 14px;">
                            ' . ($row['noOfContainersSampled'] ?? '') . '
                        </td>
                    </tr>
                    
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Quantity Used for Sampling</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['quantityUsedForSampling'] ?? '') . '
                        </td>
                    </tr>
                                      
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Quantity Approved</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['quantityApproved'] ?? '') . ' 
                        </td>
                    </tr>

                    <tr style="line-height: 20px; ">
                        <td style="vertical-align: top; border: 1px solid #000;padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>COA/A.R. No.</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            ' . ($row['coaOrARNo'] ?? '') . '
                        </td>
                    </tr>
                    <tr style="line-height: 20px; ">
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Remarks</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                           ' . ($row['remarks'] ?? '') . '
                        </td>
                    </tr>         
                </table>
            </div>';

        $html .= '<div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px; ">                    
                    <tr style="line-height: 20px;">
                        <td colspan="4" style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            The above material is
                            <span style="flex:1;">
                                ' . ($row['approvalStatus'] == 1 ? "&#x2611;" : "&#x2610;") . ' Approved
                            </span>
                            <span style="flex:1;">
                                ' . ($row['approvalStatus'] == 2 ? "&#x2611;" : "&#x2610;") . ' Not Approved
                            </span>
                            <span style="flex:1;">
                                ' . ($row['approvalStatus'] == 3 ? "&#x2611;" : "&#x2610;") . ' Released
                            </span>
                            <span style="flex:1;">
                                ' . ($row['approvalStatus'] == 4 ? "&#x2611;" : "&#x2610;") . ' Not Released for manufacturing
                            </span>
                        </td>                        
                    </tr>
                    <tr style="line-height: 20px; ">
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Checked By
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            
                        </td>
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Verified By
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            
                        </td>
                        <td style="width: 20%; border: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 30%; border: 1px solid #000; padding-left:10px; font-size: 14px;">
                            
                        </td>
                    </tr>
                </table>
            </div>';

        $html .= '<div style="border-top: 1px solid #000; border-bottom: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; padding: 10px;">       
                <div style="margin-top: 20px; font-weight: bold;">' . $footerLabel . '</div>
            </div>';
        $html .= '</div>';
        $html .= '<br/><br/><br/><br/><br/>';
    }
    $html .= ' </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-xl-2 col-md-4 col-12 invoice-actions">
            <div class="card border border-slate-200 !rounded-xl bg-white shadow-sm">
                <div class="card-body p-4">
                    <button class="inline-flex h-11 w-full items-center justify-center gap-2 bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 pdfSampleAdviceDownloadBtn" style="border-radius: 0.75rem !important;" data-id ="' . base64_encrypt($row['id']) . '">
                        <i class="ti ti-download text-lg"></i> Download
                    </button>
                </div>
            </div>
        </div>';
    $html .= '</div>';
    return $html;
}

function generateOrderCode($conn)
{
    $prefix = "BIPL-ORD";
    $now = new DateTime();
    $sequenceDate = $now->format('Y-m-d');
    $datePart = $now->format('d-m-Y');

    $stmt = $conn->prepare("INSERT INTO `order_number_sequences` (`sequence_date`, `last_sequence`) VALUES (?, 1) ON DUPLICATE KEY UPDATE `last_sequence` = LAST_INSERT_ID(`last_sequence` + 1)");
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the order number sequence.');
    }
    $stmt->bind_param('s', $sequenceDate);
    if (!$stmt->execute()) {
        $message = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to reserve the next order number: ' . $message);
    }
    $isFirstSequence = $stmt->affected_rows === 1;
    $stmt->close();

    if ($isFirstSequence) {
        $nextSequence = 1;
    } else {
        $result = $conn->query('SELECT LAST_INSERT_ID() AS `next_sequence`');
        $nextSequence = (int) ($result->fetch_assoc()['next_sequence'] ?? 0);
    }

    if ($nextSequence <= 0) {
        throw new RuntimeException('The next order number could not be reserved.');
    }

    return "{$prefix}-{$datePart}-" . str_pad((string) $nextSequence, 2, '0', STR_PAD_LEFT);
}


// function labelPrintDesign(array $row): string
// {
//     $html = '';            
//     $html .= '<div class="row invoice-preview">';
//     $html .= '<div class="col-xl-10 col-md-8 col-12 mb-md-0 mb-4">
//                 <div class="card">
//                     <div class="transfer-copy">  
//                     </div>';        
//     $html .= '  </div>';     
//         $html .= '';   

//         $html .= '</div>';      
//     $html .= '<div class="col-xl-2 col-md-4 col-12 invoice-actions">
//             <div class="card">
//                 <div class="card-body">
//                     <button class="btn btn-label-secondary d-grid w-100 mb-2 pdfSampleAdviceDownloadBtn1122" data-id ="'.base64_encrypt($row['id']).'">Download </button>
//                 </div>
//             </div>
//         </div>';
//     $html .= '</div>';     
//     return $html;
// }


function labelPrintDesign(array $row): string
{
    $width = isset($row['width']) ? htmlspecialchars($row['width']) : '100mm';
    $height = isset($row['height']) ? htmlspecialchars($row['height']) : '30mm';

    $html = '';
    $html .= '<div class="row invoice-preview">';
    $html .= '<div class="col-xl-8 col-md-8 col-12 mb-md-0 mb-4">
                <div class="card">
                    <div class="transfer-copy" 
                         style="border:1px solid #000; padding:1mm; width:' . $width . '; height:' . $height . '; overflow:hidden;">  
                        ' . $row['html'] . '  
                    </div>
                </div>
              </div>';
    $html .= '<div class="col-xl-4 col-md-4 col-12 invoice-actions">
                <div class="card">
                    <div class="card-body">
                        <h6 class="mb-2">' . htmlspecialchars($row['name']) . '</h6>                        
                        <button class="btn btn-primary d-grid w-100 mb-2 printLabelBtn" 
                                data-id="' . base64_encrypt($row['id']) . '">Print</button>
                    </div>
                </div>
              </div>';
    $html .= '</div>';
    return $html;
}

function coaDesignPdf(array $row): string
{
    $poNumber = htmlspecialchars($row['id'] ?? '');
    $row["id"] = 1;

    $html = '';
    $rowsPerPage = 10;
    $chunks = array_chunk($row['items'], $rowsPerPage);
    $lastPageIndex = array_key_last($chunks);
    $totalPages = count($chunks);
    $html .= '<div class="row invoice-preview">';
    $html .= '<div class="col-xl-10 col-md-8 col-12 mb-md-0 mb-4">';
    foreach ($chunks as $pageIndex => $pageProducts) {
        $realCount = count($pageProducts);
        $emptyRows = $rowsPerPage - $realCount;
        $currentPage = $pageIndex + 1;
        $html .= '<div class="card mb-2">
                    <div style="overflow-x: auto; width: 100%;">                        
                        <div style="font-family: Calibri, Arial, sans-serif !important; font-size: 14px; margin: 0; padding: 10px;">';
        $html .= '<div id="transferTicketContent-' . $row["id"] . '" style="width: 100%; max-width: 794px; padding: 15px !important; margin: auto;">';

        // ===== HEADER SECTION =====
        $html .= '<div class="transfer-copy">';

        $html .= '<div style="border: 1px solid #000; margin-bottom:10px;">
                    <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                        <tr>
                            <td style="width: 30%; border-right: 1px solid #000; padding:0; vertical-align: top;">
                                <table style="width:100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="border-bottom: 1px solid #000; padding:15px;">
                                            <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 60px; vertical-align: middle; padding-left:10px;">                                           
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding:6px; font-size:12px; line-height:1.5;">
                                            B19/A S.I.L. Ancillary Estate, Amausi<br>
                                            Industrial Area, Nadarganj-226008<br>
                                            (Lucknow)
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td style="width: 30%; border-right: 1px solid #000; text-align:center; vertical-align: middle;">
                                <strong style="font-size:16px;">TITLE: <br> CERTIFICATE OF ANALYSIS</strong>
                            </td>
                            <td style="width: 40%; vertical-align: top; padding:0px;">
                                <table style="width: 100%; border-collapse: collapse; font-size:12px;">
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; width:50%; font-weight:700;">Document No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">BIPL-F-COA-01</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Issue No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">01</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Revision No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">02</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Effective Date</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">03/04/2025</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Review Date</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">02/04/2028</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Department</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">Quality Control</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;padding:4px; font-weight:700;">Supersedes</td>
                                        <td style="padding:4px;">Nil</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>';

        $html .= '<table style="border-collapse:collapse; width:100%; font-family:Arial, sans-serif; font-size:12px; margin-bottom:20px; line-height: 0.7;">
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Item Description</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['name'] ?? "") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Manufacturer/Supplier</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['manufacturer_supplier'] ?? "") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">COA/AR No.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['coa_number'] ?? "") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Item Code No.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['material_code_no'] ?? "") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">G. R. No.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars('-' ?? "NA") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Testing date</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['testing_date'] ?? "NA") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Mfg. Date.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars(formatDateDMY($row['mfg_date']) ?? "-") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Exp. Date.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars(formatDateDMY($row['expiry_date']) ?? "-") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">No. of Packings received</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['number_of_container_received'] ?? "") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">No. of Packings sampled</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['container_sampled'] ?? "") . '</td>                   
                    </tr>
                    
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Reference specification no./STP no.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['coa_ref_stp'] ?? "NA") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Lot No./ Batch no.</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['lot_batch_number'] ?? "NA") . '</td>                   
                    </tr>
                    <tr>
                        <td style="width:30%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; border-bottom:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Lot Size/ Batch size</td>
                        <td style="width:70%; border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;border-top:1px solid #000; border-right:1px solid #000; padding:6px;">' . htmlspecialchars($row['lot_batch_size'] ?? "NA") . '</td>                   
                    </tr>
                </table>';

        $html .= '<table style="border-collapse:collapse; width:100%; font-family:Arial, sans-serif; font-size:12px;">
                    <thead>
                        <tr style="font-weight:bold; text-align:center;">
                            <th style="width:10%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Sr. No.</th>
                            <th style="width:32%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Parameter</th>
                            <th style="width:32%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Specification</th>
                            <th style="width:26%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">Observation</th>
                        </tr>
                    </thead>
                    <tbody>';
        foreach ($pageProducts as $p) {
            if ($p['table_head']) {
                $html .= '<tr style="font-weight:bold; text-align:left;">
                            <td colspan="4" style="background-color:#D3D3D3; border-bottom:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;border-top:1px solid #000; padding:6px;">' . $p['table_head'] . '</td>                            
                        </tr>';
            }

            $html .= '<tr style="text-align:left;">
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px; text-align:center;">' . $p['serial'] . '</td>
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;">' . $p['parameter'] . '</td>
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;">' . $p['specification'] . '</td>
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;border-right:1px solid #000; ">' . $p['observation'] . '</td>
                        </tr>';
        }
        for ($i = 0; $i < $emptyRows; $i++) {
            $html .= '<tr>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                        </tr>';
        }
        $html .= '
                    </tbody>
                </table>';
        $html .= '';
        if ($pageIndex === $lastPageIndex) {
            $html .= '<div style="margin-top:5px;">
                        <table style="width:100%; border:1px solid #000; border-collapse:collapse; text-align:left; padding: 15px; font-size:12px;">
                            <tr>
                                <td style="width:3%; border:1px solid #000; padding:10px; font-size:15px;">' .
                ($row['coa_approval_status'] == 1 ? "&#x2611;" : "&#x2610;") . '
                                </td>
                                <td style="width:6%; border:1px solid #000; padding:10px;">
                                    <b>Approved</b> 
                                </td>
                                <td rowspan="2" style="width:40%; border:1px solid #000; padding:10px; vertical-align: top;">
                                    <b>Comments/Instructions :</b>' . htmlspecialchars($row['coa_remark'] ?? "") . '
                                </td>
                                <td style="width:10%; border:1px solid #000; padding:10px;">
                                    <b>Analysis by</b>
                                </td>
                                <td style="width:10%; border:1px solid #000; padding:10px;">                               
                                </td>
                            </tr>
                            <tr>
                                <td style="width:3%; border:1px solid #000; padding:10px; font-size:15px;">
                                   ' . ($row['coa_approval_status'] == 2 ? "&#x2611;" : "&#x2610;") . '
                                </td>
                                <td style="width:6%; border:1px solid #000; padding:10px;">
                                    <b>Rejected</b> 
                                </td>                            
                                <td style="width:10%; border:1px solid #000; padding:10px;">
                                    <b>Verified and Approved by</b>
                                </td>
                                <td style="width:10%; border:1px solid #000; padding:10px;">                               
                                </td>
                            </tr>                        
                        </table>
                    </div>';
        }
        $html .= '<div style="margin-top:5px;">
                    <table style="width:100%; border:1px solid #000; border-collapse:collapse; text-align:left; padding: 15px;font-size:12px;">
                        <tr>
                            <td style="width:40%; border:1px solid #000; padding:15px;">
                                <b>Format Prepared by :</b> MR/QA
                            </td>
                            <td style="width:40%; border:1px solid #000; padding:15px;">
                                <b>Format Approved by:</b> Head of the organization
                            </td>
                            <td style="width:20%; border:1px solid #000; padding:15px;">
                                Page No.: ' . $currentPage . ' of ' . $totalPages . '
                            </td>
                        </tr>
                    </table>
                </div>';
        $html .= '</div>';
        $html .= ' </div>
                </div>
            </div></div>';
    }
    $html .= '</div>
        <div class="col-xl-2 col-md-4 col-12 invoice-actions">
            <div class="card">
                <div class="card-body">
                    <button class="btn btn-label-secondary d-grid w-100 mb-2 pdfCOADownloadBtn" data-id ="' . base64_encrypt($poNumber) . '">Download </button>
                </div>
            </div>
        </div>';
    $html .= '</div>';


    return $html;
}

function countSundays($monthInput)
{
    $firstDate = date('Y-m-01', strtotime($monthInput));
    $lastDate = date('Y-m-t', strtotime($monthInput));
    $start = strtotime($firstDate);
    $end = strtotime($lastDate);
    $firstSunday = strtotime('Sunday', $start);
    if ($firstSunday > $end) {
        return 0;
    }
    return floor(($end - $firstSunday) / (7 * 24 * 60 * 60)) + 1;
}

function countSundaysBetween($startDate, $endDate)
{
    $start = strtotime($startDate);
    $end = strtotime($endDate);
    if ($start > $end)
        return 0;
    $dayOfWeek = date('w', $start);
    $daysToSunday = (7 - $dayOfWeek) % 7;
    $firstSunday = strtotime("+$daysToSunday days", $start);
    if ($firstSunday > $end)
        return 0;
    return floor(($end - $firstSunday) / 604800) + 1; // 7*86400
}


function countHolidays($conn, $firstDate, $lastDate, ?int $companyId = null)
{
    $firstDateObj = DateTime::createFromFormat('Y-m-d', $firstDate);
    $lastDateObj = DateTime::createFromFormat('Y-m-d', $lastDate);

    if (!$firstDateObj || !$lastDateObj) {
        return 0; // Invalid date format
    }

    $firstDate = $firstDateObj->format('Y-m-d');
    $lastDate = $lastDateObj->format('Y-m-d');

    $annualDates = getHolidayDates($conn, $firstDate, $lastDate, $companyId, true);
    if ($annualDates !== null) {
        return count($annualDates);
    }

    $sql = "SELECT COUNT(*) AS `total`
        FROM `holidays`
        WHERE `holiday_date` BETWEEN ? AND ?
            AND `status` = 1
            AND `deleted_at` IS NULL
            AND DAYOFWEEK(`holiday_date`) <> 1"; // Exclude Sundays

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return 0; // Query prepare failed
    }
    $stmt->bind_param("ss", $firstDate, $lastDate);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $res['total'] ?? 0;
}

/**
 * Resolves the company scope of the signed-in user so legacy call sites can
 * still reach the finalized master calendar without passing an explicit id.
 */
function resolveSessionCompanyId($conn): ?int
{
    static $resolved = false;
    static $companyId = null;
    if ($resolved) {
        return $companyId;
    }
    $resolved = true;
    $userId = (int) ($_SESSION['user_id'] ?? 0);
    if ($userId <= 0) {
        return $companyId;
    }
    $stmt = $conn->prepare('SELECT company_id FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1');
    if (!$stmt) {
        return $companyId;
    }
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $companyId = !empty($row['company_id']) ? (int) $row['company_id'] : null;
    return $companyId;
}

function getHolidayDates($conn, $firstDate, $lastDate, ?int $companyId = null, bool $masterOnly = false)
{
    // The finalized annual calendar is the master source; legacy rows are pre-cutover fallback only.
    if (function_exists('acGetHolidayDatesForRange')) {
        $companyId = $companyId ?? resolveSessionCompanyId($conn);
        $annualDates = acGetHolidayDatesForRange($conn, $firstDate, $lastDate, $companyId);
        if ($annualDates !== null) {
            return $annualDates;
        }
    }
    if ($masterOnly) {
        return null;
    }

    // Legacy fallback: read from the holidays table
    $sql = "SELECT holiday_date FROM holidays
            WHERE holiday_date BETWEEN ? AND ?
            AND status = 1
            AND deleted_at IS NULL
            AND DAYOFWEEK(holiday_date) <> 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $firstDate, $lastDate);
    $stmt->execute();

    $result = $stmt->get_result();
    $dates = [];

    while ($row = $result->fetch_assoc()) {
        $dates[] = $row['holiday_date'];
    }

    return $dates;
}

function generateUniquePoOrderNumForRaw($conn)
{
    $today = date('Ymd');

    // Get last PO number for today
    $sql = "SELECT `po_order_num` 
            FROM `purchase_order_raw` 
            WHERE `po_order_num` LIKE ? 
            ORDER BY id DESC 
            LIMIT 1";
    $like = "BIPL-PO-{$today}-%";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();

    $lastSeq = 0;
    if ($row = $result->fetch_assoc()) {
        $parts = explode("-", $row['po_order_num']);
        $lastPart = end($parts);

        // Convert last Roman to integer
        $lastSeq = romanToInt($lastPart);
    }

    $nextSeq = $lastSeq + 1;
    $romanSeq = intToRoman($nextSeq);

    return "BIPL-PO-{$today}-{$romanSeq}";
}

/**
 * Convert integer to Roman numeral
 */
function intToRoman($num)
{
    $map = [
        'M' => 1000,
        'CM' => 900,
        'D' => 500,
        'CD' => 400,
        'C' => 100,
        'XC' => 90,
        'L' => 50,
        'XL' => 40,
        'X' => 10,
        'IX' => 9,
        'V' => 5,
        'IV' => 4,
        'I' => 1
    ];
    $returnValue = '';
    foreach ($map as $roman => $int) {
        while ($num >= $int) {
            $returnValue .= $roman;
            $num -= $int;
        }
    }
    return $returnValue;
}

/**
 * Convert Roman numeral to integer
 */
function romanToInt($roman)
{
    $map = [
        'I' => 1,
        'V' => 5,
        'X' => 10,
        'L' => 50,
        'C' => 100,
        'D' => 500,
        'M' => 1000
    ];

    $result = 0;
    $prevValue = 0;

    $roman = strtoupper($roman);
    for ($i = strlen($roman) - 1; $i >= 0; $i--) {
        $value = $map[$roman[$i]] ?? 0;
        if ($value < $prevValue) {
            $result -= $value;
        } else {
            $result += $value;
        }
        $prevValue = $value;
    }
    return $result;
}

function PORawPdf(array $row): string
{
    $poNumber = htmlspecialchars($row['po_order_num'] ?? '');
    $vendor = htmlspecialchars($row['vendor'] ?? '');
    $extraNote = htmlspecialchars($row['extraNote'] ?? '');
    $date = htmlspecialchars($row['created_at'] ?? date('d-m-Y'));
    $row["id"] = 1;
    $companyAddressHtml = 'B19/A S.I.L. Ancillary Estate, Amausi<br>Industrial Area, Nadarganj-226008<br>(Lucknow)<br>GSTN: 09AACGB6941G1ZJ';
    if (trim((string) ($row['shipment_address_snapshot'] ?? '')) !== '') {
        $companyAddressHtml = nl2br(htmlspecialchars($row['shipment_address_snapshot'], ENT_QUOTES, 'UTF-8'));
        if (trim((string) ($row['shipment_gst_snapshot'] ?? '')) !== '') {
            $companyAddressHtml .= '<br>GSTN: ' . htmlspecialchars($row['shipment_gst_snapshot'], ENT_QUOTES, 'UTF-8');
        }
    }

    $html = '';
    $chunks = array_chunk($row['items'], 15);
    $html .= '<div class="row invoice-preview">';
    $html .= '<div class="col-xl-10 col-md-8 col-12 mb-md-0 mb-4">
                <div class="card border border-slate-200 !rounded-xl bg-white shadow-sm">
                    <div style="overflow-x: auto; width: 100%;">                        
                        <div style="font-family: Calibri, Arial, sans-serif !important; font-size: 14px; margin: 0; padding: 10px;">';
    $html .= '<div id="transferTicketContent-' . $row["id"] . '" style="width: 100%; max-width: 794px; padding: 15px !important; margin: auto;">';
    foreach ($chunks as $pageIndex => $pageProducts) {

        $html .= '<div class="transfer-copy">                            
                    <div style="border: 2px solid #000; margin-bottom:10px;">
                        <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                            <tr>
                                <!-- Left side: Logo + Company Info -->
                                <td style="width: 30%; border-right: 2px solid #000; padding:0; vertical-align: top;">
                                    <table style="width:100%; border-collapse: collapse;">
                                        <tr>
                                            <td style="border-bottom: 2px solid #000; padding:5px;">
                                                <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 60px; vertical-align: middle; padding-left:10px;">
                                                <div style="font-size:11px; font-weight:700; margin-top:5px;">
                                                    CIN NO. U24304UP2016PTC082775
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="po-doc-company-address-view" style="padding:6px; font-size:12px; line-height:1.3;">
                                                ' . $companyAddressHtml . '
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td style="width: 30%; border-right: 2px solid #000; text-align:center; vertical-align: middle;">
                                    <strong style="font-size:16px;">TITLE: Purchase Order</strong>
                                </td>
                                <td style="width: 40%; vertical-align: top; padding:0px;">
                                    <table style="width: 100%; border-collapse: collapse; font-size:12px;">
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; width:50%; font-weight:700;">Document No.</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">BIPL-F-PO-01</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Issue No.</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">01</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Revision No.</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">02</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Effective Date</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">03/04/2025</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Review Date</td>
                                            <td style="padding:4px;border-bottom:2px solid #000;">02/04/2028</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;border-bottom:2px solid #000;padding:4px; font-weight:700;">Department</td>
                                            <td style="border-bottom:2px solid #000;padding:4px;">Purchase</td>
                                        </tr>
                                        <tr>
                                            <td style="border-right:2px solid #000;padding:4px; font-weight:700;">Supersedes</td>
                                            <td style="padding:4px;">Nil</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>';

        $html .= '<div style="padding: 15px;">
            <table style="width: 100%; border-collapse: collapse; margin-top: 0px;">
                <tr style="line-height: 30px;">
                    <td style="width: 65%; font-weight:500 !important;">' . $poNumber . '</td>
                    <td style="width: 25%;">Date: ' . $date . '</td>
                </tr>
                <tr style="line-height: 30px;">
                    <td style="width: 65%; font-weight:600 !important;">' . $vendor . '</td>
                    <td style="width: 25%;"></td>
                </tr>
            </table>
        </div>';

        $html .= '<table style="border:2px solid #000; border-collapse:collapse; width:100%; text-align:center; font-size:14px;">
                <thead>
                    <tr>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">S. no</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Product(s)</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Cat No</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Size</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Thickness</th>
                        <th style="border:2px solid #000; padding:6px; font-weight:900 !important;">Qty</th>                        
                    </tr>
                </thead>
                <tbody>';
        foreach ($pageProducts as $p) {
            $html .= '<tr>
                        <td style="border:2px solid #000; padding:6px; text-align:center;">' . $p['serial'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['name'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['catno'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['size'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['thickness'] . '</td>
                        <td style="border:2px solid #000; padding:6px;">' . $p['qty'] . '</td>
                    </tr>';
        }
        $html .= '
                </tbody>
            </table>';

        if ($pageIndex === array_key_last($chunks)) {
            if (!empty($extraNote)) {
                $html .= '<div style="margin-top:18px; font-size:14px;">
                                <div style="margin-bottom:10px; font-weight:700 !important;">' . $extraNote . '</div>                            
                            </div>';
            }
            $html .= '<div style="margin-top:18px; font-size:14px;">
                            <div style="margin-bottom:10px;">Yours Sincerely,</div>
                            <img src="' . asset('assets/img/stamp_logo.jpeg') . '" style="height:80px;" />
                            <div style="margin-top:12px;">Biogenix Inc Pvt Ltd.</div>
                        </div>';
        }
        $html .= '<div style="margin-top:30px;">
                <table style="width:100%; border:2px solid #000; border-collapse:collapse; text-align:left; padding: 15px;">
                    <tr>
                        <td style="width:50%; border:2px solid #000; padding:15px;">
                            <b>Format Prepared by :</b> MR/QA
                        </td>
                        <td style="width:50%; border:2px solid #000; padding:15px;">
                            <b>Format Approved by:</b> Head of the organization
                        </td>
                    </tr>
                </table>
            </div></div>';
        $html .= '<br/><br/><br/>';
    }

    $html .= ' </div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-xl-2 col-md-4 col-12 invoice-actions">
            <div class="card border border-slate-200 !rounded-xl bg-white shadow-sm">
                <div class="card-body p-4">
                    <button class="inline-flex h-10 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 pdfPurchaseOrderRawDownloadBtn" data-id ="' . base64_encrypt($poNumber) . '">
                        <i class="ti ti-download text-base"></i> Download
                    </button>
                </div>
            </div>
        </div>';
    $html .= '</div>'; // closing tags


    return $html;
}


function inventoryEnsureBalance(mysqli $conn, int $productId, int $userId = 0): int
{
    if ($productId <= 0) {
        throw new InvalidArgumentException('A valid product is required.');
    }
    $lookup = $conn->prepare(
        'SELECT stock.id
         FROM live_stock stock
         INNER JOIN products product ON product.id = stock.product_id
         WHERE stock.product_id = ? AND product.status = 1
           AND product.deleted_at IS NULL
         ORDER BY stock.id ASC
         LIMIT 1'
    );
    if ($lookup) {
        $lookup->bind_param('i', $productId);
        $lookup->execute();
        $stockId = (int) ($lookup->get_result()->fetch_assoc()['id'] ?? 0);
        $lookup->close();
        if ($stockId > 0) {
            return $stockId;
        }
    }

    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resColName = $hasReservedQty ? 'reserved_qty' : ($hasReservedQuantity ? 'reserved_quantity' : null);
    $resInsertCol = $resColName ? ", `{$resColName}`" : '';
    $resInsertVal = $resColName ? ', 0' : '';

    $stmt = $conn->prepare(
        "INSERT INTO live_stock
            (product_id, quantity_available{$resInsertCol}, status, created_by, created_at)
         SELECT id, 0{$resInsertVal}, 0, ?, NOW()
         FROM products
         WHERE id = ? AND status = 1 AND deleted_at IS NULL"
    );
    if ($stmt) {
        $stmt->bind_param('ii', $userId, $productId);
        $stmt->execute();
        $stockId = (int) $conn->insert_id;
        $stmt->close();
    } else {
        $stockId = 0;
    }
    if ($stockId <= 0) {
        throw new RuntimeException('Product inventory balance is unavailable.');
    }
    return $stockId;
}

function inventoryGetBalance(
    mysqli $conn,
    int $productId,
    bool $forUpdate = false,
    bool $includeInactive = true
): ?array {
    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resCol = $hasReservedQty ? '`reserved_qty`' : ($hasReservedQuantity ? '`reserved_quantity`' : '0');

    $hasUnreservedQty = mvDbColumnExists($conn, 'live_stock', 'unreserved_qty');
    $unresExpr = $hasUnreservedQty ? '`unreserved_qty`' : "GREATEST(0, quantity_available - COALESCE({$resCol}, 0))";

    $sql = "SELECT 
                COALESCE(MIN(id), 0) AS id,
                product_id,
                COALESCE(SUM(quantity_available), 0) AS quantity_available,
                COALESCE(SUM(COALESCE({$resCol}, 0)), 0) AS reserved_qty,
                COALESCE(SUM(COALESCE({$resCol}, 0)), 0) AS reserved_quantity,
                COALESCE(SUM(COALESCE({$unresExpr}, 0)), 0) AS unreserved_qty,
                MAX(status) AS status,
                NULL AS deleted_at
            FROM live_stock
            WHERE product_id = ? AND deleted_at IS NULL";
    if (!$includeInactive) {
        $sql .= ' AND status = 1';
    }
    $sql .= ' GROUP BY product_id LIMIT 1' . ($forUpdate ? ' FOR UPDATE' : '');
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $row;
}

function inventoryLogMovement(
    mysqli $conn,
    int $productId,
    int $liveStockId,
    string $movementType,
    float $quantity,
    int $userId,
    ?string $sourceType = null,
    ?int $sourceId = null,
    ?string $referenceKey = null,
    ?string $notes = null
): void {
    $balance = inventoryGetBalance($conn, $productId);
    if (!$balance) {
        inventoryWriteOptionalTransactionAudit(
            $conn,
            $quantity,
            $movementType,
            $productId,
            $liveStockId,
            $userId,
            $sourceType,
            $sourceId,
            $referenceKey,
            $notes,
            null
        );
        return;
    }
    $stmt = $conn->prepare(
        'INSERT INTO inventory_movements
            (product_id, live_stock_id, movement_type, quantity,
             quantity_available_after, reserved_qty_after,
             source_type, source_id, reference_key, notes, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    if (!$stmt) {
        inventoryWriteOptionalTransactionAudit(
            $conn,
            $quantity,
            $movementType,
            $productId,
            $liveStockId,
            $userId,
            $sourceType,
            $sourceId,
            $referenceKey,
            $notes,
            $balance
        );
        return;
    }
    $total = (float) $balance['quantity_available'];
    $reserved = (float) ($balance['reserved_qty'] ?? $balance['reserved_quantity'] ?? 0);
    $stmt->bind_param(
        'iisdddsissi',
        $productId,
        $liveStockId,
        $movementType,
        $quantity,
        $total,
        $reserved,
        $sourceType,
        $sourceId,
        $referenceKey,
        $notes,
        $userId
    );
    $stmt->execute();
    $stmt->close();
    inventoryWriteOptionalTransactionAudit(
        $conn,
        $quantity,
        $movementType,
        $productId,
        $liveStockId,
        $userId,
        $sourceType,
        $sourceId,
        $referenceKey,
        $notes,
        $balance
    );
}

/**
 * Best-effort plug-in bridge. Audit storage is intentionally outside the
 * inventory success contract and can never throw into a business flow.
 */
function inventoryWriteOptionalTransactionAudit(
    mysqli $conn,
    float $quantity,
    string $actionName,
    int $productId,
    int $liveStockId,
    int $userId,
    ?string $sourceType,
    ?int $sourceId,
    ?string $referenceKey,
    ?string $notes,
    ?array $balance
): void {
    try {
        require_once __DIR__ . '/sync/InventoryTransactionAudit.php';
        InventoryTransactionAudit::record($conn, $quantity, [
            'action_name' => $actionName,
            'product_id' => $productId,
            'live_stock_id' => $liveStockId,
            'quantity_available_after' => $balance['quantity_available'] ?? null,
            'reserved_quantity_after' => $balance['reserved_qty'] ?? $balance['reserved_quantity'] ?? null,
            'unreserved_quantity_after' => $balance['unreserved_qty'] ?? null,
            'source_type' => $sourceType,
            'source_id' => $sourceId,
            'reference_key' => $referenceKey,
            'performed_by' => $userId,
            'request_id' => $_SERVER['HTTP_X_REQUEST_ID'] ?? null,
            'notes' => $notes,
        ]);
    } catch (Throwable $exception) {
        error_log('Optional inventory audit bridge failed: ' . $exception->getMessage());
    }
}

function inventoryAddStock(
    mysqli $conn,
    int $productId,
    float $quantity,
    int $userId,
    string $sourceType,
    ?int $sourceId = null,
    ?string $referenceKey = null,
    ?string $notes = null
): int {
    if ($quantity <= 0) {
        throw new InvalidArgumentException('Stock quantity must be greater than zero.');
    }
    if ($referenceKey !== null && $referenceKey !== '') {
        $duplicate = $conn->prepare(
            'SELECT live_stock_id FROM inventory_movements WHERE reference_key = ? LIMIT 1'
        );
        if ($duplicate) {
            $duplicate->bind_param('s', $referenceKey);
            $duplicate->execute();
            $existingStockId = (int) ($duplicate->get_result()->fetch_assoc()['live_stock_id'] ?? 0);
            $duplicate->close();
            if ($existingStockId > 0) {
                return $existingStockId;
            }
        }
    }
    $stockId = inventoryEnsureBalance($conn, $productId, $userId);
    $stmt = $conn->prepare(
        'UPDATE live_stock
         SET quantity_available = quantity_available + ?, status = 1,
             updated_by = ?, updated_at = NOW()
         WHERE id = ? AND deleted_at IS NULL'
    );
    $stmt->bind_param('dii', $quantity, $userId, $stockId);
    $stmt->execute();
    if ($stmt->affected_rows !== 1) {
        $stmt->close();
        throw new RuntimeException('Unable to add stock to an inactive or deleted balance.');
    }
    $stmt->close();
    inventoryLogMovement(
        $conn,
        $productId,
        $stockId,
        'stock_in',
        $quantity,
        $userId,
        $sourceType,
        $sourceId,
        $referenceKey,
        $notes
    );
    return $stockId;
}

function inventorySetUnreservedStock(
    mysqli $conn,
    int $productId,
    float $unreservedQuantity,
    int $userId,
    string $sourceType = 'product_edit'
): int {
    if ($unreservedQuantity < 0) {
        throw new InvalidArgumentException('Unreserved stock cannot be negative.');
    }
    $stockId = inventoryEnsureBalance($conn, $productId, $userId);
    $before = inventoryGetBalance($conn, $productId, true);
    if (!$before) {
        throw new RuntimeException('Product inventory balance is unavailable.');
    }
    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resCol = $hasReservedQty ? '`reserved_qty`' : ($hasReservedQuantity ? '`reserved_quantity`' : '0');

    $delta = $unreservedQuantity - (float) ($before['unreserved_qty'] ?? 0);
    $stmt = $conn->prepare(
        "UPDATE live_stock
         SET quantity_available = {$resCol} + ?,
             status = CASE WHEN {$resCol} + ? > 0 THEN 1 ELSE 0 END,
             updated_by = ?, updated_at = NOW()
         WHERE id = ? AND deleted_at IS NULL"
    );
    $stmt->bind_param('ddii', $unreservedQuantity, $unreservedQuantity, $userId, $stockId);
    $stmt->execute();
    if ($stmt->affected_rows > 1) {
        $stmt->close();
        throw new RuntimeException('More than one inventory balance was changed.');
    }
    $stmt->close();
    inventoryLogMovement(
        $conn,
        $productId,
        $stockId,
        'adjustment',
        $delta,
        $userId,
        $sourceType,
        $productId,
        null,
        'Set unreserved stock to ' . $unreservedQuantity
    );
    return $stockId;
}

function inventoryReserveStock(
    mysqli $conn,
    int $productId,
    float $quantity,
    int $userId
): int {
    if ($quantity <= 0) {
        throw new InvalidArgumentException('Reservation quantity must be greater than zero.');
    }
    $stockId = inventoryEnsureBalance($conn, $productId, $userId);
    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resCol = $hasReservedQty ? '`reserved_qty`' : ($hasReservedQuantity ? '`reserved_quantity`' : '`reserved_qty`');

    $stmt = $conn->prepare(
        "UPDATE live_stock
         SET {$resCol} = {$resCol} + ?, updated_by = ?, updated_at = NOW()
         WHERE id = ? AND status = 1 AND deleted_at IS NULL
           AND (quantity_available - {$resCol}) + 0.00000001 >= ?"
    );
    $stmt->bind_param('diid', $quantity, $userId, $stockId, $quantity);
    $stmt->execute();
    $changed = $stmt->affected_rows === 1;
    $stmt->close();
    if (!$changed) {
        throw new RuntimeException('Insufficient unreserved stock.');
    }
    inventoryLogMovement($conn, $productId, $stockId, 'reserve', $quantity, $userId);
    return $stockId;
}

function inventoryReleaseStock(
    mysqli $conn,
    int $productId,
    float $quantity,
    int $userId
): int {
    if ($quantity <= 0) {
        throw new InvalidArgumentException('Release quantity must be greater than zero.');
    }
    $stockId = inventoryEnsureBalance($conn, $productId, $userId);
    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resCol = $hasReservedQty ? '`reserved_qty`' : ($hasReservedQuantity ? '`reserved_quantity`' : '`reserved_qty`');

    $stmt = $conn->prepare(
        "UPDATE live_stock
         SET {$resCol} = {$resCol} - ?, updated_by = ?, updated_at = NOW()
         WHERE id = ? AND deleted_at IS NULL
           AND {$resCol} + 0.00000001 >= ?"
    );
    $stmt->bind_param('diid', $quantity, $userId, $stockId, $quantity);
    $stmt->execute();
    $changed = $stmt->affected_rows === 1;
    $stmt->close();
    if (!$changed) {
        throw new RuntimeException('Reserved stock is lower than the requested release.');
    }
    inventoryLogMovement($conn, $productId, $stockId, 'release', -$quantity, $userId);
    return $stockId;
}

function inventoryConsumeReservedStock(
    mysqli $conn,
    int $productId,
    float $quantity,
    int $userId,
    string $sourceType,
    ?int $sourceId = null
): int {
    if ($quantity <= 0) {
        throw new InvalidArgumentException('Dispatch quantity must be greater than zero.');
    }
    $stockId = inventoryEnsureBalance($conn, $productId, $userId);
    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resCol = $hasReservedQty ? '`reserved_qty`' : ($hasReservedQuantity ? '`reserved_quantity`' : '`reserved_qty`');

    $stmt = $conn->prepare(
        "UPDATE live_stock
         SET quantity_available = quantity_available - ?,
             {$resCol} = {$resCol} - ?,
             status = CASE WHEN quantity_available - ? <= 0.00000001 THEN 0 ELSE 1 END,
             updated_by = ?, updated_at = NOW()
         WHERE id = ? AND status = 1 AND deleted_at IS NULL
           AND quantity_available + 0.00000001 >= ?
           AND {$resCol} + 0.00000001 >= ?"
    );
    $stmt->bind_param(
        'dddiidd',
        $quantity,
        $quantity,
        $quantity,
        $userId,
        $stockId,
        $quantity,
        $quantity
    );
    $stmt->execute();
    $changed = $stmt->affected_rows === 1;
    $stmt->close();
    if (!$changed) {
        throw new RuntimeException('Insufficient reserved stock for dispatch.');
    }
    inventoryLogMovement(
        $conn,
        $productId,
        $stockId,
        'reserved_out',
        -$quantity,
        $userId,
        $sourceType,
        $sourceId
    );
    return $stockId;
}

function inventoryConsumeUnreservedStock(
    mysqli $conn,
    int $productId,
    float $quantity,
    int $userId,
    string $sourceType,
    ?int $sourceId = null
): int {
    if ($quantity <= 0) {
        throw new InvalidArgumentException('Issue quantity must be greater than zero.');
    }
    $stockId = inventoryEnsureBalance($conn, $productId, $userId);
    $hasReservedQty = mvDbColumnExists($conn, 'live_stock', 'reserved_qty');
    $hasReservedQuantity = mvDbColumnExists($conn, 'live_stock', 'reserved_quantity');
    $resCol = $hasReservedQty ? '`reserved_qty`' : ($hasReservedQuantity ? '`reserved_quantity`' : '0');

    $stmt = $conn->prepare(
        "UPDATE live_stock
         SET quantity_available = quantity_available - ?,
             status = CASE WHEN quantity_available - ? <= 0.00000001 THEN 0 ELSE 1 END,
             updated_by = ?, updated_at = NOW()
         WHERE id = ? AND status = 1 AND deleted_at IS NULL
           AND (quantity_available - {$resCol}) + 0.00000001 >= ?"
    );
    $stmt->bind_param('ddiid', $quantity, $quantity, $userId, $stockId, $quantity);
    $stmt->execute();
    $changed = $stmt->affected_rows === 1;
    $stmt->close();
    if (!$changed) {
        throw new RuntimeException('Insufficient unreserved stock.');
    }
    inventoryLogMovement(
        $conn,
        $productId,
        $stockId,
        'unreserved_out',
        -$quantity,
        $userId,
        $sourceType,
        $sourceId
    );
    return $stockId;
}

function inventoryRestoreStock(
    mysqli $conn,
    int $productId,
    float $quantity,
    int $userId,
    string $sourceType,
    ?int $sourceId = null
): int {
    return inventoryAddStock(
        $conn,
        $productId,
        $quantity,
        $userId,
        $sourceType,
        $sourceId,
        null,
        'Reversal or return'
    );
}

function updateLiveStockDepleteToAvailable($conn)
{
    $sql = 'UPDATE live_stock SET status = 1 WHERE quantity_available > 0 AND status = 0 AND deleted_at IS NULL';
    if ($stmt = $conn->prepare($sql)) {
        $stmt->execute();
        $stmt->close();
    }
}

function checkOrderSubItemsStatus($conn, $orderId)
{
    $sql = "SELECT COUNT(*) AS pending_count
            FROM `order_received_items`
            WHERE `order_id` = ? AND `status` != 5 AND `status` != 3 AND `deleted_at` IS NULL";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return ($result && $result['pending_count'] > 0)
        ? Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Partial_Delivered']
        : Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Dispatched'];
}

// mysqli error reporting is disabled globally, so a failed query() returns false rather than throwing.
function queryScalar(mysqli $conn, string $sql, string $column): int
{
    $result = $conn->query($sql);
    if ($result === false) {
        error_log('queryScalar failed: ' . $conn->error . ' | SQL: ' . $sql);
        return 0;
    }

    $row = $result->fetch_assoc();
    $result->free();

    return (int) ($row[$column] ?? 0);
}

function getActiveInactivePercent($conn, $companyType, $categoryType, $filterType = null, $fromDate = null, $toDate = null)
{
    // Total employees
    $sqlTotal = "SELECT COUNT(*) AS total 
                 FROM `employees`
                 WHERE `company` = {$companyType}
                 AND `emp_categ_type` = {$categoryType}
                 AND `status` = 1
                 AND `deleted_at` IS NULL";
    $total = queryScalar($conn, $sqlTotal, 'total');

    // Active employees
    // $sqlActive = "SELECT COUNT(DISTINCT s.employee_id) AS active
    //               FROM `worker_attendance_sessions` s
    //               INNER JOIN `employees` e ON e.id = s.employee_id
    //               WHERE DATE(s.in_time) = CURDATE()
    //               AND s.`status` = 1
    //               AND s.`deleted_at` IS NULL
    //               AND e.`company` = {$companyType}
    //               AND e.`emp_categ_type` = {$categoryType}";
    $sqlActive = "SELECT COUNT(DISTINCT s.employee_id) AS active 
                    FROM `worker_attendance_sessions` s
                    INNER JOIN employees e ON e.id = s.employee_id
                    WHERE DATE(s.in_time) = CURDATE()
                    AND s.status = 1
                    AND s.deleted_at IS NULL
                    AND e.company = {$companyType}
                    AND e.emp_categ_type = {$categoryType}
                    AND e.status = 1
                    AND e.deleted_at IS NULL;";
    $active = queryScalar($conn, $sqlActive, 'active');
    $inactive = max($total - $active, 0);
    $presentPercent = $total > 0 ? round(($active / $total) * 100) : 0;
    $absentPercent = 100 - $presentPercent;

    return [
        'total' => $total,
        'present' => $active,
        'absent' => $inactive,
        'present_percent' => $presentPercent,
        'absent_percent' => $absentPercent,
        'company_type' => $companyType,
        'category_type' => $categoryType,
    ];
}

function buildAttendanceCard($title, $total, $bioData, $labData)
{
    ob_start(); ?>
    <div
        class="flex flex-col h-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition-all hover:shadow-md">
        <div class="flex items-center justify-between border-b border-slate-100 bg-slate-50/70 px-4 py-3">
            <h5 class="m-0 text-[11px] font-bold uppercase tracking-wider text-slate-600 truncate pe-2"
                title="<?= htmlspecialchars($title) ?>"><?= htmlspecialchars($title) ?></h5>
            <span
                class="inline-flex shrink-0 items-center justify-center rounded-md bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                <?= htmlspecialchars($total) ?>
            </span>
        </div>
        <div class="flex flex-grow flex-col justify-start p-4" style="gap: 15px;">
            <?php foreach (['BIO' => $bioData, 'LAB' => $labData] as $label => $data): ?>
                <?php if (!empty($data['total'])) { ?>
                    <div
                        class="rounded-lg border border-slate-200 bg-slate-50/50 p-3 transition-colors hover:border-slate-300 hover:bg-slate-50">
                        <div class="mb-3 flex items-start justify-between">
                            <div class="flex items-center">
                                <span
                                    class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg shadow-sm <?= $label === 'BIO' ? 'bg-label-primary text-primary' : 'bg-label-success text-success' ?>">
                                    <i class="ti <?= $label === 'BIO' ? 'ti-building-factory' : 'ti-flask' ?> text-base"></i>
                                </span>
                                <div class="ms-2 flex flex-col">
                                    <span
                                        class="text-[9px] font-bold uppercase tracking-widest text-slate-400 leading-none mb-0.5"><?= $label ?>
                                        DEPT</span>
                                    <span
                                        class="text-xs font-bold text-slate-800 leading-none"><?= htmlspecialchars($data['total']) ?>
                                        Total</span>
                                </div>
                            </div>

                            <div class="flex flex-col items-end gap-1.5">
                                <div class="absent-data flex cursor-pointer items-center gap-1.5 transition-opacity hover:opacity-80"
                                    title="View Present" data-company="<?= htmlspecialchars($data['company_type']) ?>"
                                    data-attendance-type="P" data-category="<?= htmlspecialchars($data['category_type']) ?>">
                                    <div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-sm"></div>
                                    <span class="text-[11px] font-bold text-slate-600 leading-none"><span
                                            class="text-emerald-600"><?= htmlspecialchars($data['present']) ?></span> Present</span>
                                </div>
                                <div class="absent-data flex cursor-pointer items-center gap-1.5 transition-opacity hover:opacity-80"
                                    title="View Absent" data-company="<?= htmlspecialchars($data['company_type']) ?>"
                                    data-attendance-type="A" data-category="<?= htmlspecialchars($data['category_type']) ?>">
                                    <div class="h-1.5 w-1.5 rounded-full bg-rose-500 shadow-sm"></div>
                                    <span class="text-[11px] font-bold text-slate-600 leading-none"><span
                                            class="text-rose-600"><?= htmlspecialchars($data['absent']) ?></span> Absent</span>
                                </div>
                            </div>
                        </div>

                        <div class="relative h-1 w-full overflow-hidden rounded-full bg-slate-200/80 shadow-inner">
                            <?php if ($data['present_percent'] > 0) { ?>
                                <div class="absolute left-0 top-0 h-full rounded-full bg-emerald-500"
                                    style="width: <?= $data['present_percent'] ?>%"></div>
                            <?php } ?>
                            <?php if ($data['absent_percent'] > 0) { ?>
                                <div class="absolute right-0 top-0 h-full rounded-full bg-rose-500"
                                    style="width: <?= $data['absent_percent'] ?>%"></div>
                            <?php } ?>
                        </div>
                        <div class="mt-1 flex justify-between px-1 text-[11px] font-bold uppercase tracking-wide text-slate-400">
                            <span><?= $data['present_percent'] ?>%</span>
                            <span><?= $data['absent_percent'] ?>%</span>
                        </div>
                    </div>
                <?php } ?>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function buildEmployeeCard($title, $total, $bioData, $labData)
{
    ob_start(); ?>
    <div class="col-xl-4 col-md-4 mb-4">
        <div
            class="flex flex-col h-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition-all hover:shadow-md">
            <div class="flex items-center justify-between border-b border-slate-100 bg-slate-50/70 px-4 py-3">
                <h5 class="m-0 text-[11px] font-bold uppercase tracking-wider text-slate-600 truncate pe-2"
                    title="<?= htmlspecialchars($title) ?>"><?= htmlspecialchars($title) ?></h5>
                <span
                    class="inline-flex shrink-0 items-center justify-center rounded-md bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                    <?= htmlspecialchars($total) ?>
                </span>
            </div>
            <div class="flex flex-grow flex-col justify-start p-4" style="gap: 15px;">
                <?php foreach (['BIO' => $bioData, 'LAB' => $labData] as $label => $data): ?>
                    <?php if (!empty($data['total'])) { ?>
                        <div
                            class="rounded-lg border border-slate-200 bg-slate-50/50 p-3 transition-colors hover:border-slate-300 hover:bg-slate-50">
                            <div class="mb-3 flex items-start justify-between">
                                <div class="flex items-center">
                                    <span
                                        class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg shadow-sm <?= $label === 'BIO' ? 'bg-label-primary text-primary' : 'bg-label-success text-success' ?>">
                                        <i class="ti <?= $label === 'BIO' ? 'ti-building-factory' : 'ti-flask' ?> text-base"></i>
                                    </span>
                                    <div class="ms-2 flex flex-col">
                                        <span
                                            class="text-[9px] font-bold uppercase tracking-widest text-slate-400 leading-none mb-0.5"><?= $label ?>
                                            DEPT</span>
                                        <span
                                            class="text-xs font-bold text-slate-800 leading-none"><?= htmlspecialchars($data['total']) ?>
                                            Total</span>
                                    </div>
                                </div>

                                <div class="flex flex-col items-end gap-1.5">
                                    <div class="absent-data flex cursor-pointer items-center gap-1.5 transition-opacity hover:opacity-80"
                                        title="View Active" data-company="<?= htmlspecialchars($data['company_type']) ?>"
                                        data-status-type="1" data-category="<?= htmlspecialchars($data['category_type']) ?>">
                                        <div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-sm"></div>
                                        <span class="text-[11px] font-bold text-slate-600 leading-none"><span
                                                class="text-emerald-600"><?= htmlspecialchars($data['active'] ?? 0) ?></span>
                                            Active</span>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <div class="absent-data flex cursor-pointer items-center gap-1.5 transition-opacity hover:opacity-80"
                                            title="View Inactive" data-company="<?= htmlspecialchars($data['company_type']) ?>"
                                            data-status-type="0" data-category="<?= htmlspecialchars($data['category_type']) ?>">
                                            <div class="h-1.5 w-1.5 rounded-full bg-rose-500 shadow-sm"></div>
                                            <span class="text-[10px] font-bold text-slate-600 leading-none"><span
                                                    class="text-rose-600"><?= htmlspecialchars($data['inactive'] ?? 0) ?></span>
                                                Inactive</span>
                                        </div>
                                        <div class="absent-data flex cursor-pointer items-center gap-1.5 transition-opacity hover:opacity-80"
                                            title="View Resigned" data-company="<?= htmlspecialchars($data['company_type']) ?>"
                                            data-status-type="2" data-category="<?= htmlspecialchars($data['category_type']) ?>">
                                            <div class="h-1.5 w-1.5 rounded-full bg-slate-400 shadow-sm"></div>
                                            <span class="text-[10px] font-bold text-slate-600 leading-none"><span
                                                    class="text-slate-500"><?= htmlspecialchars($data['resigned'] ?? 0) ?></span>
                                                Resigned</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="relative h-1 w-full overflow-hidden rounded-full bg-slate-200/80 shadow-inner flex">
                                <?php if ($data['active_percent'] > 0) { ?>
                                    <div class="h-full bg-emerald-500" style="width: <?= $data['active_percent'] ?>%"></div>
                                <?php } ?>
                                <?php if ($data['inactive_percent'] > 0) { ?>
                                    <div class="h-full bg-rose-500" style="width: <?= $data['inactive_percent'] ?>%"></div>
                                <?php } ?>
                                <?php if ($data['resigned_percent'] > 0) { ?>
                                    <div class="h-full bg-slate-400" style="width: <?= $data['resigned_percent'] ?>%"></div>
                                <?php } ?>
                            </div>
                            <div
                                class="mt-1 flex justify-between px-1 text-[11px] font-bold uppercase tracking-wide text-slate-400">
                                <span class="text-emerald-500"><?= $data['active_percent'] ?>%</span>
                                <div class="flex gap-3">
                                    <span class="text-rose-500"><?= $data['inactive_percent'] ?>%</span>
                                    <span class="text-slate-400"><?= $data['resigned_percent'] ?>%</span>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function getEmployeeCounts($conn, $companyType, $categoryType)
{
    $sqlTotal = "SELECT COUNT(*) AS total 
                 FROM `employees`
                 WHERE `company` = {$companyType}
                 AND `emp_categ_type` = {$categoryType}
                 AND `status` IN (0,1,2)
                 AND `deleted_at` IS NULL";
    $total = queryScalar($conn, $sqlTotal, 'total');

    $sqlBio = "SELECT COUNT(DISTINCT s.employee_id) AS bio_total
               FROM `worker_attendance_sessions` s
               INNER JOIN `employees` e ON e.id = s.employee_id
               WHERE e.`company` = {$companyType}
               AND e.`emp_categ_type` = {$categoryType}
               AND e.`deleted_at` IS NULL
               AND s.`deleted_at` IS NULL";
    $bioTotal = queryScalar($conn, $sqlBio, 'bio_total');

    $sqlActive = "SELECT COUNT(*) AS active
                  FROM `employees`
                  WHERE `company` = {$companyType}
                  AND `emp_categ_type` = {$categoryType}
                  AND `status` = " . Constant::EMPLOYEES['STATUS_TYPES_LABEL']['Active'] . "
                  AND `deleted_at` IS NULL";
    $active = queryScalar($conn, $sqlActive, 'active');

    $sqlInactive = "SELECT COUNT(*) AS inactive
                    FROM `employees`
                    WHERE `company` = {$companyType}
                    AND `emp_categ_type` = {$categoryType}
                    AND `status` = " . Constant::EMPLOYEES['STATUS_TYPES_LABEL']['Inactive'] . "
                    AND `deleted_at` IS NULL";
    $inactive = queryScalar($conn, $sqlInactive, 'inactive');

    $sqlResigned = "SELECT COUNT(*) AS resigned
                    FROM `employees`
                    WHERE `company` = {$companyType}
                    AND `emp_categ_type` = {$categoryType}
                    AND `status` = " . Constant::EMPLOYEES['STATUS_TYPES_LABEL']['Resigned'] . "
                    AND `deleted_at` IS NULL";
    $resigned = queryScalar($conn, $sqlResigned, 'resigned');
    $activePercent = $total > 0 ? round(($active / $total) * 100) : 0;
    $inactivePercent = $total > 0 ? round(($inactive / $total) * 100) : 0;
    $resignedPercent = $total > 0 ? round(($resigned / $total) * 100) : 0;

    return [
        'total' => $total,
        'bio_total' => $bioTotal,
        'active' => $active,
        'inactive' => $inactive,
        'resigned' => $resigned,
        'active_percent' => $activePercent,
        'inactive_percent' => $inactivePercent,
        'resigned_percent' => $resignedPercent,
        'company_type' => $companyType,
        'category_type' => $categoryType,
    ];
}

function generateUniqueMaterialRequisitionNum($conn)
{
    $today = date('d-m-Y');

    // Get last PO number for today
    $sql = "SELECT `auto_generated_batch` 
            FROM `material_requisition` 
            WHERE `auto_generated_batch` LIKE ? 
            ORDER BY `id` DESC 
            LIMIT 1";
    $like = "BIPL-MR-{$today}-%";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
    $lastSeq = 0;
    if ($row = $result->fetch_assoc()) {
        $parts = explode("-", $row['auto_generated_batch']);
        $lastSeq = intval(end($parts));
    }
    $nextSeq = str_pad($lastSeq + 1, 2, "0", STR_PAD_LEFT);

    return "BIPL-MR-{$today}-{$nextSeq}";
}

function generateUniqueProformaInvoice($conn)
{
    $today = date('Ymd');

    // Get last PO number for today
    $sql = "SELECT `pi_auto_batch` 
            FROM `proforma_invoices` 
            WHERE `pi_auto_batch` LIKE ? 
            ORDER BY id DESC 
            LIMIT 1";
    $like = "BIPL-PI-{$today}-%";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();

    $lastSeq = 0;
    if ($row = $result->fetch_assoc()) {
        $parts = explode("-", $row['pi_auto_batch']);
        $lastPart = end($parts);

        // Convert last Roman to integer
        $lastSeq = romanToInt($lastPart);
    }

    $nextSeq = $lastSeq + 1;
    $romanSeq = intToRoman($nextSeq);

    return "BIPL-PI-{$today}-{$romanSeq}";
}

// function convertNumberToWords($number)
// {
//     $no = floor($number);
//     $point = round($number - $no, 2) * 100;

//     $words = array(
//         '0' => '', '1' => 'One', '2' => 'Two', '3' => 'Three', '4' => 'Four',
//         '5' => 'Five', '6' => 'Six', '7' => 'Seven', '8' => 'Eight',
//         '9' => 'Nine', '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
//         '13' => 'Thirteen', '14' => 'Fourteen', '15' => 'Fifteen', '16' => 'Sixteen',
//         '17' => 'Seventeen', '18' => 'Eighteen', '19' => 'Nineteen',
//         '20' => 'Twenty', '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
//         '60' => 'Sixty', '70' => 'Seventy', '80' => 'Eighty', '90' => 'Ninety'
//     );

//     $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
//     $str = array();
//     $i = 0;

//     while ($no > 0) {
//         $divider = ($i == 1) ? 10 : 100;
//         $number_part = $no % $divider;
//         $no = floor($no / $divider);

//         if ($number_part) {
//             $str[] = ($number_part < 21)
//                 ? $words[$number_part] . " " . $digits[$i] . " "
//                 : $words[floor($number_part / 10) * 10] . " " . $words[$number_part % 10] . " " . $digits[$i] . " ";
//         } else {
//             $str[] = '';
//         }

//         $i += ($divider == 10) ? 1 : 2;
//     }

//     $rupees = trim(implode('', array_reverse($str)));

//     // Paise conversion
//     $paise = "";
//     if ($point > 0) {
//         if ($point < 21) {
//             $paise = $words[$point] . " Paise";
//         } else {
//             $paise = $words[floor($point / 10) * 10] . " " . $words[$point % 10] . " Paise";
//         }
//         return "Rupees " . $rupees . " and " . $paise . " Only";
//     }

//     // If no paise
//     return "Rupees " . $rupees . " Only";
// }

function convertNumberToWords($number)
{
    $no = floor($number);
    $point = round($number - $no, 2) * 100;
    $hundred = null;
    $digits_1 = strlen($no);
    $i = 0;
    $str = array();

    $words = array(
        '0' => '',
        '1' => 'One',
        '2' => 'Two',
        '3' => 'Three',
        '4' => 'Four',
        '5' => 'Five',
        '6' => 'Six',
        '7' => 'Seven',
        '8' => 'Eight',
        '9' => 'Nine',
        '10' => 'Ten',
        '11' => 'Eleven',
        '12' => 'Twelve',
        '13' => 'Thirteen',
        '14' => 'Fourteen',
        '15' => 'Fifteen',
        '16' => 'Sixteen',
        '17' => 'Seventeen',
        '18' => 'Eighteen',
        '19' => 'Nineteen',
        '20' => 'Twenty',
        '30' => 'Thirty',
        '40' => 'Forty',
        '50' => 'Fifty',
        '60' => 'Sixty',
        '70' => 'Seventy',
        '80' => 'Eighty',
        '90' => 'Ninety'
    );

    $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');

    while ($i < $digits_1) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += ($divider == 10) ? 1 : 2;

        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? '' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str[] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural . ' ' . $hundred :
                $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural . ' ' . $hundred;
        } else {
            $str[] = null;
        }
    }
    $str = array_reverse($str);
    $result = implode('', $str) . 'Rupees';

    return ucwords(trim($result) . ' Only');
}

function indianCommaFormat($number)
{
    $number = number_format((float) $number, 2, '.', ''); // ensure float

    list($int, $dec) = explode('.', $number);

    $last3 = substr($int, -3);
    $rest = substr($int, 0, -3);

    if ($rest != '') {
        $rest = preg_replace("/\B(?=(\d{2})+(?!\d))/", ",", $rest);
        return $rest . "," . $last3 . "." . $dec;
    } else {
        return $last3 . "." . $dec;
    }
}


function ProformaInvoicePdf(array $row): string
{
    $proInvId = $row["id"];
    $poNumber = htmlspecialchars($row['pi_auto_batch'] ?? '');
    $companyName = htmlspecialchars($row['company_name'] ?? '');
    $companyAddress = htmlspecialchars($row['company_address'] ?? '');
    $companyGst = htmlspecialchars($row['company_gst'] ?? '');
    $shipCompanyName = htmlspecialchars($row['ship_company_name'] ?? '');
    $shipCompanyAddress = htmlspecialchars($row['ship_company_address'] ?? '');
    $shipCompanyGst = htmlspecialchars($row['ship_company_gst'] ?? '');
    $attendantPerson = htmlspecialchars($row['attendant_person'] ?? '');
    $attendantContact = htmlspecialchars($row['attendant_contact'] ?? '');
    $enquiryMedium = htmlspecialchars($row['enquiry_medium'] ?? '');
    $enquiryDate = formatDateDMY(htmlspecialchars($row['enquiry_date'] ?? ''));
    $freightNotice = htmlspecialchars($row['freight_notice'] ?? '');
    $supplyPeriod = htmlspecialchars($row['supply_period'] ?? '');
    $date = formatDatePO(htmlspecialchars($row['created_at'] ?? ''));
    $freightAmount = round(floatval($row['freight_amount'] ?? 0), 2);
    $freightAmountDisp = number_format($freightAmount, 2, '.', '');
    $freightPercent = floatval($row['freight_percent'] ?? 0);
    $freight_percent_amount = floatval($row['freight_percent_amount'] ?? 0);
    $freightTotal = round(floatval($row['freight_total'] ?? 0), 2);
    $freightPercentAmanoutDisp = number_format($freight_percent_amount, 2, '.', '');
    $freightTotalDisp = number_format($freightTotal, 2, '.', '');
    $totalFreightValue = $freightAmount + $freight_percent_amount;
    $bottomLines = [];
    if (!empty($freightNotice)) {
        $bottomLines[] = $freightNotice;
    }
    if (!empty($supplyPeriod)) {
        $bottomLines[] = $supplyPeriod;
    }
    $bottomLines[] = 'All Disputes are subject to Lucknow Jurisdiction only';
    $html = '';
    $totPrc = 0.00;
    $totPrcFinal = 0.00;
    $totGst = 0.00;
    $totQty = 0.00;
    $totPrc += $totalFreightValue;
    $chunks = array_chunk($row['items'], 50);
    $html .= '<div class="row invoice-preview">
                <div class="col-xl-10 col-md-8 col-12 mb-md-0">
                    <div class="card">
                        <div style="overflow-x: auto; width: 100%;">
                            <div style="font-family: Calibri, Arial, sans-serif !important; font-size: 10px; margin: 0; padding: 10px;">
                                <div id="transferTicketContent" style="width: 100%; padding: 15px !important; margin: auto;">';
    foreach ($chunks as $pageIndex => $pageProducts) {
        $html .= '<div class="transfer-copy">
                    <div style=" margin-bottom:10px;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr style="line-height: 18px; ">
                                <td rowspan="2" style="width: 25%;border-left: 1px solid #000; border-top: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                                    <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 50px;">
                                </td>
                                <td style="width: 75%; border-right: 1px solid #000; border-top: 1px solid #000; border-bottom: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">PROFORMA INVOICE</strong></td>
                                
                            </tr>
                            <tr style="line-height: 18px; border-right: 1px solid #000; border-bottom: 1px solid #000;">                                                                
                                <td style="width: 75%; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">BIOGENIX INC. PVT. LTD.</strong></td>                                                               
                            </tr>
                            
                        </table>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr style="line-height: 15px; font-size:small;">
                                <td colspan="5" style="width: 100%; text-align:center;border-left: 1px solid #000;border-right: 1px solid #000; border-bottom: 1px solid #000; padding-left:10px;">
                                    B19/A, S.I.L. Ancillary Estate,<br />
                                    Amausi Industrial Area, Nadarganj-226008,<br />
                                    Lucknow (U.P.) <b>Mob.:</b> 9889485222, 9616105666<br />
                                    <b>E-mail:</b> biogenix2007@yahoo.com, info@biogenixinc.com
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 5%; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px; padding-right:5px; font-weight:600;font-size:medium;">GSTIN</td>
                                <td style="width: 35%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;">09AAGCB6941G1ZJ</td>
                                <td style="width: 20%; padding-left:5px;font-weight:700;"><u>Shipping Address</u></td>
                                <td style="width: 15%;border-bottom: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;">STATE CODE:</td>
                                <td style="width: 25%;border-right: 1px solid #000; border-bottom: 1px solid #000; padding-left:5px;font-weight:600;">9</td>
                            </tr>
                            <tr>
                                <td style="width: 5%; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;font-weight:600;">No. </td>
                                <td style="width: 35%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;">' . $poNumber . '</td>
                                <td rowspan="3" style="width: 20%; padding-left:5px; padding-left:5px;font-size:small;"> 
                                    <strong>' . $shipCompanyName . '</strong> <br> ' . $shipCompanyAddress . '<br>';
        if (!empty($shipCompanyGst)) {
            $html .= '<strong>GST.: ' . $shipCompanyGst . '</strong>';
        }
        $html .= '</td>
                                <td style="width: 15%; border-bottom: 1px solid #000;border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;font-weight:600;">Date: </td>
                                <td style="width: 25%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;">' . $date . '</td>
                            </tr>
                            <tr>
                                <td style="width: 5%; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;">M/s </td>
                                <td style="width: 35%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-size:small;">
                                    <strong>' . $companyName . '</strong> <br> ' . $companyAddress . '<br>
                                    <strong>GST.: ' . $companyGst . '</strong>
                                </td>
                                
                                <td colspan="2" style="width: 30%; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;"><strong>Kind Attn:</strong> ' . $attendantPerson;
        if (!empty($attendantContact)) {
            $html .= '<br /><strong>Attn Contact:</strong> ' . $attendantContact;
        }
        $html .= '</td>
                                
                            </tr>
                            <tr>
                                <td colspan="2" style="border-left:1px solid #000; border-right:1px solid #000;padding-left:5px;"><strong>Your Enquiry No.:</strong> ' . $enquiryMedium . '</td>
                                <td colspan="2" style="border-left:1px solid #000; border-right:1px solid #000;padding-left:5px;"><strong>Dated:</strong> ' . $enquiryDate . '</td>
                            </tr>
                        </table>';


        $html .= '<table style="table-layout: fixed; width: 100%; border-collapse: collapse; text-align:center;">                                                            
                    <tr style="text-align:center; font-weight:bold; background-color:#d9d9d9;">
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;">S. No.</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Cat. No.</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Product</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Pack Size</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Qty.</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Rate</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Value</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">GST</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">Total Price (Inc. Vat)</td>
                    </tr>';
        foreach ($pageProducts as $p) {
            $html .= '
                    <tr>
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;">' . $p['serial'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $p['catNo'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;background-color:#ffff00;font-weight:800;">' . $p['name'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;background-color:#92d050;font-weight:800;">' . $p['packSize'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;background-color:#c5d9f1;font-weight:800;">' . $p['qtyReq'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;color:#ff0000;font-weight:800;">' . $p['prodRate'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $p['prodValue'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $p['gstVal'] . '</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $p['totalPrice'] . '</td>
                    </tr>';
            $totPrc += floatval($p['totalPrice'] ?? 0.00);
            $totGst += floatval($p['gstVal'] ?? 0.00);
            $totQty += floatval($p['qtyReq'] ?? 0.00);
        }
        $totalPrice = floatval($totPrc);
        $roundedTotal = round($totalPrice);   // PHP automatically .50 and above = up
        $roundDiff = $roundedTotal - $totalPrice;
        $sign = ($roundDiff >= 0) ? '+' : '-';
        $roundDiffAbs = number_format(abs($roundDiff), 2, '.', '');
        $roundOffValue = $sign . $roundDiffAbs;

        $totPrcFinal = number_format($roundedTotal, 2, '.', '');
        $html .= '<tr>
                    <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;">&nbsp; </td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                </tr>';

        $html .= '                
                <tr>
                    <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px; font-weight:800;">FREIGHT</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $freightAmountDisp . '</td>
                </tr>
                <tr>
                    <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px; font-weight:800;">FREIGHT TAX (' . $freightPercent . '%)</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $freightPercentAmanoutDisp . '</td>
                </tr>
                <tr>
                    <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;font-weight:800;">ROUND OFF</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . $roundOffValue . '</td>
                </tr>
                <tr style="font-weight:800;">
                    <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td  colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">TOTAL</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . indianCommaFormat($totQty) . '</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . indianCommaFormat($totGst) . '</td>
                    <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;background-color:#ff0000;color:#ffffff;">' . indianCommaFormat($totPrcFinal) . '</td>
                </tr>                                                            
                <tr style="font-weight:800; text-align:left;">
                    <td colspan="2" style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> Amount in Rupees:</td>
                    <td colspan="7" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . convertNumberToWords($totPrcFinal) . '</td>                                                                
                </tr>
                <tr style="font-weight:800;">
                    <td colspan="6" style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;text-align:left;"> TERMS : E.&.O.E. </td>
                    <td colspan="3" rowspan="4" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;font-family: "Poppins", sans-serif;font-size: 11px;font-style: italic;">Auto-Generated Proforma,
                        <br>
                        <img src="' . asset('assets/img/logo3.jpeg') . '" alt="Biogenix Logo" style="height: 50px;">
                        <br>
                        Signature not required.
                    </td>
                </tr>';
        foreach ($bottomLines as $bIndex => $bText) {
            $html .= '<tr style="font-size:13px;">
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;">' . ($bIndex + 1) . '</td>
                        <td colspan="5" style="text-align:left; border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">' . htmlspecialchars($bText ?? '') . '</td>
                    </tr>';
        }
        $html .= '</table>';
        // if ($pageIndex === array_key_last($chunks)) {
        //     if (!empty($extraNote)) {
        //         $html .= '<div style="margin-top:18px; font-size:14px;">
        //                     <div style="margin-bottom:10px; font-weight:700 !important;">' . $extraNote . '</div>                            
        //                 </div>';
        //     }
        //     $html .= '<div style="margin-top:18px; font-size:14px;">
        //                 <div style="margin-bottom:10px;">Yours Sincerely,</div>
        //                 <img src="' . asset('assets/img/stamp_logo.jpeg') . '" style="height:80px;" />
        //                 <div style="margin-top:12px;">Biogenix Inc Pvt Ltd.</div>
        //             </div>';
        // }
        $html .= '<div style="margin-top:10px; color:#ff0000; line-height:18px;">
                            <h6 style="color:#ff0000;font-weight: 900;">Bank Details:</h6>
                            <ol type="1" style="font-size:medium;font-weight: 900;">
                                <li>Bank of Baroda Lucknow, Account No: 00500500000114, IFSC Code: BARB0HAZARA.</li>
                            </ol>
                        </div>
                    </div>
                </div>';
    }
    $html .= '</div>
                        </div>
                    </div>
                </div>
            </div>   
            <div class="col-xl-2 col-md-4 col-12 invoice-actions">
                <div class="card">
                    <div class="card-body">
                        <button class="btn btn-label-secondary d-grid w-100 mb-2 pdfPurchaseOrderRawDownloadBtn" data-id ="' . base64_encrypt($proInvId) . '">Download </button>
                    </div>
                </div>
            </div>             
        </div>';

    return $html;
}


/* Helper function */
function getEventCalendar($type)
{
    switch ($type) {
        case 1:
            return 'birthday';
        case 2:
            return 'work_anniversary';
        case 3:
            return 'marriage';
        default:
            return 'other';
    }
}

function createNotification($conn, array $data)
{
    /*
    Required keys in $data:
    module
    title
    message
    notification_type
    severity
    created_by

    Optional keys:
    ref_table
    ref_id
    is_broadcast (0/1)
    user_ids   => array of user IDs
    role_ids   => array of role IDs
    */

    $module = $data['module'];
    $ref_table = $data['ref_table'] ?? null;
    $ref_id = $data['ref_id'] ?? null;
    $title = $data['title'];
    $message = $data['message'];
    $notification_type = $data['notification_type'];
    $severity = $data['severity'];
    $is_broadcast = $data['is_broadcast'] ?? 0;
    $created_by = $data['created_by'];
    $createdAt = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("INSERT INTO notifications
        (module, ref_table, ref_id, title, message, notification_type, severity, is_broadcast, created_by, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");

    $stmt->bind_param(
        "ssissiiii",
        $module,
        $ref_table,
        $ref_id,
        $title,
        $message,
        $notification_type,
        $severity,
        $is_broadcast,
        $created_by
    );

    if (!$stmt->execute()) {
        return false;
    }

    $notificationId = $stmt->insert_id;
    $stmt->close();
    if (!empty($data['user_ids']) && is_array($data['user_ids'])) {
        $stmt = $conn->prepare(" INSERT IGNORE INTO notification_recipients
            (notification_id, user_id, is_read)
            VALUES (?, ?, 0)
        ");

        foreach ($data['user_ids'] as $userId) {
            $stmt->bind_param("ii", $notificationId, $userId);
            $stmt->execute();
        }
        $stmt->close();
    }

    /* 3️⃣ Assign to roles (if any) */
    if (!empty($data['role_ids']) && is_array($data['role_ids'])) {
        $stmt = $conn->prepare("INSERT IGNORE INTO notification_roles
            (notification_id, role_id)
            VALUES (?, ?)
        ");

        foreach ($data['role_ids'] as $roleId) {
            $stmt->bind_param("ii", $notificationId, $roleId);
            $stmt->execute();
        }
        $stmt->close();
    }

    return $notificationId;
}

function cronCalendarReminders(mysqli $conn): int
{
    $lockResult = $conn->query("SELECT GET_LOCK('erp_calendar_reminders', 0) AS acquired");
    $lockRow = $lockResult ? $lockResult->fetch_assoc() : null;
    if ((int) ($lockRow['acquired'] ?? 0) !== 1) {
        return 0;
    }

    try {
    $sql = "SELECT event.id, event.event_title, event.event_date_start,
            event.start_time, event.location, event.created_by
        FROM employee_events event
        WHERE event.is_reminder_enabled = 1
          AND event.status != 3
          AND event.deleted_at IS NULL
          AND (
              (event.show_year = 1 AND DATE_FORMAT(event.event_date_start, '%m-%d') = DATE_FORMAT(CURDATE(), '%m-%d'))
              OR (event.show_year != 1 AND DATE(event.event_date_start) = CURDATE())
          )
          AND (event.all_day = 1 OR event.start_time IS NULL OR event.start_time <= CURTIME())
          AND NOT EXISTS (
              SELECT 1 FROM notifications notification
              WHERE notification.module = 'CALENDAR_REMINDER'
                AND notification.ref_table = 'employee_events'
                AND notification.ref_id = event.id
                AND DATE(notification.created_at) = CURDATE()
          )
        ORDER BY event.start_time ASC, event.id ASC";
    $result = $conn->query($sql);
    if (!$result) {
        return 0;
    }

    $created = 0;
    while ($event = $result->fetch_assoc()) {
        $title = trim((string) ($event['event_title'] ?? '')) ?: 'Calendar reminder';
        $message = 'Reminder: ' . $title;
        if (!empty($event['start_time'])) {
            $message .= ' at ' . date('h:i A', strtotime((string) $event['start_time']));
        }
        if (!empty($event['location'])) {
            $message .= ' — ' . trim((string) $event['location']);
        }
        $creatorId = (int) ($event['created_by'] ?? 0);
        $notificationId = createNotification($conn, [
            'module' => 'CALENDAR_REMINDER',
            'ref_table' => 'employee_events',
            'ref_id' => (int) $event['id'],
            'title' => $title,
            'message' => $message,
            'notification_type' => 1,
            'severity' => 1,
            'created_by' => $creatorId,
            'user_ids' => $creatorId > 0 ? [$creatorId] : [],
        ]);
        if ($notificationId) {
            $created++;
        }
    }

    return $created;
    } finally {
        $conn->query("SELECT RELEASE_LOCK('erp_calendar_reminders')");
    }
}

function notificationRoleIdsForPermission(mysqli $conn, string $permissionSlug): array
{
    $roleIds = [];
    $stmt = $conn->prepare(
        'SELECT DISTINCT rp.role_id
         FROM role_permissions rp
         INNER JOIN permissions permission ON permission.id = rp.permission_id
         WHERE rp.status = 1 AND permission.slug = ?'
    );
    if (!$stmt) {
        return $roleIds;
    }
    $stmt->bind_param('s', $permissionSlug);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $roleIds[] = (int) $row['role_id'];
    }
    $stmt->close();
    return $roleIds;
}

function cronFinanceDueDateReminders(mysqli $conn): int
{
    $roleIds = notificationRoleIdsForPermission($conn, 'finance_trade_payables_view');
    if (!$roleIds) {
        return 0;
    }
    $sql = "SELECT id, counterparty_name, document_number, reference_number, due_date
            FROM finance_documents
            WHERE deleted_at IS NULL
              AND document_type = 'VENDOR_BILL'
              AND status IN ('PENDING', 'OPEN', 'PART_PAID')
              AND due_date IS NOT NULL
              AND DATE(due_date) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
              AND NOT EXISTS (
                  SELECT 1 FROM notifications n
                  WHERE n.module = 'FINANCE_DUE_DATE'
                    AND n.ref_table = 'finance_documents'
                    AND n.ref_id = finance_documents.id
                    AND DATE(n.created_at) = CURDATE()
              )
            ORDER BY due_date ASC, id ASC";
    $result = $conn->query($sql);
    if (!$result) {
        return 0;
    }
    $created = 0;
    while ($row = $result->fetch_assoc()) {
        $days = (int) floor((strtotime((string) $row['due_date']) - strtotime(date('Y-m-d'))) / 86400);
        $dueText = $days <= 0 ? 'is due today' : ('is due in ' . $days . ' day' . ($days === 1 ? '' : 's'));
        if (createNotification($conn, [
            'module' => 'FINANCE_DUE_DATE',
            'ref_table' => 'finance_documents',
            'ref_id' => (int) $row['id'],
            'title' => 'Vendor bill due date approaching',
            'message' => trim((string) ($row['counterparty_name'] ?? 'Vendor bill')) . ' ' . $dueText . ' (' . date('d M Y', strtotime((string) $row['due_date'])) . ').',
            'notification_type' => 1,
            'severity' => $days <= 0 ? 3 : 2,
            'created_by' => 1,
            'role_ids' => $roleIds,
        ])) {
            $created++;
        }
    }
    return $created;
}

function cronTenderDueDateReminders(mysqli $conn): int
{
    $roleIds = notificationRoleIdsForPermission($conn, 'tenders_view');
    if (!$roleIds) {
        $roleIds = notificationRoleIdsForPermission($conn, 'tenders_menu_list');
    }
    if (!$roleIds) {
        return 0;
    }
        $sql = "SELECT t.id, t.tender_no, t.submission_last_date, ti.name AS institution_name
                        FROM tenders t
                        LEFT JOIN tender_institutions ti ON ti.id = t.authority_name_id
                        WHERE t.status != 3
                            AND t.submission_last_date IS NOT NULL
                            AND DATE(t.submission_last_date) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
              AND NOT EXISTS (
                  SELECT 1 FROM notifications n
                  WHERE n.module = 'TENDER_DUE_DATE'
                    AND n.ref_table = 'tenders'
                                        AND n.ref_id = t.id
                    AND DATE(n.created_at) = CURDATE()
              )
                        ORDER BY t.submission_last_date ASC, t.id ASC";
    $result = $conn->query($sql);
    if (!$result) {
        return 0;
    }
    $created = 0;
    while ($row = $result->fetch_assoc()) {
        $days = (int) floor((strtotime((string) $row['submission_last_date']) - strtotime(date('Y-m-d'))) / 86400);
        $dueText = $days <= 0 ? 'is due today' : ('is due in ' . $days . ' day' . ($days === 1 ? '' : 's'));
        if (createNotification($conn, [
            'module' => 'TENDER_DUE_DATE',
            'ref_table' => 'tenders',
            'ref_id' => (int) $row['id'],
            'title' => 'Tender submission date approaching',
            'message' => trim((string) ($row['tender_no'] ?? 'Tender')) . ' for ' . trim((string) ($row['institution_name'] ?? 'the institution')) . ' ' . $dueText . ' (' . date('d M Y', strtotime((string) $row['submission_last_date'])) . ').',
            'notification_type' => 1,
            'severity' => $days <= 0 ? 3 : 2,
            'created_by' => 1,
            'role_ids' => $roleIds,
        ])) {
            $created++;
        }
    }
    return $created;
}


function cronProductReorder($conn)
{
    /*
      Logic:
      - Read each product's unreserved stock balance directly
      - If stock == 0 → Stock Finished (type 2)
      - If stock <= reorder_level → Stock Low (type 1)
    */

    $sql = "SELECT 
                p.id AS product_id,
                p.product_name,
                p.reorder_level,
                COALESCE(ls.unreserved_qty, 0) AS total_stock
            FROM products p
            LEFT JOIN live_stock ls 
                ON ls.product_id = p.id
                AND ls.status = 1
                AND ls.deleted_at IS NULL
            WHERE p.status = 1 
                AND p.is_notification = 1
                AND p.deleted_at IS NULL
              AND COALESCE(ls.unreserved_qty, 0) <= p.reorder_level";

    $result = $conn->query($sql);
    if (!$result || $result->num_rows === 0) {
        return;
    }

    while ($row = $result->fetch_assoc()) {
        if ($row['total_stock'] <= 0) {
            $notificationType = 2; // Stock Finished
            $severity = 3;         // Critical
            $title = Constant::NOTIFIACTION_TYPE[2]['label'];
            $message = sprintf(
                '%s stock finished. Available: %.3f',
                $row['product_name'],
                $row['total_stock']
            );
        } else {
            $notificationType = 1; // Stock Low
            $severity = 2;         // Warning
            $title = Constant::NOTIFIACTION_TYPE[1]['label'];
            $message = sprintf(
                '%s stock below reorder level. Available: %.3f | Reorder Level: %d',
                $row['product_name'],
                $row['total_stock'],
                intval($row['reorder_level'])
            );
        }


        createNotification($conn, [
            'module' => 1,
            'ref_table' => 'products',
            'ref_id' => $row['product_id'],
            'title' => $title,
            'message' => $message,
            'notification_type' => $notificationType,
            'severity' => $severity,
            'created_by' => 1,
            'role_ids' => [1, 3, 11, 12] // Store / Admin
        ]);
    }
}


function tenderTimelineMeta($action)
{
    switch ($action) {
        case 'CREATED':
            return ['icon' => 'ti ti-file-plus', 'color' => 'primary'];
        case 'STATUS_CHANGED':
            return ['icon' => 'ti ti-arrows-exchange', 'color' => 'info'];
        case 'PAYMENT_UPDATED':
            return ['icon' => 'ti ti-edit-circle', 'color' => 'info'];
        case 'PAYMENT_ADDED':
            return ['icon' => 'ti ti-cash', 'color' => 'warning'];
        case 'EMD_PAID':
            return ['icon' => 'ti ti-currency-rupee', 'color' => 'warning'];
        case 'FEE_PAID':
            return ['icon' => 'ti ti-receipt-2', 'color' => 'success'];
        case 'EMD_ADDED':
            return ['icon' => 'ti ti-cash', 'color' => 'info'];
        case 'FEE_ADDED':
            return ['icon' => 'ti ti-cash', 'color' => 'info'];
        case 'EMD_UPDATED':
            return ['icon' => 'ti ti-edit', 'color' => 'primary'];
        case 'FEE_UPDATED':
            return ['icon' => 'ti ti-edit', 'color' => 'primary'];
        case 'PBG_ADDED':
            return ['icon' => 'ti ti-shield', 'color' => 'info'];
        case 'PBG_PAID':
            return ['icon' => 'ti ti-shield-check', 'color' => 'success'];
        case 'PBG_UPDATED':
            return ['icon' => 'ti ti-edit', 'color' => 'primary'];
        case 'PBG_REFUNDED':
            return ['icon' => 'ti ti-cash-off', 'color' => 'warning'];
        case 'REJECTED':
            return ['icon' => 'ti ti-circle-x', 'color' => 'danger'];
        case 'AOC':
            return ['icon' => 'ti ti-award-filled', 'color' => 'success'];
        case 'TECHNICAL_OPENING':
            return ['icon' => 'ti ti-settings', 'color' => 'primary'];
        case 'FINANCIAL_OPENING':
            return ['icon' => 'ti ti-coin-rupee', 'color' => 'info'];
        case 'TECHNICAL_EVALUATED':
            return ['icon' => 'ti ti-checklist', 'color' => 'secondary'];
        case 'FINANCIAL_EVALUATED':
            return ['icon' => 'ti ti-chart-bar', 'color' => 'muted'];
        case 'TECHNICAL_QUALIFIED':
            return ['icon' => 'ti ti-circle-check', 'color' => 'success'];
        case 'TECHNICAL_DISQUALIFIED':
            return ['icon' => 'ti ti-circle-x', 'color' => 'danger'];
        case 'ITEM_DELETED':
            return ['icon' => 'ti ti-trash', 'color' => 'danger'];
        case 'AOC_CONTRACT_CREATED':
            return ['icon' => 'ti ti-shield-check', 'color' => 'success'];
        case 'FINANCIAL_QUALIFIED':
            return ['icon' => 'ti ti-rosette', 'color' => 'success'];
        case 'FINANCIAL_DISQUALIFIED':
            return ['icon' => 'ti ti-x', 'color' => 'danger'];
        case 'PAYMENT_UPDATED_1':
            return ['icon' => 'ti ti-refresh', 'color' => 'info'];
        case 'FEE_PAID_1':
            return ['icon' => 'ti ti-receipt', 'color' => 'success'];
        case 'REJECTED_1':
            return ['icon' => 'ti ti-x', 'color' => 'danger'];
        case 'AOC_1':
            return ['icon' => 'ti ti-award', 'color' => 'success'];
        default:
            return ['icon' => 'ti ti-info-circle', 'color' => 'secondary'];
    }
}



function addTenderHistoryRecordFunction($conn, array $data)
{
    if (empty($data['tender_id']) || empty($data['action_type'])) {
        return false;
    }

    $stmt = $conn->prepare("INSERT INTO tender_history
        (tender_id, action_type, old_value, new_value, description, performed_by, performed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        return false;
    }

    $tenderId = (int) $data['tender_id'];
    $actionType = (string) $data['action_type'];
    $oldValue = $data['old_value'] ?? null;
    $newValue = $data['new_value'] ?? null;
    $description = $data['description'] ?? null;
    $performedBy = $data['performed_by'] ?? ($_SESSION['user_id'] ?? null);
    $performedAt = $data['performed_at'] ?? date('Y-m-d H:i:s');

    $stmt->bind_param(
        "issssis",
        $tenderId,
        $actionType,
        $oldValue,
        $newValue,
        $description,
        $performedBy,
        $performedAt
    );

    $result = $stmt->execute();
    $stmt->close();

    return $result;
}


function insertRecordIntoTable($conn, $table, $data)
{
    if (empty($data) || !is_array($data)) {
        return false;
    }

    $columns = array_keys($data);
    $columnSql = '`' . implode('`,`', $columns) . '`';
    $placeholders = implode(',', array_fill(0, count($columns), '?'));

    $sql = "INSERT INTO `$table` ($columnSql) VALUES ($placeholders)";
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return mysqli_error($conn);
    }

    $types = '';
    $values = [];

    foreach ($data as $value) {
        if (is_null($value)) {
            $types .= 's';
            $values[] = null;
        } elseif (is_array($value)) {
            $types .= 's';
            $values[] = json_encode($value, JSON_UNESCAPED_UNICODE);
        } elseif (is_int($value)) {
            $types .= 'i';
            $values[] = $value;
        } elseif (is_float($value)) {
            $types .= 'd';
            $values[] = $value;
        } else {
            $types .= 's';
            $values[] = $value;
        }
    }
    mysqli_stmt_bind_param($stmt, $types, ...$values);

    if (mysqli_stmt_execute($stmt)) {
        return mysqli_insert_id($conn);
    } else {
        return mysqli_stmt_error($stmt);
    }
}


// $data = [
//     'outward_type' => 2,
//     'client_name' => 'ABC Pharma',
//     'client_receiver_type_details' => [
//         'name' => 'Store Manager',
//         'mobile' => '9999999999',
//         'email' => 'store@abc.com'
//     ],
//     'type_of_dispatch_details' => [
//         'vehicle_no' => 'RJ14AB1234',
//         'driver' => 'Ramesh'
//     ],
//     'created_by' => 5
// ];

// $lastId = insertRecordIntoTable($conn, 'stock_outward', $data);


function updateRecordIntoTable($conn, $table, $data, $where)
{
    if (empty($data) || empty($where)) {
        return false;
    }

    $setSql = [];
    $whereSql = [];
    $types = '';
    $values = [];

    /* ---------- SET PART ---------- */
    foreach ($data as $column => $value) {
        $setSql[] = "`$column` = ?";
        $types .= is_int($value) ? 'i' : (is_float($value) ? 'd' : 's');
        $values[] = $value;
    }

    /* ---------- WHERE PART ---------- */
    foreach ($where as $column => $value) {

        if ($value === null) {
            // IMPORTANT FIX
            $whereSql[] = "`$column` IS NULL";
        } else {
            $whereSql[] = "`$column` = ?";
            $types .= is_int($value) ? 'i' : 's';
            $values[] = $value;
        }
    }

    $sql = "UPDATE `$table`
            SET " . implode(', ', $setSql) . "
            WHERE " . implode(' AND ', $whereSql);

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return mysqli_error($conn);
    }

    mysqli_stmt_bind_param($stmt, $types, ...$values);

    if (!mysqli_stmt_execute($stmt)) {
        return mysqli_stmt_error($stmt);
    }

    return mysqli_stmt_affected_rows($stmt);
}


// Example: Vendor Soft Delete
// updateRecordIntoTable(
//     $conn,
//     'tender_vendors',
//     [
//         'deleted_at' => date('Y-m-d H:i:s'),
//         'deleted_by' => $_SESSION['user_id'],
//         'status'     => 0
//     ],
//     [
//         'id' => $vendor_id
//     ]
// );


// Normal Update Example
// updateRecordIntoTable(
//     $conn,
//     'tender_vendors',
//     [
//         'vendor_name' => $vendor_name,
//         'mobile'      => $mobile,
//         'updated_at'  => date('Y-m-d H:i:s'),
//         'updated_by'  => $_SESSION['user_id']
//     ],
//     [
//         'id' => $vendor_id,
//         'deleted_at' => null
//     ]
// );

function productionTimelineMeta(int $actionType): array
{
    switch ($actionType) {
        case 1:
            return ['icon' => 'ti ti-file-plus', 'color' => 'primary'];
        case 2:
            return ['icon' => 'ti ti-package', 'color' => 'warning'];
        case 3:
            return ['icon' => 'ti ti-circle-check', 'color' => 'primary'];
        case 4:
            return ['icon' => 'ti ti-truck-loading', 'color' => 'info'];
        case 5:
            return ['icon' => 'ti ti-player-play', 'color' => 'primary'];
        case 6:
            return ['icon' => 'ti ti-player-pause', 'color' => 'danger'];
        case 7:
            return ['icon' => 'ti ti-refresh', 'color' => 'info'];
        case 8:
            return ['icon' => 'ti ti-checks', 'color' => 'success'];
        case 9:
            return ['icon' => 'ti ti-transfer', 'color' => 'success'];
        case 10:
            return ['icon' => 'ti ti-lock', 'color' => 'dark'];
        case 11:
            return ['icon' => 'ti ti-circle-x', 'color' => 'danger'];
        default:
            return ['icon' => 'ti ti-info-circle', 'color' => 'secondary'];
    }
}

function productionStatusMeta(int $status): array
{
    switch ($status) {
        case 0:
            return ['icon' => 'ti ti-clock', 'color' => 'secondary'];
        case 1:
            return ['icon' => 'ti ti-package', 'color' => 'warning'];
        case 2:
            return ['icon' => 'ti ti-truck', 'color' => 'primary'];
        case 4:
            return ['icon' => 'ti ti-player-play', 'color' => 'info'];
        case 5:
            return ['icon' => 'ti ti-player-pause', 'color' => 'danger'];
        case 6:
            return ['icon' => 'ti ti-refresh', 'color' => 'primary'];
        case 7:
            return ['icon' => 'ti ti-check', 'color' => 'success'];
        case 8:
            return ['icon' => 'ti ti-transfer', 'color' => 'success'];
        case 9:
            return ['icon' => 'ti ti-lock', 'color' => 'dark'];
        case 10:
            return ['icon' => 'ti ti-circle-x', 'color' => 'danger'];
        default:
            return ['icon' => 'ti ti-info-circle', 'color' => 'secondary'];
    }
}



function insertProductionHistory($conn, array $data)
{
    $sql = "INSERT INTO `production_history` SET
        `production_id`   = ?,
        `action_type`     = ?,
        `related_table`   = ?,
        `related_record_id` = ?,
        `old_flow_status` = ?,
        `new_flow_status` = ?,
        `update_type`     = ?,
        `stop_reason`     = ?,
        `changed_fields`  = ?,
        `remarks`         = ?,
        `action_by`       = ?,
        `action_at`       = ?,
        `created_by`      = ?
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }
    $production_id = $data['production_id'] ?? null;
    $action_type = $data['action_type'] ?? null;
    $related_table = $data['related_table'] ?? null;
    $related_record_id = $data['related_record_id'] ?? null;
    $old_flow_status = $data['old_flow_status'] ?? null;
    $new_flow_status = $data['new_flow_status'] ?? null;
    $update_type = $data['update_type'] ?? null;
    $stop_reason = $data['stop_reason'] ?? null;
    $remarks = $data['remarks'] ?? null;
    $action_by = $data['action_by'] ?? null;
    $action_at = $data['action_at'] ?? null;
    $created_by = $data['created_by'] ?? null;

    $changedFields = null;
    if (!empty($data['changed_fields'])) {
        $changedFields = is_array($data['changed_fields'])
            ? json_encode($data['changed_fields'], JSON_UNESCAPED_UNICODE)
            : $data['changed_fields'];
    }

    $stmt->bind_param(
        "iisiiiisssisi",
        $production_id,
        $action_type,
        $related_table,
        $related_record_id,
        $old_flow_status,
        $new_flow_status,
        $update_type,
        $stop_reason,
        $changedFields,
        $remarks,
        $action_by,
        $action_at,
        $created_by
    );

    if (!$stmt->execute()) {
        return false;
    }

    return $stmt->insert_id;
}

// insertProductionHistory($conn, [
//     'production_id' => $productionId,
//     'action_type'   => PRODUCTION_ACTION_UPDATE_BLOCKED,
//     'remarks'       => 'Major update blocked after production started',
//     'action_by'     => $userId
// ]);

function getProductionTimeline($conn, int $productionId): array
{
    $sql = "SELECT 
            ph.id,
            ph.action_type,
            ph.old_flow_status,
            ph.new_flow_status,
            ph.update_type,
            ph.stop_reason,
            ph.remarks,
            ph.action_at,
            u.name AS action_by_name
        FROM production_history ph
        LEFT JOIN users u ON u.id = ph.action_by
        WHERE ph.production_id = ?
          AND ph.deleted_at IS NULL
        ORDER BY ph.action_at ASC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productionId);
    $stmt->execute();
    $res = $stmt->get_result();

    $timeline = [];

    while ($row = $res->fetch_assoc()) {

        $meta = productionTimelineMeta((int) $row['action_type']);

        $timeline[] = [
            'id' => $row['id'],
            'icon' => $meta['icon'],
            'color' => $meta['color'],
            'title' => Constant::PRODUCTION['PRODUCTION_ACTION_TYPE'][$row['action_type']] ?? 'Updated',
            'remarks' => $row['remarks'],
            'action_by' => $row['action_by_name'] ?? 'System',
            'action_at' => date('d M Y, h:i A', strtotime($row['action_at'])),
        ];
    }

    return $timeline;
}

function getDashboardProductionTimeline($conn, array $options = []): array
{
    // ---- Defaults ----
    $productionIds = $options['production_ids'] ?? []; // [1,2,3] OR [5]
    $days = $options['days'] ?? null;          // last N days
    $startDate = $options['start_date'] ?? null;    // Y-m-d
    $endDate = $options['end_date'] ?? null;      // Y-m-d
    $orderBy = strtoupper($options['order'] ?? 'ASC'); // ASC | DESC

    // Safety
    if (!in_array($orderBy, ['ASC', 'DESC'])) {
        $orderBy = 'ASC';
    }

    $where = [];
    $params = [];
    $types = '';

    $where[] = "ph.deleted_at IS NULL";

    // ---- Filter : Production IDs ----
    if (!empty($productionIds)) {
        $placeholders = implode(',', array_fill(0, count($productionIds), '?'));
        $where[] = "ph.production_id IN ($placeholders)";
        $types .= str_repeat('i', count($productionIds));
        $params = array_merge($params, $productionIds);
    }

    // ---- Filter : Date Range ----
    if (!empty($startDate) && !empty($endDate)) {
        $where[] = "DATE(ph.action_at) BETWEEN ? AND ?";
        $types .= 'ss';
        $params[] = $startDate;
        $params[] = $endDate;
    }
    // ---- Filter : Days (ONLY if date range not provided) ----
    if (!empty($days) && empty($startDate) && empty($endDate)) {
        $where[] = "ph.action_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)";
        $types .= 'i';
        $params[] = $days;
    }


    $whereSql = implode(' AND ', $where);

    $sql = "SELECT 
            ph.production_id,
            ph.action_type,
            ph.remarks,
            ph.action_at,
            u.name AS user_name,
            pp.name AS prod_plan_title
        FROM production_history ph
        JOIN production_plans pp ON pp.id = ph.production_id
        LEFT JOIN users u ON u.id = ph.action_by
        WHERE $whereSql
        ORDER BY ph.production_id, ph.action_at $orderBy";

    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $res = $stmt->get_result();

    $data = [];

    while ($r = $res->fetch_assoc()) {

        $pid = $r['production_id'];
        $ptitle = $r['prod_plan_title'];

        if (!isset($data[$pid])) {
            $data[$pid] = [
                'production_id' => $pid,
                'production_plan_title' => $ptitle,
                'steps' => []
            ];
        }

        $meta = productionTimelineMeta($r['action_type']);
        $data[$pid]['steps'][] = [
            'action' => Constant::PRODUCTION['PRODUCTION_ACTION_TYPE'][$r['action_type']] ?? 'Updated',
            'icon' => $meta['icon'],
            'color' => $meta['color'],
            'remarks' => $r['remarks'] ?? null,
            'user' => $r['user_name'] ?? 'System',
            'time' => date('d M Y, h:i A', strtotime($r['action_at']))
        ];
    }

    return array_values($data);
}

function checkBomStockAvailability($conn, int $bomId, float $batchSize): array
{
    $result = [
        'status' => 'ok',
        'hasShortage' => false,
        'items' => []
    ];

    $stmt = $conn->prepare("SELECT id FROM bom_master
        WHERE id = ? AND status = 1 AND bom_status = 'APPROVED' AND deleted_at IS NULL
    ");
    $stmt->bind_param('i', $bomId);
    $stmt->execute();

    if (!$stmt->get_result()->fetch_assoc()) {
        return [
            'status' => 'error',
            'message' => 'BOM not found'
        ];
    }
    $stmt = $conn->prepare("SELECT bi.raw_product_id, bi.qty_per_unit, p.product_name, bi.qty_unit_id, bi.raw_product_category_id,
            su.short_name AS unit_name
        FROM bom_items bi
        JOIN products p ON p.id = bi.raw_product_id
        LEFT JOIN standard_units su ON su.id = bi.qty_unit_id
        WHERE bi.bom_id = ?
          AND bi.status = 1
          AND bi.deleted_at IS NULL
    ");
    $stmt->bind_param('i', $bomId);
    $stmt->execute();
    $items = $stmt->get_result();

    if ($items->num_rows === 0) {
        return [
            'status' => 'error',
            'message' => 'The selected BOM has no raw material components configured in BOM Master.',
            'hasShortage' => false,
            'is_incomplete' => true,
            'items' => []
        ];
    }

    $stockStmt = $conn->prepare("SELECT unreserved_qty
        FROM live_stock
        WHERE product_id = ?
          AND status = 1
          AND deleted_at IS NULL
        LIMIT 1");

    while ($row = $items->fetch_assoc()) {
        $bomQty = (float) $row['qty_per_unit'];
        $requiredInBomUnit = $bomQty * $batchSize;
        $requiredBase = $requiredInBomUnit;

        $stockStmt->bind_param('i', $row['raw_product_id']);
        $stockStmt->execute();
        $stock = $stockStmt->get_result()->fetch_assoc();

        $availableBase = (float) ($stock['unreserved_qty'] ?? 0);
        $availableInBomUnit = $availableBase;

        $isShort = ($availableBase + 0.00000001) < $requiredBase;

        if ($isShort) {
            $result['hasShortage'] = true;
            $result['status'] = 'error';
        }

        $result['items'][] = [
            'product_category_id' => (int) $row['raw_product_category_id'],
            'product_id' => (int) $row['raw_product_id'],
            'product_name' => (string) $row['product_name'],
            'bom_qty' => $bomQty,
            'qty_unit_id' => (int) $row['qty_unit_id'],
            'unit_name' => (string) ($row['unit_name'] ?? ''),
            'required' => $requiredInBomUnit,
            'available' => $availableInBomUnit,
            'short' => $isShort
        ];
    }
    $stockStmt->close();

    return $result;
}

/**
 * Resolve the active BOM for a finished product and return its quantities scaled
 * to the requested production batch. This is shared by Material Requisition and
 * direct Goods Issuance so both screens apply exactly the same calculation.
 */
function mvGetScaledBomForFinishedProduct(mysqli $conn, int $finishedProductId, float $batchSize): array
{
    if ($finishedProductId <= 0) {
        throw new RuntimeException('Select a finished product.');
    }
    if (!is_finite($batchSize) || $batchSize <= 0) {
        throw new RuntimeException('Batch size must be greater than zero.');
    }

    $bomStmt = $conn->prepare("SELECT bom.id, bom.finished_product_id, product.product_name,
            product.unit_id AS batch_size_unit
        FROM bom_master AS bom
        INNER JOIN products AS product ON product.id = bom.finished_product_id
        WHERE bom.finished_product_id = ?
          AND bom.status = 1 AND bom.bom_status = 'APPROVED' AND bom.deleted_at IS NULL
          AND product.status = 1 AND product.deleted_at IS NULL
        ORDER BY bom.id DESC LIMIT 1");
    if (!$bomStmt) {
        throw new RuntimeException('Unable to load the finished-product BOM.');
    }
    $bomStmt->bind_param('i', $finishedProductId);
    $bomStmt->execute();
    $bom = $bomStmt->get_result()->fetch_assoc();
    $bomStmt->close();
    if (!$bom) {
        $productName = 'the selected finished product';
        $productStmt = $conn->prepare("SELECT product_name FROM products WHERE id = ? LIMIT 1");
        if ($productStmt) {
            $productStmt->bind_param('i', $finishedProductId);
            $productStmt->execute();
            $productName = (string) ($productStmt->get_result()->fetch_assoc()['product_name'] ?? $productName);
            $productStmt->close();
        }
        throw new RuntimeException('No active BOM is configured for ' . $productName . '. Production cannot proceed until its BOM is completed.');
    }

    $itemStmt = $conn->prepare("SELECT item.raw_product_category_id AS product_category_id,
            item.raw_product_id AS product_id, product.product_name,
            item.qty_per_unit AS bom_qty, item.qty_unit_id,
            unit.fullname AS unit_name, unit.short_name AS unit_short_name
        FROM bom_items AS item
        INNER JOIN products AS product ON product.id = item.raw_product_id
        LEFT JOIN standard_units AS unit ON unit.id = item.qty_unit_id
        WHERE item.bom_id = ? AND item.status = 1 AND item.deleted_at IS NULL
          AND product.status = 1 AND product.deleted_at IS NULL
        ORDER BY item.id ASC");
    if (!$itemStmt) {
        throw new RuntimeException('Unable to load BOM material lines.');
    }
    $bomId = (int) $bom['id'];
    $itemStmt->bind_param('i', $bomId);
    $itemStmt->execute();
    $result = $itemStmt->get_result();
    $items = [];
    while ($item = $result->fetch_assoc()) {
        $required = (float) $item['bom_qty'] * $batchSize;
        $items[] = [
            'product_category_id' => (int) $item['product_category_id'],
            'product_id' => (int) $item['product_id'],
            'product_name' => (string) $item['product_name'],
            'bom_qty' => (float) $item['bom_qty'],
            'qty_unit_id' => (int) $item['qty_unit_id'],
            'unit_name' => (string) ($item['unit_short_name'] ?: $item['unit_name'] ?: ''),
            'required_qty' => $required,
            'issued_qty' => $required,
        ];
    }
    $itemStmt->close();
    if (!$items) {
        throw new RuntimeException('The active BOM for ' . $bom['product_name'] . ' has no material lines. Production cannot proceed.');
    }

    return [
        'bom_master_id' => $bomId,
        'finished_product_id' => (int) $bom['finished_product_id'],
        'finished_product_name' => (string) $bom['product_name'],
        'batch_size' => $batchSize,
        'batch_size_unit' => (int) $bom['batch_size_unit'],
        'items' => $items,
    ];
}

/**
 * Extracts a normalized base product name by stripping pack sizes, units, and trailing counts.
 * e.g. "ADA REAGENT, BIOGENIX 15 ML" -> "ADA REAGENT, BIOGENIX"
 *      "HIV 1/2 RAPID TEST KIT (25 Test)" -> "HIV 1/2 RAPID TEST KIT"
 */
function extractBaseProductName(string $name): string
{
    $clean = preg_replace('/\(\s*\d+(?:\.\d+)?\s*(?:test|tests|t|pcs|cards?|cassettes?|vials?|ml|l|ltr|reactions?|rxn)\s*\)/i', '', $name);
    $clean = preg_replace('/\b\d+\s*[xX*]\s*\d+(?:\.\d+)?\s*(?:ml|l|ltr|tests?|vials?)\b/i', '', $clean);
    $clean = preg_replace('/\b\d+(?:\.\d+)?\s*(?:ml|l|ltr|litre|litres|test|tests|t|pcs|cards?|cassettes?|vials?|rxn|reactions?|determinations?)\b/i', '', $clean);
    $clean = preg_replace('/\b(?:ltr|litre|litres)\b/i', '', $clean);
    $clean = trim(preg_replace('/[,\-\/\(\)]+$/', '', trim($clean)));
    $clean = trim(preg_replace('/^[,\-\/\(\)]+/', '', $clean));
    $clean = trim(preg_replace('/\s+/', ' ', $clean));
    return $clean;
}

/**
 * Finds reference BOMs (approved, active) for other packages of the same base product,
 * or fallback BOMs from the same category.
 */
function findReferenceBomsForProduct($conn, int $productId): array
{
    $stmt = $conn->prepare("
        SELECT p.product_name, p.category_id, pc.name AS category_name
        FROM products p
        LEFT JOIN product_categories pc ON pc.id = p.category_id
        WHERE p.id = ?
    ");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    $prod = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$prod) {
        return [];
    }

    $rawName = (string) ($prod['product_name'] ?? '');
    $baseName = extractBaseProductName($rawName);
    $categoryId = (int) ($prod['category_id'] ?? 0);
    $categoryName = (string) ($prod['category_name'] ?? '');

    $refs = [];
    $seenBomIds = [];

    // TIER 1: Similar Product Matches (Name keywords / base product match)
    if (strlen($baseName) >= 3) {
        $searchPattern = '%' . preg_replace('/[,\s\-]+/', '%', $baseName) . '%';
        $stmt = $conn->prepare("
            SELECT bm.id, bm.name, bm.category_id, bm.finished_product_id, bm.bom_type, bm.bom_status,
                   p.product_name, p.product_code, pc.name AS category_name,
                   '⭐ Recommended: Similar Formulations' AS group_label,
                   (SELECT COUNT(*) FROM bom_items WHERE bom_id = bm.id AND status != 3 AND deleted_at IS NULL) AS item_count
            FROM bom_master bm
            JOIN products p ON p.id = bm.finished_product_id
            LEFT JOIN product_categories pc ON pc.id = bm.category_id
            WHERE bm.status = 1 AND bm.bom_status = 'APPROVED' AND bm.deleted_at IS NULL
              AND bm.finished_product_id != ?
              AND (p.product_name LIKE ? OR bm.name LIKE ?)
            ORDER BY p.product_name ASC
        ");
        if ($stmt) {
            $stmt->bind_param('iss', $productId, $searchPattern, $searchPattern);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                $refs[] = $row;
                $seenBomIds[(int)$row['id']] = true;
            }
            $stmt->close();
        }
    }

    // TIER 2: Same Category Matches
    if ($categoryId > 0) {
        $tier2Label = '📂 Same Category: ' . ($categoryName ?: 'Current Category');
        $stmt = $conn->prepare("
            SELECT bm.id, bm.name, bm.category_id, bm.finished_product_id, bm.bom_type, bm.bom_status,
                   p.product_name, p.product_code, pc.name AS category_name,
                   ? AS group_label,
                   (SELECT COUNT(*) FROM bom_items WHERE bom_id = bm.id AND status != 3 AND deleted_at IS NULL) AS item_count
            FROM bom_master bm
            JOIN products p ON p.id = bm.finished_product_id
            LEFT JOIN product_categories pc ON pc.id = bm.category_id
            WHERE bm.status = 1 AND bm.bom_status = 'APPROVED' AND bm.deleted_at IS NULL
              AND bm.finished_product_id != ?
              AND bm.category_id = ?
            ORDER BY p.product_name ASC
        ");
        if ($stmt) {
            $stmt->bind_param('sii', $tier2Label, $productId, $categoryId);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                $bId = (int)$row['id'];
                if (!isset($seenBomIds[$bId])) {
                    $refs[] = $row;
                    $seenBomIds[$bId] = true;
                }
            }
            $stmt->close();
        }
    }

    // TIER 3: All Remaining Approved BOMs in the system
    $stmt = $conn->prepare("
        SELECT bm.id, bm.name, bm.category_id, bm.finished_product_id, bm.bom_type, bm.bom_status,
               p.product_name, p.product_code, pc.name AS category_name,
               CONCAT('📦 Other Categories: ', COALESCE(pc.name, 'General')) AS group_label,
               (SELECT COUNT(*) FROM bom_items WHERE bom_id = bm.id AND status != 3 AND deleted_at IS NULL) AS item_count
        FROM bom_master bm
        JOIN products p ON p.id = bm.finished_product_id
        LEFT JOIN product_categories pc ON pc.id = bm.category_id
        WHERE bm.status = 1 AND bm.bom_status = 'APPROVED' AND bm.deleted_at IS NULL
          AND bm.finished_product_id != ?
        ORDER BY pc.name ASC, p.product_name ASC
    ");
    if ($stmt) {
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $bId = (int)$row['id'];
            if (!isset($seenBomIds[$bId])) {
                $refs[] = $row;
                $seenBomIds[$bId] = true;
            }
        }
        $stmt->close();
    }

    return $refs;
}

/**
 * Finds all active COA templates, ranking and grouping them for the target material:
 * 1. ⭐ Recommended Templates: Direct product mapping, category match, or keyword/name similarity.
 * 2. 📋 All Available COA Templates: All other active templates in Company Setup.
 */
function findCoaTemplatesForMaterial($conn, int $productId = 0, int $categoryId = 0, string $productName = ''): array
{
    $targetName = trim($productName);
    if ($targetName === '' && $productId > 0) {
        $pStmt = $conn->prepare("SELECT product_name, category_id FROM products WHERE id = ?");
        if ($pStmt) {
            $pStmt->bind_param('i', $productId);
            $pStmt->execute();
            $pRow = $pStmt->get_result()->fetch_assoc();
            $pStmt->close();
            if ($pRow) {
                $targetName = (string) ($pRow['product_name'] ?? '');
                if ($categoryId <= 0) {
                    $categoryId = (int) ($pRow['category_id'] ?? 0);
                }
            }
        }
    }

    $baseName = $targetName !== '' ? extractBaseProductName($targetName) : '';

    // Fetch all active COA templates
    $sql = "
        SELECT ct.id, ct.name, ct.description, ct.prod_categ_id, ct.product_id,
               pc.name AS category_name, p.product_name AS mapped_product_name,
               (SELECT COUNT(*) FROM coa_templates_items WHERE coa_template_id = ct.id AND status = 1 AND deleted_at IS NULL) AS item_count
        FROM coa_templates ct
        LEFT JOIN product_categories pc ON pc.id = ct.prod_categ_id
        LEFT JOIN products p ON p.id = ct.product_id
        WHERE ct.status = 1 AND ct.deleted_at IS NULL
        ORDER BY ct.name ASC
    ";
    $result = $conn->query($sql);
    if (!$result) {
        return [];
    }

    $recommended = [];
    $others = [];

    while ($row = $result->fetch_assoc()) {
        $tId = (int) $row['id'];
        $tName = (string) ($row['name'] ?? '');
        $tProdId = (int) ($row['product_id'] ?? 0);
        $tCatId = (int) ($row['prod_categ_id'] ?? 0);
        $tMappedProdName = (string) ($row['mapped_product_name'] ?? '');
        $tDesc = (string) ($row['description'] ?? '');
        $targetWords = preg_split('/[\s,\-\(\)\/\.\+]+/', strtolower($baseName ?: $targetName), -1, PREG_SPLIT_NO_EMPTY);
        $tokenMatch = false;
        if (is_array($targetWords)) {
            foreach ($targetWords as $w) {
                if (strlen($w) >= 3 && (stripos($tName, $w) !== false || ($tMappedProdName !== '' && stripos($tMappedProdName, $w) !== false))) {
                    $tokenMatch = true;
                    break;
                }
            }
        }

        $isMatch = false;
        $matchReason = '';

        // Check exact product match
        if ($productId > 0 && $tProdId > 0 && $tProdId === $productId) {
            $isMatch = true;
            $matchReason = 'Direct Product Match';
        } elseif ($targetName !== '' && (
            strcasecmp($tName, $targetName) === 0 ||
            strcasecmp($tMappedProdName, $targetName) === 0
        )) {
            $isMatch = true;
            $matchReason = 'Exact Name Match';
        } elseif ($baseName !== '' && strlen($baseName) >= 3 && (
            stripos($tName, $baseName) !== false ||
            stripos($targetName, extractBaseProductName($tName)) !== false ||
            ($tMappedProdName !== '' && stripos($tMappedProdName, $baseName) !== false)
        )) {
            $isMatch = true;
            $matchReason = 'Similar Name Match';
        } elseif ($tokenMatch) {
            $isMatch = true;
            $matchReason = 'Keyword Match';
        } elseif ($categoryId > 0 && $tCatId > 0 && $tCatId === $categoryId) {
            $isMatch = true;
            $matchReason = 'Category Match';
        }

        $templateItem = [
            'id' => $tId,
            'name' => $tName,
            'description' => $tDesc,
            'prod_categ_id' => $tCatId,
            'product_id' => $tProdId,
            'category_name' => (string) ($row['category_name'] ?? ''),
            'mapped_product_name' => $tMappedProdName,
            'item_count' => (int) ($row['item_count'] ?? 0),
            'is_recommended' => $isMatch,
            'match_reason' => $matchReason
        ];

        if ($isMatch) {
            $templateItem['group_label'] = '⭐ Recommended Templates';
            $recommended[] = $templateItem;
        } else {
            $templateItem['group_label'] = '📋 All Available COA Templates';
            $others[] = $templateItem;
        }
    }

    return array_merge($recommended, $others);
}

/**
 * Logs an action in bom_approval_history for audit trail.
 */
function logBomApprovalHistory($conn, int $bomId, string $action, ?string $fromStatus, string $toStatus, ?string $comments, int $userId): bool
{
    $stmt = $conn->prepare("
        INSERT INTO bom_approval_history
        (`bom_master_id`, `action`, `from_status`, `to_status`, `comments`, `performed_by`, `performed_at`)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('issssi', $bomId, $action, $fromStatus, $toStatus, $comments, $userId);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}


function checkLiveStockAvailability($conn, int $productId, float $requiredQtyInBase, int $productCategoryId = 0): array
{
    // Product is the stock identity. Keep the category argument for existing
    // callers, but do not exclude valid legacy/imported lots whose category is
    // empty or historical.
    $sql = "SELECT unreserved_qty AS total_available
            FROM live_stock
            WHERE product_id = ?
              AND status = 1
              AND deleted_at IS NULL
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);

    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $availableBaseQty = (float) ($row['total_available'] ?? 0);

    return [
        'available_qty_base' => $availableBaseQty,
        'required_qty_base' => $requiredQtyInBase,
        'is_available' => ($availableBaseQty >= $requiredQtyInBase)
    ];
}



function mvDbColumnExists(mysqli $conn, string $table, string $column): bool
{
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    $tableSafe = $conn->real_escape_string($table);
    $columnSafe = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM `{$tableSafe}` LIKE '{$columnSafe}'");
    $cache[$key] = ($result && $result->num_rows > 0);
    return $cache[$key];
}

function mvGetSessionUserName(mysqli $conn, int $userId): string
{
    $sessionName = trim((string) ($_SESSION['user_name'] ?? ''));
    if ($sessionName !== '') {
        return $sessionName;
    }
    if ($userId > 0) {
        $stmt = $conn->prepare("SELECT `name` FROM `users` WHERE `id` = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (trim((string) ($row['name'] ?? '')) !== '') {
                return trim((string) $row['name']);
            }
        }
    }
    return 'System';
}

function mvGetActiveCustomer(mysqli $conn, int $customerId): ?array
{
    if ($customerId <= 0) {
        return null;
    }
    $stmt = $conn->prepare("SELECT `id`, `name`, `company_name`, `email`, `phone`, `gstin`, `pan`,
            `state_province`, `state_code`, `contact_person`, `city`, `postal_code`, `detailed_address`,
            `payment_terms_status`, `payment_terms_text`, `credit_days`
        FROM `customers` WHERE `id` = ? AND `status` = 1 LIMIT 1");
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $customer;
}

function mvCustomerDisplayName(array $customer): string
{
    $company = trim((string) ($customer['company_name'] ?? ''));
    return $company !== '' ? $company : trim((string) ($customer['name'] ?? ''));
}

function mvCustomerAddress(array $customer): string
{
    return implode(', ', array_filter([
        trim((string) ($customer['detailed_address'] ?? '')),
        trim((string) ($customer['city'] ?? '')),
        trim((string) ($customer['state_province'] ?? '')),
        trim((string) ($customer['postal_code'] ?? '')),
    ], static fn(string $part): bool => $part !== ''));
}

function mvValidateCustomerForOrder(array $customer): array
{
    $missing = [];
    $checks = [
        'address' => mvCustomerAddress($customer),
        'GSTIN' => trim((string) ($customer['gstin'] ?? '')),
        'PAN' => trim((string) ($customer['pan'] ?? '')),
        'state' => trim((string) ($customer['state_province'] ?? '')),
        'state code' => trim((string) ($customer['state_code'] ?? '')),
        'contact person' => trim((string) ($customer['contact_person'] ?? '')),
        'contact number' => trim((string) ($customer['phone'] ?? '')),
        'email' => trim((string) ($customer['email'] ?? '')),
    ];
    foreach ($checks as $label => $value) {
        if ($value === '') {
            $missing[] = $label;
        }
    }
    $gstin = strtoupper(trim((string) ($customer['gstin'] ?? '')));
    if ($gstin !== '' && preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/', $gstin) !== 1) {
        $missing[] = 'valid GSTIN';
    }
    $pan = strtoupper(trim((string) ($customer['pan'] ?? '')));
    if ($pan !== '' && preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $pan) !== 1) {
        $missing[] = 'valid PAN';
    }
    $email = trim((string) ($customer['email'] ?? ''));
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $missing[] = 'valid email';
    }
    return $missing;
}

function mvResolveCustomerPaymentTerms(array $customer): array
{
    $status = (int) ($customer['payment_terms_status'] ?? 0);
    if (!isset(Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM'][$status])) {
        $status = (int) ($customer['credit_days'] ?? 0) > 0
            ? Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM_LABEL']['Credit_Order']
            : Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM_LABEL']['Payment_Pending'];
    }
    $details = trim((string) ($customer['payment_terms_text'] ?? ''));
    if ($details === '' && (int) ($customer['credit_days'] ?? 0) > 0) {
        $details = (int) $customer['credit_days'] . ' credit day(s)';
    }
    return ['status' => $status, 'details' => $details];
}

function mvAuditOrderChange(
    mysqli $conn,
    int $orderId,
    string $action,
    int $userId,
    ?int $orderItemId = null,
    ?string $fieldName = null,
    $oldValue = null,
    $newValue = null,
    ?string $reason = null
): void {
    if ($orderId <= 0 || !mvDbColumnExists($conn, 'order_management_audit', 'id')) {
        return;
    }
    $oldText = $oldValue === null ? null : (is_scalar($oldValue) ? (string) $oldValue : json_encode($oldValue));
    $newText = $newValue === null ? null : (is_scalar($newValue) ? (string) $newValue : json_encode($newValue));
    $stmt = $conn->prepare("INSERT INTO `order_management_audit`
        (`order_id`, `order_item_id`, `action`, `field_name`, `old_value`, `new_value`, `reason`, `user_id`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param('iisssssi', $orderId, $orderItemId, $action, $fieldName, $oldText, $newText, $reason, $userId);
        $stmt->execute();
        $stmt->close();
    }
}

function mvOrderRequiresApproval(int $sourceType): bool
{
    return in_array($sourceType, [2, 3, 4], true);
}

function mvGetOrderProformaInvoice(mysqli $conn, string $source, int $invoiceId, int $customerId): ?array
{
    if ($invoiceId <= 0 || $customerId <= 0) {
        return null;
    }
    if ($source === 'website') {
        $stmt = $conn->prepare("SELECT `id`, `pi_number` AS `number`, `pi_date` AS `date`,
                `total_amount` AS `value`, `validity_date`, `status`
            FROM `pi_requests` WHERE `id` = ? AND `customer_id` = ? LIMIT 1");
    } else {
        $source = 'erp';
        $stmt = $conn->prepare("SELECT `id`, `pi_auto_batch` AS `number`, `enquiry_date` AS `date`,
                `total_price` AS `value`, `validity_date`, `status`
            FROM `proforma_invoices` WHERE `id` = ? AND `customer_id` = ? AND `deleted_at` IS NULL LIMIT 1");
    }
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('ii', $invoiceId, $customerId);
    $stmt->execute();
    $invoice = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if ($invoice) {
        $invoice['source'] = $source;
    }
    return $invoice;
}

function mvSyncLiveStockReservedQuantity(mysqli $conn, ?int $liveStockId = null): void
{
    if (!mvDbColumnExists($conn, 'live_stock', 'reserved_qty')) {
        return;
    }
    $where = $liveStockId !== null && $liveStockId > 0 ? ' WHERE `id` = ?' : '';
    $stmt = $conn->prepare("UPDATE `live_stock` AS `stock`
        SET `reserved_qty` = COALESCE((
            SELECT SUM(`reservation`.`quantity`)
            FROM `order_stock_reservations` AS `reservation`
            WHERE `reservation`.`live_stock_id` = `stock`.`id`
              AND `reservation`.`status` = 1
              AND `reservation`.`deleted_at` IS NULL
        ), 0)" . $where);
    if (!$stmt) {
        return;
    }
    if ($where !== '') {
        $stmt->bind_param('i', $liveStockId);
    }
    $stmt->execute();
    $stmt->close();
}

function mvReleaseOrderReservations(mysqli $conn, int $orderId, int $updatedBy): void
{
    $stockIds = [];
    $stmt = $conn->prepare("SELECT DISTINCT `live_stock_id` FROM `order_stock_reservations`
        WHERE `order_id` = ? AND `status` = 1 FOR UPDATE");
    if ($stmt) {
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $stockIds[] = (int) $row['live_stock_id'];
        }
        $stmt->close();
    }
    $release = $conn->prepare("UPDATE `order_stock_reservations`
        SET `status` = 0, `closed_reason` = 'released',
            `updated_by` = ?, `updated_at` = NOW()
        WHERE `order_id` = ? AND `status` = 1");
    if ($release) {
        $release->bind_param('ii', $updatedBy, $orderId);
        $release->execute();
        $release->close();
    }
    foreach ($stockIds as $stockId) {
        mvSyncLiveStockReservedQuantity($conn, $stockId);
    }
}

function mvFindSupplierByIdentifier(mysqli $conn, string $identifier): ?array
{
    $identifier = trim($identifier);
    if ($identifier === '') {
        return null;
    }

    // Strip " (Linked Vendor)" suffix if present
    if (substr($identifier, -16) === ' (Linked Vendor)') {
        $identifier = substr($identifier, 0, -16);
        $identifier = trim($identifier);
    }

    $emailSelect = mvDbColumnExists($conn, 'suppliers', 'email') ? '`email`' : "'' AS `email`";

    if (ctype_digit($identifier)) {
        $supplierId = (int) $identifier;
        $stmt = $conn->prepare("SELECT `id`, `name`, {$emailSelect} FROM `suppliers` WHERE `id` = ? AND `status` = 1 AND `deleted_at` IS NULL LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $supplierId);
            $stmt->execute();
            $supplier = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($supplier) {
                return $supplier;
            }
        }
    } else {
        // 1. Try exact match first
        $stmt = $conn->prepare("SELECT `id`, `name`, {$emailSelect} FROM `suppliers` WHERE (`name` = ? OR `contact_person` = ?) AND `status` = 1 AND `deleted_at` IS NULL LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('ss', $identifier, $identifier);
            $stmt->execute();
            $supplier = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($supplier) {
                return $supplier;
            }
        }

        // 2. Try smart partial match fallback
        $sql = "SELECT `id`, `name`, {$emailSelect} FROM `suppliers` WHERE (
            (CHAR_LENGTH(`name`) >= 3 AND ? LIKE CONCAT('%', `name`, '%'))
            OR `name` LIKE ?
        ) AND `status` = 1 AND `deleted_at` IS NULL LIMIT 1";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $likeInput = "%" . $identifier . "%";
            $stmt->bind_param('ss', $identifier, $likeInput);
            $stmt->execute();
            $supplier = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($supplier) {
                return $supplier;
            }
        }
    }

    return null;
}

function mvGetShipmentBranchSnapshot(mysqli $conn, int $branchId): ?array
{
    if ($branchId <= 0) {
        return null;
    }

    $companyId = (int) ($_SESSION['company_id'] ?? 0);
    $stmt = $conn->prepare("SELECT id, branch_name, branch_gst_no, address, city, state, pincode FROM erp_branches WHERE id = ? AND (? = 0 OR company_id = ?) AND status = 1 AND deleted_at IS NULL LIMIT 1");
    $stmt->bind_param('iii', $branchId, $companyId, $companyId);
    $stmt->execute();
    $branch = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$branch) {
        return null;
    }

    $lines = [trim((string) $branch['branch_name'])];
    if (trim((string) ($branch['address'] ?? '')) !== '') {
        $lines[] = trim((string) $branch['address']);
    }
    $location = implode(', ', array_filter([
        trim((string) ($branch['city'] ?? '')),
        trim((string) ($branch['state'] ?? '')),
    ]));
    if (trim((string) ($branch['pincode'] ?? '')) !== '') {
        $location .= ($location !== '' ? ' - ' : '') . trim((string) $branch['pincode']);
    }
    if ($location !== '') {
        $lines[] = $location;
    }

    return [
        'branch_id' => (int) $branch['id'],
        'address_snapshot' => implode("\n", array_filter($lines)),
        'gst_snapshot' => trim((string) ($branch['branch_gst_no'] ?? '')),
    ];
}

function mvCalculateInboundReceiptStatus(float $expectedQty, float $receivedQty): int
{
    if ($receivedQty <= 0) {
        return 0;
    }
    if ($expectedQty <= 0) {
        return 4;
    }
    if ($receivedQty > $expectedQty) {
        return 4;
    }
    if (abs($receivedQty - $expectedQty) < 0.00001) {
        return 2;
    }
    if ($receivedQty <= ($expectedQty / 2)) {
        return 5;
    }
    return 1;
}

function mvGetProcurementAgingDays(mysqli $conn): int
{
    $result = $conn->query("SELECT `low_stock_aging_days` FROM `procurement_settings` WHERE `id` = 1 LIMIT 1");
    if (!$result) {
        return 30;
    }

    $days = (int) ($result->fetch_assoc()['low_stock_aging_days'] ?? 30);
    return in_array($days, [30, 60], true) ? $days : 30;
}

function mvIsInboundReceiptCompleteStatus(int $status): bool
{
    return in_array($status, [2, 4], true);
}

function mvGetGoodsTypeForProduct(mysqli $conn, int $productId, int $categoryId = 0): string
{
    $goodsType = 'RM';
    if ($productId > 0) {
        $stmt = $conn->prepare("SELECT COALESCE(p.`inventory_group`, c.`inventory_group`, 3) AS inventory_group FROM `products` p LEFT JOIN `product_categories` c ON c.id = p.category_id WHERE p.id = ? LIMIT 1");
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $grp = (int) ($row['inventory_group'] ?? 3);
        if ($grp === 1) {
            $goodsType = 'FG';
        } elseif ($grp === 2) {
            $goodsType = 'PM';
        } elseif ($grp === 4) {
            $goodsType = 'CON';
        }
    } elseif ($categoryId > 0) {
        $stmt = $conn->prepare("SELECT `inventory_group` FROM `product_categories` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $categoryId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $grp = (int) ($row['inventory_group'] ?? 3);
        if ($grp === 1) {
            $goodsType = 'FG';
        } elseif ($grp === 2) {
            $goodsType = 'PM';
        } elseif ($grp === 4) {
            $goodsType = 'CON';
        }
    }
    return $goodsType;
}

function mvQueueStockInwardForCoa(mysqli $conn, int $stockInwardId, int $productId, int $categoryId, int $supplierId, float $quantity, int $quantityUnit, int $createdBy): void
{
    if ($stockInwardId <= 0 || $productId <= 0 || $quantity <= 0) {
        return;
    }

    $checkStmt = $conn->prepare("SELECT `id`, `status` FROM `coa_inbound_queue` WHERE `stock_inward_id` = ? LIMIT 1");
    if ($checkStmt) {
        $checkStmt->bind_param('i', $stockInwardId);
        $checkStmt->execute();
        $existingQueue = $checkStmt->get_result()->fetch_assoc();
        if ($existingQueue) {
            $checkStmt->close();
            if ((int) $existingQueue['status'] === 2) {
                $goodsType = mvGetGoodsTypeForProduct($conn, $productId, $categoryId);
                $existingQueueId = (int) $existingQueue['id'];
                $resetStmt = $conn->prepare("UPDATE coa_inbound_queue SET product_id = ?, product_category_id = ?, supplier_id = ?, quantity = ?, quantity_unit = ?, goods_type = ?, status = 0, coa_id = NULL, updated_by = ?, updated_at = NOW() WHERE id = ?");
                $resetStmt->bind_param('iiidisii', $productId, $categoryId, $supplierId, $quantity, $quantityUnit, $goodsType, $createdBy, $existingQueueId);
                if (!$resetStmt->execute()) {
                    throw new Exception('Failed to reopen the COA queue item: ' . $resetStmt->error);
                }
                $resetStmt->close();
            }
            return;
        }
        $checkStmt->close();
    }

    $goodsType = mvGetGoodsTypeForProduct($conn, $productId, $categoryId);
    $stmt = $conn->prepare("INSERT INTO `coa_inbound_queue` (`stock_inward_id`, `product_id`, `product_category_id`, `supplier_id`, `quantity`, `quantity_unit`, `goods_type`, `status`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)");
    if (!$stmt) {
        throw new Exception('Failed to prepare COA queue insert: ' . $conn->error);
    }
    $stmt->bind_param('iiiidisi', $stockInwardId, $productId, $categoryId, $supplierId, $quantity, $quantityUnit, $goodsType, $createdBy);
    if (!$stmt->execute()) {
        throw new Exception('Failed to queue item for COA generation: ' . $stmt->error);
    }
    $stmt->close();
}

function mvCompleteProcurementRequestForPoItem(mysqli $conn, bool $isFinalPo, int $poItemId, int $updatedBy): void
{
    $table = $isFinalPo ? 'purchase_order_final' : 'purchase_order_raw_items';
    $stmt = $conn->prepare("SELECT `low_stock_id`, `status` FROM `{$table}` WHERE `id` = ? AND `deleted_at` IS NULL LIMIT 1");
    $stmt->bind_param('i', $poItemId);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $lowStockId = (int) ($item['low_stock_id'] ?? 0);
    if ($lowStockId <= 0 || !mvIsInboundReceiptCompleteStatus((int) ($item['status'] ?? 0))) {
        return;
    }

    $completedStatus = Constant::LOW_STOCK['STATUS_LABEL']['Completed'];
    $update = $conn->prepare("UPDATE `low_stocks` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ? AND `deleted_at` IS NULL");
    $update->bind_param('iii', $completedStatus, $updatedBy, $lowStockId);
    $update->execute();
    $update->close();
}

function mvCalculateReceiptStatus(float $expectedQty, float $cumulativeReceivedQty): int
{
    $complete = Constant::STOCKS_INWARDS['RECEIPT_STATUS_LABEL']['Complete'];
    $partial = Constant::STOCKS_INWARDS['RECEIPT_STATUS_LABEL']['Partially_Received'];
    $excess = Constant::STOCKS_INWARDS['RECEIPT_STATUS_LABEL']['Excess_Received'];
    $half = Constant::STOCKS_INWARDS['RECEIPT_STATUS_LABEL']['Half_Received'];

    if ($expectedQty > 0 && abs($cumulativeReceivedQty - $expectedQty) < 0.000001) {
        return $complete;
    }
    if ($cumulativeReceivedQty > $expectedQty) {
        return $excess;
    }
    if ($expectedQty > 0 && abs($cumulativeReceivedQty - ($expectedQty / 2)) < 0.000001) {
        return $half;
    }
    return $partial;
}

function mvStoreProductImageUpload(array $file): string
{
    $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE
            ? 'Product image must not exceed 5 MB.'
            : 'Unable to upload the product image.');
    }

    $tmpName = (string) ($file['tmp_name'] ?? '');
    $fileSize = (int) ($file['size'] ?? 0);
    if ($tmpName === '' || $fileSize <= 0 || $fileSize > 5 * 1024 * 1024) {
        throw new RuntimeException('Product image must be a non-empty file no larger than 5 MB.');
    }

    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = (string) $finfo->file($tmpName);
    if (!isset($allowedMimeTypes[$mimeType])) {
        throw new RuntimeException('Product image must be a valid JPG, PNG, or WebP file.');
    }

    $uploadDir = dirname(__DIR__) . '/assets/uploads/products/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        throw new RuntimeException('Unable to create the product image directory.');
    }

    $fileName = 'product_' . bin2hex(random_bytes(12)) . '.' . $allowedMimeTypes[$mimeType];
    if (!move_uploaded_file($tmpName, $uploadDir . $fileName)) {
        throw new RuntimeException('Unable to store the product image.');
    }

    return 'assets/uploads/products/' . $fileName;
}

function mvDeleteProductImage(?string $relativePath): void
{
    $relativePath = str_replace('\\', '/', trim((string) $relativePath));
    if ($relativePath === '' || strpos($relativePath, 'assets/uploads/products/') !== 0) {
        return;
    }

    $filePath = dirname(__DIR__) . '/assets/uploads/products/' . basename($relativePath);
    if (is_file($filePath)) {
        @unlink($filePath);
    }
}

/**
 * Allocate the next Product Master CAT number while the caller's transaction is active.
 *
 * The sequence row is locked until commit/rollback, preventing two concurrent product
 * creates from receiving the same number. Existing CAT numbers are inspected when a
 * financial-year sequence is first used so legacy data is not overwritten or reused.
 */
function mvProductCategoryPrefix(string $name): string
{
    $name = trim($name);
    if (preg_match('/\((.*?)\)/', $name, $m) && !empty(trim($m[1]))) {
        $clean = preg_replace('/[^A-Z]/', '', strtoupper($m[1]));
        if (strlen($clean) >= 3) {
            return substr($clean, 0, 3);
        }
    }
    $clean = preg_replace('/[^A-Z]/', '', strtoupper($name));
    return strlen($clean) >= 3 ? substr($clean, 0, 3) : str_pad($clean ?: 'GEN', 3, 'X');
}

function mvNextProductCatNumber(mysqli $conn, ?string $asOfDate = null, ?string $categoryPrefix = null, ?string $stageCode = null): string
{
    $asOfDate = $asOfDate ?? date('Y-m-d');
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $asOfDate);
    if (!$date || $date->format('Y-m-d') !== $asOfDate) {
        throw new RuntimeException('A valid date is required to generate the CAT number.');
    }

    $calendarYear = (int) $date->format('Y');
    $financialYearStart = (int) $date->format('n') >= 4 ? $calendarYear : $calendarYear - 1;
    $financialYear = sprintf('%02d-%02d', $financialYearStart % 100, ($financialYearStart + 1) % 100);

    $companyCode = 'BGX';
    $companyStmt = $conn->prepare("SELECT `company_code`
        FROM `erp_companies`
        WHERE `status` = 1 AND `deleted_at` IS NULL AND TRIM(`company_code`) <> ''
        ORDER BY `id` ASC LIMIT 1");
    if ($companyStmt) {
        $companyStmt->execute();
        $companyRow = $companyStmt->get_result()->fetch_assoc();
        $companyStmt->close();
        $configuredCode = strtoupper(trim((string) ($companyRow['company_code'] ?? '')));
        if ($configuredCode !== '') {
            $companyCode = preg_replace('/[^A-Z0-9]/', '', $configuredCode) ?: $companyCode;
        }
    }

    $sequenceScope = 'CAT';
    if ($categoryPrefix !== null || $stageCode !== null) {
        $cat3 = $categoryPrefix ? strtoupper(substr(preg_replace('/[^A-Z0-9]/', '', $categoryPrefix), 0, 3)) : 'RAP';
        $stage = $stageCode ? strtoupper(preg_replace('/[^A-Z0-9]/', '', $stageCode)) : 'FG';
        $sequenceScope = $cat3 . '/' . $stage;
        $catPrefix = $companyCode . '/' . $cat3 . '/' . $stage . '/' . $calendarYear . '/';
    } else {
        $catPrefix = $companyCode . '/CAT/FY' . $financialYear . '/';
    }
    $catPattern = $catPrefix . '%';

    $seedStmt = $conn->prepare("INSERT INTO `product_cat_sequences`
            (`company_code`, `financial_year_start`, `sequence_scope`, `last_sequence`)
        SELECT ?, ?, ?, COALESCE(MAX(CAST(SUBSTRING_INDEX(`product_code`, '/', -1) AS UNSIGNED)), 0)
        FROM `products`
        WHERE `product_code` LIKE ?
        ON DUPLICATE KEY UPDATE
            `last_sequence` = GREATEST(`last_sequence`, VALUES(`last_sequence`))");
    if (!$seedStmt) {
        throw new RuntimeException('The Product HSN and CAT sequence migration must be applied before adding products.');
    }
    $seedStmt->bind_param('siss', $companyCode, $financialYearStart, $sequenceScope, $catPattern);
    if (!$seedStmt->execute()) {
        throw new RuntimeException('Unable to initialize the CAT number sequence: ' . $seedStmt->error);
    }
    $seedStmt->close();

    $sequenceStmt = $conn->prepare("SELECT `last_sequence`
        FROM `product_cat_sequences`
        WHERE `company_code` = ? AND `financial_year_start` = ? AND `sequence_scope` = ?
        FOR UPDATE");
    if (!$sequenceStmt) {
        throw new RuntimeException('Unable to lock the CAT number sequence.');
    }
    $sequenceStmt->bind_param('sis', $companyCode, $financialYearStart, $sequenceScope);
    $sequenceStmt->execute();
    $sequenceRow = $sequenceStmt->get_result()->fetch_assoc();
    $sequenceStmt->close();
    if (!$sequenceRow) {
        throw new RuntimeException('Unable to initialize the CAT number sequence.');
    }

    $nextSequence = (int) $sequenceRow['last_sequence'] + 1;
    $candidateCatNumber = '';
    $collisionStmt = $conn->prepare("SELECT 1 FROM `products` WHERE `product_code` = ? LIMIT 1");
    if (!$collisionStmt) {
        throw new RuntimeException('Unable to validate the next CAT number.');
    }

    for ($attempt = 0; $attempt < 1000; $attempt++, $nextSequence++) {
        $candidateCatNumber = $catPrefix . str_pad((string) $nextSequence, 6, '0', STR_PAD_LEFT);
        $collisionStmt->bind_param('s', $candidateCatNumber);
        $collisionStmt->execute();
        if (!$collisionStmt->get_result()->fetch_row()) {
            break;
        }
        $candidateCatNumber = '';
    }
    $collisionStmt->close();

    if ($candidateCatNumber === '') {
        throw new RuntimeException('Unable to allocate a unique CAT number.');
    }

    $updateStmt = $conn->prepare("UPDATE `product_cat_sequences`
        SET `last_sequence` = ?, `updated_at` = NOW()
        WHERE `company_code` = ? AND `financial_year_start` = ? AND `sequence_scope` = ?");
    if (!$updateStmt) {
        throw new RuntimeException('Unable to update the CAT number sequence.');
    }
    $updateStmt->bind_param('isis', $nextSequence, $companyCode, $financialYearStart, $sequenceScope);
    if (!$updateStmt->execute()) {
        throw new RuntimeException('Unable to update the CAT number sequence: ' . $updateStmt->error);
    }
    $updateStmt->close();

    return $candidateCatNumber;
}

function mvResolveOrCreateRawProduct(mysqli $conn, string $name, int $categoryId = 0, int $unitId = 0, int $userId = 1): int
{
    $name = trim($name);
    if ($name === '') {
        return 0;
    }

    // Check if product already exists by name (case-insensitive)
    $stmt = $conn->prepare("SELECT `id`, `category_id`, `unit_id` FROM `products` WHERE LOWER(TRIM(`product_name`)) = LOWER(?) AND `deleted_at` IS NULL LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $existingId = (int) $row['id'];
            $stmt->close();
            if (($row['category_id'] === null || (int)$row['category_id'] === 0) && $categoryId > 0) {
                $upStmt = $conn->prepare("UPDATE `products` SET `category_id` = ? WHERE `id` = ?");
                if ($upStmt) {
                    $upStmt->bind_param("ii", $categoryId, $existingId);
                    $upStmt->execute();
                    $upStmt->close();
                }
            }
            if (($row['unit_id'] === null || (int)$row['unit_id'] === 0) && $unitId > 0) {
                $upStmt = $conn->prepare("UPDATE `products` SET `unit_id` = ? WHERE `id` = ?");
                if ($upStmt) {
                    $upStmt->bind_param("ii", $unitId, $existingId);
                    $upStmt->execute();
                    $upStmt->close();
                }
            }
            return $existingId;
        }
        $stmt->close();
    }

    // Determine category prefix & inventory group
    $catPrefix = 'RAW';
    $catGroup = 2;
    if ($categoryId > 0) {
        $catStmt = $conn->prepare("SELECT `name`, `inventory_group` FROM `product_categories` WHERE `id` = ? LIMIT 1");
        if ($catStmt) {
            $catStmt->bind_param("i", $categoryId);
            $catStmt->execute();
            if ($catRow = $catStmt->get_result()->fetch_assoc()) {
                if (function_exists('mvProductCategoryPrefix')) {
                    $catPrefix = mvProductCategoryPrefix((string)$catRow['name']);
                } else {
                    $catPrefix = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', (string)$catRow['name']), 0, 3)) ?: 'RAW';
                }
                $catGroup = (int) ($catRow['inventory_group'] ?? 2);
            }
            $catStmt->close();
        }
    }

    $productCode = '';
    if (function_exists('mvNextProductCatNumber')) {
        try {
            $productCode = mvNextProductCatNumber($conn, null, $catPrefix, 'RM');
        } catch (Throwable $e) {
            $productCode = 'RM-' . date('Ymd') . '-' . rand(1000, 9999);
        }
    } else {
        $productCode = 'RM-' . date('Ymd') . '-' . rand(1000, 9999);
    }

    $userId = $userId > 0 ? $userId : 1;
    $insertStmt = $conn->prepare("INSERT INTO `products` (`product_code`, `product_name`, `category_id`, `inventory_group`, `unit_id`, `status`, `created_by`, `created_at`) VALUES (?, ?, ?, ?, ?, 1, ?, NOW())");
    if ($insertStmt) {
        $insertStmt->bind_param("ssiiii", $productCode, $name, $categoryId, $catGroup, $unitId, $userId);
        if ($insertStmt->execute()) {
            $newId = (int) $conn->insert_id;
            $insertStmt->close();
            return $newId;
        }
        $insertStmt->close();
    }

    return 0;
}

function mvStoreInvoiceUploads(array $files): ?string
{
    if (!isset($files['name'])) {
        return null;
    }

    $names = is_array($files['name']) ? $files['name'] : [$files['name']];
    $tmpNames = is_array($files['tmp_name'] ?? null) ? $files['tmp_name'] : [$files['tmp_name'] ?? ''];
    $errors = is_array($files['error'] ?? null) ? $files['error'] : [$files['error'] ?? UPLOAD_ERR_NO_FILE];
    $sizes = is_array($files['size'] ?? null) ? $files['size'] : [$files['size'] ?? 0];
    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf',
    ];
    $uploadDir = __DIR__ . '/uploads/invoices/';
    $paths = [];
    $finfo = new finfo(FILEINFO_MIME_TYPE);

    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        throw new RuntimeException('Unable to create the invoice upload directory.');
    }

    foreach ($names as $index => $originalName) {
        $error = (int) ($errors[$index] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE || trim((string) $originalName) === '') {
            continue;
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException('An invoice file could not be uploaded.');
        }

        $size = (int) ($sizes[$index] ?? 0);
        if ($size <= 0 || $size > 10 * 1024 * 1024) {
            throw new RuntimeException('Invoice files must be 10 MB or smaller.');
        }

        $tmpName = (string) ($tmpNames[$index] ?? '');
        $mimeType = $tmpName !== '' ? $finfo->file($tmpName) : false;
        if (!$mimeType || !isset($allowedMimeTypes[$mimeType])) {
            throw new RuntimeException('Invoice files must be JPG, PNG, WebP, or PDF.');
        }

        $newName = 'invoice_' . date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.' . $allowedMimeTypes[$mimeType];
        if (!move_uploaded_file($tmpName, $uploadDir . $newName)) {
            throw new RuntimeException('Unable to store an invoice file.');
        }
        $paths[] = 'uploads/invoices/' . $newName;
    }

    return $paths ? json_encode($paths) : null;
}

function mvResolveOrderProduct(mysqli $conn, string $productName): ?array
{
    static $cache = [];
    $productName = trim($productName);
    if ($productName === '') {
        return null;
    }

    if (isset($cache[$productName])) {
        return $cache[$productName];
    }

    // 0. Try numeric ID match first if input is an integer ID (e.g. from select option value)
    if (is_numeric($productName) && (int)$productName > 0) {
        $prodId = (int)$productName;
        $stmt = $conn->prepare("SELECT `id`, `product_name`, `category_id`, `unit_id`, `reorder_level`, `erp_sku_web` FROM `products` WHERE `status` = 1 AND `deleted_at` IS NULL AND `id` = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $prodId);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($product) {
                $cache[$productName] = $product;
                return $product;
            }
        }
    }

    // 1. Try exact match on product_name or product_code
    $stmt = $conn->prepare("SELECT `id`, `product_name`, `category_id`, `unit_id`, `reorder_level`, `erp_sku_web` FROM `products` WHERE `status` = 1 AND `deleted_at` IS NULL AND (`product_name` = ? OR `product_code` = ?) LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('ss', $productName, $productName);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($product) {
            $cache[$productName] = $product;
            return $product;
        }
    }

    // 1b. If format is "Product Name (PRODUCT_CODE)", extract the name or code
    if (preg_match('/^(.*?)\s*\(([^)]+)\)$/', $productName, $m)) {
        $extractedName = trim($m[1]);
        $extractedCode = trim($m[2]);
        $stmt = $conn->prepare("SELECT `id`, `product_name`, `category_id`, `unit_id`, `reorder_level`, `erp_sku_web` FROM `products` WHERE `status` = 1 AND `deleted_at` IS NULL AND (`product_name` = ? OR `product_code` = ?) LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('ss', $extractedName, $extractedCode);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($product) {
                $cache[$productName] = $product;
                return $product;
            }
        }
    }

    // 2. Try LIKE fallback if exact match wasn't found
    $likeVal = '%' . $productName . '%';
    $stmt = $conn->prepare("SELECT `id`, `product_name`, `category_id`, `unit_id`, `reorder_level`, `erp_sku_web` FROM `products` WHERE `status` = 1 AND `deleted_at` IS NULL AND (`product_name` LIKE ? OR `product_code` LIKE ?) ORDER BY CASE WHEN `product_name` = ? THEN 0 ELSE 1 END, `product_name` ASC LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('sss', $likeVal, $likeVal, $productName);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $cache[$productName] = $product ?: null;
        return $product ?: null;
    }

    $cache[$productName] = null;
    return null;
}

function mvGetUnitFactorForOrder(mysqli $conn, int $unitId): float
{
    if ($unitId <= 0) {
        return 1.0;
    }

    $factor = 1.0;
    $stmt = $conn->prepare("SELECT `factor` FROM `standard_units` WHERE `id` = ? AND `status` = 1 LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('i', $unitId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $factor = (float) ($row['factor'] ?? 1);
    }

    return $factor > 0 ? $factor : 1.0;
}

/**
 * Resolve a reliable active unit for production without changing the existing
 * quantity-conversion rules. Product/order units remain authoritative; stock
 * and pack history are used only for legacy records where those links are empty.
 */
function mvResolveProductionUnitId(mysqli $conn, int $productId, array $preferredUnitIds = []): int
{
    $unitIds = array_values(array_unique(array_filter(
        array_map('intval', $preferredUnitIds),
        static fn (int $unitId): bool => $unitId > 0
    )));

    if (!empty($unitIds)) {
        $placeholders = implode(',', array_fill(0, count($unitIds), '?'));
        $types = str_repeat('i', count($unitIds));
        $stmt = $conn->prepare("SELECT `id` FROM `standard_units`
            WHERE `id` IN ({$placeholders}) AND `status` = 1 AND `factor` > 0");
        if ($stmt) {
            $stmt->bind_param($types, ...$unitIds);
            $stmt->execute();
            $result = $stmt->get_result();
            $activeUnitIds = [];
            while ($row = $result->fetch_assoc()) {
                $activeUnitIds[(int) $row['id']] = true;
            }
            $stmt->close();
            foreach ($unitIds as $unitId) {
                if (isset($activeUnitIds[$unitId])) {
                    return $unitId;
                }
            }
        }
    }

    if ($productId <= 0) {
        return 0;
    }

    $stockStmt = $conn->prepare("SELECT NULLIF(stock.quantity_unit, 0) AS unit_id
        FROM live_stock AS stock
        INNER JOIN standard_units AS unit
          ON unit.id = NULLIF(stock.quantity_unit, 0)
         AND unit.status = 1 AND unit.factor > 0
        WHERE stock.product_id = ? AND stock.deleted_at IS NULL
        ORDER BY stock.id DESC LIMIT 1");
    if ($stockStmt) {
        $stockStmt->bind_param('i', $productId);
        $stockStmt->execute();
        $stockUnitId = (int) ($stockStmt->get_result()->fetch_assoc()['unit_id'] ?? 0);
        $stockStmt->close();
        if ($stockUnitId > 0) {
            return $stockUnitId;
        }
    }

    $packStmt = $conn->prepare("SELECT pack.pack_unit_id AS unit_id
        FROM product_pack_sizes AS pack
        INNER JOIN standard_units AS unit
          ON unit.id = pack.pack_unit_id AND unit.status = 1 AND unit.factor > 0
        WHERE pack.product_id = ? AND pack.status != 3 AND pack.deleted_at IS NULL
        ORDER BY pack.sort_order ASC, pack.id ASC LIMIT 1");
    if ($packStmt) {
        $packStmt->bind_param('i', $productId);
        $packStmt->execute();
        $packUnitId = (int) ($packStmt->get_result()->fetch_assoc()['unit_id'] ?? 0);
        $packStmt->close();
        if ($packUnitId > 0) {
            return $packUnitId;
        }
    }

    return 0;
}

function mvGetOrderStockAnalysis(mysqli $conn, int $orderId, bool $usePersistedReservations = false): array
{
    $itemsQ = $conn->prepare("SELECT `id`, `product_id`, `product_name`, `quantity`, `unit`, `status` AS `item_status`,
            COALESCE(`fulfilled_quantity`, 0) AS `fulfilled_quantity_base`,
            COALESCE(`reserved_quantity`, 0) AS `stored_reserved_base`,
            COALESCE(`shortfall_quantity`, 0) AS `stored_shortfall_base`,
            `fulfillment_action`, `fulfillment_status`
        FROM `order_received_items`
        WHERE `order_id` = ? AND `deleted_at` IS NULL AND `status` != 3 ORDER BY `id` ASC");
    if (!$itemsQ) {
        throw new RuntimeException('Unable to prepare order stock analysis: ' . $conn->error);
    }
    $itemsQ->bind_param('i', $orderId);
    $itemsQ->execute();
    $itemsResult = $itemsQ->get_result();

    $items = [];
    $allSufficient = true;
    $hasAnyAvailable = false;
    $productAllocated = [];
    while ($item = $itemsResult->fetch_assoc()) {
        $product = null;
        $storedProductId = (int) ($item['product_id'] ?? 0);
        if ($storedProductId > 0) {
            $productStmt = $conn->prepare("SELECT `id`, `product_name`, `category_id`, `unit_id`, `reorder_level`, `erp_sku_web`
                FROM `products` WHERE `id` = ? AND `status` = 1 AND `deleted_at` IS NULL LIMIT 1");
            if ($productStmt) {
                $productStmt->bind_param('i', $storedProductId);
                $productStmt->execute();
                $product = $productStmt->get_result()->fetch_assoc() ?: null;
                $productStmt->close();
            }
        }
        if (!$product) {
            $product = mvResolveOrderProduct($conn, $item['product_name']);
        }
        $qty = (float) ($item['quantity'] ?? 0);
        $unitId = mvResolveProductionUnitId(
            $conn,
            (int) ($product['id'] ?? $storedProductId),
            [(int) ($item['unit'] ?? 0), (int) ($product['unit_id'] ?? 0)]
        );
        $fulfilledBaseQty = max(0, (float) ($item['fulfilled_quantity_base'] ?? 0));
        $requiredBaseQty = max(0, $qty - $fulfilledBaseQty);

        if ($requiredBaseQty < 0.00000001 && $fulfilledBaseQty > 0) {
            $items[] = [
                'order_item_id' => (int) $item['id'],
                'product_name' => $item['product_name'],
                'quantity' => $qty,
                'unit' => $unitId,
                'product_unit_id' => mvResolveProductionUnitId(
                    $conn,
                    (int) ($product['id'] ?? $storedProductId),
                    [(int) ($product['unit_id'] ?? 0), $unitId]
                ),
                'product_id' => (int) ($product['id'] ?? $storedProductId),
                'category_id' => (int) ($product['category_id'] ?? 0),
                'sku' => (string) ($product['erp_sku_web'] ?? ''),
                'physical_stock' => 0,
                'available_stock' => 0,
                'required_base' => 0,
                'reserved_base' => 0,
                'shortfall_base' => 0,
                'minimum_required_base' => 0,
                'fulfillment_action' => (string) ($item['fulfillment_action'] ?? ''),
                'fulfillment_status' => (string) ($item['fulfillment_status'] ?? ''),
                'status' => 'COMPLETED',
            ];
            continue;
        }

        if ($qty <= 0) {
            $allSufficient = false;
            $items[] = [
                'order_item_id' => (int) $item['id'],
                'product_name' => $item['product_name'],
                'quantity' => $qty,
                'unit' => $unitId,
                'product_unit_id' => 0,
                'product_id' => 0,
                'category_id' => 0,
                'sku' => '',
                'available_stock' => 0,
                'required_base' => $requiredBaseQty,
                'reserved_base' => 0,
                'shortfall_base' => $requiredBaseQty,
                'minimum_required_base' => 0,
                'fulfillment_action' => (string) ($item['fulfillment_action'] ?? ''),
                'fulfillment_status' => (string) ($item['fulfillment_status'] ?? ''),
                'status' => 'INVALID_QUANTITY'
            ];
            continue;
        }

        if (!$product) {
            $allSufficient = false;
            $items[] = [
                'order_item_id' => (int) $item['id'],
                'product_name' => $item['product_name'],
                'quantity' => $qty,
                'unit' => $unitId,
                'product_unit_id' => 0,
                'product_id' => 0,
                'category_id' => 0,
                'sku' => '',
                'available_stock' => 0,
                'required_base' => $requiredBaseQty,
                'reserved_base' => 0,
                'shortfall_base' => $requiredBaseQty,
                'minimum_required_base' => 0,
                'fulfillment_action' => (string) ($item['fulfillment_action'] ?? ''),
                'fulfillment_status' => (string) ($item['fulfillment_status'] ?? ''),
                'status' => 'NOT_FOUND'
            ];
            continue;
        }

        $productId = (int) $product['id'];
        $minimumRequiredBase = 0.0;

        $stockStmt = $conn->prepare("SELECT `quantity_available` AS `physical_base`,
                `unreserved_qty`
            FROM `live_stock`
            WHERE `product_id` = ? AND `status` = 1 AND `deleted_at` IS NULL
            LIMIT 1");
        $stockStmt->bind_param('i', $productId);
        $stockStmt->execute();
        $stockRow = $stockStmt->get_result()->fetch_assoc() ?: [];
        $physicalBase = (float) ($stockRow['physical_base'] ?? 0);
        $unreservedQty = (float) ($stockRow['unreserved_qty'] ?? 0);
        $stockStmt->close();

        $reservationStmt = $conn->prepare("SELECT
                COALESCE(SUM(CASE WHEN `order_id` = ? THEN `quantity` ELSE 0 END), 0) AS `own_reserved`,
                COALESCE(SUM(CASE WHEN `order_id` != ? THEN `quantity` ELSE 0 END), 0) AS `other_reserved`
            FROM `order_stock_reservations` WHERE `product_id` = ? AND `status` = 1");
        $reservationStmt->bind_param('iii', $orderId, $orderId, $productId);
        $reservationStmt->execute();
        $reservationRow = $reservationStmt->get_result()->fetch_assoc();
        $reservationStmt->close();
        $ownReserved = (float) ($reservationRow['own_reserved'] ?? 0);
        $otherReserved = (float) ($reservationRow['other_reserved'] ?? 0);
        $productAvailable = max(0, $unreservedQty);
        $alreadyAllocated = (float) ($productAllocated[$productId] ?? 0);
        $availableForItem = $usePersistedReservations && (string) ($item['fulfillment_status'] ?? 'pending') !== 'pending'
            ? max(0, min($requiredBaseQty, (float) ($item['stored_reserved_base'] ?? 0)))
            : max(0, min($requiredBaseQty, $productAvailable - $alreadyAllocated));
        $productAllocated[$productId] = $alreadyAllocated + $availableForItem;
        $shortfallBase = max(0, $requiredBaseQty - $availableForItem);
        $isAvailable = $requiredBaseQty > 0 && $shortfallBase < 0.00000001;
        if ($availableForItem > 0) {
            $hasAnyAvailable = true;
        }
        if (!$isAvailable) {
            $allSufficient = false;
        }

        $items[] = [
            'order_item_id' => (int) $item['id'],
            'product_name' => $item['product_name'],
            'quantity' => $qty,
            'unit' => $unitId,
            'product_unit_id' => mvResolveProductionUnitId(
                $conn,
                $productId,
                [(int) ($product['unit_id'] ?? 0), $unitId]
            ),
            'product_id' => $productId,
            'category_id' => (int) $product['category_id'],
            'sku' => (string) ($product['erp_sku_web'] ?? ''),
            'physical_stock' => $physicalBase,
            'unreserved_stock' => $productAvailable,
            'available_stock' => $availableForItem,
            'required_base' => $requiredBaseQty,
            'reserved_base' => min($requiredBaseQty, max(0, (float) ($item['stored_reserved_base'] ?? $ownReserved))),
            'shortfall_base' => $shortfallBase,
            'minimum_required_base' => $minimumRequiredBase,
            'fulfillment_action' => (string) ($item['fulfillment_action'] ?? ''),
            'fulfillment_status' => (string) ($item['fulfillment_status'] ?? ''),
            'status' => $isAvailable ? 'SUFFICIENT' : ($availableForItem > 0 ? 'PARTIAL' : 'UNAVAILABLE')
        ];
    }
    $itemsQ->close();

    if (empty($items)) {
        $allSufficient = false;
    }

    return [
        'all_sufficient' => $allSufficient,
        'partially_available' => !$allSufficient && $hasAnyAvailable,
        'all_unavailable' => !$hasAnyAvailable,
        'items' => $items
    ];
}

function mvRecalculateOrderFulfillment(mysqli $conn, int $orderId, int $updatedBy, string $reason = ''): array
{
    $reviewStmt = $conn->prepare('SELECT source_type, status FROM order_received WHERE id = ? AND deleted_at IS NULL LIMIT 1');
    $reviewStmt->bind_param('i', $orderId);
    $reviewStmt->execute();
    $reviewOrder = $reviewStmt->get_result()->fetch_assoc();
    $reviewStmt->close();
    $pendingReview = (int) (Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Pending_Review'] ?? 12);
    if ($reviewOrder && mvOrderRequiresApproval((int) $reviewOrder['source_type'])
        && (int) $reviewOrder['status'] === $pendingReview) {
        return [
            'status' => 'success',
            'action' => 'approval',
            'message' => 'External order is waiting for approval.',
            'order_status' => $pendingReview,
            'analysis' => mvGetOrderStockAnalysis($conn, $orderId),
        ];
    }

    $conn->begin_transaction();
    try {
        $result = mvRecalculateOrderFulfillmentLocked($conn, $orderId, $updatedBy, $reason);
        $conn->commit();
        if (isset($result['order_status'])) {
            mvSyncOrderStatusToWebsite($conn, $orderId, (int) $result['order_status']);
        }
        return $result;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function mvRecalculateOrderFulfillmentLocked(mysqli $conn, int $orderId, int $updatedBy, string $reason = ''): array
{
    if ($orderId <= 0) {
        throw new RuntimeException('Invalid order ID.');
    }

    $orderStmt = $conn->prepare("SELECT `status` FROM `order_received`
            WHERE `id` = ? AND `deleted_at` IS NULL FOR UPDATE");
        $orderStmt->bind_param('i', $orderId);
        $orderStmt->execute();
        $order = $orderStmt->get_result()->fetch_assoc();
        $orderStmt->close();
        if (!$order) {
            throw new RuntimeException('Order not found.');
        }

        $terminalStatuses = [
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'],
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled_by_Client'],
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Complete'],
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Dispatched'],
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Forcefully_Complete'],
        ];
        if (in_array((int) $order['status'], $terminalStatuses, true)) {
            // Cancellation returns reservations to stock. Completed and dispatched
            // orders have already consumed them and must remain read-only here.
            if (in_array((int) $order['status'], [
                Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'],
                Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled_by_Client'],
            ], true)) {
                mvReleaseOrderReservations($conn, $orderId, $updatedBy);
            }
            return [
                'status' => 'success',
                'action' => 'none',
                'message' => 'Order is already in a terminal fulfillment state.',
                'terminal' => true,
            ];
        }

        $releaseOnlyStatuses = [
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Hold'],
            Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Hold_by_Client'],
        ];
        mvReleaseOrderReservations($conn, $orderId, $updatedBy);
        if (in_array((int) $order['status'], $releaseOnlyStatuses, true)) {
            return ['status' => 'success', 'action' => 'released', 'message' => 'Stock reservations released.'];
        }
        $analysis = mvGetOrderStockAnalysis($conn, $orderId);
        $insertReservation = $conn->prepare("INSERT INTO `order_stock_reservations`
            (`order_id`, `order_item_id`, `product_id`, `live_stock_id`,
             `quantity`, `quantity_base`, `created_by`)
            VALUES (?, ?, ?, ?, ?, ?, ?)");
        $updateItem = $conn->prepare("UPDATE `order_received_items`
            SET `reserved_quantity` = ?, `shortfall_quantity` = ?,
                `reserved_quantity_base` = ?, `shortfall_quantity_base` = ?,
                `fulfillment_status` = ?,
                `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ?");
        if (!$insertReservation || !$updateItem) {
            throw new RuntimeException('The order reservation migration must be applied before recalculation.');
        }

        $stockIds = [];
        foreach ($analysis['items'] as &$item) {
            $itemId = (int) ($item['order_item_id'] ?? 0);
            $productId = (int) ($item['product_id'] ?? 0);
            $requiredBase = max(0, (float) ($item['required_base'] ?? 0));
            $reserveTarget = max(0, min($requiredBase, (float) ($item['available_stock'] ?? 0)));
            $reservedBase = 0.0;

            if (($item['status'] ?? '') === 'COMPLETED') {
                $completedStatus = 'completed';
                $zero = 0.0;
                $updateItem->bind_param(
                    'ddddsii',
                    $zero,
                    $zero,
                    $zero,
                    $zero,
                    $completedStatus,
                    $updatedBy,
                    $itemId
                );
                $updateItem->execute();
                continue;
            }

            if ($productId > 0 && $reserveTarget > 0) {
                $balance = inventoryGetBalance($conn, $productId, true, false);
                $capacity = max(0, (float) ($balance['unreserved_qty'] ?? 0));
                $take = min($capacity, $reserveTarget);
                if ($take > 0) {
                    $stockId = inventoryReserveStock($conn, $productId, $take, $updatedBy);
                    $insertReservation->bind_param(
                        'iiiiddi',
                        $orderId,
                        $itemId,
                        $productId,
                        $stockId,
                        $take,
                        $take,
                        $updatedBy
                    );
                    if (!$insertReservation->execute()) {
                        throw new RuntimeException(
                            'Unable to reserve stock for ' . ($item['product_name'] ?? 'order item') . '.'
                        );
                    }
                    $stockIds[$stockId] = true;
                    $reservedBase = $take;
                }
            }

            $shortfallBase = max(0, $requiredBase - $reservedBase);
            $fulfillmentStatus = $shortfallBase < 0.00000001
                ? 'stock_available'
                : ($reservedBase > 0 ? 'partially_available' : 'stock_unavailable');
            $existingAction = (string) ($item['fulfillment_action'] ?? '');
            if ($existingAction === 'dispatch' && $fulfillmentStatus === 'stock_available') {
                $fulfillmentStatus = 'ready_for_dispatch';
            } elseif ($existingAction === 'production' && $shortfallBase > 0) {
                $fulfillmentStatus = 'sent_to_production';
            } elseif ($existingAction === 'procurement' && $shortfallBase > 0) {
                $fulfillmentStatus = 'sent_to_procurement';
            }
            $updateItem->bind_param(
                'ddddsii',
                $reservedBase,
                $shortfallBase,
                $reservedBase,
                $shortfallBase,
                $fulfillmentStatus,
                $updatedBy,
                $itemId
            );
            $updateItem->execute();
            $item['reserved_base'] = $reservedBase;
            $item['available_stock'] = $reservedBase;
            $item['shortfall_base'] = $shortfallBase;
            $item['status'] = $shortfallBase < 0.00000001 ? 'SUFFICIENT' : ($reservedBase > 0 ? 'PARTIAL' : 'UNAVAILABLE');
        }
        unset($item);
        $insertReservation->close();
        $updateItem->close();

        $allSufficient = !empty($analysis['items']);
        $hasReserved = false;
        $hasProductionAction = false;
        $hasProcurementAction = false;
        foreach ($analysis['items'] as $item) {
            $allSufficient = $allSufficient && in_array(($item['status'] ?? ''), ['SUFFICIENT', 'COMPLETED'], true);
            $hasReserved = $hasReserved || (float) ($item['reserved_base'] ?? 0) > 0;
            $hasProductionAction = $hasProductionAction || ($item['fulfillment_action'] ?? '') === 'production';
            $hasProcurementAction = $hasProcurementAction || ($item['fulfillment_action'] ?? '') === 'procurement';
        }
        if ($allSufficient) {
            $nextStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Ready_for_Dispatch'];
        } elseif ($hasProductionAction) {
            $nextStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Production_in_Progress'];
        } elseif ($hasProcurementAction) {
            $nextStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Procurement_in_Progress'];
        } else {
            $nextStatus = $hasReserved
                ? Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Partially_Available']
                : Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Stock_Unavailable'];
        }
        $updateOrder = $conn->prepare("UPDATE `order_received` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ?");
        $updateOrder->bind_param('iii', $nextStatus, $updatedBy, $orderId);
        $updateOrder->execute();
        $updateOrder->close();
        foreach (array_keys($stockIds) as $stockId) {
            mvSyncLiveStockReservedQuantity($conn, (int) $stockId);
        }
        if ((int) $order['status'] !== $nextStatus) {
            mvAuditOrderChange($conn, $orderId, 'stock_recalculated', $updatedBy, null, 'status', $order['status'], $nextStatus, $reason);
        }
        $analysis['all_sufficient'] = $allSufficient;
        $analysis['partially_available'] = !$allSufficient && $hasReserved;
        $analysis['all_unavailable'] = !$hasReserved;
        return [
            'status' => 'success',
            'action' => $allSufficient ? 'dispatch' : 'attention',
            'message' => $allSufficient
                ? 'Stock is reserved and the order is ready for dispatch.'
                : ($hasReserved ? 'Available stock is reserved; choose Production or Procurement for each shortfall.' : 'Stock is unavailable; choose Production or Procurement for each item.'),
            'order_status' => $nextStatus,
            'analysis' => $analysis,
        ];
}

function mvReviewExternalOrder(mysqli $conn, int $orderId, string $decision, string $reason, int $reviewedBy): array
{
    $decision = strtoupper(trim($decision));
    $reason = trim($reason);
    if ($orderId <= 0 || !in_array($decision, ['APPROVE', 'REJECT'], true)) {
        throw new InvalidArgumentException('A valid order and review decision are required.');
    }
    if ($decision === 'REJECT' && $reason === '') {
        throw new InvalidArgumentException('Please enter a reason for rejecting this order.');
    }

    $pendingReview = (int) (Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Pending_Review'] ?? 12);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('SELECT source_type, status FROM order_received WHERE id = ? AND deleted_at IS NULL FOR UPDATE');
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$order) {
            throw new RuntimeException('Order not found.');
        }
        if (!mvOrderRequiresApproval((int) $order['source_type'])) {
            throw new RuntimeException('ERP orders do not require approval.');
        }
        if ((int) $order['status'] !== $pendingReview) {
            throw new RuntimeException('This order has already been reviewed. Refresh the list to see its current status.');
        }
        if ($decision === 'APPROVE') {
            $routing = mvRecalculateOrderFulfillmentLocked(
                $conn,
                $orderId,
                $reviewedBy,
                $reason !== '' ? $reason : 'External order approved.'
            );
            $nextStatus = (int) ($routing['order_status'] ?? $pendingReview);
            mvAuditOrderChange($conn, $orderId, 'external_order_approved', $reviewedBy, null,
                'status', $pendingReview, $nextStatus, $reason !== '' ? $reason : null);
            $message = 'Order approved. ' . ($routing['message'] ?? 'Fulfillment has started.');
        } else {
            $cancelled = (int) (Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'] ?? 6);
            mvReleaseOrderReservations($conn, $orderId, $reviewedBy);
            $items = $conn->prepare('UPDATE order_received_items
                SET status = ?, fulfillment_status = \'cancelled\',
                    reserved_quantity = 0, reserved_quantity_base = 0,
                    updated_by = ?, updated_at = NOW()
                WHERE order_id = ? AND deleted_at IS NULL');
            $items->bind_param('iii', $cancelled, $reviewedBy, $orderId);
            $items->execute();
            $items->close();
            $update = $conn->prepare('UPDATE order_received
                SET status = ?, updated_by = ?, updated_at = NOW()
                WHERE id = ? AND status = ? AND deleted_at IS NULL');
            $update->bind_param('iiii', $cancelled, $reviewedBy, $orderId, $pendingReview);
            $update->execute();
            if ($update->affected_rows !== 1) {
                $update->close();
                throw new RuntimeException('The order status changed during review. Please refresh and try again.');
            }
            $update->close();
            mvAuditOrderChange($conn, $orderId, 'external_order_rejected', $reviewedBy, null,
                'status', $pendingReview, $cancelled, $reason);
            $routing = ['status' => 'success', 'action' => 'rejected', 'order_status' => $cancelled];
            $nextStatus = $cancelled;
            $message = 'Order rejected and removed from the approval queue.';
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }

    mvSyncOrderStatusToWebsite($conn, $orderId, $nextStatus);
    return ['status' => 'success', 'message' => $message, 'routing' => $routing];
}

function mvGetOrderProductionPlanState(mysqli $conn, int $orderId): array
{
    if ($orderId <= 0 || !mvDbColumnExists($conn, 'production_plans', 'order_id')) {
        return ['total' => 0, 'incomplete' => 0];
    }

    $stmt = $conn->prepare("SELECT COUNT(*) AS `total`,
            SUM(CASE WHEN `status` != 2 THEN 1 ELSE 0 END) AS `incomplete`
        FROM `production_plans`
        WHERE `order_id` = ? AND `status` != 3 AND `deleted_at` IS NULL");
    if (!$stmt) {
        throw new RuntimeException('Unable to inspect linked production plans: ' . $conn->error);
    }
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return [
        'total' => (int) ($row['total'] ?? 0),
        'incomplete' => (int) ($row['incomplete'] ?? 0),
    ];
}

function mvNextProductionBatchNumber(mysqli $conn, string $planDate): string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $planDate);
    if (!$date || $date->format('Y-m-d') !== $planDate) {
        throw new RuntimeException('A valid production plan date is required to generate the batch number.');
    }

    // Indian financial year: April through March. The documented batch format is
    // <Company Code>/PROD/FY<YY-YY>/<6-digit sequence>.
    $calendarYear = (int) $date->format('Y');
    $financialYearStart = (int) $date->format('n') >= 4 ? $calendarYear : $calendarYear - 1;
    $financialYear = sprintf('%02d-%02d', $financialYearStart % 100, ($financialYearStart + 1) % 100);
    $companyCode = 'BIO';
    $companyStmt = $conn->prepare("SELECT company_code
        FROM erp_companies
        WHERE status = 1 AND deleted_at IS NULL AND TRIM(company_code) <> ''
        ORDER BY id ASC LIMIT 1");
    if ($companyStmt) {
        $companyStmt->execute();
        $companyRow = $companyStmt->get_result()->fetch_assoc();
        $companyStmt->close();
        $configuredCode = strtoupper(trim((string) ($companyRow['company_code'] ?? '')));
        if ($configuredCode !== '') {
            $companyCode = preg_replace('/[^A-Z0-9]/', '', $configuredCode) ?: $companyCode;
        }
    }
    $batchPrefix = $companyCode . '/PROD/FY' . $financialYear . '/';
    $batchPattern = $batchPrefix . '%';

    $seedStmt = $conn->prepare("INSERT INTO production_batch_sequences (sequence_date, last_sequence)
        SELECT ?, COALESCE(MAX(CAST(SUBSTRING_INDEX(lo_batch_no, '/', -1) AS UNSIGNED)), 0)
        FROM production_plans
        WHERE lo_batch_no LIKE ?
        ON DUPLICATE KEY UPDATE last_sequence = GREATEST(last_sequence, VALUES(last_sequence))");
    if (!$seedStmt) {
        throw new RuntimeException('The production batch sequence migration must be applied before routing orders to Production.');
    }
    $seedStmt->bind_param('ss', $planDate, $batchPattern);
    $seedStmt->execute();
    $seedStmt->close();

    $sequenceStmt = $conn->prepare("SELECT last_sequence
        FROM production_batch_sequences
        WHERE sequence_date = ?
        FOR UPDATE");
    if (!$sequenceStmt) {
        throw new RuntimeException('Unable to lock the production batch sequence.');
    }
    $sequenceStmt->bind_param('s', $planDate);
    $sequenceStmt->execute();
    $sequenceRow = $sequenceStmt->get_result()->fetch_assoc();
    $sequenceStmt->close();
    if (!$sequenceRow) {
        throw new RuntimeException('Unable to initialize the production batch sequence.');
    }

    $nextSequence = (int) $sequenceRow['last_sequence'] + 1;
    $candidateBatchNumber = '';
    $collisionStmt = $conn->prepare("SELECT 1
        FROM production_plans
        WHERE lo_batch_no = ?
        LIMIT 1");
    if (!$collisionStmt) {
        throw new RuntimeException('Unable to validate the next production batch number.');
    }

    // The sequence row is locked above. Skip any batch number already used by
    // current or legacy data so every newly generated document number is unique.
    for ($attempt = 0; $attempt < 1000; $attempt++, $nextSequence++) {
        $candidateBatchNumber = $batchPrefix . str_pad((string) $nextSequence, 6, '0', STR_PAD_LEFT);
        $collisionStmt->bind_param('s', $candidateBatchNumber);
        $collisionStmt->execute();
        if (!$collisionStmt->get_result()->fetch_row()) {
            break;
        }
        $candidateBatchNumber = '';
    }
    $collisionStmt->close();

    if ($candidateBatchNumber === '') {
        throw new RuntimeException('Unable to allocate a unique production batch number.');
    }

    $updateStmt = $conn->prepare("UPDATE production_batch_sequences
        SET last_sequence = ?, updated_at = NOW()
        WHERE sequence_date = ?");
    if (!$updateStmt) {
        throw new RuntimeException('Unable to update the production batch sequence.');
    }
    $updateStmt->bind_param('is', $nextSequence, $planDate);
    $updateStmt->execute();
    $updateStmt->close();

    return $candidateBatchNumber;
}

function mvNextProductionPlanNumber(mysqli $conn, string $planDate): string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $planDate);
    if (!$date || $date->format('Y-m-d') !== $planDate) {
        throw new RuntimeException('A valid production plan date is required to generate the plan number.');
    }

    $calendarYear = (int) $date->format('Y');
    $financialYearStart = (int) $date->format('n') >= 4 ? $calendarYear : $calendarYear - 1;
    $financialYear = sprintf('%02d-%02d', $financialYearStart % 100, ($financialYearStart + 1) % 100);

    $sequenceStmt = $conn->prepare("INSERT INTO production_plan_number_sequences
            (financial_year, last_sequence, updated_at)
        VALUES (?, LAST_INSERT_ID(1), NOW())
        ON DUPLICATE KEY UPDATE last_sequence = LAST_INSERT_ID(last_sequence + 1), updated_at = NOW()");
    if (!$sequenceStmt) {
        throw new RuntimeException('The production plan number migration must be applied before creating a plan.');
    }
    $sequenceStmt->bind_param('s', $financialYear);
    if (!$sequenceStmt->execute()) {
        $message = $sequenceStmt->error;
        $sequenceStmt->close();
        throw new RuntimeException('Unable to allocate a production plan number: ' . $message);
    }
    $sequenceStmt->close();

    $sequence = (int) $conn->insert_id;
    if ($sequence <= 0) {
        throw new RuntimeException('Unable to read the production plan sequence.');
    }

    return 'PP/FY' . $financialYear . '/' . str_pad((string) $sequence, 6, '0', STR_PAD_LEFT);
}

function mvCreateProductionPlansForOrder(mysqli $conn, int $orderId, int $createdBy, string $remark = '', int $orderItemIdFilter = 0): array
{
    if ($orderId <= 0) {
        throw new RuntimeException('Invalid order ID.');
    }
    if (
        !mvDbColumnExists($conn, 'production_plans', 'product_id')
        || !mvDbColumnExists($conn, 'production_plans', 'order_item_id')
    ) {
        throw new RuntimeException('The production order-item migration must be applied before routing orders to Production.');
    }

    $conn->begin_transaction();
    try {
        $orderStmt = $conn->prepare("SELECT `id`, `order_number`, `dispatch_timeline`, `status`
            FROM `order_received`
            WHERE `id` = ? AND `deleted_at` IS NULL
            FOR UPDATE");
        if (!$orderStmt) {
            throw new RuntimeException('Unable to prepare the linked order: ' . $conn->error);
        }
        $orderStmt->bind_param('i', $orderId);
        $orderStmt->execute();
        $order = $orderStmt->get_result()->fetch_assoc();
        $orderStmt->close();
        if (!$order) {
            throw new RuntimeException('Order not found.');
        }

        $analysis = mvGetOrderStockAnalysis($conn, $orderId);
        if ($analysis['all_sufficient']) {
            throw new RuntimeException('Stock is now sufficient. Check availability again and send the order to Dispatch.');
        }

        $shortItems = [];
        $invalidItems = [];
        foreach ($analysis['items'] as $item) {
            if ($orderItemIdFilter > 0 && (int) ($item['order_item_id'] ?? 0) !== $orderItemIdFilter) {
                continue;
            }
            if (in_array(($item['status'] ?? ''), ['LOW', 'PARTIAL', 'UNAVAILABLE'], true)) {
                $shortItems[] = $item;
            } elseif (!in_array(($item['status'] ?? ''), ['SUFFICIENT', 'COMPLETED'], true)) {
                $invalidItems[] = (string) ($item['product_name'] ?? 'Unknown product');
            }
        }
        if (!empty($invalidItems)) {
            throw new RuntimeException('Production cannot be created until these order items are corrected: ' . implode(', ', $invalidItems) . '.');
        }
        if (empty($shortItems)) {
            throw new RuntimeException('No insufficient-stock items are available for Production.');
        }

        $existingStmt = $conn->prepare("SELECT `id`, `order_item_id`
            FROM `production_plans`
            WHERE `order_id` = ? AND `status` != 3 AND `deleted_at` IS NULL
            FOR UPDATE");
        $existingStmt->bind_param('i', $orderId);
        $existingStmt->execute();
        $existingResult = $existingStmt->get_result();
        $existingOrderItems = [];
        $hasLegacyOrderPlan = false;
        while ($existing = $existingResult->fetch_assoc()) {
            $existingOrderItemId = (int) ($existing['order_item_id'] ?? 0);
            if ($existingOrderItemId > 0) {
                $existingOrderItems[$existingOrderItemId] = true;
            } else {
                $hasLegacyOrderPlan = true;
            }
        }
        $existingStmt->close();
        if ($hasLegacyOrderPlan) {
            throw new RuntimeException('This order already has a production plan.');
        }

        $bomStmt = $conn->prepare("SELECT `id` FROM `bom_master`
            WHERE `finished_product_id` = ? AND `status` = 1 AND `bom_status` = 'APPROVED' AND `deleted_at` IS NULL
            ORDER BY `id` DESC LIMIT 1");
        $insertStmt = $conn->prepare("INSERT INTO `production_plans`
            (`production_plan_no`, `date`, `name`, `lo_batch_no`, `batch_size`, `batch_size_unit`, `timeline`, `status`,
             `prodplan_remark`, `bom_master_id`, `order_id`, `product_id`, `order_item_id`, `created_by`, `created_at`)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$bomStmt || !$insertStmt) {
            throw new RuntimeException('Unable to prepare production plan creation: ' . $conn->error);
        }

        $planDate = date('Y-m-d');
        $planCreatedAt = date('Y-m-d H:i:s');
        $timeline = (int) ($order['dispatch_timeline'] ?? 1);
        $planStatus = 0;
        $orderNumber = trim((string) ($order['order_number'] ?? $orderId));
        $createdPlanIds = [];

        foreach ($shortItems as $item) {
            $orderItemId = (int) ($item['order_item_id'] ?? 0);
            if ($orderItemId <= 0 || isset($existingOrderItems[$orderItemId])) {
                continue;
            }

            $productId = (int) ($item['product_id'] ?? 0);
            $productName = trim((string) ($item['product_name'] ?? ''));
            $batchSizeUnit = mvResolveProductionUnitId($conn, $productId, [
                (int) ($item['product_unit_id'] ?? 0),
                (int) ($item['unit'] ?? 0),
            ]);
            $productUnitFactor = mvGetUnitFactorForOrder($conn, $batchSizeUnit);
            $shortfallBaseQty = (float) ($item['shortfall_base'] ?? $item['required_base'] ?? 0);
            $batchSize = $productUnitFactor > 0 ? $shortfallBaseQty / $productUnitFactor : 0;
            if ($batchSizeUnit <= 0) {
                throw new RuntimeException('No active production unit is configured for ' . ($productName ?: 'this order item') . '. Update its Product Master unit before routing it to Production.');
            }
            if ($productId <= 0 || $productName === '' || $batchSize <= 0) {
                throw new RuntimeException('The production quantity for ' . ($productName ?: 'this order item') . ' could not be calculated from its stock shortfall.');
            }

            $bomStmt->bind_param('i', $productId);
            $bomStmt->execute();
            $bomRow = $bomStmt->get_result()->fetch_assoc();
            $bomMasterId = (int) ($bomRow['id'] ?? 0);
            if ($bomMasterId <= 0) {
                throw new RuntimeException('No active BOM is configured for ' . $productName . '. Production cannot proceed until its BOM is completed.');
            }

            $productionPlanNo = mvNextProductionPlanNumber($conn, $planDate);
            $lotNo = mvNextProductionBatchNumber($conn, $planDate);
            $planRemark = '';

            $insertStmt->bind_param(
                'ssssdiiisiiiiis',
                $productionPlanNo,
                $planDate,
                $productName,
                $lotNo,
                $batchSize,
                $batchSizeUnit,
                $timeline,
                $planStatus,
                $planRemark,
                $bomMasterId,
                $orderId,
                $productId,
                $orderItemId,
                $createdBy,
                $planCreatedAt
            );
            if (!$insertStmt->execute()) {
                throw new RuntimeException('Unable to create the production plan for ' . $productName . ': ' . $insertStmt->error);
            }
            $productionPlanId = (int) $conn->insert_id;
            $createdPlanIds[] = $productionPlanId;

            $historyId = insertProductionHistory($conn, [
                'production_id' => $productionPlanId,
                'action_type' => Constant::PRODUCTION['PRODUCTION_ACTION_TYPE_LABEL']['PlanCreated'],
                'related_table' => 'order_received_items',
                'related_record_id' => $orderItemId,
                'old_flow_status' => null,
                'new_flow_status' => $planStatus,
                'update_type' => 1,
                'changed_fields' => [
                    'order_id' => $orderId,
                    'order_number' => $orderNumber,
                    'production_plan_no' => $productionPlanNo,
                    'lot_batch_no' => $lotNo,
                    'order_item_id' => $orderItemId,
                    'product_id' => $productId,
                    'quantity' => $batchSize,
                    'unit_id' => $batchSizeUnit,
                    'bom_master_id' => $bomMasterId,
                ],
                'remarks' => 'Production plan created from insufficient order stock.',
                'action_by' => $createdBy,
                'action_at' => date('Y-m-d H:i:s'),
                'created_by' => $createdBy,
            ]);
            if (!$historyId) {
                throw new RuntimeException('Unable to record production plan history.');
            }
        }
        $bomStmt->close();
        $insertStmt->close();

        if (empty($createdPlanIds)) {
            throw new RuntimeException('Production plan(s) already exist for the insufficient order items.');
        }

        $inProcessStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Sent_to_Production'];
        $updateStmt = $conn->prepare("UPDATE `order_received`
            SET `status` = ?, `updated_by` = ?, `updated_at` = NOW()
            WHERE `id` = ?");
        $updateStmt->bind_param('iii', $inProcessStatus, $createdBy, $orderId);
        if (!$updateStmt->execute()) {
            throw new RuntimeException('Unable to update the order status.');
        }
        $updateStmt->close();

        $itemActionStmt = $conn->prepare("UPDATE `order_received_items`
            SET `fulfillment_action` = 'production', `fulfillment_status` = 'sent_to_production',
                `updated_by` = ?, `updated_at` = NOW()
            WHERE `order_id` = ? AND `id` IN (" . implode(',', array_map('intval', array_column($shortItems, 'order_item_id'))) . ")");
        if ($itemActionStmt) {
            $itemActionStmt->bind_param('ii', $createdBy, $orderId);
            $itemActionStmt->execute();
            $itemActionStmt->close();
        }
        mvAuditOrderChange($conn, $orderId, 'sent_to_production', $createdBy, $orderItemIdFilter ?: null, null, null, $createdPlanIds, $remark);

        $conn->commit();
        mvSyncOrderStatusToWebsite($conn, $orderId, $inProcessStatus);
        return [
            'status' => 'success',
            'message' => count($createdPlanIds) . ' production plan(s) created for insufficient-stock items.',
            'order_id' => $orderId,
            'order_number' => $orderNumber,
            'production_plan_ids' => $createdPlanIds,
            'bom_review_required' => [],
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function mvFormatOrderStockAlerts(array $analysisItems): array
{
    return array_map(static function (array $item): array {
        $status = (string) ($item['status'] ?? 'NOT_FOUND');
        if ($status === 'SUFFICIENT' || $status === 'COMPLETED') {
            $uiStatus = 'ok';
        } elseif ($status === 'LOW' || $status === 'PARTIAL') {
            $uiStatus = (float) ($item['available_stock'] ?? 0) > 0 ? 'low_stock' : 'out_of_stock';
        } elseif ($status === 'UNAVAILABLE') {
            $uiStatus = 'out_of_stock';
        } else {
            $uiStatus = 'not_found';
        }

        return [
            'order_item_id' => (int) ($item['order_item_id'] ?? 0),
            'product_name' => (string) ($item['product_name'] ?? ''),
            'ordered_qty' => (float) ($item['quantity'] ?? 0),
            'available_qty' => (float) ($item['available_stock'] ?? 0),
            'required_base' => (float) ($item['required_base'] ?? 0),
            'reserved_base' => (float) ($item['reserved_base'] ?? 0),
            'shortfall_base' => (float) ($item['shortfall_base'] ?? 0),
            'minimum_required_base' => (float) ($item['minimum_required_base'] ?? 0),
            'product_id' => (int) ($item['product_id'] ?? 0),
            'category_id' => (int) ($item['category_id'] ?? 0),
            'unit_id' => (int) ($item['unit'] ?? 0),
            'status' => $uiStatus,
        ];
    }, $analysisItems);
}

function mvCreateLowStockRequestsForOrder(mysqli $conn, int $orderId, array $analysisItems, int $createdBy): int
{
    $inserted = 0;
    // The low_stocks.order_id column is part of the required schema. Avoid the
    // information_schema lookup here because it can return a false negative on XAMPP.
    $hasOrderId = true;
    $reportingPerson = 'Auto - Order Stock Alert';
    $dateOfReport = date('Y-m-d');
    $procurementSource = 'order_auto';
    $status = 0;

    foreach ($analysisItems as $item) {
        if (($item['status'] ?? '') === 'SUFFICIENT' || (int) ($item['product_id'] ?? 0) <= 0) {
            continue;
        }

        $productId = (int) $item['product_id'];
        $categoryId = (int) ($item['category_id'] ?? 0);
        $reqUnit = (int) ($item['unit'] ?? 0);
        $unitFactor = mvGetUnitFactorForOrder($conn, $reqUnit);
        $requiredBaseQty = (float) ($item['required_base'] ?? 0);
        $availableBaseQty = max(0, (float) ($item['available_stock'] ?? 0));
        $reqQty = max(0, $requiredBaseQty - $availableBaseQty) / $unitFactor;
        if ($reqQty <= 0) {
            continue;
        }

        if ($hasOrderId) {
            $checkStmt = $conn->prepare("SELECT `id` FROM `low_stocks` WHERE `product_id` = ? AND `order_id` = ? AND `procurement_source` = ? AND `status` IN (0, 1, 4) AND `deleted_at` IS NULL LIMIT 1");
            $checkStmt->bind_param('iis', $productId, $orderId, $procurementSource);
        } else {
            $checkStmt = $conn->prepare("SELECT `id` FROM `low_stocks` WHERE `product_id` = ? AND `procurement_source` = ? AND `status` IN (0, 1, 4) AND `deleted_at` IS NULL LIMIT 1");
            $checkStmt->bind_param('is', $productId, $procurementSource);
        }
        $checkStmt->execute();
        $checkStmt->store_result();
        $exists = $checkStmt->num_rows > 0;
        $checkStmt->close();

        if ($exists) {
            continue;
        }

        if ($hasOrderId) {
            $insertStmt = $conn->prepare("INSERT INTO `low_stocks` (`reporting_person`, `date_report`, `category_id`, `product_id`, `required_qty`, `required_qty_unit`, `procurement_source`, `order_id`, `status`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insertStmt->bind_param('ssiidisiii', $reportingPerson, $dateOfReport, $categoryId, $productId, $reqQty, $reqUnit, $procurementSource, $orderId, $status, $createdBy);
        } else {
            $insertStmt = $conn->prepare("INSERT INTO `low_stocks` (`reporting_person`, `date_report`, `category_id`, `product_id`, `required_qty`, `required_qty_unit`, `procurement_source`, `status`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insertStmt->bind_param('ssiidisii', $reportingPerson, $dateOfReport, $categoryId, $productId, $reqQty, $reqUnit, $procurementSource, $status, $createdBy);
        }
        if ($insertStmt->execute()) {
            $inserted++;
        }
        $insertStmt->close();
    }

    return $inserted;
}

function mvResolveOrderIdForLowStockRequests(mysqli $conn, array $lowStockIds): ?int
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $lowStockIds), static function (int $id): bool {
        return $id > 0;
    })));
    if (empty($ids)) {
        return null;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $stmt = $conn->prepare("SELECT `id`, `order_id`, `status` FROM `low_stocks` WHERE `id` IN ($placeholders) AND `deleted_at` IS NULL FOR UPDATE");
    if (!$stmt) {
        throw new RuntimeException('Unable to validate the selected procurement request.');
    }
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $result = $stmt->get_result();

    $foundIds = [];
    $orderIds = [];
    while ($row = $result->fetch_assoc()) {
        $foundIds[] = (int) $row['id'];
        if ((int) $row['status'] !== Constant::LOW_STOCK['STATUS_LABEL']['Pending']) {
            $stmt->close();
            throw new RuntimeException('One of the selected procurement requests has already been processed.');
        }
        if ((int) ($row['order_id'] ?? 0) > 0) {
            $orderIds[] = (int) $row['order_id'];
        }
    }
    $stmt->close();

    if (count($foundIds) !== count($ids)) {
        throw new RuntimeException('One of the selected procurement requests could not be found.');
    }

    $orderIds = array_values(array_unique($orderIds));
    if (count($orderIds) > 1) {
        return null;
    }

    return $orderIds[0] ?? null;
}

function mvDispatchOrderToStockOutward(mysqli $conn, int $orderId, string $remark, int $createdBy): array
{
    if ($orderId <= 0) {
        return ['status' => 'error', 'message' => 'Invalid order ID.'];
    }

    $orderQ = $conn->prepare("SELECT * FROM `order_received` WHERE `id` = ? AND `deleted_at` IS NULL LIMIT 1");
    $orderQ->bind_param('i', $orderId);
    $orderQ->execute();
    $order = $orderQ->get_result()->fetch_assoc();
    $orderQ->close();
    if (!$order) {
        return ['status' => 'error', 'message' => 'Order not found.'];
    }

    $terminalStatuses = [
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Complete'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled_by_Client'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Dispatched'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Forcefully_Complete'],
    ];
    if (in_array((int) $order['status'], $terminalStatuses, true)) {
        return ['status' => 'error', 'message' => 'This order is already in a terminal fulfillment state.'];
    }

    $conn->begin_transaction();
    try {
        $statusPending = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Ready_for_Dispatch'];
        // Serialize the queue handoff against the final Goods Dispatch submit.
        $lockQ = $conn->prepare('SELECT `source_type`, `status` FROM `order_received` WHERE `id` = ? AND `deleted_at` IS NULL FOR UPDATE');
        $lockQ->bind_param('i', $orderId);
        $lockQ->execute();
        $lockedOrder = $lockQ->get_result()->fetch_assoc();
        $lockQ->close();
        if (!$lockedOrder || in_array((int) $lockedOrder['status'], $terminalStatuses, true)) {
            throw new RuntimeException('This order is already in a terminal fulfillment state.');
        }
        $pendingReview = (int) (Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Pending_Review'] ?? 12);
        if (mvOrderRequiresApproval((int) $lockedOrder['source_type'])
            && (int) $lockedOrder['status'] === $pendingReview) {
            throw new RuntimeException('This external order must be approved before dispatch.');
        }

        $analysis = mvGetOrderStockAnalysis($conn, $orderId, true);
        if (!$analysis['all_sufficient']) {
            throw new RuntimeException('Stock is not sufficient for dispatch.');
        }
        $updateQ = $conn->prepare("UPDATE `order_received` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ?");
        $updateQ->bind_param('iii', $statusPending, $createdBy, $orderId);
        $updateQ->execute();
        $updateQ->close();

        $itemQ = $conn->prepare("UPDATE `order_received_items`
            SET `fulfillment_action` = 'dispatch', `fulfillment_status` = 'ready_for_dispatch',
                `updated_by` = ?, `updated_at` = NOW()
            WHERE `order_id` = ? AND `deleted_at` IS NULL
              AND `status` NOT IN (3, 5, 6, 7, 8, 10, 11)
              AND `shortfall_quantity_base` <= 0.00000001");
        $itemQ->bind_param('ii', $createdBy, $orderId);
        $itemQ->execute();
        $queuedItemCount = $itemQ->affected_rows;
        $itemQ->close();
        if ($queuedItemCount < 1) {
            throw new RuntimeException('This order has no reserved items waiting for Goods Dispatch.');
        }
        mvAuditOrderChange($conn, $orderId, 'ready_for_dispatch', $createdBy, null, null, null, null, $remark);

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        return ['status' => 'error', 'message' => $e->getMessage()];
    }

    try {
        mvSyncOrderStatusToWebsite($conn, $orderId, $statusPending);
    } catch (Throwable $syncError) {
        error_log('Website order status sync failed after Goods Dispatch queue handoff: ' . $syncError->getMessage());
    }

    return ['status' => 'success', 'message' => 'Order successfully sent to Goods Dispatch.', 'outward_id' => null];
}

function mvAutoRouteOrderAfterStockCheck(mysqli $conn, int $orderId, int $createdBy, string $remark = ''): array
{
    $orderStmt = $conn->prepare("SELECT `status` FROM `order_received` WHERE `id` = ? AND `deleted_at` IS NULL LIMIT 1");
    $orderStmt->bind_param('i', $orderId);
    $orderStmt->execute();
    $orderRow = $orderStmt->get_result()->fetch_assoc();
    $orderStmt->close();
    if (!$orderRow) {
        return ['status' => 'error', 'message' => 'Order not found.', 'action' => 'none'];
    }

    $terminalStatuses = [
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Complete'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled_by_Client'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Dispatched'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Forcefully_Complete'],
    ];
    if (in_array((int) $orderRow['status'], $terminalStatuses, true)) {
        return [
            'status' => 'success',
            'message' => 'Order is already in a terminal fulfillment state.',
            'action' => 'none',
            'terminal' => true,
        ];
    }

    // The review workflow reserves all currently saleable stock immediately.
    // Shortages remain a user choice (Production or Procurement) instead of
    // silently creating a procurement request for every product.
    return mvRecalculateOrderFulfillment($conn, $orderId, $createdBy, $remark ?: 'Automatic stock recalculation.');

    $analysis = mvGetOrderStockAnalysis($conn, $orderId);
    $productionState = mvGetOrderProductionPlanState($conn, $orderId);
    if ($productionState['total'] > 0 && $productionState['incomplete'] > 0) {
        $inProcessStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Inprocess'];
        $stmt = $conn->prepare("UPDATE `order_received` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ?");
        $stmt->bind_param('iii', $inProcessStatus, $createdBy, $orderId);
        $stmt->execute();
        $stmt->close();
        mvSyncOrderStatusToWebsite($conn, $orderId, $inProcessStatus);

        return [
            'status' => 'success',
            'message' => 'The linked Production workflow is still in progress.',
            'action' => 'production',
            'analysis' => $analysis,
            'production' => $productionState,
        ];
    }
    if ($analysis['all_sufficient']) {
        $result = mvDispatchOrderToStockOutward($conn, $orderId, $remark ?: 'Auto-routed after stock verification.', $createdBy);
        $result['action'] = 'dispatch';
        $result['analysis'] = $analysis;
        return $result;
    }

    if ($productionState['total'] > 0) {
        $statusNotInStock = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Not_In_Stock'];
        $stmt = $conn->prepare("UPDATE `order_received` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ?");
        $stmt->bind_param('iii', $statusNotInStock, $createdBy, $orderId);
        $stmt->execute();
        $stmt->close();
        mvSyncOrderStatusToWebsite($conn, $orderId, $statusNotInStock);

        return [
            'status' => 'success',
            'message' => 'Production is complete, but the linked order is waiting for sufficient finished-goods stock.',
            'action' => 'production',
            'analysis' => $analysis,
            'production' => $productionState,
        ];
    }

    $inserted = mvCreateLowStockRequestsForOrder($conn, $orderId, $analysis['items'], $createdBy);
    $procurementSource = 'order_auto';
    $requestStmt = $conn->prepare("SELECT COUNT(*) AS `total` FROM `low_stocks` WHERE `order_id` = ? AND `procurement_source` = ? AND `status` IN (0, 1, 4) AND `deleted_at` IS NULL");
    $requestStmt->bind_param('is', $orderId, $procurementSource);
    $requestStmt->execute();
    $requestCount = (int) ($requestStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $requestStmt->close();
    if ($requestCount <= 0) {
        return [
            'status' => 'error',
            'message' => 'No procurement request could be created. Resolve the product mapping and try again.',
            'action' => 'none',
            'inserted' => $inserted,
            'analysis' => $analysis,
        ];
    }
    $statusNotInStock = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Not_In_Stock'];
    $stmt = $conn->prepare("UPDATE `order_received` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ?");
    $stmt->bind_param('iii', $statusNotInStock, $createdBy, $orderId);
    $stmt->execute();
    $stmt->close();
    mvSyncOrderStatusToWebsite($conn, $orderId, $statusNotInStock);

    return [
        'status' => 'success',
        'message' => 'Stock shortfall found. Procurement request(s) updated in Purchase Management.',
        'action' => 'procurement',
        'inserted' => $inserted,
        'request_count' => $requestCount,
        'analysis' => $analysis
    ];
}

/**
 * Non-blocking bridge used by the shared order-routing paths. The isolated
 * handler ignores non-website orders and disabled sync modules.
 */
function mvSyncOrderStatusToWebsite(mysqli $conn, int $orderId, int $status): void
{
    try {
        require_once __DIR__ . '/sync/OrderSyncHandler.php';
        (new OrderSyncHandler($conn))->pushOrderStatusToWebsite($orderId, $status);
    } catch (Throwable $syncError) {
        error_log('Order sync to website failed (non-blocking): ' . $syncError->getMessage());
    }
}

function mvAutoRoutePendingOrdersAfterStockChange(mysqli $conn, int $createdBy): array
{
    $statusNotInStock = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Not_In_Stock'];
    $recalculationStatuses = [
        $statusNotInStock,
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Partially_Available'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Stock_Unavailable'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Sent_to_Production'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Sent_to_Procurement'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Production_in_Progress'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Procurement_in_Progress'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Partial_Delivered'],
    ];
    $statusList = implode(',', array_map('intval', $recalculationStatuses));
    $stmt = $conn->prepare("SELECT `id` FROM `order_received` WHERE `status` IN ($statusList) AND `deleted_at` IS NULL ORDER BY `created_at` ASC LIMIT 25");
    $stmt->execute();
    $orders = $stmt->get_result();
    $routed = [];
    while ($row = $orders->fetch_assoc()) {
        $result = mvAutoRouteOrderAfterStockCheck($conn, (int) $row['id'], $createdBy, 'Auto-routed after stock became available.');
        if (($result['status'] ?? '') === 'success' && ($result['action'] ?? '') === 'dispatch') {
            $routed[] = (int) $row['id'];
        }
    }
    $stmt->close();
    return $routed;
}

function mvRefreshOrderAfterProductionCompletion(mysqli $conn, int $orderId, int $updatedBy): array
{
    if ($orderId <= 0) {
        return ['status' => 'success', 'message' => 'Production completed without a linked order.'];
    }

    return mvRecalculateOrderFulfillment($conn, $orderId, $updatedBy, 'Recalculated after production completion.');

    $analysis = mvGetOrderStockAnalysis($conn, $orderId);
    $productionState = mvGetOrderProductionPlanState($conn, $orderId);
    if ($productionState['incomplete'] > 0) {
        $nextStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Inprocess'];
    } else {
        $nextStatus = $analysis['all_sufficient']
            ? Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Pending']
            : Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Not_In_Stock'];
    }
    $terminalStatuses = [
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Complete'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled_by_Client'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Dispatched'],
        Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Forcefully_Complete']
    ];
    $placeholders = implode(',', array_fill(0, count($terminalStatuses), '?'));
    $types = 'iii' . str_repeat('i', count($terminalStatuses));
    $params = array_merge([$nextStatus, $updatedBy, $orderId], $terminalStatuses);
    $stmt = $conn->prepare("UPDATE `order_received` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ? AND `deleted_at` IS NULL AND `status` NOT IN ($placeholders)");
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the linked order status update.');
    }
    $stmt->bind_param($types, ...$params);
    if (!$stmt->execute()) {
        $message = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to update the linked order: ' . $message);
    }
    $stmt->close();

    return [
        'status' => 'success',
        'message' => $productionState['incomplete'] > 0
            ? 'Linked order remains in Production until all plans are complete.'
            : ($analysis['all_sufficient']
                ? 'Linked order is ready for stock verification.'
                : 'Linked order remains marked Not In Stock.'),
        'order_status' => $nextStatus,
        'analysis' => $analysis,
        'production' => $productionState,
    ];
}

function mvNormalizeExternalOrderPayload(array $input): array
{
    $rawContent = trim((string) ($input['raw_content'] ?? $input['rawContent'] ?? ''));
    $items = $input['items'] ?? [];
    if ((!is_array($items) || empty($items)) && trim((string) ($input['product_name'] ?? '')) !== '') {
        $items = [
            [
                'product_name' => trim((string) $input['product_name']),
                'quantity' => (float) ($input['quantity'] ?? 1),
                'unit' => (int) ($input['unit'] ?? 1),
                'order_remark' => ''
            ]
        ];
    }

    if ((!is_array($items) || empty($items)) && $rawContent !== '') {
        $qty = 1;
        if (preg_match('/\b(\d+(?:\.\d+)?)\b/', $rawContent, $qtyMatch)) {
            $qty = (float) $qtyMatch[1];
        }

        $productName = '';
        if (preg_match('/(?:units?|pcs|pieces|boxes|kits?)\s+(?:of\s+)?([A-Za-z0-9][A-Za-z0-9 \-\/&().]+)/i', $rawContent, $productMatch)) {
            $productName = trim($productMatch[1]);
        } elseif (preg_match('/(?:order|need|require|want)\s+(?:of\s+)?(.+?)(?:\s+for|,|\.|$)/i', $rawContent, $productMatch)) {
            $productName = trim($productMatch[1]);
        }

        if ($productName !== '') {
            $items = [
                [
                    'product_name' => $productName,
                    'quantity' => $qty,
                    'unit' => (int) ($input['unit'] ?? 1),
                    'order_remark' => 'Parsed from raw message'
                ]
            ];
        }
    }

    $input['items'] = is_array($items) ? $items : [];
    $input['raw_content'] = $rawContent;
    return $input;
}

function renderBMRExecutionForm($execution_id, $conn)
{

    // STEP 1: GET TEMPLATE ID

    $q = $conn->query("SELECT template_id
    FROM bmr_executions
    WHERE id='$execution_id'
    ");

    $template_id = $q->fetch_assoc()['template_id'];


    // STEP 2: LOAD SECTIONS PAGE WISE

    $sections = $conn->query("SELECT *
    FROM bmr_template_sections
    WHERE template_id='$template_id'
    AND status=1
    ORDER BY page_no,display_order
    ");

    $formHTML = '';

    $currentPage = '';

    while ($sec = $sections->fetch_assoc()) {

        // NEW PAGE DIV

        if ($currentPage != $sec['page_no']) {

            $formHTML .= "<hr>
    <h4>Page " . $sec['page_no'] . "</h4>";

            $currentPage = $sec['page_no'];
        }


        // NORMAL BLOCK
        if ($sec['section_type'] == 1) {

            $formHTML .= "<h5>" . $sec['section_title'] . "</h5>";

            $fields = $conn->query("SELECT *
    FROM bmr_template_fields
    WHERE section_id='" . $sec['id'] . "'
    AND status=1
    ORDER BY display_order
    ");

            while ($f = $fields->fetch_assoc()) {

                $value = '';

                // LOAD EXECUTION VALUE IF EXISTS

                $v = $conn->query("SELECT field_value
    FROM bmr_execution_field_values
    WHERE execution_id='$execution_id'
    AND field_id='" . $f['id'] . "'
    ");

                if ($v->num_rows > 0) {
                    $value = $v->fetch_assoc()['field_value'];
                }

                $formHTML .= '
    <div class="mb-2">
    <label>' . $f['field_label'] . '</label>
    <input type="text"
    name="field_' . $f['id'] . '"
    value="' . $value . '"
    class="form-control">
    </div>';

            }

        }


        // TABLE BLOCK
        if ($sec['section_type'] == 2) {

            $formHTML .= "<h5>" . $sec['section_title'] . "</h5>";

            $cols = $conn->query("SELECT *
    FROM bmr_template_table_columns
    WHERE section_id='" . $sec['id'] . "'
    AND status=1
    ORDER BY display_order
    ");

            $formHTML .= '<table class="table table-bordered">
    <thead><tr>';

            $colArr = [];

            while ($c = $cols->fetch_assoc()) {

                $formHTML .= "<th>" . $c['column_label'] . "</th>";
                $colArr[] = $c['id'];

            }

            $formHTML .= "</tr></thead><tbody>";


            // LOAD EXISTING ROWS

            $rows = $conn->query("SELECT *
    FROM bmr_execution_table_rows
    WHERE execution_id='$execution_id'
    AND section_id='" . $sec['id'] . "'
    AND status=1
    ORDER BY row_index
    ");

            while ($r = $rows->fetch_assoc()) {

                $formHTML .= "<tr>";

                foreach ($colArr as $cid) {

                    $val = '';

                    $v = $conn->query("SELECT cell_value
    FROM bmr_execution_table_cells
    WHERE row_id='" . $r['id'] . "'
    AND column_id='$cid'
    ");

                    if ($v->num_rows > 0) {
                        $val = $v->fetch_assoc()['cell_value'];
                    }

                    $formHTML .= '
    <td>
    <input type="text"
    name="cell_' . $r['id'] . '_' . $cid . '"
    value="' . $val . '"
    class="form-control">
    </td>';

                }

                $formHTML .= "</tr>";
            }

            $formHTML .= "</tbody></table>";

        }

    }

    return $formHTML;

}


function previewBMRTemplate($template_id, $conn)
{

    $sections = $conn->query("SELECT *
        FROM bmr_template_sections
        WHERE template_id='$template_id'
        AND status=1
        ORDER BY page_no,display_order
        ");

    $html = '';
    $currentPage = 0;

    while ($sec = $sections->fetch_assoc()) {

        // NEW PAGE START
        if ($currentPage != $sec['page_no']) {

            // close previous page
            if ($currentPage != 0) {
                $html .= "Page No.: " . $currentPage . "</div>";
            }

            $currentPage = $sec['page_no'];

            $html .= "
                    <div class='bmr-page' style='border:2px solid #000;padding:15px;margin-bottom:20px;background:#fff;'>

                    <h4 style='text-align:center'>Page " . $currentPage . "</h4>
                    ";
        }


        // ================= NORMAL BLOCK =================

        if ($sec['section_type'] == 1) {

            $html .= "<h5>" . $sec['section_title'] . "</h5>";

            $fields = $conn->query("SELECT *
                FROM bmr_template_fields
                WHERE section_id='" . $sec['id'] . "'
                AND status=1
                ORDER BY display_order
                ");

            $html .= "<div class='row'>";

            while ($f = $fields->fetch_assoc()) {

                $html .= "
                    <div class='col-md-3 mb-2'>
                    <label>" . $f['field_label'] . "</label>
                    <input type='text' class='form-control' placeholder='" . $f['field_label'] . "'>
                    </div>
                    ";
            }

            $html .= "</div>";
        }



        // ================= TABLE BLOCK =================

        if ($sec['section_type'] == 2) {

            $html .= "<h5>" . $sec['section_title'] . "</h5>";

            $cols = $conn->query("SELECT *
                FROM bmr_template_table_columns
                WHERE section_id='" . $sec['id'] . "'
                AND status=1
                ORDER BY display_order
                ");

            $html .= "
                <table class='table table-bordered'>
                <thead>
                <tr>
                ";

            $columns = [];

            while ($c = $cols->fetch_assoc()) {

                $columns[] = $c;
                $html .= "<th>" . $c['column_label'] . "</th>";
            }

            $html .= "</tr></thead><tbody><tr>";

            foreach ($columns as $c) {

                $html .= "<td>-</td>";
            }

            $html .= "</tr></tbody></table>";
        }



        // ================= STATIC TEXT =================

        if ($sec['section_type'] == 3) {

            $html .= "
            <div style='margin-bottom:15px'>
            " . $sec['section_title'] . "
            </div>";
        }
    }

    // close last page
    // $html .= "<h4 style='text-align:center'>Page " . $currentPage . "</h4>";
    $html .= "</div>";

    return $html;
}

function previewBMRTemplateDesign($template_id, $conn)
{

    $html = "";
    $template = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM bmr_templates WHERE id='$template_id'"));

    $htmlHeader = "";

    if ($template['header_id']) {

        $header = mysqli_fetch_assoc(mysqli_query($conn, "SELECT header_html 
            FROM bmr_headers 
            WHERE id='" . $template['header_id'] . "' 
            AND status=1
        "));

        $htmlHeader = $header['header_html'];
    }

    $htmlFooter = "";

    if ($template['footer_id']) {

        $footer = mysqli_fetch_assoc(mysqli_query($conn, "SELECT footer_html 
            FROM bmr_footers
            WHERE id='" . $template['footer_id'] . "' 
            AND status=1
        "));

        $htmlFooter = $footer['footer_html'];
    }

    $totalPagesResult = mysqli_query($conn, "SELECT COUNT(DISTINCT page_no) as total 
        FROM bmr_template_sections WHERE template_id ='$template_id' AND status = 1");
    $totalPagesRow = mysqli_fetch_assoc($totalPagesResult);
    $totalPages = $totalPagesRow['total'];

    $pages = mysqli_query($conn, "SELECT DISTINCT page_no FROM bmr_template_sections WHERE template_id='$template_id' AND status=1 ORDER BY page_no");
    $currentPage = 1;
    while ($page = mysqli_fetch_assoc($pages)) {

        $page_no = $page['page_no'];

        $html .= "<div class='bmr-page'>";


        $html .= $htmlHeader;


        $sections = mysqli_query($conn, "SELECT * FROM bmr_template_sections WHERE template_id='$template_id' 
            AND status=1 AND (page_no='$page_no' OR repeatable=1) ORDER BY repeatable DESC, display_order
        ");
        while ($section = mysqli_fetch_assoc($sections)) {

            $sectionPadding = ($section['display_order'] == 1) ? "" : "margin-top:10px";
            $html .= "<div class='bmr-section' style=" . $sectionPadding . ">";

            if ($section['section_title']) {
                $html .= "<h6 style='font-weight:bold;'>" . $section['section_title'] . "</h6>";
            }

            /* STATIC TEXT */

            if ($section['section_type'] == 3) {
                // $html .= $section['static_text'];
                $html .= nl2br($section['static_text']);
            }

            /* NORMAL FIELDS */

            if ($section['section_type'] == 1) {

                $fields = mysqli_query($conn, "SELECT *
                        FROM bmr_template_fields
                        WHERE section_id='" . $section['id'] . "'
                        AND status=1
                        ORDER BY display_order
                    ");

                $html .= "<div class='row'>";

                while ($field = mysqli_fetch_assoc($fields)) {

                    $html .= "<div class='col-md-" . $field['field_width'] . "'>";

                    $html .= "<label>" . $field['field_label'] . "</label>";

                    $key = $field['field_key'];

                    if ($field['field_type'] == 1)
                        $html .= "<input type='text' name='$key' class='form-control'>";
                    elseif ($field['field_type'] == 2)
                        $html .= "<input type='number' name='$key' class='form-control'>";
                    elseif ($field['field_type'] == 3)
                        $html .= "<input type='date' name='$key' class='form-control'>";
                    elseif ($field['field_type'] == 4)
                        $html .= "<input type='time' name='$key' class='form-control'>";
                    elseif ($field['field_type'] == 5)
                        $html .= "<textarea name='$key' class='form-control'></textarea>";
                    elseif ($field['field_type'] == 6)
                        $html .= "<input type='checkbox' name='$key'>";

                    $html .= "</div>";
                }

                $html .= "</div>";
            }

            /* TABLE */

            if ($section['section_type'] == 2) {

                $html .= "<table style='width:100%; border-collapse:collapse; border-left:2px solid #000; border-right:2px solid #000; border-bottom:2px solid #000;'>";

                $rows = mysqli_query($conn, "SELECT * FROM bmr_template_table_rows
                        WHERE section_id='" . $section['id'] . "' AND status=1 ORDER BY row_index
                    ");

                while ($row = mysqli_fetch_assoc($rows)) {

                    $rowBorder = ($row['row_index'] == 1) ? "" : "border-top:1px solid #000; border-bottom:1px solid #000;";

                    $html .= "<tr style='line-height:18px; $rowBorder'>";

                    $cells = mysqli_query($conn, "SELECT * FROM bmr_template_table_cells
                            WHERE row_id='" . $row['id'] . "' AND status=1 ORDER BY column_index
                        ");

                    while ($cell = mysqli_fetch_assoc($cells)) {

                        $colspan = $cell['colspan'] ?: 1;
                        $rowspan = $cell['rowspan'] ?: 1;

                        $cellStyle = "padding-left:5px; border-right:1px solid #000;";

                        if ($cell['column_index'] == 1) {
                            $cellStyle .= " border-left:1px solid #000;";
                        }
                        // $html .= "<td colspan='$colspan' rowspan='$rowspan'>";
                        $html .= "<td colspan='$colspan' rowspan='$rowspan' style='$cellStyle'>";

                        if ($cell['cell_type'] == 1)
                            $html .= "<b>" . $cell['cell_label'] . "</b>";
                        elseif ($cell['cell_type'] == 2) {
                            $key = $cell['field_key'];
                            // $html .= "<input type='text' name='$key' class='form-control'>";
                            $html .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        } elseif ($cell['cell_type'] == 3)
                            $html .= $cell['static_value'];

                        $html .= "</td>";
                    }

                    $html .= "</tr>";
                }

                $html .= "</table>";
            }

            $html .= "</div>";

        }

        /* FOOTER */

        // $html .= $htmlFooter;
        /* FOOTER */
        $dynamicFooter = str_replace(['{page_no}', '{total_pages}'], [$currentPage, $totalPages], $htmlFooter);

        $html .= $dynamicFooter;

        $html .= "</div>";
        $currentPage++;
    }

    return $html;
}

function getPaginationFooter($wrapperId = 'paginationWrapper', $summaryId = 'paginationSummary', $selectId = 'footerPerPageSelect')
{
    $spanId = ($selectId === 'footerPerPageSelect') ? 'perPageText' : 'perPageText-' . $selectId;
    return '
    <div class="flex max-md:flex-col md:flex-row flex-wrap md:flex-nowrap items-center justify-between max-md:gap-4 border-t border-slate-200 bg-white px-6 py-4">
        <p class="m-0 shrink-0 text-sm font-medium text-slate-700 max-md:text-center" id="' . htmlspecialchars($summaryId) . '">Showing 0 results of 0</p>
        <div class="flex flex-wrap md:flex-nowrap max-md:justify-center items-center gap-3 w-full md:w-auto">
            <select id="' . htmlspecialchars($selectId) . '" style="display: none !important;">
                <option value="100000000">All Items Per Page</option>
                <option value="5">5 Items Per Page</option>
                <option value="10" selected>10 Items Per Page</option>
                <option value="25">25 Items Per Page</option>
                <option value="50">50 Items Per Page</option>
                <option value="100">100 Items Per Page</option>
                <option value="1000">1000 Items Per Page</option>
                <option value="3000">3000 Items Per Page</option>
            </select>
            <div class="dropdown shrink-0">
                <button class="flex h-9 min-w-[170px] w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-all hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                    <span id="' . htmlspecialchars($spanId) . '" class="perPageText whitespace-nowrap">10 Items Per Page</span>
                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end !rounded-xl border border-slate-200 p-1 shadow-xl">
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="100000000">All Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="5">5 Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="10">10 Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="25">25 Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="50">50 Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="100">100 Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="1000">1000 Items Per Page</a></li>
                    <li><a class="per-page-item block cursor-pointer rounded-xl px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50" data-select-id="' . htmlspecialchars($selectId) . '" data-val="3000">3000 Items Per Page</a></li>
                </ul>
            </div>
            <nav aria-label="Page navigation" class="shrink-0 max-md:flex max-md:justify-center max-md:w-full">
                <ul class="pagination flex-wrap md:flex-nowrap max-md:justify-center m-0 max-md:gap-1" id="' . htmlspecialchars($wrapperId) . '"></ul>
            </nav>
        </div>
    </div>';
}

/**
 * Create a URL-friendly slug.
 */
function createSlug($text)
{
    $text = trim($text);
    // Convert to lowercase
    $text = strtolower($text);
    // Replace all non-alphanumeric characters replaced with -
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    // Remove duplicate hyphens
    $text = preg_replace('/-+/', '-', $text);
    // Remove leading/trailing hyphens
    $text = trim($text, '-');
    // Fallback
    if ($text == '') {
        $text = 'item';
    }
    return $text;
}

/**
 * Generate a unique slug for any table.
 *
 * @param mysqli $conn
 * @param string $table
 * @param string $text
 * @param string $slugColumn
 * @param string $idColumn
 * @return string
 */
function generateUniqueSlug($conn, $table, $text, $slugColumn = 'slug', $idColumn = 'id')
{
    $baseSlug = createSlug($text);

    if ($baseSlug === '') {
        $baseSlug = 'item';
    }

    $slug = $baseSlug;
    $counter = 1;

    while (true) {

        $sql = "SELECT `$idColumn` FROM `$table` WHERE `$slugColumn` = ? LIMIT 1";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception($conn->error);
        }
        $stmt->bind_param("s", $slug);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows == 0) {
            $stmt->close();
            break;
        }
        $stmt->close();
        $slug = $baseSlug . '-' . $counter;
        $counter++;
    }
    return $slug;
}

function generateAndSavePoPdf($poNumber, $type)
{
    global $conn;
    // Save current working directory
    $oldCwd = getcwd();

    // Change to pages directory so the relative requires inside the template work
    chdir(__DIR__ . '/pages');

    // Prepare target path
    $targetDir = __DIR__ . '/uploads/purchase_orders/';
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $targetFile = $targetDir . preg_replace('/[^A-Za-z0-9\-]/', '_', $poNumber) . '.pdf';

    // Mock GET variables that the template expects
    $oldGet = $_GET;
    $_GET['id'] = base64_encode($poNumber);

    ob_start();
    if ($type === 'PM') {
        require 'purchase_order_template.php';
    } else {
        require 'purchase_order_raw_template.php';
    }
    $html = ob_get_clean();

    // Restore GET parameters and working directory
    $_GET = $oldGet;
    chdir($oldCwd);

    // Remove JavaScript block that triggers download on load
    $html = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $html);

    // Initialize Dompdf
    require_once __DIR__ . '/../vendor/autoload.php';
    $options = new \Dompdf\Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);

    $dompdf = new \Dompdf\Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    file_put_contents($targetFile, $dompdf->output());

    return 'uploads/purchase_orders/' . preg_replace('/[^A-Za-z0-9\-]/', '_', $poNumber) . '.pdf';
}

function sendPoEmailToSupplier($vendorEmail, $vendorName, $poNumber, $pdfPath, $customBody = '')
{
    if (empty($vendorEmail)) {
        return false;
    }

    $subject = "Purchase Order " . $poNumber . " - Biogenix Inc Pvt Ltd";
    $from = "no-reply@biogenix.in";
    $fromName = "Biogenix Purchase Department";

    $file = __DIR__ . '/' . $pdfPath;
    if (!file_exists($file)) {
        return false;
    }

    $file_size = filesize($file);
    $handle = fopen($file, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $content = chunk_split(base64_encode($content));

    $uid = md5(uniqid(time()));

    // Header
    $header = "From: " . $fromName . " <" . $from . ">\r\n";
    $header .= "Reply-To: " . $from . "\r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"\r\n\r\n";

    // Message body
    $message = "--" . $uid . "\r\n";
    $message .= "Content-type:text/html; charset=utf-8\r\n";
    $message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";

    $customBody = trim((string) $customBody);
    if ($customBody === '') {
        $customBody = 'Please find attached Purchase Order {PO_NUMBER} from Biogenix Inc Pvt. Ltd.' . "\n\n"
            . 'Kindly acknowledge receipt and confirm the delivery timeline.';
    }
    $customBody = strtr($customBody, [
        '{PO_NUMBER}' => $poNumber,
        '{VENDOR_NAME}' => $vendorName,
    ]);
    $customBodyHtml = nl2br(htmlspecialchars($customBody, ENT_QUOTES, 'UTF-8'));

    $emailHtml = '
    <html>
    <body>
        <p>Dear ' . htmlspecialchars($vendorName) . ',</p>
        <div>' . $customBodyHtml . '</div>
        <br>
        <p>Best Regards,<br>
        <strong>Purchase Department</strong><br>
        <strong>Biogenix Inc Pvt. Ltd.</strong></p>
    </body>
    </html>';

    $message .= $emailHtml . "\r\n\r\n";
    $message .= "--" . $uid . "\r\n";
    $message .= "Content-Type: application/pdf; name=\"" . basename($file) . "\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n";
    $message .= "Content-Disposition: attachment; filename=\"" . basename($file) . "\"\r\n\r\n";
    $message .= $content . "\r\n\r\n";
    $message .= "--" . $uid . "--";

    return mail($vendorEmail, $subject, $message, $header);
}
function autoProcessOrderRouting($conn, $orderId, $createdBy, $stockAlerts)
{
    return mvAutoRouteOrderAfterStockCheck($conn, (int) $orderId, (int) $createdBy);

    /* Legacy routing body retained for reference. The shared service above is authoritative.
    $allSufficient = true;
    foreach ($stockAlerts as $alert) {
        if ($alert['status'] !== 'ok') {
            $allSufficient = false;
            break;
        }
    }

    $orderQ = $conn->prepare("SELECT * FROM \order_received\ WHERE \id\ = ?");
    $orderQ->bind_param("i", $orderId);
    $orderQ->execute();
    $order = $orderQ->get_result()->fetch_assoc();
    $orderQ->close();
    if (!$order) return;

    if ($allSufficient) {
        $updateQ = $conn->prepare("UPDATE \order_received\ SET \status\ = 8, \updated_by\ = ?, \updated_at\ = NOW() WHERE \id\ = ?");
        $updateQ->bind_param("ii", $createdBy, $orderId);
        $updateQ->execute();
        $updateQ->close();

        $outwardType = 2;
        $clientName = $order['client_name'];
        $extraNote = "Auto-routed from Order #" . $order['order_number'];
        $stmt = $conn->prepare("INSERT INTO \stock_outward\ (\outward_type\, \client_name\, \extra_note\, \order_id\, \created_by\) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issii", $outwardType, $clientName, $extraNote, $orderId, $createdBy);
        $stmt->execute();
        $outwardId = $conn->insert_id;
        $stmt->close();

        $itemsQ = $conn->prepare("SELECT product_name, quantity, unit FROM \order_received_items\ WHERE order_id = ? AND deleted_at IS NULL");
        $itemsQ->bind_param("i", $orderId);
        $itemsQ->execute();
        $itemsResult = $itemsQ->get_result();

        $itemStmt = $conn->prepare("INSERT INTO \stock_outward_items\ (\outward_id\, \product_name\, \quantity_out\, \created_by\) VALUES (?, ?, ?, ?)");
        while ($itemRow = $itemsResult->fetch_assoc()) {
            $pName = trim($itemRow['product_name']);
            $qty = floatval($itemRow['quantity']);
            $qtyStr = strval($qty);
            $itemStmt->bind_param("issi", $outwardId, $pName, $qtyStr, $createdBy);
            $itemStmt->execute();
        }
        $itemStmt->close();
        $itemsQ->close();

    } else {
        $updateQ = $conn->prepare("UPDATE \order_received\ SET \status\ = 9, \updated_by\ = ?, \updated_at\ = NOW() WHERE \id\ = ?");
        $updateQ->bind_param("ii", $createdBy, $orderId);
        $updateQ->execute();
        $updateQ->close();

        $poNumber = "PO-RAW-" . date('Ymd') . "-" . $orderId;
        $vendorName = $order['client_name'] . " (Linked Vendor)";
        $status = 0;
        $extraNote = "Auto-routed from Order #" . $order['order_number'] . " due to low stock.";

        $stmt = $conn->prepare("INSERT INTO \purchase_order_raw\ (\po_order_num\, \endor_name_po\, \status\, \extra_note\, \order_id\, \created_by\) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisii", $poNumber, $vendorName, $status, $extraNote, $orderId, $createdBy);
        $stmt->execute();
        $poId = $conn->insert_id;
        $stmt->close();

        $itemStmt = $conn->prepare("INSERT INTO \purchase_order_raw_items\ (\po_raw_id\, \product_name\, \quantity_required\, \status\, \created_by\) VALUES (?, ?, ?, 1, ?)");
        foreach ($stockAlerts as $alert) {
            if ($alert['status'] !== 'ok') {
                $pName = trim($alert['product_name']);
                $qtyStr = strval($alert['ordered_qty']);
                $itemStmt->bind_param("issi", $poId, $pName, $qtyStr, $createdBy);
                $itemStmt->execute();
            }
        }
        $itemStmt->close();
    }
    */
}
function getOrderStockAlerts($conn, $orderId)
{
    $alerts = [];
    $itemsQ = $conn->prepare("SELECT product_name, quantity FROM `order_received_items` WHERE order_id = ? AND deleted_at IS NULL");
    if (!$itemsQ)
        return $alerts;

    $itemsQ->bind_param("i", $orderId);
    $itemsQ->execute();
    $itemsResult = $itemsQ->get_result();

    while ($itemRow = $itemsResult->fetch_assoc()) {
        $pName = trim($itemRow['product_name']);
        $qtyRequired = floatval($itemRow['quantity']);

        $pStmt = $conn->prepare("SELECT id FROM products WHERE product_name = ? LIMIT 1");
        $pStmt->bind_param("s", $pName);
        $pStmt->execute();
        $pRes = $pStmt->get_result();

        $availableQty = 0;
        if ($pRes->num_rows > 0) {
            $pId = $pRes->fetch_assoc()['id'];

            $sStmt = $conn->prepare("SELECT COALESCE(unreserved_qty, 0) as total_avail
                FROM live_stock WHERE product_id = ? AND deleted_at IS NULL");
            $sStmt->bind_param("i", $pId);
            $sStmt->execute();
            $sRes = $sStmt->get_result();
            if ($sRes->num_rows > 0) {
                $availableQty = floatval($sRes->fetch_assoc()['total_avail']);
            }
            $sStmt->close();
        }
        $pStmt->close();

        $status = 'ok';
        if ($availableQty <= 0) {
            $status = 'out_of_stock';
        } elseif ($availableQty < $qtyRequired) {
            $status = 'low_stock';
        }

        $alerts[] = [
            'status' => $status,
            'product_name' => $pName,
            'ordered_qty' => $qtyRequired
        ];
    }
    $itemsQ->close();

    return $alerts;
}

function mvTriggerAutoRoutingInBackground(int $createdBy): void
{
    $scriptPath = __DIR__ . '/tasks/route_pending.php';
    if (!file_exists($scriptPath)) {
        return;
    }

    $cmd = "php -d xdebug.mode=off " . escapeshellarg($scriptPath) . " " . intval($createdBy);
    if (stristr(PHP_OS, 'WIN')) {
        $p = popen("start /B " . $cmd . " > NUL 2>&1", "r");
        if ($p !== false) {
            pclose($p);
        }
    } else {
        exec($cmd . " > /dev/null 2>&1 &");
    }
}

function mvStoreCompanyProfileUpload(array $file, int $companyId, string $documentType): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The selected file could not be uploaded.');
    }

    $fileSize = (int) ($file['size'] ?? 0);
    if ($fileSize <= 0 || $fileSize > 10 * 1024 * 1024) {
        throw new RuntimeException('Files must be smaller than 10 MB.');
    }

    $tmpName = (string) ($file['tmp_name'] ?? '');
    $originalName = basename((string) ($file['name'] ?? 'document'));
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $allowedExtensions = ['pdf', 'png', 'jpg', 'jpeg'];
    if (!in_array($extension, $allowedExtensions, true)) {
        throw new RuntimeException('Only PDF, PNG, JPG, and JPEG files are supported.');
    }

    $mimeType = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = (string) $finfo->file($tmpName);
    }
    $allowedMimeTypes = ['application/pdf', 'image/png', 'image/jpeg'];
    if ($mimeType !== '' && !in_array($mimeType, $allowedMimeTypes, true)) {
        throw new RuntimeException('The selected file type is not valid.');
    }
    $imageOnlyTypes = ['logo', 'letterhead_header', 'letterhead_logo', 'stamp', 'digital_signature'];
    if (in_array($documentType, $imageOnlyTypes, true) && $mimeType !== '' && !in_array($mimeType, ['image/png', 'image/jpeg'], true)) {
        throw new RuntimeException('Logo, letterhead, stamp, and signature files must be PNG, JPG, or JPEG images.');
    }

    $safeType = preg_replace('/[^a-z0-9_]+/i', '_', $documentType);
    $relativeDir = 'uploads/company-profiles/' . $companyId . '/';
    $uploadDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDir);
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        throw new RuntimeException('The company document folder could not be created.');
    }

    $storedName = $safeType . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    if (!move_uploaded_file($tmpName, $uploadDir . $storedName)) {
        throw new RuntimeException('The selected file could not be stored.');
    }

    return [
        'file_path' => $relativeDir . $storedName,
        'original_name' => $originalName,
        'mime_type' => $mimeType,
        'file_size' => $fileSize,
    ];
}

function mvStoreEmployeeProfilePhoto(array $file, int $employeeId): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The selected profile photo could not be uploaded.');
    }

    $fileSize = (int) ($file['size'] ?? 0);
    if ($fileSize <= 0 || $fileSize > 5 * 1024 * 1024) {
        throw new RuntimeException('Profile photos must be smaller than 5 MB.');
    }

    $tmpName = (string) ($file['tmp_name'] ?? '');
    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        throw new RuntimeException('The selected profile photo could not be uploaded.');
    }
    $originalName = basename((string) ($file['name'] ?? 'profile-photo'));
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $allowedExtensions = ['png', 'jpg', 'jpeg', 'webp'];
    if (!in_array($extension, $allowedExtensions, true)) {
        throw new RuntimeException('Profile photos must be PNG, JPG, JPEG, or WEBP images.');
    }

    $mimeType = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = (string) $finfo->file($tmpName);
    }
    $allowedMimeTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (($mimeType !== '' && !in_array($mimeType, $allowedMimeTypes, true)) || @getimagesize($tmpName) === false) {
        throw new RuntimeException('The selected profile photo is not a valid image.');
    }

    $relativeDir = 'uploads/employee-profiles/' . $employeeId . '/';
    $uploadDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDir);
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
        throw new RuntimeException('The employee profile photo folder could not be created.');
    }

    $storedName = 'profile_' . bin2hex(random_bytes(8)) . '.' . $extension;
    if (!move_uploaded_file($tmpName, $uploadDir . $storedName)) {
        throw new RuntimeException('The selected profile photo could not be stored.');
    }

    return [
        'file_path' => $relativeDir . $storedName,
        'original_name' => $originalName,
        'mime_type' => $mimeType,
        'file_size' => $fileSize,
    ];
}

function mvGetCompanyBranding(mysqli $conn, ?int $companyId = null): array
{
    $branding = [
        'company_id' => null,
        'legal_name' => 'Biogenix Inc Pvt Ltd.',
        'trade_name' => 'Biogenix',
        'cin_no' => '',
        'gst_no' => '',
        'registered_address' => '',
        'logo' => null,
        'letterhead_header' => null,
        'letterhead_logo' => null,
        'stamp' => null,
        'digital_signature' => null,
    ];

    $tableCheck = $conn->query("SHOW TABLES LIKE 'company_profiles'");
    if (!$tableCheck || $tableCheck->num_rows === 0) {
        return $branding;
    }

    if ($companyId !== null && $companyId > 0) {
        $stmt = $conn->prepare('SELECT id, legal_name, trade_name, cin_no, gst_no FROM company_profiles WHERE id = ? AND status != 3 LIMIT 1');
    } else {
        $stmt = $conn->prepare('SELECT id, legal_name, trade_name, cin_no, gst_no FROM company_profiles WHERE status = 1 ORDER BY id ASC LIMIT 1');
    }
    if (!$stmt) {
        return $branding;
    }
    if ($companyId !== null && $companyId > 0) {
        $stmt->bind_param('i', $companyId);
    }
    if (!$stmt->execute()) {
        $stmt->close();
        return $branding;
    }

    $profile = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$profile) {
        return $branding;
    }

    $branding['company_id'] = (int) $profile['id'];
    $branding['legal_name'] = $profile['legal_name'] ?: $branding['legal_name'];
    $branding['trade_name'] = $profile['trade_name'] ?: $branding['trade_name'];
    $branding['cin_no'] = trim((string) ($profile['cin_no'] ?? ''));
    $branding['gst_no'] = trim((string) ($profile['gst_no'] ?? ''));

    $addressTableCheck = $conn->query("SHOW TABLES LIKE 'company_profile_addresses'");
    if ($addressTableCheck && $addressTableCheck->num_rows > 0) {
        $addressStmt = $conn->prepare("SELECT address FROM company_profile_addresses WHERE company_id = ? ORDER BY is_primary DESC, FIELD(address_type, 'registered', 'factory', 'warehouse'), sort_order ASC, id ASC LIMIT 1");
        if ($addressStmt) {
            $addressStmt->bind_param('i', $branding['company_id']);
            if ($addressStmt->execute()) {
                $branding['registered_address'] = trim((string) ($addressStmt->get_result()->fetch_assoc()['address'] ?? ''));
            }
            $addressStmt->close();
        }
    }

    $documentTypes = ['logo', 'letterhead_header', 'letterhead_logo', 'stamp', 'digital_signature'];
    $docStmt = $conn->prepare('SELECT document_type, file_path FROM company_profile_documents WHERE company_id = ?');
    if (!$docStmt) {
        return $branding;
    }
    $docStmt->bind_param('i', $branding['company_id']);
    $docStmt->execute();
    $documents = $docStmt->get_result();
    while ($document = $documents->fetch_assoc()) {
        if (in_array($document['document_type'], $documentTypes, true)) {
            $branding[$document['document_type']] = $document['file_path'];
        }
    }
    $docStmt->close();

    return $branding;
}

/**
 * CRM Helper Functions
 */

function generateLeadNumber(mysqli $conn, ?string $date = null): string
{
    $now = $date ? new DateTime($date) : new DateTime();
    $yearYY = $now->format('y');
    $sequenceYear = $now->format('Y') . '-01-01';

    $stmt = $conn->prepare("INSERT INTO `crm_lead_number_sequences` (`sequence_date`, `last_sequence`) VALUES (?, 1) ON DUPLICATE KEY UPDATE `last_sequence` = LAST_INSERT_ID(`last_sequence` + 1)");
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the lead number sequence.');
    }
    $stmt->bind_param('s', $sequenceYear);
    if (!$stmt->execute()) {
        $message = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to reserve the next lead number: ' . $message);
    }
    $isFirstSequence = $stmt->affected_rows === 1;
    $stmt->close();

    if ($isFirstSequence) {
        $nextSequence = 1;
    } else {
        $result = $conn->query('SELECT LAST_INSERT_ID() AS `next_sequence`');
        $nextSequence = (int) ($result->fetch_assoc()['next_sequence'] ?? 0);
    }

    if ($nextSequence <= 0) {
        throw new RuntimeException('The next lead number could not be reserved.');
    }

    return sprintf('LEAD-%s-%04d', $yearYY, $nextSequence);
}

function logLeadActivity(mysqli $conn, int $leadId, string $action, ?string $details = null, ?int $userId = null): bool
{
    if ($userId === null && isset($_SESSION['user_id'])) {
        $userId = (int) $_SESSION['user_id'];
    }
    $stmt = $conn->prepare("INSERT INTO `crm_lead_activity_log` (`lead_id`, `action`, `details`, `user_id`, `created_at`) VALUES (?, ?, ?, ?, NOW())");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('issi', $leadId, $action, $details, $userId);
    $ok = $stmt->execute();
    $stmt->close();
    if ($ok) {
        $activityUpdate = $conn->prepare(
            'UPDATE crm_leads SET last_activity_date = NOW(), updated_at = NOW() WHERE id = ?'
        );
        if ($activityUpdate) {
            $activityUpdate->bind_param('i', $leadId);
            $activityUpdate->execute();
            $activityUpdate->close();
        }
    }
    return $ok;
}

function getNewLeadsCount(mysqli $conn): int
{
    $res = $conn->query("SELECT COUNT(*) AS total FROM `crm_leads` WHERE `acceptance_status` = 'Pending' AND `deleted_at` IS NULL");
    if (!$res) {
        return 0;
    }
    $row = $res->fetch_assoc();
    return (int) ($row['total'] ?? 0);
}

function getLeadAssignmentRecommendation(mysqli $conn, int $leadId): array
{
    $leadStmt = $conn->prepare("SELECT id, territory, city, state, region FROM `crm_leads` WHERE id = ? AND deleted_at IS NULL LIMIT 1");
    if (!$leadStmt) {
        return ['salesperson_id' => null, 'salesperson_name' => '', 'sales_team' => '', 'score' => 0, 'match_reason' => 'Lead not found'];
    }
    $leadStmt->bind_param('i', $leadId);
    $leadStmt->execute();
    $lead = $leadStmt->get_result()->fetch_assoc();
    $leadStmt->close();
    if (!$lead) {
        return ['salesperson_id' => null, 'salesperson_name' => '', 'sales_team' => '', 'score' => 0, 'match_reason' => 'Lead not found'];
    }

    $leadProductIds = [];
    $leadCategories = [];
    $prodRes = $conn->query("SELECT lp.product_id, pc.name AS category_name
        FROM `crm_lead_products` lp 
        LEFT JOIN `products` p ON p.id = lp.product_id 
        LEFT JOIN `product_categories` pc ON pc.id = p.category_id 
        WHERE lp.lead_id = {$leadId}");
    if ($prodRes) {
        while ($row = $prodRes->fetch_assoc()) {
            if (!empty($row['product_id'])) $leadProductIds[] = (int) $row['product_id'];
            if (!empty($row['category_name'])) $leadCategories[] = strtolower(trim($row['category_name']));
        }
    }

    $spRes = $conn->query(
        "SELECT id, salesperson_name, sales_team, assignment_priority
         FROM `salesperson_masters`
         WHERE status = 1 AND deleted_at IS NULL
         ORDER BY assignment_priority ASC, id ASC"
    );
    if (!$spRes || $spRes->num_rows === 0) {
        return ['salesperson_id' => null, 'salesperson_name' => '', 'sales_team' => '', 'score' => 0, 'match_reason' => 'No active salespersons registered'];
    }

    $candidates = [];
    $leadTerritory = strtolower(trim((string)($lead['territory'] ?? '')));
    $leadCity = strtolower(trim((string)($lead['city'] ?? '')));
    $leadState = strtolower(trim((string)($lead['state'] ?? '')));
    $leadRegion = strtolower(trim((string)($lead['region'] ?? '')));

    while ($sp = $spRes->fetch_assoc()) {
        $spId = (int) $sp['id'];
        $score = 0;
        $territoryRank = 0;
        $productMatches = 0;
        $responsibilityMatches = 0;
        $reasons = [];

        $tRes = $conn->query("SELECT territory_name, territory_type FROM `salesperson_territories` WHERE salesperson_id = {$spId}");
        if ($tRes) {
            while ($tRow = $tRes->fetch_assoc()) {
                $tName = strtolower(trim((string)$tRow['territory_name']));
                $territoryType = strtolower(trim((string) $tRow['territory_type']));
                if ($territoryType === 'territory' && $leadTerritory !== '' && $tName === $leadTerritory) {
                    $score += 50;
                    $territoryRank = max($territoryRank, 3);
                    $reasons[] = 'Territory: ' . ($lead['territory'] ?? '');
                } elseif ($territoryType === 'city' && $leadCity !== '' && $tName === $leadCity) {
                    $score += 60;
                    $territoryRank = max($territoryRank, 3);
                    $reasons[] = 'City: ' . ($lead['city'] ?? '');
                } elseif ($territoryType === 'state' && $leadState !== '' && $tName === $leadState) {
                    $score += 40;
                    $territoryRank = max($territoryRank, 2);
                    $reasons[] = 'State: ' . ($lead['state'] ?? '');
                } elseif ($territoryType === 'region' && $leadRegion !== '' && $tName === $leadRegion) {
                    $score += 20;
                    $territoryRank = max($territoryRank, 1);
                    $reasons[] = 'Region: ' . ($lead['region'] ?? '');
                }
            }
        }

        $eRes = $conn->query("SELECT category_name, product_id FROM `salesperson_product_expertise` WHERE salesperson_id = {$spId}");
        if ($eRes) {
            while ($eRow = $eRes->fetch_assoc()) {
                $catName = strtolower(trim((string)$eRow['category_name']));
                if (!empty($eRow['product_id']) && in_array((int)$eRow['product_id'], $leadProductIds, true)) {
                    $score += 50;
                    $productMatches++;
                    $reasons[] = 'Product expertise';
                }
                if ($catName !== '' && in_array($catName, $leadCategories, true)) {
                    $score += 30;
                    $productMatches++;
                    $reasons[] = 'Product category expertise';
                }
            }
        }

        $rRes = $conn->query("SELECT category_name, product_id FROM `salesperson_product_responsibility` WHERE salesperson_id = {$spId}");
        if ($rRes) {
            while ($rRow = $rRes->fetch_assoc()) {
                $catName = strtolower(trim((string)$rRow['category_name']));
                if (!empty($rRow['product_id']) && in_array((int)$rRow['product_id'], $leadProductIds, true)) {
                    $score += 50;
                    $responsibilityMatches++;
                    $reasons[] = 'Product responsibility';
                }
                if ($catName !== '' && in_array($catName, $leadCategories, true)) {
                    $score += 30;
                    $responsibilityMatches++;
                    $reasons[] = 'Product category responsibility';
                }
            }
        }

        $candidates[] = [
            'salesperson_id' => $spId,
            'salesperson_name' => (string) $sp['salesperson_name'],
            'sales_team' => (string) ($sp['sales_team'] ?? ''),
            'assignment_priority' => max(1, (int) ($sp['assignment_priority'] ?? 100)),
            'score' => $score,
            'territory_rank' => $territoryRank,
            'product_matches' => $productMatches,
            'responsibility_matches' => $responsibilityMatches,
            'reasons' => array_values(array_unique($reasons)),
        ];
    }

    usort($candidates, static function (array $a, array $b): int {
        return ($b['score'] <=> $a['score'])
            ?: ($b['responsibility_matches'] <=> $a['responsibility_matches'])
            ?: ($b['product_matches'] <=> $a['product_matches'])
            ?: ($b['territory_rank'] <=> $a['territory_rank'])
            ?: ($a['assignment_priority'] <=> $b['assignment_priority'])
            ?: ($a['salesperson_id'] <=> $b['salesperson_id']);
    });

    $best = $candidates[0] ?? null;
    if (!$best || (int) $best['score'] <= 0) {
        return [
            'salesperson_id' => null,
            'salesperson_name' => '',
            'sales_team' => '',
            'score' => 0,
            'match_reason' => 'No territory, product expertise, or product responsibility rule matched',
        ];
    }

    $best['match_reason'] = 'Matched by ' . implode(' + ', $best['reasons'])
        . ' (score ' . $best['score'] . ', priority ' . $best['assignment_priority'] . ')';
    return $best;
}

function assignLeadToSalesperson(mysqli $conn, int $leadId, ?int $userId = null): ?int
{
    $recommendation = getLeadAssignmentRecommendation($conn, $leadId);
    $salespersonId = $recommendation['salesperson_id'] ?? null;
    if (!$salespersonId) {
        return null;
    }

    $salesTeam = (string) ($recommendation['sales_team'] ?? '');
    $reason = (string) ($recommendation['match_reason'] ?? 'Automatic assignment');
    $stmt = $conn->prepare(
        'UPDATE crm_leads
         SET assigned_salesperson_id = ?, sales_team = ?, assignment_reason = ?, updated_at = NOW()
         WHERE id = ? AND deleted_at IS NULL'
    );
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('issi', $salespersonId, $salesTeam, $reason, $leadId);
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) {
        return null;
    }

    logLeadActivity(
        $conn,
        $leadId,
        'Auto-Assigned Salesperson',
        'Assigned to ' . $recommendation['salesperson_name'] . '. ' . $reason,
        $userId
    );
    return (int) $salespersonId;
}

/**
 * Fetch all completed Procurement (PO) and Production (BMR/BPR) records mapped to orders
 * that are received and reserved into stock before dispatch or cancellation.
 */
function mvGetGoodsReceivedReservedList(mysqli $conn): array
{
    $records = [];
    $unitMap = [];
    $unitQuery = $conn->query("SELECT id, short_name, fullname FROM standard_units WHERE status != 3");
    if ($unitQuery) {
        while ($uRow = $unitQuery->fetch_assoc()) {
            $unitMap[(int)$uRow['id']] = $uRow['short_name'] ?: $uRow['fullname'];
        }
    }

    // Terminal statuses to exclude: Complete (5), Cancelled (6), Cancelled_by_Client (7), Dispatched (8), Forcefully_Complete (10), Partial_Delivered (11)
    // 1. Procured items linked to Orders (via purchase orders / low stocks / inward records)
    $poSql = "SELECT 
                oi.id AS order_item_id,
                o.id AS order_id,
                o.order_number,
                o.client_name,
                oi.product_name,
                oi.quantity,
                oi.unit,
                COALESCE(oi.reserved_quantity_base, oi.quantity) AS reserved_qty,
                COALESCE(pof.po_order_num, CONCAT('PO-FY26/', LPAD(o.id, 5, '0'))) AS po_ref,
                COALESCE(DATE(si.created_at), DATE(pof.created_at), DATE(o.date_order_received), CURDATE()) AS date_received,
                oi.product_id,
                oi.fulfillment_action,
                oi.fulfillment_status,
                o.status AS order_status
              FROM order_received_items oi
              INNER JOIN order_received o ON o.id = oi.order_id AND o.deleted_at IS NULL
              LEFT JOIN low_stocks ls ON ls.order_id = o.id AND (ls.product_id = oi.product_id OR ls.product_name = oi.product_name) AND ls.deleted_at IS NULL
              LEFT JOIN purchase_order_final pof ON pof.low_stock_id = ls.id AND pof.deleted_at IS NULL
              LEFT JOIN stock_inwards si ON (si.po_id = pof.id OR si.purchase_order_id = pof.id OR si.product_id = oi.product_id) AND si.deleted_at IS NULL
              WHERE oi.deleted_at IS NULL
                AND o.status NOT IN (5, 6, 7, 8, 10, 11)
                AND oi.status NOT IN (5, 6, 7, 8, 10, 11)
                AND (
                    (si.id IS NOT NULL AND oi.reserved_quantity_base > 0)
                    OR oi.fulfillment_status IN ('procured_received', 'stock_received', 'ready_for_dispatch')
                    OR (o.status = 13 AND (oi.fulfillment_action = 'procurement' OR oi.fulfillment_status = 'stock_available'))
                    OR (pof.id IS NOT NULL AND pof.status = 2)
                )
              GROUP BY oi.id
              ORDER BY o.id DESC, oi.id ASC";

    $poResult = $conn->query($poSql);
    if ($poResult) {
        while ($row = $poResult->fetch_assoc()) {
            $unitName = $unitMap[(int)$row['unit']] ?? 'pcs';
            $qtyVal = (float)$row['quantity'];
            $resVal = (float)($row['reserved_qty'] > 0 ? $row['reserved_qty'] : $qtyVal);
            $qtyText = number_format($resVal, 0) . ' / ' . number_format($qtyVal, 0) . ' ' . $unitName;

            $dateRec = !empty($row['date_received']) ? date('d/m/Y', strtotime((string)$row['date_received'])) : date('d/m/Y');

            $records[] = [
                'id' => 'PO_' . $row['order_item_id'],
                'order_id' => (int)$row['order_id'],
                'order_item_id' => (int)$row['order_item_id'],
                'product_id' => (int)$row['product_id'],
                'order_number' => (string)$row['order_number'],
                'client_name' => (string)$row['client_name'],
                'item_name' => (string)$row['product_name'],
                'source_type' => 'Procure (PO)',
                'source_category' => 'procure',
                'source_ref' => (string)$row['po_ref'],
                'arrived_qty_text' => $qtyText,
                'raw_qty' => $qtyVal,
                'unit_name' => $unitName,
                'date_received' => $dateRec,
                'reservation_status' => 'Reserved & Closed'
            ];
        }
    }

    // 2. Produced items linked to Orders (via production plans / BMR / BPR / transfer ticket)
    $prodSql = "SELECT 
                oi.id AS order_item_id,
                o.id AS order_id,
                o.order_number,
                o.client_name,
                oi.product_name,
                oi.quantity,
                oi.unit,
                COALESCE(oi.reserved_quantity_base, oi.quantity) AS reserved_qty,
                pp.id AS prod_plan_id,
                COALESCE(pp.lo_batch_no, pp.production_plan_no, CONCAT('BMR-BIO/26-', LPAD(pp.id, 5, '0'))) AS batch_ref,
                COALESCE(DATE(tt.created_at), DATE(pp.updated_at), DATE(pp.date), CURDATE()) AS date_received,
                oi.product_id,
                oi.fulfillment_action,
                oi.fulfillment_status,
                o.status AS order_status
              FROM order_received_items oi
              INNER JOIN order_received o ON o.id = oi.order_id AND o.deleted_at IS NULL
              INNER JOIN production_plans pp ON pp.order_id = o.id AND (pp.order_item_id = oi.id OR pp.product_id = oi.product_id) AND pp.deleted_at IS NULL
              LEFT JOIN transfer_ticket tt ON tt.prod_plan_id = pp.id AND tt.deleted_at IS NULL
              WHERE oi.deleted_at IS NULL
                AND o.status NOT IN (5, 6, 7, 8, 10, 11)
                AND oi.status NOT IN (5, 6, 7, 8, 10, 11)
                AND (
                    (tt.id IS NOT NULL AND tt.status = 1)
                    OR pp.status = 2 -- Completed
                    OR oi.fulfillment_status IN ('produced_received', 'stock_received', 'ready_for_dispatch')
                    OR (o.status = 13 AND (oi.fulfillment_action = 'production' OR oi.fulfillment_status = 'stock_available'))
                )
              GROUP BY oi.id
              ORDER BY o.id DESC, oi.id ASC";

    $prodResult = $conn->query($prodSql);
    if ($prodResult) {
        while ($row = $prodResult->fetch_assoc()) {
            $unitName = $unitMap[(int)$row['unit']] ?? 'pcs';
            $qtyVal = (float)$row['quantity'];
            $resVal = (float)($row['reserved_qty'] > 0 ? $row['reserved_qty'] : $qtyVal);
            $qtyText = number_format($resVal, 0) . ' / ' . number_format($qtyVal, 0) . ' ' . $unitName;

            $dateRec = !empty($row['date_received']) ? date('d/m/Y', strtotime((string)$row['date_received'])) : date('d/m/Y');
            
            // Determine whether BMR or BPR based on product name/code
            $isBpr = stripos($row['product_name'], 'tip') !== false || stripos($row['product_name'], 'tube') !== false || stripos($row['product_name'], 'vial') !== false;
            $sourceType = $isBpr ? 'Produce (BPR)' : 'Produce (BMR)';

            $records[] = [
                'id' => 'PROD_' . $row['order_item_id'],
                'order_id' => (int)$row['order_id'],
                'order_item_id' => (int)$row['order_item_id'],
                'product_id' => (int)$row['product_id'],
                'order_number' => (string)$row['order_number'],
                'client_name' => (string)$row['client_name'],
                'item_name' => (string)$row['product_name'],
                'source_type' => $sourceType,
                'source_category' => 'produce',
                'source_ref' => (string)$row['batch_ref'],
                'arrived_qty_text' => $qtyText,
                'raw_qty' => $qtyVal,
                'unit_name' => $unitName,
                'date_received' => $dateRec,
                'reservation_status' => 'Reserved & Closed'
            ];
        }
    }

    // 3. Any other active Orders that are in Closed & Ready / Reserved status with stock allocated
    $reservedSql = "SELECT 
                    oi.id AS order_item_id,
                    o.id AS order_id,
                    o.order_number,
                    o.client_name,
                    oi.product_name,
                    oi.quantity,
                    oi.unit,
                    COALESCE(oi.reserved_quantity_base, oi.quantity) AS reserved_qty,
                    COALESCE(o.date_order_received, CURDATE()) AS date_received,
                    oi.product_id,
                    o.status AS order_status
                  FROM order_received_items oi
                  INNER JOIN order_received o ON o.id = oi.order_id AND o.deleted_at IS NULL
                  WHERE oi.deleted_at IS NULL
                    AND o.status IN (1, 13) -- Inprocess / Ready for Dispatch
                    AND oi.status NOT IN (5, 6, 7, 8, 10, 11)
                  GROUP BY oi.id
                  ORDER BY o.id DESC";

    $resResult = $conn->query($reservedSql);
    $existingItemIds = array_column($records, 'order_item_id');
    if ($resResult) {
        while ($row = $resResult->fetch_assoc()) {
            $itemId = (int)$row['order_item_id'];
            if (in_array($itemId, $existingItemIds, true)) {
                continue;
            }
            $unitName = $unitMap[(int)$row['unit']] ?? 'pcs';
            $qtyVal = (float)$row['quantity'];
            $resVal = (float)($row['reserved_qty'] > 0 ? $row['reserved_qty'] : $qtyVal);
            $qtyText = number_format($resVal, 0) . ' / ' . number_format($qtyVal, 0) . ' ' . $unitName;
            $dateRec = !empty($row['date_received']) ? date('d/m/Y', strtotime((string)$row['date_received'])) : date('d/m/Y');

            $records[] = [
                'id' => 'RES_' . $itemId,
                'order_id' => (int)$row['order_id'],
                'order_item_id' => $itemId,
                'product_id' => (int)$row['product_id'],
                'order_number' => (string)$row['order_number'],
                'client_name' => (string)$row['client_name'],
                'item_name' => (string)$row['product_name'],
                'source_type' => 'Procure (PO)',
                'source_category' => 'procure',
                'source_ref' => 'PO-FY26/' . str_pad((string)$row['order_id'], 5, '0', STR_PAD_LEFT),
                'arrived_qty_text' => $qtyText,
                'raw_qty' => $qtyVal,
                'unit_name' => $unitName,
                'date_received' => $dateRec,
                'reservation_status' => 'Reserved & Closed'
            ];
            $existingItemIds[] = $itemId;
        }
    }

    // Stats calculations
    $uniqueOrders = array_unique(array_column($records, 'order_id'));
    $procuredCount = count(array_filter($records, static fn($r) => $r['source_category'] === 'procure'));
    $producedCount = count(array_filter($records, static fn($r) => $r['source_category'] === 'produce'));

    return [
        'records' => $records,
        'stats' => [
            'closed_orders_count' => count($uniqueOrders),
            'procured_items_count' => $procuredCount,
            'produced_batches_count' => $producedCount,
            'total_count' => count($records),
        ]
    ];
}

/**
 * Mark a reserved order record as Goods Dispatched, update stock/reservations,
 * create the stock outward record, and update the main Order Management table automatically.
 */
function mvDispatchReservedOrderRecord(mysqli $conn, int $orderId, int $orderItemId, int $userId): array
{
    if ($orderId <= 0) {
        throw new InvalidArgumentException('A valid order ID is required.');
    }

    $conn->begin_transaction();
    try {
        $dispatchedStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Dispatched'] ?? 8;
        $partialDispatchedStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Partial_Delivered'] ?? 11;

        // Fetch Order header
        $orderStmt = $conn->prepare("SELECT id, order_number, client_name, area_city, order_type FROM order_received WHERE id = ? AND deleted_at IS NULL FOR UPDATE");
        $orderStmt->bind_param('i', $orderId);
        $orderStmt->execute();
        $order = $orderStmt->get_result()->fetch_assoc();
        $orderStmt->close();

        if (!$order) {
            throw new RuntimeException('Order not found.');
        }

        // Fetch items to dispatch. Quantities are always in the product's direct stock unit.
        $itemSql = "SELECT id, product_id, product_name, quantity, fulfilled_quantity, unit FROM order_received_items
                    WHERE order_id = ? AND deleted_at IS NULL" . ($orderItemId > 0 ? " AND id = ?" : " AND status NOT IN (5,6,7,8,10,11)");
        $itemStmt = $conn->prepare($itemSql);
        if ($orderItemId > 0) {
            $itemStmt->bind_param('ii', $orderId, $orderItemId);
        } else {
            $itemStmt->bind_param('i', $orderId);
        }
        $itemStmt->execute();
        $itemsResult = $itemStmt->get_result();
        $itemsToDispatch = [];
        while ($iRow = $itemsResult->fetch_assoc()) {
            $itemsToDispatch[] = $iRow;
        }
        $itemStmt->close();

        if (empty($itemsToDispatch)) {
            // Already dispatched / no pending items
            $conn->commit();
            return [
                'status' => 'success',
                'message' => 'Order is already marked as Dispatched.',
                'order_id' => $orderId,
                'new_status' => $dispatchedStatus
            ];
        }

        // Create or find Stock Outward parent record
        $outwardType = 2; // External Dispatch / Product Order
        $clientName = $order['client_name'] ?? '';
        $placeOfDispatch = $order['area_city'] ?? '';
        $remark = 'Auto-dispatched from Order Management (Order #' . ($order['order_number'] ?? $orderId) . ')';

        $checkOutward = $conn->prepare("SELECT id FROM stock_outward WHERE order_id = ? AND status != 3 LIMIT 1");
        $checkOutward->bind_param('i', $orderId);
        $checkOutward->execute();
        $existingOutward = $checkOutward->get_result()->fetch_assoc();
        $checkOutward->close();

        if ($existingOutward) {
            $outwardId = (int)$existingOutward['id'];
        } else {
            $insertOutward = $conn->prepare("INSERT INTO stock_outward (outward_type, client_name, place_of_dispatch, order_id, status, remark, created_by, created_at) VALUES (?, ?, ?, ?, 1, ?, ?, NOW())");
            // Six values are supplied, so six kinds are declared; the extra one
            // here made the dispatch fail as soon as an order had no outward
            // record yet.
            $insertOutward->bind_param('issisi', $outwardType, $clientName, $placeOfDispatch, $orderId, $remark, $userId);
            $insertOutward->execute();
            $outwardId = $conn->insert_id;
            $insertOutward->close();
        }

        $insertOutwardItem = $conn->prepare("INSERT INTO stock_outward_items (outward_id, prod_categ_id, product_id, live_stock_id, coa_number, lot_batch_no, mfg_date, exp_date, issued_quantity, issued_unit, remark, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

        foreach ($itemsToDispatch as $item) {
            $currItemId = (int)$item['id'];
            $productId = (int)$item['product_id'];
            $pName = trim((string)$item['product_name']);
            $qty = max(0, (float) $item['quantity'] - (float) ($item['fulfilled_quantity'] ?? 0));
            $unitId = (int)$item['unit'];
            if ($qty <= 0) {
                continue;
            }

            $catId = 0;
            if ($productId > 0) {
                $pCatStmt = $conn->prepare("SELECT category_id FROM products WHERE id = ?");
                $pCatStmt->bind_param('i', $productId);
                $pCatStmt->execute();
                $catRow = $pCatStmt->get_result()->fetch_assoc();
                $catId = (int)($catRow['category_id'] ?? 0);
                $pCatStmt->close();
            } else if (!empty($pName)) {
                $pCatStmt = $conn->prepare("SELECT id, category_id FROM products WHERE product_name = ? AND status = 1 LIMIT 1");
                $pCatStmt->bind_param('s', $pName);
                $pCatStmt->execute();
                $catRow = $pCatStmt->get_result()->fetch_assoc();
                if ($catRow) {
                    $productId = (int)$catRow['id'];
                    $catId = (int)$catRow['category_id'];
                }
                $pCatStmt->close();
            }

            $balance = inventoryGetBalance($conn, $productId, true);
            if (!$balance) {
                throw new RuntimeException('Inventory balance is missing for ' . ($pName ?: 'the selected product') . '.');
            }
            $liveStockId = (int) $balance['id'];
            $coaNumber = '';
            $lotBatchNo = '';
            $mfgDate = null;
            $expDate = null;

            $reservationStmt = $conn->prepare("SELECT id, quantity
                FROM order_stock_reservations
                WHERE order_id = ? AND order_item_id = ? AND product_id = ?
                  AND status = 1 AND deleted_at IS NULL
                ORDER BY id ASC LIMIT 1 FOR UPDATE");
            $reservationStmt->bind_param('iii', $orderId, $currItemId, $productId);
            $reservationStmt->execute();
            $reservation = $reservationStmt->get_result()->fetch_assoc();
            $reservationStmt->close();
            if (!$reservation || (float) $reservation['quantity'] + 0.00000001 < $qty) {
                throw new RuntimeException('Reserved stock is insufficient for ' . ($pName ?: 'the selected product') . '.');
            }
            inventoryConsumeReservedStock($conn, $productId, $qty, $userId, 'order_dispatch', $currItemId);

            $itemRemark = 'Dispatched from Order #' . ($order['order_number'] ?? $orderId);
            $insertOutwardItem->bind_param(
                'iiiissssdisi',
                $outwardId,
                $catId,
                $productId,
                $liveStockId,
                $coaNumber,
                $lotBatchNo,
                $mfgDate,
                $expDate,
                $qty,
                $unitId,
                $itemRemark,
                $userId
            );
            $insertOutwardItem->execute();

            $updReservation = $conn->prepare("UPDATE order_stock_reservations
                SET quantity = quantity - ?,
                    quantity_base = quantity_base - ?,
                    status = CASE WHEN quantity - ? <= 0.00000001 THEN 0 ELSE 1 END,
                    closed_reason = CASE WHEN quantity - ? <= 0.00000001 THEN 'dispatched' ELSE NULL END,
                    updated_by = ?, updated_at = NOW()
                WHERE id = ?");
            $reservationId = (int) $reservation['id'];
            $updReservation->bind_param('ddddii', $qty, $qty, $qty, $qty, $userId, $reservationId);
            $updReservation->execute();
            $updReservation->close();

            $updItem = $conn->prepare("UPDATE order_received_items
                SET status = ?, fulfillment_status = 'dispatched',
                    fulfilled_quantity = fulfilled_quantity + ?,
                    reserved_quantity = GREATEST(reserved_quantity - ?, 0),
                    shortfall_quantity = GREATEST(quantity - (fulfilled_quantity + ?), 0),
                    fulfilled_quantity_base = fulfilled_quantity_base + ?,
                    reserved_quantity_base = GREATEST(reserved_quantity_base - ?, 0),
                    shortfall_quantity_base = GREATEST(quantity - (fulfilled_quantity_base + ?), 0),
                    updated_by = ?, updated_at = NOW()
                WHERE id = ?");
            $updItem->bind_param('iddddddii', $dispatchedStatus, $qty, $qty, $qty, $qty, $qty, $qty, $userId, $currItemId);
            $updItem->execute();
            $updItem->close();
        }
        $insertOutwardItem->close();

        // Check remaining non-dispatched items
        $checkStmt = $conn->prepare("SELECT COUNT(*) AS remaining FROM order_received_items WHERE order_id = ? AND status NOT IN (5, 6, 7, 8, 10, 11) AND deleted_at IS NULL");
        $checkStmt->bind_param('i', $orderId);
        $checkStmt->execute();
        $remaining = (int)($checkStmt->get_result()->fetch_assoc()['remaining'] ?? 0);
        $checkStmt->close();

        $orderStatusToSet = ($remaining === 0) ? $dispatchedStatus : $partialDispatchedStatus;

        $stmtOrder = $conn->prepare("UPDATE order_received SET status = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND deleted_at IS NULL");
        $stmtOrder->bind_param('iii', $orderStatusToSet, $userId, $orderId);
        $stmtOrder->execute();
        $stmtOrder->close();

        $conn->commit();

        return [
            'status' => 'success',
            'message' => 'Order ' . ($orderItemId > 0 ? 'item' : '') . ' marked as Goods Dispatched successfully.',
            'order_id' => $orderId,
            'outward_id' => $outwardId,
            'new_status' => $orderStatusToSet
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/**
 * Cancel a reserved order record, release the reserved stock back to unreserved inventory,
 * and update the main Order Management table automatically.
 */
function mvCancelReservedOrderRecord(mysqli $conn, int $orderId, int $orderItemId, int $userId): array
{
    if ($orderId <= 0) {
        throw new InvalidArgumentException('A valid order ID is required.');
    }

    $conn->begin_transaction();
    try {
        $cancelledStatus = Constant::ORDER_RECEIVED['STATUS_TYPES_LABEL']['Cancelled'] ?? 3;

        // Update item status
        if ($orderItemId > 0) {
            $stmtItem = $conn->prepare("UPDATE order_received_items 
                SET status = ?, fulfillment_status = 'cancelled',
                    reserved_quantity = 0, reserved_quantity_base = 0,
                    updated_by = ?, updated_at = NOW()
                WHERE id = ? AND order_id = ? AND deleted_at IS NULL");
            $stmtItem->bind_param('iiii', $cancelledStatus, $userId, $orderItemId, $orderId);
            $stmtItem->execute();
            $stmtItem->close();
        } else {
            $stmtItems = $conn->prepare("UPDATE order_received_items 
                SET status = ?, fulfillment_status = 'cancelled',
                    reserved_quantity = 0, reserved_quantity_base = 0,
                    updated_by = ?, updated_at = NOW()
                WHERE order_id = ? AND deleted_at IS NULL");
            $stmtItems->bind_param('iii', $cancelledStatus, $userId, $orderId);
            $stmtItems->execute();
            $stmtItems->close();
        }

        // Cancel the order
        $stmtOrder = $conn->prepare("UPDATE order_received 
            SET status = ?, updated_by = ?, updated_at = NOW() 
            WHERE id = ? AND deleted_at IS NULL");
        $stmtOrder->bind_param('iii', $cancelledStatus, $userId, $orderId);
        $stmtOrder->execute();
        $stmtOrder->close();

        // Delete / release order stock reservation
        $resStmt = $conn->prepare("UPDATE order_stock_reservations
            SET status = 0, closed_reason = 'cancelled', updated_by = ?, updated_at = NOW()
            WHERE order_id = ?" . ($orderItemId > 0 ? " AND order_item_id = ?" : ""));
        if ($orderItemId > 0) {
            $resStmt->bind_param('iii', $userId, $orderId, $orderItemId);
        } else {
            $resStmt->bind_param('ii', $userId, $orderId);
        }
        $resStmt->execute();
        $resStmt->close();

        mvSyncLiveStockReservedQuantity($conn);
        $conn->commit();
        mvSyncOrderStatusToWebsite($conn, $orderId, $cancelledStatus);

        return [
            'status' => 'success',
            'message' => 'Order cancelled and reserved stock released back to inventory.',
            'order_id' => $orderId,
            'new_status' => $cancelledStatus
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/**
 * Get curated product catalog for Proforma Invoice generation & editing.
 * Includes Cat No, Pack Size, commercial Rate, and GST rate.
 */
function getPiProductCatalog(mysqli $conn): array
{
    static $cachedCatalog = null;
    if ($cachedCatalog !== null) {
        return $cachedCatalog;
    }

    $packMap = [];
    $ppsQ = $conn->query("SELECT product_id, pack_size FROM product_pack_sizes WHERE status != 3 AND TRIM(pack_size) != '' ORDER BY id DESC");
    if ($ppsQ) {
        while ($pps = $ppsQ->fetch_assoc()) {
            $pId = (int)$pps['product_id'];
            if (!isset($packMap[$pId])) {
                $packMap[$pId] = trim($pps['pack_size']);
            }
        }
    }

    $piPackMap = [];
    $pipQ = $conn->query("SELECT LOWER(TRIM(product)) AS p_name, pack_size FROM proforma_invoice_items WHERE TRIM(pack_size) != '' ORDER BY id DESC");
    if ($pipQ) {
        while ($pi = $pipQ->fetch_assoc()) {
            $pName = (string)$pi['p_name'];
            if (!isset($piPackMap[$pName])) {
                $piPackMap[$pName] = trim($pi['pack_size']);
            }
        }
    }

    $rateMap = [];
    $rQ1 = $conn->query("SELECT product_id, unit_price FROM quotation_request_items WHERE unit_price > 0 ORDER BY id DESC");
    if ($rQ1) {
        while ($r = $rQ1->fetch_assoc()) {
            $pId = (int)$r['product_id'];
            if (!isset($rateMap[$pId])) {
                $rateMap[$pId] = (float)$r['unit_price'];
            }
        }
    }
    $rQ2 = $conn->query("SELECT p.id AS product_id, pii.prod_rate FROM proforma_invoice_items pii JOIN products p ON LOWER(TRIM(p.product_name)) = LOWER(TRIM(pii.product)) WHERE pii.prod_rate > 0 ORDER BY pii.id DESC");
    if ($rQ2) {
        while ($r = $rQ2->fetch_assoc()) {
            $pId = (int)$r['product_id'];
            if (!isset($rateMap[$pId])) {
                $rateMap[$pId] = (float)$r['prod_rate'];
            }
        }
    }

    $prodSql = "SELECT p.id, p.product_name, p.product_code, p.gst_rate, u.short_name AS unit_short, u.fullname AS unit_full,
                fpc.selling_rate, fpc.mrp
                FROM products p
                LEFT JOIN standard_units u ON p.unit_id = u.id
                LEFT JOIN finance_product_commercials fpc ON fpc.product_id = p.id
                WHERE p.status = 1 AND p.deleted_at IS NULL AND TRIM(p.product_name) != ''
                ORDER BY p.product_name ASC";

    $res = $conn->query($prodSql);
    $catalog = [];
    if ($res) {
        while ($p = $res->fetch_assoc()) {
            $pId = (int)$p['id'];
            $pNameLower = strtolower(trim($p['product_name']));

            $rate = '';
            if (!empty($p['selling_rate']) && (float)$p['selling_rate'] > 0) {
                $rate = (float)$p['selling_rate'];
            } elseif (isset($rateMap[$pId])) {
                $rate = (float)$rateMap[$pId];
            } elseif (!empty($p['mrp']) && (float)$p['mrp'] > 0) {
                $rate = (float)$p['mrp'];
            }

            $packSize = '';
            if (isset($packMap[$pId]) && $packMap[$pId] !== '') {
                $packSize = $packMap[$pId];
            } elseif (isset($piPackMap[$pNameLower]) && $piPackMap[$pNameLower] !== '') {
                $packSize = $piPackMap[$pNameLower];
            } elseif (!empty($p['unit_short'])) {
                $packSize = $p['unit_short'];
            } elseif (!empty($p['unit_full'])) {
                $packSize = $p['unit_full'];
            }

            $catalog[] = [
                'id' => $pId,
                'product_name' => $p['product_name'],
                'cat_no' => $p['product_code'] ?? '',
                'pack_size' => $packSize,
                'rate' => $rate !== '' ? $rate : '',
                'gst_rate' => (!empty($p['gst_rate']) && (float)$p['gst_rate'] > 0) ? (float)$p['gst_rate'] : 18.00
            ];
        }
    }

    $cachedCatalog = $catalog;
    return $catalog;
}


