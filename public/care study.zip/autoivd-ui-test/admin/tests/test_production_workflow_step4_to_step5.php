<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

echo "======================================================================\n";
echo "   PRODUCTION WORKFLOW: STEP 4 -> STEP 5 -> STEP 6 ROUTING TEST       \n";
echo "======================================================================\n\n";

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] $message\n";
    } else {
        echo "  [PASSED] $message\n";
    }
};

$actionsPath = dirname(__DIR__) . '/workflow/bmr_bpr_actions.php';
$actionsContent = (string) file_get_contents($actionsPath);

$ajaxPath = dirname(__DIR__) . '/ajax.php';
$ajaxContent = (string) file_get_contents($ajaxPath);

$goodsIssuancePath = dirname(__DIR__) . '/pages/goods-issuance.php';
$goodsIssuanceContent = (string) file_get_contents($goodsIssuancePath);

$commonPath = dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
$commonContent = (string) file_get_contents($commonPath);

$bmrBprRequestPath = dirname(__DIR__) . '/pages/bmr-bpr-form-request.php';
$bmrBprRequestContent = (string) file_get_contents($bmrBprRequestPath);

$bmrBprIssuancePath = dirname(__DIR__) . '/pages/bmr-bpr-issuance.php';
$bmrBprIssuanceContent = (string) file_get_contents($bmrBprIssuancePath);

// TEST 1: QA/QC Issuance List must strictly exclude UPCOMING status
echo "TEST 1: Verify QA/QC issuance_list pending queue filters...\n";
$assert(
    strpos($actionsContent, "in_array(\$row['status_code'], ['SUBMITTED'], true)") !== false,
    "QA/QC pending list in bmr_bpr_actions.php must strictly filter for ['SUBMITTED'] only."
);
$assert(
    strpos($actionsContent, "in_array(\$row['status_code'], ['UPCOMING', 'SUBMITTED'], true)") === false,
    "QA/QC pending list in bmr_bpr_actions.php must NOT include 'UPCOMING' requests."
);

// TEST 2: QA/QC review_request must enforce SUBMITTED status
echo "\nTEST 2: Verify QA/QC review_request status guard...\n";
$assert(
    strpos($actionsContent, "\$previousStatus !== 'SUBMITTED'") !== false,
    "QA/QC review_request must reject any status other than 'SUBMITTED'."
);

// TEST 3: ajax.php issueBomItems & bmr_bpr_common.php must route to Step 5 with UPCOMING status
echo "\nTEST 3: Verify ajax.php issueBomItems and bmr_bpr_common.php routing contract...\n";
$assert(
    strpos($ajaxContent, "'redirect_url' => 'index.php?page=bmr-bpr-form-request'") !== false,
    "issueBomItems in ajax.php must return redirect_url => 'index.php?page=bmr-bpr-form-request'."
);
$assert(
    strpos($ajaxContent, "bmrBprEnsureRequestForMaterialRequisition(\$conn, \$reqId, \$userId);") !== false,
    "issueBomItems must trigger bmrBprEnsureRequestForMaterialRequisition."
);
$assert(
    strpos($commonContent, "status = 'UPCOMING' WHERE id = ?") !== false,
    "bmrBprEnsureRequestForMaterialRequisition must retain status as 'UPCOMING' for Step 5 queue."
);
$assert(
    strpos($commonContent, "status = 'SUBMITTED', requested_by = ?") === false,
    "bmrBprEnsureRequestForMaterialRequisition must NOT set status = 'SUBMITTED' prematurely."
);

// TEST 4: goods-issuance.php must handle redirect_url
echo "\nTEST 4: Verify goods-issuance.php frontend redirect handler...\n";
$assert(
    strpos($goodsIssuanceContent, "res.redirect_url") !== false
        && str_contains($goodsIssuanceContent, "window.location.href = res.redirect_url;"),
    "goods-issuance.php must redirect to res.redirect_url upon completed issuance."
);

// TEST 5: Production > BMR/BPR Form Request upcoming queue contract
echo "\nTEST 5: Verify Production > BMR/BPR Form Request upcoming queue handling...\n";
$assert(
    strpos($bmrBprRequestContent, "String(request.status_code || '').toUpperCase() === 'UPCOMING'") !== false,
    "bmr-bpr-form-request.php must filter upcoming widget by 'UPCOMING' status."
);
$assert(
    strpos($bmrBprRequestContent, "id=\"upcomingBmrBprWidget\"") !== false,
    "bmr-bpr-form-request.php must contain #upcomingBmrBprWidget."
);
$assert(
    strpos($bmrBprRequestContent, "id=\"upcomingBmrBprModal\"") !== false,
    "bmr-bpr-form-request.php must contain #upcomingBmrBprModal."
);
$assert(
    strpos($bmrBprRequestContent, "id=\"bmrBprRequestModal\"") !== false,
    "bmr-bpr-form-request.php must contain #bmrBprRequestModal for submitting request to QA/QC."
);

// SUMMARY
echo "\n======================================================================\n";
if ($failures !== []) {
    echo "FAILED with " . count($failures) . " errors:\n- " . implode("\n- ", $failures) . "\n";
    exit(1);
}

echo "ALL PRODUCTION WORKFLOW ROUTING TESTS PASSED SUCCESSFULLY! (0 failures)\n";
echo "======================================================================\n";
