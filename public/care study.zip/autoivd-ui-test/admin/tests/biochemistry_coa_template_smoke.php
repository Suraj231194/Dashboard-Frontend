<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/biochemistry_profiles.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';

function coaSmokeAssert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

try {
    $profiles = coaBiochemistryProfiles();
    $productIds = coaBiochemistryMappedProductIds();
    coaSmokeAssert(count($profiles) === 29, 'Expected 29 Biochemistry COA product families.');
    coaSmokeAssert(count($productIds) === 63, 'Expected 63 distinct mapped products.');
    coaSmokeAssert(coaTemplateSchemaReady($conn), 'The COA template schema is not ready.');

    $sourceRoot = dirname(__DIR__, 2) . '/BIOCHEMISTRY COA REPORT 2026';
    foreach ($profiles as $familyKey => $profile) {
        coaSmokeAssert(
            trim((string) ($profile['product_name'] ?? '')) !== '',
            "Profile {$familyKey} is missing its controlled product name."
        );
        coaSmokeAssert(
            trim((string) ($profile['product_code'] ?? '')) !== '',
            "Profile {$familyKey} is missing its controlled product code."
        );
        coaSmokeAssert(
            is_array($profile['rows'] ?? null) && count($profile['rows']) >= 8,
            "Profile {$familyKey} does not contain the expected test rows."
        );
        foreach (['IP' => 'source_ip_document', 'FG' => 'source_fg_document'] as $type => $sourceKey) {
            $sourcePath = $sourceRoot
                . '/'
                . (string) $profile['source_folder']
                . '/'
                . (string) $profile[$sourceKey];
            coaSmokeAssert(is_file($sourcePath), "{$type} source document is missing: {$sourcePath}");
        }
    }

    $templateResult = $conn->query(
        "SELECT id, coa_type, template_code, template_name, layout_json
         FROM coa_document_templates
         WHERE template_code IN (
             'COMMON_BIOCHEMISTRY_IP_COA_V01',
             'COMMON_BIOCHEMISTRY_FG_COA_V01'
         )
           AND status = 1
           AND deleted_at IS NULL"
    );
    coaSmokeAssert($templateResult !== false, 'Unable to inspect installed COA templates.');
    $templateCounts = [];
    $installedTemplates = [];
    while ($row = $templateResult->fetch_assoc()) {
        $type = (string) $row['coa_type'];
        $templateCounts[$type] = ($templateCounts[$type] ?? 0) + 1;
        $layout = coaTemplateDecodeLayout((string) $row['layout_json']);
        $installedTemplates[$type] = [
            'id' => (int) $row['id'],
            'template_code' => (string) $row['template_code'],
            'template_name' => (string) $row['template_name'],
            'layout' => $layout,
        ];
    }
    coaSmokeAssert(($templateCounts['IP'] ?? 0) === 1, 'The common IP COA template is missing.');
    coaSmokeAssert(($templateCounts['FG'] ?? 0) === 1, 'The common FG COA template is missing.');
    coaSmokeAssert(
        (string) ($installedTemplates['IP']['layout']['document']['company_address'] ?? '')
        === 'B19/A, S.I.L. Ancillary Estate, Amausi Industrial Area, Nadarganj-226008 (Lucknow)',
        'The controlled company address does not match the supplied COA header.'
    );
    $creatinineIp = coaTemplateResolveProfile($installedTemplates['IP']['layout'], 894);
    coaSmokeAssert(
        (string) ($creatinineIp['stp_reference'] ?? '') === 'BIL-IPSTP-034',
        'The source-specific Creatinine IP STP reference is incorrect.'
    );
    $albuminFg = coaTemplateResolveProfile($installedTemplates['FG']['layout'], 917);
    $triglycerideFg = coaTemplateResolveProfile($installedTemplates['FG']['layout'], 840);
    $albuminFgSpecifications = array_column($albuminFg['rows'], 'specification', 'key');
    $triglycerideFgSpecifications = array_column($triglycerideFg['rows'], 'specification', 'key');
    coaSmokeAssert(
        (string) ($albuminFgSpecifications['control_1'] ?? '') === '3.82(3.48-4.15) gm/dl',
        'The source-specific Albumin FG control specification is incorrect.'
    );
    coaSmokeAssert(
        (string) ($triglycerideFgSpecifications['standard_1'] ?? '') === '200 mg/dl (± 5mg/dl)',
        'The source-specific Triglyceride FG standard specification is incorrect.'
    );

    $mappingResult = $conn->query(
        "SELECT mapping.coa_type, COUNT(*) AS total
         FROM coa_template_product_mappings mapping
         INNER JOIN coa_document_templates template ON template.id = mapping.template_id
         WHERE template.template_code IN (
             'COMMON_BIOCHEMISTRY_IP_COA_V01',
             'COMMON_BIOCHEMISTRY_FG_COA_V01'
         )
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
           AND template.status = 1
           AND template.deleted_at IS NULL
         GROUP BY mapping.coa_type"
    );
    coaSmokeAssert($mappingResult !== false, 'Unable to inspect installed COA mappings.');
    $mappingCounts = [];
    while ($row = $mappingResult->fetch_assoc()) {
        $mappingCounts[(string) $row['coa_type']] = (int) $row['total'];
    }
    coaSmokeAssert(($mappingCounts['IP'] ?? 0) === 63, 'Expected 63 active IP mappings.');
    coaSmokeAssert(($mappingCounts['FG'] ?? 0) === 63, 'Expected 63 active FG mappings.');

    foreach (['IP', 'FG'] as $coaType) {
        $template = $installedTemplates[$coaType] ?? null;
        coaSmokeAssert(is_array($template), "The {$coaType} template layout is unavailable.");
        foreach ($productIds as $productId) {
            coaSmokeAssert(
                strtoupper((string) ($template['layout']['coa_type'] ?? '')) === $coaType,
                "Product {$productId} resolved the wrong {$coaType} layout."
            );
            $profile = coaTemplateResolveProfile($template['layout'], $productId);
            coaSmokeAssert(
                is_array($profile['rows'] ?? null),
                "Product {$productId} has no {$coaType} test profile."
            );
        }
    }

    $sampleProductId = 917;
    $sampleTemplate = $installedTemplates['IP'];
    $sampleTemplate['profile'] = coaTemplateResolveProfile($sampleTemplate['layout'], $sampleProductId);
    $fields = [
        'metadata.manufacturing_date' => '01/07/2026',
        'metadata.expiry_date' => '30/06/2028',
        'approval.decision' => 'APPROVED',
        'approval.comments' => 'Meets specification.',
        'approval.analysis_by' => 'QC Analyst',
        'approval.verified_by' => 'QC Head',
    ];
    foreach ($sampleTemplate['profile']['rows'] as $row) {
        if (($row['kind'] ?? 'test') !== 'section') {
            $fields['results.' . $row['key']] = 'Complies';
        }
    }
    $payload = coaTemplateSanitizePayload(
        $sampleTemplate['profile'],
        ['schema_version' => 1, 'fields' => $fields]
    );
    $form = coaTemplatePrepareForm(
        $sampleTemplate,
        'IP',
        [
            'coa_number' => 'BIPL-COA-IP-TEST',
            'batch_number' => 'ALB-TEST',
            'batch_size' => '100 ml',
            'testing_date' => '30/07/2026',
        ],
        $payload
    );
    $editableHtml = coaTemplateRender($form, true);
    $readonlyHtml = coaTemplateRender($form, false);
    coaSmokeAssert(
        str_contains($editableHtml, 'data-coa-field="results.physical_checks"'),
        'The editable COA renderer did not create result inputs.'
    );
    coaSmokeAssert(
        str_contains($readonlyHtml, 'BIPL-F-COA-01')
        && str_contains($readonlyHtml, 'ALBUMIN Reagent')
        && str_contains($readonlyHtml, 'Meets specification.'),
        'The saved COA renderer omitted controlled or entered content.'
    );

    require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
    $pdfOptions = new Dompdf\Options();
    $pdfOptions->set('isRemoteEnabled', false);
    $pdfOptions->set('isHtml5ParserEnabled', true);
    $pdfOptions->set('defaultFont', 'Helvetica');
    $pdfOptions->set('defaultMediaType', 'print');
    $pdf = new Dompdf\Dompdf($pdfOptions);
    $pdf->setPaper('A4', 'portrait');
    $pdf->loadHtml(
        '<!DOCTYPE html><html><head><meta charset="UTF-8">'
        . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
        . '</head><body>' . $readonlyHtml . '</body></html>',
        'UTF-8'
    );
    $pdf->render();
    coaSmokeAssert(
        strlen($pdf->output()) > 5000,
        'The structured COA PDF output is unexpectedly empty.'
    );
    $pdfPageCount = $pdf->getCanvas()->get_page_count();
    coaSmokeAssert(
        $pdfPageCount === 1,
        "The one-page Albumin source template rendered as {$pdfPageCount} PDF pages."
    );

    $hbaTemplate = $installedTemplates['IP'];
    $hbaTemplate['profile'] = coaTemplateResolveProfile($hbaTemplate['layout'], 881);
    $hbaForm = coaTemplatePrepareForm(
        $hbaTemplate,
        'IP',
        [
            'coa_number' => 'BIPL-COA-IP-TEST',
            'batch_number' => 'HBA-TEST',
            'batch_size' => '100 ml',
            'testing_date' => '30/07/2026',
        ]
    );
    $hbaPdf = new Dompdf\Dompdf($pdfOptions);
    $hbaPdf->setPaper('A4', 'portrait');
    $hbaPdf->loadHtml(
        '<!DOCTYPE html><html><head><meta charset="UTF-8">'
        . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
        . '</head><body>' . coaTemplateRender($hbaForm, false) . '</body></html>',
        'UTF-8'
    );
    $hbaPdf->render();
    $hbaPageCount = $hbaPdf->getCanvas()->get_page_count();
    coaSmokeAssert(
        $hbaPageCount === 2,
        "The two-page HbA1C source template rendered as {$hbaPageCount} PDF pages."
    );

    echo "Biochemistry COA smoke test passed: 29 families, 63 products, 126 mappings.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
