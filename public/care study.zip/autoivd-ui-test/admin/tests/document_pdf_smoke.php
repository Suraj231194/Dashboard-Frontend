<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/document_pdf_helpers.php';

$rows = '';
for ($index = 1; $index <= 90; $index++) {
    $rows .= '<tr><td>' . $index . '</td><td>'
        . htmlspecialchars('Long report row <' . $index . '> & value', ENT_QUOTES, 'UTF-8')
        . '</td></tr>';
}
$html = '<!doctype html><html><head><meta charset="UTF-8"><style>'
    . '@page{size:A4 portrait;margin:20px}table{width:100%;border-collapse:collapse}'
    . 'td{border:1px solid #111;padding:6px}tr{page-break-inside:avoid}'
    . '</style></head><body><h1>Server PDF smoke</h1><table>' . $rows . '</table></body></html>';
$pdf = documentPdfBuild($html);

$failures = [];
if (!str_starts_with($pdf, '%PDF-')) {
    $failures[] = 'Dompdf output does not have a valid PDF signature.';
}
if (strlen($pdf) < 2000) {
    $failures[] = 'Dompdf output is unexpectedly small.';
}
if (substr_count($pdf, '/Type /Page') < 2) {
    $failures[] = 'Long report content did not produce multiple PDF pages.';
}

$legacyTemplates = [
    'sample_advice_template.php',
    'coa_template_print.php',
    'coa_record_template.php',
    'daily_report_template.php',
    'daily_report_bulk_template.php',
    'material_requisition_template.php',
    'transfer_ticket_template.php',
];
foreach ($legacyTemplates as $template) {
    $source = file_get_contents(dirname(__DIR__) . '/pages/' . $template);
    if ($source === false || str_contains($source, 'html2pdf.bundle.min.js')) {
        $failures[] = "{$template} still depends on html2pdf.js.";
    }
    if ($source === false || !str_contains($source, 'documentPdfStream')) {
        $failures[] = "{$template} does not use the shared server PDF renderer.";
    }
}

$rapidSource = (string) file_get_contents(dirname(__DIR__) . '/pages/rapid.php');
if (str_contains($rapidSource, 'html2pdf.bundle.min.js')) {
    $failures[] = 'rapid.php still loads the public html2pdf.js dependency.';
}
if (
    !str_contains($rapidSource, 'daily_report_bulk_template.php')
    || !str_contains($rapidSource, "formData.append('csrf_token'")
    || str_contains($rapidSource, 'generatePdfManually')
) {
    $failures[] = 'Rapid bulk PDF download is not routed through the protected server PDF endpoint.';
}

$rapidBulkSource = (string) file_get_contents(dirname(__DIR__) . '/pages/daily_report_bulk_template.php');
if (
    !str_contains($rapidBulkSource, "documentPdfRequireAnyPermission")
    || !str_contains($rapidBulkSource, "hash_equals")
    || !str_contains($rapidBulkSource, "array_unique")
    || !str_contains($rapidBulkSource, 'count($requestedIds) > 250')
    || !str_contains($rapidBulkSource, "documentPdfStream")
) {
    $failures[] = 'The Rapid bulk PDF endpoint is missing permission, CSRF, selection, limit, or streaming controls.';
}

$ajaxSource = (string) file_get_contents(dirname(__DIR__) . '/ajax.php');
if (str_contains($ajaxSource, 'generatePdfManually')) {
    $failures[] = 'The obsolete external Rapid PDF generator is still reachable through ajax.php.';
}

$globalCssSource = (string) file_get_contents(dirname(__DIR__, 2) . '/assets/css/demo.css');
if (
    !str_contains($globalCssSource, '.dropdown-menu.show')
    || !str_contains($globalCssSource, '.bs-container')
    || !str_contains($globalCssSource, 'z-index: 1085 !important')
) {
    $failures[] = 'The global dropdown layer does not cover Bootstrap and Bootstrap Select overlays.';
}

$helperSource = (string) file_get_contents(dirname(__DIR__) . '/document_pdf_helpers.php');
if (
    !str_contains($helperSource, 'isLoggedIn()')
    || !str_contains($helperSource, "http_response_code(401)")
    || !str_contains($helperSource, "http_response_code(403)")
    || !str_contains($helperSource, "http_response_code(422)")
    || !str_contains($helperSource, "isRemoteEnabled', false")
) {
    $failures[] = 'The shared PDF authentication, validation, or remote-asset controls are incomplete.';
}

if ($failures) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "PASS: server PDF signature, pagination, protected bulk download, global overlays, and six template dependency checks.\n";
