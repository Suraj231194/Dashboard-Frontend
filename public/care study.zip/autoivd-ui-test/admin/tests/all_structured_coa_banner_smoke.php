<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';

function allStructuredCoaAssert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

try {
    $ipTemplateCodes = [
        'COMMON_BIOCHEMISTRY_IP_COA_V01',
        'COMMON_URINE_STRIP_IP_COA_V01',
        'COMMON_RAPID_TEST_IP_COA_V01',
        'COMMON_SEROLOGY_IP_COA_V01',
    ];
    $fgTemplateCodes = [
        'COMMON_BIOCHEMISTRY_FG_COA_V01',
        'COMMON_URINE_STRIP_FG_COA_V01',
        'COMMON_RAPID_TEST_FG_COA_V01',
        'COMMON_SEROLOGY_FG_COA_V01',
    ];
    $quoteCodes = static function (array $codes) use ($conn): string {
        return implode(',', array_map(
            static fn(string $code): string => "'" . $conn->real_escape_string($code) . "'",
            $codes
        ));
    };
    $ipCodeSql = $quoteCodes($ipTemplateCodes);
    $fgCodeSql = $quoteCodes($fgTemplateCodes);

    $mappedResult = $conn->query(
        "SELECT ip_mapping.product_id, product.product_name,
                COALESCE(product.inventory_group, category.inventory_group, 1) AS inventory_group,
                ip_template.id AS ip_template_id,
                ip_template.template_code AS ip_template_code,
                fg_template.id AS fg_template_id,
                fg_template.template_code AS fg_template_code
         FROM coa_template_product_mappings ip_mapping
         INNER JOIN coa_document_templates ip_template
            ON ip_template.id = ip_mapping.template_id
           AND ip_template.template_code IN ({$ipCodeSql})
           AND ip_template.coa_type = 'IP'
           AND ip_template.status = 1
           AND ip_template.deleted_at IS NULL
         INNER JOIN coa_template_product_mappings fg_mapping
            ON fg_mapping.product_id = ip_mapping.product_id
           AND fg_mapping.coa_type = 'FG'
           AND fg_mapping.status = 1
           AND fg_mapping.deleted_at IS NULL
         INNER JOIN coa_document_templates fg_template
            ON fg_template.id = fg_mapping.template_id
           AND fg_template.template_code IN ({$fgCodeSql})
           AND fg_template.coa_type = 'FG'
           AND fg_template.status = 1
           AND fg_template.deleted_at IS NULL
         INNER JOIN products product
            ON product.id = ip_mapping.product_id
           AND product.status != 3
           AND product.deleted_at IS NULL
         LEFT JOIN product_categories category ON category.id = product.category_id
         WHERE ip_mapping.coa_type = 'IP'
           AND ip_mapping.status = 1
           AND ip_mapping.deleted_at IS NULL
         ORDER BY ip_mapping.product_id"
    );
    allStructuredCoaAssert($mappedResult !== false, 'Unable to load structured COA mappings.');

    $products = [];
    while ($row = $mappedResult->fetch_assoc()) {
        $products[(int) $row['product_id']] = $row;
    }
    allStructuredCoaAssert(count($products) === 118, 'Expected 118 mapped structured COA products.');

    $variantByPrefix = [
        'COMMON_BIOCHEMISTRY_' => 'biochemistry',
        'COMMON_URINE_STRIP_' => 'urine_strip',
        'COMMON_RAPID_TEST_' => 'rapid_test',
        'COMMON_SEROLOGY_' => 'serology',
    ];
    $unselectableFgProducts = [];
    $representativeProducts = [];
    foreach ($products as $productId => $product) {
        if ((int) $product['inventory_group'] !== 1) {
            $unselectableFgProducts[] = $productId;
        }
        foreach (['IP', 'FG'] as $coaType) {
            $expectedCode = (string) $product[strtolower($coaType) . '_template_code'];
            if (!isset($representativeProducts[$expectedCode])) {
                $representativeProducts[$expectedCode] = $productId;
            }
        }
    }
    if ($unselectableFgProducts !== []) {
        $fgPageSource = file_get_contents(dirname(__DIR__) . '/pages/fg-coa-generation.php');
        allStructuredCoaAssert(
            is_string($fgPageSource)
            && str_contains($fgPageSource, "data-workflow-source', '1"),
            'Mapped products need the FG workflow-source dropdown fallback: '
                . implode(', ', $unselectableFgProducts)
        );
    }

    foreach ($representativeProducts as $expectedCode => $productId) {
        $coaType = str_contains($expectedCode, '_IP_COA_') ? 'IP' : 'FG';
            $template = coaTemplateResolveMappedTemplate($conn, $productId, $coaType);
            allStructuredCoaAssert(
                is_array($template),
                "Product {$productId} did not resolve its {$coaType} COA template."
            );
            allStructuredCoaAssert(
                (string) $template['template_code'] === $expectedCode,
                "Product {$productId} resolved the wrong {$coaType} COA template."
            );
            $expectedVariant = '';
            foreach ($variantByPrefix as $prefix => $variant) {
                if (str_starts_with($expectedCode, $prefix)) {
                    $expectedVariant = $variant;
                    break;
                }
            }
            allStructuredCoaAssert(
                $expectedVariant !== ''
                && (string) ($template['layout']['renderer_variant'] ?? '') === $expectedVariant,
                "Product {$productId} resolved the wrong {$coaType} renderer variant."
            );
    }

    $ipQueueResult = $conn->query(
        "SELECT wi.id, request_row.product_id
         FROM bmr_bpr_work_items wi
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = wi.request_id
           AND request_row.product_id IS NOT NULL
           AND request_row.deleted_at IS NULL
         WHERE wi.form_type = 'BMR'
           AND wi.status IN ('IN_PROCESS', 'COMPLETE')
           AND wi.deleted_at IS NULL
           AND wi.id = (
               SELECT MIN(eligible.id)
               FROM bmr_bpr_work_items eligible
               WHERE eligible.request_id = wi.request_id
                 AND eligible.form_type = 'BMR'
                 AND eligible.status IN ('IN_PROCESS', 'COMPLETE')
                 AND eligible.deleted_at IS NULL
           )
           AND NOT EXISTS (
               SELECT 1
               FROM ip_coa_generation existing_ip
               LEFT JOIN bmr_bpr_work_items source_work_item
                  ON source_work_item.id = existing_ip.source_bmr_work_item_id
               WHERE (
                       existing_ip.source_bmr_bpr_request_id = wi.request_id
                       OR (
                           existing_ip.source_bmr_bpr_request_id IS NULL
                           AND source_work_item.request_id = wi.request_id
                       )
                   )
                 AND existing_ip.deleted_at IS NULL
           )"
    );
    allStructuredCoaAssert($ipQueueResult !== false, 'Unable to inspect the Incoming IP COA queue.');
    $ipQueueProducts = [];
    while ($row = $ipQueueResult->fetch_assoc()) {
        $productId = (int) $row['product_id'];
        if (isset($products[$productId])) {
            $ipQueueProducts[$productId] = (int) $row['id'];
        }
    }

    $fgQueueResult = $conn->query(
        "SELECT ip.id, ip.product_id
         FROM ip_coa_generation ip
         LEFT JOIN fg_coa_generation fg
            ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
         WHERE ip.product_id IS NOT NULL
           AND ip.source_bmr_work_item_id IS NOT NULL
           AND ip.deleted_at IS NULL
           AND fg.id IS NULL"
    );
    allStructuredCoaAssert($fgQueueResult !== false, 'Unable to inspect the Incoming FG COA queue.');
    $fgQueueProducts = [];
    while ($row = $fgQueueResult->fetch_assoc()) {
        $productId = (int) $row['product_id'];
        if (isset($products[$productId])) {
            $fgQueueProducts[$productId] = (int) $row['id'];
        }
    }

    $missingIp = array_diff(array_keys($products), array_keys($ipQueueProducts));
    $missingFg = array_diff(array_keys($products), array_keys($fgQueueProducts));
    allStructuredCoaAssert(
        $missingIp === [],
        'Incoming IP COA is missing mapped products: ' . implode(', ', $missingIp)
    );
    allStructuredCoaAssert(
        $missingFg === [],
        'Incoming FG COA is missing mapped products: ' . implode(', ', $missingFg)
    );

    $markerResult = $conn->query(
        "SELECT request_row.remarks,
                COUNT(DISTINCT request_row.id) AS requests,
                COUNT(DISTINCT work_item.id) AS work_items,
                SUM(CASE WHEN work_item.template_id IS NOT NULL THEN 1 ELSE 0 END)
                    AS work_items_with_bmr_template
         FROM bmr_bpr_requests request_row
         INNER JOIN bmr_bpr_work_items work_item
            ON work_item.request_id = request_row.id
           AND work_item.form_type = 'BMR'
           AND work_item.deleted_at IS NULL
         WHERE request_row.remarks IN (
             'Common structured COA IP banner acceptance record.',
             'Common structured COA FG banner acceptance record.'
         )
           AND request_row.deleted_at IS NULL
         GROUP BY request_row.remarks"
    );
    allStructuredCoaAssert($markerResult !== false, 'Unable to inspect appended COA source records.');
    $markerCounts = [];
    while ($row = $markerResult->fetch_assoc()) {
        $markerCounts[(string) $row['remarks']] = $row;
    }
    $ipMarker = $markerCounts['Common structured COA IP banner acceptance record.'] ?? [];
    $fgMarker = $markerCounts['Common structured COA FG banner acceptance record.'] ?? [];
    allStructuredCoaAssert(
        (int) ($ipMarker['requests'] ?? 0) === 40
        && (int) ($ipMarker['work_items'] ?? 0) === 40,
        'Expected 40 appended IP-banner source requests and work items.'
    );
    allStructuredCoaAssert(
        (int) ($fgMarker['requests'] ?? 0) === 105
        && (int) ($fgMarker['work_items'] ?? 0) === 105,
        'Expected 105 appended FG-banner source requests and work items.'
    );
    allStructuredCoaAssert(
        (int) ($ipMarker['work_items_with_bmr_template'] ?? 0) === 0
        && (int) ($fgMarker['work_items_with_bmr_template'] ?? 0) === 0,
        'A source-only work item unexpectedly changed BMR template behavior.'
    );

    $sourceRequestResult = $conn->query(
        "SELECT id
         FROM bmr_bpr_requests
         WHERE remarks IN (
             'Common structured COA IP banner acceptance record.',
             'Common structured COA FG banner acceptance record.',
             'Common Serology FG COA template banner acceptance record.'
         )
           AND deleted_at IS NULL"
    );
    allStructuredCoaAssert($sourceRequestResult !== false, 'Unable to inspect COA-only request IDs.');
    $sourceRequestIds = [];
    while ($row = $sourceRequestResult->fetch_assoc()) {
        $sourceRequestIds[(int) $row['id']] = true;
    }
    foreach (bmrBprProductionRows($conn) as $productionRow) {
        allStructuredCoaAssert(
            !isset($sourceRequestIds[(int) $productionRow['request_id']]),
            'A COA-only source record leaked into the Production BMR/BPR list.'
        );
    }

    $fgSourceResult = $conn->query(
        "SELECT COUNT(*) AS sources,
                SUM(CASE WHEN ip.coa_template_id = mapping.template_id THEN 1 ELSE 0 END)
                    AS correct_ip_templates,
                SUM(CASE WHEN fg.id IS NOT NULL THEN 1 ELSE 0 END) AS completed_fg_rows
         FROM ip_coa_generation ip
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = ip.source_bmr_bpr_request_id
           AND request_row.remarks = 'Common structured COA FG banner acceptance record.'
           AND request_row.deleted_at IS NULL
         INNER JOIN coa_template_product_mappings mapping
            ON mapping.product_id = ip.product_id
           AND mapping.coa_type = 'IP'
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         LEFT JOIN fg_coa_generation fg
            ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
         WHERE ip.deleted_at IS NULL"
    );
    allStructuredCoaAssert($fgSourceResult !== false, 'Unable to validate FG-banner IP sources.');
    $fgSource = $fgSourceResult->fetch_assoc();
    allStructuredCoaAssert(
        (int) ($fgSource['sources'] ?? 0) === 105
        && (int) ($fgSource['correct_ip_templates'] ?? 0) === 105,
        'An appended FG-banner source is missing its correct mapped IP template.'
    );
    allStructuredCoaAssert(
        (int) ($fgSource['completed_fg_rows'] ?? 0) === 0,
        'An appended FG-banner source was unexpectedly completed.'
    );

    echo "All structured COA banner smoke test passed: 118 products, 236 mappings, "
        . "118 IP-banner products, 118 FG-banner products, "
        . "40 appended IP sources and 105 appended FG sources.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
