<?php

declare(strict_types=1);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '1');

echo "=== HRMS Self-Service & Notifications Test ===\n";

define('HRMS_CONTEXT', true);
require_once __DIR__ . '/../hrms/hrms_common.php';

// 1. Check hrmsSendLeaveTeamNotification function exists
assert(function_exists('hrmsSendLeaveTeamNotification'), 'hrmsSendLeaveTeamNotification function must exist.');
echo "PASS: hrmsSendLeaveTeamNotification function defined.\n";

// 2. Check invalid team email handling
$connMock = mysqli_init();
$result = hrmsSendLeaveTeamNotification($connMock, 999999, 'invalid-email');
assert($result === false, 'Invalid email must return false safely without exception.');
echo "PASS: Invalid team email rejected gracefully.\n";

// 3. Check hrms-api.php source code contains required actions
$apiSource = file_get_contents(__DIR__ . '/../hrms-api.php');
assert(str_contains($apiSource, "'update_my_profile'"), 'hrms-api.php must handle update_my_profile.');
assert(str_contains($apiSource, "'upload_profile_photo'"), 'hrms-api.php must handle upload_profile_photo.');
assert(str_contains($apiSource, "'remove_profile_photo'"), 'hrms-api.php must handle remove_profile_photo.');
assert(str_contains($apiSource, 'hrmsSendLeaveTeamNotification'), 'hrms-api.php must trigger hrmsSendLeaveTeamNotification.');
echo "PASS: hrms-api.php contains all 3 new action handlers.\n";

assert(str_contains($apiSource, "'link_employee_user'"), 'hrms-api.php must handle link_employee_user.');
assert(str_contains($apiSource, "existing_user_id"), 'hrms-api.php must support existing_user_id in onboard_employee.');
echo "PASS: hrms-api.php contains user linking action and onboarding support.\n";

// 4. Check employee-master.php contains onboarding user linking selector
$masterSource = file_get_contents(__DIR__ . '/../pages/employee-master.php');
assert(str_contains($masterSource, "onboardingExistingUser"), 'employee-master.php must have onboardingExistingUser select.');
echo "PASS: employee-master.php contains onboarding existing user selector.\n";

echo "ALL ASSERTIONS PASSED (100%)\n";
