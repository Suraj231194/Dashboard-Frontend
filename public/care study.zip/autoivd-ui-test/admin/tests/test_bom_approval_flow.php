<?php
/**
 * Automated Verification Script for BOM Flow Lifecycle
 * Tests:
 * 1. Reference BOM candidate search (same product / same category)
 * 2. Item loading with blank quantities
 * 3. Draft creation & audit logging
 * 4. Production exclusion for unapproved BOMs
 * 5. Submission for approval
 * 6. Approver review, rejection with reason, and approval
 * 7. Production inclusion for approved BOMs
 * 8. Cleanup of test records
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';

echo "======================================================================\n";
echo "           END-TO-END BOM APPROVAL & CLONING FLOW TEST                \n";
echo "======================================================================\n\n";

$passCount = 0;
$failCount = 0;

$runTest = function (string $name, callable $fn) use (&$passCount, &$failCount) {
    echo "TEST: $name ... ";
    try {
        $result = $fn();
        if ($result === true || $result === null) {
            echo "[PASSED]\n";
            $passCount++;
        } else {
            echo "[FAILED]: $result\n";
            $failCount++;
        }
    } catch (Throwable $e) {
        echo "[ERROR]: " . $e->getMessage() . "\n";
        $failCount++;
    }
};

// 1. Find an existing approved BOM as reference source
$refBomRes = $conn->query("SELECT bm.id, bm.finished_product_id, bm.category_id, p.product_name, p.product_code 
    FROM bom_master bm 
    JOIN products p ON p.id = bm.finished_product_id 
    WHERE bm.status = 1 AND bm.bom_status = 'APPROVED' 
    ORDER BY bm.id ASC LIMIT 1");
$refBom = $refBomRes->fetch_assoc();
$sourceBomId = (int)$refBom['id'];
$sourceCatId = (int)$refBom['category_id'];

// 2. Find a target product in the same category that does NOT have a BOM
$targetRes = $conn->query("SELECT p.id, p.product_name, p.product_code 
    FROM products p 
    WHERE p.category_id = $sourceCatId 
      AND p.id NOT IN (SELECT finished_product_id FROM bom_master WHERE status = 1 AND deleted_at IS NULL)
      AND p.status = 1 
    LIMIT 1");
$targetProd = $targetRes ? $targetRes->fetch_assoc() : null;

if (!$targetProd) {
    // If none in same category, pick any active product without BOM
    $targetRes = $conn->query("SELECT p.id, p.product_name, p.product_code, p.category_id 
        FROM products p 
        WHERE p.id NOT IN (SELECT finished_product_id FROM bom_master WHERE status = 1 AND deleted_at IS NULL)
          AND p.status = 1 
        LIMIT 1");
    $targetProd = $targetRes->fetch_assoc();
}

$targetProductId = (int)$targetProd['id'];
$targetCatId = (int)($targetProd['category_id'] ?? $sourceCatId);

echo "Source Reference BOM: #$sourceBomId ({$refBom['product_name']})\n";
echo "Target Product:       #$targetProductId ({$targetProd['product_name']})\n\n";

$createdTestBomId = 0;

// Test 1: Candidate Reference Search
$runTest("1. Find reference BOM candidates for target product", function () use ($conn, $targetProductId, $sourceBomId) {
    $candidates = findReferenceBomsForProduct($conn, $targetProductId);
    if (empty($candidates)) {
        return "No reference BOM candidates found";
    }
    echo "(" . count($candidates) . " candidate(s) found) ";
    return true;
});

// Test 2: Verify target product currently has NO production BOM
$runTest("2. Verify target product has NO active production BOM", function () use ($conn, $targetProductId) {
    $stmt = $conn->prepare("SELECT id FROM bom_master WHERE finished_product_id = ? AND status = 1 AND bom_status = 'APPROVED' AND deleted_at IS NULL");
    $stmt->bind_param('i', $targetProductId);
    $stmt->execute();
    $res = $stmt->get_result();
    $count = $res->num_rows;
    $stmt->close();
    if ($count > 0) {
        return "Target product already has an approved BOM";
    }
    return true;
});

// Test 3: Create DRAFT Cloned BOM with components
$runTest("3. Create DRAFT Cloned BOM via workflow", function () use ($conn, $targetProductId, $targetCatId, $sourceBomId, &$createdTestBomId) {
    $bomName = "TEST CLONED BOM - " . date('YmdHis');
    $userId = 1;
    $sourceType = 'CLONED';

    $insert = $conn->prepare("INSERT INTO bom_master 
        (name, category_id, finished_product_id, bom_type, descriptions, status, bom_status, source_type, source_bom_id, created_by, created_at)
        VALUES (?, ?, ?, 4, 'Automated Test Cloned BOM', 1, 'DRAFT', ?, ?, ?, NOW())");
    $insert->bind_param('siisii', $bomName, $targetCatId, $targetProductId, $sourceType, $sourceBomId, $userId);
    $insert->execute();
    $createdTestBomId = $conn->insert_id;
    $insert->close();

    if ($createdTestBomId <= 0) {
        return "Failed to insert draft BOM";
    }

    // Add 2 test items
    $itemStmt = $conn->prepare("INSERT INTO bom_items (bom_id, raw_product_category_id, raw_product_id, qty_unit_id, qty_per_unit, status, created_by, created_at)
        SELECT ?, raw_product_category_id, raw_product_id, qty_unit_id, 2.500, 1, 1, NOW()
        FROM bom_items WHERE bom_id = ? AND status = 1 LIMIT 2");
    $itemStmt->bind_param('ii', $createdTestBomId, $sourceBomId);
    $itemStmt->execute();
    $itemStmt->close();

    // Log history
    logBomApprovalHistory($conn, $createdTestBomId, 'CREATED', null, 'DRAFT', "Cloned from BOM #$sourceBomId", $userId);

    echo "(New BOM ID: #$createdTestBomId) ";
    return true;
});

// Test 4: Verify DRAFT BOM is NOT visible to production
$runTest("4. Verify DRAFT BOM is EXCLUDED from production/material-requisition", function () use ($conn, $targetProductId) {
    $stmt = $conn->prepare("SELECT id FROM bom_master WHERE finished_product_id = ? AND status = 1 AND bom_status = 'APPROVED' AND deleted_at IS NULL");
    $stmt->bind_param('i', $targetProductId);
    $stmt->execute();
    $count = $stmt->get_result()->num_rows;
    $stmt->close();
    if ($count > 0) {
        return "Draft BOM was incorrectly included in production query";
    }
    return true;
});

// Test 5: Submit for approval
$runTest("5. Submit BOM for Approval (DRAFT -> PENDING_APPROVAL)", function () use ($conn, $createdTestBomId) {
    $stmt = $conn->prepare("UPDATE bom_master SET bom_status = 'PENDING_APPROVAL' WHERE id = ?");
    $stmt->bind_param('i', $createdTestBomId);
    $stmt->execute();
    $stmt->close();

    logBomApprovalHistory($conn, $createdTestBomId, 'SUBMITTED', 'DRAFT', 'PENDING_APPROVAL', 'Submitted for review', 1);

    // Verify pending count query
    $cRes = $conn->query("SELECT COUNT(*) FROM bom_master WHERE bom_status = 'PENDING_APPROVAL' AND status = 1 AND deleted_at IS NULL");
    $pendingTotal = (int)$cRes->fetch_row()[0];
    if ($pendingTotal < 1) {
        return "Pending count is 0 after submission";
    }
    echo "(Pending queue count: $pendingTotal) ";
    return true;
});

// Test 6: Rejection with Mandatory Reason
$runTest("6. Reject BOM with mandatory reason (PENDING -> REJECTED)", function () use ($conn, $createdTestBomId) {
    $reason = "Component ratio exceeds batch limit. Please re-adjust.";
    $stmt = $conn->prepare("UPDATE bom_master SET bom_status = 'REJECTED', reason = ? WHERE id = ?");
    $stmt->bind_param('si', $reason, $createdTestBomId);
    $stmt->execute();
    $stmt->close();

    logBomApprovalHistory($conn, $createdTestBomId, 'REJECTED', 'PENDING_APPROVAL', 'REJECTED', $reason, 1);

    // Check status in DB
    $res = $conn->query("SELECT bom_status, reason FROM bom_master WHERE id = $createdTestBomId")->fetch_assoc();
    if ($res['bom_status'] !== 'REJECTED' || $res['reason'] !== $reason) {
        return "Rejection status or reason mismatch";
    }
    return true;
});

// Test 7: Re-submit and APPROVE BOM
$runTest("7. Re-submit and APPROVE BOM (REJECTED -> APPROVED)", function () use ($conn, $createdTestBomId) {
    $comment = "Recipe verified by QA. Approved for production.";
    $approverId = 1;
    $stmt = $conn->prepare("UPDATE bom_master SET bom_status = 'APPROVED', approved_by = ?, approved_at = NOW(), reason = NULL WHERE id = ?");
    $stmt->bind_param('ii', $approverId, $createdTestBomId);
    $stmt->execute();
    $stmt->close();

    logBomApprovalHistory($conn, $createdTestBomId, 'APPROVED', 'REJECTED', 'APPROVED', $comment, $approverId);

    $res = $conn->query("SELECT bom_status, approved_by, approved_at, reason FROM bom_master WHERE id = $createdTestBomId")->fetch_assoc();
    if ($res['bom_status'] !== 'APPROVED' || (int)$res['approved_by'] !== 1 || empty($res['approved_at']) || $res['reason'] !== null) {
        return "Approval status update failed in database";
    }
    return true;
});

// Test 8: Verify APPROVED BOM is now AVAILABLE in production & material requisition
$runTest("8. Verify APPROVED BOM is now AVAILABLE for Material Requisition", function () use ($conn, $targetProductId, $createdTestBomId) {
    $stmt = $conn->prepare("SELECT bm.id, bm.name 
        FROM bom_master bm 
        WHERE bm.finished_product_id = ? AND bm.status = 1 AND bm.bom_status = 'APPROVED' AND bm.deleted_at IS NULL");
    $stmt->bind_param('i', $targetProductId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || (int)$row['id'] !== $createdTestBomId) {
        return "Approved BOM not found via production query";
    }
    return true;
});

// Test 9: Verify complete audit history trail
$runTest("9. Verify complete audit trail in bom_approval_history", function () use ($conn, $createdTestBomId) {
    $res = $conn->query("SELECT action, from_status, to_status, comments FROM bom_approval_history WHERE bom_master_id = $createdTestBomId ORDER BY id ASC");
    $history = [];
    while ($r = $res->fetch_assoc()) {
        $history[] = $r['action'] . " (" . ($r['from_status'] ?: 'NULL') . " -> " . $r['to_status'] . ")";
    }
    if (count($history) < 4) {
        return "Expected at least 4 history entries (CREATED, SUBMITTED, REJECTED, APPROVED), got " . count($history);
    }
    echo "\n   Audit actions: " . implode(" -> ", $history) . "\n   ";
    return true;
});

// Cleanup test records
$runTest("10. Cleanup test records", function () use ($conn, $createdTestBomId) {
    $conn->query("DELETE FROM bom_items WHERE bom_id = $createdTestBomId");
    $conn->query("DELETE FROM bom_approval_history WHERE bom_master_id = $createdTestBomId");
    $conn->query("DELETE FROM bom_master WHERE id = $createdTestBomId");
    return true;
});

echo "\n======================================================================\n";
echo "SUMMARY: Passed: $passCount, Failed: $failCount\n";
echo "======================================================================\n";
