<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$admin = dirname(__DIR__);
$functions = (string) file_get_contents($admin . '/functions.php');
$appearancePage = (string) file_get_contents($admin . '/pages/appearance.php');
$appearanceSync = (string) file_get_contents($admin . '/sync_appearance.php');
$header = (string) file_get_contents($admin . '/layout/header.php');
$theme = (string) file_get_contents(dirname($admin) . '/assets/css/theme.css');
$customScript = (string) file_get_contents(dirname($admin) . '/assets/js/custom-script.js');
$purchasePage = (string) file_get_contents($admin . '/pages/purchase-management.php');
$usersPage = (string) file_get_contents($admin . '/pages/users.php');
$inboundQualityPage = (string) file_get_contents($admin . '/pages/raw-material-packing-material.php');
$stockInwardsPage = (string) file_get_contents($admin . '/pages/stock-inwards.php');
$ajax = (string) file_get_contents($admin . '/ajax.php');
$lowStocksPage = (string) file_get_contents($admin . '/pages/low-stocks.php');
$saPage = (string) file_get_contents($admin . '/pages/sa-generation.php');
$coaPage = (string) file_get_contents($admin . '/pages/coa-generation.php');
$ipCoaPage = (string) file_get_contents($admin . '/pages/ip-coa-generation.php');
$calendarPage = (string) file_get_contents($admin . '/pages/annual-calendar.php');
$calendarApi = (string) file_get_contents($admin . '/hrms/annual_calendar_api.php');
$sidebar = (string) file_get_contents($admin . '/layout/sidebar.php');
$profilePage = (string) file_get_contents($admin . '/pages/profile.php');
$employeeMasterPage = (string) file_get_contents($admin . '/pages/employee-master.php');
$payrollAdvancesPage = (string) file_get_contents($admin . '/pages/payroll-advances.php');
$rapidPage = (string) file_get_contents($admin . '/pages/rapid.php');
$attendancePage = (string) file_get_contents($admin . '/pages/attendance-management.php');
$piRequestsPage = (string) file_get_contents($admin . '/pages/pi-requests.php');
$piGeneratorPage = (string) file_get_contents($admin . '/pages/pi-generator.php');
$adminIndex = (string) file_get_contents($admin . '/index.php');
$syncAjax = (string) file_get_contents($admin . '/syncAjax.php');
$bulkSync = (string) file_get_contents($admin . '/sync/BulkEntitySyncHandler.php');
$poTemplate = (string) file_get_contents($admin . '/pages/purchase_order_template.php');
$rawPoTemplate = (string) file_get_contents($admin . '/pages/purchase_order_raw_template.php');
$fontMigration = (string) file_get_contents($admin . '/migrations/2026_09_15_002_readable_default_font_size_pending.sql');
$migrationRunner = (string) file_get_contents($admin . '/migrations/execute_all_pending.php');

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$assert(
    str_contains($functions, "'base_font_size' => 15")
        && str_contains($appearancePage, "base_font_size: 15")
        && str_contains($appearancePage, 'min="12" max="18" value="15"')
        && str_contains($appearanceSync, 'DEFAULT 15')
        && str_contains($theme, '--ui-base-font-size: 15px;'),
    'The shared readable font default must be 15px while retaining the configurable 12-18px range.'
);
$assert(
    str_contains($usersPage, 'const hasChanges = roleWizardHasChanges();')
        && str_contains($usersPage, "$('#roleWizardFinishBtn').prop('hidden', step !== 4 || hasChanges)")
        && str_contains($employeeMasterPage, 'id="bankFields"')
        && str_contains($employeeMasterPage, "document.querySelectorAll('.bank-required')")
        && str_contains($payrollAdvancesPage, "dropdownParent: jQuery('#recordAdvanceModal')")
        && str_contains($payrollAdvancesPage, ".prop('disabled',!type.value).trigger('change')"),
    'Role dirty state, onboarding bank fields, and the Advance Salary employee selector must remain functional.'
);
$assert(
    str_contains($usersPage, "loadRoleAssignableUsers: 'loadRoleAssignableUsers'")
        && str_contains($ajax, 'isset($_POST["loadRoleAssignableUsers"])')
        && str_contains($ajax, 'FROM users u')
        && str_contains($ajax, 'LEFT JOIN employees e ON e.id = (')
        && str_contains($profilePage, 'notify(\'success\', res.message || \'Profile updated successfully.\');')
        && str_contains($profilePage, 'loadProfileData();'),
    'Role assignment must include users without employee rows, while My Account reloads persisted values after save.'
);
$assert(
    substr_count($ajax, 'flex flex-nowrap items-center justify-end gap-1.5') >= 2
        && substr_count($ajax, 'text-right whitespace-nowrap') >= 2
        && str_contains($ajax, 'id="coaRemarksQc" name="coaRemarksQc">\' . htmlspecialchars($row[\'coa_remark\'] ?? "") . \'</textarea>'),
    'SA/COA actions must align right and the saved QC remark must be populated in the edit form.'
);
$assert(
    str_contains($theme, '.swal2-container')
        && str_contains($theme, 'z-index: 3000 !important;')
        && str_contains($theme, '.form-switch .form-check-input:not(:checked)')
        && str_contains($sidebar, "'company-setup' => 'fas fa-building'"),
    'Shared modal alerts, off-state toggles, and the Company Setup menu icon must use the established global styles.'
);
$assert(
    substr_count($lowStocksPage, "dropdownParent: $('#addLowStockModal')") >= 1
        && substr_count($lowStocksPage, "dropdownParent: $('#lowStockEditModal')") >= 1,
    'Low Stock unit and critical-item dropdowns must remain attached to their owning modal.'
);
$assert(
    !str_contains($saPage, 'data-bs-dismiss="modal">Close</button>')
        && !str_contains($coaPage, 'data-bs-dismiss="modal">Close</button>')
        && str_contains($ipCoaPage, 'class="input-theme block w-full min-w-0 max-w-full"'),
    'QA view modals must rely on their top close control and the IP testing date must fit its responsive grid.'
);
$assert(
    str_contains($calendarPage, "$('#acUnfinalizeBtn').on('click'")
        && str_contains($calendarPage, "hrmsPost('unfinalize_annual_calendar'")
        && str_contains($calendarPage, "$('#acSaveOverrideBtn').on('click'")
        && str_contains($calendarPage, "hrmsPost('save_calendar_day_override'")
        && str_contains($calendarApi, "case 'unfinalize_annual_calendar':")
        && str_contains($calendarApi, "case 'save_calendar_day_override':"),
    'Calendar Unlock and Add Override controls must remain wired to their existing API handlers.'
);
$assert(
    str_contains($stockInwardsPage, 'id="inboundMaterialsCount"')
        && str_contains($stockInwardsPage, "$('#inboundMaterialsCount').text(Number(response.count || 0))")
        && str_contains($ajax, "'count' => count(\$inbound)"),
    'Goods Received must display the count from its existing inbound collection.'
);
$assert(
    str_contains($inboundQualityPage, "window.location.href = 'index.php?page=coa-generation' + queueQuery")
        && !str_contains($inboundQualityPage, 'page=fg-coa-generation')
        && !str_contains($inboundQualityPage, 'Redirecting to FG COA Generation...'),
    'Select & Test must use the unified inbound-quality route without an FG-specific redirect.'
);
$assert(
    substr_count($usersPage, 'class="toggle-user-password') === 2
        && str_contains($usersPage, "$(document).on('click', '.toggle-user-password'")
        && str_contains($usersPage, "input.type = showPassword ? 'text' : 'password'")
        && str_contains($usersPage, "this.setAttribute('aria-pressed', String(showPassword))"),
    'Add User password and confirmation fields must have accessible visibility controls.'
);
$assert(
    str_contains($purchasePage, "dropdownParent: $('#addPurchaseOrderRawModal')")
        && str_contains($purchasePage, "dropdownParent: $('#addPurchaseOrderModal')")
        && str_contains($purchasePage, "dropdownParent: $('#purchaseOrderEditModal')")
        && str_contains($purchasePage, 'min-width: 0 !important;')
        && str_contains($theme, 'max-width: calc(100vw - 2rem) !important;'),
    'Purchase-order Select2 controls must remain within their modal and the viewport.'
);
$assert(
    str_contains($customScript, 'function applyRequiredIndicators(scope)')
        && str_contains($customScript, 'input[required], select[required], textarea[required]')
        && str_contains($customScript, 'hasExistingRequiredIndicator(label)')
        && str_contains($customScript, "attributeFilter: ['required']")
        && str_contains($theme, '.required-field-indicator'),
    'Required controls must receive a duplicate-safe shared indicator, including dynamically added fields.'
);
$assert(
    str_contains($header, 'favicon-32x32.png')
        && str_contains($header, 'favicon-16x16.png')
        && str_contains($header, 'apple-touch-icon.png')
        && str_contains($theme, '.menu-item:not(.active) > .menu-link .menu-icon')
        && str_contains($theme, 'color-mix(in srgb, var(--appearance-accent) 68%'),
    'Favicon variants and inactive sidebar icons must use the supplied branding and selected accent.'
);
$assert(
    str_contains($fontMigration, 'DEFAULT 15')
        && str_contains($fontMigration, 'WHERE `base_font_size` = 14')
        && str_contains($migrationRunner, '2026_09_15_002_readable_default_font_size_pending.sql'),
    'The migration must upgrade only the former 14px default and be registered in the pending runner.'
);
$assert(
    str_contains($rapidPage, 'id="rapidModalDownloadBtn"')
        && str_contains($rapidPage, "$('#rapidModalDownloadBtn').data('id', id).prop('hidden', false)")
        && str_contains($attendancePage, 'data-company-collapse=')
        && str_contains($attendancePage, 'bootstrap.Collapse.getOrCreateInstance'),
    'Rapid download placement and attendance accordion state handling must remain wired.'
);
$assert(
    str_contains($adminIndex, "if (\$page === 'pi-generator')")
        && str_contains($adminIndex, "header('Location: index.php?page=pi-requests');")
        && str_contains($piRequestsPage, "require __DIR__ . '/pi-generator.php';"),
    'Legacy PI Generator access must resolve inside the canonical PI Requests workflow.'
);
$assert(
    str_contains($syncAjax, "in_array(\$entity, ['users', 'meetings', 'quiz', 'pi', 'quotations'], true)")
        && str_contains($bulkSync, "'users' => \$this->saveCustomer(\$item)")
        && str_contains($bulkSync, "'meetings' => \$this->saveMeetingRequest(\$item)")
        && str_contains($bulkSync, '/api/erp-sync/acknowledge'),
    'Customer and meeting pull/upsert/acknowledgement must remain on the shared sync layer.'
);
$assert(
    str_contains($functions, "'registered_address' => ''")
        && str_contains($functions, 'SELECT id, legal_name, trade_name, cin_no, gst_no FROM company_profiles')
        && str_contains($poTemplate, "\$companyBranding['cin_no'] ?: '-'")
        && str_contains($rawPoTemplate, "\$companyBranding['cin_no'] ?: '-'"),
    'Purchase-order templates must use live company profile identity and address data.'
);
$assert(
    substr_count($ajax, "SET `status` = ?, `deleted_at` = NULL, `deleted_by` = NULL") >= 2
        && substr_count($ajax, 'returned to Low Stock.') >= 2,
    'Deleting an unprocessed purchase order must restore its linked Low Stock demand.'
);

if ($failures !== []) {
    fwrite(STDERR, "CareIO bugs foundation contract test failed:\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "CareIO bugs foundation contract test passed.\n";
