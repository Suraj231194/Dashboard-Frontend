const assert = require('node:assert/strict');
const { rebalance } = require('../../assets/js/hrms-salary-calculator.js');

const annualCtc = 1_200_000;
const defaultComponents = [
  { code: 'BASIC', calculation_type: 'ctc_percentage', calculation_value: 60 },
  { code: 'HRA', calculation_type: 'ctc_percentage', calculation_value: 40 },
];

let result = rebalance(defaultComponents, annualCtc, 0);
assert.equal(result.balanced, true);
assert.equal(result.components[0].calculation_value, 60);
assert.equal(result.components[1].calculation_value, 40);

result = rebalance([
  { ...defaultComponents[0], calculation_value: 85 },
  defaultComponents[1],
], annualCtc, 0);
assert.equal(result.components[0].calculation_value, 85);
assert.equal(result.components[1].calculation_value, 15);
assert.equal(result.earningTotal, annualCtc);

result = rebalance([
  defaultComponents[0],
  { ...defaultComponents[1], calculation_value: 25 },
], annualCtc, 1);
assert.equal(result.components[0].calculation_value, 75);
assert.equal(result.components[1].calculation_value, 25);

result = rebalance([
  defaultComponents[0],
  defaultComponents[1],
  { code: 'SPECIAL', calculation_type: 'fixed', calculation_value: 10_000 },
], annualCtc, 2);
assert.equal(result.components[0].calculation_value, 60);
assert.equal(result.components[1].calculation_value, 30);
assert.equal(result.components[2].monthly_amount, 10_000);

result = rebalance([
  defaultComponents[0],
  defaultComponents[1],
  { code: 'SPECIAL', calculation_type: 'fixed', calculation_value: 100_000 },
], annualCtc, 2);
assert.equal(result.balanced, true);
assert.equal(result.wasClamped, true);
assert.equal(result.components[1].calculation_value, 0);
assert.equal(result.components[2].monthly_amount, 40_000);

result = rebalance([
  ...defaultComponents,
  { code: 'DEDUCTION', calculation_type: 'fixed', calculation_value: 5_000, is_deduction: 1 },
], annualCtc, 0);
assert.equal(result.earningTotal, annualCtc);
assert.equal(result.components[2].monthly_amount, 5_000);

console.log('PASS: salary component balancing, residual heads, clamping, and deductions.');