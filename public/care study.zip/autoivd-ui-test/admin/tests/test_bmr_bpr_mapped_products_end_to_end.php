<?php

declare(strict_types=1);

$host = 'srv484.hstgr.io';
$db   = 'u706677387_autoivd_shift';
$user = 'u706677387_autoivd_shift';
$pass = '8n@YmJDnoW';

echo "======================================================================\n";
echo "   BMR/BPR 100% PRODUCT MAPPING & TEMPLATE RESOLUTION END-TO-END TEST \n";
echo "======================================================================\n\n";

$conn = new mysqli($host, $user, $pass, $db, 3306);
if ($conn->connect_error) {
    echo "[FATAL] Connection failed: " . $conn->connect_error . "\n";
    exit(1);
}
$conn->set_charset('utf8mb4');

require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] $message\n";
    } else {
        echo "  [PASSED] $message\n";
    }
};

// TEST 1: Check active templates in database
echo "TEST 1: Checking Active BMR & BPR Templates in Database...\n";
$templates = bmrBprGetRankedTemplates($conn, 0, '', '');
$assert(count($templates['BMR']) === 14, "Must have exactly 14 active BMR templates (found " . count($templates['BMR']) . ")");
$assert(count($templates['BPR']) === 8, "Must have exactly 8 active BPR templates (found " . count($templates['BPR']) . ")");

// TEST 2: Check Mapped Products Catalog
echo "\nTEST 2: Checking Mapped Products Catalog...\n";
$catalog = bmrBprGetMappedProductCatalog($conn);
$bmrCount = count($catalog['BMR']);
$bprCount = count($catalog['BPR']);
$allCount = count($catalog['all_products']);

echo "  -> Found BMR product mappings: $bmrCount\n";
echo "  -> Found BPR product mappings: $bprCount\n";
echo "  -> Found unique mapped products: $allCount\n";

$assert($bmrCount >= 314, "BMR product mappings must be at least 314 (found $bmrCount)");
$assert($bprCount >= 210, "BPR product mappings must be at least 210 (found $bprCount)");
$assert($allCount >= 200, "Unique products must be at least 200 (found $allCount)");

// TEST 3: Product to Template Auto-Resolution for key product categories
echo "\nTEST 3: Product to Template Auto-Resolution Verification...\n";

// Sample 1: Biochemistry ELISA product
$sampleBio = $catalog['BMR'][0];
$bioReq = bmrBprResolveProductDocumentRequirements($conn, (int)$sampleBio['product_id'], (string)$sampleBio['pack_size']);
$assert(!empty($bioReq['BMR']), "Biochemistry product {$sampleBio['product_name']} must resolve BMR template.");
$assert(!empty($bioReq['BPR']), "Biochemistry product {$sampleBio['product_name']} must resolve BPR template.");

// Sample 2: ADA pack-resolved product
$adaReq100 = bmrBprResolveProductDocumentRequirements($conn, 415, '100 mL');
$assert(!empty($adaReq100['BMR']), "ADA 100 mL must resolve pack-specific BMR templates.");
$assert(count($adaReq100['BMR']) === 2, "ADA 100 mL must resolve 2 BMR templates (R1 and R2).");
$assert(!empty($adaReq100['BPR']), "ADA 100 mL must resolve pack-specific BPR template.");

// Sample 3: Rapid test product
$rapidMatches = array_filter($catalog['BMR'], static fn($p) => str_contains($p['template_code'], 'COMMON_RAPID_BMR_01'));
$assert(count($rapidMatches) >= 70, "Rapid test BMR template #1 must have at least 70 mapped products (found " . count($rapidMatches) . ")");

// Sample 4: Serology product
$serologyMatches = array_filter($catalog['BMR'], static fn($p) => str_contains($p['template_code'], 'COMMON_SEROLOGY_BMR'));
$assert(count($serologyMatches) === 23, "Serology BMR template must have exactly 23 mapped products (found " . count($serologyMatches) . ")");

// Sample 5: Urology product
$urologyMatches = array_filter($catalog['BMR'], static fn($p) => str_contains($p['template_code'], 'COMMON_UROLOGY_BMR'));
$assert(count($urologyMatches) >= 10, "Urology BMR template must have at least 10 mapped products (found " . count($urologyMatches) . ")");

// Sample 6: Hematology product
$hematologyMatches = array_filter($catalog['BMR'], static fn($p) => str_contains($p['template_code'], 'COMMON_HEMATOLOGY_BMR'));
$assert(count($hematologyMatches) === 5, "Hematology BMR template must have exactly 5 mapped products (found " . count($hematologyMatches) . ")");

// Sample 7: Microbiology product
$microbiologyMatches = array_filter($catalog['BMR'], static fn($p) => str_contains($p['template_code'], 'COMMON_MICROBIOLOGY_BMR'));
$assert(count($microbiologyMatches) === 13, "Microbiology BMR template must have exactly 13 mapped products (found " . count($microbiologyMatches) . ")");

// TEST 4: Frontend Contracts
echo "\nTEST 4: Frontend Form Request Searchable Dropdown Contracts...\n";
$formContent = (string) file_get_contents(dirname(__DIR__) . '/pages/bmr-bpr-form-request.php');
$assert(str_contains($formContent, 'id="bmrBprRequestProduct" class="input-theme select2"'), "Product select must have select2 class.");
$assert(str_contains($formContent, 'populateProductDropdown'), "Form request must define populateProductDropdown.");
$assert(str_contains($formContent, '$(document).on(\'change\', \'#bmrBprRequestProduct\''), "Product change listener must be registered.");
$assert(str_contains($formContent, 'populateBmrBprTemplateDropdowns'), "Template dropdown population must be integrated with product change.");

// TEST 5: Backend Actions Contracts
echo "\nTEST 5: Backend Actions Contracts...\n";
$actionsContent = (string) file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_actions.php');
$assert(str_contains($actionsContent, "'mapped_products' => bmrBprGetMappedProductCatalog(\$conn)"), "Actions must return mapped_products in request_list.");

echo "\n======================================================================\n";
if (empty($failures)) {
    echo "ALL 100% BMR/BPR PRODUCT MAPPING & TEMPLATE RESOLUTION TESTS PASSED! (0 failures)\n";
} else {
    echo "FAILED WITH " . count($failures) . " FAILURES!\n";
    exit(1);
}
echo "======================================================================\n";
