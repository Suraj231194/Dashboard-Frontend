<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/urine_strip/profiles.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/rapid_test/profiles.php';

function coaUrineRapidAssert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function coaUrineRapidCompletedPayload(array $profile): array
{
    $fields = [
        'metadata.manufacturing_date' => '01/07/2026',
        'metadata.expiry_date' => '30/06/2028',
        'approval.decision' => 'APPROVED',
        'approval.comments' => 'Meets controlled specification.',
        'approval.analysis_by' => 'QC Analyst',
        'approval.verified_by' => 'QC Head',
    ];
    foreach (($profile['editable_field_keys'] ?? []) as $fieldKey) {
        $fields[(string) $fieldKey] = str_ends_with((string) $fieldKey, '.remarks')
            ? 'The product complies.'
            : 'Complies';
    }
    return coaTemplateSanitizePayload(
        $profile,
        ['schema_version' => 1, 'fields' => $fields]
    );
}

try {
    $urineProfiles = coaUrineStripProfiles();
    $rapidProfiles = coaRapidTestProfiles();
    coaUrineRapidAssert(count($urineProfiles) === 4, 'Expected four Urine Strip COA families.');
    coaUrineRapidAssert(count(coaUrineStripMappedProductIds()) === 4, 'Expected four Urine Strip products.');
    coaUrineRapidAssert(count($rapidProfiles) === 24, 'Expected 24 Rapid Test COA families.');
    coaUrineRapidAssert(count(coaRapidTestMappedProductIds()) === 39, 'Expected 39 mapped Rapid Test products.');

    foreach ([
        ['root' => dirname(__DIR__, 2) . '/URINE STRIP', 'profiles' => $urineProfiles],
        ['root' => dirname(__DIR__, 2) . '/Rapid Test', 'profiles' => $rapidProfiles],
    ] as $catalog) {
        foreach ($catalog['profiles'] as $familyKey => $profile) {
            coaUrineRapidAssert(
                is_file($catalog['root'] . '/' . (string) $profile['source_document']),
                "Controlled source is missing for {$familyKey}."
            );
            coaUrineRapidAssert(
                ($profile['editable_field_keys'] ?? []) !== [],
                "Editable field schema is missing for {$familyKey}."
            );
        }
    }

    $templateCodes = [
        'COMMON_URINE_STRIP_IP_COA_V01',
        'COMMON_URINE_STRIP_FG_COA_V01',
        'COMMON_RAPID_TEST_IP_COA_V01',
        'COMMON_RAPID_TEST_FG_COA_V01',
    ];
    $quotedCodes = implode(',', array_map(
        static fn(string $code): string => "'" . $conn->real_escape_string($code) . "'",
        $templateCodes
    ));
    $result = $conn->query(
        "SELECT template_code, coa_type, layout_json
         FROM coa_document_templates
         WHERE template_code IN ({$quotedCodes}) AND status = 1 AND deleted_at IS NULL"
    );
    coaUrineRapidAssert($result !== false, 'Unable to inspect installed COA templates.');
    $installed = [];
    while ($row = $result->fetch_assoc()) {
        $installed[(string) $row['template_code']] = coaTemplateDecodeLayout(
            (string) $row['layout_json']
        );
    }
    coaUrineRapidAssert(count($installed) === 4, 'Expected four installed Urine/Rapid COA templates.');

    $mappingResult = $conn->query(
        "SELECT template.template_code, COUNT(*) AS total
         FROM coa_template_product_mappings mapping
         INNER JOIN coa_document_templates template ON template.id = mapping.template_id
         WHERE template.template_code IN ({$quotedCodes})
           AND mapping.status = 1 AND mapping.deleted_at IS NULL
           AND template.status = 1 AND template.deleted_at IS NULL
         GROUP BY template.template_code"
    );
    coaUrineRapidAssert($mappingResult !== false, 'Unable to inspect Urine/Rapid mappings.');
    $mappingCounts = [];
    while ($row = $mappingResult->fetch_assoc()) {
        $mappingCounts[(string) $row['template_code']] = (int) $row['total'];
    }
    coaUrineRapidAssert(
        ($mappingCounts['COMMON_URINE_STRIP_IP_COA_V01'] ?? 0) === 4
        && ($mappingCounts['COMMON_URINE_STRIP_FG_COA_V01'] ?? 0) === 4,
        'Urine Strip mappings are incomplete.'
    );
    coaUrineRapidAssert(
        ($mappingCounts['COMMON_RAPID_TEST_IP_COA_V01'] ?? 0) === 39
        && ($mappingCounts['COMMON_RAPID_TEST_FG_COA_V01'] ?? 0) === 39,
        'Rapid Test mappings are incomplete.'
    );

    $representatives = [
        ['product_id' => 1051, 'type' => 'IP', 'variant' => 'urine_strip', 'text' => 'Ascorbic Acid'],
        ['product_id' => 1048, 'type' => 'FG', 'variant' => 'urine_strip', 'text' => 'Clear Blue color pad'],
        ['product_id' => 1017, 'type' => 'IP', 'variant' => 'rapid_test', 'text' => 'Non-Reactive Samples'],
        ['product_id' => 1011, 'type' => 'FG', 'variant' => 'rapid_test', 'text' => 'Test Line III'],
        ['product_id' => 995, 'type' => 'FG', 'variant' => 'rapid_test', 'text' => '100 mIU/ml Positive'],
    ];
    $renderedDocuments = [];
    foreach ($representatives as $representative) {
        $template = coaTemplateResolveMappedTemplate(
            $conn,
            $representative['product_id'],
            $representative['type']
        );
        coaUrineRapidAssert(is_array($template), 'A representative product did not resolve a COA template.');
        coaUrineRapidAssert(
            ($template['layout']['renderer_variant'] ?? '') === $representative['variant'],
            'A representative product resolved the wrong renderer variant.'
        );
        $payload = coaUrineRapidCompletedPayload($template['profile']);
        $form = coaTemplatePrepareForm(
            $template,
            $representative['type'],
            [
                'coa_number' => 'BIPL-COA-TEST',
                'batch_number' => 'TEST-BATCH',
                'batch_size' => '100 Tests',
                'testing_date' => '30/07/2026',
            ],
            $payload
        );
        $html = coaTemplateRender($form, true);
        coaUrineRapidAssert(
            str_contains($html, 'data-coa-template="1"')
            && str_contains($html, $representative['text']),
            'A representative structured COA omitted controlled content.'
        );
        $renderedDocuments[] = $html;
    }

    require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
    $pdfOptions = new Dompdf\Options();
    $pdfOptions->set('isRemoteEnabled', false);
    $pdfOptions->set('isHtml5ParserEnabled', true);
    $pdfOptions->set('defaultFont', 'Helvetica');
    $pdfOptions->set('defaultMediaType', 'print');
    foreach ($renderedDocuments as $documentIndex => $html) {
        $pdf = new Dompdf\Dompdf($pdfOptions);
        $pdf->setPaper('A4', 'portrait');
        $pdf->loadHtml(
            '<!DOCTYPE html><html><head><meta charset="UTF-8">'
            . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
            . '</head><body>' . $html . '</body></html>',
            'UTF-8'
        );
        $pdf->render();
        coaUrineRapidAssert(
            strlen($pdf->output()) > 5000 && $pdf->getCanvas()->get_page_count() >= 1,
            'Representative Urine/Rapid PDF ' . ($documentIndex + 1)
            . ' is unexpectedly empty (bytes: ' . strlen($pdf->output())
            . ', pages: ' . $pdf->getCanvas()->get_page_count() . ').'
        );
    }

    echo "Urine/Rapid COA smoke test passed: 28 families, 43 products, 86 mappings.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
