<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_biochemistry_profiles.php';

$failures = [];
$expectedIds = bmrBprBiochemistryApprovedProductIds();
$expectedCodes = [
    'COMMON_BIOCHEMISTRY_BMR_01_V03',
    'COMMON_BIOCHEMISTRY_BMR_02_V03',
    'COMMON_BIOCHEMISTRY_BMR_03_V03',
    'COMMON_BIOCHEMISTRY_BMR_04_V03',
    'COMMON_BIOCHEMISTRY_BPR_01_V03',
    'COMMON_BIOCHEMISTRY_BPR_02_V03',
];
$escapedCodes = array_map(
    static fn(string $code): string => "'" . $conn->real_escape_string($code) . "'",
    $expectedCodes
);
$codeSql = implode(',', $escapedCodes);

$templates = $conn->query(
    "SELECT template_code, form_type, source_pdf_path, page_asset_path, layout_json
     FROM bmr_templates
     WHERE template_code IN ({$codeSql}) AND status = 1 AND deleted_at IS NULL"
);
if (!$templates || $templates->num_rows !== 6) {
    $failures[] = 'The six active Biochemistry templates are not installed.';
} else {
    while ($template = $templates->fetch_assoc()) {
        $layout = json_decode((string) $template['layout_json'], true);
        if (
            !is_array($layout)
            || ($layout['renderer'] ?? '') !== 'structured_html'
            || ($layout['renderer_variant'] ?? '') !== 'biochemistry'
            || ($layout['form_type'] ?? '') !== $template['form_type']
            || !is_array($layout['profiles'] ?? null)
            || $template['source_pdf_path'] !== null
            || $template['page_asset_path'] !== null
        ) {
            $failures[] = $template['template_code'] . ': invalid code-only layout.';
        }
    }
}

$mappingRows = $conn->query(
    "SELECT mapping.product_id, mapping.form_type, mapping.document_sequence
     FROM bmr_template_product_mappings mapping
     INNER JOIN bmr_templates template
        ON template.id = mapping.template_id
       AND template.template_code IN ({$codeSql})
       AND template.status = 1
       AND template.deleted_at IS NULL
     WHERE mapping.status = 1 AND mapping.deleted_at IS NULL
     ORDER BY mapping.product_id, mapping.form_type, mapping.document_sequence"
);
$actualIds = [];
$mappingCounts = ['BMR' => 0, 'BPR' => 0];
$combinedCounts = ['BMR' => 0, 'BPR' => 0];
if (!$mappingRows) {
    $failures[] = 'Unable to read Biochemistry mappings.';
} else {
    while ($mapping = $mappingRows->fetch_assoc()) {
        $productId = (int) $mapping['product_id'];
        $formType = (string) $mapping['form_type'];
        $actualIds[$productId] = true;
        $mappingCounts[$formType]++;
        if ($productId === 908) {
            $combinedCounts[$formType]++;
        }
    }
}
$actualIds = array_keys($actualIds);
sort($actualIds);
if ($actualIds !== $expectedIds) {
    $failures[] = 'Installed product IDs differ from the audited finished-product set.';
}
if ($mappingCounts !== ['BMR' => 183, 'BPR' => 84]) {
    $failures[] = 'Installed Biochemistry mapping totals are invalid.';
}
if ($combinedCounts !== ['BMR' => 4, 'BPR' => 2]) {
    $failures[] = 'Combined Total & Direct Bilirubin is not split into 4 BMR and 2 BPR documents.';
}

$demo = $conn->query(
    "SELECT
        COUNT(DISTINCT request_row.product_id) AS products,
        COUNT(DISTINCT request_row.id) AS requests,
        COUNT(work_item.id) AS work_items,
        SUM(work_item.form_type = 'BMR') AS bmrs,
        SUM(work_item.form_type = 'BPR') AS bprs
     FROM material_requisition mr
     INNER JOIN bmr_bpr_requests request_row
        ON request_row.material_requisition_id = mr.id
       AND request_row.deleted_at IS NULL
     INNER JOIN bmr_bpr_work_items work_item
        ON work_item.request_id = request_row.id
       AND work_item.deleted_at IS NULL
     WHERE mr.slip_no LIKE 'BMR-COMMON-BIOCHEMISTRY-DEMO-%'
       AND mr.deleted_at IS NULL"
);
$demoRow = $demo ? $demo->fetch_assoc() : [];
if (
    (int) ($demoRow['products'] ?? 0) !== 83
    || (int) ($demoRow['requests'] ?? 0) !== 83
    || (int) ($demoRow['work_items'] ?? 0) !== 267
    || (int) ($demoRow['bmrs'] ?? 0) !== 183
    || (int) ($demoRow['bprs'] ?? 0) !== 84
) {
    $failures[] = 'Biochemistry acceptance request/work-item totals are invalid.';
}

foreach ($expectedCodes as $templateCode) {
    $stmt = $conn->prepare(
        "SELECT work_item.id
         FROM bmr_bpr_work_items work_item
         INNER JOIN bmr_templates template
            ON template.id = work_item.template_id
         WHERE template.template_code = ?
           AND work_item.deleted_at IS NULL
         ORDER BY work_item.id DESC LIMIT 1"
    );
    $stmt->bind_param('s', $templateCode);
    $stmt->execute();
    $workItemId = (int) ($stmt->get_result()->fetch_assoc()['id'] ?? 0);
    $stmt->close();
    if ($workItemId <= 0) {
        $failures[] = "{$templateCode}: no installed work item.";
        continue;
    }
    $form = bmrBprLoadWorkItemTemplate($conn, $workItemId);
    if (
        empty($form['has_template'])
        || empty($form['rendered_html'])
        || stripos((string) $form['rendered_html'], 'MASTER COPY') === false
    ) {
        $failures[] = "{$templateCode}: installed form does not render.";
    }
}

$incomingCounts = ['BMR' => 0, 'BPR' => 0];
foreach (bmrBprProductionRows($conn) as $row) {
    if (!str_starts_with((string) ($row['template_code'] ?? ''), 'COMMON_BIOCHEMISTRY_')) {
        continue;
    }
    $formType = (string) $row['form_type'];
    $isDemoBmrPreview = !empty($row['is_common_template_demo'])
        && $formType === 'BMR'
        && $row['status_code'] === 'IN_PROCESS'
        && (
            !str_starts_with(
                (string) ($row['template_code'] ?? ''),
                'COMMON_BIOCHEMISTRY_BMR_'
            )
            || (int) ($row['form_sequence'] ?? 0) === 1
        );
    if (
        (
            in_array($row['status_code'], ['QUEUED', 'PENDING'], true)
            || $isDemoBmrPreview
        )
        && !empty($row['can_open'])
    ) {
        $incomingCounts[$formType]++;
    }
}
if ($incomingCounts !== ['BMR' => 83, 'BPR' => 84]) {
    $failures[] = 'Incoming Biochemistry UI totals must be 83 BMR and 84 BPR document rows.';
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo 'Biochemistry installation smoke test passed: 6 templates, 83 products, '
    . '183 BMR and 84 BPR work items.' . PHP_EOL;
