<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../constant.php';
require_once __DIR__ . '/../functions.php';

echo "======================================================================\n";
echo "   QA RELEASE / STOCK AVAILABILITY ORDER DISPATCH SYNC TEST           \n";
echo "======================================================================\n\n";

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] {$message}\n";
    } else {
        echo "  [PASSED] {$message}\n";
    }
};

$cleanups = [];

try {
    // 1. Setup Test Product
    $testProdName = 'QA_Sync_Test_Prod_' . time();
    $resP = $conn->query("INSERT INTO products (product_name, product_code, category_id, unit_id, status, created_at) 
                  VALUES ('{$testProdName}', 'QA_CODE_" . time() . "', 122, 10, 1, NOW())");
    if (!$resP) throw new RuntimeException("Insert product failed: " . $conn->error);
    $testProductId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM products WHERE id = {$testProductId}";

    // 2. Setup Test Customer Order
    $testOrderNum = 'BIPL-TEST-ORD-' . time();
    $resO = $conn->query("INSERT INTO order_received (order_number, client_name, customer_id, source_type, status, order_type, date_order_received, created_by, created_at) 
                  VALUES ('{$testOrderNum}', 'Test QA Client', 8196, 1, 17, 1, CURDATE(), 47, NOW())");
    if (!$resO) throw new RuntimeException("Insert order failed: " . $conn->error);
    $testOrderId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM order_received WHERE id = {$testOrderId}";
    $cleanups[] = "DELETE FROM order_management_audit WHERE order_id = {$testOrderId}";

    $resI = $conn->query("INSERT INTO order_received_items (order_id, product_id, product_name, quantity, unit, status, fulfillment_action, fulfillment_status, created_by, created_at)
                  VALUES ({$testOrderId}, {$testProductId}, '{$testProdName}', 500, 10, 0, 'procurement', 'sent_to_procurement', 47, NOW())");
    if (!$resI) throw new RuntimeException("Insert item failed: " . $conn->error);
    $testOrderItemId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM order_received_items WHERE order_id = {$testOrderId}";
    $cleanups[] = "DELETE FROM order_stock_reservations WHERE order_id = {$testOrderId}";

    // 3. Setup Low Stock & PO link
    $resL = $conn->query("INSERT INTO low_stocks (product_id, required_qty, required_qty_unit, order_id, procurement_source, status, created_by, created_at)
                  VALUES ({$testProductId}, 500, 10, {$testOrderId}, 'order_auto', 2, 47, NOW())");
    if (!$resL) throw new RuntimeException("Insert low_stock failed: " . $conn->error);
    $testLowStockId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM low_stocks WHERE id = {$testLowStockId}";

    $testPoNum = 'PO_TEST_' . time();
    $resPo = $conn->query("INSERT INTO purchase_order_final (low_stock_id, po_order_num, quantity_required, quantity_required_unit, status, created_by, created_at) 
                           VALUES ({$testLowStockId}, '{$testPoNum}', 500, 10, 2, 47, NOW())");
    if (!$resPo) throw new RuntimeException("Insert purchase_order_final failed: " . $conn->error);
    $testPofId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM purchase_order_final WHERE id = {$testPofId}";

    // 4. Setup Stock Inward (quarantined stock, status = 0)
    $resSi = $conn->query("INSERT INTO stock_inwards (product_id, prod_quantity, po_id, po_type, status, created_by, created_at)
                  VALUES ({$testProductId}, 500, {$testPofId}, 'RM', 4, 47, NOW())");
    if (!$resSi) throw new RuntimeException("Insert stock_inwards failed: " . $conn->error);
    $testStockInwardId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM stock_inwards WHERE id = {$testStockInwardId}";

    $resLs = $conn->query("INSERT INTO live_stock (stock_inward_id, product_id, quantity_available, reserved_qty, unreserved_qty, status, created_by, created_at)
                  VALUES ({$testStockInwardId}, {$testProductId}, 0, 0, 0, 0, 47, NOW())");
    if (!$resLs) throw new RuntimeException("Insert live_stock failed: " . $conn->error);
    $testLiveStockId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM live_stock WHERE id = {$testLiveStockId}";

    // 5. Setup Pending COA Record
    $testCoaNum = 'BIPL-COA-TEST-' . time();
    $resCoa = $conn->query("INSERT INTO coa_rm_pm_table (stock_inward_id, coa_number, type, name, batch_qty, status, approval_status, coa_approval_status, created_by, created_at)
                  VALUES ({$testStockInwardId}, '{$testCoaNum}', 'RM', '{$testProdName}', 500, 1, 1, 0, 47, NOW())");
    if (!$resCoa) throw new RuntimeException("Insert coa failed: " . $conn->error);
    $testCoaId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM coa_rm_pm_table WHERE id = {$testCoaId}";

    echo "TEST 1: Verify Initial State before QA Approval...\n";
    $oBefore = $conn->query("SELECT status FROM order_received WHERE id = {$testOrderId}")->fetch_assoc();
    $assert((int) $oBefore['status'] === 17, 'Initial order status is 17 (Sent to Procurement).');

    $sBefore = $conn->query("SELECT quantity_available, status FROM live_stock WHERE id = {$testLiveStockId}")->fetch_assoc();
    $assert((int) $sBefore['status'] === 0 && (float) $sBefore['quantity_available'] === 0.0, 'Live stock is quarantined (status = 0, quantity_available = 0).');

    echo "\nTEST 2: Simulate QA Release (COA Approval)...\n";
    // Release stock in live_stock as QA approval does
    $conn->query("UPDATE live_stock SET quantity_available = 500, unreserved_qty = 500, status = 1, updated_at = NOW() WHERE id = {$testLiveStockId}");
    $conn->query("UPDATE coa_rm_pm_table SET coa_approval_status = 1, coa_approval_date = NOW(), coa_approval_by = 47 WHERE id = {$testCoaId}");

    // Execute the auto-routing hook (as in coaApprovalFrom)
    $routeResult = mvAutoRouteOrderAfterStockCheck($conn, $testOrderId, 47, 'Auto-routed after QA COA release test.');

    echo "\nTEST 3: Verify Order Fulfillment and Status Transitions...\n";
    $oAfter = $conn->query("SELECT status FROM order_received WHERE id = {$testOrderId}")->fetch_assoc();
    $assert((int) $oAfter['status'] === 13, 'Order status automatically transitioned from 17 (Sent to Procurement) to 13 (Ready for Dispatch).');

    $itemAfter = $conn->query("SELECT reserved_quantity_base, shortfall_quantity_base, fulfillment_status FROM order_received_items WHERE id = {$testOrderItemId}")->fetch_assoc();
    $assert((float) $itemAfter['reserved_quantity_base'] === 500.0, 'Reserved quantity is 500.');
    $assert((float) $itemAfter['shortfall_quantity_base'] === 0.0, 'Shortfall quantity is 0.');
    $assert(in_array($itemAfter['fulfillment_status'], ['stock_available', 'ready_for_dispatch'], true), 'Order item fulfillment status is stock_available or ready_for_dispatch.');

    $resCount = (int) ($conn->query("SELECT COUNT(*) AS total FROM order_stock_reservations WHERE order_id = {$testOrderId} AND status = 1")->fetch_assoc()['total'] ?? 0);
    $assert($resCount >= 1, 'Stock reservation record was created in order_stock_reservations.');

    echo "\nTEST 4: Verify Goods Received & Reserved Query Accuracy...\n";
    $grr = mvGetGoodsReceivedReservedList($conn);
    $foundInGrr = false;
    foreach ($grr['records'] as $rec) {
        if ($rec['order_id'] === $testOrderId) {
            $foundInGrr = true;
            break;
        }
    }
    $assert($foundInGrr, 'Completed & reserved order appears in Goods Received & Reserved list.');

    echo PHP_EOL . 'TEST 5: Verify GRR queue handoff semantics...' . PHP_EOL;
    $outwardSql = 'SELECT COUNT(*) AS total FROM stock_outward WHERE order_id = ' . $testOrderId;
    $outwardBefore = (int) ($conn->query($outwardSql)->fetch_assoc()['total'] ?? 0);
    $queueResult = mvDispatchOrderToStockOutward($conn, $testOrderId, 'GRR queue regression test.', 47);
    $assert(($queueResult['status'] ?? '') === 'success', 'GRR handoff succeeds.');
    $queuedOrder = $conn->query('SELECT status FROM order_received WHERE id = ' . $testOrderId)->fetch_assoc();
    $assert((int) ($queuedOrder['status'] ?? -1) === 13, 'GRR handoff keeps status Ready for Dispatch.');
    $queuedItem = $conn->query('SELECT fulfillment_action, fulfillment_status FROM order_received_items WHERE id = ' . $testOrderItemId)->fetch_assoc();
    $assert(($queuedItem['fulfillment_action'] ?? '') === 'dispatch', 'GRR handoff changes the line action to dispatch.');
    $assert(($queuedItem['fulfillment_status'] ?? '') === 'ready_for_dispatch', 'GRR handoff marks the line ready for dispatch.');
    $activeReservationSql = 'SELECT COUNT(*) AS total FROM order_stock_reservations WHERE order_id = ' . $testOrderId . ' AND status = 1 AND quantity > 0';
    $activeReservation = (int) ($conn->query($activeReservationSql)->fetch_assoc()['total'] ?? 0);
    $assert($activeReservation >= 1, 'GRR handoff preserves the active reservation.');
    $outwardAfter = (int) ($conn->query($outwardSql)->fetch_assoc()['total'] ?? 0);
    $assert($outwardAfter === $outwardBefore, 'GRR handoff does not create stock outward.');

} finally {
    foreach (array_reverse($cleanups) as $sql) {
        $conn->query($sql);
    }
}

echo "\n======================================================================\n";
if ($failures !== []) {
    echo "FAILED with " . count($failures) . " errors\n";
    exit(1);
} else {
    echo "ALL QA RELEASE / ORDER DISPATCH SYNC TESTS PASSED! (0 failures)\n";
    echo "======================================================================\n";
    exit(0);
}
