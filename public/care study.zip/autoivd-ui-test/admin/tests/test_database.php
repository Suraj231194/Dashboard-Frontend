<?php

declare(strict_types=1);

function testDatabaseFromCredentialFile(string $path): mysqli
{
    if (!is_readable($path)) {
        throw new RuntimeException('The test credential file is not readable.');
    }

    $raw = (string) file_get_contents($path);
    preg_match_all(
        '~\b(Host|Port|Database|Username|Password):\s*(.*?)(?=\s+\b(?:Host|Port|Database|Username|Password):|$)~s',
        $raw,
        $matches,
        PREG_SET_ORDER
    );
    $config = [];
    foreach ($matches as $match) {
        $config[strtolower($match[1])] = trim($match[2]);
    }
    foreach (['host', 'port', 'database', 'username', 'password'] as $key) {
        if (!isset($config[$key])) {
            throw new RuntimeException("The credential file is missing {$key}.");
        }
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conn = new mysqli(
        $config['host'],
        $config['username'],
        $config['password'],
        $config['database'],
        (int) $config['port']
    );
    $conn->set_charset('utf8mb4');

    return $conn;
}
