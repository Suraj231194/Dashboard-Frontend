<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_legacy_layout.php';

$projectRoot = dirname(__DIR__, 2);
$catalogPath = $projectRoot . '/assets/bmr-bpr-templates/catalog.json';
$failures = [];

$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$catalog = json_decode((string) file_get_contents($catalogPath), true);
$mappedTemplates = $catalog['templates'] ?? [];
$unmappedTemplates = $catalog['unmapped_templates'] ?? [];
$allTemplates = array_merge($mappedTemplates, $unmappedTemplates);

$assert(is_array($catalog), 'The source template catalog is invalid JSON.');
$assert(count($mappedTemplates) === 127, 'Expected 127 mapped source templates.');
$assert(count($unmappedTemplates) === 14, 'Expected 14 unmapped source references.');
$assert(count($allTemplates) === 141, 'Expected all 141 approved source documents.');

$codes = [];
$mappingKeys = [];
$productCodesByForm = ['BMR' => [], 'BPR' => []];
foreach ($allTemplates as $template) {
    $templateCode = (string) ($template['template_code'] ?? '');
    $assert($templateCode !== '', 'A template code is missing.');
    $assert(!isset($codes[$templateCode]), "Duplicate template code: {$templateCode}");
    $codes[$templateCode] = true;

    $sourcePath = $projectRoot . '/' . ltrim((string) ($template['source_pdf_path'] ?? ''), '/');
    $layoutPath = $projectRoot . '/' . ltrim((string) ($template['layout_path'] ?? ''), '/');
    $assetDirectory = $projectRoot . '/' . ltrim((string) ($template['asset_directory'] ?? ''), '/');
    $assert(is_file($sourcePath), "Missing source PDF: {$templateCode}");
    $assert(is_file($layoutPath), "Missing layout JSON: {$templateCode}");
    if (!is_file($sourcePath) || !is_file($layoutPath)) {
        continue;
    }

    $assert(
        hash_file('sha256', $sourcePath) === (string) ($template['source_checksum'] ?? ''),
        "Source checksum mismatch: {$templateCode}"
    );
    $layout = json_decode((string) file_get_contents($layoutPath), true);
    $layout = bmrBprNormalizeLegacyLayout(is_array($layout) ? $layout : []);
    $defects = bmrBprLegacyLayoutDefects($layout);
    $assert(
        array_sum($defects) === 0,
        "Known legacy field geometry defects remain: {$templateCode}"
    );
    $pages = is_array($layout['pages'] ?? null) ? $layout['pages'] : [];
    $pageCount = (int) ($template['page_count'] ?? 0);
    $assert(count($pages) === $pageCount, "Page count mismatch: {$templateCode}");
    foreach ($pages as $page) {
        $imagePath = $assetDirectory . '/' . (string) ($page['image'] ?? '');
        $assert(is_file($imagePath), "Missing page image: {$templateCode}");
        foreach (($page['fields'] ?? []) as $field) {
            foreach (['x', 'y', 'w', 'h'] as $coordinate) {
                $assert(
                    is_numeric($field[$coordinate] ?? null),
                    "Invalid {$coordinate} coordinate: {$templateCode}"
                );
            }
            $assert(
                (float) ($field['x'] ?? -1) >= 0
                    && (float) ($field['y'] ?? -1) >= 0
                    && (float) ($field['x'] ?? 101) + (float) ($field['w'] ?? 0) <= 100.01
                    && (float) ($field['y'] ?? 101) + (float) ($field['h'] ?? 0) <= 100.01,
                "Out-of-bounds field: {$templateCode}"
            );
        }
    }

    $formType = strtoupper((string) ($template['form_type'] ?? ''));
    $documentSequence = max(1, (int) ($template['document_sequence'] ?? 1));
    foreach (($template['product_codes'] ?? []) as $productCodeValue) {
        $productCode = trim((string) $productCodeValue);
        $assert($productCode !== '', "Empty product code: {$templateCode}");
        $productCodesByForm[$formType][$productCode] = true;
        $mappingKey = "{$productCode}:{$formType}:{$documentSequence}";
        $assert(!isset($mappingKeys[$mappingKey]), "Duplicate mapping: {$mappingKey}");
        $mappingKeys[$mappingKey] = $templateCode;
    }
}

$assert(count($productCodesByForm['BMR']) === 171, 'Expected 171 BMR products.');
$assert(count($productCodesByForm['BPR']) === 171, 'Expected 171 BPR products.');
$twoPartCode = 'BGX/SF.US.URIN/2026/000002';
$assert(
    ($mappingKeys["{$twoPartCode}:BMR:1"] ?? '') === 'URINE_GLUCOSE_UNCUT_BMR_V02',
    'The two-part urine product must use Glucose as BMR document 1.'
);
$assert(
    ($mappingKeys["{$twoPartCode}:BMR:2"] ?? '') === 'URINE_PROTEIN_UNCUT_BMR_V02',
    'The two-part urine product must use Protein as BMR document 2.'
);

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "BMR/BPR source catalog smoke test passed.\n";
echo "Templates: 141 (127 mapped, 14 unmapped references)\n";
echo "Selectable source-backed products: 171 BMR and 171 BPR\n";
