<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$admin = dirname(__DIR__);
$ajax = (string) file_get_contents($admin . '/ajax.php');
$functions = (string) file_get_contents($admin . '/functions.php');
$finance = (string) file_get_contents($admin . '/finance/finance_common.php');
$migration = (string) file_get_contents($admin . '/migrations/2026_09_07_001_procurement_flow_completion_pending.sql');
$workflowMigration = (string) file_get_contents($admin . '/migrations/2026_09_07_002_pdf_workflow_completion_pending.sql');
$goodsReceiptMigration = (string) file_get_contents($admin . '/migrations/2026_09_17_001_goods_receipt_document_alignment_pending.sql');
$qualityHardeningMigration = (string) file_get_contents($admin . '/migrations/2026_09_18_001_procurement_quality_hardening_pending.sql');
$catSequenceRepairMigration = (string) file_get_contents($admin . '/migrations/2026_09_15_001_repair_product_cat_sequence_scope_pending.sql');
$migrationRunner = (string) file_get_contents($admin . '/migrations/execute_all_pending.php');
$templatePage = (string) file_get_contents($admin . '/pages/coa-templates.php');
$purchasePage = (string) file_get_contents($admin . '/pages/purchase-management.php');
$meetingPage = (string) file_get_contents($admin . '/pages/meeting-requests.php');

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$assert(
    str_contains($ajax, '"ssiisidisissiiddisi"'),
    'Stores purchase requests must bind all 19 submitted values.'
);
$assert(
    str_contains($ajax, '"iiiisssdididi"'),
    'Goods Receipt must bind the live-stock quantity and unit factor as decimals.'
);
$assert(
    !str_contains($ajax, 'UPDATE `purchase_order_final` SET `status` = 1 WHERE `po_order_num` = ?'),
    'A partial receipt must not reopen completed PM lines.'
);
$assert(
    str_contains($ajax, '$approvalStatus = 0;')
        && str_contains($ajax, 'ready for Sample Advice'),
    'Initial testing must route to Sample Advice before final COA.'
);
$assert(
    str_contains($ajax, 'Select the configured material testing template')
        && str_contains($ajax, 'Every testing parameter requires an observation.'),
    'Inbound Quality must enforce the configured template and observations.'
);
$assert(
    str_contains($ajax, 'receipt_submission_token')
        && str_contains($migration, 'uq_stock_inward_submission_item'),
    'Goods Receipt retries must be protected by an idempotency token.'
);
$assert(
    str_contains($migration, 'quantity_required_decimal')
        && str_contains($migration, 'DECIMAL(20,8)'),
    'Procurement quantities must have a decimal-safe storage path.'
);
$assert(
    str_contains($migration, 'low_stock_aging_days')
        && str_contains($migration, 'IN (30, 60)')
        && str_contains($functions, 'function mvGetProcurementAgingDays')
        && str_contains($ajax, 'INTERVAL {$agingDays} DAY')
        && !str_contains($ajax, 'INTERVAL 30 DAY')
        && str_contains($ajax, 'saveProcurementAgingSetting'),
    'Low-stock aging must be a global setting restricted to 30 or 60 days with a 30-day default.'
);
$assert(
    str_contains($migration, 'coa_templates')
        && str_contains($migration, 'product_id')
        && str_contains($ajax, '(product_id = ? OR (product_id IS NULL AND prod_categ_id = ?))')
        && str_contains($templatePage, 'name="templateProductId"'),
    'Material testing templates must support exact product mappings with legacy category fallback.'
);
$assert(
    str_contains($migrationRunner, 'assertProcurementFlowMigrationSafe')
        && str_contains($migrationRunner, 'duplicate RM request-to-PO links'),
    'The migration runner must reject conflicting links before adding uniqueness constraints.'
);
$assert(
    str_contains($finance, 'function financeVendorBillReceiptEligibilitySql')
        && str_contains($finance, 'COALESCE(si.status, 1) != 3')
        && !str_contains($finance, 'approved_coa.approval_status = 1')
        && !str_contains($finance, 'approved_coa.coa_approval_status = 1'),
    'Incoming Bills must become eligible immediately after Goods Receipt submission.'
);
$assert(
    str_contains($finance, 'Incoming Bill COA reconciliation')
        && str_contains($finance, "item.source_table = 'stock_inwards'")
        && str_contains($finance, 'item.coa_number = coa.coa_number')
        && str_contains($ajax, 'Incoming Bill COA reconciliation failed after COA number generation'),
    'Incoming Bill lines must receive the COA number when Quality generates it later.'
);
$assert(
substr_count($ajax, 'Every submitted Goods Receipt initiates Quality Control.') === 2,
    'Both PO and manual Goods Receipt paths must initiate Quality regardless of physical condition.'
);
$assert(
    str_contains($goodsReceiptMigration, 'INSERT IGNORE INTO `coa_inbound_queue`')
        && str_contains($goodsReceiptMigration, 'existing_coa.`stock_inward_id` = inward.`id`')
        && str_contains($migrationRunner, '2026_09_17_001_goods_receipt_document_alignment_pending.sql'),
    'Existing RM/PM Goods Receipts without Quality records must be safely backfilled.'
);
$assert(
    str_contains($ajax, "['RM', 'PM', 'FG', 'CON']")
        && str_contains($qualityHardeningMigration, "ENUM('RM','PM','FG','CON')")
        && str_contains($migrationRunner, '2026_09_18_001_procurement_quality_hardening_pending.sql'),
    'Inbound Quality must accept all procurement inventory groups and persist their material types.'
);
$assert(
    str_contains($functions, "`sequence_scope` = ?")
        && str_contains($workflowMigration, 'sequence_scope')
        && str_contains($catSequenceRepairMigration, 'ADD COLUMN IF NOT EXISTS `sequence_scope`')
        && str_contains($catSequenceRepairMigration, 'ADD PRIMARY KEY (`company_code`, `financial_year_start`, `sequence_scope`)')
        && str_contains($migrationRunner, '2026_09_15_001_repair_product_cat_sequence_scope_pending.sql'),
    'CAT sequences must remain independent for each category and product stage.'
);
$assert(
    str_contains($finance, 'si.receipt_submission_token')
        && str_contains($finance, "'receipt:'"),
    'Invoice-free Goods Receipt lines must remain grouped under one Incoming Bill submission.'
);
$assert(
    str_contains($functions, 'function mvCreateLowStockRequestsForOrder')
        && str_contains($ajax, 'createInventoryProcurementRequests')
        && str_contains($ajax, 'addLowStocksRecord'),
    'Order, Live Inventory, and Stores procurement sources must remain available.'
);
$assert(
    str_contains($ajax, 'dispatchDestinationIndex[')
        && str_contains($ajax, '$oPlaceOfDispatch = $destinationAddress')
        && str_contains($finance, 'NULLIF(TRIM(so.place_of_dispatch)')
        && str_contains($finance, 'counterparty_shipping_address'),
    'Multi-location dispatches must preserve the selected destination through Finance.'
);
$assert(
    str_contains($ajax, 'additionalProductId')
        && str_contains($ajax, 'Product added to the existing production campaign.')
        && str_contains($workflowMigration, 'DROP INDEX IF EXISTS `uq_production_plans_plan_no`'),
    'An unstarted production campaign must allow another product to be added during edit.'
);
$assert(
    str_contains($meetingPage, 'const shouldSelect = $columns.filter(\':checked\').length === 0;')
        && str_contains($meetingPage, "hasSelectedColumns ? 'Deselect All' : 'Select All'"),
    'Meeting Request export columns must support both Select All and Deselect All.'
);

if ($failures !== []) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "PASS: procurement, Quality, Billing, dispatch, production campaign and export workflow contracts.\n";
