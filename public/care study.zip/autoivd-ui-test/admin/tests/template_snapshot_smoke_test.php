<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->begin_transaction();
try {
    $userId = (int) ($conn->query('SELECT id FROM users ORDER BY id LIMIT 1')->fetch_row()[0] ?? 0);
    if ($userId <= 0) {
        throw new RuntimeException('A user is required for the snapshot smoke test.');
    }
    $id = templateSnapshotInsert($conn, [
        'document_type' => 'BMR',
        'source_template_id' => 1,
        'template_code' => 'SMOKE',
        'template_name' => 'Snapshot smoke test',
        'product_name' => 'Test product',
        'selection_source' => 'PREMAPPED',
        'renderer' => 'structured_html',
        'layout' => ['schema_version' => 1, 'pages' => []],
        'profile' => ['family_key' => 'smoke'],
    ], $userId);
    $snapshot = templateSnapshotLoad($conn, $id);
    if (!$snapshot || ($snapshot['profile']['family_key'] ?? '') !== 'smoke') {
        throw new RuntimeException('Snapshot round-trip failed.');
    }
    $conn->query("UPDATE template_snapshots SET metadata_json = '{\tampered\:true}' WHERE id = {$id}");
    try {
        templateSnapshotLoad($conn, $id);
        throw new RuntimeException('Snapshot metadata tampering was not detected.');
    } catch (RuntimeException $exception) {
        if (!str_contains($exception->getMessage(), 'integrity check')) {
            throw $exception;
        }
    }
    $coaSnapshotId = templateSnapshotInsert($conn, [
        'document_type' => 'IP_COA',
        'source_template_id' => 77,
        'template_code' => 'IP-SMOKE',
        'template_name' => 'IP snapshot smoke test',
        'product_name' => 'Test product',
        'family_key' => 'smoke-family',
        'selection_source' => 'MANUAL_OVERRIDE',
        'renderer' => 'structured_coa_html',
        'layout' => ['schema_version' => 1, 'coa_type' => 'IP'],
        'profile' => ['family_key' => 'smoke-family', 'editable_field_keys' => ['results.assay']],
    ], $userId);
    $validated = coaTemplateValidateSnapshotSubmission(
        $conn,
        $coaSnapshotId,
        'IP',
        77,
        ['fields' => ['results.assay' => 'Pass']],
        false
    );
    if (($validated['payload']['fields']['results.assay'] ?? '') !== 'Pass') {
        throw new RuntimeException('COA snapshot validation failed.');
    }

    $template = $conn->query("SELECT id, form_type FROM bmr_templates WHERE deleted_at IS NULL ORDER BY id LIMIT 1")->fetch_assoc();
    $product = $conn->query('SELECT id, product_name FROM products ORDER BY id LIMIT 1')->fetch_assoc();
    if ($template && $product) {
        $bmrSnapshotId = templateSnapshotCreateBmrBpr(
            $conn,
            (string) $template['form_type'],
            (int) $template['id'],
            (int) $product['id'],
            (string) $product['product_name'],
            '',
            $userId,
            'MANUAL_OVERRIDE'
        );
        if (templateSnapshotLoad($conn, $bmrSnapshotId) === null) {
            throw new RuntimeException('BMR/BPR snapshot creation failed.');
        }
    }
    $conn->rollback();
    echo "Template snapshot smoke test passed.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
