<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$source = (string) file_get_contents(dirname(__DIR__) . '/ajax.php');
$cases = [
    'production receipt' => [
        'marker' => '$insertStockStmt->bind_param(',
        'arguments' => [
            '$receiptProdId' => 'i', '$categoryId' => 'i', '$receiptLotBatchNo' => 's',
            '$coaNumber' => 's', '$mfgDate' => 's', '$expDate' => 's',
            '$actualQuantity' => 'd', '$unitId' => 'i', '$unitFactor' => 'd',
            '$quantityInBase' => 'd', '$receiptId' => 'i', '$userId' => 'i',
        ],
        'count' => 14,
    ],
    'purchase request' => [
        'marker' => 'if (isset($_POST["addLowStocksRecord"])',
        'arguments' => [
            '$reportingPerson' => 's', '$dateOfReport' => 's', '$matId' => 'i',
            '$prodId' => 'i', '$itemName' => 's', '$packId' => 'i', '$qtyReq' => 'd',
            '$qtyUnit' => 'i', '$vendName' => 's', '$critStatus' => 'i',
            '$expDeliDate' => 's', '$source' => 's', '$branch' => 'i', '$warehouse' => 'i',
            '$stockSnapshot' => 'd', '$reorderSnapshot' => 'd', '$currency' => 'i',
            '$priceValue' => 's', '$createdBy' => 'i',
        ],
        'count' => 19,
    ],
];

foreach ($cases as $name => $case) {
    $start = strpos($source, $case['marker']);
    if ($start === false || !preg_match('/->bind_param\(\s*([\'"])([idsb]+)\1\s*,(.*?)\);/s', substr($source, $start), $matches)) {
        throw new RuntimeException("Missing {$name} binding.");
    }
    $arguments = array_map('trim', explode(',', $matches[3]));
    $types = str_split($matches[2]);
    if (count($arguments) !== $case['count'] || count($types) !== count($arguments)) {
        throw new RuntimeException("Incorrect {$name} binding count.");
    }
    foreach ($arguments as $index => $argument) {
        if (($case['arguments'][$argument] ?? null) !== $types[$index]) {
            throw new RuntimeException("Incorrect {$name} type for {$argument}.");
        }
    }
}

echo "PASS: purchase request and production receipt parameter counts and types.\n";
