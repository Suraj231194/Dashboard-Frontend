<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$templates = $conn->query(
    "SELECT template_code, layout_json
     FROM bmr_templates
     WHERE status = 1 AND deleted_at IS NULL"
);
$legacyCount = 0;
$changedCount = 0;
while ($template = $templates->fetch_assoc()) {
    $layout = json_decode((string) $template['layout_json'], true);
    if (!is_array($layout) || (int) ($layout['schema_version'] ?? 1) >= 2) {
        continue;
    }
    $legacyCount++;
    $normalized = bmrBprNormalizeLegacyLayout($layout);
    if ($normalized !== $layout) {
        $changedCount++;
    }
    $defects = bmrBprLegacyLayoutDefects($normalized);
    $assert(
        array_sum($defects) === 0,
        $template['template_code'] . ': known legacy geometry defects remain after normalization.'
    );
}
$assert($legacyCount > 0, 'No active legacy BMR/BPR templates were audited.');

$aso = $conn->query(
    "SELECT layout_json FROM bmr_templates
     WHERE template_code = 'ASO_BMR_V02' AND status = 1 AND deleted_at IS NULL LIMIT 1"
)->fetch_assoc();
$asoLayout = json_decode((string) ($aso['layout_json'] ?? ''), true);
$asoNormalized = bmrBprNormalizeLegacyLayout(is_array($asoLayout) ? $asoLayout : []);
$asoPageOne = (array) ($asoNormalized['pages'][0] ?? []);
$asoFields = [];
foreach ((array) ($asoPageOne['fields'] ?? []) as $field) {
    $asoFields[(string) ($field['id'] ?? '')] = $field;
}
$assert(!isset($asoFields['p1_t1_r1_c1']), 'ASO logo cell remains editable.');
$assert(!isset($asoFields['p1_t2_r1_c4']), 'ASO grid fragment remains editable.');
$assert(!isset($asoFields['p1_t1_r5_c5']), 'ASO product-row artefact remains editable.');
$assert(
    (float) ($asoFields['p1_source_product_name_1']['w'] ?? 0) > 50,
    'ASO controlled product-name field was not expanded across its value cell.'
);

$preserved = bmrBprNormalizeLegacyLayout([
    'schema_version' => 1,
    'pages' => [[
        'page' => 1,
        'width' => 596,
        'height' => 842,
        'fields' => [[
            'id' => 'p1_t2_r1_c4',
            'x' => 30,
            'y' => 28,
            'w' => 0.8,
            'h' => 3.5,
            'editable' => true,
            'source' => null,
        ]],
    ]],
], ['p1_t2_r1_c4' => true]);
$preservedIds = array_column((array) ($preserved['pages'][0]['fields'] ?? []), 'id');
$assert(
    in_array('p1_t2_r1_c4', $preservedIds, true),
    'A populated legacy field was not preserved.'
);

$workItem = $conn->query(
    "SELECT id FROM bmr_bpr_work_items
     WHERE id = 540 AND deleted_at IS NULL LIMIT 1"
)->fetch_assoc();
if ((int) ($workItem['id'] ?? 0) === 540) {
    $form = bmrBprLoadWorkItemTemplate($conn, 540);
    $formFields = [];
    foreach ((array) ($form['layout']['pages'][0]['fields'] ?? []) as $field) {
        $formFields[(string) ($field['id'] ?? '')] = $field;
    }
    $assert(!isset($formFields['p1_t1_r1_c1']), 'Work item 540 still renders over the logo.');
    $assert(!isset($formFields['p1_t2_r1_c4']), 'Work item 540 still renders a grid fragment.');
    $assert(
        (float) ($formFields['p1_source_product_name_1']['w'] ?? 0) > 50,
        'Work item 540 still clips the controlled product name.'
    );
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Legacy BMR/BPR layout normalization smoke test passed for {$legacyCount} active templates; "
    . "{$changedCount} required runtime repair before persistence." . PHP_EOL;
