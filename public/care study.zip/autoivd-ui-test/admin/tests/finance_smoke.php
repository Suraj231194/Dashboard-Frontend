<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/finance/finance_common.php';
require_once dirname(__DIR__) . '/finance/finance_pdf.php';

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$assert(financeFinancialYear('2026-03-31') === '2025-26', 'Financial year before April is incorrect.');
$assert(financeFinancialYear('2026-04-01') === '2026-27', 'Financial year from April is incorrect.');
$assert(
    financePagePermissionSlug('finance-bill-generation') === 'finance_bill_generation_view',
    'Finance Bill Generation route does not resolve to its view permission.'
);
$assert(
    financePagePermissionSlug('finance-challan-generation') === 'finance_delivery_challan_generation_view',
    'Finance Delivery Challan route does not resolve to its view permission.'
);
$assert(
    financePageView('finance-trade-receivables') === 'trade_receivables',
    'Finance Trade Receivables route does not resolve to its shared page view.'
);
$assert(
    financePagePermissionSlug('dashboard') === null && financePageView('dashboard') === null,
    'Finance route fallback is affecting an existing non-Finance page.'
);
$drainCalls = 0;
$drained = financeDrainSourceSync(
    static function (int $limit) use (&$drainCalls): int {
        $drainCalls++;
        return $drainCalls < 3 ? $limit : 37;
    }
);
$assert(
    $drained === 2037 && $drainCalls === 3,
    'Source reconciliation does not drain backlogs in bounded batches.'
);

$sample = [[
    'product_name' => 'Finance Test Product',
    'hsn_code' => '3002',
    'quantity' => 2,
    'rate' => 100,
    'mrp' => 120,
    'discount_percent' => 10,
    'cgst_percent' => 9,
    'sgst_percent' => 9,
    'igst_percent' => 0,
]];
$intra = financeCalculateItems($sample, 'SALES_INVOICE', 'INTRA');
$assert(abs($intra['totals']['taxable_total'] - 180.0) < 0.001, 'Invoice taxable calculation is incorrect.');
$assert(abs($intra['totals']['cgst_total'] - 16.2) < 0.001, 'Invoice CGST calculation is incorrect.');
$assert(abs($intra['totals']['sgst_total'] - 16.2) < 0.001, 'Invoice SGST calculation is incorrect.');
$assert(abs($intra['totals']['grand_total'] - 212.0) < 0.001, 'Invoice nearest-rupee total is incorrect.');

$inter = financeCalculateItems($sample, 'SALES_INVOICE', 'INTER');
$assert(abs($inter['totals']['igst_total'] - 32.4) < 0.001, 'Invoice IGST fallback calculation is incorrect.');
$challan = financeCalculateItems($sample, 'DELIVERY_CHALLAN', 'NONE');
$assert(abs($challan['totals']['grand_total'] - 200.0) < 0.001, 'Delivery Challan amount calculation is incorrect.');

$requiredTables = [
    'finance_company_bank_accounts',
    'finance_document_terms',
    'finance_counterparty_credit_terms',
    'finance_product_commercials',
    'finance_number_sequences',
    'finance_documents',
    'finance_document_items',
    'finance_document_source_links',
    'finance_document_files',
    'finance_payments',
    'finance_payment_allocations',
    'finance_document_history',
];
foreach ($requiredTables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
    $assert($result && $result->num_rows === 1, "Missing Finance table: {$table}.");
}

$bankSnapshotColumn = $conn->query(
    "SHOW COLUMNS FROM finance_documents LIKE 'bank_snapshot'"
);
$assert(
    $bankSnapshotColumn && $bankSnapshotColumn->num_rows === 1,
    'Finance documents do not support per-document bank snapshots.'
);

$sequenceIndex = $conn->query(
    "SHOW INDEX FROM finance_number_sequences WHERE Key_name = 'uq_finance_sequence'"
);
$generatedNumberIndex = $conn->query(
    "SHOW INDEX FROM finance_documents WHERE Key_name = 'uq_finance_generated_number'"
);
$assert(
    $sequenceIndex && $sequenceIndex->num_rows === 3
        && (int) ($sequenceIndex->fetch_assoc()['Non_unique'] ?? 1) === 0,
    'The company/document/financial-year sequence key is not unique.'
);
$assert(
    $generatedNumberIndex && $generatedNumberIndex->num_rows === 3
        && (int) ($generatedNumberIndex->fetch_assoc()['Non_unique'] ?? 1) === 0,
    'Generated Finance document numbers are not protected by a unique key.'
);

$requiredPermissions = [
    'finance_bill_generation_view',
    'finance_bill_generation_manage',
    'finance_payment_made_view',
    'finance_payment_made_manage',
    'finance_trade_payables_view',
    'finance_trade_payables_manage',
    'finance_invoice_generation_view',
    'finance_invoice_generation_manage',
    'finance_delivery_challan_generation_view',
    'finance_delivery_challan_generation_manage',
    'finance_payment_received_view',
    'finance_payment_received_manage',
    'finance_trade_receivables_view',
    'finance_trade_receivables_manage',
];
$quotedPermissions = implode(
    ',',
    array_map(
        static fn(string $slug): string => "'" . $conn->real_escape_string($slug) . "'",
        $requiredPermissions
    )
);
$permissionResult = $conn->query(
    "SELECT COUNT(DISTINCT slug) AS total
     FROM permissions
     WHERE status = 1 AND slug IN ({$quotedPermissions})"
);
$assert(
    (int) (($permissionResult ? $permissionResult->fetch_assoc()['total'] ?? 0 : 0))
        === count($requiredPermissions),
    'The complete Finance view/manage permission set is not installed.'
);

$roleResult = $conn->query(
    "SELECT r.name, COUNT(DISTINCT p.slug) AS finance_permissions
     FROM roles r
     LEFT JOIN role_permissions rp
       ON rp.role_id = r.id AND rp.status = 1
     LEFT JOIN permissions p
       ON p.id = rp.permission_id AND p.status = 1 AND p.slug LIKE 'finance\\_%' ESCAPE '\\\\'
     WHERE r.status = 1
       AND r.deleted_at IS NULL
       AND r.name IN (
           'Super Administrator',
           'Administrator',
           'Senior Administrator',
           'Production + Ops /Admin + Sales & Billing',
           'Sales & Marketting + Sales & Billing'
       )
     GROUP BY r.id, r.name"
);
$nonAdministratorRoleValidated = false;
while ($roleResult && $role = $roleResult->fetch_assoc()) {
    $assert(
        (int) $role['finance_permissions'] === count($requiredPermissions),
        'Finance permissions are incomplete for role: ' . $role['name'] . '.'
    );
    if (!in_array($role['name'], ['Super Administrator', 'Administrator', 'Senior Administrator'], true)) {
        $nonAdministratorRoleValidated = true;
    }
}
$assert(
    $nonAdministratorRoleValidated,
    'No configured non-administrator Finance role was available for permission validation.'
);

$requiredRoutes = [
    'index.php?page=finance-bill-generation',
    'index.php?page=finance-payment-made',
    'index.php?page=finance-trade-payables',
    'index.php?page=finance-invoice-generation',
    'index.php?page=finance-challan-generation',
    'index.php?page=finance-payment-received',
    'index.php?page=finance-trade-receivables',
];
$quotedRoutes = implode(
    ',',
    array_map(
        static fn(string $route): string => "'" . $conn->real_escape_string($route) . "'",
        $requiredRoutes
    )
);
$menuResult = $conn->query(
    "SELECT COUNT(DISTINCT route) AS total
     FROM menus
     WHERE status = 1 AND deleted_at IS NULL AND route IN ({$quotedRoutes})"
);
$assert(
    (int) (($menuResult ? $menuResult->fetch_assoc()['total'] ?? 0 : 0)) === count($requiredRoutes),
    'The complete Finance sidebar route set is not installed.'
);

$assert(
    financeSourceTableExists($conn, 'proforma_invoices')
        && financeSourceTableExists($conn, 'proforma_invoice_items'),
    'Existing Proforma Invoice master-data sources are not available.'
);
try {
    $conn->begin_transaction();
    financeEnrichDispatchDocumentsFromProforma($conn, 'SALES_INVOICE', true);
    financeEnrichDispatchDocumentsFromProforma($conn, 'DELIVERY_CHALLAN', true);
    $conn->rollback();
} catch (Throwable $error) {
    $conn->rollback();
    $failures[] = 'Proforma-to-Finance source mapping failed: ' . $error->getMessage();
}

$counts = [];
$result = $conn->query(
    "SELECT document_type, COUNT(*) AS total
     FROM finance_documents
     WHERE deleted_at IS NULL
     GROUP BY document_type"
);
while ($result && $row = $result->fetch_assoc()) {
    $counts[$row['document_type']] = (int) $row['total'];
}
$assert(($counts['VENDOR_BILL'] ?? 0) > 0, 'No vendor bills are connected to Goods Received.');
$assert(($counts['SALES_INVOICE'] ?? 0) > 0, 'No invoices are connected to Goods Dispatch.');
$assert(($counts['DELIVERY_CHALLAN'] ?? 0) > 0, 'No challans are connected to Goods Dispatch.');

$testUserResult = $conn->query("SELECT id FROM users ORDER BY id LIMIT 1");
$testUserId = (int) (($testUserResult ? $testUserResult->fetch_assoc()['id'] ?? 0 : 0));
$refreshResult = $conn->query(
    "SELECT fd.id, fd.erp_company_id, fd.document_type, fd.document_date
     FROM finance_documents fd
     JOIN stock_outward so ON so.id = fd.dispatch_id
     WHERE fd.document_type = 'SALES_INVOICE'
       AND fd.source_type = 'STOCK_OUTWARD'
       AND fd.status IN ('PENDING', 'DRAFT')
       AND fd.deleted_at IS NULL
       AND so.status = 1
       AND so.deleted_at IS NULL
     ORDER BY fd.id DESC
     LIMIT 1"
);
$refreshDocument = $refreshResult ? $refreshResult->fetch_assoc() : null;
$assert($testUserId > 0, 'No test user is available for rollback-only Finance validation.');
$assert($refreshDocument !== null, 'No pending dispatch is available for snapshot refresh validation.');
if ($testUserId > 0 && $refreshDocument) {
    try {
        $conn->begin_transaction();
        financeRefreshDispatchDocumentFromSource($conn, (int) $refreshDocument['id'], $testUserId);
        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS total FROM finance_document_items WHERE document_id = ?"
        );
        $refreshDocumentId = (int) $refreshDocument['id'];
        $stmt->bind_param('i', $refreshDocumentId);
        $stmt->execute();
        $refreshedItemCount = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $stmt->close();
        $assert($refreshedItemCount > 0, 'Targeted dispatch refresh produced no Finance item snapshot.');
        $conn->rollback();
    } catch (Throwable $error) {
        $conn->rollback();
        $failures[] = 'Targeted dispatch refresh failed: ' . $error->getMessage();
    }

    try {
        $conn->begin_transaction();
        $firstNumber = financeNextNumber(
            $conn,
            (int) $refreshDocument['erp_company_id'],
            (string) $refreshDocument['document_type'],
            (string) $refreshDocument['document_date']
        );
        $secondNumber = financeNextNumber(
            $conn,
            (int) $refreshDocument['erp_company_id'],
            (string) $refreshDocument['document_type'],
            (string) $refreshDocument['document_date']
        );
        $firstSequence = (int) substr($firstNumber, strrpos($firstNumber, '/') + 1);
        $secondSequence = (int) substr($secondNumber, strrpos($secondNumber, '/') + 1);
        $assert(
            $secondSequence === $firstSequence + 1,
            'Finance numbering does not advance sequentially while the sequence row is locked.'
        );
        $conn->rollback();
    } catch (Throwable $error) {
        $conn->rollback();
        $failures[] = 'Rollback-only Finance numbering validation failed: ' . $error->getMessage();
    }
}

$result = $conn->query(
    "SELECT id
     FROM finance_documents
     WHERE document_type = 'SALES_INVOICE' AND deleted_at IS NULL
     ORDER BY id DESC
     LIMIT 1"
);
$documentId = (int) (($result ? $result->fetch_assoc()['id'] ?? 0 : 0));
$document = $documentId > 0 ? financeGetDocument($conn, $documentId) : null;
$assert($document !== null, 'Unable to read an imported Finance invoice.');
$assert(!empty($document['items']), 'Imported Finance invoice has no product snapshot.');
$assert(!empty($document['company']), 'Finance invoice has no company snapshot.');
$assert(!empty($document['terms_snapshot']), 'Approved default terms are not available.');
$assert(!empty($document['bank_accounts']), 'Approved default bank details are not available.');
if ($document) {
    $invoiceHtml = financeBuildDocumentHtml($document);
    $assert(str_contains($invoiceHtml, 'GST INVOICE'), 'Invoice template title is missing.');
    $document['items'] = array_slice($document['items'], 0, 12);
    $invoiceTemplate = financeApprovedTemplateDefinition('SALES_INVOICE');
    $invoiceSource = file_get_contents($invoiceTemplate['path']);
    $invoicePdf = financeBuildApprovedTemplatePdf($document);
    $assert(
        $invoiceSource !== false && str_starts_with($invoicePdf, $invoiceSource),
        'Generated invoice is not based on the exact supplied Invoice_1697.pdf file.'
    );
    $multiPageDocument = $document;
    while (count($multiPageDocument['items']) < 13) {
        $copy = $multiPageDocument['items'][0];
        $copy['id'] = 0;
        $copy['product_name'] = 'Finance multi-page line ' . (count($multiPageDocument['items']) + 1);
        $multiPageDocument['items'][] = $copy;
    }
    $multiPageDocument['terms_snapshot'] = implode(
        "\n",
        array_map(
            static fn(int $line): string => $line . '. Finance full terms continuation line for approved template validation.',
            range(1, 8)
        )
    );
    $multiPagePdf = financeBuildApprovedTemplatePdf($multiPageDocument);
    $multiPageTree = financePdfLastObjectBody($multiPagePdf, 2);
    $assert(
        preg_match('/\/Count\s+(\d+)/', $multiPageTree, $pageCountMatch) === 1
            && (int) $pageCountMatch[1] >= 2,
        'Approved Finance template output does not create continuation pages.'
    );
    $document['document_type'] = 'DELIVERY_CHALLAN';
    $challanHtml = financeBuildDocumentHtml($document);
    $assert(str_contains($challanHtml, '>CHALLAN<'), 'Challan template title is missing.');
    $challanTemplate = financeApprovedTemplateDefinition('DELIVERY_CHALLAN');
    $challanSource = file_get_contents($challanTemplate['path']);
    $challanPdf = financeBuildApprovedTemplatePdf($document);
    $assert(
        $challanSource !== false && str_starts_with($challanPdf, $challanSource),
        'Generated challan is not based on the exact supplied CA_200.pdf file.'
    );
}

$sharedAjax = file_get_contents(dirname(__DIR__) . '/ajax.php');
$adminIndex = file_get_contents(dirname(__DIR__) . '/index.php');
$financePage = file_get_contents(dirname(__DIR__) . '/pages/finance-page.php');
$assert(!is_file(dirname(__DIR__) . '/financeajax.php'), 'Legacy public financeajax.php must not exist.');
$assert(
    $sharedAjax !== false && str_contains($sharedAjax, "isset(\$_POST['financeAction'])"),
    'Finance is not routed through the shared admin/ajax.php endpoint.'
);
$assert(
    $sharedAjax !== false
        && str_contains($sharedAjax, 'financeSyncAfterGoodsReceipt')
        && str_contains($sharedAjax, 'financeSyncAfterGoodsDispatch'),
    'Goods Received/Goods Dispatch are not directly connected to Finance synchronization.'
);
$assert(
    $adminIndex !== false
        && str_contains($adminIndex, '$pageFile = "pages/{$page}.php";'),
    'Admin page routing is not using the standard flat pages directory.'
);
$financeWrappers = [
    'finance-bill-generation.php' => 'bill_generation',
    'finance-payment-made.php' => 'payment_made',
    'finance-trade-payables.php' => 'trade_payables',
    'finance-invoice-generation.php' => 'invoice_generation',
    'finance-challan-generation.php' => 'challan_generation',
    'finance-payment-received.php' => 'payment_received',
    'finance-trade-receivables.php' => 'trade_receivables',
];
foreach ($financeWrappers as $wrapperFile => $expectedView) {
    $wrapper = file_get_contents(dirname(__DIR__) . '/pages/' . $wrapperFile);
    $assert(
        $wrapper !== false
            && str_contains($wrapper, "\$financeView = '{$expectedView}';")
            && str_contains($wrapper, "require __DIR__ . '/finance-page.php';"),
        'Finance flat page wrapper is invalid: ' . $wrapperFile . '.'
    );
}
$assert(
    $financePage !== false
        && str_contains($financePage, "const endpoint = 'ajax.php'")
        && str_contains($financePage, 'url: endpoint')
        && str_contains($financePage, 'const incomingPerPage = 50')
        && str_contains($financePage, 'get_company_dependencies')
        && str_contains($financePage, 'renderProductionPlanPagination')
        && str_contains($financePage, 'financePaginationPrev')
        && str_contains($financePage, 'financeIncomingPaginationPrev')
        && str_contains($financePage, 'commercialPaginationPrev')
        && str_contains($financePage, 'Showing ${firstRow} to ${lastRow} of ${total} entries')
        && str_contains($financePage, 'btn btn-icon btn-label-${actionTone(tone)} finance-action-btn')
        && str_contains($financePage, "const icons = {Create: 'ti-plus', \"Don't\": 'ti-ban', Open: 'ti-eye'}")
        && !str_contains($financePage, 'financeOpenEditor(id);'),
    'Finance frontend is not using shared AJAX with Production Plan-style pagination and action buttons.'
);

if ($failures) {
    foreach ($failures as $failure) {
        fwrite(STDERR, "FAIL: {$failure}\n");
    }
    exit(1);
}

echo 'Finance smoke checks passed: calculations, schema, permissions, sidebar routes, shared AJAX, source connections, transactional refresh, numbering, defaults and exact supplied templates.' . PHP_EOL;
