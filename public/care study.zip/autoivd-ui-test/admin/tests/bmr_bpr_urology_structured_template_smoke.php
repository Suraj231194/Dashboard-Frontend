<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_structured_renderer.php';
require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

$schemaRoot = dirname(__DIR__, 2) . '/assets/bmr-bpr-schemas';
$schemaDefinitions = [
    [
        'path' => $schemaRoot . '/common-urology-bmr-v3.json',
        'product_ids' => [1047, 1048, 1049, 1050, 1051, 1052, 1342, 1466, 1705, 1787],
    ],
    [
        'path' => $schemaRoot . '/urology-glucose-uncut-bmr-v3.json',
        'product_ids' => [1422, 1863],
    ],
    [
        'path' => $schemaRoot . '/urology-protein-uncut-bmr-v3.json',
        'product_ids' => [1422, 1863],
    ],
    [
        'path' => $schemaRoot . '/common-urology-bpr-v3.json',
        'product_ids' => [1047, 1048, 1049, 1050, 1051, 1052, 1342, 1422, 1466, 1705, 1787, 1863],
    ],
];
$brandingLogoPath = dirname(__DIR__, 2) . '/assets/img/logo3.jpeg';
$brandingLogo = is_file($brandingLogoPath)
    ? (string) file_get_contents($brandingLogoPath)
    : '';
$brandingLogoDataUri = $brandingLogo === ''
    ? ''
    : 'data:image/jpeg;base64,' . base64_encode($brandingLogo);

$failures = [];
$renderedDocuments = 0;
$renderedPageCounts = [];

foreach ($schemaDefinitions as $definition) {
    $schemaFile = $definition['path'];
    $layout = json_decode((string) file_get_contents($schemaFile), true);
    if (
        !is_array($layout)
        || !bmrBprIsStructuredLayout($layout)
        || (string) ($layout['renderer_variant'] ?? '') !== 'urology'
    ) {
        $failures[] = basename($schemaFile) . ': invalid Urology structured schema';
        continue;
    }

    $productIds = array_values(array_map('intval', array_keys($layout['profiles'] ?? [])));
    sort($productIds);
    $expectedProductIds = $definition['product_ids'];
    sort($expectedProductIds);
    if ($productIds !== $expectedProductIds) {
        $failures[] = basename($schemaFile) . ': product profile set is incorrect';
        continue;
    }

    foreach ($productIds as $productId) {
        $profile = bmrBprStructuredProfile($layout, $productId);
        $expectedPages = (int) ($profile['page_count'] ?? 0);
        $formType = strtoupper((string) ($layout['form_type'] ?? ''));
        $form = [
            'form_type' => $formType,
            'layout' => $layout,
            'profile' => $profile,
            'branding_logo_data_uri' => $brandingLogoDataUri,
            'source_values' => [
                'product_name' => (string) ($profile['product_name'] ?? ''),
                'batch_number' => 'UROLOGY-SMOKE-001',
                'batch_size' => (string) ($profile['standard_batch'] ?? ''),
                'pack_size' => (string) ($profile['pack_size'] ?? ''),
                'record_number' => $formType . '/SMOKE/000001-01',
            ],
            'form_payload' => [
                'schema_version' => 2,
                'fields' => [
                    'cover.mfg_date' => '29/07/2026',
                    'qa.decision_remarks' => 'Urology structured smoke sentinel',
                ],
            ],
        ];

        $html = bmrBprRenderStructuredTemplate($form, true);
        preg_match_all('/<section class="[^"]*\bbmr-v2-page\b[^"]*"/', $html, $htmlPageMatches);
        $pageCount = count($htmlPageMatches[0] ?? []);
        if ($pageCount !== $expectedPages) {
            $failures[] = basename($schemaFile)
                . " product {$productId}: expected {$expectedPages} HTML pages, found {$pageCount}";
        }
        if (
            stripos($html, 'source.pdf') !== false
            || stripos($html, 'page-001') !== false
            || stripos($html, 'bmr-bpr-templates') !== false
        ) {
            $failures[] = basename($schemaFile)
                . " product {$productId}: renderer depends on product PDF/page artwork";
        }
        if (
            $brandingLogoDataUri !== ''
            && substr_count($html, 'class="bmr-v2-brand-logo"') !== $expectedPages
        ) {
            $failures[] = basename($schemaFile)
                . " product {$productId}: shared company logo is missing";
        }
        if (
            stripos($html, 'data-bmr-field="cover.mfg_date"') === false
            || (stripos($html, '29/07/2026') === false && stripos($html, '2026-07-29') === false)
            || stripos($html, 'Urology structured smoke sentinel') === false
        ) {
            $failures[] = basename($schemaFile)
                . " product {$productId}: editable/saved semantic fields are not rendered";
        }

        $printHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
            . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
            . '</head><body>'
            . bmrBprRenderStructuredTemplate($form, false)
            . '</body></html>';
        $options = new Dompdf\Options();
        $options->set('isRemoteEnabled', false);
        $options->set('defaultFont', 'Helvetica');
        $dompdf = new Dompdf\Dompdf($options);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->loadHtml($printHtml, 'UTF-8');
        $dompdf->render();
        $pdf = $dompdf->output();
        if (!str_starts_with($pdf, '%PDF-')) {
            $failures[] = basename($schemaFile) . " product {$productId}: Dompdf output is invalid";
        }
        $actualPdfPages = (int) $dompdf->getCanvas()->get_page_count();
        if ($actualPdfPages !== $expectedPages) {
            $sectionCounts = [];
            preg_match('/<style>.*?<\/style>/s', $printHtml, $styleMatch);
            preg_match_all(
                '/<section class="bmr-v2-page[^"]*".*?<\/section>/s',
                $printHtml,
                $sectionMatches
            );
            foreach ($sectionMatches[0] ?? [] as $sectionIndex => $sectionHtml) {
                $sectionDompdf = new Dompdf\Dompdf($options);
                $sectionDompdf->setPaper('A4', 'portrait');
                $sectionDompdf->loadHtml(
                    '<!DOCTYPE html><html><head><meta charset="UTF-8">'
                        . ($styleMatch[0] ?? '')
                        . '</head><body><div class="bmr-v2-document" data-form-type="'
                        . $formType . '">' . $sectionHtml . '</div></body></html>',
                    'UTF-8'
                );
                $sectionDompdf->render();
                $sectionCounts[] = ($sectionIndex + 1) . ':'
                    . $sectionDompdf->getCanvas()->get_page_count();
            }
            $failures[] = basename($schemaFile)
                . " product {$productId}: expected {$expectedPages} PDF pages, found {$actualPdfPages}"
                . ' (section pages ' . implode(', ', $sectionCounts) . ')';
        }
        $renderedPageCounts[$formType][$expectedPages] = true;
        $renderedDocuments++;
    }
}

foreach (['BMR' => [4, 5, 6, 7], 'BPR' => [6, 7, 8]] as $formType => $expectedCounts) {
    $actualCounts = array_map('intval', array_keys($renderedPageCounts[$formType] ?? []));
    sort($actualCounts);
    if ($actualCounts !== $expectedCounts) {
        $failures[] = "{$formType}: expected source pagination variants "
            . implode(', ', $expectedCounts) . '; found ' . implode(', ', $actualCounts);
    }
}

if ($renderedDocuments !== 26) {
    $failures[] = "Expected 26 distinct Urology product documents, rendered {$renderedDocuments}";
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Urology structured BMR/BPR smoke test passed for {$renderedDocuments} distinct product documents."
    . PHP_EOL;
