<?php
declare(strict_types=1);

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';

$failures = [];

echo "Running Notification 'Mark all as read' Verification Tests...\n";

// Test 1: Verify DOM elements in navbar.php and footer1.php
$navbarContent = file_get_contents(__DIR__ . '/../layout/navbar.php');
if ($navbarContent === false) {
    $failures[] = "Cannot read admin/layout/navbar.php";
} else {
    if (strpos($navbarContent, 'dropdown-notifications-all') === false) {
        $failures[] = "Missing .dropdown-notifications-all in navbar.php";
    }
    if (strpos($navbarContent, 'markAllNotificationsAsRead') === false) {
        $failures[] = "Missing markAllNotificationsAsRead onclick in navbar.php";
    }
}

$footerContent = file_get_contents(__DIR__ . '/../layout/footer1.php');
if ($footerContent === false) {
    $failures[] = "Cannot read admin/layout/footer1.php";
} else {
    if (strpos($footerContent, 'function markAllNotificationsAsRead') === false) {
        $failures[] = "Missing function markAllNotificationsAsRead in footer1.php";
    }
    if (strpos($footerContent, 'markAllAsReadNotifications') === false) {
        $failures[] = "Missing markAllAsReadNotifications AJAX call in footer1.php";
    }
}

// Test 2: Verify notificationajax.php endpoint handling
$ajaxContent = file_get_contents(__DIR__ . '/../notificationajax.php');
if ($ajaxContent === false) {
    $failures[] = "Cannot read admin/notificationajax.php";
} else {
    if (strpos($ajaxContent, 'markAllAsReadNotifications') === false) {
        $failures[] = "Missing markAllAsReadNotifications endpoint in notificationajax.php";
    }
}

// Test 3: Backend DB simulation of markAllAsReadNotifications logic
try {
    // Find an active user with notifications or use user 1 (superadmin)
    $userRow = $conn->query("SELECT id, role_id FROM users WHERE is_active = 1 AND deleted_at IS NULL LIMIT 1")->fetch_assoc();
    if ($userRow) {
        $testUserId = (int)$userRow['id'];
        $testRoleId = (int)$userRow['role_id'];

        // 1. Insert read records for role-based notifications
        $insertSql = "INSERT INTO notification_recipients (notification_id, user_id, is_read, read_at)
            SELECT DISTINCT n.id, ?, 1, NOW()
            FROM notifications n
            INNER JOIN notification_roles rl ON n.id = rl.notification_id AND rl.role_id = ?
            LEFT JOIN notification_recipients nr ON n.id = nr.notification_id AND nr.user_id = ?
            WHERE nr.id IS NULL";
        $stmt = $conn->prepare($insertSql);
        if ($stmt) {
            $stmt->bind_param("iii", $testUserId, $testRoleId, $testUserId);
            $stmt->execute();
            $stmt->close();
        }

        // 2. Mark existing recipient records as read
        $updateSql = "UPDATE notification_recipients
            SET is_read = 1, read_at = NOW()
            WHERE user_id = ? AND is_read = 0";
        $stmt = $conn->prepare($updateSql);
        if ($stmt) {
            $stmt->bind_param("i", $testUserId);
            $stmt->execute();
            $stmt->close();
        }

        // 3. Verify unread count is 0
        $checkStmt = $conn->prepare("SELECT COUNT(*) 
            FROM notifications n
            LEFT JOIN notification_recipients nr 
                ON n.id = nr.notification_id AND nr.user_id = ?
            LEFT JOIN notification_roles rl 
                ON n.id = rl.notification_id AND rl.role_id = ?
            WHERE (nr.user_id IS NOT NULL AND nr.is_read = 0 AND nr.is_archive = 0) 
               OR (nr.id IS NULL AND rl.notification_id IS NOT NULL)
        ");
        $checkStmt->bind_param("ii", $testUserId, $testRoleId);
        $checkStmt->execute();
        $checkStmt->bind_result($unreadCount);
        $checkStmt->fetch();
        $checkStmt->close();

        if ($unreadCount !== 0) {
            $failures[] = "Expected 0 unread notifications after markAllAsRead, got {$unreadCount}";
        } else {
            echo "Unread count verified: 0 unread notifications for user {$testUserId}.\n";
        }
    }
} catch (Throwable $e) {
    $failures[] = "Backend DB test threw exception: " . $e->getMessage();
}

if (!empty($failures)) {
    echo "TEST FAILURES (" . count($failures) . "):\n";
    foreach ($failures as $failure) {
        echo " - " . $failure . "\n";
    }
    exit(1);
}

echo "All Notification 'Mark all as read' tests passed successfully!\n";
exit(0);
