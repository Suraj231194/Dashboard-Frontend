<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$files = [
    'common' => 'hrms/annual_calendar_common.php',
    'api' => 'hrms/annual_calendar_api.php',
    'hrms_api' => 'hrms-api.php',
    'attendance' => 'hrms/hrms_common.php',
    'payroll' => 'payroll/payroll_common.php',
    'payroll_api' => 'payroll-api.php',
    'page' => 'pages/annual-calendar.php',
    'export' => 'annual-calendar-export.php',
    'migration' => 'migrations/2026_09_02_002_annual_calendar_production_ready.sql',
    'hardening_migration' => 'migrations/2026_09_02_003_annual_calendar_hardening.sql',
    'bootstrap' => 'migrations/bootstrap_annual_calendars.php',
    'functions' => 'functions.php',
    'settings' => 'pages/settings.php',
    'report' => 'ajax.php',
];
$source = [];
foreach ($files as $key => $relativePath) {
    $contents = file_get_contents($root . '/' . $relativePath);
    if ($contents === false) {
        fwrite(STDERR, "Unable to read {$relativePath}.\n");
        exit(1);
    }
    $source[$key] = $contents;
}

$assertions = [
    'versioned calendar lifecycle schema' => str_contains($source['migration'], "ENUM('draft','finalized','superseded')")
        && str_contains($source['migration'], 'revision_no')
        && str_contains($source['migration'], 'content_hash'),
    'materialized canonical day ledger' => str_contains($source['migration'], 'hr_annual_calendar_days')
        && str_contains($source['common'], 'function acPersistCalendarDays')
        && str_contains($source['common'], 'function acRequireFinalizedDaysForRange'),
    'company-scoped finalized lookup' => str_contains($source['common'], 'function acGetFinalizedCalendarForYear')
        && str_contains($source['common'], 'company_id = ?')
        && str_contains($source['common'], "lifecycle_status = 'finalized'"),
    'immutable reopen creates successor revision' => str_contains($source['common'], 'function acCreateDraftRevision')
        && str_contains($source['common'], 'supersedes_id')
        && str_contains($source['api'], 'A new draft revision was created'),
    'dedicated calendar RBAC' => str_contains($source['migration'], 'hrms_calendar_view')
        && str_contains($source['migration'], 'hrms_calendar_manage')
        && str_contains($source['migration'], 'hrms_calendar_finalize')
        && str_contains($source['migration'], 'hrms_calendar_reopen')
        && str_contains($source['migration'], 'hrms_calendar_export'),
    'tenant checks guard calendar APIs' => str_contains($source['api'], 'acApiAssertCompanyAccess')
        && str_contains($source['api'], "hrmsRequirePermission(\$conn, 'hrms_calendar_view')"),
    'calendar payload avoids reattaching normalized child data' => str_contains(
        $source['api'],
        "if (!array_key_exists('holidays', \$calendar))"
    ),
    'strict holiday validation and soft delete' => str_contains($source['common'], 'function acValidHolidayName')
        && str_contains($source['common'], 'function acValidHolidayType')
        && str_contains($source['api'], 'SET deleted_at = NOW()'),
    'leave excludes master-calendar nonworking dates' => str_contains($source['hrms_api'], 'acFilterChargeableLeaveDays')
        && str_contains($source['hrms_api'], 'calendar_day_type'),
    'attendance classifies master-calendar days' => str_contains($source['attendance'], 'acGetDayForCompanyDate')
        && str_contains($source['attendance'], "'off_day_work'"),
    'payroll requires and snapshots finalized calendar' => str_contains($source['payroll'], 'acRequireFinalizedDaysForRange')
        && str_contains($source['payroll_api'], 'calendar_revision_id')
        && str_contains($source['payroll_api'], 'calendar_hash'),
    'payroll covers leave LOP join and relieving' => str_contains($source['payroll'], 'payrollApprovedLeaveDateMap')
        && str_contains($source['payroll'], 'last_working_date')
        && str_contains($source['payroll'], 'lop_days'),
    'report resolves finalized calendar' => str_contains($source['report'], 'acGetFinalizedDaysForRange')
        && str_contains($source['report'], "day_type'] === 'weekly_off'"),
    'annual UI has full calendar audit and safe rendering' => str_contains($source['page'], 'id="acYearGrid"')
        && str_contains($source['page'], 'id="acAuditBody"')
        && str_contains($source['page'], 'function escapeHtml'),
    'finalized PDF and CSV export' => str_contains($source['export'], "['pdf', 'csv', 'audit']")
        && str_contains($source['export'], 'Content-Disposition')
        && str_contains($source['export'], "\$calendar['lifecycle_status'] !== 'finalized'"),
    'configurable weekly-off days and date overrides' => str_contains($source['hardening_migration'], 'weekly_off_days')
        && str_contains($source['hardening_migration'], 'hr_annual_calendar_day_overrides')
        && str_contains($source['common'], 'function acParseWeeklyOffDays')
        && str_contains($source['api'], "case 'save_calendar_day_override'"),
    'restricted holidays are optional and never deducted' => str_contains($source['hardening_migration'], 'is_optional')
        && str_contains($source['common'], 'function acSyncHolidayOptionalFlags')
        && str_contains($source['common'], '$mandatoryHolidays'),
    'ledger integrity is verified on every read' => str_contains($source['common'], 'function acAssertLedgerIntegrity')
        && str_contains($source['common'], 'function acCalendarLedgerHash')
        && str_contains($source['common'], 'hash_equals($storedHash'),
    'closed payroll periods are pinned to their revision' => str_contains($source['common'], 'function acPinnedCalendarIdForPeriod')
        && str_contains($source['hardening_migration'], 'fk_payroll_run_calendar_revision'),
    'reopen requires payroll impact acknowledgement' => str_contains($source['common'], '$payrollImpactAcknowledged')
        && str_contains($source['api'], 'hrms_calendar_override_locked')
        && str_contains($source['hardening_migration'], 'hrms_calendar_override_locked'),
    'optimistic locking guards finalization' => str_contains($source['common'], '$expectedLockVersion')
        && str_contains($source['api'], "\$_POST['lock_version']"),
    'copy-from-year and draft discard exist' => str_contains($source['common'], 'function acCopyCalendarFromYear')
        && str_contains($source['common'], 'function acDiscardDraftRevision')
        && str_contains($source['api'], "case 'copy_calendar_from_year'"),
    'legacy duplicate calendar endpoints are removed' => !str_contains($source['hrms_api'], "case 'load_annual_calendar':")
        && !str_contains($source['hrms_api'], "case 'finalize_annual_calendar':")
        && str_contains($source['hrms_api'], 'acHandleApiAction'),
    'legacy holiday paths are guarded and no longer per-day' => str_contains($source['report'], '$legacyHolidayMap')
        && !str_contains($source['report'], 'SELECT name, type FROM holidays')
        && str_contains($source['report'], "checkPermission('hrms_calendar_view', \$conn)"),
    'master calendar is preferred over the legacy holiday table' => str_contains($source['functions'], 'resolveSessionCompanyId')
        && str_contains($source['functions'], '$masterOnly'),
    'bootstrap backfill is available' => str_contains($source['bootstrap'], 'acFinalizeCalendar')
        && str_contains($source['bootstrap'], 'Legacy holidays table migration'),
    'jurisdiction-aware CSV holiday import with preview' => str_contains($source['common'], 'function acParseHolidayCsv')
        && str_contains($source['common'], 'function acImportHolidayRows')
        && str_contains($source['api'], "case 'import_holiday_csv'")
        && str_contains($source['api'], "\$_POST['confirm']")
        && str_contains($source['page'], 'acImportPreviewBtn'),
    'audit history can be filtered and exported' => str_contains($source['page'], 'acAuditFilter')
        && str_contains($source['export'], "'audit'")
        && str_contains($source['export'], 'Calendar_Audit_'),
    'legacy holiday writes are disabled after cutover' => str_contains($source['report'], 'This legacy list is read-only')
        && !str_contains($source['report'], 'editHolidayBtn')
        && str_contains($source['settings'], 'index.php?page=annual-calendar'),
];

$failures = array_keys(array_filter($assertions, static fn(bool $passed): bool => !$passed));
if ($failures !== []) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . PHP_EOL);
    exit(1);
}

echo 'PASS: ' . count($assertions) . ' Annual Calendar production assertions.' . PHP_EOL;
