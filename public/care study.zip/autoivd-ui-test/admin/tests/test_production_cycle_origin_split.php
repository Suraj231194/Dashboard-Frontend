<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

echo "======================================================================\n";
echo "   PRODUCTION CYCLE WORKFLOW: ORIGIN-SPLIT INTEGRATION TEST           \n";
echo "   Route A: Order Management Origin (Step 11 -> Step 12 -> Step 13)  \n";
echo "   Route B: Live Inventory Origin (Step 11 Finalizes & Credits Stock)\n";
echo "======================================================================\n\n";

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] {$message}\n";
    } else {
        echo "  [PASSED] {$message}\n";
    }
};

$adminUserId = 47;
$adminRoleId = 1;
$_SESSION['user_id'] = $adminUserId;
$_SESSION['role_id'] = $adminRoleId;
$_SESSION['csrf_token'] = 'origin_split_test_token_' . time();

// Set session timeouts on database connection
$conn->query("SET SESSION wait_timeout = 300, interactive_timeout = 300");

function getActiveConnection(?mysqli &$conn): mysqli
{
    if ($conn instanceof mysqli && @$conn->ping()) {
        return $conn;
    }
    if ($conn instanceof mysqli) {
        @$conn->close();
    }
    require dirname(__DIR__) . '/db.php';
    $conn->query("SET SESSION wait_timeout = 300, interactive_timeout = 300");
    return $conn;
}

$cleanups = [];

// Helper to invoke AJAX actions in a sub-process
function invokeAjax(array $postParams, array $sessionParams): array
{
    $postExport = var_export($postParams, true);
    $sessionExport = var_export($sessionParams, true);
    $ajaxPath = var_export(dirname(__DIR__) . '/ajax.php', true);
    $script = <<<PHP
<?php
define('CLI_AJAX_INVOCATION', true);
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}
\$_SESSION = {$sessionExport};
\$_SERVER['REQUEST_METHOD'] = 'POST';
\$_POST = {$postExport};
require {$ajaxPath};
PHP;
    $scratchDir = dirname(__DIR__, 2) . '/scratch';
    if (!is_dir($scratchDir)) {
        mkdir($scratchDir, 0777, true);
    }
    $tmpFile = tempnam($scratchDir, 'origin_test_');
    file_put_contents($tmpFile, $script);
    $cmd = 'php -d xdebug.mode=off ' . escapeshellarg($tmpFile);
    $output = shell_exec($cmd);
    @unlink($tmpFile);
    $json = json_decode((string) $output, true);
    if (!is_array($json)) {
        throw new RuntimeException("Sub-process did not return valid JSON. Output was: " . substr((string) $output, 0, 500));
    }
    return $json;
}

try {
    // 1. Setup a test standard unit
    $unitRes = $conn->query("SELECT id FROM standard_units WHERE status = 1 LIMIT 1");
    $unitRow = $unitRes ? $unitRes->fetch_assoc() : null;
    $testUnitId = $unitRow ? (int) $unitRow['id'] : 1;

    // 2. Setup a test product
    $prodCode = 'TEST-PROD-' . time() . '-' . mt_rand(100, 999);
    $prodName = 'Origin Split Test Product ' . time();
    $insertProd = $conn->query("INSERT INTO products (product_code, product_name, status, created_by, created_at)
                                VALUES ('{$prodCode}', '{$prodName}', 1, {$adminUserId}, NOW())");
    $testProductId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM products WHERE id = {$testProductId}";
    $cleanups[] = "DELETE FROM live_stock WHERE product_id = {$testProductId}";
    $cleanups[] = "DELETE FROM inventory_movements WHERE product_id = {$testProductId}";

    // Ensure zero baseline stock
    $liveStockId = inventoryEnsureBalance($conn, $testProductId, $adminUserId);
    $conn->query("UPDATE live_stock SET quantity_available = 0, reserved_qty = 0, unreserved_qty = 0 WHERE id = {$liveStockId}");

    // =========================================================================
    // ROUTE A: CUSTOMER ORDER ORIGIN (linked_order_id > 0)
    // =========================================================================
    echo "\n>>> [TEST ROUTE A: ORDER MANAGEMENT ORIGIN] <<<\n";

    // A1. Create customer order in order_received
    $orderNo = 'ORD-SPLIT-' . time();
    $resOrder = $conn->query("INSERT INTO order_received (order_number, client_name, customer_id, source_type, status, order_type, date_order_received, created_by, created_at)
                              VALUES ('{$orderNo}', 'Split Test Customer', 1, 1, 17, 1, CURDATE(), {$adminUserId}, NOW())");
    if (!$resOrder) {
        throw new RuntimeException("Insert order_received failed: " . $conn->error);
    }
    $orderAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM order_received WHERE id = {$orderAId}";

    // A2. Create order item
    $resItem = $conn->query("INSERT INTO order_received_items (order_id, product_id, product_name, quantity, unit, status, fulfillment_action, fulfillment_status, shortfall_quantity, shortfall_quantity_base, created_by, created_at)
                             VALUES ({$orderAId}, {$testProductId}, '{$prodName}', 100, {$testUnitId}, 0, 'production', 'sent_to_production', 100, 100, {$adminUserId}, NOW())");
    if (!$resItem) {
        throw new RuntimeException("Insert order_received_items failed: " . $conn->error);
    }
    $orderAItemId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM order_received_items WHERE id = {$orderAItemId}";
    $cleanups[] = "DELETE FROM order_stock_reservations WHERE order_id = {$orderAId}";

    // A3. Create Production Plan linked to order
    $batchNoA = 'B-ORD-' . time();
    $planNoA = 'PP-ORD-' . time();
    $conn->query("INSERT INTO production_plans (name, lo_batch_no, batch_size, batch_size_unit, order_id, product_id, production_plan_no, status, created_by, created_at)
                  VALUES ('Plan Order A', '{$batchNoA}', 100.0, {$testUnitId}, {$orderAId}, {$testProductId}, '{$planNoA}', 1, {$adminUserId}, NOW())");
    $planAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM production_plans WHERE id = {$planAId}";
    $cleanups[] = "DELETE FROM production_history WHERE production_id = {$planAId}";

    // A4. Create Material Requisition
    $mrBatchA = $batchNoA;
    $conn->query("INSERT INTO material_requisition (prod_plan_id, lot_batch_no, auto_generated_batch, status, created_by, created_at)
                  VALUES ({$planAId}, '{$mrBatchA}', '{$mrBatchA}', 1, {$adminUserId}, NOW())");
    $mrAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM material_requisition WHERE id = {$mrAId}";

    // A5. Create BMR/BPR Request (Approved)
    $conn->query("INSERT INTO bmr_bpr_requests (material_requisition_id, production_plan_id, product_id, bmr_form_count, bpr_form_count, status, created_by, created_at)
                  VALUES ({$mrAId}, {$planAId}, {$testProductId}, 1, 1, 'APPROVED', {$adminUserId}, NOW())");
    $reqAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM bmr_bpr_requests WHERE id = {$reqAId}";

    // A6. Create BMR and BPR work items (Complete)
    $conn->query("INSERT INTO bmr_bpr_work_items (request_id, form_type, form_sequence, status, created_by, created_at)
                  VALUES ({$reqAId}, 'BMR', 1, 'COMPLETE', {$adminUserId}, NOW())");
    $bmrAId = (int) $conn->insert_id;
    $conn->query("INSERT INTO bmr_bpr_work_items (request_id, form_type, form_sequence, status, created_by, created_at)
                  VALUES ({$reqAId}, 'BPR', 1, 'COMPLETE', {$adminUserId}, NOW())");
    $bprAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM bmr_bpr_work_items WHERE request_id = {$reqAId}";

    // A7. Create approved IP COA
    $ipCoaNoA = 'IP-COA-ORD-' . time();
    $coaPayload = json_encode(['fields' => ['approval.decision' => 'APPROVED']]);
    $conn->query("INSERT INTO ip_coa_generation (source_bmr_bpr_request_id, product_id, batch_number, batch_size, batch_size_unit, coa_template_id, form_payload_json, workflow_status, created_by, created_at)
                  VALUES ({$reqAId}, {$testProductId}, '{$batchNoA}', 100.0, {$testUnitId}, 1, '{$conn->real_escape_string($coaPayload)}', 'COMPLETED', {$adminUserId}, NOW())");
    $ipCoaAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM ip_coa_generation WHERE id = {$ipCoaAId}";

    // A8. Create approved FG COA
    $fgCoaNoA = 'FG-COA-ORD-' . time();
    $conn->query("INSERT INTO fg_coa_generation (source_ip_coa_id, production_plan_id, product_id, product_name, batch_number, batch_size, batch_size_unit, coa_template_id, form_payload_json, coa_fg, test_date, workflow_status, created_by, created_at)
                  VALUES ({$ipCoaAId}, {$planAId}, {$testProductId}, '{$prodName}', '{$batchNoA}', 100.0, {$testUnitId}, 2, '{$conn->real_escape_string($coaPayload)}', '{$fgCoaNoA}', CURDATE(), 'COMPLETED', {$adminUserId}, NOW())");
    $fgCoaAId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM fg_coa_generation WHERE id = {$fgCoaAId}";

    // Test A.1: Verify bmrBprLoadReleaseSource returns linked_order_id = $orderAId
    $sourceA = bmrBprLoadReleaseSource($conn, $fgCoaAId);
    $assert((int) ($sourceA['linked_order_id'] ?? 0) === $orderAId, 'bmrBprLoadReleaseSource returns linked_order_id matching customer order.');

    // Test A.2: Execute create_transfer_ticket (Step 11) for Order Origin
    $postA = [
        'createTransferTicketFromFg' => 'createTransferTicketFromFg',
        'csrf_token' => $_SESSION['csrf_token'],
        'source_fg_coa_id' => $fgCoaAId,
        'mfg_date' => date('Y-m-d'),
        'exp_date' => date('Y-m-d', strtotime('+2 years')),
        'sampled_by' => 'QC Tester',
        'quantity' => '100.00',
    ];
    $resA = invokeAjax($postA, $_SESSION);
    getActiveConnection($conn);
    $originA = (string) ($resA['data']['origin'] ?? $resA['origin'] ?? '');
    $ticketAId = (int) ($resA['data']['id'] ?? $resA['id'] ?? 0);
    $assert(($resA['status'] ?? '') === 'success', 'Step 11 create_transfer_ticket returned success.');
    $assert($originA === 'ORDER_MANAGEMENT', 'Step 11 identified origin as ORDER_MANAGEMENT.');

    $cleanups[] = "DELETE FROM transfer_ticket WHERE id = {$ticketAId}";
    $cleanups[] = "DELETE FROM bmr_bpr_workflow_history WHERE ref_table = 'TRANSFER_TICKET' AND ref_id = {$ticketAId}";

    // Test A.3: Verify transfer_ticket is TRANSFERRED, NOT RECEIVED
    $ttRowA = $conn->query("SELECT workflow_status FROM transfer_ticket WHERE id = {$ticketAId}")->fetch_assoc();
    $assert(($ttRowA['workflow_status'] ?? '') === 'TRANSFERRED', 'Transfer Ticket workflow_status is TRANSFERRED for Order Origin.');

    // Test A.4: Verify goods_received_from_production record was created with receipt_status = PENDING
    $grpResA = $conn->query("SELECT * FROM goods_received_from_production WHERE transfer_ticket_id = {$ticketAId}");
    $grpRowA = $grpResA ? $grpResA->fetch_assoc() : null;
    $assert($grpRowA !== null, 'goods_received_from_production record was created for Step 12 Store receipt.');
    $assert(($grpRowA['receipt_status'] ?? '') === 'PENDING', 'goods_received_from_production status is PENDING.');
    $assert((float) ($grpRowA['transferred_quantity'] ?? 0) === 100.0, 'goods_received_from_production transferred_quantity is 100.0.');

    $receiptAId = (int) ($grpRowA['id'] ?? 0);
    $cleanups[] = "DELETE FROM goods_received_from_production WHERE id = {$receiptAId}";
    $cleanups[] = "DELETE FROM bmr_bpr_workflow_history WHERE ref_table = 'PRODUCTION_RECEIPT' AND ref_id = {$receiptAId}";

    // Test A.5: Verify live_stock available stock is STILL 0 (has NOT been credited to free stock yet!)
    $lsA1 = $conn->query("SELECT quantity_available, reserved_qty FROM live_stock WHERE id = {$liveStockId}")->fetch_assoc();
    $assert((float) ($lsA1['quantity_available'] ?? 0) === 0.0, 'Stock is NOT added to free available inventory at Step 11 for Order Origin.');

    // Test A.6: Execute Step 12 Store Acknowledgement (acknowledgeGoodsReceivedProduction)
    $postA12 = [
        'acknowledgeGoodsReceivedProduction' => 'acknowledgeGoodsReceivedProduction',
        'csrf_token' => $_SESSION['csrf_token'],
        'receipt_id' => $receiptAId,
        'actual_received_quantity' => 100.0,
        'remarks' => 'Verified and received full batch into Store.',
    ];
    $resA12 = invokeAjax($postA12, $_SESSION);
    getActiveConnection($conn);
    $assert(($resA12['status'] ?? '') === 'success', 'Step 12 acknowledgeGoodsReceivedProduction returned success.');

    // Test A.7: Verify goods_received_from_production is now RECEIVED
    $grpQueryA2 = $conn->query("SELECT receipt_status, actual_received_quantity FROM goods_received_from_production WHERE id = {$receiptAId}");
    $grpRowA2 = $grpQueryA2 ? $grpQueryA2->fetch_assoc() : null;
    $assert(($grpRowA2['receipt_status'] ?? '') === 'RECEIVED', 'goods_received_from_production status is RECEIVED.');
    $assert((float) ($grpRowA2['actual_received_quantity'] ?? 0) === 100.0, 'actual_received_quantity is 100.0.');

    // Test A.8: Verify transfer_ticket is now RECEIVED
    $ttResA2 = $conn->query("SELECT workflow_status FROM transfer_ticket WHERE id = {$ticketAId}");
    $ttRowA2 = $ttResA2 ? $ttResA2->fetch_assoc() : null;
    $assert(($ttRowA2['workflow_status'] ?? '') === 'RECEIVED', 'Transfer Ticket workflow_status transitioned to RECEIVED.');

    // Test A.9: Verify production_plans is now Completed (status = 2)
    $planResA2 = $conn->query("SELECT status FROM production_plans WHERE id = {$planAId}");
    $planRowA2 = $planResA2 ? $planResA2->fetch_assoc() : null;
    $assert((int) ($planRowA2['status'] ?? 0) === 2, 'Linked production_plans status is 2 (ProductionCompleted).');

    // Test A.10: Verify production_history has ProductionCompleted entry
    $histResA = $conn->query("SELECT * FROM production_history WHERE production_id = {$planAId} AND action_type = 8 LIMIT 1");
    $histA = $histResA ? $histResA->fetch_assoc() : null;
    $assert($histA !== null, 'production_history recorded ProductionCompleted action.');

    // Test A.11: Verify stock reservation in order_stock_reservations and live_stock.reserved_qty
    $resCountA = (int) ($conn->query("SELECT COUNT(*) AS total FROM order_stock_reservations WHERE order_id = {$orderAId} AND status = 1")->fetch_assoc()['total'] ?? 0);
    $assert($resCountA >= 1, 'Active reservation created in order_stock_reservations for customer order.');

    $lsA2 = $conn->query("SELECT quantity_available, reserved_qty, unreserved_qty FROM live_stock WHERE id = {$liveStockId}")->fetch_assoc();
    $assert((float) ($lsA2['reserved_qty'] ?? 0) === 100.0, 'live_stock.reserved_qty reflects reserved 100.0.');
    $assert((float) ($lsA2['quantity_available'] ?? 0) === 100.0, 'live_stock.quantity_available reflects 100.0 total physical inventory received.');
    $assert((float) ($lsA2['unreserved_qty'] ?? 0) === 0.0, 'live_stock.unreserved_qty remains 0 because entire batch is reserved for order.');

    // Test A.12: Verify Step 13 Goods Received & Reserved list includes the order
    $grrList = mvGetGoodsReceivedReservedList($conn);
    $foundInGrr = false;
    foreach ($grrList['records'] as $rec) {
        if ((int) $rec['order_id'] === $orderAId) {
            $foundInGrr = true;
            break;
        }
    }
    $assert($foundInGrr, 'Step 13: Order appears in Goods Received & Reserved list.');

    // Test A.13: Test Step 13 Order Cancel releases reserved quantity back to available inventory
    mvReleaseOrderReservations($conn, $orderAId, $adminUserId);
    $lsA3 = $conn->query("SELECT quantity_available, reserved_qty FROM live_stock WHERE id = {$liveStockId}")->fetch_assoc();
    $assert((float) ($lsA3['reserved_qty'] ?? 0) === 0.0, 'Cancellation releases reserved_qty to 0.');
    $assert((float) ($lsA3['quantity_available'] ?? 0) === 100.0, 'Cancellation restores 100.0 to available inventory.');

    // Reset live_stock back to 0 before Route B test
    $conn->query("UPDATE live_stock SET quantity_available = 0, reserved_qty = 0, unreserved_qty = 0 WHERE id = {$liveStockId}");


    // =========================================================================
    // ROUTE B: LIVE INVENTORY REPLENISHMENT ORIGIN (linked_order_id = NULL / 0)
    // =========================================================================
    echo "\n>>> [TEST ROUTE B: LIVE INVENTORY ORIGIN] <<<\n";

    // B1. Create Production Plan with order_id = NULL
    $batchNoB = 'B-INV-' . time();
    $planNoB = 'PP-INV-' . time();
    $conn->query("INSERT INTO production_plans (name, lo_batch_no, batch_size, batch_size_unit, order_id, product_id, production_plan_no, status, created_by, created_at)
                  VALUES ('Plan Inventory B', '{$batchNoB}', 250.0, {$testUnitId}, NULL, {$testProductId}, '{$planNoB}', 1, {$adminUserId}, NOW())");
    $planBId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM production_plans WHERE id = {$planBId}";
    $cleanups[] = "DELETE FROM production_history WHERE production_id = {$planBId}";

    // B2. Create Material Requisition
    $mrBatchB = $batchNoB;
    $conn->query("INSERT INTO material_requisition (prod_plan_id, lot_batch_no, auto_generated_batch, status, created_by, created_at)
                  VALUES ({$planBId}, '{$mrBatchB}', '{$mrBatchB}', 1, {$adminUserId}, NOW())");
    $mrBId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM material_requisition WHERE id = {$mrBId}";

    // B3. Create BMR/BPR Request (Approved)
    $conn->query("INSERT INTO bmr_bpr_requests (material_requisition_id, production_plan_id, product_id, bmr_form_count, bpr_form_count, status, created_by, created_at)
                  VALUES ({$mrBId}, {$planBId}, {$testProductId}, 1, 1, 'APPROVED', {$adminUserId}, NOW())");
    $reqBId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM bmr_bpr_requests WHERE id = {$reqBId}";

    // B4. Create BMR and BPR work items (Complete)
    $conn->query("INSERT INTO bmr_bpr_work_items (request_id, form_type, form_sequence, status, created_by, created_at)
                  VALUES ({$reqBId}, 'BMR', 1, 'COMPLETE', {$adminUserId}, NOW())");
    $bmrBId = (int) $conn->insert_id;
    $conn->query("INSERT INTO bmr_bpr_work_items (request_id, form_type, form_sequence, status, created_by, created_at)
                  VALUES ({$reqBId}, 'BPR', 1, 'COMPLETE', {$adminUserId}, NOW())");
    $bprBId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM bmr_bpr_work_items WHERE request_id = {$reqBId}";

    // B5. Create approved IP COA
    $ipCoaNoB = 'IP-COA-INV-' . time();
    $conn->query("INSERT INTO ip_coa_generation (source_bmr_bpr_request_id, product_id, batch_number, batch_size, batch_size_unit, coa_template_id, form_payload_json, workflow_status, created_by, created_at)
                  VALUES ({$reqBId}, {$testProductId}, '{$batchNoB}', 250.0, {$testUnitId}, 1, '{$conn->real_escape_string($coaPayload)}', 'COMPLETED', {$adminUserId}, NOW())");
    $ipCoaBId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM ip_coa_generation WHERE id = {$ipCoaBId}";

    // B6. Create approved FG COA
    $fgCoaNoB = 'FG-COA-INV-' . time();
    $conn->query("INSERT INTO fg_coa_generation (source_ip_coa_id, production_plan_id, product_id, product_name, batch_number, batch_size, batch_size_unit, coa_template_id, form_payload_json, coa_fg, test_date, workflow_status, created_by, created_at)
                  VALUES ({$ipCoaBId}, {$planBId}, {$testProductId}, '{$prodName}', '{$batchNoB}', 250.0, {$testUnitId}, 2, '{$conn->real_escape_string($coaPayload)}', '{$fgCoaNoB}', CURDATE(), 'COMPLETED', {$adminUserId}, NOW())");
    $fgCoaBId = (int) $conn->insert_id;
    $cleanups[] = "DELETE FROM fg_coa_generation WHERE id = {$fgCoaBId}";

    // Test B.1: Verify bmrBprLoadReleaseSource returns linked_order_id = NULL / 0
    $sourceB = bmrBprLoadReleaseSource($conn, $fgCoaBId);
    $assert(empty($sourceB['linked_order_id']), 'bmrBprLoadReleaseSource returns empty linked_order_id for inventory origin.');

    // Test B.2: Execute create_transfer_ticket (Step 11) for Live Inventory Origin
    $postB = [
        'createTransferTicketFromFg' => 'createTransferTicketFromFg',
        'csrf_token' => $_SESSION['csrf_token'],
        'source_fg_coa_id' => $fgCoaBId,
        'mfg_date' => date('Y-m-d'),
        'exp_date' => date('Y-m-d', strtotime('+2 years')),
        'sampled_by' => 'QC Tester',
        'quantity' => '250.00',
    ];
    $resB = invokeAjax($postB, $_SESSION);
    getActiveConnection($conn);
    $originB = (string) ($resB['data']['origin'] ?? $resB['origin'] ?? '');
    $ticketBId = (int) ($resB['data']['id'] ?? $resB['id'] ?? 0);
    $assert(($resB['status'] ?? '') === 'success', 'Step 11 create_transfer_ticket returned success.');
    $assert($originB === 'LIVE_INVENTORY', 'Step 11 identified origin as LIVE_INVENTORY.');
    $assert(str_contains((string) ($resB['message'] ?? ''), 'credited directly to Live Stock'), 'Message confirms direct credit to Live Stock.');

    $cleanups[] = "DELETE FROM transfer_ticket WHERE id = {$ticketBId}";
    $cleanups[] = "DELETE FROM bmr_bpr_workflow_history WHERE ref_table = 'TRANSFER_TICKET' AND ref_id = {$ticketBId}";

    // Test B.3: Verify transfer_ticket is IMMEDIATELY RECEIVED
    $ttRowB = $conn->query("SELECT workflow_status, status FROM transfer_ticket WHERE id = {$ticketBId}")->fetch_assoc();
    $assert(($ttRowB['workflow_status'] ?? '') === 'RECEIVED', 'Transfer Ticket workflow_status is RECEIVED immediately.');
    $assert((int) ($ttRowB['status'] ?? 0) === 1, 'Transfer Ticket status is Active (1).');

    // Test B.4: Verify goods_received_from_production record was NOT created (closed at Step 11!)
    $grpCountB = (int) ($conn->query("SELECT COUNT(*) AS total FROM goods_received_from_production WHERE transfer_ticket_id = {$ticketBId}")->fetch_assoc()['total'] ?? 0);
    $assert($grpCountB === 0, 'No goods_received_from_production record was created for Live Inventory origin.');

    // Test B.5: Verify live_stock available inventory was DIRECTLY credited by 250.0
    $lsB = $conn->query("SELECT quantity_available, reserved_qty FROM live_stock WHERE id = {$liveStockId}")->fetch_assoc();
    $assert((float) ($lsB['quantity_available'] ?? 0) === 250.0, 'live_stock.quantity_available directly increased by 250.0.');
    $assert((float) ($lsB['reserved_qty'] ?? 0) === 0.0, 'live_stock.reserved_qty is 0 (no reservations).');

    // Test B.6: Verify production_plans is Completed (status = 2)
    $planResB = $conn->query("SELECT status FROM production_plans WHERE id = {$planBId}");
    if (!$planResB) {
        echo "  [DEBUG planResB query error]: " . $conn->error . "\n";
    }
    $planRowB = $planResB ? $planResB->fetch_assoc() : null;
    $assert((int) ($planRowB['status'] ?? 0) === 2, 'production_plans status is 2 (ProductionCompleted).');

    // Test B.7: Verify production_history recorded ProductionCompleted action
    $histResB = $conn->query("SELECT * FROM production_history WHERE production_id = {$planBId} AND action_type = 8 LIMIT 1");
    if (!$histResB) {
        echo "  [DEBUG histResB query error]: " . $conn->error . "\n";
    }
    $histB = $histResB ? $histResB->fetch_assoc() : null;
    $assert($histB !== null, 'production_history recorded ProductionCompleted action.');

    // Test B.8: Verify NO order reservations exist
    $resCountB = (int) ($conn->query("SELECT COUNT(*) AS total FROM order_stock_reservations WHERE product_id = {$testProductId} AND status = 1")->fetch_assoc()['total'] ?? 0);
    $assert($resCountB === 0, 'No order_stock_reservations created for inventory origin.');

} finally {
    echo "\nCleaning up test artifacts...\n";
    getActiveConnection($conn);
    foreach (array_reverse($cleanups) as $sql) {
        $conn->query($sql);
    }
}

echo "\n======================================================================\n";
if ($failures !== []) {
    echo "FAILED with " . count($failures) . " errors\n";
    foreach ($failures as $f) {
        echo "  - {$f}\n";
    }
    exit(1);
} else {
    echo "ALL PRODUCTION CYCLE ORIGIN-SPLIT TESTS PASSED! (0 failures)\n";
    echo "======================================================================\n";
    exit(0);
}
