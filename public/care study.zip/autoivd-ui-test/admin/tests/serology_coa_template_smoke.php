<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/serology/profiles.php';

function coaSerologyAssert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function coaSerologyCompletedPayload(array $profile): array
{
    $fields = [
        'metadata.manufacturing_date' => '01/07/2026',
        'metadata.expiry_date' => '30/06/2028',
        'approval.decision' => 'APPROVED',
        'approval.comments' => 'Meets controlled specification.',
        'approval.analysis_by' => 'QC Analyst',
        'approval.verified_by' => 'QC Head',
    ];
    foreach (($profile['editable_field_keys'] ?? []) as $fieldKey) {
        $key = (string) $fieldKey;
        $fields[$key] = match ($key) {
            'metadata.gr_number', 'metadata.sample_size' => 'NA',
            'metadata.packings_received' => '02',
            'metadata.packings_sampled' => '01',
            'results.physical_checks' => 'Complies',
            default => str_ends_with($key, '_status') ? 'Complies' : 'Positive',
        };
    }
    return coaTemplateSanitizePayload(
        $profile,
        ['schema_version' => 1, 'fields' => $fields]
    );
}

try {
    $profiles = coaSerologyProfiles();
    $productIds = coaSerologyMappedProductIds();
    coaSerologyAssert(count($profiles) === 4, 'Expected four Serology COA families.');
    coaSerologyAssert(count($productIds) === 12, 'Expected twelve Serology COA products.');
    coaSerologyAssert(coaSerologySourceDocumentCount() === 33, 'Expected 33 controlled source reports.');

    $sourceRoot = dirname(__DIR__, 2) . '/SEROLOGY COA 2026';
    foreach ($profiles as $familyKey => $profile) {
        foreach (['source_ip_documents', 'source_fg_documents'] as $documentKey) {
            foreach (($profile[$documentKey] ?? []) as $sourceDocument) {
                coaSerologyAssert(
                    is_file($sourceRoot . '/' . $profile['source_folder'] . '/' . $sourceDocument),
                    "Controlled source is missing for {$familyKey}: {$sourceDocument}"
                );
            }
        }
        coaSerologyAssert(
            count($profile['editable_field_keys'] ?? []) === 44,
            "The controlled editable-field schema is incomplete for {$familyKey}."
        );
    }

    $templateCodes = [
        'COMMON_SEROLOGY_IP_COA_V01',
        'COMMON_SEROLOGY_FG_COA_V01',
    ];
    $quotedCodes = implode(',', array_map(
        static fn(string $code): string => "'" . $conn->real_escape_string($code) . "'",
        $templateCodes
    ));
    $templateRows = $conn->query(
        "SELECT id, template_code, coa_type, layout_json
         FROM coa_document_templates
         WHERE template_code IN ({$quotedCodes}) AND status = 1 AND deleted_at IS NULL"
    );
    coaSerologyAssert($templateRows !== false, 'Unable to inspect installed Serology COA templates.');
    $installed = [];
    while ($row = $templateRows->fetch_assoc()) {
        $row['layout'] = coaTemplateDecodeLayout((string) $row['layout_json']);
        $installed[(string) $row['coa_type']] = $row;
    }
    coaSerologyAssert(count($installed) === 2, 'Expected two installed Serology COA templates.');

    $mappingRows = $conn->query(
        "SELECT mapping.coa_type, COUNT(*) AS total
         FROM coa_template_product_mappings mapping
         INNER JOIN coa_document_templates template ON template.id = mapping.template_id
         WHERE template.template_code IN ({$quotedCodes})
           AND mapping.status = 1 AND mapping.deleted_at IS NULL
           AND template.status = 1 AND template.deleted_at IS NULL
         GROUP BY mapping.coa_type"
    );
    $mappingCounts = [];
    while ($row = $mappingRows->fetch_assoc()) {
        $mappingCounts[(string) $row['coa_type']] = (int) $row['total'];
    }
    coaSerologyAssert(
        ($mappingCounts['IP'] ?? 0) === 12 && ($mappingCounts['FG'] ?? 0) === 12,
        'Expected twelve active Serology mappings for each COA type.'
    );

    $renderCases = [
        ['type' => 'IP', 'product_id' => 1043, 'stp' => 'BIPL-IPSTP-126', 'document' => 'BIPL-F-COA-01'],
        ['type' => 'FG', 'product_id' => 1039, 'stp' => 'BIPL-FPSTP-124', 'document' => 'BIPL-F-STS-14'],
        ['type' => 'IP', 'product_id' => 1034, 'stp' => 'BIPL-IPSTP-126', 'document' => 'BIPL-F-STS-14'],
        ['type' => 'FG', 'product_id' => 1028, 'stp' => 'BIPL-FPSTP-126', 'document' => 'BIPL-F-COA-01'],
    ];
    require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
    $pdfOptions = new Dompdf\Options();
    $pdfOptions->set('isRemoteEnabled', false);
    $pdfOptions->set('isHtml5ParserEnabled', true);
    $pdfOptions->set('defaultFont', 'Helvetica');
    $pdfOptions->set('defaultMediaType', 'print');
    foreach ($renderCases as $case) {
        $template = coaTemplateResolveMappedTemplate($conn, $case['product_id'], $case['type']);
        coaSerologyAssert(is_array($template), 'A representative Serology product did not resolve.');
        coaSerologyAssert(
            ($template['layout']['renderer_variant'] ?? '') === 'serology',
            'A representative Serology product resolved the wrong renderer.'
        );
        $payload = coaSerologyCompletedPayload($template['profile']);
        $form = coaTemplatePrepareForm(
            $template,
            $case['type'],
            [
                'coa_number' => 'BIPL-COA-' . $case['type'] . '-TEST',
                'batch_number' => 'SEROLOGY-TEST',
                'batch_size' => '100 Test',
                'testing_date' => '30/07/2026',
            ],
            $payload
        );
        $html = coaTemplateRender($form, true);
        coaSerologyAssert(
            str_contains($html, $case['stp'])
            && str_contains($html, $case['document'])
            && str_contains($html, 'Positive Control Titer')
            && str_contains($html, 'Clinical Samples (Abnormal)')
            && str_contains($html, 'No. of Packings received'),
            'A representative Serology renderer omitted controlled content.'
        );
        $pdf = new Dompdf\Dompdf($pdfOptions);
        $pdf->setPaper('A4', 'portrait');
        $pdf->loadHtml(
            '<!DOCTYPE html><html><head><meta charset="UTF-8">'
            . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
            . '</head><body>' . coaTemplateRender($form, false) . '</body></html>',
            'UTF-8'
        );
        $pdf->render();
        coaSerologyAssert(
            strlen($pdf->output()) > 5000 && $pdf->getCanvas()->get_page_count() >= 2,
            'A representative Serology structured PDF is unexpectedly empty.'
        );
    }

    $idSql = implode(',', $productIds);
    $ipQueue = $conn->query(
        "SELECT COUNT(DISTINCT r.product_id) AS products
         FROM bmr_bpr_requests r
         INNER JOIN bmr_bpr_work_items wi
            ON wi.request_id = r.id
           AND wi.form_type = 'BMR'
           AND wi.status IN ('IN_PROCESS', 'COMPLETE')
           AND wi.deleted_at IS NULL
         WHERE r.product_id IN ({$idSql})
           AND r.remarks = 'Common Serology template widget acceptance record.'
           AND r.deleted_at IS NULL
           AND NOT EXISTS (
               SELECT 1 FROM ip_coa_generation ip
               LEFT JOIN bmr_bpr_work_items source_item
                  ON source_item.id = ip.source_bmr_work_item_id
               WHERE (
                       ip.source_bmr_bpr_request_id = r.id
                       OR (
                           ip.source_bmr_bpr_request_id IS NULL
                           AND source_item.request_id = r.id
                       )
                   )
                 AND ip.deleted_at IS NULL
           )"
    )->fetch_assoc();
    coaSerologyAssert(
        (int) ($ipQueue['products'] ?? 0) === 12,
        'Expected twelve Serology products in the incoming IP COA banner.'
    );

    $fgQueue = $conn->query(
        "SELECT COUNT(*) AS records, COUNT(DISTINCT ip.product_id) AS products
         FROM ip_coa_generation ip
         INNER JOIN coa_document_templates template ON template.id = ip.coa_template_id
         LEFT JOIN fg_coa_generation fg
            ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
         WHERE ip.product_id IN ({$idSql})
           AND ip.remark = 'Common Serology FG COA template banner acceptance record.'
           AND ip.source_bmr_work_item_id IS NOT NULL
           AND ip.deleted_at IS NULL
           AND template.template_code = 'COMMON_SEROLOGY_IP_COA_V01'
           AND fg.id IS NULL"
    )->fetch_assoc();
    coaSerologyAssert(
        (int) ($fgQueue['records'] ?? 0) === 12
        && (int) ($fgQueue['products'] ?? 0) === 12,
        'Expected twelve Serology products in the incoming FG COA banner.'
    );

    echo "Serology COA smoke test passed: 4 families, 33 sources, 12 products, "
        . "24 mappings, 12 IP-banner and 12 FG-banner records.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
