<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/test_database.php';
require_once dirname(__DIR__) . '/constant.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';
require_once dirname(__DIR__) . '/document_pdf_helpers.php';

$credentialPath = $argv[1] ?? '';
$conn = testDatabaseFromCredentialFile($credentialPath);
$GLOBALS['conn'] = $conn;
$failures = [];
$skipped = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

// Item 13: inspect the live FG COA invariants and render an existing completed
// record without changing it.
$duplicateResult = $conn->query(
    "SELECT COUNT(*) AS total FROM (
        SELECT coa_fg
        FROM fg_coa_generation
        WHERE status != 3 AND deleted_at IS NULL
        GROUP BY coa_fg
        HAVING COUNT(*) > 1
    ) duplicates"
)->fetch_assoc();
$assert((int) ($duplicateResult['total'] ?? 0) === 0, 'Active FG COA numbers are not unique.');

$statusResult = $conn->query(
    "SELECT workflow_status, COUNT(*) AS total
     FROM fg_coa_generation
     WHERE status != 3 AND deleted_at IS NULL
     GROUP BY workflow_status"
);
$statusCounts = [];
while ($statusRow = $statusResult->fetch_assoc()) {
    $statusCounts[(string) $statusRow['workflow_status']] = (int) $statusRow['total'];
}
$completedResult = $conn->query(
    "SELECT id FROM fg_coa_generation
     WHERE workflow_status = 'COMPLETED'
       AND coa_template_id IS NOT NULL
       AND status != 3 AND deleted_at IS NULL
     ORDER BY id DESC LIMIT 1"
);
$completedId = (int) (($completedResult->fetch_assoc()['id'] ?? 0));
if ($completedId > 0) {
    try {
        $form = coaTemplateLoadSavedForm($conn, 'FG', $completedId);
        $rendered = coaTemplateRender($form, false);
        $pdf = documentPdfBuild('<!doctype html><html><body>' . $rendered . '</body></html>');
        $assert($rendered !== '', 'The completed FG COA rendered empty HTML.');
        $assert(str_starts_with($pdf, '%PDF-'), 'The completed FG COA did not render a valid PDF.');
    } catch (Throwable $error) {
        $failures[] = 'Completed FG COA rendering failed: ' . $error->getMessage();
    }

    $beforeStmt = $conn->prepare('SELECT remark FROM fg_coa_generation WHERE id = ?');
    $beforeStmt->bind_param('i', $completedId);
    $beforeStmt->execute();
    $originalRemark = $beforeStmt->get_result()->fetch_assoc()['remark'] ?? null;
    $beforeStmt->close();
    try {
        $conn->begin_transaction();
        $marker = 'ROLLBACK_ONLY_' . bin2hex(random_bytes(5));
        $updateStmt = $conn->prepare('UPDATE fg_coa_generation SET remark = ? WHERE id = ?');
        $updateStmt->bind_param('si', $marker, $completedId);
        $updateStmt->execute();
        $updateStmt->close();
        throw new RuntimeException('Forced rollback acceptance path.');
    } catch (Throwable) {
        $conn->rollback();
    }
    $afterStmt = $conn->prepare('SELECT remark FROM fg_coa_generation WHERE id = ?');
    $afterStmt->bind_param('i', $completedId);
    $afterStmt->execute();
    $afterRemark = $afterStmt->get_result()->fetch_assoc()['remark'] ?? null;
    $afterStmt->close();
    $assert($afterRemark === $originalRemark, 'The forced FG COA rollback retained a database change.');
} else {
    $skipped[] = 'FG COA completed-record PDF/rollback runtime check: target database has no templated COMPLETED record.';
}

$fgActionSource = (string) file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_actions.php');
$ajaxSource = (string) file_get_contents(dirname(__DIR__) . '/ajax.php');
$assert(
    str_contains($fgActionSource, "bmrBprRequirePermission(\$conn, 'fg_coa_generation_add')")
        && str_contains($fgActionSource, 'fg_coa_sequence_')
        && str_contains($fgActionSource, '$conn->rollback()')
        && str_contains($ajaxSource, "bmrBprRequirePermission(\$conn, 'fg_coa_generation_edit')")
        && str_contains($ajaxSource, 'bmrBprValidateCsrf();'),
    'FG COA permission, sequence lock, or rollback protection is missing.'
);

// Item 47: exercise due timed/all-day/missing-employee reminders inside a
// transaction and roll back every inserted event and notification.
$userResult = $conn->query(
    "SELECT id FROM users WHERE is_active = 1 AND deleted_at IS NULL ORDER BY id LIMIT 1"
);
$userId = (int) (($userResult->fetch_assoc()['id'] ?? 0));
$assert($userId > 0, 'No active user is available for reminder testing.');

if ($userId > 0) {
    $lockConn = testDatabaseFromCredentialFile($credentialPath);
    $lockConn->query("SELECT GET_LOCK('erp_calendar_reminders', 5)");
    $assert(cronCalendarReminders($conn) === 0, 'Reminder named-lock protection did not block a concurrent runner.');
    $lockConn->query("SELECT RELEASE_LOCK('erp_calendar_reminders')");
    $lockConn->close();

    $eventIds = [];
    try {
        $conn->begin_transaction();
        $databaseClock = $conn->query(
            "SELECT CURDATE() AS today, TIME(DATE_SUB(NOW(), INTERVAL 1 MINUTE)) AS due_time,
                    DATE_ADD(CURDATE(), INTERVAL 1 DAY) AS tomorrow"
        )->fetch_assoc();
        $today = (string) $databaseClock['today'];
        $now = (string) $databaseClock['due_time'];
        $eventType = 1;
        $status = 1;
        $createdAt = $today . ' ' . $now;
        $insert = $conn->prepare(
            "INSERT INTO employee_events
                (employee_id, event_title, event_type, event_date_start, event_date_end,
                 show_year, is_reminder_enabled, remarks, location, created_at, created_by,
                 status, all_day, start_time, end_time)
             VALUES (NULL, ?, ?, ?, ?, 0, 1, '', ?, ?, ?, ?, ?, ?, ?)"
        );
        $cases = [
            ['Scoped all-day reminder', 'Test location', 1, null, null],
            ['Scoped timed reminder', 'Test location', 0, $now, $now],
            ['Scoped missing-employee reminder', '', 1, null, null],
        ];
        foreach ($cases as [$title, $location, $allDay, $startTime, $endTime]) {
            $insert->bind_param(
                'sissssiiiss',
                $title,
                $eventType,
                $today,
                $today,
                $location,
                $createdAt,
                $userId,
                $status,
                $allDay,
                $startTime,
                $endTime
            );
            $insert->execute();
            $eventIds[] = (int) $conn->insert_id;
        }
        $insert->close();

        cronCalendarReminders($conn);
        $placeholders = implode(',', array_fill(0, count($eventIds), '?'));
        $types = str_repeat('i', count($eventIds));
        $notificationStmt = $conn->prepare(
            "SELECT ref_id, COUNT(*) AS total
             FROM notifications
             WHERE module = 'CALENDAR_REMINDER'
               AND ref_table = 'employee_events'
               AND ref_id IN ({$placeholders})
             GROUP BY ref_id"
        );
        $notificationStmt->bind_param($types, ...$eventIds);
        $notificationStmt->execute();
        $notificationRows = $notificationStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $notificationStmt->close();
        $assert(count($notificationRows) === count($eventIds), 'Not every due reminder produced a notification.');
        foreach ($notificationRows as $notificationRow) {
            $assert((int) $notificationRow['total'] === 1, 'A due reminder produced duplicate notifications.');
        }

        cronCalendarReminders($conn);
        $duplicateStmt = $conn->prepare(
            "SELECT COUNT(*) AS total FROM notifications
             WHERE module = 'CALENDAR_REMINDER'
               AND ref_table = 'employee_events'
               AND ref_id IN ({$placeholders})"
        );
        $duplicateStmt->bind_param($types, ...$eventIds);
        $duplicateStmt->execute();
        $notificationCount = (int) ($duplicateStmt->get_result()->fetch_assoc()['total'] ?? 0);
        $duplicateStmt->close();
        $assert($notificationCount === count($eventIds), 'A repeated reminder run created duplicates.');

        $tomorrow = (string) $databaseClock['tomorrow'];
        $editedTitle = 'Scoped rescheduled reminder';
        $editStmt = $conn->prepare(
            'UPDATE employee_events SET event_title = ?, event_date_start = ?, event_date_end = ? WHERE id = ?'
        );
        $editStmt->bind_param('sssi', $editedTitle, $tomorrow, $tomorrow, $eventIds[1]);
        $editStmt->execute();
        $editStmt->close();
        $deleteStmt = $conn->prepare('UPDATE employee_events SET status = 3, deleted_at = NOW() WHERE id = ?');
        $deleteStmt->bind_param('i', $eventIds[0]);
        $deleteStmt->execute();
        $deleteStmt->close();
        cronCalendarReminders($conn);
        $postEditStmt = $conn->prepare(
            "SELECT COUNT(*) AS total FROM notifications
             WHERE module = 'CALENDAR_REMINDER'
               AND ref_table = 'employee_events'
               AND ref_id IN ({$placeholders})"
        );
        $postEditStmt->bind_param($types, ...$eventIds);
        $postEditStmt->execute();
        $postEditCount = (int) ($postEditStmt->get_result()->fetch_assoc()['total'] ?? 0);
        $postEditStmt->close();
        $assert($postEditCount === count($eventIds), 'Edited or deleted reminders were delivered again.');
        $conn->rollback();
    } catch (Throwable $error) {
        $conn->rollback();
        $failures[] = 'Reminder transaction test failed: ' . $error->getMessage();
    }

    if ($eventIds) {
        $placeholders = implode(',', array_fill(0, count($eventIds), '?'));
        $types = str_repeat('i', count($eventIds));
        $residualStmt = $conn->prepare("SELECT COUNT(*) AS total FROM employee_events WHERE id IN ({$placeholders})");
        $residualStmt->bind_param($types, ...$eventIds);
        $residualStmt->execute();
        $residual = (int) ($residualStmt->get_result()->fetch_assoc()['total'] ?? 0);
        $residualStmt->close();
        $assert($residual === 0, 'Reminder test data remained after rollback.');
    }
}

$assert(
    str_contains($ajaxSource, "canDoThis('calendar_add_event')")
        && str_contains($ajaxSource, "canDoThis('calendar_edit_event')")
        && str_contains($ajaxSource, "canDoThis('calendar_delete_event')"),
    'Calendar add/edit/delete permission checks are incomplete.'
);

// Item 44: confirm the target database still treats every active Delivery
// Challan as non-accounting and has no payment allocation against a challan.
$challanAccounting = $conn->query(
    "SELECT COUNT(*) AS total,
            SUM(CASE WHEN grand_total <> 0 OR taxable_total <> 0
                          OR cgst_total <> 0 OR sgst_total <> 0 OR igst_total <> 0
                     THEN 1 ELSE 0 END) AS valued
     FROM finance_documents
     WHERE document_type = 'DELIVERY_CHALLAN' AND deleted_at IS NULL"
)->fetch_assoc();
$assert(
    (int) ($challanAccounting['valued'] ?? 0) === 0,
    'An active Delivery Challan has a non-zero accounting or tax value.'
);
$challanAllocations = $conn->query(
    "SELECT COUNT(*) AS total
     FROM finance_payment_allocations allocation
     INNER JOIN finance_documents document ON document.id = allocation.document_id
     WHERE document.document_type = 'DELIVERY_CHALLAN'"
)->fetch_assoc();
$assert(
    (int) ($challanAllocations['total'] ?? 0) === 0,
    'A payment allocation exists against a Delivery Challan.'
);

if ($failures) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

foreach ($skipped as $message) {
    echo 'SKIP: ' . $message . "\n";
}
echo "PASS: FG COA controls, Employee Reminder lifecycle, and Delivery Challan accounting-isolation checks.\n";
