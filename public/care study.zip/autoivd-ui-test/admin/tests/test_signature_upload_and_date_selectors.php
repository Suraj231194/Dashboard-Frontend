<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_structured_renderer.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/renderer.php';
require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

$failures = [];

echo "Running Signature Upload and Date Selector tests...\n";

// 1. Test BMR/BPR helpers
if (!bmrBprIsSignatureKey('cover.prepared_signature') || !bmrBprIsSignatureKey('qa.incharge_signature_date')) {
    $failures[] = "bmrBprIsSignatureKey failed for known signature keys.";
}

if (!bmrBprIsDateKey('cover.prepared_date') || !bmrBprIsDateKey('cover.mfg_date') || bmrBprIsDateKey('cover.prepared_signature')) {
    $failures[] = "bmrBprIsDateKey failed for date vs signature keys.";
}

$logoPath = dirname(__DIR__, 2) . '/assets/img/logo3.jpeg';
$sampleBase64Img = is_file($logoPath)
    ? 'data:image/jpeg;base64,' . base64_encode((string) file_get_contents($logoPath))
    : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
if (!bmrBprIsImageValue($sampleBase64Img) || bmrBprIsImageValue('John Doe')) {
    $failures[] = "bmrBprIsImageValue failed.";
}

// 2. Test BMR/BPR structured field rendering in editable mode
$fields = [
    'cover.prepared_signature' => $sampleBase64Img,
    'cover.checked_signature' => 'Dr. Jane Smith',
    'cover.prepared_date' => '2026-07-29',
    'cover.mfg_date' => '29/07/2026',
];

$sigFieldWithImg = bmrBprStructuredField('cover.prepared_signature', $fields, true);
if (stripos($sigFieldWithImg, 'bmr-v2-sig-widget') === false
    || stripos($sigFieldWithImg, 'bmr-v2-sig-preview-img') === false
    || stripos($sigFieldWithImg, 'bmr-v2-sig-file-input') === false
    || stripos($sigFieldWithImg, 'data:image/') === false) {
    $failures[] = "bmrBprStructuredField editable signature with image failed.";
}

$sigFieldWithText = bmrBprStructuredField('cover.checked_signature', $fields, true);
if (stripos($sigFieldWithText, 'bmr-v2-sig-widget') === false
    || stripos($sigFieldWithText, 'Dr. Jane Smith') === false
    || stripos($sigFieldWithText, 'bmr-v2-sig-file-input') === false) {
    $failures[] = "bmrBprStructuredField editable signature with text failed.";
}

$dateField = bmrBprStructuredField('cover.prepared_date', $fields, true);
if (stripos($dateField, 'type="date"') === false
    || stripos($dateField, 'value="2026-07-29"') === false) {
    $failures[] = "bmrBprStructuredField editable date field failed.";
}

$mfgDateField = bmrBprStructuredField('cover.mfg_date', $fields, true);
if (stripos($mfgDateField, 'type="date"') === false
    || stripos($mfgDateField, 'value="2026-07-29"') === false) {
    $failures[] = "bmrBprStructuredField editable mfg_date normalization failed.";
}

// 3. Test BMR/BPR structured field rendering in print/view mode
$printSigWithImg = bmrBprStructuredField('cover.prepared_signature', $fields, false);
if (stripos($printSigWithImg, 'bmr-v2-sig-print-img') === false
    || stripos($printSigWithImg, 'data:image/') === false) {
    $failures[] = "bmrBprStructuredField print signature with image failed.";
}

$printSigWithText = bmrBprStructuredField('cover.checked_signature', $fields, false);
if (stripos($printSigWithText, 'Dr. Jane Smith') === false) {
    $failures[] = "bmrBprStructuredField print signature with text failed.";
}

// 4. Test COA Template helpers and rendering
if (!coaTemplateIsSignatureKey('approval.analysis_by') || !coaTemplateIsSignatureKey('approval.verified_by')) {
    $failures[] = "coaTemplateIsSignatureKey failed.";
}

if (!coaTemplateIsDateKey('metadata.manufacturing_date') || !coaTemplateIsDateKey('testing_date')) {
    $failures[] = "coaTemplateIsDateKey failed.";
}

$coaFields = [
    'approval.analysis_by' => $sampleBase64Img,
    'approval.verified_by' => 'Approver QA',
    'metadata.manufacturing_date' => '2026-06-15',
];

$coaSigWithImg = coaTemplateInput('approval.analysis_by', $coaFields, true);
if (stripos($coaSigWithImg, 'coa-v1-sig-widget') === false
    || stripos($coaSigWithImg, 'coa-v1-sig-preview-img') === false
    || stripos($coaSigWithImg, 'coa-v1-sig-file-input') === false) {
    $failures[] = "coaTemplateInput editable signature with image failed.";
}

$coaDateInput = coaTemplateInput('metadata.manufacturing_date', $coaFields, true);
if (stripos($coaDateInput, 'type="date"') === false
    || stripos($coaDateInput, 'value="2026-06-15"') === false) {
    $failures[] = "coaTemplateInput date field failed.";
}

$coaPrintSigWithImg = coaTemplateInput('approval.analysis_by', $coaFields, false);
if (stripos($coaPrintSigWithImg, 'coa-v1-sig-print-img') === false
    || stripos($coaPrintSigWithImg, 'data:image/') === false) {
    $failures[] = "coaTemplateInput print signature with image failed.";
}

// 5. Dompdf rendering test for BMR and COA with signature images
$dompdfOptions = new Dompdf\Options();
$dompdfOptions->set('isRemoteEnabled', false);
$dompdfOptions->set('defaultFont', 'Helvetica');
$dompdf = new Dompdf\Dompdf($dompdfOptions);

$testHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
    . bmrBprStructuredStyles()
    . coaTemplateStyles()
    . '</head><body>'
    . '<div class="bmr-v2-page">'
    . '<h2>BMR Signature Test</h2>'
    . $printSigWithImg
    . '<div>' . $printSigWithText . '</div>'
    . '<h2>COA Signature Test</h2>'
    . $coaPrintSigWithImg
    . '</div>'
    . '</body></html>';

$dompdf->loadHtml($testHtml, 'UTF-8');
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$pdfOutput = $dompdf->output();

if (!str_starts_with($pdfOutput, '%PDF-')) {
    $failures[] = "Dompdf failed to render PDF with signature image.";
}

if ($failures !== []) {
    echo "FAILED:\n" . implode("\n", $failures) . "\n";
    exit(1);
}

echo "SUCCESS: All signature upload and date selector unit & integration tests passed cleanly!\n";
