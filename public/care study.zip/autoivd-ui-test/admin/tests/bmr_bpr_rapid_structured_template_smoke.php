<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_structured_renderer.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_rapid_profiles.php';

$failures = [];
$families = bmrBprRapidCatalog();
$productIds = bmrBprRapidApprovedProductIds();
$documentCounts = bmrBprRapidDocumentCounts();

if (count($families) !== 50) {
    $failures[] = 'Expected 50 separately catalogued Rapid source families.';
}
if (count($productIds) !== 81) {
    $failures[] = 'Expected exactly 81 separately mapped Rapid catalog products.';
}
if ($documentCounts !== ['BMR' => 82, 'BPR' => 80]) {
    $failures[] = 'Unexpected Rapid product-document totals.';
}
if (
    count($families['finished_dengue_combo']['bmr_documents'] ?? []) !== 2
    || count($families['finished_dengue_combo']['bpr_documents'] ?? []) !== 1
) {
    $failures[] = 'Dengue Combo must be split into two BMR components and one BPR.';
}
if (
    count($families['finished_hiv_4th_gen']['bpr_documents'] ?? []) !== 0
    || count($families['finished_lh']['bmr_documents'] ?? []) !== 0
    || count($families['uncut_leptospira']['bpr_documents'] ?? []) !== 1
) {
    $failures[] = 'Rapid single-document exceptions or the supplied Leptospira pair are inaccurate.';
}

$document = [
    'document_no' => 'BIPL-BMR-01',
    'issue_no' => '01',
    'revision_no' => '02',
    'effective_date' => '03/04/2025',
    'license_no' => 'MFG/IVD/2020/000082',
    'department' => 'Production',
    'company_name' => 'BIOGENIX INC. PVT. LTD.',
    'company_address' => "B19/A S.I.L. Ancillary Estate,\nAmausi Industrial Area, Nadarganj-\n226008 (Lucknow)",
    'title' => 'BATCH MANUFACTURING RECORD',
];
$rendered = 0;
foreach ($families as $familyKey => $family) {
    foreach (['BMR' => 'bmr_documents', 'BPR' => 'bpr_documents'] as $formType => $key) {
        foreach ($family[$key] as $sequenceIndex => $profile) {
            $layoutDocument = $document;
            if ($formType === 'BPR') {
                $layoutDocument['document_no'] = 'BIPL-BPR-01';
                $layoutDocument['title'] = 'BATCH PACKING RECORD';
            }
            $form = [
                'form_type' => $formType,
                'layout' => [
                    'schema_version' => 2,
                    'renderer' => 'structured_html',
                    'renderer_variant' => 'rapid',
                    'form_type' => $formType,
                    'document' => $layoutDocument,
                ],
                'profile' => $profile,
                'source_values' => [
                    'batch_number' => 'RAPID-SMOKE-001',
                    'batch_size' => '1000 Tests',
                    'pack_size' => 'Smoke Pack',
                    'record_number' => $formType . '/RAPID/' . ($sequenceIndex + 1),
                ],
                'form_payload' => [
                    'fields' => ['qa.decision_remarks' => 'Rapid structured smoke sentinel'],
                ],
            ];
            $html = bmrBprRenderStructuredTemplate($form, true);
            $pageCount = substr_count($html, 'class="bmr-v2-page ');
            if ($pageCount === 0) {
                $pageCount = substr_count($html, 'class="bmr-v2-page"');
            }
            if ($pageCount !== (int) $profile['page_count']) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ": expected {$profile['page_count']} pages, rendered {$pageCount}.";
            }
            if (
                stripos($html, 'Rapid structured smoke sentinel') === false
                || stripos($html, (string) $profile['product_name']) === false
                || trim((string) ($profile['source_document'] ?? '')) === ''
            ) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ': profile data, source audit name or editable fields are missing.';
            }
            if (
                substr_count($html, 'class="bmr-v2-sig-file-input"') === 0
                || stripos($html, 'data-bmr-field="qa.incharge.signature"') === false
                || stripos($html, 'data-bmr-field="qa.incharge.date"') === false
            ) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ': signature upload and separate date controls are missing.';
            }
            if (
                stripos($html, 'source_pdf_path') !== false
                || stripos($html, 'page_asset_path') !== false
            ) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ': runtime source-artwork dependency detected.';
            }
            $sourceItems = $formType === 'BMR'
                ? ($profile['ingredients'] ?? [])
                : array_merge(
                    $profile['reagents'] ?? [],
                    $profile['packing_materials'] ?? []
            );
            foreach ($sourceItems as $item) {
                $escapedItemName = htmlspecialchars(
                    (string) ($item['name'] ?? ''),
                    ENT_QUOTES | ENT_SUBSTITUTE,
                    'UTF-8'
                );
                if (stripos($html, $escapedItemName) === false) {
                    $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                        . ': missing controlled item ' . ($item['name'] ?? '');
                    break;
                }
            }
            $rendered++;
        }
    }
}
if ($rendered !== 99) {
    $failures[] = "Expected 99 logical source documents, rendered {$rendered}.";
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Rapid structured template smoke test passed for {$rendered} source documents, "
    . '81 separate products, the supplied Uncut Sheet pairs and the split Dengue Combo BMR.' . PHP_EOL;
