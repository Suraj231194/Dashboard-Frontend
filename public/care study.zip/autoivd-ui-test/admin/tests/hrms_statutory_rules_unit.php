<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('HRMS_CONTEXT', true);
require_once dirname(__DIR__) . '/hrms/hrms_common.php';

$admin = dirname(__DIR__);
$pageSource = (string) file_get_contents($admin . '/pages/employee-master.php');
$apiSource = (string) file_get_contents($admin . '/hrms-api.php');
$payrollSource = (string) file_get_contents($admin . '/payroll/payroll_common.php');
$migrationSource = (string) file_get_contents($admin . '/migrations/2026_09_01_002_salary_statutory_rules_pending.sql');
$calculatorSource = (string) file_get_contents(dirname($admin) . '/assets/js/hrms-salary-calculator.js');

$assertions = [
    'employee PF uses 15000 base' => abs(hrmsPfCategoryBase('e') - 15000) < 0.001,
    'worker PF uses 7500 base' => abs(hrmsPfCategoryBase('w') - 7500) < 0.001,
    'employee worker PF uses 7500 base' => abs(hrmsPfCategoryBase('ew') - 7500) < 0.001,
    'employee PF is 1800' => abs(hrmsCalculatePfAmount('e') - 1800) < 0.001,
    'worker PF is 900' => abs(hrmsCalculatePfAmount('w') - 900) < 0.001,
    'employee worker PF is 900' => abs(hrmsCalculatePfAmount('ew') - 900) < 0.001,
    'ESIC applies below threshold' => abs(hrmsCalculateEsicAmount(20999) - 209.99) < 0.001,
    'ESIC does not apply at threshold' => hrmsCalculateEsicAmount(21000) === 0.0,
    'ESIC does not apply above threshold' => hrmsCalculateEsicAmount(21001) === 0.0,
    'onboarding loads balancing engine' => str_contains($pageSource, 'hrms-salary-calculator.js')
        && str_contains($pageSource, 'HrmsSalaryCalculator.rebalance'),
    'onboarding requires PF category' => str_contains($pageSource, 'id="onboardingPfCategory"')
        && str_contains($pageSource, 'Employee / Worker (EW)'),
    'edit payroll supports PF category' => str_contains($pageSource, 'editPfEstimate')
        && str_contains($pageSource, 'rebalanceCompensation'),
    'API enforces onboarding annual CTC' => str_contains($apiSource, 'Earning salary heads must equal the Annual CTC.'),
    'API enforces edit monthly CTC' => str_contains($apiSource, 'Monthly earning heads must equal the Annual CTC divided by 12.'),
    'API requires category when schema is ready' => substr_count($apiSource, '$statutorySchemaReady && !in_array($pfCategory') === 2,
    'API stores effective category' => substr_count($apiSource, "UPDATE employee_salaries SET pf_category = ?") >= 2,
    'payroll uses fixed category PF' => str_contains($payrollSource, "in_array(\$pfCategory, ['e', 'w', 'ew'], true)")
        && str_contains($payrollSource, 'hrmsCalculatePfAmount($pfCategory)'),
    'payroll applies ESIC to earned gross' => str_contains($payrollSource, 'hrmsCalculateEsicAmount($grossEarned)'),
    'payroll reads category only from effective salary' => str_contains($payrollSource, "? 'salary.pf_category'")
        && !str_contains($payrollSource, 'COALESCE(salary.pf_category, profile.pf_category)'),
    'payroll preserves effective salary history' => str_contains($payrollSource, 'salary_match.status IN (0, 1)')
        && str_contains($payrollSource, 'salary_match.effective_to IS NULL OR salary_match.effective_to >= ?'),
    'legacy PF fallback remains' => str_contains($payrollSource, "elseif ((int) \$employee['is_pf_allowed'] === 1"),
    'migration is effective dated' => str_contains($migrationSource, "ALTER TABLE `hr_employee_profiles`")
        && str_contains($migrationSource, "ALTER TABLE `employee_salaries`")
        && str_contains($migrationSource, "ADD COLUMN IF NOT EXISTS `pf_category`")
        && str_contains($migrationSource, "ADD COLUMN IF NOT EXISTS `pf`")
        && str_contains($migrationSource, "ADD COLUMN IF NOT EXISTS `esi`"),
    'calculator chooses HRA residual' => str_contains($calculatorSource, "component.code === 'HRA'"),
];

$failures = array_keys(array_filter($assertions, static fn(bool $passed): bool => !$passed));
if ($failures !== []) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo 'PASS: ' . count($assertions) . " salary and statutory rule assertions.\n";
