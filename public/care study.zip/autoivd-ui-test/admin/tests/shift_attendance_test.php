<?php

declare(strict_types=1);

define('HRMS_CONTEXT', true);
require_once __DIR__ . '/../hrms/hrms_common.php';

$failures = 0;
$assertSame = static function (mixed $expected, mixed $actual, string $message) use (&$failures): void {
    if ($expected !== $actual) {
        $failures++;
        fwrite(STDERR, "FAIL: {$message}. Expected " . var_export($expected, true) . ', received ' . var_export($actual, true) . PHP_EOL);
    }
};

$dayShift = [
    'start_time' => '09:00:00',
    'end_time' => '18:00:00',
    'lunch_start_time' => '13:00:00',
    'lunch_end_time' => '14:00:00',
    'late_grace_minutes' => 10,
    'early_leave_minutes' => 10,
    'full_day_minutes' => 480,
    'half_day_minutes' => 240,
];

// ---- Lunch deduction -----------------------------------------------------------------
$full = hrmsShiftWorkedMinutes('2026-09-02', '2026-09-02 09:00:00', '2026-09-02 18:00:00', $dayShift);
$assertSame(60, $full['break'], 'the full lunch window is deducted from a full-day span');
$assertSame(480, $full['worked'], 'a nine-hour span with a one-hour lunch pays eight hours');

$partial = hrmsShiftWorkedMinutes('2026-09-02', '2026-09-02 13:30:00', '2026-09-02 18:00:00', $dayShift);
$assertSame(30, $partial['break'], 'only the overlapping part of the lunch window is deducted');
$assertSame(240, $partial['worked'], 'a late start still nets the worked minutes correctly');

$beforeLunch = hrmsShiftWorkedMinutes('2026-09-02', '2026-09-02 09:00:00', '2026-09-02 12:00:00', $dayShift);
$assertSame(0, $beforeLunch['break'], 'a span that ends before lunch loses nothing');
$assertSame(180, $beforeLunch['worked'], 'a pre-lunch span is paid in full');

$noLunch = hrmsShiftWorkedMinutes('2026-09-02', '2026-09-02 09:00:00', '2026-09-02 18:00:00', [
    'start_time' => '09:00:00', 'end_time' => '18:00:00',
    'lunch_start_time' => null, 'lunch_end_time' => null,
]);
$assertSame(0, $noLunch['break'], 'a shift without a lunch window deducts nothing');
$assertSame(540, $noLunch['worked'], 'a shift without a lunch window pays the whole span');

$assertSame(
    ['worked' => 0, 'break' => 0],
    hrmsShiftWorkedMinutes('2026-09-02', null, null, $dayShift),
    'a day without punches yields no minutes'
);

// An overnight lunch window must not produce a negative break.
$overnight = hrmsShiftWorkedMinutes('2026-09-02', '2026-09-02 22:00:00', '2026-09-03 06:00:00', [
    'start_time' => '22:00:00', 'end_time' => '06:00:00',
    'lunch_start_time' => '23:30:00', 'lunch_end_time' => '00:00:00',
]);
$assertSame(30, $overnight['break'], 'an overnight lunch window is deducted once');
$assertSame(450, $overnight['worked'], 'an overnight shift nets its worked minutes');

// ---- Threshold floors ----------------------------------------------------------------
$assertSame(['half' => 240, 'full' => 480], hrmsShiftThresholds($dayShift), 'configured thresholds are respected');
$assertSame(
    ['half' => 270, 'full' => 540],
    hrmsShiftThresholds(['full_day_minutes' => 540, 'half_day_minutes' => 0]),
    'a zero half-day threshold falls back to half the full day'
);
$assertSame(
    ['half' => 240, 'full' => 480],
    hrmsShiftThresholds([]),
    'a missing shift falls back to an eight-hour day'
);
$assertSame(
    ['half' => 300, 'full' => 300],
    hrmsShiftThresholds(['full_day_minutes' => 300, 'half_day_minutes' => 600]),
    'a half-day threshold above the full day is clamped'
);

// The historic bug: half_day_hours = 0 must never make one minute a half day.
$brokenShift = hrmsShiftThresholds(['full_day_minutes' => 540, 'half_day_minutes' => null]);
if ($brokenShift['half'] <= 1) {
    $failures++;
    fwrite(STDERR, 'FAIL: a one-minute punch must not satisfy the half-day threshold.' . PHP_EOL);
}

if ($failures > 0) {
    fwrite(STDERR, "\n{$failures} shift attendance assertion(s) failed." . PHP_EOL);
    exit(1);
}

echo 'Shift attendance tests passed.' . PHP_EOL;
