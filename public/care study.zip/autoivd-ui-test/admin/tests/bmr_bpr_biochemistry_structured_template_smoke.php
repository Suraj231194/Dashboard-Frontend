<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_structured_renderer.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_biochemistry_profiles.php';

$failures = [];
$families = bmrBprBiochemistryCatalog();
$productIds = bmrBprBiochemistryApprovedProductIds();
$documentCounts = bmrBprBiochemistryDocumentCounts();

if (count($families) !== 40) {
    $failures[] = 'Expected 39 source families plus one combined Bilirubin split.';
}
if (count($productIds) !== 83) {
    $failures[] = 'Expected exactly 83 approved finished-product catalog records.';
}
if ($documentCounts !== ['BMR' => 183, 'BPR' => 84]) {
    $failures[] = 'Unexpected Biochemistry product-document totals.';
}
if (
    count($families['bilirubin_combined']['bmr_documents'] ?? []) !== 4
    || count($families['bilirubin_combined']['bpr_documents'] ?? []) !== 2
) {
    $failures[] = 'The combined Total & Direct Bilirubin split is invalid.';
}

$document = [
    'document_no' => 'BIPL-BMR-01',
    'issue_no' => '01',
    'revision_no' => '02',
    'effective_date' => '03/04/2025',
    'license_no' => 'MFG/IVD/2020/000082',
    'department' => 'Production',
    'company_name' => 'BIOGENIX INC. PVT. LTD.',
    'company_address' => "B19/A S.I.L. Ancillary Estate,\nAmausi Industrial Area, Nadarganj-\n226008 (Lucknow)",
    'title' => 'BATCH MANUFACTURING RECORD',
];
$rendered = 0;
foreach ($families as $familyKey => $family) {
    foreach (['BMR' => 'bmr_documents', 'BPR' => 'bpr_documents'] as $formType => $key) {
        foreach ($family[$key] as $sequenceIndex => $profile) {
            $layoutDocument = $document;
            if ($formType === 'BPR') {
                $layoutDocument['document_no'] = 'BIPL-BPR-01';
                $layoutDocument['title'] = 'BATCH PACKING RECORD';
            }
            $layout = [
                'schema_version' => 2,
                'renderer' => 'structured_html',
                'renderer_variant' => 'biochemistry',
                'form_type' => $formType,
                'document' => $layoutDocument,
            ];
            $form = [
                'form_type' => $formType,
                'layout' => $layout,
                'profile' => $profile,
                'source_values' => [
                    'batch_number' => 'BIOCHEM-SMOKE-001',
                    'batch_size' => '10 Kit',
                    'pack_size' => 'Smoke Pack',
                    'record_number' => $formType . '/SMOKE/' . ($sequenceIndex + 1),
                ],
                'form_payload' => [
                    'fields' => [
                        'qa.decision_remarks' => 'Biochemistry structured smoke sentinel',
                    ],
                ],
            ];
            $html = bmrBprRenderStructuredTemplate($form, true);
            $pageCount = substr_count($html, 'class="bmr-v2-page ');
            if ($pageCount === 0) {
                $pageCount = substr_count($html, 'class="bmr-v2-page"');
            }
            if ($pageCount !== (int) $profile['page_count']) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ": expected {$profile['page_count']} pages, rendered {$pageCount}.";
            }
            if (
                stripos($html, 'Biochemistry structured smoke sentinel') === false
                || stripos($html, (string) $profile['product_name']) === false
                || stripos($html, (string) $profile['mfr_reference']) === false
            ) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ': profile data or editable fields did not render.';
            }
            if (
                stripos($html, '.pdf') !== false
                || stripos($html, 'page_asset_path') !== false
                || stripos($html, 'source_pdf_path') !== false
            ) {
                $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                    . ': source artwork dependency detected.';
            }
            $sourceItems = $formType === 'BMR'
                ? ($profile['ingredients'] ?? [])
                : array_merge(
                    $profile['reagents'] ?? [],
                    $profile['packing_materials'] ?? []
                );
            foreach ($sourceItems as $item) {
                if (stripos($html, (string) ($item['name'] ?? '')) === false) {
                    $failures[] = "{$familyKey} {$formType} #" . ($sequenceIndex + 1)
                        . ': missing source item ' . ($item['name'] ?? '');
                    break;
                }
            }
            $rendered++;
        }
    }
}

if ($rendered !== 129) {
    $failures[] = "Expected 129 registry documents including the six combined Bilirubin splits, rendered {$rendered}.";
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Biochemistry structured template smoke test passed for {$rendered} source-family documents."
    . PHP_EOL;
