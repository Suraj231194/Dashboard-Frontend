<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

if (!function_exists('payrollMoney')) {
    function payrollMoney(float|string|null $value): string
    {
        return number_format((float) $value, 2, '.', ',');
    }
}

define('PAYROLL_CONTEXT', true);
require_once dirname(__DIR__) . '/payroll/payroll_pdf.php';

$admin = dirname(__DIR__);
$sources = [];
foreach ([
    'navbar' => 'layout/navbar.php',
    'employee_profile' => 'pages/employee-profile.php',
    'leave_page' => 'pages/leave-management.php',
    'employee_master' => 'pages/employee-master.php',
    'offboarding_page' => 'pages/offboarding.php',
    'attendance_page' => 'pages/attendance-management.php',
    'pay_run_page' => 'pages/payroll-pay-runs.php',
    'hrms_api' => 'hrms-api.php',
    'hrms_common' => 'hrms/hrms_common.php',
    'payroll_api' => 'payroll-api.php',
    'payroll_common' => 'payroll/payroll_common.php',
    'payroll_file' => 'payroll-file.php',
    'payroll_pdf' => 'payroll/payroll_pdf.php',
    'push_api' => 'biometric-push-api.php',
    'migration' => 'migrations/2026_09_01_001_careio_pdf_completion.sql',
    'access_migration' => 'migrations/2026_09_01_003_strict_hrms_access.sql',
] as $name => $relativePath) {
    $source = file_get_contents($admin . '/' . $relativePath);
    if ($source === false) {
        fwrite(STDERR, "FAILED\n- Unable to read {$relativePath}.\n");
        exit(1);
    }
    $sources[$name] = $source;
}

$positionSignOut = strpos($sources['navbar'], '>Sign Out<');
$positionApplyLeave = strpos($sources['navbar'], '>Apply Leave<');
$assertions = [
    'navbar renders linked employee identity' => str_contains($sources['navbar'], '$navbar_employee_code')
        && str_contains($sources['navbar'], "profile_photo_id")
        && str_contains($sources['navbar'], "company_name")
        && str_contains($sources['navbar'], "branch_name"),
    'navbar trigger uses employee photo or initials' => str_contains($sources['navbar'], 'alt="Open profile settings"')
        && str_contains($sources['navbar'], '$navbar_initials')
        && !str_contains($sources['navbar'], '<i class="ti ti-user ti-md"></i>'),
    'navbar routes resignation through Profile Settings' => str_contains($sources['navbar'], 'open=apply-leave')
        && str_contains($sources['navbar'], 'open=claim-reimbursement')
        && str_contains($sources['navbar'], '>Profile Settings</a>')
        && !str_contains($sources['navbar'], 'open=resign')
        && str_contains($sources['employee_profile'], '> Resign'),
    'apply leave follows sign out as specified' => $positionSignOut !== false && $positionApplyLeave !== false && $positionApplyLeave > $positionSignOut,
    'leave types are tenant managed' => str_contains($sources['hrms_api'], "case 'save_leave_type':")
        && str_contains($sources['hrms_api'], 'System and other organization leave types cannot be edited.')
        && str_contains($sources['leave_page'], 'id="leaveTypeForm"'),
    'leave allocations validate type organization' => str_contains($sources['hrms_api'], 'Select a leave type available to this employee organization.'),
    'employee master shows full payroll breakdown' => str_contains($sources['employee_master'], 'Total Monthly Salary')
        && str_contains($sources['employee_master'], 'salary_components')
        && str_contains($sources['employee_master'], '>Payroll</h5>'),
    'employee details use Personal and Payroll tabs' => str_contains($sources['employee_master'], 'employee-detail-tab')
        && str_contains($sources['employee_master'], 'data-panel="0"')
        && str_contains($sources['employee_master'], 'data-panel="1"'),
    'employee master exposes direct resume action' => str_contains($sources['employee_master'], 'View Resume/File'),
    'extended onboarding screenshot fields are captured' => str_contains($sources['employee_master'], 'extendedOnboardingReady')
        && str_contains($sources['employee_master'], 'name="middle_name"')
        && str_contains($sources['employee_master'], 'id="onboardingAge"')
        && str_contains($sources['employee_master'], 'name="differently_abled_type"')
        && str_contains($sources['employee_master'], 'name="postal_code"')
        && str_contains($sources['hrms_api'], '$hasExtendedProfilePayload'),
    'custom payroll components remain editable' => str_contains($sources['employee_master'], 'custom_salary_components')
        && str_contains($sources['hrms_api'], '$hasCustomComponentsPayload'),
    'configured resignation approver is enforced' => str_contains($sources['hrms_api'], 'This resignation is assigned to the configured approver.')
        && str_contains($sources['offboarding_page'], 'can_review'),
    'approved offboarding documents send immediately' => str_contains($sources['hrms_api'], "if (\$decision === 'approved')")
        && str_contains($sources['hrms_api'], 'hrmsSendOffboardingDocuments($conn, $requestId);')
        && str_contains($sources['hrms_common'], "request.status IN ('exit_interview_pending','completed')"),
    'offboarding document retry remains available' => substr_count($sources['hrms_api'], 'hrmsSendOffboardingDocuments($conn, $requestId)') >= 2,
    'biometric push uses bearer authentication' => str_contains($sources['push_api'], 'HTTP_AUTHORIZATION')
        && str_contains($sources['push_api'], "hash('sha256', \$deviceToken)"),
    'biometric push is idempotent and rate limited' => str_contains($sources['push_api'], 'X_INGEST_BATCH_ID')
        && str_contains($sources['push_api'], 'ingestion rate limit exceeded')
        && str_contains($sources['migration'], 'uq_hr_biometric_batch'),
    'biometric push preserves raw vendor data' => str_contains($sources['push_api'], 'rawPayload')
        && str_contains($sources['push_api'], 'JSON_UNESCAPED_SLASHES'),
    'biometric imports use the shared attendance calculator' => str_contains($sources['push_api'], 'hrmsRecalculateAttendance')
        && str_contains($sources['hrms_api'], 'hrmsRecalculateAttendance'),
    'global authorized managers receive workflow alerts' => str_contains($sources['hrms_common'], 'user.company_id = ? OR user.company_id IS NULL'),
    'manual attendance is restricted to biometric presence' => str_contains($sources['hrms_api'], 'daily.first_punch_at IS NOT NULL')
        && str_contains($sources['hrms_api'], 'Attendance can only be marked for employees present in biometric data.'),
    'manual attendance survives recalculation' => str_contains($sources['hrms_common'], "hr_attendance_daily.source = 'manual'"),
    'present-only marking surface exists' => str_contains($sources['attendance_page'], 'Present Employee Marking')
        && str_contains($sources['attendance_page'], '$presentAttendanceRows'),
    'present marking supports type department and bulk selection' => str_contains($sources['attendance_page'], 'id="presentTypeFilter"')
        && str_contains($sources['attendance_page'], 'id="presentDepartmentFilter"')
        && str_contains($sources['attendance_page'], 'id="selectAllPresent"')
        && str_contains($sources['hrms_api'], "isset(\$_POST['employee_ids'])"),
    'attendance drill-down starts from every scoped employee' => str_contains($sources['attendance_page'], 'FROM employees employee')
        && str_contains($sources['attendance_page'], "COALESCE(daily.classification,'absent')"),
    'employees inherit a tenant default shift without a roster' => str_contains($sources['hrms_common'], '$defaultShiftStmt')
        && str_contains($sources['hrms_common'], 'day.day_of_week = WEEKDAY(?) + 1'),
    'shift policy changes recalculate affected attendance automatically' => str_contains($sources['hrms_common'], 'function hrmsRecalculateAttendanceRange')
        && substr_count($sources['hrms_api'], 'hrmsRecalculateAttendanceRange(') >= 2,
    'biometric administration is separated from Production marking' => str_contains($sources['hrms_api'], "hrmsRequirePermission(\$conn, 'hrms_biometric_manage')")
        && str_contains($sources['attendance_page'], '$canConfigureBiometrics')
        && str_contains($sources['migration'], 'HRMS Biometric Administration'),
    'attendance and shifts receive exact action role scope' => str_contains($sources['access_migration'], "permission.slug = 'hrms_attendance_view'")
        && str_contains($sources['access_migration'], "permission.slug = 'hrms_attendance_mark'")
        && str_contains($sources['access_migration'], "LOWER(role.name) IN ('production', 'human resources')")
        && str_contains($sources['access_migration'], "CASE WHEN LOWER(role.name) = 'human resources' THEN 1 ELSE 0 END"),
    'all HRMS menu routes are registered' => str_contains($sources['migration'], 'index.php?page=employee-master')
        && str_contains($sources['migration'], 'index.php?page=leave-management')
        && str_contains($sources['migration'], 'index.php?page=offboarding')
        && str_contains($sources['migration'], 'index.php?page=attendance-management')
        && str_contains($sources['migration'], 'index.php?page=shift-management'),
    'employee self-service route permissions are seeded' => str_contains($sources['migration'], 'hrms_leave_view')
        && str_contains($sources['migration'], 'hrms_offboarding_view'),
    'legacy tenant profiles are backfilled without overwriting values' => str_contains($sources['migration'], 'ON DUPLICATE KEY UPDATE')
        && str_contains($sources['migration'], 'COALESCE(hr_employee_profiles.company_id, VALUES(company_id))')
        && str_contains($sources['migration'], 'HAVING COUNT(*) = 1'),
    'payroll monthly salary uses earning components' => str_contains($sources['payroll_common'], 'SUM(component.monthly_amount)')
        && str_contains($sources['payroll_common'], 'component.is_deduction = 0')
        && str_contains($sources['payroll_common'], 'COALESCE(salary.hra,0)')
        && str_contains($sources['payroll_common'], 'COALESCE(salary.incentives,0)'),
    'legacy attendance fallback remains intact' => str_contains($sources['payroll_common'], "'source' => 'legacy'")
        && str_contains($sources['payroll_common'], "\$attendance['daily'][\$employeeId] ?? \$attendance['legacy'][\$employeeId]"),
    'pay run exposes an embedded PDF preview' => str_contains($sources['pay_run_page'], 'id="payRunPdfFrame"')
        && str_contains($sources['payroll_api'], "'preview_url'")
        && str_contains($sources['payroll_file'], "pay-run-preview")
        && str_contains($sources['payroll_file'], 'payrollBuildFullPreviewPdf'),
    'full payroll preview contains all required columns' => str_contains($sources['payroll_pdf'], '<th>Monthly Salary</th>')
        && str_contains($sources['payroll_pdf'], '<th>Actual Salary</th>')
        && str_contains($sources['payroll_pdf'], '<th>Total Working Days</th>')
        && str_contains($sources['payroll_pdf'], '<th>PF Amount</th>')
        && str_contains($sources['payroll_pdf'], '<th>ESIC Amount</th>')
        && str_contains($sources['payroll_pdf'], '<th>Advance Taken</th>'),
    'pay-run history has preview and download actions' => str_contains($sources['pay_run_page'], 'preview-pay-run')
        && str_contains($sources['pay_run_page'], 'title="Download bank PDF"'),
    'reimbursement notifications use numeric module' => !str_contains($sources['payroll_api'], 'PAYROLL_REIMBURSEMENT')
        && !str_contains($sources['payroll_common'], 'PAYROLL_REIMBURSEMENT')
        && substr_count($sources['payroll_api'] . $sources['payroll_common'], "'92'") === 2,
];

$run = ['run_number' => 'PR-SMOKE', 'payroll_month' => '2026-09', 'payment_date' => '2026-10-07'];
$items = [[
    'serial_number' => 1,
    'employee_code' => 'EMP-SMOKE',
    'employee_name' => 'Payroll Smoke',
    'monthly_salary' => 15000,
    'gross_earned' => 13000,
    'actual_salary' => 12345.67,
    'present_days' => 26,
    'month_days' => 30,
    'pf_amount' => 900,
    'esic_amount' => 130,
    'advance_taken' => 500,
    'bank_account_number' => '000011112222',
    'bank_name' => 'Test Bank',
]];
$generated = null;
try {
    $generated = payrollGenerateBankPdf($run, $items);
    $pdf = file_get_contents($generated['absolute_path']);
    $assertions['bank disbursement PDF is generated'] = $pdf !== false && str_starts_with($pdf, '%PDF-') && strlen($pdf) > 1000;
    $assertions['bank PDF keeps exactly the required headers'] = str_contains($sources['payroll_pdf'], '<th>Serial #</th><th>Employee Code</th><th>Name</th><th>Salary</th><th>Bank Account #</th><th>Bank Name</th>');
    $fullPreviewPdf = payrollBuildFullPreviewPdf($run, $items);
    $assertions['full payroll preview PDF is generated'] = str_starts_with($fullPreviewPdf, '%PDF-') && strlen($fullPreviewPdf) > 1000;
} finally {
    if (is_array($generated) && is_file($generated['absolute_path'])) {
        unlink($generated['absolute_path']);
    }
}

$failures = array_keys(array_filter($assertions, static fn(bool $passed): bool => !$passed));
if ($failures !== []) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo 'PASS: ' . count($assertions) . " Care IO PDF completion assertions.\n";