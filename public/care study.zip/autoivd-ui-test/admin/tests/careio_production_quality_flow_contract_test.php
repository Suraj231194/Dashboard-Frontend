<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$approvedPayload = json_encode(['fields' => ['approval.decision' => 'APPROVED']]);
$rejectedPayload = json_encode(['fields' => ['approval.decision' => 'REJECTED']]);

$assert(
    bmrBprCoaApprovalDecision($approvedPayload) === 'APPROVED'
        && bmrBprCoaApprovalDecision($rejectedPayload) === 'REJECTED',
    'COA approval decisions are not read from the controlled document payload.'
);
$assert(
    bmrBprNormalizeCoaWorkflowStatus('DRAFT', null, null, 'COA') === 'DRAFT',
    'A controlled COA draft cannot remain a draft.'
);
$assert(
    bmrBprNormalizeCoaWorkflowStatus('COMPLETED', 1, $approvedPayload, 'COA') === 'COMPLETED',
    'An approved controlled COA does not reach the completed state.'
);
$assert(
    bmrBprNormalizeCoaWorkflowStatus('COMPLETED', 1, $rejectedPayload, 'COA') === 'REJECTED',
    'A rejected controlled COA is incorrectly treated as approved.'
);

$missingTemplateBlocked = false;
try {
    bmrBprNormalizeCoaWorkflowStatus('COMPLETED', null, null, 'COA');
} catch (DomainException) {
    $missingTemplateBlocked = true;
}
$assert($missingTemplateBlocked, 'A controlled COA can complete without an active mapped template.');
$assert(
    !bmrBprBmrStatusesReady(['IN_PROCESS', 'COMPLETE'])
        && bmrBprBmrStatusesReady(['COMPLETE', 'COMPLETE']),
    'BPR can start before every BMR is complete.'
);
$assert(
    !bmrBprBmrStatusesReady(['COMPLETE'], 2)
        && bmrBprBmrStatusesReady(['COMPLETE', 'COMPLETE'], 2),
    'BPR can start when a configured BMR is missing.'
);

foreach ([[1, 100], [100, 100], [0.125, 1]] as [$quantity, $batchSize]) {
    try {
        bmrBprValidateTransferQuantity($quantity, $batchSize);
    } catch (Throwable $exception) {
        $failures[] = 'A valid finished-goods transfer quantity was rejected.';
    }
}
foreach ([[0, 100], [-1, 100], [101, 100], [NAN, 100], [INF, 100], [1, 0], [1, NAN], [1, INF], [0.000000001, 100]] as [$quantity, $batchSize]) {
    $blocked = false;
    try {
        bmrBprValidateTransferQuantity($quantity, $batchSize);
    } catch (InvalidArgumentException | DomainException $exception) {
        $blocked = true;
    }
    $assert($blocked, 'An invalid or oversized finished-goods transfer quantity was accepted.');
}

$releaseRecord = [
    'request_id' => 1, 'request_status' => 'APPROVED', 'required_bpr_count' => 2,
    'workflow_status' => 'COMPLETED', 'coa_template_id' => 1, 'form_payload_json' => $approvedPayload,
    'ip_workflow_status' => 'COMPLETED', 'ip_coa_template_id' => 1, 'ip_form_payload_json' => $approvedPayload,
];
bmrBprValidateReleaseRecord($releaseRecord, ['COMPLETE', 'COMPLETE']);
foreach ([
    [['workflow_status' => 'DRAFT'], ['COMPLETE', 'COMPLETE']],
    [['form_payload_json' => $rejectedPayload], ['COMPLETE', 'COMPLETE']],
    [['ip_form_payload_json' => $rejectedPayload], ['COMPLETE', 'COMPLETE']],
    [['request_status' => 'REJECTED'], ['COMPLETE', 'COMPLETE']],
    [[], ['COMPLETE', 'IN_PROCESS']],
    [[], ['COMPLETE']],
    [[], []],
] as [$overrides, $statuses]) {
    $blocked = false;
    try {
        bmrBprValidateReleaseRecord(array_replace($releaseRecord, $overrides), $statuses);
    } catch (DomainException $exception) {
        $blocked = true;
    }
    $assert($blocked, 'An unapproved or incomplete manufacturing batch was accepted for release.');
}
foreach (['addTransferTicket', 'updateTransferTicket', 'updateTransferTicket1', 'createManualBomIssuance'] as $action) {
    $assert(in_array($action, bmrBprLegacyWriteActions(), true), 'A legacy production write route remains enabled.');
}
foreach (['addProductionPlan', 'addProductionPlanBom', 'completeProductionPlan', 'acceptProductionPlan', 'addMaterialRequisitionForm', 'generateBomFromPlan', 'issueBomItems', 'acknowledgeGoodsReceivedProduction', 'updateIpCoaRecord'] as $action) {
    $assert(isset(bmrBprProductionWritePermissions()[$action]), 'A production write route has no server-side permission.');
}

bmrBprValidateBatchIdentity(7, 100.25, 7, 100.25);
foreach ([[7, 100, 8, 100], [7, 100, 7, 101], [7, 100, 7, NAN], [0, 100, 0, 100]] as $identity) {
    $blocked = false;
    try {
        bmrBprValidateBatchIdentity(...$identity);
    } catch (DomainException $exception) {
        $blocked = true;
    }
    $assert($blocked, 'A product or batch change bypassed its production source.');
}
$completionLayout = ['schema_version' => 2, 'renderer' => 'structured_html', 'editable_prefixes' => ['test.'], 'required_fields' => ['test.result']];
bmrBprValidateCompletionPayload($completionLayout, ['fields' => ['test.result' => '0']]);
foreach ([[], ['fields' => []], ['fields' => ['test.result' => '   ']], ['fields' => ['test.other' => 'value']]] as $payload) {
    $blocked = false;
    try {
        bmrBprValidateCompletionPayload($completionLayout, bmrBprSanitizeTemplatePayload($completionLayout, $payload));
    } catch (DomainException $exception) {
        $blocked = true;
    }
    $assert($blocked, 'An empty or incomplete required production form was accepted.');
}
$configuredRequirements = bmrBprNormalizeDocumentRequirements([
    'BMR' => [['document_sequence' => 1, 'required_quantity' => 3, 'template_id' => 1]],
    'BPR' => [['document_sequence' => 1, 'required_quantity' => 2, 'template_id' => 2]],
], 9, 9);
$assert(bmrBprDocumentRequirementCounts($configuredRequirements) === ['BMR' => 3, 'BPR' => 2],
    'The configured BMR/BPR document counts were changed.');

$ajax = file_get_contents(dirname(__DIR__) . '/ajax.php');
$actions = file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_actions.php');
$common = file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_common.php');
$assert(substr_count($actions, "bmrBprBmrStatusesReady(\$bmrStatuses, (int) \$item['bmr_form_count'])") === 2
    && str_contains($common, 'bmr_gate.bmr_count = r.bmr_form_count'),
    'The packing actions or queue omit the configured BMR count gate.');
$assert($ajax !== false && substr_count($ajax, 'bmrBprEnsureRequestForMaterialRequisition(') === 1,
    'BMR/BPR requests are queued from a point other than completed material issuance.');
$assert(
    $actions !== false
        && substr_count($actions, 'bmrBprRequestHasApprovedIpCoa(') >= 2
        && substr_count($actions, 'bmrBprCoaRecordIsApproved(') >= 3
        && str_contains($actions, 'bmrBprLoadReleaseSource(')
        && str_contains($ajax, 'bmrBprLoadReleaseSource(')
        && str_contains($ajax, 'bmrBprProductionWritePermissions()')
        && str_contains($ajax, 'bmrBprLegacyWriteActions()'),
    'One or more controlled quality/packing release gates are missing.'
);
$assert(
    $common !== false
        && str_contains($common, 'Automatically queued after all Material Requisition items were issued.')
        && str_contains($common, 'Automatically queued after BPR completion and FG COA approval.'),
    'The controlled handoff audit messages do not match the approved production flow.'
);
$assert(
    $actions !== false
        && substr_count($actions, 'bmrBprEnsurePendingTransferTicketForRequest(') >= 2,
    'The automatic pending Transfer Ticket is not handled from both possible final gate events.'
);
$assert(str_contains($common, "status = 'UPCOMING'")
    && str_contains($actions, 'bmrBprValidateBatchIdentity(')
    && str_contains($actions, 'bmrBprValidateCompletionPayload('),
    'Controlled handoff, source identity or production document completion is not enforced.');
$assert(str_contains($actions, 'FG COA generation is locked until Sample Advice (SA) is approved by QA.'),
    'The required Sample Advice approval gate was removed.');
$assert(str_contains($ajax, 'bmrBprRequireApprovedSampleAdvice(')
    && substr_count($common, 'bmrBprRequireApprovedSampleAdvice(') >= 2,
    'Sample Advice is not rechecked during controlled FG completion and release.');
$materialListStart = strpos($ajax, 'if (isset($_POST["loadProductionPlanWithMatRequi"])');
$materialListEnd = strpos($ajax, '// if (isset($_POST["addProductionPlan"])', $materialListStart);
$materialList = substr($ajax, $materialListStart, $materialListEnd - $materialListStart);
$assert(!str_contains($materialList, 'order-detail') && !str_contains($materialList, 'linked_order')
    && !str_contains($materialList, 'addTransferTicketByPlanBtn') && !str_contains($materialList, 'productionPlanToMatRequest')
    && str_contains($materialList, 'accepted_history') && str_contains($materialList, 'production_plan_no'),
    'Material Requisition leaks order details or exposes an unaccepted/legacy workflow shortcut.');
$assert(str_contains($ajax, 'Production Plan details are locked once Material Requisition has started.'),
    'Production plan identity remains editable after its material requisition.');
$assert(str_contains($ajax, 'Complete the linked manufacturing documents and quality release before completing this plan.'),
    'Manual plan completion bypasses production documentation and quality release.');
$productionListStart = strpos($ajax, 'if (isset($_POST["loadProductionPlan"])');
$productionList = substr($ajax, $productionListStart, $materialListStart - $productionListStart);
$assert(!str_contains($productionList, 'order-detail') && !str_contains($productionList, 'linked_order'),
    'Production Plan exposes commercial order references.');
$fgEditStart = strpos($ajax, 'if (isset($_POST["updateFGCoaRecord"])');
$fgEditEnd = strpos($ajax, 'if (isset($_POST["loadAdvanceSalary"])', $fgEditStart);
$fgEdit = substr($ajax, $fgEditStart, $fgEditEnd - $fgEditStart);
$assert(str_contains($fgEdit, "\$prodBatchSize = (float) \$currentCoa['batch_size'];")
    && str_contains($fgEdit, "\$prodBatchSizeUnit = (int) \$currentCoa['batch_size_unit'];"),
    'Controlled FG COA edits can override the manufacturing quantity or unit.');

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo 'CareIO production/quality PDF flow contract test passed.' . PHP_EOL;
