<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../workflow/bmr_bpr_common.php';

$assert = static function (bool $condition, string $message): void {
    if (!$condition) {
        throw new RuntimeException($message);
    }
};

$expectedProductIds = [
    937, 940, 941, 942, 950, 951, 1019,
    1432, 1433, 1434, 1684, 1685, 2020, 2021,
];
sort($expectedProductIds);

$templateResult = $conn->query(
    "SELECT id, form_type, template_code, source_pdf_path, page_asset_path, layout_json
     FROM bmr_templates
     WHERE template_code IN (
         'COMMON_MICROBIOLOGY_BMR_V03',
         'COMMON_MICROBIOLOGY_BPR_V03'
     )
       AND status = 1
       AND deleted_at IS NULL
     ORDER BY form_type"
);
$assert($templateResult !== false, 'Unable to query the installed Microbiology templates.');
$templates = $templateResult->fetch_all(MYSQLI_ASSOC);
$assert(count($templates) === 2, 'Both Microbiology templates are not active.');

$templateIdsByType = [];
foreach ($templates as $template) {
    $formType = strtoupper((string) $template['form_type']);
    $layout = json_decode((string) $template['layout_json'], true);
    $assert(
        $template['source_pdf_path'] === null && $template['page_asset_path'] === null,
        "The {$formType} template has a runtime PDF or image dependency."
    );
    $assert(
        is_array($layout)
            && ($layout['renderer'] ?? '') === 'structured_html'
            && ($layout['renderer_variant'] ?? '') === 'microbiology',
        "The {$formType} template is not using the Microbiology code renderer."
    );
    $templateIdsByType[$formType] = (int) $template['id'];
}
$assert(
    isset($templateIdsByType['BMR'], $templateIdsByType['BPR']),
    'The installed Microbiology template types are incomplete.'
);

$mappingResult = $conn->query(
    "SELECT mapping.product_id, mapping.form_type, mapping.template_id
     FROM bmr_template_product_mappings mapping
     INNER JOIN bmr_templates template
        ON template.id = mapping.template_id
       AND template.template_code IN (
           'COMMON_MICROBIOLOGY_BMR_V03',
           'COMMON_MICROBIOLOGY_BPR_V03'
       )
       AND template.status = 1
       AND template.deleted_at IS NULL
     WHERE mapping.status = 1
       AND mapping.deleted_at IS NULL
     ORDER BY mapping.form_type, mapping.product_id"
);
$assert($mappingResult !== false, 'Unable to query the Microbiology mappings.');
$mappings = $mappingResult->fetch_all(MYSQLI_ASSOC);
$assert(count($mappings) === 28, 'The installed Microbiology mapping count is not 28.');

$mappedIdsByType = ['BMR' => [], 'BPR' => []];
foreach ($mappings as $mapping) {
    $formType = strtoupper((string) $mapping['form_type']);
    $assert(
        (int) $mapping['template_id'] === ($templateIdsByType[$formType] ?? 0),
        "A {$formType} product is mapped to the wrong Microbiology template."
    );
    $mappedIdsByType[$formType][] = (int) $mapping['product_id'];
}
foreach ($mappedIdsByType as $formType => $productIds) {
    sort($productIds);
    $assert(
        $productIds === $expectedProductIds,
        "The installed {$formType} Microbiology product set is incorrect."
    );
}

$demoResult = $conn->query(
    "SELECT
        request_row.id AS request_id,
        request_row.product_id,
        work_item.form_type,
        work_item.status,
        work_item.form_payload_json,
        template.template_code
     FROM material_requisition source_mr
     INNER JOIN bmr_bpr_requests request_row
        ON request_row.material_requisition_id = source_mr.id
       AND request_row.deleted_at IS NULL
     INNER JOIN bmr_bpr_work_items work_item
        ON work_item.request_id = request_row.id
       AND work_item.deleted_at IS NULL
     INNER JOIN bmr_templates template
        ON template.id = work_item.template_id
       AND template.deleted_at IS NULL
     WHERE source_mr.slip_no LIKE 'BMR-COMMON-MICROBIOLOGY-DEMO-%'
       AND source_mr.deleted_at IS NULL
     ORDER BY request_row.product_id, work_item.form_type"
);
$assert($demoResult !== false, 'Unable to query the Microbiology demo records.');
$demoRows = $demoResult->fetch_all(MYSQLI_ASSOC);
$assert(count($demoRows) === 28, 'The Microbiology demo work-item count is not 28.');

$demoProductIds = [];
foreach ($demoRows as $row) {
    $formType = strtoupper((string) $row['form_type']);
    $expectedStatus = $formType === 'BMR' ? 'IN_PROCESS' : 'PENDING';
    $expectedTemplateCode = 'COMMON_MICROBIOLOGY_' . $formType . '_V03';
    $assert(
        strtoupper((string) $row['status']) === $expectedStatus,
        "A Microbiology {$formType} demo record has the wrong status."
    );
    $assert(
        (string) $row['template_code'] === $expectedTemplateCode,
        "A Microbiology {$formType} demo record has the wrong template."
    );
    $assert(
        $row['form_payload_json'] === null,
        "A Microbiology {$formType} demo record contains preloaded saved form data."
    );
    $demoProductIds[(int) $row['product_id']] = true;
}
$actualDemoProductIds = array_map('intval', array_keys($demoProductIds));
sort($actualDemoProductIds);
$assert(
    $actualDemoProductIds === $expectedProductIds,
    'The Microbiology demo product set is incorrect.'
);

$incomingCounts = ['BMR' => 0, 'BPR' => 0];
$productionRows = bmrBprProductionRows($conn);
foreach ($productionRows as $row) {
    if (!in_array((int) ($row['product_id'] ?? 0), $expectedProductIds, true)) {
        continue;
    }
    if (strpos((string) ($row['template_code'] ?? ''), 'COMMON_MICROBIOLOGY_') !== 0) {
        continue;
    }
    $isDemoBmrPreview = !empty($row['is_common_template_demo'])
        && $row['form_type'] === 'BMR'
        && $row['status_code'] === 'IN_PROCESS';
    if (
        (
            in_array($row['status_code'], ['QUEUED', 'PENDING'], true)
            || $isDemoBmrPreview
        )
        && !empty($row['can_open'])
    ) {
        $incomingCounts[$row['form_type']]++;
    }
}
$assert(
    $incomingCounts === ['BMR' => 14, 'BPR' => 14],
    'The Microbiology Incoming BMR/BPR classification is not 14 and 14.'
);

echo "Microbiology installation smoke test passed: 2 templates, 28 mappings, "
    . "14 BMR demos and 14 BPR demos.\n";
