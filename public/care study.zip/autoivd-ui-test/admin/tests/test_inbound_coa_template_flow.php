<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';

echo "======================================================================\n";
echo "       INBOUND COA TEMPLATE WORKFLOW & IN-PAGE FORM TEST             \n";
echo "======================================================================\n\n";

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] $message\n";
    } else {
        echo "  [PASSED] $message\n";
    }
};

// TEST 1: Template Discovery & Top Matching Algorithm
echo "TEST 1: Verify findCoaTemplatesForMaterial ranking & grouping...\n";

$templates = findCoaTemplatesForMaterial($conn, 0, 0, 'Albumin');
$assert(!empty($templates), 'Templates must be returned when searching with keywords.');

$hasRecommendedGroup = false;
$hasAllGroup = false;
foreach ($templates as $t) {
    if (($t['group_label'] ?? '') === '⭐ Recommended Templates') {
        $hasRecommendedGroup = true;
    }
    if (($t['group_label'] ?? '') === '📋 All Available COA Templates') {
        $hasAllGroup = true;
    }
}
$assert($hasAllGroup, 'Templates list must include the universal "All Available COA Templates" group.');
echo "  Total templates returned: " . count($templates) . "\n\n";

// TEST 2: Static Source Code Check - No redirect in raw-material-packing-material.php
echo "TEST 2: Verify raw-material-packing-material.php source code contract...\n";
$rmpmSource = (string) file_get_contents(dirname(__DIR__) . '/pages/raw-material-packing-material.php');

$assert(
    !str_contains($rmpmSource, "window.location.href = 'index.php?page=coa-generation'"),
    'raw-material-packing-material.php must NOT redirect to coa-generation page.'
);
$assert(
    str_contains($rmpmSource, 'id="inboundCoaEntryModal"'),
    'raw-material-packing-material.php must include the in-page inboundCoaEntryModal.'
);
$assert(
    str_contains($rmpmSource, 'id="inboundLoadTemplateBtn"'),
    'raw-material-packing-material.php must provide a dedicated Load Template button.'
);
$assert(
    str_contains($rmpmSource, 'openInboundCoaForm(queueId, stockInwardId)'),
    'selectTestBtn click must trigger in-page openInboundCoaForm.'
);
echo "\n";

// TEST 3: Static Source Code Check - coa-generation.php
echo "TEST 3: Verify coa-generation.php template loader consistency...\n";
$coaGenSource = (string) file_get_contents(dirname(__DIR__) . '/pages/coa-generation.php');
$assert(
    str_contains($coaGenSource, 'id="inboundLoadTemplateBtn"'),
    'coa-generation.php must include the Load Template button for UI consistency.'
);
$assert(
    str_contains($coaGenSource, 'loadInboundTemplateFields'),
    'coa-generation.php must include the loadInboundTemplateFields helper.'
);
echo "\n";

// TEST 4: Fetch Template Fields Output
echo "TEST 4: Verify template fields query for active templates...\n";
$activeTemplate = $conn->query("SELECT id, name FROM coa_templates WHERE status = 1 AND deleted_at IS NULL LIMIT 1")->fetch_assoc();
if ($activeTemplate) {
    $tId = (int) $activeTemplate['id'];
    $itemCount = (int) ($conn->query("SELECT COUNT(*) AS total FROM coa_templates_items WHERE coa_template_id = {$tId} AND status = 1 AND deleted_at IS NULL")->fetch_assoc()['total'] ?? 0);
    echo "  Testing template ID: #{$tId} ({$activeTemplate['name']}), items: {$itemCount}\n";
    $assert($tId > 0, "Active template exists with ID #{$tId}");
} else {
    $assert(false, 'At least one active template must exist in coa_templates.');
}
echo "\n";

// SUMMARY
echo "======================================================================\n";
if ($failures !== []) {
    echo "FAILED with " . count($failures) . " errors:\n- " . implode("\n- ", $failures) . "\n";
    exit(1);
}

echo "ALL TESTS PASSED SUCCESSFULLY! (0 failures)\n";
echo "======================================================================\n";
