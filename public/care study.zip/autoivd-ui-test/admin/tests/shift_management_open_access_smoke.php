<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$page = (string) file_get_contents($root . '/pages/shift-management.php');
$api = (string) file_get_contents($root . '/hrms-api.php');
$migration = (string) file_get_contents($root . '/migrations/2026_09_02_004_shift_management_open_access.sql');

$createStart = strpos($api, "case 'create_hrms_shift':");
$policyStart = strpos($api, "case 'save_shift_policy':");
$createSection = $createStart === false || $policyStart === false
    ? ''
    : substr($api, $createStart, $policyStart - $createStart);
$policySection = $policyStart === false ? '' : substr($api, $policyStart, 4000);

$assertions = [
    'page is available without a shift permission grant' => str_contains($page, '$canManageShifts=true;'),
    'shift creation has no role or user permission check' => $createSection !== ''
        && !str_contains($createSection, 'hrmsRequirePermission')
        && !str_contains($createSection, 'hrmsCan('),
    'shift policy updates have no role or user permission check' => $policySection !== ''
        && !str_contains($policySection, "hrmsRequirePermission(\$conn, 'hrms_shift_manage')"),
    'menu permission is removed idempotently' => str_contains($migration, '`permission_slug` = NULL')
        && str_contains($migration, "index.php?page=shift-management"),
    'global login and CSRF protections remain in the HRMS API' => str_contains($api, '$userId = hrmsRequireLogin();')
        && str_contains($api, "'create_hrms_shift'")
        && str_contains($api, "'save_shift_policy'")
        && str_contains($api, 'hrmsRequireCsrf();'),
];

$failures = array_keys(array_filter($assertions, static fn(bool $passed): bool => !$passed));
if ($failures !== []) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . PHP_EOL);
    exit(1);
}

echo 'PASS: ' . count($assertions) . " Shift Management open-access assertions.\n";
