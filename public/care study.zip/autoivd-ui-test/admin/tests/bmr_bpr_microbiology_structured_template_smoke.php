<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_structured_renderer.php';
require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

$schemaRoot = dirname(__DIR__, 2) . '/assets/bmr-bpr-schemas';
$schemaFiles = [
    $schemaRoot . '/common-microbiology-bmr-v3.json',
    $schemaRoot . '/common-microbiology-bpr-v3.json',
];
$expectedProductIds = [
    937, 940, 941, 942, 950, 951, 1019,
    1432, 1433, 1434, 1684, 1685, 2020, 2021,
];
$brandingLogoPath = dirname(__DIR__, 2) . '/assets/img/logo3.jpeg';
$brandingLogo = is_file($brandingLogoPath)
    ? (string) file_get_contents($brandingLogoPath)
    : '';
$brandingLogoDataUri = $brandingLogo === ''
    ? ''
    : 'data:image/jpeg;base64,' . base64_encode($brandingLogo);

$failures = [];
$renderedDocuments = 0;
$renderedPageCounts = [];

foreach ($schemaFiles as $schemaFile) {
    $layout = json_decode((string) file_get_contents($schemaFile), true);
    if (
        !is_array($layout)
        || !bmrBprIsStructuredLayout($layout)
        || (string) ($layout['renderer_variant'] ?? '') !== 'microbiology'
    ) {
        $failures[] = basename($schemaFile) . ': invalid Microbiology structured schema';
        continue;
    }

    $productIds = array_values(array_map('intval', array_keys($layout['profiles'] ?? [])));
    sort($productIds);
    $sortedExpected = $expectedProductIds;
    sort($sortedExpected);
    if ($productIds !== $sortedExpected) {
        $failures[] = basename($schemaFile) . ': distinct Microbiology product profile set is incomplete';
        continue;
    }

    foreach ($productIds as $productId) {
        $profile = bmrBprStructuredProfile($layout, $productId);
        $expectedPages = (int) ($profile['page_count'] ?? 0);
        $form = [
            'form_type' => (string) $layout['form_type'],
            'layout' => $layout,
            'profile' => $profile,
            'branding_logo_data_uri' => $brandingLogoDataUri,
            'source_values' => [
                'product_name' => (string) ($profile['product_name'] ?? ''),
                'batch_number' => 'MICROBIOLOGY-SMOKE-001',
                'batch_size' => (string) ($profile['standard_batch'] ?? ''),
                'pack_size' => (string) ($profile['pack_size'] ?? ''),
                'record_number' => (string) $layout['form_type'] . '/SMOKE/000001-01',
            ],
            'form_payload' => [
                'schema_version' => 2,
                'fields' => [
                    'cover.mfg_date' => '29/07/2026',
                    'qa.decision_remarks' => 'Microbiology structured smoke test',
                ],
            ],
        ];

        $html = bmrBprRenderStructuredTemplate($form, true);
        $pageCount = substr_count($html, 'class="bmr-v2-page"');
        if ($pageCount !== $expectedPages) {
            $failures[] = "{$layout['form_type']} product {$productId}: expected {$expectedPages} HTML pages, found {$pageCount}";
        }
        if (
            stripos($html, 'source.pdf') !== false
            || stripos($html, 'page-001') !== false
            || stripos($html, 'bmr-bpr-templates') !== false
        ) {
            $failures[] = "{$layout['form_type']} product {$productId}: renderer depends on product PDF/page artwork";
        }
        if (
            $brandingLogoDataUri !== ''
            && substr_count($html, 'class="bmr-v2-brand-logo"') !== $expectedPages
        ) {
            $failures[] = "{$layout['form_type']} product {$productId}: shared company logo is missing";
        }
        if (stripos($html, 'data-bmr-field="cover.mfg_date"') === false) {
            $failures[] = "{$layout['form_type']} product {$productId}: editable semantic field missing";
        }

        $printHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
            . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
            . '</head><body>'
            . bmrBprRenderStructuredTemplate($form, false)
            . '</body></html>';
        $options = new Dompdf\Options();
        $options->set('isRemoteEnabled', false);
        $options->set('defaultFont', 'Helvetica');
        $dompdf = new Dompdf\Dompdf($options);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->loadHtml($printHtml, 'UTF-8');
        $dompdf->render();
        $pdf = $dompdf->output();
        if (!str_starts_with($pdf, '%PDF-')) {
            $failures[] = "{$layout['form_type']} product {$productId}: Dompdf output is invalid";
        }
        $actualPdfPages = (int) $dompdf->getCanvas()->get_page_count();
        if ($actualPdfPages !== $expectedPages) {
            $failures[] = "{$layout['form_type']} product {$productId}: expected {$expectedPages} PDF pages, found {$actualPdfPages}";
        }
        $renderedPageCounts[$layout['form_type']][$expectedPages] = true;
        $renderedDocuments++;
    }
}

foreach (['BMR' => [3, 4], 'BPR' => [8, 9, 10]] as $formType => $expectedCounts) {
    $actualCounts = array_map(
        'intval',
        array_keys($renderedPageCounts[$formType] ?? [])
    );
    sort($actualCounts);
    if ($actualCounts !== $expectedCounts) {
        $failures[] = "{$formType}: expected source pagination variants "
            . implode(', ', $expectedCounts) . '; found ' . implode(', ', $actualCounts);
    }
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Microbiology structured BMR/BPR smoke test passed for {$renderedDocuments} distinct product documents." . PHP_EOL;
