'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const footer = fs.readFileSync(path.join(__dirname, '../layout/footer1.php'), 'utf8');
const script = footer.match(/<script id="production-workflow-csrf">([\s\S]*?)<\/script>/);
assert.ok(script, 'The shared production CSRF client is missing.');
let prefilter;
vm.runInNewContext(script[1], {
    URL,
    URLSearchParams,
    FormData,
    document: { baseURI: 'https://workflow.test/admin/index.php', querySelector: () => ({ content: 'test-csrf' }) },
    window: { location: { origin: 'https://workflow.test' } },
    $: {
        ajaxPrefilter: callback => { prefilter = callback; },
        param: values => new URLSearchParams(values).toString(),
    },
});

const encoded = { type: 'POST', url: 'ajax.php', data: 'issueBomItems=1' };
prefilter(encoded);
assert.equal(new URLSearchParams(encoded.data).get('csrf_token'), 'test-csrf');
assert.equal(new URLSearchParams(encoded.data).get('issueBomItems'), '1');

const multipart = { type: 'POST', url: 'ajax.php', data: new FormData() };
multipart.data.set('addProductionPlan', '1');
prefilter(multipart);
assert.equal(multipart.data.get('csrf_token'), 'test-csrf');
assert.equal(multipart.data.get('addProductionPlan'), '1');

const existing = { type: 'POST', url: 'ajax.php', data: 'csrf_token=original' };
prefilter(existing);
assert.equal(new URLSearchParams(existing.data).get('csrf_token'), 'original');

const objectData = { type: 'POST', url: 'ajax.php', data: { acceptProductionPlan: 1 } };
prefilter(objectData);
assert.equal(new URLSearchParams(objectData.data).get('csrf_token'), 'test-csrf');

for (const request of [
    { type: 'GET', url: 'ajax.php', data: 'page=1' },
    { type: 'POST', url: 'https://external.test/admin/ajax.php', data: 'value=1' },
    { type: 'POST', url: 'other.php', data: 'value=1' },
    { type: 'POST', url: 'ajax.php', contentType: 'application/json', data: '{"value":1}' },
]) {
    const original = request.data;
    prefilter(request);
    assert.equal(request.data, original, 'CSRF handling changed an unrelated request.');
}

for (const [page, pattern] of [
    ['goods-issuance.php', /<button\b[^>]*id="openManualBomIssuanceBtn"/],
    ['material-requisition.php', /<button\b[^>]*id="addMaterialRquisitionModalBtn"/],
    ['transfer-ticket.php', /<button\b[^>]*data-bs-target="#addTransferTicketModal"/],
]) {
    assert.doesNotMatch(fs.readFileSync(path.join(__dirname, '../pages', page), 'utf8'), pattern,
        'A standalone legacy workflow button is still exposed.');
}

const productionPage = fs.readFileSync(path.join(__dirname, '../pages/production-plan.php'), 'utf8');
assert.match(productionPage, /id="productionPlanReviewForm"/);
assert.match(productionPage, /plan_date: \$\('#productionPlanReviewDate'\)\.val\(\)/);
assert.doesNotMatch(productionPage, /escapeNewProductionPlanText\(plan\.order_number/);
for (const page of ['production-plan.php', 'material-requisition.php', 'goods-issuance.php', 'bmr-bpr-issuance.php']) {
    const source = fs.readFileSync(path.join(__dirname, '../pages', page), 'utf8');
    assert.match(source, /production_plan_no/, 'A handoff screen does not display the plan number.');
    for (const match of source.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
        const javascript = match[1].replace(/<\?(?:php|=)[\s\S]*?\?>/g, 'null');
        new vm.Script(javascript, { filename: page });
    }
}
const issuancePage = fs.readFileSync(path.join(__dirname, '../pages/bmr-bpr-issuance.php'), 'utf8');
assert.match(issuancePage, /request\.issued_materials/);
assert.match(issuancePage, /id="bmrBprReviewMaterials"/);

for (const type of ['Ip', 'Fg']) {
    const prefix = type.toLowerCase();
    const source = fs.readFileSync(path.join(__dirname, `../pages/${prefix}-coa-generation.php`), 'utf8');
    const functionName = `loadMapped${type}CoaTemplate`;
    const loader = source.match(new RegExp(`    function ${functionName}\\(record[^)]*\\) \\{[\\s\\S]*?^    \\}`, 'm'));
    assert.ok(loader, `${type} COA template loader is missing.`);
    const elements = new Map();
    const requests = [];
    const errors = [];
    const jquery = selector => {
        if (!elements.has(selector)) elements.set(selector, {});
        const state = elements.get(selector);
        return {
            val(value) { if (value === undefined) return state.value || ''; state.value = value; return this; },
            text(value) { state.text = value; return this; },
            html(value) { state.html = value; return this; },
            prop(name, value) { state[name] = value; return this; },
            removeClass() { return this; },
            addClass() { return this; },
            empty() { state.text = ''; state.html = ''; return this; },
        };
    };
    jquery.ajax = request => requests.push(request);
    const context = {
        $: jquery,
        toastr: { error: message => errors.push(message) },
        [`current${type}CoaRecord`]: null,
        [`${prefix}CoaTemplateRequestToken`]: 0,
        [`active${type}CoaTemplate`]: null,
        [`${prefix}CoaWorkflowCsrf`]: 'test-csrf',
        [`reset${type}CoaTemplatePanel`]: () => { context[`${prefix}CoaTemplateRequestToken`]++; },
        [`sync${type}CoaTemplateSources`]: () => {},
        [`render${type}CoaTemplatePicker`]: (record, availableTemplates) => {
            elements.get(`#${prefix}CoaTemplateDocument`).text = 'Mapping required.';
        },
        [`setup${type}CoaHeaderTemplateSwitch`]: () => {},
    };
    vm.createContext(context);
    vm.runInContext(loader[0], context);
    const load = () => context[functionName]({ id: 1, product_name: 'Synthetic product' });
    const buttonState = () => elements.get(`#add${type}CoaGenerateForm button[type="submit"]`);
    load();
    assert.equal(buttonState().disabled, true, 'Submitting during template loading must be blocked.');
    requests.at(-1).success({ status: 'success', data: { has_template: false, message: 'Mapping required.' } });
    assert.equal(buttonState().disabled, true, 'A missing template must keep submission blocked.');
    assert.equal(elements.get(`#${prefix}CoaTemplateDocument`).text, 'Mapping required.');
    load();
    requests.at(-1).error({ responseJSON: { message: 'Template unavailable.' } });
    assert.equal(buttonState().disabled, true, 'A failed template request must keep submission blocked.');
    assert.equal(errors.at(-1), 'Template unavailable.');
    load();
    const staleRequest = requests.at(-1);
    load();
    const mappedResponse = { status: 'success', data: { has_template: true, template_id: 1, rendered_html: '<input>' } };
    staleRequest.success(mappedResponse);
    assert.equal(buttonState().disabled, true, 'A stale response must not enable submission.');
    requests.at(-1).success(mappedResponse);
    assert.equal(buttonState().disabled, false, 'The loaded template must enable submission.');
}

console.log('PASS: protected production forms, reviewed plan submission, linked entry points and handoff scripts.');
console.log('PASS: IP/FG template loading, missing mappings, failed requests and stale response handling.');

if (process.argv.includes('--serve') || process.argv.includes('--check-fixtures')) {
    const http = require('node:http');
    const { spawnSync } = require('node:child_process');
    const root = path.resolve(__dirname, '../..');
    const fixturePages = ['production-plan', 'material-requisition', 'goods-issuance', 'bmr-bpr-issuance', 'bmr-bpr-form-request', 'production-bmr-bpr', 'ip-coa-generation', 'fg-coa-generation', 'transfer-ticket'];
    const phpString = value => "'" + value.replaceAll('\\', '/').replaceAll("'", "\\'") + "'";
    const styles = ['assets/vendor/css/rtl/core.css', 'assets/vendor/css/rtl/theme-default.css', 'assets/vendor/fonts/tabler-icons.css', 'assets/css/tailwind.css', 'assets/css/theme.css', 'assets/vendor/libs/select2/select2.css', 'assets/vendor/libs/toastr/toastr.css'];
    const scripts = ['assets/vendor/libs/jquery/jquery.js', 'assets/vendor/libs/popper/popper.js', 'assets/vendor/js/bootstrap.js', 'assets/vendor/libs/select2/select2.js', 'assets/vendor/libs/toastr/toastr.js', 'assets/vendor/libs/sweetalert2/sweetalert2.js', 'assets/vendor/libs/bootstrap-select/bootstrap-select.js'];
    const renderFixture = pageName => {
        const php = `$_SESSION = ['user_id' => 1, 'role_id' => 1, 'csrf_token' => 'test-csrf'];
            $conn = new class { function query($sql) { if (!preg_match('/^\\s*SELECT\\b/i', $sql)) { throw new RuntimeException('Fixture attempted a non-read query.'); } return false; } };
            $pageTitle = 'Production Workflow Preview';
            register_shutdown_function(static function () { foreach (get_included_files() as $included) { if (basename($included) === 'db.php') { fwrite(STDERR, 'Fixture attempted to load database configuration.'); exit(1); } } });
            define('APP_URL', '');
            function roleHasPermission(...$arguments) { return true; }
            function checkPermission(...$arguments) { return true; }
            function startSection(...$arguments) {}
            function endSection(...$arguments) {}
            function getPaginationFooter(...$arguments) { return ''; }
            function asset($asset) { return '/' . ltrim($asset, '/'); }
            function fetch_table_records(...$arguments) { return []; }
            require ${phpString(path.join(root, 'admin/constant.php'))};
            include ${phpString(path.join(root, 'admin/pages', pageName + '.php'))};`;
        return spawnSync('php', ['-d', 'display_errors=0', '-r', php], { cwd: root, encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 });
    };
    if (process.argv.includes('--check-fixtures')) {
        for (const pageName of fixturePages) {
            const rendered = renderFixture(pageName);
            assert.equal(rendered.status, 0, pageName + ': ' + rendered.stderr);
            assert.ok(rendered.stdout.includes('<'), 'Fixture output is blank.');
            assert.ok(!rendered.stdout.includes('Application configuration error'), 'Fixture reached the application database bootstrap.');
            for (const match of rendered.stdout.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
                new vm.Script(match[1], { filename: pageName });
            }
        }
        console.log(`PASS: all ${fixturePages.length} isolated workflow fixtures render and compile without a database.`);
        process.exit(0);
    }
    const server = http.createServer((request, response) => {
        const url = new URL(request.url, 'http://127.0.0.1');
        if (url.pathname.startsWith('/assets/') && request.method === 'GET') {
            const assetPath = path.resolve(root, '.' + decodeURIComponent(url.pathname));
            if (!assetPath.startsWith(path.join(root, 'assets') + path.sep) || !fs.existsSync(assetPath) || !fs.statSync(assetPath).isFile()) {
                response.writeHead(404).end();
                return;
            }
            const types = { '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.svg': 'image/svg+xml' };
            response.writeHead(200, { 'Content-Type': types[path.extname(assetPath)] || 'application/octet-stream' });
            fs.createReadStream(assetPath).pipe(response);
            return;
        }
        if (url.pathname.endsWith('/ajax.php')) {
            response.writeHead(200, { 'Content-Type': 'application/json' });
            response.end(JSON.stringify({ status: 'error', message: 'Synthetic preview: no database writes are supported.' }));
            return;
        }
        const pageName = url.searchParams.get('page') || 'production-plan';
        if (!fixturePages.includes(pageName)) {
            response.writeHead(404).end();
            return;
        }
        const rendered = renderFixture(pageName);
        if (rendered.status !== 0) {
            response.writeHead(500, { 'Content-Type': 'text/plain' }).end('Unable to render the isolated fixture.');
            console.error('Fixture rendering failed for ' + pageName + ': ' + rendered.stderr);
            return;
        }
        const clientSetup = `const APP_CONST = { PRODUCTION_PLAN: { STATUS: {}, TIMELINE: {} } }; function updateSerialNumbers() {}`;
        const html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="test-csrf"><title>Workflow Test Preview</title>'
            + styles.map(asset => `<link rel="stylesheet" href="/${asset}">`).join('')
            + scripts.map(asset => `<script src="/${asset}"></script>`).join('')
            + `<script>${clientSetup}</script><script>${script[1]}</script></head><body>`
            + rendered.stdout + '</body></html>';
        response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        response.end(html);
    });
    const port = Number(process.env.WORKFLOW_PREVIEW_PORT || 8096);
    server.listen(port, '127.0.0.1', () => console.log(`Synthetic workflow preview: http://127.0.0.1:${port}/admin/index.php?page=production-plan`));
}