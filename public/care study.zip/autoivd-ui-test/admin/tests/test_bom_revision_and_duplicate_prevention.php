<?php
/**
 * Automated Verification Script: BOM Revision & Duplicate Prevention
 *
 * Tests:
 * 1. Initial submission of BOM for approval creates single PENDING_APPROVAL record.
 * 2. getReferenceBoms detects existing PENDING_APPROVAL record and returns pending_bom with items.
 * 3. Re-submission with revised items updates existing BOM without creating duplicate in bom_master.
 * 4. Audit trail correctly logs revision and re-submission.
 * 5. Cleanup test data.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';

echo "======================================================================\n";
echo "       BOM REVISION & DUPLICATE PREVENTION VERIFICATION               \n";
echo "======================================================================\n\n";

$passCount = 0;
$failCount = 0;

$runTest = function (string $name, callable $fn) use (&$passCount, &$failCount) {
    echo "TEST: $name ... ";
    try {
        $result = $fn();
        if ($result === true || $result === null) {
            echo "[PASSED]\n";
            $passCount++;
        } else {
            echo "[FAILED]: $result\n";
            $failCount++;
        }
    } catch (Throwable $e) {
        echo "[ERROR]: " . $e->getMessage() . "\n";
        $failCount++;
    }
};

// 1. Pick a reference product/BOM
$refBomRes = $conn->query("SELECT bm.id, bm.finished_product_id, bm.category_id, p.product_name 
    FROM bom_master bm 
    JOIN products p ON p.id = bm.finished_product_id 
    WHERE bm.status = 1 AND bm.bom_status = 'APPROVED' 
    ORDER BY bm.id ASC LIMIT 1");
$refBom = $refBomRes->fetch_assoc();
$sourceBomId = (int)$refBom['id'];
$sourceCatId = (int)$refBom['category_id'];

// 2. Pick a target product without BOM
$targetRes = $conn->query("SELECT p.id, p.product_name, p.category_id 
    FROM products p 
    WHERE p.id NOT IN (SELECT finished_product_id FROM bom_master WHERE status = 1 AND deleted_at IS NULL)
      AND p.status = 1 
    LIMIT 1");
$targetProd = $targetRes->fetch_assoc();
if (!$targetProd) {
    echo "No target product without BOM found for test.\n";
    exit(1);
}

$targetProductId = (int)$targetProd['id'];
$targetCatId = (int)($targetProd['category_id'] ?? $sourceCatId);

echo "Target Product: #$targetProductId ({$targetProd['product_name']})\n\n";

$testBomId = 0;

// Test 1: Submit initial BOM for approval
$runTest("1. Submit Initial BOM for Approval", function () use ($conn, $targetProductId, $targetCatId, $sourceBomId, &$testBomId) {
    // Pick 2 raw items from source BOM
    $rawRes = $conn->query("SELECT raw_product_category_id, raw_product_id, qty_unit_id, qty_per_unit FROM bom_items WHERE bom_id = $sourceBomId AND status = 1 LIMIT 2");
    $items = [];
    while ($r = $rawRes->fetch_assoc()) {
        $items[] = [
            'raw_product_category_id' => (int)$r['raw_product_category_id'],
            'raw_product_id' => (int)$r['raw_product_id'],
            'qty_unit_id' => (int)$r['qty_unit_id'],
            'qty_per_unit' => 1.5
        ];
    }

    if (empty($items)) {
        return "Source BOM has no active items";
    }

    $bomName = "TEST REVISION BOM - " . date('YmdHis');
    $conn->begin_transaction();
    $insertMaster = $conn->prepare("INSERT INTO `bom_master`
        (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `source_bom_id`, `created_by`, `created_at`)
        VALUES (?, ?, ?, 4, 'Initial submission', 1, 'PENDING_APPROVAL', 'CLONED', ?, 1, NOW())");
    $insertMaster->bind_param("siii", $bomName, $targetCatId, $targetProductId, $sourceBomId);
    $insertMaster->execute();
    $testBomId = $conn->insert_id;
    $insertMaster->close();

    $insertItem = $conn->prepare("INSERT INTO `bom_items`
        (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
        VALUES (?, ?, ?, ?, ?, 1, 1, NOW())");
    foreach ($items as $it) {
        $insertItem->bind_param("iiiid", $testBomId, $it['raw_product_category_id'], $it['raw_product_id'], $it['qty_unit_id'], $it['qty_per_unit']);
        $insertItem->execute();
    }
    $insertItem->close();

    logBomApprovalHistory($conn, $testBomId, 'SUBMITTED', null, 'PENDING_APPROVAL', 'Initial submission for test', 1);
    $conn->commit();

    echo "(Created BOM #$testBomId) ";
    return true;
});

// Test 2: Verify getReferenceBoms query detects pending BOM
$runTest("2. Detect Pending BOM in getReferenceBoms query", function () use ($conn, $targetProductId, $testBomId) {
    $pendingStmt = $conn->prepare("SELECT bm.id, bm.name, bm.category_id, bm.finished_product_id, bm.bom_type, bm.descriptions,
               bm.source_type, bm.source_bom_id, bm.bom_status, bm.created_at, bm.created_by,
               u.name AS creator_name
        FROM bom_master bm
        LEFT JOIN users u ON u.id = bm.created_by
        WHERE bm.finished_product_id = ? AND bm.status = 1 AND bm.bom_status = 'PENDING_APPROVAL' AND bm.deleted_at IS NULL
        ORDER BY bm.id DESC LIMIT 1");
    $pendingStmt->bind_param('i', $targetProductId);
    $pendingStmt->execute();
    $pendingBom = $pendingStmt->get_result()->fetch_assoc();
    $pendingStmt->close();

    if (!$pendingBom) {
        return "Failed to detect pending BOM";
    }
    if ((int)$pendingBom['id'] !== $testBomId) {
        return "Detected BOM ID mismatch: expected $testBomId, got " . $pendingBom['id'];
    }

    // Fetch items
    $pItemsStmt = $conn->prepare("SELECT bi.id, bi.qty_per_unit FROM bom_items bi WHERE bi.bom_id = ? AND bi.status != 3 AND bi.deleted_at IS NULL");
    $pItemsStmt->bind_param('i', $testBomId);
    $pItemsStmt->execute();
    $items = $pItemsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $pItemsStmt->close();

    if (count($items) !== 2) {
        return "Expected 2 items in pending BOM, found " . count($items);
    }
    echo "(Pending BOM #$testBomId found with " . count($items) . " items) ";
    return true;
});

// Test 3: Re-submit with revised quantity and ensure NO duplicate bom_master record
$runTest("3. Re-submit BOM and verify NO duplicate in bom_master", function () use ($conn, $targetProductId, $testBomId, $sourceBomId) {
    $preCountRes = $conn->query("SELECT COUNT(*) FROM bom_master WHERE finished_product_id = $targetProductId AND status = 1 AND deleted_at IS NULL");
    $preCount = (int)$preCountRes->fetch_row()[0];

    // Revised item with new quantity
    $rawRes = $conn->query("SELECT raw_product_category_id, raw_product_id, qty_unit_id FROM bom_items WHERE bom_id = $sourceBomId AND status = 1 LIMIT 1");
    $r = $rawRes->fetch_assoc();
    $revisedItems = [
        [
            'raw_product_category_id' => (int)$r['raw_product_category_id'],
            'raw_product_id' => (int)$r['raw_product_id'],
            'qty_unit_id' => (int)$r['qty_unit_id'],
            'qty_per_unit' => 9.99
        ]
    ];

    // Simulate update in submitBomForApproval
    $conn->begin_transaction();
    $upMaster = $conn->prepare("UPDATE `bom_master` SET
        `name` = 'REVISED BOM NAME', `descriptions` = 'Revised formulation',
        `updated_by` = 1, `updated_at` = NOW()
        WHERE id = ?");
    $upMaster->bind_param("i", $testBomId);
    $upMaster->execute();
    $upMaster->close();

    // Soft delete previous components
    $delItems = $conn->prepare("UPDATE `bom_items` SET `status` = 3, `deleted_at` = NOW() WHERE `bom_id` = ? AND `status` != 3 AND `deleted_at` IS NULL");
    $delItems->bind_param("i", $testBomId);
    $delItems->execute();
    $delItems->close();

    // Insert revised component
    $insertItem = $conn->prepare("INSERT INTO `bom_items`
        (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
        VALUES (?, ?, ?, ?, ?, 1, 1, NOW())");
    foreach ($revisedItems as $it) {
        $insertItem->bind_param("iiiid", $testBomId, $it['raw_product_category_id'], $it['raw_product_id'], $it['qty_unit_id'], $it['qty_per_unit']);
        $insertItem->execute();
    }
    $insertItem->close();

    logBomApprovalHistory($conn, $testBomId, 'SUBMITTED', 'PENDING_APPROVAL', 'PENDING_APPROVAL', "Revised components and re-submitted for approval", 1);
    $conn->commit();

    // Check count after re-submission
    $postCountRes = $conn->query("SELECT COUNT(*) FROM bom_master WHERE finished_product_id = $targetProductId AND status = 1 AND deleted_at IS NULL");
    $postCount = (int)$postCountRes->fetch_row()[0];

    if ($postCount !== $preCount || $postCount !== 1) {
        return "Duplicate record created! Pre-count was $preCount, post-count is $postCount";
    }

    // Check that active item has new quantity 9.99
    $activeItemRes = $conn->query("SELECT qty_per_unit FROM bom_items WHERE bom_id = $testBomId AND status = 1 AND deleted_at IS NULL");
    $activeItems = $activeItemRes->fetch_all(MYSQLI_ASSOC);
    if (count($activeItems) !== 1 || (float)$activeItems[0]['qty_per_unit'] !== 9.99) {
        return "Revised item quantity mismatch";
    }

    echo "(Total active BOM count for product remains $postCount, revised qty = 9.99) ";
    return true;
});

// Test 4: Verify audit log shows revision
$runTest("4. Verify Audit Trail contains Revision Log", function () use ($conn, $testBomId) {
    $res = $conn->query("SELECT action, comments FROM bom_approval_history WHERE bom_master_id = $testBomId ORDER BY id DESC LIMIT 1");
    $latest = $res->fetch_assoc();
    if (!$latest || strpos($latest['comments'], 'Revised components') === false) {
        return "Audit log does not show revision entry";
    }
    echo "(Audit note: \"{$latest['comments']}\") ";
    return true;
});

// Test 5: Cleanup test records
$runTest("5. Cleanup Test Records", function () use ($conn, $testBomId) {
    $conn->query("DELETE FROM bom_items WHERE bom_id = $testBomId");
    $conn->query("DELETE FROM bom_approval_history WHERE bom_master_id = $testBomId");
    $conn->query("DELETE FROM bom_master WHERE id = $testBomId");
    return true;
});

echo "\n======================================================================\n";
echo "SUMMARY: Passed: $passCount, Failed: $failCount\n";
echo "======================================================================\n";
