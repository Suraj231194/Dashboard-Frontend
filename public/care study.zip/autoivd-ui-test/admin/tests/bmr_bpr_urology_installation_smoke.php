<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../workflow/bmr_bpr_common.php';

$assert = static function (bool $condition, string $message): void {
    if (!$condition) {
        throw new RuntimeException($message);
    }
};

$standardBmrProductIds = [1047, 1048, 1049, 1050, 1051, 1052, 1342, 1466, 1705, 1787];
$twoComponentProductIds = [1422, 1863];
$expectedProductIds = array_values(array_unique(array_merge(
    $standardBmrProductIds,
    $twoComponentProductIds
)));
sort($expectedProductIds);
$templateCodes = [
    'COMMON_UROLOGY_BMR_V03',
    'COMMON_UROLOGY_GLUCOSE_UNCUT_BMR_V03',
    'COMMON_UROLOGY_PROTEIN_UNCUT_BMR_V03',
    'COMMON_UROLOGY_BPR_V03',
];

$templateResult = $conn->query(
    "SELECT id, form_type, template_code, source_pdf_path, page_asset_path, layout_json
     FROM bmr_templates
     WHERE template_code IN (
         'COMMON_UROLOGY_BMR_V03',
         'COMMON_UROLOGY_GLUCOSE_UNCUT_BMR_V03',
         'COMMON_UROLOGY_PROTEIN_UNCUT_BMR_V03',
         'COMMON_UROLOGY_BPR_V03'
     )
       AND status = 1
       AND deleted_at IS NULL
     ORDER BY template_code"
);
$assert($templateResult !== false, 'Unable to query the installed Urology templates.');
$templates = $templateResult->fetch_all(MYSQLI_ASSOC);
$assert(count($templates) === 4, 'All four Urology templates are not active.');

$templateIdsByCode = [];
foreach ($templates as $template) {
    $layout = json_decode((string) $template['layout_json'], true);
    $assert(
        $template['source_pdf_path'] === null && $template['page_asset_path'] === null,
        "{$template['template_code']} has a runtime PDF or image dependency."
    );
    $assert(
        is_array($layout)
            && ($layout['renderer'] ?? '') === 'structured_html'
            && ($layout['renderer_variant'] ?? '') === 'urology',
        "{$template['template_code']} is not using the Urology code renderer."
    );
    $templateIdsByCode[(string) $template['template_code']] = (int) $template['id'];
}
sort($templateCodes);
$actualTemplateCodes = array_keys($templateIdsByCode);
sort($actualTemplateCodes);
$assert($actualTemplateCodes === $templateCodes, 'The active Urology template code set is incorrect.');

$mappingResult = $conn->query(
    "SELECT
        mapping.product_id,
        mapping.form_type,
        mapping.document_sequence,
        template.template_code
     FROM bmr_template_product_mappings mapping
     INNER JOIN bmr_templates template
        ON template.id = mapping.template_id
       AND template.template_code LIKE 'COMMON_UROLOGY_%'
       AND template.status = 1
       AND template.deleted_at IS NULL
     WHERE mapping.status = 1
       AND mapping.deleted_at IS NULL
     ORDER BY mapping.product_id, mapping.form_type, mapping.document_sequence"
);
$assert($mappingResult !== false, 'Unable to query the Urology mappings.');
$mappings = $mappingResult->fetch_all(MYSQLI_ASSOC);
$assert(count($mappings) === 26, 'The installed Urology mapping count is not 26.');

$actualMappingKeys = [];
foreach ($mappings as $mapping) {
    $productId = (int) $mapping['product_id'];
    $formType = strtoupper((string) $mapping['form_type']);
    $sequence = (int) $mapping['document_sequence'];
    $templateCode = (string) $mapping['template_code'];
    $expectedCode = $formType === 'BPR'
        ? 'COMMON_UROLOGY_BPR_V03'
        : 'COMMON_UROLOGY_BMR_V03';
    if ($formType === 'BMR' && in_array($productId, $twoComponentProductIds, true)) {
        $expectedCode = $sequence === 1
            ? 'COMMON_UROLOGY_GLUCOSE_UNCUT_BMR_V03'
            : 'COMMON_UROLOGY_PROTEIN_UNCUT_BMR_V03';
    }
    $assert(
        $templateCode === $expectedCode,
        "Urology product {$productId} {$formType} #{$sequence} is mapped incorrectly."
    );
    $actualMappingKeys[] = "{$productId}:{$formType}:{$sequence}";
}

$expectedMappingKeys = [];
foreach ($expectedProductIds as $productId) {
    $bmrCount = in_array($productId, $twoComponentProductIds, true) ? 2 : 1;
    for ($sequence = 1; $sequence <= $bmrCount; $sequence++) {
        $expectedMappingKeys[] = "{$productId}:BMR:{$sequence}";
    }
    $expectedMappingKeys[] = "{$productId}:BPR:1";
}
sort($actualMappingKeys);
sort($expectedMappingKeys);
$assert($actualMappingKeys === $expectedMappingKeys, 'The Urology product-document map is incomplete.');

$demoResult = $conn->query(
    "SELECT
        request_row.id AS request_id,
        request_row.product_id,
        work_item.form_type,
        work_item.form_sequence,
        work_item.status,
        work_item.form_payload_json,
        template.template_code
     FROM material_requisition source_mr
     INNER JOIN bmr_bpr_requests request_row
        ON request_row.material_requisition_id = source_mr.id
       AND request_row.deleted_at IS NULL
     INNER JOIN bmr_bpr_work_items work_item
        ON work_item.request_id = request_row.id
       AND work_item.deleted_at IS NULL
     INNER JOIN bmr_templates template
        ON template.id = work_item.template_id
       AND template.deleted_at IS NULL
     WHERE source_mr.slip_no LIKE 'BMR-COMMON-UROLOGY-DEMO-%'
       AND source_mr.deleted_at IS NULL
     ORDER BY request_row.product_id, work_item.form_type, work_item.form_sequence"
);
$assert($demoResult !== false, 'Unable to query the Urology demo records.');
$demoRows = $demoResult->fetch_all(MYSQLI_ASSOC);
$assert(count($demoRows) === 26, 'The Urology demo work-item count is not 26.');

$demoProductIds = [];
$demoRequestIds = [];
$demoCounts = ['BMR' => 0, 'BPR' => 0];
foreach ($demoRows as $row) {
    $productId = (int) $row['product_id'];
    $formType = strtoupper((string) $row['form_type']);
    $formSequence = (int) $row['form_sequence'];
    $expectedStatus = $formType === 'BMR' ? 'IN_PROCESS' : 'PENDING';
    $expectedCode = $formType === 'BPR'
        ? 'COMMON_UROLOGY_BPR_V03'
        : 'COMMON_UROLOGY_BMR_V03';
    if ($formType === 'BMR' && in_array($productId, $twoComponentProductIds, true)) {
        $expectedCode = $formSequence === 1
            ? 'COMMON_UROLOGY_GLUCOSE_UNCUT_BMR_V03'
            : 'COMMON_UROLOGY_PROTEIN_UNCUT_BMR_V03';
    }
    $assert(
        strtoupper((string) $row['status']) === $expectedStatus,
        "A Urology {$formType} demo record has the wrong status."
    );
    $assert(
        (string) $row['template_code'] === $expectedCode,
        "A Urology {$formType} demo record has the wrong template."
    );
    $assert(
        $row['form_payload_json'] === null,
        "A Urology {$formType} demo record contains preloaded saved form data."
    );
    $demoProductIds[$productId] = true;
    $demoRequestIds[(int) $row['request_id']] = true;
    $demoCounts[$formType]++;
}
$actualDemoProductIds = array_map('intval', array_keys($demoProductIds));
sort($actualDemoProductIds);
$assert($actualDemoProductIds === $expectedProductIds, 'The Urology demo product set is incorrect.');
$assert(count($demoRequestIds) === 12, 'The Urology demo request count is not 12.');
$assert(
    $demoCounts === ['BMR' => 14, 'BPR' => 12],
    'The Urology demo document split is not 14 BMR and 12 BPR.'
);

$incomingCounts = ['BMR' => 0, 'BPR' => 0];
foreach (bmrBprProductionRows($conn) as $row) {
    if (!in_array((int) ($row['product_id'] ?? 0), $expectedProductIds, true)) {
        continue;
    }
    if (strpos((string) ($row['template_code'] ?? ''), 'COMMON_UROLOGY_') !== 0) {
        continue;
    }
    $isDemoBmrPreview = !empty($row['is_common_template_demo'])
        && $row['form_type'] === 'BMR'
        && $row['status_code'] === 'IN_PROCESS';
    if (
        (
            in_array($row['status_code'], ['QUEUED', 'PENDING'], true)
            || $isDemoBmrPreview
        )
        && !empty($row['can_open'])
    ) {
        $incomingCounts[$row['form_type']]++;
    }
}
$assert(
    $incomingCounts === ['BMR' => 14, 'BPR' => 12],
    'The Urology Incoming BMR/BPR classification is not 14 and 12.'
);

echo "Urology installation smoke test passed: 4 templates, 26 mappings, "
    . "12 requests, 14 BMR demos and 12 BPR demos.\n";
