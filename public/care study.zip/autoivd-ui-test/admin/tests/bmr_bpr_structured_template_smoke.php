<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/workflow/bmr_bpr_structured_renderer.php';
require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

$schemaRoot = dirname(__DIR__, 2) . '/assets/bmr-bpr-schemas';
$schemaFiles = [
    $schemaRoot . '/common-hematology-bmr-v3.json',
    $schemaRoot . '/common-hematology-bpr-v3.json',
];
$brandingLogoPath = dirname(__DIR__, 2) . '/assets/img/logo3.jpeg';
$brandingLogo = is_file($brandingLogoPath)
    ? (string) file_get_contents($brandingLogoPath)
    : '';
$brandingLogoDataUri = $brandingLogo === ''
    ? ''
    : 'data:image/jpeg;base64,' . base64_encode($brandingLogo);

$failures = [];
$renderedDocuments = 0;

foreach ($schemaFiles as $schemaFile) {
    $layout = json_decode((string) file_get_contents($schemaFile), true);
    if (!is_array($layout) || !bmrBprIsStructuredLayout($layout)) {
        $failures[] = basename($schemaFile) . ': invalid structured schema';
        continue;
    }

    foreach (($layout['profiles'] ?? []) as $productId => $profile) {
        $expectedPages = (int) ($profile['page_count'] ?? 0);
        $form = [
            'form_type' => (string) $layout['form_type'],
            'layout' => $layout,
            'profile' => $profile,
            'branding_logo_data_uri' => $brandingLogoDataUri,
            'source_values' => [
                'product_name' => (string) ($profile['product_name'] ?? ''),
                'batch_number' => 'SMOKE-BATCH-001',
                'batch_size' => (string) ($profile['standard_batch'] ?? ''),
                'pack_size' => (string) ($profile['pack_size'] ?? ''),
                'record_number' => (string) $layout['form_type'] . '/SMOKE/000001-01',
            ],
            'form_payload' => [
                'schema_version' => 2,
                'fields' => [
                    'cover.mfg_date' => '28/07/2026',
                    'qa.decision_remarks' => 'Smoke test',
                ],
            ],
        ];

        $html = bmrBprRenderStructuredTemplate($form, true);
        $pageCount = substr_count($html, 'class="bmr-v2-page"');
        if ($pageCount !== $expectedPages) {
            $failures[] = "{$layout['form_type']} product {$productId}: expected {$expectedPages} HTML pages, found {$pageCount}";
        }
        $imageCount = substr_count($html, '<img ');
        $logoCount = substr_count($html, 'class="bmr-v2-brand-logo"');
        if (
            stripos($html, 'source.pdf') !== false
            || $imageCount !== $expectedPages
            || $logoCount !== $expectedPages
        ) {
            $failures[] = "{$layout['form_type']} product {$productId}: renderer contains product artwork or is missing the shared company logo";
        }
        if (stripos($html, 'data-bmr-field="cover.mfg_date"') === false) {
            $failures[] = "{$layout['form_type']} product {$productId}: editable semantic field missing";
        }

        $printHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
            . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}</style>'
            . '</head><body>'
            . bmrBprRenderStructuredTemplate($form, false)
            . '</body></html>';
        $options = new Dompdf\Options();
        $options->set('isRemoteEnabled', false);
        $options->set('defaultFont', 'Helvetica');
        $dompdf = new Dompdf\Dompdf($options);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->loadHtml($printHtml, 'UTF-8');
        $dompdf->render();
        $pdf = $dompdf->output();
        if (!str_starts_with($pdf, '%PDF-')) {
            $failures[] = "{$layout['form_type']} product {$productId}: Dompdf output is invalid";
        }
        $actualPdfPages = (int) $dompdf->getCanvas()->get_page_count();
        if ($actualPdfPages !== $expectedPages) {
            $failures[] = "{$layout['form_type']} product {$productId}: expected {$expectedPages} PDF pages, found {$actualPdfPages}";
        }
        $renderedDocuments++;
    }
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Structured BMR/BPR smoke test passed for {$renderedDocuments} product documents." . PHP_EOL;
