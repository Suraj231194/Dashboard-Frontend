<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

$failures = [];
$actions = file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_actions.php');
$page = file_get_contents(dirname(__DIR__) . '/pages/production-bmr-bpr.php');
if (
    $actions === false
    || !str_contains($actions, '$isWaitingRapidBpr')
    || !str_contains($actions, "'COMMON_RAPID_BPR_'")
    || !str_contains($actions, '($row[\'can_open\'] || $isWaitingRapidBpr)')
) {
    $failures[] = 'Pending gated Rapid BPR rows are not included in the incoming API list.';
}
if (
    $page === false
    || !str_contains($page, 'Waiting for BMR')
    || !str_contains($page, 'Waiting for IP COA')
    || !str_contains($page, 'Complete every related BMR')
    || !str_contains($page, 'const canOpen = Boolean(record.can_open);')
) {
    $failures[] = 'The disabled BMR/IP-COA gate action is missing from the incoming UI.';
}
if (
    $actions === false
    || !str_contains($actions, 'bmrBprBmrStatusesReady($bmrStatuses)')
    || !str_contains($actions, 'Complete every configured BMR before opening the BPR.')
    || !str_contains($actions, 'An approved In-Process COA is required before opening the BPR.')
) {
    $failures[] = 'The server-side BPR readiness gate was removed.';
}

$rapidPending = 0;
$rapidWaiting = 0;
foreach (bmrBprProductionRows($conn) as $row) {
    if (
        $row['form_type'] !== 'BPR'
        || $row['status_code'] !== 'PENDING'
        || !str_starts_with(
            (string) ($row['template_code'] ?? ''),
            'COMMON_RAPID_BPR_'
        )
    ) {
        continue;
    }
    $rapidPending++;
    if (empty($row['can_open'])) {
        $rapidWaiting++;
    }
}
if ($rapidPending <= 0 || $rapidWaiting <= 0) {
    $failures[] = 'No pending gated Rapid BPR rows are available for the visibility check.';
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "Rapid waiting-BPR smoke test passed: {$rapidPending} pending Rapid BPR rows are visible; "
    . "{$rapidWaiting} remain safely disabled until their BMR and IP COA gates are ready." . PHP_EOL;
