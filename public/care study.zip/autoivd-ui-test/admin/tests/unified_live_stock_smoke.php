<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/constant.php';
require_once dirname(__DIR__) . '/functions.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$checks = [
    'duplicate_products' => 'SELECT COUNT(*) FROM (
        SELECT product_id FROM live_stock GROUP BY product_id HAVING COUNT(*) > 1
    ) duplicates',
    'invalid_quantities' => 'SELECT COUNT(*) FROM live_stock
        WHERE quantity_available < 0 OR reserved_qty < 0 OR reserved_qty > quantity_available',
    'invalid_statuses' => 'SELECT COUNT(*) FROM live_stock WHERE status NOT IN (0, 1)',
    'orphan_balances' => 'SELECT COUNT(*) FROM live_stock stock
        LEFT JOIN products product ON product.id = stock.product_id
        WHERE product.id IS NULL',
    'missing_active_product_balances' => 'SELECT COUNT(*) FROM products product
        LEFT JOIN live_stock stock ON stock.product_id = product.id
        WHERE product.status = 1 AND product.deleted_at IS NULL AND stock.id IS NULL',
    'deleted_product_active_balances' => 'SELECT COUNT(*) FROM live_stock stock
        INNER JOIN products product ON product.id = stock.product_id
        WHERE (product.status = 3 OR product.deleted_at IS NOT NULL)
          AND (stock.status != 0 OR stock.deleted_at IS NULL)',
];

foreach ($checks as $name => $sql) {
    $count = (int) $conn->query($sql)->fetch_row()[0];
    if ($count !== 0) {
        throw new RuntimeException($name . '=' . $count);
    }
}

$candidate = $conn->query(
    'SELECT product_id, unreserved_qty
     FROM live_stock
     WHERE deleted_at IS NULL AND reserved_qty = 0 AND unreserved_qty >= 4
     ORDER BY product_id LIMIT 1'
)->fetch_assoc();
if (!$candidate) {
    throw new RuntimeException('No balance is available for the transactional smoke test.');
}

$productId = (int) $candidate['product_id'];
$before = inventoryGetBalance($conn, $productId);
$conn->begin_transaction();
try {
    inventoryReserveStock($conn, $productId, 2, 1);
    inventoryReleaseStock($conn, $productId, 1, 1);
    inventoryConsumeReservedStock($conn, $productId, 1, 1, 'smoke_test');
    inventoryConsumeUnreservedStock($conn, $productId, 1, 1, 'smoke_test');
    inventoryRestoreStock($conn, $productId, 1, 1, 'smoke_test');

    $after = inventoryGetBalance($conn, $productId, true);
    $expectedTotal = (float) $before['quantity_available'] - 1;
    if (abs((float) $after['quantity_available'] - $expectedTotal) > 0.00000001
        || abs((float) $after['reserved_qty']) > 0.00000001
        || abs((float) $after['unreserved_qty'] - $expectedTotal) > 0.00000001) {
        throw new RuntimeException('Transactional quantity result is inconsistent.');
    }
    $conn->rollback();
} catch (Throwable $e) {
    $conn->rollback();
    throw $e;
}

echo 'Unified live stock smoke test passed for product ' . $productId . PHP_EOL;
