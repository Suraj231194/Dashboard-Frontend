<?php

declare(strict_types=1);

define('HRMS_CONTEXT', true);
require_once __DIR__ . '/../hrms/annual_calendar_common.php';

$failures = 0;
$assertSame = static function (mixed $expected, mixed $actual, string $message) use (&$failures): void {
    if ($expected !== $actual) {
        $failures++;
        fwrite(STDERR, "FAIL: {$message}. Expected " . var_export($expected, true) . ', received ' . var_export($actual, true) . PHP_EOL);
    }
};
$assertThrows = static function (callable $callback, string $message) use (&$failures): void {
    try {
        $callback();
    } catch (Throwable) {
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$message}. Expected an exception." . PHP_EOL);
};

// ---- Weekly-off day configuration -------------------------------------------------
$assertSame([7], acParseWeeklyOffDays(null), 'weekly-off default is Sunday');
$assertSame([7], acParseWeeklyOffDays(''), 'empty weekly-off falls back to Sunday');
$assertSame([1, 6, 7], acParseWeeklyOffDays('7,6,1,6,99,0'), 'weekly-off parsing normalizes and de-duplicates');
$assertSame([5, 6], acValidWeeklyOffDays([6, 5, 5]), 'weekly-off validation sorts and de-duplicates');
$assertThrows(static fn() => acValidWeeklyOffDays([1, 2, 3, 4, 5, 6, 7]), 'a fully non-working week is rejected');

$fridayOff = acBuildCalendarDaysFromData(2026, 'all_working', [], [], [5]);
$fridayTotals = acTotalsFromDays($fridayOff);
$assertSame(365, count($fridayOff), 'Friday-off calendar covers the year');
$assertSame(52, $fridayTotals['total_saturday_offs'], 'Friday weekly offs are counted as non-Sunday offs');
$assertSame(0, $fridayTotals['total_sundays'] - 52, 'Sundays are still counted for reporting');
$assertSame(313, $fridayTotals['total_working_days'], 'Friday-off working days exclude only Fridays');

// ---- Restricted holidays are optional and never reduce working days ---------------
$withRestricted = acBuildCalendarDaysFromData(2026, 'all_working', [
    ['holiday_date' => '2026-04-14', 'holiday_name' => 'Dr. Ambedkar Jayanti', 'holiday_type' => 'restricted', 'is_enabled' => 1, 'is_optional' => 1],
    ['holiday_date' => '2026-01-26', 'holiday_name' => 'Republic Day', 'holiday_type' => 'national', 'is_enabled' => 1, 'is_optional' => 0],
]);
$restrictedTotals = acTotalsFromDays($withRestricted);
$assertSame(1, $restrictedTotals['total_holidays'], 'only mandatory holidays reduce working days');
$assertSame(2, $restrictedTotals['total_declared_holidays'], 'declared holidays include optional ones');
$assertSame(1, $restrictedTotals['total_optional_holidays'], 'optional holidays are reported separately');

$april14 = array_values(array_filter($withRestricted, static fn(array $day): bool => $day['calendar_date'] === '2026-04-14'))[0];
$assertSame('working_day', $april14['day_type'], 'a restricted holiday stays a working day');
$assertSame(1, $april14['is_optional_holiday'], 'a restricted holiday is flagged as optional');
$assertSame('Dr. Ambedkar Jayanti', $april14['holiday_names'], 'a restricted holiday keeps its name for display');

// A restricted holiday falling back to type-based inference when the column is absent.
$inferred = acBuildCalendarDaysFromData(2026, 'all_working', [
    ['holiday_date' => '2026-04-03', 'holiday_name' => 'Good Friday', 'holiday_type' => 'restricted', 'is_enabled' => 1],
]);
$assertSame(0, acTotalsFromDays($inferred)['total_holidays'], 'restricted type alone marks a holiday optional');

// ---- Per-date overrides ------------------------------------------------------------
$overridden = acBuildCalendarDaysFromData(
    2026,
    'all_off',
    [['holiday_date' => '2026-01-26', 'holiday_name' => 'Republic Day', 'holiday_type' => 'national', 'is_enabled' => 1]],
    [],
    [7],
    [
        ['override_date' => '2026-01-10', 'override_type' => 'working_day'],
        ['override_date' => '2026-01-13', 'override_type' => 'weekly_off'],
        ['override_date' => '2025-12-25', 'override_type' => 'working_day'],
    ]
);
$byDate = array_column($overridden, null, 'calendar_date');
$assertSame('working_day', $byDate['2026-01-10']['day_type'], 'a Saturday can be forced to a working day');
$assertSame(1, (int) $byDate['2026-01-10']['is_overridden'], 'forced working days are flagged');
$assertSame('weekly_off', $byDate['2026-01-13']['day_type'], 'a Tuesday can be forced to a weekly off');
$assertSame('weekly_off', $byDate['2026-01-04']['day_type'], 'Sundays remain weekly offs without an override');
$assertSame('holiday', $byDate['2026-01-26']['day_type'], 'a Monday holiday is still a holiday');

// An override to weekly_off must win over a holiday so the day is not deducted twice.
$overrideOverHoliday = acBuildCalendarDaysFromData(
    2026,
    'all_working',
    [['holiday_date' => '2026-03-04', 'holiday_name' => 'Holi', 'holiday_type' => 'festival', 'is_enabled' => 1]],
    [],
    [7],
    [['override_date' => '2026-03-04', 'override_type' => 'weekly_off']]
);
$holi = array_column($overrideOverHoliday, null, 'calendar_date')['2026-03-04'];
$assertSame('weekly_off', $holi['day_type'], 'an override to weekly off takes precedence over a holiday');
$assertSame(0, (int) $holi['is_holiday'], 'a holiday on an overridden off day is not double counted');

// ---- Ledger hash --------------------------------------------------------------------
$baseline = acBuildCalendarDaysFromData(2026, '2nd_4th_off', []);
$hash = acCalendarLedgerHash($baseline);
$assertSame(64, strlen($hash), 'the ledger hash is a sha256 digest');
$assertSame($hash, acCalendarLedgerHash($baseline), 'the ledger hash is stable for identical input');

$mutated = $baseline;
$mutated[0]['day_type'] = 'holiday';
if ($hash === acCalendarLedgerHash($mutated)) {
    $failures++;
    fwrite(STDERR, 'FAIL: the ledger hash must change when a day classification changes.' . PHP_EOL);
}

// The hash must also react to an optional-holiday flag change.
$optionalMutated = $baseline;
$optionalMutated[0]['is_optional_holiday'] = 1;
if ($hash === acCalendarLedgerHash($optionalMutated)) {
    $failures++;
    fwrite(STDERR, 'FAIL: the ledger hash must change when the optional-holiday flag changes.' . PHP_EOL);
}

// ---- Validation guards ---------------------------------------------------------------
$assertSame('working_day', acValidOverrideType('working_day'), 'working_day is a valid override type');
$assertSame('weekly_off', acValidOverrideType('weekly_off'), 'weekly_off is a valid override type');
$assertThrows(static fn() => acValidOverrideType('holiday'), 'unknown override types are rejected');
$assertThrows(static fn() => acValidDate('2026-02-30'), 'impossible dates are rejected');
$assertThrows(static fn() => acValidDate('2026-01-01', 2027), 'dates outside the calendar year are rejected');
$assertThrows(static fn() => acValidHolidayName('x'), 'short holiday names are rejected');
$assertThrows(static fn() => acValidHolidayType('public'), 'unknown holiday types are rejected');
$assertThrows(static fn() => acValidReason('nope'), 'short reasons are rejected');

// ---- Leap year and coincident holidays remain correct ---------------------------------
$leap = acBuildCalendarDaysFromData(2028, 'all_working', [
    ['holiday_date' => '2028-02-29', 'holiday_name' => 'Leap Day', 'holiday_type' => 'company', 'is_enabled' => 1],
]);
$assertSame(366, count($leap), 'leap years materialize 366 days');
$assertSame('holiday', array_column($leap, null, 'calendar_date')['2028-02-29']['day_type'], '29 February can be a holiday');

// ---- Holiday CSV import parsing -------------------------------------------------------
$csv = "Date,Name,Type,Optional\n"
    . "2026-01-26,Republic Day,national,\n"
    . "2026-08-15,Independence Day,NATIONAL,no\n"
    . "2026-04-14,Dr. Ambedkar Jayanti,restricted,\n"
    . "2026-12-25,Christmas,festival,yes\n"
    . "2026-01-26,Republic Day,national,\n"
    . "2026-13-01,Bad Month,national,\n"
    . "2027-01-01,Wrong Year,national,\n"
    . "2026-05-01,A,company,\n"
    . "2026-06-01,Valid Name,unknown_type,\n"
    . "\n";
$parsed = acParseHolidayCsv($csv, 2026);
$assertSame(4, count($parsed['rows']), 'valid CSV rows are accepted');
$assertSame(5, count($parsed['errors']), 'invalid CSV rows are reported');
$parsedByDate = array_column($parsed['rows'], null, 'date');
$assertSame('national', $parsedByDate['2026-01-26']['type'], 'holiday type is lower-cased');
$assertSame(1, $parsedByDate['2026-04-14']['is_optional'], 'restricted rows default to optional');
$assertSame(1, $parsedByDate['2026-12-25']['is_optional'], 'an explicit optional flag is honoured');
$assertSame(0, $parsedByDate['2026-08-15']['is_optional'], 'a national holiday is not optional');
$assertSame('2026-01-26', $parsed['rows'][0]['date'], 'rows are sorted by date');

$assertThrows(static fn() => acParseHolidayCsv("Date,Name\n2026-01-01,New Year\n", 2026), 'a CSV without a type column is rejected');
$assertThrows(static fn() => acParseHolidayCsv('', 2026), 'an empty CSV is rejected');
$assertThrows(static fn() => acParseHolidayCsv("Date,Name,Type\n", 2026), 'a header-only CSV is rejected');

// A UTF-8 BOM must not break the header detection.
$bomParsed = acParseHolidayCsv("\xEF\xBB\xBFdate,name,type\n2026-03-04,Holi,festival\n", 2026);
$assertSame(1, count($bomParsed['rows']), 'a BOM-prefixed CSV is parsed');

// ---- The worked example from the requirements document --------------------------------
// "Calendar Days: 31 / Weekly Offs: 5 / Company/Festival Holidays: 2 / Total Working Days: 24"
$exampleDays = acBuildCalendarDaysFromData(
    2026,
    'all_working',
    [
        ['holiday_date' => '2026-03-04', 'holiday_name' => 'Holi', 'holiday_type' => 'festival', 'is_enabled' => 1],
        ['holiday_date' => '2026-03-20', 'holiday_name' => 'Eid ul-Fitr', 'holiday_type' => 'company', 'is_enabled' => 1],
    ]
);
$march = acMonthlyBreakdownFromDays($exampleDays)[2];
$assertSame(31, $march['total_days'], 'example month reports 31 calendar days');
$assertSame(5, $march['weekly_offs'], 'example month reports 5 weekly offs');
$assertSame(2, $march['holidays'], 'example month reports 2 company/festival holidays');
$assertSame(24, $march['working_days'], 'example month reports 24 working days');
$assertSame(
    $march['total_days'] - $march['weekly_offs'] - $march['holidays'],
    $march['working_days'],
    'Total Working Days = Calendar Days - Weekly Offs - Applicable Holidays'
);

// The combined weekly-off figure must always equal Sundays plus any other configured offs.
foreach (acMonthlyBreakdownFromDays(acBuildCalendarDaysFromData(2026, '2nd_4th_off', [])) as $monthRow) {
    $assertSame(
        $monthRow['sundays'] + $monthRow['sat_offs'],
        $monthRow['weekly_offs'],
        'weekly_offs equals sundays + other offs for ' . $monthRow['month_name']
    );
}

if ($failures > 0) {
    fwrite(STDERR, "\n{$failures} annual calendar hardening assertion(s) failed." . PHP_EOL);
    exit(1);
}

echo 'Annual calendar hardening tests passed.' . PHP_EOL;
