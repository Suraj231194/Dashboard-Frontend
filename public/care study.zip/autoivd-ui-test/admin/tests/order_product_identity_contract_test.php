<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$page = (string) file_get_contents(dirname(__DIR__) . '/pages/order-received.php');
$ajax = (string) file_get_contents(dirname(__DIR__) . '/ajax.php');

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$assert(
    str_contains($page, '<option value="${prod.id}"')
        && !str_contains($page, '<option value="${escapedName}"'),
    'The Add Order product dropdown does not submit the exact inventory product ID.'
);

$addOrderStart = strpos($ajax, 'if (isset($_POST["addOrderReceived"])');
$addOrderEnd = strpos($ajax, 'if (isset($_POST["loadOrderReceived"])', $addOrderStart);
$addOrderSource = $addOrderStart === false
    ? ''
    : substr($ajax, $addOrderStart, ($addOrderEnd === false ? null : $addOrderEnd - $addOrderStart));
$assert(
    str_contains($addOrderSource, "\$productCategory = \$_POST['productCategory'] ?? [];")
        && str_contains($addOrderSource, 'WHERE id = ? AND category_id = ? AND status = 1 AND deleted_at IS NULL')
        && str_contains($addOrderSource, "\$pStmt->bind_param('ii', \$productIdVal, \$selectedCategoryId);")
        && !str_contains($addOrderSource, 'WHERE product_name = ? LIMIT 1'),
    'Add Order does not validate the exact active product ID/category or still resolves products by name.'
);
$assert(
    str_contains($addOrderSource, "\$pname = (string) \$pRes['product_name'];"),
    'Add Order does not preserve the validated database product name as its order snapshot.'
);
$updateOrderStart = strpos($ajax, 'if (isset($_POST["updateOrderReceivedRecord"])');
$updateOrderEnd = strpos($ajax, 'if (isset($_POST[\'updateOrderReceivedStatusRecord\'])', $updateOrderStart);
$updateOrderSource = $updateOrderStart === false
    ? ''
    : substr($ajax, $updateOrderStart, ($updateOrderEnd === false ? null : $updateOrderEnd - $updateOrderStart));
$assert(
    str_contains($ajax, 'name="inventoryProductIdEdit[]"')
        && str_contains($updateOrderSource, "\$inventoryProductIdsEdit = \$_POST['inventoryProductIdEdit'] ?? [];")
        && str_contains($page, 'name="inventoryProductIdEdit[]" class="input-theme select2 product-select"')
        && str_contains($page, 'populateExistingOrderProductSelects();')
        && !str_contains($updateOrderSource, 'WHERE product_name = ? LIMIT 1'),
    'Edit Order can still re-resolve an item through an ambiguous product name.'
);

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

echo "PASS: Add Order submits and validates exact inventory product IDs.\n";
