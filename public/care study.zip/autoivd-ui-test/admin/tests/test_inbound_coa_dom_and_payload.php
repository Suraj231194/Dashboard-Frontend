<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';

echo "======================================================================\n";
echo "    INBOUND COA PAYLOAD & DOM INTEGRATION TEST                       \n";
echo "======================================================================\n\n";

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] $message\n";
    } else {
        echo "  [PASSED] $message\n";
    }
};

// 1. Verify required DOM element IDs in raw-material-packing-material.php
echo "TEST 1: DOM Elements in raw-material-packing-material.php...\n";
$html = (string) file_get_contents(dirname(__DIR__) . '/pages/raw-material-packing-material.php');
$requiredIds = [
    'inboundMaterialsModal',
    'inboundCoaEntryModal',
    'inboundCoaEntryForm',
    'inbound_queue_id',
    'stock_inward_id',
    'coa_digit',
    'coa_batch_unit_id',
    'coa_goods_type',
    'coa_number',
    'coa_material_code',
    'coa_product_name',
    'coa_batch_number',
    'coa_batch_qty',
    'coa_batch_size',
    'coa_supplier_name',
    'coa_manufacturer_name',
    'coa_testing_date',
    'coa_receipt_date',
    'coa_mfg_date',
    'coa_expiry_date',
    'coa_invoice_number',
    'coa_invoice_date',
    'coa_containers',
    'coa_storage',
    'coa_remarks',
    'inboundCoaTemplateSelect',
    'inboundLoadTemplateBtn',
    'inboundDynamicCoaFields',
    'inboundCoaSubmitBtn'
];

foreach ($requiredIds as $id) {
    $assert(str_contains($html, "id=\"{$id}\""), "DOM ID '{$id}' must be present in raw-material-packing-material.php");
}
echo "\n";

// 2. Test template matching algorithm on various material names
echo "TEST 2: Smart template matching with multiple real product scenarios...\n";

// Scenario A: Packing Material (Pouch / Box / Foil)
$pmTemplates = findCoaTemplatesForMaterial($conn, 0, 0, 'Pouch 120mm');
$hasPouchMatch = false;
foreach ($pmTemplates as $t) {
    if (!empty($t['is_recommended']) && stripos($t['name'], 'pouch') !== false) {
        $hasPouchMatch = true;
        break;
    }
}
$assert($hasPouchMatch, 'Pouch material search must recommend Pouch template at the top.');

// Scenario B: Raw Material / Reagent
$rmTemplates = findCoaTemplatesForMaterial($conn, 0, 0, 'Albumin Reagent');
$hasAlbuminMatch = false;
foreach ($rmTemplates as $t) {
    if (!empty($t['is_recommended']) && stripos($t['name'], 'albumin') !== false) {
        $hasAlbuminMatch = true;
        break;
    }
}
$assert($hasAlbuminMatch, 'Albumin search must recommend Albumin template at the top.');

// Scenario C: Unmapped / Generic item (all templates still available)
$genericTemplates = findCoaTemplatesForMaterial($conn, 0, 0, 'Unmapped Random Material X999');
$assert(count($genericTemplates) > 10, 'All active templates must still be accessible even when no direct mapping exists.');
echo "  Total available fallback templates for unmapped items: " . count($genericTemplates) . "\n\n";

// 3. Test template observations generation
echo "TEST 3: Template items table structure...\n";
$firstTmpl = $conn->query("SELECT id FROM coa_templates WHERE status = 1 AND deleted_at IS NULL ORDER BY id ASC LIMIT 1")->fetch_assoc();
if ($firstTmpl) {
    $tId = (int) $firstTmpl['id'];
    $items = $conn->query("SELECT * FROM coa_templates_items WHERE coa_template_id = {$tId} AND status = 1 AND deleted_at IS NULL")->fetch_all(MYSQLI_ASSOC);
    $assert(count($items) > 0, "Template #{$tId} has testing parameters configured.");
}
echo "\n";

// 4. Test optional template & Company Control Room redirect link in both files
echo "TEST 4: Optional template requirement & redirect to COA Templates...\n";
$coaGenFile = file_get_contents(dirname(__DIR__) . '/pages/coa-generation.php');
$assert(strpos($html, 'index.php?page=coa-templates') !== false, 'raw-material-packing-material.php must have link to Company Control Room > COA Templates');
$assert(strpos($coaGenFile, 'index.php?page=coa-templates') !== false, 'coa-generation.php must have link to Company Control Room > COA Templates');
$assert(strpos($coaGenFile, 'id="inboundCoaTemplateSelect" class="input-theme select2" required') === false, 'coa-generation.php must NOT have required on inboundCoaTemplateSelect');
$assert(strpos($html, 'id="inboundCoaTemplateSelect" class="form-select input-theme" required') === false, 'raw-material-packing-material.php must NOT have required on inboundCoaTemplateSelect');
echo "\n";

// SUMMARY
echo "======================================================================\n";
if ($failures !== []) {
    echo "FAILED with " . count($failures) . " errors:\n- " . implode("\n- ", $failures) . "\n";
    exit(1);
}

echo "DOM & PAYLOAD INTEGRATION TESTS PASSED SUCCESSFULLY! (0 failures)\n";
echo "======================================================================\n";
