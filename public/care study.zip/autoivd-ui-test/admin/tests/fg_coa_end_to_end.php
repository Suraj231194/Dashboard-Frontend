<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/test_database.php';
require_once dirname(__DIR__) . '/constant.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';
require_once dirname(__DIR__) . '/document_pdf_helpers.php';

$credentialPath = $argv[1] ?? '';
if ($credentialPath === '') {
    require_once dirname(__DIR__) . '/db.php';
} else {
    $conn = testDatabaseFromCredentialFile($credentialPath);
}
$GLOBALS['conn'] = $conn;
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};
$workflowSource = (string) file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_actions.php');
$assert(
    str_contains($workflowSource, "'iisiiisssiissdissssi',"),
    'The production FG COA insert bind signature does not match its 20 values.'
);

// Authenticate as an existing active user whose effective permissions cover
// the complete FG COA workflow.
$userResult = $conn->query(
    'SELECT id, role_id FROM users WHERE is_active = 1 AND deleted_at IS NULL ORDER BY id'
);
$authorizedUser = null;
while ($candidateUser = $userResult->fetch_assoc()) {
    $_SESSION['user_id'] = (int) $candidateUser['id'];
    $_SESSION['role_id'] = (int) $candidateUser['role_id'];
    if (
        checkPermission('fg_coa_generation_add', $conn)
        && checkPermission('fg_coa_generation_edit', $conn)
        && checkPermission('fg_coa_generation_view', $conn)
    ) {
        $authorizedUser = $candidateUser;
        break;
    }
}
$assert($authorizedUser !== null, 'No active user has the complete FG COA add/edit/view permission set.');

// Prove that a role without the manage permissions is rejected by the same
// effective-permission function used by the endpoints.
$unauthorizedRejected = false;
$userResult->data_seek(0);
while ($candidateUser = $userResult->fetch_assoc()) {
    $_SESSION['user_id'] = (int) $candidateUser['id'];
    $_SESSION['role_id'] = (int) $candidateUser['role_id'];
    if (
        !checkPermission('fg_coa_generation_add', $conn)
        && !checkPermission('fg_coa_generation_edit', $conn)
    ) {
        $unauthorizedRejected = true;
        break;
    }
}
$assert($unauthorizedRejected, 'No active unauthorized user was available for the FG COA permission rejection test.');

if ($authorizedUser !== null) {
    $_SESSION['user_id'] = (int) $authorizedUser['id'];
    $_SESSION['role_id'] = (int) $authorizedUser['role_id'];
}
$userId = (int) ($_SESSION['user_id'] ?? 0);

// Select an eligible completed IP COA with an active FG template and a matching
// unassigned finished-goods stock lot. Nothing is changed by this lookup.
$fixtureResult = $conn->query(
    "SELECT ip.id AS source_ip_id, ip.production_plan_id, ip.product_id,
            ip.product_name, ip.batch_number, ip.test_date,
            stock.id AS live_stock_id,
            COALESCE(stock.quantity_available, 0) AS batch_size,
            COALESCE(stock.quantity_unit, 0) AS batch_size_unit
     FROM ip_coa_generation ip
     INNER JOIN live_stock stock
        ON stock.product_id = ip.product_id
       AND CONVERT(TRIM(COALESCE(stock.lot_batch_no, '')) USING utf8mb4) COLLATE utf8mb4_unicode_ci
           = CONVERT(TRIM(COALESCE(ip.batch_number, '')) USING utf8mb4) COLLATE utf8mb4_unicode_ci
       AND stock.status != 3 AND stock.deleted_at IS NULL
       AND COALESCE(stock.coa_number, '') = ''
     INNER JOIN coa_template_product_mappings mapping
        ON mapping.product_id = ip.product_id
       AND mapping.coa_type = 'FG'
       AND mapping.status = 1 AND mapping.deleted_at IS NULL
     INNER JOIN coa_document_templates template
        ON template.id = mapping.template_id
       AND template.coa_type = 'FG'
       AND template.status = 1 AND template.deleted_at IS NULL
     LEFT JOIN fg_coa_generation existing_source
        ON existing_source.source_ip_coa_id = ip.id
       AND existing_source.deleted_at IS NULL
     LEFT JOIN fg_coa_generation existing_stock
        ON existing_stock.live_stock_id = stock.id
       AND existing_stock.deleted_at IS NULL
     WHERE ip.source_bmr_work_item_id IS NOT NULL
       AND ip.workflow_status = 'COMPLETED'
       AND ip.deleted_at IS NULL
       AND existing_source.id IS NULL
       AND existing_stock.id IS NULL
     ORDER BY ip.id DESC, stock.id DESC
     LIMIT 1"
);
$fixture = $fixtureResult->fetch_assoc() ?: null;
$assert($fixture !== null, 'No eligible templated IP COA/live-stock fixture is available for the FG COA workflow test.');

$namedLock = null;
$draftId = 0;
$originalStockCoa = null;
$workflowCompleted = false;

if ($authorizedUser !== null && $fixture !== null) {
    try {
        $sourceIpId = (int) $fixture['source_ip_id'];
        $productId = (int) $fixture['product_id'];
        $liveStockId = (int) $fixture['live_stock_id'];
        $batchSize = (float) $fixture['batch_size'];
        $batchUnitId = (int) $fixture['batch_size_unit'];
        $assert($batchSize > 0 && $batchUnitId > 0, 'The eligible stock fixture has no valid batch size/unit.');

        $template = coaTemplateResolveMappedTemplate($conn, $productId, 'FG');
        $assert($template !== null, 'The selected product did not resolve its active FG template.');
        if ($template === null) {
            throw new RuntimeException('Mapped FG template unavailable.');
        }

        $yearPrefix = date('y');
        $sequencePrefix = 'BIPL-COA-FG-' . $yearPrefix;
        $namedLock = 'fg_coa_sequence_' . $yearPrefix;
        $lockStmt = $conn->prepare('SELECT GET_LOCK(?, 10) AS acquired');
        $lockStmt->bind_param('s', $namedLock);
        $lockStmt->execute();
        $lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0);
        $lockStmt->close();
        if ($lockAcquired !== 1) {
            throw new RuntimeException('Unable to acquire the FG COA sequence lock.');
        }

        $conn->begin_transaction();
        $sourceLock = $conn->prepare(
            "SELECT id FROM ip_coa_generation
             WHERE id = ? AND workflow_status = 'COMPLETED' AND deleted_at IS NULL
             FOR UPDATE"
        );
        $sourceLock->bind_param('i', $sourceIpId);
        $sourceLock->execute();
        $assert($sourceLock->get_result()->num_rows === 1, 'The source IP COA could not be locked.');
        $sourceLock->close();

        $stockLock = $conn->prepare(
            "SELECT coa_number FROM live_stock
             WHERE id = ? AND status != 3 AND deleted_at IS NULL FOR UPDATE"
        );
        $stockLock->bind_param('i', $liveStockId);
        $stockLock->execute();
        $stockRow = $stockLock->get_result()->fetch_assoc();
        $stockLock->close();
        $originalStockCoa = (string) ($stockRow['coa_number'] ?? '');
        $assert($originalStockCoa === '', 'The selected stock fixture already has a COA number.');

        $likePrefix = $sequencePrefix . '%';
        $sequenceStmt = $conn->prepare(
            'SELECT coa_fg FROM fg_coa_generation WHERE coa_fg LIKE ? ORDER BY id DESC'
        );
        $sequenceStmt->bind_param('s', $likePrefix);
        $sequenceStmt->execute();
        $sequenceResult = $sequenceStmt->get_result();
        $lastSequence = 0;
        $sequencePattern = '/^' . preg_quote($sequencePrefix, '/') . '(\d{4})$/';
        while ($sequenceRow = $sequenceResult->fetch_assoc()) {
            if (preg_match($sequencePattern, trim((string) $sequenceRow['coa_fg']), $matches)) {
                $lastSequence = max($lastSequence, (int) $matches[1]);
            }
        }
        $sequenceStmt->close();
        $coaNumber = $sequencePrefix . str_pad((string) ($lastSequence + 1), 4, '0', STR_PAD_LEFT);

        $draftValidation = coaTemplateValidateSubmission(
            $conn,
            $productId,
            'FG',
            (int) $template['id'],
            ['schema_version' => 1, 'fields' => []],
            false
        );
        $draftPayloadJson = json_encode(
            $draftValidation['payload'],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
        $departmentResult = $conn->query(
            'SELECT id FROM departments WHERE status != 3 AND deleted_at IS NULL ORDER BY id LIMIT 1'
        );
        $departmentId = (int) (($departmentResult->fetch_assoc()['id'] ?? 0));
        $assert($departmentId > 0, 'No active department is available for the FG COA test.');

        $workflowStatus = 'DRAFT';
        $productName = (string) $fixture['product_name'];
        $batchNumber = (string) $fixture['batch_number'];
        $testDate = (string) ($fixture['test_date'] ?: date('Y-m-d'));
        $testedBy = 'Automated authorized FG COA test';
        $reviewedBy = 'Automated QA reviewer';
        $remark = 'Rollback-only Item 13 acceptance test';
        $productionPlanId = $fixture['production_plan_id'] !== null
            ? (int) $fixture['production_plan_id']
            : null;
        $templateId = (int) $template['id'];
        $familyKey = (string) ($draftValidation['template']['profile']['family_key'] ?? '');
        $templateSnapshotId = templateSnapshotCreateCoa(
            $conn,
            'FG',
            $draftValidation['template'],
            $productId,
            $productName,
            $batchNumber,
            $userId
        );
        $insertStmt = $conn->prepare(
            "INSERT INTO fg_coa_generation
                (source_ip_coa_id, production_plan_id, coa_fg, product_id, coa_template_id,
                 template_snapshot_id, family_key, form_payload_json, workflow_status, live_stock_id, dept_id,
                 product_name, batch_number, batch_size, batch_size_unit, test_date,
                 tested_by, review_approved_by, remark, status, created_by, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NOW())"
        );
        $insertStmt->bind_param(
            'iisiiisssiissdissssi',
            $sourceIpId,
            $productionPlanId,
            $coaNumber,
            $productId,
            $templateId,
            $templateSnapshotId,
            $familyKey,
            $draftPayloadJson,
            $workflowStatus,
            $liveStockId,
            $departmentId,
            $productName,
            $batchNumber,
            $batchSize,
            $batchUnitId,
            $testDate,
            $testedBy,
            $reviewedBy,
            $remark,
            $userId
        );
        if (!$insertStmt->execute()) {
            throw new RuntimeException('Draft insert failed: ' . $insertStmt->error);
        }
        $draftId = (int) $conn->insert_id;
        $insertStmt->close();

        $mapStmt = $conn->prepare(
            'UPDATE live_stock SET coa_number = ?, updated_by = ?, updated_at = NOW() WHERE id = ?'
        );
        $mapStmt->bind_param('sii', $coaNumber, $userId, $liveStockId);
        $mapStmt->execute();
        $mapStmt->close();

        $draftStmt = $conn->prepare(
            'SELECT * FROM fg_coa_generation WHERE id = ? AND workflow_status = \'DRAFT\''
        );
        $draftStmt->bind_param('i', $draftId);
        $draftStmt->execute();
        $savedDraft = $draftStmt->get_result()->fetch_assoc();
        $draftStmt->close();
        $assert($savedDraft !== null, 'The authorized FG COA draft was not saved.');
        $assert((string) ($savedDraft['coa_fg'] ?? '') === $coaNumber, 'The allocated FG COA sequence was not saved.');
        $assert((string) ($savedDraft['batch_number'] ?? '') === $batchNumber, 'The draft batch value changed unexpectedly.');
        $assert((int) ($savedDraft['live_stock_id'] ?? 0) === $liveStockId, 'The draft stock mapping was not saved.');

        // Reopen through the same saved-form loader used by the draft endpoint.
        $reopened = coaTemplateLoadSavedForm($conn, 'FG', $draftId);
        $editableHtml = coaTemplateRender($reopened, true);
        $assert($editableHtml !== '', 'Reopening the saved FG COA draft produced empty content.');
        $assert((int) $reopened['template_id'] === $templateId, 'The reopened draft resolved a different template.');

        $completeFields = [
            'metadata.manufacturing_date' => date('Y-m-d'),
            'metadata.expiry_date' => date('Y-m-d', strtotime('+1 year')),
            'approval.decision' => 'APPROVED',
            'approval.comments' => 'Item 13 rollback-only acceptance test',
            'approval.analysis_by' => $testedBy,
            'approval.verified_by' => $reviewedBy,
        ];
        foreach (($template['profile']['editable_field_keys'] ?? []) as $fieldKey) {
            $completeFields[(string) $fieldKey] = 'Complies';
        }
        $completeValidation = coaTemplateValidateSubmission(
            $conn,
            $productId,
            'FG',
            $templateId,
            ['schema_version' => 1, 'fields' => $completeFields],
            true
        );
        $completePayloadJson = json_encode(
            $completeValidation['payload'],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
        $completeStatus = 'COMPLETED';
        $completeStmt = $conn->prepare(
            "UPDATE fg_coa_generation
             SET form_payload_json = ?, workflow_status = ?, tested_by = ?,
                 review_approved_by = ?, remark = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ? AND workflow_status = 'DRAFT'"
        );
        $completeStmt->bind_param(
            'sssssii',
            $completePayloadJson,
            $completeStatus,
            $testedBy,
            $reviewedBy,
            $remark,
            $userId,
            $draftId
        );
        $completeStmt->execute();
        $assert($completeStmt->affected_rows === 1, 'The reopened FG COA draft was not completed exactly once.');
        $completeStmt->close();

        $duplicateStmt = $conn->prepare(
            'SELECT COUNT(*) AS total FROM fg_coa_generation WHERE source_ip_coa_id = ? AND deleted_at IS NULL'
        );
        $duplicateStmt->bind_param('i', $sourceIpId);
        $duplicateStmt->execute();
        $sourceCount = (int) ($duplicateStmt->get_result()->fetch_assoc()['total'] ?? 0);
        $duplicateStmt->close();
        $assert($sourceCount === 1, 'The submission produced more than one FG COA for its source.');

        $listStmt = $conn->prepare(
            "SELECT id FROM fg_coa_generation
             WHERE status != 3 AND deleted_at IS NULL
             ORDER BY id DESC LIMIT 1"
        );
        $listStmt->execute();
        $listedId = (int) ($listStmt->get_result()->fetch_assoc()['id'] ?? 0);
        $listStmt->close();
        $assert($listedId === $draftId, 'The completed FG COA is not in the expected newest list position.');

        $completedForm = coaTemplateLoadSavedForm($conn, 'FG', $draftId);
        $completedHtml = coaTemplateRender($completedForm, false);
        $pdf = documentPdfBuild('<!doctype html><html><body>' . $completedHtml . '</body></html>');
        $assert(str_starts_with($pdf, '%PDF-'), 'The completed FG COA download did not produce a valid PDF.');
        $assert(strlen($pdf) > 2000, 'The completed FG COA PDF content is unexpectedly small.');

        $missingFieldsRejected = false;
        try {
            coaTemplateValidateSubmission(
                $conn,
                $productId,
                'FG',
                $templateId,
                ['schema_version' => 1, 'fields' => []],
                true
            );
        } catch (InvalidArgumentException) {
            $missingFieldsRejected = true;
        }
        $assert($missingFieldsRejected, 'A completed FG COA accepted missing required fields.');

        $invalidIdRejected = false;
        try {
            coaTemplateLoadSavedForm($conn, 'FG', PHP_INT_MAX);
        } catch (Throwable) {
            $invalidIdRejected = true;
        }
        $assert($invalidIdRejected, 'An invalid FG COA ID was accepted.');

        $workflowCompleted = true;
        throw new RuntimeException('FORCED_FG_COA_ROLLBACK');
    } catch (Throwable $error) {
        if ($conn->errno === 0 || $conn->ping()) {
            $conn->rollback();
        }
        if ($error->getMessage() !== 'FORCED_FG_COA_ROLLBACK') {
            $failures[] = 'FG COA workflow execution failed: ' . $error->getMessage();
        }
    } finally {
        if ($namedLock !== null) {
            $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
            $releaseStmt->bind_param('s', $namedLock);
            $releaseStmt->execute();
            $releaseStmt->close();
        }
    }

    $assert($workflowCompleted, 'The complete FG COA acceptance workflow did not reach its forced rollback.');
    if ($draftId > 0) {
        $cleanupStmt = $conn->prepare('SELECT COUNT(*) AS total FROM fg_coa_generation WHERE id = ?');
        $cleanupStmt->bind_param('i', $draftId);
        $cleanupStmt->execute();
        $remainingDraft = (int) ($cleanupStmt->get_result()->fetch_assoc()['total'] ?? 0);
        $cleanupStmt->close();
        $assert($remainingDraft === 0, 'The forced rollback left the FG COA test record behind.');
    }
    $stockStmt = $conn->prepare('SELECT coa_number FROM live_stock WHERE id = ?');
    $fixtureStockId = (int) $fixture['live_stock_id'];
    $stockStmt->bind_param('i', $fixtureStockId);
    $stockStmt->execute();
    $restoredStockCoa = (string) ($stockStmt->get_result()->fetch_assoc()['coa_number'] ?? '');
    $stockStmt->close();
    $assert($restoredStockCoa === (string) $originalStockCoa, 'The forced rollback did not restore the live-stock COA mapping.');
}

if ($failures) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", array_unique($failures)) . "\n");
    exit(1);
}

echo "PASS: authenticated FG COA draft, sequence, reopen, completion, uniqueness, list, PDF, validation, authorization, invalid-ID, and rollback checks.\n";
