<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/finance/finance_common.php';
require_once dirname(__DIR__) . '/finance/finance_pdf.php';

$sample = [[
    'product_name' => 'Regression Product',
    'quantity' => 2,
    'rate' => 100,
    'mrp' => 120,
    'discount_percent' => 10,
    'cgst_percent' => 9,
    'sgst_percent' => 9,
    'igst_percent' => 0,
]];

$invoice = financeCalculateItems($sample, 'SALES_INVOICE', 'INTRA');
$vendorBill = financeCalculateItems($sample, 'VENDOR_BILL', 'INTRA');
$challan = financeCalculateItems($sample, 'DELIVERY_CHALLAN', 'NONE');

$document = array_merge([
    'document_type' => 'DELIVERY_CHALLAN',
    'document_number' => 'DC-TEST',
    'reference_number' => 'DC-TEST',
    'document_date' => '2026-08-31',
    'counterparty_name' => 'Reference Client',
    'company' => [],
    'selected_bank' => [],
    'terms_snapshot' => '',
], $challan['totals'], [
    'reference_total' => financeReferenceTotal($challan['items']),
    'items' => $challan['items'],
]);
$html = financeBuildDocumentHtml($document);
$pdf = financeBuildApprovedTemplatePdf($document);
$actionsSource = (string) file_get_contents(dirname(__DIR__) . '/finance/finance_actions.php');
$pageSource = (string) file_get_contents(dirname(__DIR__) . '/pages/finance-page.php');
$pdfSource = (string) file_get_contents(dirname(__DIR__) . '/finance/finance_pdf.php');
$decimalReference = financeReferenceTotal([
    ['quantity' => 1.5, 'rate' => 2.25],
    ['quantity' => 4, 'rate' => null],
]);
$multiItems = array_fill(0, 13, $challan['items'][0]);
$multiDocument = $document;
$multiDocument['items'] = $multiItems;
$multiDocument['reference_total'] = financeReferenceTotal($multiItems);
$multiPdf = financeBuildApprovedTemplatePdf($multiDocument);

$assertions = [
    'invoice total remains unchanged' => abs($invoice['totals']['grand_total'] - 212.0) < 0.001,
    'vendor bill total remains unchanged' => abs($vendorBill['totals']['grand_total'] - 212.0) < 0.001,
    'challan total uses quantity and rate' => abs($challan['totals']['grand_total'] - 200.0) < 0.001,
    'challan taxable total carries the dispatch value' => abs($challan['totals']['taxable_total'] - 200.0) < 0.001,
    'challan item total carries the dispatch value' => abs($challan['items'][0]['line_total'] - 200.0) < 0.001,
    'reference helper uses quantity and rate' => abs(financeReferenceValue($sample[0]) - 200.0) < 0.001,
    'decimal and missing reference rates are handled safely' => abs($decimalReference - 3.38) < 0.001,
    'reference helper agrees with the calculated total' => abs($document['reference_total'] - $document['grand_total']) < 0.001,
    'challan regeneration keeps the same reference total' => abs(financeReferenceTotal($challan['items']) - $document['reference_total']) < 0.001,
    'challan HTML labels the calculated total' => str_contains($html, 'Total Amount'),
    'challan HTML preserves non-receivable semantics' => str_contains($html, 'no receivable or payment is created'),
    'challan screen labels rate and amount' => str_contains($pageSource, 'Total Amount') && str_contains($pageSource, '>Amount</label>'),
    'challan PDF labels amount and total' => str_contains($pdfSource, "'Amount', true") && str_contains($pdfSource, 'Total Amount'),
    'multi-item challan uses multiple approved-template pages' => str_starts_with($multiPdf, '%PDF-') && substr_count($multiPdf, '/Type /Page') >= 2,
    'challan amount in words remains explicit' => str_contains($pdfSource, 'Amount: Rs.'),
    'payments remain limited to bills and invoices' => str_contains($actionsSource, "['VENDOR_BILL', 'SALES_INVOICE']"),
    'trade receivables remain invoice-only' => str_contains($actionsSource, "'invoice_generation', 'trade_receivables' => 'SALES_INVOICE'"),
    'challan approved-template output is a PDF' => str_starts_with($pdf, '%PDF-'),
];

$failures = array_keys(array_filter($assertions, static fn(bool $passed): bool => !$passed));
if ($failures) {
    fwrite(STDERR, "FAILED\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo 'PASS: ' . count($assertions) . " Delivery Challan compatibility assertions.\n";
