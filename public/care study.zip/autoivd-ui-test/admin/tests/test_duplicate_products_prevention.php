<?php
/**
 * Test Duplicate Products Prevention Suite
 * Validates:
 * 1. Database zero duplicate active products
 * 2. MySQL unique index rejection at the storage engine level
 * 3. Soft-delete nullification allows reuse of name
 * 4. Application-level AJAX validation for addProduct and updateProduct
 */

require_once __DIR__ . '/../db.php';

$allPassed = true;

function runTest($name, $callable) {
    global $allPassed;
    echo "Running [{$name}]... ";
    try {
        $callable();
        echo "PASSED\n";
    } catch (Throwable $e) {
        $allPassed = false;
        echo "FAILED: " . $e->getMessage() . "\n";
    }
}

// 1. Zero Duplicate Active Products
runTest('Database Zero Active Product Duplicates', function() use ($conn) {
    $res = $conn->query("SELECT LOWER(TRIM(product_name)) as norm_name, COUNT(*) as cnt 
                         FROM products 
                         WHERE status != 3 AND deleted_at IS NULL 
                         GROUP BY LOWER(TRIM(product_name)) 
                         HAVING cnt > 1");
    if (!$res) {
        throw new Exception("Query failed: " . $conn->error);
    }
    $duplicates = $res->fetch_all(MYSQLI_ASSOC);
    if (count($duplicates) > 0) {
        throw new Exception("Found " . count($duplicates) . " duplicate groups in active products!");
    }
});

// 2. MySQL Unique Index Rejection on Direct Insert
runTest('MySQL Schema Engine Physical Duplicate Rejection', function() use ($conn) {
    // Get an existing active product name
    $existing = $conn->query("SELECT product_name FROM products WHERE status != 3 AND deleted_at IS NULL LIMIT 1")->fetch_assoc();
    if (!$existing) {
        throw new Exception("No existing product found for test.");
    }
    $existingName = $existing['product_name'];

    // Try inserting duplicate active product (with different casing / leading whitespace)
    $testName = "  " . strtoupper($existingName) . "  ";
    $dummyCode = 'TEST-DUP-' . time();
    $stmt = $conn->prepare("INSERT INTO products (product_code, product_name, category_id, status, created_at) VALUES (?, ?, 1, 1, NOW())");
    $stmt->bind_param('ss', $dummyCode, $testName);
    
    $executed = @$stmt->execute();
    if ($executed) {
        // Rollback test insert if unexpectedly succeeded
        $insertedId = $conn->insert_id;
        $conn->query("DELETE FROM products WHERE id = $insertedId");
        throw new Exception("MySQL failed to physically reject duplicate active product name!");
    }

    $errno = $stmt->errno;
    $stmt->close();

    // MySQL error 1062 = ER_DUP_ENTRY
    if ($errno !== 1062) {
        throw new Exception("Expected MySQL error 1062 (ER_DUP_ENTRY), got error {$errno}: " . $conn->error);
    }
});

// 3. MySQL Allows Multiple Soft-Deleted Items with Same Name
runTest('MySQL Allows Soft-Deleted Products without Collision', function() use ($conn) {
    $dummyCode1 = 'TEST-DEL-1-' . time();
    $dummyCode2 = 'TEST-DEL-2-' . time();
    $sameName = 'Test Deleted Name ' . time();

    // Insert 1st soft-deleted
    $stmt1 = $conn->prepare("INSERT INTO products (product_code, product_name, category_id, status, deleted_at) VALUES (?, ?, 1, 3, NOW())");
    $stmt1->bind_param('ss', $dummyCode1, $sameName);
    if (!$stmt1->execute()) {
        throw new Exception("Failed inserting 1st soft-deleted product: " . $stmt1->error);
    }
    $id1 = $conn->insert_id;
    $stmt1->close();

    // Insert 2nd soft-deleted with identical name (must succeed because active_product_name evaluates to NULL)
    $stmt2 = $conn->prepare("INSERT INTO products (product_code, product_name, category_id, status, deleted_at) VALUES (?, ?, 1, 3, NOW())");
    $stmt2->bind_param('ss', $dummyCode2, $sameName);
    if (!$stmt2->execute()) {
        $conn->query("DELETE FROM products WHERE id = $id1");
        throw new Exception("Failed inserting 2nd soft-deleted product: " . $stmt2->error);
    }
    $id2 = $conn->insert_id;
    $stmt2->close();

    // Clean up test rows
    $conn->query("DELETE FROM products WHERE id IN ($id1, $id2)");
});

// 4. AJAX addProduct and updateProduct duplicate validation logic check
runTest('Application Validation Logic Matches Schema Constraint', function() use ($conn) {
    $existing = $conn->query("SELECT id, product_name FROM products WHERE status != 3 AND deleted_at IS NULL LIMIT 1")->fetch_assoc();
    $targetName = " " . strtolower($existing['product_name']) . " ";

    // Test addProduct check
    $stmt = $conn->prepare("SELECT id FROM `products` WHERE `status` != 3 AND `deleted_at` IS NULL AND LOWER(TRIM(`product_name`)) = LOWER(TRIM(?)) LIMIT 1");
    $stmt->bind_param('s', $targetName);
    $stmt->execute();
    $stmt->store_result();
    $isDupAdd = $stmt->num_rows > 0;
    $stmt->close();

    if (!$isDupAdd) {
        throw new Exception("Validation logic failed to detect duplicate in addProduct!");
    }

    // Test updateProduct check on different product ID
    $otherProduct = $conn->query("SELECT id FROM products WHERE status != 3 AND deleted_at IS NULL AND id != {$existing['id']} LIMIT 1")->fetch_assoc();
    $otherId = (int)$otherProduct['id'];

    $stmt2 = $conn->prepare("SELECT id FROM `products` WHERE `status` != 3 AND `deleted_at` IS NULL AND LOWER(TRIM(`product_name`)) = LOWER(TRIM(?)) AND `id` != ? LIMIT 1");
    $stmt2->bind_param('si', $targetName, $otherId);
    $stmt2->execute();
    $stmt2->store_result();
    $isDupUpdate = $stmt2->num_rows > 0;
    $stmt2->close();

    if (!$isDupUpdate) {
        throw new Exception("Validation logic failed to detect duplicate in updateProduct!");
    }
});

echo "\n========================================\n";
if ($allPassed) {
    echo "ALL 4 DUPLICATE PREVENTION TESTS PASSED!\n";
    exit(0);
} else {
    echo "SOME TESTS FAILED!\n";
    exit(1);
}
