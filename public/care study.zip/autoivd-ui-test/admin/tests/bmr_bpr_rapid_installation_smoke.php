<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_rapid_profiles.php';

$failures = [];
$expectedIds = bmrBprRapidApprovedProductIds();
$expectedIdSql = implode(',', $expectedIds);
$expectedCodes = [
    'COMMON_RAPID_BMR_01_V03',
    'COMMON_RAPID_BMR_02_V03',
    'COMMON_RAPID_BPR_01_V03',
];
$productionPage = file_get_contents(dirname(__DIR__) . '/pages/production-bmr-bpr.php');
if (
    $productionPage === false
    || !str_contains($productionPage, "templateCode.startsWith('COMMON_RAPID_')")
    || !str_contains($productionPage, "return 'Rapid';")
    || !str_contains($productionPage, 'productionBmrBprTemplateFamilyText(record)')
    || !str_contains($productionPage, '${templateFamilyText}')
) {
    $failures[] = 'Rapid identity is missing from the incoming or lower-record UI.';
}
$codeSql = implode(',', array_map(
    static fn(string $code): string => "'" . $conn->real_escape_string($code) . "'",
    $expectedCodes
));

$installedTemplates = [];
$templates = $conn->query(
    "SELECT template_code, form_type, source_pdf_path, page_asset_path, layout_json
     FROM bmr_templates
     WHERE template_code IN ({$codeSql}) AND status = 1 AND deleted_at IS NULL"
);
if (!$templates || $templates->num_rows !== 3) {
    $failures[] = 'The three active Rapid templates are not installed.';
} else {
    while ($template = $templates->fetch_assoc()) {
        $layout = json_decode((string) $template['layout_json'], true);
        if (
            !is_array($layout)
            || ($layout['renderer'] ?? '') !== 'structured_html'
            || ($layout['renderer_variant'] ?? '') !== 'rapid'
            || ($layout['form_type'] ?? '') !== $template['form_type']
            || !is_array($layout['profiles'] ?? null)
            || $template['source_pdf_path'] !== null
            || $template['page_asset_path'] !== null
        ) {
            $failures[] = $template['template_code'] . ': invalid code-only Rapid layout.';
        }
        foreach (($layout['profiles'] ?? []) as $productId => $profile) {
            if ((int) ($profile['catalog_product_id'] ?? 0) !== (int) $productId) {
                $failures[] = $template['template_code'] . ': products are not separately profiled.';
                break;
            }
        }
        $installedTemplates[(string) $template['template_code']] = [
            'form_type' => (string) $template['form_type'],
            'layout' => $layout,
        ];
    }
}

$mappingRows = $conn->query(
    "SELECT mapping.product_id, mapping.form_type, mapping.document_sequence
     FROM bmr_template_product_mappings mapping
     INNER JOIN bmr_templates template
        ON template.id = mapping.template_id
       AND template.template_code IN ({$codeSql})
       AND template.status = 1 AND template.deleted_at IS NULL
     WHERE mapping.status = 1 AND mapping.deleted_at IS NULL
     ORDER BY mapping.product_id, mapping.form_type, mapping.document_sequence"
);
$actualIds = [];
$mappingCounts = ['BMR' => 0, 'BPR' => 0];
$comboCounts = ['BMR' => 0, 'BPR' => 0];
if (!$mappingRows) {
    $failures[] = 'Unable to read Rapid mappings.';
} else {
    while ($mapping = $mappingRows->fetch_assoc()) {
        $productId = (int) $mapping['product_id'];
        $formType = (string) $mapping['form_type'];
        $actualIds[$productId] = true;
        $mappingCounts[$formType]++;
        if (in_array($productId, [1147, 1148], true)) {
            $comboCounts[$formType]++;
        }
    }
}
$actualIds = array_keys($actualIds);
sort($actualIds);
if ($actualIds !== $expectedIds) {
    $failures[] = 'Installed Rapid product IDs differ from the audited source set.';
}
if ($mappingCounts !== ['BMR' => 82, 'BPR' => 80]) {
    $failures[] = 'Installed Rapid mapping totals are invalid.';
}
if ($comboCounts !== ['BMR' => 4, 'BPR' => 2]) {
    $failures[] = 'Each Dengue Combo catalog product must have two BMRs and one BPR.';
}

$separateProfiles = $conn->query(
    "SELECT layout_json
     FROM bmr_templates
     WHERE template_code = 'COMMON_RAPID_BMR_01_V03'
       AND status = 1 AND deleted_at IS NULL LIMIT 1"
);
$separateLayout = $separateProfiles
    ? json_decode((string) ($separateProfiles->fetch_assoc()['layout_json'] ?? ''), true)
    : [];
$syphilisWholeBlood = $separateLayout['profiles']['1216']['product_name'] ?? '';
$syphilisSerum = $separateLayout['profiles']['1215']['product_name'] ?? '';
if (
    $syphilisWholeBlood === ''
    || $syphilisSerum === ''
    || $syphilisWholeBlood === $syphilisSerum
) {
    $failures[] = 'Two products sharing a source layout were not kept as separate profiles.';
}

$demo = $conn->query(
    "SELECT
        COUNT(DISTINCT request_row.product_id) AS products,
        COUNT(DISTINCT request_row.id) AS requests,
        COUNT(work_item.id) AS work_items,
        SUM(work_item.form_type = 'BMR') AS bmrs,
        SUM(work_item.form_type = 'BPR') AS bprs,
        SUM(work_item.status != 'PENDING') AS non_pending
     FROM material_requisition mr
     INNER JOIN bmr_bpr_requests request_row
        ON request_row.material_requisition_id = mr.id
       AND request_row.deleted_at IS NULL
     INNER JOIN bmr_bpr_work_items work_item
        ON work_item.request_id = request_row.id
       AND work_item.deleted_at IS NULL
     WHERE mr.slip_no LIKE 'BMR-COMMON-RAPID-DEMO-%'
       AND request_row.product_id IN ({$expectedIdSql})
       AND mr.deleted_at IS NULL"
);
$demoRow = $demo ? $demo->fetch_assoc() : [];
$demoRequests = (int) ($demoRow['requests'] ?? 0);
$demoValidated = $demoRequests > 0;
if ($demoValidated && (
    (int) ($demoRow['products'] ?? 0) !== 79
    || $demoRequests !== 79
    || (int) ($demoRow['work_items'] ?? 0) !== 160
    || (int) ($demoRow['bmrs'] ?? 0) !== 81
    || (int) ($demoRow['bprs'] ?? 0) !== 79
    || (int) ($demoRow['non_pending'] ?? 0) !== 0
)) {
    $failures[] = 'Rapid acceptance request/work-item totals or statuses are invalid.';
}

$coaSideEffects = $conn->query(
    "SELECT COUNT(*) AS total
     FROM ip_coa_generation ip
     INNER JOIN bmr_bpr_requests request_row
        ON request_row.id = ip.source_bmr_bpr_request_id
       AND request_row.deleted_at IS NULL
     INNER JOIN material_requisition mr
        ON mr.id = request_row.material_requisition_id
       AND mr.slip_no LIKE 'BMR-COMMON-RAPID-DEMO-%'
       AND mr.deleted_at IS NULL
     WHERE request_row.product_id IN ({$expectedIdSql})
       AND ip.deleted_at IS NULL"
);
if ((int) ($coaSideEffects ? $coaSideEffects->fetch_assoc()['total'] ?? 0 : -1) !== 0) {
    $failures[] = 'Rapid BMR/BPR acceptance records unexpectedly created IP COA records.';
}

foreach ($installedTemplates as $templateCode => $installedTemplate) {
    $layout = $installedTemplate['layout'];
    $profiles = is_array($layout['profiles'] ?? null) ? $layout['profiles'] : [];
    $profile = $profiles === [] ? null : reset($profiles);
    if (!is_array($profile)) {
        $failures[] = "{$templateCode}: no installed profile.";
        continue;
    }
    $formType = (string) $installedTemplate['form_type'];
    $html = bmrBprRenderStructuredTemplate([
        'form_type' => $formType,
        'layout' => $layout,
        'profile' => $profile,
        'source_values' => [
            'batch_number' => 'INSTALL-SMOKE',
            'batch_size' => '1000',
            'record_number' => $formType . '/INSTALL-SMOKE',
        ],
        'form_payload' => ['fields' => []],
    ], true);
    if (
        $html === ''
        || stripos($html, 'MASTER COPY') === false
        || stripos($html, 'data-bmr-field="qa.incharge.signature"') === false
        || stripos($html, 'data-bmr-field="qa.incharge.date"') === false
    ) {
        $failures[] = "{$templateCode}: installed form does not render.";
    }
}

if ($failures !== []) {
    fwrite(STDERR, implode(PHP_EOL, $failures) . PHP_EOL);
    exit(1);
}

$demoMessage = $demoValidated
    ? '79 complete-pair demo requests validated, '
    : 'optional demo records not installed, ';
echo 'Rapid installation smoke test passed: 3 templates, 81 separate mappings, '
    . $demoMessage . 'and no IP/FG COA side effects.' . PHP_EOL;
