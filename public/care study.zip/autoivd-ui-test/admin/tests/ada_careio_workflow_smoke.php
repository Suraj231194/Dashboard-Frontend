<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';

function adaCareioAssert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

try {
    $products = [
        415 => ['code' => 'BGX/FIN.BIOC/2026/000001', 'pack_size' => '100 ml'],
        417 => ['code' => 'BGX/FIN.BIOC/2026/000003', 'pack_size' => '15 ml'],
        418 => ['code' => 'BGX/FIN.BIOC/2026/000004', 'pack_size' => '30 ml'],
    ];
    foreach ($products as $productId => $expected) {
        $productStmt = $conn->prepare(
            'SELECT id, product_name, product_code FROM products
             WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
        );
        $productStmt->bind_param('i', $productId);
        $productStmt->execute();
        $product = $productStmt->get_result()->fetch_assoc();
        adaCareioAssert(
            $product !== null && (string) $product['product_code'] === $expected['code'],
            "ADA product {$productId} is unavailable."
        );
        $productStmt->close();

        $resolvedPackSize = bmrBprResolveProductPackSize(
            $conn,
            $productId,
            (string) $product['product_name']
        );
        adaCareioAssert(
            strtolower($resolvedPackSize) === $expected['pack_size'],
            "ADA product {$productId} did not resolve pack size {$expected['pack_size']}."
        );

        $legacyRequirements = bmrBprProductDocumentRequirements($conn, $productId);
        $legacyCounts = bmrBprDocumentRequirementCounts(
            bmrBprNormalizeDocumentRequirements($legacyRequirements, 1, 1)
        );
        adaCareioAssert(
            $legacyCounts === ['BMR' => 2, 'BPR' => 1],
            "ADA product {$productId} did not preserve its existing two-BMR/one-BPR fallback."
        );

        $requirements = bmrBprResolveProductDocumentRequirements(
            $conn,
            $productId,
            $resolvedPackSize
        );
        $counts = bmrBprDocumentRequirementCounts(
            bmrBprNormalizeDocumentRequirements($requirements, 1, 1)
        );
        adaCareioAssert(
            $counts === ['BMR' => 2, 'BPR' => 1],
            "ADA product {$productId} does not resolve two BMRs and one pack-size BPR."
        );

        $bmrProfileNames = [];
        $bmrTemplateIds = [];
        foreach ($requirements as $formType => $items) {
            foreach ($items as $item) {
                $templateId = (int) ($item['template_id'] ?? 0);
                $templateResult = $conn->query(
                    "SELECT layout_json FROM bmr_templates WHERE id = {$templateId} LIMIT 1"
                );
                $template = $templateResult ? $templateResult->fetch_assoc() : null;
                $layout = json_decode((string) ($template['layout_json'] ?? ''), true);
                adaCareioAssert(
                    is_array($layout) && isset($layout['profiles'][(string) $productId]),
                    "ADA product {$productId} has no {$formType} structured profile."
                );
                $profile = $layout['profiles'][(string) $productId];
                if ($formType === 'BMR') {
                    $bmrProfileNames[(int) $item['document_sequence']] = (string) ($profile['product_name'] ?? '');
                    $bmrTemplateIds[] = $templateId;
                } else {
                    adaCareioAssert(
                        strtolower((string) ($profile['pack_size'] ?? '')) === '1 kit (' . $expected['pack_size'] . ')',
                        "ADA product {$productId} has the wrong pack-size BPR profile."
                    );
                }
            }
        }
        ksort($bmrProfileNames);
        adaCareioAssert(
            array_values($bmrProfileNames) === ['ADA Reagent R1', 'ADA Reagent R2'],
            "ADA product {$productId} does not have distinct R1 and R2 BMR profiles."
        );
        adaCareioAssert(
            count(array_unique($bmrTemplateIds)) === 2,
            "ADA product {$productId} maps both BMR positions to the same template."
        );

        foreach (['IP', 'FG'] as $coaType) {
            $template = coaTemplateResolveMappedTemplate($conn, $productId, $coaType);
            adaCareioAssert(
                is_array($template),
                "ADA product {$productId} has no {$coaType} COA template."
            );

            $fields = [
                'metadata.manufacturing_date' => '01/09/2026',
                'metadata.expiry_date' => '01/09/2028',
                'approval.decision' => 'APPROVED',
                'approval.comments' => 'Smoke test',
                'approval.analysis_by' => 'QC Analyst',
                'approval.verified_by' => 'QC Approver',
            ];
            foreach (($template['profile']['rows'] ?? []) as $row) {
                if (($row['kind'] ?? 'test') !== 'section') {
                    $fields['results.' . $row['key']] = 'Conforms';
                }
            }
            $payload = coaTemplateSanitizePayload(
                $template['profile'],
                ['schema_version' => 1, 'fields' => $fields],
                true
            );
            $form = coaTemplatePrepareForm(
                $template,
                $coaType,
                [
                    'coa_number' => 'ADA-CAREIO-SMOKE',
                    'product_name' => 'ADA',
                    'batch_number' => 'ADA-SMOKE-001',
                    'batch_size' => '1 Kit',
                    'testing_date' => '16/09/2026',
                ],
                $payload
            );
            adaCareioAssert(
                str_contains(coaTemplateRender($form, true), 'data-coa-template="1"'),
                "ADA product {$productId} {$coaType} COA did not render."
            );
        }
    }

    $fallbackRequirements = bmrBprResolveProductDocumentRequirements($conn, 416, '50 mL');
    $fallbackCounts = bmrBprDocumentRequirementCounts(
        bmrBprNormalizeDocumentRequirements($fallbackRequirements, 1, 1)
    );
    adaCareioAssert(
        $fallbackCounts === ['BMR' => 2, 'BPR' => 1]
            && str_starts_with(
                (string) ($fallbackRequirements['BMR'][0]['template_code'] ?? ''),
                'COMMON_BIOCHEMISTRY_'
            ),
        'ADA 50 mL did not retain the existing product-level fallback.'
    );

    $requestResult = $conn->query(
        "SELECT id, product_id, product_name, pack_size, bmr_form_count, bpr_form_count
         FROM bmr_bpr_requests
         WHERE product_id IN (415, 417, 418)
           AND status = 'UPCOMING' AND deleted_at IS NULL
         ORDER BY id DESC LIMIT 1"
    );
    $request = $requestResult ? $requestResult->fetch_assoc() : null;
    if ($request) {
        $requestId = (int) $request['id'];
        $beforeResult = $conn->query(
            "SELECT COUNT(*) AS total FROM bmr_bpr_request_documents WHERE request_id = {$requestId}"
        );
        $beforeCount = (int) ($beforeResult->fetch_assoc()['total'] ?? 0);
        $conn->begin_transaction();
        try {
            $packSize = bmrBprResolveProductPackSize(
                $conn,
                (int) $request['product_id'],
                (string) $request['product_name'],
                (string) ($request['pack_size'] ?? '')
            );
            $snapshotCounts = bmrBprSnapshotProductDocumentRequirements(
                $conn,
                $requestId,
                (int) $request['product_id'],
                (int) $request['bmr_form_count'],
                (int) $request['bpr_form_count'],
                1,
                $packSize
            );
            adaCareioAssert(
                $snapshotCounts === ['BMR' => 2, 'BPR' => 1],
                'The upcoming ADA request did not snapshot two BMRs and one BPR.'
            );
            $snapshotResult = $conn->query(
                "SELECT document.form_type, document.document_sequence, template.template_code
                 FROM bmr_bpr_request_documents document
                 INNER JOIN bmr_templates template ON template.id = document.template_id
                 WHERE document.request_id = {$requestId}
                 ORDER BY document.form_type, document.document_sequence"
            );
            $snapshotCodes = [];
            while ($row = $snapshotResult->fetch_assoc()) {
                $snapshotCodes[] = $row['template_code'];
            }
            adaCareioAssert(
                $snapshotCodes === [
                    'ADA_PACK_SIZE_BMR_01_V01',
                    'ADA_PACK_SIZE_BMR_02_V01',
                    'ADA_PACK_SIZE_BPR_V01',
                ],
                'The upcoming ADA request selected the wrong pack-size templates.'
            );
        } finally {
            $conn->rollback();
        }
        $afterResult = $conn->query(
            "SELECT COUNT(*) AS total FROM bmr_bpr_request_documents WHERE request_id = {$requestId}"
        );
        adaCareioAssert(
            (int) ($afterResult->fetch_assoc()['total'] ?? 0) === $beforeCount,
            'The rollback snapshot test changed the live ADA request.'
        );
    }

    echo 'ADA CareIO workflow smoke test passed: existing fallback preserved; '
        . '3 approved pack sizes resolve distinct R1/R2 BMRs, one pack-size BPR, IP COA and FG COA.'
        . PHP_EOL;
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
