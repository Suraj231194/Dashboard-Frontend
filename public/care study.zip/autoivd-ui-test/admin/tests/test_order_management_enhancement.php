<?php
declare(strict_types=1);

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';

$failures = [];

echo "Running Order Management Enhancement Verification Tests...\n";

// Test 1: Validate HTML DOM components in order-received.php
$pageContent = file_get_contents(__DIR__ . '/../pages/order-received.php');
if ($pageContent === false) {
    $failures[] = 'Failed to read admin/pages/order-received.php';
} else {
    $requiredElements = [
        '#newOrdersBanner' => 'id="newOrdersBanner"',
        '#goodsReceivedReservedBanner' => 'id="goodsReceivedReservedBanner"',
        '#goodsReceivedReservedOrdersCount' => 'id="goodsReceivedReservedOrdersCount"',
        '#goodsReceivedReservedModal' => 'id="goodsReceivedReservedModal"',
        '#grrClosedOrdersBadge' => 'id="grrClosedOrdersBadge"',
        '#grrClosedOrdersCount' => 'id="grrClosedOrdersCount"',
        '#grrProcuredItemsBadge' => 'id="grrProcuredItemsBadge"',
        '#grrProcuredItemsCount' => 'id="grrProcuredItemsCount"',
        '#grrProducedBatchesBadge' => 'id="grrProducedBatchesBadge"',
        '#grrProducedBatchesCount' => 'id="grrProducedBatchesCount"',
        '#grrFilterAllCount' => 'id="grrFilterAllCount"',
        '#grrFilterPoCount' => 'id="grrFilterPoCount"',
        '#grrFilterBmrCount' => 'id="grrFilterBmrCount"',
        '#grrSearchInput' => 'id="grrSearchInput"',
        '#grrTableBody' => 'id="grrTableBody"',
        '#processOrderActionModal' => 'id="processOrderActionModal"',
        '#processOrderNoText' => 'id="processOrderNoText"',
        '#summaryOrderNo' => 'id="summaryOrderNo"',
        '#summaryClientName' => 'id="summaryClientName"',
        '#summaryItemQty' => 'id="summaryItemQty"',
        '#summaryStockStatus' => 'id="summaryStockStatus"',
        '#confirmGoodsDispatchedBtn' => 'id="confirmGoodsDispatchedBtn"',
        '#cancelReservedOrderBtn' => 'id="cancelReservedOrderBtn"',
        '#backToGrrListBtn' => 'id="backToGrrListBtn"',
    ];

    foreach ($requiredElements as $name => $snippet) {
        if (strpos($pageContent, $snippet) === false) {
            $failures[] = "Missing DOM element in order-received.php: {$name}";
        }
    }
}

// Test 2: Verify mvGetGoodsReceivedReservedList execution & payload structure
try {
    $grrData = mvGetGoodsReceivedReservedList($conn);
    if (!isset($grrData['records']) || !is_array($grrData['records'])) {
        $failures[] = 'mvGetGoodsReceivedReservedList did not return a records array.';
    }
    if (!isset($grrData['stats']) || !is_array($grrData['stats'])) {
        $failures[] = 'mvGetGoodsReceivedReservedList did not return a stats array.';
    } else {
        $expectedStats = ['closed_orders_count', 'procured_items_count', 'produced_batches_count', 'total_count'];
        foreach ($expectedStats as $statKey) {
            if (!array_key_exists($statKey, $grrData['stats'])) {
                $failures[] = "Missing stat key in mvGetGoodsReceivedReservedList: {$statKey}";
            }
        }
    }
    echo "mvGetGoodsReceivedReservedList returned " . count($grrData['records']) . " records and stats: " . json_encode($grrData['stats']) . "\n";
} catch (Throwable $e) {
    $failures[] = 'mvGetGoodsReceivedReservedList threw exception: ' . $e->getMessage();
}

// Test 3: Verify AJAX endpoints registered in ajax.php
$ajaxContent = file_get_contents(__DIR__ . '/../ajax.php');
if ($ajaxContent === false) {
    $failures[] = 'Failed to read admin/ajax.php';
} else {
    $ajaxEndpoints = [
        'loadGoodsReceivedReservedData',
        'dispatchReservedOrderRecord',
        'cancelReservedOrderRecord',
    ];
    foreach ($ajaxEndpoints as $endpoint) {
        if (strpos($ajaxContent, $endpoint) === false) {
            $failures[] = "Missing AJAX endpoint in ajax.php: {$endpoint}";
        }
    }
}

if (!empty($failures)) {
    echo "TEST FAILURES (" . count($failures) . "):\n";
    foreach ($failures as $failure) {
        echo " - " . $failure . "\n";
    }
    exit(1);
}

echo "All Order Management Enhancement verification tests passed successfully!\n";
exit(0);
