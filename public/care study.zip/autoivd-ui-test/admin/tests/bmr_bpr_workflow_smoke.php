<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$definitions = bmrBprConfiguredWorkItemDefinitions(3, 2);
$assert(count($definitions) === 5, 'Configured counts do not create three BMR and two BPR definitions.');
$assert(
    $definitions[0] === ['form_type' => 'BMR', 'form_sequence' => 1]
        && $definitions[2] === ['form_type' => 'BMR', 'form_sequence' => 3]
        && $definitions[3] === ['form_type' => 'BPR', 'form_sequence' => 1]
        && $definitions[4] === ['form_type' => 'BPR', 'form_sequence' => 2],
    'Configured work-item sequences are not deterministic.'
);
$assert(
    bmrBprWorkItemTransition('QUEUED', 'GET_FORM') === 'PENDING',
    'Get Form does not perform the Queued-to-Pending transition.'
);
$assert(
    bmrBprWorkItemTransition('PENDING', 'DRAFT') === 'IN_PROCESS',
    'Save Draft does not perform the Pending-to-In-Process transition.'
);
$assert(
    bmrBprWorkItemTransition('IN_PROCESS', 'SUBMIT') === 'COMPLETE',
    'Submit does not perform the In-Process-to-Complete transition.'
);
$invalidTransitionBlocked = false;
try {
    bmrBprWorkItemTransition('QUEUED', 'SUBMIT');
} catch (DomainException) {
    $invalidTransitionBlocked = true;
}
$assert($invalidTransitionBlocked, 'A queued work item can be submitted without Get Form.');
$assert(
    !bmrBprBmrStatusesReady([]) && !bmrBprBmrStatusesReady(['IN_PROCESS', 'PENDING']),
    'The BPR gate allows a request with no BMR or an unfinished BMR.'
);
$assert(
    !bmrBprBmrStatusesReady(['IN_PROCESS', 'COMPLETE'])
        && bmrBprBmrStatusesReady(['COMPLETE', 'COMPLETE']),
    'The BPR gate does not require every configured BMR to be complete.'
);

$requiredTables = [
    'bmr_bpr_requests',
    'bmr_bpr_work_items',
    'bmr_bpr_workflow_history',
    'bmr_templates',
    'bmr_template_product_mappings',
    'bmr_bpr_request_documents',
];
foreach ($requiredTables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
    $assert($result && $result->num_rows === 1, "Missing workflow table: {$table}.");
}

$requestCountColumns = $conn->query(
    "SELECT COUNT(*) AS total
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'bmr_bpr_requests'
       AND COLUMN_NAME IN ('bmr_form_count', 'bpr_form_count')"
);
$assert(
    (int) (($requestCountColumns ? $requestCountColumns->fetch_assoc()['total'] ?? 0 : 0)) === 2,
    'Separate BMR/BPR configured-count snapshots are missing.'
);

$sequenceColumn = $conn->query("SHOW COLUMNS FROM bmr_bpr_work_items LIKE 'form_sequence'");
$statusColumn = $conn->query("SHOW COLUMNS FROM bmr_bpr_work_items LIKE 'status'");
$statusDefinition = $statusColumn ? $statusColumn->fetch_assoc() : null;
$assert($sequenceColumn && $sequenceColumn->num_rows === 1, 'Work items do not have a form sequence.');
$assert(
    $statusDefinition && str_contains(strtoupper((string) $statusDefinition['Type']), "'QUEUED'"),
    'Work-item status does not support the pre-Get-Form Queued state.'
);

$templateColumns = $conn->query(
    "SELECT COUNT(*) AS total
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'bmr_templates'
       AND COLUMN_NAME IN (
           'form_type', 'template_code', 'document_no', 'source_pdf_path',
           'page_asset_path', 'source_checksum', 'page_count', 'layout_json'
       )"
);
$assert(
    (int) (($templateColumns ? $templateColumns->fetch_assoc()['total'] ?? 0 : 0)) === 8,
    'The product-specific BMR/BPR template columns are incomplete.'
);

$requirementColumns = $conn->query(
    "SELECT COUNT(*) AS total
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'bmr_template_product_mappings'
       AND COLUMN_NAME IN ('document_sequence', 'required_quantity')"
);
$assert(
    (int) (($requirementColumns ? $requirementColumns->fetch_assoc()['total'] ?? 0 : 0)) === 2,
    'Product document sequences or independent required quantities are missing.'
);

$requestSourceColumn = $conn->query(
    "SHOW COLUMNS FROM ip_coa_generation LIKE 'source_bmr_bpr_request_id'"
);
$assert(
    $requestSourceColumn && $requestSourceColumn->num_rows === 1,
    'IP COA records do not have a request-level workflow source.'
);

$templateCatalog = $conn->query(
    "SELECT id, template_code, form_type, page_asset_path, page_count, layout_json
     FROM bmr_templates
     WHERE template_code IS NOT NULL AND status = 1 AND deleted_at IS NULL"
);
$templateRows = $templateCatalog ? $templateCatalog->fetch_all(MYSQLI_ASSOC) : [];
$assert(count($templateRows) >= 2, 'The approved template catalog is missing BMR/BPR templates.');
$structuredTemplateCodes = [];
foreach ($templateRows as $templateRow) {
    $layout = json_decode((string) ($templateRow['layout_json'] ?? ''), true);
    if (bmrBprIsStructuredLayout(is_array($layout) ? $layout : [])) {
        $structuredTemplateCodes[] = (string) $templateRow['template_code'];
        $profiles = is_array($layout['profiles'] ?? null) ? $layout['profiles'] : [];
        $assert(
            $profiles !== [],
            "Structured template {$templateRow['template_code']} has no product profiles."
        );
        $assert(
            empty($templateRow['page_asset_path']),
            "Structured template {$templateRow['template_code']} unexpectedly depends on page images."
        );
        foreach ($profiles as $productId => $profile) {
            $profilePageCount = (int) ($profile['page_count'] ?? 0);
            $assert(
                $profilePageCount > 0 && $profilePageCount <= (int) ($templateRow['page_count'] ?? 0),
                "Structured template {$templateRow['template_code']} has invalid pagination for product {$productId}."
            );
        }
        continue;
    }
    $pages = is_array($layout['pages'] ?? null) ? $layout['pages'] : [];
    $assert(
        count($pages) === (int) ($templateRow['page_count'] ?? 0),
        "Template {$templateRow['template_code']} has an invalid page layout."
    );
    foreach ($pages as $page) {
        $imagePath = dirname(__DIR__, 2)
            . '/'
            . trim((string) $templateRow['page_asset_path'], '/')
            . '/'
            . basename((string) ($page['image'] ?? ''));
        $assert(
            is_file($imagePath),
            "Template {$templateRow['template_code']} is missing page asset " . ($page['image'] ?? '') . '.'
        );
    }
}
$assert(
    in_array('COMMON_HEMATOLOGY_BMR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_HEMATOLOGY_BPR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_SEROLOGY_BMR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_SEROLOGY_BPR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_MICROBIOLOGY_BMR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_MICROBIOLOGY_BPR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_UROLOGY_BMR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_UROLOGY_GLUCOSE_UNCUT_BMR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_UROLOGY_PROTEIN_UNCUT_BMR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_UROLOGY_BPR_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_BIOCHEMISTRY_BMR_01_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_BIOCHEMISTRY_BMR_02_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_BIOCHEMISTRY_BMR_03_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_BIOCHEMISTRY_BMR_04_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_BIOCHEMISTRY_BPR_01_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_BIOCHEMISTRY_BPR_02_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_RAPID_BMR_01_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_RAPID_BMR_02_V03', $structuredTemplateCodes, true)
        && in_array('COMMON_RAPID_BPR_01_V03', $structuredTemplateCodes, true),
    'The common structured Hematology, Serology, Microbiology, Urology and Biochemistry BMR/BPR templates are not all active.'
);

$mappingCount = $conn->query(
    "SELECT COUNT(*) AS total
     FROM bmr_template_product_mappings
     WHERE status = 1 AND deleted_at IS NULL"
);
$assert(
    (int) (($mappingCount ? $mappingCount->fetch_assoc()['total'] ?? 0 : 0)) >= 86,
    'The confirmed product-to-BMR/BPR template mapping set is incomplete.'
);

$sanitizedPayload = bmrBprSanitizeTemplatePayload(
    [
        'allow_custom_fields' => true,
        'pages' => [[
            'page' => 1,
            'fields' => [
                ['id' => 'editable', 'editable' => true, 'source' => null],
                ['id' => 'locked', 'editable' => false, 'source' => 'product_name'],
            ],
        ]],
    ],
    [
        'fields' => [
            'editable' => 'Accepted value',
            'locked' => 'Browser override',
            'unknown' => 'Unknown field',
        ],
        'custom_fields' => [[
            'page' => 1,
            'x' => 10,
            'y' => 20,
            'w' => 25,
            'h' => 4,
            'value' => 'Positioned value',
        ]],
    ]
);
$assert(
    ($sanitizedPayload['fields'] ?? []) === ['editable' => 'Accepted value']
        && count($sanitizedPayload['custom_fields'] ?? []) === 1,
    'Template payload validation accepts server-controlled or unknown fields.'
);

$structuredPayload = bmrBprSanitizeTemplatePayload(
    [
        'schema_version' => 2,
        'renderer' => 'structured_html',
        'editable_prefixes' => ['cover.', 'rm.'],
    ],
    [
        'schema_version' => 2,
        'fields' => [
            'cover.mfg_date' => '28/07/2026',
            'rm.sodium_chloride.actual_qty' => '100',
            'product_name' => 'Browser override',
            'qa.unapproved' => 'Unknown prefix',
        ],
    ]
);
$assert(
    ($structuredPayload['fields'] ?? []) === [
        'cover.mfg_date' => '28/07/2026',
        'rm.sodium_chloride.actual_qty' => '100',
    ],
    'Structured template payload validation accepts a locked or unapproved field.'
);

$sequenceIndex = $conn->query(
    "SHOW INDEX FROM bmr_bpr_work_items WHERE Key_name = 'uq_bmr_bpr_work_item_sequence'"
);
$sequenceIndexRows = $sequenceIndex ? $sequenceIndex->fetch_all(MYSQLI_ASSOC) : [];
$assert(
    count($sequenceIndexRows) === 3
        && (int) ($sequenceIndexRows[0]['Non_unique'] ?? 1) === 0
        && array_column($sequenceIndexRows, 'Column_name') === ['request_id', 'form_type', 'form_sequence'],
    'The request/type/sequence idempotency key is missing or invalid.'
);

$documentIndex = $conn->query(
    "SHOW INDEX FROM bmr_template_product_mappings
     WHERE Key_name = 'uq_bmr_template_product_document'"
);
$documentIndexRows = $documentIndex ? $documentIndex->fetch_all(MYSQLI_ASSOC) : [];
$assert(
    count($documentIndexRows) === 3
        && (int) ($documentIndexRows[0]['Non_unique'] ?? 1) === 0
        && array_column($documentIndexRows, 'Column_name')
            === ['product_id', 'form_type', 'document_sequence'],
    'Multiple product document mappings do not have the expected idempotency key.'
);

$requestDocumentIndex = $conn->query(
    "SHOW INDEX FROM bmr_bpr_request_documents
     WHERE Key_name = 'uq_bmr_bpr_request_document'"
);
$requestDocumentIndexRows = $requestDocumentIndex
    ? $requestDocumentIndex->fetch_all(MYSQLI_ASSOC)
    : [];
$assert(
    count($requestDocumentIndexRows) === 3
        && (int) ($requestDocumentIndexRows[0]['Non_unique'] ?? 1) === 0
        && array_column($requestDocumentIndexRows, 'Column_name')
            === ['request_id', 'form_type', 'document_sequence'],
    'Request document snapshots do not have the expected idempotency key.'
);

$ipRequestIndex = $conn->query(
    "SHOW INDEX FROM ip_coa_generation WHERE Key_name = 'uq_ip_coa_source_request'"
);
$ipRequestIndexRows = $ipRequestIndex ? $ipRequestIndex->fetch_all(MYSQLI_ASSOC) : [];
$assert(
    count($ipRequestIndexRows) === 1
        && (int) ($ipRequestIndexRows[0]['Non_unique'] ?? 1) === 0
        && ($ipRequestIndexRows[0]['Column_name'] ?? '') === 'source_bmr_bpr_request_id',
    'Request-level IP COA idempotency is not enforced by the database.'
);

$requiredPermissions = [
    'qa_qc_bmr_bpr_form_request_view',
    'qa_qc_bmr_bpr_form_request_manage',
    'qa_qc_bmr_bpr_issuance_view',
    'qa_qc_bmr_bpr_issuance_review',
    'production_bmr_bpr_view',
    'production_bmr_bpr_manage',
    'ip_coa_generation_menu_list',
    'ip_coa_generation_add',
    'fg_coa_generation_menu_list',
    'fg_coa_generation_add',
    'transfer_ticket_menu_list',
    'transfer_ticket_add',
];
$quotedPermissions = implode(
    ',',
    array_map(
        static fn(string $slug): string => "'" . $conn->real_escape_string($slug) . "'",
        $requiredPermissions
    )
);
$permissionResult = $conn->query(
    "SELECT COUNT(DISTINCT slug) AS total
     FROM permissions
     WHERE status = 1 AND slug IN ({$quotedPermissions})"
);
$assert(
    (int) (($permissionResult ? $permissionResult->fetch_assoc()['total'] ?? 0 : 0))
        === count($requiredPermissions),
    'The workflow permission set is incomplete.'
);

$handler = file_get_contents(dirname(__DIR__) . '/workflow/bmr_bpr_actions.php');
$assert(
    $handler !== false
        && str_contains($handler, 'bmrBprEnsureConfiguredWorkItems')
        && str_contains($handler, "'QUEUED'")
        && str_contains($handler, "'GET_FORM'")
        && str_contains($handler, 'Complete every configured BMR')
        && str_contains($handler, 'bmrBprRequestHasApprovedIpCoa')
        && str_contains($handler, 'source_bmr_bpr_request_id'),
    'The workflow handler is missing configured forms, first-open transition, BPR gate or request-level IP idempotency.'
);

$ajax = file_get_contents(dirname(__DIR__) . '/ajax.php');
$manualStart = $ajax === false ? false : strpos($ajax, 'if (isset($_POST["addMaterialRequisitionForm"])');
$manualEnd = $ajax === false ? false : strpos($ajax, 'if (isset($_POST["loadMaterialRequisition"])', (int) $manualStart);
$manualSection = $manualStart !== false && $manualEnd !== false
    ? substr($ajax, $manualStart, $manualEnd - $manualStart)
    : '';
$beginPosition = strpos($manualSection, '$conn->begin_transaction()');
$insertPosition = strpos($manualSection, "insertRecordIntoTable(\$conn, 'material_requisition'");
$commitPosition = strrpos($manualSection, '$conn->commit()');
$assert(
    $beginPosition !== false
        && $insertPosition !== false
        && $commitPosition !== false
        && $beginPosition < $insertPosition
        && $insertPosition < $commitPosition
        && !str_contains($manualSection, 'bmrBprEnsureRequestForMaterialRequisition')
        && !str_contains($manualSection, 'catch (Throwable $workflowException)'),
    'Manual Material Requisition still queues controlled documents before Stores issues every item.'
);

$issueStart = $ajax === false ? false : strpos($ajax, 'if (isset($_POST["issueBomItems"])');
$issueEnd = $ajax === false ? false : strpos($ajax, 'if (isset($_POST["generateBomFromPlan"])', (int) $issueStart);
$issueSection = $issueStart !== false && $issueEnd !== false
    ? substr($ajax, $issueStart, $issueEnd - $issueStart)
    : '';
$issueCompletePosition = strpos($issueSection, '$newReqStatus = $remainingRows === 0 ? 1 : 0;');
$workflowPosition = strpos($issueSection, 'bmrBprEnsureRequestForMaterialRequisition');
$issueCommitPosition = strpos($issueSection, '$conn->commit()');
$assert(
    $issueCompletePosition !== false
        && $workflowPosition !== false
        && $issueCommitPosition !== false
        && $issueCompletePosition < $workflowPosition
        && $workflowPosition < $issueCommitPosition,
    'Controlled BMR/BPR documents are not queued atomically after complete material issuance.'
);

$eventRefreshPages = [
    'bmr-bpr-form-request.php',
    'bmr-bpr-issuance.php',
    'production-bmr-bpr.php',
    'ip-coa-generation.php',
    'fg-coa-generation.php',
    'transfer-ticket.php',
];
foreach ($eventRefreshPages as $page) {
    $source = file_get_contents(dirname(__DIR__) . '/pages/' . $page);
    $assert(
        $source !== false
            && str_contains($source, 'visibilitychange')
            && !str_contains($source, 'setInterval'),
        "Event-driven widget refresh is missing or polling is enabled in {$page}."
    );
}

$chainResult = $conn->query(
    "SELECT COUNT(DISTINCT r.id) AS total
     FROM bmr_bpr_requests r
     INNER JOIN bmr_bpr_work_items bmr
        ON bmr.request_id = r.id AND bmr.form_type = 'BMR' AND bmr.deleted_at IS NULL
     INNER JOIN ip_coa_generation ip
        ON ip.source_bmr_work_item_id = bmr.id AND ip.deleted_at IS NULL
     INNER JOIN fg_coa_generation fg
        ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
     INNER JOIN transfer_ticket tt
        ON tt.source_fg_coa_id = fg.id AND tt.deleted_at IS NULL
     WHERE r.deleted_at IS NULL"
);
$assert(
    (int) (($chainResult ? $chainResult->fetch_assoc()['total'] ?? 0 : 0)) > 0,
    'No complete MR-to-Transfer workflow chain is available for integration validation.'
);

$rejectionLeak = $conn->query(
    "SELECT COUNT(*) AS total
     FROM bmr_bpr_requests r
     INNER JOIN bmr_bpr_work_items wi
        ON wi.request_id = r.id AND wi.deleted_at IS NULL
     WHERE r.status = 'REJECTED' AND r.deleted_at IS NULL"
);
$assert(
    (int) (($rejectionLeak ? $rejectionLeak->fetch_assoc()['total'] ?? 0 : 0)) === 0,
    'A rejected request has entered the Production workflow.'
);

$requestResult = $conn->query(
    "SELECT r.id AS request_id, r.form_count, COALESCE(r.created_by, 1) AS user_id
     FROM bmr_bpr_requests r
     INNER JOIN bmr_bpr_work_items wi
        ON wi.request_id = r.id AND wi.deleted_at IS NULL
     WHERE r.deleted_at IS NULL
       AND NOT EXISTS (
           SELECT 1
           FROM ip_coa_generation ip
           LEFT JOIN bmr_bpr_work_items source_item
              ON source_item.id = ip.source_bmr_work_item_id
           WHERE ip.deleted_at IS NULL
             AND (
                 ip.source_bmr_bpr_request_id = r.id
                 OR (
                     ip.source_bmr_bpr_request_id IS NULL
                     AND source_item.request_id = r.id
                 )
             )
       )
     GROUP BY r.id, r.form_count, r.created_by
     ORDER BY r.id
     LIMIT 1"
);
$testRequest = $requestResult ? $requestResult->fetch_assoc() : null;
$assert($testRequest !== null, 'No workflow request is available for rollback-only idempotency validation.');
if ($testRequest) {
    $requestId = (int) $testRequest['request_id'];
    $formCount = max(1, (int) $testRequest['form_count']);
    $userId = max(1, (int) $testRequest['user_id']);
    $beforeStmt = $conn->prepare(
        "SELECT COUNT(*) AS total
         FROM bmr_bpr_work_items
         WHERE request_id = ?"
    );
    $beforeStmt->bind_param('i', $requestId);
    $beforeStmt->execute();
    $beforeCount = (int) ($beforeStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $beforeStmt->close();
    $evidenceBefore = $conn->query(
        "SELECT COUNT(*) AS total
         FROM bmr_bpr_workflow_history
         WHERE action_name IN ('GET_FORM', 'SAVE_DRAFT', 'REJECT_ISSUANCE')"
    );
    $evidenceBeforeCount = (int) (
        ($evidenceBefore ? $evidenceBefore->fetch_assoc()['total'] ?? 0 : 0)
    );

    try {
        $conn->begin_transaction();
        $mappedProductId = 1045;
        $mapRequest = $conn->prepare(
            'UPDATE bmr_bpr_requests SET product_id = ? WHERE id = ?'
        );
        $mapRequest->bind_param('ii', $mappedProductId, $requestId);
        $mapRequest->execute();
        $mapRequest->close();
        $clearSnapshots = $conn->prepare(
            'DELETE FROM bmr_bpr_request_documents WHERE request_id = ?'
        );
        $clearSnapshots->bind_param('i', $requestId);
        $clearSnapshots->execute();
        $clearSnapshots->close();
        $clearWorkItems = $conn->prepare(
            'DELETE FROM bmr_bpr_work_items WHERE request_id = ?'
        );
        $clearWorkItems->bind_param('i', $requestId);
        $clearWorkItems->execute();
        $clearWorkItems->close();

        $baseTemplates = $conn->query(
            "SELECT mapping.form_type, mapping.template_id
             FROM bmr_template_product_mappings mapping
             WHERE mapping.product_id = {$mappedProductId}
               AND mapping.document_sequence = 1
               AND mapping.status = 1
               AND mapping.deleted_at IS NULL"
        );
        $baseTemplateRows = $baseTemplates ? $baseTemplates->fetch_all(MYSQLI_ASSOC) : [];
        $baseTemplateIds = [];
        foreach ($baseTemplateRows as $baseTemplateRow) {
            $baseTemplateIds[strtoupper((string) $baseTemplateRow['form_type'])]
                = (int) $baseTemplateRow['template_id'];
        }
        $assert(
            !empty($baseTemplateIds['BMR']) && !empty($baseTemplateIds['BPR']),
            'The rollback test product does not have both base document mappings.'
        );

        $quantityStmt = $conn->prepare(
            "UPDATE bmr_template_product_mappings
             SET required_quantity = CASE form_type WHEN 'BMR' THEN 2 ELSE 4 END
             WHERE product_id = ? AND document_sequence = 1
               AND status = 1 AND deleted_at IS NULL"
        );
        $quantityStmt->bind_param('i', $mappedProductId);
        $quantityStmt->execute();
        $quantityStmt->close();

        $alternativeBmr = $conn->query(
            "SELECT id
             FROM bmr_templates
             WHERE form_type = 'BMR'
               AND id <> " . (int) ($baseTemplateIds['BMR'] ?? 0) . "
               AND status = 1
               AND deleted_at IS NULL
             ORDER BY id
             LIMIT 1"
        );
        $alternativeBmrId = (int) (
            ($alternativeBmr ? $alternativeBmr->fetch_assoc()['id'] ?? 0 : 0)
        );
        $extraMapping = $conn->prepare(
            "INSERT INTO bmr_template_product_mappings
                (template_id, product_id, form_type, document_sequence, required_quantity,
                 status, created_by, created_at)
             VALUES (?, ?, 'BMR', 2, 1, 1, ?, NOW())"
        );
        $extraMapping->bind_param('iii', $alternativeBmrId, $mappedProductId, $userId);
        $extraMapping->execute();
        $extraMapping->close();

        $configuredCounts = bmrBprSnapshotProductDocumentRequirements(
            $conn,
            $requestId,
            $mappedProductId,
            $formCount,
            $formCount,
            $userId
        );
        $assert(
            $configuredCounts === ['BMR' => 3, 'BPR' => 4],
            'Independent configured BMR and BPR quantities were not snapshotted.'
        );

        bmrBprEnsureConfiguredWorkItems($conn, $requestId, 3, 4, $userId);
        bmrBprEnsureConfiguredWorkItems($conn, $requestId, 3, 4, $userId);

        $configuredStmt = $conn->prepare(
            "SELECT COUNT(*) AS total
             FROM bmr_bpr_work_items
             WHERE request_id = ?"
        );
        $configuredStmt->bind_param('i', $requestId);
        $configuredStmt->execute();
        $configuredCount = (int) ($configuredStmt->get_result()->fetch_assoc()['total'] ?? 0);
        $configuredStmt->close();
        $assert(
            $configuredCount === 7,
            'Configured quantity creation did not produce exactly three BMR and four BPR items.'
        );

        $mappedStmt = $conn->prepare(
            "SELECT COUNT(*) AS total, COUNT(DISTINCT CASE
                    WHEN wi.form_type = 'BMR' THEN wi.template_id
                END) AS distinct_bmr_templates
             FROM bmr_bpr_work_items wi
             INNER JOIN bmr_templates template ON template.id = wi.template_id
             WHERE wi.request_id = ?
               AND template.form_type = wi.form_type
               AND template.status = 1
               AND template.deleted_at IS NULL"
        );
        $mappedStmt->bind_param('i', $requestId);
        $mappedStmt->execute();
        $mappedResult = $mappedStmt->get_result()->fetch_assoc();
        $mappedCount = (int) ($mappedResult['total'] ?? 0);
        $distinctBmrTemplates = (int) ($mappedResult['distinct_bmr_templates'] ?? 0);
        $mappedStmt->close();
        $assert(
            $mappedCount === 7 && $distinctBmrTemplates === 2,
            'Configured workflow items do not receive the product-specific BMR/BPR templates.'
        );

        $formStmt = $conn->prepare(
            "SELECT id
             FROM bmr_bpr_work_items
             WHERE request_id = ? AND form_type = 'BMR'
             ORDER BY form_sequence
             LIMIT 1"
        );
        $formStmt->bind_param('i', $requestId);
        $formStmt->execute();
        $mappedWorkItemId = (int) ($formStmt->get_result()->fetch_assoc()['id'] ?? 0);
        $formStmt->close();
        $loadedForm = $mappedWorkItemId > 0 ? bmrBprLoadWorkItemTemplate($conn, $mappedWorkItemId) : [];
        $assert(
            !empty($loadedForm['has_template'])
                && ($loadedForm['template_code'] ?? '') === 'COMMON_SEROLOGY_BMR_V03'
                && (int) ($loadedForm['schema_version'] ?? 0) === 2
                && !empty($loadedForm['profile'])
                && substr_count((string) ($loadedForm['rendered_html'] ?? ''), 'class="bmr-v2-page"') === 4
                && !empty($loadedForm['download_url']),
            'The mapped BMR template cannot be loaded for editing and download.'
        );

        $pendingStatus = bmrBprWorkItemTransition('QUEUED', 'GET_FORM');
        $pendingStmt = $conn->prepare(
            'UPDATE bmr_bpr_work_items SET status = ? WHERE id = ?'
        );
        $pendingStmt->bind_param('si', $pendingStatus, $mappedWorkItemId);
        $pendingStmt->execute();
        $pendingStmt->close();
        bmrBprInsertHistory(
            $conn,
            'WORK_ITEM',
            $mappedWorkItemId,
            'GET_FORM',
            'QUEUED',
            $pendingStatus,
            null,
            ['rollback_acceptance' => true],
            $userId
        );
        $draftStatus = bmrBprWorkItemTransition($pendingStatus, 'DRAFT');
        $draftStmt = $conn->prepare(
            'UPDATE bmr_bpr_work_items SET status = ? WHERE id = ?'
        );
        $draftStmt->bind_param('si', $draftStatus, $mappedWorkItemId);
        $draftStmt->execute();
        $draftStmt->close();
        bmrBprInsertHistory(
            $conn,
            'WORK_ITEM',
            $mappedWorkItemId,
            'SAVE_DRAFT',
            $pendingStatus,
            $draftStatus,
            null,
            ['rollback_acceptance' => true],
            $userId
        );

        $insertStmt = $conn->prepare(
            "INSERT INTO bmr_bpr_work_items
                (request_id, form_type, form_sequence, status, created_at)
             VALUES (?, 'BMR', 1, 'QUEUED', NOW())"
        );
        $insertStmt->bind_param('i', $requestId);
        $duplicateInsert = $insertStmt->execute();
        $duplicateError = (int) $insertStmt->errno;
        $insertStmt->close();
        $assert(
            !$duplicateInsert && $duplicateError === 1062,
            'Duplicate-click idempotency is not enforced by the database.'
        );

        $rejectRequest = $conn->query(
            "SELECT r.id
             FROM bmr_bpr_requests r
             WHERE r.status = 'SUBMITTED'
               AND r.deleted_at IS NULL
               AND NOT EXISTS (
                   SELECT 1 FROM bmr_bpr_work_items wi
                   WHERE wi.request_id = r.id AND wi.deleted_at IS NULL
               )
             ORDER BY r.id
             LIMIT 1
             FOR UPDATE"
        );
        $rejectRequestId = (int) (
            ($rejectRequest ? $rejectRequest->fetch_assoc()['id'] ?? 0 : 0)
        );
        $assert($rejectRequestId > 0, 'No submitted request is available for rejection validation.');
        if ($rejectRequestId > 0) {
            $rejectStmt = $conn->prepare(
                "UPDATE bmr_bpr_requests SET status = 'REJECTED' WHERE id = ?"
            );
            $rejectStmt->bind_param('i', $rejectRequestId);
            $rejectStmt->execute();
            $rejectStmt->close();
            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $rejectRequestId,
                'REJECT_ISSUANCE',
                'SUBMITTED',
                'REJECTED',
                'Rollback-only acceptance test.',
                ['rollback_acceptance' => true],
                $userId
            );
            $rejectLeakStmt = $conn->prepare(
                'SELECT COUNT(*) AS total FROM bmr_bpr_work_items WHERE request_id = ?'
            );
            $rejectLeakStmt->bind_param('i', $rejectRequestId);
            $rejectLeakStmt->execute();
            $rejectWorkItems = (int) (
                $rejectLeakStmt->get_result()->fetch_assoc()['total'] ?? 0
            );
            $rejectLeakStmt->close();
            $assert($rejectWorkItems === 0, 'The rollback rejection test created Production work items.');
        }

        $transitionEvidenceStmt = $conn->prepare(
            "SELECT COUNT(DISTINCT action_name) AS total
             FROM bmr_bpr_workflow_history
             WHERE action_name IN ('GET_FORM', 'SAVE_DRAFT', 'REJECT_ISSUANCE')
               AND payload_json LIKE '%rollback_acceptance%'"
        );
        $transitionEvidenceStmt->execute();
        $transitionEvidence = (int) (
            $transitionEvidenceStmt->get_result()->fetch_assoc()['total'] ?? 0
        );
        $transitionEvidenceStmt->close();
        $assert(
            $transitionEvidence === 3,
            'Rollback acceptance did not exercise Get Form, Save Draft and rejection history.'
        );
        $conn->rollback();
    } catch (Throwable $error) {
        $conn->rollback();
        $failures[] = 'Rollback-only configured-form validation failed: ' . $error->getMessage();
    }

    $afterStmt = $conn->prepare(
        "SELECT COUNT(*) AS total
         FROM bmr_bpr_work_items
         WHERE request_id = ?"
    );
    $afterStmt->bind_param('i', $requestId);
    $afterStmt->execute();
    $afterCount = (int) ($afterStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $afterStmt->close();
    $assert($beforeCount === $afterCount, 'The rollback-only workflow test retained configured work items.');
    $evidenceAfter = $conn->query(
        "SELECT COUNT(*) AS total
         FROM bmr_bpr_workflow_history
         WHERE action_name IN ('GET_FORM', 'SAVE_DRAFT', 'REJECT_ISSUANCE')"
    );
    $evidenceAfterCount = (int) (
        ($evidenceAfter ? $evidenceAfter->fetch_assoc()['total'] ?? 0 : 0)
    );
    $assert(
        $evidenceBeforeCount === $evidenceAfterCount,
        'The rollback acceptance test retained workflow history.'
    );
}

if ($failures) {
    foreach ($failures as $failure) {
        fwrite(STDERR, "FAIL: {$failure}\n");
    }
    exit(1);
}

echo 'BMR/BPR workflow smoke checks passed: independent product quantities, multiple templates, request snapshots, first-open and draft history, rejection isolation, BPR gate, permissions, atomic MR handoff, request-level IP idempotency, linked chain, duplicate protection and rollback.' . PHP_EOL;
