<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$admin = dirname(__DIR__);
$root = dirname($admin);
$files = [
    'ajax' => (string) file_get_contents($admin . '/ajax.php'),
    'orders' => (string) file_get_contents($admin . '/pages/order-received.php'),
    'leave' => (string) file_get_contents($admin . '/pages/leave-management.php'),
    'hrmsApi' => (string) file_get_contents($admin . '/hrms-api.php'),
    'calendar' => (string) file_get_contents($admin . '/pages/annual-calendar.php'),
    'attendance' => (string) file_get_contents($admin . '/pages/attendance-management.php'),
    'payRuns' => (string) file_get_contents($admin . '/pages/payroll-pay-runs.php'),
    'advances' => (string) file_get_contents($admin . '/pages/payroll-advances.php'),
    'navbar' => (string) file_get_contents($admin . '/layout/navbar.php'),
    'profile' => (string) file_get_contents($admin . '/pages/profile.php'),
    'leads' => (string) file_get_contents($admin . '/pages/lead-management.php'),
    'quotes' => (string) file_get_contents($admin . '/pages/crm-quote-management.php'),
    'header' => (string) file_get_contents($admin . '/layout/header.php'),
    'theme' => (string) file_get_contents($root . '/assets/css/theme.css'),
    'issueCss' => (string) file_get_contents($root . '/assets/css/issue-3-fixes.css'),
];

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
    }
};

$assert(str_contains($files['orders'], "createProcurementFromOrder: 'createProcurementFromOrder'")
    && str_contains($files['ajax'], '"ssiidisii"'), 'Procurement creation must submit nested items with the correct bind types.');
$assert(str_contains($files['leave'], 'Allocated Leave by Employee')
    && str_contains($files['leave'], 'leaveAllocationSearch'), 'Leave allocations must be visible and searchable.');
$assert(str_contains($files['hrmsApi'], "case 'get_leave_balances':")
    && str_contains($files['leave'], "payload.set('action', 'get_leave_balances')"), 'Apply Leave must load the selected employee balance.');
$assert(str_contains($files['hrmsApi'], "genderEligibility === 'female'")
    && str_contains($files['leave'], 'data-gender-eligibility'), 'Leave allocation must enforce gender eligibility in the UI and API.');
$assert(str_contains($files['calendar'], '$currentYear - 10')
    && str_contains($files['calendar'], 'acOverrideLockHint')
    && str_contains($files['calendar'], "$('#acSaveOverrideBtn').prop('disabled', !canEditDraft)"), 'Calendar years and finalized override guidance must remain accessible.');
$assert(str_contains($files['attendance'], 'id="attendanceCompanyFilter"')
    && str_contains($files['attendance'], 'id="attendanceBranchFilter"')
    && str_contains($files['attendance'], 'attendanceBranchOptions')
    && str_contains($files['attendance'], "\$pastSql .= ' AND company_id = ?'")
    && str_contains($files['attendance'], '[data-company-collapse]'), 'Attendance filters, report scope, and company drilldown must remain functional.');
$assert(str_contains($files['payRuns'], 'id="payRunPreviewSearch"')
    && str_contains($files['payRuns'], 'generateButton.disabled=data.validation.length>0'), 'Pay Run search and validation guard must remain active.');
$assert(str_contains($files['advances'], 'required disabled')
    && str_contains($files['advances'], ".prop('disabled',!type.value).trigger('change')"), 'Advance employee selection must wait for the employee type.');
$assert(str_contains($files['navbar'], "canDoThis('payroll_reimbursements_view')")
    && str_contains($files['profile'], '$navbar_claim_href'), 'Reimbursement shortcuts must handle unlinked user accounts.');
$assert(substr_count($files['leads'], 'issue3-lead-filter-control') === 4, 'Lead filter controls must use the dedicated alignment class.');
$assert(str_contains($files['quotes'], 'issue3-quote-modal-body')
    && str_contains($files['leave'], 'issue3-leave-date-rows')
    && str_contains($files['header'], 'assets/css/issue-3-fixes.css')
    && str_contains($files['issueCss'], '.issue3-modal-form')
    && !str_contains($files['theme'], 'issue3-'), 'Issue-specific modal styles must stay in the separate stylesheet.');

if ($failures) {
    fwrite(STDERR, "Issue 3 regression contract failed:\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "Issue 3 regression contract passed.\n";
