<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';

echo "======================================================================\n";
echo "   BMR/BPR FORM REQUEST TEMPLATES & STEP 7-9 INCOMING BPR TEST        \n";
echo "======================================================================\n\n";

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) {
        $failures[] = $message;
        echo "  [FAILED] $message\n";
    } else {
        echo "  [PASSED] $message\n";
    }
};

// TEST 1: Verify bmrBprGetRankedTemplates returns templates
echo "TEST 1: Verify bmrBprGetRankedTemplates...\n";
$ranked = bmrBprGetRankedTemplates($conn, 0, '', '');
$assert(isset($ranked['BMR']) && is_array($ranked['BMR']), 'Ranked templates must contain BMR list.');
$assert(isset($ranked['BPR']) && is_array($ranked['BPR']), 'Ranked templates must contain BPR list.');
$assert(count($ranked['BMR']) > 0, 'BMR list must not be empty.');
$assert(count($ranked['BPR']) > 0, 'BPR list must not be empty.');

$mappedCatalog = bmrBprGetMappedProductCatalog($conn);
$assert(count($mappedCatalog['template_products']['BMR'] ?? []) === 243, 'The BMR dropdown catalog must contain the 243 active source-backed product entries.');
$assert(count($mappedCatalog['template_products']['BPR'] ?? []) === 239, 'The BPR dropdown catalog must contain the 239 active source-backed product entries.');
$catalogNames = array_merge(
    array_column($mappedCatalog['template_products']['BMR'] ?? [], 'product_name'),
    array_column($mappedCatalog['template_products']['BPR'] ?? [], 'product_name')
);
$assert(in_array('ADA 100 mL', $catalogNames, true), 'New source-backed Biochemistry products must appear in the template dropdown.');

// TEST 2: Verify keyword matching for recommended templates
echo "\nTEST 2: Verify keyword recommendations...\n";
$glucoseRanked = bmrBprGetRankedTemplates($conn, 0, '', 'Glucose Test Strip');
$recommendedBmrCount = count(array_filter($glucoseRanked['BMR'], static fn($t) => !empty($t['is_recommended'])));
$assert($recommendedBmrCount > 0, 'Templates matching "Glucose" should be flagged as recommended.');

// TEST 3: Verify bmr-bpr-form-request.php UI elements
echo "\nTEST 3: Verify bmr-bpr-form-request.php HTML & JS contracts...\n";
$formRequestPath = dirname(__DIR__) . '/pages/bmr-bpr-form-request.php';
$formRequestContent = (string) file_get_contents($formRequestPath);

$assert(str_contains($formRequestContent, 'id="bmrBprRequestProduct"'), 'Form request page must have #bmrBprRequestProduct dropdown.');
$assert(str_contains($formRequestContent, 'id="bmrBprRequestBmrTemplate"'), 'Form request page must have #bmrBprRequestBmrTemplate dropdown.');
$assert(str_contains($formRequestContent, 'id="bmrBprRequestBprTemplate"'), 'Form request page must have #bmrBprRequestBprTemplate dropdown.');
$assert(str_contains($formRequestContent, 'Document Template Specification'), 'Form request page must have Document Template Specification header.');
$assert(str_contains($formRequestContent, 'id="bmrTemplateMatchBadge"'), 'Form request page must have BMR match badge.');
$assert(str_contains($formRequestContent, 'id="bprTemplateMatchBadge"'), 'Form request page must have BPR match badge.');
$assert(str_contains($formRequestContent, "dropdownParent: $('#bmrBprRequestModal')"), 'Template dropdowns must retain the working modal parent.');
$assert(str_contains($formRequestContent, '#bmrBprRequestModal .bmr-bpr-template-dropdown.select2-dropdown--below'), 'Rendered below template dropdown must be repositioned directly above its field.');
$assert(str_contains($formRequestContent, 'translateY(calc(-100% - 46px))'), 'Template dropdown must move by its full height plus the selection height.');
$assert(!str_contains($formRequestContent, 'bmr-bpr-template-dropdown-host'), 'Template dropdowns must not use zero-height parent hosts.');
$assert(str_contains($formRequestContent, 'max-height: min(15rem, 40vh)'), 'Template dropdown results must have a viewport-safe maximum height.');
$assert(str_contains($formRequestContent, 'overflow-y: auto !important'), 'Template dropdown results must remain vertically scrollable.');
$assert(str_contains($formRequestContent, 'populateProductDropdown'), 'Form request JS must have populateProductDropdown helper.');
$assert(str_contains($formRequestContent, 'populateBmrBprTemplateDropdowns'), 'Form request JS must have populateBmrBprTemplateDropdowns helper.');
$assert(str_contains($formRequestContent, 'exact_bmr_template_ids || []'), 'BMR exact mappings must be ranked for the opened request.');
$assert(str_contains($formRequestContent, 'exact_bpr_template_ids || []'), 'BPR exact mappings must be ranked for the opened request.');
$assert(str_contains($formRequestContent, 'const isExact = exactIds.has(templateId)'), 'Exact ranking must use request-specific template IDs.');
$assert(!str_contains($formRequestContent, 'const isExact = Boolean(tpl.is_exact_match)'), 'The shared template catalogue must not supply a global exact flag.');
$assert(str_contains($formRequestContent, 'bmrBprMappedProducts.template_products'), 'Template dropdowns must use the complete PDF product catalogs.');
$assert(str_contains($formRequestContent, 'data-template-id='), 'Every PDF product option must retain its mapped template ID.');
$assert(str_contains($formRequestContent, '${escapeBmrBprText(product.productName)}</option>'), 'Template option labels must contain only the exact PDF product name.');
$assert(!str_contains($formRequestContent, 'Recommended Matching Templates'), 'Template dropdowns must not filter or recommend entries from the selected Product Name.');
$assert(!str_contains($formRequestContent, 'All Master Templates'), 'Template dropdowns must not append names outside the PDF product catalogs.');
$assert(str_contains($formRequestContent, "$(document).on('change', '#bmrBprRequestProduct'"), 'Product dropdown must automatically trigger template and metadata resolution on change.');
$assert(str_contains($formRequestContent, 'initProductSelect2();'), 'Product Select2 must be initialized.');
$assert(substr_count($formRequestContent, 'initTemplateSelect2();') === 1, 'Template Select2 controls must initialize exactly once per population.');
$assert(str_contains($formRequestContent, "$('#bmrBprRequestBmrTemplate option:selected').data('template-id')"), 'BMR selection must load its mapped template ID.');
$assert(str_contains($formRequestContent, "$('#bmrBprRequestBprTemplate option:selected').data('template-id')"), 'BPR selection must load its mapped template ID.');
$assert(str_contains($formRequestContent, "formData.append('bmr_template_id'"), 'Form request submit must append bmr_template_id.');
$assert(str_contains($formRequestContent, "formData.append('bpr_template_id'"), 'Form request submit must append bpr_template_id.');

// TEST 4: Verify bmr_bpr_actions.php server-side handling
echo "\nTEST 4: Verify bmr_bpr_actions.php contracts...\n";
$actionsPath = dirname(__DIR__) . '/workflow/bmr_bpr_actions.php';
$actionsContent = (string) file_get_contents($actionsPath);

$assert(str_contains($actionsContent, "'templates' => bmrBprGetRankedTemplates(\$conn)"), 'request_list in bmr_bpr_actions.php must return templates.');
$assert(str_contains($actionsContent, "'mapped_products' => bmrBprGetMappedProductCatalog(\$conn)"), 'request_list must return mapped products catalog for BMR and BPR.');
$assert(!str_contains($actionsContent, "'products' => bmrBprProductOptions(\$conn)"), 'request_list must not return the complete unmapped 3,200 Product Master.');
$assert(str_contains($actionsContent, "'has_document_configuration'"), 'Each request must retain its product document configuration flag.');
$assert(str_contains($actionsContent, "'configured_bmr_form_count'"), 'Each request must retain its configured BMR count.');
$assert(str_contains($actionsContent, "'configured_bpr_form_count'"), 'Each request must retain its configured BPR count.');
$assert(str_contains($actionsContent, "'exact_bmr_template_ids'"), 'Each request must return its exact BMR template IDs.');
$assert(str_contains($actionsContent, "'exact_bpr_template_ids'"), 'Each request must return its exact BPR template IDs.');
$assert(str_contains($actionsContent, 'bmrBprResolveProductDocumentRequirements('), 'Exact request mappings must use the authoritative product/pack resolver.');
$assert(str_contains($actionsContent, "\$bmrTemplateId = isset(\$_POST['bmr_template_id'])"), 'submit_request in bmr_bpr_actions.php must read bmr_template_id.');
$assert(str_contains($actionsContent, "\$bprTemplateId = isset(\$_POST['bpr_template_id'])"), 'submit_request in bmr_bpr_actions.php must read bpr_template_id.');
$assert(!str_contains($actionsContent, '\$existingReqs = bmrBprResolveProductDocumentRequirements'), 'Submission must not silently replace missing user selections.');
$assert(str_contains($actionsContent, "AND form_type = ? AND status = 1 AND deleted_at IS NULL"), 'Submitted templates must be active and match their BMR/BPR type.');
$assert(str_contains($actionsContent, "(\$row['form_type'] === 'BPR' && \$isPendingIncoming)"), 'production_list must include pending BPR in incoming queue without restricting to Rapid-only.');

// TEST 5: Verify bmrBprSnapshotProductDocumentRequirements accepts custom template IDs
echo "\nTEST 5: Verify bmrBprSnapshotProductDocumentRequirements signature...\n";
$reflection = new ReflectionFunction('bmrBprSnapshotProductDocumentRequirements');
$params = $reflection->getParameters();
$paramNames = array_map(static fn($p) => $p->getName(), $params);
$assert(in_array('selectedBmrTemplateId', $paramNames, true), 'bmrBprSnapshotProductDocumentRequirements must accept selectedBmrTemplateId.');
$assert(in_array('selectedBprTemplateId', $paramNames, true), 'bmrBprSnapshotProductDocumentRequirements must accept selectedBprTemplateId.');

$multiTemplateRequirements = [
    ['form_type' => 'BMR', 'document_sequence' => 1, 'template_id' => 10],
    ['form_type' => 'BMR', 'document_sequence' => 2, 'template_id' => 20],
    ['form_type' => 'BPR', 'document_sequence' => 1, 'template_id' => 30],
];
$selectedRequirements = bmrBprApplySelectedTemplate($multiTemplateRequirements, 'BMR', 99);
$assert((int) $selectedRequirements[0]['template_id'] === 99, 'A selected BMR template must be applied to a multi-template request.');
$assert((int) $selectedRequirements[1]['template_id'] === 20, 'Applying a selected BMR template must preserve the remaining mapped BMR documents.');
$assert((int) $selectedRequirements[2]['template_id'] === 30, 'Applying a selected BMR template must not change BPR documents.');

$existingRequirements = bmrBprApplySelectedTemplate($multiTemplateRequirements, 'BMR', 20);
$assert($existingRequirements === $multiTemplateRequirements, 'An already-mapped selected template must preserve the complete requirement set.');

echo "\n======================================================================\n";
if (empty($failures)) {
    echo "ALL BMR/BPR TEMPLATE & STEP 7-9 WORKFLOW TESTS PASSED! (0 failures)\n";
} else {
    echo "FAILED WITH " . count($failures) . " FAILURES!\n";
    exit(1);
}
echo "======================================================================\n";
