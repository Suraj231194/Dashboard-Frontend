<?php

declare(strict_types=1);

define('HRMS_CONTEXT', true);
require_once __DIR__ . '/../hrms/annual_calendar_common.php';

$assertSame = static function (mixed $expected, mixed $actual, string $message): void {
    if ($expected !== $actual) {
        fwrite(STDERR, "FAIL: {$message}. Expected " . var_export($expected, true) . ', received ' . var_export($actual, true) . PHP_EOL);
        exit(1);
    }
};

$assertSame(0, count(acComputeSaturdayOffs(2026, 'all_working')), 'all-working policy');
$assertSame(52, count(acComputeSaturdayOffs(2026, 'all_off')), 'all-Saturdays-off policy');
$assertSame(24, count(acComputeSaturdayOffs(2026, '2nd_4th_off')), 'second/fourth Saturday policy');
$assertSame(26, count(acComputeSaturdayOffs(2026, 'alternate_off')), 'alternate Saturday policy');
$assertSame(
    ['2026-01-10', '2026-01-24'],
    acComputeSaturdayOffs(2026, 'custom', ['2026-01-24', 'invalid', '2026-01-10', '2026-01-10']),
    'custom weekly-off normalization'
);

$days = acBuildCalendarDaysFromData(
    2026,
    '2nd_4th_off',
    [
        ['holiday_date' => '2026-01-04', 'holiday_name' => 'Sunday Holiday', 'holiday_type' => 'company', 'is_enabled' => 1],
        ['holiday_date' => '2026-01-10', 'holiday_name' => 'Saturday Holiday', 'holiday_type' => 'festival', 'is_enabled' => 1],
        ['holiday_date' => '2026-01-12', 'holiday_name' => 'Working-Day Holiday', 'holiday_type' => 'national', 'is_enabled' => 1],
        ['holiday_date' => '2026-04-14', 'holiday_name' => 'Holiday One', 'holiday_type' => 'national', 'is_enabled' => 1],
        ['holiday_date' => '2026-04-14', 'holiday_name' => 'Holiday Two', 'holiday_type' => 'festival', 'is_enabled' => 1],
    ]
);
$assertSame(365, count($days), 'complete non-leap-year ledger');
$january = acMonthlyBreakdownFromDays($days)[0];
$assertSame(31, $january['total_days'], 'January total days');
$assertSame(4, $january['sundays'], 'January Sundays');
$assertSame(2, $january['sat_offs'], 'January Saturday offs');
$assertSame(1, $january['holidays'], 'overlap-safe January holidays');
$assertSame(24, $january['working_days'], 'overlap-safe January working days');

$april14 = array_values(array_filter($days, static fn(array $day): bool => $day['calendar_date'] === '2026-04-14'))[0];
$assertSame('holiday', $april14['day_type'], 'coincident holiday date classification');
$assertSame('Holiday One / Holiday Two', $april14['holiday_names'], 'coincident holiday names retained');

$leapDays = acBuildCalendarDaysFromData(2028, 'all_working', []);
$assertSame(366, count($leapDays), 'complete leap-year ledger');

echo 'Annual calendar calculation tests passed.' . PHP_EOL;
