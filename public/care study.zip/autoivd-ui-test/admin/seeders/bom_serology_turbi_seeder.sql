-- =============================================================
-- Seeder: bom_serology_turbi_seeder.sql
-- Workbook: BOMs - Serology & Turbi.xlsx
-- BOMs: 22
--
-- GENERATED FILE - do not edit by hand.
-- Regenerate with: php admin/tools/bom/generate_seeders.php
-- Every product_code below is resolved from the inventory master;
-- unmatched codes are skipped rather than guessed.
-- =============================================================

SET SESSION max_statement_time = 0;

-- -------------------------------------------------------------
-- BOM 1/22: ASO Latex 100 Tests
-- Sheet "ASO 100" | Product BGX/FIN.SERO/2026/000007 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000007';
SET @f_name = 'ASO Latex 100 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- ASO Latex Reagent Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.SERO/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 100 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 2/22: ASO Latex 50 Tests
-- Sheet "ASO 50" | Product BGX/FIN.SERO/2026/000009 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000009';
SET @f_name = 'ASO Latex 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- ASO Latex Reagent Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.SERO/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 3/22: ASO Latex 25 Tests
-- Sheet "ASO 25" | Product BGX/FIN.SERO/2026/000008 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000008';
SET @f_name = 'ASO Latex 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- ASO Latex Reagent Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.SERO/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000133' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000130' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 4/22: CRP Latex 100 Tests
-- Sheet "CRP 100" | Product BGX/FIN.SERO/2026/000011 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000011';
SET @f_name = 'CRP Latex 100 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 100 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- CRP Latex Positive Control Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/QN.BIOC/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 5/22: CRP Latex 50 Tests
-- Sheet "CRP 50" | Product BGX/FIN.SERO/2026/000013 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000013';
SET @f_name = 'CRP Latex 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 6/22: CRP Latex 25 Tests
-- Sheet "CRP 25" | Product BGX/FIN.SERO/2026/000012 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000012';
SET @f_name = 'CRP Latex 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000133' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000130' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 7/22: CRP Turbidimetric, Biogenix 100 mL
-- Sheet "CRP Turbi 100" | Product BGX/FIN.SERO/2026/000015 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000015';
SET @f_name = 'CRP Turbidimetric, Biogenix 100 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Turbidimetric Latex R1 + R2, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 100 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 30 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000020' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 100 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000026' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- CRP Turbidimetric Calibrator Pcs Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.BIOC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 8/22: CRP Turbidimetric, Biogenix 250 mL
-- Sheet "CRP Turbi 250" | Product BGX/FIN.SERO/2026/000016 | Components 5
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000016';
SET @f_name = 'CRP Turbidimetric, Biogenix 250 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Turbidimetric Latex R1 + R2, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 100 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 400 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 9/22: CRP Turbidimetric, Biogenix 300 mL
-- Sheet "CRP Turbi 300" | Product BGX/FIN.SERO/2026/000017 | Components 5
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000017';
SET @f_name = 'CRP Turbidimetric, Biogenix 300 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Turbidimetric Latex R1 + R2, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 500 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000022' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial White 100 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- CRP Turbidimetric Calibrator Pcs Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.BIOC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 10/22: CRP Turbidimetric, Biogenix 50 mL
-- Sheet "CRP Turbi 50" | Product BGX/FIN.SERO/2026/000018 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000018';
SET @f_name = 'CRP Turbidimetric, Biogenix 50 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Turbidimetric Latex R1 + R2, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 10 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- CRP Turbidimetric Calibrator Pcs Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.BIOC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 11/22: CRP Turbidimetric, Biogenix 500 mL
-- Sheet "CRP Turbi 500" | Product BGX/FIN.SERO/2026/000019 | Components 5
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000019';
SET @f_name = 'CRP Turbidimetric, Biogenix 500 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- CRP Turbidimetric Latex R1 + R2, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.BIOC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 600 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000023' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial White 100 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- CRP Turbidimetric Calibrator Pcs Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.BIOC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 12/22: D.dimer Kit, Biogenix 30 + 10 mL
-- Sheet "D.Dimer 30+10" | Product BGX/FIN.SERO/2026/000021 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000021';
SET @f_name = 'D.dimer Kit, Biogenix 30 + 10 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- D.dimer Reagent (R1 + R2) 3 + 1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 30 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000020' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 10 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- D.dimer Calibrator 1 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.SERO/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 13/22: Ferritin Turbidimetric 40 mL
-- Sheet "Ferritin 40" | Product BGX/FIN.SERO/2026/000022 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000022';
SET @f_name = 'Ferritin Turbidimetric 40 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Ferritin Turbidimetric (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 30 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000020' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 10 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ferritin Calibrator (Set of 4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.SERO/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 14/22: HBA1C Turbidimetric Latex 40 mL
-- Sheet "HbA1c Turbi" | Product BGX/FIN.SERO/2026/000025 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000025';
SET @f_name = 'HBA1C Turbidimetric Latex 40 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HBA1C (R1) Reagent mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 30, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000183' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HBA1C (R2) Reagent mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000184' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 100 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 30 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000020' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 10 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 400 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HBA1C Calibrator (Set of 5)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.BIOC/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HBA1C Hemolysing Solution mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000185' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 15/22: Micro Albumin Turbidimetric Latex 50 mL
-- Sheet "Micro Albumin Turbi 50" | Product BGX/FIN.SERO/2026/000027 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000027';
SET @f_name = 'Micro Albumin Turbidimetric Latex 50 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Microalbumin R1 + R2 (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Micro Albumin Calibrator C1 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.SERO/2026/000005' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 10 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 16/22: RF Latex Biogenix 100 Tests
-- Sheet "RF 100" | Product BGX/FIN.SERO/2026/000028 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000028';
SET @f_name = 'RF Latex Biogenix 100 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- RF Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- RF Latex Positive Control Biosino
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/QN.SERO/2026/000007' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 100 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 17/22: RF Latex Biogenix 50 Tests
-- Sheet "RF 50" | Product BGX/FIN.SERO/2026/000030 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000030';
SET @f_name = 'RF Latex Biogenix 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- RF Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 18/22: RF Latex Biogenix 25 Tests
-- Sheet "RF 25" | Product BGX/FIN.SERO/2026/000029 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000029';
SET @f_name = 'RF Latex Biogenix 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- RF Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000133' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000130' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 Circle Black Pvc Latex Slide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 3 Hole Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000101' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 19/22: RF Turbidimetric Latex 50 mL
-- Sheet "RF Turbi 50ML" | Product BGX/FIN.SERO/2026/000031 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000031';
SET @f_name = 'RF Turbidimetric Latex 50 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- RF Turbidimetric Latex, Biosino (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- RF Turbidimetric Calibrator
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/CAL.SERO/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial Brown 10 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Green 50 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 20/22: RPR Latex Biogenix 100 Tests
-- Sheet "RPR 100 Test" | Product BGX/FIN.SERO/2026/000032 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000032';
SET @f_name = 'RPR Latex Biogenix 100 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- RPR Latex (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- RPR Slide 10 Circle Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000144' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 100 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 21/22: RPR Latex Biogenix 50 Tests
-- Sheet "RPR 50 Test" | Product BGX/FIN.SERO/2026/000033 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000033';
SET @f_name = 'RPR Latex Biogenix 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- RPR Latex (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- RPR Slide 10 Circle Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000144' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pp Droppers Tube 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000131' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 22/22: Widal Biogenix 4X5 mL 4 x 5 mL
-- Sheet "Widal 4x5" | Product BGX/FIN.SERO/2026/000038 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.SERO/2026/000038';
SET @f_name = 'Widal Biogenix 4X5 mL 4 x 5 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Widal Typhi H Antigen (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Widal Typhi O Antigen (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Widal Paratyphi A-H Antigen (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Widal Paratyphi B-H Antigen (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.SERO/2026/000019' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Glass Silde for Widol Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000106' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000005' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2 mL Glass Vial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PP Mixing Sticks 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Blue 100 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Foam 5 Whole for Widol Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000102' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Widal Positive Control Ltr
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/QN.SERO/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

