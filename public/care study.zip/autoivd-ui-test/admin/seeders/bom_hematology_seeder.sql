-- =============================================================
-- Seeder: bom_hematology_seeder.sql
-- Workbook: BOMs - Hematology.xlsx
-- BOMs: 6
--
-- GENERATED FILE - do not edit by hand.
-- Regenerate with: php admin/tools/bom/generate_seeders.php
-- Every product_code below is resolved from the inventory master;
-- unmatched codes are skipped rather than guessed.
-- =============================================================

SET SESSION max_statement_time = 0;

-- -------------------------------------------------------------
-- BOM 1/6: Diluent Biogenix 20 L
-- Sheet "Diluent 20 Ltr" | Product BGX/FIN.HEMA/2026/000006 | Components 4
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.HEMA/2026/000006';
SET @f_name = 'Diluent Biogenix 20 L';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cubitainer Empty 20 Ltrs Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 7PLY Diluent boxes
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Stickers Tapes Filter Etc Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000156' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Diluent (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.HEMA/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 2/6: Diluent 5PART 20 L
-- Sheet "Diluent 5 Part" | Product BGX/FIN.HEMA/2026/000005 | Components 4
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.HEMA/2026/000005';
SET @f_name = 'Diluent 5PART 20 L';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cubitainer Empty 20 Ltrs Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 7PLY Diluent boxes @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Stickers Tapes Filter Etc Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000156' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Diluent (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.HEMA/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 3/6: Ez Cleaner 100 mL
-- Sheet "EZ 100ML" | Product BGX/FIN.HEMA/2026/000001 | Components 3
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.HEMA/2026/000001';
SET @f_name = 'Ez Cleaner 100 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Enzymatic Cleaner Reagent Kit
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000097' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial White 100 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 4/6: Lyse Biogenix 500 mL
-- Sheet "Lyse 500 ML" | Product BGX/FIN.HEMA/2026/000009 | Components 3
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.HEMA/2026/000009';
SET @f_name = 'Lyse Biogenix 500 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Lyse (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.HEMA/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Bottle 500 mL for Lyse Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Stickers Tapes Filter Etc Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000156' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 5/6: Probe Cleaner Biogenix 100 mL
-- Sheet "Probe 100ML" | Product BGX/FIN.HEMA/2026/000019 | Components 3
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.HEMA/2026/000019';
SET @f_name = 'Probe Cleaner Biogenix 100 mL';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Probe Cleaner
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.HEMA/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plastic Vial White 100 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOT/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 6/6: Rinse Reagent 20 L
-- Sheet "Rinse 20 Ltr" | Product BGX/FIN.HEMA/2026/000021 | Components 4
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.HEMA/2026/000021';
SET @f_name = 'Rinse Reagent 20 L';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Rinse (Bulk Reagent)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ltr' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.BR.HEMA/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cubitainer Empty 20 Ltrs Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Stickers Tapes Filter Etc Nos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000156' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 7PLY Diluent boxes
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

