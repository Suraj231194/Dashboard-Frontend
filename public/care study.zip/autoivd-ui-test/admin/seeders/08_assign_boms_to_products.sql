-- =============================================================
-- Seeder: 08_assign_boms_to_products.sql
-- Description: Explicit Verification & Assignment of BOMs to Finished Products
-- Source: Sheet 2 ('BOM - Preparation') of Inventory Management - Final.xlsx (213 YES items)
--         and all 218 active BOMs across the 6 BOM workbooks
-- =============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SESSION max_statement_time = 0;

-- 1. Ensure all finished products in bom_master are mapped to valid product IDs
UPDATE `bom_master` bm
JOIN `products` p ON bm.`finished_product_id` = p.`id`
SET bm.`status` = 1,
    bm.`bom_status` = 'APPROVED'
WHERE bm.`deleted_at` IS NULL;

-- 2. Explicit BOM to Product Assignments for all 213 YES items in BOM - Preparation
-- Item 1: BGX/FIN.BIOC/2026/000001 | ADA 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000001' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000001' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ADA 100 mL' OR `name` LIKE CONCAT('%', 'ADA 100 mL', '%')));

-- Item 2: BGX/FIN.BIOC/2026/000003 | ADA 15 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000003' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000003' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ADA 15 mL' OR `name` LIKE CONCAT('%', 'ADA 15 mL', '%')));

-- Item 3: BGX/FIN.BIOC/2026/000004 | ADA 30 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000004' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000004' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ADA 30 mL' OR `name` LIKE CONCAT('%', 'ADA 30 mL', '%')));

-- Item 4: BGX/FIN.BIOC/2026/000006 | Albumin 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000006' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000006' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Albumin 100 mL' OR `name` LIKE CONCAT('%', 'Albumin 100 mL', '%')));

-- Item 5: BGX/FIN.BIOC/2026/000008 | Albumin 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000008' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000008' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Albumin 500 mL' OR `name` LIKE CONCAT('%', 'Albumin 500 mL', '%')));

-- Item 6: BGX/FIN.BIOC/2026/000009 | Albumin 450 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000009' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000009' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Albumin 450 mL' OR `name` LIKE CONCAT('%', 'Albumin 450 mL', '%')));

-- Item 7: BGX/FIN.BIOC/2026/000010 | Alkaline Phosphatase 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000010' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000010' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Alkaline Phosphatase 100 mL' OR `name` LIKE CONCAT('%', 'Alkaline Phosphatase 100 mL', '%')));

-- Item 8: BGX/FIN.BIOC/2026/000011 | Alkaline Phosphatase 20 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000011' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000011' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Alkaline Phosphatase 20 mL' OR `name` LIKE CONCAT('%', 'Alkaline Phosphatase 20 mL', '%')));

-- Item 9: BGX/FIN.BIOC/2026/000013 | Alkaline Phosphatase 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000013' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000013' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Alkaline Phosphatase 50 mL' OR `name` LIKE CONCAT('%', 'Alkaline Phosphatase 50 mL', '%')));

-- Item 10: BGX/FIN.BIOC/2026/000015 | Alpha Amylase 10 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000015' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000015' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Alpha Amylase 10 mL' OR `name` LIKE CONCAT('%', 'Alpha Amylase 10 mL', '%')));

-- Item 11: BGX/FIN.BIOC/2026/000018 | Alpha Amylase 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000018' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000018' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Alpha Amylase 50 mL' OR `name` LIKE CONCAT('%', 'Alpha Amylase 50 mL', '%')));

-- Item 12: BGX/FIN.BIOC/2026/000020 | Ammonia 10 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000020' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000020' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ammonia 10 mL' OR `name` LIKE CONCAT('%', 'Ammonia 10 mL', '%')));

-- Item 13: BGX/FIN.BIOC/2026/000023 | Ammonia Kit mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000023' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000023' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ammonia Kit mL' OR `name` LIKE CONCAT('%', 'Ammonia Kit mL', '%')));

-- Item 14: BGX/FIN.BIOC/2026/000028 | Bilirubin Direct 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000028' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000028' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Bilirubin Direct 100 mL' OR `name` LIKE CONCAT('%', 'Bilirubin Direct 100 mL', '%')));

-- Item 15: BGX/FIN.BIOC/2026/000032 | Bilirubin Total 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000032' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000032' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Bilirubin Total 100 mL' OR `name` LIKE CONCAT('%', 'Bilirubin Total 100 mL', '%')));

-- Item 16: BGX/FIN.BIOC/2026/000039 | Calcium 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000039' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000039' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Calcium 100 mL' OR `name` LIKE CONCAT('%', 'Calcium 100 mL', '%')));

-- Item 17: BGX/FIN.BIOC/2026/000041 | Calcium 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000041' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000041' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Calcium 500 mL' OR `name` LIKE CONCAT('%', 'Calcium 500 mL', '%')));

-- Item 18: BGX/FIN.BIOC/2026/000042 | Chloride 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000042' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000042' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chloride 100 mL' OR `name` LIKE CONCAT('%', 'Chloride 100 mL', '%')));

-- Item 19: BGX/FIN.BIOC/2026/000044 | Chloride 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000044' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000044' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chloride 50 mL' OR `name` LIKE CONCAT('%', 'Chloride 50 mL', '%')));

-- Item 20: BGX/FIN.BIOC/2026/000045 | Cholesterol 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000045' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000045' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Cholesterol 100 mL' OR `name` LIKE CONCAT('%', 'Cholesterol 100 mL', '%')));

-- Item 21: BGX/FIN.BIOC/2026/000048 | Ck-mb 10 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000048' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000048' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ck-mb 10 mL' OR `name` LIKE CONCAT('%', 'Ck-mb 10 mL', '%')));

-- Item 22: BGX/FIN.BIOC/2026/000050 | Ck-nac 10 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000050' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000050' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ck-nac 10 mL' OR `name` LIKE CONCAT('%', 'Ck-nac 10 mL', '%')));

-- Item 23: BGX/FIN.BIOC/2026/000051 | Creatinine 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000051' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000051' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Creatinine 100 mL' OR `name` LIKE CONCAT('%', 'Creatinine 100 mL', '%')));

-- Item 24: BGX/FIN.BIOC/2026/000065 | Glucose 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000065' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000065' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Glucose 100 mL' OR `name` LIKE CONCAT('%', 'Glucose 100 mL', '%')));

-- Item 25: BGX/FIN.BIOC/2026/000067 | Glucose 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000067' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000067' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Glucose 500 mL' OR `name` LIKE CONCAT('%', 'Glucose 500 mL', '%')));

-- Item 26: BGX/FIN.BIOC/2026/000070 | HDL Cholesterol 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000070' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000070' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HDL Cholesterol 100 mL' OR `name` LIKE CONCAT('%', 'HDL Cholesterol 100 mL', '%')));

-- Item 27: BGX/FIN.BIOC/2026/000075 | HDL Direct 300 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000075' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000075' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HDL Direct 300 mL' OR `name` LIKE CONCAT('%', 'HDL Direct 300 mL', '%')));

-- Item 28: BGX/FIN.BIOC/2026/000076 | HDL Direct 320 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000076' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000076' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HDL Direct 320 mL' OR `name` LIKE CONCAT('%', 'HDL Direct 320 mL', '%')));

-- Item 29: BGX/FIN.BIOC/2026/000077 | HDL Direct 40 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000077' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000077' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HDL Direct 40 mL' OR `name` LIKE CONCAT('%', 'HDL Direct 40 mL', '%')));

-- Item 30: BGX/FIN.BIOC/2026/000079 | HDL Direct 80 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000079' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000079' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HDL Direct 80 mL' OR `name` LIKE CONCAT('%', 'HDL Direct 80 mL', '%')));

-- Item 31: BGX/FIN.BIOC/2026/000092 | LDL Direct 40 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000092' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000092' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'LDL Direct 40 mL' OR `name` LIKE CONCAT('%', 'LDL Direct 40 mL', '%')));

-- Item 32: BGX/FIN.BIOC/2026/000095 | Lipase 40 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000095' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000095' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Lipase 40 mL' OR `name` LIKE CONCAT('%', 'Lipase 40 mL', '%')));

-- Item 33: BGX/FIN.BIOC/2026/000100 | Magnesium 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000100' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000100' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Magnesium 50 mL' OR `name` LIKE CONCAT('%', 'Magnesium 50 mL', '%')));

-- Item 34: BGX/FIN.BIOC/2026/000104 | Micro Protein 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000104' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000104' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Micro Protein 50 mL' OR `name` LIKE CONCAT('%', 'Micro Protein 50 mL', '%')));

-- Item 35: BGX/FIN.BIOC/2026/000107 | Potassium 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000107' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000107' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Potassium 100 mL' OR `name` LIKE CONCAT('%', 'Potassium 100 mL', '%')));

-- Item 36: BGX/FIN.BIOC/2026/000109 | Potassium 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000109' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000109' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Potassium 50 mL' OR `name` LIKE CONCAT('%', 'Potassium 50 mL', '%')));

-- Item 37: BGX/FIN.BIOC/2026/000111 | SGOT 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000111' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000111' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SGOT 100 mL' OR `name` LIKE CONCAT('%', 'SGOT 100 mL', '%')));

-- Item 38: BGX/FIN.BIOC/2026/000114 | SGOT 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000114' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000114' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SGOT 500 mL' OR `name` LIKE CONCAT('%', 'SGOT 500 mL', '%')));

-- Item 39: BGX/FIN.BIOC/2026/000115 | SGPT (Alt) 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000115' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000115' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SGPT (Alt) 100 mL' OR `name` LIKE CONCAT('%', 'SGPT (Alt) 100 mL', '%')));

-- Item 40: BGX/FIN.BIOC/2026/000117 | SGPT 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000117' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000117' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SGPT 500 mL' OR `name` LIKE CONCAT('%', 'SGPT 500 mL', '%')));

-- Item 41: BGX/FIN.BIOC/2026/000120 | SODIUM 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000120' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000120' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SODIUM 50 mL' OR `name` LIKE CONCAT('%', 'SODIUM 50 mL', '%')));

-- Item 42: BGX/FIN.BIOC/2026/000121 | Total & Direct Bilirubin 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000121' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000121' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total & Direct Bilirubin 100 mL' OR `name` LIKE CONCAT('%', 'Total & Direct Bilirubin 100 mL', '%')));

-- Item 43: BGX/FIN.BIOC/2026/000122 | Total & Direct Bilirubin 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000122' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000122' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total & Direct Bilirubin 500 mL' OR `name` LIKE CONCAT('%', 'Total & Direct Bilirubin 500 mL', '%')));

-- Item 44: BGX/FIN.BIOC/2026/000126 | Total Bile Acid 120 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000126' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000126' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total Bile Acid 120 mL' OR `name` LIKE CONCAT('%', 'Total Bile Acid 120 mL', '%')));

-- Item 45: BGX/FIN.BIOC/2026/000128 | Total Bile Acid 40 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000128' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000128' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total Bile Acid 40 mL' OR `name` LIKE CONCAT('%', 'Total Bile Acid 40 mL', '%')));

-- Item 46: BGX/FIN.BIOC/2026/000129 | Total Bile Acid, 80 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000129' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000129' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total Bile Acid, 80 mL' OR `name` LIKE CONCAT('%', 'Total Bile Acid, 80 mL', '%')));

-- Item 47: BGX/FIN.BIOC/2026/000133 | Triglyceride 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000133' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000133' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Triglyceride 100 mL' OR `name` LIKE CONCAT('%', 'Triglyceride 100 mL', '%')));

-- Item 48: BGX/FIN.BIOC/2026/000135 | Triglyceride 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000135' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000135' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Triglyceride 50 mL' OR `name` LIKE CONCAT('%', 'Triglyceride 50 mL', '%')));

-- Item 49: BGX/FIN.BIOC/2026/000138 | Urea Berthlot 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000138' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000138' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea Berthlot 100 mL' OR `name` LIKE CONCAT('%', 'Urea Berthlot 100 mL', '%')));

-- Item 50: BGX/FIN.BIOC/2026/000141 | Urea UV 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000141' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000141' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea UV 100 mL' OR `name` LIKE CONCAT('%', 'Urea UV 100 mL', '%')));

-- Item 51: BGX/FIN.BIOC/2026/000144 | Urea UV 250 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000144' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000144' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea UV 250 mL' OR `name` LIKE CONCAT('%', 'Urea UV 250 mL', '%')));

-- Item 52: BGX/FIN.BIOC/2026/000145 | Urea UV 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000145' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000145' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea UV 50 mL' OR `name` LIKE CONCAT('%', 'Urea UV 50 mL', '%')));

-- Item 53: BGX/FIN.BIOC/2026/000146 | Urea UV 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000146' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000146' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea UV 500 mL' OR `name` LIKE CONCAT('%', 'Urea UV 500 mL', '%')));

-- Item 54: BGX/FIN.BIOC/2026/000148 | Uric Acid 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000148' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000148' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Uric Acid 100 mL' OR `name` LIKE CONCAT('%', 'Uric Acid 100 mL', '%')));

-- Item 55: BGX/FIN.BIOC/2026/000150 | Uric Acid 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000150' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.BIOC/2026/000150' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Uric Acid 50 mL' OR `name` LIKE CONCAT('%', 'Uric Acid 50 mL', '%')));

-- Item 56: BGX/FIN.HEMA/2026/000001 | Ez Cleaner 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000001' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000001' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ez Cleaner 100 mL' OR `name` LIKE CONCAT('%', 'Ez Cleaner 100 mL', '%')));

-- Item 57: BGX/FIN.HEMA/2026/000005 | Diluent 5PART 20 L
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000005' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000005' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Diluent 5PART 20 L' OR `name` LIKE CONCAT('%', 'Diluent 5PART 20 L', '%')));

-- Item 58: BGX/FIN.HEMA/2026/000006 | Diluent Biogeni × 20 L
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000006' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000006' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Diluent Biogeni × 20 L' OR `name` LIKE CONCAT('%', 'Diluent Biogeni × 20 L', '%')));

-- Item 59: BGX/FIN.HEMA/2026/000007 | Diluent Veterinary 20 L
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000007' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000007' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Diluent Veterinary 20 L' OR `name` LIKE CONCAT('%', 'Diluent Veterinary 20 L', '%')));

-- Item 60: BGX/FIN.HEMA/2026/000012 | Lyse for VH50 500 mL Nos
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000012' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000012' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Lyse for VH50 500 mL Nos' OR `name` LIKE CONCAT('%', 'Lyse for VH50 500 mL Nos', '%')));

-- Item 61: BGX/FIN.HEMA/2026/000019 | Probe Cleaner Biogeni × 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000019' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000019' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Probe Cleaner Biogeni × 100 mL' OR `name` LIKE CONCAT('%', 'Probe Cleaner Biogeni × 100 mL', '%')));

-- Item 62: BGX/FIN.HEMA/2026/000021 | Rinse Reagent 20 L
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000021' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.HEMA/2026/000021' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Rinse Reagent 20 L' OR `name` LIKE CONCAT('%', 'Rinse Reagent 20 L', '%')));

-- Item 63: BGX/FIN.RAPID/2026/000001 | AMH Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000001' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000001' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'AMH Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'AMH Rapid Test POCT 25 Tests', '%')));

-- Item 64: BGX/FIN.RAPID/2026/000002 | Anti CCP Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000002' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000002' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Anti CCP Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Anti CCP Rapid Test POCT 25 Tests', '%')));

-- Item 65: BGX/FIN.RAPID/2026/000003 | ASO Rapid Test Post 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000003' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000003' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ASO Rapid Test Post 25 Tests' OR `name` LIKE CONCAT('%', 'ASO Rapid Test Post 25 Tests', '%')));

-- Item 66: BGX/FIN.RAPID/2026/000005 | Beta HCG Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000005' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000005' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Beta HCG Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Beta HCG Rapid Test POCT 25 Tests', '%')));

-- Item 67: BGX/FIN.RAPID/2026/000010 | Chikungunya IGM Rapid Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000010' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000010' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chikungunya IGM Rapid Test' OR `name` LIKE CONCAT('%', 'Chikungunya IGM Rapid Test', '%')));

-- Item 68: BGX/FIN.RAPID/2026/000012 | Chlamydia Trachomatis Rapid 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000012' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000012' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chlamydia Trachomatis Rapid 10 Tests' OR `name` LIKE CONCAT('%', 'Chlamydia Trachomatis Rapid 10 Tests', '%')));

-- Item 69: BGX/FIN.RAPID/2026/000013 | Cholera Ag 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000013' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000013' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Cholera Ag 25 Tests' OR `name` LIKE CONCAT('%', 'Cholera Ag 25 Tests', '%')));

-- Item 70: BGX/FIN.RAPID/2026/000014 | Cortisol Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000014' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000014' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Cortisol Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Cortisol Rapid Test POCT 25 Tests', '%')));

-- Item 71: BGX/FIN.RAPID/2026/000020 | Dengue Duo (NS1 + IGG + IGM) Biogenix 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000020' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000020' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue Duo (NS1 + IGG + IGM) Biogenix 10 Tests' OR `name` LIKE CONCAT('%', 'Dengue Duo (NS1 + IGG + IGM) Biogenix 10 Tests', '%')));

-- Item 72: BGX/FIN.RAPID/2026/000021 | Dengue Duo (NS1 + IGG + IGM) Biogenix 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000021' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000021' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue Duo (NS1 + IGG + IGM) Biogenix 25 Tests' OR `name` LIKE CONCAT('%', 'Dengue Duo (NS1 + IGG + IGM) Biogenix 25 Tests', '%')));

-- Item 73: BGX/FIN.RAPID/2026/000022 | Dengue IGG + IGM Rapid Test 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000022' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000022' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue IGG + IGM Rapid Test 50 Tests' OR `name` LIKE CONCAT('%', 'Dengue IGG + IGM Rapid Test 50 Tests', '%')));

-- Item 74: BGX/FIN.RAPID/2026/000023 | Dengue IGG/IGM Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000023' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000023' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue IGG/IGM Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Dengue IGG/IGM Rapid Test POCT 25 Tests', '%')));

-- Item 75: BGX/FIN.RAPID/2026/000024 | Dengue NS1 Rapid Test 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000024' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000024' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue NS1 Rapid Test 50 Tests' OR `name` LIKE CONCAT('%', 'Dengue NS1 Rapid Test 50 Tests', '%')));

-- Item 76: BGX/FIN.RAPID/2026/000028 | Fecal Occult Blood (Fob) Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000028' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000028' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Fecal Occult Blood (Fob) Test' OR `name` LIKE CONCAT('%', 'Fecal Occult Blood (Fob) Test', '%')));

-- Item 77: BGX/FIN.RAPID/2026/000029 | Ferritin Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000029' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000029' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ferritin Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Ferritin Rapid Test POCT 25 Tests', '%')));

-- Item 78: BGX/FIN.RAPID/2026/000030 | Filaria IGG + IGM Rapid Test Bio Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000030' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000030' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Filaria IGG + IGM Rapid Test Bio Test' OR `name` LIKE CONCAT('%', 'Filaria IGG + IGM Rapid Test Bio Test', '%')));

-- Item 79: BGX/FIN.RAPID/2026/000031 | FSH Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000031' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000031' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'FSH Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'FSH Rapid Test POCT 25 Tests', '%')));

-- Item 80: BGX/FIN.RAPID/2026/000033 | Gonorrhea Ag Rapid Test 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000033' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000033' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Gonorrhea Ag Rapid Test 10 Tests' OR `name` LIKE CONCAT('%', 'Gonorrhea Ag Rapid Test 10 Tests', '%')));

-- Item 81: BGX/FIN.RAPID/2026/000034 | H.pylori Antibody Biogenix Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000034' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000034' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'H.pylori Antibody Biogenix Test' OR `name` LIKE CONCAT('%', 'H.pylori Antibody Biogenix Test', '%')));

-- Item 82: BGX/FIN.RAPID/2026/000035 | H.pylori Antigen Biogenix 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000035' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000035' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'H.pylori Antigen Biogenix 25 Tests' OR `name` LIKE CONCAT('%', 'H.pylori Antigen Biogenix 25 Tests', '%')));

-- Item 83: BGX/FIN.RAPID/2026/000036 | Hav IGM Rapid Test Biogenix Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000036' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000036' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Hav IGM Rapid Test Biogenix Test' OR `name` LIKE CONCAT('%', 'Hav IGM Rapid Test Biogenix Test', '%')));

-- Item 84: BGX/FIN.RAPID/2026/000037 | HBA1C Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000037' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000037' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBA1C Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'HBA1C Rapid Test POCT 25 Tests', '%')));

-- Item 85: BGX/FIN.RAPID/2026/000038 | HBSAG Rapid S/P Test Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000038' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000038' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBSAG Rapid S/P Test Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'HBSAG Rapid S/P Test Biogenix 50 Tests', '%')));

-- Item 86: BGX/FIN.RAPID/2026/000039 | HBSAG Rapid W/B Test Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000039' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000039' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBSAG Rapid W/B Test Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'HBSAG Rapid W/B Test Biogenix 50 Tests', '%')));

-- Item 87: BGX/FIN.RAPID/2026/000040 | HBV5 Panel (Markers) Rapid Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000040' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000040' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBV5 Panel (Markers) Rapid Test' OR `name` LIKE CONCAT('%', 'HBV5 Panel (Markers) Rapid Test', '%')));

-- Item 88: BGX/FIN.RAPID/2026/000041 | HCG Mini Rapid Test (RT)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000041' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000041' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCG Mini Rapid Test (RT)' OR `name` LIKE CONCAT('%', 'HCG Mini Rapid Test (RT)', '%')));

-- Item 89: BGX/FIN.RAPID/2026/000042 | HCG Rapid Big 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000042' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000042' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCG Rapid Big 50 Tests' OR `name` LIKE CONCAT('%', 'HCG Rapid Big 50 Tests', '%')));

-- Item 90: BGX/FIN.RAPID/2026/000043 | HCG Rapid Test 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000043' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000043' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCG Rapid Test 50 Tests' OR `name` LIKE CONCAT('%', 'HCG Rapid Test 50 Tests', '%')));

-- Item 91: BGX/FIN.RAPID/2026/000044 | HCG Rapid Test S/P 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000044' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000044' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCG Rapid Test S/P 50 Tests' OR `name` LIKE CONCAT('%', 'HCG Rapid Test S/P 50 Tests', '%')));

-- Item 92: BGX/FIN.RAPID/2026/000045 | HCV Rapid Test 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000045' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000045' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCV Rapid Test 50 Tests' OR `name` LIKE CONCAT('%', 'HCV Rapid Test 50 Tests', '%')));

-- Item 93: BGX/FIN.RAPID/2026/000046 | HCV Rapid Test Whole Blood 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000046' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000046' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCV Rapid Test Whole Blood 50 Tests' OR `name` LIKE CONCAT('%', 'HCV Rapid Test Whole Blood 50 Tests', '%')));

-- Item 94: BGX/FIN.RAPID/2026/000048 | HEV IGM Rapid Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000048' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000048' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HEV IGM Rapid Test' OR `name` LIKE CONCAT('%', 'HEV IGM Rapid Test', '%')));

-- Item 95: BGX/FIN.RAPID/2026/000049 | HIV 1/2 Rapid Test 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000049' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000049' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV 1/2 Rapid Test 10 Tests' OR `name` LIKE CONCAT('%', 'HIV 1/2 Rapid Test 10 Tests', '%')));

-- Item 96: BGX/FIN.RAPID/2026/000050 | HIV 1/2 Rapid Test Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000050' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000050' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV 1/2 Rapid Test Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'HIV 1/2 Rapid Test Biogenix 50 Tests', '%')));

-- Item 97: BGX/FIN.RAPID/2026/000051 | HIV 1/2 Rapid Test Osmcl 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000051' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000051' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV 1/2 Rapid Test Osmcl 10 Tests' OR `name` LIKE CONCAT('%', 'HIV 1/2 Rapid Test Osmcl 10 Tests', '%')));

-- Item 98: BGX/FIN.RAPID/2026/000052 | HIV 1/2 Rapid Test Osmcl 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000052' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000052' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV 1/2 Rapid Test Osmcl 50 Tests' OR `name` LIKE CONCAT('%', 'HIV 1/2 Rapid Test Osmcl 50 Tests', '%')));

-- Item 99: BGX/FIN.RAPID/2026/000053 | HIV Rapid Test Iv Generation Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000053' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000053' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV Rapid Test Iv Generation Test' OR `name` LIKE CONCAT('%', 'HIV Rapid Test Iv Generation Test', '%')));

-- Item 100: BGX/FIN.RAPID/2026/000055 | HSV-1 IGG/IGM Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000055' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000055' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HSV-1 IGG/IGM Test' OR `name` LIKE CONCAT('%', 'HSV-1 IGG/IGM Test', '%')));

-- Item 101: BGX/FIN.RAPID/2026/000056 | HSV-2 IGG/IGM Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000056' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000056' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HSV-2 IGG/IGM Test' OR `name` LIKE CONCAT('%', 'HSV-2 IGG/IGM Test', '%')));

-- Item 102: BGX/FIN.RAPID/2026/000057 | Janaushadhi Ankur HCG Test Kit 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000057' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000057' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Janaushadhi Ankur HCG Test Kit 10 Tests' OR `name` LIKE CONCAT('%', 'Janaushadhi Ankur HCG Test Kit 10 Tests', '%')));

-- Item 103: BGX/FIN.RAPID/2026/000059 | Leishmania IGG + IGM Rapid Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000059' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000059' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Leishmania IGG + IGM Rapid Test' OR `name` LIKE CONCAT('%', 'Leishmania IGG + IGM Rapid Test', '%')));

-- Item 104: BGX/FIN.RAPID/2026/000061 | Leptospira IGG + IGM Biogenix Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000061' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000061' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Leptospira IGG + IGM Biogenix Test' OR `name` LIKE CONCAT('%', 'Leptospira IGG + IGM Biogenix Test', '%')));

-- Item 105: BGX/FIN.RAPID/2026/000062 | LH Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000062' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000062' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'LH Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'LH Rapid Test POCT 25 Tests', '%')));

-- Item 106: BGX/FIN.RAPID/2026/000063 | LH Rapid Test, Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000063' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000063' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'LH Rapid Test, Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'LH Rapid Test, Biogenix 50 Tests', '%')));

-- Item 107: BGX/FIN.RAPID/2026/000065 | Malaria Antigen Pf/Pan Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000065' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000065' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Antigen Pf/Pan Test' OR `name` LIKE CONCAT('%', 'Malaria Antigen Pf/Pan Test', '%')));

-- Item 108: BGX/FIN.RAPID/2026/000066 | Malaria Pf/Pv Antigen 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000066' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000066' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Pf/Pv Antigen 50 Tests' OR `name` LIKE CONCAT('%', 'Malaria Pf/Pv Antigen 50 Tests', '%')));

-- Item 109: BGX/FIN.RAPID/2026/000067 | Malaria Pf/Pv Antigen Osmcl 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000067' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000067' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Pf/Pv Antigen Osmcl 10 Tests' OR `name` LIKE CONCAT('%', 'Malaria Pf/Pv Antigen Osmcl 10 Tests', '%')));

-- Item 110: BGX/FIN.RAPID/2026/000068 | Malaria Pf/Pv Antigen Up Govt 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000068' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000068' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Pf/Pv Antigen Up Govt 10 Tests' OR `name` LIKE CONCAT('%', 'Malaria Pf/Pv Antigen Up Govt 10 Tests', '%')));

-- Item 111: BGX/FIN.RAPID/2026/000069 | Microalbumin Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000069' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000069' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Microalbumin Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Microalbumin Rapid Test POCT 25 Tests', '%')));

-- Item 112: BGX/FIN.RAPID/2026/000070 | Neisseria Gonorrhoeae Rapid 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000070' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000070' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Neisseria Gonorrhoeae Rapid 10 Tests' OR `name` LIKE CONCAT('%', 'Neisseria Gonorrhoeae Rapid 10 Tests', '%')));

-- Item 113: BGX/FIN.RAPID/2026/000074 | Progesterone Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000074' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000074' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Progesterone Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Progesterone Rapid Test POCT 25 Tests', '%')));

-- Item 114: BGX/FIN.RAPID/2026/000075 | Prolactin Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000075' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000075' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Prolactin Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'Prolactin Rapid Test POCT 25 Tests', '%')));

-- Item 115: BGX/FIN.RAPID/2026/000076 | PSA Rapid Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000076' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000076' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'PSA Rapid Test' OR `name` LIKE CONCAT('%', 'PSA Rapid Test', '%')));

-- Item 116: BGX/FIN.RAPID/2026/000079 | Rota Virus Ag Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000079' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000079' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Rota Virus Ag Test' OR `name` LIKE CONCAT('%', 'Rota Virus Ag Test', '%')));

-- Item 117: BGX/FIN.RAPID/2026/000080 | Rubella IGG/IGM Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000080' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000080' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Rubella IGG/IGM Test' OR `name` LIKE CONCAT('%', 'Rubella IGG/IGM Test', '%')));

-- Item 118: BGX/FIN.RAPID/2026/000082 | Scrub Typhus IGG + IGM 30 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000082' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000082' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Scrub Typhus IGG + IGM 30 Tests' OR `name` LIKE CONCAT('%', 'Scrub Typhus IGG + IGM 30 Tests', '%')));

-- Item 119: BGX/FIN.RAPID/2026/000083 | Scrub Typhus IGG + IGM Rapid 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000083' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000083' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Scrub Typhus IGG + IGM Rapid 50 Tests' OR `name` LIKE CONCAT('%', 'Scrub Typhus IGG + IGM Rapid 50 Tests', '%')));

-- Item 120: BGX/FIN.RAPID/2026/000085 | Sickle Cell 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000085' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000085' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Sickle Cell 50 Tests' OR `name` LIKE CONCAT('%', 'Sickle Cell 50 Tests', '%')));

-- Item 121: BGX/FIN.RAPID/2026/000087 | Sickle Cell Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000087' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000087' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Sickle Cell Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'Sickle Cell Biogenix 50 Tests', '%')));

-- Item 122: BGX/FIN.RAPID/2026/000088 | Syphilis Rapid Test Serum/Plasma 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000088' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000088' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Syphilis Rapid Test Serum/Plasma 50 Tests' OR `name` LIKE CONCAT('%', 'Syphilis Rapid Test Serum/Plasma 50 Tests', '%')));

-- Item 123: BGX/FIN.RAPID/2026/000089 | Syphilis Rapid Test Whole Blood 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000089' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000089' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Syphilis Rapid Test Whole Blood 50 Tests' OR `name` LIKE CONCAT('%', 'Syphilis Rapid Test Whole Blood 50 Tests', '%')));

-- Item 124: BGX/FIN.RAPID/2026/000090 | Toxo IGG/IGM Rapid Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000090' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000090' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Toxo IGG/IGM Rapid Test' OR `name` LIKE CONCAT('%', 'Toxo IGG/IGM Rapid Test', '%')));

-- Item 125: BGX/FIN.RAPID/2026/000092 | Troponin I Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000092' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000092' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Troponin I Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'Troponin I Biogenix 50 Tests', '%')));

-- Item 126: BGX/FIN.RAPID/2026/000093 | Troponin I Biogenix Test 10 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000093' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000093' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Troponin I Biogenix Test 10 Tests' OR `name` LIKE CONCAT('%', 'Troponin I Biogenix Test 10 Tests', '%')));

-- Item 127: BGX/FIN.RAPID/2026/000095 | Typhoid IGG + IGM Rapid Test 30 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000095' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000095' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Typhoid IGG + IGM Rapid Test 30 Tests' OR `name` LIKE CONCAT('%', 'Typhoid IGG + IGM Rapid Test 30 Tests', '%')));

-- Item 128: BGX/FIN.RAPID/2026/000096 | Typhoid IGG + IGM Rapid Biogenix 50 Test
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000096' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.RAPID/2026/000096' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Typhoid IGG + IGM Rapid Biogenix 50 Test' OR `name` LIKE CONCAT('%', 'Typhoid IGG + IGM Rapid Biogenix 50 Test', '%')));

-- Item 129: BGX/FIN.POCT/2026/000039 | T3 Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.POCT/2026/000039' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.POCT/2026/000039' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'T3 Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'T3 Rapid Test POCT 25 Tests', '%')));

-- Item 130: BGX/FIN.POCT/2026/000042 | T4 Rapid Test POCT 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.POCT/2026/000042' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.POCT/2026/000042' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'T4 Rapid Test POCT 25 Tests' OR `name` LIKE CONCAT('%', 'T4 Rapid Test POCT 25 Tests', '%')));

-- Item 131: BGX/FIN.POCT/2026/000051 | TSH FIA Test 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.POCT/2026/000051' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.POCT/2026/000051' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'TSH FIA Test 25 Tests' OR `name` LIKE CONCAT('%', 'TSH FIA Test 25 Tests', '%')));

-- Item 132: BGX/FIN.SERO/2026/000007 | ASO Latex 100 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000007' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000007' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ASO Latex 100 Tests' OR `name` LIKE CONCAT('%', 'ASO Latex 100 Tests', '%')));

-- Item 133: BGX/FIN.SERO/2026/000008 | ASO Latex 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000008' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000008' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ASO Latex 25 Tests' OR `name` LIKE CONCAT('%', 'ASO Latex 25 Tests', '%')));

-- Item 134: BGX/FIN.SERO/2026/000009 | ASO Latex 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000009' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000009' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'ASO Latex 50 Tests' OR `name` LIKE CONCAT('%', 'ASO Latex 50 Tests', '%')));

-- Item 135: BGX/FIN.SERO/2026/000011 | CRP Latex 100 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000011' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000011' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Latex 100 Tests' OR `name` LIKE CONCAT('%', 'CRP Latex 100 Tests', '%')));

-- Item 136: BGX/FIN.SERO/2026/000012 | CRP Latex 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000012' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000012' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Latex 25 Tests' OR `name` LIKE CONCAT('%', 'CRP Latex 25 Tests', '%')));

-- Item 137: BGX/FIN.SERO/2026/000013 | CRP Latex 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000013' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000013' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Latex 50 Tests' OR `name` LIKE CONCAT('%', 'CRP Latex 50 Tests', '%')));

-- Item 138: BGX/FIN.SERO/2026/000015 | CRP Turbidimetric, Biogeni × 100 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000015' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000015' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Turbidimetric, Biogeni × 100 mL' OR `name` LIKE CONCAT('%', 'CRP Turbidimetric, Biogeni × 100 mL', '%')));

-- Item 139: BGX/FIN.SERO/2026/000016 | CRP Turbidimetric, Biogeni × 250 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000016' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000016' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Turbidimetric, Biogeni × 250 mL' OR `name` LIKE CONCAT('%', 'CRP Turbidimetric, Biogeni × 250 mL', '%')));

-- Item 140: BGX/FIN.SERO/2026/000017 | CRP Turbidimetric, Biogeni × 300 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000017' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000017' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Turbidimetric, Biogeni × 300 mL' OR `name` LIKE CONCAT('%', 'CRP Turbidimetric, Biogeni × 300 mL', '%')));

-- Item 141: BGX/FIN.SERO/2026/000018 | CRP Turbidimetric, Biogeni × 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000018' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000018' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Turbidimetric, Biogeni × 50 mL' OR `name` LIKE CONCAT('%', 'CRP Turbidimetric, Biogeni × 50 mL', '%')));

-- Item 142: BGX/FIN.SERO/2026/000019 | CRP Turbidimetric, Biogeni × 500 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000019' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000019' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'CRP Turbidimetric, Biogeni × 500 mL' OR `name` LIKE CONCAT('%', 'CRP Turbidimetric, Biogeni × 500 mL', '%')));

-- Item 143: BGX/FIN.SERO/2026/000021 | D.dimer Kit, Biogeni × 30 + 10 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000021' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000021' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'D.dimer Kit, Biogeni × 30 + 10 mL' OR `name` LIKE CONCAT('%', 'D.dimer Kit, Biogeni × 30 + 10 mL', '%')));

-- Item 144: BGX/FIN.SERO/2026/000022 | Ferritin Turbidimetric 40 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000022' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000022' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ferritin Turbidimetric 40 mL' OR `name` LIKE CONCAT('%', 'Ferritin Turbidimetric 40 mL', '%')));

-- Item 145: BGX/FIN.SERO/2026/000025 | HBA1C Turbidimetric Latex 40 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000025' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000025' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBA1C Turbidimetric Latex 40 mL' OR `name` LIKE CONCAT('%', 'HBA1C Turbidimetric Latex 40 mL', '%')));

-- Item 146: BGX/FIN.SERO/2026/000027 | Micro Albumin Turbidimetric Late × 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000027' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000027' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Micro Albumin Turbidimetric Late × 50 mL' OR `name` LIKE CONCAT('%', 'Micro Albumin Turbidimetric Late × 50 mL', '%')));

-- Item 147: BGX/FIN.SERO/2026/000028 | RF Latex Biogenix 100 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000028' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000028' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'RF Latex Biogenix 100 Tests' OR `name` LIKE CONCAT('%', 'RF Latex Biogenix 100 Tests', '%')));

-- Item 148: BGX/FIN.SERO/2026/000029 | RF Latex Biogenix 25 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000029' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000029' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'RF Latex Biogenix 25 Tests' OR `name` LIKE CONCAT('%', 'RF Latex Biogenix 25 Tests', '%')));

-- Item 149: BGX/FIN.SERO/2026/000030 | RF Latex Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000030' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000030' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'RF Latex Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'RF Latex Biogenix 50 Tests', '%')));

-- Item 150: BGX/FIN.SERO/2026/000031 | RF Turbidimetric Latex 50 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000031' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000031' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'RF Turbidimetric Latex 50 mL' OR `name` LIKE CONCAT('%', 'RF Turbidimetric Latex 50 mL', '%')));

-- Item 151: BGX/FIN.SERO/2026/000032 | RPR Latex Biogenix 100 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000032' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000032' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'RPR Latex Biogenix 100 Tests' OR `name` LIKE CONCAT('%', 'RPR Latex Biogenix 100 Tests', '%')));

-- Item 152: BGX/FIN.SERO/2026/000033 | RPR Latex Biogenix 50 Tests
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000033' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000033' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'RPR Latex Biogenix 50 Tests' OR `name` LIKE CONCAT('%', 'RPR Latex Biogenix 50 Tests', '%')));

-- Item 153: BGX/FIN.SERO/2026/000038 | Widal Biogenix 4x5 mL 4x5 mL
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000038' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/FIN.SERO/2026/000038' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Widal Biogenix 4x5 mL 4x5 mL' OR `name` LIKE CONCAT('%', 'Widal Biogenix 4x5 mL 4x5 mL', '%')));

-- Item 154: BGX/SF.BR.BIOC/2026/000002 | Adenosine Deaminase (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000002' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000002' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Adenosine Deaminase (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Adenosine Deaminase (Bulk Reagent)', '%')));

-- Item 155: BGX/SF.BR.BIOC/2026/000003 | Albumin (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000003' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000003' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Albumin (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Albumin (Bulk Reagent)', '%')));

-- Item 156: BGX/SF.BR.BIOC/2026/000004 | Alkaline Phosphatase (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000004' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000004' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Alkaline Phosphatase (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Alkaline Phosphatase (Bulk Reagent)', '%')));

-- Item 157: BGX/SF.BR.BIOC/2026/000005 | Ammonia (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000005' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000005' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Ammonia (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Ammonia (Bulk Reagent)', '%')));

-- Item 158: BGX/SF.BR.BIOC/2026/000006 | Amylase (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000006' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000006' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Amylase (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Amylase (Bulk Reagent)', '%')));

-- Item 159: BGX/SF.BR.BIOC/2026/000008 | Direct Bilirubin (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000008' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000008' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Direct Bilirubin (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Direct Bilirubin (Bulk Reagent)', '%')));

-- Item 160: BGX/SF.BR.BIOC/2026/000009 | Total Bilirubin (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000009' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000009' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total Bilirubin (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Total Bilirubin (Bulk Reagent)', '%')));

-- Item 161: BGX/SF.BR.BIOC/2026/000010 | Calcium (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000010' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000010' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Calcium (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Calcium (Bulk Reagent)', '%')));

-- Item 162: BGX/SF.BR.BIOC/2026/000011 | Chloride, Biogenix (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000011' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000011' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chloride, Biogenix (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Chloride, Biogenix (Bulk Reagent)', '%')));

-- Item 163: BGX/SF.BR.BIOC/2026/000012 | Cholesterol (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000012' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000012' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Cholesterol (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Cholesterol (Bulk Reagent)', '%')));

-- Item 164: BGX/SF.BR.BIOC/2026/000015 | Creatinine (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000015' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000015' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Creatinine (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Creatinine (Bulk Reagent)', '%')));

-- Item 165: BGX/SF.BR.BIOC/2026/000022 | Glucose (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000022' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000022' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Glucose (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Glucose (Bulk Reagent)', '%')));

-- Item 166: BGX/SF.BR.BIOC/2026/000025 | HDL-C Direct R1 + R2 (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000025' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000025' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HDL-C Direct R1 + R2 (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'HDL-C Direct R1 + R2 (Bulk Reagent)', '%')));

-- Item 167: BGX/SF.BR.BIOC/2026/000026 | LDL Precipitating Reagent (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000026' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000026' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'LDL Precipitating Reagent (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'LDL Precipitating Reagent (Bulk Reagent)', '%')));

-- Item 168: BGX/SF.BR.BIOC/2026/000035 | Microprotein (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000035' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000035' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Microprotein (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Microprotein (Bulk Reagent)', '%')));

-- Item 169: BGX/SF.BR.BIOC/2026/000036 | Phosphorus (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000036' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000036' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Phosphorus (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Phosphorus (Bulk Reagent)', '%')));

-- Item 170: BGX/SF.BR.BIOC/2026/000037 | Potassium (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000037' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000037' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Potassium (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Potassium (Bulk Reagent)', '%')));

-- Item 171: BGX/SF.BR.BIOC/2026/000038 | SGOT (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000038' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000038' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SGOT (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'SGOT (Bulk Reagent)', '%')));

-- Item 172: BGX/SF.BR.BIOC/2026/000039 | SGPT (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000039' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000039' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'SGPT (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'SGPT (Bulk Reagent)', '%')));

-- Item 173: BGX/SF.BR.BIOC/2026/000041 | Sodium (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000041' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000041' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Sodium (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Sodium (Bulk Reagent)', '%')));

-- Item 174: BGX/SF.BR.BIOC/2026/000046 | Total Protein (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000046' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000046' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Total Protein (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Total Protein (Bulk Reagent)', '%')));

-- Item 175: BGX/SF.BR.BIOC/2026/000047 | Triglyceride (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000047' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000047' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Triglyceride (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Triglyceride (Bulk Reagent)', '%')));

-- Item 176: BGX/SF.BR.BIOC/2026/000048 | Urea Berthelot (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000048' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000048' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea Berthelot (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Urea Berthelot (Bulk Reagent)', '%')));

-- Item 177: BGX/SF.BR.BIOC/2026/000049 | Urea UV (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000049' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000049' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urea UV (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Urea UV (Bulk Reagent)', '%')));

-- Item 178: BGX/SF.BR.BIOC/2026/000050 | Uric Acid (Bulk Reagent)
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000050' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.BR.BIOC/2026/000050' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Uric Acid (Bulk Reagent)' OR `name` LIKE CONCAT('%', 'Uric Acid (Bulk Reagent)', '%')));

-- Item 179: BGX/SF.US.RAPID/2026/000017 | Chikungunya IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000017' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000017' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chikungunya IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Chikungunya IgM (Uncut Sheet) Rapid', '%')));

-- Item 180: BGX/SF.US.RAPID/2026/000018 | Chikungunya IgG/IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000018' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000018' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Chikungunya IgG/IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Chikungunya IgG/IgM (Uncut Sheet) Rapid', '%')));

-- Item 181: BGX/SF.US.RAPID/2026/000031 | Dengue IgG/IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000031' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000031' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue IgG/IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Dengue IgG/IgM (Uncut Sheet) Rapid', '%')));

-- Item 182: BGX/SF.US.RAPID/2026/000033 | Dengue NS1 (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000033' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000033' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Dengue NS1 (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Dengue NS1 (Uncut Sheet) Rapid', '%')));

-- Item 183: BGX/SF.US.RAPID/2026/000035 | Filaria (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000035' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000035' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Filaria (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Filaria (Uncut Sheet) Rapid', '%')));

-- Item 184: BGX/SF.US.RAPID/2026/000037 | FOB (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000037' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000037' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'FOB (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'FOB (Uncut Sheet) Rapid', '%')));

-- Item 185: BGX/SF.US.RAPID/2026/000043 | H. pylori Antibody (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000043' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000043' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'H. pylori Antibody (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'H. pylori Antibody (Uncut Sheet) Rapid', '%')));

-- Item 186: BGX/SF.US.RAPID/2026/000044 | H. pylori Antigen (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000044' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000044' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'H. pylori Antigen (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'H. pylori Antigen (Uncut Sheet) Rapid', '%')));

-- Item 187: BGX/SF.US.RAPID/2026/000045 | HAV IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000045' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000045' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HAV IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HAV IgM (Uncut Sheet) Rapid', '%')));

-- Item 188: BGX/SF.US.RAPID/2026/000049 | HBsAg (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000049' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000049' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBsAg (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HBsAg (Uncut Sheet) Rapid', '%')));

-- Item 189: BGX/SF.US.RAPID/2026/000050 | HBsAg Whole Blood (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000050' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000050' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HBsAg Whole Blood (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HBsAg Whole Blood (Uncut Sheet) Rapid', '%')));

-- Item 190: BGX/SF.US.RAPID/2026/000051 | hCG Dipstick (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000051' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000051' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'hCG Dipstick (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'hCG Dipstick (Uncut Sheet) Rapid', '%')));

-- Item 191: BGX/SF.US.RAPID/2026/000052 | hCG Mini (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000052' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000052' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'hCG Mini (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'hCG Mini (Uncut Sheet) Rapid', '%')));

-- Item 192: BGX/SF.US.RAPID/2026/000053 | hCG Regular (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000053' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000053' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'hCG Regular (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'hCG Regular (Uncut Sheet) Rapid', '%')));

-- Item 193: BGX/SF.US.RAPID/2026/000055 | HCV Serum/Plasma (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000055' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000055' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCV Serum/Plasma (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HCV Serum/Plasma (Uncut Sheet) Rapid', '%')));

-- Item 194: BGX/SF.US.RAPID/2026/000056 | HCV Whole Blood (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000056' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000056' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HCV Whole Blood (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HCV Whole Blood (Uncut Sheet) Rapid', '%')));

-- Item 195: BGX/SF.US.RAPID/2026/000057 | HEV IgM Antibody (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000057' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000057' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HEV IgM Antibody (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HEV IgM Antibody (Uncut Sheet) Rapid', '%')));

-- Item 196: BGX/SF.US.RAPID/2026/000059 | HIV 1/2 (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000059' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000059' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV 1/2 (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HIV 1/2 (Uncut Sheet) Rapid', '%')));

-- Item 197: BGX/SF.US.RAPID/2026/000060 | HIV Fourth Generation (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000060' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000060' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'HIV Fourth Generation (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'HIV Fourth Generation (Uncut Sheet) Rapid', '%')));

-- Item 198: BGX/SF.US.RAPID/2026/000070 | Leptospira IgG/IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000070' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000070' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Leptospira IgG/IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Leptospira IgG/IgM (Uncut Sheet) Rapid', '%')));

-- Item 199: BGX/SF.US.RAPID/2026/000071 | LH (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000071' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000071' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'LH (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'LH (Uncut Sheet) Rapid', '%')));

-- Item 200: BGX/SF.US.RAPID/2026/000075 | Malaria Pan Antigen (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000075' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000075' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Pan Antigen (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Malaria Pan Antigen (Uncut Sheet) Rapid', '%')));

-- Item 201: BGX/SF.US.RAPID/2026/000076 | Malaria Pf/Pan Antigen (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000076' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000076' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Pf/Pan Antigen (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Malaria Pf/Pan Antigen (Uncut Sheet) Rapid', '%')));

-- Item 202: BGX/SF.US.RAPID/2026/000077 | Malaria Pf/Pv Antigen (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000077' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000077' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Malaria Pf/Pv Antigen (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Malaria Pf/Pv Antigen (Uncut Sheet) Rapid', '%')));

-- Item 203: BGX/SF.US.RAPID/2026/000091 | Scrub Typhus IgG/IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000091' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000091' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Scrub Typhus IgG/IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Scrub Typhus IgG/IgM (Uncut Sheet) Rapid', '%')));

-- Item 204: BGX/SF.US.RAPID/2026/000093 | Sickle Cell (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000093' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000093' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Sickle Cell (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Sickle Cell (Uncut Sheet) Rapid', '%')));

-- Item 205: BGX/SF.US.RAPID/2026/000095 | Syphilis Serum/Plasma (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000095' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000095' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Syphilis Serum/Plasma (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Syphilis Serum/Plasma (Uncut Sheet) Rapid', '%')));

-- Item 206: BGX/SF.US.RAPID/2026/000096 | Syphilis Whole Blood (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000096' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000096' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Syphilis Whole Blood (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Syphilis Whole Blood (Uncut Sheet) Rapid', '%')));

-- Item 207: BGX/SF.US.RAPID/2026/000104 | Toxoplasma IgG/IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000104' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000104' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Toxoplasma IgG/IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Toxoplasma IgG/IgM (Uncut Sheet) Rapid', '%')));

-- Item 208: BGX/SF.US.RAPID/2026/000106 | Troponin I (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000106' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000106' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Troponin I (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Troponin I (Uncut Sheet) Rapid', '%')));

-- Item 209: BGX/SF.US.RAPID/2026/000109 | Typhoid IgG/IgM (Uncut Sheet) Rapid
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000109' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.RAPID/2026/000109' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Typhoid IgG/IgM (Uncut Sheet) Rapid' OR `name` LIKE CONCAT('%', 'Typhoid IgG/IgM (Uncut Sheet) Rapid', '%')));

-- Item 210: BGX/SF.US.URIN/2026/000002 | Glucose and Protein (Uncut Sheet) Urinalysis
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000002' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000002' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Glucose and Protein (Uncut Sheet) Urinalysis' OR `name` LIKE CONCAT('%', 'Glucose and Protein (Uncut Sheet) Urinalysis', '%')));

-- Item 211: BGX/SF.US.URIN/2026/000003 | Glucose (Uncut Sheet) Urinalysis
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000003' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000003' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Glucose (Uncut Sheet) Urinalysis' OR `name` LIKE CONCAT('%', 'Glucose (Uncut Sheet) Urinalysis', '%')));

-- Item 212: BGX/SF.US.URIN/2026/000015 | Syphilis Dipstick (Uncut Sheet) Urinalysis
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000015' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000015' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Syphilis Dipstick (Uncut Sheet) Urinalysis' OR `name` LIKE CONCAT('%', 'Syphilis Dipstick (Uncut Sheet) Urinalysis', '%')));

-- Item 213: BGX/SF.US.URIN/2026/000016 | Urine Strip 10P (Uncut Sheet) Urinalysis
UPDATE `bom_master`
SET `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000016' LIMIT 1)
WHERE `finished_product_id` = (SELECT `id` FROM `products` WHERE `product_code` = 'BGX/SF.US.URIN/2026/000016' LIMIT 1)
   OR (`finished_product_id` IS NULL AND (`name` = 'Urine Strip 10P (Uncut Sheet) Urinalysis' OR `name` LIKE CONCAT('%', 'Urine Strip 10P (Uncut Sheet) Urinalysis', '%')));

-- 3. Synchronize product_bom table (Cross-Compatibility for direct legacy/reporting queries)
TRUNCATE TABLE `product_bom`;

INSERT INTO `product_bom` (
    `finished_product_id`,
    `raw_product_category_id`,
    `raw_product_id`,
    `qty_per_unit`,
    `status`,
    `created_by`,
    `created_at`
)
SELECT 
    bm.`finished_product_id`,
    bi.`raw_product_category_id`,
    bi.`raw_product_id`,
    bi.`qty_per_unit`,
    1,
    1,
    NOW()
FROM `bom_master` bm
JOIN `bom_items` bi ON bi.`bom_id` = bm.`id`
WHERE bm.`finished_product_id` IS NOT NULL
  AND bi.`raw_product_id` IS NOT NULL
  AND bm.`status` = 1
  AND bi.`status` = 1;

SET FOREIGN_KEY_CHECKS = 1;
