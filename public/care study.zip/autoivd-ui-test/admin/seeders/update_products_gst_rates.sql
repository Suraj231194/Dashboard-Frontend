-- =============================================================
-- Script: update_products_gst_rates.sql
-- Description: Updates gst_rate for all 3,288 inventory items
--              using `product_name` (environment-independent)
-- Source: "LiveInventoryList-withHSNCodes&GST.xlsx"
-- Date: 2026-08-30
-- Total Items: 3,288 (100% Unique Product Names)
-- =============================================================

UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA REAGENT, BIOGENIX 15 ML';   -- #1 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA REAGENT,BIOGENIX 100ml 100ml';   -- #2 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA REAGENT,BIOGENIX 105ml 105ml';   -- #3 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA REAGENT,BIOGENIX 30 ML';   -- #4 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALBUMIN 500 ML TAMILNADU 500 ML';   -- #5 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALBUMIN BIOGENIX 100 ML 100 ml';   -- #6 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALBUMIN BIOGENIX 200 ML 200ML';   -- #7 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALBUMIN BIOGENIX 500 ML 500ml';   -- #8 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALBUMIN REAGENT BIOGENIX 4X50ML';   -- #9 [Biochemistry] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALKALINE PHOSPHATASE 20ml 20ml';   -- #10 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALKALINE PHOSPHATASE BIOGENIX 100 ml';   -- #11 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALKALINE PHOSPHATASE BIOGENIX 200ML';   -- #12 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALKALINE PHOSPHATASE BIOGENIX 500ML';   -- #13 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALKALINE PHOSPHATASE BIOGENIX 50ML';   -- #14 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALPHA AMYLASE BIOGENIX 10 ML 10 ml';   -- #15 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALPHA AMYLASE BIOGENIX 100 ML 100 ml';   -- #16 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALPHA AMYLASE BIOGENIX 200ML 200ML';   -- #17 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALPHA AMYLASE BIOGENIX 500ML 500ML';   -- #18 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALPHA AMYLASE BIOGENIX 50ML 50ML';   -- #19 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMONIA BIOGENIX 10 ML 10 ml';   -- #20 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMONIA BIOGENIX 100 ML 100ml';   -- #21 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMONIA KIT 25 ML 25 ML';   -- #22 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMONIA KIT 50 ML 50 ML';   -- #23 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI A+B+D 3X10ML, 3X10ML';   -- #24 [Biochemistry] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'APOA 40ml';   -- #25 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'APOB 40ml 40ml';   -- #26 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Angiotensin Converting( ACE) 40ML';   -- #27 [Biochemistry] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN DIRECT BIOGENIX 100 100 ml';   -- #28 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN DIRECT BIOGENIX 200 200ML';   -- #29 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN DIRECT BIOGENIX 500 500ML';   -- #30 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN TOTAL BIOGENIX 100ML 100 ml';   -- #31 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN TOTAL BIOGENIX 200 200ML';   -- #32 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN TOTAL BIOGENIX 500 500ML';   -- #33 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILIRUBIN TOTAL BIOGENIX 50ML 50ml';   -- #34 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BILURBIN TOTAL BIOGENIX 50 ML 50ml';   -- #35 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bilurbin Direct,Biogenix 125ml';   -- #36 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bilurbin Total,Biogenix 125ml';   -- #37 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C-3 REAGENT KIT 60ML 60Ml';   -- #38 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C-4 REAGENT KIT 60 ML 60 ml';   -- #39 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CALCIUM 100 ML, BIOGENIX 100 ml';   -- #40 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CALCIUM BIOGENIX 200 ML 200ML';   -- #41 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHLORIDE BIOGENIX 200ML 200ML';   -- #42 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHLORIDE,BIOGENIX,100ML 100Ml';   -- #43 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHLORIDE,BIOGENIX,50ML 50ml';   -- #44 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHOLESTEROL 4X100ML 400ML';   -- #45 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHOLESTEROL BIOGENIX 100ML 100 ml';   -- #46 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB BIOGENIX 10 ML 10 ml';   -- #47 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB Reagent 500ml';   -- #48 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-NAC BIOGENIX 10 ML 10 ml';   -- #49 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREATNINE BIOGENIX 100 ML 100 ml';   -- #50 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREATNINE BIOGENIX 200 ML 200ML';   -- #51 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREATNINE BIOGENIX 500 ML 500ML';   -- #52 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calcium Reagent 500 ml 500ml';   -- #53 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholesterol Total Biogenix 200 200ML';   -- #54 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Creatnine (CREA) 80 ml';   -- #55 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Creatnine BIOGENIX 250 ml 250ML';   -- #56 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cystain C 60ml';   -- #57 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D CHECK D-N,2.5ML PCS Pcs';   -- #58 [Biochemistry] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FDP REAGENT(R1+R2)80ML 80 ML';   -- #59 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G6PD REAGENT KIT 40 ML';   -- #60 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G6PD Regent Kit 100 ml';   -- #61 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GAMA GT, BIOGENIX 100 ML';   -- #62 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GLUCOSE BIOGENIX 450 ML 450ml';   -- #63 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GLUCOSE BIOGENIX 500 ML 500 ml';   -- #64 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GLUCOSE, BIOGENIX 100ML';   -- #65 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gamma GT Biogenix 10ml';   -- #66 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gamma GT Biogenix 200ML 200ML';   -- #67 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gamma GT Biogenix 500ML 500ML';   -- #68 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C,With Calibrator 70 ML';   -- #69 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL CALIBRATOR';   -- #70 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL CHOLESTEROL TAMILNADU 160 ML';   -- #71 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Cholesterol 100 ml';   -- #72 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Cholesterol 200ML 200ML';   -- #73 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Cholesterol 500ML 500ML';   -- #74 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct 200ML 200ML';   -- #75 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct 300ML';   -- #76 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct 40ml';   -- #77 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct 500ml';   -- #78 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct 80ml';   -- #79 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct, Biogenix 320 ML 320ML';   -- #80 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1C REAGENT CONTROL Q1 1 ML';   -- #81 [Biochemistry] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1C REAGENT CONTROL Q2 1 ML';   -- #82 [Biochemistry] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Homocysteins 100 ML';   -- #83 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Homocysteins with Calibrator 150 ML';   -- #84 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IMMUNOGLOBIN IGA 100ML';   -- #85 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IRON & TIBC 35 NOS Nos';   -- #86 [Biochemistry] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoglobin IgA 40ml';   -- #87 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoglobin IgG 100ML';   -- #88 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoglobin IgG 40 ML';   -- #89 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoglobin IgM 40ml';   -- #90 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDH 100ml';   -- #91 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDH 50ml';   -- #92 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL CALIBRATOR PCS';   -- #93 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL DIRECT, BIOGENIX 40 ML 40 ml';   -- #94 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Direct 200ML 200ML';   -- #95 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Direct 300ml';   -- #96 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Direct 500ML 500ML';   -- #97 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Direct, Biogenix 320 ML 320ML';   -- #98 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LIPASE 40ml 40 ML';   -- #99 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LIPASE,Biogenix,100ml 100ml';   -- #100 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LIPOPROTIEN 50ML 50ML';   -- #101 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lipoprotein 40ml 40ml';   -- #102 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAGNESIUM BIOGENIX 200ML 200ML';   -- #103 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAGNESIUM BIOGENIX 500ML 500ML';   -- #104 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAGNESIUM, BIOGENIX 50 ML';   -- #105 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICRO PROTEIN 500 ML 500 ML';   -- #106 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICRO PROTEIN BIOGENIX 100 ML 100 Ml';   -- #107 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICRO PROTEIN BIOGENIX 50 ML 50 ml';   -- #108 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Magnesium,Biogenix,100Ml 100Ml';   -- #109 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Protein 10ml';   -- #110 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'POTASSIUM Biogenix 200 ML 200ML';   -- #111 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'POTTASIUM BIOGENIX 100ML 100ML';   -- #112 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Phosphorus 100ml 100ML';   -- #113 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Potassium Biogenix 50 ML';   -- #114 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'S.Cholesterol Biogenix 100 ml 10ml';   -- #115 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT 4X125ML 4X125ML';   -- #116 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT BIOGENIX 500ml 500ml';   -- #117 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT Biogenix 100ML 100 ml';   -- #118 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT Biogenix 50ML 50ml';   -- #119 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT, BIOGENIX 200 ML';   -- #120 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT (ALT) BIOGENIX 100 Ml 100 ml';   -- #121 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT Biogenix 50ML 50ml';   -- #122 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT, BIOGENIX 500 ML';   -- #123 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM BIOGENIX 100mL 100 ML';   -- #124 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM BIOGENIX 200 ML 200ML';   -- #125 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM BIOGENIX 50ml 50 ML';   -- #126 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM STANDARD 1 ML';   -- #127 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL & DIRECT BILIRUBIN 2x50 ML';   -- #128 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL & DIRECT BILIRUBUN 500ML 500ml';   -- #129 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL ALBUMIN 500ML TAMILNADU 500ML';   -- #130 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL PROTEIN 200ML';   -- #131 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL PROTEIN BIOGENIX 100 ML 100 ml';   -- #132 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL PROTEIN BIOGENIX 500 ML 500ml';   -- #133 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Bile Acid 120ml';   -- #134 [Biochemistry] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Bile Acid 160ml';   -- #135 [Biochemistry] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Bile Acid 40Ml';   -- #136 [Biochemistry] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Bile Acid, 80 ML';   -- #137 [Biochemistry] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triglyceride 50ML';   -- #138 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triglyceride Biogenix 100 ml 100 ml';   -- #139 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triglyceride Reagent Biogenix 2X50 ml';   -- #140 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triglyceride, Biogenix 200ML';   -- #141 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triglyceride, Biogenix 500 ML';   -- #142 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA 600 ML 600 ML';   -- #143 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA BERTHLOT BIOGENIX 100 ML 100 ml';   -- #144 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA BERTHLOT BIOGENIX 500 ML 500ML';   -- #145 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BIOGENIX 100 ML 100 ml';   -- #146 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BIOGENIX 20 ml';   -- #147 [Biochemistry] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BIOGENIX 50 ML 50ML';   -- #148 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BIOGENIX 500 ML 500ml';   -- #149 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV,BIOGENIX 250ml';   -- #150 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URIC ACID 4X50ML TAMILNADU 200ML';   -- #151 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URIC ACID, BIOGENIX 200ML';   -- #152 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URIC ACID, BIOGENIX 500 ML';   -- #153 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urea Berthlot, Biogenix 200ml';   -- #154 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uric Acid Biogenix 100 ml 100 ml';   -- #155 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uric Acid Biogenix 50 ml 50ML';   -- #156 [Biochemistry] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Analyzer Reaction Cuvettes pcs';   -- #157 [Clia] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Assay Cups Clia 1000Pcs';   -- #158 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Clia 200';   -- #159 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Clia 200';   -- #160 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Clia 200';   -- #161 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pre-Trigger Solution Clia 115ml';   -- #162 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Clia 200';   -- #163 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Trigger Solution Clia 115ml';   -- #164 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin B12 Clia 200';   -- #165 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D Clia 200';   -- #166 [Clia] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25(OH)D CLIA 20Test';   -- #167 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Clia Kit 200Test';   -- #168 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Clia Kit @5% 200 Test';   -- #169 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH CLIA 40Test';   -- #170 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Clia Kit 200 Test';   -- #171 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Clia Kit @5% 200 Test';   -- #172 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'B-hCG CLIA 40Test';   -- #173 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG Clia Kit 200Test';   -- #174 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG Clia Kit @5% 200 Test';   -- #175 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 125 Clia Kit 200Test';   -- #176 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 125 Clia Kit @5% 200 Test';   -- #177 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Clia Kit 200Test';   -- #178 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Clia Kit @5% 200 Test';   -- #179 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHEMILUMISUBSTRATE BUFFER CLIA 500ML*1';   -- #180 [Clia Kits] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB CLIA 40Test';   -- #181 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CUVETTES (CLIA) 500/PKT';   -- #182 [Clia Kits] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'E2 CLIA 40Test';   -- #183 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Calibrator(0-3) 1ml x4vial';   -- #184 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Clia Kit 200Test';   -- #185 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Clia Kit @5% 200 Test';   -- #186 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Quality Control(L,H) 1ml x2vial';   -- #187 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Working Cal.(0-5) 1ml x6vial';   -- #188 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOLATE CLIA KIT 200 TEST';   -- #189 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH CLIA 40Test';   -- #190 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH CLIA KIT 200 TEST';   -- #191 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH CLIA KIT @5% 200 Test';   -- #192 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT3 CLIA 40Test';   -- #193 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT3 Clia Kit 200Test';   -- #194 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT3 Clia Kit @5% 200 Test';   -- #195 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT4 CLIA 40Test';   -- #196 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT4 Clia Kit 200Test';   -- #197 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT4 Clia Kit @5% 200 Test';   -- #198 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin CLIA 40Test';   -- #199 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Clia Kit @5% 200 Test';   -- #200 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Clia Kit @5% 200 Test';   -- #201 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV CLIA KITS';   -- #202 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV CLIA';   -- #203 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH CLIA 40Test';   -- #204 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH CLIA KIT 200 TEST';   -- #205 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH CLIA KIT @5% 200 Test';   -- #206 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MYO CLIA 40Test';   -- #207 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro BNP Clia Kit 200Test';   -- #208 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro BNP Clia Kit @5% 200 Test';   -- #209 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRE-TRIGGER SOLUTION CLIA 100ml*2';   -- #210 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL CLIA 40Test';   -- #211 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROLACTIN CLIA KIT 200 TEST';   -- #212 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pre-Trigger 110ml';   -- #213 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone CLIA 20Test';   -- #214 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prolactin Clia Kit @5% 200 Test';   -- #215 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 CLIA KIT 200 TEST';   -- #216 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Clia Kit @5% 200 Test';   -- #217 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 CLIA KIT 200 TEST';   -- #218 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Clia Kit @5% 200 Test';   -- #219 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPO Ab CLIA 20Test';   -- #220 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Clia Reagent 200Test';   -- #221 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Clia Reagent @5% 200 Test';   -- #222 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH CLIA 40Test';   -- #223 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH CLIA KIT 200 TEST';   -- #224 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator(0-2) 1ml x3vial';   -- #225 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Clia Kit @5% 200 Test';   -- #226 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Quality Control(L,H) 1ml x2vial';   -- #227 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Working Calibrator(0-5) 1ml x6vial';   -- #228 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TT3 CLIA 40Test';   -- #229 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TT4 CLIA 40Test';   -- #230 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone CLIA 40Test';   -- #231 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Calibrator(0-3) 1ml x3vial';   -- #232 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Clia Kits 200Test';   -- #233 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Clia Kits @5% 200 Test';   -- #234 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Qlty Control(L,H) 1ml x2vial';   -- #235 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Working Cal.(0-5) 1ml x6vial';   -- #236 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Trigger 110ml';   -- #237 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN B12 CLIA KIT 200 TEST';   -- #238 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin B12 Clia Kit @5% 200 Test';   -- #239 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D Calibrator(0-2) 1ml x3vial';   -- #240 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D Clia Kit 200Test';   -- #241 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D Clia Kit @5% 200 Test';   -- #242 [Clia Kits] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D Quality Control(L,H) 1ml x2vial';   -- #243 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D Working Cal.(0-5) 1ml x6vial';   -- #244 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WASH BUFFER(CLIA) 250ML*2';   -- #245 [Clia Kits] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WS WASH BUFFER(CLIA) 60ML*2';   -- #246 [Clia Kits] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Wash Buffer 1 Ltr';   -- #247 [Clia Kits] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '1.5 Anhydroglucitol Elisa 96 Test';   -- #248 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '17-OH-Progesterone Elisa 96 Test';   -- #249 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '17-OH-Progesterone Elisa ALB 96 TEST';   -- #250 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2 Met Plasma Fast Track,LDN 96*2';   -- #251 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2 Met Urine Elisa 96*2';   -- #252 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25 OH Vitamin D Elisa 96 TEST 96 Test';   -- #253 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '3 Cat Elisa Fast Track,LDN 96*3';   -- #254 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ACHR Ab Elisa Rsr 96Test';   -- #255 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ACTH ELISA 96 WELLS';   -- #256 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ACTH Elisa,Biomerica 96 Test';   -- #257 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Elisa Kit 96 Test';   -- #258 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Control 6*2ml';   -- #259 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Elisa 96 TEST 96 Test';   -- #260 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANA Elisa Biogenix 96 Test 96 Test';   -- #261 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANA Screen Elisa 96 Test';   -- #262 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANA-Hep2 IFA (20x12 Wells) Kit';   -- #263 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANCA Ethanol IFA 10*6 Wells 10*6 Wells';   -- #264 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP Elisa LD 96Test';   -- #265 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASA IgM Elisa 96 Test';   -- #266 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASPERGILLUS IgM ELISA 96 Test';   -- #267 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Adenovirus Ag Elisa 96Test';   -- #268 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Androstendione Elisa,LDN 96 Wells';   -- #269 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Beta2 Glycoprotein Elisa 96 Test';   -- #270 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CCP Elisa 96 Test';   -- #271 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CP IgG 96 TEST';   -- #272 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Cardiolupin IgA Elisa 96Test';   -- #273 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Cardiolupin IgG Elisa 96 Test';   -- #274 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Cardiolupin IgM Elisa 96 Test';   -- #275 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Cardiolupin Screen Elisa 96 Test';   -- #276 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti DGP IgG EIA 96Test';   -- #277 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti HBsAb Elisa 96 Test 96 Test';   -- #278 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti MPO Elisa 96 TEST';   -- #279 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti PR3 Elisa 96 Test';   -- #280 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Phospholipid IgG Elisa 96Test';   -- #281 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Phospholipid IgG/IgM Elis 96Test';   -- #282 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Phospholipid IgM Elisa 96Test';   -- #283 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Phospholipid Screen Elisa 96 Test';   -- #284 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti TPO Elisa 96 Test';   -- #285 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-MPO(P-ANCA) 96Test';   -- #286 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Apergillus Glactomannan Elisa 96Test';   -- #287 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Apergillus IgE Elisa 96 Test';   -- #288 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aspergillus Fumigates IgE Elis 96Test';   -- #289 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aspergillus Fumigatus IgG 96 Wells';   -- #290 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aspergillus Galactomannan 96T 96 TEST';   -- #291 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aspergillus IgG Elisa 96 Test';   -- #292 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG Elisa,Biogenix 96 TEST';   -- #293 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Brucella IgG 96 Test';   -- #294 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Brucella IgM 96 Test';   -- #295 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C-ANCA ELISA 96 WELLS';   -- #296 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C-Peptide Elisa 96 Test 96 Test';   -- #297 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 125 Elisa 96 Test 96 Test';   -- #298 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Elisa 96 test 96 Test';   -- #299 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Elisa 96 test 96 Test';   -- #300 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Elisa(Xema) 96wells';   -- #301 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CALCITONIN ELISA,Biogenix 96 TEST';   -- #302 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEA ELISA KIT 96 Test';   -- #303 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEA-S ELISA 96TEST';   -- #304 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHLAMYDIA IgA, Biogenix 96 test';   -- #305 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IgG Elisa 96 Test 96 Test';   -- #306 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IgM Elisa 96 Test 96 Test';   -- #307 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IgM Elisa Diapro 96 Test 96 Test';   -- #308 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Canine Collagen Type1 Elisa 96Test';   -- #309 [Elisa] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chik JJ Detect IgG Elisa 96 Test';   -- #310 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgG Elisa 96 TEST';   -- #311 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgG Elisa DP 96 Test';   -- #312 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgM Elisa 96 TEST';   -- #313 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgM Elisa DP 96 Test';   -- #314 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgG Elisa 96 TEST';   -- #315 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgM Elisa 96 TEST';   -- #316 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chromogranin A Elisa 96 Test';   -- #317 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cortisol Elisa  96 Test 96 Test';   -- #318 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cortisol Saliva Elisa 96Test';   -- #319 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cysticercosis Elisa 96 Test';   -- #320 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DHEA S Elisa 96 Test 96 Test';   -- #321 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgG Elisa DP 96 Test';   -- #322 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgG Elisa Sekbio 96Test';   -- #323 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgG Elisa, Biogenix 96 TEST';   -- #324 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgM Elisa 96 Test';   -- #325 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgM Elisa DP 96 Test';   -- #326 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgM Elisa Sekbio 96Test';   -- #327 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Elisa 96 Test';   -- #328 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Elisa DP 96 Test';   -- #329 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Elisa Sekbio 96Test';   -- #330 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dog/Canine NSE Elisa Kit 96Test';   -- #331 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dog/Canine TGFb1 Elisa Kit 96Test';   -- #332 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'E.Histolytica IgG Elisa 96 TEST';   -- #333 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'EBV IGG ELISA 96 TEST';   -- #334 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Echinoccous IgG Elisa 96 TEST';   -- #335 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Entilink 1st Strnd cDNA 50rxn';   -- #336 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Elisa 96 Test 96 Test';   -- #337 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol Elisa, LDN 96 Test';   -- #338 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOLATE ELISA KIT 96TEST 96TEST';   -- #339 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOOD DETECTIVE, OMEGA 05 TEST';   -- #340 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FREE TESTOSTERONE ELISA KIT 96 TEST';   -- #341 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Elisa 96 Test 96 Test';   -- #342 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Elisa  96 Test 96 Test';   -- #343 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folic Acid Elisa Kit 96 Test';   -- #344 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free Beta hCG Elisa kit 96 Test';   -- #345 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free PSA Elisa 96 Test 96 Test';   -- #346 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free T3 ELISA, Alkor 96 TEST';   -- #347 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free T3 Elisa 96 Test 96 Test';   -- #348 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free T4 ELISA, Alkor 96 TEST';   -- #349 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free T4 Elisa 96 Test 96 Test';   -- #350 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free Testosterone Diametra 96 96 Test';   -- #351 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fungus 1.3 Beta D Glucan 96 Test';   -- #352 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GA-LKM-1-Antibody Elisa 96Test';   -- #353 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GAD Elisa 96 Test 96 Test';   -- #354 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gliadin IgA 96Test';   -- #355 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gliadin IgG 96Test';   -- #356 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.Pylori IgG Elisa 96 Test';   -- #357 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.Pylori IgM Elisa 96 Test';   -- #358 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HAV IgG Elisa 96 Test 96 Test';   -- #359 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HAV IgM Elisa 96 Test 96 Test';   -- #360 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HAV IgM Elisa Diapro 96 Test 96 Test';   -- #361 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBCAb,Elisa Diapro 96 TEST';   -- #362 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBSAB ELISA QUANTITATIVE 96 TEST';   -- #363 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBSAB(ANTISURA B-96 TMB ELISA 96 TEST';   -- #364 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBSAG ELISA, GBC 96 WELLS';   -- #365 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBc IgM Elisa 96 Test 96 Test';   -- #366 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBc IgM Elisa Biov 96 Test';   -- #367 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBc IgM Elisa Diapro 96 Test 96 test';   -- #368 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBc Total Elisa 96 Test 96 Test';   -- #369 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBcAb Elisa 96 Test 96 Test';   -- #370 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBeAb ELISA BIOVANTION';   -- #371 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBeAb Elisa 96 Test 96 Test';   -- #372 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBeAg ELISA BIOVANTION';   -- #373 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBeAg Elisa 96 Test 96 Test';   -- #374 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBeAg&Ab Elisa Diapro 96Test';   -- #375 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAb ELISA BIOVANTION';   -- #376 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAb Elisa 96 TEST 96 TEST';   -- #377 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAb Elisa Diapro 96 TEST 96Test';   -- #378 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg Elisa 96 Test';   -- #379 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV ELISA GBC 96 WELLS';   -- #380 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Elisa 96 Test 96 TEST';   -- #381 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDV Elisa Ab 96Test';   -- #382 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDV Elisa IgM 96Test';   -- #383 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HE4 Elisa 96Test';   -- #384 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IgG Elisa 96 Test 96 Test';   -- #385 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IgM Elisa 96 Test 96 Test';   -- #386 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IgM Elisa DP 96 Test 96Test';   -- #387 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV-IgG ELISA BIOVANTION';   -- #388 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HGH Elisa 96 Test 96 Test';   -- #389 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV Elisa 96 Test';   -- #390 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HS CRP Elisa BIOGENIX 96wells';   -- #391 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1 IgG Elisa 96 Test 96 Test';   -- #392 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1 IgM Elisa 96 Test 96 Test';   -- #393 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1+2 IgM Elisa 96 TEST 96 TEST';   -- #394 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1+2 IgM Elisa,Dia.Pro 96 Test';   -- #395 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1/2 IgG 96Test';   -- #396 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1/2 IgG, DIAPRO 96 Test';   -- #397 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 2 IgG Elisa 96 Test 96 Test';   -- #398 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 2 IgM Elisa 96 Test 96 Test';   -- #399 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN IL-2sRA/CD25 ELISA KIT 96 TEST';   -- #400 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN VB6(VITAMIN B6) ELISA 48TEST';   -- #401 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN VB6(VITAMIN B6) ELISA 96 TEST';   -- #402 [Elisa] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN sTNF ALFA 96TEST';   -- #403 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbcAb IgM';   -- #404 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human 1.5-Anhydroglucitol 96Test';   -- #405 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Adiponectin Elisa 96 Test';   -- #406 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Anti-AChR Elisa, ELK 96 Wells';   -- #407 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Bcl2  Elisa 96 WELLA';   -- #408 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human CCND1 Elisa 96 WELLS';   -- #409 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human CHADL/Chondroadherin 96Test';   -- #410 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human COL2a1(Collage II) Elisa 96 Wells';   -- #411 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human CYFRA21-1 Elisa 96Test';   -- #412 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Cys-C Elisa 96T';   -- #413 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human ERFE Elisa Kit 96 Test';   -- #414 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human FGF23 Elisa 96Test';   -- #415 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Folic Acid Elisa 96Test';   -- #416 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human GFAP 96Test';   -- #417 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human GLP-1 96Test';   -- #418 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human HBsAb Quantitative Elisa 96 wells';   -- #419 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Hepcidin Elisa Kit 96Test';   -- #420 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IFABP/FABP2 Elisa Kit 96 Test';   -- #421 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IFN-Y 96Test';   -- #422 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-10 Elisa Kit 96Test';   -- #423 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-12 Elisa Kit 96Test';   -- #424 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-17A Elisa Kit 96Test';   -- #425 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-18 Elisa Kit 96Test';   -- #426 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-1B Elisa Kit 96Test';   -- #427 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-2 Elisa Kit 96Test';   -- #428 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-5 Elisa Kit 96Test';   -- #429 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-6 Elisa Kit 96 Test';   -- #430 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-7 Elisa Kit 96Test';   -- #431 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-8 Elisa Kit 96Test';   -- #432 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL-9 Elisa Kit 96Test';   -- #433 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IL17(Interleukin17) 96Test';   -- #434 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IP-10/CXCL 10 96Test';   -- #435 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human IgA Immunoglobin A 96Test';   -- #436 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Ki67 Protein Elisa 96 WELLS';   -- #437 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human LBP 96Test';   -- #438 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human M-AChR Elisa Kit 96 Test';   -- #439 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human MMP12 Elisa 96Test';   -- #440 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human MMP2 Elisa 96Test';   -- #441 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human MMP9 Elisa 96Test';   -- #442 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human NEFL Elisa Kit 96 Test';   -- #443 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human NSE 96Test';   -- #444 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human PDE5A Elisa EHO904 96Test';   -- #445 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human PDGF-BB 96Test';   -- #446 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human PIVKA-II Elisa 96T';   -- #447 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human RETN Elisa Kit 96 Test';   -- #448 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human SCCA1 Elisa 96Test';   -- #449 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human TCPa(Alpha-Tocopherol) 96Test';   -- #450 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human TNF Alfa 96Test';   -- #451 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Total Protein (TP)53 96 WELLS';   -- #452 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human VB1 Elisa 48TEST';   -- #453 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human VB1 Elisa 96T';   -- #454 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Zonulin Elisa Kit 96 Kits';   -- #455 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human bFGF/FGF2 96Test';   -- #456 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IGF-1 ELISA KIT 96Wells KIT';   -- #457 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'INHIBIN B GEN II';   -- #458 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'INHIBIN B GEN II CAL AND CS';   -- #459 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immuchrom-Pankreatische Elisa 96Test';   -- #460 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Inhibin A Elisa 96Test';   -- #461 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Insulin Elisa 96 Test 96 Test';   -- #462 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'JE IgM Elisa Kit 96 Test';   -- #463 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Elisa 96 Test 96 Test';   -- #464 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Legionella IgM Elisa 96 Test';   -- #465 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leptospira IgG, 96Test';   -- #466 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leptospira IgM 96 test';   -- #467 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Measles IgG 96 Test';   -- #468 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Measles IgM 96 Test';   -- #469 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Metanephrine Plasma Elis F.T 96 wells';   -- #470 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monocent Vitamin B12 Elisa 96 Test';   -- #471 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mumps Virus IgG 96 TEST';   -- #472 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mumps Virus IgM 96 TEST';   -- #473 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mycoplasma Pneumoniae IgM 96Test';   -- #474 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Myoglobin 96Test';   -- #475 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NGAL Elisa Kit 96Test';   -- #476 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT PROBNP 96TEST';   -- #477 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Norovirus Ag Elisa 96Test';   -- #478 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nova Lite Rat Liver,Kidney Kit';   -- #479 [Elisa] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'P-ANCA ELISA 96 WELLS';   -- #480 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PAPP-A Elisa 96 Test 96 Test';   -- #481 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PG Progesterone Elisa, ELK 96 Wells';   -- #482 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROCALCITONIN ELISA 96 TEST';   -- #483 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PSA TOTAL EILISA, BIOGENIX 96 TEST';   -- #484 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PTH Elisa 96 Test 96 Test';   -- #485 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pancreatic Elastage Kit 96 Test';   -- #486 [Elisa] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Parvovirus B19 IgG 96 Test';   -- #487 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Parvovirus B19 IgM 96 Test';   -- #488 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pig Estrogen (Estradiol) ELK08 96 Wells';   -- #489 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Procalcitonin Elisa Kit 96Test';   -- #490 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone Elis LDN 96 Test';   -- #491 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone Elisa 96 test 96 Test';   -- #492 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prolactin  Elisa 96 Test 96 Test';   -- #493 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RA CCP Elisa Kit 96Test';   -- #494 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF IGM ELISA 96 WELLS';   -- #495 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Total Elisa 96Test';   -- #496 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rota Virus Elisa kit 96 Test';   -- #497 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rubella IgG Elisa 96 Test 96 Test';   -- #498 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rubella IgG,Diapro 96 Test';   -- #499 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rubella IgM Elisa 96 Test 96 Test';   -- #500 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rubella IgM,Diapro 96 Test';   -- #501 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SEROTONIN ELISA FAST TARCK,LDN 96 WELLS';   -- #502 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SHBG Elisa 96 Test 96 Test';   -- #503 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SPECIFIC IGG 96 WELLS';   -- #504 [Elisa] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Scrub Typhus IgG, 96Test';   -- #505 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Scrub Typhus IgM, 96 TEST';   -- #506 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Specific IgE Elisa 96 Test';   -- #507 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphilis Elisa 96 Test 96 Test';   -- #508 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Total Elisa 96 test 96 Test';   -- #509 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Total Elisa 96 TEST 96 Test';   -- #510 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TB-IGRA 45Test';   -- #511 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TB-Inferon Gold Pluse 28 Test';   -- #512 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TG Elisa 96 Test 96 Test';   -- #513 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TGF Beta 1 96Test';   -- #514 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IgE, 96 TEST';   -- #515 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPHA 200 T RAPID 200Test';   -- #516 [Elisa] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Elisa 96 Test 96 Test';   -- #517 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Receptor Ab Elisa 96Test';   -- #518 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TTG IgA Elisa Kits 96 Test';   -- #519 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TTG IgG Elisa Kit 96 Test';   -- #520 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Taenia Solium IgG Novatec 96 Test';   -- #521 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Elisa 96 Test 96 Test';   -- #522 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total IgE Elisa Kit 96 Test';   -- #523 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total RNA Extraction Kit 200Test';   -- #524 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total RNA Extraction Kit 50Test';   -- #525 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxo IgG Elisa 96 Test 96 Test';   -- #526 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxo IgG,Diapro 96 Test';   -- #527 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxo IgM Elisa 96 Test 96 Test';   -- #528 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxo IgM,Diapro 96 Test 96 Test';   -- #529 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB6(Vitamin B6)Elisa 96Test';   -- #530 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VC(Vitamin C)Elisa 48TEST';   -- #531 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VC(Vitamin C)Elisa 96Test';   -- #532 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN B-12,Lilac 96 TEST';   -- #533 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VK1(VITAMIN K1) ELISA 48TEST';   -- #534 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VK1(VITAMIN K1) ELISA 96 TEST';   -- #535 [Elisa] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VZV IgG Elisa 96Test 96Test';   -- #536 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VZV IgM Elisa 96Test 96Test';   -- #537 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vericella VZV IgG 96Test 96Test';   -- #538 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin B12 Elisa 96 test 96 Test';   -- #539 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin B12 Elisa(Monocent) 96 Test';   -- #540 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'dsDNA Elisa 96 Test 96 Test';   -- #541 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'hCG Elisa 96 Test Kit 96 TEST';   -- #542 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'uE3 Elisa Kit 96Test';   -- #543 [Elisa] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Calibrator S0 IE00601S10 ml';   -- #544 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Calibrator S1 IE00601S11 ml';   -- #545 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Calibrator S2 IE00601S12 ml';   -- #546 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Calibrator S3 IE00601S13 ml';   -- #547 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Calibrator S4 IE00601S14 ml';   -- #548 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Calibrator S5 IE00601S15 ml';   -- #549 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP CalibratorE-C1 IE00601P11 ml';   -- #550 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP CalibratorE-C2 IE00601P12 ml';   -- #551 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP CalibratorE-C3 IE00601P13 ml';   -- #552 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Control CH IE00601C12 ml';   -- #553 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Control CL IE00601C11 ml';   -- #554 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Reagent Ra IE00601M11 ml';   -- #555 [Fapon] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Reagent Rd IE00601R11 ml';   -- #556 [Fapon] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator E-C1 IE03701P11 Vial';   -- #557 [Fapon] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator E-C2 IE03701P12 Vial';   -- #558 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator E-C3 IE03701P13 Vial';   -- #559 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator S0 IE03701S10 Vial';   -- #560 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator S1 IE03701S11 Vial';   -- #561 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator S2 IE03701S12 Vial';   -- #562 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator S3 IE03701S13 Vial';   -- #563 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator S4 IE03701S14';   -- #564 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Calibrator S5 IE03701S15 Vial';   -- #565 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Q. Control CH IE03701C12 Vial';   -- #566 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Q.Control CL IE03701C11 Vial';   -- #567 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Reagent RA IE03701M11 Vial';   -- #568 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Reagent RD IE03701R11 Vial';   -- #569 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Assay Cups 602-000417-10 Bag';   -- #570 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Control CH IE00901C12 ml';   -- #571 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Control CL IE00901C11 ml';   -- #572 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Reagent Ra IE00901M11 ml';   -- #573 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Reagent Rc IE00901R11 ml';   -- #574 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Reagent Rd IE00901R12 ml';   -- #575 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3CalibratorS0 IE00901S10 ml';   -- #576 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3CalibratorS1 IE00901S11 ml';   -- #577 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3CalibratorS2 IE00901S12 ml';   -- #578 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3CalibratorS3 IE00901S13 ml';   -- #579 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3CalibratorS4 IE00901S14 ml';   -- #580 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3CalibratorS5 IE00901S15 ml';   -- #581 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Control CH IE01101C12 ml';   -- #582 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Control CL IE01101C11 ml';   -- #583 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Reagent Ra IE01101M11 ml';   -- #584 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Reagent Rc IE01101R11 ml';   -- #585 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9 Reagent Rd IE01101R12 ml';   -- #586 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9CalibratorS0 IE01101S10 ml';   -- #587 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9CalibratorS1 IE01101S11 ml';   -- #588 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9CalibratorS2 IE01101S12 ml';   -- #589 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9CalibratorS3 IE01101S13 ml';   -- #590 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9CalibratorS4 IE01101S14 ml';   -- #591 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 19.9CalibratorS5 IE01101S15 ml';   -- #592 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA15.3CalibratorEC1 IE00901P11 ml';   -- #593 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA15.3CalibratorEC2 IE00901P12 ml';   -- #594 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA15.3CalibratorEC3 IE00901P13 ml';   -- #595 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA19.9CalibratorE-C1IE01101P11 ml';   -- #596 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA19.9CalibratorE-C2IE01101P12 ml';   -- #597 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA19.9CalibratorE-C3IE01101P13 ml';   -- #598 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Concen. Wash Buffer IT00002W11 Ltr';   -- #599 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Concentrated Wash Buffer LTR';   -- #600 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Enhanced  Wash Buffer LTR';   -- #601 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator E-C1 IE03101P11 ml';   -- #602 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator E-C2 IE03101P12 ml';   -- #603 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator E-C3 IE03101P13 ml';   -- #604 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator S0 IE03101S10 ml';   -- #605 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator S1 IE03101S11 ml';   -- #606 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator S2 IE03101S12 ml';   -- #607 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator S3 IE03101S13 ml';   -- #608 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator S4 IE03101S14 ml';   -- #609 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator S5 IE03101S15 ml';   -- #610 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Calibrator(C1 To C3) ml';   -- #611 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Control CH IE03101C12 ml';   -- #612 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Control CL IE03101C11 ml';   -- #613 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Control(CL & CH) ml';   -- #614 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Reagent RA IE03101M11 ml';   -- #615 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Reagent RD IE03101R11 ml';   -- #616 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Reagent(M11 & R11) ml';   -- #617 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Cali E-C1 IE00A0701C1 ml';   -- #618 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Cali E-C2 IE00A0701C2 ml';   -- #619 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Cali E-C3 IE00A0701C3 ml';   -- #620 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calib S0 IE00A0701S0';   -- #621 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calib S1 IE00A0701S1 ml';   -- #622 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calib S2 IE00A0701S2 ml';   -- #623 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calib S3 IE00A0701S3 ml';   -- #624 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calib S4 IE00A0701S4 ml';   -- #625 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calib S5 IE00A0701S5 ml';   -- #626 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin ControlCH IE00A0701Q2 ml';   -- #627 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin ControlCL IE00A0701Q1 ml';   -- #628 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin ReagentRa IE00A0701RA ml';   -- #629 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin ReagentRd IE00A0701RB ml';   -- #630 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Calibr E-C1 IE00A1001C1 ml';   -- #631 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Calibr E-C2 IE00A1001C2 ml';   -- #632 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Calibr E-C3 IE00A1001C3 ml';   -- #633 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Control CH IE00A1001Q2 ml';   -- #634 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Control CL IE00A1001Q1 ml';   -- #635 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Reagent PTA IE00A1001RD ml';   -- #636 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Reagent PTB IE00A1001RE ml';   -- #637 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Reagent Ra IE00A1001RA ml';   -- #638 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Reagent Rc IE00A1001RC ml';   -- #639 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Folate Reagent Rd IE00A1001RB ml';   -- #640 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FolateCalibratorS0 IE00A1001S0 ml';   -- #641 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FolateCalibratorS1 IE00A1001S1 ml';   -- #642 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FolateCalibratorS2 IE00A1001S2 ml';   -- #643 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FolateCalibratorS3 IE00A1001S3 ml';   -- #644 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FolateCalibratorS4 IE00A1001S4 ml';   -- #645 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FolateCalibratorS5 IE00A1001S5 ml';   -- #646 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator E-C1 IE03001P11 ml';   -- #647 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator E-C2 IE03001P12 ml';   -- #648 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator E-C3 IE03001P13 ml';   -- #649 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator S0 IE03001S10 ml';   -- #650 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator S1 IE03001S11 ml';   -- #651 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator S2 IE03001S12 ml';   -- #652 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator S3 IE03001S13 ml';   -- #653 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator S4 IE03001S14 ml';   -- #654 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator S5 IE03001S15 ml';   -- #655 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Calibrator(C1 To C3) ml';   -- #656 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Control CH IE03001C12 ml';   -- #657 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Control CL IE03001C11 ml';   -- #658 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Control(CL&CH) ml';   -- #659 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Reagent RA IE03001M11 ml';   -- #660 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Reagent RD IE03001R11 ml';   -- #661 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Reagent(M11&R11) ml';   -- #662 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD001-B ml';   -- #663 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD001-D ml';   -- #664 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD001M ml';   -- #665 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD003-B1 ml';   -- #666 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD003-D ml';   -- #667 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD006-B ml';   -- #668 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD006-D ml';   -- #669 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD007-B ml';   -- #670 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD007-D ml';   -- #671 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD007-Mg ml';   -- #672 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD008A ml';   -- #673 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD008G ml';   -- #674 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD013-B ml';   -- #675 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD013-E ml';   -- #676 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD013G-B ml';   -- #677 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD013G-E ml';   -- #678 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD016 ml';   -- #679 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD025-L1 ml';   -- #680 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD025-P1 g';   -- #681 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD026-B ml';   -- #682 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD026-D ml';   -- #683 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD028-B ml';   -- #684 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD028-R ml';   -- #685 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD039-B ml';   -- #686 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD039-D ml';   -- #687 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD099-B1 ml';   -- #688 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD099-B2 ml';   -- #689 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD099-D ml';   -- #690 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD126-B1 ml';   -- #691 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD126-B2 ml';   -- #692 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD126-D ml';   -- #693 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD311-B ml';   -- #694 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MD311-R ml';   -- #695 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD001 ml';   -- #696 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD005-1-U ml';   -- #697 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD005-5-U ml';   -- #698 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD006-D ml';   -- #699 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD018-B ml';   -- #700 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD018-D ml';   -- #701 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD019-B ml';   -- #702 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD019-D ml';   -- #703 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD021-002-P ml';   -- #704 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-1 ml';   -- #705 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-2 ml';   -- #706 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-3 ml';   -- #707 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-4 ml';   -- #708 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-5 ml';   -- #709 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-6 ml';   -- #710 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAD028-7 ml';   -- #711 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR013 ml';   -- #712 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR013-B ml';   -- #713 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q1 ml';   -- #714 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q10 ml';   -- #715 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q2 ml';   -- #716 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q3 ml';   -- #717 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q4 ml';   -- #718 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q5 ml';   -- #719 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q6 ml';   -- #720 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q7 ml';   -- #721 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q8 ml';   -- #722 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR030-Q9 ml';   -- #723 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDAR041 ml';   -- #724 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE020-B ml';   -- #725 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE020-E ml';   -- #726 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE020-NC ml';   -- #727 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE020-P ml';   -- #728 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE020-PC ml';   -- #729 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE027 ml';   -- #730 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDE028 ml';   -- #731 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDM001-10 ml';   -- #732 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDRR003 ml';   -- #733 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDRR003-B ml';   -- #734 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSDK0012-V1-1 ml';   -- #735 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSDK0012-V1-2 ml';   -- #736 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSDK0012-V1-3 ml';   -- #737 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSDK0012-V1-4 ml';   -- #738 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSDK0012-V1-5 ml';   -- #739 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSDK0012-V1-6 ml';   -- #740 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-1 mg';   -- #741 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-2 ml';   -- #742 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-3 mg';   -- #743 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-4 ml';   -- #744 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-5 ml';   -- #745 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-6 ml';   -- #746 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-7 ml';   -- #747 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-8 ml';   -- #748 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0001-V2-9 ml';   -- #749 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-1 mg';   -- #750 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-2 ml';   -- #751 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-3 ml';   -- #752 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-4 ml';   -- #753 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-5 ml';   -- #754 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-6 ml';   -- #755 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-7 ml';   -- #756 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDSEK0002-V1-8 ml';   -- #757 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NE007 ml';   -- #758 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NE007-B ml';   -- #759 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro BNP RA IE02001M11 ml';   -- #760 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro BNP RD IE02001R11 ml';   -- #761 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro CalibratorS0 IE02001S10 ml';   -- #762 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro CalibratorS1 IE02001S11 ml';   -- #763 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro CalibratorS2 IE02001S12 ml';   -- #764 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro CalibratorS3 IE02001S13 ml';   -- #765 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro CalibratorS4 IE02001S14 ml';   -- #766 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro CalibratorS5 IE02001S15 ml';   -- #767 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro Control CH IE02001C12 ml';   -- #768 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT Pro Control CL IE02001C11 ml';   -- #769 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT ProCalibratorE-C1IE02001P11 ml';   -- #770 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT ProCalibratorE-C2IE02001P12 ml';   -- #771 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT ProCalibratorE-C3IE02001P13 ml';   -- #772 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator (P11&P13) mL';   -- #773 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator E-C1 IE03201P11 ml';   -- #774 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator E-C2 IE03201P12 ml';   -- #775 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator E-C3 IE03201P13 ml';   -- #776 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator S0 IE03201S10 ml';   -- #777 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator S1 IE03201S11 ml';   -- #778 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator S2 IE03201S12 ml';   -- #779 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator S3 IE03201S13 ml';   -- #780 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator S4 IE03201S14 ml';   -- #781 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Calibrator S5 IE03201S15 ml';   -- #782 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Control (C11&C12) Ml';   -- #783 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Control CH IE03201C12 ml';   -- #784 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Control CL IE03201C11 ml';   -- #785 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Reagent (M11&R11) ml';   -- #786 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Reagent RA IE03201M11 ml';   -- #787 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Reagent RD IE03201R11 ml';   -- #788 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pre-Trigger SolutionIE00001F11 115ml/Vials';   -- #789 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone CH IE00A0606Q2 Vial';   -- #790 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone CL IE00A0606Q1 Vial';   -- #791 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone EC1 IE00A0606C1 Vial';   -- #792 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone EC2 IE00A0606C2 Vial';   -- #793 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone EC3 IE00A0606C3 Vial';   -- #794 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone RA IE00A0606RA Vial';   -- #795 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone RD IE00A0606RB Vial';   -- #796 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ProgesteroneCal S0 IE00A0606S0 Vial';   -- #797 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ProgesteroneCal S1 IE00A0606S1 Vial';   -- #798 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ProgesteroneCal S2 IE00A0606S2 Vial';   -- #799 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ProgesteroneCal S3 IE00A0606S3 Vial';   -- #800 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ProgesteroneCal S4 IE00A0606S4 Vial';   -- #801 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ProgesteroneCal S5 IE00A0606S5 Vial';   -- #802 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Quality Control BENHIVN102 ml';   -- #803 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Quality Control BENHIVN204 ml';   -- #804 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Quality Control BENHIVN307 ml';   -- #805 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Reagent Cartridge700-000141-10 Set';   -- #806 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sample Diluent IT00001Y11 ml';   -- #807 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Mono.Ab BRNSCDN101';   -- #808 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Mono.Ab BRNSCDN102';   -- #809 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Mono.Ab BRNSCDN103';   -- #810 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Mono.Ab BRNSCDN104';   -- #811 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Rec.Ag GRNHBAN101';   -- #812 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Rec.Ag GRNHBCN101';   -- #813 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Rec.Ag GRNHBSN101';   -- #814 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Uncutsheet SCDUS01';   -- #815 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SickleCell Redi.Buffer SCDCD01';   -- #816 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SickleCell Sample Dil. SCDSD01';   -- #817 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator E-C1 IE00A0201C1 ml';   -- #818 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator E-C2 IE00A0201C2 ml';   -- #819 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator E-C3 IE00A0201C3 ml';   -- #820 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator S0 IE00A0201S0 ml';   -- #821 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator S1 IE00A0201S1 ml';   -- #822 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator S2 IE00A0201S2 ml';   -- #823 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator S3 IE00A0201S3 ml';   -- #824 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator S4 IE00A0201S4 ml';   -- #825 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Calibrator S5 IE00A0201S5 ml';   -- #826 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Control CH IE00A0201Q2 ml';   -- #827 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Control CL IE00A0201Q1 ml';   -- #828 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Reagent RA IE00A0201RA ml';   -- #829 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Reagent RC IE00A0201RC ml';   -- #830 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Reagent RD IE00A0201RB ml';   -- #831 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator E-C1 IE00A0202C1 ml';   -- #832 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator E-C2 IE00A0202C2 ml';   -- #833 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator E-C3 IE00A0202C3 ml';   -- #834 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator S0 IE00A0202S0 ml';   -- #835 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator S1 IE00A0202S1 ml';   -- #836 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator S2 IE00A0202S2 ml';   -- #837 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator S3 IE00A0202S3 ml';   -- #838 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator S4 IE00A0202S4 ml';   -- #839 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Calibrator S5 IE00A0202S5 ml';   -- #840 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Reagent RA IE00A0202RA ml';   -- #841 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Reagent RC IE00A0202RC ml';   -- #842 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Reagent RD IE00A0202RB ml';   -- #843 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator (C1 To C3) ML';   -- #844 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator S0 IE02601S10 ml';   -- #845 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator S1 IE02601S11 ml';   -- #846 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator S2 IE02601S12 ml';   -- #847 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator S3 IE02601S13 ml';   -- #848 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator S4 IE02601S14 ml';   -- #849 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Calibrator S5 IE02601S15 ml';   -- #850 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA CalibratorE-C1 IE02601P11 ml';   -- #851 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA CalibratorE-C2 IE02601P12 ml';   -- #852 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA CalibratorE-C3 IE02601P13 ml';   -- #853 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Control (CL&CH) ML';   -- #854 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Control CH IE02601C12 ml';   -- #855 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Control CL IE02601C11 ml';   -- #856 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Reagent (M11&R11) ML';   -- #857 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Reagent RA IE02601M11 ml';   -- #858 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA Reagent RD IE02601R12 ml';   -- #859 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator (C1 To C3) ml';   -- #860 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator E-C1 IE02401P11 ml';   -- #861 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator E-C2 IE02401P12 ml';   -- #862 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator E-C3 IE02401P13 ml';   -- #863 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator S0 IE02401S10 ml';   -- #864 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator S1 IE02401S11 ml';   -- #865 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator S2 IE02401S12 ml';   -- #866 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator S3 IE02401S13 ml';   -- #867 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator S4 IE02401S14 ml';   -- #868 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator S5 IE02401S15 ml';   -- #869 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Control (CL & CH) ml';   -- #870 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Control CH IE02401C12 ml';   -- #871 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Control CL IE02401C11 ml';   -- #872 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Reagent Fapon ml';   -- #873 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Reagent RA IE02401M11 ml';   -- #874 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Reagent RD IE02401R11 ml';   -- #875 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone CH IE00A0607Q2 Vial';   -- #876 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone CL IE00A0607Q1 Vial';   -- #877 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone E-C1 IE00A0607C1 Vial';   -- #878 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone E-C2 IE00A0607C2 Vial';   -- #879 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone E-C3 IE00A0607C3 Vial';   -- #880 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone RA IE00A0607RA Vial';   -- #881 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone RC IE03501R11 Vial';   -- #882 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone RD IE00A0607RB Vial';   -- #883 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Reagent Ra-Rd';   -- #884 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TestosteroneCal S0 IE00A0607S0 Vial';   -- #885 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TestosteroneCal S1 IE00A0607S1 Vial';   -- #886 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TestosteroneCal S2 IE00A0607S2 Vial';   -- #887 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TestosteroneCal S3 IE00A0607S3 Vial';   -- #888 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TestosteroneCal S4 IE00A0607S4 Vial';   -- #889 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TestosteroneCal S5 IE00A0607S5 Vial';   -- #890 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Trigger Solution IE00001F12 115ml/Vials';   -- #891 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S0IE00A0702S0 ml';   -- #892 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S1IE00A0702S1 ml';   -- #893 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S2IE00A0702S2 ml';   -- #894 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S3IE00A0702S3 ml';   -- #895 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S4IE00A0702S4 ml';   -- #896 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S5IE00A0702S5 ml';   -- #897 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S6IE00A0702S6 ml';   -- #898 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S7IE00A0702S7 ml';   -- #899 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S8IE00A0702S8 ml';   -- #900 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Calibrator S9IE00A0702S9 ml';   -- #901 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Control CH IE00A0702Q2 ml';   -- #902 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Control CL IE00A0702Q1 ml';   -- #903 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Reagent PTA IE00A0702RD ml';   -- #904 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Reagent PTB IE00A0702RE ml';   -- #905 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Reagent RA IE00A0702RA ml';   -- #906 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Reagent RC IE00A0702RC ml';   -- #907 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB 12 Reagent RD IE00A0702RB ml';   -- #908 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 Calibrator (C1 To C3) ML';   -- #909 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 CalibratorE-C1IE00A0702C1 ml';   -- #910 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 CalibratorE-C2IE00A0702C2 ml';   -- #911 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 CalibratorE-C3IE00A0702C3 ml';   -- #912 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 CalibratorS10IE00A0702S10 ml';   -- #913 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 Control (CL&CH)';   -- #914 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Calibrator (C1 To C3) ML';   -- #915 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Calibrator E-C1 ml';   -- #916 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Calibrator E-C2 ml';   -- #917 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Calibrator E-C3 ml';   -- #918 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Control (CL&CH)';   -- #919 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Control CH ml';   -- #920 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Control CL ml';   -- #921 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Reagent (RA To RD) ML';   -- #922 [Fapon] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Reagent Ra IE05401M11 ML';   -- #923 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Reagent Rb IE05402R13 ml';   -- #924 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Reagent Rc IE05401R12 ml';   -- #925 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VD Reagent Rd IE05401R11 ml';   -- #926 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Wash Buffer IT00002W11 ml';   -- #927 [Fapon] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25-OH VITAMIN D FIA TEST 25TEST';   -- #928 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP FIA TEST 10 TEST';   -- #929 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH FIA Test 10 Test';   -- #930 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BETA HCG FIA TEST 10TEST';   -- #931 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beeta HCG FIA Test 10 Test';   -- #932 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEA FIA TEST 10TEST';   -- #933 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB FIA TEST 10 TEST';   -- #934 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IgG/IgM FIA TEST 10TEST';   -- #935 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CTNI FIA TEST 10 TEST';   -- #936 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D-DIMER FIA TEST 10TEST';   -- #937 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DENGUE NS1 FIA TEST 10TEST';   -- #938 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Estradiol (E2) FIA TEST TEST';   -- #939 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH FIA TEST 10TEST';   -- #940 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH FIA Test 10 Test';   -- #941 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.PYLORI Ab FIA TEST 10TEST';   -- #942 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.PYLORI Ag FIA TEST 10TEST';   -- #943 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV FIA TEST 25 TEST';   -- #944 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV FIA TEST 25 TEST';   -- #945 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV-1 IgG/IgM FIA TEST 10TEST';   -- #946 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV-2 IgG/IgM FIA TEST 10TEST';   -- #947 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1C FIA TEST 25TEST';   -- #948 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c FIA Test 10 Test';   -- #949 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbSAg FIA TEST 25 TEST';   -- #950 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH FIA TEST 10TEST';   -- #951 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH FIA Test 10 Test';   -- #952 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT-PRO BNP FIA TEST 10TEST';   -- #953 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCT FIA TEST 10TEST';   -- #954 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCT FIA Test 10 Test';   -- #955 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL FIA TEST 25TEST';   -- #956 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prolactin FIA Test 10 Test';   -- #957 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RUBELLA IgG/IgM FIA TEST 10TEST';   -- #958 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 FIA TEST 10TEST';   -- #959 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 FIA TEST 10TEST';   -- #960 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TES FIA TEST 10TEST';   -- #961 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IgE FIA TEST 10TEST';   -- #962 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOXO IgG/IgM FIA TEST 10TEST';   -- #963 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TPSA FIA TEST 10TEST';   -- #964 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH FIA TEST 25TEST';   -- #965 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH FIA test 10 Test';   -- #966 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN B-12 FIA TEST 25 TEST';   -- #967 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Vitamin D FIA Test 10 Test';   -- #968 [FIA Rapid Test] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'hSCRP/CRP FIA TEST 10TEST';   -- #969 [FIA Rapid Test] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASA IGG ELISA KIT 96 TEST';   -- #970 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Benedicts Reagent(33004) Nos';   -- #971 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Reagent Indus Nos';   -- #972 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Reagent Indus* Nos';   -- #973 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 72-4 Elisa 96 test 96 Test';   -- #974 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHOLESTEROL 2X50ML 2X50ML';   -- #975 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHOLESTEROL TOTAL, BIOGENIX 50 ML';   -- #976 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB,Biogenix,100mL 100 ML';   -- #977 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-NAC,Biogenix,100ml 100ML';   -- #978 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'COVID 19 Ag RAPID TEST KIT 40 Test';   -- #979 [Finish Product] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREATNINE BIOGENIX 50 ML';   -- #980 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP RAPID TEST KIT 25 TEST 25 TEST';   -- #981 [Finish Product] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CYSTATIN C 37.5ml 37.5ML';   -- #982 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cal-A Pack (450mlx2) Nos';   -- #983 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cal-B Pack (280ml) Nos';   -- #984 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur Acid Base RGT 1a Nos';   -- #985 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur CLN Soln 12PK NOS';   -- #986 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur T3 400 Test Nos';   -- #987 [Finish Product] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur T4 100 Test Nos';   -- #988 [Finish Product] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur TSH 500 Test Nos';   -- #989 [Finish Product] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur VB12 100 Test Nos';   -- #990 [Finish Product] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur Vitammin D 500Test NOS';   -- #991 [Finish Product] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur XP NOS';   -- #992 [Finish Product] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centaur XP Wash 1 Nos';   -- #993 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chocolate Agar Plate MP103';   -- #994 [Finish Product] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholesterol 50Ml 50Ml';   -- #995 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholesterol Biogenix 500 ml 500ML';   -- #996 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Clia Reagent IE00A0104RA ML';   -- #997 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Colistin (Methane Sulphonate)';   -- #998 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Continine (COT) Rapid Test 40 40 Test';   -- #999 [Finish Product] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Counting Chamber Nos';   -- #1000 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cover Slip 22x22mm, Blue Star 1x20 pcs';   -- #1001 [Finish Product] HSN: 70199010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Creatnine BioCP 2*50 ml 2*50ML';   -- #1002 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cry Vail-2ml Nos';   -- #1003 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cryptococcal Antigen 40Test';   -- #1004 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cyto Brush Spatula Pkt';   -- #1005 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D Dimer Control 2x1ml';   -- #1006 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D-DIMER RAPID TEST KIT 25 TEST 25 TEST';   -- #1007 [Finish Product] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D. DIMER REAGENT 500ML 500ML';   -- #1008 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D.P.X Mountant 250Ml';   -- #1009 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DHT Elisa Kit 96 Test';   -- #1010 [Finish Product] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deamidated Gliadin Igg(DGP) 96 TEST';   -- #1011 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diethyl Ether 500ml Nos';   -- #1012 [Finish Product] HSN: 29091100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Control D-H 2.5ml 2.5ml';   -- #1013 [Finish Product] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Control D-L 2.5ml 2.5ml';   -- #1014 [Finish Product] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Control D-N 2.5ml 2.5ml';   -- #1015 [Finish Product] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'EBV IgM Elisa Kit 96 Test';   -- #1016 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'EPO ELISA 96 TEST';   -- #1017 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESR Stand 06 Hole Nos';   -- #1018 [Finish Product] HSN: 90211000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESR Stand-6 Hole Wintrobe Nos';   -- #1019 [Finish Product] HSN: 90211000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESR Wentrobe Tube Glass Nos';   -- #1020 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESR Westergen Tube Glass Nos';   -- #1021 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ETHANOL, HONEYWELL 500 ML';   -- #1022 [Finish Product] HSN: 901800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Electrolyte 04 Para Nos';   -- #1023 [Finish Product] HSN: 90189019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Electrolyte Analyzer Cleaner 6X15Ml';   -- #1024 [Finish Product] HSN: 90189019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOLIC ACID, BIOGENIX 96 TEST';   -- #1025 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferric Chloride 500gm Nos';   -- #1026 [Finish Product] HSN: 28273990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Filariasis Test Strip, Alere';   -- #1027 [Finish Product] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Filter Paper 12.5CM Pkt';   -- #1028 [Finish Product] HSN: 48219090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Forcep 4" Nos';   -- #1029 [Finish Product] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Forcep 6" Nos';   -- #1030 [Finish Product] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Forcep 8" Nos';   -- #1031 [Finish Product] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free Estriol Elisa 96 Test 96 Test';   -- #1032 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free Testosterone Elisa 96 Tes 96 Test';   -- #1033 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Freight Inward Nos';   -- #1034 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GAMMA GT, BIOGENIX 50 ML';   -- #1035 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glucose Biogenix 01 Ltr 01 Ltr';   -- #1036 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glucose Biogenix 5*100ml 5*100ML';   -- #1037 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C Regent kits 80+20ml';   -- #1038 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1c Turbilatex 2*20 2*20';   -- #1039 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBC IgM,Bioneovan 96 TEST';   -- #1040 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct 100Ml';   -- #1041 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL Direct BioCP 2*20 ML';   -- #1042 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEPARIN 2 ML TUBE JK 100 PCS';   -- #1043 [Finish Product] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IgM Elisa OTHER 96 Test';   -- #1044 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HLA-B27 Elisa 96 Test';   -- #1045 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hepatits Delta 96Test';   -- #1046 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Alpha 1-AT Elabscience 96Test';   -- #1047 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human PCX(Podocalyxin) 96 TEST';   -- #1048 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Plasma NGAL Elisa Kit 96 96 Test';   -- #1049 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Progesterone BT Lab 96Test';   -- #1050 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IAA 100 TEST 100 TEST';   -- #1051 [Finish Product] HSN: 28444300 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IMMERSION OIL 100 ML';   -- #1052 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'INCUBATOR PCS';   -- #1053 [Finish Product] HSN: 84198990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IPA, Ltr';   -- #1054 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Imipenem IPM 10MCG';   -- #1055 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoassay Analyzer Nos';   -- #1056 [Finish Product] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoglobin IgG 5*25ML+10ML';   -- #1057 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Insulin Elisa Diametra 96 96 TEST';   -- #1058 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'JMD Digital Tourniquet & Acce set';   -- #1059 [Finish Product] HSN: 90211000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'JMD STAND WITH BASKET PCS';   -- #1060 [Finish Product] HSN: 90211000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'JMD Tech Cuff Set For Tourniqu PCS';   -- #1061 [Finish Product] HSN: 90211000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'JMD Tech Tourniquet Machine Pcs';   -- #1062 [Finish Product] HSN: 90211000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Cholesterol 100ml';   -- #1063 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Direct 100ml';   -- #1064 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL Direct, Biogenix 12 ML 12ML';   -- #1065 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LEISMAN\'S STAIN 25gm 25gm';   -- #1066 [Finish Product] HSN: 32041959 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LEUKOCYTE URINE TEST 100 TEST';   -- #1067 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LIPASE 12ml 12ML';   -- #1068 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LIQUIPLASTIN 12*5 ML 12*5 ML';   -- #1069 [Finish Product] HSN: 30029090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lab Equipments & Reagents @05% Nos';   -- #1070 [Finish Product] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lab Equipments & Reagents @12% Nos';   -- #1071 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lab Equipments & Reagents @18% Nos';   -- #1072 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lab Scale BL-P5C Nos';   -- #1073 [Finish Product] HSN: 84239010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lactophenol Cotton Blue 500ml Pkt';   -- #1074 [Finish Product] HSN: 48219090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Laser Slide Printer Nos';   -- #1075 [Finish Product] HSN: 84799090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leishman Stain 250ml Nos';   -- #1076 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leismania IgG+IgM Rapid Test 10 Test';   -- #1077 [Finish Product] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAC Conkey Agar 500gm';   -- #1078 [Finish Product] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MALARIA ANTIGEN 4TH GEN 50 TEST';   -- #1079 [Finish Product] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MCT 1.5ml 500pcs';   -- #1080 [Finish Product] HSN: 9033000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MCT Tube 1.5ml @18% 500PCS';   -- #1081 [Finish Product] HSN: 90330000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MCT Tube 2ml Nos';   -- #1082 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Meropenem MRP 10 MCG SD727';   -- #1083 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Methyl Thiocyanate 25g NOS';   -- #1084 [Finish Product] HSN: 29319090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tip Box 1000(100 Hole) Nos';   -- #1085 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tipps 200-1000ul Tarson 500 pcs';   -- #1086 [Finish Product] HSN: 84799090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tips 2-200ul LSR2020 1000Nos';   -- #1087 [Finish Product] HSN: 90330000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tips 2-200ul Tarsons 1000';   -- #1088 [Finish Product] HSN: ASH RECE | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tips Box 1000(100 Hole) Nos';   -- #1089 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tips Box 1000ul(50hole) Nos';   -- #1090 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tips Box 10ul(100Hole) Nos';   -- #1091 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Microplate Elisa Reader pcs';   -- #1092 [Finish Product] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mini Centrifuge RM-02 Nos';   -- #1093 [Finish Product] HSN: 90118000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mitochondrial Antibody AMA 96T 96 Test';   -- #1094 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Muller Hinton Agar 500gm';   -- #1095 [Finish Product] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Multi Calibrator Set Biosino 1ml*3vial';   -- #1096 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Multi Chanel Pipette 05-50ul pcs';   -- #1097 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NICOTININE TEST CARD (cot) 25 TEST';   -- #1098 [Finish Product] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nitrofurantoin Nit 300 MCG';   -- #1099 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Norfloxacin NX 10MCG';   -- #1100 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nuclease Free Water 100ml Nos';   -- #1101 [Finish Product] HSN: 38249025 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Olympus Microscope Nos';   -- #1102 [Finish Product] HSN: 90118000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'One Step RT PCR Kit Covid-19 96 Test';   -- #1103 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'POTASSIUM HYDROXIDE Flakes 500GM';   -- #1104 [Finish Product] HSN: 28151190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PREP-NA-BIO ELISA KIT  96 Test 96 Test';   -- #1105 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Phenylalanine Agar M-281-100G Nos';   -- #1106 [Finish Product] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Potassium Chloride 500 gm';   -- #1107 [Finish Product] HSN: 31042000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Printing Cylinder 360 Nos';   -- #1108 [Finish Product] HSN: 84433290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rapid H&E 250 Smears CY-1577 Kit';   -- #1109 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Remi Cyclo Mixer CM-101 NOS';   -- #1110 [Finish Product] HSN: 90118000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Reticulocyte Count 25ml HE907 Kit';   -- #1111 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ria RSR 100 Test';   -- #1112 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rna Extraction Nos';   -- #1113 [Finish Product] HSN: 38249025 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'S Cholesterol Biogenix 100Ml 100ML';   -- #1114 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SCRUB TYPHUS IGG+IGM, CTK 30 TEST';   -- #1115 [Finish Product] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT 2X50ML BIOCP 2x50ml';   -- #1116 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT BIOGENIX 50ML 50 ML';   -- #1117 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT, BIOGENIX 50ML';   -- #1118 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT (ALT) BIOGENIX 200 ML 200 ML';   -- #1119 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT BIOGENIX 50 ML';   -- #1120 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT, BIOGENIX 2x50 ML';   -- #1121 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Semen Diluting Fluid 100ml Nos';   -- #1122 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Slide Box-100 Nos';   -- #1123 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Slide Box-50 Slide Nos';   -- #1124 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Slide Carrying Tray Nos';   -- #1125 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Slide Drying Tray Nos';   -- #1126 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sodium Citrate, 100pcs';   -- #1127 [Finish Product] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TIPPS 200-1000 UL 500 PCS';   -- #1128 [Finish Product] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TIPS 2-200 ul 1000PCS';   -- #1129 [Finish Product] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL & DIRECT BILIRUBUN 250ML 250ML';   -- #1130 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL & DIRECT BILURBIN,2*25Ml 2*25ml';   -- #1131 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL PROTEIN BIOGENIX 50*2 ML 50X2ML';   -- #1132 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL PROTEIN, BIOGENIX 50 ML';   -- #1133 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Elisa Diametra 96 96TEST';   -- #1134 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total & Direct Bilurbin Bio-CP 2*50ML';   -- #1135 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tournikit Plus Nos';   -- #1136 [Finish Product] HSN: 9011113 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA BUN BIOGENIX 50 ML 50 ml';   -- #1137 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BIOGENIX 200 ML 200 ML';   -- #1138 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BIOGENIX 2X50 ML 2X50 ML';   -- #1139 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UREA UV BioCP 2X50 ML 2X50 ML';   -- #1140 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URIC ACID 50ML 50ML';   -- #1141 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ultra TSH 96 test';   -- #1142 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urea Bun, Biogenix 100ML 100 ml';   -- #1143 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uric Acid BioCP 2X25ml 2X25ml';   -- #1144 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uric Acid Biogenix 2X50ml 2X50ml';   -- #1145 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Varaible Volume 0.5-10ul Nos';   -- #1146 [Finish Product] HSN: 90311800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Varicella Zoster Virus IgG 96Test';   -- #1147 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Varicella Zoster Virus IgM 96Test';   -- #1148 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Viral RNA Extraction kit 100';   -- #1149 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WBC Diluting Fluid 500ml Nos';   -- #1150 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL BIOGENIX 2X5 ML 2X5Ml';   -- #1151 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL TYPHI "H" 5ML';   -- #1152 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL TYPHI "O" 5 ML';   -- #1153 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'West Nile Virus IgM 96 Test';   -- #1154 [Finish Product] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Widal Reaent 8x5 ml 8x5ml';   -- #1155 [Finish Product] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centaur AIT Cuvettes 3000Pack Nos';   -- #1156 [Finish Product] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centaur Kit Sample Tips-6480 Nos';   -- #1157 [Finish Product] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ETHANOL 500ML';   -- #1158 [Finish Product] HSN: 38249090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Funnel Long Stem 75MM 3" NOS';   -- #1159 [Finish Product] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Haemocytometer Nos';   -- #1160 [Finish Product] HSN: 70179090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Measuring Beakeer C Nos';   -- #1161 [Finish Product] HSN: 70179090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Measuring cylinder 250ml 250Ml';   -- #1162 [Finish Product] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Measuring cylinder 500 ml 500ml';   -- #1163 [Finish Product] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Print Cylinder Nos';   -- #1164 [Finish Product] HSN: 84439100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RIA VIAL 500';   -- #1165 [Finish Product] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Viral Transport Medium (VTM) 50 pcs';   -- #1166 [Finish Product] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Wide Mouth Wash Bottle Nos';   -- #1167 [Finish Product] HSN: 70179090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Analyzer Substrate Buffer 2*500ml';   -- #1168 [Hematology] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Analyzer Wash Buffer 2x250ml';   -- #1169 [Hematology] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Auto Chemiluminescence Analyze pcs';   -- #1170 [Hematology] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BAR CODE CLEANER H30';   -- #1171 [Hematology] HSN: 84136090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DIFF LYSE 350 ML';   -- #1172 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DILUENT 10 LTR 10 LTR';   -- #1173 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DILUENT VATERINARY 20LTR';   -- #1174 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent 5Part 20Ltr';   -- #1175 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Barcode EDAN H30 Nos';   -- #1176 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Biogenix 20 Ltr';   -- #1177 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Card EDAN 3 Part Nos';   -- #1178 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Card EDAN 5 Part Nos';   -- #1179 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Card EDAN VD310 Vet Nos';   -- #1180 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Card for Haematology pcs';   -- #1181 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'EZ Cleaner 100 ml';   -- #1182 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'EZ-CLEANER 50 ML';   -- #1183 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hematology Control High 1X3ml';   -- #1184 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hematology Control Low 1X3ml';   -- #1185 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH LYSE FOR VH50 70ML';   -- #1186 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Barcode EDAN H30 Nos';   -- #1187 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Biogenix 500 ml';   -- #1188 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Card EDAN H30 Nos';   -- #1189 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Card For Hematology PCS';   -- #1190 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Card For VH50 LH 70ml Nos';   -- #1191 [Hematology] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse For Hematology EDAN 500ml';   -- #1192 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse For VH50 200ml Nos';   -- #1193 [Hematology] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse For VH50 500ml Nos';   -- #1194 [Hematology] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse For VL310 200ml';   -- #1195 [Hematology] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse For VL600 200ml';   -- #1196 [Hematology] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse With Barcode EDAN HL500 500ml';   -- #1197 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse With RFID Card EDAN HL600 500ml';   -- #1198 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Zijian 500ml';   -- #1199 [Hematology] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Probe Cleaner Biogenix 100 ML';   -- #1200 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RINSE REAGENT 20 Ltr';   -- #1201 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rapid AFB Stain Kit (Biolab) 2X100ml';   -- #1202 [Hematology] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rinse Barcode EDAN Nos';   -- #1203 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rinse Cleaner With Barcode 1ltr';   -- #1204 [Hematology] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sc-Cal Plus 1*3ML';   -- #1205 [Hematology] HSN: 38220011 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WS Wash Buffer 2*60ml';   -- #1206 [Hematology] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RFID CARD FOR VH 50 DIFF LYSE 500ML';   -- #1207 [Hematology] HSN: 85235290 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RFID CARD FOR VH 50 LH LYSE 200ML';   -- #1208 [Hematology] HSN: 85235290 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RFID Card For VH50 Diluent 20Ltr';   -- #1209 [Hematology] HSN: 85235290 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEMOGLOBIN TEST STRIPS BS-101';   -- #1210 [HEMOGLOBIN] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hemoglobin TestingSystem BC101';   -- #1211 [HEMOGLOBIN] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AM055-5M-Anti-NSE 6ml';   -- #1212 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AM074-5M-Anti-Vimentin 6ml';   -- #1213 [IHC Antibody] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMA12-5M-Anti-Inhibin Alpha 6ML';   -- #1214 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMA22-5M-Anti-IDH1 6ML';   -- #1215 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMA50-5M-Anti-Synaptophysin 6ml';   -- #1216 [IHC Antibody] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMB05-5M-Anti-ATRX 6ML';   -- #1217 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMB58-5M Anti-TLE1 6ML';   -- #1218 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AN789-5M-Anti-Myogenin 6ml';   -- #1219 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HK083-50K-Power Block For ISH Nos';   -- #1220 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HK111-50K-Peroxide Block Nos';   -- #1221 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HK522-XAK-EZ-AR2O Nos';   -- #1222 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HK583-5KE-Super Sensitive Wash Nos';   -- #1223 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'QD430-XAKENI-Non-Biotin 100ML';   -- #1224 [IHC Antibody] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '3 Part Hematology Analyzer HEA-3100';   -- #1225 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Abacus-5 Hematology Analyzer No.';   -- #1226 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Air Compressor For Pathfinder Nos';   -- #1227 [Instrument] HSN: 84799090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Auto Blood Culture System BT24';   -- #1228 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Auto Chemistry Analyzer BI280 Nos';   -- #1229 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Auto Hematology Analyzer BI-61 Nos';   -- #1230 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Auto Hematology Analyzer Pcs';   -- #1231 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AutoBloodCultureAnalyzer BT180';   -- #1232 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AutoBloodCultureAnalyzerBUGZ40';   -- #1233 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Automatic Alcohol Prep Machine Nos';   -- #1234 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BI32 Auto Blood Culture System Nos';   -- #1235 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BIOCHEMISTRY ANALYZER BI-9005 PCS';   -- #1236 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BIOCHEMISTRY ANALYZER DS261 NOS';   -- #1237 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bacterial Turbidity Meter Nos';   -- #1238 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Analyzer BC300 pcs';   -- #1239 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Analyzer BI70 Nos';   -- #1240 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochip Scanner DropScan-V Nos';   -- #1241 [Instrument] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blades for Coating Machines';   -- #1242 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Cell Counter Nos';   -- #1243 [Instrument] HSN: 90291090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Gas & Chemistry Analyzer Nos';   -- #1244 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Roller Nos';   -- #1245 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CLIA ANALYZER NOS';   -- #1246 [Instrument] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CORE BOARD FOR HEMATOLOGY PCS';   -- #1247 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CYTOBRUSH IND PACK';   -- #1248 [Instrument] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calibrator CP100 Edan';   -- #1249 [Instrument] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Clinical Centrifuge Tube Nos';   -- #1250 [Instrument] HSN: 84798200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Digital Hemoglobin Meter Nos';   -- #1251 [Instrument] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Digital PCR Instrument Dx-2050 Nos';   -- #1252 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Display Screen Nos';   -- #1253 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ELISA READER WITH SPL.FILTER NOS';   -- #1254 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESR-DT 10 Channel 500 Test';   -- #1255 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Electrolyte Analyzer 3 Para Nos.';   -- #1256 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Electrolyte Analyzer 5 Para Nos.';   -- #1257 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Elisa Plate Reader';   -- #1258 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Elisa Reader And Washer(Q3) Nos';   -- #1259 [Instrument] HSN: 90189019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Elisa Washer';   -- #1260 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fluorescent Immunoassay Analys Nos';   -- #1261 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fully Auto Biochemistry Analy Nos';   -- #1262 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fully Auto Micro Pipette 10-10 Nos';   -- #1263 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gulletine Cutter Nos';   -- #1264 [Instrument] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H30 Pro Hematology Analyzer Nos';   -- #1265 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H30 Vet Hematology Analyzer Nos';   -- #1266 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H60 Auto Hematology Analyzer Pcs';   -- #1267 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H60 Vet Hematology Analyzer Nos';   -- #1268 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H60S Auto Hematology Analyzer Nos';   -- #1269 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEMOGLOBIN ANALYZER MQ-3000PT NOS';   -- #1270 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEMOGLOBIN METER (CGM)';   -- #1271 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hemoglobin Cuvette Nos';   -- #1272 [Instrument] HSN: 390690 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hepa Filter Nos';   -- #1273 [Instrument] HSN: 4805 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ICX Multi Florescence Analyzer pcs';   -- #1274 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ION Selective Analyser With Ca Nos';   -- #1275 [Instrument] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immunoassay/POCT Analyzer Pcs';   -- #1276 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LAMP FOR BIOCHEMISTRY MACHINE PCS';   -- #1277 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LANCING DEVICE';   -- #1278 [Instrument] HSN: 90189019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LED Floresent Light Nos';   -- #1279 [Instrument] HSN: 8524 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lamps Seamaty Nos';   -- #1280 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICRO PLATE ELISA READER PCS';   -- #1281 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Magnetic Hotplate 280C Nos';   -- #1282 [Instrument] HSN: 84798200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Magnetic Hotplate 340C Nos';   -- #1283 [Instrument] HSN: 84798200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Magnetic Hotplate 550C Nos';   -- #1284 [Instrument] HSN: 84798200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Measuring Instrument V6 Pump';   -- #1285 [Instrument] HSN: 84136090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Plate Washer BD-W201 Pcs';   -- #1286 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Microorganism ID & AST System Nos';   -- #1287 [Instrument] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ordinary Injection Pump Dispen pcs';   -- #1288 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'P500 BIOCHEMISTRY ANALYZER';   -- #1289 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCR Amplifying ApparatusSG2000 Nos';   -- #1290 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROBE MODULE ALIGNMENTFOR HEMT PCS';   -- #1291 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pathfinder 350D With Decapper PS-U-A710';   -- #1292 [Instrument] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pre Filter Nos';   -- #1293 [Instrument] HSN: 84212300 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Printer ESR-DT';   -- #1294 [Instrument] HSN: 85365010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pump Nos';   -- #1295 [Instrument] HSN: 901800 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RBC Chamber Nos';   -- #1296 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SAMPLE PROBE WIPER FOR HAMATOL PCS';   -- #1297 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sanity 2.0 System Nos';   -- #1298 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Semi Auto Analyzer BI251 Nos';   -- #1299 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Semi Auto Cogulation Nos';   -- #1300 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Semi Biochemistry Analyzer BI9005';   -- #1301 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Semi-Auto Chemistry Analyzer BAS-10S';   -- #1302 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SemiChemistry Analyzer BI-251+ Pcs';   -- #1303 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Spirometer Nos';   -- #1304 [Instrument] HSN: 90181990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Spirometer SP10 Nos';   -- #1305 [Instrument] HSN: 90192090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Spirometer SP80B Nos';   -- #1306 [Instrument] HSN: 90192090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Test Cartridge Edan BG08@12% Set';   -- #1307 [Instrument] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Test Cartridge Edan BG10 Set';   -- #1308 [Instrument] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Test Cartridge Edan BG10@18% Set';   -- #1309 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Test Cartridge Edan BG8@18% Set';   -- #1310 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Test Cartridge Edan Nos';   -- #1311 [Instrument] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Three Way Valve Large Nos';   -- #1312 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Three Way Valve Small Nos';   -- #1313 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Touch Screen Nos';   -- #1314 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Two Way Valve Nos';   -- #1315 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'U.V.Light NOS';   -- #1316 [Instrument] HSN: 8524 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINE ANALYZER W-200B';   -- #1317 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UV Transilluminator Nos';   -- #1318 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Upper Kinfe holder(Coating Mac pcs';   -- #1319 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Analyzer BI-2000UA';   -- #1320 [Instrument] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Analyzer BI-400 Nos';   -- #1321 [Instrument] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Analyzer SB-600';   -- #1322 [Instrument] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WBC Chamber Edan Nos';   -- #1323 [Instrument] HSN: 90273090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WBC Chamber With hgb Nos';   -- #1324 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Waste Cable With Sensor Nos';   -- #1325 [Instrument] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '0.1-2 uL Pepette Grey';   -- #1326 [Instrument] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '0.5-10 uL Pepette Pink';   -- #1327 [Instrument] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '100-1000 uL Pepette Blue';   -- #1328 [Instrument] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '2-20 uL Pepette Cream';   -- #1329 [Instrument] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '20-200 uL Pepette Yellow';   -- #1330 [Instrument] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Burette Class A';   -- #1331 [Instrument] HSN: 70179090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'CAPILLARY ADAPTOR';   -- #1332 [Instrument] HSN: 90279090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'CAPILLARY TUBES';   -- #1333 [Instrument] HSN: 90279090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'H60 RBC BATH COMPONENTS';   -- #1334 [Instrument] HSN: 90279090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Laminar Air Flow Nos';   -- #1335 [Instrument] HSN: 84145190 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'VALVE FOR HEMATOLOGY ANALYZER PCS';   -- #1336 [Instrument] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFB Rapid(Biolab) 2*100';   -- #1337 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Amikacin 30MG SD035 Nos';   -- #1338 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Androstendione Elisa 96Test';   -- #1339 [Labkem] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti ABD Arkray 10ml';   -- #1340 [Labkem] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti ABD IgG+IgM 3*10ml';   -- #1341 [Labkem] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BANDAID';   -- #1342 [Labkem] HSN: 300510 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Benedict Solution Jupitor 500ml';   -- #1343 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CLOT ACTIVATOR 1ML';   -- #1344 [Labkem] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cover Slip 22x40mm, Blue Star 20*40MM';   -- #1345 [Labkem] HSN: 28332990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DD018-1VL Oxidase Discs 50Disc NOS';   -- #1346 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Doripenem DOR SD283-5*50DS Nos';   -- #1347 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Electrode ION Selective Analys 10ml';   -- #1348 [Labkem] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FLORIDE';   -- #1349 [Labkem] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOCHET REAGENT 150ML';   -- #1350 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glass Slide 50 Pcs';   -- #1351 [Labkem] HSN: 70179010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H&E Rapid Biolab 250SM';   -- #1352 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Heparin NVAC Nos';   -- #1353 [Labkem] HSN: 90181990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LUGOL\'S IODINE 100ML';   -- #1354 [Labkem] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Loop Wire WitH Handle Nos';   -- #1355 [Labkem] HSN: 90272000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NIDDLE DESTROYER';   -- #1356 [Labkem] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PPD Arkray Nos';   -- #1357 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PPD Span Nos';   -- #1358 [Labkem] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rapid PAP Biolab Nos';   -- #1359 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD002-1PK Ampicillin 10MCG Nos';   -- #1360 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD016-1PK Gentamicin 10MCG NOS';   -- #1361 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD023-1PK Nitrofurantion 300MC NOS';   -- #1362 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD028-1PK Penicillin G Unit NOS';   -- #1363 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD045-1PK Vancomycin 30MCG Nos';   -- #1364 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD060-1PK Ciprofloxacin 5 MCG NOS';   -- #1365 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD062-1PK Ceftazidime 30MCG NOS';   -- #1366 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD066-1PK Piperacillin 100MCG NOS';   -- #1367 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD158-1PK Minocycline MI30 MCG NOS';   -- #1368 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD205-1PK Fosfomycin SD205 NOS';   -- #1369 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD210-1PK Piperacillin/Tazobac 100SD';   -- #1370 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD212-1PK Aztreonam 30MCG NOS';   -- #1371 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD215-1PK Linezolid LZ30MCG NOS';   -- #1372 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD216-1PK Levofloxacin 5 MCG NOS';   -- #1373 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SD727-5X50DS Meropenem 10MCG NOS';   -- #1374 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SULPHOSALICYLIC ACID 3% 125ML';   -- #1375 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sulphosalicylic Acid 500ml';   -- #1376 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator (S0 To S5) ml';   -- #1377 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Calibrator E C1-C3 ml';   -- #1378 [Labkem] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tetracycline 30MCG SD037 Nos';   -- #1379 [Labkem] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Laboclean Jupitor 5Ltr';   -- #1380 [Labkem] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25(OH)VD Uncut Sheet Labsim';   -- #1381 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Uncut Sheet Labsim';   -- #1382 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Uncut Sheet Labsim';   -- #1383 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CCP Uncut Sheet Labsim';   -- #1384 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG Uncut Sheet Labsim';   -- #1385 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB Uncut Sheet Labsim';   -- #1386 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chip Rapid';   -- #1387 [Labsim] HSN: 39269099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgM/IgG Uncut Sheet Labsim';   -- #1388 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Uncut Sheet Labsim';   -- #1389 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c Uncut Sheet Labsim';   -- #1390 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IgE Uncut Sheet Labsim';   -- #1391 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Uncut Sheet Labsim';   -- #1392 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL Uncut Sheet Labsim';   -- #1393 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone Uncut Sheet Labsim';   -- #1394 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Uncut Sheet Labsim';   -- #1395 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 Uncut Sheet Labsim';   -- #1396 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 Uncut Sheet Labsim';   -- #1397 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Uncut Sheet Labsim';   -- #1398 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Uncut Sheet Labsim';   -- #1399 [Labsim] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25-OH VITAMIN D CLIA BIOGENIX 2*100 TEST';   -- #1400 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP CLIA BIOGENIX 2*50 TEST';   -- #1401 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AHA CLIA BIOGENIX 2*50 TEST';   -- #1402 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMA-M2 CLIA BIOGENIX 2*50 TEST';   -- #1403 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH CLIA BIOGENIX 2*100 TEST';   -- #1404 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH CONTROL L1 BIOGENIX 1 ML';   -- #1405 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH CONTROL L2 BIOGENIX 1 ML';   -- #1406 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP CONTROL L1 BIOGENIX 0.5 ML';   -- #1407 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP CONTROL L2 BIOGENIX 0.5 ML';   -- #1408 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI-CCP CLIA BIOGENIX 2*100 TEST';   -- #1409 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-CENP B Ab CLIA BIOGENIX 2*50 TEST';   -- #1410 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-HCV CLIA BIOGENIX 2*100 TEST';   -- #1411 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-LKM-1 Ab CLIA BIOGENIX 2*50 TEST';   -- #1412 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-Nuc AB CLIA BIOGENIX 2*50 TEST';   -- #1413 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-SSA Ro60 Ab CLIA BIOGENIX 2*50 TEST';   -- #1414 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-Scl-70 Ab CLIA BIOGENIX 2*50 TEST';   -- #1415 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-Sm Ab CLIA BIOGENIX 2*50 TEST';   -- #1416 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BETA HCG CLIA BIOGENIX 2*100 TEST';   -- #1417 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA125 CLIA BIOGENIX 2*50 TEST';   -- #1418 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEA CLIA BIOGENIX 2*50 TEST';   -- #1419 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DHEA-S CLIA BIOGENIX 2*50 TEST';   -- #1420 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'E2 CLIA BIOGENIX 2*100 TEST';   -- #1421 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FERRITIN CLIA BIOGENIX 2*50 TEST';   -- #1422 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOLATE CLIA BIOGENIX 50 TEST';   -- #1423 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH CLIA BIOGENIX 2*100 TEST';   -- #1424 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT3 CLIA BIOGENIX 2*100 TEST';   -- #1425 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT4 CLIA BIOGENIX 2*100 TEST';   -- #1426 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg CLIA BIOGENIX 2*100 TEST';   -- #1427 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV Ag/Ab CLIA BIOGENIX 2*100 TEST';   -- #1428 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'INSULIN CLIA BIOGENIX 2*50 TEST';   -- #1429 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH CLIA BIOGENIX 2*100 TEST';   -- #1430 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL CLIA BIOGENIX 2*100 TEST';   -- #1431 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T.PSA CLIA BIOGENIX 2*100 TEST';   -- #1432 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TESTOSTERONE CLIA BIOGENIX 2*100 TEST';   -- #1433 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TG CLIA BIOGENIX 2*100 TEST';   -- #1434 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IgE CLIA BIOGENIX 2*50 TEST';   -- #1435 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL T3 CLIA BIOGENIX 2*100 TEST';   -- #1436 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL T4 CLIA BIOGENIX 2*100 TEST';   -- #1437 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH CLIA BIOGENIX 2*100 TEST';   -- #1438 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tg Control L-1 CLIA BIOGENIX 1.0mL*1';   -- #1439 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tg Control L-2 CLIA BIOGENIX 1.0mL*1';   -- #1440 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 CLIA BIOGENIX 50 TEST';   -- #1441 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'iPTH CLIA BIOGENIX 2*100 TEST';   -- #1442 [MACCURA] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '0.1ml qPCR 8 Strip LSR2051 120/Pkt';   -- #1443 [Molecular & Micro] HSN: 903190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '0.2ml PCR Tube Flat LSR2048 500X2';   -- #1444 [Molecular & Micro] HSN: 90319000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '0.2ml qPCR 8 Strip LSR2050 120/Pkt';   -- #1445 [Molecular & Micro] HSN: 90319000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '1000ul Tips Sterile 10X6';   -- #1446 [Molecular & Micro] HSN: 903190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '1000ul Tips Sterile Universal 10X6';   -- #1447 [Molecular & Micro] HSN: 903190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '10ul Filter TipsLR LSR2027-1 10X96';   -- #1448 [Molecular & Micro] HSN: 903190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '10ul Filter TipsSterileLSR2027 10X96';   -- #1449 [Molecular & Micro] HSN: 903190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '10ul Filter TipsXL LSR2027-2 10X96';   -- #1450 [Molecular & Micro] HSN: 90319000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '20ul Filter TipsSterileLSR2028 10X96';   -- #1451 [Molecular & Micro] HSN: 90319000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2XPCR MasterMix LSR0114 1mlX2';   -- #1452 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2XPCR MasterMix LSR0114 200Rxn';   -- #1453 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2XPCR MasterMix LSR0114-1 1mlX6';   -- #1454 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2XPCR MasterMix LSR0114-2 1mlX15';   -- #1455 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '2xPCRMixTaqMixLSR0114 200RXN 5X1ml';   -- #1456 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5ML Tips Pcs';   -- #1457 [Molecular & Micro] HSN: 90330000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '6x Blue Loading Dye 5X1ml';   -- #1458 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '6xDNA Loading Dye LSR0144 5X1ml';   -- #1459 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'A1 Rheumatology Igg Profile ki test';   -- #1460 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMOXYCILLIN 10 MCG';   -- #1461 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AZITHROMYCIN 15 MCG';   -- #1462 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Acrylamide/Bisacrylamide Sol Nos';   -- #1463 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aerobic Culture Bott Adult@18% Nos';   -- #1464 [Molecular & Micro] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Agarose Low EEO LSR0142 100gm';   -- #1465 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Agarose Low EEO LSR0142-1 500gm';   -- #1466 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Agarose Low EEO LSR0142-2 500gmX2';   -- #1467 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ammonium Persulphate LSR0151 100gm';   -- #1468 [Molecular & Micro] HSN: 28334000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Amphoterricin B 20ml';   -- #1469 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anaerobic Blood Culture FFN-02 8-10mlColorime';   -- #1470 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anearobic Culture Pediatric Nos';   -- #1471 [Molecular & Micro] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti MSI2 Antibody LSR80941 100ug';   -- #1472 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'B1 Allergen IgE Profile Kit test';   -- #1473 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BSA LSR0140 100gm';   -- #1474 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Culture Adult Nos';   -- #1475 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Culture Bottle Manual 25ml';   -- #1476 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Culture Pediatric Nos';   -- #1477 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Genomic DNA Extraction 50rxns';   -- #1478 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bradford Reagent LSR0157-1 500ml';   -- #1479 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEFEPIME 30 MCG';   -- #1480 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEFIXIME 5 MCG';   -- #1481 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEFUROXIME 30 MCG';   -- #1482 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFA-01 Aerobic Blood Culture 30ML';   -- #1483 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFA-01 Aerobic Blood Culture 8-10ml';   -- #1484 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFL-04 Bacterial Blood Culture 8-10ml Type IV';   -- #1485 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFMY-05 Biomeriux L-Form 30ML';   -- #1486 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFN-02 Anaerobic Culture Bott 40ml';   -- #1487 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFP-03 Aerobic Culture Bottle 20 ML';   -- #1488 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CFP-03 Aerobic Culture Bottle 20ML';   -- #1489 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHLORAMPHENICOL 30 MCG';   -- #1490 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calcein AM/PI Double Staining Kit';   -- #1491 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centrifuge Tube 50ml LSR2017 500Pcs';   -- #1492 [Molecular & Micro] HSN: 39172200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Centrifuge Tube Self Standing 50ml';   -- #1493 [Molecular & Micro] HSN: 90330000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CentrifugeTube Sterile LSR2017 50ml';   -- #1494 [Molecular & Micro] HSN: 39172200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cervical Brush Pcs';   -- #1495 [Molecular & Micro] HSN: 90181990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chaps Buffer LSR0156 5gm';   -- #1496 [Molecular & Micro] HSN: 29420090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DI05 DNase Enzyme 1ml MB Grade ml';   -- #1497 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DMEM(Low Glucose)500ml 500ml';   -- #1498 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Gel Stain SYBRSafe LSR7011 500ul';   -- #1499 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Ladder 100bp LSR0128 500ul';   -- #1500 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Ladder 100bp LSR0128 5X50ug';   -- #1501 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Ladder 1kb LSR0129 500ul';   -- #1502 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Ladder 1kb LSR0129 5X50ug';   -- #1503 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Ladder 50bp LSR0127 500ul';   -- #1504 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA Ladder 50bp LSR0127 5X50ug';   -- #1505 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNA stool stabilizer Nos';   -- #1506 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNase I LSR119 10000U';   -- #1507 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DNase I LSR119 10000U 10000U';   -- #1508 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOXYCYCLINE HYDROCHLORIDE30MCG';   -- #1509 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DSRed Nucleic Acid Stain 500ul';   -- #1510 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dapi Reagent 1ug/ml(10ml) 10ml';   -- #1511 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diethyl Pyrocarbonate 25ml';   -- #1512 [Molecular & Micro] HSN: 29209000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Digital PCR Cartridge Nos';   -- #1513 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Digital PCR Cartridge Sealing Nos';   -- #1514 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Digital PCR Mastermix Probe Nos';   -- #1515 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ERTAPENEM ETP 10 MCG';   -- #1516 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ERYTHROMYCIN 15 MCG';   -- #1517 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Enterobacteriaccac ID&AST Test Plate';   -- #1518 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ethidium Bromide LSR0143 10 ml';   -- #1519 [Molecular & Micro] HSN: 28151190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ethidium Bromide LSR0143 5gm';   -- #1520 [Molecular & Micro] HSN: 29420090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ethidium Bromide, LSR0143 10ml';   -- #1521 [Molecular & Micro] HSN: 28220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ethudium Bromide 10ml';   -- #1522 [Molecular & Micro] HSN: 28220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FFA-01 Aerobic Culture Bottle 30ML';   -- #1523 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FFA-01 Aerobic Culture Bottle 8-10ml';   -- #1524 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FFMY-05 BD L-Form 30ML';   -- #1525 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FFN-02 Anearobic Culture Bottl 40 ml';   -- #1526 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FFP-03 Paediatric Culture Bott 20 ml';   -- #1527 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Free DNA Preservation Tube Nos';   -- #1528 [Molecular & Micro] HSN: 70023100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fungus ID&AST Test Plate';   -- #1529 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G6PD Fenghua Nos';   -- #1530 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gel Extration Kit Kit';   -- #1531 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Generation Oil For Probe Nos';   -- #1532 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gloves L 10X100/Box LSR2064 1000Pcs';   -- #1533 [Molecular & Micro] HSN: 40151900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gloves M 10X100/Box LSR2063 1000Pcs';   -- #1534 [Molecular & Micro] HSN: 40151900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glycine AR 500gm 500gm';   -- #1535 [Molecular & Micro] HSN: 29224910 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBV PCR Kit HBV002 Kit';   -- #1536 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV PCR Kit HCV001 Kit';   -- #1537 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV RT-PCR Kit 10Test';   -- #1538 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV PCR Kit HIV003 Kit';   -- #1539 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV RT-PCR Kit 10Test';   -- #1540 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HLA B27 RT-PCR Kit 10Test';   -- #1541 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HLA-B27(Influenza A&B PCR Kit) Kit';   -- #1542 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HPV PCR HPV002';   -- #1543 [Molecular & Micro] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HPV PCR Kit HPV001 10 TEST';   -- #1544 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HPV PCR Kit HPV001 48 TEST';   -- #1545 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HS Taq DNA Polymerase 500U';   -- #1546 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Heat Transfer Film Nos';   -- #1547 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hoechst 33342/PI Staining Kit 1 Kit';   -- #1548 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human BCR-ABL(P210)Fusion Gene Nos';   -- #1549 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human KRAS Gene G12A Mutation Nos';   -- #1550 [Molecular & Micro] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LBC/HPV SAMPLE COLLECTION KIT 3ML';   -- #1551 [Molecular & Micro] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Liquid Based Cytology Kit Kit';   -- #1552 [Molecular & Micro] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'M-MLV Reconbinant 5000U';   -- #1553 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MCT 2ml Clear LSR2013 500Pcs';   -- #1554 [Molecular & Micro] HSN: 90330000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MMT Cell Proliferation Kit';   -- #1555 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MOPS Buffer Extrapure 100gm';   -- #1556 [Molecular & Micro] HSN: 29333919 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MOPS Extrapure LSR0146 250gm';   -- #1557 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'N,N-MMethylene Bisacylam 25gm';   -- #1558 [Molecular & Micro] HSN: 29041090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Necleic Acid Extration Kit Kit';   -- #1559 [Molecular & Micro] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Neonatal 17A OH Progesterone Nos';   -- #1560 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Neonatal TSH Fenghua Nos';   -- #1561 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Non-Fermenters ID&AST Test Plate';   -- #1562 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nuclease FreeWater+2xTaq Mix 1ml*5';   -- #1563 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nuclease-Free Water LSR0132 500ml';   -- #1564 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nuclease-Free WaterLSR0132-100 100ml';   -- #1565 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Nuclease-free Water 125ML';   -- #1566 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'P3 Sensor Glucose Monitoring Nos';   -- #1567 [Molecular & Micro] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'P3 Transmitter Glucose Monitor Nos';   -- #1568 [Molecular & Micro] HSN: 90278990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PBS-1X';   -- #1569 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCR 0.2ML Nos';   -- #1570 [Molecular & Micro] HSN: 39264099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCR And DNA Fragment Purificat Kit';   -- #1571 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCR Tube 0.1ml/8 strip';   -- #1572 [Molecular & Micro] HSN: 39264099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PK01 Proteinase K Powder Gm';   -- #1573 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Parafilm 4"X125\'Feet Feet';   -- #1574 [Molecular & Micro] HSN: 34049010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pediatric Blood Culture CFP-03 1-3mlColorimet';   -- #1575 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Phenylalanine Kit Nos';   -- #1576 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Phenylmethane 1gm';   -- #1577 [Molecular & Micro] HSN: 29041090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pipette 10-100UL Nos';   -- #1578 [Molecular & Micro] HSN: 84799090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pipette 100-100UL Nos';   -- #1579 [Molecular & Micro] HSN: 84791000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Plant RNA Kit LSR0109 50Rxn';   -- #1580 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Plasmid Miniprep Kit LSR0101 100Rxn';   -- #1581 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prest Protein Ladder 500ul';   -- #1582 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prest Protein Ladder LSR0131 500ul';   -- #1583 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protainase K LSR0120 5ml';   -- #1584 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protainase K LSR0120-25mg 25mg';   -- #1585 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protein Loading Buffer Nos';   -- #1586 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Quick Blood Genomic DNA Extrac Kit';   -- #1587 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RESPIR PATHOGEN PCR CFDP003';   -- #1588 [Molecular & Micro] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RNA Mini Kit LSR0107 50Rxn';   -- #1589 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RNSse/DNSse Terminator 100ml';   -- #1590 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RNase A((100mg/ml) 1ml';   -- #1591 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RNase A((50mg/ml) LSR0126 50mg';   -- #1592 [Molecular & Micro] HSN: 28151190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RNase Terminator LSR0137 Nos';   -- #1593 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RT-qPCR 25Rxns Nos';   -- #1594 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RTPCR-Respi-01-25Rxns Nos';   -- #1595 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rnase Zap (100 ml) 100 ml';   -- #1596 [Molecular & Micro] HSN: 28151190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SDS LSR0152-100SodiumLsulphate 100gm';   -- #1597 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SDS LSR0152-500SodiumLsulphate 500gm';   -- #1598 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ST09 Bromophenol Blue 0.5% W/V Pcs';   -- #1599 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SYBR Green QPCR Mix LSR0113 5ml';   -- #1600 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Staphylococcus ID&AST Test Plate';   -- #1601 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Streptococcus/Enterococcus ID Test Plate';   -- #1602 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Swab/Saliva Viral DNA/RNA Ext Kit';   -- #1603 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 DNA Ligase LSR0122 10000U';   -- #1604 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TAE Buffer 50X LSR0135 500ml';   -- #1605 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TB PCR Kit TB001 Kit';   -- #1606 [Molecular & Micro] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TBE Buffer 50X LSR0136 500ml';   -- #1607 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOBRAMYCIN TB 10 MCG';   -- #1608 [Molecular & Micro] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TRIS EDTA Buffer LSR0138 500ML';   -- #1609 [Molecular & Micro] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Taq DNA Polymerase LSR0116-1 1000uX2';   -- #1610 [Molecular & Micro] HSN: 39131090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tris Base LSR0133-500 500gm';   -- #1611 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tris HCL 500g';   -- #1612 [Molecular & Micro] HSN: 29211190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'cDNA Synthesis Kit LSR0112 20Rxn';   -- #1613 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'dNTP Mixture 40mm LSR0118-1 1ml';   -- #1614 [Molecular & Micro] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Acrylamide 3x LSR0148 500gm';   -- #1615 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bis Acrylamide 3x LSR0149-1 250gm';   -- #1616 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bis Acrylamide 3x LSR0149-25gm 25gm';   -- #1617 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bis-Acrylamide LSR0149-500ml 500ml';   -- #1618 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bradford Reagent LSR0157-1 500MLX2';   -- #1619 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bromocresol Green GRM118-5G 5gm';   -- #1620 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bromophenol Blue LSR0145 25 GMS';   -- #1621 [Molecular & Micro] HSN: 32049000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centrifuge Tubes 1.5ml 500PACK';   -- #1622 [Molecular & Micro] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centrifuge Tubes 15 ml Pcs Nos';   -- #1623 [Molecular & Micro] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Contact Plates 55MM CP55MM Nos';   -- #1624 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HICROME UTI AGAR M1353 500G';   -- #1625 [Molecular & Micro] HSN: 38210000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Human JAK2 Gene V617F Mutation Nos';   -- #1626 [Molecular & Micro] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Human KRAS Gene G13D Mutation Nos';   -- #1627 [Molecular & Micro] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'MCT 0.5ml Clear LSR2011 1000Pcs';   -- #1628 [Molecular & Micro] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Microtips Box 10UL Pcs';   -- #1629 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Microtips Box 2-200UL Pcs';   -- #1630 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Microtips Box 200-1000UL Pcs';   -- #1631 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PCR Plate Nos';   -- #1632 [Molecular & Micro] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Petri dish 90mm Gamma PD90MM Nos';   -- #1633 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 15ml LSR100303 72Pcs';   -- #1634 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 250mlLSR100307 72Pcs';   -- #1635 [Molecular & Micro] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 2L LSR101401 6Pcs';   -- #1636 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 30ml LSR100304 72Pcs';   -- #1637 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 4ml LSR100301 72Pcs';   -- #1638 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 500mlLSR100308 48Pcs';   -- #1639 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 60ml LSR100305 72Pcs';   -- #1640 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles 8ml LSR100302 72Pcs';   -- #1641 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottles1000mlLSR100309 24Pcs';   -- #1642 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sepsis Pathogenic Microorganis Nos';   -- #1643 [Molecular & Micro] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Streptomycine Sulphate 5gm';   -- #1644 [Molecular & Micro] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TAE Buffer 10X LSR0135';   -- #1645 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TEB Buffer 500ml';   -- #1646 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TRIS EDTA BUFFER 100 ML';   -- #1647 [Molecular & Micro] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Taq DNA Polymerase LSR0116 1000U';   -- #1648 [Molecular & Micro] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Tips 10ul Clear LSR2019 1000Pcs';   -- #1649 [Molecular & Micro] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Box 380x280x310';   -- #1650 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Box 385x375x310';   -- #1651 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Box 565x525x365';   -- #1652 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Box 565x525x365@18%';   -- #1653 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Box 820x360x285 For UP Govt.';   -- #1654 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Box 820x360x300 For OSMCL';   -- #1655 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Carton 230*140*170 Box';   -- #1656 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Carton 385*275*310 Box';   -- #1657 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Carton 735*485*400 Box';   -- #1658 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Corrugated Box 57*52*36.50';   -- #1659 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Gatta 38.5x27x31Cms';   -- #1660 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Gatta 38x27x31.5 Cms';   -- #1661 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Gatta Small Box';   -- #1662 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Gatta size 32x24x24.5CM';   -- #1663 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply Gatta size 735*485*400MM';   -- #1664 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5Ply gatta 52x48x38.5CM';   -- #1665 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '7Ply Diluent Boxes';   -- #1666 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '7Ply Diluent Boxes @18%';   -- #1667 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '9Ply White Box';   -- #1668 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Apex SC 72MM*50Mtrs';   -- #1669 [Packing Material] HSN: 300510 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES FLUOESCREEN HEALTHCARE 190*160*75';   -- #1670 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES FOR ALCOHOL SWAB 70% IPA';   -- #1671 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES GREEN 78*83*40 MM TAMILNADU GOVT';   -- #1672 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES HEMOGLOBIN';   -- #1673 [Packing Material] HSN: 44209010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES HEMOGLOBIN 4*4 (INNER BOX)';   -- #1674 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES HEMOGLOBIN 4*7.5 (OUTER BOX)';   -- #1675 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES HIV RAPID OSMCL';   -- #1676 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES IVD 143*132*122 600ML TN Govt';   -- #1677 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES MALARIA 10 TEST OSMCL';   -- #1678 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES PLAIN WHITE 50 TEST';   -- #1679 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES SYPHILLIS TEST';   -- #1680 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOXES URIC ACID 4*50ML TamilNadu';   -- #1681 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes 2P(Urine Strips)';   -- #1682 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes 2P(Urine Strips)@18%';   -- #1683 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes 360 Pharma 25Test';   -- #1684 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes 360 Pharma 50Test';   -- #1685 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes BioCP 10X4.5X7.5 50ML';   -- #1686 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes BioCP 7.5X7.5X4.5 25ML';   -- #1687 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes BioCP 8 X 8 X 8 100ML';   -- #1688 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Blue 100 Test';   -- #1689 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Blue 50Test';   -- #1690 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Blue 50Test@18%';   -- #1691 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Common Rapid 10Test';   -- #1692 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Common Rapid 40Test';   -- #1693 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Common Rapid 40Test*';   -- #1694 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Common Rapid 50';   -- #1695 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Common Rapid50@18%';   -- #1696 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Common Rapid@18% 10Test';   -- #1697 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Covid Ag 25Test';   -- #1698 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Dengue Duo 10Test';   -- #1699 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Dengue Duo 10Test@18%';   -- #1700 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Dengue Duo 25Test';   -- #1701 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Dengue NS1';   -- #1702 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Dengue NS1*';   -- #1703 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Elisa';   -- #1704 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Elisa*';   -- #1705 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Fast Test';   -- #1706 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 100 ml';   -- #1707 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 100 ml @18%';   -- #1708 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 200ml';   -- #1709 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 2Bottle 100 ml';   -- #1710 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 2L+2S 93*93*112 TNGovt';   -- #1711 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 400 ml Pcs';   -- #1712 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 50 ml';   -- #1713 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 50 ml @18%';   -- #1714 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 500ML TamilNaduGovt';   -- #1715 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Green 600ML';   -- #1716 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HBsAg';   -- #1717 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HBsAg 10Test';   -- #1718 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HBsAg @18%';   -- #1719 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG';   -- #1720 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG 10Test';   -- #1721 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG Angel One Plus';   -- #1722 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG Angel One Step';   -- #1723 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG Pregaon';   -- #1724 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG Pregawal';   -- #1725 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCG@18%';   -- #1726 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCV';   -- #1727 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCV 10Test';   -- #1728 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCV @18%';   -- #1729 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HCV Bihar Govt.';   -- #1730 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HIV';   -- #1731 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HIV 10Test';   -- #1732 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HIV*';   -- #1733 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes HIV+Syphilis Combo';   -- #1734 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Janaushadhi HCG 10Test';   -- #1735 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Malaria';   -- #1736 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Malaria 10Test UP Govt.';   -- #1737 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Malaria @18%';   -- #1738 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Malaria OSMCL Outer Box';   -- #1739 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Malaria UP Govt Outer Box';   -- #1740 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Mokshit (100Ml)';   -- #1741 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Mokshit (400Ml)';   -- #1742 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Mokshit (50Ml)';   -- #1743 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Ostic Pharma';   -- #1744 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Plain 100 ml NOS';   -- #1745 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Plain Elisa';   -- #1746 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Plain Rapid';   -- #1747 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Plain White 50ml';   -- #1748 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Pregnasin';   -- #1749 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Sharloni Labs';   -- #1750 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Sickle Cell';   -- #1751 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Syphilis';   -- #1752 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Troponin I TamilNaduGovt';   -- #1753 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Typhoid 30Test@18%';   -- #1754 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Typhoid 50Test';   -- #1755 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Typhoid 50Test@18%';   -- #1756 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes VTM Tube';   -- #1757 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Boxes Widal';   -- #1758 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CASSTE FOR POCT TEST DRAWARY';   -- #1759 [Packing Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 40X20  5000 UP';   -- #1760 [Packing Material] HSN: OTHERS | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 40X40  2400UP';   -- #1761 [Packing Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 50X20  3000 UP';   -- #1762 [Packing Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 50X20 5000 UP';   -- #1763 [Packing Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 50X30  4000 UP';   -- #1764 [Packing Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 50x38  3000';   -- #1765 [Packing Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 60x50  1000 PCS';   -- #1766 [Packing Material] HSN: 48219090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHROME 75x50  1000 PCS';   -- #1767 [Packing Material] HSN: 48219090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CUBITAINER EMPTY 20 LTRS NOS';   -- #1768 [Packing Material] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dropper 25ul @12%';   -- #1769 [Packing Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOB Tubes';   -- #1770 [Packing Material] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Turbi Calibrator Set';   -- #1771 [Packing Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lancet';   -- #1772 [Packing Material] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lancet Plastic (100pcs)iCare';   -- #1773 [Packing Material] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PACKING BOX';   -- #1774 [Packing Material] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PP Mixing Sticks 25 Test';   -- #1775 [Packing Material] HSN: 39172200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Packing Tape White';   -- #1776 [Packing Material] HSN: 39199090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SEMI TRANSPARENT TUBE';   -- #1777 [Packing Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Swab';   -- #1778 [Packing Material] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Cup(Collection Tray)';   -- #1779 [Packing Material] HSN: 90189099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine(Surgical)Container,40ml';   -- #1780 [Packing Material] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WAD FOR 2P BOTTLES PCS';   -- #1781 [Packing Material] HSN: 76071999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '100ml Glass Vial With Accessories';   -- #1782 [Packing Material] HSN: 70109000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '25 OH VITAMIN D CASSETTE ISIA';   -- #1783 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '2ML Glass Vial';   -- #1784 [Packing Material] HSN: 70101000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '4ML Vial';   -- #1785 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '5 Circle Black PVC Latex Slide';   -- #1786 [Packing Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '50ml Glass Vial With Accessories';   -- #1787 [Packing Material] HSN: 70109000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '5ML Glass Vial';   -- #1788 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '6 Circle Black Plastic Slide';   -- #1789 [Packing Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'AMH CASSETTE ISIA';   -- #1790 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ANTI CCP CASSETTE ISIA';   -- #1791 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ASO CASSETTE ISIA';   -- #1792 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Amber Glass Vials 2 ml PCS';   -- #1793 [Packing Material] HSN: 70101000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BETA HCG CASSETTE ISIA';   -- #1794 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BOPP PACKING 2*3T';   -- #1795 [Packing Material] HSN: 39231090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BOPP PACKING 3*4T';   -- #1796 [Packing Material] HSN: 39231090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BUFFER BOTTLE 5 ML Local';   -- #1797 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BUFFER BOTTLE 5 ML PCS';   -- #1798 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BUFFER TRAY';   -- #1799 [Packing Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Bopp Packing 5*7';   -- #1800 [Packing Material] HSN: 39231090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Buffer Bottle Rapid';   -- #1801 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'CK-MB CASSETTE ISIA';   -- #1802 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette 25-OH-Vitamin D';   -- #1803 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette AMH';   -- #1804 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Beta-HCG';   -- #1805 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Chikanguniya';   -- #1806 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Colera Ag';   -- #1807 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Covid';   -- #1808 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Dengue IgG+IgM';   -- #1809 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Dengue NS1';   -- #1810 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette FSH';   -- #1811 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Filaria';   -- #1812 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette H.Pylori Ab';   -- #1813 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette H.Pylori Ag';   -- #1814 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HAV';   -- #1815 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HBsAg';   -- #1816 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HCG Mini';   -- #1817 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HCG Regular';   -- #1818 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HCV';   -- #1819 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HEV';   -- #1820 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HIV';   -- #1821 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HIV 4th Gen';   -- #1822 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HIV+Syphilis Combi';   -- #1823 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HSV 1';   -- #1824 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HSV 2';   -- #1825 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette HbA1c';   -- #1826 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Holder Dengue Duo';   -- #1827 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette LH';   -- #1828 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Leishmania';   -- #1829 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Leptospira';   -- #1830 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Malaraia Pf/PvAg';   -- #1831 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Malaria Pf/Pan';   -- #1832 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Multi HBV';   -- #1833 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette PCT';   -- #1834 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette PSA';   -- #1835 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Plain Double Hole';   -- #1836 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Plain Single Hole';   -- #1837 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Prolactin';   -- #1838 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Rota';   -- #1839 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Rubella';   -- #1840 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Scrub Typhus';   -- #1841 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Sickle Cell';   -- #1842 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Syphilis';   -- #1843 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette TSH';   -- #1844 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Toxo';   -- #1845 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Trop I';   -- #1846 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Typhoid';   -- #1847 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cryo Vial 1.8ml';   -- #1848 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cryogenic Vails';   -- #1849 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'DRIED BLOOD SPOT CARD 5 CIRCLE';   -- #1850 [Packing Material] HSN: 48239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Dropper 10ul';   -- #1851 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Dropper 25ul @18%';   -- #1852 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Dropper 5ul @18%';   -- #1853 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'FERRITIN CASSETTE ISIA';   -- #1854 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'FOAM 3 HOLE PCS';   -- #1855 [Packing Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'FOAM 5 Whole for Widol Pcs';   -- #1856 [Packing Material] HSN: 48195090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'FOAM ELISA PCS';   -- #1857 [Packing Material] HSN: 48195090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'FSH CASSETTE ISIA';   -- #1858 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Foam 06 Hole RT PCR NOS';   -- #1859 [Packing Material] HSN: 48195090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Foam 6 Whole for HBA1c Pcs';   -- #1860 [Packing Material] HSN: 48195090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Glass Silde for Widol Pcs';   -- #1861 [Packing Material] HSN: 70101000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Glass Vial 2 ML';   -- #1862 [Packing Material] HSN: 70101000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Inverted CuP 5ul';   -- #1863 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'LABEL';   -- #1864 [Packing Material] HSN: 39199010 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'LH CASSETTE ISIA';   -- #1865 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Loops for Malaria PCS';   -- #1866 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'MYOGLOBIN CASSETTE ISIA';   -- #1867 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Media Bottle 100ml';   -- #1868 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Media Bottle 500ml';   -- #1869 [Packing Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'NOSAL SWAB FOR VTM PCS';   -- #1870 [Packing Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ORAL SWAB FOR VTM PCS';   -- #1871 [Packing Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'OTHER PACKING MATERIAL';   -- #1872 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERT CARDIAC TROPONIN';   -- #1873 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERT CHOLESTEROL';   -- #1874 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERT RF LATEX';   -- #1875 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERT SGOT AST';   -- #1876 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERT UREA UV';   -- #1877 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERT URIC ACID';   -- #1878 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PACK INSERTS AND STICKERS @18';   -- #1879 [Packing Material] HSN: 48211090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PLAIN Laminate Pouch ADI';   -- #1880 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PLASTIC BOTTLE FOR 10P Only Cap';   -- #1881 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PLASTIC BOTTLE FOR 10P With Cap';   -- #1882 [Packing Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PLASTIC BOTTLE FOR 10P Without Cap';   -- #1883 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PLASTIC BOTTLE FOR 2P PCS';   -- #1884 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PP Droppers 25 Test';   -- #1885 [Packing Material] HSN: 39172390 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PP Droppers Tube 50 Test';   -- #1886 [Packing Material] HSN: 39172390 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PP Mixing Sticks 100 Test';   -- #1887 [Packing Material] HSN: 39172390 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PP Mixing Sticks 50 Test';   -- #1888 [Packing Material] HSN: 39172390 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRINT LAM. POUCH HBSAG ADI';   -- #1889 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRINT LAM. POUCH HCV ADI';   -- #1890 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRINT LAM. POUCH HIV ADI';   -- #1891 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRINTED LAM POUCHES 360';   -- #1892 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRINTED LAM POUCHES ADI PCS';   -- #1893 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRINTED LAMINATED POUCH HCG MINI RT';   -- #1894 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PRL CASSETTE ISIA';   -- #1895 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PROGESTERONE CASSETTE ISIA';   -- #1896 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert';   -- #1897 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert ADA';   -- #1898 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Alkaline Phosphatase';   -- #1899 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Glucose(GOD/POD)';   -- #1900 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert HBsAg Rapid Test(S/P)';   -- #1901 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert HIV Rapid (S/P/Whole Blood)';   -- #1902 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Malaria Pf/Pv/';   -- #1903 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Sickle Cell';   -- #1904 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Sodium';   -- #1905 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Syphilis Rapid';   -- #1906 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pack Insert Urine Strip 10P/2P';   -- #1907 [Packing Material] HSN: 49119990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plain Laminate Pouch Pcs';   -- #1908 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Bottle 1Ltr';   -- #1909 [Packing Material] HSN: 39231090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Bottle 2P Cap Only';   -- #1910 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Bottle 2P Without Cap';   -- #1911 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Bottle 500ml for lyse pcs';   -- #1912 [Packing Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Bottle Brown 1000 ml Pcs';   -- #1913 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Bottle White 500 ml pcs';   -- #1914 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Cassette For HbA1c';   -- #1915 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Jerry Can 5Ltr';   -- #1916 [Packing Material] HSN: 39231090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial 1 ml pcs';   -- #1917 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown  10 ml PCS';   -- #1918 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 100 ml NOS';   -- #1919 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 125 ml';   -- #1920 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 150 ml';   -- #1921 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 25 ml PCS';   -- #1922 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 30 ml PCS';   -- #1923 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 50 ml PCS';   -- #1924 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 500 ml PCS';   -- #1925 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial Brown 600 ml';   -- #1926 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Plastic Vial White 100 ml pcs';   -- #1927 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Lam Pouch Ostic Pharma';   -- #1928 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Common Pouch Pcs';   -- #1929 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Dengue Duo pcs';   -- #1930 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate HCG Pouch Pcs';   -- #1931 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate HCV Pouch';   -- #1932 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate HCV Pouch BMSCIL';   -- #1933 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate HIV Pouch OSMCL';   -- #1934 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate HIV Pouch Pcs';   -- #1935 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate HIV+SYP Combo Pcs';   -- #1936 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Multi HBV5 Po';   -- #1937 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch DengueNS1';   -- #1938 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Fast Ra';   -- #1939 [Packing Material] HSN: 39232990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch HBsAg Pcs';   -- #1940 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch HCG Angel One';   -- #1941 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch HCG Angel Plus';   -- #1942 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch HCG Janaushadhi';   -- #1943 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Malaria OSMCL';   -- #1944 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Malaria Pcs';   -- #1945 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Malaria UPGovt';   -- #1946 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Sickle Cell';   -- #1947 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Syphilis Big';   -- #1948 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Pouch Syphilis Small';   -- #1949 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminate Typhoid IgG/M pcs';   -- #1950 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printed Laminated Plain Pouch Small';   -- #1951 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printing Cylinder Angle One';   -- #1952 [Packing Material] HSN: 84439100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Printing Cylinder HCG Janaushadi';   -- #1953 [Packing Material] HSN: 84439100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RF CASSETTE ISIA';   -- #1954 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RPR SLIDE 10 CIRCLE PCS';   -- #1955 [Packing Material] HSN: 39172390 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottle 15ml';   -- #1956 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottle 60ml';   -- #1957 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottle 8ml';   -- #1958 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Reagent Bottle Narrow Mouth 125ml';   -- #1959 [Packing Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'STICKERS TAPES FILTER ETC NOS';   -- #1960 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'SWAB PLASTIC POUCH PCS';   -- #1961 [Packing Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Silica Gel 1/2 Gms PCS';   -- #1962 [Packing Material] HSN: 38249900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Swab Paper Rolls';   -- #1963 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TESTOSTERONE CASSETTE ISIA';   -- #1964 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'THERMOCOLE BOX 3.5 LTR';   -- #1965 [Packing Material] HSN: 39219010 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'THERMOCOLE BOX 45 LTR';   -- #1966 [Packing Material] HSN: 39219010 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TT3 CASSETTE ISIA';   -- #1967 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TT4 CASSETTE ISIA';   -- #1968 [Packing Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Transtracker H(H*12)With TTI Applied';   -- #1969 [Packing Material] HSN: 48211090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'URINESTICK 2PSTICKER 65X95, ROLL';   -- #1970 [Packing Material] HSN: 48211020 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Urine Strip 2P Labels';   -- #1971 [Packing Material] HSN: 48211020 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'VTM Tubes 15 ml Pcs';   -- #1972 [Packing Material] HSN: 39235090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'WAD FOR 10P & 2P';   -- #1973 [Packing Material] HSN: 76072090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Ziplock For LANCET';   -- #1974 [Packing Material] HSN: 39249090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Floride Tube 100 Tubes';   -- #1975 [Pipette And Tubes] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Floride Tube 2ml Nos';   -- #1976 [Pipette And Tubes] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'K3 EDTA, 100 Tubes';   -- #1977 [Pipette And Tubes] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICRO PIPETTE STAND PCS';   -- #1978 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 05 Ul Nos';   -- #1979 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 100 Ul Nos';   -- #1980 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 1000 Ul Nos';   -- #1981 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 1ML Nos';   -- #1982 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 20 Ul Pcs';   -- #1983 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 200 Ul Nos';   -- #1984 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 25 Ul NOS';   -- #1985 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 50 Ul Nos';   -- #1986 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Fixed 70 Ul Nos';   -- #1987 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette Superior 1-5ml Nos';   -- #1988 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette01-10 ul,Biogenix Nos';   -- #1989 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette05-50 ul,Biogenix Nos';   -- #1990 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette10-100ul,Biogenix Nos';   -- #1991 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette100-1000 ul,Bioge Nos';   -- #1992 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette2-200 ul,Biogenix Nos';   -- #1993 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette20-200 ul,Biogen Nos';   -- #1994 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette200-1000 ul, Nos';   -- #1995 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette50-200 ul,Biogeni Nos';   -- #1996 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Pipette50-500 ul,Biogeni Nos';   -- #1997 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Tips 1000UL LSR2021 500Pcs';   -- #1998 [Pipette And Tubes] HSN: 84798999 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Plain Tube, 100 Tube';   -- #1999 [Pipette And Tubes] HSN: 90183990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '50ml Centrifuge NonsterileTube';   -- #2000 [Pipette And Tubes] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Micro Pipette Durapet 10-100 Nos';   -- #2001 [Pipette And Tubes] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Micro Pipette Durapet 100-1000 Nos';   -- #2002 [Pipette And Tubes] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Micro Pipette Durapet 20-200 Nos';   -- #2003 [Pipette And Tubes] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Micro Pipette Durapet 5-50 Nos';   -- #2004 [Pipette And Tubes] HSN: 90318000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '1000ul Tips 500Pcs';   -- #2005 [Plastic Ware Import] HSN: 39269099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '200ul Tips with graduation 1000Pcs';   -- #2006 [Plastic Ware Import] HSN: 39269099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '0.2ml Centrifuge tube';   -- #2007 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '0.5ml Centrifuge tube';   -- #2008 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1.5ml Centrifuge tube';   -- #2009 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1.5ml Freezing tube blue cap 500Pcs';   -- #2010 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1.5ml Freezing tube white cap 500Pcs';   -- #2011 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1.8ml Freezing tube 500Pcs';   -- #2012 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1000ul Empty Tips box Box';   -- #2013 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1000ul Sterile Filter Tips';   -- #2014 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1000ul Sterile Tips withtipbox';   -- #2015 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '1000ul SterileFilterTipswitbox';   -- #2016 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '10ul Empty Tips box Box';   -- #2017 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '10ul Sterile Filter Tips 1000Pcs';   -- #2018 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '10ul Sterile FilterTipswithbox 96Pcs';   -- #2019 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '10ul Sterile Tips with tip box 96Pcs';   -- #2020 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '10ul Tips 1000Pcs';   -- #2021 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '200ul Empty Tips box Box';   -- #2022 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '200ul Sterile Filter Tips 1000Pcs';   -- #2023 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '200ul Sterile Tips with tipbox 96Pcs';   -- #2024 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '200ul SterileFilterTipswithbox 96Pcs';   -- #2025 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '2ml Centrifuge tube';   -- #2026 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '4.5ml Freezing tube';   -- #2027 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '5ml Freezing tube';   -- #2028 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '96 well PCR plate semi skirt';   -- #2029 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '96 well PCR plate withoutskirt';   -- #2030 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '96well Deepwell plate U bottom 20Pcs';   -- #2031 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cardboard Freezingtube box 100';   -- #2032 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cardboard Freezingtube box 36';   -- #2033 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centrifuge tube box D23';   -- #2034 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centrifuge tube box D34';   -- #2035 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centrifuge tube box D37';   -- #2036 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Centrifuge tube box D38';   -- #2037 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Double Centrifuge tube rackD27';   -- #2038 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Double Centrifuge tube rackD28';   -- #2039 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Freezing tube box';   -- #2040 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Multi use Rack';   -- #2041 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PCR Tube 0.2ml/8 strip';   -- #2042 [Plastic Ware Import] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25OH VITAMI.D UNCUT SHEET POCT';   -- #2043 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25OH VITAMIN D TEST 20 TEST';   -- #2044 [POCT MACHINE TEST KIT] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH UNCUT SHEET POCT';   -- #2045 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP UNCUT SHEET POCT';   -- #2046 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO UNCUT SHEET POCT';   -- #2047 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BETA HCG UNCUT SHEET POCT';   -- #2048 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CORTISOL UNCUT SHEET POCT';   -- #2049 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cassettes 1 POCT RawMaterial';   -- #2050 [POCT MACHINE TEST KIT] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cassettes 2 POCT RawMaterial';   -- #2051 [POCT MACHINE TEST KIT] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DENGUE IGG/IGM UNCUT SHET POCT';   -- #2052 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FERRITIN UNCUT SHEET POCT';   -- #2053 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH UNCUT SHEET POCT';   -- #2054 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C TEST KIT 20 TEST';   -- #2055 [POCT MACHINE TEST KIT] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C UNCUT SHEET POCT';   -- #2056 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c RAPID TEST POCT,BIOGENIX TEST';   -- #2057 [POCT MACHINE TEST KIT] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ID Card POCT';   -- #2058 [POCT MACHINE TEST KIT] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ImmunofluorecenceAnalyzer POCT PCS';   -- #2059 [POCT MACHINE TEST KIT] HSN: 90275090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH RAPID TEST POCT, BIOGENIX 25 TEST';   -- #2060 [POCT MACHINE TEST KIT] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH UNCUT SHEET POCT';   -- #2061 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICROALBUMIN UNCUT SHEET POCT';   -- #2062 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL UNCUT SHEET POCT';   -- #2063 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROGESTRONE UNCUT SHEET POCT';   -- #2064 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Packing Material Pouches POCT';   -- #2065 [POCT MACHINE TEST KIT] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF UNCUT SHEET POCT';   -- #2066 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 UNCUT SHEET POCT';   -- #2067 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 UNCUT SHEET POCT';   -- #2068 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TESTOSTERONE UNCUT SHEET POCT';   -- #2069 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IGE UNCUT SHEET POCT';   -- #2070 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH RAPID TEST POCT, BIOGENIX TEST';   -- #2071 [POCT MACHINE TEST KIT] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH TEST 20 TEST';   -- #2072 [POCT MACHINE TEST KIT] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH UNCUT SHEET POCT';   -- #2073 [POCT MACHINE TEST KIT] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH RAPID TEST POCT 25 TEST';   -- #2074 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO RAPID TEST POST 25 TEST';   -- #2075 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CCP Rapid Test POCT 25 Test';   -- #2076 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aspergillus Galactomannan Rapi Test';   -- #2077 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOLT-LINE ANA (20 TEST) 20 TEST';   -- #2078 [Rapid] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG Rapid Test POCT 25 Test';   -- #2079 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Buffer for Syphilis W/B';   -- #2080 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C.Difficile GDH Toxin A+B 10 test';   -- #2081 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHIKUNGUNYA Igm/IgM RAPID TEST 40Test';   -- #2082 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CORTISOL RAPID TEST POCT 25 TEST';   -- #2083 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calprotectin Rapid Test 10 test';   -- #2084 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgG/IgM Rapid 40Test';   -- #2085 [Rapid] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgM Rapid  Test';   -- #2086 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia Trachomatis Rapid 10 Test';   -- #2087 [Rapid] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholera Ag 25 TEST 25Test';   -- #2088 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cryptococcus Capsular Test 20 test';   -- #2089 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DENGUE IGG/IGM RAPID TEST POCT 25 TEST';   -- #2090 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue Duo (NS1+IgG+IgM)Bioge 10 TEST';   -- #2091 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue Duo (NS1+IgG+IgM)Bioge 25 Test';   -- #2092 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgG+IgM Rapid Test 50 Test';   -- #2093 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Rapid Test Test 50 Test';   -- #2094 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ENTAMOEBA HISTOLYTICA TEST CAS 10 TEST';   -- #2095 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Entamoeba/Giardia/Crypto Rapid 10 test';   -- #2096 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FERRITIN RAPID TEST POCT 25 TEST';   -- #2097 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH RAPID TEST POCT 25 TEST';   -- #2098 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fecal Calprotectin Rapid 30Test';   -- #2099 [Rapid] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fecal Occult Blood (FOB) TEST';   -- #2100 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Filaria IgG+IgM Rapid test Bio Test';   -- #2101 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GDH(Stool Clospridium TOX A+B) Test';   -- #2102 [Rapid] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gonorrhea Ag Rapid Test 10Test';   -- #2103 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.Pylori Antibbody Biogenix Test';   -- #2104 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.Pylori Antigen Biogenix 25 Test';   -- #2105 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HAV IgM Rapid Test Biogenix Test';   -- #2106 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C RAPID TEST POCT 25 TEST';   -- #2107 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBV5 Panel (Markers) Rapid TEST';   -- #2108 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg Rapid S/P Test Biogenix 50 Test';   -- #2109 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg Rapid W/B Test Biogenix 50 TEST';   -- #2110 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG MINI RAPID TEST (RT)';   -- #2111 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG Rapid Big 50Test';   -- #2112 [Rapid] HSN: 38220011 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG Rapid Test 50 Test';   -- #2113 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG Rapid Test S/P 50Test';   -- #2114 [Rapid] HSN: 38220011 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Positive &Negative control PCS';   -- #2115 [Rapid] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Positive and Negative Cont set';   -- #2116 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV RAPID WHOLE BLOOD BMSICL 50 TEST';   -- #2117 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Rapid Test 50Test';   -- #2118 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Rapid Test Whole Blood 50 Test';   -- #2119 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IGM Rapid Test  Test';   -- #2120 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1/2 RAPID TEST 10 TEST';   -- #2121 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1/2 RAPID TEST OSMCL 10 TEST';   -- #2122 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1/2 RAPID TEST OSMCL 50TEST';   -- #2123 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1/2 Rapid Test Biogenix 50 50 Test';   -- #2124 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV Rapid Test IV Generation Test';   -- #2125 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV/Syphilis Combo Rapid Test 30T';   -- #2126 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV-1 IgG/IgM Test';   -- #2127 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV-2 IgG/IgM Test';   -- #2128 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'JEV Igm Ab 10Test 10Test';   -- #2129 [Rapid] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Janaushadhi Ankur HCG Test Kit 10Test';   -- #2130 [Rapid] HSN: 38220011 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH RAPID TEST POCT 25 TEST';   -- #2131 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH RAPID TEST, Biogenix TEST';   -- #2132 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leismania IgG+IgM Rapid Test TEST';   -- #2133 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leptospira IgG+IgM Biogenix Test';   -- #2134 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICROALBUMIN RAPID TEST POCT 25 TEST';   -- #2135 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria Antigen pf/Pan Test';   -- #2136 [Rapid] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria Pf/Pv Antigen 50 Test 50 Test';   -- #2137 [Rapid] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria Pf/Pv Antigen OSMCL 10TEST';   -- #2138 [Rapid] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria Pf/Pv Antigen UP Govt 10Test';   -- #2139 [Rapid] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT PROBNP RAPID, EASYDIAGNOSTI TEST';   -- #2140 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Neisseria Gonorrhoea Rapid 10 Test';   -- #2141 [Rapid] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PAG Rapid Test 5Test';   -- #2142 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCT RAPID TEST, Easy Diagnosti TEST';   -- #2143 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROGESTERONE RAPID TEST POCT 25 TEST';   -- #2144 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROLACTIN RAPID TEST POCT 25 TEST';   -- #2145 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PSA Rapid Test';   -- #2146 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF RAPID TEST POCT 25 TEST';   -- #2147 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rapid Pap Stain Kit';   -- #2148 [Rapid] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rota Virus Ag TEST';   -- #2149 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rubella IgG/IgM Test';   -- #2150 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SICKLE CELL BUFFER 1.8 ML PCS';   -- #2151 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SWAB BIOGENIX PCS';   -- #2152 [Rapid] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Salmonella IgM Rapid Test Test';   -- #2153 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Scrub Typhus IgG+IgM Rapid 50 Test';   -- #2154 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Scrub Typhus IgM Rapid TEST';   -- #2155 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell 50Test';   -- #2156 [Rapid] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Biogenix 30Test';   -- #2157 [Rapid] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Biogenix 50Test';   -- #2158 [Rapid] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphlis Rapid Test Serum Plasm 50 Test';   -- #2159 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphlis Rapid Test Whole Blood Test';   -- #2160 [Rapid] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 RAPID TEST POCT 25 TEST';   -- #2161 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 RAPID TEST POCT BIOGENIX TEST';   -- #2162 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 RAPID TEST POCT 25 TEST';   -- #2163 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 RAPID TEST POCT BIOGENIX TEST';   -- #2164 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TESTOSTERONE RAPID TEST POCT 25 TEST';   -- #2165 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IGE RAPID TEST POCT 25 TEST';   -- #2166 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROPONIN I 25 TEST TAMILNADU TEST';   -- #2167 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROPONIN I BIOGENIX TEST 10 Test';   -- #2168 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROPONIN I BIOGENIX TEST TEST';   -- #2169 [Rapid] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH RAPID TEST POCT 25 TEST';   -- #2170 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxo IgG/IgM Rapid Test Test';   -- #2171 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Typhiod IgG+IgM Rapid Test Bio Test';   -- #2172 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Typhiod IgG+IgM rapid Test 30 Test';   -- #2173 [Rapid] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN D RAPID TEST POCT 25 TEST';   -- #2174 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN D RAPID TEST POCT BIOG TEST';   -- #2175 [Rapid] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Polystyrene HIPS BAGS 25Kg.';   -- #2176 [Rapid] HSN: 39031990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '8-HYDROXYQUINOLINE';   -- #2177 [Raw Material] HSN: 29332990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ALPHA HCG(COATING)';   -- #2178 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMPHOTERICIN';   -- #2179 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP UNCUT SHEET ISIA';   -- #2180 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO UNCUT SHEET ISIA';   -- #2181 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ATP';   -- #2182 [Raw Material] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Acetic Acid';   -- #2183 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Alpha LH Coating';   -- #2184 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti FOB Ab(Coating)(BRCFOBS102)';   -- #2185 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti FOB Ab(Conjugation)(BRJFOBS102)';   -- #2186 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti FPR';   -- #2187 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Hemoglobin A1c Clone 16';   -- #2188 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Hemoglobin Clone 10';   -- #2189 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Hemoglobin Clone 6';   -- #2190 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Hemoglobin Clone 9';   -- #2191 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Human Hemoglobin Clone 7';   -- #2192 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Human Hemoglobin Clone 8';   -- #2193 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti IgG HRP Conjugate BEEIGGI102';   -- #2194 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-Hemoglobin Mouse';   -- #2195 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-cTnl mab(NIN102)Coating';   -- #2196 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-cTnl mab(NIN105)Coating';   -- #2197 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-cTnl mab(NIN113)Conjugate';   -- #2198 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-human IgG(Coating)BRCIGGI102';   -- #2199 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti-human IgM(Coating)BRCIGMC104';   -- #2200 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Arrow Masking Tape (Blue) 25mm x 305mm';   -- #2201 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Arrow Masking Tape (Blue) 30mm x 300mm';   -- #2202 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BOVINE ALBUMIN (BSA)';   -- #2203 [Raw Material] HSN: 35029000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BSA';   -- #2204 [Raw Material] HSN: 30029020 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BUFFER ISIA';   -- #2205 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG (Conjugation)';   -- #2206 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta LH Conjugation';   -- #2207 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blocker 03-S01';   -- #2208 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blocking Solution GENHCVBR';   -- #2209 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blocking Solution GENHIVBR';   -- #2210 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blocking solution GENHBVBR';   -- #2211 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Seprator (12mm x 300mm)';   -- #2212 [Raw Material] HSN: 70199010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bromocresol Green';   -- #2213 [Raw Material] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bromothymol Blue';   -- #2214 [Raw Material] HSN: 39119090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Buffer GENFCRPSD';   -- #2215 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Buffer Standard Solution pH  4';   -- #2216 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Buffer Standard Solution pH 7';   -- #2217 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Buffer Standard Solution pH 9.18';   -- #2218 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C.Difficile GDH Antigen UncutSheet RG0111';   -- #2219 [Raw Material] HSN: 3002 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C.Difficile Toxin A Antigen UncutSheet RG0131';   -- #2220 [Raw Material] HSN: 3002 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'C.Difficile Toxin B Antigen UncutSheet RG0121';   -- #2221 [Raw Material] HSN: 3002 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CASEIN SODIUM SALT';   -- #2222 [Raw Material] HSN: 35019000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHICKEN IGY AGCIG-0100 MG';   -- #2223 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CNPG2 @12%';   -- #2224 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CNPG2 @18%';   -- #2225 [Raw Material] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CUVETTE';   -- #2226 [Raw Material] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calcium Chloride Fused';   -- #2227 [Raw Material] HSN: 28273990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calprotectin(Cal)Antigen Uncut Triline RG1211';   -- #2228 [Raw Material] HSN: 3002 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calprotectin(Cal)Antigen Uncut TwoLine RG1211';   -- #2229 [Raw Material] HSN: 3002 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikenguniya Buffer BMGCHK21';   -- #2230 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikunguniya IgM(Conjugation)(CHIKN103)';   -- #2231 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia Buffer BMGCHM01';   -- #2232 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia Buffer BMGCHM02';   -- #2233 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chloroform';   -- #2234 [Raw Material] HSN: 29031300 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholera(O1/O139) Antigen Uncut Sheet RG0612';   -- #2235 [Raw Material] HSN: 3002 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholesterol Esterase @12%';   -- #2236 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Concentrated Chlamydia Buffer A';   -- #2237 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Concentrated Chlamydia Buffer B';   -- #2238 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Conjugate Buffer Powder HCVCBP';   -- #2239 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Conjugate Buffer Powder HIVCBP';   -- #2240 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Coupling Protein GRJCPS201';   -- #2241 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Coupling Protein GRJCPS202';   -- #2242 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Coupling Protien FPZ0641';   -- #2243 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cupric Sulphate PentahydrateAR 500 Gms';   -- #2244 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D-GLUCOSE';   -- #2245 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D.DIMER ANTIBODY BBNDIMN103';   -- #2246 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D.DIMER ANTIBODY BBNDIMN104';   -- #2247 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DETERGENT-500ML FUS2000';   -- #2248 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DIETHANOLAMINE';   -- #2249 [Raw Material] HSN: 90251910 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DL-Dithiothreitol(DTT)';   -- #2250 [Raw Material] HSN: 29309099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 17MM X 100MT';   -- #2251 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 18MM X 100MT';   -- #2252 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 20MM X 100MT';   -- #2253 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 23MM X 100MT';   -- #2254 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 25MM X 100MT';   -- #2255 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 30MM X 100MT';   -- #2256 [Raw Material] HSN: 39191000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue Antibody A47-Ab15';   -- #2257 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue Antibody A47-Ab16';   -- #2258 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Antibody Dengue1M';   -- #2259 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Antibody Dengue4HB';   -- #2260 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Antibody Dengue7MB';   -- #2261 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Coating';   -- #2262 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Conjugation';   -- #2263 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1(Conjugation)BRJNS1S103';   -- #2264 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1-BRCNS1S112(Coating)';   -- #2265 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1-BRCNS1S113(Coating)';   -- #2266 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1-BRCNS1S114(Coating)';   -- #2267 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue Rec.Ag Type-I(Conjugation)0031';   -- #2268 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue Rec.Ag Type-II(Conjugation)0036';   -- #2269 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dilution Buffer GENHBVCD';   -- #2270 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dilution Buffer GENHCVBAD';   -- #2271 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dilution Buffer GENHCVCD';   -- #2272 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dilution Buffer GENHIVBAD';   -- #2273 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dilution Buffer GENHIVCD';   -- #2274 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Disodium Tetraborate Decahydrate(Borax deca.)';   -- #2275 [Raw Material] HSN: 28401900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'EPE FOAM';   -- #2276 [Raw Material] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Emergen A60';   -- #2277 [Raw Material] HSN: 34021300 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOCUS-125ML FUS2000';   -- #2278 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FORMALDEHYDE';   -- #2279 [Raw Material] HSN: 29163190 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GENTAMYCIN';   -- #2280 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GLDH @12%';   -- #2281 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GOAT ANTI CHICKEN IGY ABGAC-0500';   -- #2282 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GOAT Anti Mouse IgG ABGAM-0500';   -- #2283 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gelatin Powder';   -- #2284 [Raw Material] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glycerokinase(GYK)@12%';   -- #2285 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Goat Anti Rabbit IgG ABGAR-0500';   -- #2286 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.P.Antibody BMGHPM01';   -- #2287 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.P.Antibody BMGHPM02';   -- #2288 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.pylori Antibody(conjugation) BRNHPS102';   -- #2289 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.pylori Rec.Antigen(Coating)GRNHPS104';   -- #2290 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.pylori Rec.Antigen(conjugation)GRNHPS104';   -- #2291 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.pylori antibody (Coating)  BRNHPS101';   -- #2292 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H10-800 FUS2000(10BOTTLE*100STRIPS)';   -- #2293 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C (R1) Reagent ML';   -- #2294 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C (R2) Reagent ML';   -- #2295 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg MONOCLONAL ANTIBODY(Coating)A27-AB2';   -- #2296 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg MONOCLONAL ANTIBODY(Conjugation)A27-AB1';   -- #2297 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG BIG Plastic Cassette';   -- #2298 [Raw Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG MINI PLASTIC CASSETTE';   -- #2299 [Raw Material] HSN:  | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Coupliong mAb ABHCVR12';   -- #2300 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Positive Serum';   -- #2301 [Raw Material] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Recomb Antigen Lyophi. Capture BMGHCV101';   -- #2302 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Recombinant Antigen Conjugate BMGHCV102';   -- #2303 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV antigen AGHCVR01';   -- #2304 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV antigen AGHCVR02';   -- #2305 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV(Coating)GRCHCVS303';   -- #2306 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV(Conjugation)GRJHCVS205';   -- #2307 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDTA 2 NA';   -- #2308 [Raw Material] HSN: OTHERS | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEMOLYSING SOLUTION L2 REAGENT ML';   -- #2309 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV Antigen BMGHEV100';   -- #2310 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV Antigen BMGHEV101';   -- #2311 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV Antigen(conjugation)GECHEVI102';   -- #2312 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIER M-004';   -- #2313 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIER R-040';   -- #2314 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIER-R001';   -- #2315 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1 antigen AGHIV031';   -- #2316 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1 antigen AGHIV032';   -- #2317 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1+2(GP41+120+GP36)Conjugation 302';   -- #2318 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 2 antigen AGHIV024';   -- #2319 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 2 antigen AGHIV026';   -- #2320 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV GP36 Antigen Capture BMGHIV031';   -- #2321 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV GP41 Antigen Capture BMGHIV021';   -- #2322 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV GP41 Antigen Capture BMGHIV030';   -- #2323 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV Recombinant Antigen Conjugate BMGHIV011';   -- #2324 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV-1(GP41+120)Coating GRCHIVS105';   -- #2325 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV-2(GP36)Coating GRCHIVS203';   -- #2326 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV-O 3rd CONJUGATE GRJHIVOS101';   -- #2327 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV-O 3rd Coating GRCHIVOS101';   -- #2328 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HM INFUSION POWDER';   -- #2329 [Raw Material] HSN: 30012020 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Heterophilic Immunoglobulin HIER-E-010';   -- #2330 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Heterophilic Immunoglubin HIER-R-009';   -- #2331 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Heterophilic Immunoglubin HIER-R-014';   -- #2332 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Heterophilic Immunoglubin HIER-R-063';   -- #2333 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Human Hemoglobin mAb Clone 11';   -- #2334 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ISP Propile Alcohal Ltrs';   -- #2335 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'L-Glycerophosphate Oxidase(GPO)@12%';   -- #2336 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDH';   -- #2337 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDH @12%';   -- #2338 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leishmania IgG (Conjugaton)';   -- #2339 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leishmania IgM (Conjugaton)';   -- #2340 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leptospira Antigen BMGLEP12';   -- #2341 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leptospira Antigen BMGLEP22';   -- #2342 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Leptospira Antigen LigA Conjugate BMGLPA12';   -- #2343 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent Calibr FPZ0329-2-C1';   -- #2344 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent Calibr FPZ0329-2-C2';   -- #2345 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent Calibr FPZ0329-2-C3';   -- #2346 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent Calibr FPZ0329-2-C4';   -- #2347 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent Calibr FPZ0329-2-C5';   -- #2348 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent-R1 FPZ0329-1-R1';   -- #2349 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a) biochemical Reagent-R2 FPZ0329-1-R2';   -- #2350 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a)biochemical Reagent Quality FPZ0329-2-Q1';   -- #2351 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lp(a)biochemical Reagent Quality FPZ0329-2-Q2';   -- #2352 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lysis Buffer FPVDIDB3';   -- #2353 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lysis Buffer FPZ0917-2';   -- #2354 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lysozyme Egg White 25g';   -- #2355 [Raw Material] HSN: 35079099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAHbA2-1-P for Thalassemia';   -- #2356 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAHbF-1-P for Thalassemia';   -- #2357 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MAHbF-2-P for Thalassemia';   -- #2358 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MALARIYA ANTIBODY BRCMALS210';   -- #2359 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MALARIYA ANTIBODY BRCMALS216';   -- #2360 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MDH @12%';   -- #2361 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MES';   -- #2362 [Raw Material] HSN: 29349990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MOUSE IgG AGMIG-0100';   -- #2363 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mackonkey AGAR 500G';   -- #2364 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Magnetic Stirrer-5MLH';   -- #2365 [Raw Material] HSN: 84799090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mercuric Nitrate Monohydrate';   -- #2366 [Raw Material] HSN: 285290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Methyl Red Indicator';   -- #2367 [Raw Material] HSN: 3822 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab BRCMALS105 Malaria Coating';   -- #2368 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab BRCMALS207 Malaria';   -- #2369 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab BRCMALS211 Malaria Conjugation';   -- #2370 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab BRCMALS213 Malaria Coating';   -- #2371 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab BRJMALS106 Conjugation';   -- #2372 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab(BRCLHS101)Mg';   -- #2373 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Ab(BRJLHS103)Mg';   -- #2374 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BEJAMHS109';   -- #2375 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BEJAMHS110';   -- #2376 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BENCTNIN101';   -- #2377 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BENHIVN111';   -- #2378 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BENIGGI112';   -- #2379 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BENTSHN103';   -- #2380 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BENTSHS101';   -- #2381 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BENVDN114';   -- #2382 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BNNDIMN101';   -- #2383 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BNNDIMN102';   -- #2384 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCHBAS101';   -- #2385 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCIGGI102';   -- #2386 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCIGGS101';   -- #2387 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCIGMC104';   -- #2388 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCIGMC110';   -- #2389 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCNS1S112';   -- #2390 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCNS1S113';   -- #2391 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCNS1S114';   -- #2392 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCNS1S123';   -- #2393 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRCNS1S127';   -- #2394 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRJCRPS101';   -- #2395 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRJCRPS110';   -- #2396 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRJHBAS101';   -- #2397 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRJHIVS405';   -- #2398 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRJNS1S113';   -- #2399 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRNCTNIN113';   -- #2400 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRNCTNTS101';   -- #2401 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRNCTNTS102';   -- #2402 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody BRNVDN101';   -- #2403 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody GRCIGMC101';   -- #2404 [Raw Material] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal Antibody HRP conjugate BEENS1S105';   -- #2405 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal antibody BECHBVS103';   -- #2406 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal antibody BENHIVN109';   -- #2407 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Monoclonal antibody Biotin Conjugate';   -- #2408 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mouse Anti Human IgG Capture BMGGC01';   -- #2409 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mouse Anti Human IgM Capture BMGGM01';   -- #2410 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mouse IgG1 Anti-Hemoglobin';   -- #2411 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mouse IgG2b Anti-Hemoglobin C HbC1';   -- #2412 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Multi Calibrator Set Biosino 1ML';   -- #2413 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NEGATIVE CONTROL FUS2000';   -- #2414 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NITRIC ACID 69% AR/ACS 01X2.5 LTR';   -- #2415 [Raw Material] HSN: 25010090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Normal Serum';   -- #2416 [Raw Material] HSN: 30021019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PAN PLDH CONJUGATION BRCMALS207';   -- #2417 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'POD(PEROXIDASE)@12%';   -- #2418 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'POSITIVE CONTROL FUS2000';   -- #2419 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PVK 30';   -- #2420 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PVK 90@18%';   -- #2421 [Raw Material] HSN: 39059910 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Peroxidase';   -- #2422 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Poly(Methyl Vinyl Ether-Alt-Maleic Acid)';   -- #2423 [Raw Material] HSN: 39119090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Polyclonal Antibody HRP conjugate BEEHBVS104';   -- #2424 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Polyvinyl Alcohol';   -- #2425 [Raw Material] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Polyvinylpyrolidone(PVK90)';   -- #2426 [Raw Material] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Potassium Chloride';   -- #2427 [Raw Material] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protect Solution GECHIVPSF';   -- #2428 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protect Solution HCVPSE';   -- #2429 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protect Solution HCVPSF';   -- #2430 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protect Solution HCVPSH';   -- #2431 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protect Solution HCVPSI';   -- #2432 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pyragallol red';   -- #2433 [Raw Material] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RBC Antibody';   -- #2434 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RECOMBINANT ANTI-HEMOGLOBIN ANTIBODY-MX6-1.0';   -- #2435 [Raw Material] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF UNCUT SHEET ISIA';   -- #2436 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RUBBER STOPPER';   -- #2437 [Raw Material] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rat IgG Anti-Hemoglobin A HbA1';   -- #2438 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rat IgG1 Anti-Hemoglobin A HbS1';   -- #2439 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Raw Materials of Calibration GBNCRPN101';   -- #2440 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recomb.Antigen GRCTPS202';   -- #2441 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recomb.Antigen GRCTPS203';   -- #2442 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombigen Antigen GENHIVN403';   -- #2443 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombigen Antigen GRCHIVOS101';   -- #2444 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombigen Antigen GRCHIVS117';   -- #2445 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombigen Antigen GRCHIVS204';   -- #2446 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombigen Antigen GRCHVOS101';   -- #2447 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombigen Antigen GRJHIVS308';   -- #2448 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Anti-HbA Antibody';   -- #2449 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Anti-HbC Antibody';   -- #2450 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Anti-HbS Antibody';   -- #2451 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GENAMHN101';   -- #2452 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRCHCVS303';   -- #2453 [Raw Material] HSN: 3822 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRJHCVS205';   -- #2454 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRJHIVS302';   -- #2455 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRJTOX1101';   -- #2456 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRJTOXN101';   -- #2457 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNCHIKN103';   -- #2458 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNCTNIN101';   -- #2459 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNDEN105';   -- #2460 [Raw Material] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNDEN106';   -- #2461 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNDEN107';   -- #2462 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNDEN108';   -- #2463 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant Antigen GRNTSHN101';   -- #2464 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen Biotin Conjugate I311';   -- #2465 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen Biotin Conjugate S205';   -- #2466 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen GECHCV1309';   -- #2467 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen GECHCVI301';   -- #2468 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen GECHIVS201';   -- #2469 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen GECHIVS306';   -- #2470 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen HRP Conjugate FPZ020';   -- #2471 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen HRP Conjugate FPZ0888';   -- #2472 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen HRP Conjugate GEEHIVS105';   -- #2473 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Recombinant antigen HRP Conjugate GEEHIVS201';   -- #2474 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Redissolved Buffer NS1CD';   -- #2475 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Redissolved Buffer TPCD';   -- #2476 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM BICARBONATE';   -- #2477 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM CHLORIDE';   -- #2478 [Raw Material] HSN: 30049099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SODIUM HYDROXIDE';   -- #2479 [Raw Material] HSN: 90291090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'STBP(SODIUM TETRA PHENYL BORON)';   -- #2480 [Raw Material] HSN: 29319090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sample Diluent GENHCVSD';   -- #2481 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sample Diluent GENHIVSD';   -- #2482 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sample Diluent NS1QCS';   -- #2483 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sodium Chloride @12%';   -- #2484 [Raw Material] HSN: 3004 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sucrose AR';   -- #2485 [Raw Material] HSN: 17019990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sulphuric Acid';   -- #2486 [Raw Material] HSN: 2807 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TESTOSTERONE UNCUT SHEET ISIA';   -- #2487 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TIP';   -- #2488 [Raw Material] HSN: 90279090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TP Rec.Antigen Coating AI00606';   -- #2489 [Raw Material] HSN: OTHERS | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TP Rec.Antigen Conjugation AI00605';   -- #2490 [Raw Material] HSN: OTHERS | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROP I COATING TNIN102';   -- #2491 [Raw Material] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROP I COATING TNIN105';   -- #2492 [Raw Material] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROP I CONJUGATE TNIN113';   -- #2493 [Raw Material] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TYPHI H Ag(AI01501)';   -- #2494 [Raw Material] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxoplasma Antigen(XI101)(Conjugation)';   -- #2495 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Toxoplasma Antigen(XN101)(Conjugation)';   -- #2496 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Trigger Solution 100ml*6 Tellgen';   -- #2497 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triton-X 405 @12% Liquid Form';   -- #2498 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triton-X 405 @18% Liquid Form';   -- #2499 [Raw Material] HSN: 34024200 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triton-X 405 @18% Powder Form';   -- #2500 [Raw Material] HSN: 34021300 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Trypan Blue';   -- #2501 [Raw Material] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tsutsugamushi Antigen BMGTSU12(conjugation)';   -- #2502 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tsutsugamushi Antigen BMGTSU22(conjugation)';   -- #2503 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Tsutsugamushi Antigen BMGTSU32(conjugation)';   -- #2504 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Typhi O BSA(AI01502)';   -- #2505 [Raw Material] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UNCUT SHEET TSHFUS02';   -- #2506 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINALYSIS CONTROL NEGATIVE FUS2000';   -- #2507 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINALYSIS CONTROL POSITIVE FUS2000';   -- #2508 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINE SEDIMENT ANALYSER REAGENT FUS2000';   -- #2509 [Raw Material] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'UTI Agar 100gm';   -- #2510 [Raw Material] HSN: 38210000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uncut Sheet CRPFUS01';   -- #2511 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uncut Sheet VDFUS04';   -- #2512 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urease @12%';   -- #2513 [Raw Material] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uricase @12%';   -- #2514 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VRB AGAR 500Gm';   -- #2515 [Raw Material] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WASH BUFFER';   -- #2516 [Raw Material] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Xylidyl Blue I';   -- #2517 [Raw Material] HSN: 29270090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '2-AMINO 2 METHYL PROPANOL(AMP BUFFER)';   -- #2518 [Raw Material] HSN: 29225090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '2-MERCAPTOPYRIDINE N-OXIDE SODIUM SALT';   -- #2519 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '2-PHENOXYETHANOL';   -- #2520 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '4-AMINO ANTIPYRINE';   -- #2521 [Raw Material] HSN: 29331100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = '4-CHLORO-M-CRESOL';   -- #2522 [Raw Material] HSN: 3808 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ABSORBENT PAD(16MM X 300MM)';   -- #2523 [Raw Material] HSN: 48054000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ABSORBENT PAD(18MM X 300MM)';   -- #2524 [Raw Material] HSN: 48054000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ABSORBENT PAD(19MM X 300MM)';   -- #2525 [Raw Material] HSN: 48054000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ABSORBENT PAD(19MM X 300MM)AP250';   -- #2526 [Raw Material] HSN: 48054000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ABSORBENT PAD(26MM X 300MM)';   -- #2527 [Raw Material] HSN: 48054000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ALKALASE';   -- #2528 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ALPHA KETOGLUTARIC ACID';   -- #2529 [Raw Material] HSN: 29183090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'AMINOPROPIONIC ACID';   -- #2530 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'AMMONIUM MOLYBDATE';   -- #2531 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'AMMONIUM SULPHATE';   -- #2532 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'AMP BUFFER';   -- #2533 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Absorbent Pad(16Mm X 300Mm)@18';   -- #2534 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Absorbent Pad(18MM X 300MM)(AP-250)';   -- #2535 [Raw Material] HSN: 48054000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Absorbent Pad(18MM X 300MM)@18%';   -- #2536 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Absorbent Pad(19MM X 300MM)@18%';   -- #2537 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Absorbent Pad(7MM X 300MM)@18%';   -- #2538 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Anti HIV-P24(Coating)BRCHIVS407';   -- #2539 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Anti HIV-P24(Conjugation)BRJHIVS403';   -- #2540 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Arrow Masking Tape 22mm x 300mm';   -- #2541 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Arsenazo III';   -- #2542 [Raw Material] HSN: 29319090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BACITRACIN';   -- #2543 [Raw Material] HSN: 29419090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BHI Powder 500gm';   -- #2544 [Raw Material] HSN: 35040010 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BRIJ-35';   -- #2545 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BRIJ-35(30%AQ.SOL)';   -- #2546 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'BSA @18%';   -- #2547 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Benzoic Acid';   -- #2548 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Blocker Antibody SamplePad Treatment BMGBL01';   -- #2549 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Blocker Antibody SamplePad Treatment BMGBL03';   -- #2550 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Blood Seprator (18mm x 300mm)';   -- #2551 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Blood/Plasma Seprator (7mmx300mm)';   -- #2552 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Boric Acid';   -- #2553 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Brain Heart Infusion Agar gm';   -- #2554 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'CITRIC ACID Monohydrate 99.7% 500 gms';   -- #2555 [Raw Material] HSN: 29182190 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Calcium Carbonate';   -- #2556 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Calcium Chloride';   -- #2557 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Carboys Polypropylene 10ltr';   -- #2558 [Raw Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Carboys wide Mouth Polypropylene 20ltr';   -- #2559 [Raw Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Plain Bottom Biogenix';   -- #2560 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cassette Plain Top Biogenix';   -- #2561 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cetrimide';   -- #2562 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Charcoal';   -- #2563 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Chlorophsphonazo III';   -- #2564 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cholesterol Esterase';   -- #2565 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cholesterol Oxidase';   -- #2566 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cholesterol Oxidase@12%';   -- #2567 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cholesterol Powder';   -- #2568 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Citric Acid';   -- #2569 [Raw Material] HSN: 29182190 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Conjugate Release Pad 10X300mm';   -- #2570 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Conjugate Release Pad 20x300mm';   -- #2571 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Conjugate Release Pad 5x300mm';   -- #2572 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Conjugate Release Pad 7x300mm';   -- #2573 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Creatinine Powder';   -- #2574 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cupric Sulphate';   -- #2575 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Cupric Sulphate Pentahydrate @18%';   -- #2576 [Raw Material] HSN: 28332500 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'D-Alanine';   -- #2577 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'DISODIUM HYDROGEN PHOSPHATE(NA2HPO4)';   -- #2578 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'DMSO';   -- #2579 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 14MM X 100MT';   -- #2580 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 15MM X 100MT';   -- #2581 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'DOUBLE SIDE TAPE 16MM X 100MT';   -- #2582 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Dextrose (D Glucose)';   -- #2583 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Dextrose Mono AR Titan 500gm';   -- #2584 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Diethylene Triamine Penta Acetic Acid (DTPA)';   -- #2585 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Disodium Deoxycholate';   -- #2586 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Dodecyltrimethylammonium Chloride-LTAC';   -- #2587 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Double Sided Tape(300MMX100M)Pcs';   -- #2588 [Raw Material] HSN: 39191000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'EDTA 2 NA';   -- #2589 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'EGTA';   -- #2590 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Erioglaucine (1% Solution)';   -- #2591 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Ethanol';   -- #2592 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Ethyl Celulose';   -- #2593 [Raw Material] HSN: 3912 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'FERRIC NITRATE';   -- #2594 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Ferrous Sulfate';   -- #2595 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Ferrozine';   -- #2596 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Filariasis Conjugated Antigen(BMGFIL102)';   -- #2597 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'GLDH';   -- #2598 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'GOD';   -- #2599 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Glycerokinase(GYK)@18%';   -- #2600 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Glycerol';   -- #2601 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Glycine';   -- #2602 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Glydant';   -- #2603 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Goat Anti Typhi(PI01501)';   -- #2604 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Gold Chloride Trihydrate';   -- #2605 [Raw Material] HSN: 28433000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HAV Antigen Conjugate BMGHAV011';   -- #2606 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HAV Monoclonal Ab Conjugation BRJHAVN104';   -- #2607 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HAV Recombinant Ag BMGHAV100';   -- #2608 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HCL';   -- #2609 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HV-O Subtype Recombinant Antigen(Coating)';   -- #2610 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HV-O Subtype Recombinant Antigen(Conjugation)';   -- #2611 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'HYDROCHLORIC ACID(HCL)';   -- #2612 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Hydrogen Peroxide';   -- #2613 [Raw Material] HSN: 28470000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Hydroxyl Ammonium Chloride';   -- #2614 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Imidazole';   -- #2615 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Isocil';   -- #2616 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette HIV 1+2 Bottom';   -- #2617 [Raw Material] HSN: 998399 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette HIV 1+2 Top';   -- #2618 [Raw Material] HSN: 998399 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette HbsAg Bottom';   -- #2619 [Raw Material] HSN: 39031990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette HbsAg Top';   -- #2620 [Raw Material] HSN: 39031990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette Malaria Bottom';   -- #2621 [Raw Material] HSN: 998399 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette Malaria Top';   -- #2622 [Raw Material] HSN: 998399 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette Plain Bottom';   -- #2623 [Raw Material] HSN: 998399 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Jobwork Cassette Plain Top';   -- #2624 [Raw Material] HSN: 998399 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Ketoglutaric Acid Na.Salt';   -- #2625 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'L-ALANINE';   -- #2626 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'L-Aspartate de-Sodium';   -- #2627 [Raw Material] HSN: 29224920 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'L-Glutamic Acid';   -- #2628 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'L-Glutamic Acid Monosodium';   -- #2629 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'L-Glycerophosphate Oxidase(GPO)@18%';   -- #2630 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Labolene';   -- #2631 [Raw Material] HSN: 34029091 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Lipoproteine Lipase(LPL)@12%';   -- #2632 [Raw Material] HSN: 38229090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Lipoproteine Lipase(LPL)@18%';   -- #2633 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Lithium Carbonate';   -- #2634 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'MDH';   -- #2635 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'MICROWELL PLATE DETACHABLE ELISA 96 WELLS';   -- #2636 [Raw Material] HSN: 39269099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'MOPS Free Acid';   -- #2637 [Raw Material] HSN: 29349990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Magnesium Acetate';   -- #2638 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Magnesium Carbonate Powder';   -- #2639 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Magnesium Chloride (MGCL2.6H2O)';   -- #2640 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Magnesium Sulphate Heptahydrate';   -- #2641 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Malaria Pf Antibody HRP2 Capture BMGMAFM01';   -- #2642 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Malaria Pf Antibody HRP2 Conjugate BMGMAFM02';   -- #2643 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Malaria Pv Antibody LDH Capture BMGMAVM01';   -- #2644 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Malaria Pv Antibody LDH Capture BMGMAVM03';   -- #2645 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Malaria Pv Antibody LDH Conjugate BMGMAVM02';   -- #2646 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Master Batche Plastic Dana for Cassette';   -- #2647 [Raw Material] HSN: 32061900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Mercuric Thiocynate';   -- #2648 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Methanol';   -- #2649 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'NADH';   -- #2650 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Nitrocellulose Membrane 20MM (HCG1)';   -- #2651 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Nitrocellulose Membrane 20MM 10 MICRON';   -- #2652 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Nitrocellulose Membrane 20MM 15 Micron';   -- #2653 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Nitrocellulose Membrane 20mm*15Micron Axi';   -- #2654 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Nitrocellulose Membrane 25MM 10 Micron';   -- #2655 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Nitrocellulose Membrane 25MM 15 Micron';   -- #2656 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'ORTHOPHOSPHORIC ACID';   -- #2657 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'P-Hydroxy Benzoic Acid';   -- #2658 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PHENOL RED CHEMICAL';   -- #2659 [Raw Material] HSN: 39233090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PNP';   -- #2660 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PNPP DI TRIS CHEMICAL';   -- #2661 [Raw Material] HSN: 29190090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'POD(PEROXIDASE)';   -- #2662 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PVC Backing Laminates(60X300MM)(15-25-20)';   -- #2663 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PVC Backing Laminates(60X300MM)(17-20-23)';   -- #2664 [Raw Material] HSN: 84212900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PVC LAMINATE 260MM*120MM';   -- #2665 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PVC Laminate(70x270)';   -- #2666 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PVC Laminates(60X300MM)';   -- #2667 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'PVC Laminates(70X300MM)';   -- #2668 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Phenol';   -- #2669 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Phosphotungstic Acid';   -- #2670 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Picric Acid';   -- #2671 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pipes Di Sodium';   -- #2672 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Pipes Free Acid';   -- #2673 [Raw Material] HSN: 29335990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Polyethylene Glycol (PEG 4000) GM';   -- #2674 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Carbonate';   -- #2675 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Dichromate';   -- #2676 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Dihydrogen Phosphate(KH2PO4)';   -- #2677 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Ferrocyanide';   -- #2678 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Hydroxide';   -- #2679 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Iodide';   -- #2680 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Permagnate';   -- #2681 [Raw Material] HSN: 29152990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Phosphate Dibasic Anhydrous';   -- #2682 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassium Sodium Tartarate';   -- #2683 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Potassuim Thiocyanate';   -- #2684 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Proclin 300';   -- #2685 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Propane-1,2-Diol';   -- #2686 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Proteose Peptone Titan/Bactobio gm';   -- #2687 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'RABBIT IgG AGRIG-0100';   -- #2688 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Rigid PVC Film 0.25x120MM';   -- #2689 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Rigid PVC Film 0.25x70mm';   -- #2690 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'SDS';   -- #2691 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'SODIUM DEOXYCHOLATE RAW';   -- #2692 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'SODIUM DIHYDROGEN PHOSPHATE';   -- #2693 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'SODIUM HYDROOXIDE PELLETS';   -- #2694 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'SODIUM PHOSPHATE DIBASIC ANHYDROS (NA2HPO4)';   -- #2695 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(12MMX300MM)';   -- #2696 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(13MMX300MM)';   -- #2697 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(14MMX300MM)';   -- #2698 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(18MMX300MM)';   -- #2699 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(20MMX300MM)';   -- #2700 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(21MMX300MM)';   -- #2701 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(23MMX300MM)';   -- #2702 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sample Pad(25MMX300MM)';   -- #2703 [Raw Material] HSN: 84219900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Savinase';   -- #2704 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Scrub Typhus Antigen BMGTSU12';   -- #2705 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Scrub Typhus Antigen BMGTSU22';   -- #2706 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Scrub Typhus Antigen BMGTSU32';   -- #2707 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Acetate';   -- #2708 [Raw Material] HSN: 29152990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Azide(NAN3)';   -- #2709 [Raw Material] HSN: 28500030 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Benzoate';   -- #2710 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Carbonate';   -- #2711 [Raw Material] HSN: 2836 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Cholate';   -- #2712 [Raw Material] HSN: 29183090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Citrate Dihydrate';   -- #2713 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Hypochlorite Solution 4% W/V';   -- #2714 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Lauryl Sulphate(SDS)';   -- #2715 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Molybdate';   -- #2716 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Nitrite';   -- #2717 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Nitropruside';   -- #2718 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Oxalate';   -- #2719 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Phosphate Monobasic Dih Gms';   -- #2720 [Raw Material] HSN: 28352200 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Potassium Tartrate';   -- #2721 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Salicylate';   -- #2722 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Sulphate Anhydrous';   -- #2723 [Raw Material] HSN: 28331990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Sulphite /Sodium Sulphite Anhydrous';   -- #2724 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sodium Tetraborate Decahydrate-Borax';   -- #2725 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Stabilzyme HRP Conjugate Stab';   -- #2726 [Raw Material] HSN: 38249900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Succinic Acid';   -- #2727 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sucrose@18%';   -- #2728 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Sulphanilic Acid';   -- #2729 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TERGITOL (TM), TYPE NP-40,70% 500 ML';   -- #2730 [Raw Material] HSN: 29221990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TOOS';   -- #2731 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TREHALOSE';   -- #2732 [Raw Material] HSN: 29400000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TRI SODIUM CITRATE';   -- #2733 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TRIS BUFFER(BASE)';   -- #2734 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TRIS BUFFER(HCL)';   -- #2735 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TRITON-X 100';   -- #2736 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'TRITON-X 705';   -- #2737 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Tergitol Solution NP40S-500ml';   -- #2738 [Raw Material] HSN: 98020000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Tetrabromophenol Blue';   -- #2739 [Raw Material] HSN: 29349990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Thiomersal (Thimerosal)';   -- #2740 [Raw Material] HSN: 29349990 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Toluene';   -- #2741 [Raw Material] HSN: 90278090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Toxo Buffer BMGTO301';   -- #2742 [Raw Material] HSN: 48114100 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Triethanolamine';   -- #2743 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Trisodium Citrate Dihydrate';   -- #2744 [Raw Material] HSN: 29181520 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Trizitol';   -- #2745 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Tween-20(Polysorbate20)';   -- #2746 [Raw Material] HSN: 34021900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Urea Powder';   -- #2747 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Urease';   -- #2748 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Uric Acid';   -- #2749 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Uricase';   -- #2750 [Raw Material] HSN: 35079099 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Whatman Filter Paper 270*200MM';   -- #2751 [Raw Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Whatman Filter Paper 3mm CHR 15*17.5CM-100';   -- #2752 [Raw Material] HSN: 48232000 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Woven Roll For Swab 50mm';   -- #2753 [Raw Material] HSN: 39204900 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'XOD';   -- #2754 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 18.00 WHERE `product_name` = 'Zinc Sulphate';   -- #2755 [Raw Material] HSN: 39239090 | IGST: 18%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5\' NT Reagent (R1+R2) Bottle';   -- #2756 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5\' NT Reagent Q. control(1 ml) Vial';   -- #2757 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '5\' NT Reagent calibrator(1 ml) Vial';   -- #2758 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Reagent (R1+R2) Bottle';   -- #2759 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Reagent Q. control (1 ml) Vial';   -- #2760 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Reagent calibrator (1 ml) Vial';   -- #2761 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP Turbi Biosino Kit';   -- #2762 [Sample] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CO2 Reagent Bottle';   -- #2763 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CO2 Reagent Q. control(1 ml) Vial';   -- #2764 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CO2 Reagent calibrator (1 ml) Vial';   -- #2765 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREA Reagent (R1+R2) Bottle';   -- #2766 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREA Reagent Q. control(1 ml) Vial';   -- #2767 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CREA Reagent calibrator(1 ml) Vial';   -- #2768 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Reagent (R1+R2) Bottle';   -- #2769 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Reagent Q. control(2 ml) Vial';   -- #2770 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Reagent calibrator(2 ml) Vial';   -- #2771 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FDP Reagent (R1+R2) Bottle';   -- #2772 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FDP Reagent Q. control(1 ml) Vial';   -- #2773 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FDP Reagent calibrator(1 ml) Vial';   -- #2774 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G6PD Reagent Q. control (1 ml) Vial';   -- #2775 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G6PD Reagent calibrator (1 ml) Vial';   -- #2776 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C Reagent (R1+R2) Bottle';   -- #2777 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C Reagent Q. control(1 ml) Vial';   -- #2778 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C Reagent calibrator(1 ml) Vial';   -- #2779 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCY Reagent (R1+R2) Bottle';   -- #2780 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCY Reagent Q. control(1 ml) Vial';   -- #2781 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCY Reagent calibrator (1 ml) Vial';   -- #2782 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c With Cal & Con 1Set';   -- #2783 [Sample] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IGE Reagent (R1+R2) Bottle';   -- #2784 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IGE Reagent Q. control(1 ml) Vial';   -- #2785 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IGE Reagent calibrator(1 ml) Vial';   -- #2786 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NEFA Reagent (R1+R2) Bottle';   -- #2787 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NEFA Reagent Q. control (1 ml) Vial';   -- #2788 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NEFA Reagent calibrator(1 ml) Vial';   -- #2789 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NGAL Reagent (R1+R2) Bottle';   -- #2790 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NGAL Reagent Q. control(1 ml) Vial';   -- #2791 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NGAL Reagent calibrator(1 ml) Vial';   -- #2792 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PGTT Reagent (R1+R2) Bottle';   -- #2793 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PGTT Reagent Q. control(1 ml) Vial';   -- #2794 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PGTT Reagent calibrator(1 ml) Vial';   -- #2795 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RBP Reagent (R1+R2) Bottle';   -- #2796 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RBP Reagent Q. control(1 ml) Vial';   -- #2797 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RBP Reagent calibrator(1 ml) Vial';   -- #2798 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SA Reagent (R1+R2) Bottle';   -- #2799 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SA Reagent Q. control(1 ml) Vial';   -- #2800 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SA Reagent calibrator(1ml) Vial';   -- #2801 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TBA Reagent (R1+R2) Bottle';   -- #2802 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TBA Reagent calibrator(1 ml) Vial';   -- #2803 [Sample] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ZN With Cal & Con 1Set';   -- #2804 [Sample] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '17 OH PROGESTERONE EILSA WITHOUT BOX';   -- #2805 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25(OH)-Vitamin D without Box 96 Test';   -- #2806 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25-OH-Vitamin D Uncut sheet';   -- #2807 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25OH VITAMIN D TEST CASSETTE ISIA';   -- #2808 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ABX Difftrol H 1*3ml';   -- #2809 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ABX Difftrol L 1*3ml';   -- #2810 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ABX Difftrol N 1*3ml';   -- #2811 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Calibrator 0.5 ML';   -- #2812 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Calibrator 1ml';   -- #2813 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Control High 0.5 ML';   -- #2814 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ADA Control Low 0.5 ML';   -- #2815 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP UNCUT SHEET';   -- #2816 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AFP Without Box Elisa Kit';   -- #2817 [Semi Finish] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH ELISA KITS WITHOUT BOX';   -- #2818 [Semi Finish] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH ELISA WITHOUT BOX';   -- #2819 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH TEST CASSETTE ISIA';   -- #2820 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'AMH Uncut sheet';   -- #2821 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANA ELISA WITHOUT BOX 96 TEST';   -- #2822 [Semi Finish] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANA Screen Elisa Without Box';   -- #2823 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI BETA 2 GLYCOPROTEIN SCREEN DiaMetraW.Box';   -- #2824 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI CCP WITHOUT BOX 96 TEST';   -- #2825 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI MPO DIAMETRA WITHOUT BOX';   -- #2826 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI PR3 DIAMETRA WITHOUT BOX';   -- #2827 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI TPO ELISA WITHOUT BOX';   -- #2828 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'APOB Reagent';   -- #2829 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Latex Positive Control Biosino';   -- #2830 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Latex Reagent Biosino';   -- #2831 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Latex Reagent With Control';   -- #2832 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Latex Reagent With Control*';   -- #2833 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Turbi Latex R2';   -- #2834 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Turbilatex Calibrator Pcs';   -- #2835 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO Turbilatex R1';   -- #2836 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Adenosine Deaminase Reagent In Bulk';   -- #2837 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Albumine Reagent Ltr';   -- #2838 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Alkaline Phosphatase Reagent Ltr';   -- #2839 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ammonia Reagent LTR';   -- #2840 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Amylase Reagent LTR';   -- #2841 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CCP Calibrator Set ML';   -- #2842 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CCP Reagent R1 ML';   -- #2843 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CCP Reagent R2 ML';   -- #2844 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti CP IgG New Generation Elisa without Box';   -- #2845 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Cardiolipin Screen Elisa without Box';   -- #2846 [Semi Finish] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Cardiolupin IgA Without Box';   -- #2847 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti Phospholipids Screen Elisa Without Box';   -- #2848 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti TG';   -- #2849 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti cardiolipin IgG Elisa without Box';   -- #2850 [Semi Finish] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti cardiolipin IgM Elisa without Box';   -- #2851 [Semi Finish] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ApoA1 Reagent';   -- #2852 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Aspergillus IgE Without Box Elisa 96Test';   -- #2853 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'BETA HCG TEST CASSETTE ISIA';   -- #2854 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta HCG Uncut sheet';   -- #2855 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Beta-hCG Elisa Without Box';   -- #2856 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bilirubin Direct Reagent';   -- #2857 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Bilirubin Total Reagent LTR';   -- #2858 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control 10Pcs Pack';   -- #2859 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control 12Pcs';   -- #2860 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control Biored L1';   -- #2861 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control Biored L2';   -- #2862 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control Biored L3';   -- #2863 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control Randox H2';   -- #2864 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control Randox L2';   -- #2865 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Biochemistry Control Randox L3';   -- #2866 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Gas & Chemistry Control L1(Set Of 5)';   -- #2867 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Gas & Chemistry Control L2(Set Of 5)';   -- #2868 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Blood Gas & Chemistry Control L3(Set Of 5)';   -- #2869 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 125 Elisa without Box 96 Test';   -- #2870 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CA 15.3 Elisa Without Box 96Test';   -- #2871 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CALCIUM STANDARD';   -- #2872 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CALIBRATOR FOR HDL';   -- #2873 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CALIBRATOR FOR LDL';   -- #2874 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CD-80';   -- #2875 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEA Elisa Without Box';   -- #2876 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CEA UNCUT SHEET';   -- #2877 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHIKUNGUNIYA IgM ELISA WITHOUT BOX';   -- #2878 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CHOLERA RAPID UNCUT SHEET PCS';   -- #2879 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB Reagent Ltr';   -- #2880 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB TEST CASSETTE ISIA';   -- #2881 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-MB UNCUT SHEET';   -- #2882 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CK-NAC Reagent Ltr';   -- #2883 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IGG ELISA WITHOUT BOX';   -- #2884 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IGM ELISA WITHOUT BOX';   -- #2885 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IgG Elisa EDI';   -- #2886 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CMV IgM/IgG Uncut Sheet';   -- #2887 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Latex Positive Control Biosion';   -- #2888 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Latex Reagent Biosino';   -- #2889 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Latex Reagent Control@18% ML';   -- #2890 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Latex Reagent with Control @12%';   -- #2891 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP RAPID UNCUT SHEET SHEET';   -- #2892 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP TURBI CALIBRATOR PCSBiosino';   -- #2893 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbilatex in Ltr R1+R2 Fapon';   -- #2894 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbilatex in Ltr R1+R2,Biosino';   -- #2895 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calcium Reagent Ltr';   -- #2896 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Calibrator Randox';   -- #2897 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Candida Albicans Uncut';   -- #2898 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Chromogen/Substrate 16ml DiaPro';   -- #2899 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Enzyme Conjugate DiaPro';   -- #2900 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Microplate DiaPro';   -- #2901 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Negative Control DiaPro';   -- #2902 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Plate Sealers DiaPro';   -- #2903 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Positive Control High DiaPro';   -- #2904 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Positive Control Mid DiaPro';   -- #2905 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Specimen Diluent DiaPro';   -- #2906 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Sulphuric Acid-15ml DiaPro';   -- #2907 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikG Wash Solution 20x-60ml DiaPro';   -- #2908 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM  Microplate DiaPro';   -- #2909 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Chromogen/Substrate 16ml DiaPro';   -- #2910 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Enzyme Conjugate DiaPro';   -- #2911 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Negative Control DiaPro';   -- #2912 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Neutralizing Reagent DiaPro';   -- #2913 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Plate Sealers DiaPro';   -- #2914 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Positive Control DiaPro';   -- #2915 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Specimen Diluent DiaPro';   -- #2916 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Sulphuric Acid-15ml DiaPro';   -- #2917 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ChikM Wash Solution 20x-60ml DiaPro';   -- #2918 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgM Uncut Sheet NOS';   -- #2919 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chikungunya IgM/Igm Uncut Sheet';   -- #2920 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgA Uncut Sheet';   -- #2921 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgA Without Box';   -- #2922 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgG Uncut Sheet';   -- #2923 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgG Without Box';   -- #2924 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chlamydia IgM Without Box';   -- #2925 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chloride Reagent Biogenix';   -- #2926 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cholesterol Reagent';   -- #2927 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Chromogen/Substrate For Elisa';   -- #2928 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Colera Ag Uncut Sheet pcs';   -- #2929 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Column(HbA1c)';   -- #2930 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cortisol Without Box Elisa  96 Test';   -- #2931 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Creatinine Reagent LTR';   -- #2932 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cyctain Reagent Calibrator 6Pc ML';   -- #2933 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cyctain Reagent Quality Contro ML';   -- #2934 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Cyctain Reagent R1&R2 ML';   -- #2935 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D CHECK D-H,2.5ML PCS';   -- #2936 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D CHECK D-L,2.5ML PCS';   -- #2937 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D DIMER RAPID UNCUT SHEET SHEET';   -- #2938 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D. Dimer Calibrator';   -- #2939 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D.DIMER CALIBRATOR 1 ML PCS';   -- #2940 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D.Dimer Reagent (R1+R2)3+1';   -- #2941 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DHEA S, BIOGENIX 96 TES WITHOUT BOX';   -- #2942 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Daily Cleaners';   -- #2943 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Chromogen/Substrate 16ml DiaPro';   -- #2944 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Enzyme Conjugate DiaPro';   -- #2945 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Microplate DaiPro';   -- #2946 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Negative Control DiaPro';   -- #2947 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Plate Sealers DiaPro';   -- #2948 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Positive Control DiaPro';   -- #2949 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Specimen Diluent DiaPro';   -- #2950 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Sulphuric Acid-15ml DiaPro';   -- #2951 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenG Wash Solution 20x-60ml Diapro';   -- #2952 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Chromogen/Substrate 16ml DiaPro';   -- #2953 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Enzyme Conjugate DiaPro';   -- #2954 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Microplate DiaPro';   -- #2955 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Negative Control DiaPro';   -- #2956 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Neutralizing Reagent DiaPro';   -- #2957 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Plate Sealers DiaPro';   -- #2958 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Positive Control DiaPro';   -- #2959 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Specimen Diluent DiaPro';   -- #2960 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Sulphuric Acid-15ml DiaPro';   -- #2961 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'DenM Wash Solution 20x-60ml DiaPro';   -- #2962 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Chromogen/Substrate-25ml DiaPro';   -- #2963 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Enzyme Conjugate DiaPro';   -- #2964 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Microplate DiaPro';   -- #2965 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Negative Control DiaPro';   -- #2966 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Plate Sealers DiaPro';   -- #2967 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Positive Control DiaPro';   -- #2968 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Sample Diluent DiaPro';   -- #2969 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Sulphuric Acid-15ml DiaPro';   -- #2970 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deng NS1 Wash Solution 20x-60ml DiaPro';   -- #2971 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue IgG/IgM Uncut sheet';   -- #2972 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Dengue NS1 Uncut sheet';   -- #2973 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Deproteinizer Ampule Module';   -- #2974 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Diluent Reagent';   -- #2975 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'E3 ELISA WITHOUT BOX';   -- #2976 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ELISA ANA WITHOUT BOX KIT';   -- #2977 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESTRADIOL ELISA DIAMETRA WITHOUT BOX';   -- #2978 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ESTRADIOL UNCUT SHEET';   -- #2979 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Elisa Wash Buffer 20X 250ml';   -- #2980 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Elisa Wash Buffer 40X 250ml';   -- #2981 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Elisa Wash Buffer 50X 250ML';   -- #2982 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Enzymatic Cleaner Reagent Kit';   -- #2983 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Enzyme Conjugate Conj EVM Elisa';   -- #2984 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FERRITIN ELISA WITHOUT BOX';   -- #2985 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FERRITIN TEST CASSETTE ISIA';   -- #2986 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FERRITIN TURBI REAGENT LTR';   -- #2987 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FOB UNCUT SHEET SHEET';   -- #2988 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FREE BETA HCG ELISA';   -- #2989 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FREE PSA ELISA';   -- #2990 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FREE TESTOSTERONE DIAMETRA WITHOUT BOX';   -- #2991 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH ELISA WITHOUT BOX';   -- #2992 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH TEST CASSETTE ISIA';   -- #2993 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FSH Uncut sheet';   -- #2994 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT3 Total Elisa without Box 96 test';   -- #2995 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'FT4 Elisa Without Box';   -- #2996 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Calibrator SETS (4) pcs';   -- #2997 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Filaria uncut sheet NOS';   -- #2998 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Filter';   -- #2999 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G. PYLORI IgG ELISA';   -- #3000 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'G6PD Reagent (R1+R2)';   -- #3001 [Semi Finish] HSN: 38221900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GAMMA-GT,Reagent In Ltr';   -- #3002 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GIARDIA ANTIGEN RAPID UNCUT SHEET';   -- #3003 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'GLUCOSE & KETONE UNCUT SHEET';   -- #3004 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gardnerella Vaginails Uncut';   -- #3005 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glucose & Protein uncut sheet Sheet';   -- #3006 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glucose Reagent';   -- #3007 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Glucose uncut Sheet Sheet';   -- #3008 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Gonorrhoea Uncut Sheet';   -- #3009 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H. PYLORI ANTIGEN UNCUT SHEET PCS';   -- #3010 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H. Pylori AB uncut sheet sheet';   -- #3011 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.PYLORI IgG Elisa';   -- #3012 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'H.Pylori IgM Elisa';   -- #3013 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HAV IGM ELISA WITHOUT BOX';   -- #3014 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HAV IGM Uncut Sheet pcs';   -- #3015 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C Hemolysing Solution ml';   -- #3016 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C REAGENT R1 ML';   -- #3017 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C Reagent R2 ml';   -- #3018 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAb Elisa Without Box';   -- #3019 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg Positive Serum 10ml';   -- #3020 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg UNCUT SHEET';   -- #3021 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBsAg W/B UNCUT SHEET NOS';   -- #3022 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG Dipstick Uncut sheet';   -- #3023 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG ELISA WITHOUT BOX';   -- #3024 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG Mini Uncut sheet';   -- #3025 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCG Regular Uncut sheet';   -- #3026 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV Positive Serum 10ml';   -- #3027 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV UNCUT SHEET OLD';   -- #3028 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV UNCUT SHEET S/P';   -- #3029 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HCV UNCUT SHEET W/B';   -- #3030 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL C Direct Reagent(R1+R2)';   -- #3031 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDL/LDL PPT Reagent';   -- #3032 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDV Elisa Ab Without Box';   -- #3033 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HDV Elisa IgM Without Box';   -- #3034 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HE4 Elisa Without Box 96Test';   -- #3035 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEMATOLOGY CONTROL';   -- #3036 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IGM Ab UNCUT SHEET';   -- #3037 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IGM ELISA WITHOUT BOX';   -- #3038 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HEV IGM UNCUT SHEET OLD';   -- #3039 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 1/2 UNCUT SHEET';   -- #3040 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV 4th Genration Uncut Sheet';   -- #3041 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV(HIV-1) Positive Serum 10ml';   -- #3042 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV(HIV-1) Positive Serum 1ltr';   -- #3043 [Semi Finish] HSN: 30021290 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HIV(HIV-2) Positive Serum 10ml';   -- #3044 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HMPV Uncut Sheet';   -- #3045 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HPV Uncut Sheet';   -- #3046 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1 IGG ELISA WITHOUT BOX';   -- #3047 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1 IGM ELISA KIT WITHOUT BOX';   -- #3048 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1 IgG/IgM Uncut Sheet';   -- #3049 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1/2 IgG';   -- #3050 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 1/2 IgM Elisa';   -- #3051 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 2 IGG ELISA WITHOUT BOX';   -- #3052 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 2 IGM ELISA WITHOUT BOX';   -- #3053 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HSV 2 IgG/IgM Uncut Sheet';   -- #3054 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN IL-2sRA/CD25 ELISA W.BOX 96 TEST';   -- #3055 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN TCPa ELISA WITHOUT BOX';   -- #3056 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN VB1(VITAMIN B1) ELISA WITHOUT BOX';   -- #3057 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HUMAN VB6(VITAMIN B6) ELISA WITHOUT BOX';   -- #3058 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1C Calibrator Set(5)Pcs';   -- #3059 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c Assay Kit(HPLC)';   -- #3060 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c Heamolyser';   -- #3061 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c Nos';   -- #3062 [Semi Finish] HSN: 39269099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c TEST CASSETTE ISIA';   -- #3063 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c Uncut sheet';   -- #3064 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hemoglobin A1c Calibrator HC236T01';   -- #3065 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Hemoglobin A1c Control HC235T01';   -- #3066 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IgE Reagent Calibrator C1-C5(10mlEach)';   -- #3067 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IgE Reagent-R1';   -- #3068 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'IgE Reagent-R2';   -- #3069 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Immersion Oil BULK ML';   -- #3070 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Inhibin A Elisa Control Set';   -- #3071 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ioron and TIBC Reragent';   -- #3072 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'KETONE UNCUT SHEET NOS';   -- #3073 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LATEX NEGATIVE CONTROL LTR';   -- #3074 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDH REAGENT Ltr';   -- #3075 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LDL C Direct Reagent Ltr';   -- #3076 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LEISHMANIA IGG/IGM UNCUT SHEET pcs';   -- #3077 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LEPTOSPIRA IGG/IGM UNCUT sheet pcs';   -- #3078 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LEPTOSPIRA IGM ELISA WITHOUT BOX';   -- #3079 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH ELISA WITHOUT BOX';   -- #3080 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Rapid uncut sheet';   -- #3081 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH TEST CASSETTE ISIA';   -- #3082 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LH Uncut Sheet for FIA';   -- #3083 [Semi Finish] HSN: 48191010 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LIPASE REAGENT Ltr';   -- #3084 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LPA Quality Control Q1&Q2 ML';   -- #3085 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LPA Reagent Calibrator 6Pcs ML';   -- #3086 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'LPA Reagent R1&R2 ML';   -- #3087 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lipase Calibrator 1ml';   -- #3088 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lypocheck Immunoassay Plus Control';   -- #3089 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Lyse Reagent';   -- #3090 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'M3 ASPERGILLUS FUMIGATU ELISA';   -- #3091 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MALARIA Pf/Pv Antigen Uncut Sh';   -- #3092 [Semi Finish] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX ASCORBIC ACID';   -- #3093 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX BILURBIN Sheet';   -- #3094 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX BLOOD Sheet';   -- #3095 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX KETONE Sheet';   -- #3096 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX LEUKO Sheet';   -- #3097 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX NITRATE Sheet';   -- #3098 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX PH';   -- #3099 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX SG';   -- #3100 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MEMBRANCE MULTISTIX URO Sheet';   -- #3101 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICROALBUMIN TEST CASSETTE ISIA';   -- #3102 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MICROALBUMIN UNCUT SHEET';   -- #3103 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'MYOGLOBIN TEST CASSATTE ISIA';   -- #3104 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Magnesium Reagent';   -- #3105 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria Ag Buffer 250';   -- #3106 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria Pan Ag Uncut Sheet sheet';   -- #3107 [Semi Finish] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Malaria pf/Pan Ag Uncut Sheet sheet';   -- #3108 [Semi Finish] HSN: 30021100 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Measles IgM Wihtout Box';   -- #3109 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Microplate Active EVM Elisa';   -- #3110 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Microprotein Reagent ltr';   -- #3111 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Multi Control Level 1 Biosino 1*3ml';   -- #3112 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Multi Control Level 2 Biosino 1x3ml';   -- #3113 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Multi HBV5 Panel Uncut Sheet';   -- #3114 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Mumps IgM Without Box 96Test';   -- #3115 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NT PROBNB ANTIGEN RAPID UNCUT SHEET';   -- #3116 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Negative Control Elisa';   -- #3117 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Negative Control For CRP/ASO/R Ltr';   -- #3118 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Neutralizing Reagent';   -- #3119 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Normal Serum 10ml';   -- #3120 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Normal Serum 1Ltr';   -- #3121 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PAPP A, 96 TEST, WITHOUT BOX';   -- #3122 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCT ANTIGEN RAPID TEST UNCUT SHEET';   -- #3123 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PCT Uncut sheet';   -- #3124 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL TEST CASSETTE ISIA';   -- #3125 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PRL UNCUT SHEET';   -- #3126 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROGESTERONE TEST CASSETTE ISIA';   -- #3127 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PROGESTRONE UNCUT SHEET';   -- #3128 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PSA Total without Box 96 Test';   -- #3129 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PSA Uncut Sheet';   -- #3130 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Plate Sealing Foil Elisa';   -- #3131 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Positive Control Elisa';   -- #3132 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Posphorus Reagent';   -- #3133 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Pottasium Reagent ltr';   -- #3134 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Probe Cleaner';   -- #3135 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Progesterone Elisa Without Box';   -- #3136 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prolactin Elisa Without Box 96 Test';   -- #3137 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Prolactin Uncut sheet';   -- #3138 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Protein Uncut Sheet Sheet';   -- #3139 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF LATEX Positive Control';   -- #3140 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Latex Positive Control Biosino';   -- #3141 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Latex Reagent Biosino';   -- #3142 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Latex Reagent Bulk @12%';   -- #3143 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Latex Reagent Bulk @18%';   -- #3144 [Semi Finish] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Turbi Calibrator Biosino 1*3ml';   -- #3145 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Turbilatex Calibrator Nos';   -- #3146 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Turbilatex Diluent R1';   -- #3147 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Turbilatex Reagent Biosino';   -- #3148 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Turbilatex in Ltr R2 ML';   -- #3149 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RPR Control';   -- #3150 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RPR LATEX REAGENT BULK';   -- #3151 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RUBELLA IGG ELISA WITHOUT BOX';   -- #3152 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RUBELLA IGM ELISA WITHOUT BOX';   -- #3153 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rinse Reagent Bulk In Ltr ltr';   -- #3154 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rota Uncut Sheet';   -- #3155 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Rubella IgG/IgM Uncut Sheet';   -- #3156 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SCRUB TYPHUS IgM ELISA WITHOUT BOX';   -- #3157 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGOT Reagent';   -- #3158 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SGPT Reagent';   -- #3159 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'SHBG';   -- #3160 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Scrub Typhus IgG+IgM Uncut Sheet';   -- #3161 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Scrub Typhus Uncut Sheet';   -- #3162 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Buffer';   -- #3163 [Semi Finish] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sickle Cell Uncut Sheet';   -- #3164 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sodium Reagent';   -- #3165 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Specific IgE Elisa 96Test Without Box';   -- #3166 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Specimen Diluent';   -- #3167 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Standard Cholestrol';   -- #3168 [Semi Finish] HSN: 38229090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Standard Triglyceride';   -- #3169 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Standard Urea';   -- #3170 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Standard Uric Acid';   -- #3171 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Sulphuric Acid H2S04 For Elisa';   -- #3172 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphilis Dipstick Uncut Sheet';   -- #3173 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphilis Positive Serum 10ml';   -- #3174 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphilis S/P Uncut sheet';   -- #3175 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Syphilis WB Uncut Sheet';   -- #3176 [Semi Finish] HSN: 30021500 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 TOTAL ELISA WITHOUT BOX';   -- #3177 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T3 UNCUT SHEET';   -- #3178 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 TOTAL ELISA WITHOUT BOX';   -- #3179 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T4 UNCUT SHEET';   -- #3180 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TB-IGRA Without Box';   -- #3181 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TESTOSTERONE UNCUT SHEET';   -- #3182 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IGE UNCUT SHEET';   -- #3183 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOTAL IgE Test Cassette ISIA';   -- #3184 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOXO IGG ELISA WITHOUT BOX';   -- #3185 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOXO IGM ELISA WITHOUT BOX';   -- #3186 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TOXOPLASMA IgG/IgM Uncut Sheet SHEET';   -- #3187 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TROPONIN I UNCUT SHEET PCS';   -- #3188 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH ELISA WITHOUT BOX';   -- #3189 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH TEST CASSETTE ISIA';   -- #3190 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TSH Uncut sheet';   -- #3191 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TT3 TEST CASSETTE ISIA';   -- #3192 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TT4 TEST CASSETTE ISIA';   -- #3193 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TTG IgA Elisa without Box';   -- #3194 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'TYPHOID IGG/IGM UNCUT  Sheet PCS';   -- #3195 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Testosterone Elisa Without Box';   -- #3196 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Bile Acid';   -- #3197 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Bile Acid Calibrators';   -- #3198 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total IgE without Box 96 Test';   -- #3199 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Total Protein Reagent';   -- #3200 [Semi Finish] HSN: 90278090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Trichomonas Vaginails Uncut Sheet';   -- #3201 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Triglyceride Reagent';   -- #3202 [Semi Finish] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Typhiod Buffer';   -- #3203 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINE UNCUT 11P FOR ANALYZER NOS';   -- #3204 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urea Berthelot Reagent';   -- #3205 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urea UV Reagent LTR';   -- #3206 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Uric Acid Reagent';   -- #3207 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strip 10P uncut sheet';   -- #3208 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strip 11P uncut sheet sheet';   -- #3209 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strip 3P uncut P+G+PH';   -- #3210 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VB12 UNCUT SHEET';   -- #3211 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VC(VITAMIN C) ELISA WITHOUT BOX';   -- #3212 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VDRL CARBON ANTIGEN in Ltr ML';   -- #3213 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN B12 ELISA WITHOUT BOX';   -- #3214 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VITAMIN D ELISA WITHOUT BOX';   -- #3215 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VK1(VITAMIN K1) ELISA WITHOUT BOX';   -- #3216 [Semi Finish] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VTM LTR';   -- #3217 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VZV IgG Elisa Without Box';   -- #3218 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'VZV IgM Elisa Without Box';   -- #3219 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL POSITIVE CONTROL LTR';   -- #3220 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL TYPHI"(H)"REAGENT IN LTR ML';   -- #3221 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL TYPHI"(O)"REAGENT IN LTR ML';   -- #3222 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL TYPHI"A(H)"REAGENT IN LT ML';   -- #3223 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL TYPHI"B(H)"REAGENT IN LT ML';   -- #3224 [Semi Finish] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Wash Buffer For Elisa';   -- #3225 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Widal Antigen "AO" Reagent ML';   -- #3226 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Widal Antigen "BO" Reagent ML';   -- #3227 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Widal Antigen "CH" Reagent ML';   -- #3228 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Widal Antigen "CO" Reagent ML';   -- #3229 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'chlamydia IgM Uncut Sheet';   -- #3230 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'dsDNA Elisa Kit without Box 96 Test';   -- #3231 [Semi Finish] HSN: 38220019 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'dsDNA Quatitative DIAMETRA WITHOUT BOX';   -- #3232 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'hsCRP/CRP UNCUT SHEET';   -- #3233 [Semi Finish] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = '25-HYDROXY VIT D TURBI 100 ML';   -- #3234 [Serology And Turbi] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI \'A\' 8X10ML';   -- #3235 [Serology And Turbi] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI \'B\' 8X10ML';   -- #3236 [Serology And Turbi] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ANTI \'D\' 8X10ML';   -- #3237 [Serology And Turbi] HSN: 30025900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO LATEX 100 TEST 100 TEST';   -- #3238 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO LATEX 25 TEST 25 TEST';   -- #3239 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO LATEX 50 TEST 50 TEST';   -- #3240 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'ASO TURBI LATEX 50 ML 50ML';   -- #3241 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Anti D IgG+IgM 10ml';   -- #3242 [Serology And Turbi] HSN: 30062000 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP LATEX 100 TEST 100 test';   -- #3243 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP LATEX 25 TEST 25 TEST';   -- #3244 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP LATEX 50 TEST 50 TEST';   -- #3245 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbi,Biogenix 100 ML 100Ml';   -- #3246 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbi,Biogenix 250 ML 250ML';   -- #3247 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbi,Biogenix 300 ML';   -- #3248 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbi,Biogenix 50 ML 50 ml';   -- #3249 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'CRP Turbi,Biogenix 500 ML';   -- #3250 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'D.Dimer Kit, Biogenix 30+10 ML';   -- #3251 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Ferritin Turbi 40 ml 40 ml';   -- #3252 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Fibro Tek FIB Kit';   -- #3253 [Serology And Turbi] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HBA1C TURBI 80 ML 80 ML';   -- #3254 [Serology And Turbi] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HS-CRP TURBI 200 ML';   -- #3255 [Serology And Turbi] HSN: 38221990 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'HbA1c Turbilatex 40 ml';   -- #3256 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Albumin Calibrator C1 ML';   -- #3257 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Albumin R1&R2 ML';   -- #3258 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Micro Albumin Turbi Latex 50ML';   -- #3259 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'NGAL 80ml';   -- #3260 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Phospholin ES 5*5ml 5ml';   -- #3261 [Serology And Turbi] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'PhosphoplastinsRL10*10ml Kit';   -- #3262 [Serology And Turbi] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Plasma Control L 10X1 ml';   -- #3263 [Serology And Turbi] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Plasma Control N 10X1 ml';   -- #3264 [Serology And Turbi] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF LATEX BIOGENIX 100 TEST 100 TEST';   -- #3265 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF LATEX BIOGENIX 25 TEST 25 TEST';   -- #3266 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF LATEX BIOGENIX 50 TEST 50 Test';   -- #3267 [Serology And Turbi] HSN: 30021900 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF TURBI LATEX 50 ML 50 ML';   -- #3268 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RF Turbi Latex In Ltrs Pack Ltr';   -- #3269 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RPR LATEX BIOGENIX 100 TEST 100 test';   -- #3270 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RPR LATEX BIOGENIX 50 TEST 50 Test';   -- #3271 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'RT PCR Kit Covid-19 TEST 100 TEST';   -- #3272 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'T-Tek 10*1ml 10X1ml';   -- #3273 [Serology And Turbi] HSN: 38220099 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL BEACON 4*5 ML 4*5 ML';   -- #3274 [Serology And Turbi] HSN: 38220012 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'WIDAL BIOGENIX 4X5 ML 4x5 ml';   -- #3275 [Serology And Turbi] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINE STRIP 5P ,BIOGENIX 100 TEST';   -- #3276 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINE STRIPS 11P Biogenix 100 Strip';   -- #3277 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'URINE STRIPS 11P FOR ANALYZER 100 STRIPS';   -- #3278 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strip 1P Ketone 100 strips';   -- #3279 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strip 2P Glucose+ketone 100 strips';   -- #3280 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strip 3P(G+P+K) 100 Strips';   -- #3281 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 10P 100 strips';   -- #3282 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 2P (Uricheck) 100 strips';   -- #3283 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 3P(Leu+Nit+PH) 100 strips';   -- #3284 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 4P(PH+Ketone) She';   -- #3285 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 4P(PH+SG) 100 Strips';   -- #3286 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 8P 100 Strips';   -- #3287 [Urine Parameter\'s] HSN: 38220090 | IGST: 5%
UPDATE `products` SET `gst_rate` = 5.00 WHERE `product_name` = 'Urine Strips 8P @5% Nos';   -- #3288 [Urine Parameter\'s] HSN: 38220099 | IGST: 5%

-- =============================================================
-- SUMMARY:
-- Total UPDATE statements: 3288
-- Items with 5.00% GST: 2753
-- Items with 18.00% GST: 535
-- 100% environment-independent (matched by unique product_name).
-- =============================================================
