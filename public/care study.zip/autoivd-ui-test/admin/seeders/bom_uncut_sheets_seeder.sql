-- =============================================================
-- Seeder: bom_uncut_sheets_seeder.sql
-- Workbook: BOMs - Uncut Sheets (Semi Finished Goods for Rapid Tests).xlsx
-- BOMs: 36
--
-- GENERATED FILE - do not edit by hand.
-- Regenerate with: php admin/tools/bom/generate_seeders.php
-- Every product_code below is resolved from the inventory master;
-- unmatched codes are skipped rather than guessed.
-- =============================================================

SET SESSION max_statement_time = 0;

-- -------------------------------------------------------------
-- BOM 1/36: Chikungunya IgM (Uncut Sheet) Rapid
-- Sheet "Chikungunya IgM" | Product BGX/SF.US.RAPID/2026/000017 | Components 28
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000017';
SET @f_name = 'Chikungunya IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.078, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chikunguniya IGM (Conjugation) (CHIKN103)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000050' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 2/36: Chikungunya IgG/IgM (Uncut Sheet) Rapid
-- Sheet "Chikungunya IgGIgM" | Product BGX/SF.US.RAPID/2026/000018 | Components 31
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000018';
SET @f_name = 'Chikungunya IgG/IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Chikunguniya IGM (Conjugation) (CHIKN103)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000050' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 20 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000060' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 3/36: Dengue IgG/IgM (Uncut Sheet) Rapid
-- Sheet "Dengue IgG IgM " | Product BGX/SF.US.RAPID/2026/000031 | Components 27
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000031';
SET @f_name = 'Dengue IgG/IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Dengue Rec.ag Type-ii (Conjugation) 0036
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue Rec.ag Type-i (Conjugation) 0031
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000123' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 705
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000546' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 4/36: Dengue NS1 (Uncut Sheet) Rapid
-- Sheet "Dengue NS1" | Product BGX/SF.US.RAPID/2026/000033 | Components 27
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000033';
SET @f_name = 'Dengue NS1 (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue Antibody A47-AB15
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000112' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue Antibody A47-AB16
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000113' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.035, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIER-R001
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000213' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 5/36: Filaria (Uncut Sheet) Rapid
-- Sheet "Filaria uncut" | Product BGX/SF.US.RAPID/2026/000035 | Components 26
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000035';
SET @f_name = 'Filaria (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Filariasis Conjugated Antigen (BMGFIL102)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 705
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000546' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 6/36: FOB (Uncut Sheet) Rapid
-- Sheet "FOB UNCUT" | Product BGX/SF.US.RAPID/2026/000037 | Components 32
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000037';
SET @f_name = 'FOB (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (21MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000150' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.078, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti Fob Ab (Coating) (BRCFOBS102)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti Fob Ab (Conjugation) (BRJFOBS102)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 7/36: Glucose and Protein (Uncut Sheet) Urinalysis
-- Sheet "Glu & Prot Urine Uncut" | Product BGX/SF.US.URIN/2026/000002 | Components 3
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.URIN/2026/000002';
SET @f_name = 'Glucose and Protein (Uncut Sheet) Urinalysis';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Glucose (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Protein (Uncut Sheet Urinalysis)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminate (70 x 270)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000137' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 8/36: Glucose (Uncut Sheet) Urinalysis
-- Sheet "Glucose Urine Uncut" | Product BGX/SF.US.URIN/2026/000003 | Components 14
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.URIN/2026/000003';
SET @f_name = 'Glucose (Uncut Sheet) Urinalysis';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Double Sided Tape (300MMX100M) Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000140' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Whatman Filter Paper 270 x 200MM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- God
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.125, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000171' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.0125, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trypan Blue
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.125, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000551' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Iodide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0043, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000401' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gelatin Powder
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0145, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000158' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Citric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000087' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0023, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Polyvinylpyrolidone (PVK90)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0033, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000391' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ethyl Celulose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000150' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ethanol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.08, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.IHC/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toluene
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.32, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000528' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trisodium Citrate Dihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.021, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000541' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 9/36: H. pylori Antibody (Uncut Sheet) Rapid
-- Sheet "H.Pylori Ab" | Product BGX/SF.US.RAPID/2026/000043 | Components 32
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000043';
SET @f_name = 'H. pylori Antibody (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- H.pylori Rec.antigen (Coating) GRNHPS104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000177' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- H.pylori Rec.antigen (Conjugation) GRNHPS104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000178' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (21MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000150' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.078, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 10/36: H. pylori Antigen (Uncut Sheet) Rapid
-- Sheet "H.Pylori Ag" | Product BGX/SF.US.RAPID/2026/000044 | Components 33
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000044';
SET @f_name = 'H. pylori Antigen (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- H.pylori Antibody (Coating) BRNHPS101
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000175' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- H.pylori Antibody (Conjugation) BRNHPS102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000176' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (21MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000150' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.078, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000538' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIER-R001
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000213' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 11/36: HAV IgM (Uncut Sheet) Rapid
-- Sheet "HAV IgM" | Product BGX/SF.US.RAPID/2026/000045 | Components 28
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000045';
SET @f_name = 'HAV IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20mm x 15MICRON A x I
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000122' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.078, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hav Recombinant Ag BMGHAV100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000182' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 12/36: HBsAg (Uncut Sheet) Rapid
-- Sheet "HBsAg" | Product BGX/SF.US.RAPID/2026/000049 | Components 25
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000049';
SET @f_name = 'HBsAg (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HBSAG Monoclonal Antibody (Coating) A27-AB2
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000186' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HBSAG Monoclonal Antibody (Conjugation) A27-AB1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000187' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.024, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIER-R001
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000213' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 13/36: HBsAg Whole Blood (Uncut Sheet) Rapid
-- Sheet "HBsAg WB" | Product BGX/SF.US.RAPID/2026/000050 | Components 27
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000050';
SET @f_name = 'HBsAg Whole Blood (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HBSAG Monoclonal Antibody (Coating) A27-AB2
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000186' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HBSAG Monoclonal Antibody (Conjugation) A27-AB1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000187' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0004, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.024, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIER-R001
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000213' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 14/36: hCG Dipstick (Uncut Sheet) Rapid
-- Sheet "HCG Dip" | Product BGX/SF.US.RAPID/2026/000051 | Components 32
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000051';
SET @f_name = 'hCG Dipstick (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Alpha HCG (Coating)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Beta HCG (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000043' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 25MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Arrow Masking Tape 22mm x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000037' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Arrow Masking Tape (Blue) 30mm x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000036' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (70X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000140' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (26MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 10 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000123' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (23MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000151' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Orthophosphoric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000372' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 15/36: hCG Mini (Uncut Sheet) Rapid
-- Sheet "HCG Mini" | Product BGX/SF.US.RAPID/2026/000052 | Components 28
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000052';
SET @f_name = 'hCG Mini (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Alpha HCG (Coating)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Beta HCG (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000043' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (16MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20mm x 15MICRON A x I
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000122' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (23MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000151' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Orthophosphoric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000372' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 16/36: hCG Regular (Uncut Sheet) Rapid
-- Sheet "HCG Regular" | Product BGX/SF.US.RAPID/2026/000053 | Components 30
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000053';
SET @f_name = 'hCG Regular (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Alpha HCG (Coating)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Beta HCG (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000043' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 10 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000123' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (21MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000150' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Orthophosphoric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000372' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 17/36: HCV Serum/Plasma (Uncut Sheet) Rapid
-- Sheet "HCV SP" | Product BGX/SF.US.RAPID/2026/000055 | Components 25
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000055';
SET @f_name = 'HCV Serum/Plasma (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Recombinant Antigen GRCHCVS303
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000444' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recombinant Antigen GRJHCVS205
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000445' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Coupling Protein GRJCPS202
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.009, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000097' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.024, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 18/36: HCV Whole Blood (Uncut Sheet) Rapid
-- Sheet "HCV WB" | Product BGX/SF.US.RAPID/2026/000056 | Components 27
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000056';
SET @f_name = 'HCV Whole Blood (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Recombinant Antigen GRCHCVS303
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000444' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recombinant Antigen GRJHCVS205
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000445' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Coupling Protein GRJCPS202
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.009, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000097' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.024, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 19/36: HEV IgM Antibody (Uncut Sheet) Rapid
-- Sheet "HEV  M" | Product BGX/SF.US.RAPID/2026/000057 | Components 30
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000057';
SET @f_name = 'HEV IgM Antibody (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HEV Antigen BMGHEV101
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000210' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HEV Antigen BMGHEV100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.026, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000209' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 20 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 705
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000546' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 20/36: HIV 1/2 (Uncut Sheet) Rapid
-- Sheet "HIV" | Product BGX/SF.US.RAPID/2026/000059 | Components 32
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000059';
SET @f_name = 'HIV 1/2 (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV-2 (GP36) Coating GRCHIVS203
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000227' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIV-1 (GP41 + 120) Coating GRCHIVS105
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000226' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 10 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000125' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood Seprator (18mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.15, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.077, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000538' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Deoxycholate Raw
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000492' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tergitol (Tm), Type NP-40, 70% 500 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000519' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000394' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIV 1 + 2 (GP41 + 120 + GP36) Conjugation 302
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000217' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 21/36: HIV Fourth Generation (Uncut Sheet) Rapid
-- Sheet "HIV 4Th Gen" | Product BGX/SF.US.RAPID/2026/000060 | Components 41
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000060';
SET @f_name = 'HIV Fourth Generation (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV-2 (GP36) Coating GRCHIVS203
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000227' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIV-1 (GP41 + 120) Coating GRCHIVS105
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000226' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 14MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000087' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 25MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 10 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000125' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 7 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000059' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.15, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.077, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000538' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Deo x Ycholate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000134' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trizitol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000547' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000394' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HIV 1 + 2 (GP41 + 120 + GP36) Conjugation 302
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000217' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti HIV-P24 (Coating) BRCHIVS407
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti HIV-P24 (Conjugation) BRJHIVS403
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000025' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hiv-o 3rd Coating GRCHIVOS101
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000228' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hiv-o 3rd Conjugate GRJHIVOS101
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000229' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hier M-004
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000211' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 22/36: Leptospira IgG/IgM (Uncut Sheet) Rapid
-- Sheet "Leptospira IgG IgM" | Product BGX/SF.US.RAPID/2026/000070 | Components 27
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000070';
SET @f_name = 'Leptospira IgG/IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Leptospira Antigen BMGLEP12
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000255' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Leptospira Antigen BMGLEP22
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000256' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 705
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000546' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 23/36: LH (Uncut Sheet) Rapid
-- Sheet "LH" | Product BGX/SF.US.RAPID/2026/000071 | Components 31
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000071';
SET @f_name = 'LH (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Monoclonal Ab (BRCLHS101) mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000312' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab (BRJLHS103) mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000313' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 15MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000088' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 25MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (16MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 10 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000123' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (23MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000151' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Orthophosphoric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000372' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0016, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 24/36: Malaria Pan Antigen (Uncut Sheet) Rapid
-- Sheet "Malaria Pan" | Product BGX/SF.US.RAPID/2026/000075 | Components 32
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000075';
SET @f_name = 'Malaria Pan Antigen (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pan Pldh Conjugation BRCMALS207
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000374' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRCMALS213 Malaria Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000317' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 14MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000087' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 25MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (19MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 10X300MM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (12MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000145' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.019, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.14, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.035, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.12, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hier M-004
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000211' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SDS
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000473' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 25/36: Malaria Pf/Pan Antigen (Uncut Sheet) Rapid
-- Sheet "Malaria Pf Pan" | Product BGX/SF.US.RAPID/2026/000076 | Components 31
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000076';
SET @f_name = 'Malaria Pf/Pan Antigen (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Monoclonal Ab BRCMALS207 Malaria
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000315' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRCMALS213 Malaria Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000317' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRJMALS106 Conjugation
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000318' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRCMALS105 Malaria Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000314' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (19MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 10X300MM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (12MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000145' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.019, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.14, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.035, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.12, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hier M-004
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000211' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Lauryl Sulphate (SDS)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000497' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 26/36: Malaria Pf/Pv Antigen (Uncut Sheet) Rapid
-- Sheet "Malaria Pf Pv" | Product BGX/SF.US.RAPID/2026/000077 | Components 30
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000077';
SET @f_name = 'Malaria Pf/Pv Antigen (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Monoclonal Ab BRCMALS211 Malaria Conjugation
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.0075, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000316' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRCMALS213 Malaria Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000317' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRJMALS106 Conjugation
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.0075, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000318' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Monoclonal Ab BRCMALS105 Malaria Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000314' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Rabbit IGG AGRIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.0038, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000418' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Rabbit IGG ABGAR-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000169' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (19MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 10X300MM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (12MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000145' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.019, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.035, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.12, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hier M-004
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000211' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Lauryl Sulphate (SDS)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000497' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 27/36: Protein (Uncut Sheet Urinalysis)
-- Sheet "Protein Urine" | Product BGX/SF.US.URIN/2026/000021 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.URIN/2026/000021';
SET @f_name = 'Protein (Uncut Sheet Urinalysis)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Double Sided Tape (300MMX100M) Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000140' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Whatman Filter Paper 270 x 200MM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tetrabromophenol Blue
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.133, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000522' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Citric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000087' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trisodium Citrate Dihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0144, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000541' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Methanol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0221, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000301' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ethanol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.057, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.IHC/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Polyvinyl Alcohol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000390' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 28/36: Scrub Typhus IgG/IgM (Uncut Sheet) Rapid
-- Sheet "Scrub Typhus IgG IgM" | Product BGX/SF.US.RAPID/2026/000091 | Components 30
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000091';
SET @f_name = 'Scrub Typhus IgG/IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Tsutsugamushi Antigen BMGTSU12 (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000552' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tsutsugamushi Antigen BMGTSU22 (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000553' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tsutsugamushi Antigen BMGTSU32 (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000554' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Tetraborate Decahydrate (Bora x Deca.)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) (AP-250)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 405 @18% Powder Form
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000545' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 29/36: Sickle Cell (Uncut Sheet) Rapid
-- Sheet "Sickle Cell" | Product BGX/SF.US.RAPID/2026/000093 | Components 30
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000093';
SET @f_name = 'Sickle Cell (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pvc Backing Laminates (60X300MM) (15-25-20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recombinant Anti-hbs Antibody
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000435' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recombinant Anti-hba Antibody
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.022, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000433' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000394' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-hemoglobin Mouse
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.026, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.78, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000538' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.032, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Deoxycholate Raw
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000492' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.92, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 30/36: Syphilis Dipstick (Uncut Sheet) Urinalysis
-- Sheet "Syphilis Dipstick" | Product BGX/SF.US.URIN/2026/000015 | Components 31
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.URIN/2026/000015';
SET @f_name = 'Syphilis Dipstick (Uncut Sheet) Urinalysis';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Tp Rec.antigen Coating AI00606
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000530' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tp Rec.antigen Conjugation AI00605
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000531' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mouse IGG AGMIG-0100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000356' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 25MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (70X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000140' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (26MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Arrow Masking Tape 22mm x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000037' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Arrow Masking Tape (Blue) 30mm x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000036' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (21MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000150' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 31/36: Syphilis Serum/Plasma (Uncut Sheet) Rapid
-- Sheet "Syphilis SP" | Product BGX/SF.US.RAPID/2026/000095 | Components 26
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000095';
SET @f_name = 'Syphilis Serum/Plasma (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recomb.antigen GRCTPS202
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000425' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recomb.antigen GRCTPS203
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000426' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Coupling Protein GRJCPS201
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000096' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 32/36: Syphilis Whole Blood (Uncut Sheet) Rapid
-- Sheet "Syphilis WB" | Product BGX/SF.US.RAPID/2026/000096 | Components 28
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000096';
SET @f_name = 'Syphilis Whole Blood (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recomb.antigen GRCTPS202
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000425' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Recomb.antigen GRCTPS203
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000426' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Coupling Protein GRJCPS201
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000096' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Mouse IGG ABGAM-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000168' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Backing Laminates (60X300MM) (17-20-23)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000136' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM) (AP-250)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose Ar
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000513' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 33/36: Toxoplasma IgG/IgM (Uncut Sheet) Rapid
-- Sheet "Toxo IgG IgM" | Product BGX/SF.US.RAPID/2026/000104 | Components 30
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000104';
SET @f_name = 'Toxoplasma IgG/IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 14MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000087' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 25MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 20 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 705
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000546' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toxoplasma Antigen (XI101) (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000526' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toxoplasma Antigen (XN101) (Conjugation)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000527' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 34/36: Troponin I (Uncut Sheet) Rapid
-- Sheet "Trop I" | Product BGX/SF.US.RAPID/2026/000106 | Components 33
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000106';
SET @f_name = 'Troponin I (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 20MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000124' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hier M-004
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000211' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chicken Igy AGCIG-0100 mg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000079' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Chicken Igy ABGAC-0500
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000167' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-ctnl Mab (NIN102) Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000029' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-ctnl Mab (NIN105) Coating
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000030' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-ctnl Mab (NIN113) Conjugate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 35/36: Typhoid IgG/IgM (Uncut Sheet) Rapid
-- Sheet "Typhoid IgG IgM" | Product BGX/SF.US.RAPID/2026/000109 | Components 32
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.RAPID/2026/000109';
SET @f_name = 'Typhoid IgG/IgM (Uncut Sheet) Rapid';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Typhi H Ag (AI01501)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000556' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Typhi O Bsa (AI01502)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000557' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Goat Anti Typhi (PI01501)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000170' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGG (Coating) BRCIGGI102
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.024, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-human IGM (Coating) BRCIGMC104
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 17MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 20MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Side Tape 23MM X 100MT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminates (60X300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000139' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Absorbent Pad (18MM X 300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitrocellulose Membrane 25MM 15 Micron
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'm' LIMIT 1), 0.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000126' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Conjugate Release Pad 5 x 300mm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sample Pad (20MMX300MM)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000149' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Blood/Plasma Seprator (7mm x 300mm)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0014, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0012, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sucrose@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000514' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tri SODIUM Citrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000533' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.002, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000393' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gold Chloride Trihydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000172' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000191' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Casein SODIUM Salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Trehalose
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000532' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tween-20 (Polysorbate20)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.0001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000555' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 36/36: Urine Strip 10P (Uncut Sheet) Urinalysis
-- Sheet "Urine 10P" | Product BGX/SF.US.URIN/2026/000016 | Components 11
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.US.URIN/2026/000016';
SET @f_name = 'Urine Strip 10P (Uncut Sheet) Urinalysis';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 2, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 2, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Multistix Nitrite Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix Leukocyte Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix Urobilinogen Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix pH Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix Blood Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000007' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix Specific Gravity Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix Bilirubin Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Multistix Ketone Membrane (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Glucose and Protein (Uncut Sheet) Urinalysis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.URIN/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Double Sided Tape (300MMX100M) Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000140' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pvc Laminate 260MM x 120MM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000138' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

