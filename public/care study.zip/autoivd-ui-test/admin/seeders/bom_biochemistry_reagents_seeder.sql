-- =============================================================
-- Seeder: bom_biochemistry_reagents_seeder.sql
-- Workbook: BOMs - Biochemistry (Reagent Manufacturing) (Semi Finished).xlsx
-- BOMs: 26
--
-- GENERATED FILE - do not edit by hand.
-- Regenerate with: php admin/tools/bom/generate_seeders.php
-- Every product_code below is resolved from the inventory master;
-- unmatched codes are skipped rather than guessed.
-- =============================================================

SET SESSION max_statement_time = 0;

-- -------------------------------------------------------------
-- BOM 1/26: Adenosine Deaminase (Bulk Reagent)
-- Sheet "Ada" | Product BGX/SF.BR.BIOC/2026/000002 | Components 13
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000002';
SET @f_name = 'Adenosine Deaminase (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 5.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.45, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.91, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- L-glutamic Acid Monosodium
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000244' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- D-alanine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000105' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Xod
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 7, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000175' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pnpp Di Tris Chemical
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 3.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000384' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 7, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.21, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1.33, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.665, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000538' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0056, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000529' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 2/26: Albumin (Bulk Reagent)
-- Sheet "Albumin" | Product BGX/SF.BR.BIOC/2026/000003 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000003';
SET @f_name = 'Albumin (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Succinic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 14.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000512' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35 (30%aq.sol)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 4.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000061' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bromocresol Green
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.142, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000062' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride @12%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.09, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000488' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 3/26: Alkaline Phosphatase (Bulk Reagent)
-- Sheet "Alkaline" | Product BGX/SF.BR.BIOC/2026/000004 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000004';
SET @f_name = 'Alkaline Phosphatase (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Magnesium Acetate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000276' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.36, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Zinc Sulphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000176' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 2-amino 2 Methyl Propanol (Amp Buffer)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Egta
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000142' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Charcoal
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 12.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Diethylene Triamine Penta Acetic Acid (Dtpa)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000128' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pnpp Di Tris Chemical
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.724, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000384' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 4/26: Ammonia (Bulk Reagent)
-- Sheet "Ammonia" | Product BGX/SF.BR.BIOC/2026/000005 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000005';
SET @f_name = 'Ammonia (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 11.29, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ketoglutaric Acid Na.salt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 4.884, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000240' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.297, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.52, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Hydroxide Flakes 500 g
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 10.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000400' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sulphuric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 6.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000516' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gldh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.76, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000160' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- LDH
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000249' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nadh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.21, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000362' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ammonium Sulphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.009, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 5/26: Amylase (Bulk Reagent)
-- Sheet "Amylase" | Product BGX/SF.BR.BIOC/2026/000006 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000006';
SET @f_name = 'Amylase (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Mes
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 9.76, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000300' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 17.53, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Calcium Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000070' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassuim Thiocyanate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 43.73, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000405' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- CNPG2 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000090' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 6/26: Direct Bilirubin (Bulk Reagent)
-- Sheet "Bilirubin Direct" | Product BGX/SF.BR.BIOC/2026/000008 | Components 4
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000008';
SET @f_name = 'Direct Bilirubin (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Sulphanilic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000515' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Nitrite
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000499' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 7/26: Total Bilirubin (Bulk Reagent)
-- Sheet "Bilirubin Total" | Product BGX/SF.BR.BIOC/2026/000009 | Components 5
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000009';
SET @f_name = 'Total Bilirubin (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cetrimide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 11, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000077' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sulphanilic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 5.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000515' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Nitrite
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000499' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 8/26: Calcium (Bulk Reagent)
-- Sheet "Calcium" | Product BGX/SF.BR.BIOC/2026/000010 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000010';
SET @f_name = 'Calcium (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5.583, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Arsenazo Iii
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.13, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000038' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 8-hydroxyquinoline
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Imidazole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 6.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000237' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- BRIJ-35
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000060' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Calcium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000069' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 9/26: Chloride, Biogenix (Bulk Reagent)
-- Sheet "Chloride" | Product BGX/SF.BR.BIOC/2026/000011 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000011';
SET @f_name = 'Chloride, Biogenix (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Mercuric Thiocynate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.32, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000298' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Methanol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000301' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nitric Acid 69% Ar/Acs 01X2.5 L
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000364' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ferric Nitrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 15, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000152' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mercuric Nitrate Monohydrate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.034, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000297' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.083, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 10/26: Cholesterol (Bulk Reagent)
-- Sheet "Cholesterol" | Product BGX/SF.BR.BIOC/2026/000012 | Components 14
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000012';
SET @f_name = 'Cholesterol (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pipes Free Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000382' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Magnesium Acetate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000276' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Cholate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000489' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-chloro-m-cresol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000005' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- P-hydro x Y Benzoic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1.32, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000373' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.51, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.07, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Oxidase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000084' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Esterase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000082' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 3.875, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ethanol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/FIN.IHC/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Powder
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000086' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 11/26: Creatinine (Bulk Reagent)
-- Sheet "Creatinine" | Product BGX/SF.BR.BIOC/2026/000015 | Components 4
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000015';
SET @f_name = 'Creatinine (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2187, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Picric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 3159, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000380' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Hydrochloric Acid (Hcl)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 68.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000235' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Creatinine Powder
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1944, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000099' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 12/26: Glucose (Bulk Reagent)
-- Sheet "Glucose" | Product BGX/SF.BR.BIOC/2026/000022 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000022';
SET @f_name = 'Glucose (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 13.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 6.06, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ammonium Sulphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Phenol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.47, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000376' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.063, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Hydro x Ide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000399' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- God
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000171' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Benzoic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- De x Trose (D Glucose)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000110' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 13/26: HDL-C Direct R1 + R2 (Bulk Reagent)
-- Sheet "HDL" | Product BGX/SF.BR.BIOC/2026/000025 | Components 11
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000025';
SET @f_name = 'HDL-C Direct R1 + R2 (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pipes Di SODIUM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 11.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000381' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.3105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000529' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.375, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0925, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.015, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.029, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Emergen A60
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 7.082, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000143' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Oxidase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.165, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000084' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Esterase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.332, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000082' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1.25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 14/26: LDL-C Direct (Bulk Reagent)
-- Sheet "LDL" | Product BGX/SF.BR.BIOC/2026/000031 | Components 11
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000031';
SET @f_name = 'LDL-C Direct (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pipes Di SODIUM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.31, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000381' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.7, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Magnesium Chloride (MGCL2.6H2O)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.472, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000278' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Emergen A60
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 36.46, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000143' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.525, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.45, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000529' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Oxidase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1.747, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000084' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.053, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 3.57, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cholesterol Esterase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.495, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000082' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 15/26: Magnesium (Bulk Reagent)
-- Sheet "Magnesium" | Product BGX/SF.BR.BIOC/2026/000034 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000034';
SET @f_name = 'Magnesium (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- BRIJ-35
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 7456, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000060' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Polyethylene Glycol (Peg 4000) Gm
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1165, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000389' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Egta
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 1000, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000142' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 7022.31, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Proclin 300
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 23.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000407' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Xylidyl Blue I
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 12.582, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000567' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Magnesium Acetate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 23.76, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000276' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 16/26: Microprotein (Bulk Reagent)
-- Sheet "Microprotein" | Product BGX/SF.BR.BIOC/2026/000035 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000035';
SET @f_name = 'Microprotein (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.9, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Succinic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 5.9, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000512' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Benzoate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000484' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pyragallol Red
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 0.03, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000417' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Methanol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000301' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM O x Alate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.14, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000501' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Lauryl Sulphate (SDS)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000497' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Molybdate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.035, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000498' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 17/26: Phosphorus (Bulk Reagent)
-- Sheet "Phosphorus" | Product BGX/SF.BR.BIOC/2026/000036 | Components 5
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000036';
SET @f_name = 'Phosphorus (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Ammonium Molybdate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.35, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sulphuric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 9.065, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000516' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 1.53, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0027, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0112, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 18/26: Potassium (Bulk Reagent)
-- Sheet "Pottasium" | Product BGX/SF.BR.BIOC/2026/000037 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000037';
SET @f_name = 'Potassium (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- SODIUM Hydroxide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 3.7, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000495' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Formaldehyde
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000157' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Stbp (SODIUM Tetra Phenyl Boron)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 13, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000511' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0081, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000394' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.164, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 19/26: SGOT (Bulk Reagent)
-- Sheet "SGOT" | Product BGX/SF.BR.BIOC/2026/000038 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000038';
SET @f_name = 'SGOT (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 9.691, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.816, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- L-aspartate De-sodium
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 26.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000242' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Alpha Ketoglutaric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- LDH
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000249' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Mdh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.176, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000295' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.18, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000486' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nadh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000362' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 20/26: SGPT (Bulk Reagent)
-- Sheet "SGPT" | Product BGX/SF.BR.BIOC/2026/000039 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000039';
SET @f_name = 'SGPT (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 9.691, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.816, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Aminopropionic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 24.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Alpha Ketoglutaric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2.008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- LDH
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 2.8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000249' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.18, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000486' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nadh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000362' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 21/26: Sodium (Bulk Reagent)
-- Sheet "Sodium" | Product BGX/SF.BR.BIOC/2026/000041 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000041';
SET @f_name = 'Sodium (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Diethylene Triamine Penta Acetic Acid (Dtpa)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000128' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triethanolamine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000534' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dmso
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 200, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000138' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Chlorophsphonazo Iii
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'mg' LIMIT 1), 30, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000080' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.004, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000394' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Chloride
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.08, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000487' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 22/26: Total Protein (Bulk Reagent)
-- Sheet "Total Protein" | Product BGX/SF.BR.BIOC/2026/000046 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000046';
SET @f_name = 'Total Protein (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cupric Sulphate Pentahydrate @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000102' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium SODIUM Tartarate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 9, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000404' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Iodide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000401' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0408, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.65, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 23/26: Triglyceride (Bulk Reagent)
-- Sheet "Triglyceride" | Product BGX/SF.BR.BIOC/2026/000047 | Components 16
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000047';
SET @f_name = 'Triglyceride (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pipes Free Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 10, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000382' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydrooxide Pellets
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000494' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Magnesium Acetate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000276' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Diethylene Triamine Penta Acetic Acid (Dtpa)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.38, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000128' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-chloro-m-cresol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000005' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- L-glutamic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000243' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.16, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000529' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Atp
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000039' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.51, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Lipoproteine Lipase (Lpl) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 5.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000259' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- L-glycerophosphate Oxidase (Gpo) @12%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000245' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Glycerokinase (Gyk) @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000163' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Glycerol
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.009, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000164' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 24/26: Urea Berthelot (Bulk Reagent)
-- Sheet "Urea Berthelot" | Product BGX/SF.BR.BIOC/2026/000048 | Components 13
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000048';
SET @f_name = 'Urea Berthelot (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Disodium Hydrogen Phosphate (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 24.27, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000135' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Dihydrogen Phosphate (KH2PO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1.9, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000397' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Salicylate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 9, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000505' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Nitropruside
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.75, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000500' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Sulphite /SODIUM Sulphite Anhydrous
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.315, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000508' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.399, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.525, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Urease
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1.25, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000559' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hydroxide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 8.3, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000495' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Hypochlorite Solution 4% W/V
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 20, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000496' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.045, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000065' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Urea Powder
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.004, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000558' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Benzoic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 25/26: Urea UV (Bulk Reagent)
-- Sheet "Urea UV" | Product BGX/SF.BR.BIOC/2026/000049 | Components 13
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000049';
SET @f_name = 'Urea UV (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 9.691, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Alpha Ketoglutaric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 1.114, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.297, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.6, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Potassium Hydro x Ide
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 10.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000399' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sulphuric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 6.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000516' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Gldh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.76, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000160' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Urease
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 8, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000559' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.18, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000486' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Nadh
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000362' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Benzoic Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Urea Powder
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000558' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 26/26: Uric Acid (Bulk Reagent)
-- Sheet "Uric Acid" | Product BGX/SF.BR.BIOC/2026/000050 | Components 15
-- -------------------------------------------------------------
SET @f_code = 'BGX/SF.BR.BIOC/2026/000050';
SET @f_name = 'Uric Acid (Bulk Reagent)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 1, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 1, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Pipes Free Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 15.08, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000382' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Tris Buffer (Base)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 12.74, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000537' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Diethylene Triamine Penta Acetic Acid (Dtpa)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.38, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000128' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toos
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.16, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000529' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 4-amino Antipyrine
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Azide (NAN3)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.11, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000483' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bsa
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Triton-x 100
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'ml' LIMIT 1), 0.5, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000542' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Uricase
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 0.15, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000562' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pod (Peroxidase)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'KU' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000385' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Phosphate Dibasic Anhydros (NA2HPO4)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.0416, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000502' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- SODIUM Dihydrogen Phosphate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000493' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- EDTA 2 Na
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.003, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000141' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Lithium Carbonate
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000261' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Uric Acid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'g' LIMIT 1), 0.006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000561' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

