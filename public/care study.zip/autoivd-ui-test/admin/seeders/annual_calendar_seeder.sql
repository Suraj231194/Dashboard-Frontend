-- =====================================================
-- Seeder: Annual Calendar Module
-- Description: Creates tables and seeds a sample 2026
--   annual calendar for execution on other environments.
--   Run AFTER the migration script has been applied.
-- =====================================================

-- =====================================================
-- STEP 1: Table Creation (idempotent — IF NOT EXISTS)
-- =====================================================

CREATE TABLE IF NOT EXISTS `hr_annual_calendars` (
    `id`                  INT AUTO_INCREMENT PRIMARY KEY,
    `company_id`          BIGINT UNSIGNED NOT NULL,
    `calendar_year`       SMALLINT UNSIGNED NOT NULL,
    `revision_no`         SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    `saturday_policy`     ENUM('all_working','all_off','2nd_4th_off','alternate_off','custom')
                          NOT NULL DEFAULT 'all_working',
    `lifecycle_status`    ENUM('draft','finalized','superseded') NOT NULL DEFAULT 'draft',
    `supersedes_id`       INT DEFAULT NULL,
    `total_days`          SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_sundays`       SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_saturday_offs` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_holidays`      SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_working_days`  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `is_finalized`        TINYINT(1) NOT NULL DEFAULT 0,
    `finalized_by`        INT DEFAULT NULL,
    `finalized_at`        DATETIME DEFAULT NULL,
    `status`              TINYINT NOT NULL DEFAULT 1,
    `created_by`          INT DEFAULT NULL,
    `created_at`          DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_by`          INT DEFAULT NULL,
    `updated_at`          DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at`          DATETIME DEFAULT NULL,
    `deleted_by`          INT DEFAULT NULL,
    UNIQUE KEY `uq_ac_company_year_revision` (`company_id`, `calendar_year`, `revision_no`),
    KEY `idx_year` (`calendar_year`),
    CONSTRAINT `fk_ac_company` FOREIGN KEY (`company_id`)
        REFERENCES `erp_companies`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_holidays` (
    `id`              INT AUTO_INCREMENT PRIMARY KEY,
    `calendar_id`     INT NOT NULL,
    `holiday_date`    DATE NOT NULL,
    `holiday_name`    VARCHAR(150) NOT NULL,
    `holiday_type`    ENUM('national','company','festival','restricted','other')
                      NOT NULL DEFAULT 'national',
    `is_enabled`      TINYINT(1) NOT NULL DEFAULT 1,
    `created_by`      INT DEFAULT NULL,
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_by`      INT DEFAULT NULL,
    `updated_at`      DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_calendar_date` (`calendar_id`, `holiday_date`),
    KEY `idx_holiday_date` (`holiday_date`),
    CONSTRAINT `fk_ach_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_audit_log` (
    `id`              INT AUTO_INCREMENT PRIMARY KEY,
    `calendar_id`     INT NOT NULL,
    `action`          VARCHAR(50) NOT NULL,
    `field_changed`   VARCHAR(100) DEFAULT NULL,
    `old_value`       TEXT DEFAULT NULL,
    `new_value`       TEXT DEFAULT NULL,
    `changed_by`      INT NOT NULL,
    `changed_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_audit_calendar` (`calendar_id`),
    CONSTRAINT `fk_acal_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =====================================================
-- STEP 2: Seed Sample Calendar for Year 2026
-- Replace @company_id with the actual company_id from
-- your erp_companies table before running.
-- =====================================================

SET @company_id = (SELECT `id` FROM `erp_companies` WHERE `status` = 1 AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

-- Insert calendar (skip if already exists for this company+year)
INSERT IGNORE INTO `hr_annual_calendars`
    (`company_id`, `calendar_year`, `saturday_policy`, `total_days`, `total_sundays`,
     `total_saturday_offs`, `total_holidays`, `total_working_days`, `is_finalized`,
     `status`, `created_by`, `created_at`)
VALUES
    (@company_id, 2026, 'all_working', 365, 52, 0, 18, 295, 0, 1, 1, NOW());

SET @cal_id = (SELECT `id` FROM `hr_annual_calendars`
               WHERE `company_id` = @company_id AND `calendar_year` = 2026 LIMIT 1);

-- Insert default Indian holidays for 2026
INSERT IGNORE INTO `hr_annual_calendar_holidays`
    (`calendar_id`, `holiday_date`, `holiday_name`, `holiday_type`, `is_enabled`, `created_by`, `created_at`)
VALUES
    (@cal_id, '2026-01-01', 'New Year''s Day',              'company',    1, 1, NOW()),
    (@cal_id, '2026-01-26', 'Republic Day',                 'national',   1, 1, NOW()),
    (@cal_id, '2026-03-04', 'Holi',                         'festival',   1, 1, NOW()),
    (@cal_id, '2026-03-21', 'Eid ul-Fitr',                  'festival',   1, 1, NOW()),
    (@cal_id, '2026-03-26', 'Ram Navami',                   'festival',   1, 1, NOW()),
    (@cal_id, '2026-03-31', 'Mahavir Jayanti',              'festival',   1, 1, NOW()),
    (@cal_id, '2026-04-03', 'Good Friday',                  'restricted', 1, 1, NOW()),
    (@cal_id, '2026-04-14', 'Dr. Ambedkar Jayanti',         'national',   1, 1, NOW()),
    (@cal_id, '2026-05-01', 'May Day / Labour Day',         'national',   1, 1, NOW()),
    (@cal_id, '2026-05-28', 'Eid ul-Adha',                  'festival',   1, 1, NOW()),
    (@cal_id, '2026-06-26', 'Muharram',                     'festival',   1, 1, NOW()),
    (@cal_id, '2026-08-15', 'Independence Day',             'national',   1, 1, NOW()),
    (@cal_id, '2026-09-04', 'Janmashtami',                  'festival',   1, 1, NOW()),
    (@cal_id, '2026-10-02', 'Mahatma Gandhi Jayanti',       'national',   1, 1, NOW()),
    (@cal_id, '2026-10-20', 'Dussehra',                     'festival',   1, 1, NOW()),
    (@cal_id, '2026-11-01', 'Rajyotsava / State Holiday',   'restricted', 1, 1, NOW()),
    (@cal_id, '2026-11-08', 'Diwali',                       'festival',   1, 1, NOW()),
    (@cal_id, '2026-11-09', 'Diwali (Day 2)',               'festival',   1, 1, NOW()),
    (@cal_id, '2026-11-14', 'Children''s Day',              'national',   1, 1, NOW()),
    (@cal_id, '2026-11-24', 'Guru Nanak Jayanti',           'festival',   1, 1, NOW()),
    (@cal_id, '2026-12-25', 'Christmas',                    'festival',   1, 1, NOW());

-- =====================================================
-- STEP 3: Recalculate working days
-- This should be done via the application after seeding,
-- or you can adjust the totals manually:
-- UPDATE hr_annual_calendars SET total_holidays = X, total_working_days = Y WHERE id = @cal_id;
-- =====================================================
