-- =============================================================
-- Seeder: bom_rapid_tests_seeder.sql
-- Workbook: BOMs - Rapid Tests.xlsx
-- BOMs: 70
--
-- GENERATED FILE - do not edit by hand.
-- Regenerate with: php admin/tools/bom/generate_seeders.php
-- Every product_code below is resolved from the inventory master;
-- unmatched codes are skipped rather than guessed.
-- =============================================================

SET SESSION max_statement_time = 0;

-- -------------------------------------------------------------
-- BOM 1/70: AMH Rapid Test POCT 25 Tests
-- Sheet "AMH RAPID TEST" | Product BGX/FIN.RAPID/2026/000001 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000001';
SET @f_name = 'AMH Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- AMH (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000002' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 2/70: Anti CCP Rapid Test POCT 25 Tests
-- Sheet "Anti CCP Rapid Test" | Product BGX/FIN.RAPID/2026/000002 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000002';
SET @f_name = 'Anti CCP Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Anti-CCP (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 3/70: ASO Rapid Test Post 25 Tests
-- Sheet "ASO RAPID" | Product BGX/FIN.RAPID/2026/000003 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000003';
SET @f_name = 'ASO Rapid Test Post 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- ASO (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000005' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 4/70: Beta HCG Rapid Test POCT 25 Tests
-- Sheet "Beta HCG Rapid" | Product BGX/FIN.RAPID/2026/000005 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000005';
SET @f_name = 'Beta HCG Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Beta-hCG (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000007' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 5/70: Chikungunya IGM Rapid Test
-- Sheet "Chikungunya IgM Rapid Test" | Product BGX/FIN.RAPID/2026/000010 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000010';
SET @f_name = 'Chikungunya IGM Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Chikungunya IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Chikanguniya
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 10 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000090' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 6/70: Chlamydia Trachomatis Rapid 10 Tests
-- Sheet "Chlamydia Trachomatis" | Product BGX/FIN.RAPID/2026/000012 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000012';
SET @f_name = 'Chlamydia Trachomatis Rapid 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Chlamydia IgA (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000020' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid @18% 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000025' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 7/70: Cholera Ag 25 Tests
-- Sheet "Cholera Ag 25 " | Product BGX/FIN.RAPID/2026/000013 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000013';
SET @f_name = 'Cholera Ag 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cholera (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Plain Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000066' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Colera Ag
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 8/70: Cortisol Rapid Test POCT 25 Tests
-- Sheet "CORTISOL RAPID " | Product BGX/FIN.RAPID/2026/000014 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000014';
SET @f_name = 'Cortisol Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cortisol (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000008' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 9/70: Dengue Duo (NS1 + IGG + IGM) Bioge 10 Tests
-- Sheet "Dengue Duo 10TEST" | Product BGX/FIN.RAPID/2026/000020 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000020';
SET @f_name = 'Dengue Duo (NS1 + IGG + IGM) Bioge 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassette Dengue IGG + IGM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Dengue NS1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Holder Dengue Duo
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000029' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Dengue Duo Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Dengue Duo 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue NS1 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 10/70: Dengue Duo (NS1 + IGG + IGM) Bioge 25 Tests
-- Sheet "Dengue Duo 25TEST" | Product BGX/FIN.RAPID/2026/000021 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000021';
SET @f_name = 'Dengue Duo (NS1 + IGG + IGM) Bioge 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassette Dengue IGG + IGM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Dengue NS1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue NS1 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Holder Dengue Duo
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000029' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Dengue Duo Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Dengue Duo 25 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000020' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 11/70: Dengue IGG + IGM Rapid Test 50 Tests
-- Sheet "Dengue IgG+IgM 50TEST" | Product BGX/FIN.RAPID/2026/000022 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000022';
SET @f_name = 'Dengue IGG + IGM Rapid Test 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Dengue IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Dengue IGG + IGM
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 12/70: Dengue IGG/IGM Rapid Test POCT 25 Tests
-- Sheet "DENGUE IGG IGM POCT 25T" | Product BGX/FIN.RAPID/2026/000023 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000023';
SET @f_name = 'Dengue IGG/IGM Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dengue IgG/IgM (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 13/70: Dengue NS1 Rapid Test 50 Tests
-- Sheet "Dengue NS1 50T" | Product BGX/FIN.RAPID/2026/000024 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000024';
SET @f_name = 'Dengue NS1 Rapid Test 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Dengue NS1 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Dengue NS1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Denguens1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000019' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Dengue NS1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 14/70: Fecal Occult Blood (Fob) Test
-- Sheet "FOB" | Product BGX/FIN.RAPID/2026/000028 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000028';
SET @f_name = 'Fecal Occult Blood (Fob) Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Fob Tubes
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000105' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- FOB (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000037' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 15/70: Ferritin Rapid Test POCT 25 Tests
-- Sheet "FERRITIN RAPID POCT 25" | Product BGX/FIN.RAPID/2026/000029 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000029';
SET @f_name = 'Ferritin Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ferritin (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 16/70: Filaria IGG + IGM Rapid Test Bio Test
-- Sheet "Filaria IgG+IgM" | Product BGX/FIN.RAPID/2026/000030 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000030';
SET @f_name = 'Filaria IGG + IGM Rapid Test Bio Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Filaria (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000035' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Filaria
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Gatta 38 x 27 x 31.5 Cms
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 17/70: FSH Rapid Test POCT 25 Tests
-- Sheet "FSH POCT" | Product BGX/FIN.RAPID/2026/000031 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000031';
SET @f_name = 'FSH Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- FSH (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 18/70: Gonorrhea Ag Rapid Test 10 Tests
-- Sheet "Gonorrhea" | Product BGX/FIN.RAPID/2026/000033 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000033';
SET @f_name = 'Gonorrhea Ag Rapid Test 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Neisseria gonorrhoeae (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid @18% 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 4, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Swab
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000157' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 19/70: H.pylori Antibody Biogenix Test
-- Sheet "H.Pylori AB" | Product BGX/FIN.RAPID/2026/000034 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000034';
SET @f_name = 'H.pylori Antibody Biogenix Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- H. pylori Antibody (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'sheets' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000043' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette H.pylori Ab
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 20/70: H.pylori Antigen Biogenix 25 Tests
-- Sheet "H.Pylori AG" | Product BGX/FIN.RAPID/2026/000035 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000035';
SET @f_name = 'H.pylori Antigen Biogenix 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- H. pylori Antigen (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000044' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette H.pylori Ag
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 21/70: Hav IGM Rapid Test Biogenix Test
-- Sheet "HAV IgM" | Product BGX/FIN.RAPID/2026/000036 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000036';
SET @f_name = 'Hav IGM Rapid Test Biogenix Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HAV IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'sheets' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000045' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 22/70: HBA1C Rapid Test POCT 25 Tests
-- Sheet "HBA1C POCT" | Product BGX/FIN.RAPID/2026/000037 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000037';
SET @f_name = 'HBA1C Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HbA1c (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 23/70: HBSAG Rapid S/P Test Biogenix 50 Tests
-- Sheet "HBsAg SP" | Product BGX/FIN.RAPID/2026/000038 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000038';
SET @f_name = 'HBSAG Rapid S/P Test Biogenix 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HBsAg (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000049' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch HBSAG Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HBsAg
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000036' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HBSAG
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 24/70: HBSAG Rapid W/B Test Biogenix 50 Tests
-- Sheet "HBsAg WB" | Product BGX/FIN.RAPID/2026/000039 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000039';
SET @f_name = 'HBSAG Rapid W/B Test Biogenix 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HBsAg Whole Blood (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000050' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch HBSAG Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HBsAg @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000037' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HBSAG
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000021' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 25/70: HBV5 Panel (Markers) Rapid Test
-- Sheet "HBV5 " | Product BGX/FIN.RAPID/2026/000040 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000040';
SET @f_name = 'HBV5 Panel (Markers) Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HBV Five-Panel (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0111, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Multi HBV5 Po
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Multi HBV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000037' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 26/70: HCG Rapid Big 50 Tests
-- Sheet "HCG Rapid Big 50Test" | Product BGX/FIN.RAPID/2026/000042 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000042';
SET @f_name = 'HCG Rapid Big 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- hCG Regular (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000053' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HCG Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HCG Regular
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000023' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HCG @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000045' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 27/70: HCG Mini Rapid Test (RT)
-- Sheet "HCG MINI RT" | Product BGX/FIN.RAPID/2026/000041 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000041';
SET @f_name = 'HCG Mini Rapid Test (RT)';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- hCG Mini (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000052' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminated Pouch HCG Mini RT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HCG Mini
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000022' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 28/70: HCG Rapid Test 50 Tests
-- Sheet "HCG Rapid Test 50 Test" | Product BGX/FIN.RAPID/2026/000043 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000043';
SET @f_name = 'HCG Rapid Test 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- hCG Mini (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0087, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000052' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HCG Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HCG Mini
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000022' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HCG
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000039' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 29/70: HCG Rapid Test S/P 50 Tests
-- Sheet "HCG Rapid Test S P 50Test" | Product BGX/FIN.RAPID/2026/000044 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000044';
SET @f_name = 'HCG Rapid Test S/P 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- hCG Mini (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000052' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HCG Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HCG Regular
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000023' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HCG @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000045' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 30/70: HCV Rapid Test 50 Tests
-- Sheet "HCV Rapid Test 50Test" | Product BGX/FIN.RAPID/2026/000045 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000045';
SET @f_name = 'HCV Rapid Test 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HCV Serum/Plasma (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HCV Pouch
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HCV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000046' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HCV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 31/70: HCV Rapid Test Whole Blood 50 Tests
-- Sheet "HCV Rapid WB" | Product BGX/FIN.RAPID/2026/000046 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000046';
SET @f_name = 'HCV Rapid Test Whole Blood 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassette Plain Bottom Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000039' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Top Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- HCV Whole Blood (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0101, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000056' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HCV Pouch
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HCV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000046' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 32/70: HEV IGM Rapid Test
-- Sheet "HEV IGM" | Product BGX/FIN.RAPID/2026/000048 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000048';
SET @f_name = 'HEV IGM Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HEV IgM Old (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'sheets' LIMIT 1), 0.444, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 40, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 10 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 40, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000090' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 40, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HEV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 40, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000025' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 33/70: HIV 1/2 Rapid Test 10 Tests
-- Sheet "HIV 1 2 RAPID" | Product BGX/FIN.RAPID/2026/000049 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000049';
SET @f_name = 'HIV 1/2 Rapid Test 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV 1/2 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000059' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HIV Pouch Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HIV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000026' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HIV 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000053' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 34/70: HIV 1/2 Rapid Test Biogenix 50 50 Tests
-- Sheet "HIV 1 2 50T" | Product BGX/FIN.RAPID/2026/000050 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000050';
SET @f_name = 'HIV 1/2 Rapid Test Biogenix 50 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV 1/2 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000059' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HIV Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HIV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000026' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HIV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000050' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 35/70: HIV 1/2 Rapid Test Osmcl 10 Tests
-- Sheet "HIV OSMCL 10T" | Product BGX/FIN.RAPID/2026/000051 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000051';
SET @f_name = 'HIV 1/2 Rapid Test Osmcl 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV 1/2 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000059' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HIV Pouch Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HIV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000026' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HIV Rapid Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000084' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 36/70: HIV 1/2 Rapid Test Osmcl 50 Tests
-- Sheet "HIV OSMCL 50T" | Product BGX/FIN.RAPID/2026/000052 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000052';
SET @f_name = 'HIV 1/2 Rapid Test Osmcl 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV 1/2 (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000059' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HIV Pouch Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Top Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HIV Rapid Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000084' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Bottom Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000039' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Jobwork Cassette HIV 1 + 2 Bottom
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000067' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Jobwork Cassette HIV 1 + 2 Top
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000068' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 37/70: HIV Rapid Test Iv Generation Test
-- Sheet "HIV IV " | Product BGX/FIN.RAPID/2026/000053 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000053';
SET @f_name = 'HIV Rapid Test Iv Generation Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HIV Fourth Generation (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000060' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate HIV Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000017' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HIV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000026' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes HIV
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000050' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 38/70: HSV-1 IGG/IGM Test
-- Sheet "HSV-1 IgG IgM" | Product BGX/FIN.RAPID/2026/000055 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000055';
SET @f_name = 'HSV-1 IGG/IGM Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HSV-1 IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0111, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000064' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HSV 1
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000030' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 39/70: HSV-2 IGG/IGM Test
-- Sheet "HSV-2 IgG IgM" | Product BGX/FIN.RAPID/2026/000056 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000056';
SET @f_name = 'HSV-2 IGG/IGM Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- HSV-2 IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0111, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000067' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HSV 2
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 40/70: Janaushadhi Ankur HCG Test Kit 10 Tests
-- Sheet "Janaushadhi" | Product BGX/FIN.RAPID/2026/000057 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000057';
SET @f_name = 'Janaushadhi Ankur HCG Test Kit 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- hCG Mini (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0087, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000052' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch HCG Janaushadhi
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette HCG Mini
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000022' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Janaushadhi HCG 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0007, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Urine Cup (Collection Tray)
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000164' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 41/70: Leishmania IGG + IGM Rapid Test
-- Sheet "Leismania IgG+IgM" | Product BGX/FIN.RAPID/2026/000059 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000059';
SET @f_name = 'Leishmania IGG + IGM Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Leishmania IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000069' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Leishmania
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Gatta 38 x 27 x 31.5 Cms
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 42/70: Leptospira IGG + IGM Biogenix Test
-- Sheet "Leptospira IgG+IgM" | Product BGX/FIN.RAPID/2026/000061 | Components 6
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000061';
SET @f_name = 'Leptospira IGG + IGM Biogenix Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Leptospira IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'sheets' LIMIT 1), 0.0107, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000070' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Leptospira
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000033' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 43/70: LH Rapid Test POCT 25 Tests
-- Sheet "LH POCT 25" | Product BGX/FIN.RAPID/2026/000062 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000062';
SET @f_name = 'LH Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- LH (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000013' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 44/70: LH Rapid Test, Biogenix Test
-- Sheet "LH BIO" | Product BGX/FIN.RAPID/2026/000063 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000063';
SET @f_name = 'LH Rapid Test, Biogenix Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- LH (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000071' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette LH
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000034' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Plain Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000066' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 45/70: Malaria Antigen Pf/Pan Test
-- Sheet "Malaria PF PAN" | Product BGX/FIN.RAPID/2026/000065 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000065';
SET @f_name = 'Malaria Antigen Pf/Pan Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Malaria Pf/Pan Antigen (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000076' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Malaria Pf/Pan
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000036' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Inverted Cup 5 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000110' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 46/70: Malaria Pf/Pv Antigen 50 Tests
-- Sheet "Malaria Pf Pv" | Product BGX/FIN.RAPID/2026/000066 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000066';
SET @f_name = 'Malaria Pf/Pv Antigen 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Malaria Pf/Pv Antigen (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000077' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Malaria Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000026' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Inverted Cup 5 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000110' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Malaraia Pf/Pvag
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000035' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Malaria
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Insert Malaria Pf/Pv/
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 47/70: Malaria Pf/Pv Antigen Osmcl 10 Tests
-- Sheet "Malaria Pf Pv OSMCL" | Product BGX/FIN.RAPID/2026/000067 | Components 14
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000067';
SET @f_name = 'Malaria Pf/Pv Antigen Osmcl 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Jobwork Cassette Malaria Top
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000070' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Jobwork Cassette Malaria Bottom
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000069' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Bottom Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000039' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Top Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 820 x 360 x 300 for Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000006' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Malaria Pf/Pv Antigen (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000077' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Malaria Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000025' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Lancet Plastic (100 Pcs) Icare
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000114' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Malaria 10 Tests Osmcl
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000086' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Inverted Cup 5 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000110' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Insert Malaria Pf/Pv/
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Malaria OSMCL Outer Box
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 48/70: Malaria Pf/Pv Antigen Up Govt 10 Tests
-- Sheet "Malaria Pf Pv UPG 10T" | Product BGX/FIN.RAPID/2026/000068 | Components 12
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000068';
SET @f_name = 'Malaria Pf/Pv Antigen Up Govt 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- 5PLY Box 820 x 360 x 285 for Up Govt.
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000005' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Malaria Pf/Pv Antigen (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000077' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Malaria Upgovt
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000027' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Lancet
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000113' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Malaraia Pf/Pvag
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000035' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Malaria 10 Tests UP Govt.
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000057' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Inverted Cup 5 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000110' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Insert Malaria Pf/Pv/
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000032' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ziplock for Lancet
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000177' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Malaria UP Govt. Outer Box
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000059' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 49/70: Microalbumin Rapid Test POCT 25 Tests
-- Sheet "MICROALBUMIN" | Product BGX/FIN.RAPID/2026/000069 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000069';
SET @f_name = 'Microalbumin Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Microalbumin (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 50/70: Neisseria Gonorrhoeae Rapid 10 Tests
-- Sheet "Neisseria Gonorrhoea" | Product BGX/FIN.RAPID/2026/000070 | Components 7
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000070';
SET @f_name = 'Neisseria Gonorrhoeae Rapid 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Neisseria gonorrhoeae (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid @18% 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000025' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 51/70: Progesterone Rapid Test POCT 25 Tests
-- Sheet "PROGESTERONE" | Product BGX/FIN.RAPID/2026/000074 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000074';
SET @f_name = 'Progesterone Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Progesterone (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 52/70: Prolactin Rapid Test POCT 25 Tests
-- Sheet "PROLACTIN RAPID" | Product BGX/FIN.RAPID/2026/000075 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000075';
SET @f_name = 'Prolactin Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- PRL (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 53/70: PSA Rapid Test
-- Sheet "PSA Rapid" | Product BGX/FIN.RAPID/2026/000076 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000076';
SET @f_name = 'PSA Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- PSA (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0111, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000087' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette PSA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000044' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid @18% 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 54/70: Rota Virus Ag Test
-- Sheet "Rota" | Product BGX/FIN.RAPID/2026/000079 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000079';
SET @f_name = 'Rota Virus Ag Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Rotavirus (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0142, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000089' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Rota
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000045' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 55/70: Rubella IGG/IGM Test
-- Sheet "Rubella IgG IgM " | Product BGX/FIN.RAPID/2026/000080 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000080';
SET @f_name = 'Rubella IGG/IGM Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Rubella IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0111, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000090' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0006, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Rubella
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000046' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 56/70: Scrub Typhus IGG + IGM Rapid 50 Tests
-- Sheet "Scrub Typhus IgG+IgM" | Product BGX/FIN.RAPID/2026/000083 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000083';
SET @f_name = 'Scrub Typhus IGG + IGM Rapid 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Scrub Typhus IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.475, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000091' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Scrub Typhus
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000047' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 50, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000014' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 57/70: Scrub Typhus IGM Rapid Test
-- Sheet "Scrub Typhus IgM" | Product BGX/FIN.RAPID/2026/000084 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000084';
SET @f_name = 'Scrub Typhus IGM Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Scrub Typhus (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 50 @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000016' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 58/70: Sickle Cell Biogenix 30 Tests
-- Sheet "Sickle 30T" | Product BGX/FIN.RAPID/2026/000086 | Components 14
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000086';
SET @f_name = 'Sickle Cell Biogenix 30 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.08, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Insert Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0333, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000035' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Swab Biogenix Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000158' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Sickle Cell (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000093' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000028' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000048' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3.34, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000070' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 10 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000090' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ziplock for Lancet
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 3.33, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000177' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cryo Vial 1.8 mL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000058' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Lancet Plastic (100 Pcs) Icare
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000114' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Bopp Packing 5 x 7
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0333, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 59/70: Sickle Cell Biogenix 50 Tests
-- Sheet "Sickle 50T" | Product BGX/FIN.RAPID/2026/000087 | Components 14
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000087';
SET @f_name = 'Sickle Cell Biogenix 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Sickle Cell (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0102, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000093' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000028' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000048' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Sickle Cell
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000070' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 10 µL
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000090' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Ziplock for Lancet
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000177' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- MCT 1.5 mL 500 Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PROD.AC/2026/000292' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Lancet
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000113' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Swab Plastic Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000159' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Parafilm 4"x125'feet Feet
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0262, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/MIC.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 60/70: Syphilis Rapid Test Serum Plasm 50 Tests
-- Sheet "Syphlis SP" | Product BGX/FIN.RAPID/2026/000088 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000088';
SET @f_name = 'Syphilis Rapid Test Serum Plasm 50 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Syphilis Serum/Plasma (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.95, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000095' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Syphilis Big
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000029' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Syphilis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 100, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000049' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Syphilis
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000071' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 2, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.05, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 61/70: Syphilis Rapid Test Whole Blood Test
-- Sheet "Syphlis WB" | Product BGX/FIN.RAPID/2026/000089 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000089';
SET @f_name = 'Syphilis Rapid Test Whole Blood Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassette Plain Bottom Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000039' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Plain Top Biogenix
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000042' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Syphilis Whole Blood (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0102, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000096' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Pouch Syphilis Big
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000029' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Syphillis Test
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000088' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 62/70: Toxo IGG/IGM Rapid Test
-- Sheet "Toxo IgG IgM " | Product BGX/FIN.RAPID/2026/000090 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000090';
SET @f_name = 'Toxo IGG/IGM Rapid Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassette Plain Single Hole
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid 40 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000012' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.025, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Toxoplasma IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0105, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000104' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 63/70: Troponin I 25 Tests Tamilnadu Test
-- Sheet "TROP I25T" | Product BGX/FIN.RAPID/2026/000091 | Components 8
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000091';
SET @f_name = 'Troponin I 25 Tests Tamilnadu Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Troponin I (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'sheets' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000106' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Troponin I Tamil Nadu Govt.
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000072' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Trop I
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000051' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 64/70: Troponin I Biogenix Test 10 Tests
-- Sheet "TROP I 10T" | Product BGX/FIN.RAPID/2026/000093 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000093';
SET @f_name = 'Troponin I Biogenix Test 10 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Troponin I (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'sheets' LIMIT 1), 0.0102, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000106' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Common Rapid @18% 10 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000015' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Common Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000010' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Gatta 38 x 27 x 31.5 Cms
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000011' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Trop I
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000051' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 65/70: Typhoid IGG + IGM Rapid Test 30 Tests
-- Sheet "Typhiod IgG+IgM30T" | Product BGX/FIN.RAPID/2026/000095 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000095';
SET @f_name = 'Typhoid IGG + IGM Rapid Test 30 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Typhoid IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0102, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000109' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Typhoid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000053' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Typhoid IGG/M Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0333, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365@18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0008, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000004' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Typhoid 30 Tests @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0333, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000073' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 66/70: Typhoid IGG + IGM Rapid Test Bio Test
-- Sheet "Typhiod IgG+IgM 50T" | Product BGX/FIN.RAPID/2026/000096 | Components 9
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000096';
SET @f_name = 'Typhoid IGG + IGM Rapid Test Bio Test';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Typhoid IgG/IgM (Uncut Sheet) Rapid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.01, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.RAPID/2026/000109' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassette Typhoid
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000053' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Printed Laminate Typhoid IGG/M Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000031' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Dropper 25 µL @18%
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000092' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Typhoid 50 Tests
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000074' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Buffer Bottle 5 mL Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.02, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000024' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Box 565 x 525 x 365
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0005, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 67/70: T3 Rapid Test POCT 25 Tests
-- Sheet "T3" | Product BGX/FIN.POCT/2026/000039 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.POCT/2026/000039';
SET @f_name = 'T3 Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- T3 (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000018' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 68/70: T4 Rapid Test POCT 25 Tests
-- Sheet "T4" | Product BGX/FIN.POCT/2026/000042 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.POCT/2026/000042';
SET @f_name = 'T4 Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- T4 (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000019' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 69/70: TSH Rapid Test POCT 25 Tests
-- Sheet "TSH" | Product BGX/FIN.RAPID/2026/000094 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.RAPID/2026/000094';
SET @f_name = 'TSH Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- TSH (Uncut Sheet) POCT/FIA
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000022' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- -------------------------------------------------------------
-- BOM 70/70: Vitamin D Rapid Test POCT 25 Tests
-- Sheet "VIT D" | Product BGX/FIN.POCT/2026/000056 | Components 10
-- -------------------------------------------------------------
SET @f_code = 'BGX/FIN.POCT/2026/000056';
SET @f_name = 'Vitamin D Rapid Test POCT 25 Tests';
SET @f_id   = (SELECT `id` FROM `products` WHERE `product_code` = @f_code AND `deleted_at` IS NULL LIMIT 1);
SET @c_id   = (SELECT `category_id` FROM `products` WHERE `id` = @f_id LIMIT 1);
SET @bom_id = (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1);

INSERT INTO `bom_master` (`name`, `category_id`, `finished_product_id`, `bom_type`, `descriptions`, `status`, `bom_status`, `source_type`, `created_by`, `created_at`)
SELECT @f_name, @c_id, @f_id, 4, CONCAT('BOM for ', @f_name), 1, 'APPROVED', 'ORIGINAL', 1, NOW()
WHERE @f_id IS NOT NULL AND @bom_id IS NULL;

SET @bom_id = COALESCE(@bom_id, (SELECT `id` FROM `bom_master` WHERE `finished_product_id` = @f_id AND `deleted_at` IS NULL ORDER BY `id` LIMIT 1));

UPDATE `bom_master`
SET `name` = @f_name, `category_id` = @c_id, `bom_type` = 4, `status` = 1, `bom_status` = 'APPROVED', `deleted_at` = NULL, `deleted_by` = NULL
WHERE `id` = @bom_id;

DELETE FROM `bom_items` WHERE `bom_id` = @bom_id AND @bom_id IS NOT NULL;

-- Cassettes 1 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000054' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Cassettes 2 POCT Rawmaterial
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CAS/2026/000055' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Packing Material Pouches POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Id Card POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/AC.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Boxes Fluoescreen Healthcare 190 x 160 x 75
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.BOX/2026/000078' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 5PLY Carton 735 x 485 x 400 Bo x
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.001, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.CART/2026/000009' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- 25-OH Vitamin.D Uncut Sheet POCT
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.0143, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/SF.US.POCT/2026/000001' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Plain Laminate Pouch Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.POU/2026/000003' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Pack Inserts and Stickers
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 0.04, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PKG.ACC/2026/000041' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;
-- Silica Gel 1/2 g Pcs
INSERT INTO `bom_items` (`bom_id`, `raw_product_category_id`, `raw_product_id`, `qty_unit_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @bom_id, p.`category_id`, p.`id`, (SELECT `id` FROM `standard_units` WHERE `short_name` = 'pcs' LIMIT 1), 1, 1, 1, NOW()
FROM `products` p WHERE p.`product_code` = 'BGX/PP.CON/2026/000155' AND p.`deleted_at` IS NULL AND @bom_id IS NOT NULL LIMIT 1;

DELETE FROM `product_bom` WHERE `finished_product_id` = @f_id AND @f_id IS NOT NULL;
INSERT INTO `product_bom` (`finished_product_id`, `raw_product_category_id`, `raw_product_id`, `qty_per_unit`, `status`, `created_by`, `created_at`)
SELECT @f_id, bi.`raw_product_category_id`, bi.`raw_product_id`, bi.`qty_per_unit`, 1, 1, NOW()
FROM `bom_items` bi WHERE bi.`bom_id` = @bom_id AND @bom_id IS NOT NULL;

