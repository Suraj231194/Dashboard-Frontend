<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

session_start();
date_default_timezone_set('Asia/Kolkata');

require_once 'db.php';
require_once 'constant.php';
require_once 'functions.php';

// Check if user is logged in
if (empty($_SESSION['user_id'])) {
    echo "NOT LOGGED IN - Please log in first, then visit this page again.\n";
    exit;
}

echo "<pre>Session user: " . ($_SESSION['user_id'] ?? 'none') . "\n";
echo "DB connected: " . ($conn->ping() ? 'YES' : 'NO') . "\n";

// Test key functions used by purchase-management.php
try {
    echo "Testing generateUniquePoOrderNum... ";
    $po = generateUniquePoOrderNum($conn);
    echo "OK: $po\n";
} catch (\Throwable $e) {
    echo "FAILED: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine() . "\n";
}

try {
    echo "Testing formatDatePO... ";
    $d = formatDatePO(date('Y-m-d'));
    echo "OK: $d\n";
} catch (\Throwable $e) {
    echo "FAILED: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine() . "\n";
}

try {
    echo "Testing roleHasPermission... ";
    $r = roleHasPermission('operations_admin_purchase_mgmt_view', $conn);
    echo "OK: " . ($r ? 'true' : 'false') . "\n";
} catch (\Throwable $e) {
    echo "FAILED: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine() . "\n";
}

echo "\n=== Now including purchase-management.php ===\n";
ob_start();
try {
    include 'pages/purchase-management.php';
    $output = ob_get_clean();
    echo "Include SUCCESS. Output length: " . strlen($output) . " bytes\n";
    if (strlen($output) < 100) {
        echo "Output: $output\n";
    } else {
        echo "First 500 chars:\n" . substr($output, 0, 500) . "\n";
    }
} catch (\Throwable $e) {
    ob_end_clean();
    echo "EXCEPTION: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace:\n" . $e->getTraceAsString() . "\n";
}
echo "</pre>";
