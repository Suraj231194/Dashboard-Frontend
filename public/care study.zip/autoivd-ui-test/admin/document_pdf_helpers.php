<?php

declare(strict_types=1);

function documentPdfRequireAnyPermission(mysqli $conn, array $permissions): void
{
    if (!isLoggedIn()) {
        http_response_code(401);
        exit('Your session has expired. Please sign in again.');
    }

    foreach ($permissions as $permission) {
        if (checkPermission((string) $permission, $conn)) {
            return;
        }
    }

    http_response_code(403);
    exit('You do not have permission to download this document.');
}

function documentPdfEncryptedPositiveId(mixed $value): int
{
    $idValue = trim((string) $value);
    if ($idValue === '') {
        http_response_code(422);
        exit('A valid document ID is required.');
    }

    // Accept legacy numeric links while retaining encrypted IDs for new links.
    $decryptedId = preg_match('/^[1-9][0-9]*$/', $idValue) === 1
        ? $idValue
        : trim((string) base64_decrypt($idValue));
    if (preg_match('/^[1-9][0-9]*$/', $decryptedId) !== 1) {
        http_response_code(422);
        exit('A valid document ID is required.');
    }

    $id = filter_var($decryptedId, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false) {
        http_response_code(422);
        exit('A valid document ID is required.');
    }

    return (int) $id;
}

function documentPdfLocalImageDataUri(string $absolutePath): string
{
    if (!is_file($absolutePath) || !is_readable($absolutePath)) {
        return '';
    }

    $contents = file_get_contents($absolutePath);
    if ($contents === false) {
        return '';
    }

    $mimeType = function_exists('mime_content_type')
        ? (string) mime_content_type($absolutePath)
        : 'image/jpeg';

    return 'data:' . $mimeType . ';base64,' . base64_encode($contents);
}

function documentPdfBuild(string $html, string $orientation = 'portrait'): string
{
    require_once dirname(__DIR__) . '/vendor/autoload.php';

    $options = new Dompdf\Options();
    $options->set('isRemoteEnabled', false);
    $options->set('isHtml5ParserEnabled', true);
    $options->set('defaultFont', 'DejaVu Sans');
    $options->set('defaultMediaType', 'print');

    $dompdf = new Dompdf\Dompdf($options);
    $dompdf->setPaper('A4', $orientation);
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->render();

    return $dompdf->output();
}

function documentPdfStream(string $html, string $fileName, string $orientation = 'portrait'): never
{
    require_once dirname(__DIR__) . '/vendor/autoload.php';

    $safeFileName = preg_replace('/[^A-Za-z0-9_-]+/', '_', $fileName) ?: 'document';
    $safeFileName = trim($safeFileName, '_') ?: 'document';
    $pdf = documentPdfBuild($html, $orientation);

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $safeFileName . '.pdf"');
    header('Content-Length: ' . strlen($pdf));
    header('X-Content-Type-Options: nosniff');
    echo $pdf;
    exit;
}
