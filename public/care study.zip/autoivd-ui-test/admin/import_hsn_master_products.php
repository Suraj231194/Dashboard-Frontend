<?php
/**
 * Master Script: Clean existing product data and import all 3,288 products from Excel
 *
 * 1. Checks/updates schema columns on `products` and `product_categories`.
 * 2. Synchronizes/Registers all 25 categories into `product_categories` with correct inventory_group.
 * 3. Safely clears existing product records and resets auto_increment.
 * 4. Imports all 3,288 products from HSN Wise Details.xlsx into `products`.
 */

declare(strict_types=1);

require_once 'c:/Sigma_Projects/PersonalDocs/Project/ERP/autoivd/admin/db.php';
global $conn;

if (!$conn || $conn->connect_error) {
    die("Database connection failed: " . ($conn ? $conn->connect_error : "No conn") . "\n");
}

echo "=== STARTING PRODUCT MASTER MIGRATION & IMPORT ===\n\n";

// -------------------------------------------------------------
// Step 1: Ensure required columns exist on `products`
// -------------------------------------------------------------
echo "[Step 1] Ensuring columns on `products` and `product_categories`...\n";
$columnsToAdd = [
    'hsn_code' => "ALTER TABLE `products` ADD COLUMN `hsn_code` varchar(30) DEFAULT NULL AFTER `product_code`",
    'erp_sku_web' => "ALTER TABLE `products` ADD COLUMN `erp_sku_web` varchar(100) DEFAULT NULL AFTER `hsn_code`",
    'slug' => "ALTER TABLE `products` ADD COLUMN `slug` varchar(191) DEFAULT NULL AFTER `product_name`",
    'description' => "ALTER TABLE `products` ADD COLUMN `description` text DEFAULT NULL",
    'inventory_group' => "ALTER TABLE `products` ADD COLUMN `inventory_group` tinyint(4) DEFAULT NULL AFTER `category_id`",
    'gst_rate' => "ALTER TABLE `products` ADD COLUMN `gst_rate` decimal(5,2) DEFAULT 18.00 AFTER `description`",
    'reorder_level' => "ALTER TABLE `products` ADD COLUMN `reorder_level` decimal(12,3) DEFAULT 0.000 AFTER `unit_id`",
    'product_image' => "ALTER TABLE `products` ADD COLUMN `product_image` varchar(255) DEFAULT NULL"
];

$existingColumns = [];
$res = $conn->query("DESCRIBE `products`");
while ($row = $res->fetch_assoc()) {
    $existingColumns[strtolower($row['Field'])] = true;
}

foreach ($columnsToAdd as $colName => $alterSql) {
    if (!isset($existingColumns[strtolower($colName)])) {
        if ($conn->query($alterSql)) {
            echo "  + Added column `products.{$colName}`\n";
        } else {
            echo "  ! Error adding `{$colName}`: " . $conn->error . "\n";
        }
    }
}

$catCols = [];
$resCat = $conn->query("DESCRIBE `product_categories`");
while ($row = $resCat->fetch_assoc()) {
    $catCols[strtolower($row['Field'])] = true;
}

if (!isset($catCols['slug'])) {
    $conn->query("ALTER TABLE `product_categories` ADD COLUMN `slug` varchar(191) DEFAULT NULL AFTER `name`");
    echo "  + Added column `product_categories.slug`\n";
}
if (!isset($catCols['website_sync'])) {
    $conn->query("ALTER TABLE `product_categories` ADD COLUMN `website_sync` tinyint(1) NOT NULL DEFAULT 0 AFTER `status`");
    echo "  + Added column `product_categories.website_sync`\n";
}

// -------------------------------------------------------------
// Step 2: Category Master Definitions (25 Categories)
// -------------------------------------------------------------
echo "\n[Step 2] Synchronizing 25 Category Masters...\n";

// Group 1 = FG (Finished Goods), 2 = PM (Packing Material), 3 = RM (Raw Material), 4 = CON (Consumables)
$categoryDefinitions = [
    'Raw Material'          => ['group' => 3, 'web_sync' => 0, 'gst' => 18.00],
    'Semi Finish'           => ['group' => 3, 'web_sync' => 0, 'gst' => 18.00],
    'Fapon'                 => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Packing Material'      => ['group' => 2, 'web_sync' => 0, 'gst' => 18.00],
    'Elisa'                 => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Molecular & Micro'     => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Finish Product'        => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Biochemistry'          => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Instrument'            => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Rapid'                 => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Clia Kits'             => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Sample'                => ['group' => 1, 'web_sync' => 0, 'gst' => 18.00],
    'Labkem'                => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'MACCURA'               => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'FIA Rapid Test'        => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Hematology'            => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Serology And Turbi'    => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Plastic Ware Import'   => ['group' => 4, 'web_sync' => 0, 'gst' => 18.00],
    'POCT MACHINE TEST KIT' => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Pipette And Tubes'     => ['group' => 4, 'web_sync' => 1, 'gst' => 18.00],
    'Labsim'                => ['group' => 3, 'web_sync' => 0, 'gst' => 18.00],
    'IHC Antibody'          => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Urine Parameter\'s'    => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'Clia'                  => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00],
    'HEMOGLOBIN'            => ['group' => 1, 'web_sync' => 1, 'gst' => 18.00]
];

function generateSlug(string $name): string {
    $slug = strtolower(trim($name));
    $slug = preg_replace('/[^a-z0-9]+/i', '-', $slug);
    return trim($slug, '-');
}

$categoryNameToId = [];
$categoryNameToGroup = [];
$sortOrder = 10;

foreach ($categoryDefinitions as $catName => $meta) {
    $slug = generateSlug($catName);
    $escapedName = $conn->real_escape_string($catName);
    $check = $conn->query("SELECT `id`, `name`, `inventory_group` FROM `product_categories` WHERE `name` = '$escapedName' OR `slug` = '$slug' LIMIT 1");
    
    if ($check && $check->num_rows > 0) {
        $row = $check->fetch_assoc();
        $catId = (int)$row['id'];
        $conn->query("UPDATE `product_categories` SET `inventory_group` = {$meta['group']}, `status` = 1, `website_sync` = {$meta['web_sync']} WHERE `id` = $catId");
        $categoryNameToId[$catName] = $catId;
        $categoryNameToGroup[$catName] = $meta['group'];
        echo "  - Category mapped: [{$catName}] => ID {$catId} (Group {$meta['group']})\n";
    } else {
        $stmt = $conn->prepare("INSERT INTO `product_categories` (`name`, `slug`, `sort_order`, `inventory_group`, `status`, `website_sync`, `created_at`) VALUES (?, ?, ?, ?, 1, ?, NOW())");
        $stmt->bind_param('ssiii', $catName, $slug, $sortOrder, $meta['group'], $meta['web_sync']);
        $stmt->execute();
        $catId = (int)$conn->insert_id;
        $stmt->close();
        $categoryNameToId[$catName] = $catId;
        $categoryNameToGroup[$catName] = $meta['group'];
        echo "  + Category created: [{$catName}] => ID {$catId} (Group {$meta['group']})\n";
    }
    $sortOrder += 10;
}

// -------------------------------------------------------------
// Step 3: Parse CSV
// -------------------------------------------------------------
echo "\n[Step 3] Parsing products from HSN file...\n";
$csvFile = 'c:/Sigma_Projects/PersonalDocs/Project/ERP/autoivd/hsn_details.csv';
$raw = file_get_contents($csvFile);
if (substr($raw, 0, 2) === "\xFF\xFE" || substr($raw, 0, 2) === "\xFE\xFF") {
    $raw = mb_convert_encoding($raw, 'UTF-8', 'UTF-16');
}
$handle = fopen('php://memory', 'r+');
fwrite($handle, $raw);
rewind($handle);

fgetcsv($handle); // Title
fgetcsv($handle); // Header

$productsToInsert = [];
$rowNum = 0;

while (($row = fgetcsv($handle)) !== false) {
    if (empty($row) || count($row) < 3) continue;
    $sr = trim((string)($row[0] ?? ''));
    $cat = trim((string)($row[1] ?? ''));
    $name = trim((string)($row[2] ?? ''));
    $hsn = trim((string)($row[3] ?? ''));

    if (empty($cat) || empty($name)) continue;

    $rowNum++;
    $catId = $categoryNameToId[$cat] ?? null;
    $invGroup = $categoryNameToGroup[$cat] ?? 1;

    if (!$catId) {
        echo "  ! Unrecognized category: [{$cat}] on row {$rowNum}\n";
        continue;
    }

    // Determine GST rate: default 18.00, unless specific 12% / 5%
    $gstRate = 18.00;
    if (str_contains($name, '@12%')) {
        $gstRate = 12.00;
    } elseif (str_contains($name, '@5%')) {
        $gstRate = 5.00;
    }

    $productsToInsert[] = [
        'sr' => $rowNum,
        'category_name' => $cat,
        'category_id' => $catId,
        'inventory_group' => $invGroup,
        'name' => $name,
        'hsn' => $hsn,
        'gst_rate' => $gstRate
    ];
}
fclose($handle);

echo "Total products prepared for import: " . count($productsToInsert) . "\n";

// -------------------------------------------------------------
// Step 4: Safely Clear Existing Products Table
// -------------------------------------------------------------
echo "\n[Step 4] Clearing existing product data...\n";
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("DELETE FROM `product_pack_sizes`");
$conn->query("ALTER TABLE `product_pack_sizes` AUTO_INCREMENT = 1");
$conn->query("DELETE FROM `products`");
$conn->query("ALTER TABLE `products` AUTO_INCREMENT = 1");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");
echo "  ✓ Existing products table cleared & AUTO_INCREMENT reset to 1.\n";

// -------------------------------------------------------------
// Step 5: Insert All 3,288 Products in Batches
// -------------------------------------------------------------
echo "\n[Step 5] Inserting all products into database...\n";

$financialYear = sprintf('%02d-%02d', (int)date('Y') % 100, ((int)date('Y') + 1) % 100);
$catPrefix = 'BIO/CAT/FY' . $financialYear . '/';

$insertStmt = $conn->prepare("INSERT INTO `products` 
    (`product_code`, `hsn_code`, `erp_sku_web`, `product_name`, `slug`, `category_id`, `inventory_group`, `gst_rate`, `reorder_level`, `status`, `is_notification`, `created_by`, `created_at`) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0.000, 1, 0, 1, NOW())");

if (!$insertStmt) {
    die("Failed to prepare product insert statement: " . $conn->error . "\n");
}

$conn->begin_transaction();
$insertedCount = 0;

foreach ($productsToInsert as $p) {
    $seq = sprintf('%06d', $p['sr']);
    $productCode = $catPrefix . $seq;
    $sku = 'BIO-' . strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $p['category_name']), 0, 4)) . '-' . $seq;
    $slug = generateSlug($p['name']) . '-' . strtolower($seq);

    $catId = (int)$p['category_id'];
    $invGroup = (int)$p['inventory_group'];
    $gst = (float)$p['gst_rate'];
    $hsn = (string)$p['hsn'];
    $name = (string)$p['name'];

    $insertStmt->bind_param(
        'sssssiid',
        $productCode,
        $hsn,
        $sku,
        $name,
        $slug,
        $catId,
        $invGroup,
        $gst
    );

    if (!$insertStmt->execute()) {
        $conn->rollback();
        die("Error inserting product at row {$p['sr']} ({$name}): " . $insertStmt->error . "\n");
    }
    $insertedCount++;
}

$conn->commit();
$insertStmt->close();

echo "  ✓ Successfully inserted {$insertedCount} products!\n\n";

// -------------------------------------------------------------
// Step 6: Verification and Summary
// -------------------------------------------------------------
$res = $conn->query("SELECT count(*) as total, 
    COUNT(CASE WHEN inventory_group = 1 THEN 1 END) as fg_count,
    COUNT(CASE WHEN inventory_group = 2 THEN 1 END) as pm_count,
    COUNT(CASE WHEN inventory_group = 3 THEN 1 END) as rm_count,
    COUNT(CASE WHEN inventory_group = 4 THEN 1 END) as con_count
    FROM `products` WHERE deleted_at IS NULL AND status = 1");

$stats = $res->fetch_assoc();

echo "=== MIGRATION & IMPORT COMPLETED SUCCESSFULLY ===\n";
echo "Total Active Products in Database: " . $stats['total'] . "\n";
echo "  - Finished Goods (Group 1): " . $stats['fg_count'] . "\n";
echo "  - Packing Material (Group 2): " . $stats['pm_count'] . "\n";
echo "  - Raw Material (Group 3): " . $stats['rm_count'] . "\n";
echo "  - Consumables (Group 4): " . $stats['con_count'] . "\n";
