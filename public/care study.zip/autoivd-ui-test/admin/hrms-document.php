<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (!isLoggedIn()) {
    http_response_code(401);
    exit('Authentication required.');
}

$documentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$documentId || $documentId <= 0) {
    http_response_code(400);
    exit('Invalid document.');
}

$stmt = $conn->prepare(
    "SELECT document.original_name, document.file_path, document.mime_type,
            document.employee_id, employee.user_id
     FROM employee_documents document
     INNER JOIN employees employee ON employee.id = document.employee_id AND employee.deleted_at IS NULL
     WHERE document.id = ? AND document.status = 1 AND document.deleted_at IS NULL
     LIMIT 1"
);
$stmt->bind_param('i', $documentId);
$stmt->execute();
$document = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$document) {
    http_response_code(404);
    exit('Document not found.');
}

$isOwner = (int) $document['user_id'] === (int) ($_SESSION['user_id'] ?? 0);
$canManage = checkPermission('hrms_employee_master_view', $conn);
if (!$isOwner && !$canManage) {
    http_response_code(403);
    exit('Access denied.');
}

$projectRoot = realpath(dirname(__DIR__));
$relativePath = ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, (string) $document['file_path']), DIRECTORY_SEPARATOR);
$absolutePath = $projectRoot ? realpath($projectRoot . DIRECTORY_SEPARATOR . $relativePath) : false;
$rootPrefix = $projectRoot ? rtrim($projectRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : '';
if (!$absolutePath || !$projectRoot || !str_starts_with($absolutePath, $rootPrefix) || !is_file($absolutePath)) {
    http_response_code(404);
    exit('Document file is unavailable.');
}

$detectedMime = '';
if (class_exists('finfo')) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $detectedMime = (string) $finfo->file($absolutePath);
}
$allowedMimeTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
$mimeType = $detectedMime ?: (string) ($document['mime_type'] ?? '');
if (!in_array($mimeType, $allowedMimeTypes, true)) {
    http_response_code(415);
    exit('This file type cannot be previewed.');
}

$displayName = preg_replace('/[\r\n"]+/', '', basename((string) $document['original_name']));
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($absolutePath));
header('Content-Disposition: inline; filename="' . ($displayName ?: 'employee-document') . '"');
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
readfile($absolutePath);
exit;
