<?php

declare(strict_types=1);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '0');
date_default_timezone_set('Asia/Kolkata');
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../vendor/autoload.php';

define('PAYROLL_CONTEXT', true);
require_once __DIR__ . '/payroll/payroll_common.php';
require_once __DIR__ . '/payroll/payroll_pdf.php';

$userId = payrollRequireLogin();
$action = trim((string) ($_POST['action'] ?? ''));
if ($action === '') {
    payrollJson(['status' => 'error', 'message' => 'No Payroll action was supplied.'], 400);
}
if (!payrollSchemaReady($conn)) {
    payrollJson(['status' => 'error', 'message' => 'Payroll Management is not configured.'], 503);
}

$mutatingActions = [
    'generate_pay_run', 'create_payroll_advance', 'submit_reimbursement',
    'review_reimbursement', 'mark_reimbursement_paid',
];
if (in_array($action, $mutatingActions, true)) {
    payrollRequireCsrf();
}

$storedFile = null;
$transactionOpen = false;

try {
    $scope = payrollCurrentScope($conn, $userId);

    switch ($action) {
        case 'preview_pay_run':
            payrollRequirePermission($conn, 'payroll_pay_runs_view');
            $month = payrollMonth(trim((string) ($_POST['payroll_month'] ?? '')));
            $calculation = payrollCalculateMonth($conn, $month, $scope);
            payrollJson([
                'status' => 'success',
                'message' => count($calculation['rows']) . ' employees found for this payroll month.',
                'rows' => $calculation['rows'],
                'totals' => $calculation['totals'],
                'validation' => $calculation['validation'],
                'payment_date' => payrollDefaultPaymentDate($conn, $month, $scope),
            ]);

        case 'generate_pay_run':
            payrollRequirePermission($conn, 'payroll_pay_runs_manage');
            $month = payrollMonth(trim((string) ($_POST['payroll_month'] ?? '')));
            $paymentDate = payrollDate(trim((string) ($_POST['payment_date'] ?? '')), 'payment date');
            $calculation = payrollCalculateMonth($conn, $month, $scope);
            if ($calculation['rows'] === []) {
                throw new RuntimeException('No employees with attendance were found for this payroll month.');
            }
            if ($calculation['validation'] !== []) {
                throw new RuntimeException('Complete salary and bank details before generating: ' . implode('; ', array_slice($calculation['validation'], 0, 5)));
            }

            $conn->begin_transaction();
            $transactionOpen = true;
            $check = $conn->prepare(
                'SELECT id, run_number FROM payroll_runs WHERE company_id = ? AND branch_id = ? AND payroll_month = ? FOR UPDATE'
            );
            $companyId = (int) $scope['company_id'];
            $branchId = (int) $scope['branch_id'];
            $check->bind_param('iis', $companyId, $branchId, $month);
            $check->execute();
            $existing = $check->get_result()->fetch_assoc();
            $check->close();
            if ($existing) {
                throw new RuntimeException('Pay run ' . $existing['run_number'] . ' has already been generated for this month.');
            }

            $runNumber = sprintf('PR-%s-%s', str_replace('-', '', $month), strtoupper(bin2hex(random_bytes(3))));
            $totals = $calculation['totals'];
            $calendar = $calculation['calendar'];
            $employeeCount = count($calculation['rows']);
            $generatedAt = date('Y-m-d H:i:s');
            $insertRun = $conn->prepare(
                "INSERT INTO payroll_runs
                 (run_number, company_id, branch_id, payroll_month, calendar_revision_id, calendar_hash,
                  calendar_working_days, calendar_weekly_off_days, calendar_holiday_days, payment_date, employee_count,
                  monthly_salary_total, actual_salary_total, pf_total, esic_total, advance_total,
                  generated_by, generated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            $insertRun->bind_param(
                'siisisdddsidddddis',
                $runNumber,
                $companyId,
                $branchId,
                $month,
                $calendar['id'],
                $calendar['content_hash'],
                $calendar['working_days'],
                $calendar['weekly_off_days'],
                $calendar['holiday_days'],
                $paymentDate,
                $employeeCount,
                $totals['monthly_salary'],
                $totals['actual_salary'],
                $totals['pf_amount'],
                $totals['esic_amount'],
                $totals['advance_taken'],
                $userId,
                $generatedAt
            );
            if (!$insertRun->execute()) {
                throw new RuntimeException('Unable to create the pay run.');
            }
            $runId = (int) $insertRun->insert_id;
            $insertRun->close();

            $insertItem = $conn->prepare(
                "INSERT INTO payroll_run_items
                 (payroll_run_id, employee_id, serial_number, employee_code, employee_name,
                  monthly_salary, gross_earned, actual_salary, present_days, month_days,
                  calendar_working_days, eligible_working_days, present_working_days, paid_leave_days,
                  unpaid_leave_days, lop_days, weekly_off_days, holiday_days, off_day_worked_days,
                  pf_amount, esic_amount, advance_taken, bank_account_number, bank_name, attendance_source)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            $serial = 0;
            $pdfItems = [];
            foreach ($calculation['rows'] as $row) {
                $serial++;
                $employeeId = (int) $row['employee_id'];
                $employeeCode = (string) $row['employee_code'];
                $employeeName = (string) $row['employee_name'];
                $monthlySalary = (float) $row['monthly_salary'];
                $grossEarned = (float) $row['gross_earned'];
                $actualSalary = (float) $row['actual_salary'];
                $presentDays = (float) $row['present_days'];
                $monthDays = (int) $row['month_days'];
                $calendarWorkingDays = (float) $row['calendar_working_days'];
                $eligibleWorkingDays = (float) $row['eligible_working_days'];
                $presentWorkingDays = (float) $row['present_working_days'];
                $paidLeaveDays = (float) $row['paid_leave_days'];
                $unpaidLeaveDays = (float) $row['unpaid_leave_days'];
                $lopDays = (float) $row['lop_days'];
                $weeklyOffDays = (float) $row['weekly_off_days'];
                $holidayDays = (float) $row['holiday_days'];
                $offDayWorkedDays = (float) $row['off_day_worked_days'];
                $pfAmount = (float) $row['pf_amount'];
                $esicAmount = (float) $row['esic_amount'];
                $advanceTaken = (float) $row['advance_taken'];
                $bankAccount = (string) $row['bank_account_number'];
                $bankName = (string) $row['bank_name'];
                $attendanceSource = (string) $row['attendance_source'];
                $insertItem->bind_param(
                    'iiissddddiddddddddddddsss',
                    $runId,
                    $employeeId,
                    $serial,
                    $employeeCode,
                    $employeeName,
                    $monthlySalary,
                    $grossEarned,
                    $actualSalary,
                    $presentDays,
                    $monthDays,
                    $calendarWorkingDays,
                    $eligibleWorkingDays,
                    $presentWorkingDays,
                    $paidLeaveDays,
                    $unpaidLeaveDays,
                    $lopDays,
                    $weeklyOffDays,
                    $holidayDays,
                    $offDayWorkedDays,
                    $pfAmount,
                    $esicAmount,
                    $advanceTaken,
                    $bankAccount,
                    $bankName,
                    $attendanceSource
                );
                if (!$insertItem->execute()) {
                    throw new RuntimeException('Unable to save a pay-run employee row.');
                }
                $pdfItems[] = array_merge($row, ['serial_number' => $serial]);
            }
            $insertItem->close();

            $run = ['run_number' => $runNumber, 'payroll_month' => $month, 'payment_date' => $paymentDate];
            $storedFile = payrollGenerateBankPdf($run, $pdfItems);
            $updateRun = $conn->prepare('UPDATE payroll_runs SET pdf_path = ? WHERE id = ?');
            $updateRun->bind_param('si', $storedFile['path'], $runId);
            if (!$updateRun->execute()) {
                throw new RuntimeException('Unable to attach the generated PDF to the pay run.');
            }
            $updateRun->close();
            payrollSavePaymentDay($conn, $scope, $paymentDate, $userId);
            $conn->commit();
            $transactionOpen = false;
            payrollJson([
                'status' => 'success',
                'message' => 'Pay run ' . $runNumber . ' generated successfully.',
                'run_id' => $runId,
                'run_number' => $runNumber,
                'preview_url' => 'payroll-file.php?type=pay-run-preview&id=' . $runId,
                'download_url' => 'payroll-file.php?type=pay-run&id=' . $runId,
            ]);

        case 'create_payroll_advance':
            payrollRequirePermission($conn, 'payroll_advances_manage');
            $partyType = trim((string) ($_POST['payroll_party_type'] ?? ''));
            if (!in_array($partyType, ['worker', 'employee'], true)) {
                throw new InvalidArgumentException('Select Workers or Employees.');
            }
            $employeeId = filter_var($_POST['employee_id'] ?? null, FILTER_VALIDATE_INT);
            $issuedOn = payrollDate(trim((string) ($_POST['issued_on'] ?? '')), 'advance date');
            $amount = round((float) ($_POST['amount'] ?? 0), 2);
            $paymentMode = trim((string) ($_POST['payment_mode'] ?? ''));
            $reason = trim((string) ($_POST['reason'] ?? ''));
            if (!$employeeId || $employeeId <= 0 || $amount <= 0) {
                throw new InvalidArgumentException('Select an employee and enter a valid advance amount.');
            }
            if (!in_array($paymentMode, ['cash','bank_transfer','cheque','upi','other'], true)) {
                throw new InvalidArgumentException('Select a valid mode of payment.');
            }
            if (mb_strlen($reason) < 3 || mb_strlen($reason) > 255) {
                throw new InvalidArgumentException('Enter a reason between 3 and 255 characters.');
            }
            $requiredCategory = $partyType === 'worker' ? 1 : 2;
            $employeeCheck = $conn->prepare(
                "SELECT employee.id
                 FROM employees employee
                 LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
                 LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
                                 LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
                 WHERE employee.id = ? AND employee.emp_categ_type = ?
                   AND employee.status != 3 AND employee.deleted_at IS NULL
                                     AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?
                                     AND (? = 0 OR COALESCE(profile.branch_id, user.branch_id) = ?)
                 LIMIT 1"
            );
            $companyId = (int) $scope['company_id'];
            $branchId = (int) $scope['branch_id'];
            $employeeCheck->bind_param('iiiii', $employeeId, $requiredCategory, $companyId, $branchId, $branchId);
            $employeeCheck->execute();
            $validEmployee = $employeeCheck->get_result()->fetch_assoc();
            $employeeCheck->close();
            if (!$validEmployee) {
                throw new InvalidArgumentException('Select a valid person from the chosen Employee Master list.');
            }
            $deductionType = 1;
            $createdAt = date('Y-m-d H:i:s');
            $insert = $conn->prepare(
                "INSERT INTO employee_advances
                 (employee_id, payroll_party_type, issued_on, amount, payment_mode, company_id, branch_id,
                  deduction_type, installment_amount, balance, remarks, status, created_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)"
            );
            $insert->bind_param(
                'issdsiiiddsis',
                $employeeId,
                $partyType,
                $issuedOn,
                $amount,
                $paymentMode,
                $companyId,
                $branchId,
                $deductionType,
                $amount,
                $amount,
                $reason,
                $userId,
                $createdAt
            );
            if (!$insert->execute()) {
                throw new RuntimeException('Unable to record the advance salary.');
            }
            $insert->close();
            payrollJson(['status' => 'success', 'message' => 'Advance salary recorded successfully.']);

        case 'submit_reimbursement':
            $employee = hrmsCurrentEmployee($conn, $userId);
            if (!$employee) {
                throw new RuntimeException('Your login is not linked to an employee record.');
            }
            $expenseName = trim((string) ($_POST['expense_name'] ?? ''));
            $expenseDate = payrollDate(trim((string) ($_POST['expense_date'] ?? '')), 'expense date');
            $merchant = trim((string) ($_POST['merchant'] ?? ''));
            $category = trim((string) ($_POST['category'] ?? ''));
            $amount = round((float) ($_POST['amount'] ?? 0), 2);
            $description = trim((string) ($_POST['description'] ?? ''));
            if (mb_strlen($expenseName) < 3 || mb_strlen($expenseName) > 255) {
                throw new InvalidArgumentException('Enter an expense name between 3 and 255 characters.');
            }
            if (mb_strlen($merchant) < 2 || mb_strlen($merchant) > 255) {
                throw new InvalidArgumentException('Enter a merchant name.');
            }
            if (!in_array($category, payrollReimbursementCategories(), true)) {
                throw new InvalidArgumentException('Select a valid expense category.');
            }
            if ($amount <= 0) {
                throw new InvalidArgumentException('Enter a valid reimbursement amount.');
            }
            if (mb_strlen($description) < 5 || mb_strlen($description) > 3000) {
                throw new InvalidArgumentException('Enter a description between 5 and 3000 characters.');
            }

            $storedFile = payrollStoreReceipt((int) $employee['id'], $_FILES['receipt'] ?? []);
            $conn->begin_transaction();
            $transactionOpen = true;
            $claimNumber = hrmsReference('RB');
            $employeeId = (int) $employee['id'];
            $companyId = !empty($employee['company_id']) ? (int) $employee['company_id'] : null;
            $branchId = !empty($employee['branch_id']) ? (int) $employee['branch_id'] : null;
            $submittedAt = date('Y-m-d H:i:s');
            $insert = $conn->prepare(
                "INSERT INTO payroll_reimbursements
                 (claim_number, employee_id, company_id, branch_id, expense_name, expense_date,
                  merchant, category, amount, description, receipt_path, receipt_original_name,
                  receipt_mime_type, status, reimbursement_status, submitted_at, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending', ?, ?)"
            );
            $insert->bind_param(
                'siiissssdsssssi',
                $claimNumber,
                $employeeId,
                $companyId,
                $branchId,
                $expenseName,
                $expenseDate,
                $merchant,
                $category,
                $amount,
                $description,
                $storedFile['path'],
                $storedFile['original_name'],
                $storedFile['mime_type'],
                $submittedAt,
                $userId
            );
            if (!$insert->execute()) {
                throw new RuntimeException('Unable to submit the reimbursement claim.');
            }
            $claimId = (int) $insert->insert_id;
            $insert->close();
            $history = $conn->prepare(
                "INSERT INTO payroll_reimbursement_history (reimbursement_id, from_status, to_status, note, changed_by)
                 VALUES (?, NULL, 'pending', 'Submitted by employee', ?)"
            );
            $history->bind_param('ii', $claimId, $userId);
            $history->execute();
            $history->close();
            $conn->commit();
            $transactionOpen = false;
            $managerIds = hrmsManagerUserIds($conn, 'payroll_reimbursements_manage', $companyId, $branchId);
                hrmsNotify(
                    $conn,
                    '92',
                    'payroll_reimbursements',
                    $claimId,
                    'New reimbursement claim',
                    trim($employee['first_name'] . ' ' . $employee['last_name']) . ' submitted ' . $claimNumber . ' for ₹' . payrollMoney($amount) . '.',
                    $userId,
                    $managerIds
                );
            payrollJson(['status' => 'success', 'message' => 'Reimbursement claim ' . $claimNumber . ' submitted successfully.']);

        case 'review_reimbursement':
            payrollRequirePermission($conn, 'payroll_reimbursements_manage');
            $claimId = filter_var($_POST['claim_id'] ?? null, FILTER_VALIDATE_INT);
            $decision = trim((string) ($_POST['decision'] ?? ''));
            $note = trim((string) ($_POST['action_note'] ?? ''));
            if (!$claimId || !in_array($decision, ['approved','rejected'], true)) {
                throw new InvalidArgumentException('Select a valid claim and decision.');
            }
            if (mb_strlen($note) > 1000) {
                throw new InvalidArgumentException('The action note must not exceed 1000 characters.');
            }
            $conn->begin_transaction();
            $transactionOpen = true;
            $select = $conn->prepare(
                "SELECT claim.id, claim.claim_number, claim.employee_id, claim.status, claim.company_id, claim.branch_id
                 FROM payroll_reimbursements claim WHERE claim.id = ? FOR UPDATE"
            );
            $select->bind_param('i', $claimId);
            $select->execute();
            $claim = $select->get_result()->fetch_assoc();
            $select->close();
            if (!$claim) {
                throw new RuntimeException('The selected reimbursement claim was not found.');
            }
            if ((int) ($claim['company_id'] ?? 0) !== (int) $scope['company_id']
                || ((int) $scope['branch_id'] > 0 && (int) ($claim['branch_id'] ?? 0) !== (int) $scope['branch_id'])) {
                throw new RuntimeException('This reimbursement claim belongs to another organization or branch.');
            }
            if ($claim['status'] !== 'pending') {
                throw new RuntimeException('This reimbursement claim has already been reviewed.');
            }
            $approvedDate = $decision === 'approved' ? date('Y-m-d') : null;
            $reimbursementStatus = $decision === 'approved' ? 'pending' : 'rejected';
            $update = $conn->prepare(
                'UPDATE payroll_reimbursements SET status = ?, action_by = ?, action_at = NOW(), action_note = ?, approved_date = ?, reimbursement_status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?'
            );
            $update->bind_param('sisssii', $decision, $userId, $note, $approvedDate, $reimbursementStatus, $userId, $claimId);
            if (!$update->execute()) {
                throw new RuntimeException('Unable to update the reimbursement claim.');
            }
            $update->close();
            $history = $conn->prepare(
                'INSERT INTO payroll_reimbursement_history (reimbursement_id, from_status, to_status, note, changed_by) VALUES (?, ?, ?, ?, ?)'
            );
            $fromStatus = (string) $claim['status'];
            $history->bind_param('isssi', $claimId, $fromStatus, $decision, $note, $userId);
            $history->execute();
            $history->close();
            $conn->commit();
            $transactionOpen = false;
            payrollNotifyEmployee(
                $conn,
                (int) $claim['employee_id'],
                'Reimbursement ' . $decision,
                $claim['claim_number'] . ' has been ' . $decision . '.',
                $userId,
                $claimId
            );
            payrollJson(['status' => 'success', 'message' => 'Reimbursement claim ' . $decision . ' successfully.']);

        case 'mark_reimbursement_paid':
            payrollRequireAnyPermission($conn, ['payroll_reimbursements_manage','finance_reimbursement_claims_manage']);
            $claimId = filter_var($_POST['claim_id'] ?? null, FILTER_VALIDATE_INT);
            $paymentMode = trim((string) ($_POST['payment_mode'] ?? ''));
            $paymentReference = trim((string) ($_POST['payment_reference'] ?? ''));
            if (!$claimId || !in_array($paymentMode, ['cash','bank_transfer','cheque','upi','other'], true)) {
                throw new InvalidArgumentException('Select a valid claim and payment mode.');
            }
            if (mb_strlen($paymentReference) > 255) {
                throw new InvalidArgumentException('The payment reference must not exceed 255 characters.');
            }
            $conn->begin_transaction();
            $transactionOpen = true;
            $select = $conn->prepare(
                'SELECT id, claim_number, employee_id, status, reimbursement_status, company_id, branch_id FROM payroll_reimbursements WHERE id = ? FOR UPDATE'
            );
            $select->bind_param('i', $claimId);
            $select->execute();
            $claim = $select->get_result()->fetch_assoc();
            $select->close();
            if (!$claim || $claim['status'] !== 'approved') {
                throw new RuntimeException('Only approved reimbursement claims can be marked paid.');
            }
            if ((int) ($claim['company_id'] ?? 0) !== (int) $scope['company_id']
                || ((int) $scope['branch_id'] > 0 && (int) ($claim['branch_id'] ?? 0) !== (int) $scope['branch_id'])) {
                throw new RuntimeException('This reimbursement claim belongs to another organization or branch.');
            }
            if ($claim['reimbursement_status'] === 'paid') {
                throw new RuntimeException('This reimbursement claim is already marked paid.');
            }
            $update = $conn->prepare(
                "UPDATE payroll_reimbursements SET reimbursement_status = 'paid', paid_by = ?, paid_at = NOW(),
                 payment_mode = ?, payment_reference = ?, updated_by = ?, updated_at = NOW() WHERE id = ?"
            );
            $update->bind_param('issii', $userId, $paymentMode, $paymentReference, $userId, $claimId);
            if (!$update->execute()) {
                throw new RuntimeException('Unable to mark the reimbursement claim paid.');
            }
            $update->close();
            $history = $conn->prepare(
                "INSERT INTO payroll_reimbursement_history (reimbursement_id, from_status, to_status, note, changed_by)
                 VALUES (?, 'pending', 'paid', ?, ?)"
            );
            $historyNote = $paymentReference !== '' ? 'Payment reference: ' . $paymentReference : 'Payment completed';
            $history->bind_param('isi', $claimId, $historyNote, $userId);
            $history->execute();
            $history->close();
            $conn->commit();
            $transactionOpen = false;
            payrollNotifyEmployee(
                $conn,
                (int) $claim['employee_id'],
                'Reimbursement paid',
                $claim['claim_number'] . ' has been marked paid.',
                $userId,
                $claimId
            );
            payrollJson(['status' => 'success', 'message' => 'Reimbursement payment recorded successfully.']);

        default:
            payrollJson(['status' => 'error', 'message' => 'Unknown Payroll action.'], 404);
    }
} catch (Throwable $error) {
    if ($transactionOpen) {
        $conn->rollback();
    }
    if ($storedFile && !empty($storedFile['absolute_path']) && is_file($storedFile['absolute_path'])) {
        @unlink($storedFile['absolute_path']);
    }
    $statusCode = $error instanceof InvalidArgumentException ? 422 : 400;
    payrollJson(['status' => 'error', 'message' => $error->getMessage()], $statusCode);
}
