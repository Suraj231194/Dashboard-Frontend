<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Kolkata');
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/finance/finance_common.php';

requireLogin();

$templateKey = strtolower(trim((string) ($_GET['template'] ?? '')));
$templates = [
    'invoice' => [
        'file_path' => 'all details/Invoice_1697.pdf',
        'original_name' => 'Invoice_1697.pdf',
        'mime_type' => 'application/pdf',
        'document_type' => 'SALES_INVOICE',
    ],
    'challan' => [
        'file_path' => 'all details/CA_200.pdf',
        'original_name' => 'CA_200.pdf',
        'mime_type' => 'application/pdf',
        'document_type' => 'DELIVERY_CHALLAN',
    ],
];

$fileId = (int) ($_GET['file_id'] ?? 0);
if ($templateKey !== '' && isset($templates[$templateKey])) {
    $file = $templates[$templateKey];
} elseif ($fileId <= 0 || !financeSchemaReady($conn)) {
    http_response_code(404);
    exit('File not found.');
} else {
    $stmt = $conn->prepare(
        "SELECT fdf.*, fd.document_type
         FROM finance_document_files fdf
         JOIN finance_documents fd ON fd.id = fdf.document_id
         WHERE fdf.id = ? AND fd.deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $fileId);
    $stmt->execute();
    $file = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if (!$file) {
    http_response_code(404);
    exit('File not found.');
}

$permissions = match ($file['document_type']) {
    'VENDOR_BILL' => ['finance_bill_generation_view', 'finance_trade_payables_view', 'finance_payment_made_view'],
    'SALES_INVOICE' => ['finance_invoice_generation_view', 'finance_trade_receivables_view', 'finance_payment_received_view'],
    'DELIVERY_CHALLAN' => ['finance_delivery_challan_generation_view'],
    default => [],
};
$allowed = false;
foreach ($permissions as $permission) {
    if (checkPermission($permission, $conn)) {
        $allowed = true;
        break;
    }
}
if (!$allowed) {
    http_response_code(403);
    exit('Access denied.');
}

$storedPath = str_replace('\\', '/', trim((string) $file['file_path']));
$storedPath = preg_replace('#^(\.\./)+#', '', $storedPath);
$projectRoot = realpath(dirname(__DIR__));
$adminRoot = realpath(__DIR__);
$candidates = [];

if (preg_match('#^[A-Za-z]:/#', $storedPath)) {
    $candidates[] = $storedPath;
} else {
    $candidates[] = $adminRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $storedPath);
    $candidates[] = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $storedPath);
    if (str_starts_with($storedPath, 'admin/')) {
        $candidates[] = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $storedPath);
    }
}

$resolved = null;
foreach ($candidates as $candidate) {
    $real = realpath($candidate);
    if ($real && is_file($real)) {
        $normalizedReal = strtolower(str_replace('\\', '/', $real));
        $normalizedProject = strtolower(str_replace('\\', '/', (string) $projectRoot));
        if (str_starts_with($normalizedReal, $normalizedProject . '/')) {
            $resolved = $real;
            break;
        }
    }
}

if (!$resolved) {
    http_response_code(404);
    exit('The stored Finance file is unavailable.');
}

$mime = (string) ($file['mime_type'] ?: '');
if ($mime === '' || $mime === 'application/octet-stream') {
    $mime = function_exists('mime_content_type') ? (string) mime_content_type($resolved) : 'application/octet-stream';
}
$allowedMimes = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
if (!in_array($mime, $allowedMimes, true)) {
    http_response_code(415);
    exit('Unsupported file type.');
}

$filename = (string) ($file['original_name'] ?: basename($resolved));
$filename = preg_replace('/[^A-Za-z0-9._ -]/', '_', $filename);
$download = isset($_GET['download']) && (int) $_GET['download'] === 1;

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($resolved));
header('X-Content-Type-Options: nosniff');
header(
    'Content-Disposition: ' . ($download ? 'attachment' : 'inline')
    . '; filename="' . addcslashes($filename, '"\\') . '"'
);
readfile($resolved);
exit;
