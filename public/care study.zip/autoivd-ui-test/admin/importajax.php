<?php
date_default_timezone_set('Asia/Kolkata');
session_start();
require_once "db.php";
require_once 'constant.php';
include "functions.php";
require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;

if (isset($_POST["importEmployeesFile"])) {
    header('Content-Type: application/json');

    // Check file upload
    if (empty($_FILES['fileUploadEmployee']['tmp_name']) || $_FILES['fileUploadEmployee']['error'] !== 0) {
        echo json_encode(['status' => 'error', 'message' => 'No file uploaded or upload error.']);
        exit;
    }

    $filePath = $_FILES['fileUploadEmployee']['tmp_name'];

    try {
    //     // Load Excel file
        $spreadsheet = IOFactory::load($filePath);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray(null, true, true, true);        
        if (count($rows) < 2) {
            echo json_encode(['status' => 'error', 'message' => 'Excel file is empty or missing data.']);
            exit;
        }        
        // Detect headers from first row
        // $headers = array_map('strtolower', array_map('trim', $rows[1]));
        $headers = array_map(function($val) { 
            return strtolower(trim((string)$val)); 
        }, $rows[1]);

        $columns = [
            'emp_code'   => null,
            'first_name' => null,
            'last_name'  => null,
            'company'    => null,
            'emp_categ_type'=> null,
            'basic_salary'=> null,
            'uan_no'     => null,
            'esic_no'     => null,
            'bank_account_number' => null,
            'bank_id' => null,
        ];
        
        // Map columns dynamically
        foreach ($columns as $col => $val) {
            foreach ($headers as $letter => $headerName) {
                if ($headerName === strtolower($col)) {
                    $columns[$col] = $letter;
                    break;
                }
            }
            if ($columns[$col] === null) {
                echo json_encode(['status' => 'error', 'message' => "Missing column: $col"]);
                exit;
            }
        }

        $inserted = 0;
        $updated = 0;

        $bankMap = [];
        $unitQuery = $conn->query("SELECT * FROM `banks` WHERE `status` = 1");        
        while ($row = $unitQuery->fetch_assoc()) {
            $bankName = strtoupper(trim($row['bank_name']));
            $bankShort = str_replace('BANK', '', $bankName);
            $bankShort = trim($bankShort);
            $bankMap[$bankShort] = $row['id'];
        }
        $createdBy = $_SESSION['user_id'] ?? 0;
        $createdAt = date('Y-m-d H:i:s');
        // Process rows (skip header)
        foreach ($rows as $rowNum => $row) {
            if ($rowNum == 1) continue;

            $empCode   = trim((string)$row[$columns['emp_code']]);
            $firstName = trim((string)$row[$columns['first_name']]);
            $lastName  = trim((string)$row[$columns['last_name']]);
            $companyRaw = trim((string)$row[$columns['company']]);
            $empCategTypeRaw = trim((string)$row[$columns['emp_categ_type']]);
            $uanNo = trim((string)$row[$columns['uan_no']]);
            $esicNo = trim((string)$row[$columns['esic_no']]);
            $bankAccountNumber = trim((string)$row[$columns['bank_account_number']]);
            $bankNameRaw = trim((string)$row[$columns['bank_id']]);
            $basicSalary = (float)($row[$columns['basic_salary']] ?? 0);
            $status = 1;


            if (empty($empCode)) continue;

            $company = null;
            if (!empty($companyRaw)) {
                $companyRaw = strtoupper(trim($companyRaw));
                $companyTypes = Constant::EMPLOYEES['COMPANY_TYPE_LABEL'];                
                if (isset($companyTypes[$companyRaw])) {
                    $company = $companyTypes[$companyRaw];
                }
            }
            $empCategType = null;
            if (!empty($empCategTypeRaw)) {
                $empCategTypeRaw = strtoupper(trim($empCategTypeRaw));
                $companyCategTypes = Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_SHORT_TYPE'];                
                if (isset($companyCategTypes[$empCategTypeRaw])) {
                    $empCategType = $companyCategTypes[$empCategTypeRaw];
                }
            }
            
            $bankId = null;
            if (!empty($bankNameRaw)) {
                $bankKey = strtoupper(trim($bankNameRaw));
                if (isset($bankMap[$bankKey])) {
                    $bankId = $bankMap[$bankKey];
                } else {
                    foreach ($bankMap as $key => $id) {
                        if (stripos($key, $bankKey) !== false || stripos($bankKey, $key) !== false) {
                            $bankId = $id;
                            break;
                        }
                    }
                }
            }           
            // Check if employee exists
            $check = $conn->prepare("SELECT `id` FROM `employees` WHERE `emp_code` = ?");
            $check->bind_param("s", $empCode);
            $check->execute();
            $result = $check->get_result();

            if ($result->num_rows > 0) {
                $existing = $result->fetch_assoc();
                $empId = $existing['id'];

                // Fetch current values of relevant columns
                $existingQuery = $conn->prepare("SELECT `company`, `emp_categ_type`, `uan_no`, `esic_no`, `bank_id`, `bank_account_number` FROM `employees` WHERE `id` = ?");
                $existingQuery->bind_param("i", $empId);
                $existingQuery->execute();
                $existingData = $existingQuery->get_result()->fetch_assoc();
                $existingQuery->close();

                // Prepare fields to update ONLY IF currently null
                $updateFields = [];
                $params = [];
                $types = '';

                if (empty($existingData['company']) && !empty($company)) {
                    $updateFields[] = "`company` = ?";
                    $params[] = $company;
                    $types .= 'i';
                }
                if (empty($existingData['emp_categ_type']) && !empty($empCategType)) {
                    $updateFields[] = "`emp_categ_type` = ?";
                    $params[] = $empCategType;
                    $types .= 'i';
                }
                if (empty($existingData['uan_no']) && !empty($uanNo)) {
                    $updateFields[] = "`uan_no` = ?";
                    $params[] = $uanNo;
                    $types .= 's';
                }
                if (empty($existingData['esic_no']) && !empty($esicNo)) {
                    $updateFields[] = "`esic_no` = ?";
                    $params[] = $esicNo;
                    $types .= 's';
                }
                if (empty($existingData['bank_id']) && !empty($bankId)) {
                    $updateFields[] = "`bank_id` = ?";
                    $params[] = $bankId;
                    $types .= 'i';
                }
                if (empty($existingData['bank_account_number']) && !empty($bankAccountNumber)) {
                    $updateFields[] = "`bank_account_number` = ?";
                    $params[] = $bankAccountNumber;
                    $types .= 's';
                }

                // If there are any updates to apply
                if (!empty($updateFields)) {
                    $updateFields[] = "`updated_at` = ?";
                    $updateFields[] = "`updated_by` = ?";
                    $params[] = $createdAt;   
                    $params[] = $createdBy;  
                    $types .= 'si';
                    
                    $updateSQL = "UPDATE `employees` SET " . implode(', ', $updateFields) . " WHERE `id` = ?";
                    $updateStmt = $conn->prepare($updateSQL);
                    $types .= 'i';
                    $params[] = $empId;

                    $updateStmt->bind_param($types, ...$params);
                    $updateStmt->execute();
                    $updateStmt->close();

                    $updated++;
                }
            } else {
                // Insert new
                $insert = $conn->prepare("INSERT INTO `employees` (`emp_code`, `first_name`, `last_name`, `company`, `emp_categ_type`,`uan_no`, `esic_no`, `bank_id`, `bank_account_number`, `status`,`created_at`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $insert->bind_param("sssiissisisi", $empCode, $firstName, $lastName, $company, $empCategType, $uanNo,$esicNo, $bankId, $bankAccountNumber, $status, $createdAt, $createdBy);
                $insert->execute();
                $lastEmpId = $conn->insert_id;
                $insert->close();
                $inserted++;
                if(!empty($basicSalary)){
                    $defaultBasic = 0.00;
                    $defaultHra = 0.00;
                    $defaultAllowances = 0.00;
                    $salaryStatus = 1;
                    $baseSalaryPfEsi = ($basicSalary <= 15000) ? 7500 : 15000;
                    $salaryInsert = $conn->prepare("INSERT INTO `employee_salaries`
                        (`employee_id`,`base_salary_pf_esi`, `basic_salary`,`effective_from`, `status`, `created_at`, `created_by`)
                        VALUES (?, ?, ?, ?, ?, ?, ?) ");
                    $salaryInsert->bind_param(
                        "iddsisi",
                        $lastEmpId,
                        $baseSalaryPfEsi,
                        $basicSalary,
                        $createdAt,                    
                        $salaryStatus,
                        $createdAt,
                        $createdBy
                    );
                    $salaryInsert->execute();
                    $salaryInsert->close();
                }
            }

            $check->close();
        }
        
        echo json_encode([
            'status' => 'success',
            'message' => "Import completed: $inserted inserted, $updated updated."
        ]);
        exit;

    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Error reading Excel: ' . $e->getMessage()]);
        exit;
    }
}

if (isset($_POST["importEmployeesSalaryFile"])) {
    header('Content-Type: application/json');
    $createdBy  = $_SESSION['user_id'] ?? 0;

    // Check file
    if (empty($_FILES['fileUploadEmployeeSalary']['tmp_name']) || $_FILES['fileUploadEmployeeSalary']['error'] !== 0) {
        echo json_encode(['status' => 'error', 'message' => 'No file uploaded or upload error.']);
        exit;
    }

    $filePath = $_FILES['fileUploadEmployeeSalary']['tmp_name'];

    try {
        $spreadsheet = IOFactory::load($filePath);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray(null, true, true, true);

        if (count($rows) < 2) {
            echo json_encode(['status' => 'error', 'message' => 'Excel file is empty or missing data.']);
            exit;
        }

        // Map expected columns
        $headers = array_map('strtolower', array_map('trim', $rows[1]));
        $columns = [
            'emp_code' => null,
            'name' => null,
            'base_salary_pf_esi' => null,
            'basic_salary' => null,
            'effective_from' => null,
            'effective_to' => null
        ];

        foreach ($columns as $col => $val) {
            foreach ($headers as $letter => $headerName) {
                $normalized = strtolower(str_replace(['.', ' '], '', $headerName));
                $colNormalized = strtolower(str_replace(['.', ' '], '', $col));
                if ($normalized === $colNormalized) {
                    $columns[$col] = $letter;
                    break;
                }
            }
            if ($columns[$col] === null) {
                echo json_encode(['status' => 'error', 'message' => "Missing column: $col"]);
                exit;
            }
        }

        $inserted = 0;
        $skipped = 0;

        foreach ($rows as $rowNum => $row) {
            if ($rowNum == 1) continue; // Skip header row

            $empCode = trim((string)($row[$columns['emp_code']] ?? ''));
            $baseSalaryPFESI = (float)($row[$columns['base_salary_pf_esi']] ?? 0);
            $basicSalary = (float)($row[$columns['basic_salary']] ?? 0);
            $effFromRaw = trim((string)($row[$columns['effective_from']] ?? ''));
            $effToRaw = trim((string)($row[$columns['effective_to']] ?? ''));

            if (empty($empCode)) continue;

            // Find employee
            $check = $conn->prepare("SELECT `id`, `date_of_join` FROM `employees` WHERE `emp_code` = ?");
            $check->bind_param("s", $empCode);
            $check->execute();
            $result = $check->get_result();

            if ($result->num_rows === 0) {
                $skipped++;
                continue;
            }

            $employee = $result->fetch_assoc();
            $employeeId = $employee['id'];
            $joinDate = $employee['date_of_join'] ?? null;

            // Format effective dates
            $effectiveFrom = null;
            $effectiveTo = null;

            if (!empty($effFromRaw)) {
                if (is_numeric($effFromRaw)) {
                    $effectiveFrom = Date::excelToDateTimeObject($effFromRaw)->format('Y-m-d');
                } else {
                    $effectiveFrom = date('Y-m-d', strtotime($effFromRaw));
                }
            }

            if (!empty($effToRaw)) {
                if (is_numeric($effToRaw)) {
                    $effectiveTo = Date::excelToDateTimeObject($effToRaw)->format('Y-m-d');
                } else {
                    $effectiveTo = date('Y-m-d', strtotime($effToRaw));
                }
            }

            // Default if missing
            if (empty($effectiveFrom)) {
                $effectiveFrom = $joinDate ?: date('Y-m-d');
            }

            // 🔹 Mark old salary records as inactive
            $updateOld = $conn->prepare("
                UPDATE `employee_salaries`
                SET `status` = 3, `deleted_at` = NOW(), `deleted_by` = ?
                WHERE `employee_id` = ? AND `status` != 3
            ");
            $updateOld->bind_param("ii", $createdBy, $employeeId);
            $updateOld->execute();
            $updateOld->close();

            
            $insert = $conn->prepare("
                INSERT INTO `employee_salaries`
                (`employee_id`, `base_salary_pf_esi`, `basic_salary`, `effective_from`, `effective_to`, `created_at`, `created_by`, `status`)
                VALUES (?, ?, ?, ?, ?, NOW(), ?, 1)
            ");
            $insert->bind_param("iddssi", $employeeId, $baseSalaryPFESI, $basicSalary, $effectiveFrom, $effectiveTo, $createdBy);
            $insert->execute();
            $insert->close();

            $inserted++;
        }

        echo json_encode([
            'status' => 'success',
            'message' => "Import completed: $inserted inserted, $skipped skipped (due to missing employee code)."
        ]);
        exit;

    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Error reading Excel: ' . $e->getMessage()]);
        exit;
    }
}
