<?php
require __DIR__ . '/db.php';
$res = $conn->query("SELECT id, name, route, showmenu, permission_slug, parent_id FROM menus WHERE id IN (21, 30)");
while($row = $res->fetch_assoc()) {
    print_r($row);
}
