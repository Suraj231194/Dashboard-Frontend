<?php
/**
 * Master Script: Create/Update Customer & Supplier Tables, and Import from VendorsCustomers_updated.xlsx
 *
 * 1. Ensures `customers` and `suppliers` tables exist with all necessary columns (including `source_origin` = 'erp' / 'website').
 * 2. Clears existing customer and vendor records safely and resets auto_increment.
 * 3. Parses `VendorsCustomers_updated.xlsx` (Sheet 1: `All Party (PPI Details)`).
 * 4. Inserts `vendor` records into `suppliers` table with unique supplier code.
 * 5. Inserts `customer` records into `customers` table with GST, PAN, State, Address, and `source_origin = 'erp'`.
 */

declare(strict_types=1);

require_once 'c:/Sigma_Projects/PersonalDocs/Project/ERP/autoivd/admin/db.php';
global $conn;

if (!$conn || $conn->connect_error) {
    die("Database connection failed: " . ($conn ? $conn->connect_error : "No conn") . "\n");
}

echo "=== STARTING VENDOR & CUSTOMER MASTER MIGRATION & IMPORT ===\n\n";

// -------------------------------------------------------------
// Step 1: Create / Ensure `customers` table exists with source_origin
// -------------------------------------------------------------
echo "[Step 1] Ensuring `customers` table schema...\n";

$createCustomersTable = "CREATE TABLE IF NOT EXISTS `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_user_id` bigint(20) unsigned DEFAULT NULL,
  `source_origin` varchar(20) NOT NULL DEFAULT 'erp' COMMENT 'Defines whether customer is from erp or website',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) NOT NULL DEFAULT '+91',
  `user_type` varchar(30) NOT NULL DEFAULT 'b2b',
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `gstin` varchar(50) DEFAULT NULL,
  `pan` varchar(20) DEFAULT NULL,
  `gst_format_valid` tinyint(1) NOT NULL DEFAULT 0,
  `state_province` varchar(100) DEFAULT NULL,
  `state_code` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `detailed_address` text DEFAULT NULL,
  `credit_limit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit_days` int(11) NOT NULL DEFAULT 0,
  `payment_terms_status` int(11) DEFAULT 3,
  `payment_terms_text` varchar(500) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customers_website_user_id` (`website_user_id`),
  KEY `idx_customers_name` (`name`),
  KEY `idx_customers_gstin` (`gstin`),
  KEY `idx_customers_email` (`email`),
  KEY `idx_customers_type_status` (`user_type`,`status`),
  KEY `idx_customers_source_origin` (`source_origin`),
  KEY `idx_customers_location` (`state_province`,`city`,`postal_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!$conn->query($createCustomersTable)) {
    die("Error creating customers table: " . $conn->error . "\n");
}
echo "  ✓ `customers` table verified.\n";

// Ensure required columns on customers table
$custCols = [];
$res = $conn->query("DESCRIBE `customers`");
while ($r = $res->fetch_assoc()) $custCols[strtolower($r['Field'])] = true;

if (!isset($custCols['source_origin'])) {
    $conn->query("ALTER TABLE `customers` ADD COLUMN `source_origin` varchar(20) NOT NULL DEFAULT 'erp' AFTER `website_user_id`");
    $conn->query("ALTER TABLE `customers` ADD INDEX `idx_customers_source_origin` (`source_origin`)");
    echo "  + Added `source_origin` column to `customers` table\n";
}

// -------------------------------------------------------------
// Step 2: Ensure `suppliers` table has all required columns
// -------------------------------------------------------------
echo "\n[Step 2] Ensuring `suppliers` table schema...\n";

$suppCols = [];
$res = $conn->query("DESCRIBE `suppliers`");
while ($r = $res->fetch_assoc()) $suppCols[strtolower($r['Field'])] = true;

$conn->query("ALTER TABLE `suppliers` MODIFY COLUMN `contact_number` varchar(150) DEFAULT NULL");
$conn->query("ALTER TABLE `suppliers` MODIFY COLUMN `supplier_code` varchar(50) DEFAULT NULL");
$conn->query("ALTER TABLE `suppliers` MODIFY COLUMN `gst_no` varchar(100) DEFAULT NULL");

$suppColumnsToAdd = [
    'source_origin' => "ALTER TABLE `suppliers` ADD COLUMN `source_origin` varchar(20) NOT NULL DEFAULT 'erp' AFTER `supplier_code`",
    'state' => "ALTER TABLE `suppliers` ADD COLUMN `state` varchar(100) DEFAULT NULL AFTER `contact_details`",
    'address' => "ALTER TABLE `suppliers` ADD COLUMN `address` text DEFAULT NULL AFTER `state`",
    'city' => "ALTER TABLE `suppliers` ADD COLUMN `city` varchar(100) DEFAULT NULL AFTER `address`",
    'pincode' => "ALTER TABLE `suppliers` ADD COLUMN `pincode` varchar(20) DEFAULT NULL AFTER `city`"
];

foreach ($suppColumnsToAdd as $col => $sql) {
    if (!isset($suppCols[strtolower($col)])) {
        $conn->query($sql);
        echo "  + Added `suppliers.{$col}`\n";
    }
}
echo "  ✓ `suppliers` table verified.\n";

// -------------------------------------------------------------
// Step 3: Export fresh CSV from VendorsCustomers_updated.xlsx
// -------------------------------------------------------------
echo "\n[Step 3] Reading data from VendorsCustomers_updated.xlsx...\n";

$excelPath = 'c:/Sigma_Projects/PersonalDocs/Project/ERP/autoivd/VendorsCustomers_updated.xlsx';
$csvExportCmd = 'npx -y xlsx-cli "' . $excelPath . '" > "c:/Sigma_Projects/PersonalDocs/Project/ERP/autoivd/vc_dump.csv"';
exec($csvExportCmd, $output, $ret);

$csvFile = 'c:/Sigma_Projects/PersonalDocs/Project/ERP/autoivd/vc_dump.csv';
$raw = file_get_contents($csvFile);
if (substr($raw, 0, 2) === "\xFF\xFE" || substr($raw, 0, 2) === "\xFE\xFF") {
    $raw = mb_convert_encoding($raw, 'UTF-8', 'UTF-16');
}
$handle = fopen('php://memory', 'r+');
fwrite($handle, $raw);
rewind($handle);

$header = fgetcsv($handle); // Header row

$vendorsToInsert = [];
$customersToInsert = [];
$skippedCount = 0;
$rowIdx = 0;

while (($row = fgetcsv($handle)) !== false) {
    if (empty($row) || count($row) < 2) continue;
    $rowIdx++;
    $gst = trim((string)($row[0] ?? ''));
    $name = trim((string)($row[1] ?? ''));
    $phone = trim((string)($row[2] ?? ''));
    $state = trim((string)($row[3] ?? ''));
    $address = trim((string)($row[4] ?? ''));
    $type = strtolower(trim((string)($row[5] ?? '')));

    if (empty($name)) continue;

    // Parse PAN and state code from GST if valid
    $pan = null;
    $stateCode = null;
    $isGstValid = 0;
    if (strlen($gst) === 15 && preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/i', $gst)) {
        $stateCode = substr($gst, 0, 2);
        $pan = substr($gst, 2, 10);
        $isGstValid = 1;
    } elseif (strlen($gst) === 15) {
        $stateCode = substr($gst, 0, 2);
        $pan = substr($gst, 2, 10);
    }

    // Extract pincode if present in address
    $pincode = null;
    if (preg_match('/\b([1-9][0-9]{5})\b/', $address, $pm)) {
        $pincode = $pm[1];
    }

    if ($type === 'vendor') {
        $vendorsToInsert[] = [
            'name' => $name,
            'gst' => $gst,
            'phone' => $phone,
            'state' => $state,
            'address' => $address,
            'pincode' => $pincode
        ];
    } elseif ($type === 'customer') {
        $customersToInsert[] = [
            'name' => $name,
            'company_name' => $name,
            'gstin' => $gst,
            'pan' => $pan,
            'gst_format_valid' => $isGstValid,
            'phone' => $phone,
            'state_province' => $state,
            'state_code' => $stateCode,
            'postal_code' => $pincode,
            'detailed_address' => $address,
            'user_type' => 'b2b', // All customer master records are B2B
            'source_origin' => 'erp' // defines customer is from ERP
        ];
    } else {
        $skippedCount++;
    }
}
fclose($handle);
@unlink($csvFile);

echo "  - Vendors found: " . count($vendorsToInsert) . "\n";
echo "  - Customers found: " . count($customersToInsert) . "\n";
echo "  - Blank/Skipped non-parties: " . $skippedCount . "\n";

// -------------------------------------------------------------
// Step 4: Safely Clear Existing Data
// -------------------------------------------------------------
echo "\n[Step 4] Clearing existing vendor & customer tables...\n";
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("DELETE FROM `suppliers`");
$conn->query("ALTER TABLE `suppliers` AUTO_INCREMENT = 1");
$conn->query("DELETE FROM `customers`");
$conn->query("ALTER TABLE `customers` AUTO_INCREMENT = 1");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");
echo "  ✓ `suppliers` and `customers` cleared & AUTO_INCREMENT reset to 1.\n";

// -------------------------------------------------------------
// Step 5: Insert All Vendors into `suppliers`
// -------------------------------------------------------------
$totalV = count($vendorsToInsert);
echo "\n[Step 5] Inserting {$totalV} Vendors into `suppliers`...\n";

$suppStmt = $conn->prepare("INSERT INTO `suppliers` 
    (`name`, `supplier_code`, `source_origin`, `contact_number`, `gst_no`, `state`, `address`, `pincode`, `status`, `is_approved`, `is_supplier`, `is_vendor`, `created_by`, `created_at`) 
    VALUES (?, ?, 'erp', ?, ?, ?, ?, ?, 1, 1, 1, 1, 1, NOW())");

if (!$suppStmt) {
    die("Failed to prepare supplier insert statement: " . $conn->error . "\n");
}

$conn->begin_transaction();
$vIdx = 0;
foreach ($vendorsToInsert as $v) {
    $vIdx++;
    $supplierCode = sprintf('BIO/VEN/FY26-27/%06d', $vIdx);
    $name = (string)$v['name'];
    $phone = (string)$v['phone'];
    $gst = (string)$v['gst'];
    $state = (string)$v['state'];
    $address = (string)$v['address'];
    $pincode = (string)($v['pincode'] ?? '');

    $suppStmt->bind_param('sssssss', $name, $supplierCode, $phone, $gst, $state, $address, $pincode);
    if (!$suppStmt->execute()) {
        $conn->rollback();
        die("Error inserting vendor #{$vIdx} ({$name}): " . $suppStmt->error . "\n");
    }
}
$conn->commit();
$suppStmt->close();
echo "  ✓ Successfully inserted {$vIdx} Vendors into `suppliers`!\n";

// -------------------------------------------------------------
// Step 6: Insert All Customers into `customers`
// -------------------------------------------------------------
$totalC = count($customersToInsert);
echo "\n[Step 6] Inserting {$totalC} Customers into `customers`...\n";

$custStmt = $conn->prepare("INSERT INTO `customers` 
    (`source_origin`, `name`, `company_name`, `user_type`, `gstin`, `pan`, `gst_format_valid`, `phone`, `country_code`, `state_province`, `state_code`, `postal_code`, `detailed_address`, `credit_limit`, `credit_days`, `payment_terms_status`, `status`, `created_by`, `created_at`) 
    VALUES ('erp', ?, ?, ?, ?, ?, ?, ?, '+91', ?, ?, ?, ?, 0.00, 0, 3, 1, 1, NOW())");

if (!$custStmt) {
    die("Failed to prepare customer insert statement: " . $conn->error . "\n");
}

$conn->begin_transaction();
$cIdx = 0;
foreach ($customersToInsert as $c) {
    $cIdx++;
    $name = (string)$c['name'];
    $companyName = (string)$c['company_name'];
    $userType = (string)$c['user_type'];
    $gstin = (string)$c['gstin'];
    $pan = (string)$c['pan'];
    $gstValid = (int)$c['gst_format_valid'];
    $phone = (string)$c['phone'];
    $state = (string)$c['state_province'];
    $stateCode = (string)$c['state_code'];
    $pincode = (string)$c['postal_code'];
    $address = (string)$c['detailed_address'];

    $custStmt->bind_param(
        'sssssisssss',
        $name,
        $companyName,
        $userType,
        $gstin,
        $pan,
        $gstValid,
        $phone,
        $state,
        $stateCode,
        $pincode,
        $address
    );

    if (!$custStmt->execute()) {
        $conn->rollback();
        die("Error inserting customer #{$cIdx} ({$name}): " . $custStmt->error . "\n");
    }
}
$conn->commit();
$custStmt->close();
echo "  ✓ Successfully inserted {$cIdx} Customers into `customers`!\n\n";

// -------------------------------------------------------------
// Step 7: Final Verification
// -------------------------------------------------------------
$vRes = $conn->query("SELECT count(*) as total, count(case when source_origin = 'erp' then 1 end) as erp_count FROM `suppliers`");
$vStats = $vRes->fetch_assoc();

$cRes = $conn->query("SELECT count(*) as total, 
    count(case when source_origin = 'erp' then 1 end) as erp_count,
    count(case when user_type = 'b2b' then 1 end) as b2b_count,
    count(case when gstin != '' and gstin is not null then 1 end) as gst_count
    FROM `customers`");
$cStats = $cRes->fetch_assoc();

echo "=== MIGRATION & IMPORT COMPLETED SUCCESSFULLY ===\n";
echo "Suppliers / Vendors Master (`suppliers`):\n";
echo "  - Total Records: " . $vStats['total'] . "\n";
echo "  - Source Origin ERP: " . $vStats['erp_count'] . "\n\n";

echo "Customers Master (`customers`):\n";
echo "  - Total Records: " . $cStats['total'] . "\n";
echo "  - Source Origin ERP: " . $cStats['erp_count'] . "\n";
echo "  - All B2B Customers: " . $cStats['b2b_count'] . "\n";
echo "  - Customers with Registered GSTIN: " . $cStats['gst_count'] . "\n";
