<?php
// Set execution limit to 5 minutes so it never timeouts in the background
set_time_limit(300);

if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.");
}

$createdBy = isset($argv[1]) ? intval($argv[1]) : 1;

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/constant.php';
require_once dirname(__DIR__) . '/functions.php';

$logFile = __DIR__ . '/background_routing.log';
file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] Background route_pending.php started for user " . $createdBy . "\n", FILE_APPEND);
$routed = mvAutoRoutePendingOrdersAfterStockChange($conn, $createdBy);
file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] Background route_pending.php finished. Routed orders: " . implode(', ', $routed) . "\n", FILE_APPEND);
