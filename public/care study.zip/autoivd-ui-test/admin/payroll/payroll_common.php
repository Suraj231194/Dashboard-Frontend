<?php

declare(strict_types=1);

if (!defined('PAYROLL_CONTEXT')) {
    http_response_code(404);
    exit;
}

if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once __DIR__ . '/../hrms/hrms_common.php';
require_once __DIR__ . '/../hrms/annual_calendar_common.php';

function payrollJson(array $payload, int $statusCode = 200): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function payrollRequireLogin(): int
{
    $userId = (int) ($_SESSION['user_id'] ?? 0);
    if ($userId <= 0) {
        payrollJson(['status' => 'error', 'message' => 'Your session has expired. Please sign in again.'], 401);
    }
    return $userId;
}

function payrollRequireCsrf(): void
{
    $provided = (string) ($_POST['csrf_token'] ?? '');
    $expected = (string) ($_SESSION['csrf_token'] ?? '');
    if ($expected === '' || !hash_equals($expected, $provided)) {
        payrollJson(['status' => 'error', 'message' => 'The request token is invalid or expired.'], 419);
    }
}

function payrollCan(mysqli $conn, string $permission): bool
{
    return checkPermission($permission, $conn);
}

function payrollRequirePermission(mysqli $conn, string $permission): void
{
    if (!payrollCan($conn, $permission)) {
        payrollJson(['status' => 'error', 'message' => 'You do not have permission to perform this Payroll action.'], 403);
    }
}

function payrollRequireAnyPermission(mysqli $conn, array $permissions): void
{
    foreach ($permissions as $permission) {
        if (payrollCan($conn, (string) $permission)) {
            return;
        }
    }
    payrollJson(['status' => 'error', 'message' => 'You do not have permission to perform this action.'], 403);
}

function payrollSchemaReady(mysqli $conn): bool
{
    $result = $conn->query("SHOW TABLES LIKE 'payroll_runs'");
    return $result && $result->num_rows === 1;
}

function payrollCurrentScope(mysqli $conn, int $userId): array
{
    $scope = hrmsCurrentScope($conn, $userId);
    $companyId = (int) ($scope['company_id'] ?? 0);
    $branchId = (int) ($scope['branch_id'] ?? 0);

    if ($companyId <= 0) {
        $result = $conn->query(
            'SELECT id FROM erp_companies WHERE status = 1 AND deleted_at IS NULL ORDER BY id LIMIT 1'
        );
        $companyId = (int) (($result ? $result->fetch_assoc()['id'] ?? 0 : 0));
    }
    if ($companyId <= 0) {
        throw new RuntimeException('No active organization is available for Payroll Management.');
    }

    return ['company_id' => $companyId, 'branch_id' => max(0, $branchId)];
}

function payrollMonth(string $value): string
{
    if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $value)) {
        throw new InvalidArgumentException('Select a valid payroll month.');
    }
    return $value;
}

function payrollDate(string $value, string $label = 'date'): string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) {
        throw new InvalidArgumentException('Select a valid ' . $label . '.');
    }
    return $value;
}

function payrollMoney(float|string|null $value): string
{
    return number_format((float) $value, 2, '.', ',');
}

function payrollAttendanceMaps(mysqli $conn, string $firstDate, string $lastDate, array $scope): array
{
    $daily = [];
    $dailySql = "SELECT daily.employee_id,
            SUM(CASE WHEN DAYOFWEEK(daily.attendance_date) = 1
                THEN CASE WHEN daily.classification IN ('on_time','late','early_leave','full_day') THEN 1
                          WHEN daily.classification = 'half_day' THEN 0.5 ELSE 0 END ELSE 0 END) sunday_days,
            SUM(CASE WHEN DAYOFWEEK(daily.attendance_date) <> 1
                THEN CASE WHEN daily.classification IN ('on_time','late','early_leave','full_day') THEN 1
                          WHEN daily.classification = 'half_day' THEN 0.5 ELSE 0 END ELSE 0 END) present_days
        FROM hr_attendance_daily daily
        WHERE daily.attendance_date BETWEEN ? AND ?
          AND (daily.company_id IS NULL OR daily.company_id = ?)";
    if ((int) $scope['branch_id'] > 0) {
        $dailySql .= ' AND (daily.branch_id IS NULL OR daily.branch_id = ?)';
    }
    $dailySql .= ' GROUP BY daily.employee_id';
    $stmt = $conn->prepare($dailySql);
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    if ($branchId > 0) {
        $stmt->bind_param('ssii', $firstDate, $lastDate, $companyId, $branchId);
    } else {
        $stmt->bind_param('ssi', $firstDate, $lastDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $daily[(int) $row['employee_id']] = [
            'present_days' => (float) $row['present_days'],
            'sunday_days' => (float) $row['sunday_days'],
            'source' => 'biometric',
        ];
    }
    $stmt->close();

    $legacy = [];
    $legacyStmt = $conn->prepare(
        "SELECT attendance.employee_id,
                SUM(CASE WHEN DAYOFWEEK(attendance.attendance_date) = 1 THEN attendance.day_value ELSE 0 END) sunday_days,
                SUM(CASE WHEN DAYOFWEEK(attendance.attendance_date) <> 1 THEN attendance.day_value ELSE 0 END) present_days
         FROM (
             SELECT session.employee_id, DATE(session.in_time) attendance_date,
                    CASE WHEN MAX(CASE WHEN session.out_time IS NOT NULL THEN 1 ELSE 0 END) = 1 THEN 0.5 ELSE 1 END day_value
             FROM worker_attendance_sessions session
             WHERE session.status = 1 AND session.deleted_at IS NULL
               AND session.in_time >= ? AND session.in_time < DATE_ADD(?, INTERVAL 1 DAY)
             GROUP BY session.employee_id, DATE(session.in_time)
         ) attendance
         GROUP BY attendance.employee_id"
    );
    $legacyStmt->bind_param('ss', $firstDate, $lastDate);
    $legacyStmt->execute();
    $legacyResult = $legacyStmt->get_result();
    while ($row = $legacyResult->fetch_assoc()) {
        $legacy[(int) $row['employee_id']] = [
            'present_days' => (float) $row['present_days'],
            'sunday_days' => (float) $row['sunday_days'],
            'source' => 'legacy',
        ];
    }
    $legacyStmt->close();

    return ['daily' => $daily, 'legacy' => $legacy];
}

function payrollAdvanceMap(mysqli $conn, string $firstDate, string $lastDate): array
{
    $map = [];
    $stmt = $conn->prepare(
        "SELECT employee_id, SUM(amount) total_amount
         FROM employee_advances
         WHERE status = 1 AND deleted_at IS NULL AND issued_on BETWEEN ? AND ?
         GROUP BY employee_id"
    );
    $stmt->bind_param('ss', $firstDate, $lastDate);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $map[(int) $row['employee_id']] = (float) $row['total_amount'];
    }
    $stmt->close();
    return $map;
}

function payrollAttendanceDateMap(mysqli $conn, string $firstDate, string $lastDate, array $scope): array
{
    $map = [];
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    $sql = "SELECT daily.employee_id, daily.attendance_date, daily.classification
        FROM hr_attendance_daily daily
        WHERE daily.attendance_date BETWEEN ? AND ? AND daily.company_id = ?";
    if ($branchId > 0) {
        $sql .= ' AND (daily.branch_id IS NULL OR daily.branch_id = ?)';
    }
    $stmt = $conn->prepare($sql);
    if ($branchId > 0) {
        $stmt->bind_param('ssii', $firstDate, $lastDate, $companyId, $branchId);
    } else {
        $stmt->bind_param('ssi', $firstDate, $lastDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $value = match ($row['classification']) {
            'on_time', 'late', 'early_leave', 'full_day', 'off_day_work' => 1.0,
            'half_day' => 0.5,
            default => 0.0,
        };
        $map[(int) $row['employee_id']][$row['attendance_date']] = ['value' => $value, 'source' => 'biometric'];
    }
    $stmt->close();

    $legacySql = "SELECT session.employee_id, DATE(session.in_time) attendance_date,
            CASE WHEN MAX(CASE WHEN session.out_time IS NOT NULL THEN 1 ELSE 0 END) = 1 THEN 0.5 ELSE 1 END day_value
        FROM worker_attendance_sessions session
        INNER JOIN employees employee ON employee.id = session.employee_id AND employee.deleted_at IS NULL
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        WHERE session.status = 1 AND session.deleted_at IS NULL
          AND session.in_time >= ? AND session.in_time < DATE_ADD(?, INTERVAL 1 DAY)
          AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?";
    if ($branchId > 0) {
        $legacySql .= ' AND COALESCE(profile.branch_id, user.branch_id) = ?';
    }
    $legacySql .= ' GROUP BY session.employee_id, DATE(session.in_time)';
    $legacyStmt = $conn->prepare($legacySql);
    if ($branchId > 0) {
        $legacyStmt->bind_param('ssii', $firstDate, $lastDate, $companyId, $branchId);
    } else {
        $legacyStmt->bind_param('ssi', $firstDate, $lastDate, $companyId);
    }
    $legacyStmt->execute();
    $legacyResult = $legacyStmt->get_result();
    while ($row = $legacyResult->fetch_assoc()) {
        $employeeId = (int) $row['employee_id'];
        $date = (string) $row['attendance_date'];
        if (!isset($map[$employeeId][$date])) {
            $map[$employeeId][$date] = ['value' => (float) $row['day_value'], 'source' => 'legacy'];
        }
    }
    $legacyStmt->close();
    return $map;
}

function payrollApprovedLeaveDateMap(mysqli $conn, string $firstDate, string $lastDate, array $scope): array
{
    $map = [];
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    $sql = "SELECT application.employee_id, day.leave_date, type.is_paid, SUM(day.day_value) day_value
        FROM hr_leave_application_days day
        INNER JOIN hr_leave_applications application ON application.id = day.application_id AND application.status = 'approved'
        INNER JOIN hr_leave_types type ON type.id = application.leave_type_id AND type.status = 1
        WHERE day.leave_date BETWEEN ? AND ? AND application.company_id = ?";
    if ($branchId > 0) {
        $sql .= ' AND (application.branch_id IS NULL OR application.branch_id = ?)';
    }
    $sql .= ' GROUP BY application.employee_id, day.leave_date, type.is_paid';
    $stmt = $conn->prepare($sql);
    if ($branchId > 0) {
        $stmt->bind_param('ssii', $firstDate, $lastDate, $companyId, $branchId);
    } else {
        $stmt->bind_param('ssi', $firstDate, $lastDate, $companyId);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $employeeId = (int) $row['employee_id'];
        $date = (string) $row['leave_date'];
        $bucket = (int) $row['is_paid'] === 1 ? 'paid' : 'unpaid';
        $map[$employeeId][$date][$bucket] = min(1.0, (float) $row['day_value']);
    }
    $stmt->close();
    return $map;
}

function payrollCalculateMonth(mysqli $conn, string $month, array $scope): array
{
    $month = payrollMonth($month);
    $firstDate = $month . '-01';
    $lastDate = date('Y-m-t', strtotime($firstDate));
    $monthDays = (int) date('t', strtotime($firstDate));
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    $calendarResult = acRequireFinalizedDaysForRange($conn, $companyId, $firstDate, $lastDate);
    $calendar = $calendarResult['calendar'];
    $calendarDays = $calendarResult['days'];
    $calendarDayMap = [];
    $calendarWorkingDates = [];
    $calendarWeeklyOffDays = 0;
    $calendarHolidayDays = 0;
    foreach ($calendarDays as $calendarDay) {
        $calendarDayMap[$calendarDay['calendar_date']] = $calendarDay;
        if ((int) $calendarDay['is_working'] === 1) {
            $calendarWorkingDates[] = $calendarDay['calendar_date'];
        } elseif ($calendarDay['day_type'] === 'weekly_off') {
            $calendarWeeklyOffDays++;
        } elseif ($calendarDay['day_type'] === 'holiday') {
            $calendarHolidayDays++;
        }
    }
    $calendarWorkingDays = count($calendarWorkingDates);
    if ($calendarWorkingDays <= 0) {
        throw new RuntimeException('The finalized calendar contains no working days for this payroll month.');
    }
    $attendance = payrollAttendanceDateMap($conn, $firstDate, $lastDate, $scope);
    $approvedLeave = payrollApprovedLeaveDateMap($conn, $firstDate, $lastDate, $scope);
    $advances = payrollAdvanceMap($conn, $firstDate, $lastDate);
    $profilePfColumn = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'pf_category'");
    $salaryPfColumn = $conn->query("SHOW COLUMNS FROM employee_salaries LIKE 'pf_category'");
    $pfCategorySelect = $profilePfColumn && $profilePfColumn->num_rows === 1
        && $salaryPfColumn && $salaryPfColumn->num_rows === 1
        ? 'salary.pf_category'
        : 'NULL';

    $employeeSql = "SELECT employee.id, employee.emp_code, employee.first_name, employee.last_name,
            employee.date_of_join, employee.last_working_date, employee.is_pf_allowed, employee.uan_no,
            employee.is_esic_allowed, employee.esic_no, employee.bank_account_number,
            bank.bank_name, salary.basic_salary, salary.base_salary_pf_esi,
            {$pfCategorySelect} AS pf_category,
            COALESCE(NULLIF(CASE WHEN salary.status = 1 THEN (
                SELECT SUM(component.monthly_amount)
                FROM hr_salary_components component
                WHERE component.employee_id = employee.id AND component.status = 1 AND component.is_deduction = 0
            ) ELSE 0 END, 0), COALESCE(salary.basic_salary,0) + COALESCE(salary.hra,0)
                + COALESCE(salary.conveyance_allowance,0) + COALESCE(salary.medical_allowance,0)
                + COALESCE(salary.special_allowance,0) + COALESCE(salary.incentives,0), 0) AS monthly_salary,
            COALESCE(profile.company_id, user.company_id, legacy_company.id) company_id,
            COALESCE(profile.branch_id, user.branch_id, 0) branch_id
        FROM employees employee
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        LEFT JOIN employee_salaries salary ON salary.id = (
            SELECT salary_match.id FROM employee_salaries salary_match
            WHERE salary_match.employee_id = employee.id
              AND salary_match.status IN (0, 1) AND salary_match.deleted_at IS NULL
              AND salary_match.effective_from <= ?
              AND (salary_match.effective_to IS NULL OR salary_match.effective_to >= ?)
            ORDER BY salary_match.effective_from DESC, salary_match.id DESC LIMIT 1
        )
        LEFT JOIN banks bank ON bank.id = employee.bank_id
        WHERE employee.status != 3 AND employee.deleted_at IS NULL
          AND (employee.date_of_join IS NULL OR employee.date_of_join <= ?)
          AND (employee.last_working_date IS NULL OR employee.last_working_date >= ?)
                    AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?";
    if ($branchId > 0) {
                $employeeSql .= ' AND COALESCE(profile.branch_id, user.branch_id) = ?';
    }
    $employeeSql .= ' ORDER BY employee.first_name, employee.last_name, employee.id';
    $stmt = $conn->prepare($employeeSql);
    if ($branchId > 0) {
        $stmt->bind_param('ssssii', $lastDate, $firstDate, $lastDate, $firstDate, $companyId, $branchId);
    } else {
        $stmt->bind_param('ssssi', $lastDate, $firstDate, $lastDate, $firstDate, $companyId);
    }
    $stmt->execute();
    $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $rows = [];
    $totals = [
        'monthly_salary' => 0.0,
        'gross_earned' => 0.0,
        'actual_salary' => 0.0,
        'pf_amount' => 0.0,
        'esic_amount' => 0.0,
        'advance_taken' => 0.0,
    ];
    $validation = [];

    foreach ($employees as $employee) {
        $employeeId = (int) $employee['id'];
        $effectiveStart = $firstDate;
        if (!empty($employee['date_of_join']) && $employee['date_of_join'] > $effectiveStart) {
            $effectiveStart = $employee['date_of_join'];
        }
        $effectiveEnd = $lastDate;
        if (!empty($employee['last_working_date']) && $employee['last_working_date'] < $effectiveEnd) {
            $effectiveEnd = $employee['last_working_date'];
        }
        if ($effectiveStart > $effectiveEnd) {
            continue;
        }

        $eligibleWorkingDays = 0.0;
        $presentWorkingDays = 0.0;
        $paidLeaveDays = 0.0;
        $unpaidLeaveDays = 0.0;
        $offDayWorked = 0.0;
        $attendanceSource = 'legacy';
        foreach ($calendarDayMap as $date => $calendarDay) {
            if ($date < $effectiveStart || $date > $effectiveEnd) {
                continue;
            }
            $attendanceValue = min(1.0, max(0.0, (float) ($attendance[$employeeId][$date]['value'] ?? 0.0)));
            if (($attendance[$employeeId][$date]['source'] ?? '') === 'biometric') {
                $attendanceSource = 'biometric';
            }
            if ((int) $calendarDay['is_working'] !== 1) {
                $offDayWorked += $attendanceValue;
                continue;
            }
            $eligibleWorkingDays += 1.0;
            $presentWorkingDays += $attendanceValue;
            $remaining = max(0.0, 1.0 - $attendanceValue);
            $paidValue = min($remaining, max(0.0, (float) ($approvedLeave[$employeeId][$date]['paid'] ?? 0.0)));
            $paidLeaveDays += $paidValue;
            $remaining -= $paidValue;
            $unpaidValue = min($remaining, max(0.0, (float) ($approvedLeave[$employeeId][$date]['unpaid'] ?? 0.0)));
            $unpaidLeaveDays += $unpaidValue;
        }
        $monthlySalary = (float) ($employee['monthly_salary'] ?? $employee['basic_salary'] ?? 0);
        $dailySalary = round($monthlySalary / $calendarWorkingDays, 2);
        $paidDays = min($eligibleWorkingDays, $presentWorkingDays + $paidLeaveDays);
        $lopDays = max(0.0, $eligibleWorkingDays - $paidDays);
        $grossEarned = round(($paidDays * $dailySalary) + ($offDayWorked * $dailySalary), 2);
        $ratio = $calendarWorkingDays > 0 ? min($paidDays / $calendarWorkingDays, 1) : 0.0;
        $pfAmount = 0.0;
        $pfCategory = strtolower(trim((string) ($employee['pf_category'] ?? '')));
        if (in_array($pfCategory, ['e', 'w', 'ew'], true)) {
            $pfAmount = hrmsCalculatePfAmount($pfCategory);
        } elseif ((int) $employee['is_pf_allowed'] === 1
            && (float) $employee['base_salary_pf_esi'] > 0
            && trim((string) $employee['uan_no']) !== '') {
            $pfAmount = round(((float) $employee['base_salary_pf_esi'] * 0.12) * $ratio, 2);
        }
        $esicAmount = hrmsCalculateEsicAmount($grossEarned);
        $advanceTaken = round((float) ($advances[$employeeId] ?? 0), 2);
        $actualSalary = max(0, round($grossEarned - $pfAmount - $esicAmount - $advanceTaken, 2));
        $employeeName = trim((string) $employee['first_name'] . ' ' . (string) $employee['last_name']);

        $issues = [];
        if ($monthlySalary <= 0) {
            $issues[] = 'salary';
        }
        if (trim((string) $employee['bank_account_number']) === '' || trim((string) $employee['bank_name']) === '') {
            $issues[] = 'bank details';
        }
        if ($issues !== []) {
            $validation[] = ($employee['emp_code'] ?: $employeeName) . ': missing ' . implode(' and ', $issues);
        }

        $row = [
            'employee_id' => $employeeId,
            'employee_code' => (string) ($employee['emp_code'] ?? ''),
            'employee_name' => $employeeName,
            'monthly_salary' => $monthlySalary,
            'gross_earned' => $grossEarned,
            'actual_salary' => $actualSalary,
            'present_days' => round($presentWorkingDays + $offDayWorked, 2),
            'month_days' => $monthDays,
            'calendar_working_days' => $calendarWorkingDays,
            'eligible_working_days' => round($eligibleWorkingDays, 2),
            'present_working_days' => round($presentWorkingDays, 2),
            'paid_leave_days' => round($paidLeaveDays, 2),
            'unpaid_leave_days' => round($unpaidLeaveDays, 2),
            'lop_days' => round($lopDays, 2),
            'weekly_off_days' => $calendarWeeklyOffDays,
            'holiday_days' => $calendarHolidayDays,
            'off_day_worked_days' => round($offDayWorked, 2),
            'pf_amount' => $pfAmount,
            'esic_amount' => $esicAmount,
            'advance_taken' => $advanceTaken,
            'pf_category' => $pfCategory,
            'bank_account_number' => (string) ($employee['bank_account_number'] ?? ''),
            'bank_name' => (string) ($employee['bank_name'] ?? ''),
            'attendance_source' => $attendanceSource,
        ];
        $rows[] = $row;
        foreach ($totals as $key => $_) {
            $totals[$key] += (float) $row[$key];
        }
    }

    foreach ($totals as &$total) {
        $total = round($total, 2);
    }
    unset($total);

    return [
        'month' => $month,
        'first_date' => $firstDate,
        'last_date' => $lastDate,
        'month_days' => $monthDays,
        'calendar' => [
            'id' => (int) $calendar['id'],
            'revision_no' => (int) $calendar['revision_no'],
            'content_hash' => (string) $calendar['content_hash'],
            'working_days' => $calendarWorkingDays,
            'weekly_off_days' => $calendarWeeklyOffDays,
            'holiday_days' => $calendarHolidayDays,
        ],
        'rows' => $rows,
        'totals' => $totals,
        'validation' => $validation,
    ];
}

function payrollDefaultPaymentDate(mysqli $conn, string $month, array $scope): string
{
    $month = payrollMonth($month);
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    $stmt = $conn->prepare(
        'SELECT salary_day FROM payroll_settings WHERE company_id = ? AND branch_id = ? LIMIT 1'
    );
    $stmt->bind_param('ii', $companyId, $branchId);
    $stmt->execute();
    $salaryDay = (int) ($stmt->get_result()->fetch_assoc()['salary_day'] ?? 7);
    $stmt->close();
    $nextMonth = new DateTimeImmutable($month . '-01 first day of next month');
    $day = min(max(1, $salaryDay), (int) $nextMonth->format('t'));
    return $nextMonth->format('Y-m-') . str_pad((string) $day, 2, '0', STR_PAD_LEFT);
}

function payrollSavePaymentDay(mysqli $conn, array $scope, string $paymentDate, int $userId): void
{
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    $salaryDay = (int) date('j', strtotime($paymentDate));
    $stmt = $conn->prepare(
        "INSERT INTO payroll_settings (company_id, branch_id, salary_day, created_by)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE salary_day = VALUES(salary_day), updated_by = VALUES(created_by), updated_at = NOW()"
    );
    $stmt->bind_param('iiii', $companyId, $branchId, $salaryDay, $userId);
    $stmt->execute();
    $stmt->close();
}

function payrollRunRows(mysqli $conn, array $scope): array
{
    $stmt = $conn->prepare(
        "SELECT run.id, run.run_number, run.payroll_month, run.payment_date, run.employee_count,
                run.actual_salary_total, run.generated_at, run.pdf_path,
                COALESCE(user.name, '') generated_by_name
         FROM payroll_runs run
         LEFT JOIN users user ON user.id = run.generated_by
         WHERE run.company_id = ? AND run.branch_id = ?
         ORDER BY run.payroll_month DESC, run.generated_at DESC"
    );
    $companyId = (int) $scope['company_id'];
    $branchId = (int) $scope['branch_id'];
    $stmt->bind_param('ii', $companyId, $branchId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function payrollReimbursementCategories(): array
{
    return ['Travel', 'Meals', 'Accommodation', 'Medical', 'Office Supplies', 'Communication', 'Other'];
}

function payrollStoreReceipt(int $employeeId, array $upload): array
{
    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        throw new InvalidArgumentException('Attach a receipt from your phone or computer.');
    }
    if (($upload['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The receipt upload did not complete successfully.');
    }
    $size = (int) ($upload['size'] ?? 0);
    if ($size <= 0 || $size > 10 * 1024 * 1024) {
        throw new InvalidArgumentException('The receipt must be smaller than 10 MB.');
    }
    $temporaryPath = (string) ($upload['tmp_name'] ?? '');
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = (string) $finfo->file($temporaryPath);
    $extensions = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    if (!isset($extensions[$mimeType])) {
        throw new InvalidArgumentException('Receipts must be PDF, JPG, PNG, or WEBP files.');
    }
    $relativeDirectory = 'uploads/payroll/reimbursements/' . $employeeId;
    $absoluteDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDirectory);
    if (!is_dir($absoluteDirectory) && !mkdir($absoluteDirectory, 0775, true) && !is_dir($absoluteDirectory)) {
        throw new RuntimeException('Unable to prepare secure receipt storage.');
    }
    $fileName = bin2hex(random_bytes(16)) . '.' . $extensions[$mimeType];
    $absolutePath = $absoluteDirectory . DIRECTORY_SEPARATOR . $fileName;
    if (!move_uploaded_file($temporaryPath, $absolutePath)) {
        throw new RuntimeException('Unable to store the attached receipt.');
    }
    return [
        'path' => $relativeDirectory . '/' . $fileName,
        'original_name' => mb_substr((string) ($upload['name'] ?? 'receipt'), 0, 255),
        'mime_type' => $mimeType,
        'absolute_path' => $absolutePath,
    ];
}

function payrollNotifyEmployee(mysqli $conn, int $employeeId, string $title, string $message, int $createdBy, int $recordId): void
{
    $stmt = $conn->prepare('SELECT user_id FROM employees WHERE id = ? AND deleted_at IS NULL LIMIT 1');
    $stmt->bind_param('i', $employeeId);
    $stmt->execute();
    $userId = (int) ($stmt->get_result()->fetch_assoc()['user_id'] ?? 0);
    $stmt->close();
    if ($userId > 0) {
        hrmsNotify($conn, '92', 'payroll_reimbursements', $recordId, $title, $message, $createdBy, [$userId]);
    }
}
