<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/constant.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../vendor/autoload.php';

define('PAYROLL_CONTEXT', true);
require_once __DIR__ . '/payroll/payroll_common.php';
require_once __DIR__ . '/payroll/payroll_pdf.php';

$userId = (int) ($_SESSION['user_id'] ?? 0);
$type = trim((string) ($_GET['type'] ?? ''));
$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$inline = isset($_GET['inline']) && (string) $_GET['inline'] === '1';
if ($userId <= 0 || !$id || $id <= 0) {
    http_response_code(404);
    exit('File not found.');
}

$scope = payrollCurrentScope($conn, $userId);
$relativePath = null;
$mimeType = 'application/octet-stream';
$downloadName = 'download';

if ($type === 'pay-run-preview') {
    if (!payrollCan($conn, 'payroll_pay_runs_view')) {
        http_response_code(403);
        exit('You do not have permission to preview this pay run.');
    }
    $stmt = $conn->prepare(
        'SELECT run_number, payroll_month, payment_date, company_id, branch_id
         FROM payroll_runs WHERE id = ? LIMIT 1'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $run = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$run
        || (int) $run['company_id'] !== (int) $scope['company_id']
        || ((int) $scope['branch_id'] > 0 && (int) $run['branch_id'] !== (int) $scope['branch_id'])) {
        http_response_code(404);
        exit('Pay run not found.');
    }
    $itemStmt = $conn->prepare(
        'SELECT serial_number, employee_code, employee_name, monthly_salary, actual_salary,
                present_days, month_days, pf_amount, esic_amount, advance_taken,
                bank_account_number, bank_name
         FROM payroll_run_items WHERE payroll_run_id = ? ORDER BY serial_number, id'
    );
    $itemStmt->bind_param('i', $id);
    $itemStmt->execute();
    $items = $itemStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $itemStmt->close();
    if ($items === []) {
        http_response_code(404);
        exit('Pay run rows are unavailable.');
    }
    $pdf = payrollBuildFullPreviewPdf($run, $items);
    $previewName = preg_replace('/[^A-Za-z0-9_-]/', '_', (string) $run['run_number']) . '-payroll-sheet.pdf';
    header('Content-Type: application/pdf');
    header('Content-Length: ' . strlen($pdf));
    header('Content-Disposition: inline; filename="' . addcslashes($previewName, '"\\') . '"');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Cache-Control: private, no-store, max-age=0');
    echo $pdf;
    exit;
}

if ($type === 'pay-run') {
    if (!payrollCan($conn, 'payroll_pay_runs_view')) {
        http_response_code(403);
        exit('You do not have permission to download this pay run.');
    }
    $stmt = $conn->prepare(
        'SELECT run_number, pdf_path, company_id, branch_id FROM payroll_runs WHERE id = ? LIMIT 1'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $file = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$file
        || (int) $file['company_id'] !== (int) $scope['company_id']
        || ((int) $scope['branch_id'] > 0 && (int) $file['branch_id'] !== (int) $scope['branch_id'])) {
        http_response_code(404);
        exit('File not found.');
    }
    $relativePath = (string) $file['pdf_path'];
    $mimeType = 'application/pdf';
    $downloadName = preg_replace('/[^A-Za-z0-9_-]/', '_', (string) $file['run_number']) . '.pdf';
} elseif ($type === 'receipt') {
    $stmt = $conn->prepare(
        'SELECT claim.employee_id, claim.company_id, claim.branch_id, claim.receipt_path,
                claim.receipt_original_name, claim.receipt_mime_type, employee.user_id
         FROM payroll_reimbursements claim
         INNER JOIN employees employee ON employee.id = claim.employee_id
         WHERE claim.id = ? LIMIT 1'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $file = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $isOwner = $file && (int) $file['user_id'] === $userId;
    $canManage = payrollCan($conn, 'payroll_reimbursements_view')
        || payrollCan($conn, 'finance_reimbursement_claims_view');
    $sameScope = $file
        && (int) ($file['company_id'] ?? 0) === (int) $scope['company_id']
        && ((int) $scope['branch_id'] === 0 || (int) ($file['branch_id'] ?? 0) === (int) $scope['branch_id']);
    if (!$file || (!$isOwner && (!$canManage || !$sameScope))) {
        http_response_code(404);
        exit('File not found.');
    }
    $relativePath = (string) $file['receipt_path'];
    $mimeType = (string) $file['receipt_mime_type'];
    $downloadName = preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $file['receipt_original_name']);
} else {
    http_response_code(404);
    exit('File not found.');
}

$baseDirectory = realpath(__DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'payroll');
$absolutePath = realpath(__DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, (string) $relativePath));
if (!$baseDirectory || !$absolutePath || !str_starts_with($absolutePath, $baseDirectory . DIRECTORY_SEPARATOR) || !is_file($absolutePath)) {
    http_response_code(404);
    exit('The stored file is unavailable.');
}

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($absolutePath));
header('Content-Disposition: ' . ($inline && $mimeType === 'application/pdf' ? 'inline' : 'attachment') . '; filename="' . addcslashes($downloadName, '"\\') . '"');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Cache-Control: private, no-store, max-age=0');
readfile($absolutePath);
exit;
