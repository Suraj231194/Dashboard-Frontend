<?php
date_default_timezone_set('Asia/Kolkata');
session_start();
require_once "db.php";
require_once 'constant.php';
include "functions.php";
require_once __DIR__ . '/../vendor/autoload.php';

function getTenderAnalytics($conn)
{
    $analytics = [
        'pending' => 0,
        'participated' => 0,
        'rejected' => 0,
        'completed' => 0,
        'inprogress' => 0,
        'total' => 0
    ];

    $q = mysqli_query($conn, "SELECT `status`, COUNT(*) `total`
        FROM `tenders`
        WHERE `status` != 3 AND `deleted_at` IS NULL
        GROUP BY `status`");

    while ($r = mysqli_fetch_assoc($q)) {
        $analytics['total'] += $r['total'];

        match ((int)$r['status']) {
            Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Pending'] => $analytics['pending'] = $r['total'],
            Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Participated'] => $analytics['participated'] = $r['total'],
            Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Rejected'] => $analytics['rejected'] = $r['total'],
            Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['AOC'] => $analytics['completed'] = $r['total'],
            default => null
        };
    }

    return $analytics;
}

function getTenderReminders($conn)
{
    $statusNeeded = [
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Pending'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Participated'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['TechnicalOpening'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['TechnicalEvaluated'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['TechnicalQualified'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['FinancialOpening'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['FinancialEvaluated'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['FinancialQualified']
    ];
    $placeholders = implode(',', $statusNeeded);

    $where = "t.status IN ($placeholders) AND t.deleted_at IS NULL";

    $sql = "SELECT 
            t.id,
            t.tender_no,
            tin.short_name AS tender_title,
            t.status,
            DATE(COALESCE(MAX(th.performed_at), t.updated_at, t.created_at)) AS last_activity_date,
            DATE_FORMAT(COALESCE(MAX(th.performed_at), t.updated_at, t.created_at),
                '%d %b %Y %h:%i %p') AS last_activity_datetime,
            DATEDIFF(CURDATE(),
                DATE(COALESCE(MAX(th.performed_at), t.updated_at, t.created_at))) AS aging_days
        FROM tenders t
        LEFT JOIN tender_history th ON th.tender_id = t.id
        LEFT JOIN tender_institutions tin ON t.authority_name_id = tin.id
        WHERE $where
        GROUP BY t.id
        ORDER BY aging_days DESC";

    $r = mysqli_query($conn, $sql);
    $data = [];

    while ($row = mysqli_fetch_assoc($r)) {
        $data[] = $row;
    }

    return [
        'count' => count($data),
        'data' => $data
    ];
}



if (isset($_POST['getTenderDashboardData']) && $_POST['getTenderDashboardData'] == 'getTenderDashboardData') {
    header('Content-Type: application/json');

    echo json_encode([
        'status' => 'success',
        'analytics' => getTenderAnalytics($conn),
        'reminders' => getTenderReminders($conn)
    ]);
    exit;
}

if (isset($_POST['fetchTenderReminders']) && $_POST['fetchTenderReminders'] == 'fetchTenderReminders') {
    header('Content-Type: application/json');
    
    echo json_encode([
        'reminders' => getTenderReminders($conn),
        'status' => 'success'
    ]);
    exit;
}

function getUsersData($conn, $specificUser = false)
{
    if (empty($specificUser)) {
        $specificUser = $_SESSION['user_id'];
    }
    $specificUser = (int)$specificUser;
    $sql = "SELECT 
                u.id,
                u.name,
                u.email,
                u.role_id,
                r.name AS role_name,
                u.is_active,
                u.created_at
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE u.id = $specificUser
              AND u.deleted_at IS NULL";

    $q = mysqli_query($conn, $sql);

    if ($q && mysqli_num_rows($q) > 0) {
        return mysqli_fetch_assoc($q); 
    }

    return false;
}
function getUsersEmployeeData($conn, $specificUser = false)
{
    if (empty($specificUser)) {
        $specificUser = $_SESSION['user_id'] ?? 0;
    }
    $specificUser = (int)$specificUser;
    if ($specificUser <= 0) {
        return false;
    }

    $photoTable = $conn->query("SHOW TABLES LIKE 'employee_documents'");
    $photoSelect = $photoTable && $photoTable->num_rows > 0
        ? "(SELECT document.id FROM employee_documents document
            WHERE document.employee_id = emp.id AND document.document_type = 'profile_photo'
              AND document.status = 1 AND document.deleted_at IS NULL
            ORDER BY document.id DESC LIMIT 1)"
        : 'NULL';

    $sql = "SELECT emp.*,
            dsgn.name AS designation,
            {$photoSelect} AS profile_photo_id
            FROM employees emp
            LEFT JOIN designations dsgn ON emp.designation_id = dsgn.id
            WHERE (emp.user_id = $specificUser OR (emp.user_id IS NULL AND emp.email = (SELECT email FROM users WHERE id = $specificUser AND deleted_at IS NULL LIMIT 1)))
              AND emp.deleted_at IS NULL
            ORDER BY (emp.user_id = $specificUser) DESC, emp.id DESC LIMIT 1";

    $q = mysqli_query($conn, $sql);

    if ($q && mysqli_num_rows($q) > 0) {
        $row = mysqli_fetch_assoc($q);
        if (empty($row['user_id'])) {
            $conn->query("UPDATE employees SET user_id = $specificUser WHERE id = " . (int)$row['id']);
            $row['user_id'] = (string)$specificUser;
        }
        return $row;
    }
    return false;
}

if (isset($_POST['userProfileAllData']) && $_POST['userProfileAllData'] == 'userProfileAllData') {
    header('Content-Type: application/json');

    echo json_encode([
        'status' => 'success',
        'usersData' => getUsersData($conn),
        'employeeData' => getUsersEmployeeData($conn)
    ]);
    exit;
}

if (isset($_POST['loadDashboardProduction'])) {
    header('Content-Type: application/json');

    $data = getDashboardProductionTimeline($conn, ['days' => 3]);

    if (empty($data)) {
        $latestProductionIds = [];
        $latestSql = "SELECT ph.production_id, MAX(ph.action_at) AS last_action_at
            FROM production_history ph
            JOIN production_plans pp ON pp.id = ph.production_id
            WHERE ph.deleted_at IS NULL
            GROUP BY ph.production_id
            ORDER BY last_action_at DESC
            LIMIT 5";

        $latestResult = mysqli_query($conn, $latestSql);
        while ($latestResult && $row = mysqli_fetch_assoc($latestResult)) {
            $latestProductionIds[] = (int)$row['production_id'];
        }

        if (!empty($latestProductionIds)) {
            $data = getDashboardProductionTimeline($conn, [
                'production_ids' => $latestProductionIds,
            ]);
        }
    }

    echo json_encode([
        'status' => 'success',
        // 'data'   => getDashboardProductionTimeline($conn, ['days' => 3, 'production_ids' => [21,22] ])
        'data'   => $data
        // 'data'   => getDashboardProductionTimeline($conn, ['days' => 3, 'order' => 'DESC'])
    ]);
    exit;
}
