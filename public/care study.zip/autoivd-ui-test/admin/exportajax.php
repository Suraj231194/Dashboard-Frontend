<?php
date_default_timezone_set('Asia/Kolkata');
// Building a spreadsheet holds every cell in memory, so an export of a full
// list needs more headroom than an ordinary page request.
ini_set('memory_limit', '512M');
set_time_limit(300);
session_start();
require_once "db.php";
require_once 'constant.php';
include "functions.php";
if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once __DIR__ . '/hrms/annual_calendar_common.php';
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/finance/finance_common.php';
require_once __DIR__ . '/finance/finance_pdf.php';

function exportDownloadUrl($filePath)
{
    return 'exports/' . rawurlencode(basename($filePath));
}

function requireSalesOrderDownloadAccess(): void
{
    if (empty($_SESSION['user_id']) || empty($_SESSION['role_id'])) {
        http_response_code(401);
        exit('Authentication required.');
    }
    $roleId = (int)$_SESSION['role_id'];
    if (!roleHasPermission($roleId, 'store_order_received_view')
        && !roleHasPermission($roleId, 'crm_sales_order_download')) {
        http_response_code(403);
        exit('You do not have permission to download Sales Orders.');
    }
}

function exportSpreadsheetText(string $value): string
{
    return preg_match('/^[=+\-@]/', ltrim($value)) === 1 ? "'" . $value : $value;
}

function exportResolveTargetPath(string $filename, string $extension): ?string
{
    $safeName = trim((string) preg_replace('/[^A-Za-z0-9_\-]/', '_', $filename), '_');
    if ($safeName === '') {
        return null;
    }

    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir) && !mkdir($exportDir, 0775, true) && !is_dir($exportDir)) {
        return null;
    }

    return $exportDir . $safeName . '.' . $extension;
}

function exportToCSV(array $headers, array $rows, string $filename)
{
    $filePath = exportResolveTargetPath($filename, 'csv');
    if ($filePath === null) {
        return false;
    }

    $handle = fopen($filePath, 'w');
    if ($handle === false) {
        return false;
    }

    $writeRow = static function (array $values) use ($handle): void {
        $line = [];
        foreach ($values as $value) {
            $line[] = exportSpreadsheetText((string) $value);
        }
        fputcsv($handle, $line, ',', '"', '\\');
    };

    $writeRow($headers);
    foreach ($rows as $row) {
        $writeRow((array) $row);
    }
    fclose($handle);

    return exportDownloadUrl($filePath);
}

function exportToExcel(array $headers, array $rows, string $filename, string $sheetTitle = 'Sheet1')
{
    $filePath = exportResolveTargetPath($filename, 'xlsx');
    if ($filePath === null) {
        return false;
    }

    try {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Excel rejects \ / ? * [ ] in sheet names and caps the title at 31 characters.
        $safeTitle = trim((string) preg_replace('/[\\\\\/\?\*\[\]:]/', ' ', $sheetTitle));
        $sheet->setTitle($safeTitle === '' ? 'Sheet1' : mb_substr($safeTitle, 0, 31));

        $column = 'A';
        foreach ($headers as $header) {
            $sheet->setCellValue($column . '1', exportSpreadsheetText((string) $header));
            $column++;
        }

        $rowNum = 2;
        foreach ($rows as $row) {
            $column = 'A';
            foreach ((array) $row as $value) {
                $sheet->setCellValue($column . $rowNum, exportSpreadsheetText((string) $value));
                $column++;
            }
            $rowNum++;
        }

        (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save($filePath);
    } catch (\Throwable $e) {
        error_log('exportToExcel failed: ' . $e->getMessage());
        return false;
    }

    return exportDownloadUrl($filePath);
}

function exportToPDF(array $headers, array $rows, string $filename, string $title = '', string $orientation = 'P')
{
    $filePath = exportResolveTargetPath($filename, 'pdf');
    if ($filePath === null) {
        return false;
    }

    try {
        $html = '<style>
            table { width: 100%; border-collapse: collapse; font-size: 11px; }
            th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
            th { background-color: #f1f5f9; font-weight: bold; }
            h2 { text-align: center; margin-bottom: 15px; font-family: sans-serif; }
        </style>';

        if ($title !== '') {
            $html .= '<h2>' . htmlspecialchars($title) . '</h2>';
        }

        $html .= '<table><tr>';
        foreach ($headers as $header) {
            $html .= '<th>' . htmlspecialchars((string) $header) . '</th>';
        }
        $html .= '</tr>';

        foreach ($rows as $row) {
            $html .= '<tr>';
            foreach ((array) $row as $value) {
                $html .= '<td>' . htmlspecialchars((string) $value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf = new \Dompdf\Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', strtoupper($orientation) === 'L' ? 'landscape' : 'portrait');
        $dompdf->render();

        if (file_put_contents($filePath, $dompdf->output()) === false) {
            return false;
        }
    } catch (\Throwable $e) {
        error_log('exportToPDF failed: ' . $e->getMessage());
        return false;
    }

    return exportDownloadUrl($filePath);
}


if (
    (isset($_POST["exportPayrollManual"]) && !empty($_POST["exportPayrollManual"])) ||
    (isset($_POST["exportPayrollManual30052026"]) && !empty($_POST["exportPayrollManual30052026"]))
) {
    header('Content-Type: application/json'); 
    $search = trim($_POST['search'] ?? '');
    $perPage = $_POST['perPage'] ?? 10;
    $monthInput = $_POST['monthPay'] ?? date('Y-m');
    $selectedColumns = $_POST['listOfColumns'] ?? []; // array of selected columns
    $exportType = $_POST['exportType'] ?? 'csv';

    $categoryType = !empty($_POST['categoryType']) ? $_POST['categoryType'] : [];
    $selectedStatus = !empty($_POST['selectedStatus']) ? $_POST['selectedStatus'] : [];
    $companyType = !empty($_POST['companyType']) ? $_POST['companyType'] : [];


    $firstDate = date('Y-m-01', strtotime($monthInput));
    $lastDate = date('Y-m-t', strtotime($monthInput));
    $totalMonthDays = date('t', strtotime($monthInput));
    $sundays = countSundays($monthInput);
    $holidays = countHolidays($conn, $firstDate, $lastDate);
    $totalWorkingDays = $totalMonthDays;
    $totalWorkingDays = $totalMonthDays - $holidays;

    $page = 1; 
    $searchTerm = "%$search%";

    if ($perPage === "all") {
        $limit  = 1000000; 
        $offset = 0;
    } else {
        $limit  = intval($perPage);
        $offset = ($page - 1) * $limit;
    }

    // Decode JSON arrays if needed
    if (is_string($categoryType)) {
        $decoded = json_decode($categoryType, true);
        $categoryType = is_array($decoded) ? $decoded : explode(',', $categoryType);
    }
    if (is_string($companyType)) {
        $decoded = json_decode($companyType, true);
        $companyType = is_array($decoded) ? $decoded : explode(',', $companyType);
    }
    if (is_string($selectedStatus)) {
        $decoded = json_decode($selectedStatus, true);
        $selectedStatus = is_array($decoded) ? $decoded : explode(',', $selectedStatus);
    }

    // ✅ convert to integer safely
    $categoryType = array_values(array_filter(array_map('intval', $categoryType))); // safe
    $companyType = array_values(array_filter(array_map('intval', $companyType))); // safe
    $selectedStatus = array_values(array_map('intval', $selectedStatus)); // don't filter out 0

    $whereConditions = [];
    $whereParams = [];
    $whereTypes = "";

    // Common fixed conditions
    $whereConditions[] = "emp.status != 3";
    $whereConditions[] = "emp.deleted_at IS NULL";
    $whereConditions[] = "(emp.emp_code LIKE ? OR emp.first_name LIKE ? OR emp.last_name LIKE ?)";
    $whereParams[] = $searchTerm;
    $whereParams[] = $searchTerm;
    $whereParams[] = $searchTerm;
    $whereTypes .= "sss";

    // Category filter
    if (!empty($categoryType)) {
        $placeholders = implode(',', array_fill(0, count($categoryType), '?'));
        $whereConditions[] = "emp.emp_categ_type IN ($placeholders)";
        $whereParams = array_merge($whereParams, $categoryType);
        $whereTypes .= str_repeat('i', count($categoryType)); // numeric types
    }
    if (!empty($companyType)) {
        $placeholders = implode(',', array_fill(0, count($companyType), '?'));
        $whereConditions[] = "emp.company IN ($placeholders)";
        $whereParams = array_merge($whereParams, $companyType);
        $whereTypes .= str_repeat('i', count($companyType)); // numeric types
    }

    // Status filter
    if (!empty($selectedStatus)) {
        $placeholders = implode(',', array_fill(0, count($selectedStatus), '?'));
        $whereConditions[] = "emp.status IN ($placeholders)";
        $whereParams = array_merge($whereParams, $selectedStatus);
        $whereTypes .= str_repeat('i', count($selectedStatus));
    }

    // Final WHERE string
    $whereSql = implode(' AND ', $whereConditions);


    $sql ="SELECT
            `emp`.`id` AS `emp_id`,
            `emp`.`emp_code`,
            `emp`.`company` AS `company_id`,
            emp.date_of_join,
            CONCAT(`emp`.`first_name`, ' ', `emp`.`last_name`) AS `full_name`,
            `emp`.`emp_categ_type`,
            `emp`.`status` AS `emp_status`,
            `emp`.`uan_no`,
            `emp`.`esic_no`,
            `emp`.`bank_account_number`,
            `bank`.`bank_name`,
            `empsal`.`basic_salary`,
            `empsal`.`base_salary_pf_esi`,
            `emp`.`is_pf_allowed`,
            `emp`.`is_esic_allowed`,           
            COALESCE(SUM(
                CASE
                    WHEN DAYOFWEEK(att.att_date) != 1
                    THEN att.day_value
                    ELSE 0
                END
            ), 0) AS present_days,

            COALESCE(SUM(
                CASE
                    WHEN DAYOFWEEK(att.att_date) = 1
                    THEN att.day_value
                    ELSE 0
                END
            ), 0) AS sunday_worked,
            COALESCE(`empadv_summary`.`total_advances_count`, 0) AS `total_advances_count`,
            COALESCE(`empadv_summary`.`total_advance_amount`, 0) AS `total_advance_amount`
            FROM `employees` `emp`
            LEFT JOIN (
                SELECT es1.*
                FROM employee_salaries es1
                INNER JOIN (
                    SELECT employee_id, MAX(effective_from) as max_date
                    FROM employee_salaries
                    WHERE effective_from <= ?
                    AND status = 1
                    AND deleted_at IS NULL
                    GROUP BY employee_id
                ) es2
                ON es1.employee_id = es2.employee_id
                AND es1.effective_from = es2.max_date
            ) empsal
            ON empsal.employee_id = emp.id

            LEFT JOIN `banks` `bank`
            ON `emp`.`bank_id` = `bank`.`id`

            LEFT JOIN (
                SELECT 
                    employee_id,
                    DATE(in_time) as att_date,

                    CASE 
                        WHEN MAX(
                            CASE WHEN out_time IS NOT NULL
                            THEN 1 ELSE 0 END
                        ) = 1
                        THEN 0.5
                        ELSE 1
                    END as day_value

                FROM worker_attendance_sessions
                WHERE status = 1 
                AND deleted_at IS NULL

                GROUP BY employee_id, DATE(in_time)
            ) att
                ON att.employee_id = emp.id
                AND att.att_date BETWEEN ? AND ?
                AND att.att_date >= emp.date_of_join
           
            LEFT JOIN (
            SELECT `employee_id`,
                    COUNT(*) AS `total_advances_count`,
                    SUM(`amount`) AS `total_advance_amount`
            FROM `employee_advances`
            WHERE `deleted_at` IS NULL
                AND `status` = 1
                AND `issued_on` BETWEEN ? AND ?
            GROUP BY `employee_id`
            ) `empadv_summary`
            ON `empadv_summary`.`employee_id` = `emp`.`id`

            WHERE $whereSql
            GROUP BY emp.id
            HAVING (`present_days` + `sunday_worked`) > 0
            ORDER BY emp.first_name ASC
            LIMIT ?, ?";
    $stmt = $conn->prepare($sql);
    $types = "sssss" . $whereTypes . "ii";
    $params = array_merge([$lastDate, $firstDate, $lastDate, $firstDate, $lastDate], $whereParams, [$offset, $limit]);
  

    $stmt->bind_param($types, ...$params);

    $stmt->execute();
    $result = $stmt->get_result();
    $allHolidays = getHolidayDates($conn, $firstDate, $lastDate);
    $calendarDaysByCompany = [];

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $absentDays = 0;
        $pf_amount = 0;
        $esi_amount = 0;
        if ($row['date_of_join'] > $lastDate) {
            continue;
        }
        $empJoinDate = $row['date_of_join'];

        $effectiveStartDate = ($empJoinDate > $firstDate) ? $empJoinDate : $firstDate;
        $empTotalDays = (int)((strtotime($lastDate) - strtotime($effectiveStartDate)) / (60 * 60 * 24)) + 1;
        $rowCompanyId = (int) ($row['company_id'] ?? 0);
        if (!array_key_exists($rowCompanyId, $calendarDaysByCompany)) {
            $calendarResult = $rowCompanyId > 0 ? acGetFinalizedDaysForRange($conn, $rowCompanyId, $firstDate, $lastDate) : null;
            $calendarDaysByCompany[$rowCompanyId] = $calendarResult['days'] ?? null;
        }
        $companyCalendarDays = $calendarDaysByCompany[$rowCompanyId];
        $empSundays = 0;
        $empHolidays = 0;
        if (is_array($companyCalendarDays)) {
            foreach ($companyCalendarDays as $calendarDay) {
                if ($calendarDay['calendar_date'] < $effectiveStartDate || $calendarDay['calendar_date'] > $lastDate) continue;
                if ($calendarDay['day_type'] === 'weekly_off') $empSundays++;
                if ($calendarDay['day_type'] === 'holiday') $empHolidays++;
            }
        } else {
            $empSundays = countSundaysBetween($effectiveStartDate, $lastDate);
            foreach ($allHolidays as $hDate) {
                if ($hDate >= $effectiveStartDate && $hDate <= $lastDate) $empHolidays++;
            }
        }

        if ($empTotalDays <= 0) {
            $empTotalDays = 0;
        }
        $grossSalary = floatval($row['basic_salary']);
        $workingDays = $empTotalDays - $empSundays - $empHolidays;
        $presentDays = min(floatval($row['present_days']), $workingDays);
        $absentDays = max(0, $workingDays - $presentDays);
        $sundayWorked = floatval($row['sunday_worked']);
        $daySalary = ($workingDays > 0) ? round($grossSalary / ($workingDays + $empHolidays), 2) : 0;
        $paidDays = $presentDays + $empHolidays;
        $extraSundayPay = round($sundayWorked * $daySalary, 2);
        $grossSalaryForDays = round(($paidDays * $daySalary) + $extraSundayPay, 2);
        $totalPaidMonthDays = $workingDays + $empHolidays;
        $ratio = ($totalPaidMonthDays > 0) ? min($paidDays / $totalPaidMonthDays, 1) : 0;

        if ($row['is_pf_allowed'] == 1 && !empty($row['base_salary_pf_esi']) && !empty($row['uan_no'])) {
            $pf_amount = round(($row['base_salary_pf_esi'] * 0.12) * $ratio, 2);
        }

        if ($row['is_esic_allowed'] == 1 && !empty($row['base_salary_pf_esi']) && !empty($row['esic_no'])) {
            $esi_amount = round(($row['base_salary_pf_esi'] * 0.01) * $ratio, 2);
        }

        $netSalary = round($grossSalaryForDays - $pf_amount - $esi_amount - $row['total_advance_amount'], 2);
        
        $dataRow = [
            'Employee Code' => ($row['emp_code'] ? $row['emp_code'] : ''),
            'Name' => ($row['full_name'] ? $row['full_name'] : ''),
            'Category' => ($row['emp_categ_type'] ? Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'][$row['emp_categ_type']]['shortKey'] : ''),
            'Status' => ($row['emp_status'] ? Constant::EMPLOYEES['STATUS_TYPES'][$row['emp_status']]['label'] : 'Inactive'),
            'Basic Salary' => ($row['basic_salary'] ? $row['basic_salary'] : 0),
            'Day Pay' => round((float)$daySalary),
            'Working Days' => ($presentDays ? $presentDays: 0),
            'Absents' => $absentDays,
            'Week Off' => $sundays,
            'Holidays' => $holidays,
            'Gross Earned' => round((float)$grossSalaryForDays),
            'PF Amount' => round((float)$pf_amount),
            'ESIC Amount' => round((float)$esi_amount),
            'Advance Count' => ($row['total_advances_count'] ? $row['total_advances_count'] : 0),
            'Advance AMT' => ($row['total_advance_amount'] ? $row['total_advance_amount'] : 0),
            'Net Salary' => round((float)$netSalary),
            'UAN' => ($row['uan_no'] ? $row['uan_no'] : ''),
            'ESIC' => ($row['esic_no'] ? $row['esic_no'] : ''),
            'Acc No' => ($row['bank_account_number'] ? $row['bank_account_number'] : ''),
            'Bank' => ($row['bank_name'] ? $row['bank_name'] : 'Not Found'),

        ];

        // Filter columns based on selected
        if (!empty($selectedColumns)) {
            $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
        }

        $data[] = $dataRow;
    }

    $stmt->close();
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    
    $exportType = trim($_POST['exportType'] ?? 'csv');
    $monthInput = trim($_POST['monthPay'] ?? date('Y-m'));

    // Columns selected by user or default to all
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);

    // Filter data to selected columns
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "payroll_{$monthInput}_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 10) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Payroll Report - ' . htmlspecialchars($monthInput) . '</h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportOrdMgmtManual"]) && !empty($_POST["exportOrdMgmtManual"])) {
    header('Content-Type: application/json'); 
    $search = trim($_POST['search'] ?? '');
    $page = intval($_POST['page'] ?? 1);
    $perPage = $_POST['perPage'] ?? 10;
    if ($perPage !== "all") {
        $perPage = intval($perPage);
    }
    $statusType = $_POST['statusType'] ?? [];
    $fromDate = trim($_POST['fromDate'] ?? '');
    $toDate = trim($_POST['toDate'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? []; 
    $exportType = $_POST['exportType'] ?? 'csv';
    $where = "WHERE `status` NOT IN (3, 12) AND `deleted_at` IS NULL";
    $params = [];
    $types = "";
    $where .= " AND (`order_number` LIKE ? OR `client_name` LIKE ? OR `area_city` LIKE ? OR `purchase_invoice` LIKE ? OR `received_by` LIKE ?)";
    $searchTerm = "%{$search}%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= "sssss";

    if (!empty($statusType)) {
        $placeholders = implode(',', array_fill(0, count($statusType), '?'));
        $where .= " AND `status` IN ($placeholders)";
        foreach ($statusType as $st) {
            $params[] = $st;
            $types .= "i";
        }
    }

    if (!empty($fromDate) && !empty($toDate)) {
        $where .= " AND DATE(`date_order_received`) BETWEEN ? AND ?";
        $params[] = $fromDate;
        $params[] = $toDate;
        $types .= "ss";
    } elseif (!empty($fromDate)) {
        $where .= " AND DATE(`date_order_received`) >= ?";
        $params[] = $fromDate;
        $types .= "s";
    } elseif (!empty($toDate)) {
        $where .= " AND DATE(`date_order_received`) <= ?";
        $params[] = $toDate;
        $types .= "s";
    }

    $allowedSortColumns = [
        'id','created_at','date_order_received','order_number',
        'client_name','area_city','dispatch_timeline','received_by','status'
    ];

    $sortColumn = $_POST['sort_column'] ?? 'id';
    $sortOrder = strtoupper($_POST['sort_order'] ?? 'DESC');

    if (!in_array($sortColumn, $allowedSortColumns)) {
        $sortColumn = "id";
    }
    if (!in_array($sortOrder, ['ASC','DESC'])) {
        $sortOrder = "DESC";
    }

    $countSql = "SELECT COUNT(*) AS total FROM `order_received` $where";
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $totalRows = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();

    if ($perPage === "all") {
        $limit  = $totalRows;
        $offset = 0;
    } else {
        $limit  = intval($perPage);
        if ($limit <= 0) {
            $limit = 10; 
        }
        $offset = ($page - 1) * $limit;
    }


    $sql = "SELECT * FROM `order_received` $where 
            ORDER BY $sortColumn $sortOrder 
            LIMIT ?, ?";

    $params2 = $params;
    $params2[] = $offset;
    $params2[] = $limit;

    $types2 = $types . "ii";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types2, ...$params2);
    $stmt->execute();
    $result = $stmt->get_result();
    $buildTableHtml = '';

    $unitMap = [];
    $unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
    while ($row = $unitQuery->fetch_assoc()) {
        $unitMap[$row['id']] = $row['short_name'];
    }     
    
    $data = [];
    while ($row = $result->fetch_assoc()) {  
        $itemSql = "SELECT * FROM `order_received_items` WHERE `status` !=3 AND `deleted_at` IS NULL AND `order_id`= ? ";
        $itemStmt = $conn->prepare($itemSql);
        $itemStmt->bind_param('i', $row['id']);
        $itemStmt->execute();
        $itemResult = $itemStmt->get_result();
        while ($itemRow = $itemResult->fetch_assoc()) {             
            $dataRow = [
                'Timestamp' => ($row['created_at'] ? formatDateDMYTime($row['created_at']) : ''),
                'Order Number' => ($row['order_number'] ? $row['order_number'] : ''),
                'Order Date' => ($row['date_order_received'] ? formatDateDMY($row['date_order_received']) : ''),
                'Status' => ($row['status'] ? Constant::ORDER_RECEIVED['STATUS_TYPES'][$row['status']]['label'] : Constant::ORDER_RECEIVED['STATUS_TYPES'][0]['label']),
                'Client Name' => ($row['client_name'] ? $row['client_name'] : ''),
                'Product' => ($itemRow['product_name'] ? $itemRow['product_name'] : ''),
                'Qty' => ($itemRow['quantity'] ? $itemRow['quantity'] .' '. $unitMap[$itemRow['unit']] : ''),
                'Item Status' => ($itemRow['status'] ? Constant::ORDER_RECEIVED['STATUS_TYPES'][$itemRow['status']]['label'] : Constant::ORDER_RECEIVED['STATUS_TYPES'][0]['label']),
                'Area City' => ($row['area_city'] ? $row['area_city'] : ''),
                'Dispatch Timeline' => ($row['dispatch_timeline'] ? Constant::ORDER_RECEIVED['DISPATCH_TIMELINE'][$row['dispatch_timeline']]: '')
            ];
            if (!empty($selectedColumns)) {
                $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
            }

        $data[] = $dataRow;
        }
        $itemStmt->close();
    }
    $stmt->close();   
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "order_management_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Order Management </h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}


if (isset($_POST["exportStocks"]) && !empty($_POST["exportStocks"])) {
    header('Content-Type: application/json');

    $search = trim($_POST['search'] ?? '');
    $searchTerm = "%{$search}%";
    $selectedColumns = $_POST['listOfColumns'] ?? [];
    $exportType = $_POST['exportType'] ?? 'csv';

    $selectedCategs = $_POST['selectedCategs'] ?? [];
    if (is_string($selectedCategs)) {
        $selectedCategs = json_decode($selectedCategs, true);
    }
    $selectedCategs = is_array($selectedCategs) ? $selectedCategs : [];

    $selectedSubcategs = $_POST['selectedSubcategs'] ?? [];
    if (is_string($selectedSubcategs)) {
        $selectedSubcategs = json_decode($selectedSubcategs, true);
    }
    $selectedSubcategs = is_array($selectedSubcategs) ? $selectedSubcategs : [];

    $selectedGroups = array_values(array_filter(array_map('intval', $selectedCategs), function ($id) {
        return $id > 0;
    }));
    $selectedCategories = array_values(array_filter(array_map('intval', $selectedSubcategs), function ($id) {
        return $id > 0;
    }));

    $perPageRaw = $_POST['perPage'] ?? 10;
    $limit = ($perPageRaw === 'all' ? 0 : max(0, (int) $perPageRaw));
    $page = max(1, (int) ($_POST['page'] ?? 1));
    $offset = ($limit > 0) ? ($page - 1) * $limit : 0;

    $sortMap = [
        'prodcateg.name' => 'inventory_group_label',
        'prod.product_name' => 'prod.product_name',
        'qtysum.total_quantity' => 'total_quantity',
        'prod.reorder_level' => 'prod.reorder_level',
        'stock_status' => 'stock_status'
    ];
    $sortColumn = $sortMap[$_POST['sort_column'] ?? ''] ?? 'inventory_group_label';
    $sortOrder = in_array(strtolower($_POST['sort_order'] ?? ''), ['asc', 'desc'], true) ? strtoupper($_POST['sort_order']) : 'ASC';

    $whereSql = "WHERE prod.status != 3 AND prod.deleted_at IS NULL";
    $types = '';
    $params = [];

    if (!empty($selectedGroups)) {
        $whereSql .= " AND COALESCE(prod.inventory_group, prodcateg.inventory_group, 1) IN (" . implode(',', array_fill(0, count($selectedGroups), '?')) . ")";
        $types .= str_repeat('i', count($selectedGroups));
        $params = array_merge($params, $selectedGroups);
    }

    if (!empty($selectedCategories)) {
        $whereSql .= " AND prod.category_id IN (" . implode(',', array_fill(0, count($selectedCategories), '?')) . ")";
        $types .= str_repeat('i', count($selectedCategories));
        $params = array_merge($params, $selectedCategories);
    }

    $whereSql .= " AND (prodcateg.name LIKE ? OR prod.product_name LIKE ? OR prod.product_code LIKE ?)";
    $types .= 'sss';
    $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);

    $sql = "SELECT
                prod.id AS product_id,
                prod.product_code,
                prod.product_name,
                prod.reorder_level,
                prodcateg.name AS category_name,
                CASE COALESCE(prod.inventory_group, prodcateg.inventory_group, 1)
                    WHEN 1 THEN 'Finished Goods'
                    WHEN 2 THEN 'Packing Material'
                    WHEN 3 THEN 'Raw Material'
                    WHEN 4 THEN 'Consumables'
                    ELSE 'Finished Goods'
                END AS inventory_group_label,
                stdunit.short_name AS quantity_unit_name,
                COALESCE(qtysum.total_quantity, 0) AS total_quantity,
                CASE
                    WHEN COALESCE(qtysum.total_quantity, 0) <= 0 THEN 0
                    WHEN prod.reorder_level > 0 AND COALESCE(qtysum.total_quantity, 0) <= prod.reorder_level THEN 2
                    ELSE 1
                END AS stock_status
            FROM products prod
            LEFT JOIN product_categories prodcateg ON prod.category_id = prodcateg.id
            LEFT JOIN (
                SELECT product_id, SUM(quantity_available) AS total_quantity, MIN(quantity_unit) AS quantity_unit
                FROM live_stock
                WHERE status != 3 AND deleted_at IS NULL
                GROUP BY product_id
            ) qtysum ON prod.id = qtysum.product_id
            LEFT JOIN standard_units stdunit ON COALESCE(qtysum.quantity_unit, prod.unit_id) = stdunit.id
            $whereSql
            ORDER BY $sortColumn $sortOrder";

    if ($limit > 0) {
        $sql .= " LIMIT ?, ?";
        $types .= 'ii';
        $params[] = $offset;
        $params[] = $limit;
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $offset + 1;
    $data = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $totalQty = number_format((float) $row['total_quantity'], 2);
            $reorderLevel = number_format((float) ($row['reorder_level'] ?? 0), 2);
            $categoryText = $row['inventory_group_label'] ?? '';
            if (!empty($row['category_name'])) {
                $categoryText .= ($categoryText !== '' ? ' / ' : '') . $row['category_name'];
            }

            $dataRow = [
                'Sr No' => $count,
                'Product' => ($row['product_name'] ? htmlspecialchars($row['product_name']) : ''),
                'Category' => htmlspecialchars($categoryText),
                'Available Qty' => $totalQty . ' ' . ($row['quantity_unit_name'] ?? ''),
                'L/S R.L' => $reorderLevel,
                'Status' => Constant::STOCKS['STATUS_TYPES'][(int) $row['stock_status']]['label'] ?? ''
            ];

            $data[] = $dataRow;
            $count++;
        }
    }

    $stmt->close();
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }

    if (empty($selectedColumns)) {
        $selectedColumns = array_keys($data[0]);
    }

    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "inventory_management_" . time();
    $filePath = '';

    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Inventory Management </h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation);    
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}


if (isset($_POST["exportTransferTicketManual"]) && !empty($_POST["exportTransferTicketManual"])) {
    header('Content-Type: application/json'); 

    $search = trim($_POST['search'] ?? '');
    $page = intval($_POST['page'] ?? 1);
    $limit = intval($_POST['perPage'] ?? 10);
    $fromDate = trim($_POST['fromDate'] ?? '');
    $toDate = trim($_POST['toDate'] ?? '');
    $offset = ($page - 1) * $limit;
    $searchTerm = "%{$search}%";
    $exportType = $_POST['exportType'] ?? 'csv';
    $selectedColumns = $_POST['listOfColumns'] ?? [];

    $validSortColumns = ['date', 'ticket_no', 'fg_coa_no', 'code', 'batch_no', 'product_description', 'status', 'user_name'];
    $sortColumn = $_POST['sort_column'] ?? 'id';
    $sortDirection = strtoupper($_POST['sort_direction'] ?? 'DESC');

    if (!in_array($sortColumn, $validSortColumns)) {
        $sortColumn = 'id';
    }
    if (!in_array($sortDirection, ['ASC', 'DESC'])) {
        $sortDirection = 'DESC';
    }

    $buildTableHtml = '';
    $buildPaginationHtml = '';

    $dateWhere = "";
    $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
    $types = "ssss";

    if (!empty($fromDate) && !empty($toDate)) {
        $dateWhere = " AND `date` BETWEEN ? AND ? ";
        $params[] = $fromDate;
        $params[] = $toDate;
        $types .= "ss";
    } elseif (!empty($fromDate)) {
        $dateWhere = " AND `date` >= ? ";
        $params[] = $fromDate;
        $types .= "s";
    } elseif (!empty($toDate)) {
        $dateWhere = " AND `date` <= ? ";
        $params[] = $toDate;
        $types .= "s";
    }
    
    $countSql = "SELECT COUNT(*) as total 
                 FROM `transfer_ticket` 
                 WHERE `status` != 3 
                 AND `deleted_at` IS NULL
                 AND (`ticket_no` LIKE ? 
                    OR `fg_coa_no` LIKE ? 
                    OR `code` LIKE ? 
                    OR `batch_no` LIKE ?)
                 $dateWhere";

    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();

    $countResult = $countStmt->get_result();
    $totalRows = $countResult->fetch_assoc()['total'];
    $countStmt->close();

    $unitMap = [];
    $unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
    while ($row = $unitQuery->fetch_assoc()) {
        $unitMap[$row['id']] = $row['short_name'];
    }    

    $sql = "SELECT tt.*, u.name AS user_name
            FROM `transfer_ticket` tt
            LEFT JOIN `users` u ON tt.created_by = u.id
            WHERE tt.status != 3
            AND tt.deleted_at IS NULL
            AND (tt.ticket_no LIKE ?
                OR tt.fg_coa_no LIKE ?
                OR tt.code LIKE ?
                OR tt.batch_no LIKE ?)
            $dateWhere
            ORDER BY $sortColumn $sortDirection
            LIMIT ?, ?";

    $params2 = $params;
    $params2[] = $offset;
    $params2[] = $limit;

    $types2 = $types . "ii";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types2, ...$params2);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    if ($result->num_rows > 0) {
        $count = $offset + 1;
        while ($row = $result->fetch_assoc()) {           
             $dataRow = [
                'Date' => ($row['date'] ? formatDateDMY($row['date']) : ''),
                'Transfer Ticket No' => ($row['ticket_no'] ? $row['ticket_no'] : ''),
                'FG COA No' => ($row['fg_coa_no'] ? $row['fg_coa_no'] : ''),
                'Code' => ($row['code'] ? $row['code'] : ''),
                'Batch Number' => ($row['batch_no'] ? $row['batch_no'] : ''),
                'Product Description' => ($row['product_description'] ? $row['product_description'] : ''),
                'Product Code' => ($row['product_code'] ? $row['product_code'] : ''),
                'Pack Size' => ($row['pack_size'] ? $row['pack_size'] .' '. ($unitMap[$row['pack_size_unit']] ?? '') : ''),
                'MFG Date' => ($row['mfg_date'] ? formatDateDMY($row['mfg_date']) : ''),
                'EXP Date' => ($row['exp_date'] ? formatDateDMY($row['exp_date']) : ''),
                'QA Sampled' => ($row['sampled_qa'] ? $row['sampled_qa'] .' '. ($unitMap[$row['sampled_qa_unit']] ?? '') : ''),
                'Quantity Transferred' => ($row['quantity_transferred'] ? $row['quantity_transferred'] .' '. ($unitMap[$row['quantity_transferred_unit']] ?? '') : ''),
                'Created By' => ($row['user_name'] ? $row['user_name'] : 'NA')
            ];
            if (!empty($selectedColumns)) {
                $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
            }
        $data[] = $dataRow;
        }
    }
    
    if (empty($selectedColumns) && !empty($data)) {
        $selectedColumns = array_keys($data[0]);
    }
   
    $stmt->close();   
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "transfer_ticket_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Transfer Ticket</h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportGoodsReceived"]) && !empty($_POST["exportGoodsReceived"])) {
    header('Content-Type: application/json'); 
    $sortColumn = $_POST['sort_column'] ?? 'stkin.id';
    $sortOrder = strtoupper($_POST['sort_order'] ?? 'DESC');
    $allowedColumns = [
        'stkin.date_of_entry', 'prodcateg.name', 'prod.product_name',
        'sup.name', 'recemp.name', 'stkin.id'
    ];
    if (!in_array($sortColumn, $allowedColumns)) {
        $sortColumn = 'stkin.id';
    }
    if (!in_array($sortOrder, ['ASC', 'DESC'])) {
        $sortOrder = 'DESC';
    }
  
    $conditions = $_POST['conditions'] ?? [];
    if (is_string($conditions)) {
        $conditions = json_decode($conditions, true);
    }
    $conditions = array_map('intval', $conditions);

    $conditionSql = "";
    $conditionParams = [];
    if (!empty($conditions)) {
        $placeholders = implode(",", array_fill(0, count($conditions), "?"));
        $conditionSql = " AND stkin.physical_condition IN ($placeholders)";
        $conditionParams = $conditions;
    }

    $search = trim($_POST['search'] ?? '');
    $page = intval($_POST['page'] ?? 1);
    $perPageRaw = $_POST['perPage'] ?? 10;
    $limit = ($perPageRaw === 'all' ? 0 : max(0, (int) $perPageRaw));
    $offset = ($limit > 0) ? ($page - 1) * $limit : 0;
    $searchTerm = "%{$search}%";
    $selectedColumns = $_POST['listOfColumns'] ?? []; // array of selected columns
    $exportType = $_POST['exportType'] ?? 'csv';    
    $countSql = "SELECT COUNT(*) as `total` FROM `stock_inwards` stkin
            LEFT JOIN `suppliers` sup ON stkin.supplier_id = sup.id 
            LEFT JOIN `receiver_emp` recemp ON stkin.received_by = recemp.id 
            LEFT JOIN `product_categories` prodcateg ON stkin.materialtype_prodcateg_id = prodcateg.id 
            LEFT JOIN `products` prod ON stkin.product_id = prod.id 
            LEFT JOIN `users` usr ON stkin.created_by = usr.id
            WHERE stkin.status != 3 AND stkin.deleted_at IS NULL 
            AND (
                stkin.date_of_entry LIKE ? OR
                sup.name LIKE ? OR
                recemp.name LIKE ? OR
                prodcateg.name LIKE ? OR
                prod.product_name LIKE ?
            ) $conditionSql";
    $countStmt = $conn->prepare($countSql);
    $countParams = array_merge([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm], $conditionParams);
    $countBindTypes = str_repeat("s", 5) . str_repeat("i", count($conditionParams)); 
    $countStmt->bind_param($countBindTypes, ...$countParams);

    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = $countResult->fetch_assoc()['total'];
    $countStmt->close();        
    $sql = "SELECT 
                stkin.*, 
                sup.name AS supplier_name, 
                recemp.name AS received_by_name, 
                prodcateg.name AS category_name, 
                prod.product_name AS product_name, 
                stdunit.short_name AS quantity_unit_name,
                usr.email AS created_by_name
            FROM `stock_inwards` stkin 
            LEFT JOIN `suppliers` sup ON stkin.supplier_id = sup.id 
            LEFT JOIN `receiver_emp` recemp ON stkin.received_by = recemp.id 
            LEFT JOIN `product_categories` prodcateg ON stkin.materialtype_prodcateg_id = prodcateg.id 
            LEFT JOIN `products` prod ON stkin.product_id = prod.id 
            LEFT JOIN `users` usr ON stkin.created_by = usr.id
            LEFT JOIN `standard_units` stdunit ON stkin.prod_quantity_unit = stdunit.id 
            WHERE stkin.status != 3 AND stkin.deleted_at IS NULL
            AND (
                stkin.date_of_entry LIKE ? OR
                sup.name LIKE ? OR
                recemp.name LIKE ? OR
                prodcateg.name LIKE ? OR
                prod.product_name LIKE ?
            ) $conditionSql 
        ORDER BY $sortColumn $sortOrder";

    if ($limit > 0) {
        $sql .= " LIMIT ?, ?";
    }

    $stmt = $conn->prepare($sql);
    $mainParams = array_merge(
        [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm],
        $conditionParams
    );
    $mainBindTypes = str_repeat("s", 5) . str_repeat("i", count($conditionParams));

    if ($limit > 0) {
        $mainBindTypes .= 'ii';
        $mainParams[] = $offset;
        $mainParams[] = $limit;
    }

    $stmt->bind_param($mainBindTypes, ...$mainParams);

    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    while ($row = $result->fetch_assoc()) {  
        $dataRow = [
                'Timestamp' => ($row['created_at'] ? formatDateDMYTime($row['created_at']) : ''),
                'Date Of Entry' => ($row['date_of_entry'] ? formatDateDMY($row['date_of_entry']) : ''),
                'Product' => ($row['product_name'] ? $row['product_name'] : ''),
                'Quantity' => ($row['prod_quantity'] ? $row['prod_quantity'] .' '. $row['quantity_unit_name'] : ''),
                'Supplier' => ($row['supplier_name'] ? $row['supplier_name'] : ''),
                'Received By' => ($row['received_by_name'] ? $row['received_by_name'] : ''),
                'Physical Condition' => ($row['physical_condition'] ? Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'][$row['physical_condition']]['label'] : Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'][0]['label']),
                'Created By' => ($row['created_by_name'] ? $row['created_by_name'] : ''),
            ];
            if (!empty($selectedColumns)) {
                $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
            }
        $data[] = $dataRow;
        
    }
   
    $stmt->close();   
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "goods_received_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Goods Received </h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportGoodsDispatched"]) && !empty($_POST["exportGoodsDispatched"])) {
    header('Content-Type: application/json'); 
    // $sortColumn = $_POST['sort_column'] ?? 'stkin.id';
    // $sortOrder = strtoupper($_POST['sort_order'] ?? 'DESC');
    // $allowedColumns = [
    //     'stkin.date_of_entry', 'prodcateg.name', 'prod.product_name',
    //     'sup.name', 'recemp.name', 'stkin.id'
    // ];
    // if (!in_array($sortColumn, $allowedColumns)) {
    //     $sortColumn = 'stkin.id';
    // }
    // if (!in_array($sortOrder, ['ASC', 'DESC'])) {
    //     $sortOrder = 'DESC';
    // }
  
    // $conditions = $_POST['conditions'] ?? [];
    // if (is_string($conditions)) {
    //     $conditions = json_decode($conditions, true);
    // }
    // $conditions = array_map('intval', $conditions);

    // $conditionSql = "";
    // $conditionParams = [];
    // if (!empty($conditions)) {
    //     $placeholders = implode(",", array_fill(0, count($conditions), "?"));
    //     $conditionSql = " AND stkin.physical_condition IN ($placeholders)";
    //     $conditionParams = $conditions;
    // }

    // $search = trim($_POST['search'] ?? '');
    // $page = intval($_POST['page'] ?? 1);
    // $limit = intval($_POST['per_page'] ?? 10);
    // $offset = ($page - 1) * $limit;
    // $searchTerm = "%{$search}%";
    // $selectedColumns = $_POST['listOfColumns'] ?? []; // array of selected columns
    // $exportType = $_POST['exportType'] ?? 'csv';    
    // $countSql = "SELECT COUNT(*) as `total` FROM `stock_inwards` stkin
    //         LEFT JOIN `suppliers` sup ON stkin.supplier_id = sup.id 
    //         LEFT JOIN `receiver_emp` recemp ON stkin.received_by = recemp.id 
    //         LEFT JOIN `product_categories` prodcateg ON stkin.materialtype_prodcateg_id = prodcateg.id 
    //         LEFT JOIN `products` prod ON stkin.product_id = prod.id 
    //         LEFT JOIN `users` usr ON stkin.created_by = usr.id
    //         WHERE stkin.status != 3 AND stkin.deleted_at IS NULL 
    //         AND (
    //             stkin.date_of_entry LIKE ? OR
    //             sup.name LIKE ? OR
    //             recemp.name LIKE ? OR
    //             prodcateg.name LIKE ? OR
    //             prod.product_name LIKE ?
    //         ) $conditionSql";
    // $countStmt = $conn->prepare($countSql);
    // $countParams = array_merge([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm], $conditionParams);
    // $countBindTypes = str_repeat("s", 5) . str_repeat("i", count($conditionParams)); 
    // $countStmt->bind_param($countBindTypes, ...$countParams);

    // $countStmt->execute();
    // $countResult = $countStmt->get_result();
    // $totalRows = $countResult->fetch_assoc()['total'];
    // $countStmt->close();        
    // $sql = "SELECT 
    //             stkin.*, 
    //             sup.name AS supplier_name, 
    //             recemp.name AS received_by_name, 
    //             prodcateg.name AS category_name, 
    //             prod.product_name AS product_name, 
    //             stdunit.short_name AS quantity_unit_name,
    //             usr.email AS created_by_name
    //         FROM `stock_inwards` stkin 
    //         LEFT JOIN `suppliers` sup ON stkin.supplier_id = sup.id 
    //         LEFT JOIN `receiver_emp` recemp ON stkin.received_by = recemp.id 
    //         LEFT JOIN `product_categories` prodcateg ON stkin.materialtype_prodcateg_id = prodcateg.id 
    //         LEFT JOIN `products` prod ON stkin.product_id = prod.id 
    //         LEFT JOIN `users` usr ON stkin.created_by = usr.id
    //         LEFT JOIN `standard_units` stdunit ON stkin.prod_quantity_unit = stdunit.id 
    //         WHERE stkin.status != 3 AND stkin.deleted_at IS NULL
    //         AND (
    //             stkin.date_of_entry LIKE ? OR
    //             sup.name LIKE ? OR
    //             recemp.name LIKE ? OR
    //             prodcateg.name LIKE ? OR
    //             prod.product_name LIKE ?
    //         ) $conditionSql 
    //     ORDER BY $sortColumn $sortOrder";
    // $stmt = $conn->prepare($sql);
    // $mainParams = array_merge(
    //     [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm],
    //     $conditionParams
    // );    
    // $mainBindTypes = str_repeat("s", 5) . str_repeat("i", count($conditionParams));

    // $stmt->bind_param($mainBindTypes, ...$mainParams);

    // $stmt->execute();
    // $result = $stmt->get_result();

    $search = trim($_POST['search'] ?? '');
    $page = intval($_POST['page'] ?? 1);
    $perPageRaw = $_POST['perPage'] ?? 10;
    $limit = ($perPageRaw === 'all' ? 0 : max(0, (int) $perPageRaw));
    $offset = ($limit > 0) ? ($page - 1) * $limit : 0;
    $searchTerm = "%{$search}%";
    $fromDate = trim($_POST['fromDate'] ?? '');
    $toDate   = trim($_POST['toDate'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? []; 
    $exportType = $_POST['exportType'] ?? 'csv'; 
    $dispatch_type = intval($_POST['dispatch_type'] ?? 0);
    $where  = "";
    $params = [$searchTerm,$searchTerm,$searchTerm];
    $types  = "sss";

    // Date Filter Add
    if (!empty($fromDate) && !empty($toDate)) {
        $where .= " AND DATE(stkout.created_at) BETWEEN ? AND ?";
        $params[] = $fromDate;
        $params[] = $toDate;
        $types .= "ss";
    } elseif (!empty($fromDate)) {
        $where .= " AND DATE(stkout.created_at) >= ?";
        $params[] = $fromDate;
        $types .= "s";
    } elseif (!empty($toDate)) {
        $where .= " AND DATE(stkout.created_at) <= ?";
        $params[] = $toDate;
        $types .= "s";
    }

    if ($dispatch_type > 0) {
        $where .= " AND stkout.outward_type = ?";
        $params[] = $dispatch_type;
        $types .= "i";
    }
    $sortColumn = $_POST['sort_column'] ?? 'stkoutitem.id';
    $sortOrder  = strtoupper($_POST['sort_order'] ?? 'DESC');

    $allowedSortColumns = [
        'created_at' => 'stkoutitem.created_at',
        'outward_type' => 'stkout.outward_type',
        'client_name' => 'stkout.client_name',
        'place_of_dispatch' => 'stkout.place_of_dispatch',
        'product_name' => 'prod.product_name',
        'category' => 'prodcateg.name',
        'issued_quantity' => 'stkoutitem.issued_quantity',
        'delivery_mode' => 'stkout.delivery_mode',
        'dispatcher' => 'remp.name'
    ];

    if (array_key_exists($sortColumn, $allowedSortColumns)) {
        $sortColumn = $allowedSortColumns[$sortColumn];
    } else {
        $sortColumn = 'stkoutitem.id';
    }

    $sortOrder = ($sortOrder === 'ASC') ? 'ASC' : 'DESC';

    $buildTableHtml = '';
    $buildPaginationHtml = '';
    // Count total records
    $countSql = "SELECT COUNT(stkoutitem.id) as total
            FROM stock_outward_items stkoutitem
            LEFT JOIN stock_outward stkout ON stkoutitem.outward_id = stkout.id
            LEFT JOIN receiver_emp remp ON stkout.dispatched_by = remp.id
            LEFT JOIN products prod ON stkoutitem.product_id = prod.id
            LEFT JOIN product_categories prodcateg ON stkoutitem.prod_categ_id = prodcateg.id
            LEFT JOIN standard_units stdunit ON stkoutitem.issued_unit = stdunit.id
            WHERE stkout.status != 3
            AND (
                stkout.client_name LIKE ? 
                OR stkout.place_of_dispatch LIKE ?
                OR prod.product_name LIKE ?
            ) $where";

    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = $countResult->fetch_assoc()['total'];
    $countStmt->close();

    $sql = "SELECT stkoutitem.*, remp.name AS dispatcher,
        stkout.id AS stkoutid,
        stkout.outward_type,
        stkout.client_name,
        stkout.place_of_dispatch,
        stkout.client_receiver_type,
        stkout.type_of_dispatch,
        stkout.delivery_mode,
        prodcateg.name AS category,
        stdunit.short_name AS short_name,
        prod.product_name,
        stkoutitem.issued_quantity,
        stkoutitem.remark,
        stkoutitem.created_at
        FROM stock_outward_items stkoutitem
        LEFT JOIN stock_outward stkout ON stkoutitem.outward_id = stkout.id
        LEFT JOIN receiver_emp remp ON stkout.dispatched_by = remp.id
        LEFT JOIN products prod ON stkoutitem.product_id = prod.id
        LEFT JOIN product_categories prodcateg ON stkoutitem.prod_categ_id = prodcateg.id
        LEFT JOIN standard_units stdunit ON stkoutitem.issued_unit = stdunit.id
        WHERE stkout.status != 3
        AND (
            stkout.client_name LIKE ? 
            OR stkout.place_of_dispatch LIKE ?
            OR prod.product_name LIKE ?
        ) $where
        ORDER BY $sortColumn $sortOrder";

    // The page size the screen sends is applied here, as the other exports do.
    // Without it every dispatched item was loaded at once, which exhausted
    // memory while building the spreadsheet or the PDF.
    if ($limit > 0) {
        $sql .= " LIMIT ?, ?";
        $types .= 'ii';
        $params[] = $offset;
        $params[] = $limit;
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $dataRow = [
                'Timestamp' => ($row['created_at'] ? formatDateDMYTime($row['created_at']) : ''),
                'Product' => ($row['product_name'] ? $row['product_name'] : ''),
                'Quantity' => ($row['issued_quantity'] ? $row['issued_quantity'] .' '. $row['short_name'] : ''),
                'Client Name' => ($row['client_name'] ? $row['client_name'] : ''),
                'Dispatch Type' => ($row['outward_type'] ? Constant::STOCKS_OUTWARDS['DISPATCH_MGMT'][$row['outward_type']] : ''),
                'City Area' => ($row['place_of_dispatch'] ? $row['place_of_dispatch'] : ''),
                'Category' => ($row['category'] ? $row['category'] : '')
            ];
            if (!empty($selectedColumns)) {
                $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
            }
        $data[] = $dataRow;
    }
   
    $stmt->close();   
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "goods_dispatched_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Goods Dispatched </h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportMaterialRequest"]) && !empty($_POST["exportMaterialRequest"])) {
    header('Content-Type: application/json'); 
    $search = trim($_POST['search'] ?? '');
    $page = intval($_POST['page'] ?? 1);
    $limit = intval($_POST['per_page'] ?? $_POST['perPage'] ?? 10);
    $offset = max(0, ($page - 1) * $limit);
    $searchTerm = "%{$search}%";
    $buildTableHtml = '';
    $buildPaginationHtml = '';
    $sortColumn = $_POST['sort_column'] ?? 'id';
    $sortOrder  = $_POST['sort_order'] ?? 'DESC';
    $selectedColumns = $_POST['listOfColumns'] ?? []; 
    $exportType = $_POST['exportType'] ?? 'csv';
    $fromDate = trim($_POST['fromDate'] ?? '');
    $toDate = trim($_POST['toDate'] ?? '');
    $allowedColumns = ['id','date','product_name','lot_batch_no','batch_size','requested_by','status'];
    if (!in_array($sortColumn, $allowedColumns)) {
        $sortColumn = 'id';
    }
    $sortOrder = ($sortOrder === 'ASC') ? 'ASC' : 'DESC';

    $isValidDate = static function (string $value): bool {
        if ($value === '') {
            return true;
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    };
    if (!$isValidDate($fromDate) || !$isValidDate($toDate) || ($fromDate !== '' && $toDate !== '' && $fromDate > $toDate)) {
        echo json_encode(['success' => 'error', 'message' => 'Please provide a valid date range.']);
        exit;
    }

    $unitMap = [];
    $unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
    while ($row = $unitQuery->fetch_assoc()) {
        $unitMap[$row['id']] = $row['short_name'];
    } 
   
    $where = "WHERE `status` != 3 AND `deleted_at` IS NULL AND (`product_name` LIKE ? OR `lot_batch_no` LIKE ?)";
    $params = [$searchTerm, $searchTerm];
    $types = 'ss';
    if ($fromDate !== '') {
        $where .= " AND DATE(`date`) >= ?";
        $params[] = $fromDate;
        $types .= 's';
    }
    if ($toDate !== '') {
        $where .= " AND DATE(`date`) <= ?";
        $params[] = $toDate;
        $types .= 's';
    }

    $countSql = "SELECT COUNT(*) as `total` FROM `material_requisition` $where";
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = $countResult->fetch_assoc()['total'];
    $countStmt->close();

    $limitSql = "";
    if ($limit > 0 && $limit < 100000000) {
        $limitSql = " LIMIT $offset, $limit";
    }
    $sql = "SELECT * FROM `material_requisition` $where ORDER BY $sortColumn $sortOrder $limitSql";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {    
        $batchSizeUnitShortName = $unitMap[$row['batch_size_unit']] ?? $row['batch_size_unit'];
        $dataRow = [
                'Timestamp' => ($row['created_at'] ? formatDateDMYTime($row['created_at']) : ''),
                'Date' => ($row['date'] ? $row['date'] : ''),
                'LOT/Batch No' => ($row['lot_batch_no'] ? $row['lot_batch_no'] : ''),
                'Product Name' => ($row['product_name'] ? $row['product_name'] : ''),
                'Batch Size' => ($row['batch_size'] ? $row['batch_size'] .' '.$batchSizeUnitShortName : ''),
                'Request By' => ($row['requested_by'] ? $row['requested_by'] : ''),
                'Status' => ($row['status'] ? Constant::MATERIAL_REQUISITION['STATUS_TYPES'][$row['status']]['label'] : Constant::MATERIAL_REQUISITION['STATUS_TYPES'][0]['label'])               
            ];
            if (!empty($selectedColumns)) {
                $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
            }
        $data[] = $dataRow;
    }
   
    $stmt->close();   
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "material_request_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Material Request </h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportEmployeeDetails"]) && !empty($_POST["exportEmployeeDetails"])) {
    header('Content-Type: application/json');     
    $search = trim($_POST['search'] ?? '');
    $page = intval($_POST['page'] ?? 1);
    $perPage = $_POST['per_page'] ?? 10;
    $searchTerm = "%{$search}%";
    $selectedColumns = $_POST['listOfColumns'] ?? []; 
    $exportType = $_POST['exportType'] ?? 'csv'; 
    
    $categoryType = $_POST['categoryType'] ?? [];
    $selectedStatus = $_POST['selectedStatus'] ?? [];
    $selectedCompany = $_POST['selectedCompany'] ?? [];
    if (is_string($categoryType)) {
        $categoryType = json_decode($categoryType, true);
    }
    if (is_string($selectedStatus)) {
        $selectedStatus = json_decode($selectedStatus, true);
    }
    if (is_string($selectedCompany)) {
        $selectedCompany = json_decode($selectedCompany, true);
    }

    $bankMap = [];
    $bankQuery = $conn->query("SELECT `id`, `bank_name` FROM `banks`");
    while ($row = $bankQuery->fetch_assoc()) {
        $bankMap[$row['id']] = $row['bank_name'];
    } 
    $designationMap = [];
    $designationQuery = $conn->query("SELECT `id`, `name` FROM `designations`");
    while ($row = $designationQuery->fetch_assoc()) {
        $designationMap[$row['id']] = $row['name'];
    } 
    $allowedSortColumns = ['emp_code', 'first_name', 'email', 'emp_categ_type'];
    $sortColumn = $_POST['sort_column'] ?? 'first_name';
    $sortOrder  = strtoupper($_POST['sort_order'] ?? 'ASC');

    if (!in_array($sortColumn, $allowedSortColumns)) $sortColumn = 'first_name';
    if (!in_array($sortOrder, ['ASC', 'DESC'])) $sortOrder = 'ASC';

    $where = "WHERE e.status != 3 
              AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.emp_code LIKE ? OR e.email LIKE ?)";

    $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
    $types  = "ssss";

    if (!empty($categoryType)) {
        $inCat = implode(',', array_fill(0, count($categoryType), '?'));
        $where .= " AND e.emp_categ_type IN ($inCat)";
        $types .= str_repeat('i', count($categoryType));
        $params = array_merge($params, $categoryType);
    }

    if (!empty($selectedStatus)) {
        $inStatus = implode(',', array_fill(0, count($selectedStatus), '?'));
        $where .= " AND e.status IN ($inStatus)";
        $types .= str_repeat('i', count($selectedStatus));
        $params = array_merge($params, $selectedStatus);
    }

    if (!empty($selectedCompany)) {
        $inStatus = implode(',', array_fill(0, count($selectedCompany), '?'));
        $where .= " AND e.company IN ($inStatus)";
        $types .= str_repeat('i', count($selectedCompany));
        $params = array_merge($params, $selectedCompany);
    }

    // Count total
    $countSql = "SELECT COUNT(*) as total FROM employees e $where";
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $totalRows = $countStmt->get_result()->fetch_assoc()['total'] ?? 0;
    $countStmt->close();

    if ($perPage === "all") {
        $limit = $totalRows;
        $offset = 0;
    } else {
        $limit = intval($perPage);
        $offset = ($page - 1) * $limit;
    }

    // Fetch records
    $sql = "SELECT e.* FROM employees e 
            $where 
            ORDER BY $sortColumn $sortOrder 
            LIMIT ?, ?";
    $stmt = $conn->prepare($sql);

    $typesWithLimit = $types . "ii";
    $paramsWithLimit = array_merge($params, [$offset, $limit]);
    $stmt->bind_param($typesWithLimit, ...$paramsWithLimit);
    $stmt->execute();
    $result = $stmt->get_result();

    // ============= BUILD TABLE HTML ==============
    if ($result->num_rows > 0) {
        $count = $offset + 1;
        $data = [];
        while ($row = $result->fetch_assoc()) { 
            $bankName = $bankMap[$row['bank_id']] ?? $row['bank_id'];
            $designationName = $designationMap[$row['designation_id']] ?? $row['designation_id'];
            $dataRow = [
                    'Sr No' => $count++,
                    'Employee Code' => ($row['emp_code'] ? $row['emp_code'] : ''),
                    'Name' => htmlspecialchars($row['first_name'] ?? "") .' '.htmlspecialchars($row['last_name'] ?? ""),
                    'Email' => ($row['email'] ? $row['email'] : ''),
                    'Designation' => ($row['designation_id'] ? $designationName : '-'),
                    'Company' => ($row['company'] ? Constant::EMPLOYEES['COMPANY_TYPE'][$row['company']] : '-'),
                    'Employment Type' => ($row['employment_type'] ? Constant::EMPLOYEES['EMPLOYMENT_TYPE'][$row['employment_type']] : Constant::EMPLOYEES['EMPLOYMENT_TYPE'][2]),
                    'Category' => ($row['emp_categ_type'] ? Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'][$row['emp_categ_type']]['shortKey'] : 'NA'),
                    'DOB' => ($row['dob'] ? formatDateDMY($row['dob']) : ''),
                    'DOJ' => ($row['date_of_join'] ? formatDateDMY($row['date_of_join']) : ''),
                    'Gender' => ($row['gender'] ? Constant::EMPLOYEES['GENDER'][$row['gender']] : '-'),
                    'Status' => ($row['status'] ? Constant::EMPLOYEES['STATUS_TYPES'][$row['status']]['label'] : Constant::EMPLOYEES['STATUS_TYPES'][0]['label']),
                    'Marital Status' => ($row['marital_status'] ? Constant::EMPLOYEES['MARITAL_STATUS'][$row['marital_status']] : '-'),
                    'Father Name' => ($row['fathers_name'] ? $row['fathers_name'] : '-'),
                    'Husband Name' => ($row['husband_name'] ? $row['husband_name'] : '-'),
                    'Contact' => ($row['contact_no'] ? "\t".$row['contact_no'] : '-'),
                    'Alt Contact 1' => ($row['alt_contact_no'] ? "\t".$row['alt_contact_no'] : '-'),
                    'Alt Contact 2' => ($row['alt_contact_no2'] ? "\t".$row['alt_contact_no2'] : '-'), 
                    'Local Address' => ($row['local_address'] ? "\t".$row['local_address'] : '-'), 
                    'Permanant Address' => ($row['permanent_address'] ? "\t".$row['permanent_address'] : '-'), 
                    'Aadhar'  => ($row['aadhar_no'] ? "\t".$row['aadhar_no'] : '-'),
                    'PAN' => ($row['pan_no'] ? $row['pan_no'] : '-'),
                    'UAN'     => ($row['uan_no'] ? "\t".$row['uan_no'] : '-'),
                    'ESIC'    => ($row['esic_no'] ? "\t".$row['esic_no'] : '-'),
                    'IFSC Code' => ($row['bank_ifsc_code'] ? $row['bank_ifsc_code'] : '-'),
                    'Acc No'  => ($row['bank_account_number'] ? "\t".$row['bank_account_number'] : '-'),
                    'Bank' => ($row['bank_id'] ? $bankName : '-')
                ];
                if (!empty($selectedColumns)) {
                    $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
                }
            $data[] = $dataRow;
        }        
    }
    
    $stmt->close();   
    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found']);
        exit;
    }   
    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    
    // Create export folder if not exists
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "employee_details_" . time();
    $filePath = '';

    // ===== CSV =====
    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); // headers
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    // ===== Excel =====
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Headers
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Data
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();

        // Decide orientation based on column count
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Employee Details </h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportPurchaseManagementRecords"]) && !empty($_POST["exportPurchaseManagementRecords"])) {
    header('Content-Type: application/json');     
    $search = trim($_POST['search'] ?? '');
    $searchTerm = "%{$search}%";
    $selectedColumns = $_POST['listOfColumns'] ?? []; 
    $exportType = $_POST['exportType'] ?? 'csv'; 
    $page  = max(1, intval($_POST['page'] ?? 1));
    $limit = $_POST['per_page'] ?? 10; 

    $selectedStatus = $_POST['selectedStatus'] ?? []; 
    if (is_string($selectedStatus)) {
        $selectedStatus = json_decode($selectedStatus, true);
    }
    $allowedSortColumns = [
        'created_date' => 'lowstk.created_at',
        'vendor_name'  => 'lowstk.vendor_name',
        'categories'   => 'podcateg.name',
        'products'     => 'prod.product_name',
        'critical_item'=> 'lowstk.critical_item',
        'user'         => 'user.email',
        'status'       => 'lowstk.status'
    ];

    $sortKey    = $_POST['sort_column'] ?? 'created_date';
    $sortColumn = $allowedSortColumns[$sortKey] ?? 'lowstk.created_at';

    $sortOrder = strtoupper($_POST['sort_order'] ?? 'DESC');
    if (!in_array($sortOrder, ['ASC','DESC'])) {
        $sortOrder = 'DESC';
    }
    $where = " WHERE lowstk.status != 3
               AND (lowstk.vendor_name LIKE ? OR prod.product_name LIKE ? OR podcateg.name LIKE ?)";

    $params = [$searchTerm, $searchTerm, $searchTerm];
    $types  = "sss";
   
    if (!empty($selectedStatus)) {
        $placeholders = implode(',', array_fill(0, count($selectedStatus), '?'));
        $where .= " AND lowstk.status IN ($placeholders)";
        $types .= str_repeat('i', count($selectedStatus));
        $params = array_merge($params, $selectedStatus);
    }

    $countSql = "SELECT COUNT(*) AS total
        FROM low_stocks lowstk
        LEFT JOIN products prod ON lowstk.product_id = prod.id
        LEFT JOIN product_categories podcateg ON lowstk.category_id = podcateg.id
        $where";

    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $totalRows = (int)($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $countStmt->close();

    $limitSql = "";
    $offset   = 0;

    if ($limit !== 'all') {
        $limit  = (int)$limit;
        $offset = ($page - 1) * $limit;
        $limitSql = " LIMIT ?, ?";
    }

    $sql = "SELECT
            lowstk.id AS lowstk_id,
            DATE(lowstk.created_at) AS created_date,
            lowstk.vendor_name,
            prod.product_name AS products,
            podcateg.name AS categories,
            lowstk.required_qty,
            stdunit.short_name,
            lowstk.critical_item,
            lowstk.status,
            user.email AS user
        FROM low_stocks lowstk
        LEFT JOIN standard_units stdunit ON lowstk.required_qty_unit = stdunit.id
        LEFT JOIN products prod ON lowstk.product_id = prod.id
        LEFT JOIN users user ON lowstk.created_by = user.id
        LEFT JOIN product_categories podcateg ON lowstk.category_id = podcateg.id
        $where
        ORDER BY $sortColumn $sortOrder
        $limitSql";

    if ($limit !== 'all') {
        $types .= "ii";
        $params[] = $offset;
        $params[] = $limit;
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $buildTableHtml = '';
    $count = ($limit === 'all') ? 1 : ($offset + 1);

    if ($result->num_rows > 0) {
        $count = $offset + 1;
        $data = [];
        while ($row = $result->fetch_assoc()) {
             $dataRow = [
                'Sr No' => $count++,
                'Date of Report' => ($row['created_date'] ? formatDateDMY($row['created_date']) : ''),
                'Vendor' => htmlspecialchars($row['vendor_name'] ?? '-'),
                'Category' => ($row['categories'] ? $row['categories'] : '-'),
                'Product Name' => ($row['products'] ? htmlspecialchars($row['products'] ?? "-") : '-'),
                'Req Qty' => ($row['required_qty'] ? htmlspecialchars($row['required_qty'] ?? "").' ' . htmlspecialchars($row['short_name'] ?? "")  : '-'),
                'Is Critical' => ($row['critical_item'] ? Constant::LOW_STOCK['CRITICAL_STATUS'][$row['critical_item']]['label'] : '-'),
                'Status' => ($row['status'] ? Constant::LOW_STOCK['STATUS'][$row['status']]['label'] : 'Pending'),
                'Requested By' => ($row['user'] ? htmlspecialchars($row['user'] ?? "") : 'NA')              
            ];
            if (!empty($selectedColumns)) {
                $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
            }
            $data[] = $dataRow;
        }
    }

    $selectedColumns = $_POST['listOfColumns'] ?? array_keys($data[0]);
    
    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }   
    
    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) mkdir($exportDir, 0777, true);

    $fileName = "purchase_management_" . time();
    $filePath = '';

    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\'); 
        foreach ($filteredData as $row) fputcsv($f, $row, ',', '"', '\\');
        fclose($f);

    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }

        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    }   
    elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';
        $html = '
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px;
                    text-align: left;
                }
                th {
                    background-color: #f0f0f0;
                }
                h2 {
                    text-align: center;
                    margin-bottom: 15px;
                }
            </style>
        ';

        $html .= '<h2>Purchase Management</h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';

        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars($value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation); // 👈 Set A4 + auto orientation
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    }
     else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

if (isset($_POST["exportTenderReminders"]) && !empty($_POST["exportTenderReminders"])) {
    header('Content-Type: application/json');
    $search = trim($_POST['search'] ?? '');
    $exportType = $_POST['exportType'] ?? 'csv';

    $statusNeeded = [
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Pending'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['Participated'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['TechnicalOpening'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['TechnicalEvaluated'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['TechnicalQualified'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['FinancialOpening'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['FinancialEvaluated'],
        Constant::TENDERS['BASE_STATUS_TYPE_LABEL']['FinancialQualified']
    ];
    $placeholders = implode(',', $statusNeeded);

    $where = "t.status IN ($placeholders) AND t.deleted_at IS NULL";

    if (!empty($search)) {
        $search = mysqli_real_escape_string($conn, $search);
        $where .= " AND (t.tender_no LIKE '%$search%' OR tin.short_name LIKE '%$search%')";
    }

    $sql = "SELECT 
            t.tender_no,
            tin.short_name AS tender_title,
            t.status,
            DATE_FORMAT(COALESCE(MAX(th.performed_at), t.updated_at, t.created_at), '%d %b %Y %h:%i %p') AS last_activity_datetime,
            DATEDIFF(CURDATE(), DATE(COALESCE(MAX(th.performed_at), t.updated_at, t.created_at))) AS aging_days
        FROM tenders t
        LEFT JOIN tender_history th ON th.tender_id = t.id
        LEFT JOIN tender_institutions tin ON t.authority_name_id = tin.id
        WHERE $where
        GROUP BY t.id
        ORDER BY aging_days DESC";

    $r = mysqli_query($conn, $sql);
    
    $headers = ['#', 'Tender Number', 'Institution', 'Status', 'Last Activity', 'Duration (Days)'];
    $exportData = [];
    $sr = 1;

    while ($row = mysqli_fetch_assoc($r)) {
        $statusLabel = Constant::TENDERS['BASE_STATUS_TYPE'][$row['status']]['label'] ?? 'Unknown';
        $exportData[] = [
            $sr++,
            $row['tender_no'],
            $row['tender_title'],
            $statusLabel,
            $row['last_activity_datetime'],
            $row['aging_days']
        ];
    }

    $filename = 'tender_reminders_' . time();
    if ($exportType === 'csv') {
        $fileurl = exportToCSV($headers, $exportData, $filename);
        $file = $filename . '.csv';
    } elseif ($exportType === 'excel') {
        $fileurl = exportToExcel($headers, $exportData, $filename, "Tender Reminders");
        $file = $filename . '.xlsx';
    } elseif ($exportType === 'pdf') {
        $fileurl = exportToPDF($headers, $exportData, $filename, "Tender Reminders", 'L');
        $file = $filename . '.pdf';
    } else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type.']);
        exit;
    }

    if ($fileurl) {
        echo json_encode(['success' => 'success', 'fileurl' => $fileurl, 'file' => $file, 'message' => 'File exported successfully.']);
    } else {
        echo json_encode(['success' => 'error', 'message' => 'Failed to export file.']);
    }
    exit;
}

if (isset($_POST['exportProductionBmrBpr']) && !empty($_POST['exportProductionBmrBpr'])) {
    header('Content-Type: application/json');
    $search = trim($_POST['search'] ?? '');
    $selectedFormType = trim($_POST['selectedFormType'] ?? 'all');
    $exportType = trim($_POST['exportType'] ?? 'csv');
    $selectedColumns = $_POST['listOfColumns'] ?? [];

    require_once __DIR__ . '/workflow/bmr_bpr_common.php';

    $rows = bmrBprProductionRows($conn);
    $data = [];
    foreach ($rows as $row) {
        if ($row['status_code'] !== 'QUEUED') {
            if ($selectedFormType === 'all' || $row['form_type'] === $selectedFormType) {
                $searchable = strtolower(implode(' ', [
                    $row['serial_number'],
                    $row['date'],
                    $row['product_name'],
                    $row['form_type'],
                    $row['lot_number'],
                    $row['status']
                ]));
                if (empty($search) || str_contains($searchable, strtolower($search))) {
                    $dataRow = [
                        'S.No' => $row['serial_number'],
                        'Date' => $row['date'],
                        'Product Name' => $row['product_name'],
                        'Form Type' => $row['form_label'] ?? $row['form_type'],
                        'Lot Number' => $row['lot_number'],
                        'Status' => $row['status'],
                    ];
                    if (!empty($selectedColumns)) {
                        $dataRow = array_intersect_key($dataRow, array_flip($selectedColumns));
                    }
                    $data[] = $dataRow;
                }
            }
        }
    }

    if (empty($data)) {
        echo json_encode(['success' => 'error', 'message' => 'No records found to export.']);
        exit;
    }

    $selectedColumns = !empty($_POST['listOfColumns']) ? $_POST['listOfColumns'] : array_keys($data[0]);

    $filteredData = [];
    foreach ($data as $row) {
        $filteredRow = [];
        foreach ($selectedColumns as $col) {
            if (isset($row[$col])) {
                $filteredRow[$col] = $row[$col];
            }
        }
        $filteredData[] = $filteredRow;
    }

    $exportDir = __DIR__ . '/exports/';
    if (!is_dir($exportDir)) {
        mkdir($exportDir, 0777, true);
    }

    $fileName = "production_bmr_bpr_" . time();
    $filePath = '';

    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\');
        foreach ($filteredData as $row) {
            fputcsv($f, $row, ',', '"', '\\');
        }
        fclose($f);
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, $val);
                $col++;
            }
            $rowNum++;
        }
        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    } elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '<style>
            table { width: 100%; border-collapse: collapse; font-size: 12px; }
            th, td { border: 1px solid #000; padding: 6px; text-align: left; }
            th { background-color: #f0f0f0; }
            h2 { text-align: center; margin-bottom: 15px; }
        </style>';
        $html .= '<h2>Production BMR / BPR Records</h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';
        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars((string) $value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation);
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    } else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type specified.']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as {$exportType}.",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

// Global Export Helper Function
function handleGenericDocumentExport($selectedColumns, $filteredData, $exportType, $filePrefix, $documentTitle) {
    header('Content-Type: application/json');
    $exportDir = __DIR__ . '/exports/';
    if (!file_exists($exportDir)) {
        mkdir($exportDir, 0777, true);
    }

    $fileName = $filePrefix . "_" . date('Ymd_His');
    $filePath = '';

    if (empty($selectedColumns)) {
        echo json_encode(['success' => 'error', 'message' => 'Please select at least one column to export.']);
        exit;
    }

    if ($exportType === 'csv') {
        $filePath = $exportDir . $fileName . '.csv';
        $f = fopen($filePath, 'w');
        fputcsv($f, $selectedColumns, ',', '"', '\\');
        foreach ($filteredData as $row) {
            $csvRow = [];
            foreach ($row as $val) {
                $csvRow[] = (string)$val;
            }
            fputcsv($f, $csvRow, ',', '"', '\\');
        }
        fclose($f);
    } elseif ($exportType === 'excel') {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $col = 'A';
        foreach ($selectedColumns as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }
        $rowNum = 2;
        foreach ($filteredData as $row) {
            $col = 'A';
            foreach ($row as $val) {
                $sheet->setCellValue($col . $rowNum, (string)$val);
                $col++;
            }
            $rowNum++;
        }
        $filePath = $exportDir . $fileName . '.xlsx';
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save($filePath);
    } elseif ($exportType === 'pdf') {
        $dompdf = new \Dompdf\Dompdf();
        $orientation = (count($selectedColumns) > 6) ? 'landscape' : 'portrait';
        $paperSize = 'A4';

        $html = '<style>
            table { width: 100%; border-collapse: collapse; font-size: 11px; }
            th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
            th { background-color: #f1f5f9; font-weight: bold; }
            h2 { text-align: center; margin-bottom: 15px; font-family: sans-serif; }
        </style>';
        $html .= '<h2>' . htmlspecialchars($documentTitle) . '</h2>';
        $html .= '<table><tr>';
        foreach ($selectedColumns as $colName) {
            $html .= '<th>' . htmlspecialchars($colName) . '</th>';
        }
        $html .= '</tr>';
        foreach ($filteredData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                $html .= '<td>' . htmlspecialchars((string) $value) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $dompdf->loadHtml($html);
        $dompdf->setPaper($paperSize, $orientation);
        $dompdf->render();

        $filePath = $exportDir . $fileName . '.pdf';
        file_put_contents($filePath, $dompdf->output());
    } else {
        echo json_encode(['success' => 'error', 'message' => 'Invalid export type specified.']);
        exit;
    }

    echo json_encode([
        'success' => 'success',
        'message' => "File exported successfully as " . strtoupper($exportType) . ".",
        'file' => basename($filePath),
        'fileurl' => exportDownloadUrl($filePath)
    ]);
    exit;
}

// 1. Customer Management Export
if (isset($_POST['exportCustomerManagement'])) {
    $search = trim($_POST['search'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? [];
    $exportType = $_POST['exportType'] ?? 'csv';

    $where = [];
    if (!empty($search)) {
        $searchEsc = $conn->real_escape_string($search);
        $where[] = "(c.full_name LIKE '%$searchEsc%' OR c.email LIKE '%$searchEsc%' OR c.company_name LIKE '%$searchEsc%' OR c.phone LIKE '%$searchEsc%')";
    }
    $whereSql = !empty($where) ? "WHERE " . implode(' AND ', $where) : "";

    $sql = "SELECT c.* FROM erp_customers c $whereSql ORDER BY c.id DESC";
    $res = $conn->query($sql);
    $rows = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $row = [];
            foreach ($selectedColumns as $col) {
                switch ($col) {
                    case 'Source': $row[] = $r['source'] ?? 'ERP'; break;
                    case 'Customer Name': $row[] = $r['full_name'] ?? ''; break;
                    case 'Phone': $row[] = $r['phone'] ?? ''; break;
                    case 'Company / GSTIN': $row[] = ($r['company_name'] ?? '') . ($r['gstin'] ? ' (' . $r['gstin'] . ')' : ''); break;
                    case 'Email': $row[] = $r['email'] ?? ''; break;
                    case 'Type': $row[] = strtoupper($r['customer_type'] ?? 'B2B'); break;
                    case 'Credit Limit': $row[] = number_format((float)($r['credit_limit'] ?? 0), 2); break;
                    case 'Status': $row[] = ($r['status'] == 1) ? 'Active' : 'Inactive'; break;
                    case 'Created At': $row[] = $r['created_at'] ?? ''; break;
                    default: $row[] = $r[$col] ?? ''; break;
                }
            }
            $rows[] = $row;
        }
    }
    handleGenericDocumentExport($selectedColumns, $rows, $exportType, 'customer_management', 'Customer Management Report');
}

// 2. Meeting Requests Export
if (isset($_POST['exportMeetingRequests'])) {
    $search = trim($_POST['search'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? [];
    $exportType = $_POST['exportType'] ?? 'csv';

    $where = [];
    if (!empty($search)) {
        $searchEsc = $conn->real_escape_string($search);
        $where[] = "(full_name LIKE '%$searchEsc%' OR email LIKE '%$searchEsc%' OR organization_name LIKE '%$searchEsc%' OR phone LIKE '%$searchEsc%')";
    }
    $whereSql = !empty($where) ? "WHERE " . implode(' AND ', $where) : "";

    $sql = "SELECT * FROM website_meeting_requests $whereSql ORDER BY id DESC";
    $res = $conn->query($sql);
    $rows = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $row = [];
            foreach ($selectedColumns as $col) {
                switch ($col) {
                    case 'Request ID': $row[] = $r['id'] ?? ''; break;
                    case 'Full Name': $row[] = $r['full_name'] ?? ''; break;
                    case 'Organization': $row[] = $r['organization_name'] ?? ''; break;
                    case 'Preferred Date': $row[] = $r['preferred_date'] ?? ''; break;
                    case 'Start Time': $row[] = $r['start_time'] ?? ''; break;
                    case 'End Time': $row[] = $r['end_time'] ?? ''; break;
                    case 'Email': $row[] = $r['email'] ?? ''; break;
                    case 'Phone': $row[] = $r['phone'] ?? ''; break;
                    case 'Status': $row[] = ucfirst($r['status'] ?? 'new'); break;
                    case 'Submitted At': $row[] = $r['created_at'] ?? ''; break;
                    default: $row[] = $r[$col] ?? ''; break;
                }
            }
            $rows[] = $row;
        }
    }
    handleGenericDocumentExport($selectedColumns, $rows, $exportType, 'meeting_requests', 'Meeting Requests Report');
}

// 3. Quiz Activity Feed Export
if (isset($_POST['exportQuizActivityFeed'])) {
    $search = trim($_POST['search'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? [];
    $exportType = $_POST['exportType'] ?? 'csv';

    $where = [];
    if (!empty($search)) {
        $searchEsc = $conn->real_escape_string($search);
        $where[] = "(CONCAT_WS(' ', participant_first_name, participant_last_name) LIKE '%$searchEsc%' OR participant_email LIKE '%$searchEsc%' OR participant_phone LIKE '%$searchEsc%')";
    }
    $whereSql = !empty($where) ? "WHERE " . implode(' AND ', $where) : "";

    $sql = "SELECT * FROM quiz_leads $whereSql ORDER BY id DESC";
    $res = $conn->query($sql);
    $rows = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $row = [];
            foreach ($selectedColumns as $col) {
                switch ($col) {
                    case 'Lead ID': $row[] = $r['id'] ?? ''; break;
                    case 'Full Name': $row[] = trim(($r['participant_first_name'] ?? '') . ' ' . ($r['participant_last_name'] ?? '')); break;
                    case 'Email': $row[] = $r['participant_email'] ?? ''; break;
                    case 'Phone': $row[] = $r['participant_phone'] ?? ''; break;
                    case 'Segment': $row[] = strtoupper(($r['user_type'] ?? 'common') === 'common' ? 'common' : ($r['user_type'] ?? 'B2C')); break;
                    case 'Score': $row[] = $r['score_percentage'] ?? 0; break;
                    case 'Status': $row[] = ucfirst($r['lead_status'] ?? 'submitted'); break;
                    case 'Submitted At': $row[] = $r['submitted_at'] ?? $r['created_at'] ?? ''; break;
                    default: $row[] = $r[$col] ?? ''; break;
                }
            }
            $rows[] = $row;
        }
    }
    handleGenericDocumentExport($selectedColumns, $rows, $exportType, 'quiz_activity_feed', 'Quiz Activity Feed Report');
}

// 4. Quotation Requests Export
if (isset($_POST['exportQuotationRequests'])) {
    $search = trim($_POST['search'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? [];
    $exportType = $_POST['exportType'] ?? 'csv';

    $where = ['q.deleted_at IS NULL'];
    if ($search !== '') {
        $searchEsc = $conn->real_escape_string($search);
        $where[] = "(q.quotation_number LIKE '%$searchEsc%' OR q.target_name LIKE '%$searchEsc%' OR q.target_email LIKE '%$searchEsc%' OR q.target_phone LIKE '%$searchEsc%' OR qi.product_name LIKE '%$searchEsc%')";
    }

    $sql = "SELECT q.*, GROUP_CONCAT(DISTINCT qi.product_name ORDER BY qi.id SEPARATOR ', ') AS product_names
        FROM quotation_requests q
        LEFT JOIN quotation_request_items qi ON qi.quotation_request_id = q.id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY q.id
        ORDER BY q.id DESC";
    $res = $conn->query($sql);
    $rows = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $row = [];
            foreach ($selectedColumns as $col) {
                switch ($col) {
                    case 'Quotation Number': $row[] = $r['quotation_number'] ?? ''; break;
                    case 'Website Quote ID': $row[] = $r['website_quotation_id'] ?? ''; break;
                    case 'Date': $row[] = $r['source_created_at'] ?? $r['created_at'] ?? ''; break;
                    case 'Customer Name': $row[] = $r['target_name'] ?? ''; break;
                    case 'Email': $row[] = $r['target_email'] ?? ''; break;
                    case 'Mobile': $row[] = $r['target_phone'] ?? ''; break;
                    case 'Products': $row[] = $r['product_names'] ?? ''; break;
                    case 'Quote Amount': $row[] = number_format((float) ($r['total_amount'] ?? 0), 2, '.', ''); break;
                    case 'Currency': $row[] = $r['currency'] ?? 'INR'; break;
                    case 'Status': $row[] = ucfirst($r['status'] ?? ''); break;
                    default: $row[] = $r[$col] ?? ''; break;
                }
            }
            $rows[] = $row;
        }
    }
    handleGenericDocumentExport($selectedColumns, $rows, $exportType, 'quotation_requests', 'Quotation Requests Report');
}

// 5. PI Requests Export
if (isset($_POST['exportPiRequests'])) {
    $search = trim($_POST['search'] ?? '');
    $selectedColumns = $_POST['listOfColumns'] ?? [];
    $exportType = $_POST['exportType'] ?? 'csv';

    $searchEsc = $conn->real_escape_string($search);
    $erpSearch = !empty($search) ? "AND (proinv.pi_auto_batch LIKE '%$searchEsc%' OR proinv.company_name LIKE '%$searchEsc%' OR usr.name LIKE '%$searchEsc%')" : "";
    $webSearch = !empty($search) ? "WHERE (pir.pi_number LIKE '%$searchEsc%' OR pir.target_company_name LIKE '%$searchEsc%' OR pir.target_name LIKE '%$searchEsc%' OR pir.created_by_name LIKE '%$searchEsc%')" : "";

    $sql = "SELECT * FROM (
        SELECT 
            'ERP' AS `source`,
            `proinv`.`id`,
            `proinv`.`created_at`,
            `proinv`.`enquiry_date` AS `pi_date`,
            `proinv`.`pi_auto_batch` AS `pi_number`,
            `proinv`.`company_name` AS `target_name`,
            `proinv`.`attendant_contact` AS `target_phone`,
            '' AS `target_email`,
            ROUND(COALESCE(`proinv`.`total_price`, SUM(`pii`.`total_price`), 0), 2) AS `total_amount`,
            'INR' AS `currency`,
            'Active' AS `status`,
            (`usr`.`name` COLLATE utf8mb4_unicode_ci) AS `created_by`
        FROM `proforma_invoices` AS `proinv`
        LEFT JOIN `users` AS `usr` ON `proinv`.`created_by` = `usr`.`id`
        LEFT JOIN `proforma_invoice_items` AS `pii` ON `pii`.`pi_id` = `proinv`.`id` AND `pii`.`status` != 3
        WHERE `proinv`.`status` != 3 AND `proinv`.`deleted_at` IS NULL $erpSearch
        GROUP BY `proinv`.`id`
        UNION ALL
        SELECT
            'Website' AS `source`,
            `pir`.`id`,
            `pir`.`created_at`,
            COALESCE(`pir`.`pi_date`, DATE(`pir`.`created_at`)) AS `pi_date`,
            `pir`.`pi_number`,
            COALESCE(NULLIF(`pir`.`target_company_name`, ''), `pir`.`target_name`, 'Website Customer') AS `target_name`,
            `pir`.`target_phone`,
            `pir`.`target_email`,
            ROUND(`pir`.`total_amount`, 2) AS `total_amount`,
            COALESCE(`pir`.`currency`, 'INR') AS `currency`,
            COALESCE(`pir`.`status`, 'Requested') AS `status`,
            COALESCE(NULLIF(`pir`.`created_by_name`, ''), 'Website Sync') AS `created_by`
        FROM `pi_requests` AS `pir`
        $webSearch
    ) AS unified_pi_export ORDER BY `id` DESC";

    $res = $conn->query($sql);
    $rows = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $row = [];
            foreach ($selectedColumns as $col) {
                switch ($col) {
                    case 'PI Number': $row[] = $r['pi_number'] ?? ''; break;
                    case 'Source': $row[] = $r['source'] ?? ''; break;
                    case 'Website PI ID': $row[] = ($r['source'] === 'Website') ? ($r['id'] ?? '') : '-'; break;
                    case 'Customer Name': $row[] = $r['target_name'] ?? ''; break;
                    case 'Customer Email': $row[] = $r['target_email'] ?? ''; break;
                    case 'Customer Phone': $row[] = $r['target_phone'] ?? ''; break;
                    case 'PI Date': $row[] = $r['pi_date'] ?? ''; break;
                    case 'Total Amount': $row[] = number_format((float)($r['total_amount'] ?? 0), 2); break;
                    case 'Currency': $row[] = $r['currency'] ?? 'INR'; break;
                    case 'Status': $row[] = ucfirst($r['status'] ?? 'Active'); break;
                    case 'Created By': $row[] = $r['created_by'] ?? ''; break;
                    case 'Created At': $row[] = $r['created_at'] ?? ''; break;
                    default: $row[] = $r[$col] ?? ''; break;
                }
            }
            $rows[] = $row;
        }
    }
    handleGenericDocumentExport($selectedColumns, $rows, $exportType, 'pi_requests', 'PI Management Report');
}

// 6. Sales Order Individual PDF / Excel Export (Section 6.1)
if (isset($_GET['downloadOrderPdf']) && !empty($_GET['downloadOrderPdf'])) {
    requireSalesOrderDownloadAccess();
    $orderId = (int) $_GET['downloadOrderPdf'];
    $stmt = $conn->prepare("SELECT o.*, c.email AS customer_email, c.phone AS customer_phone FROM order_received o LEFT JOIN customers c ON c.id = o.customer_id WHERE o.id = ? AND o.deleted_at IS NULL LIMIT 1");
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$order) {
        die("Sales Order not found.");
    }

    $items = [];
    $iRes = $conn->query("SELECT * FROM order_received_items WHERE order_id = {$orderId} AND deleted_at IS NULL");
    if ($iRes) {
        while ($it = $iRes->fetch_assoc()) {
            $items[] = $it;
        }
    }

    $piItems = [];
    if (!empty($order['proforma_invoice_id'])) {
        $piStmt = $conn->prepare(
            'SELECT * FROM proforma_invoice_items WHERE pi_id = ? AND status != 3 AND deleted_at IS NULL ORDER BY id'
        );
        $piId = (int)$order['proforma_invoice_id'];
        $piStmt->bind_param('i', $piId);
        $piStmt->execute();
        $piItems = $piStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $piStmt->close();
    }

    $printItems = [];
    foreach ($items as $index => $item) {
        $piItem = $piItems[$index] ?? [];
        $quantity = (float)($item['quantity'] ?? 0);
        $rate = (float)($piItem['prod_rate'] ?? 0);
        $taxable = round((float)($piItem['prod_value'] ?? ($quantity * $rate)), 2);
        $gstPercent = (float)($piItem['gst_percent'] ?? 0);
        $gstValue = round((float)($piItem['gst_val'] ?? ($taxable * $gstPercent / 100)), 2);
        $printItems[] = [
            'hsn_code' => '',
            'product_name' => (string)($item['product_name'] ?? $piItem['product'] ?? 'Product'),
            'pack_size' => (string)($piItem['pack_size'] ?? ''),
            'quantity' => $quantity,
            'free_quantity' => 0,
            'batch_number' => '',
            'manufacturing_date' => null,
            'expiry_date' => null,
            'mrp' => $rate,
            'rate' => $rate,
            'discount_percent' => 0,
            'taxable_value' => $taxable,
            'sgst_percent' => $gstPercent / 2,
            'cgst_percent' => $gstPercent / 2,
            'igst_percent' => 0,
            'sgst_value' => $gstValue / 2,
            'cgst_value' => $gstValue / 2,
            'igst_value' => 0,
            'line_total' => round((float)($piItem['total_price'] ?? ($taxable + $gstValue)), 2),
        ];
    }

    $company = [];
    $companyId = financeCurrentCompanyId($conn);
    if ($companyId) {
        $companyStmt = $conn->prepare('SELECT * FROM erp_companies WHERE id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1');
        $companyStmt->bind_param('i', $companyId);
        $companyStmt->execute();
        $company = $companyStmt->get_result()->fetch_assoc() ?: [];
        $companyStmt->close();
    }
    $taxableTotal = array_sum(array_column($printItems, 'taxable_value'));
    $cgstTotal = array_sum(array_column($printItems, 'cgst_value'));
    $sgstTotal = array_sum(array_column($printItems, 'sgst_value'));
    $document = [
        'document_type' => 'SALES_ORDER',
        'document_number' => (string)$order['order_number'],
        'document_date' => (string)($order['date_order_received'] ?: $order['created_at']),
        'po_reference' => (string)($order['purchase_invoice'] ?? ''),
        'counterparty_name' => (string)($order['client_name'] ?? ''),
        'counterparty_address' => (string)($order['customer_address_snapshot'] ?: ($order['delivery_address'] ?? '')),
        'counterparty_shipping_address' => (string)($order['delivery_address'] ?? ''),
        'counterparty_state' => (string)($order['customer_state_snapshot'] ?? ''),
        'counterparty_state_code' => (string)($order['customer_state_code_snapshot'] ?? ''),
        'counterparty_contact' => (string)($order['customer_contact_number_snapshot'] ?: ($order['customer_phone'] ?? '')),
        'counterparty_email' => (string)($order['customer_email_snapshot'] ?: ($order['customer_email'] ?? '')),
        'counterparty_gstin' => (string)($order['customer_gstin_snapshot'] ?? ''),
        'items' => $printItems,
        'subtotal' => $taxableTotal,
        'taxable_total' => $taxableTotal,
        'discount_total' => 0,
        'round_off' => round((float)$order['order_value'] - ($taxableTotal + $cgstTotal + $sgstTotal), 2),
        'cgst_total' => $cgstTotal,
        'sgst_total' => $sgstTotal,
        'igst_total' => 0,
        'grand_total' => (float)($order['order_value'] ?? 0),
        'terms_snapshot' => trim((string)($order['payment_details'] ?? '')),
        'company' => $company,
        'company_documents' => [],
        'selected_bank' => null,
    ];

    $dompdf = new \Dompdf\Dompdf();
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->loadHtml(financeBuildDocumentHtml($document));
    $dompdf->render();
    $safeOrderNumber = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string)$order['order_number']);
    $dompdf->stream('Sales_Order_' . trim($safeOrderNumber, '-') . '.pdf', ['Attachment' => false]);
    exit;

    $dompdf = new \Dompdf\Dompdf();
    $dompdf->setPaper('A4', 'portrait');

    $itemRowsHtml = '';
    $sr = 1;
    foreach ($items as $it) {
        $itemRowsHtml .= "<tr>
            <td style='text-align:center; padding: 8px; border: 1px solid #e2e8f0;'>{$sr}</td>
            <td style='padding: 8px; border: 1px solid #e2e8f0; font-weight: bold;'>" . htmlspecialchars($it['product_name'] ?? 'Product') . "</td>
            <td style='text-align:center; padding: 8px; border: 1px solid #e2e8f0;'>" . htmlspecialchars($it['quantity'] ?? '1') . "</td>
            <td style='padding: 8px; border: 1px solid #e2e8f0;'>" . htmlspecialchars($it['order_remark'] ?? '-') . "</td>
        </tr>";
        $sr++;
    }

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8'>
        <title>Sales Order - {$order['order_number']}</title>
        <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 12px; color: #1e293b; margin: 0; padding: 20px; }
            .header-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; border-bottom: 2px solid #1A4D2E; padding-bottom: 10px; }
            .order-title { font-size: 20px; font-weight: bold; color: #1A4D2E; text-transform: uppercase; margin: 0; }
            .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            .info-table td { vertical-align: top; padding: 4px; }
            .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 11px; }
            .items-table th { background-color: #1A4D2E; color: #ffffff; padding: 8px; text-align: left; font-weight: bold; }
            .footer { margin-top: 30px; border-top: 1px solid #cbd5e1; padding-top: 10px; font-size: 10px; color: #64748b; text-align: center; }
        </style>
    </head>
    <body>
        <table class='header-table'>
            <tr>
                <td>
                    <h1 class='order-title'>Sales Order</h1>
                    <div style='color: #64748b; font-size: 11px;'>Biogenix Diagnostic Systems</div>
                </td>
                <td style='text-align: right;'>
                    <div style='font-size: 14px; font-weight: bold; color: #0f172a;'>Order #: " . htmlspecialchars($order['order_number']) . "</div>
                    <div style='color: #64748b; font-size: 11px;'>Date: " . date('d M Y', strtotime($order['date_order_received'] ?: $order['created_at'])) . "</div>
                </td>
            </tr>
        </table>

        <table class='info-table'>
            <tr>
                <td style='width: 50%;'>
                    <strong style='color: #1A4D2E; text-transform: uppercase; font-size: 11px;'>Client / Customer:</strong><br>
                    <strong style='font-size: 13px;'>" . htmlspecialchars($order['client_name']) . "</strong><br>
                    " . ($order['delivery_address'] ? nl2br(htmlspecialchars($order['delivery_address'])) . "<br>" : "") . "
                    " . ($order['area_city'] ? htmlspecialchars($order['area_city']) . "<br>" : "") . "
                    " . ($order['customer_gstin_snapshot'] ? "GSTIN: " . htmlspecialchars($order['customer_gstin_snapshot']) . "<br>" : "") . "
                </td>
                <td style='width: 50%; text-align: right;'>
                    <strong style='color: #1A4D2E; text-transform: uppercase; font-size: 11px;'>Order Summary:</strong><br>
                    Order Value: <strong>₹" . number_format((float)($order['order_value'] ?? 0), 2) . "</strong><br>
                    Received By: " . htmlspecialchars($order['received_by'] ?? 'N/A') . "<br>
                    " . ($order['purchase_invoice'] ? "Ref PI: " . htmlspecialchars($order['purchase_invoice']) . "<br>" : "") . "
                </td>
            </tr>
        </table>

        <table class='items-table'>
            <thead>
                <tr>
                    <th style='width: 8%; text-align: center;'>Sr.</th>
                    <th style='width: 55%;'>Item Description</th>
                    <th style='width: 15%; text-align: center;'>Qty</th>
                    <th style='width: 22%;'>Remarks</th>
                </tr>
            </thead>
            <tbody>
                {$itemRowsHtml}
            </tbody>
        </table>

        <div class='footer'>
            This is a system generated Sales Order document from Biogenix AutoIVD ERP.
        </div>
    </body>
    </html>";

    $dompdf->loadHtml($html);
    $dompdf->render();
    $dompdf->stream("Sales_Order_{$order['order_number']}.pdf", ["Attachment" => false]);
    exit;
}

if (isset($_GET['downloadOrderExcel']) && !empty($_GET['downloadOrderExcel'])) {
    requireSalesOrderDownloadAccess();
    $orderId = (int) $_GET['downloadOrderExcel'];
    $stmt = $conn->prepare("SELECT o.* FROM order_received o WHERE o.id = ? AND o.deleted_at IS NULL LIMIT 1");
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$order) {
        die("Sales Order not found.");
    }

    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Sales Order');

    // Header info
    $sheet->setCellValueExplicit('A1', exportSpreadsheetText('Sales Order: ' . $order['order_number']), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
    $sheet->setCellValueExplicit('A2', exportSpreadsheetText('Client: ' . $order['client_name']), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
    $sheet->setCellValueExplicit('A3', exportSpreadsheetText('Date: ' . ($order['date_order_received'] ?: $order['created_at'])), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
    $sheet->setCellValueExplicit('A4', 'Order Value: INR ' . number_format((float)($order['order_value'] ?? 0), 2), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);

    // Items table header
    $sheet->setCellValue('A6', 'Sr.');
    $sheet->setCellValue('B6', 'Product Name');
    $sheet->setCellValue('C6', 'Quantity');
    $sheet->setCellValue('D6', 'Remarks');

    $iRes = $conn->query("SELECT * FROM order_received_items WHERE order_id = {$orderId} AND deleted_at IS NULL");
    $rowNum = 7;
    $sr = 1;
    if ($iRes) {
        while ($it = $iRes->fetch_assoc()) {
            $sheet->setCellValue('A' . $rowNum, $sr++);
            $sheet->setCellValueExplicit('B' . $rowNum, exportSpreadsheetText((string)$it['product_name']), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $sheet->setCellValue('C' . $rowNum, $it['quantity']);
            $sheet->setCellValueExplicit('D' . $rowNum, exportSpreadsheetText((string)($it['order_remark'] ?? '')), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $rowNum++;
        }
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    $safeOrderNumber = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string)$order['order_number']);
    header('Content-Disposition: attachment; filename="Sales_Order_' . trim($safeOrderNumber, '-') . '.xlsx"');
    header('Cache-Control: max-age=0');

    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}
