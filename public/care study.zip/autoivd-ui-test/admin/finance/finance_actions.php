<?php

declare(strict_types=1);

if (!defined('FINANCE_SHARED_AJAX_CONTEXT')) {
    http_response_code(404);
    exit;
}

requireLogin();

if (!financeSchemaReady($conn)) {
    financeJson(
        'error',
        'The Finance database migration has not been applied.',
        ['migration' => 'admin/migrations/2026_07_24_finance_module_pending.sql'],
        503
    );
}

financeValidateCsrf();

$action = trim((string) ($_POST['financeAction'] ?? ''));
$userId = (int) ($_SESSION['user_id'] ?? 0);

function financeViewPermission(string $view): string
{
    return match ($view) {
        'bill_generation' => 'finance_bill_generation_view',
        'payment_made' => 'finance_payment_made_view',
        'trade_payables' => 'finance_trade_payables_view',
        'invoice_generation' => 'finance_invoice_generation_view',
        'challan_generation' => 'finance_delivery_challan_generation_view',
        'payment_received' => 'finance_payment_received_view',
        'trade_receivables' => 'finance_trade_receivables_view',
        default => '',
    };
}

function financeManagePermissionForDocument(string $documentType): string
{
    return match ($documentType) {
        'VENDOR_BILL' => 'finance_bill_generation_manage',
        'SALES_INVOICE' => 'finance_invoice_generation_manage',
        'DELIVERY_CHALLAN' => 'finance_delivery_challan_generation_manage',
        default => '',
    };
}

function financeRequireView(mysqli $conn, string $view): void
{
    $permission = financeViewPermission($view);
    if ($permission === '') {
        financeJson('error', 'Invalid Finance screen.', [], 422);
    }
    financeRequirePermission($conn, $permission);
}

function financeRequireDocumentManage(mysqli $conn, int $documentId): array
{
    $stmt = $conn->prepare(
        "SELECT id, document_type, status, decision_status, grand_total, amount_paid,
                counterparty_type, counterparty_name, supplier_id
         FROM finance_documents
         WHERE id = ? AND deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$document) {
        financeJson('error', 'Finance document not found.', [], 404);
    }

    financeRequirePermission($conn, financeManagePermissionForDocument($document['document_type']));
    return $document;
}

function financeBind(mysqli_stmt $stmt, string $types, array &$values): void
{
    if ($types !== '') {
        $stmt->bind_param($types, ...$values);
    }
}

function financeListDocuments(mysqli $conn, string $view, int $page, int $perPage, string $search, string $sort, string $order, bool $pendingOnly = false): array
{
    $documentType = match ($view) {
        'bill_generation', 'trade_payables' => 'VENDOR_BILL',
        'invoice_generation', 'trade_receivables' => 'SALES_INVOICE',
        'challan_generation' => 'DELIVERY_CHALLAN',
        default => '',
    };
    if ($documentType === '') {
        throw new InvalidArgumentException('Invalid Finance document list.');
    }

    $where = ["fd.document_type = ?", "fd.deleted_at IS NULL"];
    $params = [$documentType];
    $types = 's';

    if ($view === 'trade_payables') {
        $where[] = "fd.status IN ('OPEN','PART_PAID')";
        $where[] = "(fd.grand_total - fd.amount_paid) > 0";
        $where[] = "fd.decision_status IN ('UNPAID','PAID')";
    } elseif ($view === 'trade_receivables') {
        $where[] = "fd.status IN ('GENERATED','OPEN','PART_PAID')";
        $where[] = "(fd.grand_total - fd.amount_paid) > 0";
    }

    if ($pendingOnly) {
        if ($documentType === 'VENDOR_BILL') {
            $where[] = "fd.decision_status IN ('PENDING','NOT_SURE')";
            $where[] = "fd.status = 'PENDING'";
        } else {
            $where[] = "fd.decision_status = 'PENDING'";
            $where[] = "fd.status IN ('PENDING','DRAFT')";
        }
    } elseif ($view === 'bill_generation') {
        // A Not Sure bill remains in the incoming queue and is also shown in
        // the lower register as Pending, matching the approved Bill workflow.
        $where[] = "fd.decision_status <> 'PENDING'";
    } elseif (in_array($view, ['invoice_generation', 'challan_generation'], true)) {
        $where[] = "fd.decision_status <> 'PENDING'";
    }

    if ($search !== '') {
        $where[] = "(
            fd.counterparty_name LIKE ?
            OR COALESCE(fd.document_number, '') LIKE ?
            OR COALESCE(fd.reference_number, '') LIKE ?
            OR COALESCE(fd.po_reference, '') LIKE ?
            OR EXISTS (
                SELECT 1 FROM finance_document_items fdi
                WHERE fdi.document_id = fd.id AND fdi.product_name LIKE ?
            )
        )";
        $needle = '%' . $search . '%';
        for ($i = 0; $i < 5; $i++) {
            $params[] = $needle;
            $types .= 's';
        }
    }

    $sortMap = [
        'date' => 'COALESCE(fd.document_date, DATE(fd.created_at))',
        'party' => 'fd.counterparty_name',
        'number' => "COALESCE(fd.document_number, fd.reference_number, '')",
        'total' => 'fd.grand_total',
        'due_date' => 'fd.due_date',
        'status' => 'fd.status',
        'created_at' => 'fd.created_at',
    ];
    $sortSql = $sortMap[$sort] ?? 'fd.id';
    $orderSql = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';
    $whereSql = implode(' AND ', $where);

    $countSql = "SELECT COUNT(*) AS total FROM finance_documents fd WHERE {$whereSql}";
    $countStmt = $conn->prepare($countSql);
    $countParams = $params;
    financeBind($countStmt, $types, $countParams);
    $countStmt->execute();
    $total = (int) ($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $countStmt->close();

    $totalPages = max(1, (int) ceil($total / max(1, $perPage)));
    $page = min(max(1, $page), $totalPages);
    $offset = ($page - 1) * $perPage;
    $sql = "
        SELECT
            fd.*,
            GREATEST(fd.grand_total - fd.amount_paid, 0) AS outstanding_amount,
            u.name AS created_by_name,
            receiver.name AS received_by_name,
            (SELECT COUNT(*) FROM finance_document_items fdi WHERE fdi.document_id = fd.id) AS item_count,
            (SELECT COALESCE(SUM(fdi.quantity * fdi.rate), 0)
             FROM finance_document_items fdi WHERE fdi.document_id = fd.id) AS reference_total,
            (SELECT GROUP_CONCAT(fdi.product_name ORDER BY fdi.sort_order SEPARATOR ', ')
             FROM finance_document_items fdi WHERE fdi.document_id = fd.id) AS product_names,
            (SELECT GROUP_CONCAT(DISTINCT NULLIF(fdi.batch_number, '') ORDER BY fdi.sort_order SEPARATOR ',')
             FROM finance_document_items fdi WHERE fdi.document_id = fd.id) AS batch_numbers,
            (SELECT COUNT(*) FROM finance_document_files fdf
             WHERE fdf.document_id = fd.id AND fdf.file_type = 'SOURCE_INVOICE') AS source_file_count,
            (SELECT id FROM finance_document_files fdf
             WHERE fdf.document_id = fd.id AND fdf.file_type = 'SOURCE_INVOICE'
             ORDER BY fdf.version_number DESC, fdf.id DESC LIMIT 1) AS source_file_id,
            (SELECT id FROM finance_document_files fdf
             WHERE fdf.document_id = fd.id AND fdf.file_type = 'GENERATED_PDF'
             ORDER BY fdf.version_number DESC, fdf.id DESC LIMIT 1) AS generated_file_id
        FROM finance_documents fd
        LEFT JOIN users u ON u.id = fd.created_by
        LEFT JOIN receiver_emp receiver ON receiver.id = fd.received_by
        WHERE {$whereSql}
        ORDER BY {$sortSql} {$orderSql}, fd.id DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $conn->prepare($sql);
    $listParams = array_merge($params, [$perPage, $offset]);
    $listTypes = $types . 'ii';
    financeBind($stmt, $listTypes, $listParams);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $pendingWhere = match ($documentType) {
        'VENDOR_BILL' => "decision_status IN ('PENDING','NOT_SURE') AND status = 'PENDING'",
        default => "decision_status = 'PENDING' AND status IN ('PENDING','DRAFT')",
    };
    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS total
         FROM finance_documents
         WHERE document_type = ? AND deleted_at IS NULL AND {$pendingWhere}"
    );
    $stmt->bind_param('s', $documentType);
    $stmt->execute();
    $pending = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();

    return [
        'rows' => $rows,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => $totalPages,
        'from' => $total ? $offset + 1 : 0,
        'to' => min($offset + $perPage, $total),
        'pending_count' => $pending,
    ];
}

function financeListPayments(mysqli $conn, string $view, int $page, int $perPage, string $search, string $sort, string $order): array
{
    $direction = $view === 'payment_made' ? 'OUTGOING' : 'INCOMING';
    $where = ['fp.direction = ?'];
    $params = [$direction];
    $types = 's';

    if ($search !== '') {
        $where[] = "(
            fp.counterparty_name LIKE ?
            OR COALESCE(fp.reference_number, '') LIKE ?
            OR fp.payment_mode LIKE ?
            OR EXISTS (
                SELECT 1
                FROM finance_payment_allocations fpa2
                JOIN finance_documents fd2 ON fd2.id = fpa2.document_id
                WHERE fpa2.payment_id = fp.id
                  AND (COALESCE(fd2.document_number, '') LIKE ? OR COALESCE(fd2.reference_number, '') LIKE ?)
            )
        )";
        $needle = '%' . $search . '%';
        for ($i = 0; $i < 5; $i++) {
            $params[] = $needle;
            $types .= 's';
        }
    }

    $sortMap = [
        'date' => 'fp.payment_date',
        'party' => 'fp.counterparty_name',
        'amount' => 'fp.amount',
        'mode' => 'fp.payment_mode',
        'status' => 'fp.status',
        'created_at' => 'fp.created_at',
    ];
    $sortSql = $sortMap[$sort] ?? 'fp.id';
    $orderSql = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';
    $whereSql = implode(' AND ', $where);

    $countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM finance_payments fp WHERE {$whereSql}");
    $countParams = $params;
    financeBind($countStmt, $types, $countParams);
    $countStmt->execute();
    $total = (int) ($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $countStmt->close();

    $totalPages = max(1, (int) ceil($total / max(1, $perPage)));
    $page = min(max(1, $page), $totalPages);
    $offset = ($page - 1) * $perPage;
    $sql = "
        SELECT
            fp.*,
            u.name AS created_by_name,
            GROUP_CONCAT(
                DISTINCT COALESCE(fd.document_number, fd.reference_number, CONCAT('Document #', fd.id))
                ORDER BY fd.id SEPARATOR ', '
            ) AS document_references,
            GROUP_CONCAT(DISTINCT fd.id ORDER BY fd.id SEPARATOR ',') AS document_ids
        FROM finance_payments fp
        LEFT JOIN finance_payment_allocations fpa ON fpa.payment_id = fp.id
        LEFT JOIN finance_documents fd ON fd.id = fpa.document_id
        LEFT JOIN users u ON u.id = fp.created_by
        WHERE {$whereSql}
        GROUP BY fp.id, u.name
        ORDER BY {$sortSql} {$orderSql}, fp.id DESC
        LIMIT ? OFFSET ?
    ";
    $stmt = $conn->prepare($sql);
    $listParams = array_merge($params, [$perPage, $offset]);
    $listTypes = $types . 'ii';
    financeBind($stmt, $listTypes, $listParams);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return [
        'rows' => $rows,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => $totalPages,
        'from' => $total ? $offset + 1 : 0,
        'to' => min($offset + $perPage, $total),
        'pending_count' => 0,
    ];
}

function financeCreatePayment(
    mysqli $conn,
    array $document,
    float $amount,
    string $paymentDate,
    string $paymentMode,
    ?string $referenceNumber,
    ?int $bankAccountId,
    ?string $notes,
    int $userId
): int {
    $documentId = (int) $document['id'];
    $total = round((float) $document['grand_total'], 2);
    $paid = round((float) $document['amount_paid'], 2);
    $outstanding = max(0.0, round($total - $paid, 2));

    if ($amount <= 0 || $amount > $outstanding + 0.001) {
        throw new RuntimeException('Payment must be greater than zero and cannot exceed the outstanding amount.');
    }

    $direction = $document['document_type'] === 'VENDOR_BILL' ? 'OUTGOING' : 'INCOMING';
    $counterpartyType = $document['document_type'] === 'VENDOR_BILL' ? 'VENDOR' : 'CLIENT';
    $supplierId = $document['supplier_id'] !== null ? (int) $document['supplier_id'] : null;
    $counterpartyName = (string) $document['counterparty_name'];
    $stmt = $conn->prepare(
        "INSERT INTO finance_payments
            (direction, counterparty_type, supplier_id, counterparty_name, payment_date,
             amount, payment_mode, reference_number, bank_account_id, notes, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'ssissdssisi',
        $direction,
        $counterpartyType,
        $supplierId,
        $counterpartyName,
        $paymentDate,
        $amount,
        $paymentMode,
        $referenceNumber,
        $bankAccountId,
        $notes,
        $userId
    );
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to record payment: ' . $error);
    }
    $paymentId = (int) $conn->insert_id;
    $stmt->close();

    $stmt = $conn->prepare(
        "INSERT INTO finance_payment_allocations (payment_id, document_id, allocated_amount)
         VALUES (?, ?, ?)"
    );
    $stmt->bind_param('iid', $paymentId, $documentId, $amount);
    $stmt->execute();
    $stmt->close();

    financeRefreshDocumentPaymentStatus($conn, $documentId, $userId);
    financeHistory(
        $conn,
        $documentId,
        'PAYMENT_RECORDED',
        $document['status'],
        null,
        sprintf('%s payment of %.2f recorded.', $direction, $amount),
        $userId,
        ['payment_id' => $paymentId, 'amount' => $amount]
    );

    return $paymentId;
}

if ($action === 'sync_sources') {
    $scope = trim((string) ($_POST['view'] ?? ''));
    financeRequireView($conn, $scope);
    try {
        $conn->begin_transaction();
        $synced = financeSyncSources($conn, $scope, $userId);
        $conn->commit();
        financeJson('success', 'Finance sources synchronized.', $synced);
    } catch (Throwable $error) {
        $conn->rollback();
        error_log('Finance source sync failed: ' . $error->getMessage());
        financeJson('error', 'Unable to synchronize Finance sources.', [], 500);
    }
}

if ($action === 'list') {
    $view = trim((string) ($_POST['view'] ?? ''));
    financeRequireView($conn, $view);
    $page = max(1, (int) ($_POST['page'] ?? 1));
    $pendingOnly = isset($_POST['pending_only']) && (int) $_POST['pending_only'] === 1;
    $requestedPerPage = max(5, min(100, (int) ($_POST['per_page'] ?? 10)));
    $perPage = $pendingOnly ? min(50, $requestedPerPage) : $requestedPerPage;
    $search = trim((string) ($_POST['search'] ?? ''));
    $sort = trim((string) ($_POST['sort'] ?? 'created_at'));
    $order = trim((string) ($_POST['order'] ?? 'desc'));

    try {
        $data = in_array($view, ['payment_made', 'payment_received'], true)
            ? financeListPayments($conn, $view, $page, $perPage, $search, $sort, $order)
            : financeListDocuments($conn, $view, $page, $perPage, $search, $sort, $order, $pendingOnly);
        financeJson('success', '', $data);
    } catch (Throwable $error) {
        error_log('Finance list failed: ' . $error->getMessage());
        financeJson('error', 'Unable to load Finance records.', [], 500);
    }
}

if ($action === 'get_document') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $document = financeGetDocument($conn, $documentId);
    if (!$document) {
        financeJson('error', 'Finance document not found.', [], 404);
    }
    $allowedPermissions = match ($document['document_type']) {
        'VENDOR_BILL' => ['finance_bill_generation_view', 'finance_trade_payables_view', 'finance_payment_made_view'],
        'SALES_INVOICE' => ['finance_invoice_generation_view', 'finance_trade_receivables_view', 'finance_payment_received_view'],
        'DELIVERY_CHALLAN' => ['finance_delivery_challan_generation_view'],
        default => [],
    };
    $allowed = false;
    foreach ($allowedPermissions as $permission) {
        if (checkPermission($permission, $conn)) {
            $allowed = true;
            break;
        }
    }
    if (!$allowed) {
        financeJson('error', 'You do not have permission to view this Finance document.', [], 403);
    }
    financeJson('success', '', ['document' => $document]);
}

if ($action === 'preview_document_html') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $document = financeGetDocument($conn, $documentId);
    if (!$document) {
        financeJson('error', 'Finance document not found.', [], 404);
    }
    $allowedPermissions = match ($document['document_type']) {
        'VENDOR_BILL' => ['finance_bill_generation_view', 'finance_trade_payables_view', 'finance_payment_made_view'],
        'SALES_INVOICE' => ['finance_invoice_generation_view', 'finance_trade_receivables_view', 'finance_payment_received_view'],
        'DELIVERY_CHALLAN' => ['finance_delivery_challan_generation_view'],
        default => [],
    };
    $allowed = false;
    foreach ($allowedPermissions as $permission) {
        if (checkPermission($permission, $conn)) {
            $allowed = true;
            break;
        }
    }
    if (!$allowed) {
        financeJson('error', 'You do not have permission to preview this Finance document format.', [], 403);
    }

    require_once dirname(__DIR__) . '/finance/finance_pdf.php';

    if (!empty($_POST['items'])) {
        $postedItems = json_decode((string) $_POST['items'], true);
        if (is_array($postedItems)) {
            $calc = financeCalculateItems($postedItems, (string) $document['document_type'], (string) ($_POST['tax_mode'] ?? $document['tax_mode'] ?? 'INTRA'));
            $document['items'] = $calc['items'];
            $document['tax_mode'] = $calc['tax_mode'];
            $document['grand_total'] = $calc['grand_total'];
            $document['subtotal'] = $calc['subtotal'];
            $document['discount_total'] = $calc['discount_total'];
            $document['taxable_total'] = $calc['taxable_total'];
            $document['cgst_total'] = $calc['cgst_total'];
            $document['sgst_total'] = $calc['sgst_total'];
            $document['igst_total'] = $calc['igst_total'];
            $document['round_off'] = $calc['round_off'];
        }
    }
    if (!empty($_POST['transport_mode'])) $document['transport_mode'] = trim((string) $_POST['transport_mode']);
    if (!empty($_POST['document_date'])) $document['document_date'] = trim((string) $_POST['document_date']);
    if (!empty($_POST['due_date'])) $document['due_date'] = trim((string) $_POST['due_date']);
    if (!empty($_POST['counterparty_name'])) $document['counterparty_name'] = trim((string) $_POST['counterparty_name']);
    if (!empty($_POST['counterparty_address'])) $document['counterparty_address'] = trim((string) $_POST['counterparty_address']);
    if (!empty($_POST['counterparty_shipping_address'])) $document['counterparty_shipping_address'] = trim((string) $_POST['counterparty_shipping_address']);
    if (!empty($_POST['counterparty_gstin'])) $document['counterparty_gstin'] = trim((string) $_POST['counterparty_gstin']);
    if (!empty($_POST['counterparty_state'])) $document['counterparty_state'] = trim((string) $_POST['counterparty_state']);
    if (!empty($_POST['counterparty_state_code'])) $document['counterparty_state_code'] = trim((string) $_POST['counterparty_state_code']);
    if (!empty($_POST['counterparty_contact'])) $document['counterparty_contact'] = trim((string) $_POST['counterparty_contact']);
    if (!empty($_POST['counterparty_email'])) $document['counterparty_email'] = trim((string) $_POST['counterparty_email']);
    if (!empty($_POST['terms_snapshot'])) $document['terms_snapshot'] = trim((string) $_POST['terms_snapshot']);

    try {
        $html = financeBuildDocumentHtml($document);
        financeJson('success', '', ['html' => $html]);
    } catch (Throwable $e) {
        financeJson('error', 'Unable to build preview: ' . $e->getMessage(), [], 500);
    }
}

if ($action === 'get_company_dependencies') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $companyId = (int) ($_POST['erp_company_id'] ?? 0);
    $document = financeRequireDocumentManage($conn, $documentId);
    if ($companyId <= 0) {
        financeJson('error', 'Select a valid company.', [], 422);
    }

    try {
        $options = financeCompanyDocumentOptions(
            $conn,
            $companyId,
            (string) $document['document_type']
        );
        financeJson('success', '', $options);
    } catch (Throwable $error) {
        financeJson('error', $error->getMessage(), [], 422);
    }
}

if ($action === 'classify_bill') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $document = financeRequireDocumentManage($conn, $documentId);
    if ($document['document_type'] !== 'VENDOR_BILL') {
        financeJson('error', 'Only vendor bills can be classified here.', [], 422);
    }

    $decision = strtoupper(trim((string) ($_POST['decision'] ?? '')));
    if (!in_array($decision, ['PAID', 'UNPAID', 'NOT_SURE'], true)) {
        financeJson('error', 'Select Paid, Unpaid or Not Sure.', [], 422);
    }

    $grandTotal = financeNumeric($_POST['grand_total'] ?? 0);
    $documentDate = trim((string) ($_POST['document_date'] ?? '')) ?: null;
    $dueDate = trim((string) ($_POST['due_date'] ?? '')) ?: null;
    $creditDays = isset($_POST['credit_days']) && is_numeric($_POST['credit_days']) ? max(0, min(365, (int) $_POST['credit_days'])) : null;
    $notes = trim((string) ($_POST['notes'] ?? '')) ?: null;
    if ($decision !== 'NOT_SURE' && $grandTotal <= 0) {
        financeJson('error', 'Enter a bill amount greater than zero.', [], 422);
    }

    try {
        $conn->begin_transaction();
        $lock = $conn->prepare("SELECT * FROM finance_documents WHERE id = ? FOR UPDATE");
        $lock->bind_param('i', $documentId);
        $lock->execute();
        $locked = $lock->get_result()->fetch_assoc();
        $lock->close();
        if (!$locked) {
            throw new RuntimeException('Bill not found.');
        }

        $newStatus = $decision === 'NOT_SURE' ? 'PENDING' : 'OPEN';
        $stmt = $conn->prepare(
            "UPDATE finance_documents
             SET document_date = ?, due_date = ?, credit_days = ?, grand_total = ?, taxable_total = ?,
                 decision_status = ?, status = ?, notes = ?, status_changed_at = NOW(),
                 status_changed_by = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ?"
        );
        $stmt->bind_param(
            'ssiddsssiii',
            $documentDate,
            $dueDate,
            $creditDays,
            $grandTotal,
            $grandTotal,
            $decision,
            $newStatus,
            $notes,
            $userId,
            $userId,
            $documentId
        );
        $stmt->execute();
        $stmt->close();

        financeHistory(
            $conn,
            $documentId,
            'BILL_CLASSIFIED',
            $locked['status'],
            $newStatus,
            'Bill classified as ' . $decision . '.',
            $userId
        );

        $paymentId = null;
        if ($decision === 'PAID') {
            $locked['grand_total'] = $grandTotal;
            $locked['amount_paid'] = 0;
            $locked['status'] = $newStatus;
            $paymentDate = trim((string) ($_POST['payment_date'] ?? '')) ?: date('Y-m-d');
            $paymentMode = strtoupper(trim((string) ($_POST['payment_mode'] ?? 'BANK_TRANSFER')));
            $allowedModes = ['CASH', 'BANK_TRANSFER', 'CHEQUE', 'UPI', 'CARD', 'OTHER'];
            if (!in_array($paymentMode, $allowedModes, true)) {
                $paymentMode = 'OTHER';
            }
            $reference = trim((string) ($_POST['reference_number'] ?? '')) ?: null;
            $bankAccount = (int) ($_POST['bank_account_id'] ?? 0);
            $bankAccount = $bankAccount > 0 ? $bankAccount : null;
            $paymentId = financeCreatePayment(
                $conn,
                $locked,
                $grandTotal,
                $paymentDate,
                $paymentMode,
                $reference,
                $bankAccount,
                $notes,
                $userId
            );
        }

        $conn->commit();
        financeJson('success', 'Vendor bill classification saved.', ['payment_id' => $paymentId]);
    } catch (Throwable $error) {
        $conn->rollback();
        error_log('Finance bill classification failed: ' . $error->getMessage());
        financeJson('error', $error->getMessage(), [], 422);
    }
}

if ($action === 'set_document_decision') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $document = financeRequireDocumentManage($conn, $documentId);
    if (!in_array($document['document_type'], ['SALES_INVOICE', 'DELIVERY_CHALLAN'], true)) {
        financeJson('error', 'Invalid document decision.', [], 422);
    }
    $decision = strtoupper(trim((string) ($_POST['decision'] ?? '')));
    if (!in_array($decision, ['CREATE', 'DONT', 'REOPEN'], true)) {
        financeJson('error', 'Invalid document decision.', [], 422);
    }
    if (
        in_array($decision, ['CREATE', 'DONT'], true)
        && !in_array($document['status'], ['PENDING', 'DRAFT'], true)
    ) {
        financeJson('error', 'This decision is no longer available for the selected document.', [], 409);
    }
    if ($decision === 'REOPEN' && $document['status'] !== 'NO_DOCUMENT') {
        financeJson('error', 'Only a No Invoice/No Challan record can be reopened.', [], 409);
    }

    $newDecision = match ($decision) {
        'CREATE' => 'CREATE',
        'DONT' => 'DONT',
        default => 'PENDING',
    };
    $newStatus = match ($decision) {
        'CREATE' => 'DRAFT',
        'DONT' => 'NO_DOCUMENT',
        default => 'PENDING',
    };

    try {
        $conn->begin_transaction();

        // Serialize competing decisions and re-check the status after acquiring
        // the row lock so a stale browser response cannot overwrite a newer one.
        $stmt = $conn->prepare(
            "SELECT document_type, status
             FROM finance_documents
             WHERE id = ? AND deleted_at IS NULL
             FOR UPDATE"
        );
        $stmt->bind_param('i', $documentId);
        $stmt->execute();
        $lockedDocument = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$lockedDocument) {
            throw new RuntimeException('Finance document not found.', 404);
        }
        if (
            in_array($decision, ['CREATE', 'DONT'], true)
            && !in_array($lockedDocument['status'], ['PENDING', 'DRAFT'], true)
        ) {
            throw new RuntimeException(
                'This decision is no longer available for the selected document.',
                409
            );
        }
        if ($decision === 'REOPEN' && $lockedDocument['status'] !== 'NO_DOCUMENT') {
            throw new RuntimeException('Only a No Invoice/No Challan record can be reopened.', 409);
        }

        // Refresh only the Finance snapshot immediately before an operator starts
        // editing it. The source workflow and its tables remain unchanged.
        if ($decision === 'CREATE') {
            financeRefreshDispatchDocumentFromSource($conn, $documentId, $userId);
        }

        $stmt = $conn->prepare(
            "UPDATE finance_documents
             SET decision_status = ?, status = ?, status_changed_at = NOW(), status_changed_by = ?,
                 updated_by = ?, updated_at = NOW()
             WHERE id = ?"
        );
        $stmt->bind_param('ssiii', $newDecision, $newStatus, $userId, $userId, $documentId);
        $stmt->execute();
        $stmt->close();
        financeHistory(
            $conn,
            $documentId,
            match ($decision) {
                'CREATE' => 'DOCUMENT_DRAFTED',
                'DONT' => 'DOCUMENT_DECLINED',
                default => 'DOCUMENT_REOPENED',
            },
            $lockedDocument['status'],
            $newStatus,
            match ($decision) {
                'CREATE' => 'Document moved to draft for generation.',
                'DONT' => 'Document generation declined.',
                default => 'Document reopened for generation.',
            },
            $userId
        );

        $conn->commit();
        $message = match ($decision) {
            'CREATE' => 'Draft created. Use Open in the lower table to review and generate it.',
            'DONT' => 'The decision was recorded.',
            default => 'The document was reopened.',
        };
        financeJson('success', $message);
    } catch (Throwable $error) {
        $conn->rollback();
        error_log('Finance document decision failed: ' . $error->getMessage());
        $statusCode = in_array((int) $error->getCode(), [404, 409, 422], true)
            ? (int) $error->getCode()
            : 422;
        financeJson('error', $error->getMessage(), [], $statusCode);
    }
}

if ($action === 'generate_document') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $document = financeRequireDocumentManage($conn, $documentId);
    if (!in_array($document['document_type'], ['SALES_INVOICE', 'DELIVERY_CHALLAN'], true)) {
        financeJson('error', 'Only invoices and delivery challans can be generated.', [], 422);
    }

    $items = json_decode((string) ($_POST['items'] ?? '[]'), true);
    if (!is_array($items) || !$items) {
        financeJson('error', 'At least one document item is required.', [], 422);
    }

    $documentDate = trim((string) ($_POST['document_date'] ?? '')) ?: date('Y-m-d');
    $dueDate = trim((string) ($_POST['due_date'] ?? '')) ?: date('Y-m-d', strtotime($documentDate . ' +30 days'));
    $taxMode = strtoupper(trim((string) ($_POST['tax_mode'] ?? 'INTRA')));
    if ($document['document_type'] === 'DELIVERY_CHALLAN') {
        $taxMode = 'NONE';
    } elseif (!in_array($taxMode, ['INTRA', 'INTER'], true)) {
        $taxMode = 'INTRA';
    }
    $calculated = financeCalculateItems($items, $document['document_type'], $taxMode);
    $totals = $calculated['totals'];
    if ($document['document_type'] === 'SALES_INVOICE') {
        foreach ($calculated['items'] as $index => $item) {
            if (trim((string) $item['hsn_code']) === '') {
                financeJson('error', 'Configure the HSN code for invoice item ' . ($index + 1) . '.', [], 422);
            }
            if ((float) $item['mrp'] <= 0) {
                financeJson('error', 'Enter an MRP greater than zero for invoice item ' . ($index + 1) . '.', [], 422);
            }
            if ((float) $item['rate'] <= 0) {
                financeJson('error', 'Enter a selling rate greater than zero for invoice item ' . ($index + 1) . '.', [], 422);
            }
        }
    }
    $pdf = null;

    try {
        $conn->begin_transaction();
        $lock = $conn->prepare("SELECT * FROM finance_documents WHERE id = ? FOR UPDATE");
        $lock->bind_param('i', $documentId);
        $lock->execute();
        $locked = $lock->get_result()->fetch_assoc();
        $lock->close();
        if (!$locked) {
            throw new RuntimeException('Finance document not found.');
        }
        // A challan is a dispatch record, so re-running generation would rewrite
        // an already-issued document. Invoices stay editable via the amount_paid
        // rule below.
        if (
            in_array($document['document_type'], ['DELIVERY_CHALLAN', 'SALES_INVOICE'], true)
            && in_array((string) $locked['status'], ['GENERATED', 'OPEN', 'PART_PAID', 'PAID'], true)
        ) {
            $docLabel = $document['document_type'] === 'DELIVERY_CHALLAN' ? 'Delivery challan' : 'Sales invoice';
            $issued = trim((string) ($locked['document_number'] ?? ''));
            throw new RuntimeException(
                $docLabel . ' ' . ($issued !== '' ? $issued . ' ' : '') . 'has already been generated for this dispatch.'
            );
        }
        if (
            $document['document_type'] === 'SALES_INVOICE'
            && (float) $locked['amount_paid'] > (float) $totals['grand_total'] + 0.001
        ) {
            throw new RuntimeException('Invoice total cannot be reduced below the amount already received.');
        }

        $companyId = (int) ($_POST['erp_company_id'] ?? 0);
        if ($companyId <= 0) {
            $companyId = (int) ($locked['erp_company_id'] ?: financeCurrentCompanyId($conn) ?: 0);
        }
        $companyCheck = $conn->prepare(
            "SELECT id FROM erp_companies
             WHERE id = ? AND status = 1 AND deleted_at IS NULL
             LIMIT 1"
        );
        $companyCheck->bind_param('i', $companyId);
        $companyCheck->execute();
        $validCompany = $companyCheck->get_result()->fetch_assoc();
        $companyCheck->close();
        if (!$validCompany) {
            throw new RuntimeException('Select a valid company for this document.');
        }
        $profileId = financeCurrentProfileId($conn, $companyId);
        $documentNumber = $locked['document_number'];
        if (!$documentNumber) {
            $documentNumber = financeNextNumber($conn, $companyId, $document['document_type'], $documentDate);
        }

        $counterpartyName = trim((string) ($_POST['counterparty_name'] ?? ''));
        if ($counterpartyName === '') {
            throw new RuntimeException('Client/party name is required.');
        }
        $counterpartyAddress = trim((string) ($_POST['counterparty_address'] ?? '')) ?: null;
        $counterpartyShippingAddress = trim((string) ($_POST['counterparty_shipping_address'] ?? '')) ?: $counterpartyAddress;
        $counterpartyEmail = trim((string) ($_POST['counterparty_email'] ?? '')) ?: null;
        $counterpartyGstin = trim((string) ($_POST['counterparty_gstin'] ?? '')) ?: null;
        $counterpartyState = trim((string) ($_POST['counterparty_state'] ?? '')) ?: null;
        $counterpartyStateCode = trim((string) ($_POST['counterparty_state_code'] ?? '')) ?: null;
        $counterpartyContact = trim((string) ($_POST['counterparty_contact'] ?? '')) ?: null;
        $irn = trim((string) ($_POST['irn'] ?? '')) ?: null;
        $ack = trim((string) ($_POST['acknowledgement_number'] ?? '')) ?: null;
        $cases = trim((string) ($_POST['cases_text'] ?? '')) ?: null;
        $lrNumber = trim((string) ($_POST['lr_number'] ?? '')) ?: null;
        $lrDate = trim((string) ($_POST['lr_date'] ?? '')) ?: null;
        $transport = trim((string) ($_POST['transport_mode'] ?? '')) ?: null;
        $tracking = trim((string) ($_POST['tracking_id'] ?? '')) ?: null;
        $creditDays = max(0, min(365, (int) ($_POST['credit_days'] ?? 30)));
        $bankAccount = (int) ($_POST['bank_account_id'] ?? 0);
        $bankAccount = $bankAccount > 0 ? $bankAccount : null;
        $selectedBank = [];
        if ($bankAccount !== null) {
            $stmt = $conn->prepare(
                "SELECT *
                 FROM finance_company_bank_accounts
                 WHERE id = ? AND status = 1 AND deleted_at IS NULL
                   AND (erp_company_id <=> ? OR erp_company_id IS NULL)
                 LIMIT 1"
            );
            $stmt->bind_param('ii', $bankAccount, $companyId);
            $stmt->execute();
            $selectedBank = $stmt->get_result()->fetch_assoc() ?: [];
            $stmt->close();
            if (!$selectedBank) {
                throw new RuntimeException('Select a bank account belonging to the selected company.');
            }
        }
        $bankSnapshotValues = [];
        foreach ([
            'bank_name', 'branch_name', 'account_name', 'account_number',
            'ifsc_code', 'swift_code', 'upi_id',
        ] as $bankField) {
            $postedValue = trim((string) ($_POST[$bankField] ?? ''));
            $bankSnapshotValues[$bankField] = $postedValue !== ''
                ? $postedValue
                : (string) ($selectedBank[$bankField] ?? '');
        }
        $bankSnapshotValues['qr_file'] = (string) ($selectedBank['qr_file'] ?? '');
        $bankSnapshot = json_encode(
            $bankSnapshotValues,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
        $terms = trim((string) ($_POST['terms_snapshot'] ?? '')) ?: financeDefaultTerms(
            $conn,
            $companyId,
            $profileId,
            (string) $document['document_type']
        );
        $notes = trim((string) ($_POST['notes'] ?? '')) ?: null;
        $snapshot = json_encode([
            'header' => $_POST,
            'items' => $calculated['items'],
            'totals' => $totals,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $stmt = $conn->prepare(
            "UPDATE finance_documents
             SET erp_company_id = ?, company_profile_id = ?, counterparty_name = ?,
                 counterparty_address = ?, counterparty_shipping_address = ?, counterparty_email = ?,
                 counterparty_gstin = ?, counterparty_state = ?, counterparty_state_code = ?,
                 counterparty_contact = ?, document_number = ?, document_date = ?, due_date = ?,
                 credit_days = ?, decision_status = 'CREATE', status = 'GENERATED', tax_mode = ?,
                 irn = ?, acknowledgement_number = ?, cases_text = ?, lr_number = ?, lr_date = ?,
                 transport_mode = ?, tracking_id = ?, subtotal = ?, discount_total = ?,
                 taxable_total = ?, cgst_total = ?, sgst_total = ?, igst_total = ?, round_off = ?,
                 grand_total = ?, bank_account_id = ?, bank_snapshot = ?, terms_snapshot = ?, notes = ?,
                 document_snapshot = ?, generated_at = NOW(), generated_by = ?,
                 status_changed_at = NOW(), status_changed_by = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ?"
        );
        $values = [
            $companyId, $profileId, $counterpartyName, $counterpartyAddress,
            $counterpartyShippingAddress, $counterpartyEmail, $counterpartyGstin,
            $counterpartyState, $counterpartyStateCode, $counterpartyContact, $documentNumber,
            $documentDate, $dueDate, $creditDays, $taxMode, $irn, $ack, $cases, $lrNumber,
            $lrDate, $transport, $tracking, $totals['subtotal'], $totals['discount_total'],
            $totals['taxable_total'], $totals['cgst_total'], $totals['sgst_total'],
            $totals['igst_total'], $totals['round_off'], $totals['grand_total'],
            $bankAccount, $bankSnapshot, $terms, $notes, $snapshot,
            $userId, $userId, $userId, $documentId,
        ];
        $types = 'ii' . str_repeat('s', 11) . 'i' . str_repeat('s', 8)
            . str_repeat('d', 8) . 'i' . str_repeat('s', 4) . 'iiii';
        financeBind($stmt, $types, $values);
        if (!$stmt->execute()) {
            throw new RuntimeException('Unable to save the Finance document: ' . $stmt->error);
        }
        $stmt->close();

        $delete = $conn->prepare("DELETE FROM finance_document_items WHERE document_id = ?");
        $delete->bind_param('i', $documentId);
        $delete->execute();
        $delete->close();

        $insert = $conn->prepare(
            "INSERT INTO finance_document_items
                (document_id, source_table, source_item_id, product_id, product_name, hsn_code,
                 pack_size, quantity, free_quantity, unit_id, unit_label, batch_number,
                 manufacturing_date, expiry_date, coa_number, mrp, rate, gross_amount,
                 discount_percent, discount_value, taxable_value, cgst_percent, cgst_value,
                 sgst_percent, sgst_value, igst_percent, igst_value, line_total, sort_order, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $insertTypes = 'isiisssddisssss' . str_repeat('d', 13) . 'ii';
        foreach ($calculated['items'] as $item) {
            $sourceItemId = $item['source_item_id'] ?: null;
            $productId = $item['product_id'] ?: null;
            $unitId = $item['unit_id'] ?: null;
            $values = [
                $documentId, $item['source_table'], $sourceItemId, $productId,
                $item['product_name'], $item['hsn_code'], $item['pack_size'],
                $item['quantity'], $item['free_quantity'], $unitId, $item['unit_label'],
                $item['batch_number'], $item['manufacturing_date'], $item['expiry_date'],
                $item['coa_number'], $item['mrp'], $item['rate'], $item['gross_amount'],
                $item['discount_percent'], $item['discount_value'], $item['taxable_value'],
                $item['cgst_percent'], $item['cgst_value'], $item['sgst_percent'],
                $item['sgst_value'], $item['igst_percent'], $item['igst_value'],
                $item['line_total'], $item['sort_order'], $userId,
            ];
            financeBind($insert, $insertTypes, $values);
            if (!$insert->execute()) {
                throw new RuntimeException('Unable to save a Finance document item: ' . $insert->error);
            }
        }
        $insert->close();

        if (
            $document['document_type'] === 'SALES_INVOICE'
            && (int) ($_POST['save_credit_default'] ?? 0) === 1
        ) {
            financeRememberCounterpartyCreditDefault(
                $conn,
                $counterpartyName,
                $counterpartyGstin,
                $creditDays,
                $userId
            );
        }
        if (
            $document['document_type'] === 'SALES_INVOICE'
            && (int) ($_POST['save_commercial_defaults'] ?? 0) === 1
        ) {
            $rememberedProducts = [];
            foreach ($calculated['items'] as $item) {
                $productId = (int) ($item['product_id'] ?? 0);
                if ($productId <= 0) {
                    continue;
                }
                $gstRate = $taxMode === 'INTER'
                    ? (float) ($item['igst_percent'] ?? 0)
                    : (float) ($item['cgst_percent'] ?? 0)
                        + (float) ($item['sgst_percent'] ?? 0);
                financeRememberProductCommercialDefault(
                    $conn,
                    $productId,
                    (string) $item['hsn_code'],
                    (float) $item['mrp'],
                    (float) $item['rate'],
                    $gstRate,
                    $documentDate,
                    $userId
                );
                $rememberedProducts[$productId] = true;
            }
            foreach (array_keys($rememberedProducts) as $productId) {
                financeRefreshPendingCommercials($conn, (int) $productId);
            }
        }

        financeHistory(
            $conn,
            $documentId,
            'DOCUMENT_GENERATED',
            $locked['status'],
            'GENERATED',
            $documentTypeLabel = $document['document_type'] === 'SALES_INVOICE'
                ? 'Invoice generated.'
                : 'Delivery Challan generated.',
            $userId,
            ['document_number' => $documentNumber, 'totals' => $totals]
        );

        $pdf = financeGenerateDocumentPdf($conn, $documentId, $userId);
        $stmt = $conn->prepare(
            "UPDATE finance_documents
             SET counterparty_address = CASE
                     WHEN NULLIF(TRIM(counterparty_address), '') IS NULL THEN ? ELSE counterparty_address END,
                 counterparty_shipping_address = CASE
                     WHEN NULLIF(TRIM(counterparty_shipping_address), '') IS NULL THEN ? ELSE counterparty_shipping_address END,
                 counterparty_email = CASE
                     WHEN NULLIF(TRIM(counterparty_email), '') IS NULL THEN ? ELSE counterparty_email END,
                 counterparty_gstin = CASE
                     WHEN NULLIF(TRIM(counterparty_gstin), '') IS NULL THEN ? ELSE counterparty_gstin END,
                 counterparty_state = CASE
                     WHEN NULLIF(TRIM(counterparty_state), '') IS NULL THEN ? ELSE counterparty_state END,
                 counterparty_state_code = CASE
                     WHEN NULLIF(TRIM(counterparty_state_code), '') IS NULL THEN ? ELSE counterparty_state_code END,
                 counterparty_contact = CASE
                     WHEN NULLIF(TRIM(counterparty_contact), '') IS NULL THEN ? ELSE counterparty_contact END,
                 credit_days = ?,
                 due_date = DATE_ADD(COALESCE(document_date, CURRENT_DATE), INTERVAL ? DAY),
                 updated_at = NOW()
             WHERE counterparty_type = 'CLIENT'
               AND LOWER(TRIM(counterparty_name)) = LOWER(TRIM(?))
               AND status IN ('PENDING', 'DRAFT')
               AND deleted_at IS NULL"
        );
        $stmt->bind_param(
            'sssssssiis',
            $counterpartyAddress,
            $counterpartyShippingAddress,
            $counterpartyEmail,
            $counterpartyGstin,
            $counterpartyState,
            $counterpartyStateCode,
            $counterpartyContact,
            $creditDays,
            $creditDays,
            $counterpartyName
        );
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        financeJson(
            'success',
            $documentTypeLabel,
            ['document_id' => $documentId, 'document_number' => $documentNumber, 'pdf' => $pdf]
        );
    } catch (Throwable $error) {
        $conn->rollback();
        if (!empty($pdf['path'])) {
            $generatedPath = dirname(__DIR__) . DIRECTORY_SEPARATOR
                . str_replace('/', DIRECTORY_SEPARATOR, (string) $pdf['path']);
            if (is_file($generatedPath)) {
                @unlink($generatedPath);
            }
        }
        error_log('Finance document generation failed: ' . $error->getMessage());
        financeJson('error', $error->getMessage(), [], 422);
    }
}

if ($action === 'record_payment') {
    $documentId = (int) ($_POST['document_id'] ?? 0);
    $document = financeGetDocument($conn, $documentId);
    if (!$document) {
        financeJson('error', 'Finance document not found.', [], 404);
    }
    if (!in_array($document['document_type'], ['VENDOR_BILL', 'SALES_INVOICE'], true)) {
        financeJson('error', 'Payments cannot be allocated to this document.', [], 422);
    }
    financeRequirePermission(
        $conn,
        $document['document_type'] === 'VENDOR_BILL'
            ? 'finance_trade_payables_manage'
            : 'finance_trade_receivables_manage'
    );

    $amount = financeNumeric($_POST['amount'] ?? 0);
    $paymentDate = trim((string) ($_POST['payment_date'] ?? '')) ?: date('Y-m-d');
    $paymentMode = strtoupper(trim((string) ($_POST['payment_mode'] ?? 'BANK_TRANSFER')));
    $allowedModes = ['CASH', 'BANK_TRANSFER', 'CHEQUE', 'UPI', 'CARD', 'OTHER'];
    if (!in_array($paymentMode, $allowedModes, true)) {
        $paymentMode = 'OTHER';
    }
    $reference = trim((string) ($_POST['reference_number'] ?? '')) ?: null;
    $bankAccount = (int) ($_POST['bank_account_id'] ?? 0);
    $bankAccount = $bankAccount > 0 ? $bankAccount : null;
    $notes = trim((string) ($_POST['notes'] ?? '')) ?: null;

    try {
        $conn->begin_transaction();
        $stmt = $conn->prepare("SELECT * FROM finance_documents WHERE id = ? FOR UPDATE");
        $stmt->bind_param('i', $documentId);
        $stmt->execute();
        $locked = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$locked) {
            throw new RuntimeException('Finance document not found.');
        }

        $paymentId = financeCreatePayment(
            $conn,
            $locked,
            $amount,
            $paymentDate,
            $paymentMode,
            $reference,
            $bankAccount,
            $notes,
            $userId
        );
        $conn->commit();
        financeJson('success', 'Payment recorded successfully.', ['payment_id' => $paymentId]);
    } catch (Throwable $error) {
        $conn->rollback();
        financeJson('error', $error->getMessage(), [], 422);
    }
}

if ($action === 'get_payment') {
    $paymentId = (int) ($_POST['payment_id'] ?? 0);
    $stmt = $conn->prepare("SELECT direction FROM finance_payments WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $paymentId);
    $stmt->execute();
    $direction = $stmt->get_result()->fetch_assoc()['direction'] ?? null;
    $stmt->close();
    financeRequirePermission(
        $conn,
        $direction === 'OUTGOING' ? 'finance_payment_made_view' : 'finance_payment_received_view'
    );
    $stmt = $conn->prepare(
        "SELECT fp.*, u.name AS created_by_name, ru.name AS reversed_by_name
         FROM finance_payments fp
         LEFT JOIN users u ON u.id = fp.created_by
         LEFT JOIN users ru ON ru.id = fp.reversed_by
         WHERE fp.id = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $paymentId);
    $stmt->execute();
    $payment = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$payment) {
        financeJson('error', 'Payment not found.', [], 404);
    }
    $stmt = $conn->prepare(
        "SELECT fpa.allocated_amount, fd.id AS document_id, fd.document_type,
                fd.document_number, fd.reference_number, fd.grand_total
         FROM finance_payment_allocations fpa
         JOIN finance_documents fd ON fd.id = fpa.document_id
         WHERE fpa.payment_id = ?
         ORDER BY fd.id"
    );
    $stmt->bind_param('i', $paymentId);
    $stmt->execute();
    $payment['allocations'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    financeJson('success', '', ['payment' => $payment]);
}

if ($action === 'reverse_payment') {
    $paymentId = (int) ($_POST['payment_id'] ?? 0);
    $reason = trim((string) ($_POST['reason'] ?? ''));
    if ($reason === '') {
        financeJson('error', 'Enter a reversal reason.', [], 422);
    }

    try {
        $conn->begin_transaction();
        $stmt = $conn->prepare("SELECT * FROM finance_payments WHERE id = ? FOR UPDATE");
        $stmt->bind_param('i', $paymentId);
        $stmt->execute();
        $payment = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$payment || $payment['status'] !== 'POSTED') {
            throw new RuntimeException('This payment is not available for reversal.');
        }
        financeRequirePermission(
            $conn,
            $payment['direction'] === 'OUTGOING'
                ? 'finance_payment_made_manage'
                : 'finance_payment_received_manage'
        );
        $stmt = $conn->prepare(
            "UPDATE finance_payments
             SET status = 'REVERSED', reversed_at = NOW(), reversed_by = ?,
                 reversal_reason = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ?"
        );
        $stmt->bind_param('isii', $userId, $reason, $userId, $paymentId);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("SELECT document_id FROM finance_payment_allocations WHERE payment_id = ?");
        $stmt->bind_param('i', $paymentId);
        $stmt->execute();
        $documents = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        foreach ($documents as $row) {
            $documentId = (int) $row['document_id'];
            financeRefreshDocumentPaymentStatus($conn, $documentId, $userId);
            financeHistory(
                $conn,
                $documentId,
                'PAYMENT_REVERSED',
                null,
                null,
                $reason,
                $userId,
                ['payment_id' => $paymentId]
            );
        }
        $conn->commit();
        financeJson('success', 'Payment reversed successfully.');
    } catch (Throwable $error) {
        $conn->rollback();
        financeJson('error', $error->getMessage(), [], 422);
    }
}

if ($action === 'list_product_commercials') {
    financeRequirePermission($conn, 'finance_invoice_generation_manage');
    $page = max(1, (int) ($_POST['page'] ?? 1));
    $perPage = max(5, min(50, (int) ($_POST['per_page'] ?? 50)));
    $search = trim((string) ($_POST['search'] ?? ''));
    $where = "p.status = 1 AND p.deleted_at IS NULL";
    $types = '';
    $params = [];
    if ($search !== '') {
        $where .= " AND (p.product_name LIKE ? OR COALESCE(fpc.hsn_code, '') LIKE ?)";
        $needle = '%' . $search . '%';
        $types = 'ss';
        $params = [$needle, $needle];
    }

    $join = "
        LEFT JOIN finance_product_commercials fpc
          ON fpc.id = (
              SELECT current.id
              FROM finance_product_commercials current
              WHERE current.product_id = p.id
                AND current.status = 1
                AND current.deleted_at IS NULL
                AND current.effective_from <= CURRENT_DATE
                AND (current.effective_to IS NULL OR current.effective_to >= CURRENT_DATE)
              ORDER BY current.effective_from DESC, current.id DESC
              LIMIT 1
          )";
    $countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM products p {$join} WHERE {$where}");
    $countParams = $params;
    financeBind($countStmt, $types, $countParams);
    $countStmt->execute();
    $total = (int) ($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
    $countStmt->close();
    $totalPages = max(1, (int) ceil($total / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;

    $stmt = $conn->prepare(
        "SELECT p.id AS product_id, p.product_name, COALESCE(p.gst_rate, 0) AS product_gst_rate,
                fpc.id AS commercial_id, fpc.hsn_code, fpc.mrp, fpc.selling_rate,
                COALESCE(fpc.gst_rate, p.gst_rate, 0) AS gst_rate, fpc.effective_from
         FROM products p
         {$join}
         WHERE {$where}
         ORDER BY p.product_name, p.id
         LIMIT ? OFFSET ?"
    );
    $listParams = array_merge($params, [$perPage, $offset]);
    $listTypes = $types . 'ii';
    financeBind($stmt, $listTypes, $listParams);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    financeJson('success', '', [
        'rows' => $rows,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => $totalPages,
        'from' => $total ? $offset + 1 : 0,
        'to' => min($offset + $perPage, $total),
    ]);
}

if ($action === 'save_product_commercial') {
    financeRequirePermission($conn, 'finance_invoice_generation_manage');
    $productId = (int) ($_POST['product_id'] ?? 0);
    $hsnCode = strtoupper(trim((string) ($_POST['hsn_code'] ?? '')));
    $mrp = financeNumeric($_POST['mrp'] ?? 0);
    $sellingRate = financeNumeric($_POST['selling_rate'] ?? 0);
    $gstRate = financeNumeric($_POST['gst_rate'] ?? 0);
    $effectiveFrom = trim((string) ($_POST['effective_from'] ?? '')) ?: date('Y-m-d');
    if ($productId <= 0 || $hsnCode === '') {
        financeJson('error', 'Select a product and enter its HSN code.', [], 422);
    }
    if ($gstRate > 100) {
        financeJson('error', 'GST rate must be between 0 and 100.', [], 422);
    }
    $stmt = $conn->prepare(
        "SELECT id FROM products
         WHERE id = ? AND status = 1 AND deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$product) {
        financeJson('error', 'The selected product is not active.', [], 422);
    }

    try {
        $conn->begin_transaction();
        $stmt = $conn->prepare(
            "SELECT id
             FROM finance_product_commercials
             WHERE product_id = ? AND pack_size_id IS NULL
               AND effective_from = ? AND deleted_at IS NULL
             LIMIT 1 FOR UPDATE"
        );
        $stmt->bind_param('is', $productId, $effectiveFrom);
        $stmt->execute();
        $commercial = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($commercial) {
            $commercialId = (int) $commercial['id'];
            $stmt = $conn->prepare(
                "UPDATE finance_product_commercials
                 SET hsn_code = ?, mrp = ?, selling_rate = ?, gst_rate = ?,
                     status = 1, updated_by = ?, updated_at = NOW()
                 WHERE id = ?"
            );
            $stmt->bind_param('sdddii', $hsnCode, $mrp, $sellingRate, $gstRate, $userId, $commercialId);
        } else {
            $stmt = $conn->prepare(
                "INSERT INTO finance_product_commercials
                    (product_id, pack_size_id, hsn_code, mrp, selling_rate, gst_rate,
                     effective_from, status, created_by)
                 VALUES (?, NULL, ?, ?, ?, ?, ?, 1, ?)"
            );
            $stmt->bind_param('isdddsi', $productId, $hsnCode, $mrp, $sellingRate, $gstRate, $effectiveFrom, $userId);
        }
        if (!$stmt->execute()) {
            throw new RuntimeException('Unable to save product commercial data: ' . $stmt->error);
        }
        $stmt->close();
        $refreshed = financeRefreshPendingCommercials($conn, $productId);
        $conn->commit();
        financeJson('success', 'Product commercial data saved.', ['rows_refreshed' => $refreshed]);
    } catch (Throwable $error) {
        $conn->rollback();
        financeJson('error', $error->getMessage(), [], 422);
    }
}

if ($action === 'save_bank_account') {
    if (
        !checkPermission('finance_invoice_generation_manage', $conn)
        && !checkPermission('finance_delivery_challan_generation_manage', $conn)
    ) {
        financeJson('error', 'You do not have permission to manage Finance bank accounts.', [], 403);
    }
    $bankName = trim((string) ($_POST['bank_name'] ?? ''));
    if ($bankName === '') {
        financeJson('error', 'Bank name is required.', [], 422);
    }
    $companyId = financeCurrentCompanyId($conn);
    $profileId = financeCurrentProfileId($conn);
    $branch = trim((string) ($_POST['branch_name'] ?? '')) ?: null;
    $accountName = trim((string) ($_POST['account_name'] ?? '')) ?: null;
    $accountNumber = trim((string) ($_POST['account_number'] ?? '')) ?: null;
    $ifsc = strtoupper(trim((string) ($_POST['ifsc_code'] ?? ''))) ?: null;
    $swift = strtoupper(trim((string) ($_POST['swift_code'] ?? ''))) ?: null;
    $upi = trim((string) ($_POST['upi_id'] ?? '')) ?: null;
    $isDefault = isset($_POST['is_default']) && (int) $_POST['is_default'] === 1 ? 1 : 0;
    $qrPath = null;

    if (isset($_FILES['qr_file']) && (int) $_FILES['qr_file']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['qr_file'];
        if ((int) $file['error'] !== UPLOAD_ERR_OK) {
            financeJson('error', 'Unable to upload the payment QR image.', [], 422);
        }
        if ((int) $file['size'] > 2 * 1024 * 1024) {
            financeJson('error', 'Payment QR image must be 2 MB or smaller.', [], 422);
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file($file['tmp_name']);
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($extensions[$mime])) {
            financeJson('error', 'Payment QR must be a JPG, PNG or WEBP image.', [], 422);
        }
        $relativeDirectory = 'uploads/finance/banks';
        $absoluteDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'finance' . DIRECTORY_SEPARATOR . 'banks';
        if (!is_dir($absoluteDirectory) && !mkdir($absoluteDirectory, 0775, true) && !is_dir($absoluteDirectory)) {
            financeJson('error', 'Unable to create the Finance bank upload directory.', [], 500);
        }
        $filename = 'payment-qr-' . bin2hex(random_bytes(12)) . '.' . $extensions[$mime];
        if (!move_uploaded_file($file['tmp_name'], $absoluteDirectory . DIRECTORY_SEPARATOR . $filename)) {
            financeJson('error', 'Unable to store the payment QR image.', [], 500);
        }
        $qrPath = $relativeDirectory . '/' . $filename;
    }

    $conn->begin_transaction();
    if ($isDefault && $companyId) {
        $stmt = $conn->prepare(
            "UPDATE finance_company_bank_accounts SET is_default = 0
             WHERE erp_company_id = ? AND deleted_at IS NULL"
        );
        $stmt->bind_param('i', $companyId);
        $stmt->execute();
        $stmt->close();
    }
    $stmt = $conn->prepare(
        "INSERT INTO finance_company_bank_accounts
            (erp_company_id, company_profile_id, bank_name, branch_name, account_name,
             account_number, ifsc_code, swift_code, upi_id, qr_file, is_default, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'iissssssssii',
        $companyId,
        $profileId,
        $bankName,
        $branch,
        $accountName,
        $accountNumber,
        $ifsc,
        $swift,
        $upi,
        $qrPath,
        $isDefault,
        $userId
    );
    $stmt->execute();
    $bankId = (int) $conn->insert_id;
    $stmt->close();
    $conn->commit();
    financeJson('success', 'Finance bank account saved.', ['bank_id' => $bankId]);
}

financeJson('error', 'Invalid Finance request.', [], 400);
