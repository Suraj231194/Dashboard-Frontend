<?php

declare(strict_types=1);

function financeJson(string $status, string $message = '', array $data = [], int $httpCode = 200): never
{
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function financeEscape(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function financeMoney(float|string|null $value): string
{
    return number_format((float) $value, 2, '.', ',');
}

function financeDate(?string $value, string $fallback = '—'): string
{
    if (!$value || $value === '0000-00-00') {
        return $fallback;
    }

    $timestamp = strtotime($value);
    return $timestamp ? date('d M Y', $timestamp) : $fallback;
}

function financeRequirePermission(mysqli $conn, string $slug): void
{
    if (!isset($_SESSION['user_id'])) {
        financeJson('error', 'Your session has expired. Please sign in again.', [], 401);
    }

    if (!checkPermission($slug, $conn)) {
        financeJson('error', 'You do not have permission to perform this Finance action.', [], 403);
    }
}

function financeValidateCsrf(): void
{
    $sessionToken = (string) ($_SESSION['csrf_token'] ?? '');
    $requestToken = (string) ($_POST['csrf_token'] ?? '');

    if ($sessionToken === '' || !hash_equals($sessionToken, $requestToken)) {
        financeJson('error', 'Your session token is invalid. Refresh the page and try again.', [], 419);
    }
}

function financeSchemaReady(mysqli $conn): bool
{
    $result = $conn->query("SHOW TABLES LIKE 'finance_documents'");
    return $result && $result->num_rows > 0;
}

function financeNavigationDefinitions(): array
{
    return [
        'roles' => [
            'Super Administrator',
            'Administrator',
            'Senior Administrator',
            'Production + Ops /Admin + Sales & Billing',
            'Sales & Marketting + Sales & Billing',
        ],
        'permissions' => [
            'finance_bill_generation_view' => 'Finance Bill Generation View',
            'finance_bill_generation_manage' => 'Finance Bill Generation Manage',
            'finance_payment_made_view' => 'Finance Payment Made View',
            'finance_payment_made_manage' => 'Finance Payment Made Manage',
            'finance_trade_payables_view' => 'Finance Trade Payables View',
            'finance_trade_payables_manage' => 'Finance Trade Payables Manage',
            'finance_invoice_generation_view' => 'Finance Invoice Generation View',
            'finance_invoice_generation_manage' => 'Finance Invoice Generation Manage',
            'finance_delivery_challan_generation_view' => 'Finance Delivery Challan View',
            'finance_delivery_challan_generation_manage' => 'Finance Delivery Challan Manage',
            'finance_payment_received_view' => 'Finance Payment Received View',
            'finance_payment_received_manage' => 'Finance Payment Received Manage',
            'finance_trade_receivables_view' => 'Finance Trade Receivables View',
            'finance_trade_receivables_manage' => 'Finance Trade Receivables Manage',
        ],
        'pages' => [
            'finance-bill-generation' => [
                'view' => 'bill_generation',
                'name' => 'Bill Generation',
                'icon' => 'ti ti-file-upload',
                'group' => 'bill',
                'sort_order' => 1,
                'permission' => 'finance_bill_generation_view',
            ],
            'finance-payment-made' => [
                'view' => 'payment_made',
                'name' => 'Payment Made',
                'icon' => 'ti ti-credit-card-pay',
                'group' => 'bill',
                'sort_order' => 2,
                'permission' => 'finance_payment_made_view',
            ],
            'finance-trade-payables' => [
                'view' => 'trade_payables',
                'name' => 'Creditors / Trade Payables',
                'icon' => 'ti ti-hourglass',
                'group' => 'bill',
                'sort_order' => 3,
                'permission' => 'finance_trade_payables_view',
            ],
            'finance-invoice-generation' => [
                'view' => 'invoice_generation',
                'name' => 'Invoice Generation',
                'icon' => 'ti ti-file-invoice',
                'group' => 'invoice',
                'sort_order' => 1,
                'permission' => 'finance_invoice_generation_view',
            ],
            'finance-challan-generation' => [
                'view' => 'challan_generation',
                'name' => 'Delivery Challan Generation',
                'icon' => 'ti ti-truck-delivery',
                'group' => 'invoice',
                'sort_order' => 2,
                'permission' => 'finance_delivery_challan_generation_view',
            ],
            'finance-payment-received' => [
                'view' => 'payment_received',
                'name' => 'Payment Received',
                'icon' => 'ti ti-credit-card-refund',
                'group' => 'invoice',
                'sort_order' => 3,
                'permission' => 'finance_payment_received_view',
            ],
            'finance-trade-receivables' => [
                'view' => 'trade_receivables',
                'name' => 'Debtors / Trade Receivables',
                'icon' => 'ti ti-cash-banknote',
                'group' => 'invoice',
                'sort_order' => 4,
                'permission' => 'finance_trade_receivables_view',
            ],
        ],
    ];
}

function financePageView(string $page): ?string
{
    $definitions = financeNavigationDefinitions();
    $view = $definitions['pages'][$page]['view'] ?? null;
    return is_string($view) && $view !== '' ? $view : null;
}

function financePagePermissionSlug(string $page): ?string
{
    $definitions = financeNavigationDefinitions();
    $permission = $definitions['pages'][$page]['permission'] ?? null;
    return is_string($permission) && $permission !== '' ? $permission : null;
}

function financeNavigationReady(mysqli $conn, array $definitions): bool
{
    $quote = static fn(string $value): string => "'" . $conn->real_escape_string($value) . "'";
    $permissionSlugs = array_keys($definitions['permissions']);
    $routes = array_map(
        static fn(string $page): string => 'index.php?page=' . $page,
        array_keys($definitions['pages'])
    );
    $roleNames = $definitions['roles'];

    $quotedPermissions = implode(',', array_map($quote, $permissionSlugs));
    $quotedRoutes = implode(',', array_map($quote, $routes));
    $quotedRoles = implode(',', array_map($quote, $roleNames));

    $result = $conn->query(
        "SELECT
            (
                SELECT COUNT(DISTINCT slug)
                FROM permissions
                WHERE slug IN ({$quotedPermissions})
            ) AS permission_count,
            (
                SELECT COUNT(DISTINCT route)
                FROM menus
                WHERE deleted_at IS NULL
                  AND route IN ({$quotedRoutes})
            ) AS route_count,
            (
                SELECT COUNT(DISTINCT name)
                FROM menus
                WHERE deleted_at IS NULL
                  AND name IN ('Finance', 'Bill Module', 'Invoice Module')
            ) AS group_count,
            (
                SELECT COUNT(*)
                FROM roles r
                JOIN permissions p ON p.slug IN ({$quotedPermissions})
                LEFT JOIN role_permissions rp
                  ON rp.role_id = r.id
                 AND rp.permission_id = p.id
                WHERE r.status = 1
                  AND r.deleted_at IS NULL
                  AND r.name IN ({$quotedRoles})
                  AND rp.permission_id IS NULL
            ) AS missing_role_permissions"
    );
    $row = $result ? $result->fetch_assoc() : null;

    return $row
        && (int) $row['permission_count'] === count($permissionSlugs)
        && (int) $row['route_count'] === count($routes)
        && (int) $row['group_count'] === 3
        && (int) $row['missing_role_permissions'] === 0;
}

function financeEnsureNavigation(mysqli $conn): void
{
    static $navigationChecked = false;
    if ($navigationChecked) {
        return;
    }

    $definitions = financeNavigationDefinitions();
    if (financeNavigationReady($conn, $definitions)) {
        $navigationChecked = true;
        return;
    }

    $lockName = 'autoivd_finance_navigation_v1';
    $lockStatement = $conn->prepare('SELECT GET_LOCK(?, 5) AS acquired');
    if (!$lockStatement) {
        throw new RuntimeException('Unable to prepare the Finance navigation lock.');
    }
    $lockStatement->bind_param('s', $lockName);
    $lockStatement->execute();
    $lockRow = $lockStatement->get_result()->fetch_assoc();
    $lockStatement->close();
    if ((int) ($lockRow['acquired'] ?? 0) !== 1) {
        throw new RuntimeException('Unable to acquire the Finance navigation lock.');
    }

    $inTransaction = false;
    try {
        if (financeNavigationReady($conn, $definitions)) {
            $navigationChecked = true;
            return;
        }

        $conn->begin_transaction();
        $inTransaction = true;

        $permissionStatement = $conn->prepare(
            "INSERT INTO permissions (name, slug, status, created_at)
             SELECT ?, ?, 1, CURRENT_TIMESTAMP
             WHERE NOT EXISTS (
                 SELECT 1 FROM permissions WHERE slug = ?
             )"
        );
        if (!$permissionStatement) {
            throw new RuntimeException('Unable to prepare Finance permission registration.');
        }
        foreach ($definitions['permissions'] as $permissionSlug => $permissionName) {
            $permissionStatement->bind_param(
                'sss',
                $permissionName,
                $permissionSlug,
                $permissionSlug
            );
            if (!$permissionStatement->execute()) {
                throw new RuntimeException('Unable to register Finance permission: ' . $permissionSlug);
            }
        }
        $permissionStatement->close();

        $quote = static fn(string $value): string => "'" . $conn->real_escape_string($value) . "'";
        $quotedPermissions = implode(',', array_map($quote, array_keys($definitions['permissions'])));
        $quotedRoles = implode(',', array_map($quote, $definitions['roles']));
        if (!$conn->query(
            "INSERT IGNORE INTO role_permissions (role_id, permission_id, status)
             SELECT r.id, p.id, 1
             FROM roles r
             JOIN permissions p ON p.slug IN ({$quotedPermissions})
             LEFT JOIN role_permissions rp
               ON rp.role_id = r.id
              AND rp.permission_id = p.id
             WHERE r.status = 1
               AND r.deleted_at IS NULL
               AND r.name IN ({$quotedRoles})
               AND rp.permission_id IS NULL"
        )) {
            throw new RuntimeException('Unable to assign Finance permissions to configured roles.');
        }

        $selectGroup = $conn->prepare(
            "SELECT id
             FROM menus
             WHERE name = ?
               AND COALESCE(parent_id, 0) = ?
               AND deleted_at IS NULL
             ORDER BY id
             LIMIT 1"
        );
        $insertGroup = $conn->prepare(
            "INSERT INTO menus
                (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
             VALUES (?, NULL, ?, ?, ?, NULL, 1, 1, CURRENT_TIMESTAMP)"
        );
        if (!$selectGroup || !$insertGroup) {
            throw new RuntimeException('Unable to prepare Finance menu group registration.');
        }

        $ensureGroup = static function (
            string $name,
            string $icon,
            int $parentId,
            int $sortOrder
        ) use ($selectGroup, $insertGroup): int {
            $selectGroup->bind_param('si', $name, $parentId);
            $selectGroup->execute();
            $row = $selectGroup->get_result()->fetch_assoc();
            if ($row) {
                return (int) $row['id'];
            }

            $insertGroup->bind_param('ssii', $name, $icon, $parentId, $sortOrder);
            if (!$insertGroup->execute()) {
                throw new RuntimeException('Unable to register Finance menu group: ' . $name);
            }
            return (int) $insertGroup->insert_id;
        };

        $financeMenuId = $ensureGroup('Finance', 'ti ti-currency-rupee', 0, 90);
        $groupIds = [
            'bill' => $ensureGroup('Bill Module', 'ti ti-file-invoice', $financeMenuId, 1),
            'invoice' => $ensureGroup('Invoice Module', 'ti ti-receipt', $financeMenuId, 2),
        ];
        $selectGroup->close();
        $insertGroup->close();

        $selectRoute = $conn->prepare(
            "SELECT id
             FROM menus
             WHERE route = ?
               AND deleted_at IS NULL
             ORDER BY id
             LIMIT 1"
        );
        $insertRoute = $conn->prepare(
            "INSERT INTO menus
                (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, 1, 1, CURRENT_TIMESTAMP)"
        );
        if (!$selectRoute || !$insertRoute) {
            throw new RuntimeException('Unable to prepare Finance page route registration.');
        }

        foreach ($definitions['pages'] as $page => $menu) {
            $route = 'index.php?page=' . $page;
            $selectRoute->bind_param('s', $route);
            $selectRoute->execute();
            if ($selectRoute->get_result()->fetch_assoc()) {
                continue;
            }

            $name = (string) $menu['name'];
            $icon = (string) $menu['icon'];
            $parentId = (int) $groupIds[$menu['group']];
            $sortOrder = (int) $menu['sort_order'];
            $permissionSlug = (string) $menu['permission'];
            $insertRoute->bind_param(
                'sssiis',
                $name,
                $route,
                $icon,
                $parentId,
                $sortOrder,
                $permissionSlug
            );
            if (!$insertRoute->execute()) {
                throw new RuntimeException('Unable to register Finance page route: ' . $page);
            }
        }
        $selectRoute->close();
        $insertRoute->close();

        $conn->commit();
        $inTransaction = false;
        $navigationChecked = true;
    } catch (Throwable $error) {
        if ($inTransaction) {
            $conn->rollback();
        }
        throw $error;
    } finally {
        $releaseStatement = $conn->prepare('SELECT RELEASE_LOCK(?)');
        if ($releaseStatement) {
            $releaseStatement->bind_param('s', $lockName);
            $releaseStatement->execute();
            $releaseStatement->close();
        }
    }
}

function financeCurrentCompanyId(mysqli $conn): ?int
{
    $sessionCompany = (int) ($_SESSION['company_id'] ?? 0);
    if ($sessionCompany > 0) {
        return $sessionCompany;
    }

    $result = $conn->query("SELECT id FROM erp_companies WHERE status = 1 AND deleted_at IS NULL ORDER BY id LIMIT 1");
    $row = $result ? $result->fetch_assoc() : null;
    return $row ? (int) $row['id'] : null;
}

function financeCurrentProfileId(mysqli $conn, ?int $erpCompanyId = null): ?int
{
    $erpCompanyId = $erpCompanyId ?: financeCurrentCompanyId($conn);
    if ($erpCompanyId) {
        $stmt = $conn->prepare(
            "SELECT gst_no, legal_name, company_name
             FROM erp_companies
             WHERE id = ? AND status = 1 AND deleted_at IS NULL
             LIMIT 1"
        );
        $stmt->bind_param('i', $erpCompanyId);
        $stmt->execute();
        $erpCompany = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($erpCompany) {
            $normalise = static fn(?string $value): string => mb_strtolower(trim((string) $value), 'UTF-8');
            $gst = $normalise($erpCompany['gst_no'] ?? '');
            $legalName = $normalise($erpCompany['legal_name'] ?? '');
            $companyName = $normalise($erpCompany['company_name'] ?? '');
            $profiles = $conn->query(
                "SELECT id, gst_no, legal_name, trade_name
                 FROM company_profiles
                 WHERE status = 1 AND deleted_at IS NULL
                 ORDER BY id"
            );

            $nameMatch = null;
            while ($profile = $profiles->fetch_assoc()) {
                $profileGst = $normalise($profile['gst_no'] ?? '');
                if ($gst !== '' && $profileGst !== '' && $gst === $profileGst) {
                    return (int) $profile['id'];
                }

                $profileLegal = $normalise($profile['legal_name'] ?? '');
                $profileTrade = $normalise($profile['trade_name'] ?? '');
                if (
                    $nameMatch === null
                    && (
                        ($legalName !== '' && in_array($legalName, [$profileLegal, $profileTrade], true))
                        || ($companyName !== '' && in_array($companyName, [$profileLegal, $profileTrade], true))
                    )
                ) {
                    $nameMatch = (int) $profile['id'];
                }
            }

            if ($nameMatch !== null) {
                return $nameMatch;
            }
        }
    }

    // Never associate an ERP company with an unrelated profile merely because
    // it is the first active row. Unmatched companies retain their ERP company
    // snapshot until their GST/name mapping is configured.
    return null;
}

function financeDefaultTerms(mysqli $conn, ?int $companyId, ?int $profileId, string $documentType): ?string
{
    $stmt = $conn->prepare(
        "SELECT terms_text
         FROM finance_document_terms
         WHERE document_type = ?
           AND status = 1
           AND deleted_at IS NULL
           AND (
               erp_company_id <=> ?
               OR company_profile_id <=> ?
               OR (erp_company_id IS NULL AND company_profile_id IS NULL)
           )
         ORDER BY
             CASE WHEN erp_company_id <=> ? THEN 0
                  WHEN company_profile_id <=> ? THEN 1
                  ELSE 2 END,
             is_default DESC,
             id
         LIMIT 1"
    );
    $stmt->bind_param('siiii', $documentType, $companyId, $profileId, $companyId, $profileId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ? (string) $row['terms_text'] : null;
}

function financeCompanyDocumentOptions(mysqli $conn, int $companyId, string $documentType): array
{
    if (!in_array($documentType, ['SALES_INVOICE', 'DELIVERY_CHALLAN', 'VENDOR_BILL'], true)) {
        throw new InvalidArgumentException('Invalid Finance document type.');
    }

    $stmt = $conn->prepare(
        "SELECT id, company_name, legal_name, company_code, gst_no
         FROM erp_companies
         WHERE id = ? AND status = 1 AND deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $companyId);
    $stmt->execute();
    $company = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$company) {
        throw new RuntimeException('Select a valid company for this document.');
    }

    $profileId = financeCurrentProfileId($conn, $companyId);
    $stmt = $conn->prepare(
        "SELECT *
         FROM finance_company_bank_accounts
         WHERE status = 1 AND deleted_at IS NULL
           AND (erp_company_id <=> ? OR erp_company_id IS NULL)
         ORDER BY
             CASE WHEN erp_company_id <=> ? THEN 0 ELSE 1 END,
             is_default DESC,
             id"
    );
    $stmt->bind_param('ii', $companyId, $companyId);
    $stmt->execute();
    $banks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return [
        'company' => $company,
        'company_profile_id' => $profileId,
        'bank_accounts' => $banks,
        'terms_snapshot' => financeDefaultTerms($conn, $companyId, $profileId, $documentType),
    ];
}

function financeCounterpartyCreditKey(string $counterpartyName, ?string $gstin = null): string
{
    $gstin = strtoupper(preg_replace('/\s+/u', '', trim((string) $gstin)) ?? '');
    if ($gstin !== '') {
        return hash('sha256', 'GSTIN:' . $gstin);
    }

    $name = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $counterpartyName) ?? ''), 'UTF-8');
    return hash('sha256', 'NAME:' . $name);
}

function financeCounterpartyCreditDefault(
    mysqli $conn,
    string $counterpartyName,
    ?string $gstin = null
): ?int {
    if (!financeSourceTableExists($conn, 'finance_counterparty_credit_terms')) {
        return null;
    }

    $key = financeCounterpartyCreditKey($counterpartyName, $gstin);
    $stmt = $conn->prepare(
        "SELECT credit_days
         FROM finance_counterparty_credit_terms
         WHERE counterparty_key = ? AND status = 1 AND deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ? max(0, min(365, (int) $row['credit_days'])) : null;
}

function financeRememberCounterpartyCreditDefault(
    mysqli $conn,
    string $counterpartyName,
    ?string $gstin,
    int $creditDays,
    int $userId
): void {
    $creditDays = max(0, min(365, $creditDays));
    $key = financeCounterpartyCreditKey($counterpartyName, $gstin);
    $gstin = strtoupper(trim((string) $gstin)) ?: null;
    $stmt = $conn->prepare(
        "INSERT INTO finance_counterparty_credit_terms
            (counterparty_key, counterparty_name, counterparty_gstin, credit_days,
             status, created_by, created_at)
         VALUES (?, ?, ?, ?, 1, ?, NOW())
         ON DUPLICATE KEY UPDATE
             counterparty_name = VALUES(counterparty_name),
             counterparty_gstin = VALUES(counterparty_gstin),
             credit_days = VALUES(credit_days),
             status = 1,
             updated_by = VALUES(created_by),
             updated_at = NOW(),
             deleted_by = NULL,
             deleted_at = NULL"
    );
    $stmt->bind_param('sssii', $key, $counterpartyName, $gstin, $creditDays, $userId);
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to save the Finance customer credit default: ' . $error);
    }
    $stmt->close();
}

function financeRememberProductCommercialDefault(
    mysqli $conn,
    int $productId,
    string $hsnCode,
    float $mrp,
    float $sellingRate,
    float $gstRate,
    string $effectiveFrom,
    int $userId
): void {
    if ($productId <= 0 || trim($hsnCode) === '' || $mrp <= 0 || $sellingRate <= 0) {
        return;
    }

    $stmt = $conn->prepare(
        "SELECT id
         FROM finance_product_commercials
         WHERE product_id = ? AND pack_size_id IS NULL
           AND effective_from = ? AND deleted_at IS NULL
         ORDER BY id DESC
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->bind_param('is', $productId, $effectiveFrom);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $hsnCode = strtoupper(trim($hsnCode));
    $gstRate = max(0, min(100, $gstRate));
    if ($existing) {
        $commercialId = (int) $existing['id'];
        $stmt = $conn->prepare(
            "UPDATE finance_product_commercials
             SET hsn_code = ?, mrp = ?, selling_rate = ?, gst_rate = ?,
                 status = 1, updated_by = ?, updated_at = NOW(),
                 deleted_by = NULL, deleted_at = NULL
             WHERE id = ?"
        );
        $stmt->bind_param(
            'sdddii',
            $hsnCode,
            $mrp,
            $sellingRate,
            $gstRate,
            $userId,
            $commercialId
        );
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO finance_product_commercials
                (product_id, pack_size_id, hsn_code, mrp, selling_rate, gst_rate,
                 effective_from, status, created_by)
             VALUES (?, NULL, ?, ?, ?, ?, ?, 1, ?)"
        );
        $stmt->bind_param(
            'isdddsi',
            $productId,
            $hsnCode,
            $mrp,
            $sellingRate,
            $gstRate,
            $effectiveFrom,
            $userId
        );
    }
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to save the Finance product commercial default: ' . $error);
    }
    $stmt->close();
}

function financeSourceTableExists(mysqli $conn, string $table): bool
{
    static $cache = [];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }

    $escaped = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$escaped}'");
    $cache[$table] = $result && $result->num_rows > 0;
    return $cache[$table];
}

/**
 * Proforma Invoices are the only existing, approved source containing client
 * billing/shipping snapshots and client-specific selling rates. Finance reads
 * them as a fallback; an explicit Finance commercial value always wins.
 */
function financeEnrichDispatchDocumentsFromProforma(
    mysqli $conn,
    string $documentType,
    bool $recentOnly = true,
    ?int $documentId = null
): void {
    if (
        !in_array($documentType, ['SALES_INVOICE', 'DELIVERY_CHALLAN'], true)
        || !financeSourceTableExists($conn, 'proforma_invoices')
        || !financeSourceTableExists($conn, 'proforma_invoice_items')
    ) {
        return;
    }

    $recentFilter = $documentId
        ? ' AND fd.id = ?'
        : ($recentOnly ? ' AND fd.created_at >= NOW() - INTERVAL 5 MINUTE' : '');
    $headerSql = "
        UPDATE finance_documents fd
        SET
            fd.counterparty_address = COALESCE(
                NULLIF(TRIM(fd.counterparty_address), ''),
                (
                    SELECT NULLIF(TRIM(pi.company_address), '')
                    FROM proforma_invoices pi
                    WHERE pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC
                    LIMIT 1
                )
            ),
            fd.counterparty_shipping_address = COALESCE(
                NULLIF(TRIM(fd.counterparty_shipping_address), ''),
                (
                    SELECT COALESCE(
                        NULLIF(TRIM(pi.ship_company_address), ''),
                        NULLIF(TRIM(pi.company_address), '')
                    )
                    FROM proforma_invoices pi
                    WHERE pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC
                    LIMIT 1
                )
            ),
            fd.counterparty_gstin = COALESCE(
                NULLIF(TRIM(fd.counterparty_gstin), ''),
                (
                    SELECT NULLIF(TRIM(pi.company_gst), '')
                    FROM proforma_invoices pi
                    WHERE pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC
                    LIMIT 1
                )
            ),
            fd.counterparty_contact = COALESCE(
                NULLIF(TRIM(fd.counterparty_contact), ''),
                (
                    SELECT NULLIF(TRIM(pi.attendant_contact), '')
                    FROM proforma_invoices pi
                    WHERE pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC
                    LIMIT 1
                )
            ),
            fd.counterparty_state_code = COALESCE(
                NULLIF(TRIM(fd.counterparty_state_code), ''),
                (
                    SELECT CASE
                        WHEN TRIM(pi.company_gst) REGEXP '^[0-9]{2}'
                        THEN LEFT(TRIM(pi.company_gst), 2)
                        ELSE NULL
                    END
                    FROM proforma_invoices pi
                    WHERE pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC
                    LIMIT 1
                )
            ),
            fd.updated_at = NOW()
        WHERE fd.document_type = ?
          AND fd.source_type = 'STOCK_OUTWARD'
          AND fd.status IN ('PENDING', 'DRAFT')
          AND fd.deleted_at IS NULL
          {$recentFilter}
    ";
    $stmt = $conn->prepare($headerSql);
    if ($documentId) {
        $stmt->bind_param('si', $documentType, $documentId);
    } else {
        $stmt->bind_param('s', $documentType);
    }
    $stmt->execute();
    $stmt->close();

    if ($documentType !== 'SALES_INVOICE') {
        return;
    }

    $itemRecentFilter = $documentId
        ? ' AND fd.id = ' . (int) $documentId
        : ($recentOnly ? ' AND fd.created_at >= NOW() - INTERVAL 5 MINUTE' : '');
    $proformaProductMatch = "(
        LOWER(TRIM(pii.product)) = LOWER(TRIM(fdi.product_name))
        OR (
            NULLIF(TRIM(pii.cat_no), '') IS NOT NULL
            AND EXISTS (
                SELECT 1
                FROM products catalog_product
                WHERE catalog_product.id = fdi.product_id
                  AND LOWER(TRIM(pii.cat_no)) IN (
                      LOWER(TRIM(COALESCE(catalog_product.product_code, ''))),
                      LOWER(TRIM(COALESCE(catalog_product.erp_sku_web, ''))),
                      LOWER(TRIM(COALESCE(catalog_product.marg_code, '')))
                  )
            )
        )
    )";
    $itemSql = "
        UPDATE finance_document_items fdi
        JOIN finance_documents fd ON fd.id = fdi.document_id
        SET
            fdi.pack_size = CASE
                WHEN NULLIF(TRIM(fdi.pack_size), '') IS NULL THEN COALESCE((
                    SELECT NULLIF(TRIM(pii.pack_size), '')
                    FROM proforma_invoice_items pii
                    JOIN proforma_invoices pi ON pi.id = pii.pi_id
                    WHERE pii.status != 3
                      AND pii.deleted_at IS NULL
                      AND pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                      AND {$proformaProductMatch}
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC, pii.id DESC
                    LIMIT 1
                ), fdi.pack_size) ELSE fdi.pack_size END,
            fdi.rate = CASE
                WHEN fdi.rate = 0 THEN COALESCE((
                    SELECT pii.prod_rate
                    FROM proforma_invoice_items pii
                    JOIN proforma_invoices pi ON pi.id = pii.pi_id
                    WHERE pii.status != 3
                      AND pii.deleted_at IS NULL
                      AND pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                      AND {$proformaProductMatch}
                      AND pii.prod_rate > 0
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC, pii.id DESC
                    LIMIT 1
                ), 0) ELSE fdi.rate END,
            fdi.cgst_percent = CASE
                WHEN fdi.cgst_percent = 0 THEN COALESCE((
                    SELECT pii.gst_percent / 2
                    FROM proforma_invoice_items pii
                    JOIN proforma_invoices pi ON pi.id = pii.pi_id
                    WHERE pii.status != 3
                      AND pii.deleted_at IS NULL
                      AND pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                      AND {$proformaProductMatch}
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC, pii.id DESC
                    LIMIT 1
                ), fdi.cgst_percent) ELSE fdi.cgst_percent END,
            fdi.sgst_percent = CASE
                WHEN fdi.sgst_percent = 0 THEN COALESCE((
                    SELECT pii.gst_percent / 2
                    FROM proforma_invoice_items pii
                    JOIN proforma_invoices pi ON pi.id = pii.pi_id
                    WHERE pii.status != 3
                      AND pii.deleted_at IS NULL
                      AND pi.status != 3
                      AND pi.deleted_at IS NULL
                      AND LOWER(TRIM(pi.company_name)) = LOWER(TRIM(fd.counterparty_name))
                      AND {$proformaProductMatch}
                    ORDER BY COALESCE(pi.enquiry_date, DATE(pi.created_at)) DESC, pi.id DESC, pii.id DESC
                    LIMIT 1
                ), fdi.sgst_percent) ELSE fdi.sgst_percent END,
            fdi.updated_at = NOW()
        WHERE fd.document_type = 'SALES_INVOICE'
          AND fd.source_type = 'STOCK_OUTWARD'
          AND fd.status IN ('PENDING', 'DRAFT')
          AND fd.deleted_at IS NULL
          {$itemRecentFilter}
    ";
    $conn->query($itemSql);
}

function financeNormalizeSourceKey(string $prefix, array $parts): string
{
    $normalized = array_map(static fn($value) => strtolower(trim((string) $value)), $parts);
    return $prefix . ':' . hash('sha256', implode('|', $normalized));
}

function financeHistory(
    mysqli $conn,
    int $documentId,
    string $event,
    ?string $fromStatus,
    ?string $toStatus,
    ?string $remarks,
    int $userId,
    ?array $snapshot = null
): void {
    $snapshotJson = $snapshot ? json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
    $stmt = $conn->prepare(
        "INSERT INTO finance_document_history
            (document_id, event_type, from_status, to_status, remarks, snapshot, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'isssssi',
        $documentId,
        $event,
        $fromStatus,
        $toStatus,
        $remarks,
        $snapshotJson,
        $userId
    );
    $stmt->execute();
    $stmt->close();
}

function financeDecodeStoredFiles(?string $value): array
{
    $value = trim((string) $value);
    if ($value === '') {
        return [];
    }

    $decoded = json_decode($value, true);
    if (is_array($decoded)) {
        $files = [];
        array_walk_recursive($decoded, static function ($item) use (&$files): void {
            if (is_string($item) && trim($item) !== '') {
                $files[] = trim($item);
            }
        });
        return array_values(array_unique($files));
    }

    return [$value];
}

function financeAddSourceFile(mysqli $conn, int $documentId, string $path, int $userId): void
{
    $path = trim($path);
    if ($path === '') {
        return;
    }

    $stmt = $conn->prepare(
        "SELECT id FROM finance_document_files
         WHERE document_id = ? AND file_type = 'SOURCE_INVOICE' AND file_path = ?
         LIMIT 1"
    );
    $stmt->bind_param('is', $documentId, $path);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    if ($exists) {
        return;
    }

    $name = basename(str_replace('\\', '/', $path));
    $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $mimeMap = [
        'pdf' => 'application/pdf',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'webp' => 'image/webp',
    ];
    $mime = $mimeMap[$extension] ?? 'application/octet-stream';

    $stmt = $conn->prepare(
        "INSERT INTO finance_document_files
            (document_id, file_type, file_path, original_name, mime_type, version_number, created_by)
         VALUES (?, 'SOURCE_INVOICE', ?, ?, ?, 1, ?)"
    );
    $stmt->bind_param('isssi', $documentId, $path, $name, $mime, $userId);
    $stmt->execute();
    $stmt->close();
}

function financeVendorBillReceiptEligibilitySql(): string
{
    // A submitted Goods Receipt is the source event for Incoming Bills.
    // Quality approval continues independently and must not delay Billing.
    return "COALESCE(si.status, 1) != 3";
}

function financeRefreshVendorBillCoaNumbers(mysqli $conn, int $userId): void
{
    $stmt = $conn->prepare(
        "UPDATE finance_document_items item
         JOIN finance_documents bill
           ON bill.id = item.document_id
          AND bill.document_type = 'VENDOR_BILL'
          AND bill.deleted_at IS NULL
         JOIN (
             SELECT coa.stock_inward_id, MAX(coa.id) AS coa_id
             FROM coa_rm_pm_table coa
             WHERE coa.deleted_at IS NULL
               AND NULLIF(TRIM(coa.coa_number), '') IS NOT NULL
             GROUP BY coa.stock_inward_id
         ) latest ON latest.stock_inward_id = item.source_item_id
         JOIN coa_rm_pm_table coa ON coa.id = latest.coa_id
         SET item.coa_number = coa.coa_number,
             item.updated_by = ?,
             item.updated_at = NOW()
         WHERE item.source_table = 'stock_inwards'
           AND COALESCE(item.coa_number, '') <> coa.coa_number"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the Incoming Bill COA reconciliation.');
    }
    $stmt->bind_param('i', $userId);
    if (!$stmt->execute()) {
        throw new RuntimeException('Unable to reconcile COA details with Incoming Bills.');
    }
    $stmt->close();
}

function financeInsertVendorBillItems(
    mysqli $conn,
    int $documentId,
    ?int $supplierId,
    string $invoiceNumber,
    ?string $invoiceDate,
    ?string $poType,
    int $userId
): void {
    $receiptEligibilitySql = financeVendorBillReceiptEligibilitySql();
    $sql = "
        SELECT
            si.id,
            si.product_id,
            COALESCE(p.product_name, CONCAT('Product #', si.product_id), 'Unspecified item') AS product_name,
            si.prod_quantity,
            si.prod_quantity_unit,
            COALESCE(su.short_name, su.fullname, '') AS unit_label,
            si.lot_number,
            si.prod_mfg_date,
            si.prod_expiary_date,
            COALESCE(MAX(ls.coa_number), '') AS coa_number,
            COALESCE(p.gst_rate, 0) AS gst_rate,
            COALESCE((
                SELECT pps.pack_size
                FROM product_pack_sizes pps
                WHERE pps.product_id = si.product_id
                  AND pps.status = 1
                  AND pps.deleted_at IS NULL
                ORDER BY pps.sort_order, pps.id
                LIMIT 1
            ), '') AS pack_size,
            COALESCE((
                SELECT NULLIF(TRIM(fpc.hsn_code), '')
                FROM finance_product_commercials fpc
                WHERE fpc.product_id = si.product_id
                  AND fpc.status = 1
                  AND fpc.deleted_at IS NULL
                  AND fpc.effective_from <= COALESCE(si.invoice_date, CURRENT_DATE)
                  AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(si.invoice_date, CURRENT_DATE))
                ORDER BY fpc.effective_from DESC, fpc.id DESC
                LIMIT 1
            ), (
                SELECT NULLIF(TRIM(fdi2.hsn_code), '')
                FROM finance_document_items fdi2
                WHERE fdi2.product_id = si.product_id
                  AND NULLIF(TRIM(fdi2.hsn_code), '') IS NOT NULL
                ORDER BY fdi2.id DESC
                LIMIT 1
            ), '') AS hsn_code,
            COALESCE((
                SELECT fpc.mrp
                FROM finance_product_commercials fpc
                WHERE fpc.product_id = si.product_id
                  AND fpc.status = 1
                  AND fpc.deleted_at IS NULL
                  AND fpc.effective_from <= COALESCE(si.invoice_date, CURRENT_DATE)
                  AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(si.invoice_date, CURRENT_DATE))
                ORDER BY fpc.effective_from DESC, fpc.id DESC
                LIMIT 1
            ), 0) AS mrp,
            COALESCE((
                SELECT fpc.selling_rate
                FROM finance_product_commercials fpc
                WHERE fpc.product_id = si.product_id
                  AND fpc.status = 1
                  AND fpc.deleted_at IS NULL
                  AND fpc.effective_from <= COALESCE(si.invoice_date, CURRENT_DATE)
                  AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(si.invoice_date, CURRENT_DATE))
                ORDER BY fpc.effective_from DESC, fpc.id DESC
                LIMIT 1
            ), 0) AS selling_rate
        FROM stock_inwards si
        LEFT JOIN products p ON p.id = si.product_id
        LEFT JOIN standard_units su ON su.id = si.prod_quantity_unit
        LEFT JOIN live_stock ls ON ls.stock_inward_id = si.id AND ls.deleted_at IS NULL
        WHERE si.deleted_at IS NULL
                    AND {$receiptEligibilitySql}
          AND si.supplier_id <=> ?
          AND si.invoice_number = ?
          AND si.invoice_date <=> ?
          AND si.po_type <=> ?
        GROUP BY
            si.id, si.product_id, p.product_name, si.prod_quantity, si.prod_quantity_unit,
            su.short_name, su.fullname, si.lot_number, si.prod_mfg_date, si.prod_expiary_date,
            p.gst_rate
        ORDER BY si.id
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('isss', $supplierId, $invoiceNumber, $invoiceDate, $poType);
    $stmt->execute();
    $result = $stmt->get_result();
    $sort = 0;

    $insertItem = $conn->prepare(
        "INSERT INTO finance_document_items
            (document_id, source_table, source_item_id, product_id, product_name, hsn_code,
             pack_size, quantity, unit_id, unit_label, batch_number, manufacturing_date,
             expiry_date, coa_number, mrp, rate, cgst_percent, sgst_percent, sort_order, created_by)
         VALUES (?, 'stock_inwards', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $insertLink = $conn->prepare(
        "INSERT IGNORE INTO finance_document_source_links (document_id, source_table, source_id)
         VALUES (?, 'stock_inwards', ?)"
    );

    while ($row = $result->fetch_assoc()) {
        $sort++;
        $sourceId = (int) $row['id'];
        $productId = $row['product_id'] !== null ? (int) $row['product_id'] : null;
        $quantity = (float) preg_replace('/[^0-9.\-]/', '', (string) $row['prod_quantity']);
        $unitId = $row['prod_quantity_unit'] !== null ? (int) $row['prod_quantity_unit'] : null;
        $mrp = (float) $row['mrp'];
        $rate = (float) $row['selling_rate'];
        $halfGst = ((float) $row['gst_rate']) / 2;

        $insertItem->bind_param(
            'iiisssdisssssddddii',
            $documentId,
            $sourceId,
            $productId,
            $row['product_name'],
            $row['hsn_code'],
            $row['pack_size'],
            $quantity,
            $unitId,
            $row['unit_label'],
            $row['lot_number'],
            $row['prod_mfg_date'],
            $row['prod_expiary_date'],
            $row['coa_number'],
            $mrp,
            $rate,
            $halfGst,
            $halfGst,
            $sort,
            $userId
        );
        $insertItem->execute();

        $insertLink->bind_param('ii', $documentId, $sourceId);
        $insertLink->execute();
    }

    $insertItem->close();
    $insertLink->close();
    $stmt->close();
}

function financeSyncVendorBills(mysqli $conn, int $userId, int $limit = 500): int
{
    $limit = max(1, min(1000, $limit));
    $companyId = financeCurrentCompanyId($conn);
    $profileId = financeCurrentProfileId($conn, $companyId);
    $receiptEligibilitySql = financeVendorBillReceiptEligibilitySql();

    // Sync any invoice numbers/dates captured or updated in QA (coa_rm_pm_table) back to stock_inwards
    $conn->query("
        UPDATE stock_inwards si
        JOIN coa_rm_pm_table coa ON coa.stock_inward_id = si.id AND coa.deleted_at IS NULL
        SET si.invoice_number = coa.invoice_number,
            si.invoice_date = COALESCE(NULLIF(coa.invoice_date, ''), si.invoice_date)
        WHERE (si.invoice_number IS NULL OR TRIM(si.invoice_number) = '')
          AND NULLIF(TRIM(coa.invoice_number), '') IS NOT NULL
    ");

    // The receipt identity must never change when an invoice is entered during
    // Quality. Otherwise the same receipt is imported as a second vendor bill.
    $sourceKeySql = "CONCAT(
        'receipt:',
        COALESCE(NULLIF(TRIM(si.receipt_submission_token), ''), CAST(si.id AS CHAR))
      )";

    $insertSql = "
        INSERT IGNORE INTO finance_documents
            (document_type, source_type, source_id, source_key, erp_company_id, company_profile_id,
             supplier_id, po_type, po_reference, counterparty_type, counterparty_name,
             counterparty_address, counterparty_gstin, counterparty_contact, reference_number,
             document_date, due_date, credit_days, decision_status, status, accounting_effect,
             received_by, created_by)
        SELECT
            'VENDOR_BILL',
            'STOCK_INWARD',
            MIN(si.id),
            {$sourceKeySql},
            ?,
            ?,
            si.supplier_id,
            si.po_type,
            GROUP_CONCAT(
                DISTINCT COALESCE(pof.po_order_num, por.po_order_num)
                ORDER BY COALESCE(pof.po_order_num, por.po_order_num)
                SEPARATOR ', '
            ),
            'VENDOR',
            COALESCE(NULLIF(TRIM(s.name), ''), CONCAT('Vendor #', si.supplier_id), 'Unspecified Vendor'),
            COALESCE(NULLIF(TRIM(s.contact_details), ''), ''),
            COALESCE(s.gst_no, ''),
            COALESCE(s.contact_number, ''),
            COALESCE(NULLIF(TRIM(si.invoice_number), ''), CONCAT('GRN-', MIN(si.id))),
            COALESCE(si.invoice_date, MIN(si.date_of_entry)),
            DATE_ADD(COALESCE(si.invoice_date, MIN(si.date_of_entry)), INTERVAL 30 DAY),
            30,
            'PENDING',
            'PENDING',
            1,
            MIN(si.received_by),
            ?
        FROM stock_inwards si
        LEFT JOIN suppliers s ON s.id = si.supplier_id
        LEFT JOIN purchase_order_final pof ON si.po_type <> 'RM' AND pof.id = si.po_id
        LEFT JOIN purchase_order_raw_items pori ON si.po_type = 'RM' AND pori.id = si.po_id
        LEFT JOIN purchase_order_raw por ON por.id = pori.po_raw_id
        WHERE si.deleted_at IS NULL
          AND {$receiptEligibilitySql}
          AND NOT EXISTS (
              SELECT 1
              FROM finance_documents existing
              WHERE existing.document_type = 'VENDOR_BILL'
                AND existing.source_key = {$sourceKeySql}
          )
          AND NOT EXISTS (
              SELECT 1
              FROM finance_document_source_links existing_link
              INNER JOIN finance_documents linked_document
                      ON linked_document.id = existing_link.document_id
                     AND linked_document.document_type = 'VENDOR_BILL'
                     AND linked_document.deleted_at IS NULL
              WHERE existing_link.source_table = 'stock_inwards'
                AND existing_link.source_id = si.id
          )
        GROUP BY
            {$sourceKeySql},
            si.supplier_id, s.name, s.contact_details, s.gst_no, s.contact_number,
            si.invoice_number, si.invoice_date, si.po_type
        ORDER BY MIN(si.id)
        LIMIT {$limit}
    ";
    $stmt = $conn->prepare($insertSql);
    $stmt->bind_param('iii', $companyId, $profileId, $userId);
    $stmt->execute();
    $inserted = $stmt->affected_rows;
    $stmt->close();

    // Incoming Bills are created at Goods Receipt time. When Quality later
    // generates the COA, reconcile its number onto the existing bill line.
    financeRefreshVendorBillCoaNumbers($conn, $userId);

    $approvedUnlinked = false;
    if ($inserted === 0) {
        $approvedResult = $conn->query(
            "SELECT 1
             FROM stock_inwards si
             JOIN finance_documents fd
               ON fd.document_type = 'VENDOR_BILL'
              AND fd.source_key = {$sourceKeySql}
              AND fd.deleted_at IS NULL
             LEFT JOIN finance_document_source_links link
               ON link.document_id = fd.id
              AND link.source_table = 'stock_inwards'
              AND link.source_id = si.id
             WHERE si.deleted_at IS NULL
                             AND {$receiptEligibilitySql}
               AND link.id IS NULL
             LIMIT 1"
        );
                $approvedUnlinked = $approvedResult && $approvedResult->num_rows > 0;
    }

        if ($inserted === 0 && !$approvedUnlinked) {
        return 0;
    }

    $refreshSql = "
        UPDATE finance_documents fd
        JOIN (
            SELECT
                {$sourceKeySql} AS source_key,
                MIN(si.received_by) AS received_by,
                MAX(si.created_at) AS latest_created_at,
                COALESCE(NULLIF(TRIM(s.contact_details), ''), '') AS counterparty_address,
                COALESCE(s.gst_no, '') AS counterparty_gstin,
                COALESCE(s.contact_number, '') AS counterparty_contact
            FROM stock_inwards si
            LEFT JOIN suppliers s ON s.id = si.supplier_id
            WHERE si.deleted_at IS NULL
                            AND {$receiptEligibilitySql}
            GROUP BY
                {$sourceKeySql},
                si.supplier_id, s.contact_details, s.gst_no, s.contact_number,
                si.invoice_number, si.invoice_date, si.po_type
        ) source
          ON source.source_key = fd.source_key
        SET
            fd.received_by = source.received_by,
            fd.counterparty_address = CASE
                WHEN NULLIF(TRIM(fd.counterparty_address), '') IS NULL
                THEN source.counterparty_address ELSE fd.counterparty_address END,
            fd.counterparty_gstin = CASE
                WHEN NULLIF(TRIM(fd.counterparty_gstin), '') IS NULL
                THEN source.counterparty_gstin ELSE fd.counterparty_gstin END,
            fd.counterparty_contact = CASE
                WHEN NULLIF(TRIM(fd.counterparty_contact), '') IS NULL
                THEN source.counterparty_contact ELSE fd.counterparty_contact END,
            fd.updated_at = NOW()
        WHERE fd.document_type = 'VENDOR_BILL'
          AND fd.deleted_at IS NULL
          AND fd.status = 'PENDING'
          AND (
              fd.created_at >= NOW() - INTERVAL 5 MINUTE
              OR source.latest_created_at >= NOW() - INTERVAL 5 MINUTE
          )
    ";
    $conn->query($refreshSql);

    $itemSql = "
        INSERT INTO finance_document_items
            (document_id, source_table, source_item_id, product_id, product_name, hsn_code,
             pack_size, quantity, unit_id, unit_label, batch_number, manufacturing_date,
             expiry_date, coa_number, mrp, rate, cgst_percent, sgst_percent, sort_order, created_by)
        SELECT
            fd.id,
            'stock_inwards',
            si.id,
            si.product_id,
            COALESCE(p.product_name, CONCAT('Product #', si.product_id), 'Unspecified item'),
            COALESCE(fpc.hsn_code, ''),
            COALESCE(pps.pack_size, ''),
            CAST(COALESCE(NULLIF(si.prod_quantity, ''), '0') AS DECIMAL(18,3)),
            si.prod_quantity_unit,
            COALESCE(su.short_name, su.fullname, ''),
            si.lot_number,
            si.prod_mfg_date,
            si.prod_expiary_date,
            COALESCE(ls.coa_number, ''),
            COALESCE(fpc.mrp, 0.00),
            COALESCE(
                CASE WHEN si.po_type = 'RM' THEN pori.price_value ELSE pof.price_value END,
                fpc.selling_rate,
                0.00
            ),
            COALESCE(p.gst_rate, 0.000) / 2,
            COALESCE(p.gst_rate, 0.000) / 2,
            si.id,
            ?
        FROM stock_inwards si
        JOIN finance_documents fd
          ON fd.document_type = 'VENDOR_BILL'
         AND fd.source_key = {$sourceKeySql}
         AND fd.deleted_at IS NULL
        LEFT JOIN products p ON p.id = si.product_id
        LEFT JOIN standard_units su ON su.id = si.prod_quantity_unit
        LEFT JOIN purchase_order_final pof ON si.po_type <> 'RM' AND pof.id = si.po_id
        LEFT JOIN purchase_order_raw_items pori ON si.po_type = 'RM' AND pori.id = si.po_id
        LEFT JOIN (
            SELECT stock_inward_id, MAX(coa_number) AS coa_number
            FROM live_stock
            WHERE deleted_at IS NULL
            GROUP BY stock_inward_id
        ) ls ON ls.stock_inward_id = si.id
        LEFT JOIN (
            SELECT product_id, MIN(id) AS pack_id
            FROM product_pack_sizes
            WHERE status = 1 AND deleted_at IS NULL
            GROUP BY product_id
        ) first_pack ON first_pack.product_id = si.product_id
        LEFT JOIN product_pack_sizes pps ON pps.id = first_pack.pack_id
        LEFT JOIN finance_product_commercials fpc
          ON fpc.id = (
              SELECT fpc2.id
              FROM finance_product_commercials fpc2
              WHERE fpc2.product_id = si.product_id
                AND fpc2.status = 1
                AND fpc2.deleted_at IS NULL
                AND fpc2.effective_from <= COALESCE(si.invoice_date, CURRENT_DATE)
                AND (fpc2.effective_to IS NULL OR fpc2.effective_to >= COALESCE(si.invoice_date, CURRENT_DATE))
              ORDER BY fpc2.effective_from DESC, fpc2.id DESC
              LIMIT 1
          )
        WHERE si.deleted_at IS NULL
                    AND {$receiptEligibilitySql}
          AND NOT EXISTS (
              SELECT 1
              FROM finance_document_items existing_item
              WHERE existing_item.document_id = fd.id
                AND existing_item.source_table = 'stock_inwards'
                AND existing_item.source_item_id = si.id
          )
    ";
    $stmt = $conn->prepare($itemSql);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();

    // Populate financial values immediately from the PO purchase rate. Imported
    // bills must not remain at zero until somebody manually edits every line.
    $conn->query("
        UPDATE finance_document_items item
        INNER JOIN finance_documents document ON document.id = item.document_id
        SET item.gross_amount = ROUND(item.quantity * item.rate, 2),
            item.taxable_value = ROUND((item.quantity * item.rate) - item.discount_value, 2),
            item.cgst_value = ROUND(((item.quantity * item.rate) - item.discount_value) * item.cgst_percent / 100, 2),
            item.sgst_value = ROUND(((item.quantity * item.rate) - item.discount_value) * item.sgst_percent / 100, 2),
            item.line_total = ROUND(
                ((item.quantity * item.rate) - item.discount_value)
                * (1 + ((item.cgst_percent + item.sgst_percent + item.igst_percent) / 100)),
                2
            ),
            item.updated_by = " . (int) $userId . ",
            item.updated_at = NOW()
        WHERE document.document_type = 'VENDOR_BILL'
          AND document.status = 'PENDING'
          AND document.deleted_at IS NULL
          AND item.source_table = 'stock_inwards'
    ");

    $conn->query("
        UPDATE finance_documents document
        INNER JOIN (
            SELECT document_id,
                   ROUND(SUM(gross_amount), 2) AS subtotal,
                   ROUND(SUM(discount_value), 2) AS discount_total,
                   ROUND(SUM(taxable_value), 2) AS taxable_total,
                   ROUND(SUM(cgst_value), 2) AS cgst_total,
                   ROUND(SUM(sgst_value), 2) AS sgst_total,
                   ROUND(SUM(igst_value), 2) AS igst_total,
                   ROUND(SUM(line_total), 2) AS grand_total
            FROM finance_document_items
            GROUP BY document_id
        ) totals ON totals.document_id = document.id
        SET document.subtotal = totals.subtotal,
            document.discount_total = totals.discount_total,
            document.taxable_total = totals.taxable_total,
            document.cgst_total = totals.cgst_total,
            document.sgst_total = totals.sgst_total,
            document.igst_total = totals.igst_total,
            document.grand_total = totals.grand_total,
            document.updated_by = " . (int) $userId . ",
            document.updated_at = NOW()
        WHERE document.document_type = 'VENDOR_BILL'
          AND document.status = 'PENDING'
          AND document.deleted_at IS NULL
    ");

    // Reconcile once more so newly backfilled bill lines also receive any COA
    // that was generated before the Finance source synchronization ran.
    financeRefreshVendorBillCoaNumbers($conn, $userId);

    $stmt = $conn->prepare(
        "INSERT IGNORE INTO finance_document_source_links (document_id, source_table, source_id)
         SELECT fd.id, 'stock_inwards', si.id
         FROM stock_inwards si
         JOIN finance_documents fd
           ON fd.document_type = 'VENDOR_BILL'
          AND fd.source_key = {$sourceKeySql}
          AND fd.deleted_at IS NULL
         WHERE si.deleted_at IS NULL
                     AND {$receiptEligibilitySql}
          "
    );
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare(
        "INSERT INTO finance_document_history
            (document_id, event_type, from_status, to_status, remarks, created_by)
         SELECT fd.id, 'SOURCE_IMPORTED', NULL, 'PENDING', 'Imported from Goods Received.', ?
         FROM finance_documents fd
         WHERE fd.document_type = 'VENDOR_BILL'
           AND fd.deleted_at IS NULL
           AND fd.created_at >= NOW() - INTERVAL 5 MINUTE
           AND NOT EXISTS (
               SELECT 1 FROM finance_document_history fdh
               WHERE fdh.document_id = fd.id AND fdh.event_type = 'SOURCE_IMPORTED'
           )"
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();

    $fileSql = "
        SELECT
            fd.id AS document_id,
            si.invoice_file,
            si.invoice_image
        FROM stock_inwards si
        JOIN finance_documents fd
         ON fd.document_type = 'VENDOR_BILL'
         AND fd.source_key = {$sourceKeySql}
         AND fd.deleted_at IS NULL
        WHERE si.deleted_at IS NULL
                    AND {$receiptEligibilitySql}
          AND (
              NULLIF(TRIM(si.invoice_file), '') IS NOT NULL
              OR NULLIF(TRIM(si.invoice_image), '') IS NOT NULL
          )
          AND NOT EXISTS (
              SELECT 1 FROM finance_document_files fdf
              WHERE fdf.document_id = fd.id AND fdf.file_type = 'SOURCE_INVOICE'
          )
    ";
    $result = $conn->query($fileSql);
    while ($row = $result->fetch_assoc()) {
        foreach (['invoice_file', 'invoice_image'] as $fileColumn) {
            foreach (financeDecodeStoredFiles($row[$fileColumn] ?? null) as $file) {
                financeAddSourceFile($conn, (int) $row['document_id'], $file, $userId);
            }
        }
    }

    return $inserted;
}

function financeInsertDispatchItems(
    mysqli $conn,
    int $documentId,
    int $dispatchId,
    string $documentType,
    int $userId
): void {
    // Resolve customer user_type for B2B vs B2C pricing
    $userType = 'b2b';
    $custStmt = $conn->prepare("
        SELECT c.user_type 
        FROM stock_outward so
        JOIN order_received o ON o.id = so.order_id 
        JOIN customers c ON c.id = o.customer_id 
        WHERE so.id = ? LIMIT 1
    ");
    if ($custStmt) {
        $custStmt->bind_param('i', $dispatchId);
        $custStmt->execute();
        $cRow = $custStmt->get_result()->fetch_assoc();
        $custStmt->close();
        if ($cRow && !empty($cRow['user_type'])) {
            $userType = strtolower(trim($cRow['user_type']));
        }
    }

    $sql = "
        SELECT
            soi.id,
            soi.product_id,
            COALESCE(p.product_name, CONCAT('Product #', soi.product_id)) AS product_name,
            soi.issued_quantity,
            soi.issued_unit,
            COALESCE(su.short_name, su.fullname, '') AS unit_label,
            COALESCE(
                NULLIF(soi.lot_batch_no, ''),
                NULLIF(soi.lot_batch_no_inputted, ''),
                ls.lot_batch_no,
                (SELECT ls2.lot_batch_no FROM live_stock ls2 WHERE ls2.product_id = soi.product_id AND NULLIF(ls2.lot_batch_no, '') IS NOT NULL AND ls2.deleted_at IS NULL ORDER BY ls2.id DESC LIMIT 1),
                (SELECT tt.batch_no FROM transfer_ticket tt JOIN products p2 ON (p2.product_code COLLATE utf8mb4_unicode_ci = tt.code OR p2.product_name COLLATE utf8mb4_unicode_ci = tt.product_description) WHERE p2.id = soi.product_id AND NULLIF(tt.batch_no, '') IS NOT NULL AND tt.deleted_at IS NULL ORDER BY tt.id DESC LIMIT 1),
                ''
            ) AS batch_number,
            COALESCE(
                soi.mfg_date,
                ls.mfg_date,
                (SELECT ls2.mfg_date FROM live_stock ls2 WHERE ls2.product_id = soi.product_id AND ls2.mfg_date IS NOT NULL AND ls2.deleted_at IS NULL ORDER BY ls2.id DESC LIMIT 1),
                (SELECT tt.mfg_date FROM transfer_ticket tt JOIN products p2 ON (p2.product_code COLLATE utf8mb4_unicode_ci = tt.code OR p2.product_name COLLATE utf8mb4_unicode_ci = tt.product_description) WHERE p2.id = soi.product_id AND tt.mfg_date IS NOT NULL AND tt.deleted_at IS NULL ORDER BY tt.id DESC LIMIT 1)
            ) AS mfg_date,
            COALESCE(
                soi.exp_date,
                ls.exp_date,
                (SELECT ls2.exp_date FROM live_stock ls2 WHERE ls2.product_id = soi.product_id AND ls2.exp_date IS NOT NULL AND ls2.deleted_at IS NULL ORDER BY ls2.id DESC LIMIT 1),
                (SELECT tt.exp_date FROM transfer_ticket tt JOIN products p2 ON (p2.product_code COLLATE utf8mb4_unicode_ci = tt.code OR p2.product_name COLLATE utf8mb4_unicode_ci = tt.product_description) WHERE p2.id = soi.product_id AND tt.exp_date IS NOT NULL AND tt.deleted_at IS NULL ORDER BY tt.id DESC LIMIT 1)
            ) AS exp_date,
            soi.coa_number,
            COALESCE(p.gst_rate, 0) AS gst_rate,
            COALESCE((
                SELECT pps.pack_size
                FROM product_pack_sizes pps
                WHERE pps.product_id = soi.product_id
                  AND pps.status = 1
                  AND pps.deleted_at IS NULL
                ORDER BY pps.sort_order, pps.id
                LIMIT 1
            ), '') AS pack_size,
            COALESCE(
                NULLIF(TRIM(p.hsn_code), ''),
                (
                    SELECT NULLIF(TRIM(fpc.hsn_code), '')
                    FROM finance_product_commercials fpc
                    WHERE fpc.product_id = soi.product_id
                      AND fpc.status = 1
                      AND fpc.deleted_at IS NULL
                      AND fpc.effective_from <= CURRENT_DATE
                      AND (fpc.effective_to IS NULL OR fpc.effective_to >= CURRENT_DATE)
                    ORDER BY fpc.effective_from DESC, fpc.id DESC
                    LIMIT 1
                ),
                (
                    SELECT NULLIF(TRIM(fdi2.hsn_code), '')
                    FROM finance_document_items fdi2
                    WHERE fdi2.product_id = soi.product_id
                      AND NULLIF(TRIM(fdi2.hsn_code), '') IS NOT NULL
                    ORDER BY fdi2.id DESC
                    LIMIT 1
                ),
                ''
            ) AS hsn_code,
            COALESCE((
                SELECT fpc.mrp
                FROM finance_product_commercials fpc
                WHERE fpc.product_id = soi.product_id
                  AND fpc.status = 1
                  AND fpc.deleted_at IS NULL
                  AND fpc.effective_from <= CURRENT_DATE
                  AND (fpc.effective_to IS NULL OR fpc.effective_to >= CURRENT_DATE)
                ORDER BY fpc.effective_from DESC, fpc.id DESC
                LIMIT 1
            ), 0) AS mrp,
            COALESCE((
                SELECT fpc.selling_rate
                FROM finance_product_commercials fpc
                WHERE fpc.product_id = soi.product_id
                  AND fpc.status = 1
                  AND fpc.deleted_at IS NULL
                  AND fpc.effective_from <= CURRENT_DATE
                  AND (fpc.effective_to IS NULL OR fpc.effective_to >= CURRENT_DATE)
                ORDER BY fpc.effective_from DESC, fpc.id DESC
                LIMIT 1
            ), 0) AS selling_rate
        FROM stock_outward_items soi
        LEFT JOIN products p ON p.id = soi.product_id
        LEFT JOIN standard_units su ON su.id = soi.issued_unit
        LEFT JOIN live_stock ls ON ls.product_id = soi.product_id
          AND ls.lot_batch_no COLLATE utf8mb4_general_ci = COALESCE(NULLIF(soi.lot_batch_no, ''), soi.lot_batch_no_inputted) COLLATE utf8mb4_general_ci
          AND ls.deleted_at IS NULL
        WHERE soi.outward_id = ?
          AND soi.status = 1
          AND soi.deleted_at IS NULL
        ORDER BY soi.id
    ";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Failed to prepare dispatch items query: ' . $conn->error);
    }
    $stmt->bind_param('i', $dispatchId);
    $stmt->execute();
    $result = $stmt->get_result();
    $sort = 0;

    $insertItem = $conn->prepare(
        "INSERT INTO finance_document_items
            (document_id, source_table, source_item_id, product_id, product_name, hsn_code,
             pack_size, quantity, unit_id, unit_label, batch_number, manufacturing_date,
             expiry_date, coa_number, mrp, rate, cgst_percent, sgst_percent, sort_order, created_by)
         VALUES (?, 'stock_outward_items', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    if (!$insertItem) {
        $stmt->close();
        throw new RuntimeException('Failed to prepare finance_document_items insert: ' . $conn->error);
    }

    while ($row = $result->fetch_assoc()) {
        $sort++;
        $sourceId = (int) $row['id'];
        $productId = (int) $row['product_id'];
        $quantity = (float) $row['issued_quantity'];
        $unitId = (int) $row['issued_unit'];
        $mrp = (float) $row['mrp'];
        $sellingRate = (float) $row['selling_rate'];
        // B2B uses selling_rate (wholesale), B2C uses mrp (retail)
        if ($userType === 'b2c') {
            $rate = $mrp > 0 ? $mrp : $sellingRate;
        } else {
            $rate = $sellingRate > 0 ? $sellingRate : $mrp;
        }
        $halfGst = $documentType === 'DELIVERY_CHALLAN' ? 0.0 : ((float) $row['gst_rate']) / 2;

        $insertItem->bind_param(
            'iiisssdisssssddddii',
            $documentId,
            $sourceId,
            $productId,
            $row['product_name'],
            $row['hsn_code'],
            $row['pack_size'],
            $quantity,
            $unitId,
            $row['unit_label'],
            $row['batch_number'],
            $row['mfg_date'],
            $row['exp_date'],
            $row['coa_number'],
            $mrp,
            $rate,
            $halfGst,
            $halfGst,
            $sort,
            $userId
        );
        $insertItem->execute();
    }

    $insertItem->close();
    $stmt->close();

    $link = $conn->prepare(
        "INSERT IGNORE INTO finance_document_source_links (document_id, source_table, source_id)
         VALUES (?, 'stock_outward', ?)"
    );
    if ($link) {
        $link->bind_param('ii', $documentId, $dispatchId);
        $link->execute();
        $link->close();
    }
}

function financeRefreshDispatchDocumentFromSource(mysqli $conn, int $documentId, int $userId): void
{
    $stmt = $conn->prepare(
        "SELECT document_type, dispatch_id, status
         FROM finance_documents
         WHERE id = ?
           AND source_type = 'STOCK_OUTWARD'
           AND document_type IN ('SALES_INVOICE', 'DELIVERY_CHALLAN')
           AND deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (
        !$document
        || !in_array($document['status'], ['PENDING', 'DRAFT'], true)
        || (int) $document['dispatch_id'] <= 0
    ) {
        return;
    }

    $shipmentTypeSql = "CASE so.type_of_dispatch
        WHEN 1 THEN 'Product Order'
        WHEN 2 THEN 'Sample Dispatch'
        WHEN 3 THEN 'Replacement'
        WHEN 4 THEN 'Tender Supply'
        WHEN 5 THEN 'Other'
        WHEN 6 THEN 'In-House Production'
        ELSE '' END";
    $deliveryModeSql = "CASE so.delivery_mode
        WHEN 1 THEN 'Self Pickup'
        WHEN 2 THEN 'By Delivery Boy'
        WHEN 4 THEN 'Transport/Courier'
        ELSE '' END";
    $transportSql = "CASE CAST(so.courier_transport_service AS UNSIGNED)
        WHEN 1 THEN 'DTDC'
        WHEN 2 THEN 'TCI'
        WHEN 3 THEN 'Bluedart'
        WHEN 4 THEN 'Reliable'
        WHEN 5 THEN 'Jetline'
        WHEN 6 THEN 'Fedex'
        WHEN 7 THEN 'DP World'
        WHEN 8 THEN 'TrackOn'
        WHEN 9 THEN COALESCE(NULLIF(so.type_of_dispatch_details, ''), 'Other')
        WHEN 10 THEN 'Safe Express'
        WHEN 11 THEN 'Porter'
        WHEN 12 THEN 'Tirupati'
        ELSE COALESCE(so.courier_transport_service, '') END";
    $stmt = $conn->prepare(
        "UPDATE finance_documents fd
         JOIN stock_outward so ON so.id = fd.dispatch_id
         LEFT JOIN order_received o ON o.id = so.order_id AND o.deleted_at IS NULL
         SET
            fd.order_id = so.order_id,
            fd.po_reference = COALESCE(NULLIF(o.order_number, ''), CONCAT('Order #', so.order_id)),
            fd.counterparty_name = COALESCE(NULLIF(TRIM(so.client_name), ''), fd.counterparty_name),
            fd.counterparty_address = COALESCE(
                NULLIF(TRIM(o.delivery_address), ''),
                NULLIF(TRIM(fd.counterparty_address), ''),
                NULLIF(TRIM(so.place_of_dispatch), '')
            ),
            fd.counterparty_shipping_address = COALESCE(
                NULLIF(TRIM(so.place_of_dispatch), ''),
                NULLIF(TRIM(o.delivery_address), ''),
                fd.counterparty_shipping_address
            ),
            fd.transport_mode = {$transportSql},
            fd.tracking_id = so.tracking_id,
            fd.shipment_type = {$shipmentTypeSql},
            fd.shipment_type_details = so.type_of_dispatch_details,
            fd.delivery_mode = {$deliveryModeSql},
            fd.dispatched_by = so.dispatched_by,
            fd.dispatched_to = so.dispatched_to,
            fd.updated_by = ?,
            fd.updated_at = NOW()
         WHERE fd.id = ?
           AND fd.status IN ('PENDING', 'DRAFT')
           AND so.status = 1
           AND so.deleted_at IS NULL"
    );
    $stmt->bind_param('ii', $userId, $documentId);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM finance_document_items WHERE document_id = ?");
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $stmt->close();
    financeInsertDispatchItems(
        $conn,
        $documentId,
        (int) $document['dispatch_id'],
        (string) $document['document_type'],
        $userId
    );
    financeEnrichDispatchDocumentsFromProforma(
        $conn,
        (string) $document['document_type'],
        false,
        $documentId
    );
    financeHistory(
        $conn,
        $documentId,
        'SOURCE_REFRESHED',
        (string) $document['status'],
        (string) $document['status'],
        'Dispatch snapshot refreshed before document generation.',
        $userId
    );
}

function financeSyncDispatchDocuments(mysqli $conn, string $documentType, int $userId, int $limit = 500): int
{
    if (!in_array($documentType, ['SALES_INVOICE', 'DELIVERY_CHALLAN'], true)) {
        throw new InvalidArgumentException('Invalid dispatch Finance document type.');
    }

    $companyId = financeCurrentCompanyId($conn);
    $profileId = financeCurrentProfileId($conn, $companyId);
    $sourcePrefix = $documentType === 'SALES_INVOICE' ? 'invoice-dispatch' : 'challan-dispatch';
    $limit = max(1, min(1000, $limit));
    $shipmentTypeSql = "CASE so.type_of_dispatch
        WHEN 1 THEN 'Product Order'
        WHEN 2 THEN 'Sample Dispatch'
        WHEN 3 THEN 'Replacement'
        WHEN 4 THEN 'Tender Supply'
        WHEN 5 THEN 'Other'
        WHEN 6 THEN 'In-House Production'
        ELSE '' END";
    $deliveryModeSql = "CASE so.delivery_mode
        WHEN 1 THEN 'Self Pickup'
        WHEN 2 THEN 'By Delivery Boy'
        WHEN 4 THEN 'Transport/Courier'
        ELSE '' END";
    $transportSql = "CASE CAST(so.courier_transport_service AS UNSIGNED)
        WHEN 1 THEN 'DTDC'
        WHEN 2 THEN 'TCI'
        WHEN 3 THEN 'Bluedart'
        WHEN 4 THEN 'Reliable'
        WHEN 5 THEN 'Jetline'
        WHEN 6 THEN 'Fedex'
        WHEN 7 THEN 'DP World'
        WHEN 8 THEN 'TrackOn'
        WHEN 9 THEN COALESCE(NULLIF(so.type_of_dispatch_details, ''), 'Other')
        WHEN 10 THEN 'Safe Express'
        WHEN 11 THEN 'Porter'
        WHEN 12 THEN 'Tirupati'
        ELSE COALESCE(so.courier_transport_service, '') END";
    $sql = "
        INSERT IGNORE INTO finance_documents
            (document_type, source_type, source_id, source_key, erp_company_id, company_profile_id,
             order_id, dispatch_id, po_reference, counterparty_type, counterparty_name,
             counterparty_address, counterparty_shipping_address, counterparty_gstin,
             counterparty_state, counterparty_state_code, counterparty_contact, counterparty_email,
             document_date, due_date, credit_days,
             decision_status, status, accounting_effect, tax_mode, transport_mode, tracking_id,
             shipment_type, shipment_type_details, delivery_mode, dispatched_by, dispatched_to, created_by)
        SELECT
            ?,
            'STOCK_OUTWARD',
            so.id,
            CONCAT(?, ':', so.id),
            ?,
            ?,
            so.order_id,
            so.id,
            COALESCE(NULLIF(o.order_number, ''), CONCAT('Order #', so.order_id)),
            'CLIENT',
            COALESCE(NULLIF(TRIM(so.client_name), ''), NULLIF(TRIM(c.name), ''), 'Unspecified Client'),
            COALESCE(NULLIF(TRIM(c.detailed_address), ''), NULLIF(TRIM(o.delivery_address), ''), so.place_of_dispatch, ''),
            COALESCE(NULLIF(TRIM(so.place_of_dispatch), ''), NULLIF(TRIM(c.detailed_address), ''), NULLIF(TRIM(o.delivery_address), ''), ''),
            COALESCE(NULLIF(TRIM(c.gstin), ''), ''),
            COALESCE(NULLIF(TRIM(c.state_province), ''), ''),
            COALESCE(NULLIF(TRIM(c.state_code), ''), ''),
            COALESCE(NULLIF(TRIM(c.phone), ''), ''),
            COALESCE(NULLIF(TRIM(c.email), ''), ''),
            COALESCE(DATE(so.created_at), CURRENT_DATE),
            DATE_ADD(COALESCE(DATE(so.created_at), CURRENT_DATE), INTERVAL COALESCE(NULLIF(c.credit_days, 0), 30) DAY),
            COALESCE(NULLIF(c.credit_days, 0), 30),
            'PENDING',
            'PENDING',
            ?,
            ?,
            {$transportSql},
            so.tracking_id,
            {$shipmentTypeSql},
            so.type_of_dispatch_details,
            {$deliveryModeSql},
            so.dispatched_by,
            so.dispatched_to,
            ?
        FROM stock_outward so
        LEFT JOIN order_received o ON o.id = so.order_id AND o.deleted_at IS NULL
        LEFT JOIN customers c ON (c.id = o.customer_id OR c.name = so.client_name COLLATE utf8mb4_unicode_ci OR c.company_name = so.client_name COLLATE utf8mb4_unicode_ci) AND c.status = 1
        WHERE so.outward_type = 2
          AND so.status = 1
          AND so.deleted_at IS NULL
          AND so.order_id IS NOT NULL
          AND NOT EXISTS (
              SELECT 1
              FROM finance_documents fd
              WHERE fd.document_type = ?
                AND fd.source_key = CONCAT(?, ':', so.id)
          )
        ORDER BY so.id
        LIMIT ?
    ";
    $stmt = $conn->prepare($sql);
    $accountingEffect = $documentType === 'SALES_INVOICE' ? 1 : 0;
    $taxMode = $documentType === 'SALES_INVOICE' ? 'INTRA' : 'NONE';
    $stmt->bind_param(
        'ssiiisissi',
        $documentType,
        $sourcePrefix,
        $companyId,
        $profileId,
        $accountingEffect,
        $taxMode,
        $userId,
        $documentType,
        $sourcePrefix,
        $limit
    );
    $stmt->execute();
    $inserted = $stmt->affected_rows;
    $stmt->close();

    // Existing dispatches are reconciled by the deployment check. Normal page
    // refreshes only need to hydrate documents that were newly discovered.
    if ($inserted === 0) {
        return 0;
    }

    $refreshSql = "
        UPDATE finance_documents fd
        JOIN stock_outward so ON so.id = fd.dispatch_id
        LEFT JOIN order_received o ON o.id = so.order_id AND o.deleted_at IS NULL
        LEFT JOIN customers c ON (c.id = o.customer_id OR c.name = so.client_name COLLATE utf8mb4_unicode_ci OR c.company_name = so.client_name COLLATE utf8mb4_unicode_ci) AND c.status = 1
        SET
            fd.order_id = so.order_id,
            fd.po_reference = COALESCE(NULLIF(o.order_number, ''), CONCAT('Order #', so.order_id)),
            fd.counterparty_name = COALESCE(NULLIF(TRIM(so.client_name), ''), fd.counterparty_name),
            fd.counterparty_address = CASE
                WHEN NULLIF(TRIM(fd.counterparty_address), '') IS NULL
                THEN COALESCE(NULLIF(TRIM(c.detailed_address), ''), NULLIF(TRIM(o.delivery_address), ''), so.place_of_dispatch, '')
                ELSE fd.counterparty_address END,
            fd.counterparty_shipping_address = COALESCE(
                NULLIF(TRIM(so.place_of_dispatch), ''),
                NULLIF(TRIM(c.detailed_address), ''),
                NULLIF(TRIM(o.delivery_address), ''),
                fd.counterparty_shipping_address
            ),
            fd.counterparty_gstin = COALESCE(NULLIF(TRIM(fd.counterparty_gstin), ''), NULLIF(TRIM(c.gstin), ''), ''),
            fd.counterparty_state = COALESCE(NULLIF(TRIM(fd.counterparty_state), ''), NULLIF(TRIM(c.state_province), ''), ''),
            fd.counterparty_state_code = COALESCE(NULLIF(TRIM(fd.counterparty_state_code), ''), NULLIF(TRIM(c.state_code), ''), ''),
            fd.counterparty_contact = COALESCE(NULLIF(TRIM(fd.counterparty_contact), ''), NULLIF(TRIM(c.phone), ''), ''),
            fd.counterparty_email = COALESCE(NULLIF(TRIM(fd.counterparty_email), ''), NULLIF(TRIM(c.email), ''), ''),
            fd.credit_days = COALESCE(NULLIF(fd.credit_days, 0), NULLIF(c.credit_days, 0), 30),
            fd.transport_mode = {$transportSql},
            fd.tracking_id = so.tracking_id,
            fd.shipment_type = {$shipmentTypeSql},
            fd.shipment_type_details = so.type_of_dispatch_details,
            fd.delivery_mode = {$deliveryModeSql},
            fd.dispatched_by = so.dispatched_by,
            fd.dispatched_to = so.dispatched_to,
            fd.updated_at = NOW()
        WHERE fd.document_type = ?
          AND fd.source_type = 'STOCK_OUTWARD'
          AND fd.deleted_at IS NULL
          AND fd.status IN ('PENDING', 'DRAFT')
          AND fd.created_at >= NOW() - INTERVAL 5 MINUTE
    ";
    $stmt = $conn->prepare($refreshSql);
    $stmt->bind_param('s', $documentType);
    $stmt->execute();
    $stmt->close();

    $snapshotSql = "
        UPDATE finance_documents target
        SET
            target.counterparty_gstin = COALESCE(
                NULLIF(TRIM(target.counterparty_gstin), ''),
                (
                    SELECT NULLIF(TRIM(source.counterparty_gstin), '')
                    FROM finance_documents source
                    WHERE source.counterparty_type = 'CLIENT'
                      AND source.deleted_at IS NULL
                      AND source.status IN ('GENERATED', 'OPEN', 'PART_PAID', 'PAID')
                      AND LOWER(TRIM(source.counterparty_name)) = LOWER(TRIM(target.counterparty_name))
                      AND NULLIF(TRIM(source.counterparty_gstin), '') IS NOT NULL
                    ORDER BY source.generated_at DESC, source.id DESC
                    LIMIT 1
                )
            ),
            target.counterparty_contact = COALESCE(
                NULLIF(TRIM(target.counterparty_contact), ''),
                (
                    SELECT NULLIF(TRIM(source.counterparty_contact), '')
                    FROM finance_documents source
                    WHERE source.counterparty_type = 'CLIENT'
                      AND source.deleted_at IS NULL
                      AND source.status IN ('GENERATED', 'OPEN', 'PART_PAID', 'PAID')
                      AND LOWER(TRIM(source.counterparty_name)) = LOWER(TRIM(target.counterparty_name))
                      AND NULLIF(TRIM(source.counterparty_contact), '') IS NOT NULL
                    ORDER BY source.generated_at DESC, source.id DESC
                    LIMIT 1
                )
            ),
            target.counterparty_email = COALESCE(
                NULLIF(TRIM(target.counterparty_email), ''),
                (
                    SELECT NULLIF(TRIM(source.counterparty_email), '')
                    FROM finance_documents source
                    WHERE source.counterparty_type = 'CLIENT'
                      AND source.deleted_at IS NULL
                      AND source.status IN ('GENERATED', 'OPEN', 'PART_PAID', 'PAID')
                      AND LOWER(TRIM(source.counterparty_name)) = LOWER(TRIM(target.counterparty_name))
                      AND NULLIF(TRIM(source.counterparty_email), '') IS NOT NULL
                    ORDER BY source.generated_at DESC, source.id DESC
                    LIMIT 1
                )
            ),
            target.counterparty_state = COALESCE(
                NULLIF(TRIM(target.counterparty_state), ''),
                (
                    SELECT NULLIF(TRIM(source.counterparty_state), '')
                    FROM finance_documents source
                    WHERE source.counterparty_type = 'CLIENT'
                      AND source.deleted_at IS NULL
                      AND source.status IN ('GENERATED', 'OPEN', 'PART_PAID', 'PAID')
                      AND LOWER(TRIM(source.counterparty_name)) = LOWER(TRIM(target.counterparty_name))
                      AND NULLIF(TRIM(source.counterparty_state), '') IS NOT NULL
                    ORDER BY source.generated_at DESC, source.id DESC
                    LIMIT 1
                )
            ),
            target.counterparty_state_code = COALESCE(
                NULLIF(TRIM(target.counterparty_state_code), ''),
                (
                    SELECT NULLIF(TRIM(source.counterparty_state_code), '')
                    FROM finance_documents source
                    WHERE source.counterparty_type = 'CLIENT'
                      AND source.deleted_at IS NULL
                      AND source.status IN ('GENERATED', 'OPEN', 'PART_PAID', 'PAID')
                      AND LOWER(TRIM(source.counterparty_name)) = LOWER(TRIM(target.counterparty_name))
                      AND NULLIF(TRIM(source.counterparty_state_code), '') IS NOT NULL
                    ORDER BY source.generated_at DESC, source.id DESC
                    LIMIT 1
                )
            )
        WHERE target.document_type = ?
          AND target.deleted_at IS NULL
          AND target.status IN ('PENDING', 'DRAFT')
          AND target.created_at >= NOW() - INTERVAL 5 MINUTE
    ";
    $stmt = $conn->prepare($snapshotSql);
    $stmt->bind_param('s', $documentType);
    $stmt->execute();
    $stmt->close();

    $rateSql = 'COALESCE(fpc.selling_rate, 0.00)';
    $mrpSql = 'COALESCE(fpc.mrp, 0.00)';
    $taxSql = $documentType === 'DELIVERY_CHALLAN' ? '0.000' : 'COALESCE(p.gst_rate, 0.000) / 2';
    $itemSql = "
        INSERT INTO finance_document_items
            (document_id, source_table, source_item_id, product_id, product_name, hsn_code,
             pack_size, quantity, unit_id, unit_label, batch_number, manufacturing_date,
             expiry_date, coa_number, mrp, rate, cgst_percent, sgst_percent, sort_order, created_by)
        SELECT
            fd.id,
            'stock_outward_items',
            soi.id,
            soi.product_id,
            COALESCE(p.product_name, CONCAT('Product #', soi.product_id)),
            COALESCE(fpc.hsn_code, ''),
            COALESCE(pps.pack_size, ''),
            soi.issued_quantity,
            soi.issued_unit,
            COALESCE(su.short_name, su.fullname, ''),
            COALESCE(NULLIF(soi.lot_batch_no, ''), soi.lot_batch_no_inputted, ''),
            soi.mfg_date,
            soi.exp_date,
            soi.coa_number,
            {$mrpSql},
            {$rateSql},
            {$taxSql},
            {$taxSql},
            soi.id,
            ?
        FROM finance_documents fd
        JOIN stock_outward_items soi
          ON soi.outward_id = fd.dispatch_id
         AND soi.status = 1
         AND soi.deleted_at IS NULL
        LEFT JOIN products p ON p.id = soi.product_id
        LEFT JOIN standard_units su ON su.id = soi.issued_unit
        LEFT JOIN (
            SELECT product_id, MIN(id) AS pack_id
            FROM product_pack_sizes
            WHERE status = 1 AND deleted_at IS NULL
            GROUP BY product_id
        ) first_pack ON first_pack.product_id = soi.product_id
        LEFT JOIN product_pack_sizes pps ON pps.id = first_pack.pack_id
        LEFT JOIN finance_product_commercials fpc
          ON fpc.id = (
              SELECT fpc2.id
              FROM finance_product_commercials fpc2
              WHERE fpc2.product_id = soi.product_id
                AND fpc2.status = 1
                AND fpc2.deleted_at IS NULL
                AND fpc2.effective_from <= CURRENT_DATE
                AND (fpc2.effective_to IS NULL OR fpc2.effective_to >= CURRENT_DATE)
              ORDER BY fpc2.effective_from DESC, fpc2.id DESC
              LIMIT 1
          )
        WHERE fd.document_type = ?
          AND fd.source_type = 'STOCK_OUTWARD'
          AND fd.deleted_at IS NULL
          AND fd.created_at >= NOW() - INTERVAL 5 MINUTE
          AND NOT EXISTS (
              SELECT 1
              FROM finance_document_items existing
              WHERE existing.document_id = fd.id
                AND existing.source_table = 'stock_outward_items'
                AND existing.source_item_id = soi.id
          )
    ";
    $stmt = $conn->prepare($itemSql);
    $stmt->bind_param('is', $userId, $documentType);
    $stmt->execute();
    $stmt->close();

    financeEnrichDispatchDocumentsFromProforma($conn, $documentType, true);

    $stmt = $conn->prepare(
        "INSERT IGNORE INTO finance_document_source_links (document_id, source_table, source_id)
         SELECT fd.id, 'stock_outward', fd.dispatch_id
         FROM finance_documents fd
         WHERE fd.document_type = ?
           AND fd.source_type = 'STOCK_OUTWARD'
           AND fd.dispatch_id IS NOT NULL
           AND fd.deleted_at IS NULL
           AND fd.created_at >= NOW() - INTERVAL 5 MINUTE"
    );
    $stmt->bind_param('s', $documentType);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare(
        "INSERT INTO finance_document_history
            (document_id, event_type, from_status, to_status, remarks, created_by)
         SELECT fd.id, 'SOURCE_IMPORTED', NULL, 'PENDING', 'Imported from Goods Dispatch.', ?
         FROM finance_documents fd
         WHERE fd.document_type = ?
           AND fd.source_type = 'STOCK_OUTWARD'
           AND fd.deleted_at IS NULL
           AND NOT EXISTS (
               SELECT 1 FROM finance_document_history fdh
               WHERE fdh.document_id = fd.id AND fdh.event_type = 'SOURCE_IMPORTED'
           )"
    );
    $stmt->bind_param('is', $userId, $documentType);
    $stmt->execute();
    $stmt->close();

    return $inserted;
}

function financeRefreshPendingCommercials(mysqli $conn, ?int $productId = null): int
{
    $productFilter = $productId ? ' AND fdi.product_id = ?' : '';
    $sql = "
        UPDATE finance_document_items fdi
        JOIN finance_documents fd ON fd.id = fdi.document_id
        LEFT JOIN products p ON p.id = fdi.product_id
        SET
            fdi.hsn_code = CASE
                WHEN NULLIF(TRIM(fdi.hsn_code), '') IS NULL THEN COALESCE((
                    SELECT NULLIF(TRIM(fpc.hsn_code), '')
                    FROM finance_product_commercials fpc
                    WHERE fpc.product_id = fdi.product_id
                      AND fpc.status = 1
                      AND fpc.deleted_at IS NULL
                      AND fpc.effective_from <= COALESCE(fd.document_date, CURRENT_DATE)
                      AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(fd.document_date, CURRENT_DATE))
                    ORDER BY fpc.effective_from DESC, fpc.id DESC
                    LIMIT 1
                ), (
                    SELECT NULLIF(TRIM(fdi2.hsn_code), '')
                    FROM finance_document_items fdi2
                    WHERE fdi2.product_id = fdi.product_id
                      AND fdi2.id != fdi.id
                      AND NULLIF(TRIM(fdi2.hsn_code), '') IS NOT NULL
                    ORDER BY fdi2.id DESC
                    LIMIT 1
                ), fdi.hsn_code) ELSE fdi.hsn_code END,
            fdi.mrp = CASE
                WHEN fdi.mrp = 0 THEN COALESCE((
                    SELECT fpc.mrp
                    FROM finance_product_commercials fpc
                    WHERE fpc.product_id = fdi.product_id
                      AND fpc.status = 1
                      AND fpc.deleted_at IS NULL
                      AND fpc.effective_from <= COALESCE(fd.document_date, CURRENT_DATE)
                      AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(fd.document_date, CURRENT_DATE))
                    ORDER BY fpc.effective_from DESC, fpc.id DESC
                    LIMIT 1
                ), 0) ELSE fdi.mrp END,
            fdi.rate = CASE
                WHEN fdi.rate = 0 THEN COALESCE((
                    SELECT fpc.selling_rate
                    FROM finance_product_commercials fpc
                    WHERE fpc.product_id = fdi.product_id
                      AND fpc.status = 1
                      AND fpc.deleted_at IS NULL
                      AND fpc.effective_from <= COALESCE(fd.document_date, CURRENT_DATE)
                      AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(fd.document_date, CURRENT_DATE))
                    ORDER BY fpc.effective_from DESC, fpc.id DESC
                    LIMIT 1
                ), 0) ELSE fdi.rate END,
            fdi.cgst_percent = CASE
                WHEN fdi.cgst_percent = 0
                THEN COALESCE((
                    SELECT COALESCE(fpc.gst_rate, p.gst_rate, 0) / 2
                    FROM finance_product_commercials fpc
                    WHERE fpc.product_id = fdi.product_id
                      AND fpc.status = 1
                      AND fpc.deleted_at IS NULL
                      AND fpc.effective_from <= COALESCE(fd.document_date, CURRENT_DATE)
                      AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(fd.document_date, CURRENT_DATE))
                    ORDER BY fpc.effective_from DESC, fpc.id DESC
                    LIMIT 1
                ), COALESCE(p.gst_rate, 0) / 2)
                ELSE fdi.cgst_percent END,
            fdi.sgst_percent = CASE
                WHEN fdi.sgst_percent = 0
                THEN COALESCE((
                    SELECT COALESCE(fpc.gst_rate, p.gst_rate, 0) / 2
                    FROM finance_product_commercials fpc
                    WHERE fpc.product_id = fdi.product_id
                      AND fpc.status = 1
                      AND fpc.deleted_at IS NULL
                      AND fpc.effective_from <= COALESCE(fd.document_date, CURRENT_DATE)
                      AND (fpc.effective_to IS NULL OR fpc.effective_to >= COALESCE(fd.document_date, CURRENT_DATE))
                    ORDER BY fpc.effective_from DESC, fpc.id DESC
                    LIMIT 1
                ), COALESCE(p.gst_rate, 0) / 2)
                ELSE fdi.sgst_percent END,
            fdi.updated_at = NOW()
        WHERE fd.document_type IN ('VENDOR_BILL', 'SALES_INVOICE')
          AND fd.status IN ('PENDING', 'DRAFT')
          AND fd.deleted_at IS NULL
          AND fdi.product_id IS NOT NULL
          {$productFilter}
    ";
    $stmt = $conn->prepare($sql);
    if ($productId) {
        $stmt->bind_param('i', $productId);
    }
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();
    return max(0, $affected);
}

/**
 * Drain an explicit source reconciliation in bounded batches. Normal workflow
 * hooks usually import one new source, while this prevents an old backlog from
 * requiring multiple Finance page polling cycles.
 */
function financeDrainSourceSync(callable $sync, int $batchSize = 1000, int $maxBatches = 50): int
{
    $batchSize = max(1, min(1000, $batchSize));
    $maxBatches = max(1, min(50, $maxBatches));
    $total = 0;

    for ($batch = 0; $batch < $maxBatches; $batch++) {
        $inserted = max(0, (int) $sync($batchSize));
        $total += $inserted;
        if ($inserted < $batchSize) {
            break;
        }
    }

    return $total;
}

function financeSyncSources(mysqli $conn, ?string $scope, int $userId): array
{
    $result = ['vendor_bills' => 0, 'sales_invoices' => 0, 'delivery_challans' => 0];
    if ($scope === null || $scope === 'bill_generation') {
        $result['vendor_bills'] = financeDrainSourceSync(
            static fn(int $limit): int => financeSyncVendorBills($conn, $userId, $limit)
        );
    }
    if ($scope === null || $scope === 'invoice_generation') {
        $result['sales_invoices'] = financeDrainSourceSync(
            static fn(int $limit): int => financeSyncDispatchDocuments(
                $conn,
                'SALES_INVOICE',
                $userId,
                $limit
            )
        );
    }
    if ($scope === null || $scope === 'challan_generation') {
        $result['delivery_challans'] = financeDrainSourceSync(
            static fn(int $limit): int => financeSyncDispatchDocuments(
                $conn,
                'DELIVERY_CHALLAN',
                $userId,
                $limit
            )
        );
    }
    return $result;
}

function financeSyncAfterGoodsReceipt(mysqli $conn, int $userId): void
{
    $conn->begin_transaction();
    try {
        financeDrainSourceSync(
            static fn(int $limit): int => financeSyncVendorBills($conn, $userId, $limit)
        );
        $conn->commit();
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function financeSyncAfterGoodsDispatch(mysqli $conn, int $userId): void
{
    $conn->begin_transaction();
    try {
        financeDrainSourceSync(
            static fn(int $limit): int => financeSyncDispatchDocuments(
                $conn,
                'SALES_INVOICE',
                $userId,
                $limit
            )
        );
        financeDrainSourceSync(
            static fn(int $limit): int => financeSyncDispatchDocuments(
                $conn,
                'DELIVERY_CHALLAN',
                $userId,
                $limit
            )
        );
        $conn->commit();
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function financeGetDocument(mysqli $conn, int $documentId): ?array
{
    $stmt = $conn->prepare(
        "SELECT fd.*, u.name AS created_by_name,
                receiver.name AS received_by_name,
                dispatcher.name AS dispatched_by_name,
                GREATEST(fd.grand_total - fd.amount_paid, 0) AS outstanding_amount
         FROM finance_documents fd
         LEFT JOIN users u ON u.id = fd.created_by
         LEFT JOIN receiver_emp receiver ON receiver.id = fd.received_by
         LEFT JOIN receiver_emp dispatcher ON dispatcher.id = fd.dispatched_by
         WHERE fd.id = ? AND fd.deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$document) {
        return null;
    }

    if (
        empty($document['counterparty_address'])
        || empty($document['counterparty_gstin'])
        || empty($document['counterparty_state'])
    ) {
        $cust = null;
        if (!empty($document['order_id'])) {
            $custStmt = $conn->prepare("SELECT c.* FROM order_received o JOIN customers c ON c.id = o.customer_id WHERE o.id = ? LIMIT 1");
            if ($custStmt) {
                $custStmt->bind_param('i', $document['order_id']);
                $custStmt->execute();
                $cust = $custStmt->get_result()->fetch_assoc();
                $custStmt->close();
            }
        }
        if (!$cust && !empty($document['counterparty_name'])) {
            $custStmt = $conn->prepare("SELECT * FROM customers WHERE (name = ? OR company_name = ?) AND status = 1 LIMIT 1");
            if ($custStmt) {
                $custStmt->bind_param('ss', $document['counterparty_name'], $document['counterparty_name']);
                $custStmt->execute();
                $cust = $custStmt->get_result()->fetch_assoc();
                $custStmt->close();
            }
        }
        if ($cust) {
            if (empty($document['counterparty_address'])) $document['counterparty_address'] = $cust['detailed_address'] ?: '';
            if (empty($document['counterparty_shipping_address'])) $document['counterparty_shipping_address'] = $cust['detailed_address'] ?: '';
            if (empty($document['counterparty_gstin'])) $document['counterparty_gstin'] = $cust['gstin'] ?: '';
            if (empty($document['counterparty_state'])) $document['counterparty_state'] = $cust['state_province'] ?: '';
            if (empty($document['counterparty_state_code'])) $document['counterparty_state_code'] = $cust['state_code'] ?: '';
            if (empty($document['counterparty_contact'])) $document['counterparty_contact'] = $cust['phone'] ?: '';
            if (empty($document['counterparty_email'])) $document['counterparty_email'] = $cust['email'] ?: '';
            if (empty($document['credit_days']) && !empty($cust['credit_days'])) {
                $document['credit_days'] = (int) $cust['credit_days'];
            }
        }
    }

    $stmt = $conn->prepare(
        "SELECT * FROM finance_document_items WHERE document_id = ? ORDER BY sort_order, id"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document['items'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($document['items'] as &$item) {
        $pId = (int) ($item['product_id'] ?? 0);
        if (empty($item['hsn_code']) && $pId > 0) {
            $pStmt = $conn->prepare("SELECT hsn_code, gst_rate FROM products WHERE id = ? LIMIT 1");
            if ($pStmt) {
                $pStmt->bind_param('i', $pId);
                $pStmt->execute();
                $pRes = $pStmt->get_result()->fetch_assoc();
                $pStmt->close();
                if ($pRes && !empty($pRes['hsn_code'])) {
                    $item['hsn_code'] = $pRes['hsn_code'];
                }
            }
        }
        if ((empty($item['manufacturing_date']) || empty($item['expiry_date']) || empty($item['batch_number'])) && $pId > 0) {
            if (!empty($item['batch_number'])) {
                $bStmt = $conn->prepare("SELECT mfg_date, exp_date FROM live_stock WHERE product_id = ? AND lot_batch_no COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci AND deleted_at IS NULL ORDER BY id DESC LIMIT 1");
                if ($bStmt) {
                    $bStmt->bind_param('is', $pId, $item['batch_number']);
                    $bStmt->execute();
                    $bRes = $bStmt->get_result()->fetch_assoc();
                    $bStmt->close();
                    if ($bRes) {
                        if (empty($item['manufacturing_date']) && !empty($bRes['mfg_date'])) $item['manufacturing_date'] = $bRes['mfg_date'];
                        if (empty($item['expiry_date']) && !empty($bRes['exp_date'])) $item['expiry_date'] = $bRes['exp_date'];
                    }
                }
            } else {
                $lsStmt = $conn->prepare("SELECT lot_batch_no, mfg_date, exp_date FROM live_stock WHERE product_id = ? AND NULLIF(lot_batch_no, '') IS NOT NULL AND deleted_at IS NULL ORDER BY id DESC LIMIT 1");
                if ($lsStmt) {
                    $lsStmt->bind_param('i', $pId);
                    $lsStmt->execute();
                    $lsRes = $lsStmt->get_result()->fetch_assoc();
                    $lsStmt->close();
                    if ($lsRes) {
                        if (empty($item['batch_number'])) $item['batch_number'] = $lsRes['lot_batch_no'];
                        if (empty($item['manufacturing_date']) && !empty($lsRes['mfg_date'])) $item['manufacturing_date'] = $lsRes['mfg_date'];
                        if (empty($item['expiry_date']) && !empty($lsRes['exp_date'])) $item['expiry_date'] = $lsRes['exp_date'];
                    }
                }
            }
            // Fallback to transfer_ticket if still missing
            if (empty($item['batch_number']) || empty($item['manufacturing_date']) || empty($item['expiry_date'])) {
                $ttStmt = $conn->prepare("SELECT tt.batch_no, tt.mfg_date, tt.exp_date FROM transfer_ticket tt JOIN products p ON (p.product_code COLLATE utf8mb4_unicode_ci = tt.code OR p.product_name COLLATE utf8mb4_unicode_ci = tt.product_description) WHERE p.id = ? AND NULLIF(tt.batch_no, '') IS NOT NULL AND tt.deleted_at IS NULL ORDER BY tt.id DESC LIMIT 1");
                if ($ttStmt) {
                    $ttStmt->bind_param('i', $pId);
                    $ttStmt->execute();
                    $ttRes = $ttStmt->get_result()->fetch_assoc();
                    $ttStmt->close();
                    if ($ttRes) {
                        if (empty($item['batch_number']) && !empty($ttRes['batch_no'])) $item['batch_number'] = $ttRes['batch_no'];
                        if (empty($item['manufacturing_date']) && !empty($ttRes['mfg_date'])) $item['manufacturing_date'] = $ttRes['mfg_date'];
                        if (empty($item['expiry_date']) && !empty($ttRes['exp_date'])) $item['expiry_date'] = $ttRes['exp_date'];
                    }
                }
            }
        }
    }
    unset($item);

    if ($document['document_type'] === 'DELIVERY_CHALLAN') {
        $document['reference_total'] = financeReferenceTotal($document['items']);
    }

    $stmt = $conn->prepare(
        "SELECT id, file_type, original_name, mime_type, file_size, version_number, created_at
         FROM finance_document_files
         WHERE document_id = ?
         ORDER BY file_type, version_number DESC, id DESC"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document['files'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Fallback: if VENDOR_BILL has no SOURCE_INVOICE file in finance_document_files, import from stock_inwards
    $hasSourceInvoice = false;
    foreach ($document['files'] as $f) {
        if ($f['file_type'] === 'SOURCE_INVOICE') {
            $hasSourceInvoice = true;
            break;
        }
    }
    if (!$hasSourceInvoice && $document['document_type'] === 'VENDOR_BILL') {
        $siId = 0;
        if (!empty($document['source_id']) && $document['source_type'] === 'STOCK_INWARD') {
            $siId = (int) $document['source_id'];
        } elseif (!empty($document['source_key']) && preg_match('/INWARD_(\d+)/', $document['source_key'], $m)) {
            $siId = (int) $m[1];
        }
        if ($siId > 0) {
            $siStmt = $conn->prepare("SELECT invoice_file, invoice_image FROM stock_inwards WHERE id = ? LIMIT 1");
            if ($siStmt) {
                $siStmt->bind_param('i', $siId);
                $siStmt->execute();
                $siRow = $siStmt->get_result()->fetch_assoc();
                $siStmt->close();
                if ($siRow) {
                    $rawFiles = [];
                    foreach (['invoice_file', 'invoice_image'] as $col) {
                        if (!empty($siRow[$col])) {
                            $decoded = financeDecodeStoredFiles($siRow[$col]);
                            if (!empty($decoded)) {
                                $rawFiles = array_merge($rawFiles, $decoded);
                            }
                        }
                    }
                    if (!empty($rawFiles)) {
                        foreach ($rawFiles as $rf) {
                            $addedFile = financeAddSourceFile($conn, $documentId, $rf, (int) ($document['created_by'] ?? 0));
                            if ($addedFile) {
                                $document['files'][] = $addedFile;
                            }
                        }
                    }
                }
            }
        }
    }

    $stmt = $conn->prepare(
        "SELECT fp.id, fp.direction, fp.payment_date, fp.amount, fp.payment_mode,
                fp.reference_number, fp.status, fp.notes, fpa.allocated_amount,
                u.name AS recorded_by
         FROM finance_payment_allocations fpa
         JOIN finance_payments fp ON fp.id = fpa.payment_id
         LEFT JOIN users u ON u.id = fp.created_by
         WHERE fpa.document_id = ?
         ORDER BY fp.payment_date DESC, fp.id DESC"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document['payments'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $stmt = $conn->prepare(
        "SELECT fdh.*, u.name AS user_name
         FROM finance_document_history fdh
         LEFT JOIN users u ON u.id = fdh.created_by
         WHERE fdh.document_id = ?
         ORDER BY fdh.id DESC
         LIMIT 100"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $document['history'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $companyId = $document['erp_company_id'] !== null ? (int) $document['erp_company_id'] : financeCurrentCompanyId($conn);
    $document['company_options'] = [];
    $companies = $conn->query(
        "SELECT id, company_name, legal_name, company_code, gst_no
         FROM erp_companies
         WHERE status = 1 AND deleted_at IS NULL
         ORDER BY company_name, id"
    );
    if ($companies) {
        $document['company_options'] = $companies->fetch_all(MYSQLI_ASSOC);
    }

    $company = null;
    if ($companyId) {
        $stmt = $conn->prepare("SELECT * FROM erp_companies WHERE id = ? AND deleted_at IS NULL LIMIT 1");
        $stmt->bind_param('i', $companyId);
        $stmt->execute();
        $company = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
    $company = $company ?: [];
    $profileId = (int) (financeCurrentProfileId($conn, $companyId) ?? 0);

    if ($profileId > 0) {
        $stmt = $conn->prepare(
            "SELECT legal_name, trade_name, cin_no, gst_no, udyam_no,
                    manufacturing_license_no, website
             FROM company_profiles
             WHERE id = ? AND status = 1 AND deleted_at IS NULL
             LIMIT 1"
        );
        $stmt->bind_param('i', $profileId);
        $stmt->execute();
        $profile = $stmt->get_result()->fetch_assoc() ?: [];
        $stmt->close();
        foreach ($profile as $key => $value) {
            if ($value !== null && trim((string) $value) !== '') {
                $company[$key] = $value;
            }
        }

        $stmt = $conn->prepare(
            "SELECT address_type, address
             FROM company_profile_addresses
             WHERE company_id = ?
             ORDER BY is_primary DESC, sort_order, id"
        );
        $stmt->bind_param('i', $profileId);
        $stmt->execute();
        $addresses = $stmt->get_result();
        while ($address = $addresses->fetch_assoc()) {
            $key = strtolower((string) $address['address_type']) . '_address';
            if (!isset($company[$key])) {
                $company[$key] = $address['address'];
            }
            if (empty($company['address'])) {
                $company['address'] = $address['address'];
            }
        }
        $stmt->close();

        $stmt = $conn->prepare(
            "SELECT contact_type, contact_value
             FROM company_profile_contacts
             WHERE company_id = ?
             ORDER BY is_primary DESC, sort_order, id"
        );
        $stmt->bind_param('i', $profileId);
        $stmt->execute();
        $contacts = $stmt->get_result();
        while ($contact = $contacts->fetch_assoc()) {
            $contactType = strtolower(trim((string) $contact['contact_type']));
            $contactValue = trim((string) $contact['contact_value']);
            if ($contactValue === '') {
                continue;
            }
            if (str_contains($contactType, 'email') && empty($company['email'])) {
                $company['email'] = $contactValue;
            } elseif (
                (str_contains($contactType, 'phone') || str_contains($contactType, 'mobile'))
                && empty($company['mobile'])
            ) {
                $company['mobile'] = $contactValue;
            }
        }
        $stmt->close();
    }

    $document['company_profile_id'] = $profileId ?: null;
    $document['company'] = $company;
    if (trim((string) ($document['terms_snapshot'] ?? '')) === '') {
        $document['terms_snapshot'] = financeDefaultTerms(
            $conn,
            $companyId,
            $profileId ?: null,
            (string) $document['document_type']
        );
    }

    $document['company_documents'] = [];
    if ($profileId > 0) {
        $stmt = $conn->prepare(
            "SELECT document_type, file_path
             FROM company_profile_documents
             WHERE company_id = ?
             ORDER BY id"
        );
        $stmt->bind_param('i', $profileId);
        $stmt->execute();
        $companyDocuments = $stmt->get_result();
        while ($companyDocument = $companyDocuments->fetch_assoc()) {
            $document['company_documents'][$companyDocument['document_type']] = $companyDocument['file_path'];
        }
        $stmt->close();
    }

    $stmt = $conn->prepare(
        "SELECT * FROM finance_company_bank_accounts
         WHERE status = 1 AND deleted_at IS NULL
           AND (erp_company_id = ? OR erp_company_id IS NULL OR ? <= 0)
         ORDER BY (erp_company_id = ?) DESC, is_default DESC, id"
    );
    $stmt->bind_param('iii', $companyId, $companyId, $companyId);
    $stmt->execute();
    $document['bank_accounts'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $selectedBank = null;
    foreach ($document['bank_accounts'] as $bank) {
        if ((int) ($bank['id'] ?? 0) === (int) ($document['bank_account_id'] ?? 0)) {
            $selectedBank = $bank;
            break;
        }
    }
    $selectedBank = $selectedBank ?: ($document['bank_accounts'][0] ?? []);
    $bankSnapshot = json_decode((string) ($document['bank_snapshot'] ?? ''), true);
    if (is_array($bankSnapshot)) {
        foreach ($bankSnapshot as $key => $value) {
            if (in_array($key, [
                'bank_name', 'branch_name', 'account_name', 'account_number',
                'ifsc_code', 'swift_code', 'upi_id', 'qr_file',
            ], true)) {
                $selectedBank[$key] = $value;
            }
        }
    }
    $document['selected_bank'] = $selectedBank;

    if (
        $document['document_type'] === 'SALES_INVOICE'
        && in_array($document['status'], ['PENDING', 'DRAFT'], true)
    ) {
        $configuredCreditDays = financeCounterpartyCreditDefault(
            $conn,
            (string) $document['counterparty_name'],
            $document['counterparty_gstin'] ?? null
        );
        if ($configuredCreditDays !== null) {
            $document['credit_days'] = $configuredCreditDays;
            $baseDate = (string) ($document['document_date'] ?: date('Y-m-d'));
            $document['due_date'] = date(
                'Y-m-d',
                strtotime($baseDate . ' +' . $configuredCreditDays . ' days')
            );
            $document['credit_days_source'] = 'FINANCE_MASTER';
        }
    }

    return $document;
}

function financeFinancialYear(?string $date = null): string
{
    $timestamp = $date ? strtotime($date) : time();
    $year = (int) date('Y', $timestamp);
    $month = (int) date('n', $timestamp);
    $start = $month >= 4 ? $year : $year - 1;
    return sprintf('%d-%02d', $start, ($start + 1) % 100);
}

function financeNextNumber(mysqli $conn, int $companyId, string $documentType, string $documentDate): string
{
    $prefix = $documentType === 'DELIVERY_CHALLAN' ? 'DC' : 'INV';
    $financialYear = financeFinancialYear($documentDate);

    // Ensure the sequence row exists before locking it. The unique company/type/
    // financial-year key makes this safe even when two first-time generations
    // arrive together; the duplicate-key branch waits on the winning insert.
    $zero = 0;
    $stmt = $conn->prepare(
        "INSERT INTO finance_number_sequences
            (erp_company_id, document_type, financial_year, prefix, last_number)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)"
    );
    $stmt->bind_param('isssi', $companyId, $documentType, $financialYear, $prefix, $zero);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare(
        "SELECT id, last_number
         FROM finance_number_sequences
         WHERE erp_company_id = ? AND document_type = ? AND financial_year = ?
         FOR UPDATE"
    );
    $stmt->bind_param('iss', $companyId, $documentType, $financialYear);
    $stmt->execute();
    $sequence = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$sequence) {
        throw new RuntimeException('Unable to initialize the Finance document number sequence.');
    }

    $number = (int) $sequence['last_number'] + 1;
    $sequenceId = (int) $sequence['id'];
    $stmt = $conn->prepare(
        "UPDATE finance_number_sequences SET last_number = ?, updated_at = NOW() WHERE id = ?"
    );
    $stmt->bind_param('ii', $number, $sequenceId);
    $stmt->execute();
    $stmt->close();

    return sprintf('%s/%s/%06d', $prefix, $financialYear, $number);
}

function financeNumeric(mixed $value, float $minimum = 0.0): float
{
    if (is_string($value)) {
        $value = str_replace(',', '', trim($value));
    }
    $number = is_numeric($value) ? (float) $value : 0.0;
    return max($minimum, $number);
}

function financeReferenceValue(array $item): float
{
    return round(
        financeNumeric($item['quantity'] ?? 0) * financeNumeric($item['rate'] ?? 0),
        2
    );
}

function financeReferenceTotal(array $items): float
{
    $total = 0.0;
    foreach ($items as $item) {
        if (is_array($item)) {
            $total += financeReferenceValue($item);
        }
    }

    return round($total, 2);
}

function financeCalculateItems(array $items, string $documentType, string $taxMode): array
{
    $normalized = [];
    $totals = [
        'subtotal' => 0.0,
        'discount_total' => 0.0,
        'taxable_total' => 0.0,
        'cgst_total' => 0.0,
        'sgst_total' => 0.0,
        'igst_total' => 0.0,
        'round_off' => 0.0,
        'grand_total' => 0.0,
    ];

    foreach (array_values($items) as $index => $item) {
        if (!is_array($item)) {
            continue;
        }

        $quantity = financeNumeric($item['quantity'] ?? 0);
        $rate = financeNumeric($item['rate'] ?? 0);
        $mrp = financeNumeric($item['mrp'] ?? 0);
        $discountPercent = $documentType === 'DELIVERY_CHALLAN'
            ? 0.0
            : min(100.0, financeNumeric($item['discount_percent'] ?? 0));
        $cgstPercent = 0.0;
        $sgstPercent = 0.0;
        $igstPercent = 0.0;

        if ($documentType !== 'DELIVERY_CHALLAN') {
            if ($taxMode === 'INTER') {
                $igstPercent = financeNumeric($item['igst_percent'] ?? 0);
                if ($igstPercent <= 0) {
                    $igstPercent = financeNumeric($item['cgst_percent'] ?? 0)
                        + financeNumeric($item['sgst_percent'] ?? 0);
                }
            } elseif ($taxMode === 'INTRA') {
                $cgstPercent = financeNumeric($item['cgst_percent'] ?? 0);
                $sgstPercent = financeNumeric($item['sgst_percent'] ?? 0);
            }
        }

        $gross = round($quantity * $rate, 2);
        $discountValue = round($gross * $discountPercent / 100, 2);
        $taxable = round($gross - $discountValue, 2);
        $cgstValue = round($taxable * $cgstPercent / 100, 2);
        $sgstValue = round($taxable * $sgstPercent / 100, 2);
        $igstValue = round($taxable * $igstPercent / 100, 2);
        $lineTotal = round($taxable + $cgstValue + $sgstValue + $igstValue, 2);

        $normalized[] = [
            'id' => (int) ($item['id'] ?? 0),
            'source_table' => trim((string) ($item['source_table'] ?? '')),
            'source_item_id' => (int) ($item['source_item_id'] ?? 0),
            'product_id' => (int) ($item['product_id'] ?? 0),
            'product_name' => trim((string) ($item['product_name'] ?? 'Unspecified item')),
            'hsn_code' => trim((string) ($item['hsn_code'] ?? '')),
            'pack_size' => trim((string) ($item['pack_size'] ?? '')),
            'quantity' => $quantity,
            'free_quantity' => financeNumeric($item['free_quantity'] ?? 0),
            'unit_id' => (int) ($item['unit_id'] ?? 0),
            'unit_label' => trim((string) ($item['unit_label'] ?? '')),
            'batch_number' => trim((string) ($item['batch_number'] ?? '')),
            'manufacturing_date' => trim((string) ($item['manufacturing_date'] ?? '')) ?: null,
            'expiry_date' => trim((string) ($item['expiry_date'] ?? '')) ?: null,
            'coa_number' => trim((string) ($item['coa_number'] ?? '')),
            'mrp' => $mrp,
            'rate' => $rate,
            'gross_amount' => $gross,
            'discount_percent' => $discountPercent,
            'discount_value' => $discountValue,
            'taxable_value' => $taxable,
            'cgst_percent' => $cgstPercent,
            'cgst_value' => $cgstValue,
            'sgst_percent' => $sgstPercent,
            'sgst_value' => $sgstValue,
            'igst_percent' => $igstPercent,
            'igst_value' => $igstValue,
            'line_total' => $lineTotal,
            'sort_order' => $index + 1,
        ];

        $totals['subtotal'] += $gross;
        $totals['discount_total'] += $discountValue;
        $totals['taxable_total'] += $taxable;
        $totals['cgst_total'] += $cgstValue;
        $totals['sgst_total'] += $sgstValue;
        $totals['igst_total'] += $igstValue;
    }

    $unrounded = round(
        $totals['taxable_total'] + $totals['cgst_total'] + $totals['sgst_total'] + $totals['igst_total'],
        2
    );
    if ($documentType === 'DELIVERY_CHALLAN') {
        $totals['round_off'] = 0.0;
        $totals['grand_total'] = $unrounded;
    } else {
        $totals['round_off'] = round(round($unrounded, 0) - $unrounded, 2);
        $totals['grand_total'] = round($unrounded + $totals['round_off'], 2);
    }

    foreach ($totals as $key => $value) {
        $totals[$key] = round($value, 2);
    }

    return ['items' => $normalized, 'totals' => $totals];
}

function financeRefreshDocumentPaymentStatus(mysqli $conn, int $documentId, int $userId): void
{
    $stmt = $conn->prepare(
        "SELECT fd.document_type, fd.status, fd.grand_total,
                COALESCE(SUM(CASE WHEN fp.status = 'POSTED' THEN fpa.allocated_amount ELSE 0 END), 0) AS paid
         FROM finance_documents fd
         LEFT JOIN finance_payment_allocations fpa ON fpa.document_id = fd.id
         LEFT JOIN finance_payments fp ON fp.id = fpa.payment_id
         WHERE fd.id = ?
         GROUP BY fd.id, fd.document_type, fd.status, fd.grand_total"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (
        !$row
        || $row['document_type'] === 'DELIVERY_CHALLAN'
        || in_array($row['status'], ['NO_DOCUMENT', 'VOID'], true)
    ) {
        return;
    }

    $paid = round((float) $row['paid'], 2);
    $total = round((float) $row['grand_total'], 2);
    if ($total > 0 && $paid >= $total) {
        $status = 'PAID';
    } elseif ($paid > 0) {
        $status = 'PART_PAID';
    } elseif ($row['document_type'] === 'SALES_INVOICE') {
        $status = 'GENERATED';
    } else {
        $status = 'OPEN';
    }

    $stmt = $conn->prepare(
        "UPDATE finance_documents
         SET amount_paid = ?, status = ?, status_changed_at = NOW(), status_changed_by = ?,
             updated_by = ?, updated_at = NOW()
         WHERE id = ?"
    );
    $stmt->bind_param('dsiii', $paid, $status, $userId, $userId, $documentId);
    $stmt->execute();
    $stmt->close();
}

function financeAmountInWords(float $amount): string
{
    $number = (int) round($amount);
    if ($number === 0) {
        return 'Zero Rupees Only';
    }

    $ones = [
        0 => '', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five',
        6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine', 10 => 'Ten',
        11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen',
        15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen',
    ];
    $tens = [
        2 => 'Twenty', 3 => 'Thirty', 4 => 'Forty', 5 => 'Fifty',
        6 => 'Sixty', 7 => 'Seventy', 8 => 'Eighty', 9 => 'Ninety',
    ];

    $twoDigits = static function (int $value) use ($ones, $tens): string {
        if ($value < 20) {
            return $ones[$value];
        }
        return trim($tens[intdiv($value, 10)] . ' ' . $ones[$value % 10]);
    };
    $threeDigits = static function (int $value) use ($twoDigits, $ones): string {
        $words = '';
        if ($value >= 100) {
            $words .= $ones[intdiv($value, 100)] . ' Hundred ';
            $value %= 100;
        }
        return trim($words . $twoDigits($value));
    };

    $parts = [];
    $crore = intdiv($number, 10000000);
    $number %= 10000000;
    $lakh = intdiv($number, 100000);
    $number %= 100000;
    $thousand = intdiv($number, 1000);
    $number %= 1000;

    if ($crore) {
        $parts[] = $threeDigits($crore) . ' Crore';
    }
    if ($lakh) {
        $parts[] = $twoDigits($lakh) . ' Lakh';
    }
    if ($thousand) {
        $parts[] = $twoDigits($thousand) . ' Thousand';
    }
    if ($number) {
        $parts[] = $threeDigits($number);
    }

    return trim(implode(' ', $parts)) . ' Rupees Only';
}
