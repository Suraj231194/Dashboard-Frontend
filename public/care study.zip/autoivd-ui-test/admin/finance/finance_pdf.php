<?php

declare(strict_types=1);

function financePdfAssetData(string $path): ?string
{
    if (!is_file($path) || !is_readable($path)) {
        return null;
    }

    $mime = function_exists('mime_content_type') ? mime_content_type($path) : 'image/png';
    $content = file_get_contents($path);
    if ($content === false) {
        return null;
    }

    return 'data:' . $mime . ';base64,' . base64_encode($content);
}

function financeResolveStoredAsset(?string $storedPath): ?string
{
    $storedPath = trim(str_replace('\\', '/', (string) $storedPath));
    if ($storedPath === '') {
        return null;
    }

    $projectRoot = dirname(__DIR__, 2);
    $adminRoot = dirname(__DIR__);
    $candidates = preg_match('#^[A-Za-z]:/#', $storedPath)
        ? [$storedPath]
        : [
            $adminRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $storedPath),
            $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $storedPath),
        ];
    foreach ($candidates as $candidate) {
        $real = realpath($candidate);
        if ($real && is_file($real)) {
            return $real;
        }
    }

    return null;
}

/**
 * The supplied PDFs are the canonical Finance print templates. Their hashes are
 * intentionally pinned so a replaced or edited sample cannot silently change
 * the legal document layout.
 */
function financeApprovedTemplateDefinition(string $documentType): array
{
    $projectRoot = dirname(__DIR__, 2);
    $definitions = [
        'SALES_INVOICE' => [
            'path' => $projectRoot . DIRECTORY_SEPARATOR . 'all details' . DIRECTORY_SEPARATOR . 'Invoice_1697.pdf',
            'name' => 'Invoice_1697.pdf',
            'sha256' => '7da8b045615e26cca955b6f39ea09183cb498567d1f4ada7e329a3d13e671945',
            'page_object' => 5,
            'content_object' => 40,
            'font_dictionary_object' => 39,
            'xobject_dictionary_object' => 38,
        ],
        'DELIVERY_CHALLAN' => [
            'path' => $projectRoot . DIRECTORY_SEPARATOR . 'all details' . DIRECTORY_SEPARATOR . 'CA_200.pdf',
            'name' => 'CA_200.pdf',
            'sha256' => 'f326a3e0b7876ecdfd7a2c30b3d69e24b854e2cbe0ba46a8536fe386e61cb711',
            'page_object' => 5,
            'content_object' => 25,
            'font_dictionary_object' => null,
            'xobject_dictionary_object' => null,
        ],
    ];

    if (!isset($definitions[$documentType])) {
        throw new RuntimeException('No approved Finance PDF template is configured for this document type.');
    }

    $definition = $definitions[$documentType];
    if (!is_file($definition['path']) || !is_readable($definition['path'])) {
        throw new RuntimeException('The approved Finance PDF template is missing: ' . $definition['name']);
    }
    $actualHash = hash_file('sha256', $definition['path']);
    if (!hash_equals($definition['sha256'], (string) $actualHash)) {
        throw new RuntimeException(
            'The approved Finance PDF template has changed. Restore the supplied ' . $definition['name'] . ' file.'
        );
    }

    return $definition;
}

function financePdfLastObjectBody(string $pdf, int $objectNumber): string
{
    $pattern = '/(?:^|[\r\n])' . preg_quote((string) $objectNumber, '/')
        . '\s+0\s+obj\s*(.*?)\s*endobj/s';
    if (!preg_match_all($pattern, $pdf, $matches) || empty($matches[1])) {
        throw new RuntimeException("The approved PDF template object {$objectNumber} could not be read.");
    }

    return trim((string) end($matches[1]));
}

function financePdfAppendDictionaryEntries(string $dictionary, string $entries): string
{
    $dictionary = rtrim($dictionary);
    if (!str_ends_with($dictionary, '>>')) {
        throw new RuntimeException('The approved PDF template dictionary is invalid.');
    }

    return substr($dictionary, 0, -2) . ' ' . trim($entries) . ' >>';
}

function financePdfEscapeLiteral(string $value): string
{
    $value = preg_replace('/[\r\n\t]+/u', ' ', trim($value)) ?? '';
    if (function_exists('iconv')) {
        $converted = iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }
    }

    return str_replace(
        ['\\', '(', ')'],
        ['\\\\', '\\(', '\\)'],
        $value
    );
}

function financePdfNumber(float $value): string
{
    return rtrim(rtrim(number_format($value, 3, '.', ''), '0'), '.');
}

function financePdfFillRect(
    float $x,
    float $top,
    float $width,
    float $height,
    float $red = 1,
    float $green = 1,
    float $blue = 1
): string {
    $pageHeight = 594.75;
    $bottom = $pageHeight - $top - $height;
    return sprintf(
        "q %.3F %.3F %.3F rg %.3F %.3F %.3F %.3F re f Q\n",
        $red,
        $green,
        $blue,
        $x,
        $bottom,
        $width,
        $height
    );
}

function financePdfText(
    float $x,
    float $top,
    float $size,
    string $text,
    bool $bold = false,
    array $rgb = [0, 0, 0]
): string {
    if ($text === '') {
        return '';
    }
    $pageHeight = 594.75;
    $baseline = $pageHeight - $top - ($size * 0.82);
    return sprintf(
        "BT /%s %.3F Tf %.3F %.3F %.3F rg 1 0 0 1 %.3F %.3F Tm (%s) Tj ET\n",
        $bold ? 'FTB' : 'FT',
        $size,
        (float) ($rgb[0] ?? 0),
        (float) ($rgb[1] ?? 0),
        (float) ($rgb[2] ?? 0),
        $x,
        $baseline,
        financePdfEscapeLiteral($text)
    );
}

function financePdfRightText(
    float $right,
    float $top,
    float $size,
    string $text,
    bool $bold = false
): string {
    $plain = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    $estimatedWidth = $plain * $size * ($bold ? 0.55 : 0.5);
    return financePdfText(max(0, $right - $estimatedWidth), $top, $size, $text, $bold);
}

function financePdfWrappedLines(string $value, int $maxCharacters, int $maxLines): array
{
    $value = trim(preg_replace('/\s+/u', ' ', $value) ?? '');
    if ($value === '') {
        return [];
    }

    $words = preg_split('/\s+/u', $value) ?: [];
    $lines = [];
    $line = '';
    foreach ($words as $word) {
        $candidate = $line === '' ? $word : $line . ' ' . $word;
        $length = function_exists('mb_strlen') ? mb_strlen($candidate, 'UTF-8') : strlen($candidate);
        if ($line !== '' && $length > $maxCharacters) {
            $lines[] = $line;
            $line = $word;
            if (count($lines) >= $maxLines) {
                break;
            }
        } else {
            $line = $candidate;
        }
    }
    if ($line !== '' && count($lines) < $maxLines) {
        $lines[] = $line;
    }

    if (count($lines) === $maxLines) {
        $consumed = implode(' ', $lines);
        $sourceLength = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
        $consumedLength = function_exists('mb_strlen') ? mb_strlen($consumed, 'UTF-8') : strlen($consumed);
        if ($consumedLength < $sourceLength) {
            $last = array_pop($lines);
            if (function_exists('mb_strimwidth')) {
                $last = mb_strimwidth((string) $last, 0, max(1, $maxCharacters - 3), '...', 'UTF-8');
            } else {
                $last = substr((string) $last, 0, max(1, $maxCharacters - 3)) . '...';
            }
            $lines[] = $last;
        }
    }

    return $lines;
}

function financePdfAllWrappedLines(string $value, int $maxCharacters): array
{
    $value = trim(str_replace(["\r\n", "\r"], "\n", $value));
    if ($value === '') {
        return [];
    }

    $lines = [];
    foreach (preg_split('/\n/u', $value) ?: [] as $paragraph) {
        $paragraph = trim(preg_replace('/\s+/u', ' ', $paragraph) ?? '');
        if ($paragraph === '') {
            continue;
        }
        $words = preg_split('/\s+/u', $paragraph) ?: [];
        $line = '';
        foreach ($words as $word) {
            $candidate = $line === '' ? $word : $line . ' ' . $word;
            $length = function_exists('mb_strlen')
                ? mb_strlen($candidate, 'UTF-8')
                : strlen($candidate);
            if ($line !== '' && $length > $maxCharacters) {
                $lines[] = $line;
                $line = $word;
            } else {
                $line = $candidate;
            }
        }
        if ($line !== '') {
            $lines[] = $line;
        }
    }

    return $lines;
}

function financePdfMonthYear(?string $date): string
{
    if (!$date || $date === '0000-00-00') {
        return '';
    }
    $timestamp = strtotime($date);
    return $timestamp ? date('n/y', $timestamp) : '';
}

function financePdfDocumentDate(?string $date): string
{
    if (!$date || $date === '0000-00-00') {
        return '';
    }
    $timestamp = strtotime($date);
    return $timestamp ? date('d/m/Y', $timestamp) : '';
}

function financePdfPaethPredictor(int $left, int $up, int $upperLeft): int
{
    $prediction = $left + $up - $upperLeft;
    $leftDistance = abs($prediction - $left);
    $upDistance = abs($prediction - $up);
    $upperLeftDistance = abs($prediction - $upperLeft);
    if ($leftDistance <= $upDistance && $leftDistance <= $upperLeftDistance) {
        return $left;
    }
    return $upDistance <= $upperLeftDistance ? $up : $upperLeft;
}

function financePdfPngAsset(string $binary): ?array
{
    if (!str_starts_with($binary, "\x89PNG\r\n\x1a\n")) {
        return null;
    }

    $offset = 8;
    $length = strlen($binary);
    $header = null;
    $compressedPixels = '';
    while ($offset + 12 <= $length) {
        $chunkLength = unpack('Nlength', substr($binary, $offset, 4))['length'] ?? 0;
        $chunkType = substr($binary, $offset + 4, 4);
        $chunkData = substr($binary, $offset + 8, $chunkLength);
        if ($chunkType === 'IHDR') {
            $header = unpack(
                'Nwidth/Nheight/Cbit_depth/Ccolor_type/Ccompression/Cfilter/Cinterlace',
                $chunkData
            );
        } elseif ($chunkType === 'IDAT') {
            $compressedPixels .= $chunkData;
        } elseif ($chunkType === 'IEND') {
            break;
        }
        $offset += 12 + $chunkLength;
    }

    if (
        !$header
        || (int) $header['bit_depth'] !== 8
        || (int) $header['interlace'] !== 0
        || !in_array((int) $header['color_type'], [0, 2, 4, 6], true)
        || $compressedPixels === ''
    ) {
        return null;
    }

    $width = (int) $header['width'];
    $height = (int) $header['height'];
    if ($width <= 0 || $height <= 0 || $width > 6000 || $height > 6000) {
        return null;
    }
    $colorType = (int) $header['color_type'];
    $sourceChannels = match ($colorType) {
        0 => 1,
        2 => 3,
        4 => 2,
        6 => 4,
    };
    $mainChannels = in_array($colorType, [0, 4], true) ? 1 : 3;
    $hasAlpha = in_array($colorType, [4, 6], true);
    $raw = @gzuncompress($compressedPixels);
    if ($raw === false && function_exists('zlib_decode')) {
        $raw = @zlib_decode($compressedPixels);
    }
    $stride = $width * $sourceChannels;
    if ($raw === false || strlen($raw) < ($stride + 1) * $height) {
        return null;
    }

    $previous = array_fill(0, $stride, 0);
    $mainRows = '';
    $alphaRows = '';
    $position = 0;
    for ($rowIndex = 0; $rowIndex < $height; $rowIndex++) {
        $filter = ord($raw[$position++]);
        $filtered = substr($raw, $position, $stride);
        $position += $stride;
        $row = [];
        for ($index = 0; $index < $stride; $index++) {
            $byte = ord($filtered[$index]);
            $left = $index >= $sourceChannels ? $row[$index - $sourceChannels] : 0;
            $up = $previous[$index] ?? 0;
            $upperLeft = $index >= $sourceChannels ? ($previous[$index - $sourceChannels] ?? 0) : 0;
            $row[$index] = match ($filter) {
                0 => $byte,
                1 => ($byte + $left) & 0xff,
                2 => ($byte + $up) & 0xff,
                3 => ($byte + intdiv($left + $up, 2)) & 0xff,
                4 => ($byte + financePdfPaethPredictor($left, $up, $upperLeft)) & 0xff,
                default => -1,
            };
            if ($row[$index] < 0) {
                return null;
            }
        }

        $mainRows .= "\x00";
        if ($hasAlpha) {
            $alphaRows .= "\x00";
        }
        for ($pixel = 0; $pixel < $width; $pixel++) {
            $base = $pixel * $sourceChannels;
            if ($mainChannels === 1) {
                $mainRows .= chr($row[$base]);
            } else {
                $mainRows .= chr($row[$base]) . chr($row[$base + 1]) . chr($row[$base + 2]);
            }
            if ($hasAlpha) {
                $alphaRows .= chr($row[$base + $sourceChannels - 1]);
            }
        }
        $previous = $row;
    }

    $main = gzcompress($mainRows, 9);
    $alpha = $hasAlpha ? gzcompress($alphaRows, 9) : null;
    if ($main === false || ($hasAlpha && $alpha === false)) {
        return null;
    }

    return [
        'format' => 'png',
        'binary' => $main,
        'alpha' => $alpha ?: null,
        'width' => $width,
        'height' => $height,
        'colorspace' => $mainChannels === 1 ? '/DeviceGray' : '/DeviceRGB',
        'colors' => $mainChannels,
    ];
}

function financePdfRasterAsset(?string $storedPath): ?array
{
    static $cache = [];
    $path = financeResolveStoredAsset($storedPath);
    if (!$path) {
        return null;
    }
    $cacheKey = $path . '|' . (string) @filemtime($path) . '|' . (string) @filesize($path);
    if (array_key_exists($cacheKey, $cache)) {
        return $cache[$cacheKey];
    }
    $binary = file_get_contents($path);
    if ($binary === false) {
        return $cache[$cacheKey] = null;
    }

    $image = @getimagesizefromstring($binary);
    if (!$image) {
        return $cache[$cacheKey] = null;
    }
    if (($image['mime'] ?? '') === 'image/png') {
        $png = financePdfPngAsset($binary);
        if ($png) {
            return $cache[$cacheKey] = $png;
        }
    }
    if (($image['mime'] ?? '') !== 'image/jpeg') {
        return $cache[$cacheKey] = null;
    }

    return $cache[$cacheKey] = [
        'format' => 'jpeg',
        'binary' => $binary,
        'alpha' => null,
        'width' => (int) $image[0],
        'height' => (int) $image[1],
        'colorspace' => (($image['channels'] ?? 3) === 4) ? '/DeviceCMYK' : '/DeviceRGB',
        'colors' => (($image['channels'] ?? 3) === 4) ? 4 : 3,
    ];
}

function financePdfImageObject(array $image, ?int $softMaskObject = null): string
{
    $binary = (string) $image['binary'];
    if (($image['format'] ?? '') === 'png') {
        $softMask = $softMaskObject ? " /SMask {$softMaskObject} 0 R" : '';
        return sprintf(
            "<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s "
            . "/BitsPerComponent 8 /Filter /FlateDecode "
            . "/DecodeParms << /Predictor 15 /Colors %d /BitsPerComponent 8 /Columns %d >>%s /Length %d >>\nstream\n",
            (int) $image['width'],
            (int) $image['height'],
            (string) $image['colorspace'],
            (int) $image['colors'],
            (int) $image['width'],
            $softMask,
            strlen($binary)
        ) . $binary . "\nendstream";
    }

    return sprintf(
        "<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s "
        . "/BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n",
        (int) $image['width'],
        (int) $image['height'],
        (string) $image['colorspace'],
        strlen($binary)
    ) . $binary . "\nendstream";
}

function financePdfSoftMaskObject(array $image): string
{
    $binary = (string) ($image['alpha'] ?? '');
    return sprintf(
        "<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceGray "
        . "/BitsPerComponent 8 /Filter /FlateDecode "
        . "/DecodeParms << /Predictor 15 /Colors 1 /BitsPerComponent 8 /Columns %d >> /Length %d >>\nstream\n",
        (int) $image['width'],
        (int) $image['height'],
        (int) $image['width'],
        strlen($binary)
    ) . $binary . "\nendstream";
}

function financePdfSanitizedTemplateContent(string $pdf, array $definition): string
{
    $contentObject = (int) $definition['content_object'];
    $body = financePdfLastObjectBody($pdf, $contentObject);
    if (!preg_match('/stream\r?\n(.*)\r?\nendstream/s', $body, $streamMatch)) {
        throw new RuntimeException('The approved Finance PDF template content stream is invalid.');
    }
    $compressed = (string) $streamMatch[1];
    $decoded = @gzuncompress($compressed);
    if ($decoded === false && function_exists('zlib_decode')) {
        $decoded = @zlib_decode($compressed);
    }
    if ($decoded === false) {
        throw new RuntimeException('The approved Finance PDF template content stream could not be decoded.');
    }

    $allowedStaticText = [
        'GST INVOICE',
        'C H A L L A N',
        'Party Name :',
        'Delivery Att',
        'Phone No. :',
        'Invoice No',
        'Invoice Date',
        'L.R. No.',
        'L.R. Date',
        'Order No.',
        'Order Date',
        'Transport  :-',
        'Cases',
        'TOTAL',
        'GST 5.00%',
        'GST 12.00%',
        'GST 18.00%',
        'GST 28 %',
        'DIS AMT.',
        'SGST PAYBLE',
        'CGST PAYBLE',
        'Round off',
        'CR/DR NOTE',
        'MSG:',
        'MARG ERP NANO Rs.5550 | Manage Stock,Accounts,GST,Barcodeing | Call 9870218886,8470063701,8470063703',
        'Digital Purchase | ERP Ordering | Healthcare QRCode on bills for extra earnings | Call MARG 9870218886,8470063701,8470063703',
    ];
    $decoded = preg_replace_callback(
        '/\(((?:\\\\.|[^\\\\)])*)\)\s*Tj/s',
        static function (array $match) use ($allowedStaticText): string {
            $raw = (string) $match[1];
            $plain = str_replace(['\\(', '\\)', '\\\\'], ['(', ')', '\\'], $raw);
            $trimmed = trim($plain);
            $isTableHeader = str_starts_with($trimmed, 'S.N') && str_contains($trimmed, 'Product Name');
            $isSummaryHeader = str_starts_with($trimmed, 'CLASS') && str_contains($trimmed, 'TOTAL GST');
            if ($isTableHeader || $isSummaryHeader || in_array($trimmed, $allowedStaticText, true)) {
                return $match[0];
            }
            return '()Tj';
        },
        $decoded
    );
    if ($decoded === null) {
        throw new RuntimeException('The approved Finance PDF template text layer could not be prepared.');
    }

    // Remove the sample payment QR images while retaining the supplied logo.
    $decoded = str_replace(
        ['/X1 Do', '/X2 Do', '/Im22 Do'],
        ['q Q', 'q Q', 'q Q'],
        $decoded
    );
    $compressed = gzcompress($decoded, 9);
    if ($compressed === false) {
        throw new RuntimeException('The approved Finance PDF template content stream could not be encoded.');
    }

    return '<< /Filter /FlateDecode /Length ' . strlen($compressed) . " >>\nstream\n"
        . $compressed . "\nendstream";
}

function financePdfDrawImage(string $resourceName, float $x, float $top, float $width, float $height): string
{
    $bottom = 594.75 - $top - $height;
    return sprintf(
        "q %.3F 0 0 %.3F %.3F %.3F cm /%s Do Q\n",
        $width,
        $height,
        $x,
        $bottom,
        $resourceName
    );
}

/**
 * Builds the editable data layer laid over the exact supplied PDF page.
 * Coordinates use the original 841.5 x 594.75 point landscape page.
 */
function financeBuildApprovedTemplateOverlay(
    array $document,
    array $imageResources = [],
    array $pageContext = []
): string
{
    $isChallan = ($document['document_type'] ?? '') === 'DELIVERY_CHALLAN';
    $blue = [0.05, 0.05, 0.42];
    $company = $document['company'] ?? [];
    $items = array_values($document['items'] ?? []);
    $allItems = array_values($pageContext['all_items'] ?? $items);
    $itemOffset = max(0, (int) ($pageContext['item_offset'] ?? 0));
    $pageNumber = max(1, (int) ($pageContext['page_number'] ?? 1));
    $pageCount = max(1, (int) ($pageContext['page_count'] ?? 1));
    if (count($items) > 12) {
        throw new RuntimeException('A Finance PDF template page supports a maximum of 12 product lines.');
    }

    $out = "% Biogenix Finance editable overlay\n";

    // Company snapshot: preserve the original logo and background.
    $companyName = trim((string) ($company['legal_name'] ?? $company['company_name'] ?? 'BIOGENIX INC. PVT.LTD.'));
    $out .= financePdfText(24.5, 96, 11, strtoupper($companyName), true, $blue);
    $companyAddress = trim((string) ($company['address'] ?? ''));
    $addressLines = financePdfWrappedLines($companyAddress, 48, 3);
    foreach ($addressLines as $index => $line) {
        $out .= financePdfText(24.5, 111 + ($index * 9.3), 7.5, $line, false, $blue);
    }
    $contact = trim(implode('/', array_filter([
        $company['mobile'] ?? '',
        $company['phone'] ?? '',
    ])));
    if ($contact !== '') {
        $out .= financePdfText(24.5, 141, 7.5, 'Phone : ' . $contact, false, $blue);
    }
    $out .= financePdfText(24.5, 158.5, 7.5, 'GSTIN : ' . trim((string) ($company['gst_no'] ?? '')), false, $blue);
    $udyam = trim((string) ($company['udyam_no'] ?? ''));
    $license = trim((string) ($company['manufacturing_license_no'] ?? ''));
    $registration = $udyam !== '' ? 'UDYAM Reg. No.: ' . $udyam : ($license !== '' ? 'Licence No. : ' . $license : '');
    $out .= financePdfText(24.5, 168, 7.2, $registration, false, $blue);

    // IRN/acknowledgement and metadata values.
    $out .= financePdfText(254, 37.5, 8, 'IRN NO :', true, $blue);
    $irnLines = financePdfWrappedLines((string) ($document['irn'] ?? ''), 58, 2);
    foreach ($irnLines as $index => $line) {
        $out .= financePdfText(254, 47 + ($index * 9), 7.5, $line, true, $blue);
    }
    $ack = trim((string) ($document['acknowledgement_number'] ?? ''));
    $out .= financePdfText(254, 65, 8, 'ACK NO :' . ($ack !== '' ? ' ' . $ack : ''), true, $blue);

    $documentNumber = (string) ($document['document_number'] ?? '');
    if (function_exists('mb_strimwidth')) {
        $documentNumber = mb_strimwidth($documentNumber, 0, 22, '...', 'UTF-8');
    }
    $out .= financePdfText(339.5, 75.2, 6.3, $documentNumber, true);
    $out .= financePdfText(339.5, 85.5, 7.5, financePdfDocumentDate($document['document_date'] ?? null));
    $out .= financePdfText(339.5, 96.7, 7.5, (string) ($document['cases_text'] ?? '0'));
    $out .= financePdfText(307, 108, 7.2, financePdfDocumentDate($document['order_date'] ?? $document['document_date'] ?? null));
    $out .= financePdfText(307, 119.2, 7.2, (string) ($document['po_reference'] ?? ''));
    $out .= financePdfText(309.5, 130.5, 7.5, (string) ($document['transport_mode'] ?? ''), true);
    $out .= financePdfText(489, 74.2, 7.2, (string) ($document['lr_number'] ?? ''));
    $out .= financePdfText(508, 85.5, 7.2, financePdfDocumentDate($document['lr_date'] ?? null));
    $out .= financePdfText(414.5, 108, 7.2, 'Due Date', true);
    $out .= financePdfText(
        508,
        108,
        7.2,
        $isChallan ? financePdfDocumentDate($document['document_date'] ?? null) : financePdfDocumentDate($document['due_date'] ?? null)
    );

    // Party/billing snapshot and separate delivery address.
    $out .= financePdfText(578, 42.5, 8.8, (string) ($document['counterparty_name'] ?? ''), true);
    $partyAddress = financePdfWrappedLines((string) ($document['counterparty_address'] ?? ''), 52, 2);
    foreach ($partyAddress as $index => $line) {
        $out .= financePdfText(578, 54 + ($index * 9), 7.2, $line);
    }
    $stateText = trim(implode(' ', array_filter([
        $document['counterparty_state'] ?? '',
        !empty($document['counterparty_state_code']) ? 'State : ' . $document['counterparty_state_code'] : '',
    ])));
    $out .= financePdfText(578, 73, 7.2, $stateText);
    $out .= financePdfText(578, 83.2, 7.2, 'PHONE. : ' . (string) ($document['counterparty_contact'] ?? ''));
    $out .= financePdfText(578, 102.7, 7.2, 'GSTIN : ' . (string) ($document['counterparty_gstin'] ?? ''));
    $shipping = financePdfWrappedLines(
        (string) ($document['counterparty_shipping_address'] ?? $document['counterparty_address'] ?? ''),
        52,
        4
    );
    foreach ($shipping as $index => $line) {
        $out .= financePdfText(578, 127 + ($index * 9), 7.1, $line);
    }
    // Product body. The approved source keeps its original grid; only the two
    // commercial columns are relabelled for a non-accounting challan.
    if ($isChallan) {
        $out .= financePdfFillRect(545, 181.5, 47, 11.5);
        $out .= financePdfText(549, 184, 5.2, 'Rate', true);
        $out .= financePdfFillRect(767, 181.5, 57, 11.5);
        $out .= financePdfText(772, 184, 5.2, 'Amount', true);
    }
    $columns = [19, 41.5, 75.5, 304, 338, 375, 405, 450, 479, 506, 544, 593, 619, 649, 690, 721, 766, 825];
    foreach ($items as $index => $item) {
        $top = 195 + ($index * 13);
        $quantity = financePdfNumber((float) ($item['quantity'] ?? 0));
        $free = financePdfNumber((float) ($item['free_quantity'] ?? 0));
        $values = [
            (string) ($itemOffset + $index + 1),
            (string) ($item['hsn_code'] ?? ''),
            (string) ($item['product_name'] ?? ''),
            (string) ($item['pack_size'] ?? ''),
            $quantity,
            $free,
            (string) ($item['batch_number'] ?? ''),
            financePdfMonthYear($item['manufacturing_date'] ?? null),
            financePdfMonthYear($item['expiry_date'] ?? null),
            financeMoney($item['mrp'] ?? 0),
            financeMoney($item['rate'] ?? 0),
            $isChallan ? '' : financePdfNumber((float) ($item['discount_percent'] ?? 0)),
            $isChallan ? '' : financePdfNumber((float) ($item['sgst_percent'] ?? 0)),
            $isChallan ? '' : financeMoney($item['sgst_value'] ?? 0),
            $isChallan ? '' : financePdfNumber((float) ($item['cgst_percent'] ?? 0)),
            $isChallan ? '' : financeMoney($item['cgst_value'] ?? 0),
            $isChallan
                ? financeMoney($item['line_total'] ?? 0)
                : financeMoney($item['taxable_value'] ?? $item['line_total'] ?? 0),
        ];
        foreach ($values as $column => $value) {
            $size = $column === 2 ? 6.7 : ($column === 6 ? 5.5 : 6.2);
            $x = $columns[$column] + ($column === 2 ? 8 : 3);
            $maxCharacters = $column === 2 ? 42 : max(3, (int) (($columns[$column + 1] - $columns[$column]) / 3.5));
            if (function_exists('mb_strimwidth')) {
                $value = mb_strimwidth((string) $value, 0, $maxCharacters, '...', 'UTF-8');
            } else {
                $value = strlen((string) $value) > $maxCharacters
                    ? substr((string) $value, 0, max(1, $maxCharacters - 3)) . '...'
                    : (string) $value;
            }
            $out .= financePdfText($x, $top, $size, (string) $value, $column === 16);
        }
    }

    // GST-class summary.
    $taxGroups = [];
    if (!$isChallan) {
        foreach ($allItems as $item) {
            $rate = round(
                (float) ($item['cgst_percent'] ?? 0)
                + (float) ($item['sgst_percent'] ?? 0)
                + (float) ($item['igst_percent'] ?? 0),
                2
            );
            $key = number_format($rate, 2, '.', '');
            $taxGroups[$key] ??= ['taxable' => 0.0, 'discount' => 0.0, 'sgst' => 0.0, 'cgst' => 0.0, 'igst' => 0.0];
            $taxGroups[$key]['taxable'] += (float) ($item['taxable_value'] ?? 0);
            $taxGroups[$key]['discount'] += (float) ($item['discount_value'] ?? 0);
            $taxGroups[$key]['sgst'] += (float) ($item['sgst_value'] ?? 0);
            $taxGroups[$key]['cgst'] += (float) ($item['cgst_value'] ?? 0);
            $taxGroups[$key]['igst'] += (float) ($item['igst_value'] ?? 0);
        }
    }
    $summaryColumns = [94, 162, 221, 289, 349, 417, 499];
    $rateRows = ['5.00' => 399, '12.00' => 409.5, '18.00' => 420, '28.00' => 430.5];
    foreach ($rateRows as $rate => $top) {
        $group = $taxGroups[$rate] ?? ['taxable' => 0, 'discount' => 0, 'sgst' => 0, 'cgst' => 0, 'igst' => 0];
        $row = $isChallan
            ? ['', '', '', '', '', '']
            : [
                financeMoney($group['taxable']),
                '0.00',
                financeMoney($group['discount']),
                financeMoney($group['sgst']),
                financeMoney($group['cgst']),
                financeMoney($group['sgst'] + $group['cgst'] + $group['igst']),
            ];
        $rights = [153, 213, 281, 340, 408, 490];
        foreach ($row as $column => $value) {
            $out .= financePdfRightText($rights[$column], $top, 6.8, $value);
        }
    }
    $totalSummary = $isChallan
        ? ['', '', '', '', '', '']
        : [
            financeMoney($document['taxable_total'] ?? 0),
            '0.00',
            financeMoney($document['discount_total'] ?? 0),
            financeMoney($document['sgst_total'] ?? 0),
            financeMoney($document['cgst_total'] ?? 0),
            financeMoney(
                (float) ($document['sgst_total'] ?? 0)
                + (float) ($document['cgst_total'] ?? 0)
                + (float) ($document['igst_total'] ?? 0)
            ),
        ];
    foreach ($totalSummary as $column => $value) {
        $out .= financePdfRightText([153, 213, 281, 340, 408, 490][$column], 442, 6.8, $value);
    }

    $totalQuantity = array_sum(array_map(static fn(array $item): float => (float) ($item['quantity'] ?? 0), $allItems));
    $out .= financePdfText(508, 398.3, 8, 'Total Items :-');
    $out .= financePdfText(584, 398.3, 8, (string) count($allItems));
    $out .= financePdfText(508, 409, 8, 'Total Qty   :-');
    $out .= financePdfText(584, 409, 8, financePdfNumber($totalQuantity));

    $rightTotals = [
        [$isChallan ? financeMoney($document['grand_total'] ?? 0) : financeMoney($document['subtotal'] ?? 0), true, 384.5],
        [$isChallan ? '' : financeMoney($document['discount_total'] ?? 0), false, 399],
        [$isChallan ? '' : financeMoney($document['sgst_total'] ?? 0), false, 409.5],
        [$isChallan ? '' : financeMoney($document['cgst_total'] ?? 0), false, 420],
        [$isChallan ? '' : financeMoney($document['round_off'] ?? 0), false, 430.5],
        [$isChallan ? '' : '0.00', false, 442.5],
    ];
    foreach ($rightTotals as [$value, $bold, $top]) {
        $out .= financePdfRightText(816, $top, 8, $value, $bold);
    }

    if ($isChallan) {
        $out .= financePdfText(32, 453.2, 7.2, 'Dispatch value only; no receivable or payment is created.', true);
        $out .= financePdfText(
            32,
            462,
            6.5,
            'Amount: Rs. ' . financeAmountInWords((float) ($document['grand_total'] ?? 0))
        );
    } else {
        $out .= financePdfText(
            32,
            453.2,
            7.2,
            'Rs. ' . financeAmountInWords((float) ($document['grand_total'] ?? 0)),
            true
        );
    }

    // Bank, terms, configurable signature/QR, and grand total.
    $selectedBank = $document['selected_bank'] ?? [];
    $out .= financePdfText(24.5, 474.5, 9.5, 'OUR BANK DETAILS AS :-', true);
    $out .= financePdfText(24.5, 484, 6.2, 'Bank Name : ' . (string) ($selectedBank['bank_name'] ?? ''));
    $out .= financePdfText(24.5, 491.5, 6.2, 'Branch Name : ' . (string) ($selectedBank['branch_name'] ?? ''));
    $out .= financePdfText(24.5, 499, 6.2, 'Account Name : ' . (string) ($selectedBank['account_name'] ?? ''));
    $out .= financePdfText(24.5, 506.5, 6.2, 'Account No. : ' . (string) ($selectedBank['account_number'] ?? ''));
    $out .= financePdfText(
        24.5,
        514,
        6.2,
        'IFSC : ' . (string) ($selectedBank['ifsc_code'] ?? '')
            . '   SWIFT : ' . (string) ($selectedBank['swift_code'] ?? '')
    );
    $out .= financePdfText(24.5, 521.5, 6.2, 'UPI : ' . (string) ($selectedBank['upi_id'] ?? ''));
    $out .= financePdfText(24.5, 527, 9, 'Terms & Conditions', true);
    $termLines = array_values(
        $pageContext['term_lines']
            ?? financePdfWrappedLines((string) ($document['terms_snapshot'] ?? ''), 76, 3)
    );
    foreach ($termLines as $index => $line) {
        $out .= financePdfText(24.5, 539 + ($index * 10), 6.7, $line);
    }
    if (isset($imageResources['FinanceQr'])) {
        $out .= financePdfDrawImage('FinanceQr', 300, 480, 78, 55);
    }

    $out .= financePdfText(425.75, 475.5, 8, 'FOR   ' . strtoupper($companyName), true);
    if (isset($imageResources['FinanceSignature'])) {
        $out .= financePdfDrawImage('FinanceSignature', 474, 491, 118, 35);
    }
    $out .= financePdfText(429.5, 528, 8, 'Authorised Signatory', true);
    $out .= financePdfText(707, 507, 11.5, $isChallan ? 'Total Amount' : 'Grand Total');
    $out .= financePdfRightText(
        786,
        528,
        12,
        financeMoney($document['grand_total'] ?? 0)
    );
    if ($pageCount > 1) {
        $out .= financePdfText(505, 453.2, 6.5, "Page {$pageNumber} of {$pageCount}", true);
    }

    return $out;
}

function financeBuildApprovedTemplatePdf(array $document): string
{
    $definition = financeApprovedTemplateDefinition((string) ($document['document_type'] ?? ''));
    $pdf = file_get_contents($definition['path']);
    if ($pdf === false) {
        throw new RuntimeException('Unable to read the approved Finance PDF template.');
    }
    $allItems = array_values($document['items'] ?? []);
    $allTermLines = financePdfAllWrappedLines(
        (string) ($document['terms_snapshot'] ?? ''),
        76
    );
    $itemPageCount = max(1, (int) ceil(count($allItems) / 12));
    $termPageCount = max(1, (int) ceil(count($allTermLines) / 3));
    $pageCount = max($itemPageCount, $termPageCount);

    if (!preg_match_all('/startxref\s*(\d+)/s', $pdf, $startMatches) || empty($startMatches[1])) {
        throw new RuntimeException('The approved Finance PDF template has no cross-reference pointer.');
    }
    $previousXref = (int) end($startMatches[1]);

    if (!preg_match_all('/trailer\s*<<(.*?)>>\s*startxref/s', $pdf, $trailerMatches) || empty($trailerMatches[1])) {
        throw new RuntimeException('The approved Finance PDF template trailer could not be read.');
    }
    $trailer = (string) end($trailerMatches[1]);
    if (!preg_match('/\/Size\s+(\d+)/', $trailer, $sizeMatch) || !preg_match('/\/Root\s+(\d+\s+\d+\s+R)/', $trailer, $rootMatch)) {
        throw new RuntimeException('The approved Finance PDF template trailer is incomplete.');
    }

    $oldSize = (int) $sizeMatch[1];
    $nextObject = $oldSize;
    $normalFontObject = $nextObject++;
    $boldFontObject = $nextObject++;

    $images = [];
    $signature = financePdfRasterAsset($document['company_documents']['digital_signature'] ?? null);
    if ($signature) {
        $images['FinanceSignature'] = [
            'object' => $nextObject++,
            'soft_mask_object' => !empty($signature['alpha']) ? $nextObject++ : null,
            'image' => $signature,
        ];
    }
    $selectedBank = $document['selected_bank'] ?? [];
    $qr = financePdfRasterAsset($selectedBank['qr_file'] ?? null);
    if ($qr) {
        $images['FinanceQr'] = [
            'object' => $nextObject++,
            'soft_mask_object' => !empty($qr['alpha']) ? $nextObject++ : null,
            'image' => $qr,
        ];
    }
    $additionalPageObjects = [];
    for ($pageIndex = 1; $pageIndex < $pageCount; $pageIndex++) {
        $additionalPageObjects[$pageIndex] = $nextObject++;
    }
    $overlayObjects = [];
    for ($pageIndex = 0; $pageIndex < $pageCount; $pageIndex++) {
        $overlayObjects[$pageIndex] = $nextObject++;
    }

    $pageObjectNumber = (int) $definition['page_object'];
    $contentObjectNumber = (int) $definition['content_object'];
    $pageBody = financePdfLastObjectBody($pdf, $pageObjectNumber);
    $contentsPattern = '/\/Contents\s+' . preg_quote((string) $contentObjectNumber, '/')
        . '\s+0\s+R/';
    $pageBody = preg_replace(
        $contentsPattern,
        '/Contents [' . $contentObjectNumber . ' 0 R ' . $overlayObjects[0] . ' 0 R]',
        $pageBody,
        1,
        $contentsReplaced
    );
    if ($contentsReplaced !== 1) {
        throw new RuntimeException('The approved Finance PDF template content reference is invalid.');
    }

    $objects = [
        $normalFontObject => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
        $boldFontObject => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
        $contentObjectNumber => financePdfSanitizedTemplateContent($pdf, $definition),
    ];
    $fontEntries = "/FT {$normalFontObject} 0 R /FTB {$boldFontObject} 0 R";
    $imageEntries = '';
    $imageResourceMap = [];
    foreach ($images as $name => $image) {
        $objects[$image['object']] = financePdfImageObject(
            $image['image'],
            $image['soft_mask_object']
        );
        if ($image['soft_mask_object']) {
            $objects[$image['soft_mask_object']] = financePdfSoftMaskObject($image['image']);
        }
        $imageEntries .= " /{$name} {$image['object']} 0 R";
        $imageResourceMap[$name] = $image['object'];
    }

    if ($definition['font_dictionary_object'] !== null) {
        $fontDictionaryObject = (int) $definition['font_dictionary_object'];
        $fontBody = financePdfLastObjectBody($pdf, $fontDictionaryObject);
        $objects[$fontDictionaryObject] = financePdfAppendDictionaryEntries($fontBody, $fontEntries);

        if ($imageEntries !== '') {
            $xobjectDictionaryObject = (int) $definition['xobject_dictionary_object'];
            $xobjectBody = financePdfLastObjectBody($pdf, $xobjectDictionaryObject);
            $objects[$xobjectDictionaryObject] = financePdfAppendDictionaryEntries($xobjectBody, $imageEntries);
        }
    } else {
        $pageBody = preg_replace(
            '/\/Font\s*<<(.*?)>>/s',
            '/Font <<$1 ' . $fontEntries . ' >>',
            $pageBody,
            1,
            $fontReplaced
        );
        if ($fontReplaced !== 1) {
            throw new RuntimeException('The approved Finance PDF template font resources are invalid.');
        }
        if ($imageEntries !== '') {
            $pageBody = preg_replace(
                '/\/XObject\s*<<(.*?)>>/s',
                '/XObject <<$1 ' . trim($imageEntries) . ' >>',
                $pageBody,
                1,
                $xobjectReplaced
            );
            if ($xobjectReplaced !== 1) {
                throw new RuntimeException('The approved Finance PDF template image resources are invalid.');
            }
        }
    }
    $objects[$pageObjectNumber] = $pageBody;

    if (!preg_match('/\/Parent\s+(\d+)\s+0\s+R/', $pageBody, $parentMatch)) {
        throw new RuntimeException('The approved Finance PDF template page tree is invalid.');
    }
    $pagesObjectNumber = (int) $parentMatch[1];
    $pageObjectNumbers = [0 => $pageObjectNumber] + $additionalPageObjects;
    for ($pageIndex = 1; $pageIndex < $pageCount; $pageIndex++) {
        $duplicatePageBody = preg_replace(
            '/\/Contents\s*\[\s*' . preg_quote((string) $contentObjectNumber, '/')
                . '\s+0\s+R\s+' . preg_quote((string) $overlayObjects[0], '/')
                . '\s+0\s+R\s*\]/',
            '/Contents [' . $contentObjectNumber . ' 0 R ' . $overlayObjects[$pageIndex] . ' 0 R]',
            $pageBody,
            1,
            $duplicateContentsReplaced
        );
        if ($duplicateContentsReplaced !== 1 || $duplicatePageBody === null) {
            throw new RuntimeException('Unable to create an additional approved Finance template page.');
        }
        $objects[$pageObjectNumbers[$pageIndex]] = $duplicatePageBody;
    }

    $pagesBody = financePdfLastObjectBody($pdf, $pagesObjectNumber);
    $kids = implode(
        ' ',
        array_map(
            static fn(int $objectNumber): string => $objectNumber . ' 0 R',
            array_values($pageObjectNumbers)
        )
    );
    $pagesBody = preg_replace(
        '/\/Kids\s*\[(.*?)\]/s',
        '/Kids [' . $kids . ']',
        $pagesBody,
        1,
        $kidsReplaced
    );
    $pagesBody = preg_replace(
        '/\/Count\s+\d+/',
        '/Count ' . $pageCount,
        (string) $pagesBody,
        1,
        $countReplaced
    );
    if ($kidsReplaced !== 1 || $countReplaced !== 1 || $pagesBody === null) {
        throw new RuntimeException('Unable to update the approved Finance PDF page tree.');
    }
    $objects[$pagesObjectNumber] = $pagesBody;

    for ($pageIndex = 0; $pageIndex < $pageCount; $pageIndex++) {
        $pageDocument = $document;
        $pageDocument['items'] = array_slice($allItems, $pageIndex * 12, 12);
        $overlay = financeBuildApprovedTemplateOverlay(
            $pageDocument,
            $imageResourceMap,
            [
                'all_items' => $allItems,
                'item_offset' => $pageIndex * 12,
                'term_lines' => array_slice($allTermLines, $pageIndex * 3, 3),
                'page_number' => $pageIndex + 1,
                'page_count' => $pageCount,
            ]
        );
        $objects[$overlayObjects[$pageIndex]] = '<< /Length ' . strlen($overlay) . " >>\nstream\n"
            . $overlay . "endstream";
    }

    ksort($objects, SORT_NUMERIC);
    $output = $pdf;
    if (!str_ends_with($output, "\n")) {
        $output .= "\n";
    }
    $offsets = [];
    foreach ($objects as $objectNumber => $objectBody) {
        $offsets[$objectNumber] = strlen($output);
        $output .= $objectNumber . " 0 obj\n" . $objectBody . "\nendobj\n";
    }

    $xrefOffset = strlen($output);
    $output .= "xref\n";
    $groups = [];
    foreach (array_keys($objects) as $objectNumber) {
        $lastGroup = array_key_last($groups);
        if ($lastGroup === null || $objectNumber !== end($groups[$lastGroup]) + 1) {
            $groups[] = [$objectNumber];
        } else {
            $groups[$lastGroup][] = $objectNumber;
        }
    }
    foreach ($groups as $group) {
        $output .= $group[0] . ' ' . count($group) . "\n";
        foreach ($group as $objectNumber) {
            $output .= sprintf("%010d 00000 n \n", $offsets[$objectNumber]);
        }
    }

    $newSize = max($oldSize, max(array_keys($objects)) + 1);
    $output .= "trailer\n<< /Size {$newSize} /Root {$rootMatch[1]}";
    if (preg_match('/\/Info\s+(\d+\s+\d+\s+R)/', $trailer, $infoMatch)) {
        $output .= ' /Info ' . $infoMatch[1];
    }
    $output .= ' /Prev ' . $previousXref;
    if (preg_match('/\/ID\s*(\[[^\]]+\])/', $trailer, $idMatch)) {
        $output .= ' /ID ' . $idMatch[1];
    }
    $output .= " >>\nstartxref\n{$xrefOffset}\n%%EOF\n";

    return $output;
}

function financeBuildDocumentHtml(array $document): string
{
    $isChallan = $document['document_type'] === 'DELIVERY_CHALLAN';
    $isSalesOrder = $document['document_type'] === 'SALES_ORDER';
    $title = $isSalesOrder ? 'SALES ORDER' : ($isChallan ? 'CHALLAN' : 'GST INVOICE');
    $numberLabel = $isSalesOrder ? 'Order No.' : ($isChallan ? 'Challan No.' : 'Invoice No.');
    $company = $document['company'] ?? [];
    $items = $document['items'] ?? [];
    $selectedBank = $document['selected_bank'] ?? null;

    // JPEG is used intentionally because Dompdf can embed it without requiring PHP GD.
    $defaultLogoPath = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 'logo2.jpeg';
    $configuredLogo = financeResolveStoredAsset($document['company_documents']['logo'] ?? null);
    $signaturePath = financeResolveStoredAsset($document['company_documents']['digital_signature'] ?? null);
    $qrPath = financeResolveStoredAsset($selectedBank['qr_file'] ?? null);
    $logo = extension_loaded('gd') ? financePdfAssetData($configuredLogo ?: $defaultLogoPath) : null;
    $signature = extension_loaded('gd') && $signaturePath ? financePdfAssetData($signaturePath) : null;
    $paymentQr = extension_loaded('gd') && $qrPath ? financePdfAssetData($qrPath) : null;
    $companyName = $company['legal_name'] ?? $company['company_name'] ?? 'BIOGENIX INC. PVT. LTD.';
    $companyAddress = $company['address'] ?? '';
    $companyContact = trim(implode(' | ', array_filter([
        $company['mobile'] ?? '',
        $company['email'] ?? '',
        $company['website'] ?? '',
    ])));
    $companyGst = $company['gst_no'] ?? '';
    $terms = trim((string) ($document['terms_snapshot'] ?? ''));
    if ($terms === '') {
        $terms = "1. Goods once sold will not be taken back or exchanged after 15 days.\n"
            . "2. Bills remaining overdue will attract interest at 24% per annum.\n"
            . "3. All disputes are subject to Lucknow jurisdiction.";
    }
    $taxGroups = [];
    if (!$isChallan) {
        foreach ($items as $item) {
            $rate = round(
                (float) ($item['cgst_percent'] ?? 0)
                + (float) ($item['sgst_percent'] ?? 0)
                + (float) ($item['igst_percent'] ?? 0),
                3
            );
            $key = number_format($rate, 3, '.', '');
            if (!isset($taxGroups[$key])) {
                $taxGroups[$key] = [
                    'rate' => $rate,
                    'taxable' => 0.0,
                    'cgst' => 0.0,
                    'sgst' => 0.0,
                    'igst' => 0.0,
                ];
            }
            $taxGroups[$key]['taxable'] += (float) ($item['taxable_value'] ?? 0);
            $taxGroups[$key]['cgst'] += (float) ($item['cgst_value'] ?? 0);
            $taxGroups[$key]['sgst'] += (float) ($item['sgst_value'] ?? 0);
            $taxGroups[$key]['igst'] += (float) ($item['igst_value'] ?? 0);
        }
        ksort($taxGroups, SORT_NUMERIC);
    }

    ob_start();
    ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 11mm 9mm 10mm; size: A4 landscape; }
        * { box-sizing: border-box; }
        body { margin: 0; color: #111; font-family: DejaVu Sans, Arial, sans-serif; font-size: 8px; }
        .title { color: #205aa7; text-align: center; font-size: 18px; font-weight: 700; margin: 0 0 4px; }
        table { width: 100%; border-collapse: collapse; }
        .frame, .frame td, .frame th { border: 1px solid #222; }
        .header td { vertical-align: top; padding: 4px; }
        .company { width: 36%; }
        .document-meta { width: 30%; padding: 0 !important; }
        .party { width: 34%; }
        .logo { width: 66px; float: left; margin: 1px 7px 3px 0; }
        .logo-fallback { width: 52px; height: 52px; line-height: 52px; float: left; margin: 1px 7px 3px 0; background: #205a38; color: #ffea00; font-size: 34px; font-weight: 700; text-align: center; border-radius: 4px; }
        .company-name { color: #205aa7; font-size: 14px; font-weight: 700; }
        .muted { color: #444; font-size: 7px; line-height: 1.45; }
        .meta-grid td { border: 0; border-bottom: 1px solid #555; padding: 3px 4px; font-size: 7px; }
        .meta-grid tr:last-child td { border-bottom: 0; }
        .meta-label { width: 31%; font-weight: 700; background: #f0f0f0; }
        .party-title { font-size: 7px; font-weight: 700; color: #205aa7; }
        .party-name { font-size: 11px; font-weight: 700; margin: 2px 0; }
        .items { table-layout: fixed; margin-top: -1px; }
        .items th { background: #d9e4f5; font-size: 6px; padding: 3px 1px; text-align: center; }
        .items td { padding: 3px 2px; font-size: 6px; vertical-align: top; text-align: center; height: 23px; }
        .items .product { text-align: left; }
        .summary-wrap { margin-top: -1px; }
        .summary-wrap td { vertical-align: top; padding: 0; }
        .tax-summary { width: 58%; }
        .tax-summary th, .tax-summary td { padding: 3px; text-align: right; font-size: 7px; }
        .tax-summary th { background: #eee; }
        .totals { width: 42%; }
        .totals td { padding: 3px 5px; font-size: 8px; }
        .totals .label { background: #eee; font-weight: 700; width: 63%; }
        .totals .value { text-align: right; font-weight: 700; }
        .words { padding: 4px 5px !important; font-size: 8px; min-height: 24px; }
        .footer { margin-top: -1px; table-layout: fixed; }
        .footer > tbody > tr > td { height: 105px; padding: 5px; vertical-align: top; }
        .bank { width: 37%; }
        .sign { width: 31%; text-align: center; position: relative; }
        .grand { width: 32%; padding: 0 !important; }
        .section-label { color: #205aa7; font-weight: 700; font-size: 8px; margin-bottom: 3px; }
        .terms { white-space: pre-line; font-size: 6.5px; line-height: 1.4; margin-top: 5px; }
        .sign-space { height: 55px; }
        .signature-image { max-height: 35px; max-width: 115px; margin: 8px auto 0; }
        .payment-qr { width: 45px; height: 45px; position: absolute; right: 5px; bottom: 17px; }
        .authorised { border-top: 1px solid #333; padding-top: 3px; font-weight: 700; }
        .grand-table td { padding: 4px 6px; }
        .grand-total td { background: #d9e4f5; font-size: 12px; font-weight: 700; padding: 8px 6px; }
        .page-note { text-align: center; color: #666; font-size: 6px; margin-top: 2px; }
    </style>
</head>
<body>
    <div class="title"><?= financeEscape($title) ?></div>

    <table class="frame header">
        <tr>
            <td class="company">
                <?php if ($logo): ?><img class="logo" src="<?= $logo ?>" alt="Logo"><?php else: ?><span class="logo-fallback">B</span><?php endif; ?>
                <div class="company-name"><?= financeEscape($companyName) ?></div>
                <div class="muted"><?= nl2br(financeEscape($companyAddress)) ?></div>
                <?php if ($companyContact): ?><div class="muted"><?= financeEscape($companyContact) ?></div><?php endif; ?>
                <div class="muted"><strong>GSTIN:</strong> <?= financeEscape($companyGst) ?></div>
                <?php if (!empty($company['udyam_no'])): ?><div class="muted"><strong>UDYAM:</strong> <?= financeEscape($company['udyam_no']) ?></div><?php endif; ?>
                <?php if (!empty($company['manufacturing_license_no'])): ?><div class="muted"><strong>Mfg. Lic.:</strong> <?= financeEscape($company['manufacturing_license_no']) ?></div><?php endif; ?>
            </td>
            <td class="document-meta">
                <table class="meta-grid">
                    <tr><td class="meta-label">IRN No.</td><td><?= financeEscape($document['irn'] ?? '') ?></td></tr>
                    <tr><td class="meta-label">ACK No.</td><td><?= financeEscape($document['acknowledgement_number'] ?? '') ?></td></tr>
                    <tr><td class="meta-label"><?= financeEscape($numberLabel) ?></td><td><?= financeEscape($document['document_number'] ?? '') ?></td></tr>
                    <tr><td class="meta-label">Document Date</td><td><?= financeDate($document['document_date'] ?? null) ?></td></tr>
                    <tr><td class="meta-label">Cases</td><td><?= financeEscape($document['cases_text'] ?? '') ?></td></tr>
                    <tr><td class="meta-label"><?= $isSalesOrder ? 'PI Reference' : 'Order No.' ?></td><td><?= financeEscape($document['po_reference'] ?? '') ?></td></tr>
                    <tr><td class="meta-label">L.R. No./Date</td><td><?= financeEscape($document['lr_number'] ?? '') ?> <?= financeDate($document['lr_date'] ?? null, '') ?></td></tr>
                    <tr><td class="meta-label">Due Date</td><td><?= $isChallan ? '' : financeDate($document['due_date'] ?? null) ?></td></tr>
                    <tr><td class="meta-label">Transport</td><td><?= financeEscape($document['transport_mode'] ?? '') ?></td></tr>
                </table>
            </td>
            <td class="party">
                <div class="party-title">PARTY / RECEIVING PARTY</div>
                <div class="party-name"><?= financeEscape($document['counterparty_name'] ?? '') ?></div>
                <div class="muted"><?= nl2br(financeEscape($document['counterparty_address'] ?? '')) ?></div>
                <?php if (!empty($document['counterparty_shipping_address']) && $document['counterparty_shipping_address'] !== $document['counterparty_address']): ?>
                    <div class="muted"><strong>Ship To:</strong> <?= nl2br(financeEscape($document['counterparty_shipping_address'])) ?></div>
                <?php endif; ?>
                <div class="muted"><strong>State:</strong> <?= financeEscape($document['counterparty_state'] ?? '') ?> <?= financeEscape($document['counterparty_state_code'] ?? '') ?></div>
                <div class="muted"><strong>Phone:</strong> <?= financeEscape($document['counterparty_contact'] ?? '') ?></div>
                <?php if (!empty($document['counterparty_email'])): ?><div class="muted"><strong>Email:</strong> <?= financeEscape($document['counterparty_email']) ?></div><?php endif; ?>
                <div class="muted"><strong>GSTIN:</strong> <?= financeEscape($document['counterparty_gstin'] ?? '') ?></div>
                <div class="muted"><strong>Tracking ID:</strong> <?= financeEscape($document['tracking_id'] ?? '') ?></div>
            </td>
        </tr>
    </table>

    <table class="frame items">
        <colgroup>
            <col style="width:3%"><col style="width:5%"><col style="width:18%"><col style="width:6%">
            <col style="width:5%"><col style="width:4%"><col style="width:8%"><col style="width:6%">
            <col style="width:6%"><col style="width:6%"><col style="width:6%"><col style="width:5%">
            <col style="width:5%"><col style="width:6%"><col style="width:5%"><col style="width:6%">
        </colgroup>
        <thead>
        <tr>
            <th>S.N.</th><th>HSN</th><th>Product Name</th><th>Pack</th><th>Qty</th><th>Free</th>
            <th>Batch</th><th>Mfg.</th><th>Exp.</th><th>M.R.P.</th><th>Rate</th><th>Dis.%</th>
            <th>SGST%</th><th>Value</th><th>CGST%</th><th><?= $isChallan ? 'Amount' : 'Total' ?></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $index => $item): ?>
            <tr>
                <td><?= $index + 1 ?></td>
                <td><?= financeEscape($item['hsn_code'] ?? '') ?></td>
                <td class="product"><?= financeEscape($item['product_name'] ?? '') ?></td>
                <td><?= financeEscape($item['pack_size'] ?? '') ?></td>
                <td><?= financeEscape(rtrim(rtrim(number_format((float) $item['quantity'], 3, '.', ''), '0'), '.')) ?></td>
                <td><?= financeEscape(rtrim(rtrim(number_format((float) $item['free_quantity'], 3, '.', ''), '0'), '.')) ?></td>
                <td><?= financeEscape($item['batch_number'] ?? '') ?></td>
                <td><?= financeDate($item['manufacturing_date'] ?? null, '') ?></td>
                <td><?= financeDate($item['expiry_date'] ?? null, '') ?></td>
                <td><?= financeMoney($item['mrp'] ?? 0) ?></td>
                <td><?= financeMoney($item['rate'] ?? 0) ?></td>
                <td><?= $isChallan ? '' : financeEscape((string) ($item['discount_percent'] ?? 0)) ?></td>
                <td><?= $isChallan ? '' : financeEscape((string) ($item['sgst_percent'] ?? 0)) ?></td>
                <td><?= $isChallan ? '' : financeMoney($item['sgst_value'] ?? 0) ?></td>
                <td><?= $isChallan ? '' : financeEscape((string) ($item['cgst_percent'] ?? 0)) ?></td>
                <td><?= financeMoney($item['line_total'] ?? 0) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php for ($i = count($items); $i < 7; $i++): ?>
            <tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <?php endfor; ?>
        </tbody>
    </table>

    <table class="frame summary-wrap">
        <tr>
            <td class="tax-summary">
                <table>
                    <tr><th>GST Rate</th><th>Taxable Value</th><th>SGST</th><th>CGST</th><th>IGST</th><th>Total GST</th></tr>
                    <?php if ($isChallan): ?>
                        <tr><td colspan="6">&nbsp;</td></tr>
                    <?php elseif ($taxGroups): ?>
                        <?php foreach ($taxGroups as $group): ?>
                            <tr>
                                <td><?= financeEscape(rtrim(rtrim(number_format($group['rate'], 3, '.', ''), '0'), '.')) ?>%</td>
                                <td><?= financeMoney($group['taxable']) ?></td>
                                <td><?= financeMoney($group['sgst']) ?></td>
                                <td><?= financeMoney($group['cgst']) ?></td>
                                <td><?= financeMoney($group['igst']) ?></td>
                                <td><?= financeMoney($group['sgst'] + $group['cgst'] + $group['igst']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td>0%</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr>
                    <?php endif; ?>
                </table>
            </td>
            <td class="totals">
                <table>
                    <tr><td class="label"><?= $isChallan ? 'TOTAL AMOUNT' : 'TOTAL' ?></td><td class="value"><?= $isChallan ? financeMoney($document['grand_total'] ?? 0) : financeMoney($document['subtotal'] ?? 0) ?></td></tr>
                    <tr><td class="label">DISCOUNT</td><td class="value"><?= $isChallan ? '' : financeMoney($document['discount_total'] ?? 0) ?></td></tr>
                    <tr><td class="label">ROUND OFF</td><td class="value"><?= $isChallan ? '' : financeMoney($document['round_off'] ?? 0) ?></td></tr>
                </table>
            </td>
        </tr>
        <tr>
            <td colspan="2" class="words"><strong>Amount in Words:</strong>
                <?= financeEscape(financeAmountInWords((float) ($document['grand_total'] ?? 0))) ?>
                <?php if ($isChallan): ?><br><strong>Dispatch value only; no receivable or payment is created.</strong><?php endif; ?>
            </td>
        </tr>
    </table>

    <table class="frame footer">
        <tr>
            <td class="bank">
                <div class="section-label">BANK DETAILS</div>
                <?php if ($selectedBank): ?>
                    <div><strong><?= financeEscape($selectedBank['bank_name'] ?? '') ?></strong></div>
                    <div>Branch: <?= financeEscape($selectedBank['branch_name'] ?? '') ?></div>
                    <div>A/C Name: <?= financeEscape($selectedBank['account_name'] ?? '') ?></div>
                    <div>A/C No.: <?= financeEscape($selectedBank['account_number'] ?? '') ?></div>
                    <div>IFSC: <?= financeEscape($selectedBank['ifsc_code'] ?? '') ?> &nbsp; SWIFT: <?= financeEscape($selectedBank['swift_code'] ?? '') ?></div>
                    <div>UPI: <?= financeEscape($selectedBank['upi_id'] ?? '') ?></div>
                <?php else: ?>
                    <div>Bank details not configured.</div>
                <?php endif; ?>
                <div class="terms"><strong>Terms &amp; Conditions:</strong>
<?= financeEscape($terms) ?></div>
            </td>
            <td class="sign">
                <div><strong>FOR <?= financeEscape(strtoupper($companyName)) ?></strong></div>
                <div class="sign-space"><?php if ($signature): ?><img class="signature-image" src="<?= $signature ?>" alt="Signature"><?php endif; ?></div>
                <?php if ($paymentQr): ?><img class="payment-qr" src="<?= $paymentQr ?>" alt="Payment QR"><?php endif; ?>
                <div class="authorised">Authorised Signatory</div>
            </td>
            <td class="grand">
                <table class="grand-table">
                    <tr><td>Total Items</td><td style="text-align:right"><?= count($items) ?></td></tr>
                    <tr><td>Total Quantity</td><td style="text-align:right"><?= financeEscape((string) array_sum(array_map(static fn($item) => (float) ($item['quantity'] ?? 0), $items))) ?></td></tr>
                    <tr><td>Taxable Amount</td><td style="text-align:right"><?= $isChallan ? '' : financeMoney($document['taxable_total'] ?? 0) ?></td></tr>
                    <tr><td>Total GST</td><td style="text-align:right"><?= $isChallan ? '' : financeMoney(
                        (float) ($document['cgst_total'] ?? 0)
                        + (float) ($document['sgst_total'] ?? 0)
                        + (float) ($document['igst_total'] ?? 0)
                    ) ?></td></tr>
                    <tr class="grand-total"><td><?= $isChallan ? 'Total Amount' : 'Grand Total' ?></td><td style="text-align:right">₹ <?= financeMoney($document['grand_total'] ?? 0) ?></td></tr>
                </table>
            </td>
        </tr>
    </table>
    <div class="page-note">This document was generated by the Biogenix ERP <?= $isSalesOrder ? 'Sales' : 'Finance' ?> module.</div>
</body>
</html>
    <?php
    return (string) ob_get_clean();
}

function financeGenerateDocumentPdf(mysqli $conn, int $documentId, int $userId): array
{
    $document = financeGetDocument($conn, $documentId);
    if (!$document || !in_array($document['document_type'], ['SALES_INVOICE', 'DELIVERY_CHALLAN'], true)) {
        throw new RuntimeException('The selected Finance document cannot be generated.');
    }

    // Generated documents are incremental overlays of the exact supplied
    // Invoice_1697.pdf / CA_200.pdf files, not substitute HTML layouts.
    $pdf = financeBuildApprovedTemplatePdf($document);

    $relativeDirectory = 'uploads/finance/generated';
    $absoluteDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'finance' . DIRECTORY_SEPARATOR . 'generated';
    if (!is_dir($absoluteDirectory) && !mkdir($absoluteDirectory, 0775, true) && !is_dir($absoluteDirectory)) {
        throw new RuntimeException('Unable to create the Finance document directory.');
    }

    $stmt = $conn->prepare(
        "SELECT COALESCE(MAX(version_number), 0) + 1 AS next_version
         FROM finance_document_files
         WHERE document_id = ? AND file_type = 'GENERATED_PDF'"
    );
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $version = (int) ($stmt->get_result()->fetch_assoc()['next_version'] ?? 1);
    $stmt->close();

    $safeNumber = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string) ($document['document_number'] ?? $documentId));
    $filename = strtolower($document['document_type']) . '-' . trim($safeNumber, '-') . '-v' . $version . '.pdf';
    $absolutePath = $absoluteDirectory . DIRECTORY_SEPARATOR . $filename;
    $relativePath = $relativeDirectory . '/' . $filename;
    if (file_put_contents($absolutePath, $pdf, LOCK_EX) === false) {
        throw new RuntimeException('Unable to save the generated Finance PDF.');
    }

    $hash = hash_file('sha256', $absolutePath);
    $size = filesize($absolutePath) ?: null;
    $stmt = $conn->prepare(
        "INSERT INTO finance_document_files
            (document_id, file_type, file_path, original_name, mime_type, file_size,
             file_hash, version_number, created_by)
         VALUES (?, 'GENERATED_PDF', ?, ?, 'application/pdf', ?, ?, ?, ?)"
    );
    $stmt->bind_param('issisii', $documentId, $relativePath, $filename, $size, $hash, $version, $userId);
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        @unlink($absolutePath);
        throw new RuntimeException('Unable to register the generated Finance PDF: ' . $error);
    }
    $fileId = (int) $conn->insert_id;
    $stmt->close();

    return ['file_id' => $fileId, 'path' => $relativePath, 'version' => $version];
}
