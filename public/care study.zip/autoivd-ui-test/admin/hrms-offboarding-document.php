<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (!isLoggedIn()) {
    http_response_code(401);
    exit('Authentication required.');
}
$documentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$documentId || $documentId <= 0) {
    http_response_code(400);
    exit('Invalid offboarding document.');
}
$stmt = $conn->prepare(
    "SELECT document.file_path, document.document_type, request.request_no, employee.user_id
     FROM hr_offboarding_documents document
     INNER JOIN hr_resignation_requests request ON request.id = document.resignation_request_id
     INNER JOIN employees employee ON employee.id = request.employee_id
     WHERE document.id = ? AND document.file_path IS NOT NULL
       AND document.status IN ('generated','sent','failed') LIMIT 1"
);
$stmt->bind_param('i', $documentId);
$stmt->execute();
$document = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$document) {
    http_response_code(404);
    exit('Document not found.');
}
$isOwner = (int) $document['user_id'] === (int) ($_SESSION['user_id'] ?? 0);
if (!$isOwner && !checkPermission('hrms_offboarding_manage', $conn)) {
    http_response_code(403);
    exit('Access denied.');
}
$projectRoot = realpath(dirname(__DIR__));
$relativePath = ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, (string) $document['file_path']), DIRECTORY_SEPARATOR);
$absolutePath = $projectRoot ? realpath($projectRoot . DIRECTORY_SEPARATOR . $relativePath) : false;
if (!$projectRoot || !$absolutePath || !str_starts_with($absolutePath, rtrim($projectRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) || !is_file($absolutePath)) {
    http_response_code(404);
    exit('Document file is unavailable.');
}
$displayName = preg_replace('/[^A-Za-z0-9_-]/', '-', (string) $document['document_type'] . '-' . (string) $document['request_no']) . '.pdf';
header('Content-Type: application/pdf');
header('Content-Length: ' . filesize($absolutePath));
header('Content-Disposition: inline; filename="' . $displayName . '"');
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
readfile($absolutePath);
exit;
