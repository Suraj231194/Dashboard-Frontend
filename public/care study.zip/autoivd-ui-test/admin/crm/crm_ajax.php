<?php
/**
 * CRM Module AJAX Handlers
 */

if (!defined('CRM_AJAX_CONTEXT') && basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'crm_ajax.php') {
    header('Content-Type: application/json');
    require_once __DIR__ . '/../db.php';
    require_once __DIR__ . '/../constant.php';
    require_once __DIR__ . '/../functions.php';
}
require_once __DIR__ . '/crm_common.php';

$action = $_POST['action'] ?? '';
$action = is_string($action) ? trim($action) : '';
crmRequireAjaxAccess($conn, $action);
$currentRoleId = (int) ($_SESSION['role_id'] ?? 0);
$currentUserId = (int) ($_SESSION['user_id'] ?? 0);

header('Content-Type: application/json');

/**
 * 0. Sync the in-scope, repository-owned lead sources into crm_leads.
 * The six explicitly excluded integrations are intentionally not handled here.
 */
function syncIncomingSourcesToCrm(mysqli $conn): void
{
    // A. Quiz Leads (Section 2)
    $qSql = "SELECT ql.id, ql.participant_first_name, ql.participant_last_name, ql.participant_email, ql.participant_phone, ql.submitted_at 
             FROM quiz_leads ql 
             LEFT JOIN crm_leads cl ON cl.source_reference_id = ql.id AND cl.source_reference_table = 'quiz_leads'
             WHERE cl.id IS NULL AND ql.submitted_at IS NOT NULL";
    $qRes = $conn->query($qSql);
    if ($qRes) {
        while ($q = $qRes->fetch_assoc()) {
            $leadNum = generateLeadNumber($conn);
            $fullName = trim(($q['participant_first_name'] ?? '') . ' ' . ($q['participant_last_name'] ?? ''));
            $company = $fullName ? $fullName . ' (Quiz Participant)' : 'Quiz Participant';
            $stmt = $conn->prepare("INSERT INTO crm_leads (lead_number, company_name, contact_person, mobile_number, email, source_type, source_reference_id, source_reference_table, lead_status, acceptance_status, priority, captured_at) VALUES (?, ?, ?, ?, ?, 'quiz', ?, 'quiz_leads', 'New', 'Pending', 'Medium', ?)");
            if ($stmt) {
                $qId = (string)$q['id'];
                $stmt->bind_param('sssssss', $leadNum, $company, $fullName, $q['participant_phone'], $q['participant_email'], $qId, $q['submitted_at']);
                $stmt->execute();
                if ($stmt->affected_rows === 1) {
                    logLeadActivity($conn, (int)$stmt->insert_id, 'Lead Captured', 'Captured from the website quiz.');
                }
                $stmt->close();
            }
        }
    }

    // B. Meeting Requests
    $mSql = "SELECT mr.id, mr.full_name, mr.email, mr.phone, mr.organization_name, mr.preferred_date, mr.created_at
             FROM meeting_requests mr
             LEFT JOIN crm_leads cl ON cl.source_reference_id = mr.id AND cl.source_reference_table = 'meeting_requests'
             WHERE cl.id IS NULL";
    $mRes = $conn->query($mSql);
    if ($mRes) {
        while ($m = $mRes->fetch_assoc()) {
            $leadNum = generateLeadNumber($conn);
            $company = $m['organization_name'] ?: ($m['full_name'] ? $m['full_name'] . ' Org' : 'Meeting Client');
            $stmt = $conn->prepare("INSERT INTO crm_leads (lead_number, company_name, contact_person, mobile_number, email, source_type, source_reference_id, source_reference_table, lead_status, acceptance_status, priority, captured_at) VALUES (?, ?, ?, ?, ?, 'meeting', ?, 'meeting_requests', 'New', 'Pending', 'High', ?)");
            if ($stmt) {
                $mId = (string)$m['id'];
                $stmt->bind_param('sssssss', $leadNum, $company, $m['full_name'], $m['phone'], $m['email'], $mId, $m['created_at']);
                $stmt->execute();
                if ($stmt->affected_rows === 1) {
                    logLeadActivity($conn, (int)$stmt->insert_id, 'Lead Captured', 'Captured from a meeting request.');
                }
                $stmt->close();
            }
        }
    }

    // C. WhatsApp messages. Successful order messages remain valid CRM history.
    $wSql = "SELECT wl.id, wl.from_phone, wl.from_name, wl.message_type, wl.raw_message, wl.raw_payload, wl.created_at
             FROM whatsapp_order_log wl
             LEFT JOIN crm_leads cl ON cl.source_reference_id = wl.id AND cl.source_reference_table = 'whatsapp_order_log'
             WHERE cl.id IS NULL";
    $wRes = $conn->query($wSql);
    if ($wRes) {
        while ($w = $wRes->fetch_assoc()) {
            $leadNum = generateLeadNumber($conn);
            $company = $w['from_name'] ? $w['from_name'] . ' (WhatsApp)' : 'WhatsApp Contact';
            $messageType = trim((string)($w['message_type'] ?? ''));
            $messageText = trim((string)($w['raw_message'] ?? ''));
            $notes = $messageType !== '' ? 'WhatsApp message type: ' . $messageType : 'WhatsApp enquiry';
            $stmt = $conn->prepare("INSERT INTO crm_leads (lead_number, company_name, contact_person, mobile_number, source_type, source_reference_id, source_reference_table, lead_status, acceptance_status, priority, notes, source_message_text, source_payload, captured_at) VALUES (?, ?, ?, ?, 'whatsapp', ?, 'whatsapp_order_log', 'New', 'Pending', 'Medium', ?, ?, ?, ?)");
            if ($stmt) {
                $wId = (string)$w['id'];
                $rawPayload = (string)($w['raw_payload'] ?? '');
                $stmt->bind_param('sssssssss', $leadNum, $company, $w['from_name'], $w['from_phone'], $wId, $notes, $messageText, $rawPayload, $w['created_at']);
                $stmt->execute();
                if ($stmt->affected_rows === 1) {
                    logLeadActivity($conn, (int)$stmt->insert_id, 'Lead Captured', 'Captured from WhatsApp.');
                }
                $stmt->close();
            }
        }
    }
}

/**
 * Evaluate automatic lead assignment based on Territory & Product rules (Section 3)
 */
function evaluateLeadAssignment(mysqli $conn, int $leadId): array
{
    return getLeadAssignmentRecommendation($conn, $leadId);
}

// Route actions
switch ($action) {

    // =========================================================================
    // 1. Get New Leads Count & Pipeline Stats
    // =========================================================================
    case 'crm_get_new_leads_count':
        syncIncomingSourcesToCrm($conn);
        $count = getNewLeadsCount($conn);
        echo json_encode(['status' => 'success', 'count' => $count]);
        exit;

    case 'crm_get_lead_stats':
        syncIncomingSourcesToCrm($conn);
        $countBySql = static function (mysqli $conn, string $sql): int {
            $result = $conn->query($sql);
            return $result ? (int)($result->fetch_assoc()['c'] ?? 0) : 0;
        };
        $total = $countBySql($conn, "SELECT COUNT(*) AS c FROM crm_leads WHERE deleted_at IS NULL AND acceptance_status = 'Accepted'");
        $incoming = $countBySql($conn, "SELECT COUNT(*) AS c FROM crm_leads WHERE deleted_at IS NULL AND acceptance_status = 'Pending'");
        $qualified = $countBySql($conn, "SELECT COUNT(*) AS c FROM crm_leads WHERE deleted_at IS NULL AND acceptance_status = 'Accepted' AND lead_status = 'Qualified'");
        $converted = $countBySql($conn, "SELECT COUNT(*) AS c FROM crm_leads WHERE deleted_at IS NULL AND acceptance_status = 'Accepted' AND lead_status = 'Converted'");

        echo json_encode([
            'status' => 'success',
            'total' => $total,
            'incoming' => $incoming,
            'qualified' => $qualified,
            'converted' => $converted
        ]);
        exit;

    case 'crm_get_sales_performance':
        $performanceSql = "SELECT sp.id, sp.salesperson_name, sp.salesperson_code, sp.sales_team,
                                  COUNT(cl.id) AS total_leads,
                                  COALESCE(SUM(cl.lead_status = 'Contacted'), 0) AS contacted_leads,
                                  COALESCE(SUM(cl.lead_status = 'Qualified'), 0) AS qualified_leads,
                                  COALESCE(SUM(cl.lead_status = 'Unqualified'), 0) AS unqualified_leads,
                                  COALESCE(SUM(cl.lead_status = 'Converted'), 0) AS converted_leads,
                                  COALESCE(SUM(cl.lead_status = 'Lost'), 0) AS lost_leads,
                                  (SELECT COUNT(*) FROM quotation_requests qr
                                   WHERE qr.assigned_salesperson_id = sp.id
                                     AND qr.source_origin = 'crm' AND qr.deleted_at IS NULL) AS quote_count,
                                  (SELECT COUNT(*) FROM proforma_invoices pi
                                   JOIN crm_leads pi_lead ON pi_lead.id = pi.lead_id
                                   WHERE pi_lead.assigned_salesperson_id = sp.id) AS pi_count,
                                  (SELECT COUNT(*) FROM order_received ord
                                   JOIN crm_leads ord_lead ON ord_lead.id = ord.lead_id
                                   WHERE ord_lead.assigned_salesperson_id = sp.id) AS order_count
                           FROM salesperson_masters sp
                           LEFT JOIN crm_leads cl ON cl.assigned_salesperson_id = sp.id
                                                 AND cl.acceptance_status = 'Accepted'
                                                 AND cl.deleted_at IS NULL
                           WHERE sp.deleted_at IS NULL
                           GROUP BY sp.id, sp.salesperson_name, sp.salesperson_code, sp.sales_team
                           ORDER BY converted_leads DESC, qualified_leads DESC, total_leads DESC, sp.salesperson_name ASC";
        $performanceResult = $conn->query($performanceSql);
        if (!$performanceResult) {
            crmJson('error', 'Unable to load sales performance.', [], 500);
        }

        $performanceHtml = '';
        while ($performance = $performanceResult->fetch_assoc()) {
            $totalLeads = (int)$performance['total_leads'];
            $convertedLeads = (int)$performance['converted_leads'];
            $conversionRate = $totalLeads > 0 ? round(($convertedLeads / $totalLeads) * 100, 1) : 0;
            $salespersonName = crmEscape($performance['salesperson_name']);
            $salespersonMeta = crmEscape(trim(($performance['salesperson_code'] ?? '') . (($performance['sales_team'] ?? '') !== '' ? ' · ' . $performance['sales_team'] : '')));
            $performanceHtml .= "<tr class='transition-colors hover:bg-slate-50/70'>
                <td class='px-6 py-3.5'><div class='text-[13px] font-bold text-slate-900'>{$salespersonName}</div><div class='mt-0.5 text-[11px] font-medium text-slate-500'>{$salespersonMeta}</div></td>
                <td class='px-4 py-3.5 text-center text-xs font-bold text-slate-700'>{$totalLeads}</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-blue-700'>" . (int)$performance['contacted_leads'] . "</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-amber-700'>" . (int)$performance['qualified_leads'] . "</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-slate-600'>" . (int)$performance['unqualified_leads'] . "</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-emerald-700'>{$convertedLeads}</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-rose-700'>" . (int)$performance['lost_leads'] . "</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-slate-700'>" . (int)$performance['quote_count'] . "</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-slate-700'>" . (int)$performance['pi_count'] . "</td>
                <td class='px-4 py-3.5 text-center text-xs font-semibold text-slate-700'>" . (int)$performance['order_count'] . "</td>
                <td class='px-6 py-3.5 text-right'><span class='inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-extrabold text-emerald-800'>{$conversionRate}%</span></td>
            </tr>";
        }
        if ($performanceHtml === '') {
            $performanceHtml = "<tr><td colspan='11' class='px-6 py-12 text-center text-sm font-medium text-slate-400'>No salesperson performance data is available.</td></tr>";
        }
        crmJson('success', '', ['html' => $performanceHtml]);

    // =========================================================================
    // 2. Load Incoming Leads Pop-up Table
    // =========================================================================
    case 'crm_load_incoming_leads':
        syncIncomingSourcesToCrm($conn);
        $res = $conn->query("SELECT id, lead_number, company_name, contact_person, mobile_number, email, source_type, city, state, captured_at 
                             FROM crm_leads 
                             WHERE acceptance_status = 'Pending' AND deleted_at IS NULL 
                             ORDER BY captured_at DESC");
        $html = '';
        $sr = 1;
        if ($res && $res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                $sourceBadge = Constant::CRM_LEAD['SOURCES'][$row['source_type']]['badge'] ?? 'bg-label-secondary';
                $sourceLabel = Constant::CRM_LEAD['SOURCES'][$row['source_type']]['label'] ?? ucfirst($row['source_type']);
                $timeStr = date('d M Y, h:i A', strtotime($row['captured_at']));
                $sourceBadge = crmEscape($sourceBadge);
                $sourceLabel = crmEscape($sourceLabel);
                $leadNumber = crmEscape($row['lead_number']);
                $companyName = crmEscape($row['company_name'] ?: 'N/A');
                $leadName = crmEscape($row['contact_person'] ?: ($row['company_name'] ?: 'N/A'));
                $reviewActions = '';
                if (roleHasPermission($currentRoleId, 'crm_lead_accept')) {
                    $reviewActions .= "<button type='button' class='btn btn-label-success btn-sm flex items-center gap-1' onclick='openAcceptLeadModal({$row['id']})'><span class='ti ti-check text-xs'></span> Accept</button>";
                }
                if (roleHasPermission($currentRoleId, 'crm_lead_reject')) {
                    $reviewActions .= "<button type='button' class='btn btn-label-danger btn-sm flex items-center gap-1' onclick='rejectLead({$row['id']})'><span class='ti ti-x text-xs'></span> Reject</button>";
                }

                $html .= "<tr class='group hover:bg-slate-50/50 transition-colors'>
                    <td class='px-6 py-3.5 font-semibold text-slate-500 align-middle whitespace-nowrap'>{$sr}</td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'><span class='badge {$sourceBadge} rounded-pill text-[11px]'>{$sourceLabel}</span></td>
                    <td class='px-6 py-3.5 text-xs text-slate-600 align-middle whitespace-nowrap'>{$timeStr}</td>
                    <td class='px-6 py-3.5 font-mono font-bold text-slate-900 align-middle whitespace-nowrap'>
                        <span class='font-mono font-bold text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 whitespace-nowrap inline-block'>{$leadNumber}</span>
                    </td>
                    <td class='px-6 py-3.5 align-middle font-semibold text-slate-800'>{$leadName}</td>
                    <td class='px-6 py-3.5 align-middle font-semibold text-slate-800'>{$companyName}</td>
                    <td class='px-6 py-3.5 text-center align-middle whitespace-nowrap'>
                        <div class='flex items-center justify-center gap-1.5'>{$reviewActions}</div>
                    </td>
                </tr>";
                $sr++;
            }
        }
        echo json_encode(['status' => 'success', 'html' => $html]);
        exit;

    // =========================================================================
    // 3. Get Lead Data & Run Auto-Assignment Evaluation for Accept Modal
    // =========================================================================
    case 'crm_get_lead_for_accept_modal':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $res = $conn->query("SELECT * FROM crm_leads WHERE id = {$leadId} AND acceptance_status = 'Pending' AND deleted_at IS NULL LIMIT 1");
        if (!$res || $res->num_rows === 0) {
            echo json_encode(['status' => 'error', 'message' => 'Lead not found']);
            exit;
        }
        $lead = $res->fetch_assoc();

        // Get interested products
        $products = [];
        $pRes = $conn->query("SELECT p.id, p.product_name, p.product_code FROM crm_lead_products lp JOIN products p ON p.id = lp.product_id WHERE lp.lead_id = {$leadId}");
        if ($pRes) {
            while ($p = $pRes->fetch_assoc()) {
                $products[] = $p;
            }
        }

        // Run auto-assignment evaluation engine (Section 3)
        $eval = evaluateLeadAssignment($conn, $leadId);

        // Get all active salespersons
        $salespersons = [];
        $spRes = $conn->query("SELECT id, salesperson_name, salesperson_code, sales_team FROM salesperson_masters WHERE deleted_at IS NULL AND status = 1 ORDER BY salesperson_name ASC");
        if ($spRes) {
            while ($sp = $spRes->fetch_assoc()) {
                $salespersons[] = $sp;
            }
        }

        echo json_encode([
            'status' => 'success',
            'lead' => $lead,
            'products' => $products,
            'salespersons' => $salespersons,
            'recommended_sp_id' => $eval['salesperson_id'],
            'recommended_sp_name' => $eval['salesperson_name'] ?? '',
            'match_reason' => $eval['match_reason']
        ]);
        exit;

    // =========================================================================
    // 3B. Confirm Accept & Assign Lead
    // =========================================================================
    case 'crm_confirm_accept_lead':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $salespersonId = !empty($_POST['salesperson_id']) ? (int)$_POST['salesperson_id'] : null;
        $priority = trim($_POST['priority'] ?? 'Medium');
        $notes = trim($_POST['assignment_notes'] ?? '');

        if ($leadId <= 0 || !in_array($priority, ['Low', 'Medium', 'High'], true)) {
            crmJson('error', 'Invalid lead or priority.', [], 422);
        }

        $recommendation = evaluateLeadAssignment($conn, $leadId);
        $assignmentReason = '';
        $salesTeam = '';
        $spName = 'Unassigned';
        if ($salespersonId) {
            $spStmt = $conn->prepare(
                'SELECT salesperson_name, sales_team FROM salesperson_masters WHERE id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1'
            );
            $spStmt->bind_param('i', $salespersonId);
            $spStmt->execute();
            $salesperson = $spStmt->get_result()->fetch_assoc();
            $spStmt->close();
            if (!$salesperson) {
                crmJson('error', 'Select an active salesperson.', [], 422);
            }
            $spName = (string)$salesperson['salesperson_name'];
            $salesTeam = (string)($salesperson['sales_team'] ?? '');
            $assignmentReason = (int)($recommendation['salesperson_id'] ?? 0) === $salespersonId
                ? (string)($recommendation['match_reason'] ?? 'Recommended assignment')
                : 'Manually selected during lead acceptance';
        } elseif (!empty($recommendation['salesperson_id'])) {
            $salespersonId = (int)$recommendation['salesperson_id'];
            $spName = (string)$recommendation['salesperson_name'];
            $salesTeam = (string)($recommendation['sales_team'] ?? '');
            $assignmentReason = (string)$recommendation['match_reason'];
        } else {
            $assignmentReason = (string)($recommendation['match_reason'] ?? 'No assignment rule matched');
        }

        $stmt = $conn->prepare(
            "UPDATE crm_leads
             SET acceptance_status = 'Accepted', lead_status = 'New', assigned_salesperson_id = ?,
                 sales_team = ?, assignment_reason = ?, priority = ?, accepted_at = NOW(),
                 accepted_by = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ? AND acceptance_status = 'Pending' AND deleted_at IS NULL"
        );
        $stmt->bind_param('isssiii', $salespersonId, $salesTeam, $assignmentReason, $priority, $currentUserId, $currentUserId, $leadId);
        $ok = $stmt->execute() && $stmt->affected_rows === 1;
        $stmt->close();
        if (!$ok) {
            crmJson('error', 'The lead is no longer pending or could not be accepted.', [], 409);
        }

        $details = "Lead accepted into CRM and assigned to {$spName}. {$assignmentReason}.";
        if ($notes !== '') {
            $details .= " Notes: {$notes}";
        }
        logLeadActivity($conn, $leadId, 'Lead Accepted & Assigned', $details, $currentUserId);
        crmJson('success', "Lead accepted and assigned to {$spName} successfully.");

    // =========================================================================
    // 4. Reject Incoming Lead
    // =========================================================================
    case 'crm_reject_lead':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        if ($leadId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid lead ID']);
            exit;
        }
        $stmt = $conn->prepare("UPDATE crm_leads SET acceptance_status = 'Rejected', rejected_at = NOW(), rejected_by = ?, updated_at = NOW() WHERE id = ? AND acceptance_status = 'Pending' AND deleted_at IS NULL");
        $stmt->bind_param('ii', $currentUserId, $leadId);
        $ok = $stmt->execute() && $stmt->affected_rows === 1;
        $stmt->close();

        if ($ok) {
            logLeadActivity($conn, $leadId, 'Lead Rejected', 'Rejected from CRM pipeline by user #' . $currentUserId, $currentUserId);
            echo json_encode(['status' => 'success', 'message' => 'Lead rejected']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database error rejecting lead']);
        }
        exit;

    // =========================================================================
    // 5. Load Accepted Leads Grid (Tile View per Section 2.3)
    // =========================================================================
    case 'crm_load_leads_grid':
        $status = trim($_POST['status'] ?? 'all');
        $search = trim($_POST['search'] ?? '');
        $source = trim($_POST['source'] ?? '');
        $custType = trim($_POST['customer_type'] ?? '');
        $priority = trim($_POST['priority'] ?? '');
        $page = max(1, (int) ($_POST['page'] ?? 1));
        $limit = 12;
        $offset = ($page - 1) * $limit;

        $where = ["cl.acceptance_status = 'Accepted'", "cl.deleted_at IS NULL"];

        if ($status !== 'all' && $status !== '') {
            $escStatus = $conn->real_escape_string($status);
            $where[] = "cl.lead_status = '{$escStatus}'";
        }
        if ($source !== '') {
            $escSrc = $conn->real_escape_string($source);
            $where[] = "cl.source_type = '{$escSrc}'";
        }
        if ($custType !== '') {
            $escCust = $conn->real_escape_string($custType);
            $where[] = "cl.customer_type = '{$escCust}'";
        }
        if ($priority !== '') {
            $escPrio = $conn->real_escape_string($priority);
            $where[] = "cl.priority = '{$escPrio}'";
        }
        if ($search !== '') {
            $escSearch = $conn->real_escape_string($search);
            $where[] = "(cl.lead_number LIKE '%{$escSearch}%' OR cl.company_name LIKE '%{$escSearch}%' OR cl.contact_person LIKE '%{$escSearch}%' OR cl.mobile_number LIKE '%{$escSearch}%' OR cl.territory LIKE '%{$escSearch}%' OR cl.city LIKE '%{$escSearch}%')";
        }

        $whereSql = implode(' AND ', $where);

        // Count total
        $countRes = $conn->query("SELECT COUNT(*) AS total FROM crm_leads cl WHERE {$whereSql}");
        $totalCount = $countRes ? (int)($countRes->fetch_assoc()['total'] ?? 0) : 0;

        // Fetch page
        $sql = "SELECT cl.*, sp.salesperson_name, sp.salesperson_code 
                FROM crm_leads cl 
                LEFT JOIN salesperson_masters sp ON sp.id = cl.assigned_salesperson_id 
                WHERE {$whereSql} 
                ORDER BY cl.id DESC 
                LIMIT {$limit} OFFSET {$offset}";
        $res = $conn->query($sql);

        $html = '';
        if ($res && $res->num_rows > 0) {
            while ($lead = $res->fetch_assoc()) {
                $leadId = (int)$lead['id'];
                $statusBadge = Constant::CRM_LEAD['STATUS'][$lead['lead_status']]['badge'] ?? 'bg-label-primary';
                $priorityBadge = Constant::CRM_LEAD['PRIORITY'][$lead['priority']]['badge'] ?? 'bg-label-secondary';
                $sourceBadge = Constant::CRM_LEAD['SOURCES'][$lead['source_type']]['badge'] ?? 'bg-label-info';
                $sourceLabel = Constant::CRM_LEAD['SOURCES'][$lead['source_type']]['label'] ?? ucfirst($lead['source_type']);

                // Fetch product tags
                $prodTags = '';
                $pRes = $conn->query("SELECT p.product_name FROM crm_lead_products lp JOIN products p ON p.id = lp.product_id WHERE lp.lead_id = {$leadId} LIMIT 3");
                if ($pRes) {
                    while ($pRow = $pRes->fetch_assoc()) {
                        $prodTags .= "<span class='inline-block px-2 py-0.5 bg-slate-100 text-slate-700 text-[11px] rounded-md font-medium truncate max-w-[140px]'>" . htmlspecialchars($pRow['product_name']) . "</span> ";
                    }
                }

                $assignedStr = $lead['salesperson_name'] ? htmlspecialchars($lead['salesperson_name']) : '<span class="text-amber-600 italic font-medium">Unassigned</span>';
                $location = array_filter([$lead['territory'], $lead['city'], $lead['state'], $lead['region']]);
                $locStr = !empty($location) ? implode(', ', $location) : 'N/A';

                $leadNumber = crmEscape($lead['lead_number']);
                $companyName = crmEscape($lead['company_name'] ?: 'N/A');
                $customerType = crmEscape($lead['customer_type'] ?: 'Other');
                $contactPerson = crmEscape($lead['contact_person'] ?: 'N/A');
                $mobileNumber = crmEscape($lead['mobile_number'] ?: 'N/A');
                $emailAddress = crmEscape($lead['email'] ?: 'N/A');
                $locationText = crmEscape($locStr);
                $sourceLabelEscaped = crmEscape($sourceLabel);
                $leadStatus = crmEscape($lead['lead_status']);
                $leadPriority = crmEscape($lead['priority']);
                $createdDate = crmEscape(date('d M Y, h:i A', strtotime($lead['captured_at'] ?: $lead['created_at'])));
                $lastActivity = crmEscape(
                    $lead['last_activity_date']
                        ? date('d M Y, h:i A', strtotime($lead['last_activity_date']))
                        : 'No activity yet'
                );
                $actions = "<button type='button' class='btn btn-icon btn-label-secondary btn-sm' title='View Lead' onclick='viewLeadDetail({$leadId})'><span class='ti ti-eye'></span></button>";
                if (roleHasPermission($currentRoleId, 'crm_lead_edit')) {
                    $actions .= "<button type='button' class='btn btn-icon btn-label-primary btn-sm' title='Edit Lead' onclick='openLeadModal(\"edit\", {$leadId})'><span class='ti ti-edit'></span></button>";
                }
                if (roleHasPermission($currentRoleId, 'crm_quote_add')) {
                    $actions .= "<button type='button' class='btn btn-icon btn-label-success btn-sm' title='Create Quote' onclick='selectLeadForQuote({$leadId})'><span class='ti ti-file-dollar'></span></button>";
                }
                if (roleHasPermission($currentRoleId, 'crm_lead_delete')) {
                    $actions .= "<button type='button' class='btn btn-icon btn-label-danger btn-sm' title='Delete Lead' onclick='deleteLead({$leadId})'><span class='ti ti-trash'></span></button>";
                }

                $html .= "<article role='button' tabindex='0' onclick='viewLeadDetail({$leadId})' onkeydown='if(event.key===\"Enter\"||event.key===\" \"){event.preventDefault();viewLeadDetail({$leadId});}' class='flex min-h-[300px] cursor-pointer flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-emerald-200 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-emerald-500/30'>
                    <div class='flex items-start justify-between gap-3'>
                        <div>
                            <span class='font-mono font-bold text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100'>{$leadNumber}</span>
                            <p class='mt-2 text-[11px] font-medium text-slate-400'>Captured {$createdDate}</p>
                        </div>
                        <div class='flex flex-col items-end gap-1.5'>
                            <span class='badge {$statusBadge} rounded-pill text-[11px]'>{$leadStatus}</span>
                            <span class='badge {$priorityBadge} rounded-pill text-[11px]'>{$leadPriority}</span>
                        </div>
                    </div>
                    <div class='mt-4'>
                        <h3 class='text-sm font-extrabold text-slate-900'>{$companyName}</h3>
                        <p class='mt-0.5 text-xs font-medium text-slate-500'>{$customerType}</p>
                    </div>
                    <div class='mt-3 grid grid-cols-1 gap-1.5 text-xs text-slate-600'>
                        <p><i class='ti ti-user mr-1.5 text-slate-400'></i>{$contactPerson}</p>
                        <p><i class='ti ti-phone mr-1.5 text-slate-400'></i>{$mobileNumber}</p>
                        <p class='truncate'><i class='ti ti-mail mr-1.5 text-slate-400'></i>{$emailAddress}</p>
                        <p><i class='ti ti-map-pin mr-1.5 text-slate-400'></i>{$locationText}</p>
                    </div>
                    " . ($prodTags ? "<div class='mt-3 flex flex-wrap gap-1'>{$prodTags}</div>" : '') . "
                    <div class='mt-auto pt-4'>
                        <div class='flex items-center justify-between gap-3 border-t border-slate-100 pt-3 text-xs'>
                            <span class='badge {$sourceBadge} rounded-pill text-[11px]'>{$sourceLabelEscaped}</span>
                            <span class='font-semibold text-slate-700'>{$assignedStr}</span>
                        </div>
                        <p class='mt-2 text-right text-[11px] font-medium text-slate-400'>Last activity: {$lastActivity}</p>
                        <div class='mt-3 flex items-center justify-end gap-1.5' onclick='event.stopPropagation()'>{$actions}</div>
                    </div>
                </article>";
                continue;

                $html .= "<tr class='group hover:bg-slate-50/50 transition-colors'>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap min-w-[140px]'>
                        <span class='font-mono font-bold text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100 whitespace-nowrap inline-block'>{$lead['lead_number']}</span>
                        <div class='text-[11px] text-slate-400 mt-1 whitespace-nowrap font-medium'>" . date('d M Y', strtotime($lead['created_at'])) . "</div>
                    </td>
                    <td class='px-6 py-3.5 align-middle'>
                        <div class='font-bold text-slate-900 text-[13px]'>" . htmlspecialchars($lead['company_name'] ?? 'N/A') . "</div>
                        <div class='text-xs text-slate-500 font-medium'>" . htmlspecialchars($lead['customer_type'] ?? 'General') . "</div>
                        " . ($prodTags ? "<div class='flex flex-wrap gap-1 mt-1'>{$prodTags}</div>" : "") . "
                    </td>
                    <td class='px-6 py-3.5 align-middle text-[13px] text-slate-600'>
                        <div class='font-bold text-slate-800'>" . htmlspecialchars($lead['contact_person'] ?? 'N/A') . "</div>
                        " . ($lead['mobile_number'] ? "<div class='text-slate-500 text-xs mt-0.5 whitespace-nowrap'><i class='ti ti-phone text-xs text-slate-400 mr-1'></i>" . htmlspecialchars($lead['mobile_number']) . "</div>" : "") . "
                        " . ($lead['email'] ? "<div class='text-slate-400 text-xs truncate max-w-[180px] mt-0.5'><i class='ti ti-mail text-xs text-slate-400 mr-1'></i>" . htmlspecialchars($lead['email']) . "</div>" : "") . "
                    </td>
                    <td class='px-6 py-3.5 align-middle text-[13px] text-slate-600 whitespace-nowrap'>
                        <div class='flex items-center gap-1.5'>
                            <i class='ti ti-map-pin text-slate-400 text-sm'></i>
                            <span>{$locStr}</span>
                        </div>
                    </td>
                    <td class='px-6 py-3.5 align-middle text-[13px] whitespace-nowrap'>
                        <div class='font-semibold text-slate-800'>{$assignedStr}</div>
                    </td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'>
                        <span class='badge {$sourceBadge} rounded-pill text-[11px]'>{$sourceLabel}</span>
                    </td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'>
                        <span class='badge {$statusBadge} rounded-pill text-[11px]'>{$lead['lead_status']}</span>
                    </td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'>
                        <span class='badge {$priorityBadge} rounded-pill text-[11px]'>{$lead['priority']}</span>
                    </td>
                    <td class='px-6 py-3.5 align-middle text-right whitespace-nowrap'>
                        <div class='flex flex-nowrap items-center justify-end gap-1.5'>
                            <button type='button' class='btn btn-icon btn-label-secondary btn-sm' title='View Lead Dossier' onclick='viewLeadDetail({$leadId})'>
                                <span class='ti ti-eye'></span>
                            </button>
                            <button type='button' class='btn btn-icon btn-label-primary btn-sm' title='Edit Lead' onclick='openLeadModal(\"edit\", {$leadId})'>
                                <span class='ti ti-edit'></span>
                            </button>
                            <button type='button' class='btn btn-icon btn-label-success btn-sm' title='Create Commercial Quote' onclick='selectLeadForQuote({$leadId})'>
                                <span class='ti ti-file-dollar'></span>
                            </button>
                            <button type='button' class='btn btn-icon btn-label-danger btn-sm' title='Delete Lead' onclick='deleteLead({$leadId})'>
                                <span class='ti ti-trash'></span>
                            </button>
                        </div>
                    </td>
                </tr>";
            }
        }

        $html = $html ?: "<div class='col-span-full px-6 py-12 text-center text-slate-400'><i class='ti ti-mood-empty text-3xl mb-2 block text-slate-300'></i><p class='text-sm font-medium'>No leads found matching your criteria.</p></div>";

        // Pagination HTML
        $totalPages = ceil($totalCount / $limit);
        $paginationHtml = "<div>Showing <strong>" . min($offset + 1, $totalCount) . "</strong> to <strong>" . min($offset + $limit, $totalCount) . "</strong> of <strong>{$totalCount}</strong> leads</div>";
        if ($totalPages > 1) {
            $paginationHtml .= "<div class='flex items-center gap-1'>";
            for ($i = 1; $i <= $totalPages; $i++) {
                $activeCls = ($i === $page) ? 'bg-primary-600 text-white font-bold' : 'bg-slate-100 hover:bg-slate-200 text-slate-700';
                $paginationHtml .= "<button type='button' class='px-3 py-1 rounded-lg text-xs transition {$activeCls}' onclick='loadLeadsGrid({$i})'>{$i}</button>";
            }
            $paginationHtml .= "</div>";
        }

        echo json_encode([
            'status' => 'success',
            'html' => $html,
            'pagination' => $paginationHtml,
            'total' => $totalCount
        ]);
        exit;

    // =========================================================================
    // 6. Get Lead Detail + Timeline Activity Log
    // =========================================================================
    case 'crm_get_lead_detail':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $stmt = $conn->prepare("SELECT cl.*, sp.salesperson_name, sp.salesperson_code 
                                FROM crm_leads cl 
                                LEFT JOIN salesperson_masters sp ON sp.id = cl.assigned_salesperson_id 
                                WHERE cl.id = ? AND cl.deleted_at IS NULL LIMIT 1");
        $stmt->bind_param('i', $leadId);
        $stmt->execute();
        $lead = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$lead) {
            echo json_encode(['status' => 'error', 'message' => 'Lead not found']);
            exit;
        }

        // Fetch products
        $products = [];
        $pRes = $conn->query("SELECT p.id, p.product_name, p.product_code FROM crm_lead_products lp JOIN products p ON p.id = lp.product_id WHERE lp.lead_id = {$leadId}");
        if ($pRes) {
            while ($p = $pRes->fetch_assoc()) {
                $products[] = $p;
            }
        }

        // Fetch activity timeline
        $timeline = [];
        $tRes = $conn->query("SELECT al.*, u.name AS user_name 
                              FROM crm_lead_activity_log al 
                              LEFT JOIN users u ON u.id = al.user_id 
                              WHERE al.lead_id = {$leadId} 
                              ORDER BY al.created_at DESC");
        if ($tRes) {
            while ($t = $tRes->fetch_assoc()) {
                $timeline[] = $t;
            }
        }

        // Build HTML
        $statusBadge = Constant::CRM_LEAD['STATUS'][$lead['lead_status']]['badge'] ?? 'bg-label-primary';
        $sourceBadge = Constant::CRM_LEAD['SOURCES'][$lead['source_type']]['badge'] ?? 'bg-label-info';
        $sourceLabel = Constant::CRM_LEAD['SOURCES'][$lead['source_type']]['label'] ?? ucfirst($lead['source_type']);

        $detailHtml = "
        <div class='grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/60 text-xs'>
            <div><strong>Company:</strong> " . htmlspecialchars($lead['company_name'] ?? 'N/A') . "</div>
            <div><strong>Contact Person:</strong> " . htmlspecialchars($lead['contact_person'] ?? 'N/A') . "</div>
            <div><strong>Mobile:</strong> " . htmlspecialchars($lead['mobile_number'] ?? 'N/A') . "</div>
            <div><strong>Email:</strong> " . htmlspecialchars($lead['email'] ?? 'N/A') . "</div>
            <div><strong>Customer Type:</strong> " . htmlspecialchars($lead['customer_type'] ?? 'N/A') . "</div>
            <div><strong>Priority:</strong> " . htmlspecialchars($lead['priority'] ?? 'Medium') . "</div>
            <div><strong>Territory:</strong> " . crmEscape($lead['territory'] ?: 'N/A') . "</div>
            <div><strong>Location:</strong> " . htmlspecialchars(implode(', ', array_filter([$lead['city'], $lead['state'], $lead['region']])) ?: 'N/A') . "</div>
            <div><strong>Assigned Salesperson:</strong> " . htmlspecialchars($lead['salesperson_name'] ?? 'Unassigned') . "</div>
            <div><strong>Sales Team:</strong> " . crmEscape($lead['sales_team'] ?: 'Unassigned') . "</div>
            <div><strong>Captured At:</strong> " . crmEscape(date('d M Y, h:i A', strtotime($lead['captured_at']))) . "</div>
            <div><strong>Last Activity:</strong> " . crmEscape($lead['last_activity_date'] ? date('d M Y, h:i A', strtotime($lead['last_activity_date'])) : 'No activity yet') . "</div>
            <div><strong>Source:</strong> <span class='badge {$sourceBadge} text-[10px]'>{$sourceLabel}</span></div>
            <div><strong>Current Status:</strong> <span class='badge {$statusBadge} text-[10px]'>{$lead['lead_status']}</span></div>
            " . ($lead['assignment_reason'] ? "<div class='col-span-full'><strong>Assignment Reason:</strong> " . crmEscape($lead['assignment_reason']) . "</div>" : '') . "
            " . ($lead['source_message_text'] ? "<div class='col-span-full'><strong>Source Message:</strong> " . nl2br(crmEscape($lead['source_message_text'])) . "</div>" : '') . "
            " . ($lead['notes'] ? "<div class='col-span-full pt-2 border-t border-slate-200'><strong>Notes:</strong> " . nl2br(htmlspecialchars($lead['notes'])) . "</div>" : "") . "
        </div>";

        if (!empty($products)) {
            $detailHtml .= "<div class='mt-4'><h6 class='font-bold text-xs text-slate-700 uppercase tracking-wider mb-2'>Interested Products</h6><div class='flex flex-wrap gap-1.5'>";
            foreach ($products as $p) {
                $detailHtml .= "<span class='px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs rounded-lg font-bold'>" . htmlspecialchars($p['product_name']) . "</span>";
            }
            $detailHtml .= "</div></div>";
        }

        // Status Update Quick Action
        $detailHtml .= "
        <div class='mt-4 pt-4 border-t border-slate-200 flex flex-wrap items-center gap-2'>
            <span class='text-xs font-bold text-slate-600'>Update Lifecycle Status:</span>
            <button type='button' class='px-2.5 py-1 text-xs font-bold rounded-lg bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 transition' onclick='updateLeadStatus({$leadId}, \"Contacted\")'>Contacted</button>
            <button type='button' class='px-2.5 py-1 text-xs font-bold rounded-lg bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition' onclick='updateLeadStatus({$leadId}, \"Qualified\")'>Qualified</button>
            <button type='button' class='px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-100 text-slate-700 border border-slate-200 hover:bg-slate-200 transition' onclick='updateLeadStatus({$leadId}, \"Unqualified\")'>Unqualified</button>
            <button type='button' class='px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 transition' onclick='updateLeadStatus({$leadId}, \"Converted\")'>Converted</button>
            <button type='button' class='px-2.5 py-1 text-xs font-bold rounded-lg bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition' onclick='updateLeadStatus({$leadId}, \"Lost\")'>Lost</button>
        </div>";

        // Activity Timeline & Comment Box
        $detailHtml .= "
        <div class='mt-5 pt-5 border-t border-slate-100'>
            <h6 class='font-bold text-xs text-slate-700 uppercase tracking-wider mb-3'>Activity Timeline & Interaction History</h6>
            
            <!-- Comment Input -->
            <div class='flex flex-col items-stretch gap-2 mb-4 sm:flex-row sm:items-center'>
                <input type='text' id='leadCommentInput' placeholder='Add follow-up notes, call remarks, next meeting date...' class='form-control min-w-0 flex-1 !rounded-xl border-slate-200 text-xs py-2 px-3 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm'>
                <button type='button' class='inline-flex h-9 shrink-0 items-center justify-center px-4 !rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm ring-1 ring-emerald-900/10 transition cursor-pointer' onclick='addLeadComment({$leadId})'>Post Note</button>
            </div>

            <!-- Timeline items -->
            <div class='space-y-3 max-h-60 overflow-y-auto pr-1'>";
            if (!empty($timeline)) {
                foreach ($timeline as $tl) {
                    $dt = date('d M Y, h:i A', strtotime($tl['created_at']));
                    $by = $tl['user_name'] ? 'by <strong>' . crmEscape($tl['user_name']) . '</strong>' : '';
                    $detailHtml .= "
                    <div class='p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs'>
                        <div class='flex justify-between items-center mb-1 text-slate-500'>
                            <span class='font-bold text-slate-800'>" . htmlspecialchars($tl['action']) . " {$by}</span>
                            <span class='text-[11px]'>{$dt}</span>
                        </div>
                        " . ($tl['details'] ? "<div class='text-slate-600'>" . nl2br(htmlspecialchars($tl['details'])) . "</div>" : "") . "
                    </div>";
                }
            } else {
                $detailHtml .= "<p class='text-xs text-slate-400 italic'>No activity logged yet.</p>";
            }
            $detailHtml .= "</div>
        </div>";

        $actionsHtml = "
        <button type='button' class='inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white !rounded-xl font-bold text-xs shadow-sm ring-1 ring-emerald-900/10 transition cursor-pointer' onclick='selectLeadForQuote({$leadId})'>
            <i class='ti ti-file-plus'></i> Generate Quote
        </button>
        <button type='button' class='inline-flex items-center gap-1.5 px-3 py-2 border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 !rounded-xl font-bold text-xs shadow-sm transition cursor-pointer' onclick='openLeadModal(\"edit\", {$leadId})'>
            <i class='ti ti-edit'></i> Edit
        </button>";

        echo json_encode([
            'status' => 'success',
            'lead' => $lead,
            'html' => $detailHtml,
            'actionsHtml' => $actionsHtml
        ]);
        exit;

    // =========================================================================
    // 7. Get Lead for Edit Form
    // =========================================================================
    case 'crm_get_lead_for_edit':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $stmt = $conn->prepare("SELECT * FROM crm_leads WHERE id = ? AND acceptance_status = 'Accepted' AND deleted_at IS NULL LIMIT 1");
        $stmt->bind_param('i', $leadId);
        $stmt->execute();
        $lead = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$lead) {
            echo json_encode(['status' => 'error', 'message' => 'Lead not found']);
            exit;
        }

        $prodIds = [];
        $pRes = $conn->query("SELECT product_id FROM crm_lead_products WHERE lead_id = {$leadId}");
        if ($pRes) {
            while ($p = $pRes->fetch_assoc()) {
                $prodIds[] = (int)$p['product_id'];
            }
        }

        echo json_encode(['status' => 'success', 'lead' => $lead, 'product_ids' => $prodIds]);
        exit;

    // =========================================================================
    // 8. Save Lead (Create or Update)
    // =========================================================================
    case 'crm_save_lead':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $company = trim($_POST['company_name'] ?? '');
        $contact = trim($_POST['contact_person'] ?? '');
        $mobile = trim($_POST['mobile_number'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $custType = trim($_POST['customer_type'] ?? 'Other');
        $priority = trim($_POST['priority'] ?? 'Medium');
        $city = trim($_POST['city'] ?? '');
        $state = trim($_POST['state'] ?? '');
        $territory = trim($_POST['territory'] ?? '');
        $region = trim($_POST['region'] ?? '');
        $spId = !empty($_POST['assigned_salesperson_id']) ? (int)$_POST['assigned_salesperson_id'] : null;
        $notes = trim($_POST['notes'] ?? '');
        $productIds = $_POST['product_ids'] ?? [];

        if ($company === '' || !in_array($custType, Constant::CRM_LEAD['CUSTOMER_TYPES'], true)
            || !in_array($priority, ['Low', 'Medium', 'High'], true)) {
            crmJson('error', 'Provide a company name, valid customer type, and valid priority.', [], 422);
        }
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            crmJson('error', 'Enter a valid email address.', [], 422);
        }

        $productIds = array_values(array_unique(array_filter(
            array_map('intval', is_array($productIds) ? $productIds : []),
            static fn(int $id): bool => $id > 0
        )));
        $salesTeam = '';
        $assignmentReason = 'Awaiting territory/product assignment evaluation';
        if ($spId !== null) {
            $spStmt = $conn->prepare(
                'SELECT salesperson_name, sales_team FROM salesperson_masters WHERE id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1'
            );
            $spStmt->bind_param('i', $spId);
            $spStmt->execute();
            $selectedSalesperson = $spStmt->get_result()->fetch_assoc();
            $spStmt->close();
            if (!$selectedSalesperson) {
                crmJson('error', 'Select an active salesperson.', [], 422);
            }
            $salesTeam = (string)($selectedSalesperson['sales_team'] ?? '');
            $assignmentReason = 'Manually assigned to ' . $selectedSalesperson['salesperson_name'];
        }

        $conn->begin_transaction();
        try {
            if ($leadId > 0) {
                $stmt = $conn->prepare(
                    "UPDATE crm_leads SET company_name = ?, contact_person = ?, mobile_number = ?, email = ?,
                     customer_type = ?, priority = ?, city = ?, state = ?, territory = ?, region = ?, assigned_salesperson_id = ?,
                     sales_team = ?, assignment_reason = ?, notes = ?, updated_by = ?, updated_at = NOW()
                     WHERE id = ? AND deleted_at IS NULL"
                );
                $stmt->bind_param('ssssssssssisssii', $company, $contact, $mobile, $email, $custType, $priority, $city, $state, $territory, $region, $spId, $salesTeam, $assignmentReason, $notes, $currentUserId, $leadId);
                if (!$stmt->execute() || $stmt->affected_rows < 0) {
                    throw new RuntimeException('Unable to update the lead.');
                }
                $stmt->close();
            } else {
                $leadNumber = generateLeadNumber($conn);
                $stmt = $conn->prepare(
                    "INSERT INTO crm_leads
                     (lead_number, company_name, contact_person, mobile_number, email, customer_type, source_type,
                      priority, city, state, territory, region, assigned_salesperson_id, sales_team, assignment_reason,
                      lead_status, acceptance_status, notes, accepted_at, accepted_by, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, 'manual', ?, ?, ?, ?, ?, ?, ?, ?, 'New', 'Accepted', ?, NOW(), ?, ?, NOW())"
                );
                $stmt->bind_param('sssssssssssisssii', $leadNumber, $company, $contact, $mobile, $email, $custType, $priority, $city, $state, $territory, $region, $spId, $salesTeam, $assignmentReason, $notes, $currentUserId, $currentUserId);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to create the lead.');
                }
                $leadId = (int)$stmt->insert_id;
                $stmt->close();
            }

            $deleteProducts = $conn->prepare('DELETE FROM crm_lead_products WHERE lead_id = ?');
            $deleteProducts->bind_param('i', $leadId);
            $deleteProducts->execute();
            $deleteProducts->close();

            if ($productIds !== []) {
                $productStmt = $conn->prepare(
                    'INSERT IGNORE INTO crm_lead_products (lead_id, product_id, created_at)
                     SELECT ?, id, NOW() FROM products WHERE id = ? AND status = 1 AND deleted_at IS NULL'
                );
                foreach ($productIds as $productId) {
                    $productStmt->bind_param('ii', $leadId, $productId);
                    if (!$productStmt->execute()) {
                        throw new RuntimeException('Unable to save lead product interests.');
                    }
                }
                $productStmt->close();
            }

            if ($spId === null) {
                assignLeadToSalesperson($conn, $leadId, $currentUserId);
            }
            logLeadActivity(
                $conn,
                $leadId,
                $leadId > 0 && isset($leadNumber) ? 'Lead Created' : 'Lead Updated',
                isset($leadNumber) ? 'Manual lead entry created.' : 'Lead master information modified.',
                $currentUserId
            );
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            crmJson('error', $e->getMessage(), [], 500);
        }

        crmJson('success', 'Lead saved successfully.', ['lead_id' => $leadId]);

    // =========================================================================
    // 9. Update Lead Status
    // =========================================================================
    case 'crm_update_lead_status':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $newStatus = trim($_POST['status'] ?? '');
        $allowed = ['New', 'Contacted', 'Qualified', 'Unqualified', 'Converted', 'Lost'];
        if ($leadId <= 0 || !in_array($newStatus, $allowed, true)) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid status']);
            exit;
        }
        $stmt = $conn->prepare("UPDATE crm_leads SET lead_status = ?, updated_at = NOW() WHERE id = ? AND acceptance_status = 'Accepted' AND deleted_at IS NULL");
        $stmt->bind_param('si', $newStatus, $leadId);
        $ok = $stmt->execute() && $stmt->affected_rows === 1;
        $stmt->close();

        if ($ok) {
            logLeadActivity($conn, $leadId, 'Status Changed', "Status changed to {$newStatus}", $currentUserId);
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database error']);
        }
        exit;

    // =========================================================================
    // 10. Add Lead Comment
    // =========================================================================
    case 'crm_add_lead_comment':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $comment = trim($_POST['comment'] ?? '');
        if ($leadId <= 0 || empty($comment)) {
            echo json_encode(['status' => 'error', 'message' => 'Comment cannot be empty']);
            exit;
        }
        $activeLeadStmt = $conn->prepare("SELECT id FROM crm_leads WHERE id = ? AND acceptance_status = 'Accepted' AND deleted_at IS NULL LIMIT 1");
        $activeLeadStmt->bind_param('i', $leadId);
        $activeLeadStmt->execute();
        $activeLead = $activeLeadStmt->get_result()->fetch_assoc();
        $activeLeadStmt->close();
        if (!$activeLead) {
            crmJson('error', 'Active lead not found.', [], 404);
        }
        $ok = logLeadActivity($conn, $leadId, 'Follow-up Note', $comment, $currentUserId);
        echo json_encode(['status' => $ok ? 'success' : 'error']);
        exit;

    // =========================================================================
    // 11. Delete Lead (Soft Delete)
    // =========================================================================
    case 'crm_delete_lead':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        if ($leadId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
            exit;
        }
        $stmt = $conn->prepare("UPDATE crm_leads SET deleted_at = NOW(), deleted_by = ? WHERE id = ? AND deleted_at IS NULL");
        $stmt->bind_param('ii', $currentUserId, $leadId);
        $ok = $stmt->execute() && $stmt->affected_rows === 1;
        $stmt->close();
        if ($ok) {
            logLeadActivity($conn, $leadId, 'Lead Deleted', 'Lead was removed from the active CRM record section.', $currentUserId);
        }
        echo json_encode(['status' => $ok ? 'success' : 'error', 'message' => $ok ? 'Lead deleted' : 'Lead not found']);
        exit;

    // =========================================================================
    // 12. Load Salespersons List
    // =========================================================================
    case 'crm_load_salespersons':
        $search = trim($_POST['search'] ?? '');
        $status = trim($_POST['status'] ?? 'all');
        $where = ["sp.deleted_at IS NULL"];
        if ($status === 'active') {
            $where[] = "sp.status = 1";
        } elseif ($status === 'inactive') {
            $where[] = "sp.status = 0";
        }
        if ($search !== '') {
            $esc = $conn->real_escape_string($search);
            $where[] = "(sp.salesperson_name LIKE '%{$esc}%' OR sp.salesperson_code LIKE '%{$esc}%' OR sp.email LIKE '%{$esc}%' OR sp.sales_team LIKE '%{$esc}%')";
        }
        $whereSql = implode(' AND ', $where);

        $res = $conn->query("SELECT sp.* FROM salesperson_masters sp WHERE {$whereSql} ORDER BY sp.id DESC");
        $html = '';
        if ($res && $res->num_rows > 0) {
            while ($sp = $res->fetch_assoc()) {
                $spId = (int)$sp['id'];

                // Get territories
                $tHtml = '';
                $tRes = $conn->query("SELECT territory_name, territory_type FROM salesperson_territories WHERE salesperson_id = {$spId}");
                if ($tRes) {
                    while ($t = $tRes->fetch_assoc()) {
                        $territoryType = crmEscape($t['territory_type']);
                        $territoryName = crmEscape($t['territory_name']);
                        $tHtml .= "<span class='inline-block px-2 py-0.5 bg-slate-100 text-slate-700 text-[11px] rounded-md font-medium mr-1 mb-1'>{$territoryType}: {$territoryName}</span>";
                    }
                }
                if (!$tHtml) $tHtml = '<span class="text-slate-400 italic text-xs">No territories mapped</span>';

                // Get product expertise
                $eHtml = '';
                $eRes = $conn->query("SELECT p.product_name FROM salesperson_product_expertise spe JOIN products p ON p.id = spe.product_id WHERE spe.salesperson_id = {$spId} LIMIT 3");
                if ($eRes) {
                    while ($e = $eRes->fetch_assoc()) {
                        $eHtml .= "<span class='inline-block px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[11px] rounded-md font-medium mr-1 mb-1'>" . htmlspecialchars($e['product_name']) . "</span>";
                    }
                }
                if (!$eHtml) $eHtml = '<span class="text-slate-400 italic text-xs">All Products</span>';

                // Get product responsibility
                $rHtml = '';
                $rRes = $conn->query("SELECT p.product_name FROM salesperson_product_responsibility spr JOIN products p ON p.id = spr.product_id WHERE spr.salesperson_id = {$spId} LIMIT 3");
                if ($rRes) {
                    while ($responsibility = $rRes->fetch_assoc()) {
                        $rHtml .= "<span class='inline-block px-2 py-0.5 bg-blue-50 text-blue-700 text-[11px] rounded-md font-medium mr-1 mb-1'>" . crmEscape($responsibility['product_name']) . "</span>";
                    }
                }
                if (!$rHtml) $rHtml = '<span class="text-slate-400 italic text-xs">No responsibility mapped</span>';

                $statusBadge = $sp['status'] == 1 ? '<span class="badge bg-label-success rounded-pill text-[11px]">Active</span>' : '<span class="badge bg-label-secondary rounded-pill text-[11px]">Inactive</span>';
                $salespersonActions = '';
                if (roleHasPermission($currentRoleId, 'crm_salesperson_edit')) {
                    $salespersonActions .= "<button type='button' class='btn btn-icon btn-label-primary btn-sm' title='Edit' onclick='openSalespersonModal(\"edit\", {$spId})'><span class='ti ti-edit'></span></button>";
                }
                if (roleHasPermission($currentRoleId, 'crm_salesperson_delete')) {
                    $salespersonActions .= "<button type='button' class='btn btn-icon btn-label-danger btn-sm' title='Delete' onclick='deleteSalesperson({$spId})'><span class='ti ti-trash'></span></button>";
                }

                $html .= "<tr class='group hover:bg-slate-50/50 transition-colors'>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'>
                        <div class='font-bold text-slate-900 text-[13px]'>" . htmlspecialchars($sp['salesperson_name']) . "</div>
                        <div class='text-xs text-slate-500 font-medium'>" . htmlspecialchars($sp['salesperson_code'] ?? 'SP') . " " . ($sp['sales_team'] ? "• " . htmlspecialchars($sp['sales_team']) : '') . "</div>
                    </td>
                    <td class='px-6 py-3.5 align-middle text-[13px] text-slate-600 whitespace-nowrap'>
                        <div class='font-medium text-slate-800'>" . htmlspecialchars($sp['email'] ?? 'N/A') . "</div>
                        <div class='text-slate-400 text-xs mt-0.5'>" . htmlspecialchars($sp['mobile'] ?? '') . "</div>
                    </td>
                    <td class='px-6 py-3.5 align-middle max-w-xs'>{$tHtml}</td>
                    <td class='px-6 py-3.5 align-middle max-w-xs'>{$eHtml}</td>
                    <td class='px-6 py-3.5 align-middle max-w-xs'>{$rHtml}</td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'>{$statusBadge}</td>
                    <td class='px-6 py-3.5 align-middle text-right whitespace-nowrap'>
                        <div class='flex flex-nowrap items-center justify-end gap-1.5'>{$salespersonActions}</div>
                    </td>
                </tr>";
            }
        }
        $html = $html ?: "<tr><td colspan='7' class='px-6 py-12 text-center text-slate-400'><i class='ti ti-mood-empty text-3xl mb-2 block text-slate-300'></i><p class='text-sm font-medium'>No salespersons registered yet.</p></td></tr>";
        echo json_encode(['status' => 'success', 'html' => $html]);
        exit;

    // =========================================================================
    // 13. Get Salesperson Detail for Edit
    // =========================================================================
    case 'crm_get_salesperson_detail':
        $spId = (int) ($_POST['salesperson_id'] ?? 0);
        $res = $conn->query("SELECT * FROM salesperson_masters WHERE id = {$spId} AND deleted_at IS NULL LIMIT 1");
        if (!$res || $res->num_rows === 0) {
            echo json_encode(['status' => 'error', 'message' => 'Salesperson not found']);
            exit;
        }
        $sp = $res->fetch_assoc();

        // Territories
        $territories = [];
        $tRes = $conn->query("SELECT territory_name AS name, territory_type AS type FROM salesperson_territories WHERE salesperson_id = {$spId}");
        if ($tRes) {
            while ($t = $tRes->fetch_assoc()) {
                $territories[] = $t;
            }
        }

        // Product expertise
        $productIds = [];
        $eRes = $conn->query("SELECT product_id FROM salesperson_product_expertise WHERE salesperson_id = {$spId}");
        if ($eRes) {
            while ($e = $eRes->fetch_assoc()) {
                $productIds[] = (int)$e['product_id'];
            }
        }

        // Product responsibility
        $responsibilityProductIds = [];
        $rRes = $conn->query("SELECT product_id FROM salesperson_product_responsibility WHERE salesperson_id = {$spId}");
        if ($rRes) {
            while ($responsibility = $rRes->fetch_assoc()) {
                $responsibilityProductIds[] = (int)$responsibility['product_id'];
            }
        }

        echo json_encode([
            'status' => 'success',
            'salesperson' => $sp,
            'territories' => $territories,
            'product_ids' => $productIds,
            'responsibility_product_ids' => $responsibilityProductIds
        ]);
        exit;

    // =========================================================================
    // 14. Save Salesperson (Add / Edit)
    // =========================================================================
    case 'crm_save_salesperson':
        $spId = (int) ($_POST['salesperson_id'] ?? 0);
        $name = trim($_POST['salesperson_name'] ?? '');
        $code = trim($_POST['salesperson_code'] ?? '');
        $userId = !empty($_POST['user_id']) ? (int)$_POST['user_id'] : null;
        $employeeId = !empty($_POST['employee_id']) ? (int)$_POST['employee_id'] : null;
        $email = trim($_POST['email'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $salesTeam = trim($_POST['sales_team'] ?? '');
        $status = (int) ($_POST['status'] ?? 1);
        $assignmentPriority = max(1, (int)($_POST['assignment_priority'] ?? 100));

        if ($name === '' || !in_array($status, [0, 1], true)) {
            crmJson('error', 'Salesperson name and a valid status are required.', [], 422);
        }
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            crmJson('error', 'Enter a valid salesperson email address.', [], 422);
        }

        $territoriesJson = $_POST['territories_json'] ?? '[]';
        $territoriesArr = json_decode($territoriesJson, true);
        if (!is_array($territoriesArr)) {
            crmJson('error', 'Territory mappings are invalid.', [], 422);
        }
        $productExpertise = $_POST['product_expertise'] ?? [];
        $productExpertise = array_values(array_unique(array_filter(
            array_map('intval', is_array($productExpertise) ? $productExpertise : []),
            static fn(int $id): bool => $id > 0
        )));
        $productResponsibility = $_POST['product_responsibility'] ?? [];
        $productResponsibility = array_values(array_unique(array_filter(
            array_map('intval', is_array($productResponsibility) ? $productResponsibility : []),
            static fn(int $id): bool => $id > 0
        )));

        $conn->begin_transaction();
        try {
            if ($spId > 0) {
                $stmt = $conn->prepare(
                    'UPDATE salesperson_masters
                     SET salesperson_name = ?, salesperson_code = ?, user_id = ?, employee_id = ?, email = ?,
                         mobile = ?, sales_team = ?, assignment_priority = ?, status = ?, updated_by = ?, updated_at = NOW()
                     WHERE id = ? AND deleted_at IS NULL'
                );
                $stmt->bind_param('ssiisssiiii', $name, $code, $userId, $employeeId, $email, $mobile, $salesTeam, $assignmentPriority, $status, $currentUserId, $spId);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to update the salesperson.');
                }
                $stmt->close();
            } else {
                $stmt = $conn->prepare(
                    'INSERT INTO salesperson_masters
                     (salesperson_name, salesperson_code, user_id, employee_id, email, mobile, sales_team,
                      assignment_priority, status, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
                );
                $stmt->bind_param('ssiisssiii', $name, $code, $userId, $employeeId, $email, $mobile, $salesTeam, $assignmentPriority, $status, $currentUserId);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to create the salesperson.');
                }
                $spId = (int)$stmt->insert_id;
                $stmt->close();
            }

            $deleteTerritories = $conn->prepare('DELETE FROM salesperson_territories WHERE salesperson_id = ?');
            $deleteTerritories->bind_param('i', $spId);
            $deleteTerritories->execute();
            $deleteTerritories->close();
            $territoryStmt = $conn->prepare(
                'INSERT IGNORE INTO salesperson_territories (salesperson_id, territory_name, territory_type) VALUES (?, ?, ?)'
            );
            foreach ($territoriesArr as $territory) {
                $territoryName = trim((string)($territory['name'] ?? ''));
                $territoryType = ucfirst(strtolower(trim((string)($territory['type'] ?? 'City'))));
                if ($territoryName === '' || !in_array($territoryType, ['Territory', 'City', 'State', 'Region'], true)) {
                    continue;
                }
                $territoryStmt->bind_param('iss', $spId, $territoryName, $territoryType);
                if (!$territoryStmt->execute()) {
                    throw new RuntimeException('Unable to save salesperson territories.');
                }
            }
            $territoryStmt->close();

            $deleteExpertise = $conn->prepare('DELETE FROM salesperson_product_expertise WHERE salesperson_id = ?');
            $deleteExpertise->bind_param('i', $spId);
            $deleteExpertise->execute();
            $deleteExpertise->close();
            if ($productExpertise !== []) {
                $expertiseStmt = $conn->prepare(
                    'INSERT IGNORE INTO salesperson_product_expertise (salesperson_id, category_name, product_id)
                     SELECT ?, pc.name, p.id FROM products p
                     LEFT JOIN product_categories pc ON pc.id = p.category_id
                     WHERE p.id = ? AND p.status = 1 AND p.deleted_at IS NULL'
                );
                foreach ($productExpertise as $productId) {
                    $expertiseStmt->bind_param('ii', $spId, $productId);
                    if (!$expertiseStmt->execute()) {
                        throw new RuntimeException('Unable to save product expertise.');
                    }
                }
                $expertiseStmt->close();
            }

            $deleteResponsibility = $conn->prepare('DELETE FROM salesperson_product_responsibility WHERE salesperson_id = ?');
            $deleteResponsibility->bind_param('i', $spId);
            $deleteResponsibility->execute();
            $deleteResponsibility->close();
            if ($productResponsibility !== []) {
                $responsibilityStmt = $conn->prepare(
                    'INSERT IGNORE INTO salesperson_product_responsibility (salesperson_id, category_name, product_id)
                     SELECT ?, pc.name, p.id FROM products p
                     LEFT JOIN product_categories pc ON pc.id = p.category_id
                     WHERE p.id = ? AND p.status = 1 AND p.deleted_at IS NULL'
                );
                foreach ($productResponsibility as $productId) {
                    $responsibilityStmt->bind_param('ii', $spId, $productId);
                    if (!$responsibilityStmt->execute()) {
                        throw new RuntimeException('Unable to save product responsibility.');
                    }
                }
                $responsibilityStmt->close();
            }

            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            crmJson('error', $e->getMessage(), [], 500);
        }

        crmJson('success', 'Salesperson saved successfully.');

    // =========================================================================
    // 15. Delete Salesperson
    // =========================================================================
    case 'crm_delete_salesperson':
        $spId = (int) ($_POST['salesperson_id'] ?? 0);
        if ($spId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
            exit;
        }
        $stmt = $conn->prepare('UPDATE salesperson_masters SET deleted_at = NOW(), updated_by = ? WHERE id = ? AND deleted_at IS NULL');
        $stmt->bind_param('ii', $currentUserId, $spId);
        $ok = $stmt->execute();
        $stmt->close();
        crmJson($ok ? 'success' : 'error', $ok ? 'Salesperson deleted.' : 'Unable to delete salesperson.', [], $ok ? 200 : 500);

    // =========================================================================
    // 16. Load CRM Quotes
    // =========================================================================
    case 'crm_load_quotes':
        $status = trim($_POST['status'] ?? 'all');
        $search = trim($_POST['search'] ?? '');
        $page = max(1, (int) ($_POST['page'] ?? 1));
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $where = ["qr.source_origin = 'crm'", "qr.deleted_at IS NULL"];
        if ($status !== 'all' && $status !== '') {
            $escStatus = $conn->real_escape_string($status);
            $where[] = "qr.status = '{$escStatus}'";
        }
        if ($search !== '') {
            $escSearch = $conn->real_escape_string($search);
            $where[] = "(qr.quotation_number LIKE '%{$escSearch}%' OR qr.target_company_name LIKE '%{$escSearch}%' OR qr.target_name LIKE '%{$escSearch}%' OR qr.target_email LIKE '%{$escSearch}%')";
        }

        $whereSql = implode(' AND ', $where);

        $countRes = $conn->query("SELECT COUNT(*) AS total FROM quotation_requests qr WHERE {$whereSql}");
        $totalCount = $countRes ? (int)($countRes->fetch_assoc()['total'] ?? 0) : 0;

        $sql = "SELECT qr.*, cl.lead_number, cl.company_name AS lead_company 
                FROM quotation_requests qr 
                LEFT JOIN crm_leads cl ON cl.id = qr.lead_id 
                WHERE {$whereSql} 
                ORDER BY qr.id DESC 
                LIMIT {$limit} OFFSET {$offset}";
        $res = $conn->query($sql);

        $html = '';
        if ($res && $res->num_rows > 0) {
            while ($q = $res->fetch_assoc()) {
                $qId = (int)$q['id'];
                $statusBadge = Constant::CRM_QUOTE['STATUS'][$q['status']]['badge'] ?? 'bg-label-secondary';
                $statusLabel = Constant::CRM_QUOTE['STATUS'][$q['status']]['label'] ?? ucfirst($q['status']);
                $dateStr = date('d M Y', strtotime($q['created_at']));
                $linkedLead = $q['lead_number'] ? "<span class='font-mono font-bold text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 whitespace-nowrap inline-block'>" . crmEscape($q['lead_number']) . "</span>" : '<span class="text-slate-400 italic text-xs">None</span>';
                $quoteActions = '';
                if (roleHasPermission($currentRoleId, 'crm_quote_edit')) {
                    $quoteActions .= "<button type='button' class='btn btn-icon btn-label-primary btn-sm' title='Edit' onclick='editCrmQuote({$qId})'><span class='ti ti-edit'></span></button>";
                }
                if (roleHasPermission($currentRoleId, 'crm_quote_delete')) {
                    $quoteActions .= "<button type='button' class='btn btn-icon btn-label-danger btn-sm' title='Delete' onclick='deleteCrmQuote({$qId})'><span class='ti ti-trash'></span></button>";
                }

                $html .= "<tr class='group hover:bg-slate-50/50 transition-colors'>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap min-w-[140px]'>
                        <span class='font-mono font-bold text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100 whitespace-nowrap inline-block'>" . crmEscape($q['quotation_number']) . "</span>
                    </td>
                    <td class='px-6 py-3.5 align-middle'>
                        <div class='font-bold text-slate-900 text-[13px]'>" . htmlspecialchars($q['target_company_name'] ?: ($q['target_name'] ?: 'N/A')) . "</div>
                        <div class='text-xs text-slate-500 font-medium'>" . crmEscape($q['target_name'] ?? '') . " " . ($q['target_phone'] ? '(' . crmEscape($q['target_phone']) . ')' : '') . "</div>
                    </td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'>{$linkedLead}</td>
                    <td class='px-6 py-3.5 align-middle text-[13px] text-slate-600 whitespace-nowrap'>{$dateStr}</td>
                    <td class='px-6 py-3.5 align-middle font-bold text-slate-900 whitespace-nowrap'>₹" . number_format((float)$q['total_amount'], 2) . "</td>
                    <td class='px-6 py-3.5 align-middle whitespace-nowrap'><span class='badge {$statusBadge} rounded-pill text-[11px]'>{$statusLabel}</span></td>
                    <td class='px-6 py-3.5 align-middle text-right whitespace-nowrap'>
                        <div class='flex flex-nowrap items-center justify-end gap-1.5'>{$quoteActions}</div>
                    </td>
                </tr>";
            }
        }

        $totalPages = ceil($totalCount / $limit);
        $paginationHtml = "<div>Showing <strong>" . min($offset + 1, $totalCount) . "</strong> to <strong>" . min($offset + $limit, $totalCount) . "</strong> of <strong>{$totalCount}</strong> quotes</div>";
        if ($totalPages > 1) {
            $paginationHtml .= "<div class='flex items-center gap-1'>";
            for ($i = 1; $i <= $totalPages; $i++) {
                $activeCls = ($i === $page) ? 'bg-primary-600 text-white font-bold' : 'bg-slate-100 hover:bg-slate-200 text-slate-700';
                $paginationHtml .= "<button type='button' class='px-3 py-1 rounded-lg text-xs transition {$activeCls}' onclick='loadQuotesList({$i})'>{$i}</button>";
            }
            $paginationHtml .= "</div>";
        }
        $html = $html ?: "<tr><td colspan='7' class='py-12 text-center text-slate-400'><i class='ti ti-mood-empty text-3xl mb-2 block text-slate-300'></i><p class='text-sm font-medium'>No CRM quotations found.</p></td></tr>";
        echo json_encode(['status' => 'success', 'html' => $html, 'pagination' => $paginationHtml]);
        exit;

    // =========================================================================
    // 17. Load Accepted Leads for Quote Selection (Section 4.1)
    // =========================================================================
    case 'crm_load_leads_for_quote':
        $search = trim($_POST['search'] ?? '');
        $page = max(1, (int)($_POST['page'] ?? 1));
        $limit = 10;
        $offset = ($page - 1) * $limit;
        $where = ["acceptance_status = 'Accepted'", "deleted_at IS NULL"];
        if ($search !== '') {
            $esc = $conn->real_escape_string($search);
            $where[] = "(lead_number LIKE '%{$esc}%' OR company_name LIKE '%{$esc}%' OR contact_person LIKE '%{$esc}%' OR territory LIKE '%{$esc}%' OR city LIKE '%{$esc}%')";
        }
        $whereSql = implode(' AND ', $where);

        $countResult = $conn->query("SELECT COUNT(*) AS total FROM crm_leads WHERE {$whereSql}");
        $totalCount = $countResult ? (int)($countResult->fetch_assoc()['total'] ?? 0) : 0;
        $totalPages = max(1, (int)ceil($totalCount / $limit));
        if ($page > $totalPages) {
            $page = $totalPages;
            $offset = ($page - 1) * $limit;
        }
        $res = $conn->query("SELECT id, lead_number, company_name, contact_person, source_type, captured_at FROM crm_leads WHERE {$whereSql} ORDER BY captured_at DESC, id DESC LIMIT {$limit} OFFSET {$offset}");
        $html = '';
        $sr = $offset + 1;
        if ($res && $res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                $source = Constant::CRM_LEAD['SOURCES'][$row['source_type']] ?? ['label' => ucfirst($row['source_type']), 'badge' => 'bg-label-secondary'];
                $sourceLabel = crmEscape($source['label']);
                $sourceBadge = crmEscape($source['badge']);
                $capturedAt = crmEscape(date('d M Y, h:i A', strtotime($row['captured_at'])));
                $leadNumber = crmEscape($row['lead_number']);
                $leadName = crmEscape($row['contact_person'] ?: $row['company_name']);
                $companyName = crmEscape($row['company_name'] ?: 'N/A');

                $html .= "<tr class='hover:bg-slate-50 transition'>
                    <td class='px-5 py-3 font-semibold text-slate-500'>{$sr}</td>
                    <td class='px-5 py-3'><span class='badge {$sourceBadge} rounded-pill text-[10px]'>{$sourceLabel}</span></td>
                    <td class='px-5 py-3 text-xs text-slate-600 whitespace-nowrap'>{$capturedAt}</td>
                    <td class='px-5 py-3 font-mono font-bold text-primary-600'>{$leadNumber}</td>
                    <td class='px-5 py-3 font-semibold text-slate-800'>{$leadName}</td>
                    <td class='px-5 py-3 font-bold text-slate-900'>{$companyName}</td>
                    <td class='px-5 py-3 text-center'>
                        <button type='button' class='px-3 py-1 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-bold text-xs shadow-sm transition' onclick='selectLeadForQuote({$row['id']})'>
                            Select
                        </button>
                    </td>
                </tr>";
                $sr++;
            }
        }
        echo json_encode([
            'status' => 'success',
            'html' => $html,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_count' => $totalCount,
            'from' => $totalCount > 0 ? $offset + 1 : 0,
            'to' => min($offset + $limit, $totalCount),
        ]);
        exit;

    // =========================================================================
    // 18. Get Lead Data for Quote Prefill
    // =========================================================================
    case 'crm_get_lead_for_quote_prefill':
        $leadId = (int) ($_POST['lead_id'] ?? 0);
        $stmt = $conn->prepare("SELECT * FROM crm_leads WHERE id = ? AND acceptance_status = 'Accepted' AND deleted_at IS NULL LIMIT 1");
        $stmt->bind_param('i', $leadId);
        $stmt->execute();
        $lead = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$lead) {
            echo json_encode(['status' => 'error', 'message' => 'Lead not found']);
            exit;
        }

        $products = [];
        $pRes = $conn->query("SELECT p.id, p.product_name, p.product_code, p.marg_code, p.gst_rate FROM crm_lead_products lp JOIN products p ON p.id = lp.product_id WHERE lp.lead_id = {$leadId}");
        if ($pRes) {
            while ($p = $pRes->fetch_assoc()) {
                $p['sku'] = !empty($p['product_code']) ? $p['product_code'] : (!empty($p['marg_code']) ? $p['marg_code'] : 'PRD-' . str_pad($p['id'], 4, '0', STR_PAD_LEFT));
                $p['gst_rate'] = (!empty($p['gst_rate']) && (float)$p['gst_rate'] > 0) ? (float)$p['gst_rate'] : 18.00;
                
                $rRes = $conn->query("SELECT unit_price FROM quotation_request_items WHERE product_id = {$p['id']} AND unit_price > 0 ORDER BY id DESC LIMIT 1");
                if ($rRes && $rRow = $rRes->fetch_assoc()) {
                    $p['default_rate'] = (float)$rRow['unit_price'];
                } else {
                    $p['default_rate'] = 100.00;
                }
                $products[] = $p;
            }
        }

        echo json_encode(['status' => 'success', 'lead' => $lead, 'products' => $products]);
        exit;

    // =========================================================================
    // 18B. Load CRM Quotes for PI Selection
    // =========================================================================
    case 'crm_load_quotes_for_pi':
        $search = trim((string)($_POST['search'] ?? ''));
        $page = max(1, (int)($_POST['page'] ?? 1));
        $limit = 10;
        $offset = ($page - 1) * $limit;
        $where = ["source_origin = 'crm'", 'deleted_at IS NULL'];
        if ($search !== '') {
            $escaped = $conn->real_escape_string($search);
            $where[] = "(quotation_number LIKE '%{$escaped}%' OR target_name LIKE '%{$escaped}%' OR target_company_name LIKE '%{$escaped}%')";
        }
        $whereSql = implode(' AND ', $where);
        $countResult = $conn->query('SELECT COUNT(*) AS total FROM quotation_requests WHERE ' . $whereSql);
        $totalCount = $countResult ? (int)($countResult->fetch_assoc()['total'] ?? 0) : 0;
        $totalPages = max(1, (int)ceil($totalCount / $limit));
        if ($page > $totalPages) {
            $page = $totalPages;
            $offset = ($page - 1) * $limit;
        }
        $quoteResult = $conn->query(
            'SELECT id, quotation_number, target_name, target_company_name, created_at
             FROM quotation_requests WHERE ' . $whereSql . '
             ORDER BY created_at DESC, id DESC LIMIT ' . $limit . ' OFFSET ' . $offset
        );
        $html = '';
        $serial = $offset + 1;
        if ($quoteResult) {
            while ($quote = $quoteResult->fetch_assoc()) {
                $quoteId = (int)$quote['id'];
                $quoteNumber = crmEscape($quote['quotation_number']);
                $quoteName = crmEscape($quote['target_name'] ?: $quote['target_company_name']);
                $companyName = crmEscape($quote['target_company_name'] ?: 'N/A');
                $timestamp = crmEscape(date('d M Y, h:i A', strtotime($quote['created_at'])));
                $html .= "<tr class='hover:bg-slate-50 transition'>
                    <td class='px-5 py-3 font-semibold text-slate-500'>{$serial}</td>
                    <td class='px-5 py-3'><span class='badge bg-label-primary rounded-pill text-[10px]'>CRM</span></td>
                    <td class='px-5 py-3 text-xs text-slate-600 whitespace-nowrap'>{$timestamp}</td>
                    <td class='px-5 py-3 font-mono font-bold text-primary-600'>{$quoteNumber}</td>
                    <td class='px-5 py-3 font-semibold text-slate-800'>{$quoteName}</td>
                    <td class='px-5 py-3 font-bold text-slate-900'>{$companyName}</td>
                    <td class='px-5 py-3 text-center'>
                        <button type='button' class='px-3 py-1 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-bold text-xs shadow-sm transition' onclick='selectQuoteForPi({$quoteId})'>Select</button>
                    </td>
                </tr>";
                $serial++;
            }
        }
        crmJson('success', '', [
            'html' => $html,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_count' => $totalCount,
            'from' => $totalCount > 0 ? $offset + 1 : 0,
            'to' => min($offset + $limit, $totalCount),
        ]);

    // =========================================================================
    // 19. Save CRM Quote (into quotation_requests & quotation_request_items)
    // =========================================================================
    case 'crm_save_quote':
        try {
            $quote = crmSaveQuote($conn, $_POST, $currentUserId);
            crmJson('success', 'Quotation saved successfully.', $quote);
        } catch (InvalidArgumentException $e) {
            crmJson('error', $e->getMessage(), [], 422);
        } catch (Throwable $e) {
            error_log('CRM quote save failed: ' . $e->getMessage());
            crmJson('error', $e->getMessage(), [], 500);
        }

    // =========================================================================
    // 20. Get Quote Detail
    // =========================================================================
    case 'crm_get_quote_detail':
        $quoteId = (int) ($_POST['quote_id'] ?? 0);
        $stmt = $conn->prepare("SELECT * FROM quotation_requests WHERE id = ? AND source_origin = 'crm' AND deleted_at IS NULL LIMIT 1");
        $stmt->bind_param('i', $quoteId);
        $stmt->execute();
        $q = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$q) {
            echo json_encode(['status' => 'error', 'message' => 'Quote not found']);
            exit;
        }

        $items = [];
        $iRes = $conn->query("SELECT * FROM quotation_request_items WHERE quotation_request_id = {$quoteId}");
        if ($iRes) {
            while ($it = $iRes->fetch_assoc()) {
                $items[] = $it;
            }
        }

        echo json_encode(['status' => 'success', 'quote' => $q, 'items' => $items]);
        exit;

    // =========================================================================
    // 21. Delete Quote
    // =========================================================================
    case 'crm_delete_quote':
        $quoteId = (int) ($_POST['quote_id'] ?? 0);
        if ($quoteId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
            exit;
        }
        $stmt = $conn->prepare(
            "UPDATE quotation_requests SET deleted_at = NOW(), deleted_by = ?, updated_at = NOW()
             WHERE id = ? AND source_origin = 'crm' AND deleted_at IS NULL"
        );
        $stmt->bind_param('ii', $currentUserId, $quoteId);
        $ok = $stmt->execute() && $stmt->affected_rows === 1;
        $stmt->close();
        crmJson($ok ? 'success' : 'error', $ok ? 'Quotation deleted.' : 'Quotation was not found.', [], $ok ? 200 : 404);

    // =========================================================================
    // 22. Convert Confirmed PI to Order (Phase 6 per Section 6)
    // =========================================================================
    case 'crm_convert_pi_to_order':
        $piId = (int) ($_POST['pi_id'] ?? 0);
        if ($piId <= 0) {
            crmJson('error', 'Invalid PI ID.', [], 422);
        }

        try {
            $order = crmCreateOrderFromPi($conn, $piId, $currentUserId);
            crmJson('success', 'Order #' . $order['order_number'] . ' created successfully from the PI.', $order);
        } catch (InvalidArgumentException $e) {
            crmJson('error', $e->getMessage(), [], 422);
        } catch (RuntimeException $e) {
            crmJson('error', $e->getMessage(), [], 409);
        } catch (Throwable $e) {
            error_log('CRM PI conversion failed: ' . $e->getMessage());
            crmJson('error', 'Unable to convert the PI to an Order.', [], 500);
        }
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Unknown CRM action']);
        exit;
}
