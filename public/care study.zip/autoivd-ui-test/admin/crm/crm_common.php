<?php

declare(strict_types=1);

function crmJson(string $status, string $message = '', array $data = [], int $httpStatus = 200): never
{
    http_response_code($httpStatus);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(
        array_merge(['status' => $status, 'message' => $message], $data),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function crmEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function crmTableExists(mysqli $conn, string $table): bool
{
    static $cache = [];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }
    $escaped = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$escaped}'");
    $cache[$table] = $result !== false && $result->num_rows > 0;
    return $cache[$table];
}

function crmColumnExists(mysqli $conn, string $table, string $column): bool
{
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
        return false;
    }
    $tableEscaped = $conn->real_escape_string($table);
    $columnEscaped = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM `{$tableEscaped}` LIKE '{$columnEscaped}'");
    $cache[$key] = $result !== false && $result->num_rows > 0;
    return $cache[$key];
}

function crmSchemaReady(mysqli $conn): bool
{
    foreach ([
        'crm_leads',
        'crm_lead_products',
        'crm_lead_activity_log',
        'crm_lead_number_sequences',
        'crm_quote_number_sequences',
        'salesperson_masters',
        'salesperson_territories',
        'salesperson_product_expertise',
        'salesperson_product_responsibility',
    ] as $table) {
        if (!crmTableExists($conn, $table)) {
            return false;
        }
    }

    foreach ([
        ['quotation_requests', 'lead_id'],
        ['quotation_requests', 'source_origin'],
        ['proforma_invoices', 'lead_id'],
        ['proforma_invoices', 'quote_request_id'],
        ['proforma_invoices', 'converted_order_id'],
        ['order_received', 'lead_id'],
        ['order_received', 'quotation_request_id'],
        ['crm_leads', 'territory'],
    ] as [$table, $column]) {
        if (!crmColumnExists($conn, $table, $column)) {
            return false;
        }
    }

    return true;
}

function crmActionPermissions(string $action): array
{
    return match ($action) {
        'crm_get_new_leads_count', 'crm_get_lead_stats', 'crm_load_incoming_leads',
        'crm_load_leads_grid', 'crm_get_lead_detail', 'crm_get_lead_for_edit',
        'crm_get_lead_for_accept_modal', 'crm_get_sales_performance' => ['crm_lead_management_menu_list'],
        'crm_confirm_accept_lead' => ['crm_lead_accept'],
        'crm_reject_lead' => ['crm_lead_reject'],
        'crm_update_lead_status', 'crm_add_lead_comment' => ['crm_lead_edit'],
        'crm_delete_lead' => ['crm_lead_delete'],
        'crm_load_salespersons', 'crm_get_salesperson_detail' => ['crm_salesperson_master_menu_list'],
        'crm_delete_salesperson' => ['crm_salesperson_delete'],
        'crm_load_quotes' => ['crm_quote_menu_list', 'sales_billing_pi_generate_view'],
        'crm_load_leads_for_quote', 'crm_get_lead_for_quote_prefill' => [
            'crm_quote_menu_list', 'crm_lead_management_menu_list', 'sales_billing_pi_generate_view',
        ],
        'crm_load_quotes_for_pi', 'crm_get_quote_detail' => ['crm_quote_menu_list', 'sales_billing_pi_generate_view'],
        'crm_delete_quote' => ['crm_quote_delete'],
        'crm_convert_pi_to_order' => ['crm_pi_convert_to_order', 'sales_billing_pi_generate_edit'],
        default => [],
    };
}

function crmRequireAjaxAccess(mysqli $conn, string $action): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'POST') !== 'POST') {
        crmJson('error', 'Method not allowed.', [], 405);
    }
    if (empty($_SESSION['user_id']) || empty($_SESSION['role_id'])) {
        crmJson('error', 'Authentication required.', [], 401);
    }

    $sessionToken = (string) ($_SESSION['csrf_token'] ?? '');
    $requestToken = (string) ($_POST['csrf_token'] ?? '');
    if ($sessionToken === '' || $requestToken === '' || !hash_equals($sessionToken, $requestToken)) {
        crmJson('error', 'The request security token is invalid or expired. Refresh the page and try again.', [], 419);
    }

    if (!crmSchemaReady($conn)) {
        crmJson(
            'error',
            'The Sales & CRM database migration has not been applied.',
            ['migration' => 'admin/migrations/2026_08_16_001_crm_sales_module_pending.sql'],
            503
        );
    }

    if ($action === 'crm_save_lead') {
        $permissions = [!empty($_POST['lead_id']) ? 'crm_lead_edit' : 'crm_lead_add'];
    } elseif ($action === 'crm_save_salesperson') {
        $permissions = [!empty($_POST['salesperson_id']) ? 'crm_salesperson_edit' : 'crm_salesperson_add'];
    } elseif ($action === 'crm_save_quote') {
        $permissions = [!empty($_POST['quote_id']) ? 'crm_quote_edit' : 'crm_quote_add'];
    } else {
        $permissions = crmActionPermissions($action);
    }

    if ($permissions === []) {
        crmJson('error', 'Unknown CRM action.', [], 404);
    }

    $roleId = (int) $_SESSION['role_id'];
    foreach ($permissions as $permission) {
        if (roleHasPermission($roleId, $permission)) {
            return;
        }
    }

    crmJson('error', 'You do not have permission to perform this Sales & CRM action.', [], 403);
}

function crmBindAndExecute(mysqli_stmt $stmt, string $types, array $values): bool
{
    $references = [];
    foreach ($values as $index => $value) {
        $values[$index] = $value;
        $references[$index] = &$values[$index];
    }
    $stmt->bind_param($types, ...$references);
    return $stmt->execute();
}

function crmGenerateQuoteNumber(mysqli $conn): string
{
    $sequenceDate = date('Y-m-d');
    $stmt = $conn->prepare(
        "INSERT INTO crm_quote_number_sequences (sequence_date, last_sequence)
         VALUES (?, LAST_INSERT_ID(1))
         ON DUPLICATE KEY UPDATE last_sequence = LAST_INSERT_ID(last_sequence + 1)"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the CRM quote sequence.');
    }
    $stmt->bind_param('s', $sequenceDate);
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Unable to generate a quote number: ' . $error);
    }
    $sequence = (int) $conn->insert_id;
    $stmt->close();
    if ($sequence <= 0) {
        $query = $conn->prepare('SELECT last_sequence FROM crm_quote_number_sequences WHERE sequence_date = ?');
        $query->bind_param('s', $sequenceDate);
        $query->execute();
        $sequence = (int) ($query->get_result()->fetch_assoc()['last_sequence'] ?? 1);
        $query->close();
    }
    return 'BIPL-QT-' . date('Ymd') . '-' . str_pad((string) $sequence, 4, '0', STR_PAD_LEFT);
}

/**
 * Canonical, bearer-token-protected intake boundary for website forms whose
 * external schemas are owned outside this repository.
 */
function crmCaptureCanonicalWebsiteLead(mysqli $conn, array $payload): array
{
    if (!crmSchemaReady($conn)) {
        throw new RuntimeException('The Sales & CRM database migration has not been applied.');
    }

    $allowedSources = ['generate_code', 'request_api', 'become_partner'];
    $source = strtolower(trim((string) ($payload['source'] ?? '')));
    if (!in_array($source, $allowedSources, true)) {
        throw new InvalidArgumentException('Invalid website lead source.');
    }
    $externalId = trim((string) ($payload['external_id'] ?? ''));
    if ($externalId === '' || strlen($externalId) > 191) {
        throw new InvalidArgumentException('A valid external_id is required.');
    }

    $company = trim((string) ($payload['company_name'] ?? ''));
    $contact = trim((string) ($payload['contact_person'] ?? ''));
    $mobile = trim((string) ($payload['mobile_number'] ?? ''));
    $email = trim((string) ($payload['email'] ?? ''));
    if ($company === '' && $contact === '' && $mobile === '' && $email === '') {
        throw new InvalidArgumentException('Provide at least one lead identity or contact field.');
    }
    if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        throw new InvalidArgumentException('The email address is invalid.');
    }

    $customerTypes = Constant::CRM_LEAD['CUSTOMER_TYPES'];
    $customerType = trim((string) ($payload['customer_type'] ?? 'Other'));
    if (!in_array($customerType, $customerTypes, true)) {
        $customerType = 'Other';
    }
    $priority = ucfirst(strtolower(trim((string) ($payload['priority'] ?? 'Medium'))));
    if (!in_array($priority, ['Low', 'Medium', 'High'], true)) {
        $priority = 'Medium';
    }

    $capturedAt = trim((string) ($payload['captured_at'] ?? ''));
    if ($capturedAt === '' || strtotime($capturedAt) === false) {
        $capturedAt = date('Y-m-d H:i:s');
    } else {
        $capturedAt = date('Y-m-d H:i:s', strtotime($capturedAt));
    }
    $sourceTable = 'website_' . $source;
    $rawPayload = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $existing = $conn->prepare(
        'SELECT id, lead_number FROM crm_leads WHERE source_reference_table = ? AND source_reference_id = ? LIMIT 1'
    );
    $existing->bind_param('ss', $sourceTable, $externalId);
    $existing->execute();
    $existingLead = $existing->get_result()->fetch_assoc();
    $existing->close();
    if ($existingLead) {
        return [
            'created' => false,
            'lead_id' => (int) $existingLead['id'],
            'lead_number' => (string) $existingLead['lead_number'],
        ];
    }

    $leadNumber = generateLeadNumber($conn);
    $city = trim((string) ($payload['city'] ?? ''));
    $state = trim((string) ($payload['state'] ?? ''));
    $territory = trim((string) ($payload['territory'] ?? ''));
    $region = trim((string) ($payload['region'] ?? ''));
    $notes = trim((string) ($payload['notes'] ?? ''));

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare(
            "INSERT INTO crm_leads
                (lead_number, company_name, contact_person, mobile_number, email, customer_type,
                 source_type, source_reference_id, source_reference_table, territory, region, city, state,
                 lead_status, acceptance_status, priority, notes, source_payload, captured_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'New', 'Pending', ?, ?, ?, ?)"
        );
        if (!$stmt) {
            throw new RuntimeException('Unable to prepare the website lead intake.');
        }
        $stmt->bind_param(
            'sssssssssssssssss',
            $leadNumber,
            $company,
            $contact,
            $mobile,
            $email,
            $customerType,
            $source,
            $externalId,
            $sourceTable,
            $territory,
            $region,
            $city,
            $state,
            $priority,
            $notes,
            $rawPayload,
            $capturedAt
        );
        if (!$stmt->execute()) {
            throw new RuntimeException('Unable to save the website lead: ' . $stmt->error);
        }
        $leadId = (int) $stmt->insert_id;
        $stmt->close();

        $productIds = array_values(array_unique(array_filter(
            array_map('intval', is_array($payload['product_ids'] ?? null) ? $payload['product_ids'] : []),
            static fn(int $id): bool => $id > 0
        )));
        if ($productIds !== []) {
            $productCheck = $conn->prepare('SELECT id FROM products WHERE id = ? AND status = 1 AND deleted_at IS NULL');
            $productInsert = $conn->prepare(
                'INSERT IGNORE INTO crm_lead_products (lead_id, product_id, created_at) VALUES (?, ?, NOW())'
            );
            foreach ($productIds as $productId) {
                $productCheck->bind_param('i', $productId);
                $productCheck->execute();
                if (!$productCheck->get_result()->fetch_assoc()) {
                    continue;
                }
                $productInsert->bind_param('ii', $leadId, $productId);
                $productInsert->execute();
            }
            $productCheck->close();
            $productInsert->close();
        }

        logLeadActivity($conn, $leadId, 'Lead Captured', 'Captured from ' . $sourceTable . '.');
        $conn->commit();
        return ['created' => true, 'lead_id' => $leadId, 'lead_number' => $leadNumber];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function crmSaveQuote(mysqli $conn, array $payload, int $userId): array
{
    $quoteId = (int)($payload['quote_id'] ?? 0);
    $leadId = !empty($payload['lead_id']) ? (int)$payload['lead_id'] : null;
    $targetCompany = trim((string)($payload['target_company_name'] ?? ''));
    $targetName = trim((string)($payload['target_name'] ?? ''));
    $targetEmail = trim((string)($payload['target_email'] ?? ''));
    $targetPhone = trim((string)($payload['target_phone'] ?? ''));
    $gstin = strtoupper(trim((string)($payload['customer_gstin'] ?? '')));
    $billing = trim((string)($payload['billing_address'] ?? ''));
    $shipping = trim((string)($payload['shipping_address'] ?? ''));
    $status = strtolower(trim((string)($payload['status'] ?? 'generated')));
    $notes = trim((string)($payload['notes'] ?? ''));
    $discountAmount = round(max(0, (float)($payload['discount_amount'] ?? 0)), 2);
    $items = is_array($payload['items'] ?? null) ? $payload['items'] : [];

    if ($targetCompany === '' && $targetName === '') {
        throw new InvalidArgumentException('Company or contact name is required.');
    }
    if ($targetEmail !== '' && filter_var($targetEmail, FILTER_VALIDATE_EMAIL) === false) {
        throw new InvalidArgumentException('Enter a valid quote email address.');
    }
    if (!array_key_exists($status, Constant::CRM_QUOTE['STATUS'])) {
        throw new InvalidArgumentException('Select a valid quote status.');
    }
    if ($items === []) {
        throw new InvalidArgumentException('At least one quotation item is required.');
    }
    $assignedSalespersonId = null;
    if ($leadId !== null) {
        $leadStmt = $conn->prepare(
            "SELECT id, assigned_salesperson_id FROM crm_leads WHERE id = ? AND acceptance_status = 'Accepted' AND deleted_at IS NULL LIMIT 1"
        );
        $leadStmt->bind_param('i', $leadId);
        $leadStmt->execute();
        $validLead = $leadStmt->get_result()->fetch_assoc();
        $leadStmt->close();
        if (!$validLead) {
            throw new InvalidArgumentException('The linked lead must be accepted and active.');
        }
        $assignedSalespersonId = !empty($validLead['assigned_salesperson_id'])
            ? (int)$validLead['assigned_salesperson_id']
            : null;
    }

    $normalizedItems = [];
    $subtotal = 0.0;
    $taxAmount = 0.0;
    $productStmt = $conn->prepare(
        "SELECT product_name,
                COALESCE(NULLIF(product_code, ''), NULLIF(marg_code, ''), CONCAT('PRD-', LPAD(id, 4, '0'))) AS sku
         FROM products WHERE id = ? AND status = 1 AND deleted_at IS NULL LIMIT 1"
    );
    if (!$productStmt) {
        throw new RuntimeException('Unable to validate quote products.');
    }
    foreach ($items as $index => $item) {
        $productId = (int)($item['product_id'] ?? 0);
        $quantity = (int)($item['quantity'] ?? 0);
        $unitPrice = (float)($item['unit_price'] ?? -1);
        $gstRate = (float)($item['gst_rate'] ?? -1);
        if ($productId <= 0 || $quantity <= 0 || $unitPrice < 0 || $gstRate < 0 || $gstRate > 100) {
            $productStmt->close();
            throw new InvalidArgumentException(
                'Quote item ' . ($index + 1) . ' contains an invalid product, quantity, price, or GST.'
            );
        }
        $productStmt->bind_param('i', $productId);
        $productStmt->execute();
        $product = $productStmt->get_result()->fetch_assoc();
        if (!$product) {
            $productStmt->close();
            throw new InvalidArgumentException('Quote item ' . ($index + 1) . ' is not an active Product Master item.');
        }
        $baseAmount = round($quantity * $unitPrice, 2);
        $gstAmount = round($baseAmount * ($gstRate / 100), 2);
        $subtotal += $baseAmount;
        $taxAmount += $gstAmount;
        $normalizedItems[] = [
            'product_id' => $productId,
            'product_name' => (string)$product['product_name'],
            'sku' => (string)$product['sku'],
            'quantity' => $quantity,
            'unit_price' => $unitPrice,
            'gst_rate' => $gstRate,
            'gst_amount' => $gstAmount,
            'line_total' => round($baseAmount + $gstAmount, 2),
        ];
    }
    $productStmt->close();
    $subtotal = round($subtotal, 2);
    $taxAmount = round($taxAmount, 2);
    $discountAmount = min($discountAmount, $subtotal + $taxAmount);
    $totalAmount = round($subtotal + $taxAmount - $discountAmount, 2);
    $isNew = $quoteId <= 0;

    $conn->begin_transaction();
    try {
        if ($isNew) {
            $quoteNumber = crmGenerateQuoteNumber($conn);
            $stmt = $conn->prepare(
                "INSERT INTO quotation_requests
                 (source_origin, lead_id, assigned_salesperson_id, quotation_number, target_name, target_email, target_phone,
                  target_company_name, customer_gstin, billing_address, shipping_address, status, currency,
                  subtotal, tax_amount, discount_amount, total_amount, notes, created_at)
                 VALUES ('crm', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'INR', ?, ?, ?, ?, ?, NOW())"
            );
            if (!$stmt || !crmBindAndExecute($stmt, 'iisssssssssdddds', [
                $leadId, $assignedSalespersonId, $quoteNumber, $targetName, $targetEmail, $targetPhone, $targetCompany,
                $gstin, $billing, $shipping, $status, $subtotal, $taxAmount, $discountAmount, $totalAmount, $notes,
            ])) {
                throw new RuntimeException('Unable to create the quotation.');
            }
            $quoteId = (int)$stmt->insert_id;
            $stmt->close();
        } else {
            $currentStmt = $conn->prepare(
                "SELECT quotation_number FROM quotation_requests
                 WHERE id = ? AND source_origin = 'crm' AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
            );
            $currentStmt->bind_param('i', $quoteId);
            $currentStmt->execute();
            $currentQuote = $currentStmt->get_result()->fetch_assoc();
            $currentStmt->close();
            if (!$currentQuote) {
                throw new RuntimeException('The CRM quotation was not found.');
            }
            $quoteNumber = (string)$currentQuote['quotation_number'];
            $stmt = $conn->prepare(
                "UPDATE quotation_requests SET lead_id = ?, assigned_salesperson_id = ?, target_name = ?, target_email = ?, target_phone = ?,
                 target_company_name = ?, customer_gstin = ?, billing_address = ?, shipping_address = ?, status = ?,
                 subtotal = ?, tax_amount = ?, discount_amount = ?, total_amount = ?, notes = ?, updated_at = NOW()
                 WHERE id = ? AND source_origin = 'crm' AND deleted_at IS NULL"
            );
            if (!$stmt || !crmBindAndExecute($stmt, 'iissssssssddddsi', [
                $leadId, $assignedSalespersonId, $targetName, $targetEmail, $targetPhone, $targetCompany, $gstin, $billing,
                $shipping, $status, $subtotal, $taxAmount, $discountAmount, $totalAmount, $notes, $quoteId,
            ])) {
                throw new RuntimeException('Unable to update the quotation.');
            }
            $stmt->close();
        }

        $deleteItems = $conn->prepare('DELETE FROM quotation_request_items WHERE quotation_request_id = ?');
        $deleteItems->bind_param('i', $quoteId);
        if (!$deleteItems->execute()) {
            throw new RuntimeException('Unable to replace quotation line items.');
        }
        $deleteItems->close();

        $itemStmt = $conn->prepare(
            'INSERT INTO quotation_request_items
             (quotation_request_id, product_id, product_name, sku, quantity, unit_price, gst_rate, gst_amount, line_total, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
        );
        foreach ($normalizedItems as $item) {
            if (!$itemStmt || !crmBindAndExecute($itemStmt, 'iissidddd', [
                $quoteId, $item['product_id'], $item['product_name'], $item['sku'], $item['quantity'],
                $item['unit_price'], $item['gst_rate'], $item['gst_amount'], $item['line_total'],
            ])) {
                throw new RuntimeException('Unable to save quotation line items.');
            }
        }
        $itemStmt->close();

        if ($leadId) {
            logLeadActivity(
                $conn,
                $leadId,
                $isNew ? 'Quote Generated' : 'Quote Updated',
                'Quotation #' . $quoteNumber . ' saved with total INR ' . number_format($totalAmount, 2) . '.',
                $userId
            );
        }
        $conn->commit();
        return [
            'quote_id' => $quoteId,
            'quotation_number' => $quoteNumber,
            'subtotal' => $subtotal,
            'tax_amount' => $taxAmount,
            'discount_amount' => $discountAmount,
            'total_amount' => $totalAmount,
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function crmCreateOrderFromPi(mysqli $conn, int $piId, int $userId): array
{
    if ($piId <= 0) {
        throw new InvalidArgumentException('Invalid PI ID.');
    }

    $conn->begin_transaction();
    try {
        $piStmt = $conn->prepare(
            'SELECT * FROM proforma_invoices WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1 FOR UPDATE'
        );
        $piStmt->bind_param('i', $piId);
        $piStmt->execute();
        $pi = $piStmt->get_result()->fetch_assoc();
        $piStmt->close();
        if (!$pi) {
            throw new RuntimeException('Proforma Invoice not found.');
        }
        if (!empty($pi['converted_order_id'])) {
            throw new RuntimeException('This PI has already been converted to an Order.');
        }

        // Detect proforma_source column type for compatibility
        $proformaSourceValue = 'erp';
        $proformaSourceColCheck = $conn->query(
            "SELECT DATA_TYPE FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_received'
             AND COLUMN_NAME = 'proforma_source' LIMIT 1"
        );
        $proformaSourceColType = $proformaSourceColCheck ? ($proformaSourceColCheck->fetch_assoc()['DATA_TYPE'] ?? 'varchar') : 'varchar';
        $proformaSourceIsNumeric = in_array($proformaSourceColType, ['tinyint', 'smallint', 'int', 'bigint'], true);
        $proformaSourceDbValue = $proformaSourceIsNumeric ? 1 : $proformaSourceValue;

        // Check for existing order linked to this PI
        if ($proformaSourceIsNumeric) {
            $existing = $conn->prepare(
                "SELECT id, order_number FROM order_received
                 WHERE proforma_source = 1 AND proforma_invoice_id = ? LIMIT 1"
            );
        } else {
            $existing = $conn->prepare(
                "SELECT id, order_number FROM order_received
                 WHERE proforma_source = 'erp' AND proforma_invoice_id = ? LIMIT 1"
            );
        }
        $existing->bind_param('i', $piId);
        $existing->execute();
        $existingOrder = $existing->get_result()->fetch_assoc();
        $existing->close();
        if ($existingOrder) {
            throw new RuntimeException('This PI is already linked to Order #' . $existingOrder['order_number'] . '.');
        }

        $customerId = (int) ($pi['customer_id'] ?? 0);
        $customer = $customerId > 0 ? mvGetActiveCustomer($conn, $customerId) : null;
        if (!$customer) {
            $companyName = trim((string)($pi['company_name'] ?? ''));
            $gstNo = trim((string)($pi['company_gst'] ?? ''));
            if ($companyName !== '' || $gstNo !== '') {
                $matchCustStmt = $conn->prepare("SELECT id FROM customers WHERE status = 1 AND (
                    (TRIM(gstin) <> '' AND BINARY TRIM(gstin) = BINARY TRIM(?))
                    OR BINARY TRIM(name) = BINARY TRIM(?)
                    OR (TRIM(COALESCE(company_name, '')) <> '' AND BINARY TRIM(company_name) = BINARY TRIM(?))
                ) ORDER BY CASE WHEN TRIM(gstin) <> '' AND BINARY TRIM(gstin) = BINARY TRIM(?) THEN 0 ELSE 1 END LIMIT 1");
                $matchCustStmt->bind_param('ssss', $gstNo, $companyName, $companyName, $gstNo);
                $matchCustStmt->execute();
                $matchedCust = $matchCustStmt->get_result()->fetch_assoc();
                $matchCustStmt->close();
                if ($matchedCust) {
                    $customerId = (int) $matchedCust['id'];
                    $upStmt = $conn->prepare("UPDATE proforma_invoices SET customer_id = ? WHERE id = ?");
                    $upStmt->bind_param('ii', $customerId, $piId);
                    $upStmt->execute();
                    $upStmt->close();
                    $customer = mvGetActiveCustomer($conn, $customerId);
                } else {
                    $contactPerson = trim((string)($pi['attendant_person'] ?? ''));
                    $phone = trim((string)($pi['attendant_contact'] ?? ''));
                    $address = trim((string)($pi['company_address'] ?? ''));
                    $userType = 'B2B';
                    $sourceOrigin = 'erp';
                    $gstValid = (!empty($gstNo) && preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/i', $gstNo)) ? 1 : 0;
                    $insCustStmt = $conn->prepare("INSERT INTO customers (source_origin, name, user_type, company_name, contact_person, phone, gstin, detailed_address, gst_format_valid, credit_limit, credit_days, status, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0.00, 30, 1, ?, NOW())");
                    $custName = $companyName ?: 'Customer';
                    $insCustStmt->bind_param('ssssssssii', $sourceOrigin, $custName, $userType, $companyName, $contactPerson, $phone, $gstNo, $address, $gstValid, $userId);
                    if ($insCustStmt->execute()) {
                        $customerId = (int) $conn->insert_id;
                        $insCustStmt->close();
                        $upStmt = $conn->prepare("UPDATE proforma_invoices SET customer_id = ? WHERE id = ?");
                        $upStmt->bind_param('ii', $customerId, $piId);
                        $upStmt->execute();
                        $upStmt->close();
                        $customer = mvGetActiveCustomer($conn, $customerId);
                    } else {
                        $insCustStmt->close();
                    }
                }
            }
        }
        if (!$customer) {
            throw new RuntimeException('Link this PI to an active Customer Master record before converting it.');
        }
        // Only validate critical fields for PI conversion; skip non-essential fields
        $missing = mvValidateCustomerForOrder($customer);
        // Filter to only block on truly critical missing fields (address and contact)
        $criticalMissing = array_filter($missing, static function (string $field): bool {
            $criticalFields = ['address', 'contact person', 'contact number'];
            return in_array(strtolower($field), $criticalFields, true);
        });
        if ($criticalMissing !== []) {
            throw new RuntimeException(
                'Complete these Customer Master fields before conversion: ' . implode(', ', $criticalMissing) . '.'
            );
        }

        $itemsStmt = $conn->prepare(
            'SELECT * FROM proforma_invoice_items WHERE pi_id = ? AND status != 3 AND deleted_at IS NULL ORDER BY id'
        );
        $itemsStmt->bind_param('i', $piId);
        $itemsStmt->execute();
        $piItems = $itemsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $itemsStmt->close();
        if ($piItems === []) {
            throw new RuntimeException('The PI has no active line items.');
        }

        $resolvedItems = [];
        foreach ($piItems as $index => $piItem) {
            $productName = trim((string) ($piItem['product'] ?? ''));
            $catalogNumber = trim((string) ($piItem['cat_no'] ?? ''));
            $quantity = (float) ($piItem['qty'] ?? 0);
            if ($productName === '' || $quantity <= 0) {
                throw new RuntimeException('PI item ' . ($index + 1) . ' has an invalid product or quantity.');
            }

            $product = null;
            if ($catalogNumber !== '') {
                $productStmt = $conn->prepare(
                    'SELECT id, product_name, unit_id FROM products
                     WHERE deleted_at IS NULL AND status = 1
                       AND (erp_sku_web = ? OR product_code = ? OR marg_code = ?)
                     LIMIT 1'
                );
                $productStmt->bind_param('sss', $catalogNumber, $catalogNumber, $catalogNumber);
                $productStmt->execute();
                $product = $productStmt->get_result()->fetch_assoc();
                $productStmt->close();
            }
            if (!$product) {
                $productStmt = $conn->prepare(
                    'SELECT id, product_name, unit_id FROM products
                     WHERE deleted_at IS NULL AND status = 1 AND (
                        LOWER(TRIM(product_name)) = LOWER(TRIM(?))
                        OR LOWER(TRIM(product_name)) LIKE LOWER(CONCAT("%", TRIM(?), "%"))
                        OR LOWER(?) LIKE LOWER(CONCAT("%", TRIM(product_name), "%"))
                     ) ORDER BY CASE WHEN LOWER(TRIM(product_name)) = LOWER(TRIM(?)) THEN 0 ELSE 1 END LIMIT 1'
                );
                $productStmt->bind_param('ssss', $productName, $productName, $productName, $productName);
                $productStmt->execute();
                $product = $productStmt->get_result()->fetch_assoc();
                $productStmt->close();
            }
            if (!$product) {
                throw new RuntimeException(
                    'Map PI item "' . $productName . '" to an active Product Master record before conversion.'
                );
            }

            $productId = (int) $product['id'];
            $unitId = mvResolveProductionUnitId($conn, $productId, [(int) ($product['unit_id'] ?? 0)]);
            if ($unitId <= 0) {
                throw new RuntimeException('Configure a valid unit for ' . $product['product_name'] . ' before conversion.');
            }
            $resolvedItems[] = [
                'product_id' => $productId,
                'product_name' => (string) $product['product_name'],
                'quantity' => $quantity,
                'unit_id' => $unitId,
            ];
        }

        $orderNumber = generateOrderCode($conn);
        if ($orderNumber === '') {
            $orderNumber = generateAutoStringNumber('ORD');
        }
        $clientName = mvCustomerDisplayName($customer);
        $areaCity = trim((string) ($customer['city'] ?? ''));
        $deliveryAddress = (int) ($pi['is_shipping_add'] ?? 0) === 1
            ? trim((string) ($pi['ship_company_address'] ?? ''))
            : trim((string) ($pi['company_address'] ?? ''));
        if ($deliveryAddress === '') {
            $deliveryAddress = mvCustomerAddress($customer);
        }
        $customerTerms = mvResolveCustomerPaymentTerms($customer);
        $orderValue = (float) ($pi['total_price'] ?? 0);
        $receivedBy = mvGetSessionUserName($conn, $userId);
        $leadId = !empty($pi['lead_id']) ? (int) $pi['lead_id'] : null;
        $quoteId = !empty($pi['quote_request_id']) ? (int) $pi['quote_request_id'] : null;
        $locationType = 1;
        $orderDate = date('Y-m-d');
        $orderType = 1;
        $orderTypeDetails = 'Converted from confirmed PI ' . (string) $pi['pi_auto_batch'];
        $dispatchTimeline = 1;
        $paymentStatus = (int) $customerTerms['status'];
        $paymentDetails = (string) $customerTerms['details'];
        $paymentOverrideReason = '';
        $purchaseInvoice = (string) $pi['pi_auto_batch'];
        $customerAddress = mvCustomerAddress($customer);
        $customerGstin = trim((string) ($customer['gstin'] ?? $pi['company_gst'] ?? ''));
        $customerPan = trim((string) ($customer['pan'] ?? ''));
        $customerState = trim((string) ($customer['state_province'] ?? ''));
        $customerStateCode = trim((string) ($customer['state_code'] ?? ''));
        $customerContact = trim((string) ($customer['contact_person'] ?? $pi['attendant_person'] ?? ''));
        $customerPhone = trim((string) ($customer['phone'] ?? $pi['attendant_contact'] ?? ''));
        $customerEmail = trim((string) ($customer['email'] ?? ''));
        $sourceType = 1;
        $status = 0;

        // Build INSERT dynamically to handle nullable lead_id and quotation_request_id
        $columns = 'locationtype, order_number, date_order_received, client_name, area_city, delivery_address,
                 customer_id, order_type, order_type_details, order_value, dispatch_timeline,
                 payment_tems_status, payment_details, payment_override_reason, purchase_invoice,
                 proforma_source, proforma_invoice_id';
        $placeholders = '?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?';
        $types = $proformaSourceIsNumeric ? 'isssssiisdiisssii' : 'isssssiisdiissssi';
        $orderValues = [
            $locationType, $orderNumber, $orderDate, $clientName, $areaCity, $deliveryAddress,
            $customerId, $orderType, $orderTypeDetails, $orderValue, $dispatchTimeline,
            $paymentStatus, $paymentDetails, $paymentOverrideReason, $purchaseInvoice,
            $proformaSourceDbValue, $piId,
        ];

        // Handle nullable lead_id
        if ($leadId !== null) {
            $columns .= ', lead_id';
            $placeholders .= ', ?';
            $types .= 'i';
            $orderValues[] = $leadId;
        }
        // Handle nullable quotation_request_id
        if ($quoteId !== null) {
            $columns .= ', quotation_request_id';
            $placeholders .= ', ?';
            $types .= 'i';
            $orderValues[] = $quoteId;
        }

        // Remaining columns are always present
        $columns .= ', received_by, received_by_user_id, customer_address_snapshot, customer_gstin_snapshot,
                 customer_pan_snapshot, customer_state_snapshot, customer_state_code_snapshot,
                 customer_contact_person_snapshot, customer_contact_number_snapshot, customer_email_snapshot,
                 source_type, status, created_by, created_at';
        $placeholders .= ', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW()';
        $types .= 'sissssssssiii';
        $orderValues = array_merge($orderValues, [
            $receivedBy, $userId,
            $customerAddress, $customerGstin, $customerPan, $customerState, $customerStateCode,
            $customerContact, $customerPhone, $customerEmail, $sourceType, $status, $userId,
        ]);

        $orderStmt = $conn->prepare(
            "INSERT INTO order_received ({$columns}) VALUES ({$placeholders})"
        );
        if (!$orderStmt) {
            throw new RuntimeException('Unable to prepare the Sales Order: ' . $conn->error);
        }
        if (!crmBindAndExecute($orderStmt, $types, $orderValues)) {
            $error = $orderStmt->error;
            $orderStmt->close();
            throw new RuntimeException('Unable to create the Sales Order: ' . $error);
        }
        $orderId = (int) $orderStmt->insert_id;
        $orderStmt->close();

        $itemStmt = $conn->prepare(
            'INSERT INTO order_received_items
                (order_id, product_id, product_name, quantity, unit, status, created_by, created_at)
             VALUES (?, ?, ?, ?, ?, 0, ?, NOW())'
        );
        if (!$itemStmt) {
            throw new RuntimeException('Unable to prepare Sales Order items: ' . $conn->error);
        }
        foreach ($resolvedItems as $item) {
            $productId = (int) $item['product_id'];
            $productName = (string) $item['product_name'];
            $quantity = (float) $item['quantity'];
            $unitId = (int) $item['unit_id'];
            $itemStmt->bind_param('iisdii', $orderId, $productId, $productName, $quantity, $unitId, $userId);
            if (!$itemStmt->execute()) {
                $error = $itemStmt->error;
                $itemStmt->close();
                throw new RuntimeException('Unable to create a Sales Order item: ' . $error);
            }
        }
        $itemStmt->close();

        $piUpdate = $conn->prepare(
            "UPDATE proforma_invoices
             SET crm_conversion_status = 'Converted', confirmed_at = COALESCE(confirmed_at, NOW()),
                 confirmed_by = COALESCE(confirmed_by, ?), converted_order_id = ?, updated_by = ?, updated_at = NOW()
             WHERE id = ? AND converted_order_id IS NULL"
        );
        $piUpdate->bind_param('iiii', $userId, $orderId, $userId, $piId);
        if (!$piUpdate->execute() || $piUpdate->affected_rows !== 1) {
            $piUpdate->close();
            throw new RuntimeException('The PI conversion state changed. Refresh and try again.');
        }
        $piUpdate->close();

        mvAuditOrderChange($conn, $orderId, 'order_created_from_pi', $userId, null, null, null, [
            'proforma_source' => $proformaSourceValue,
            'proforma_invoice_id' => $piId,
            'lead_id' => $leadId,
            'quotation_request_id' => $quoteId,
        ]);
        $conn->commit();

        if ($leadId) {
            $leadUpdate = $conn->prepare(
                "UPDATE crm_leads SET lead_status = 'Converted', updated_by = ?, updated_at = NOW() WHERE id = ?"
            );
            $leadUpdate->bind_param('ii', $userId, $leadId);
            $leadUpdate->execute();
            $leadUpdate->close();
            logLeadActivity(
                $conn,
                $leadId,
                'Converted to Sales Order',
                'PI #' . $pi['pi_auto_batch'] . ' converted to Order #' . $orderNumber . '.',
                $userId
            );
        }

        $routing = null;
        try {
            $routing = mvAutoRouteOrderAfterStockCheck(
                $conn,
                $orderId,
                $userId,
                'Auto-routed after CRM PI conversion.'
            );
        } catch (Throwable $routingError) {
            error_log('CRM Sales Order routing failed for order ' . $orderId . ': ' . $routingError->getMessage());
        }

        return [
            'order_id' => $orderId,
            'order_number' => $orderNumber,
            'routing' => $routing,
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}
