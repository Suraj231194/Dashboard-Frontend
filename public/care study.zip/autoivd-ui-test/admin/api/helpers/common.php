<?php

function writeApiLog($message)
{
    $file = __DIR__ . '/../logs/api.log';

    $log = "[" . date("Y-m-d H:i:s") . "] " . $message . PHP_EOL;

    file_put_contents($file, $log, FILE_APPEND);
}

/**
 * Simple, business-friendly logger for WhatsApp order processing.
 *
 * @param string $event_type    Short event label (e.g. 'WEBHOOK_RECEIVED', 'ORDER_CREATED')
 * @param string $log_message   Human-readable business summary
 * @param mixed  $extra_details Optional data array, payload, or error response
 */
function writeWhatsAppLog($event_type, $log_message, $extra_details = null)
{
    $log_folder = __DIR__ . '/../logs';
    if (!is_dir($log_folder)) {
        mkdir($log_folder, 0777, true);
    }

    $log_file = $log_folder . '/whatsapp_webhook.log';
    $current_time = date('Y-m-d H:i:s');

    $log_entry = "[" . $current_time . "] [" . $event_type . "] " . $log_message . PHP_EOL;

    if ($extra_details !== null) {
        if (is_array($extra_details) || is_object($extra_details)) {
            $log_entry .= json_encode($extra_details, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL;
        } else {
            $log_entry .= (string)$extra_details . PHP_EOL;
        }
    }

    file_put_contents($log_file, $log_entry, FILE_APPEND);
}