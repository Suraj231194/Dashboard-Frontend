<?php

$routes = [

    'product' => [
        'add' => [
            'class' => 'ProductController',
            'method' => 'addProduct'
        ],
        'getList' => [
            'class' => 'ProductController',
            'method' => 'getProducts'
        ]
    ],
    'category' => [
        'add' => [
            'class' => 'CategoryController',
            'method' => 'addCategory'
        ]
    ],
    'order' => [
        'sync' => [
            'class' => 'OrderApiController',
            'method' => 'syncOrder'
        ]
    ],
    'website' => [
        'order' => [
            'class' => 'OrderApiController',
            'method' => 'receiveWebsiteOrder'
        ],
        'receiveOrder' => [
            'class' => 'OrderApiController',
            'method' => 'receiveWebsiteOrder'
        ]
    ],
    'crm' => [
        'captureLead' => [
            'class' => 'CrmLeadApiController',
            'method' => 'captureWebsiteLead'
        ]
    ],

    'inventory' => [
        'updateStock' => [
            'class' => 'InventoryApiController',
            'method' => 'updateStock'
        ]
    ],
    'whatsapp' => [
        'webhook' => [
            'class' => 'WhatsAppApiController',
            'method' => 'handleWebhook'
        ],
        'test' => [
            'class' => 'WhatsAppApiController',
            'method' => 'testSimulation'
        ]
    ]

];
