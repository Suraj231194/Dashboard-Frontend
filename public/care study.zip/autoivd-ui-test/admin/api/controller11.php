<?php
function getQtyUnits()
{
    global $conn;

    // $unitOptions = fetch_table_records($conn, 'standard_units', ['status' => 1], 'fullname');
   
    $unitOptions = fetch_table_records($conn, 'products', [
            'status' => ['op' => '!=', 'value' => 3],
            'deleted_at' => null
        ], 'product_name', 'ASC',['id', 'product_name'] );   
   
    // $unitOptions = fetch_table_records($conn, 'products', [
    //         'status' => ['op' => '!=', 'value' => 3],
    //         'deleted_at' => null
    //     ], 'product_name', 'ASC','COUNT(*) AS total');   

    apiResponse(true, 'Units List', $unitOptions);
}

function receiveOrder()
{
    global $conn;
    $data = getRequestData();
    $orderNo = $data['order_no'] ?? '';
    $total   = $data['total'] ?? 0;

    if (empty($orderNo)) {
        apiResponse(false, 'Order No Missing');
    }

    // $stmt = $conn->prepare("INSERT INTO erp_orders (order_no, total) VALUES (?, ?)");
    // $stmt->bind_param("sd", $orderNo, $total);
    // $stmt->execute();

    apiResponse(true, 'Order Received in ERP');
}

function addProductCategory()
{
    global $conn;

    try {

        $conn->begin_transaction();
        $data = getRequestData();

        $name = trim($data['name'] ?? '');
        // $total   = floatval($data['total'] ?? 0);

        if (empty($name)) {
            throw new Exception('Category Name Missing');
        }

        // if ($total <= 0) {
        //     throw new Exception('Invalid Order Total');
        // }

        // 🔎 Check Duplicate Order
        $check = $conn->prepare("SELECT `id` FROM `product_categories` WHERE `name` = ?");
        $check->bind_param("s", $name);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            throw new Exception('Category Already Exists');
        }
        $check->close();       
        // $supplierData = [
        //     'name'              => $supplierName,
        //     'supplier_code'     => $supplierCode,
        //     'contact_person'    => $supplierContactPerson,
        //     'contact_number'    => $supplierContactPersonNumner,
        //     'item_description'  => $itemDescription,
        //     'date_of_approval'  => $dateofApproval,
        //     'basis_of_approval' => $basisOfApproval,
        //     'remark'            => $remark,
        //     'is_approved'       => $supplierStatusApproved,
        //     'gst_no'            => $supplierGstNo,
        //     'contact_details'   => $supplierContactDetails,
        //     'status'            => $supplierStatus,
        //     'is_supplier'       => $isSupplier,
        //     'is_manufacturer'   => $isManufacturer,
        //     'is_vendor'         => $isVendor,
        //     'is_dealer'         => $isDealer,
        //     'created_by'        => $createdBy,
        //     'created_at'        => $createdAt
        // ];

        // $supplierId = insertRecordIntoTable($conn, 'suppliers', $supplierData);

        // if (!is_numeric($supplierId)) {
        //     throw new Exception("Insert failed: " . $supplierId);
        // }      

        $conn->commit();

        apiResponse(true, 'Category added successfully.', [
            'order_no' => $name
        ]);
        
    } catch (Exception $e) {
        $conn->rollback();
        apiResponse(false, $e->getMessage());
    }
}


function getProducts()
{
    global $conn;
    $page  = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 100;
    if($page < 1) $page = 1;

    $offset = ($page - 1) * $limit;
   
    $filters = [];

    if(isset($_GET['status']) && $_GET['status'] !== ''){

        $status = array_map('intval', explode(',', $_GET['status']));

        $filters['p.status'] = [
            'op' => 'IN',
            'value' => $status
        ];
    }

    if(!empty($_GET['category_id'])){

        $category = array_map('intval', explode(',', $_GET['category_id']));

        $filters['p.category_id'] = [
            'op' => 'IN',
            'value' => $category
        ];
    }

    if(!empty($_GET['unit_id'])){

        $unit = array_map('intval', explode(',', $_GET['unit_id']));

        $filters['p.unit_id'] = [
            'op' => 'IN',
            'value' => $unit
        ];
    }

    $options = [
        'columns' => [
            'p.*'
        ],
        'order_by' => 'p.product_name',

        'limit' => $limit,

        'offset' => $offset
    ];

    $countResult = fetchApiRecords($conn,'products p', $filters,['columns' => ['COUNT(*) as total']]);

    $totalProducts = $countResult[0]['total'] ?? 0;

    $products = fetchApiRecords($conn,'products p',$filters,$options);

    if(!$products){
        apiResponse(true,'Products List',[]);
    }


    $categoryIds = [];
    $unitIds = [];

    foreach($products as $p){

        if(!empty($p['category_id'])){
            $categoryIds[] = $p['category_id'];
        }

        if(!empty($p['unit_id'])){
            $unitIds[] = $p['unit_id'];
        }

    }

    $categoryIds = array_unique($categoryIds);
    $unitIds = array_unique($unitIds);

    $categories = [];
    $units = [];


    if($categoryIds){

        $rows = fetchApiRecords(
            $conn,
            'product_categories',
            [
                'id'=>[
                    'op'=>'IN',
                    'value'=>$categoryIds
                ]
            ]
        );

        foreach($rows as $r){
            $categories[$r['id']] = $r;
        }

    }   

    if($unitIds){

        $rows = fetchApiRecords(
            $conn,
            'standard_units',
            [
                'id'=>[
                    'op'=>'IN',
                    'value'=>$unitIds
                ]
            ]
        );

        foreach($rows as $r){
            $units[$r['id']] = $r;
        }

    }


    foreach($products as &$p){

        $p['category'] = $categories[$p['category_id']] ?? null;
        $p['unit'] = $units[$p['unit_id']] ?? null;

    }

    $response = [
        'pagination' => [
            'total' => $totalProducts,
            'per_page' => $limit,
            'current_page' => $page,
            'total_pages' => ceil($totalProducts / $limit)

        ],

        'data' => $products
    ];

    apiResponse(true,'Products List',$response);
}