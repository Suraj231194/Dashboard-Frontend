<?php
header("Content-Type: application/json");

require_once("bootfile.php");

$module = $_GET['module'] ?? '';
$action = $_GET['action'] ?? '';

// Bypass Bearer token verification for public webhooks (WhatsApp Meta Cloud API uses hub.verify_token)
$isPublicWebhook = ($module === 'whatsapp' && $action === 'webhook');
if (!$isPublicWebhook) {
    verifyApiToken();
}

if (!$module || !$action) {
    apiResponse(false, 'Module or Action Missing');
}

require_once("routes.php");

if (!isset($routes[$module][$action])) {
    apiResponse(false, 'Invalid API Route');
}

$handler = $routes[$module][$action];

// if (!class_exists($handler['class'])) {
//     require_once($handler['file']);
// }

// $controller = new $handler['class'];

// if (!method_exists($controller, $handler['method'])) {
//     apiResponse(false, 'Invalid Method');
// }

// call_user_func([$controller, $handler['method']]);
try {

    $controllerClass = $handler['class'];
    $method = $handler['method'];

    $controller = new $controllerClass();

    if (!method_exists($controller, $method)) {
        apiResponse(false, 'Invalid Method');
    }

    // optional log
    // writeApiLog("$module/$action API called");

    call_user_func([$controller, $method]);

} catch (Throwable $e) {

    writeApiLog("ERROR: " . $e->getMessage());

    apiResponse(false, 'Something went wrong');
}