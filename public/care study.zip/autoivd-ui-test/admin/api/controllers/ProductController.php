<?php
class ProductController {  

    public function addProduct() {
        global $conn;

        $params = getRequestData();

        if (empty($params['product_name'])) {
            apiResponse(false, 'Product name required');
        }

        if (empty($params['category_id'])) {
            apiResponse(false, 'Category required');
        }

        if (!is_numeric($params['category_id'])) {
            apiResponse(false, 'Invalid category');
        }

        $id = insertRecordIntoTable($conn, 'products', $params);

        apiResponse(true, 'Product Added', ['id' => $id]);
    }

    public function getProducts() {
        global $conn;
        $params = getRequestData();
        $products = ProductService::getAllProducts($conn, $params);      
        apiResponse(true, 'Products List', $products);
    }

}