<?php
class OrderApiController
{
    public function syncOrder(): void
    {
        $this->createOrder(null, false);
    }

    public function receiveWebsiteOrder(): void
    {
        $this->createOrder(2, true);
    }

    private function createOrder(?int $forcedSourceType, bool $requireExternalReference): void
    {
        global $conn;

        $syncLogManager = null;
        $syncLogId = 0;
        if ($forcedSourceType === 2) {
            require_once(__DIR__ . '/../../sync/SyncSettingsManager.php');
            $syncSettings = new SyncSettingsManager($conn);
            if (! $syncSettings->isEnabled('orders')) {
                apiResponse(false, 'Order sync is disabled in Company Control Room.');
            }
            require_once(__DIR__ . '/../../sync/SyncLogManager.php');
            $syncLogManager = new SyncLogManager($conn);
        }

        $params = mvNormalizeExternalOrderPayload(getRequestData());
        $sourceType = $forcedSourceType ?? intval($params['source_type'] ?? 0);
        if (!in_array($sourceType, [2, 3, 4], true)) {
            apiResponse(false, 'Invalid source_type. Must be 2 (Website), 3 (Email), or 4 (WhatsApp)');
        }

        $clientName = trim((string) ($params['client_name'] ?? ''));
        $externalReference = trim((string) ($params['external_reference'] ?? $params['external_id'] ?? ''));
        $items = $params['items'] ?? [];
        if ($clientName === '') {
            apiResponse(false, 'client_name is required');
        }
        if ($requireExternalReference && $externalReference === '') {
            apiResponse(false, 'external_reference is required');
        }
        if (!is_array($items) || empty($items)) {
            apiResponse(false, 'No order items found. Send structured items or parseable raw_content');
        }

        if ($syncLogManager) {
            $syncLogId = $syncLogManager->createLog(
                'orders',
                $externalReference !== '' ? $externalReference : 'website-order',
                'inbound',
                $params
            );
        }

        if ($externalReference !== '') {
            $duplicateStmt = $conn->prepare("SELECT id, order_number FROM order_received WHERE source_type = ? AND external_reference = ? AND deleted_at IS NULL LIMIT 1");
            $duplicateStmt->bind_param('is', $sourceType, $externalReference);
            $duplicateStmt->execute();
            $duplicate = $duplicateStmt->get_result()->fetch_assoc();
            $duplicateStmt->close();
            if ($duplicate) {
                if ($syncLogManager && $syncLogId > 0) {
                    $syncLogManager->markSuccess($syncLogId, json_encode([
                        'duplicate' => true,
                        'order_id' => (int) $duplicate['id'],
                    ]));
                }
                apiResponse(true, 'Order already received', [
                    'order_id' => (int) $duplicate['id'],
                    'order_number' => $duplicate['order_number'],
                    'duplicate' => true,
                ]);
            }
        }

        try {
            $orderNumber = generateOrderCode($conn);
        } catch (Throwable $e) {
            $prefix = $sourceType === 2 ? 'WEB' : ($sourceType === 3 ? 'EM' : 'WA');
            $orderNumber = generateAutoStringNumber($prefix . '-');
        }

        $dateOrderReceived = trim((string) ($params['date_order_received'] ?? date('Y-m-d')));
        $areaCity = trim((string) ($params['area_city'] ?? ''));
        $deliveryAddress = trim((string) ($params['delivery_address'] ?? ''));
        $orderType = intval($params['order_type'] ?? 1);
        $orderValue = floatval($params['order_value'] ?? 0);
        $dispatchTimeline = intval($params['dispatch_timeline'] ?? 1);
        $paymentStatus = intval($params['payment_tems_status'] ?? $params['payment_status'] ?? 2);
        $paymentDetails = trim((string) ($params['payment_details'] ?? ''));
        $rawContent = trim((string) ($params['raw_content'] ?? ''));
        $status = 12;
        $createdBy = 1;

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO order_received
                (order_number, source_type, external_reference, date_order_received, client_name, area_city,
                 delivery_address, order_type, order_value, dispatch_timeline, payment_tems_status,
                 payment_details, status, raw_content, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param(
                'sisssssidiisisi',
                $orderNumber,
                $sourceType,
                $externalReference,
                $dateOrderReceived,
                $clientName,
                $areaCity,
                $deliveryAddress,
                $orderType,
                $orderValue,
                $dispatchTimeline,
                $paymentStatus,
                $paymentDetails,
                $status,
                $rawContent,
                $createdBy
            );
            if (! $stmt->execute()) {
                $insertErrno = (int) $stmt->errno;
                $insertError = (string) $stmt->error;
                $stmt->close();

                if ($insertErrno === 1062 && $externalReference !== '') {
                    $conn->rollback();
                    $existingStmt = $conn->prepare(
                        "SELECT id, order_number FROM order_received
                         WHERE source_type = ? AND external_reference = ? AND deleted_at IS NULL LIMIT 1"
                    );
                    $existingStmt->bind_param('is', $sourceType, $externalReference);
                    $existingStmt->execute();
                    $existing = $existingStmt->get_result()->fetch_assoc();
                    $existingStmt->close();
                    if ($existing) {
                        if ($syncLogManager && $syncLogId > 0) {
                            $syncLogManager->markSuccess($syncLogId, json_encode([
                                'duplicate' => true,
                                'order_id' => (int) $existing['id'],
                            ]));
                        }
                        apiResponse(true, 'Order already received', [
                            'order_id' => (int) $existing['id'],
                            'order_number' => $existing['order_number'],
                            'duplicate' => true,
                        ]);
                    }
                }

                throw new RuntimeException('Order insert failed: ' . $insertError, $insertErrno);
            }
            $orderId = $stmt->insert_id;
            $stmt->close();

            $itemStmt = $conn->prepare("INSERT INTO order_received_items
                (order_id, product_id, product_name, quantity, unit, status, order_remark, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            foreach ($items as $item) {
                $productName = trim((string) ($item['product_name'] ?? ''));
                $sku = trim((string) ($item['sku'] ?? ''));
                $quantity = floatval($item['quantity'] ?? 0);
                $unit = intval($item['unit'] ?? 1);
                $remark = trim((string) ($item['order_remark'] ?? ''));
                if ($productName === '' || $quantity <= 0 || $unit <= 0) {
                    throw new RuntimeException('Every order item requires product_name, positive quantity, and unit.');
                }
                
                $productIdVal = null;
                $pStmt = $conn->prepare("
                    SELECT p.id
                    FROM products p
                    LEFT JOIN product_categories c ON c.id = p.category_id
                    WHERE (p.product_name = ? OR p.erp_sku_web = ? OR p.product_code = ?)
                      AND (c.website_sync = 1 OR p.website_sync = 1)
                      AND p.deleted_at IS NULL
                    LIMIT 1
                ");
                $lookupSku = $sku !== '' ? $sku : $productName;
                $pStmt->bind_param("sss", $productName, $lookupSku, $lookupSku);
                $pStmt->execute();
                $pRes = $pStmt->get_result()->fetch_assoc();
                if ($pRes) {
                    $productIdVal = intval($pRes['id']);
                }
                $pStmt->close();

                $itemStmt->bind_param('iisdiisi', $orderId, $productIdVal, $productName, $quantity, $unit, $status, $remark, $createdBy);
                if (! $itemStmt->execute()) {
                    throw new RuntimeException('Order item insert failed: ' . $itemStmt->error);
                }
            }
            $itemStmt->close();
            $conn->commit();

            $routing = [
                'status' => 'success',
                'action' => 'approval',
                'message' => 'Order is awaiting ERP approval.',
            ];

            if ($syncLogManager && $syncLogId > 0) {
                $syncLogManager->markSuccess($syncLogId, json_encode([
                    'order_id' => (int) $orderId,
                    'order_number' => $orderNumber,
                ]));
            }
            apiResponse(true, 'Order synced successfully', [
                'order_id' => $orderId,
                'order_number' => $orderNumber,
                'duplicate' => false,
                'routing' => $routing,
            ]);
        } catch (Throwable $e) {
            $conn->rollback();
            if ($syncLogManager && $syncLogId > 0) {
                $syncLogManager->markFailed($syncLogId, $e->getMessage(), 500);
            }
            writeApiLog('ORDER CREATE ERROR: ' . $e->getMessage());
            apiResponse(false, 'Failed to save order');
        }
    }
}
