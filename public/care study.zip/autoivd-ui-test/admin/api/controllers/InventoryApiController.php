<?php

/**
 * InventoryApiController — ERP API controller for handling inbound inventory stock updates from Website.
 *
 * Location: admin/api/controllers/InventoryApiController.php
 */
class InventoryApiController
{
    /**
     * Handle POST request from Website to update product stock in ERP.
     * Endpoint: /admin/api/index.php?module=inventory&action=updateStock
     */
    public function updateStock(): void
    {
        global $conn;

        require_once(__DIR__ . '/../../sync/SyncSettingsManager.php');
        $syncSettings = new SyncSettingsManager($conn);
        if (! $syncSettings->isEnabled('inventory')) {
            apiResponse(false, 'Inventory sync is disabled in Company Control Room.');
        }

        // ERP is the sole inventory authority. Return success for legacy
        // Website jobs so old queued work drains without retrying or mutating
        // ERP stock. Website continues receiving ERP inventory snapshots.
        apiResponse(true, 'Inventory update ignored because ERP is the inventory source of truth.', [
            'ignored' => true,
            'authoritative_system' => 'erp',
        ]);

        $params = getRequestData();
        $sku = trim((string) ($params['sku'] ?? ''));
        $stockQuantity = (float) ($params['stock_quantity'] ?? 0);
        $stockVersion = max(0, (int) ($params['stock_version'] ?? 0));
        $coaNumber = isset($params['coa_no']) ? trim((string) $params['coa_no']) : null;
        $batchNumber = isset($params['batch_no']) ? trim((string) $params['batch_no']) : null;
        $mfgDate = isset($params['mfg_date']) ? trim((string) $params['mfg_date']) : null;
        $expiryDate = isset($params['expiry_date']) ? trim((string) $params['expiry_date']) : null;

        if (empty($sku)) {
            apiResponse(false, 'SKU parameter is required');
        }
        if ($stockQuantity < 0) {
            apiResponse(false, 'stock_quantity must be zero or greater');
        }

        // Find product by erp_sku_web or product_code
        $stmt = $conn->prepare(
            "SELECT p.`id`, p.`product_name`, p.`category_id`, p.`website_sync`,
                    p.`last_website_stock_version`,
                    c.`website_sync` AS `category_sync`
             FROM `products` p
             LEFT JOIN `product_categories` c ON c.`id` = p.`category_id`
             WHERE (p.`erp_sku_web` = ? OR p.`product_code` = ?) AND p.`deleted_at` IS NULL
             LIMIT 1"
        );
        $stmt->bind_param('ss', $sku, $sku);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$product) {
            apiResponse(false, "Product not found in ERP for SKU: {$sku}");
        }
        if ((int) ($product['website_sync'] ?? 0) !== 1 || (int) ($product['category_sync'] ?? 0) !== 1) {
            apiResponse(false, "Inventory sync is not enabled for ERP product SKU: {$sku}");
        }

        $productId = (int) $product['id'];
        require_once(__DIR__ . '/../../sync/SyncLogManager.php');
        $syncLogManager = new SyncLogManager($conn);
        $syncLogId = $syncLogManager->createLog('inventory', (string) $productId, 'inbound', $params);

        // Upsert into live_stock table
        $conn->query("SET @manuverse_sync_origin = 'website'");
        $conn->begin_transaction();
        try {
            if ($stockVersion > 0) {
                $versionStmt = $conn->prepare(
                    "SELECT `last_website_stock_version`
                     FROM `products` WHERE `id` = ? LIMIT 1 FOR UPDATE"
                );
                $versionStmt->bind_param('i', $productId);
                $versionStmt->execute();
                $currentVersion = (int) ($versionStmt->get_result()->fetch_assoc()['last_website_stock_version'] ?? 0);
                $versionStmt->close();

                if ($stockVersion <= $currentVersion) {
                    $conn->rollback();
                    $conn->query("SET @manuverse_sync_origin = NULL");
                    $syncLogManager->markSuccess($syncLogId, json_encode([
                        'duplicate' => true,
                        'stock_version' => $stockVersion,
                    ]));
                    apiResponse(true, 'Stock update already applied or superseded.', [
                        'product_id' => $productId,
                        'sku' => $sku,
                        'stock_quantity' => $stockQuantity,
                        'stock_version' => $stockVersion,
                        'duplicate' => true,
                    ]);
                }
            }

            $lsId = inventorySetUnreservedStock(
                $conn,
                $productId,
                $stockQuantity,
                0,
                'website_sync'
            );

            // Update product sync timestamp
            $pUpStmt = $conn->prepare(
                "UPDATE `products`
                 SET `last_stock_sync_at` = NOW(),
                     `last_website_stock_version` = GREATEST(`last_website_stock_version`, ?)
                 WHERE `id` = ?"
            );
            $pUpStmt->bind_param('ii', $stockVersion, $productId);
            $pUpStmt->execute();
            $pUpStmt->close();

            $conn->commit();
            $conn->query("SET @manuverse_sync_origin = NULL");
            $syncLogManager->markSuccess($syncLogId, json_encode([
                'product_id' => $productId,
                'stock_quantity' => $stockQuantity,
                'stock_version' => $stockVersion,
            ]));

            apiResponse(true, 'Stock updated successfully in ERP', [
                'product_id' => $productId,
                'sku' => $sku,
                'stock_quantity' => $stockQuantity,
                'stock_version' => $stockVersion,
            ]);

        } catch (Throwable $e) {
            $conn->rollback();
            $conn->query("SET @manuverse_sync_origin = NULL");
            $syncLogManager->markFailed($syncLogId, $e->getMessage(), 500);
            writeApiLog("ERP INVENTORY SYNC ERROR: " . $e->getMessage());
            apiResponse(false, 'Failed to update stock in ERP');
        }
    }
}
