<?php

declare(strict_types=1);

require_once __DIR__ . '/../../crm/crm_common.php';

final class CrmLeadApiController
{
    public function captureWebsiteLead(): void
    {
        global $conn;

        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            http_response_code(405);
            apiResponse(false, 'Method not allowed.');
        }

        $payload = getRequestData();
        if (!is_array($payload)) {
            http_response_code(422);
            apiResponse(false, 'The request body must be a JSON object or form payload.');
        }

        try {
            $result = crmCaptureCanonicalWebsiteLead($conn, $payload);
            http_response_code($result['created'] ? 201 : 200);
            apiResponse(
                true,
                $result['created'] ? 'Lead captured successfully.' : 'Lead already captured.',
                $result
            );
        } catch (InvalidArgumentException $e) {
            http_response_code(422);
            apiResponse(false, $e->getMessage());
        } catch (Throwable $e) {
            error_log('CRM lead intake failed: ' . $e->getMessage());
            http_response_code(500);
            apiResponse(false, 'Unable to capture the lead.');
        }
    }
}
