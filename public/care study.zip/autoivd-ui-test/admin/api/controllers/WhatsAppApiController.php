<?php

/**
 * WhatsAppApiController
 * 
 * Webhook controller & API endpoint for Meta WhatsApp Cloud API integration.
 * Handles GET webhook verification, POST real-time message events,
 * and test simulation endpoint.
 * 
 * Part of: WhatsApp-to-Order Processing Pipeline
 */
class WhatsAppApiController
{
    /**
     * Main Webhook Handler (GET for verification, POST for events)
     */
    public function handleWebhook(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        writeWhatsAppLog('WEBHOOK_CALL', "Incoming request: " . $method);

        if ($method === 'GET') {
            $this->verifyWebhook();
            return;
        }

        if ($method === 'POST') {
            $this->processWebhookPayload();
            return;
        }

        writeWhatsAppLog('METHOD_ERROR', "Unsupported method: " . $method);
        http_response_code(405);
        echo json_encode(['status' => false, 'message' => 'Method Not Allowed']);
        exit;
    }

    /**
     * Meta Cloud API Webhook Verification (GET request)
     */
    private function verifyWebhook(): void
    {
        $mode        = $_GET['hub_mode'] ?? $_GET['hub.mode'] ?? '';
        $token       = $_GET['hub_verify_token'] ?? $_GET['hub.verify_token'] ?? '';
        $challenge   = $_GET['hub_challenge'] ?? $_GET['hub.challenge'] ?? '';
        $configToken = WhatsAppConfigService::getVerifyToken();

        writeWhatsAppLog('VERIFY_CHECK', "Meta requested webhook verification (hub_mode=" . $mode . ")");

        if ($configToken !== '' && $mode === 'subscribe' && hash_equals($configToken, (string)$token)) {
            writeWhatsAppLog('VERIFY_SUCCESS', "Webhook token matched successfully");
            http_response_code(200);
            echo $challenge;
            exit;
        }

        writeWhatsAppLog('VERIFY_FAILED', "Token mismatch. Received=" . $token . ", Configured=" . $configToken);
        http_response_code(403);
        echo 'Forbidden: Invalid verification token';
        exit;
    }

    /**
     * Real-time Webhook Payload Processor (POST request from Meta)
     */
    private function processWebhookPayload(): void
    {
        global $conn;

        $rawInput = file_get_contents('php://input');
        $signature = (string)($_SERVER['HTTP_X_HUB_SIGNATURE_256'] ?? '');
        if (!WhatsAppConfigService::hasValidWebhookSignature($rawInput, $signature)) {
            writeWhatsAppLog('SIGNATURE_INVALID', 'Rejected webhook with an invalid Meta signature.');
            http_response_code(403);
            echo json_encode(['status' => false, 'message' => 'Invalid webhook signature']);
            exit;
        }
        $payload  = json_decode($rawInput, true);

        writeWhatsAppLog('PAYLOAD_RECEIVED', "Received POST payload from Meta", $payload);

        if (!$payload || !isset($payload['entry'])) {
            writeWhatsAppLog('PAYLOAD_INVALID', "Payload is empty or missing entry field");
            // Acknowledge Meta webhooks quickly with 200 OK to prevent retries
            http_response_code(200);
            echo json_encode(['status' => true, 'message' => 'Event received']);
            exit;
        }

        // Meta Cloud API structure: entry[0].changes[0].value.messages[0]
        $entries = $payload['entry'] ?? [];
        foreach ($entries as $entry) {
            $changes = $entry['changes'] ?? [];
            foreach ($changes as $change) {
                $value    = $change['value'] ?? [];
                $messages = $value['messages'] ?? [];
                $contacts = $value['contacts'] ?? [];

                $contactName = '';
                if (!empty($contacts[0]['profile']['name'])) {
                    $contactName = trim($contacts[0]['profile']['name']);
                }

                foreach ($messages as $msg) {
                    $this->processIncomingMessage($conn, $msg, $contactName, $rawInput);
                }
            }
        }

        http_response_code(200);
        echo json_encode(['status' => true, 'message' => 'Processed']);
        exit;
    }

    /**
     * Process an individual incoming WhatsApp message.
     */
    private function processIncomingMessage(mysqli $conn, array $msg, string $profileName, string $rawPayload): void
    {
        $wamid     = $msg['id'] ?? '';
        $fromPhone = $msg['from'] ?? '';
        $type      = $msg['type'] ?? '';

        writeWhatsAppLog('CUSTOMER_MESSAGE', "Message from: " . $fromPhone . " (" . $profileName . ") [Type: " . $type . "]");

        if ($wamid === '' || $fromPhone === '') {
            writeWhatsAppLog('MESSAGE_SKIPPED', "Skipped due to empty WAMID or phone number");
            return;
        }

        // Check for duplicate wamid
        if ($this->isDuplicate($conn, $wamid)) {
            writeWhatsAppLog('DUPLICATE_SKIPPED', "Skipped duplicate WAMID: " . $wamid);
            return;
        }

        $messageText = $this->extractMessageText($msg);
        $logId = $this->insertLog(
            $conn,
            $wamid,
            $fromPhone,
            $profileName,
            $messageText,
            ['success' => true, 'data' => ['message_type' => $type], 'errors' => []],
            $type,
            $rawPayload,
            'received'
        );

        $flowService = new WhatsAppInteractiveFlowService($conn);

        // Handle Interactive List / Button responses from Meta
        if ($type === 'interactive') {
            $interactive = $msg['interactive'] ?? [];
            $interactiveType = $interactive['type'] ?? '';

            if ($interactiveType === 'list_reply') {
                $listReply = $interactive['list_reply'] ?? [];
                writeWhatsAppLog('INTERACTIVE_LIST_TAP', "Customer tapped list item ID: " . ($listReply['id'] ?? ''));
                $flowService->handleCustomerMessage($fromPhone, $profileName, 'interactive_list', $listReply);
                return;
            }

            if ($interactiveType === 'button_reply') {
                $btnReply = $interactive['button_reply'] ?? [];
                writeWhatsAppLog('INTERACTIVE_BUTTON_TAP', "Customer tapped button ID: " . ($btnReply['id'] ?? ''));
                $flowService->handleCustomerMessage($fromPhone, $profileName, 'interactive_button', $btnReply);
                return;
            }
        }

        // Handle Text Messages
        if ($type === 'text') {
            if ($messageText === '') return;

            // If message is structured multi-line order template (contains "Products:"), run Direct Parser
            if (stripos($messageText, 'Products:') !== false) {
                $parseResult = WhatsAppParserService::parse($messageText, $fromPhone, $profileName);
                $this->updateLogParsedData($conn, $logId, $parseResult['data'] ?? []);

                if ($parseResult['success']) {
                    $orderService = new OrderWhatsAppService($conn);
                    $orderResult  = $orderService->createOrderFromWhatsApp($parseResult['data'], $wamid, $fromPhone, $profileName, $messageText);
                    if ($orderResult['success']) {
                        WhatsAppMessagingService::sendSuccessReply($fromPhone, $profileName, [
                            'order_id'     => $orderResult['order_id'],
                            'order_number' => $orderResult['order_number'],
                            'client_name'  => $parseResult['data']['client_name'] ?? $profileName,
                            'items'        => $orderResult['items'] ?? [],
                            'warnings'     => $orderResult['warnings'] ?? [],
                        ]);
                        $this->updateLog($conn, $logId, 'success', null, $orderResult['order_id'], true, 'OK');
                        return;
                    }
                    $this->updateLog(
                        $conn,
                        $logId,
                        'system_error',
                        (string)($orderResult['message'] ?? 'Order creation failed.'),
                        null,
                        false,
                        null
                    );
                } else {
                    $this->updateLog(
                        $conn,
                        $logId,
                        'parse_error',
                        implode("\n", $parseResult['errors'] ?? ['Unable to parse the message.']),
                        null,
                        false,
                        null
                    );
                }
            }

            // Otherwise, route text to Guided Interactive Session Flow
            try {
                $flowService->handleCustomerMessage($fromPhone, $profileName, 'text', $messageText);
            } catch (Throwable $e) {
                writeWhatsAppLog('FLOW_CRASH', "Exception in handleCustomerMessage: " . $e->getMessage() . " on line " . $e->getLine());
            }
            return;
        }

        writeWhatsAppLog('MESSAGE_SKIPPED', "Unsupported message type: " . $type);
    }

    /**
     * Test Simulation Endpoint (allows testing without Meta account setup)
     */
    public function testSimulation(): void
    {
        global $conn;

        $inputData   = getRequestData();
        $messageText = trim($inputData['message'] ?? $inputData['text'] ?? '');
        $fromPhone   = trim($inputData['phone'] ?? '919876543210');
        $fromName    = trim($inputData['name'] ?? 'Test Client');
        $wamid       = 'simulated-wa-' . md5($fromPhone . time() . rand(100, 999));

        if ($messageText === '') {
            $messageText = "Client Name: Test Client Pvt Ltd\nDelivery Address: 123 Tech Park, Delhi\nOrder Type: Product Order\n\nProducts:\n1. Dengue NS1 Rapid Test | 100 | Kits\n\nRemarks: Simulated test order";
        }

        $parseResult = WhatsAppParserService::parse($messageText, $fromPhone, $fromName);
        $logId       = $this->insertLog($conn, $wamid, $fromPhone, $fromName, $messageText, $parseResult);

        if (!$parseResult['success']) {
            $this->updateLog($conn, $logId, 'parse_error', implode("\n", $parseResult['errors']), null, false, 'Simulated failure');
            apiResponse(false, 'WhatsApp Order Simulation Failed (Parse Error)', [
                'wamid'   => $wamid,
                'errors'  => $parseResult['errors'],
                'parsed'  => $parseResult['data'],
            ]);
        }

        $orderService = new OrderWhatsAppService($conn);
        $orderResult  = $orderService->createOrderFromWhatsApp($parseResult['data'], $wamid, $fromPhone, $fromName, $messageText);

        if ($orderResult['success']) {
            $this->updateLog($conn, $logId, 'success', null, $orderResult['order_id'], true, 'Simulated success reply');
            $this->updateLogParsedData($conn, $logId, $parseResult['data']);

            apiResponse(true, 'WhatsApp Order Simulation Successful', [
                'wamid'        => $wamid,
                'order_id'     => $orderResult['order_id'],
                'order_number' => $orderResult['order_number'],
                'client_name'  => $parseResult['data']['client_name'],
                'items'        => $orderResult['items'],
                'warnings'     => $orderResult['warnings'],
            ]);
        } else {
            $this->updateLog($conn, $logId, 'system_error', $orderResult['message'], null, false, 'Simulated system error');
            apiResponse(false, 'WhatsApp Order Simulation Failed (DB Error)', [
                'wamid'   => $wamid,
                'message' => $orderResult['message'],
            ]);
        }
    }

    private function isDuplicate(mysqli $conn, string $wamid): bool
    {
        $stmt = $conn->prepare("SELECT id FROM whatsapp_order_log WHERE wamid = ? LIMIT 1");
        $stmt->bind_param('s', $wamid);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc() !== null;
        $stmt->close();
        return $exists;
    }

    private function insertLog(
        mysqli $conn,
        string $wamid,
        string $fromPhone,
        string $fromName,
        string $messageText,
        array $parseResult,
        string $messageType = 'text',
        string $rawPayload = '',
        ?string $processingStatus = null
    ): int
    {
        $status = $processingStatus ?? ($parseResult['success'] ? 'success' : 'parse_error');
        $errors = $parseResult['success'] ? null : implode("\n", $parseResult['errors']);
        $json   = json_encode($parseResult['data'], JSON_UNESCAPED_UNICODE);

        $stmt = $conn->prepare(
            "INSERT INTO whatsapp_order_log
             (wamid, from_phone, from_name, message_type, raw_message, raw_payload, parsed_data, processing_status, error_details)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param('sssssssss', $wamid, $fromPhone, $fromName, $messageType, $messageText, $rawPayload, $json, $status, $errors);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        return $id;
    }

    private function extractMessageText(array $message): string
    {
        $type = (string)($message['type'] ?? '');
        if ($type === 'text') {
            return trim((string)($message['text']['body'] ?? ''));
        }
        if ($type === 'interactive') {
            $interactive = is_array($message['interactive'] ?? null) ? $message['interactive'] : [];
            $replyType = (string)($interactive['type'] ?? '');
            $reply = is_array($interactive[$replyType] ?? null) ? $interactive[$replyType] : [];
            return trim((string)($reply['title'] ?? $reply['id'] ?? $replyType));
        }
        if (isset($message[$type]) && is_array($message[$type])) {
            return trim((string)json_encode($message[$type], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
        return $type !== '' ? '[WhatsApp ' . $type . ' message]' : '[WhatsApp message]';
    }

    private function updateLog(mysqli $conn, int $logId, string $status, ?string $errors, ?int $orderId, bool $replySent, ?string $replyStatus): void
    {
        $replySentInt = $replySent ? 1 : 0;
        $stmt = $conn->prepare(
            "UPDATE whatsapp_order_log SET processing_status = ?, error_details = ?, order_id = ?, reply_sent = ?, reply_status = ?, updated_at = NOW() WHERE id = ?"
        );
        $stmt->bind_param('ssiisi', $status, $errors, $orderId, $replySentInt, $replyStatus, $logId);
        $stmt->execute();
        $stmt->close();
    }

    private function updateLogParsedData(mysqli $conn, int $logId, array $parsedData): void
    {
        $json = json_encode($parsedData, JSON_UNESCAPED_UNICODE);
        $stmt = $conn->prepare("UPDATE whatsapp_order_log SET parsed_data = ? WHERE id = ?");
        $stmt->bind_param('si', $json, $logId);
        $stmt->execute();
        $stmt->close();
    }
}
