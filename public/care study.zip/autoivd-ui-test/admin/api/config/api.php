<?php

return [
    'max_limit' => 500,
    'default_limit' => 100,
];