<?php

/**
 * WhatsAppMessagingService
 * 
 * Outbound message sender for Meta WhatsApp Cloud API.
 * Sends confirmation or rejection text messages back to the WhatsApp user.
 * 
 * Part of: WhatsApp-to-Order Processing Pipeline
 */
class WhatsAppMessagingService
{
    /**
     * Send a WhatsApp message to a phone number.
     *
     * @param string $toPhone   Recipient phone number (E.164 format e.g. 919876543210)
     * @param string $message   Message text
     * @return array{success: bool, response: string, error: ?string}
     */
    public static function sendMessage(string $toPhone, string $message): array
    {
        $toPhone = preg_replace('/[^\d]/', '', $toPhone);
        if ($toPhone === '') {
            writeWhatsAppLog('OUTBOUND_ERROR', "Customer phone number is empty");
            return ['success' => false, 'response' => '', 'error' => 'Recipient phone number is empty'];
        }

        $configErrors = WhatsAppConfigService::validateConfig();
        if (!empty($configErrors)) {
            $msg = 'WhatsApp API configuration incomplete: ' . implode('; ', $configErrors);
            self::log('SIMULATED OUTBOUND MESSAGE to ' . $toPhone . ":\n" . $message);
            writeWhatsAppLog('OUTBOUND_SIMULATED', "Configuration incomplete. Simulating reply to " . $toPhone, $msg);
            return [
                'success'  => false,
                'response' => 'SIMULATED (Config missing)',
                'error'    => $msg,
            ];
        }

        $apiUrl      = WhatsAppConfigService::getApiUrl();
        $accessToken = WhatsAppConfigService::getAccessToken();

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $toPhone,
            'type'              => 'text',
            'text'              => [
                'preview_url' => false,
                'body'        => $message,
            ],
        ];

        return self::executeRawApiCall($apiUrl, $accessToken, $payload, $toPhone);
    }

    /**
     * Send an Interactive List Menu message to a WhatsApp user.
     */
    public static function sendInteractiveList(string $toPhone, string $bodyText, string $buttonTitle, array $sections): array
    {
        $toPhone = preg_replace('/[^\d]/', '', $toPhone);
        if ($toPhone === '') {
            return ['success' => false, 'response' => '', 'error' => 'Recipient phone number is empty'];
        }

        $configErrors = WhatsAppConfigService::validateConfig();
        if (!empty($configErrors)) {
            $msg = 'WhatsApp API config incomplete: ' . implode('; ', $configErrors);
            writeWhatsAppLog('CONFIG_ERROR', "Cannot send interactive list menu to {$toPhone}: " . $msg);
            self::log('SIMULATED OUTBOUND LIST to ' . $toPhone . ":\n" . $bodyText);
            return ['success' => false, 'response' => 'SIMULATED', 'error' => $msg];
        }

        $apiUrl      = WhatsAppConfigService::getApiUrl();
        $accessToken = WhatsAppConfigService::getAccessToken();

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $toPhone,
            'type'              => 'interactive',
            'interactive'       => [
                'type'   => 'list',
                'body'   => ['text' => $bodyText],
                'action' => [
                    'button'   => substr($buttonTitle, 0, 20),
                    'sections' => $sections,
                ],
            ],
        ];

        return self::executeRawApiCall($apiUrl, $accessToken, $payload, $toPhone);
    }

    /**
     * Send Interactive Reply Buttons (up to 3 buttons).
     */
    public static function sendInteractiveButtons(string $toPhone, string $bodyText, array $buttons): array
    {
        $toPhone = preg_replace('/[^\d]/', '', $toPhone);
        if ($toPhone === '') {
            return ['success' => false, 'response' => '', 'error' => 'Recipient phone number is empty'];
        }

        $configErrors = WhatsAppConfigService::validateConfig();
        if (!empty($configErrors)) {
            return ['success' => false, 'response' => 'SIMULATED', 'error' => 'Config incomplete'];
        }

        $apiUrl      = WhatsAppConfigService::getApiUrl();
        $accessToken = WhatsAppConfigService::getAccessToken();

        $formattedButtons = [];
        foreach ($buttons as $btn) {
            $formattedButtons[] = [
                'type' => 'reply',
                'reply' => [
                    'id'    => $btn['id'],
                    'title' => substr($btn['title'], 0, 20),
                ],
            ];
        }

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $toPhone,
            'type'              => 'interactive',
            'interactive'       => [
                'type'   => 'button',
                'body'   => ['text' => $bodyText],
                'action' => [
                    'buttons' => $formattedButtons,
                ],
            ],
        ];

        return self::executeRawApiCall($apiUrl, $accessToken, $payload, $toPhone);
    }

    /**
     * Internal helper to execute Meta Graph API CURL requests.
     */
    private static function executeRawApiCall(string $apiUrl, string $accessToken, array $payload, string $toPhone): array
    {
        writeWhatsAppLog('OUTBOUND_REQUEST', "Sending Meta API Payload to " . $toPhone, $payload);

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($error) {
            self::log('CURL ERROR sending WA message to ' . $toPhone . ': ' . $error);
            writeWhatsAppLog('OUTBOUND_ERROR', "CURL Error sending reply to " . $toPhone . ": " . $error);
            return ['success' => false, 'response' => (string)$response, 'error' => $error];
        }

        if ($httpCode >= 200 && $httpCode < 300) {
            self::log('SUCCESS sending WA message to ' . $toPhone);
            writeWhatsAppLog('OUTBOUND_SUCCESS', "Message sent successfully to " . $toPhone . " (HTTP " . $httpCode . ")");
            return ['success' => true, 'response' => (string)$response, 'error' => null];
        }

        $errMsg = "HTTP {$httpCode}: " . $response;
        self::log('API ERROR sending WA message to ' . $toPhone . ': ' . $errMsg);
        writeWhatsAppLog('OUTBOUND_API_ERROR', "Meta API Error for " . $toPhone . " (HTTP " . $httpCode . ")", $response);
        return ['success' => false, 'response' => (string)$response, 'error' => $errMsg];
    }

    /**
     * Format and send order success confirmation WhatsApp reply.
     */
    public static function sendSuccessReply(string $toPhone, string $toName, array $orderData): array
    {
        $orderNumber = $orderData['order_number'] ?? 'N/A';
        $clientName  = $orderData['client_name'] ?? $toName;
        $items       = $orderData['items'] ?? [];

        $msg  = "✅ *Order Received Successfully!*\n\n";
        $msg .= "Dear *{$clientName}*,\n";
        $msg .= "Thank you for your order. We have registered it in our system.\n\n";
        $msg .= "📦 *Order Number:* `#{$orderNumber}`\n\n";

        if (!empty($items)) {
            $msg .= "*Order Items:*\n";
            foreach ($items as $idx => $item) {
                $num  = $idx + 1;
                $pname = $item['product_name'] ?? '';
                $qty   = number_format($item['quantity'] ?? 0, 0);
                $msg .= "{$num}. {$pname} — Qty: {$qty}\n";
            }
            $msg .= "\n";
        }

        if (!empty($orderData['warnings'])) {
            $msg .= "⚠️ *Notes:*\n";
            foreach ($orderData['warnings'] as $w) {
                $msg .= "• {$w}\n";
            }
            $msg .= "\n";
        }

        $msg .= "Our team will process your order shortly. Thank you for choosing Biogenix IVD!";

        return self::sendMessage($toPhone, $msg);
    }

    /**
     * Format and send order failure WhatsApp reply with template guide.
     */
    public static function sendFailureReply(string $toPhone, string $toName, array $errorData): array
    {
        $errors = $errorData['errors'] ?? [];

        $msg  = "⚠️ *Order Could Not Be Processed*\n\n";
        $msg .= "We received your order message, but some required details were missing or invalid:\n\n";

        foreach ($errors as $err) {
            $msg .= "❌ {$err}\n";
        }

        $msg .= "\n-----------------------------\n";
        $msg .= "📝 *Please re-send using this template:*\n\n";
        $msg .= "Client Name: [Your Company Name]\n";
        $msg .= "Delivery Address: [Address]\n";
        $msg .= "Order Type: Product Order\n";
        $msg .= "Payment Terms: Credit\n";
        $msg .= "Dispatch Timeline: Immediate\n\n";
        $msg .= "Products:\n";
        $msg .= "1. [Product Name] | [Quantity] | [Unit]\n";
        $msg .= "2. [Product Name] | [Quantity] | [Unit]\n\n";
        $msg .= "Remarks: [Special instructions]\n";
        $msg .= "-----------------------------\n\n";
        $msg .= "Please correct the message and send again. Thank you!";

        return self::sendMessage($toPhone, $msg);
    }

    private static function log(string $message): void
    {
        $logFile = __DIR__ . '/../logs/whatsapp_orders.log';
        $entry   = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
        @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    }
}
