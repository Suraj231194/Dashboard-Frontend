<?php

/**
 * WhatsAppParserService
 * 
 * Parses incoming WhatsApp message text into structured order data.
 * Supports template key-value extraction and product line parsing.
 * 
 * Part of: WhatsApp-to-Order Processing Pipeline
 */
class WhatsAppParserService
{
    /**
     * Parse a WhatsApp message string into structured order data.
     *
     * @param string $messageText Raw text received from WhatsApp
     * @param string $fromPhone   Sender phone number
     * @param string $fromName    Sender WhatsApp profile name
     * @return array{success: bool, data: array, errors: string[], warnings: string[]}
     */
    public static function parse(string $messageText, string $fromPhone = '', string $fromName = ''): array
    {
        $errors   = [];
        $warnings = [];
        $data     = [
            'client_name'       => '',
            'delivery_address'  => '',
            'order_type'        => 1,   // Default: Product Order
            'payment_status'    => 2,   // Default: Credit
            'dispatch_timeline' => 1,   // Default: Immediate
            'area_city'         => '',
            'remarks'           => '',
            'items'             => [],
        ];

        // Normalise line endings
        $body = str_replace(["\r\n", "\r"], "\n", $messageText);

        // ── Step 1: Extract key-value fields ──
        $data['client_name']      = self::extractField($body, ['Client Name', 'Company Name', 'Customer Name', 'Client', 'Name']);
        $data['delivery_address'] = self::extractField($body, ['Delivery Address', 'Address', 'Ship To', 'Shipping Address', 'Location']);
        $data['area_city']        = self::extractField($body, ['Area', 'City', 'Area/City']);
        $data['remarks']          = self::extractField($body, ['Remarks', 'Remark', 'Note', 'Notes', 'Comments', 'Comment']);

        // Order Type mapping
        $orderTypeRaw = self::extractField($body, ['Order Type', 'Type']);
        if ($orderTypeRaw !== '') {
            $data['order_type'] = self::mapOrderType($orderTypeRaw);
        }

        // Payment Terms mapping
        $paymentRaw = self::extractField($body, ['Payment Terms', 'Payment', 'Payment Status', 'Payment Mode']);
        if ($paymentRaw !== '') {
            $data['payment_status'] = self::mapPaymentStatus($paymentRaw);
        }

        // Dispatch Timeline mapping
        $dispatchRaw = self::extractField($body, ['Dispatch Timeline', 'Dispatch', 'Timeline', 'Delivery Timeline']);
        if ($dispatchRaw !== '') {
            $data['dispatch_timeline'] = self::mapDispatchTimeline($dispatchRaw);
        }

        // ── Step 2: Fallback client name ──
        if ($data['client_name'] === '') {
            $data['client_name'] = trim($fromName);
        }
        if ($data['client_name'] === '') {
            $data['client_name'] = 'WhatsApp Customer (' . trim($fromPhone) . ')';
        }

        // ── Step 3: Extract product items ──
        $data['items'] = self::extractProductItems($body);

        // ── Step 4: Validate required fields ──
        if (trim($data['client_name']) === '') {
            $errors[] = 'Client Name is missing. Please include "Client Name: Your Company Name" in your message.';
        }

        if (empty($data['items'])) {
            $errors[] = 'No product items found. Please include a "Products:" list in format: "Product Name | Quantity | Unit"';
        } else {
            foreach ($data['items'] as $idx => $item) {
                $lineNum = $idx + 1;
                if (trim($item['product_name'] ?? '') === '') {
                    $errors[] = "Product line #{$lineNum}: Product name is empty.";
                }
                if (($item['quantity'] ?? 0) <= 0) {
                    $errors[] = "Product line #{$lineNum} ({$item['product_name']}): Quantity must be a positive number.";
                }
            }
        }

        if ($data['delivery_address'] === '') {
            $warnings[] = 'Delivery address was not provided in message.';
        }

        return [
            'success'  => empty($errors),
            'data'     => $data,
            'errors'   => $errors,
            'warnings' => $warnings,
        ];
    }

    private static function extractField(string $body, array $labels): string
    {
        foreach ($labels as $label) {
            $escaped = preg_quote($label, '/');
            if (preg_match('/^' . $escaped . '\s*[:]\s*(.+?)(?=\n\s*\n|\n[A-Za-z][\w\s\/]*\s*:|$)/ims', $body, $match)) {
                $value = trim($match[1]);
                $value = preg_replace('/\s*\n\s*/', ' ', $value);
                if ($value !== '') {
                    return $value;
                }
            }
        }
        return '';
    }

    private static function extractProductItems(string $body): array
    {
        $items = [];

        // Find "Products:" or "Items:" section
        $productSectionPattern = '/(?:Products?|Items?|Order Items?|Order Details?)\s*:\s*\n(.*?)(?=\n\s*\n(?:[A-Za-z][\w\s\/]*\s*:)|$)/is';
        if (!preg_match($productSectionPattern, $body, $sectionMatch)) {
            return self::extractFallbackItems($body);
        }

        $section = trim($sectionMatch[1]);
        $lines   = explode("\n", $section);

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;

            // Strip leading bullets/numbers
            $line = preg_replace('/^[\d]+[.)]\s*/', '', $line);
            $line = preg_replace('/^[-*•]\s*/', '', $line);
            $line = trim($line);
            if ($line === '') continue;

            $item = self::parseProductLine($line);
            if ($item !== null) {
                $items[] = $item;
            }
        }

        return $items;
    }

    private static function parseProductLine(string $line): ?array
    {
        // Format 1: "Product Name | Quantity | Unit"
        if (strpos($line, '|') !== false) {
            $parts = array_map('trim', explode('|', $line));
            if (count($parts) >= 2) {
                return [
                    'product_name' => $parts[0],
                    'quantity'     => self::parseQuantity($parts[1]),
                    'unit_text'    => $parts[2] ?? '',
                    'order_remark' => $parts[3] ?? '',
                ];
            }
        }

        // Format 2: "Product Name, Quantity, Unit"
        if (substr_count($line, ',') >= 1) {
            $parts = array_map('trim', explode(',', $line));
            if (count($parts) >= 2 && is_numeric(trim(preg_replace('/[^\d.]/', '', $parts[1])))) {
                return [
                    'product_name' => $parts[0],
                    'quantity'     => self::parseQuantity($parts[1]),
                    'unit_text'    => $parts[2] ?? '',
                    'order_remark' => $parts[3] ?? '',
                ];
            }
        }

        // Format 3: "Product Name - Quantity Unit"
        if (preg_match('/^(.+?)\s*[-–]\s*(\d+(?:\.\d+)?)\s*(.*)$/', $line, $m)) {
            return [
                'product_name' => trim($m[1]),
                'quantity'     => (float) $m[2],
                'unit_text'    => trim($m[3]),
                'order_remark' => '',
            ];
        }

        // Format 4: "Product Name  500  Kits"
        if (preg_match('/^(.+?)\s{2,}(\d+(?:\.\d+)?)\s*(.*)$/', $line, $m)) {
            return [
                'product_name' => trim($m[1]),
                'quantity'     => (float) $m[2],
                'unit_text'    => trim($m[3]),
                'order_remark' => '',
            ];
        }

        if (strlen($line) > 2) {
            return [
                'product_name' => $line,
                'quantity'     => 0,
                'unit_text'    => '',
                'order_remark' => 'Could not auto-parse quantity/unit from this line',
            ];
        }

        return null;
    }

    private static function extractFallbackItems(string $body): array
    {
        $items = [];
        if (preg_match_all('/^\s*\d+[.)]\s*(.+)$/m', $body, $matches)) {
            foreach ($matches[1] as $line) {
                $line = trim($line);
                if (strlen($line) < 3) continue;
                $item = self::parseProductLine($line);
                if ($item !== null) {
                    $items[] = $item;
                }
            }
        }
        return $items;
    }

    private static function parseQuantity(string $raw): float
    {
        $raw = trim($raw);
        $cleaned = preg_replace('/[^\d.,]/', '', $raw);
        $cleaned = str_replace(',', '', $cleaned);
        return (float) $cleaned;
    }

    private static function mapOrderType(string $text): int
    {
        $text = strtolower(trim($text));
        $map = [
            'product order'         => 1,
            'product'               => 1,
            'sample request'        => 2,
            'sample'                => 2,
            'tender supply'         => 3,
            'tender'                => 3,
            'instrument dispatched' => 4,
            'instrument'            => 4,
            'amc'                   => 5,
            'cmc'                   => 5,
            'service'               => 5,
            'amc/cmc/service'       => 5,
            'other'                 => 6,
        ];
        return $map[$text] ?? 1;
    }

    private static function mapPaymentStatus(string $text): int
    {
        $text = strtolower(trim($text));
        $map = [
            'paid'              => 1,
            'paid in advance'   => 1,
            'advance'           => 1,
            'credit'            => 2,
            'credit order'      => 2,
            'payment pending'   => 3,
            'pending'           => 3,
            'other'             => 4,
        ];
        return $map[$text] ?? 2;
    }

    private static function mapDispatchTimeline(string $text): int
    {
        $text = strtolower(trim($text));
        $map = [
            'immediate'  => 1,
            'urgent'     => 1,
            'asap'       => 1,
            '1 week'     => 2,
            'one week'   => 2,
            'next week'  => 3,
            'flexible'   => 4,
            'no rush'    => 4,
        ];
        return $map[$text] ?? 1;
    }
}
