<?php

declare(strict_types=1);

/**
 * EmailOrderLogger — Daily File Logging Engine for Email-to-Order Processing
 *
 * Generates per-day log files inside the admin/emailOrderLogs directory.
 * Modeled after admin/syncLogs/SyncLogger.php for system consistency.
 *
 * Example file paths:
 *   - admin/emailOrderLogs/email_orders_2026-09-07.log
 *   - admin/emailOrderLogs/email_orders_2026-09-08.log
 *
 * Part of: Email-to-Order Processing Pipeline
 */
class EmailOrderLogger
{
    /**
     * Write an entry into the daily email order log file.
     *
     * @param string      $eventType    e.g. 'POLL_START', 'EMAIL_RECEIVED', 'DRAFT_CREATED', 'CONFIRMATION_RECEIVED', 'ORDER_CONFIRMED', 'VALIDATION_ERROR', 'PARSE_ERROR', 'ERROR'
     * @param string      $message      Human-readable summary message
     * @param mixed|null  $extraDetails Optional structured payload, items array, or error details
     */
    public static function write(string $eventType, string $message, $extraDetails = null): void
    {
        $logFolder = dirname(__DIR__, 2) . '/emailOrderLogs';
        if (!is_dir($logFolder)) {
            @mkdir($logFolder, 0777, true);
        }

        $dateStr = date('Y-m-d');
        $logFile = $logFolder . '/email_orders_' . $dateStr . '.log';
        $currentTime = date('Y-m-d H:i:s');

        $entry = "[" . $currentTime . "] [" . strtoupper($eventType) . "] " . $message . PHP_EOL;

        if ($extraDetails !== null) {
            if (is_array($extraDetails) || is_object($extraDetails)) {
                $entry .= json_encode($extraDetails, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL;
            } else {
                $entry .= (string) $extraDetails . PHP_EOL;
            }
        }

        @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    }
}

if (!function_exists('writeEmailOrderLog')) {
    /**
     * Global helper function to write to the daily email order log.
     */
    function writeEmailOrderLog(string $eventType, string $message, $extraDetails = null): void
    {
        EmailOrderLogger::write($eventType, $message, $extraDetails);
    }
}
