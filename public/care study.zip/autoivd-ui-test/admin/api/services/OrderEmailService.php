<?php

declare(strict_types=1);

require_once __DIR__ . '/EmailOrderLogger.php';

/**
 * OrderEmailService
 * 
 * Orchestrator for the email-to-order pipeline.
 * Implements strict product matching, two-phase confirmation drafts,
 * and order insertion into the ERP.
 * 
 * Strict Product Verification Rules:
 *   - Every single item in the order email MUST match a valid, active catalog product.
 *   - If any product cannot be resolved, NO order is created (draft or final);
 *     the system rejects the order and sends the official Product Catalog Excel.
 *   - NO record in `order_received_items` will ever have `product_id = NULL`.
 * 
 * Two-Phase Confirmation Workflow:
 *   1. Initial Email -> Parse -> Validate & Resolve Products
 *   2. If valid -> Save order draft in `email_order_drafts` -> Send verification email asking for "YES"
 *   3. Customer replies "YES" -> System locates draft -> Creates order in `order_received` & `order_received_items` -> Sends Order Confirmation.
 * 
 * Part of: Email-to-Order Processing Pipeline
 */
class OrderEmailService
{
    private mysqli $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    /**
     * Resolve a raw product name string to a catalog product.
     * Uses 3-tier matching:
     *   1. Exact match (case-sensitive)
     *   2. Case-insensitive exact match
     *   3. Smart normalized token matching with finished goods boost & component penalty
     *
     * @param string $rawName Customer-provided product name
     * @return array{id: int, product_name: string, unit_id: int, unit_name: string, match_type: string}|null
     */
    public function resolveProduct(string $rawName): ?array
    {
        $rawName = trim($rawName);
        if ($rawName === '') {
            return null;
        }

        // ── Tier 1: Exact match ──
        $stmt = $this->conn->prepare(
            "SELECT p.id, p.product_name, p.unit_id, COALESCE(u.short_name, 'Unit') AS unit_name
             FROM products p
             LEFT JOIN standard_units u ON p.unit_id = u.id
             WHERE p.product_name = ? AND p.status = 1 AND p.deleted_at IS NULL LIMIT 1"
        );
        $stmt->bind_param('s', $rawName);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($res) {
            return [
                'id'           => (int) $res['id'],
                'product_name' => $res['product_name'],
                'unit_id'      => (int) ($res['unit_id'] ?? 1),
                'unit_name'    => $res['unit_name'] ?? 'Unit',
                'match_type'   => 'exact',
            ];
        }

        // ── Tier 2: Case-insensitive exact match ──
        $stmt = $this->conn->prepare(
            "SELECT p.id, p.product_name, p.unit_id, COALESCE(u.short_name, 'Unit') AS unit_name
             FROM products p
             LEFT JOIN standard_units u ON p.unit_id = u.id
             WHERE LOWER(p.product_name) = LOWER(?) AND p.status = 1 AND p.deleted_at IS NULL LIMIT 1"
        );
        $stmt->bind_param('s', $rawName);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($res) {
            return [
                'id'           => (int) $res['id'],
                'product_name' => $res['product_name'],
                'unit_id'      => (int) ($res['unit_id'] ?? 1),
                'unit_name'    => $res['unit_name'] ?? 'Unit',
                'match_type'   => 'case_insensitive',
            ];
        }

        // ── Tier 3: Smart normalized keyword matching ──
        $cleanInput = preg_replace('/[^a-zA-Z0-9\s]/', ' ', strtolower($rawName));
        $words = array_filter(explode(' ', $cleanInput), function ($w) {
            return strlen($w) >= 2;
        });

        // Common medical/packaging filler words that customers frequently add/omit
        $filler = ['antigen', 'ag', 'rapid', 'test', 'tests', 'card', 'cards', 'kit', 'kits', 'detection', 'device', 'for', 'with', 'the', 'and'];
        $coreWords = array_values(array_diff($words, $filler));
        if (empty($coreWords)) {
            $coreWords = array_values($words);
        }

        if (empty($coreWords)) {
            return null;
        }

        // Build SQL query matching all core words
        $whereParts = ["p.status = 1", "p.deleted_at IS NULL"];
        $types = '';
        $params = [];
        foreach ($coreWords as $cw) {
            $whereParts[] = "LOWER(p.product_name) LIKE ?";
            $types .= 's';
            $params[] = '%' . $cw . '%';
        }

        $sql = "SELECT p.id, p.product_name, p.unit_id, COALESCE(u.short_name, 'Unit') AS unit_name
                FROM products p
                LEFT JOIN standard_units u ON p.unit_id = u.id
                WHERE " . implode(' AND ', $whereParts);

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $candidates = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        if (empty($candidates)) {
            return null;
        }

        // Score candidates:
        // Favor finished rapid test kits over raw materials/packaging (cassettes, pouches, boxes, sheets, buffers)
        $negativeKeywords = ['cassette', 'pouch', 'box', 'boxes', 'antibody', 'uncut', 'sheet', 'buffer', 'holder', 'shipper', 'insert', 'laminate', 'coating', 'conjugation'];
        $scored = [];

        foreach ($candidates as $cand) {
            $candNameLower = strtolower($cand['product_name']);
            $score = 100;

            // Penalize raw materials / packaging components
            foreach ($negativeKeywords as $neg) {
                if (str_contains($candNameLower, $neg)) {
                    $score -= 30;
                }
            }

            // Boost if matches "rapid test" or "test"
            if (str_contains($candNameLower, 'rapid test')) {
                $score += 40;
            } elseif (str_contains($candNameLower, 'test')) {
                $score += 20;
            }

            // Normalize strings and check core token equality
            $candNorm = trim(preg_replace('/\s+/', ' ', preg_replace('/[^a-z0-9]/', ' ', $candNameLower)));
            $queryNorm = trim(preg_replace('/\s+/', ' ', preg_replace('/[^a-z0-9]/', ' ', strtolower($rawName))));

            $candCore = trim(preg_replace('/\b(' . implode('|', $filler) . ')\b/', ' ', $candNorm));
            $candCore = trim(preg_replace('/\s+/', ' ', $candCore));
            $queryCore = trim(preg_replace('/\b(' . implode('|', $filler) . ')\b/', ' ', $queryNorm));
            $queryCore = trim(preg_replace('/\s+/', ' ', $queryCore));

            if ($candCore !== '' && $candCore === $queryCore) {
                $score += 100;
            }

            // Length similarity bonus
            $lenDiff = abs(strlen($candNameLower) - strlen($cleanInput));
            $score -= min($lenDiff, 20);

            $scored[] = ['cand' => $cand, 'score' => $score];
        }

        usort($scored, function ($a, $b) {
            return $b['score'] <=> $a['score'];
        });

        // Threshold score: 80
        if ($scored[0]['score'] < 80) {
            return null;
        }

        $best = $scored[0]['cand'];
        return [
            'id'           => (int) $best['id'],
            'product_name' => $best['product_name'],
            'unit_id'      => (int) ($best['unit_id'] ?? 1),
            'unit_name'    => $best['unit_name'] ?? 'Unit',
            'match_type'   => 'smart_keyword',
        ];
    }

    /**
     * Strictly validate the parsed email and resolve all product items.
     * Fails if any item cannot be matched to a catalog product or quantity <= 0.
     *
     * @param array  $parsedData Output from EmailParserService::parse()['data']
     * @param string $fromEmail  Sender email
     * @param string $fromName   Sender display name
     * @return array{valid: bool, errors: string[], warnings: string[], resolved_items: array, order_data: array}
     */
    public function validateAndResolveOrder(array $parsedData, string $fromEmail, string $fromName): array
    {
        $errors   = [];
        $warnings = [];

        $clientName = trim($parsedData['client_name'] ?? ($fromName ?: $fromEmail));
        if ($clientName === '') {
            $errors[] = 'Client / Company name is missing from the order.';
        }

        $rawItems = $parsedData['items'] ?? [];
        if (empty($rawItems)) {
            $errors[] = 'No product items were detected in the order email.';
            return [
                'valid'          => false,
                'errors'         => $errors,
                'warnings'       => $warnings,
                'resolved_items' => [],
                'order_data'     => [],
            ];
        }

        $resolvedItems = [];

        foreach ($rawItems as $idx => $item) {
            $itemNum     = $idx + 1;
            $rawName     = trim($item['product_name'] ?? '');
            $quantity    = (float) ($item['quantity'] ?? 0);
            $unitText    = trim($item['unit_text'] ?? '');
            $orderRemark = trim($item['order_remark'] ?? '');

            if ($rawName === '') {
                $errors[] = "Item #{$itemNum} has an empty product name.";
                continue;
            }

            if ($quantity <= 0) {
                $errors[] = "Product \"{$rawName}\" (Item #{$itemNum}) has an invalid quantity ({$quantity}). Quantity must be greater than 0.";
                continue;
            }

            // Strictly resolve product from catalog
            $resolved = $this->resolveProduct($rawName);
            if ($resolved === null) {
                $errors[] = "Product \"{$rawName}\" (Item #{$itemNum}) could not be matched with any item in our product catalog. Please refer to the attached Product Catalog Excel for official names.";
                continue;
            }

            // Resolve unit
            $unitId   = $resolved['unit_id'] ?: 1;
            $unitName = $resolved['unit_name'] ?: 'Unit';

            if ($unitText !== '') {
                $customUnitId = $this->resolveUnitId($unitText);
                if ($customUnitId !== null) {
                    $unitId = $customUnitId;
                    $unitName = $this->resolveUnitName($customUnitId);
                }
            }

            if (strcasecmp($resolved['product_name'], $rawName) !== 0) {
                $warnings[] = "Product \"{$rawName}\" was matched to catalog item \"{$resolved['product_name']}\".";
            }

            $resolvedItems[] = [
                'product_id'   => $resolved['id'],
                'product_name' => $resolved['product_name'],
                'raw_name'     => $rawName,
                'quantity'     => $quantity,
                'unit'         => $unitId,
                'unit_name'    => $unitName,
                'order_remark' => $orderRemark ?: 'Received via email',
                'match_type'   => $resolved['match_type'],
            ];
        }

        if (!empty($errors)) {
            return [
                'valid'          => false,
                'errors'         => $errors,
                'warnings'       => $warnings,
                'resolved_items' => [],
                'order_data'     => [],
            ];
        }

        // Resolve Customer Master record
        $matchedCustomer = $this->resolveCustomer($fromEmail, $clientName);
        $customerId = 0;
        $customerAddr = trim($parsedData['delivery_address'] ?? '');
        $areaCity = trim($parsedData['area_city'] ?? '');
        $customerGstin = '';
        $customerPan = '';
        $customerState = '';
        $customerStateCode = '';
        $customerContact = '';
        $customerPhone = '';
        $customerEmail = $fromEmail;

        if ($matchedCustomer) {
            $customerId = (int) $matchedCustomer['id'];
            $clientName = !empty($matchedCustomer['company_name']) ? $matchedCustomer['company_name'] : $matchedCustomer['name'];
            if (empty($areaCity)) {
                $areaCity = $matchedCustomer['city'] ?: ($matchedCustomer['state_province'] ?? '');
            }
            if (empty($customerAddr)) {
                $customerAddr = $matchedCustomer['detailed_address'] ?? '';
            }
            $customerGstin     = $matchedCustomer['gstin'] ?? '';
            $customerPan       = $matchedCustomer['pan'] ?? '';
            $customerState     = $matchedCustomer['state_province'] ?? '';
            $customerStateCode = $matchedCustomer['state_code'] ?? '';
            $customerContact   = $matchedCustomer['contact_person'] ?? '';
            $customerPhone     = $matchedCustomer['phone'] ?? '';
            $customerEmail     = $matchedCustomer['email'] ?: $fromEmail;
        }

        $orderData = [
            'client_name'                      => $clientName,
            'customer_id'                      => $customerId,
            'delivery_address'                 => $customerAddr,
            'area_city'                        => $areaCity,
            'order_type'                       => (int) ($parsedData['order_type'] ?? 1),
            'payment_status'                   => (int) ($parsedData['payment_status'] ?? 2),
            'dispatch_timeline'                => (int) ($parsedData['dispatch_timeline'] ?? 1),
            'customer_address_snapshot'        => $customerAddr,
            'customer_gstin_snapshot'          => $customerGstin,
            'customer_pan_snapshot'            => $customerPan,
            'customer_state_snapshot'          => $customerState,
            'customer_state_code_snapshot'     => $customerStateCode,
            'customer_contact_person_snapshot' => $customerContact,
            'customer_contact_number_snapshot' => $customerPhone,
            'customer_email_snapshot'          => $customerEmail,
            'items'                            => $resolvedItems,
        ];

        return [
            'valid'          => true,
            'errors'         => [],
            'warnings'       => $warnings,
            'resolved_items' => $resolvedItems,
            'order_data'     => $orderData,
        ];
    }

    /**
     * Resolve a customer master record from sender email or client/company name.
     *
     * @param string $fromEmail Sender email
     * @param string $clientName Customer/Company name
     * @return array|null
     */
    public function resolveCustomer(string $fromEmail, string $clientName): ?array
    {
        $fromEmail = strtolower(trim($fromEmail));
        $clientName = trim($clientName);

        // 1. Try matching active customer by email
        if ($fromEmail !== '') {
            $stmt = $this->conn->prepare("SELECT * FROM `customers` WHERE LOWER(email) = ? AND `status` = 1 LIMIT 1");
            if ($stmt) {
                $stmt->bind_param('s', $fromEmail);
                $stmt->execute();
                $cust = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if ($cust) {
                    return $cust;
                }
            }
        }

        // 2. Try matching active customer by company name or name
        if ($clientName !== '') {
            $stmt = $this->conn->prepare("SELECT * FROM `customers` WHERE (LOWER(company_name) = LOWER(?) OR LOWER(name) = LOWER(?)) AND `status` = 1 LIMIT 1");
            if ($stmt) {
                $stmt->bind_param('ss', $clientName, $clientName);
                $stmt->execute();
                $cust = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if ($cust) {
                    return $cust;
                }
            }

            // 3. Try fuzzy/prefix match if company name has variations like "Cortex Diagnostics" vs "Cortex Diagnostics Pvt Ltd"
            $cleaned = preg_replace('/\b(pvt|ltd|private|limited|co|corp|inc|llc)\b/i', '', $clientName);
            $cleaned = trim(preg_replace('/\s+/', ' ', (string) $cleaned));
            if (strlen($cleaned) >= 4) {
                $like = '%' . $cleaned . '%';
                $stmt = $this->conn->prepare("SELECT * FROM `customers` WHERE (company_name LIKE ? OR name LIKE ?) AND `status` = 1 ORDER BY id DESC LIMIT 1");
                if ($stmt) {
                    $stmt->bind_param('ss', $like, $like);
                    $stmt->execute();
                    $cust = $stmt->get_result()->fetch_assoc();
                    $stmt->close();
                    if ($cust) {
                        return $cust;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Create an order draft in `email_order_drafts` awaiting "YES" confirmation.
     *
     * @param array  $validatedData Output from validateAndResolveOrder()
     * @param string $messageId     Initial email Message-ID
     * @param string $fromEmail     Sender email
     * @param string $fromName      Sender display name
     * @param string $subject       Email subject
     * @param string $rawBody       Original email body
     * @return array{success: bool, draft_id: ?int, draft_code: ?string, expires_at: ?string, draft_data: array}
     */
    public function createOrderDraft(
        array  $validatedData,
        string $messageId,
        string $fromEmail,
        string $fromName,
        string $subject,
        string $rawBody
    ): array {
        try {
            $draftCode = 'DRF-' . strtoupper(substr(md5(uniqid((string)mt_rand(), true)), 0, 6));
            $expiresAt = date('Y-m-d H:i:s', strtotime('+48 hours'));

            $orderData = $validatedData['order_data'];
            $payload = array_merge($orderData, [
                'raw_body'        => $rawBody,
                'initial_subject' => $subject,
                'from_email'      => $fromEmail,
                'from_name'       => $fromName,
            ]);
            $payloadJson = json_encode($payload, JSON_UNESCAPED_UNICODE);

            $stmt = $this->conn->prepare(
                "INSERT INTO `email_order_drafts`
                    (`draft_code`, `from_email`, `from_name`, `subject`, `draft_payload`, `status`, `initial_message_id`, `expires_at`, `created_at`)
                VALUES (?, ?, ?, ?, ?, 'pending_confirmation', ?, ?, NOW())"
            );

            $stmt->bind_param(
                'sssssss',
                $draftCode,
                $fromEmail,
                $fromName,
                $subject,
                $payloadJson,
                $messageId,
                $expiresAt
            );

            $stmt->execute();
            $draftId = (int) $stmt->insert_id;
            $stmt->close();

            $draftData = [
                'draft_code'        => $draftCode,
                'client_name'       => $orderData['client_name'],
                'delivery_address'  => $orderData['delivery_address'],
                'area_city'         => $orderData['area_city'],
                'payment_terms'     => $orderData['payment_status'] === 1 ? 'Prepaid' : 'Credit / Net Terms',
                'dispatch_timeline' => $orderData['dispatch_timeline'] === 1 ? 'Standard (24-48 Hours)' : 'Immediate',
                'items'             => $orderData['items'],
                'expires_at'        => date('d M Y, h:i A', strtotime($expiresAt)),
            ];

            EmailOrderLogger::write('DRAFT_CREATED', "Order draft #{$draftCode} created for {$fromEmail}", [
                'client'      => $orderData['client_name'],
                'items_count' => count($orderData['items']),
                'expires_at'  => $expiresAt,
            ]);

            return [
                'success'    => true,
                'draft_id'   => $draftId,
                'draft_code' => $draftCode,
                'expires_at' => $expiresAt,
                'draft_data' => $draftData,
            ];
        } catch (Throwable $e) {
            self::logError('CREATE DRAFT ERROR: ' . $e->getMessage());
            return [
                'success'    => false,
                'draft_id'   => null,
                'draft_code' => null,
                'expires_at' => null,
                'draft_data' => [],
            ];
        }
    }

    /**
     * Find a pending order draft for the given sender email or draft code.
     *
     * @param string      $fromEmail Sender email
     * @param string|null $draftCode Optional draft code (e.g. 'DRF-A1B2C3')
     * @return array|null
     */
    public function findPendingDraftForSender(string $fromEmail, ?string $draftCode = null): ?array
    {
        $fromEmail = strtolower(trim($fromEmail));

        // 1. Try draft code match first if present
        if ($draftCode !== null && $draftCode !== '') {
            $stmt = $this->conn->prepare(
                "SELECT * FROM `email_order_drafts`
                 WHERE draft_code = ? AND status = 'pending_confirmation' AND expires_at > NOW()
                 LIMIT 1"
            );
            $stmt->bind_param('s', $draftCode);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($row) {
                $row['payload'] = json_decode($row['draft_payload'], true) ?: [];
                return $row;
            }
        }

        // 2. Fall back to latest pending draft for sender email
        $stmt = $this->conn->prepare(
            "SELECT * FROM `email_order_drafts`
             WHERE LOWER(from_email) = ? AND status = 'pending_confirmation' AND expires_at > NOW()
             ORDER BY id DESC LIMIT 1"
        );
        $stmt->bind_param('s', $fromEmail);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($row) {
            $row['payload'] = json_decode($row['draft_payload'], true) ?: [];
            return $row;
        }

        return null;
    }

    /**
     * Confirm a pending draft and insert the final order into `order_received` & `order_received_items`.
     *
     * @param int    $draftId               ID in `email_order_drafts`
     * @param string $confirmationMessageId RFC Message-ID of the "YES" confirmation email
     * @return array{success: bool, order_id: ?int, order_number: ?string, client_name: string, items: array, warnings: string[], message: string}
     */
    public function confirmDraftAndCreateOrder(int $draftId, string $confirmationMessageId): array
    {
        $this->conn->begin_transaction();

        try {
            // Lock draft row
            $stmt = $this->conn->prepare("SELECT * FROM `email_order_drafts` WHERE id = ? FOR UPDATE");
            $stmt->bind_param('i', $draftId);
            $stmt->execute();
            $draft = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$draft) {
                $this->conn->rollback();
                return [
                    'success'      => false,
                    'order_id'     => null,
                    'order_number' => null,
                    'client_name'  => '',
                    'items'        => [],
                    'warnings'     => [],
                    'message'      => 'Draft not found.',
                ];
            }

            if ($draft['status'] !== 'pending_confirmation') {
                $this->conn->rollback();
                return [
                    'success'      => false,
                    'order_id'     => null,
                    'order_number' => null,
                    'client_name'  => '',
                    'items'        => [],
                    'warnings'     => [],
                    'message'      => "Draft #{$draft['draft_code']} is already in status '{$draft['status']}'.",
                ];
            }

            if (strtotime($draft['expires_at']) <= time()) {
                // Mark expired
                $updStmt = $this->conn->prepare("UPDATE `email_order_drafts` SET status = 'expired' WHERE id = ?");
                $updStmt->bind_param('i', $draftId);
                $updStmt->execute();
                $updStmt->close();
                $this->conn->commit();

                return [
                    'success'      => false,
                    'order_id'     => null,
                    'order_number' => null,
                    'client_name'  => '',
                    'items'        => [],
                    'warnings'     => [],
                    'message'      => "Draft #{$draft['draft_code']} expired on {$draft['expires_at']}. Please submit a new order.",
                ];
            }

            $payload = json_decode($draft['draft_payload'], true) ?: [];
            $items   = $payload['items'] ?? [];

            if (empty($items)) {
                $this->conn->rollback();
                return [
                    'success'      => false,
                    'order_id'     => null,
                    'order_number' => null,
                    'client_name'  => '',
                    'items'        => [],
                    'warnings'     => [],
                    'message'      => 'Draft contains no order items.',
                ];
            }

            // Generate official order number
            try {
                $orderNumber = generateOrderCode($this->conn);
            } catch (Throwable $e) {
                $orderNumber = generateAutoStringNumber('EM-');
            }

            $clientName       = $payload['client_name'] ?? $draft['from_name'] ?: $draft['from_email'];
            $deliveryAddress  = $payload['delivery_address'] ?? '';
            $areaCity         = $payload['area_city'] ?? '';
            $orderType        = (int) ($payload['order_type'] ?? 1);
            $paymentStatus    = (int) ($payload['payment_status'] ?? 2);
            $dispatchTimeline = (int) ($payload['dispatch_timeline'] ?? 1);
            $orderValue       = 0.0;
            $sourceType       = 3; // Email
            $status           = 12; // Pending Review
            $createdBy        = 1;  // System user
            $rawBody          = $payload['raw_body'] ?? '';
            $externalRef      = $draft['draft_code'] . ' | ' . $confirmationMessageId;

            $customerId       = (int) ($payload['customer_id'] ?? 0);
            $customerAddr     = $payload['customer_address_snapshot'] ?? $deliveryAddress;
            $customerGstin    = $payload['customer_gstin_snapshot'] ?? '';
            $customerPan      = $payload['customer_pan_snapshot'] ?? '';
            $customerState    = $payload['customer_state_snapshot'] ?? '';
            $customerStateCode= $payload['customer_state_code_snapshot'] ?? '';
            $customerContact  = $payload['customer_contact_person_snapshot'] ?? '';
            $customerPhone    = $payload['customer_contact_number_snapshot'] ?? '';
            $customerEmail    = $payload['customer_email_snapshot'] ?? ($draft['from_email'] ?? '');

            // Fallback customer resolution if not already linked
            if ($customerId <= 0) {
                $matchedCust = $this->resolveCustomer($draft['from_email'] ?? '', $clientName);
                if ($matchedCust) {
                    $customerId        = (int) $matchedCust['id'];
                    $clientName        = !empty($matchedCust['company_name']) ? $matchedCust['company_name'] : $matchedCust['name'];
                    if (empty($areaCity)) {
                        $areaCity = $matchedCust['city'] ?: ($matchedCust['state_province'] ?? '');
                    }
                    if (empty($deliveryAddress)) {
                        $deliveryAddress = $matchedCust['detailed_address'] ?? '';
                    }
                    $customerAddr      = $matchedCust['detailed_address'] ?? '';
                    $customerGstin     = $matchedCust['gstin'] ?? '';
                    $customerPan       = $matchedCust['pan'] ?? '';
                    $customerState     = $matchedCust['state_province'] ?? '';
                    $customerStateCode = $matchedCust['state_code'] ?? '';
                    $customerContact   = $matchedCust['contact_person'] ?? '';
                    $customerPhone     = $matchedCust['phone'] ?? '';
                    $customerEmail     = $matchedCust['email'] ?: ($draft['from_email'] ?? '');
                }
            }

            // Insert into order_received
            $oStmt = $this->conn->prepare(
                "INSERT INTO `order_received`
                    (`order_number`, `source_type`, `external_reference`, `date_order_received`,
                     `client_name`, `area_city`, `delivery_address`, `order_type`, `order_value`,
                     `dispatch_timeline`, `payment_tems_status`, `raw_content`, `status`,
                     `created_by`, `customer_id`, `customer_address_snapshot`, `customer_gstin_snapshot`,
                     `customer_pan_snapshot`, `customer_state_snapshot`, `customer_state_code_snapshot`,
                     `customer_contact_person_snapshot`, `customer_contact_number_snapshot`, `customer_email_snapshot`,
                     `created_at`)
                VALUES (?, ?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
            );

            $oStmt->bind_param(
                'sissssidiiisiiisssssss',
                $orderNumber,
                $sourceType,
                $externalRef,
                $clientName,
                $areaCity,
                $deliveryAddress,
                $orderType,
                $orderValue,
                $dispatchTimeline,
                $paymentStatus,
                $rawBody,
                $status,
                $createdBy,
                $customerId,
                $customerAddr,
                $customerGstin,
                $customerPan,
                $customerState,
                $customerStateCode,
                $customerContact,
                $customerPhone,
                $customerEmail
            );

            $oStmt->execute();
            $orderId = (int) $oStmt->insert_id;
            $oStmt->close();

            // Insert items into order_received_items (strictly non-null product_id)
            $iStmt = $this->conn->prepare(
                "INSERT INTO `order_received_items`
                    (`order_id`, `product_id`, `product_name`, `quantity`, `unit`, `status`, `order_remark`, `created_by`, `created_at`)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"
            );

            foreach ($items as $item) {
                $productId   = (int) ($item['product_id'] ?? 0);
                $productName = $item['product_name'] ?? '';
                $quantity    = (float) ($item['quantity'] ?? 0);
                $unitId      = (int) ($item['unit'] ?? 1);
                $orderRemark = $item['order_remark'] ?? 'Confirmed via email';

                if ($productId <= 0) {
                    throw new RuntimeException("Integrity violation: Order item '{$productName}' missing valid product_id link.");
                }

                $iStmt->bind_param(
                    'iisdissi',
                    $orderId,
                    $productId,
                    $productName,
                    $quantity,
                    $unitId,
                    $status,
                    $orderRemark,
                    $createdBy
                );
                $iStmt->execute();
            }
            $iStmt->close();

            // Update email_order_drafts status to 'confirmed'
            $dUpd = $this->conn->prepare(
                "UPDATE `email_order_drafts`
                 SET status = 'confirmed',
                     order_id = ?,
                     order_number = ?,
                     confirmation_message_id = ?,
                     confirmed_at = NOW()
                 WHERE id = ?"
            );
            $dUpd->bind_param('issi', $orderId, $orderNumber, $confirmationMessageId, $draftId);
            $dUpd->execute();
            $dUpd->close();

            $this->conn->commit();
        } catch (Throwable $e) {
            $this->conn->rollback();
            self::logError('CONFIRM DRAFT ERROR: ' . $e->getMessage());
            return [
                'success'      => false,
                'order_id'     => null,
                'order_number' => null,
                'client_name'  => '',
                'items'        => [],
                'warnings'     => [],
                'message'      => 'Database error while confirming draft: ' . $e->getMessage(),
            ];
        }

        // Email orders remain in Pending Review without reserving stock until approval.

        EmailOrderLogger::write('ORDER_CONFIRMED', "Confirmed draft #{$draft['draft_code']} -> Order #{$orderNumber} (ID {$orderId})", [
            'order_id'     => $orderId,
            'order_number' => $orderNumber,
            'client_name'  => $clientName,
            'items_count'  => count($items),
        ]);

        return [
            'success'      => true,
            'order_id'     => $orderId,
            'order_number' => $orderNumber,
            'client_name'  => $clientName,
            'items'        => $items,
            'warnings'     => [],
            'message'      => 'Order confirmed and successfully created in ERP.',
        ];
    }

    /**
     * Legacy direct order creation method with strict product validation.
     * Enforces that NO product can have product_id = NULL.
     */
    public function createOrderFromEmail(
        array  $parsedData,
        string $messageId,
        string $fromEmail,
        string $fromName,
        string $rawBody
    ): array {
        $validation = $this->validateAndResolveOrder($parsedData, $fromEmail, $fromName);
        if (!$validation['valid']) {
            return [
                'success'      => false,
                'order_id'     => null,
                'order_number' => null,
                'message'      => implode("\n", $validation['errors']),
                'warnings'     => $validation['warnings'],
            ];
        }

        // Create draft and immediately confirm (if called directly)
        $draftRes = $this->createOrderDraft($validation, $messageId, $fromEmail, $fromName, 'Direct Order', $rawBody);
        if (!$draftRes['success']) {
            return [
                'success'      => false,
                'order_id'     => null,
                'order_number' => null,
                'message'      => 'Failed to create order draft.',
                'warnings'     => [],
            ];
        }

        return $this->confirmDraftAndCreateOrder($draftRes['draft_id'], $messageId);
    }

    /**
     * Resolve unit text to a standard_units ID (exact match).
     */
    private function resolveUnitId(string $unitText): ?int
    {
        $unitText = trim($unitText);
        if ($unitText === '') return null;

        $stmt = $this->conn->prepare(
            "SELECT id FROM standard_units WHERE (fullname = ? OR short_name = ?) AND status != 3 LIMIT 1"
        );
        $stmt->bind_param('ss', $unitText, $unitText);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $result ? (int) $result['id'] : null;
    }

    /**
     * Resolve unit name by ID.
     */
    private function resolveUnitName(int $unitId): string
    {
        $stmt = $this->conn->prepare(
            "SELECT COALESCE(short_name, fullname, 'Unit') AS unit_name FROM standard_units WHERE id = ? LIMIT 1"
        );
        $stmt->bind_param('i', $unitId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $res['unit_name'] ?? 'Unit';
    }

    /**
     * Log errors.
     */
    private static function logError(string $message, $extraDetails = null): void
    {
        EmailOrderLogger::write('ERROR', $message, $extraDetails);
        if (function_exists('writeApiLog')) {
            writeApiLog('ORDER_EMAIL: ' . $message);
        } else {
            error_log('[OrderEmailService] ' . $message);
        }
    }
}
