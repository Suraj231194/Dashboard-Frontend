<?php

/**
 * EmailResponderService
 * 
 * Sends response emails (success/failure) using PHPMailer.
 * 
 * Part of: Email-to-Order Processing Pipeline
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

class EmailResponderService
{
    /**
     * Send a success confirmation email.
     *
     * @param string $toEmail     Recipient email address
     * @param string $toName      Recipient display name
     * @param array  $orderData   Order details (order_id, order_number, items, etc.)
     * @return bool
     */
    public static function sendSuccessEmail(string $toEmail, string $toName, array $orderData): bool
    {
        $subject = '✅ Order #' . ($orderData['order_number'] ?? 'N/A') . ' Received — Biogenix IVD';

        $templatePath = __DIR__ . '/../templates/email_order_success.php';
        $body = self::renderTemplate($templatePath, $orderData);

        return self::send($toEmail, $toName, $subject, $body);
    }

    /**
     * Send a failure/rejection email with template guide and optional attached product catalog Excel.
     *
     * @param string      $toEmail            Recipient email address
     * @param string      $toName             Recipient display name
     * @param array       $errorData          Error details (errors, warnings, raw_body, etc.)
     * @param string|null $catalogExcelBinary Optional binary content of Biogenix_Product_Catalog.xlsx
     * @return bool
     */
    public static function sendFailureEmail(string $toEmail, string $toName, array $errorData, ?string $catalogExcelBinary = null): bool
    {
        $subject = '⚠️ Order Could Not Be Processed — Biogenix IVD';

        $templatePath = __DIR__ . '/../templates/email_order_failure.php';
        $body = self::renderTemplate($templatePath, $errorData);

        $attachments = [];
        if (!empty($catalogExcelBinary)) {
            $attachments[] = [
                'string'   => $catalogExcelBinary,
                'name'     => 'Biogenix_Product_Catalog.xlsx',
                'encoding' => 'base64',
                'type'     => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ];
        }

        return self::send($toEmail, $toName, $subject, $body, $attachments);
    }

    /**
     * Send a verification/confirmation request email for a verified order draft.
     * Asks the customer to reply "YES" to formally place the order into the ERP.
     *
     * @param string $toEmail   Recipient email address
     * @param string $toName    Recipient display name
     * @param array  $draftData Verified draft payload (draft_code, client_name, items, etc.)
     * @return bool
     */
    public static function sendDraftConfirmationRequestEmail(string $toEmail, string $toName, array $draftData): bool
    {
        $draftCode = $draftData['draft_code'] ?? 'DRAFT';
        $subject = '📋 Action Required: Please Confirm Your Order [' . $draftCode . '] — Reply YES to Place';

        $templatePath = __DIR__ . '/../templates/email_order_confirm_draft.php';
        $body = self::renderTemplate($templatePath, $draftData);

        return self::send($toEmail, $toName, $subject, $body);
    }

    /**
     * Send a duplicate notification email.
     *
     * @param string $toEmail      Recipient email address
     * @param string $toName       Recipient display name
     * @param string $orderNumber  Existing order number
     * @return bool
     */
    public static function sendDuplicateEmail(string $toEmail, string $toName, string $orderNumber): bool
    {
        $subject = 'ℹ️ Duplicate Order Email — Biogenix IVD';

        $body = self::renderTemplate(__DIR__ . '/../templates/email_order_success.php', [
            'order_number' => $orderNumber,
            'is_duplicate' => true,
            'items'        => [],
        ]);

        return self::send($toEmail, $toName, $subject, $body);
    }

    /**
     * Core send method using PHPMailer with attachment support.
     *
     * @param string $toEmail     Recipient email
     * @param string $toName      Recipient name
     * @param string $subject     Email subject
     * @param string $htmlBody    Rendered HTML body
     * @param array  $attachments List of attachments: [['string' => ..., 'name' => ...], ['path' => ...]]
     * @return bool
     */
    private static function send(string $toEmail, string $toName, string $subject, string $htmlBody, array $attachments = []): bool
    {
        $smtp = EmailConfigService::getSmtpConfig();

        $mail = new PHPMailer(true);

        try {
            // SMTP configuration
            $mail->isSMTP();
            $mail->Host       = $smtp['host'];
            $mail->Port       = $smtp['port'];
            $mail->SMTPAuth   = true;
            $mail->Username   = $smtp['username'];
            $mail->Password   = $smtp['password'];

            if ($smtp['encryption'] === 'ssl') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($smtp['encryption'] === 'tls') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            }

            // Disable strict certificate verification for shared hosting
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true,
                ],
            ];

            // Sender / recipient
            $mail->setFrom($smtp['from_address'], $smtp['from_name']);
            $mail->addAddress($toEmail, $toName);

            // Attachments
            foreach ($attachments as $att) {
                if (!empty($att['string']) && !empty($att['name'])) {
                    $mail->addStringAttachment(
                        $att['string'],
                        $att['name'],
                        $att['encoding'] ?? 'base64',
                        $att['type'] ?? 'application/octet-stream'
                    );
                } elseif (!empty($att['path']) && file_exists($att['path'])) {
                    $mail->addAttachment(
                        $att['path'],
                        $att['name'] ?? basename($att['path'])
                    );
                }
            }

            // Content
            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>', '</tr>'], "\n", $htmlBody));

            $mail->send();
            return true;
        } catch (PHPMailerException $e) {
            self::logError('PHPMailer error: ' . $e->getMessage());
            return false;
        } catch (Throwable $e) {
            self::logError('Email send error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Render a PHP template file with data.
     */
    private static function renderTemplate(string $templatePath, array $data): string
    {
        if (!file_exists($templatePath)) {
            self::logError('Email template not found: ' . $templatePath);
            return '<p>Email template not available.</p>';
        }

        extract($data, EXTR_SKIP);
        ob_start();
        include $templatePath;
        return ob_get_clean();
    }

    /**
     * Log errors to the API log file.
     */
    private static function logError(string $message): void
    {
        Log::error('EMAIL_RESPONDER: ' . $message);
    }
}
