<?php

declare(strict_types=1);

/**
 * ProductCatalogExportService
 *
 * Generates a styled Excel spreadsheet containing all active catalog products.
 * Attached to email order failure responses to help customers order with exact names.
 *
 * Part of: Email-to-Order Processing Pipeline
 */

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

class ProductCatalogExportService
{
    /**
     * Generate in-memory Excel (.xlsx) binary containing the active product catalog.
     *
     * @param mysqli $conn Active database connection
     * @return string Binary contents of the Excel file
     */
    public static function generateExcelBinary(mysqli $conn): string
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Product Catalog');

        // Document properties
        $spreadsheet->getProperties()
            ->setCreator('Biogenix IVD ERP')
            ->setTitle('Biogenix Product Catalog')
            ->setSubject('Official Product Catalog for Email Orders');

        // Title banner (Rows 1-2)
        $sheet->mergeCells('A1:E1');
        $sheet->setCellValue('A1', 'BIOGENIX IVD — OFFICIAL PRODUCT CATALOG FOR EMAIL ORDERS');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(14)->getColor()->setRGB('FFFFFF');
        $sheet->getStyle('A1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1E3A8A');
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getRowDimension(1)->setRowHeight(32);

        $sheet->mergeCells('A2:E2');
        $sheet->setCellValue('A2', 'Please use the exact product names from Column B when submitting orders via email to automatedorders@biogenix.in');
        $sheet->getStyle('A2')->getFont()->setItalic(true)->setSize(10)->getColor()->setRGB('4B5563');
        $sheet->getStyle('A2')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('F3F4F6');
        $sheet->getStyle('A2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getRowDimension(2)->setRowHeight(22);

        // Header Row (Row 4)
        $headers = [
            'A4' => '#',
            'B4' => 'Official Product Name (Use in Email)',
            'C4' => 'Category',
            'D4' => 'Default Unit',
            'E4' => 'Email Order Format Example',
        ];

        foreach ($headers as $cell => $text) {
            $sheet->setCellValue($cell, $text);
        }

        $headerStyle = [
            'font' => [
                'bold'  => true,
                'color' => ['rgb' => 'FFFFFF'],
                'size'  => 11,
            ],
            'fill' => [
                'fillType'   => Fill::FILL_SOLID,
                'startColor' => ['rgb' => '1E40AF'],
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color'       => ['rgb' => 'CBD5E1'],
                ],
            ],
        ];
        $sheet->getStyle('A4:E4')->applyFromArray($headerStyle);
        $sheet->getStyle('A4')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getRowDimension(4)->setRowHeight(26);

        // Fetch products from database
        $sql = "SELECT p.id, p.product_name, COALESCE(c.name, 'General') AS category_name, COALESCE(u.short_name, 'Unit') AS unit_name
                FROM products p
                LEFT JOIN product_categories c ON p.product_category_id = c.id
                LEFT JOIN standard_units u ON p.unit_id = u.id
                WHERE p.status = 1 AND p.deleted_at IS NULL
                ORDER BY p.product_name ASC";

        $result = $conn->query($sql);
        $rowIdx = 5;
        $count = 1;

        if ($result && $result->num_rows > 0) {
            while ($prod = $result->fetch_assoc()) {
                $pName = (string) $prod['product_name'];
                $cName = (string) $prod['category_name'];
                $uName = (string) $prod['unit_name'];
                $sample = "1. {$pName} | 100 | {$uName}";

                $sheet->setCellValue("A{$rowIdx}", $count);
                $sheet->setCellValue("B{$rowIdx}", $pName);
                $sheet->setCellValue("C{$rowIdx}", $cName);
                $sheet->setCellValue("D{$rowIdx}", $uName);
                $sheet->setCellValue("E{$rowIdx}", $sample);

                // Zebra striping
                if ($count % 2 === 0) {
                    $sheet->getStyle("A{$rowIdx}:E{$rowIdx}")->getFill()
                        ->setFillType(Fill::FILL_SOLID)
                        ->getStartColor()->setRGB('F8FAFC');
                }

                $sheet->getStyle("A{$rowIdx}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("D{$rowIdx}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("E{$rowIdx}")->getFont()->getColor()->setRGB('6B7280');

                $sheet->getStyle("A{$rowIdx}:E{$rowIdx}")->getBorders()->getAllBorders()
                    ->setBorderStyle(Border::BORDER_HAIR)
                    ->getColor()->setRGB('E2E8F0');

                $rowIdx++;
                $count++;
            }
        }

        // Auto-fit column widths
        foreach (range('A', 'E') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Freeze header rows
        $sheet->freezePane('A5');

        // Write to in-memory binary
        $writer = new Xlsx($spreadsheet);
        ob_start();
        $writer->save('php://output');
        $binary = ob_get_clean();

        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        return (string) $binary;
    }
}
