<?php

/**
 * EmailParserService
 * 
 * Parses raw email subject + body into structured order data.
 * Supports a defined template format with key-value pairs and
 * a products table section.
 * 
 * Part of: Email-to-Order Processing Pipeline
 */
class EmailParserService
{
    /** Fields that MUST be present for a valid order */
    private const REQUIRED_FIELDS = ['client_name', 'items'];

    /**
     * Parse an email into structured order data.
     *
     * @param string $subject  Email subject line
     * @param string $body     Email plain-text body
     * @param string $fromName Sender display name (fallback for client_name)
     * @param string $fromEmail Sender email address
     * @return array{success: bool, data: array, errors: string[], warnings: string[]}
     */
    public static function parse(string $subject, string $body, string $fromName = '', string $fromEmail = ''): array
    {
        $errors   = [];
        $warnings = [];
        $data     = [
            'client_name'       => '',
            'delivery_address'  => '',
            'order_type'        => 1,   // Default: Product Order
            'payment_status'    => 2,   // Default: Credit
            'dispatch_timeline' => 1,   // Default: Immediate
            'area_city'         => '',
            'remarks'           => '',
            'items'             => [],
        ];

        // Normalise line endings
        $body = str_replace(["\r\n", "\r"], "\n", $body);

        // ── Step 1: Extract key-value fields ──
        $data['client_name']      = self::extractField($body, ['Client Name', 'Company Name', 'Customer Name', 'Name']);
        $data['delivery_address'] = self::extractField($body, ['Delivery Address', 'Address', 'Ship To', 'Shipping Address']);
        $data['area_city']        = self::extractField($body, ['Area', 'City', 'Area/City', 'Location']);
        $data['remarks']          = self::extractField($body, ['Remarks', 'Remark', 'Note', 'Notes', 'Comments', 'Comment']);

        // Order Type mapping
        $orderTypeRaw = self::extractField($body, ['Order Type', 'Type']);
        if ($orderTypeRaw !== '') {
            $data['order_type'] = self::mapOrderType($orderTypeRaw);
        }

        // Payment Terms mapping
        $paymentRaw = self::extractField($body, ['Payment Terms', 'Payment', 'Payment Status', 'Payment Mode']);
        if ($paymentRaw !== '') {
            $data['payment_status'] = self::mapPaymentStatus($paymentRaw);
        }

        // Dispatch Timeline mapping
        $dispatchRaw = self::extractField($body, ['Dispatch Timeline', 'Dispatch', 'Timeline', 'Delivery Timeline', 'Urgency']);
        if ($dispatchRaw !== '') {
            $data['dispatch_timeline'] = self::mapDispatchTimeline($dispatchRaw);
        }

        // ── Step 2: Fallback client name from subject or sender ──
        if ($data['client_name'] === '') {
            // Try to extract from subject like "New Order — ABC Diagnostics"
            if (preg_match('/(?:order|po)\s*(?:from|by|—|-|–)\s*(.+)/i', $subject, $subjectMatch)) {
                $data['client_name'] = trim($subjectMatch[1]);
            }
        }
        if ($data['client_name'] === '') {
            // Use sender display name as last resort
            $data['client_name'] = trim($fromName);
        }

        // ── Step 3: Extract product items ──
        $data['items'] = self::extractProductItems($body);

        // ── Step 4: Validate required fields ──
        if (trim($data['client_name']) === '') {
            $errors[] = 'Client Name is missing. Please include "Client Name: Your Company Name" in your email.';
        }

        if (empty($data['items'])) {
            $errors[] = 'No product items found. Please include a "Products:" section with items in format: "Product Name | Quantity | Unit"';
        } else {
            // Validate each item
            foreach ($data['items'] as $idx => $item) {
                $lineNum = $idx + 1;
                if (trim($item['product_name'] ?? '') === '') {
                    $errors[] = "Product line #{$lineNum}: Product name is empty.";
                }
                if (($item['quantity'] ?? 0) <= 0) {
                    $errors[] = "Product line #{$lineNum} ({$item['product_name']}): Quantity must be a positive number.";
                }
            }
        }

        // Warnings for optional missing fields
        if ($data['delivery_address'] === '') {
            $warnings[] = 'Delivery address was not provided. It can be updated later.';
        }

        return [
            'success'  => empty($errors),
            'data'     => $data,
            'errors'   => $errors,
            'warnings' => $warnings,
        ];
    }

    /**
     * Extract a field value from email body using multiple possible labels.
     */
    private static function extractField(string $body, array $labels): string
    {
        foreach ($labels as $label) {
            $escaped = preg_quote($label, '/');
            // Match "Label: value" or "Label : value" (value continues until next label or blank line)
            if (preg_match('/^' . $escaped . '\s*[:]\s*(.+?)(?=\n\s*\n|\n[A-Za-z][\w\s\/]*\s*:|$)/ims', $body, $match)) {
                $value = trim($match[1]);
                // Clean up multi-line values
                $value = preg_replace('/\s*\n\s*/', ' ', $value);
                if ($value !== '') {
                    return $value;
                }
            }
        }
        return '';
    }

    /**
     * Extract product line items from the email body.
     * 
     * Looks for a "Products:" section and parses lines in formats:
     *   1. Product Name | Quantity | Unit
     *   Product Name, Quantity, Unit
     *   Product Name - Quantity Unit
     *   Product Name   Quantity   Unit
     */
    private static function extractProductItems(string $body): array
    {
        $items = [];

        // Find the "Products:" section
        $productSectionPattern = '/(?:Products?|Items?|Order Items?|Order Details?)\s*:\s*\n(.*?)(?=\n\s*\n(?:[A-Za-z][\w\s\/]*\s*:)|$)/is';
        if (!preg_match($productSectionPattern, $body, $sectionMatch)) {
            // Fallback: try to find numbered lines anywhere in the body
            return self::extractFallbackItems($body);
        }

        $section = trim($sectionMatch[1]);
        $lines   = explode("\n", $section);

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;

            // Strip leading numbering: "1." or "1)" or "-" or "*" or "•"
            $line = preg_replace('/^[\d]+[.)]\s*/', '', $line);
            $line = preg_replace('/^[-*•]\s*/', '', $line);
            $line = trim($line);
            if ($line === '') continue;

            $item = self::parseProductLine($line);
            if ($item !== null) {
                $items[] = $item;
            }
        }

        return $items;
    }

    /**
     * Parse a single product line into structured data.
     */
    private static function parseProductLine(string $line): ?array
    {
        // Format 1: "Product Name | Quantity | Unit"
        if (strpos($line, '|') !== false) {
            $parts = array_map('trim', explode('|', $line));
            if (count($parts) >= 2) {
                return [
                    'product_name' => $parts[0],
                    'quantity'     => self::parseQuantity($parts[1]),
                    'unit_text'    => $parts[2] ?? '',
                    'order_remark' => $parts[3] ?? '',
                ];
            }
        }

        // Format 2: "Product Name, Quantity, Unit"
        if (substr_count($line, ',') >= 1) {
            $parts = array_map('trim', explode(',', $line));
            if (count($parts) >= 2 && is_numeric(trim(preg_replace('/[^\d.]/', '', $parts[1])))) {
                return [
                    'product_name' => $parts[0],
                    'quantity'     => self::parseQuantity($parts[1]),
                    'unit_text'    => $parts[2] ?? '',
                    'order_remark' => $parts[3] ?? '',
                ];
            }
        }

        // Format 3: "Product Name - Quantity Unit" or "Product Name  500 Kits"
        // Try to find quantity at end or after a dash
        if (preg_match('/^(.+?)\s*[-–]\s*(\d+(?:\.\d+)?)\s*(.*)$/', $line, $m)) {
            return [
                'product_name' => trim($m[1]),
                'quantity'     => (float) $m[2],
                'unit_text'    => trim($m[3]),
                'order_remark' => '',
            ];
        }

        // Format 4: "Product Name  500  Kits" (whitespace separated, quantity is numeric)
        if (preg_match('/^(.+?)\s{2,}(\d+(?:\.\d+)?)\s*(.*)$/', $line, $m)) {
            return [
                'product_name' => trim($m[1]),
                'quantity'     => (float) $m[2],
                'unit_text'    => trim($m[3]),
                'order_remark' => '',
            ];
        }

        // Cannot parse — return with defaults for manual review
        if (strlen($line) > 2) {
            return [
                'product_name' => $line,
                'quantity'     => 0,
                'unit_text'    => '',
                'order_remark' => 'Could not auto-parse quantity/unit from this line',
            ];
        }

        return null;
    }

    /**
     * Fallback: try to find numbered product lines anywhere in the body.
     */
    private static function extractFallbackItems(string $body): array
    {
        $items = [];
        // Match numbered lines that look like product entries
        if (preg_match_all('/^\s*\d+[.)]\s*(.+)$/m', $body, $matches)) {
            foreach ($matches[1] as $line) {
                $line = trim($line);
                if (strlen($line) < 3) continue;
                $item = self::parseProductLine($line);
                if ($item !== null) {
                    $items[] = $item;
                }
            }
        }
        return $items;
    }

    /**
     * Parse a quantity string (may contain commas, spaces, etc.)
     */
    private static function parseQuantity(string $raw): float
    {
        $raw = trim($raw);
        // Remove everything except digits, dots, commas
        $cleaned = preg_replace('/[^\d.,]/', '', $raw);
        // Handle comma as thousands separator
        $cleaned = str_replace(',', '', $cleaned);
        return (float) $cleaned;
    }

    /**
     * Map order type text to constant value.
     */
    private static function mapOrderType(string $text): int
    {
        $text = strtolower(trim($text));
        $map = [
            'product order'         => 1,
            'product'               => 1,
            'sample request'        => 2,
            'sample'                => 2,
            'tender supply'         => 3,
            'tender'                => 3,
            'instrument dispatched' => 4,
            'instrument'            => 4,
            'amc'                   => 5,
            'cmc'                   => 5,
            'service'               => 5,
            'amc/cmc/service'       => 5,
            'other'                 => 6,
        ];
        return $map[$text] ?? 1;
    }

    /**
     * Map payment status text to constant value.
     */
    private static function mapPaymentStatus(string $text): int
    {
        $text = strtolower(trim($text));
        $map = [
            'paid'              => 1,
            'paid in advance'   => 1,
            'advance'           => 1,
            'credit'            => 2,
            'credit order'      => 2,
            'payment pending'   => 3,
            'pending'           => 3,
            'other'             => 4,
        ];
        return $map[$text] ?? 2;
    }

    /**
     * Map dispatch timeline text to constant value.
     */
    private static function mapDispatchTimeline(string $text): int
    {
        $text = strtolower(trim($text));
        $map = [
            'immediate'  => 1,
            'urgent'     => 1,
            'asap'       => 1,
            '1 week'     => 2,
            'one week'   => 2,
            'next week'  => 3,
            'flexible'   => 4,
            'no rush'    => 4,
        ];
        return $map[$text] ?? 1;
    }
}
