<?php

/**
 * OrderWhatsAppService
 * 
 * Orchestrator for WhatsApp-to-Order creation.
 * Resolves products, inserts into order_received (source_type = 4)
 * and order_received_items, and triggers auto-stock routing.
 * 
 * Customer Identification Strategy:
 *   - Accepts any WhatsApp sender
 *   - Uses "Client Name" from message, or WhatsApp profile name, or phone number
 * 
 * Product Matching Strategy:
 *   - Exact match against products.product_name
 *   - If unlinked, product_id is set to NULL (saved for manual review)
 * 
 * Part of: WhatsApp-to-Order Processing Pipeline
 */
class OrderWhatsAppService
{
    private mysqli $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    /**
     * Create an order from parsed WhatsApp message data.
     *
     * @param array  $parsedData  Output from WhatsAppParserService::parse()['data']
     * @param string $wamid       WhatsApp Message ID for external reference / deduplication
     * @param string $fromPhone   Sender WhatsApp phone number
     * @param string $fromName    Sender WhatsApp profile display name
     * @param string $rawMessage  Original WhatsApp message body
     * @return array{success: bool, order_id: ?int, order_number: ?string, message: string, warnings: string[], items: array}
     */
    public function createOrderFromWhatsApp(
        array  $parsedData,
        string $wamid,
        string $fromPhone,
        string $fromName,
        string $rawMessage
    ): array {
        $warnings = [];

        // ── Step 1: Generate Order Code ──
        try {
            $orderNumber = generateOrderCode($this->conn);
        } catch (Throwable $e) {
            $orderNumber = generateAutoStringNumber('WA-');
        }

        // ── Step 2: Resolve Product IDs (Exact Match) ──
        $items = $parsedData['items'] ?? [];
        $resolvedItems = [];

        foreach ($items as $item) {
            $productName = trim($item['product_name'] ?? '');
            $quantity    = (float) ($item['quantity'] ?? 0);
            $unitText    = trim($item['unit_text'] ?? '');
            $remark      = trim($item['order_remark'] ?? '');

            if ($productName === '' || $quantity <= 0) {
                continue;
            }

            $productId = null;
            $unitId    = 1; // Default unit

            $pStmt = $this->conn->prepare("SELECT id, unit_id FROM products WHERE product_name = ? AND status = 1 AND deleted_at IS NULL LIMIT 1");
            $pStmt->bind_param('s', $productName);
            $pStmt->execute();
            $pRes = $pStmt->get_result()->fetch_assoc();
            $pStmt->close();

            if ($pRes) {
                $productId = (int) $pRes['id'];
                if (!empty($pRes['unit_id'])) {
                    $unitId = (int) $pRes['unit_id'];
                }
            } else {
                $warnings[] = "Product \"{$productName}\" not found in catalog. Order item saved with name only.";
            }

            if ($unitText !== '') {
                $resolvedUnit = $this->resolveUnitId($unitText);
                if ($resolvedUnit !== null) {
                    $unitId = $resolvedUnit;
                }
            }

            $resolvedItems[] = [
                'product_id'   => $productId,
                'product_name' => $productName,
                'quantity'     => $quantity,
                'unit'         => $unitId,
                'order_remark' => $remark ?: 'Received via WhatsApp',
            ];
        }

        if (empty($resolvedItems)) {
            return [
                'success'      => false,
                'order_id'     => null,
                'order_number' => null,
                'message'      => 'No valid product items could be resolved.',
                'warnings'     => $warnings,
                'items'        => [],
            ];
        }

        // ── Step 3: Prepare Order Fields ──
        $clientName       = trim($parsedData['client_name'] ?? $fromName ?: $fromPhone);
        $deliveryAddress  = trim($parsedData['delivery_address'] ?? '');
        $areaCity         = trim($parsedData['area_city'] ?? '');
        $orderType        = (int) ($parsedData['order_type'] ?? 1);
        $paymentStatus    = (int) ($parsedData['payment_status'] ?? 2);
        $dispatchTimeline = (int) ($parsedData['dispatch_timeline'] ?? 1);
        $orderValue       = 0.0;
        $sourceType       = 4; // WhatsApp
        $status           = 12; // Pending Review
        $createdBy        = 1;  // System user

        // ── Step 4: Database Transaction ──
        $this->conn->begin_transaction();

        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO `order_received`
                    (`order_number`, `source_type`, `external_reference`, `date_order_received`,
                     `client_name`, `area_city`, `delivery_address`, `order_type`, `order_value`,
                     `dispatch_timeline`, `payment_tems_status`, `raw_content`, `status`,
                     `created_by`, `created_at`)
                VALUES (?, ?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
            );

            $stmt->bind_param(
                'sissssidiiisi',
                $orderNumber,
                $sourceType,
                $wamid,            // external_reference = WhatsApp wamid
                $clientName,
                $areaCity,
                $deliveryAddress,
                $orderType,
                $orderValue,
                $dispatchTimeline,
                $paymentStatus,
                $rawMessage,
                $status,
                $createdBy
            );

            $stmt->execute();
            $orderId = $stmt->insert_id;
            $stmt->close();

            // Insert Items
            $itemStmt = $this->conn->prepare(
                "INSERT INTO `order_received_items`
                    (`order_id`, `product_id`, `product_name`, `quantity`, `unit`, `status`, `order_remark`, `created_by`, `created_at`)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"
            );

            foreach ($resolvedItems as $item) {
                $itemStmt->bind_param(
                    'iisdissi',
                    $orderId,
                    $item['product_id'],
                    $item['product_name'],
                    $item['quantity'],
                    $item['unit'],
                    $status,
                    $item['order_remark'],
                    $createdBy
                );
                $itemStmt->execute();
            }
            $itemStmt->close();

            $this->conn->commit();
        } catch (Throwable $e) {
            $this->conn->rollback();
            self::logError('ORDER CREATE ERROR: ' . $e->getMessage());
            return [
                'success'      => false,
                'order_id'     => null,
                'order_number' => null,
                'message'      => 'Database error while creating order: ' . $e->getMessage(),
                'warnings'     => $warnings,
                'items'        => [],
            ];
        }

        // Step 5: Keep the external order in Pending Review until ERP approval.
        $routing = [
            'status' => 'success',
            'action' => 'approval',
            'message' => 'Order is awaiting ERP approval.',
        ];

        return [
            'success'      => true,
            'order_id'     => $orderId,
            'order_number' => $orderNumber,
            'message'      => 'Order created successfully from WhatsApp.',
            'warnings'     => $warnings,
            'routing'      => $routing,
            'items'        => $resolvedItems,
        ];
    }

    private function resolveUnitId(string $unitText): ?int
    {
        $unitText = trim($unitText);
        if ($unitText === '') return null;

        $stmt = $this->conn->prepare(
            "SELECT id FROM standard_units WHERE (fullname = ? OR short_name = ?) AND status != 3 LIMIT 1"
        );
        $stmt->bind_param('ss', $unitText, $unitText);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $result ? (int) $result['id'] : null;
    }

    private static function logError(string $message): void
    {
        if (function_exists('writeApiLog')) {
            writeApiLog('ORDER_WHATSAPP: ' . $message);
        } else {
            error_log('[OrderWhatsAppService] ' . $message);
        }
    }
}
