<?php

/**
 * WhatsAppInteractiveFlowService
 * 
 * Standalone orchestrator for Interactive Category & Search WhatsApp Order Flow.
 * Manages customer session state (whatsapp_sessions), category list menus,
 * product typeahead search, quantity selection, and ERP order placement.
 */
class WhatsAppInteractiveFlowService
{
    private mysqli $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    /**
     * Entry point for processing customer WhatsApp interactions.
     */
    public function handleCustomerMessage(string $fromPhone, string $fromName, string $messageType, mixed $content): void
    {
        $session = $this->getOrCreateSession($fromPhone, $fromName);
        $currentStep = $session['current_step'] ?? 'MAIN_MENU';

        writeWhatsAppLog('FLOW_STEP_START', "Customer: {$fromPhone} ({$fromName}) | Current Step: {$currentStep} | MsgType: {$messageType}");

        // Reset/Restart trigger
        if ($messageType === 'text') {
            $text = strtolower(trim((string)$content));
            if (in_array($text, ['hi', 'hello', 'menu', 'order', 'start', 'restart', '0', 'reset', 'categories'])) {
                writeWhatsAppLog('FLOW_RESTART', "Customer requested flow restart: '{$text}'");
                $this->resetSessionToMainMenu($fromPhone, $fromName);
                $this->sendCategoryMenu($fromPhone, $fromName);
                return;
            }
        }

        // Interactive List responses (Category or Product tap)
        if ($messageType === 'interactive_list') {
            $selectedId = $content['id'] ?? '';
            
            if (str_starts_with($selectedId, 'cat_')) {
                $categoryId = (int)str_replace('cat_', '', $selectedId);
                $this->handleCategorySelected($fromPhone, $fromName, $categoryId);
                return;
            }

            if (str_starts_with($selectedId, 'prod_')) {
                $productId = (int)str_replace('prod_', '', $selectedId);
                $this->handleProductSelected($fromPhone, $fromName, $productId);
                return;
            }
        }

        // Interactive Button replies
        if ($messageType === 'interactive_button') {
            $btnId = $content['id'] ?? '';

            if ($btnId === 'btn_search_product') {
                writeWhatsAppLog('FLOW_BUTTON_TAP', "Customer tapped 'Search Products' button");
                $this->updateSessionStep($fromPhone, 'SEARCH_PRODUCTS', ['selected_category_id' => null]);
                WhatsAppMessagingService::sendMessage($fromPhone, "🔍 *Search Products*\n\nPlease type a product name or keyword (e.g., *Dengue*, *Reagent*, *Covid*):");
                return;
            }

            if ($btnId === 'btn_categories') {
                writeWhatsAppLog('FLOW_BUTTON_TAP', "Customer tapped 'View Categories' button");
                $this->sendCategoryMenu($fromPhone, $fromName);
                return;
            }
        }

        // Text inputs (Quantity or Product search)
        if ($messageType === 'text') {
            $userText = trim((string)$content);

            if ($currentStep === 'AWAITING_QTY') {
                $quantity = (float) preg_replace('/[^\d.]/', '', $userText);
                if ($quantity <= 0) {
                    writeWhatsAppLog('FLOW_QTY_INVALID', "Invalid quantity input: '{$userText}'");
                    WhatsAppMessagingService::sendMessage($fromPhone, "⚠️ Invalid quantity. Please enter a positive number (e.g., *10*, *100*):");
                    return;
                }
                writeWhatsAppLog('FLOW_QTY_ENTERED', "Customer entered quantity: {$quantity}");
                $this->completeOrderCreation($fromPhone, $fromName, $session, $quantity);
                return;
            }

            // Keyword search
            $this->searchAndShowProducts($fromPhone, $userText, $session['selected_category_id']);
            return;
        }

        // Default Fallback
        $this->sendCategoryMenu($fromPhone, $fromName);
    }

    /**
     * Step 1: Send Category Menu to Customer
     */
    public function sendCategoryMenu(string $fromPhone, string $fromName): void
    {
        writeWhatsAppLog('FLOW_SHOW_CATEGORIES', "Sending product categories menu to {$fromPhone}");
        $this->updateSessionStep($fromPhone, 'MAIN_MENU');

        $categories = $this->getActiveCategories();
        if (empty($categories)) {
            writeWhatsAppLog('FLOW_NO_CATEGORIES', "No active categories found in database");
            WhatsAppMessagingService::sendMessage($fromPhone, "Welcome to Biogenix IVD! Please type the product name or keyword you would like to order.");
            return;
        }

        $rows = [];
        foreach (array_slice($categories, 0, 10) as $cat) {
            $rows[] = [
                'id'          => 'cat_' . $cat['id'],
                'title'       => substr($cat['category_name'], 0, 24),
                'description' => 'Browse products in ' . substr($cat['category_name'], 0, 50),
            ];
        }

        $sections = [
            [
                'title' => 'Product Categories',
                'rows'  => $rows,
            ]
        ];

        $bodyText = "👋 Welcome *{$fromName}* to Biogenix IVD Orders!\n\nPlease select a category below, or reply with a product keyword:";
        WhatsAppMessagingService::sendInteractiveList($fromPhone, $bodyText, "Browse Categories", $sections);
    }

    /**
     * Step 2: Handle Category Selection -> Display Products List
     */
    private function handleCategorySelected(string $fromPhone, string $fromName, int $categoryId): void
    {
        writeWhatsAppLog('FLOW_CATEGORY_TAP', "Customer {$fromPhone} selected Category ID #{$categoryId}");
        $this->updateSessionStep($fromPhone, 'CATEGORY_SELECTED', ['selected_category_id' => $categoryId]);

        $products = $this->getProductsByCategory($categoryId);
        if (empty($products)) {
            writeWhatsAppLog('FLOW_NO_PRODUCTS', "No products found for Category ID #{$categoryId}");
            WhatsAppMessagingService::sendInteractiveButtons($fromPhone, "No products found in this category. Would you like to search by keyword?", [
                ['id' => 'btn_search_product', 'title' => '🔍 Search Keyword'],
                ['id' => 'btn_categories', 'title' => '📋 View Categories'],
            ]);
            return;
        }

        $rows = [];
        foreach (array_slice($products, 0, 10) as $prod) {
            $rows[] = [
                'id'          => 'prod_' . $prod['id'],
                'title'       => substr($prod['product_name'], 0, 24),
                'description' => 'Tap to order item',
            ];
        }

        $sections = [
            [
                'title' => 'Available Products',
                'rows'  => $rows,
            ]
        ];

        $bodyText = "📦 *Select a product below to place an order:*";
        WhatsAppMessagingService::sendInteractiveList($fromPhone, $bodyText, "Select Product", $sections);
    }

    /**
     * Step 3: Handle Keyword Search or Typeahead
     */
    private function searchAndShowProducts(string $fromPhone, string $keyword, ?int $categoryId = null): void
    {
        $products = $this->searchProducts($keyword, $categoryId);
        $count = count($products);

        writeWhatsAppLog('FLOW_PRODUCT_SEARCH', "Customer {$fromPhone} searched keyword '{$keyword}' (Found {$count} match)");

        if (empty($products)) {
            WhatsAppMessagingService::sendInteractiveButtons($fromPhone, "🔍 No products found matching \"*{$keyword}*\". Try another keyword or browse categories:", [
                ['id' => 'btn_search_product', 'title' => '🔍 Search Again'],
                ['id' => 'btn_categories', 'title' => '📋 Categories'],
            ]);
            return;
        }

        if (count($products) === 1) {
            writeWhatsAppLog('FLOW_SEARCH_EXACT', "Exact 1 product match for '{$keyword}'. Auto-selecting ID #{$products[0]['id']}");
            $this->handleProductSelected($fromPhone, '', (int)$products[0]['id']);
            return;
        }

        $rows = [];
        foreach (array_slice($products, 0, 10) as $prod) {
            $rows[] = [
                'id'          => 'prod_' . $prod['id'],
                'title'       => substr($prod['product_name'], 0, 24),
                'description' => 'Tap to select',
            ];
        }

        $sections = [
            [
                'title' => 'Matching Products',
                'rows'  => $rows,
            ]
        ];

        $bodyText = "🔍 Found *{$count}* matching product(s). Please select item:";
        WhatsAppMessagingService::sendInteractiveList($fromPhone, $bodyText, "Select Product", $sections);
    }

    /**
     * Step 4: Handle Product Selected -> Ask Quantity
     */
    private function handleProductSelected(string $fromPhone, string $fromName, int $productId): void
    {
        $prod = $this->getProductById($productId);
        if (!$prod) {
            writeWhatsAppLog('FLOW_PRODUCT_ERROR', "Product ID #{$productId} not found in DB");
            WhatsAppMessagingService::sendMessage($fromPhone, "Product not found. Please select from categories.");
            $this->sendCategoryMenu($fromPhone, $fromName);
            return;
        }

        writeWhatsAppLog('FLOW_PRODUCT_SELECTED', "Customer {$fromPhone} selected Product: {$prod['product_name']} (ID #{$productId})");

        $this->updateSessionStep($fromPhone, 'AWAITING_QTY', [
            'selected_product_id'   => $productId,
            'selected_product_name' => $prod['product_name'],
        ]);

        $msg = "✅ *Selected:* {$prod['product_name']}\n\n🔢 *Please type the order quantity:* (e.g., *100*)";
        WhatsAppMessagingService::sendMessage($fromPhone, $msg);
    }

    /**
     * Step 5: Complete Order Creation in ERP
     */
    private function completeOrderCreation(string $fromPhone, string $fromName, array $session, float $quantity): void
    {
        $productId   = (int)($session['selected_product_id'] ?? 0);
        $productName = $session['selected_product_name'] ?? 'Product';
        $wamid       = 'wa-session-' . md5($fromPhone . time() . rand(100, 999));

        writeWhatsAppLog('FLOW_ORDER_CREATION', "Placing ERP order for {$productName} (Qty: {$quantity}) for customer {$fromPhone}");

        $parsedData = [
            'client_name'       => $fromName ?: ('WhatsApp Customer (' . $fromPhone . ')'),
            'delivery_address'  => 'As per customer account',
            'order_type'        => 1,
            'payment_status'    => 2,
            'dispatch_timeline' => 1,
            'remarks'           => 'Placed via WhatsApp Interactive Guided Flow',
            'items'             => [
                [
                    'product_name' => $productName,
                    'quantity'     => $quantity,
                    'unit_text'    => '',
                    'order_remark' => 'Selected via WhatsApp Interactive Menu',
                ]
            ],
        ];

        $orderService = new OrderWhatsAppService($this->conn);
        $orderResult  = $orderService->createOrderFromWhatsApp($parsedData, $wamid, $fromPhone, $fromName, "Interactive Order: {$productName} x {$quantity}");

        writeWhatsAppLog('FLOW_ORDER_RESULT', $orderResult['success'] ? "Order created successfully" : "Order creation failed", $orderResult);

        if ($orderResult['success']) {
            WhatsAppMessagingService::sendSuccessReply($fromPhone, $fromName, [
                'order_id'     => $orderResult['order_id'],
                'order_number' => $orderResult['order_number'],
                'client_name'  => $fromName,
                'items'        => [
                    [
                        'product_name' => $productName,
                        'quantity'     => $quantity,
                    ]
                ],
                'warnings'     => $orderResult['warnings'] ?? [],
            ]);
            $this->resetSessionToMainMenu($fromPhone, $fromName);
        } else {
            WhatsAppMessagingService::sendMessage($fromPhone, "⚠️ Order placement failed: " . $orderResult['message']);
        }
    }

    // ── Session & Database Helpers ──

    private function getOrCreateSession(string $fromPhone, string $fromName): array
    {
        $phoneEsc = $this->conn->real_escape_string($fromPhone);
        $res = $this->conn->query("SELECT * FROM whatsapp_sessions WHERE from_phone = '{$phoneEsc}' LIMIT 1");
        if ($res && $row = $res->fetch_assoc()) {
            return $row;
        }

        $nameEsc = $this->conn->real_escape_string($fromName);
        $this->conn->query("INSERT INTO whatsapp_sessions (from_phone, from_name, current_step) VALUES ('{$phoneEsc}', '{$nameEsc}', 'MAIN_MENU')");

        return [
            'from_phone'   => $fromPhone,
            'from_name'    => $fromName,
            'current_step' => 'MAIN_MENU',
        ];
    }

    private function updateSessionStep(string $fromPhone, string $step, array $fields = []): void
    {
        $catIdSql   = isset($fields['selected_category_id']) && $fields['selected_category_id'] !== null ? (int)$fields['selected_category_id'] : 'NULL';
        $prodIdSql  = isset($fields['selected_product_id']) && $fields['selected_product_id'] !== null ? (int)$fields['selected_product_id'] : 'NULL';
        $prodName   = isset($fields['selected_product_name']) && $fields['selected_product_name'] !== null ? ("'" . $this->conn->real_escape_string($fields['selected_product_name']) . "'") : 'NULL';
        $stepEsc    = $this->conn->real_escape_string($step);
        $phoneEsc   = $this->conn->real_escape_string($fromPhone);

        $sql = "UPDATE whatsapp_sessions SET current_step = '{$stepEsc}', selected_category_id = {$catIdSql}, selected_product_id = {$prodIdSql}, selected_product_name = {$prodName}, updated_at = NOW() WHERE from_phone = '{$phoneEsc}'";
        if (!$this->conn->query($sql)) {
            writeWhatsAppLog('DB_UPDATE_ERROR', "Failed to update whatsapp_sessions: " . $this->conn->error);
        }
    }

    private function resetSessionToMainMenu(string $fromPhone, string $fromName): void
    {
        $phoneEsc = $this->conn->real_escape_string($fromPhone);
        $this->conn->query("UPDATE whatsapp_sessions SET current_step = 'MAIN_MENU', selected_category_id = NULL, selected_product_id = NULL, selected_product_name = NULL, updated_at = NOW() WHERE from_phone = '{$phoneEsc}'");
    }

    private function getActiveCategories(): array
    {
        $res = $this->conn->query("SELECT id, name AS category_name FROM product_categories WHERE status = 1 AND deleted_at IS NULL ORDER BY name ASC");
        return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    }

    private function getProductsByCategory(int $categoryId): array
    {
        $stmt = $this->conn->prepare("SELECT id, product_name FROM products WHERE category_id = ? AND status = 1 AND deleted_at IS NULL ORDER BY product_name ASC");
        $stmt->bind_param('i', $categoryId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $res ?: [];
    }

    private function searchProducts(string $keyword, ?int $categoryId = null): array
    {
        $term = '%' . trim($keyword) . '%';
        if ($categoryId && $categoryId > 0) {
            $stmt = $this->conn->prepare("SELECT id, product_name FROM products WHERE category_id = ? AND product_name LIKE ? AND status = 1 AND deleted_at IS NULL ORDER BY product_name ASC");
            $stmt->bind_param('is', $categoryId, $term);
        } else {
            $stmt = $this->conn->prepare("SELECT id, product_name FROM products WHERE product_name LIKE ? AND status = 1 AND deleted_at IS NULL ORDER BY product_name ASC");
            $stmt->bind_param('s', $term);
        }
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $res ?: [];
    }

    private function getProductById(int $productId): ?array
    {
        $stmt = $this->conn->prepare("SELECT id, product_name FROM products WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $res;
    }
}
