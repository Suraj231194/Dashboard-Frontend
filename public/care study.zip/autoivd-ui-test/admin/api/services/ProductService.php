<?php

class ProductService {

    // public static function getProducts($conn, $params = [])
    // {
    //     $page  = $params['page'] ?? 1;
    //     $limit = $params['limit'] ?? 100;

    //     if ($page < 1) $page = 1;

    //     $offset = ($page - 1) * $limit;

    //     $filters = [];

    //     if (!empty($params['status'])) {
    //         $filters['status'] = [
    //             'op' => 'IN',
    //             'value' => explode(',', $params['status'])
    //         ];
    //     }

    //     $products = fetchApiRecords($conn, 'products', $filters, [
    //         'columns' => ['id', 'product_name', 'category_id', 'unit_id'],
    //         'limit'   => $limit,
    //         'offset'  => $offset,
    //         'order_by'=> 'product_name'
    //     ]);

    //     return $products;
    // }

    // public static function getProducts()
    // {
    //     global $conn;
    //     $page  = isset($_GET['page']) ? intval($_GET['page']) : 1;
    //     $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 100;
    //     if($page < 1) $page = 1;

    //     $offset = ($page - 1) * $limit;
    
    //     $filters = [];

    //     if(isset($_GET['status']) && $_GET['status'] !== ''){

    //         $status = array_map('intval', explode(',', $_GET['status']));

    //         $filters['p.status'] = [
    //             'op' => 'IN',
    //             'value' => $status
    //         ];
    //     }

    //     if(!empty($_GET['category_id'])){

    //         $category = array_map('intval', explode(',', $_GET['category_id']));

    //         $filters['p.category_id'] = [
    //             'op' => 'IN',
    //             'value' => $category
    //         ];
    //     }

    //     if(!empty($_GET['unit_id'])){

    //         $unit = array_map('intval', explode(',', $_GET['unit_id']));

    //         $filters['p.unit_id'] = [
    //             'op' => 'IN',
    //             'value' => $unit
    //         ];
    //     }

    //     $options = [
    //         'columns' => [
    //             'p.*'
    //         ],
    //         'order_by' => 'p.product_name',

    //         'limit' => $limit,

    //         'offset' => $offset
    //     ];

    //     $countResult = fetchApiRecords($conn,'products p', $filters,['columns' => ['COUNT(*) as total']]);

    //     $totalProducts = $countResult[0]['total'] ?? 0;

    //     $products = fetchApiRecords($conn,'products p',$filters,$options);

    //     if(!$products){
    //         apiResponse(true,'Products List',[]);
    //     }


    //     $categoryIds = [];
    //     $unitIds = [];

    //     foreach($products as $p){

    //         if(!empty($p['category_id'])){
    //             $categoryIds[] = $p['category_id'];
    //         }

    //         if(!empty($p['unit_id'])){
    //             $unitIds[] = $p['unit_id'];
    //         }

    //     }

    //     $categoryIds = array_unique($categoryIds);
    //     $unitIds = array_unique($unitIds);

    //     $categories = [];
    //     $units = [];


    //     if($categoryIds){

    //         $rows = fetchApiRecords(
    //             $conn,
    //             'product_categories',
    //             [
    //                 'id'=>[
    //                     'op'=>'IN',
    //                     'value'=>$categoryIds
    //                 ]
    //             ]
    //         );

    //         foreach($rows as $r){
    //             $categories[$r['id']] = $r;
    //         }

    //     }   

    //     if($unitIds){

    //         $rows = fetchApiRecords(
    //             $conn,
    //             'standard_units',
    //             [
    //                 'id'=>[
    //                     'op'=>'IN',
    //                     'value'=>$unitIds
    //                 ]
    //             ]
    //         );

    //         foreach($rows as $r){
    //             $units[$r['id']] = $r;
    //         }

    //     }


    //     foreach($products as &$p){

    //         $p['category'] = $categories[$p['category_id']] ?? null;
    //         $p['unit'] = $units[$p['unit_id']] ?? null;

    //     }

    //     $response = [
    //         'pagination' => [
    //             'total' => $totalProducts,
    //             'per_page' => $limit,
    //             'current_page' => $page,
    //             'total_pages' => ceil($totalProducts / $limit)

    //         ],

    //         'data' => $products
    //     ];

    //     apiResponse(true,'Products List',$response);
    // }
    
    public static function getAllProducts($conn, $params = [])
    {
        $pagination = $params['pagination'] ?? 1;

        $page  = intval($params['page'] ?? 1);
        $limit = intval($params['limit'] ?? 100);

        if ($page < 1) $page = 1;

        $offset = ($page - 1) * $limit;

        $filters = [];

        if (!empty($params['status'])) {
            $filters['p.status'] = [
                'op' => 'IN',
                'value' => array_map('intval', explode(',', $params['status']))
            ];
        }

        if (!empty($params['category_id'])) {
            $filters['p.category_id'] = [
                'op' => 'IN',
                'value' => array_map('intval', explode(',', $params['category_id']))
            ];
        }

        if (!empty($params['unit_id'])) {
            $filters['p.unit_id'] = [
                'op' => 'IN',
                'value' => array_map('intval', explode(',', $params['unit_id']))
            ];
        }

        $options = [
            'columns' => ['p.*'],
            'order_by' => 'p.product_name'
        ];

        if ($pagination) {
            $options['limit']  = $limit;
            $options['offset'] = $offset;
        }

        $totalProducts = 0;

        if ($pagination) {
            $countResult = fetchApiRecords(
                $conn,
                'products p',
                $filters,
                ['columns' => ['COUNT(*) as total']]
            );

            $totalProducts = $countResult[0]['total'] ?? 0;
        }

        $products = fetchApiRecords($conn, 'products p', $filters, $options);

        if (!$products) {
            return $pagination ? [
                'pagination' => [],
                'data' => []
            ] : [];
        }

        $categoryIds = array_unique(array_column($products, 'category_id'));
        $unitIds     = array_unique(array_column($products, 'unit_id'));

        $categories = [];
        $units = [];

        if ($categoryIds) {
            $rows = fetchApiRecords($conn, 'product_categories', [
                'id' => ['op' => 'IN', 'value' => $categoryIds]
            ]);
            foreach ($rows as $r) {
                $categories[$r['id']] = $r;
            }
        }

        if ($unitIds) {
            $rows = fetchApiRecords($conn, 'standard_units', [
                'id' => ['op' => 'IN', 'value' => $unitIds]
            ]);
            foreach ($rows as $r) {
                $units[$r['id']] = $r;
            }
        }

        foreach ($products as &$p) {
            $p['category'] = $categories[$p['category_id']] ?? null;
            $p['unit']     = $units[$p['unit_id']] ?? null;
        }

        if ($pagination) {
            return [
                'pagination' => [
                    'total' => $totalProducts,
                    'per_page' => $limit,
                    'current_page' => $page,
                    'total_pages' => ceil($totalProducts / $limit)
                ],
                'data' => $products
            ];
        }
        return $products; 
    }
}