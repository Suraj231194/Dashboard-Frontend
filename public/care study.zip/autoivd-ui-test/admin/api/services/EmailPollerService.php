<?php

declare(strict_types=1);

require_once __DIR__ . '/EmailOrderLogger.php';

/**
 * EmailPollerService
 * 
 * Connects to the IMAP mailbox, fetches unseen emails,
 * and orchestrates the full parse → create → respond pipeline.
 * 
 * Part of: Email-to-Order Processing Pipeline
 */
class EmailPollerService
{
    private mysqli $conn;

    /** @var resource|false IMAP connection handle */
    private $imapStream = false;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    /**
     * Main entry point: poll mailbox and process all unseen emails.
     *
     * @param bool $dryRun  If true, parse but don't create orders or send responses
     * @return array{processed: int, success: int, failed: int, errors: string[]}
     */
    public function pollAndProcess(bool $dryRun = false): array
    {
        $summary = ['processed' => 0, 'success' => 0, 'failed' => 0, 'errors' => []];

        // ── Step 1: Validate configuration ──
        $configErrors = EmailConfigService::validateConfig();
        if (!empty($configErrors)) {
            $summary['errors'] = $configErrors;
            self::log('CONFIG ERROR: ' . implode('; ', $configErrors));
            return $summary;
        }

        // ── Step 2: Connect to IMAP ──
        try {
            $this->connect();
        } catch (Throwable $e) {
            $summary['errors'][] = 'IMAP connection failed: ' . $e->getMessage();
            self::log('IMAP CONNECT ERROR: ' . $e->getMessage());
            return $summary;
        }

        // ── Step 3: Search for unseen emails ──
        try {
            $messageNumbers = $this->searchUnseen();
        } catch (Throwable $e) {
            $summary['errors'][] = 'IMAP search failed: ' . $e->getMessage();
            self::log('IMAP SEARCH ERROR: ' . $e->getMessage());
            $this->disconnect();
            return $summary;
        }

        if (empty($messageNumbers)) {
            self::log('No unseen emails found.');
            $this->disconnect();
            return $summary;
        }

        self::log('Found ' . count($messageNumbers) . ' unseen email(s).');

        // ── Step 4: Process each email ──
        $orderService = new OrderEmailService($this->conn);

        foreach ($messageNumbers as $msgNo) {
            $summary['processed']++;

            try {
                $result = $this->processEmail($msgNo, $orderService, $dryRun);

                if ($result['success']) {
                    $summary['success']++;
                } else {
                    $summary['failed']++;
                }
            } catch (Throwable $e) {
                $summary['failed']++;
                $summary['errors'][] = 'Error processing email #' . $msgNo . ': ' . $e->getMessage();
                self::log('PROCESS ERROR (msg #' . $msgNo . '): ' . $e->getMessage());

                // Mark as seen even on error to prevent infinite reprocessing
                $this->markAsSeen($msgNo);
            }
        }

        // ── Step 5: Disconnect ──
        $this->disconnect();

        self::log(sprintf(
            'Poll complete: %d processed, %d success, %d failed.',
            $summary['processed'],
            $summary['success'],
            $summary['failed']
        ));

        return $summary;
    }

    /**
     * Test IMAP connectivity without processing any emails.
     */
    public function testConnection(): array
    {
        $configErrors = EmailConfigService::validateConfig();
        if (!empty($configErrors)) {
            self::log('TEST CONNECTION CONFIG ERROR: ' . implode('; ', $configErrors), 'CONFIG_ERROR');
            return ['success' => false, 'message' => 'Config errors: ' . implode('; ', $configErrors)];
        }

        try {
            $this->connect();
            $info = imap_mailboxmsginfo($this->imapStream);
            $result = [
                'success'  => true,
                'message'  => 'IMAP connection successful.',
                'mailbox'  => $info->Mailbox ?? 'N/A',
                'messages' => $info->Nmsgs ?? 0,
                'unread'   => $info->Unread ?? 0,
            ];
            self::log('TEST CONNECTION SUCCESSFUL', 'IMAP_TEST', $result);
            $this->disconnect();
            return $result;
        } catch (Throwable $e) {
            self::log('TEST CONNECTION FAILED: ' . $e->getMessage(), 'IMAP_ERROR');
            return ['success' => false, 'message' => 'IMAP connection failed: ' . $e->getMessage()];
        }
    }

    /**
     * Process a single email message.
     */
    private function processEmail(int $msgNo, OrderEmailService $orderService, bool $dryRun): array
    {
        // ── Extract email data ──
        $header    = imap_headerinfo($this->imapStream, $msgNo);
        $structure = imap_fetchstructure($this->imapStream, $msgNo);

        $messageId = isset($header->message_id) ? trim($header->message_id, '<> ') : '';
        $subject   = isset($header->subject) ? $this->decodeHeader($header->subject) : '';
        $fromEmail = '';
        $fromName  = '';
        $receivedAt = null;

        if (isset($header->from[0])) {
            $fromEmail = strtolower(trim($header->from[0]->mailbox . '@' . $header->from[0]->host));
            $fromName  = isset($header->from[0]->personal) ? $this->decodeHeader($header->from[0]->personal) : '';
        }

        if (isset($header->date)) {
            $receivedAt = date('Y-m-d H:i:s', strtotime($header->date));
        }

        // Generate a fallback message_id if none exists
        if ($messageId === '') {
            $messageId = 'generated-' . md5($fromEmail . $subject . ($receivedAt ?? time()));
        }

        self::log(sprintf('Processing: [%s] from <%s> subject: "%s"', $messageId, $fromEmail, $subject));

        // ── Check for duplicate ──
        if ($this->isDuplicate($messageId)) {
            self::log('DUPLICATE: Message-ID already processed: ' . $messageId);
            $this->markAsSeen($msgNo);
            return ['success' => true, 'duplicate' => true];
        }

        // ── Extract plain-text body ──
        $body = $this->extractPlainTextBody($this->imapStream, $msgNo, $structure);

        // ── Check if this email is a confirmation reply ("YES") to an active order draft ──
        $firstLine = trim((string) strtok(trim($body), "\r\n"));
        $isConfirmationWord = (bool) preg_match('/^\s*(yes|confirm|confirmed|ok|proceed|approved)\b/i', $firstLine);

        // Also check if draft code is referenced in subject or body
        $draftCode = null;
        if (preg_match('/DRF-[A-Z0-9]{6}/i', $subject . ' ' . $body, $match)) {
            $draftCode = strtoupper($match[0]);
        }

        // Search for a pending draft if confirmation word is present or draft code is found
        $pendingDraft = null;
        if ($isConfirmationWord || $draftCode !== null) {
            $pendingDraft = $orderService->findPendingDraftForSender($fromEmail, $draftCode);
        }

        // =========================================================================
        // FLOW A: Draft Confirmation ("YES" reply received)
        // =========================================================================
        if ($isConfirmationWord) {
            if ($pendingDraft !== null) {
                // Log incoming confirmation attempt
                $logId = $this->insertLog($messageId, $fromEmail, $fromName, $subject, $receivedAt, $body, [
                    'success' => true,
                    'data'    => ['flow' => 'draft_confirmation', 'draft_code' => $pendingDraft['draft_code']],
                    'errors'  => [],
                    'warnings'=> [],
                ]);

                if ($dryRun) {
                    self::log("DRY-RUN: Would have confirmed draft #{$pendingDraft['draft_code']} and created ERP order.");
                    $this->markAsSeen($msgNo);
                    return ['success' => true, 'dry_run' => true];
                }

                $confirmResult = $orderService->confirmDraftAndCreateOrder((int) $pendingDraft['id'], $messageId);

                if ($confirmResult['success']) {
                    $responseSent = EmailResponderService::sendSuccessEmail($fromEmail, $fromName, [
                        'order_id'     => $confirmResult['order_id'],
                        'order_number' => $confirmResult['order_number'],
                        'client_name'  => $confirmResult['client_name'],
                        'items'        => $confirmResult['items'],
                        'warnings'     => $confirmResult['warnings'],
                    ]);

                    $this->updateLog($logId, 'confirmed', null, $confirmResult['order_id'], $responseSent, 'confirmation');
                    $this->markAsSeen($msgNo);

                    self::log("ORDER CONFIRMED: Created order #{$confirmResult['order_number']} (ID: {$confirmResult['order_id']}) from draft #{$pendingDraft['draft_code']}");

                    return [
                        'success'      => true,
                        'order_id'     => $confirmResult['order_id'],
                        'order_number' => $confirmResult['order_number'],
                    ];
                } else {
                    // Confirmation failed (e.g. database error or expired)
                    $catalogBinary = ProductCatalogExportService::generateExcelBinary($this->conn);
                    $responseSent = EmailResponderService::sendFailureEmail($fromEmail, $fromName, [
                        'errors'   => [$confirmResult['message']],
                        'warnings' => [],
                        'subject'  => $subject,
                    ], $catalogBinary);

                    $this->updateLog($logId, 'system_error', $confirmResult['message'], null, $responseSent, 'failure');
                    $this->markAsSeen($msgNo);

                    self::log("CONFIRMATION FAILED: " . $confirmResult['message']);
                    return ['success' => false, 'errors' => [$confirmResult['message']]];
                }
            } else {
                // Customer sent "YES", but no pending draft was found (maybe expired or already confirmed)
                $logId = $this->insertLog($messageId, $fromEmail, $fromName, $subject, $receivedAt, $body, [
                    'success' => false,
                    'data'    => ['flow' => 'unmatched_confirmation'],
                    'errors'  => ['No active order draft found.'],
                    'warnings'=> [],
                ]);

                if ($dryRun) {
                    self::log("DRY-RUN: Received YES but no pending draft found for {$fromEmail}.");
                    $this->markAsSeen($msgNo);
                    return ['success' => false, 'dry_run' => true];
                }

                $catalogBinary = ProductCatalogExportService::generateExcelBinary($this->conn);
                $errNotice = "We received your confirmation ('YES'), but could not locate an active pending order draft for your email address. The draft may have already been confirmed or expired (drafts are valid for 48 hours). Please submit a new order email.";

                $responseSent = EmailResponderService::sendFailureEmail($fromEmail, $fromName, [
                    'errors'   => [$errNotice],
                    'warnings' => [],
                    'subject'  => $subject,
                ], $catalogBinary);

                $this->updateLog($logId, 'validation_error', $errNotice, null, $responseSent, 'failure');
                $this->markAsSeen($msgNo);

                return ['success' => false, 'errors' => [$errNotice]];
            }
        }

        // =========================================================================
        // FLOW B: New Order Email Processing
        // =========================================================================

        // ── Parse the email ──
        $parseResult = EmailParserService::parse($subject, $body, $fromName, $fromEmail);

        // ── Log initial email reception ──
        $logId = $this->insertLog($messageId, $fromEmail, $fromName, $subject, $receivedAt, $body, $parseResult);

        if ($dryRun) {
            self::log('DRY-RUN: Would have ' . ($parseResult['success'] ? 'validated order and created draft' : 'sent failure email with catalog attachment'));
            $this->markAsSeen($msgNo);
            return ['success' => $parseResult['success'], 'dry_run' => true];
        }

        // ── Check parse result ──
        if (!$parseResult['success']) {
            $catalogBinary = ProductCatalogExportService::generateExcelBinary($this->conn);
            $responseSent = EmailResponderService::sendFailureEmail($fromEmail, $fromName, [
                'errors'   => $parseResult['errors'],
                'warnings' => $parseResult['warnings'],
                'subject'  => $subject,
            ], $catalogBinary);

            $this->updateLog($logId, 'parse_error', implode("\n", $parseResult['errors']), null, $responseSent, 'failure');
            $this->markAsSeen($msgNo);

            return ['success' => false, 'errors' => $parseResult['errors']];
        }

        // ── Strictly validate and resolve items against product catalog ──
        $validation = $orderService->validateAndResolveOrder($parseResult['data'], $fromEmail, $fromName);

        if (!$validation['valid']) {
            // Rejection: do NOT add order; attach product catalog Excel
            $catalogBinary = ProductCatalogExportService::generateExcelBinary($this->conn);
            $responseSent = EmailResponderService::sendFailureEmail($fromEmail, $fromName, [
                'errors'   => $validation['errors'],
                'warnings' => $validation['warnings'],
                'subject'  => $subject,
            ], $catalogBinary);

            $this->updateLog($logId, 'validation_error', implode("\n", $validation['errors']), null, $responseSent, 'failure');
            $this->markAsSeen($msgNo);

            self::log("ORDER REJECTED for {$fromEmail}: " . implode('; ', $validation['errors']));
            return ['success' => false, 'errors' => $validation['errors']];
        }

        // ── Verification passed: Create draft and send confirmation request ("Reply YES") ──
        $draftResult = $orderService->createOrderDraft(
            $validation,
            $messageId,
            $fromEmail,
            $fromName,
            $subject,
            $body
        );

        if ($draftResult['success']) {
            $responseSent = EmailResponderService::sendDraftConfirmationRequestEmail(
                $fromEmail,
                $fromName,
                $draftResult['draft_data']
            );

            $this->updateLog($logId, 'draft_created', null, null, $responseSent, 'draft');
            $this->updateLogParsedData($logId, $validation['order_data']);
            $this->markAsSeen($msgNo);

            self::log("DRAFT CREATED: #{$draftResult['draft_code']} for {$fromEmail}. Sent confirmation request email.");

            return [
                'success'    => true,
                'draft_id'   => $draftResult['draft_id'],
                'draft_code' => $draftResult['draft_code'],
            ];
        } else {
            // Draft insertion failed
            $catalogBinary = ProductCatalogExportService::generateExcelBinary($this->conn);
            $err = 'Failed to create order draft due to an internal system error.';
            $responseSent = EmailResponderService::sendFailureEmail($fromEmail, $fromName, [
                'errors'   => [$err],
                'warnings' => [],
                'subject'  => $subject,
            ], $catalogBinary);

            $this->updateLog($logId, 'system_error', $err, null, $responseSent, 'failure');
            $this->markAsSeen($msgNo);

            return ['success' => false, 'errors' => [$err]];
        }
    }

    // ───────────────────────────────────────────────────
    // IMAP Helpers
    // ───────────────────────────────────────────────────

    private function connect(): void
    {
        $cfg = EmailConfigService::getImapConfig();
        $connectionString = EmailConfigService::getImapConnectionString();

        $this->imapStream = @imap_open($connectionString, $cfg['username'], $cfg['password'], 0, 3);

        if ($this->imapStream === false) {
            $errors = imap_errors();
            $alerts = imap_alerts();
            $errorMsg = $errors ? implode('; ', $errors) : 'Unknown IMAP error';
            throw new RuntimeException($errorMsg);
        }
    }

    private function disconnect(): void
    {
        if ($this->imapStream !== false) {
            // Expunge to permanently remove deleted messages and close
            @imap_close($this->imapStream, CL_EXPUNGE);
            $this->imapStream = false;
        }
    }

    private function searchUnseen(): array
    {
        $result = imap_search($this->imapStream, 'UNSEEN');
        return is_array($result) ? $result : [];
    }

    private function markAsSeen(int $msgNo): void
    {
        @imap_setflag_full($this->imapStream, (string) $msgNo, '\\Seen');
    }

    /**
     * Extract the plain-text body from a potentially multi-part email.
     *
     * @param resource $stream   IMAP stream
     * @param int      $msgNo    Message number
     * @param object   $structure imap_fetchstructure result
     * @return string
     */
    private function extractPlainTextBody($stream, int $msgNo, $structure): string
    {
        // Simple (non-multipart) message
        if (empty($structure->parts)) {
            $body = imap_fetchbody($stream, $msgNo, '1');
            return $this->decodeBody($body, $structure->encoding ?? 0);
        }

        // Multipart: search for text/plain part
        foreach ($structure->parts as $partIndex => $part) {
            $partNo = (string) ($partIndex + 1);

            if ($part->type === 0 && strtolower($part->subtype ?? '') === 'PLAIN') {
                $body = imap_fetchbody($stream, $msgNo, $partNo);
                return $this->decodeBody($body, $part->encoding ?? 0);
            }

            // Check nested multipart (e.g., multipart/alternative inside multipart/mixed)
            if (!empty($part->parts)) {
                foreach ($part->parts as $subIndex => $subPart) {
                    if ($subPart->type === 0 && strtolower($subPart->subtype ?? '') === 'PLAIN') {
                        $subPartNo = $partNo . '.' . ($subIndex + 1);
                        $body = imap_fetchbody($stream, $msgNo, $subPartNo);
                        return $this->decodeBody($body, $subPart->encoding ?? 0);
                    }
                }
            }
        }

        // Fallback: If no plain text found, try to get HTML and strip tags
        foreach ($structure->parts as $partIndex => $part) {
            if ($part->type === 0 && strtolower($part->subtype ?? '') === 'HTML') {
                $body = imap_fetchbody($stream, $msgNo, (string) ($partIndex + 1));
                $decoded = $this->decodeBody($body, $part->encoding ?? 0);
                return strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>', '</div>', '</tr>'], "\n", $decoded));
            }
        }

        // Last resort: fetch entire body
        $body = imap_fetchbody($stream, $msgNo, '1');
        return $this->decodeBody($body, $structure->encoding ?? 0);
    }

    /**
     * Decode email body based on transfer encoding.
     */
    private function decodeBody(string $body, int $encoding): string
    {
        switch ($encoding) {
            case 0: // 7BIT
            case 1: // 8BIT
                return $body;
            case 2: // BINARY
                return $body;
            case 3: // BASE64
                return base64_decode($body, true) ?: $body;
            case 4: // QUOTED-PRINTABLE
                return quoted_printable_decode($body);
            case 5: // OTHER
                return $body;
            default:
                return $body;
        }
    }

    /**
     * Decode MIME-encoded header values (UTF-8 subjects, names, etc.)
     */
    private function decodeHeader(string $value): string
    {
        $decoded = imap_mime_header_decode($value);
        $result = '';
        foreach ($decoded as $part) {
            $charset = strtolower($part->charset);
            if ($charset === 'default' || $charset === 'us-ascii' || $charset === 'utf-8') {
                $result .= $part->text;
            } else {
                $converted = @iconv($charset, 'UTF-8//TRANSLIT//IGNORE', $part->text);
                $result .= ($converted !== false) ? $converted : $part->text;
            }
        }
        return trim($result);
    }

    // ───────────────────────────────────────────────────
    // Database Logging
    // ───────────────────────────────────────────────────

    private function isDuplicate(string $messageId): bool
    {
        $stmt = $this->conn->prepare(
            "SELECT id FROM email_order_log WHERE message_id = ? LIMIT 1"
        );
        $stmt->bind_param('s', $messageId);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc() !== null;
        $stmt->close();
        return $exists;
    }

    private function insertLog(
        string  $messageId,
        string  $fromEmail,
        string  $fromName,
        string  $subject,
        ?string $receivedAt,
        string  $rawBody,
        array   $parseResult
    ): int {
        $processingStatus = $parseResult['success'] ? 'success' : 'parse_error';
        $errorDetails     = $parseResult['success'] ? null : implode("\n", $parseResult['errors']);
        $parsedDataJson   = json_encode($parseResult['data'], JSON_UNESCAPED_UNICODE);

        $stmt = $this->conn->prepare(
            "INSERT INTO email_order_log
                (message_id, from_email, from_name, subject, received_at, raw_body, parsed_data, processing_status, error_details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            'sssssssss',
            $messageId,
            $fromEmail,
            $fromName,
            $subject,
            $receivedAt,
            $rawBody,
            $parsedDataJson,
            $processingStatus,
            $errorDetails
        );
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        return $id;
    }

    private function updateLog(int $logId, string $status, ?string $errorDetails, ?int $orderId, bool $responseSent, string $responseType): void
    {
        $responseSentInt = $responseSent ? 1 : 0;
        $stmt = $this->conn->prepare(
            "UPDATE email_order_log SET processing_status = ?, error_details = ?, order_id = ?, response_sent = ?, response_type = ?, updated_at = NOW() WHERE id = ?"
        );
        $stmt->bind_param('ssiisi', $status, $errorDetails, $orderId, $responseSentInt, $responseType, $logId);
        $stmt->execute();
        $stmt->close();
    }

    private function updateLogParsedData(int $logId, array $parsedData): void
    {
        $json = json_encode($parsedData, JSON_UNESCAPED_UNICODE);
        $stmt = $this->conn->prepare("UPDATE email_order_log SET parsed_data = ? WHERE id = ?");
        $stmt->bind_param('si', $json, $logId);
        $stmt->execute();
        $stmt->close();
    }

    // ───────────────────────────────────────────────────
    // Logging
    // ───────────────────────────────────────────────────

    private static function log(string $message, string $eventType = 'POLLER', $extraDetails = null): void
    {
        EmailOrderLogger::write($eventType, $message, $extraDetails);
    }
}
