<?php

/**
 * WhatsAppConfigService
 * 
 * Centralises all Meta WhatsApp Cloud API configuration.
 * Reads from .env constants / env vars.
 * 
 * Part of: WhatsApp-to-Order Processing Pipeline
 */
class WhatsAppConfigService
{
    private static function getEnvVar(string $key, string $default = ''): string
    {
        if (defined($key)) {
            return (string) constant($key);
        }
        if (isset($GLOBALS['env'][$key]) && $GLOBALS['env'][$key] !== '') {
            return (string) $GLOBALS['env'][$key];
        }
        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return (string) $_ENV[$key];
        }
        $envVal = getenv($key);
        if ($envVal !== false && $envVal !== '') {
            return (string) $envVal;
        }
        return $default;
    }

    public static function isEnabled(): bool
    {
        $enabled = strtolower(self::getEnvVar('WA_ENABLED', 'false'));
        return in_array($enabled, ['1', 'true', 'yes', 'on'], true);
    }

    public static function getVerifyToken(): string
    {
        return self::getEnvVar('WA_VERIFY_TOKEN', '');
    }

    public static function getAppSecret(): string
    {
        return self::getEnvVar('WA_APP_SECRET', '');
    }

    public static function hasValidWebhookSignature(string $rawPayload, string $providedSignature): bool
    {
        $appSecret = self::getAppSecret();
        if ($appSecret === '' || $providedSignature === '') {
            return false;
        }
        $expected = 'sha256=' . hash_hmac('sha256', $rawPayload, $appSecret);
        return hash_equals($expected, trim($providedSignature));
    }

    public static function getPhoneNumberId(): string
    {
        return self::getEnvVar('WA_PHONE_NUMBER_ID', '');
    }

    public static function getAccessToken(): string
    {
        return self::getEnvVar('WA_ACCESS_TOKEN', '');
    }

    public static function getBusinessAccountId(): string
    {
        return self::getEnvVar('WA_BUSINESS_ACCOUNT_ID', '');
    }

    public static function getApiUrl(): string
    {
        $phoneId = self::getPhoneNumberId();
        return "https://graph.facebook.com/v18.0/{$phoneId}/messages";
    }

    public static function validateConfig(): array
    {
        $errors = [];
        if (!self::isEnabled()) {
            $errors[] = 'WhatsApp Integration is disabled in .env (WA_ENABLED=false)';
        }
        if (empty(self::getVerifyToken())) {
            $errors[] = 'WA_VERIFY_TOKEN is not configured in .env';
        }
        if (empty(self::getAppSecret())) {
            $errors[] = 'WA_APP_SECRET is not configured in .env';
        }
        if (empty(self::getPhoneNumberId())) {
            $errors[] = 'WA_PHONE_NUMBER_ID is not configured in .env';
        }
        if (empty(self::getAccessToken())) {
            $errors[] = 'WA_ACCESS_TOKEN is not configured in .env';
        }
        return $errors;
    }
}
