<?php

/**
 * EmailConfigService
 * 
 * Centralises all email-related configuration.
 * Reads from .env constants defined via db.php bootstrap.
 * 
 * Part of: Email-to-Order Processing Pipeline
 */
class EmailConfigService
{
    /**
     * Helper to read environment variable across constants, $GLOBALS['env'], $_ENV, and getenv.
     */
    private static function getEnvVar(string $key, string $default = ''): string
    {
        if (defined($key)) {
            return (string) constant($key);
        }
        if (isset($GLOBALS['env'][$key]) && $GLOBALS['env'][$key] !== '') {
            return (string) $GLOBALS['env'][$key];
        }
        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return (string) $_ENV[$key];
        }
        $envVal = getenv($key);
        if ($envVal !== false && $envVal !== '') {
            return (string) $envVal;
        }
        return $default;
    }

    /**
     * Get IMAP connection configuration.
     */
    public static function getImapConfig(): array
    {
        return [
            'host'       => self::getEnvVar('MAIL_IMAP_HOST', 'imap.hostinger.com'),
            'port'       => (int) self::getEnvVar('MAIL_IMAP_PORT', '993'),
            'encryption' => self::getEnvVar('MAIL_IMAP_ENCRYPTION', 'ssl'),
            'username'   => self::getEnvVar('MAIL_IMAP_USERNAME', ''),
            'password'   => self::getEnvVar('MAIL_IMAP_PASSWORD', ''),
            'folder'     => self::getEnvVar('MAIL_IMAP_FOLDER', 'INBOX'),
        ];
    }

    /**
     * Get SMTP sending configuration.
     */
    public static function getSmtpConfig(): array
    {
        return [
            'host'         => self::getEnvVar('MAIL_SMTP_HOST', 'smtp.hostinger.com'),
            'port'         => (int) self::getEnvVar('MAIL_SMTP_PORT', '465'),
            'encryption'   => self::getEnvVar('MAIL_SMTP_ENCRYPTION', 'ssl'),
            'username'     => self::getEnvVar('MAIL_SMTP_USERNAME', ''),
            'password'     => self::getEnvVar('MAIL_SMTP_PASSWORD', ''),
            'from_name'    => self::getEnvVar('MAIL_FROM_NAME', 'Biogenix'),
            'from_address' => self::getEnvVar('MAIL_FROM_ADDRESS', ''),
        ];
    }

    /**
     * Build the IMAP mailbox connection string.
     * Example: {imap.hostinger.com:993/imap/ssl}INBOX
     */
    public static function getImapConnectionString(): string
    {
        $cfg = self::getImapConfig();
        $flags = '/imap';
        if ($cfg['encryption'] === 'ssl') {
            $flags .= '/ssl';
        } elseif ($cfg['encryption'] === 'tls') {
            $flags .= '/tls';
        }
        // Add novalidate-cert for environments where the certificate chain may not be fully trusted
        $flags .= '/novalidate-cert';

        return sprintf('{%s:%d%s}%s', $cfg['host'], $cfg['port'], $flags, $cfg['folder']);
    }

    /**
     * Validate that minimum required config is present.
     */
    public static function validateConfig(): array
    {
        $errors = [];
        $imap = self::getImapConfig();
        $smtp = self::getSmtpConfig();

        if (empty($imap['username'])) {
            $errors[] = 'MAIL_IMAP_USERNAME is not configured in .env';
        }
        if (empty($imap['password'])) {
            $errors[] = 'MAIL_IMAP_PASSWORD is not configured in .env';
        }
        if (empty($smtp['username'])) {
            $errors[] = 'MAIL_SMTP_USERNAME is not configured in .env';
        }
        if (empty($smtp['password'])) {
            $errors[] = 'MAIL_SMTP_PASSWORD is not configured in .env';
        }
        if (empty($smtp['from_address'])) {
            $errors[] = 'MAIL_FROM_ADDRESS is not configured in .env';
        }
        if (!function_exists('imap_open')) {
            $errors[] = 'PHP IMAP extension is not installed or enabled';
        }

        return $errors;
    }
}
