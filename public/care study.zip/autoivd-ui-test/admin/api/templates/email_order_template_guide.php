<?php
/**
 * Email Template: Order Email Format Guide
 *
 * Standalone template guide — can be used for auto-replies or documentation.
 * No variables needed.
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How to Order via Email - Biogenix IVD</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f4f6f9;">
        <tr>
            <td style="padding: 30px 20px;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.08);">

                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); padding: 32px 40px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 22px; font-weight: 700;">
                                📧 How to Place an Order via Email
                            </h1>
                            <p style="margin: 8px 0 0 0; color: #dbeafe; font-size: 14px;">Biogenix IVD — Order Management System</p>
                        </td>
                    </tr>

                    <!-- Body -->
                    <tr>
                        <td style="padding: 36px 40px;">
                            <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 20px 0;">
                                You can place orders by sending an email to <strong style="color: #1e40af;">suraj@biogenix.in</strong>.
                                Please use the format below so our system can automatically process your order.
                            </p>

                            <!-- Template -->
                            <p style="color: #6b7280; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 12px 0;">
                                Email Template
                            </p>
                            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px 24px; margin-bottom: 28px;">
                                <pre style="margin: 0; font-family: 'Courier New', monospace; font-size: 13px; color: #334155; line-height: 1.7; white-space: pre-wrap;">Subject: New Order — [Your Company Name]

Client Name: [Your Company Name]
Delivery Address: [Full delivery address]
Order Type: Product Order
Payment Terms: Credit
Dispatch Timeline: Immediate

Products:
1. [Product Name] | [Quantity] | [Unit]
2. [Product Name] | [Quantity] | [Unit]

Remarks: [Any special instructions]</pre>
                            </div>

                            <!-- Key Points -->
                            <div style="padding: 16px 20px; background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; margin-bottom: 28px;">
                                <p style="margin: 0 0 8px 0; font-size: 14px; font-weight: 700; color: #1e40af;">💡 Key Points:</p>
                                <p style="margin: 3px 0; font-size: 13px; color: #1e40af; line-height: 1.5;">• <strong>Client Name</strong> and at least <strong>one product</strong> are required</p>
                                <p style="margin: 3px 0; font-size: 13px; color: #1e40af; line-height: 1.5;">• Separate product details with the pipe character: <strong>|</strong></p>
                                <p style="margin: 3px 0; font-size: 13px; color: #1e40af; line-height: 1.5;">• Use exact product names from our catalog for fastest processing</p>
                                <p style="margin: 3px 0; font-size: 13px; color: #1e40af; line-height: 1.5;">• You will receive a confirmation email with your order number</p>
                                <p style="margin: 3px 0; font-size: 13px; color: #1e40af; line-height: 1.5;">• If something is unclear, we'll email you back with guidance</p>
                            </div>

                            <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 0;">
                                For any questions, contact our team by replying to this email.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 24px 40px; border-top: 1px solid #e5e7eb; text-align: center;">
                            <p style="margin: 0; font-size: 13px; color: #9ca3af;">
                                <strong style="color: #6b7280;">Biogenix IVD</strong><br>
                                Automated Order Processing System
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
