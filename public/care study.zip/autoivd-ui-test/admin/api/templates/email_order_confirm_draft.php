<?php
/**
 * Email Template: Order Draft Confirmation Request
 *
 * Sent to the customer after all product names and required fields are matched.
 * Asks the customer to confirm the order by replying "YES".
 *
 * Variables:
 *   $draftCode       string  e.g. 'DRF-A1B2C3'
 *   $clientName      string  Customer / Company display name
 *   $deliveryAddress string  Delivery address
 *   $itemsList       array   [['product_name' => ..., 'quantity' => ..., 'unit_name' => ...], ...]
 *   $paymentTerms    string  e.g. 'Credit'
 *   $dispatchTimeline string e.g. 'Immediate'
 *   $expiresAt       string  Expiration date/time
 */

$draftCode        = htmlspecialchars($draft_code ?? ($draftCode ?? 'N/A'));
$clientName       = htmlspecialchars($client_name ?? ($clientName ?? 'Valued Customer'));
$deliveryAddress  = htmlspecialchars($delivery_address ?? ($deliveryAddress ?? ''));
$itemsList        = $items ?? ($itemsList ?? []);
$paymentTerms     = htmlspecialchars($payment_terms ?? ($paymentTerms ?? 'Standard'));
$dispatchTimeline = htmlspecialchars($dispatch_timeline ?? ($dispatchTimeline ?? 'Immediate'));
$expiresAt        = htmlspecialchars($expires_at ?? ($expiresAt ?? '72 hours'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Verification Required - Biogenix IVD</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f4f6f9;">
        <tr>
            <td style="padding: 30px 20px;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.08);">

                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); padding: 32px 40px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 22px; font-weight: 700;">
                                📋 Action Required: Confirm Your Order
                            </h1>
                            <p style="margin: 8px 0 0 0; color: #dbeafe; font-size: 14px;">Biogenix IVD — Order Management System</p>
                        </td>
                    </tr>

                    <!-- Body -->
                    <tr>
                        <td style="padding: 36px 40px;">
                            <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0;">
                                Dear <strong><?= $clientName ?></strong>,
                            </p>
                            <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 24px 0;">
                                We have received your order request and successfully verified all items against our product catalog.
                                <strong>Please review the verified order details below:</strong>
                            </p>

                            <!-- Draft Badge -->
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                <tr>
                                    <td style="text-align: center; padding: 8px 0 20px 0;">
                                        <span style="display: inline-block; background-color: #eff6ff; border: 2px solid #93c5fd; border-radius: 8px; padding: 10px 24px; font-size: 16px; font-weight: 700; color: #1e40af; letter-spacing: 0.5px;">
                                            Draft Reference: #<?= $draftCode ?>
                                        </span>
                                    </td>
                                </tr>
                            </table>

                            <!-- ACTION REQUIRED CALL-TO-ACTION BOX -->
                            <div style="margin: 0 0 28px 0; padding: 20px; background-color: #ecfdf5; border: 2px solid #10b981; border-radius: 10px; text-align: center;">
                                <p style="margin: 0 0 8px 0; font-size: 15px; font-weight: 700; color: #065f46; text-transform: uppercase; letter-spacing: 0.5px;">
                                    👉 How to Finalize This Order
                                </p>
                                <p style="margin: 0 0 12px 0; font-size: 15px; color: #047857; line-height: 1.5;">
                                    To place this order into our production and dispatch queue, please reply to this email with the single word:
                                </p>
                                <div style="display: inline-block; background-color: #059669; color: #ffffff; font-size: 24px; font-weight: 800; padding: 10px 36px; border-radius: 8px; letter-spacing: 2px;">
                                    YES
                                </div>
                                <p style="margin: 12px 0 0 0; font-size: 12px; color: #065f46;">
                                    (Your order will <strong>not</strong> be processed until we receive your confirmation reply).
                                </p>
                            </div>

                            <!-- Order Items Table -->
                            <p style="color: #6b7280; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 12px 0;">
                                Verified Order Items
                            </p>
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; margin-bottom: 24px;">
                                <tr style="background-color: #f9fafb;">
                                    <td style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb;">#</td>
                                    <td style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb;">Catalog Product Name</td>
                                    <td style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb; text-align: right;">Qty</td>
                                    <td style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb; text-align: right;">Unit</td>
                                </tr>
                                <?php if (!empty($itemsList)): ?>
                                    <?php foreach ($itemsList as $idx => $item): ?>
                                        <tr>
                                            <td style="padding: 10px 14px; font-size: 14px; color: #374151; border-bottom: 1px solid #f3f4f6;"><?= $idx + 1 ?></td>
                                            <td style="padding: 10px 14px; font-size: 14px; color: #1e3a8a; font-weight: 600; border-bottom: 1px solid #f3f4f6;"><?= htmlspecialchars($item['product_name'] ?? '') ?></td>
                                            <td style="padding: 10px 14px; font-size: 14px; color: #374151; border-bottom: 1px solid #f3f4f6; text-align: right; font-weight: 700;"><?= number_format((float)($item['quantity'] ?? 0), 0) ?></td>
                                            <td style="padding: 10px 14px; font-size: 14px; color: #6b7280; border-bottom: 1px solid #f3f4f6; text-align: right;"><?= htmlspecialchars($item['unit_name'] ?? 'Unit') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </table>

                            <!-- Delivery & Order Meta -->
                            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px 20px; margin-bottom: 24px;">
                                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <?php if ($deliveryAddress !== ''): ?>
                                        <tr>
                                            <td style="padding: 4px 0; font-size: 13px; color: #6b7280; width: 140px; vertical-align: top;"><strong>Delivery Address:</strong></td>
                                            <td style="padding: 4px 0; font-size: 13px; color: #1f2937;"><?= $deliveryAddress ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td style="padding: 4px 0; font-size: 13px; color: #6b7280; width: 140px;"><strong>Payment Terms:</strong></td>
                                        <td style="padding: 4px 0; font-size: 13px; color: #1f2937;"><?= $paymentTerms ?></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 4px 0; font-size: 13px; color: #6b7280; width: 140px;"><strong>Dispatch Timeline:</strong></td>
                                        <td style="padding: 4px 0; font-size: 13px; color: #1f2937;"><?= $dispatchTimeline ?></td>
                                    </tr>
                                </table>
                            </div>

                            <p style="color: #6b7280; font-size: 13px; line-height: 1.5; margin: 0;">
                                Note: This draft will remain open for 72 hours. If any changes are needed, please reply with your updated order instead of confirming.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 24px 40px; border-top: 1px solid #e5e7eb; text-align: center;">
                            <p style="margin: 0; font-size: 13px; color: #9ca3af;">
                                <strong style="color: #6b7280;">Biogenix IVD</strong><br>
                                Automated Order Verification System • Support: automatedorders@biogenix.in
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
