<?php
/**
 * Email Template: Order Parsing Failed
 *
 * Variables available:
 *   $errors   - array of error strings
 *   $warnings - array of warning strings (optional)
 *   $subject  - string (original email subject)
 */

$errorList   = $errors ?? [];
$warningList = $warnings ?? [];
$origSubject = htmlspecialchars($subject ?? '(no subject)');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Processing Failed</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f4f6f9;">
        <tr>
            <td style="padding: 30px 20px;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.08);">

                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%); padding: 32px 40px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 22px; font-weight: 700; letter-spacing: -0.02em;">
                                ⚠️ Order Could Not Be Processed
                            </h1>
                        </td>
                    </tr>

                    <!-- Body -->
                    <tr>
                        <td style="padding: 36px 40px;">
                            <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 8px 0;">
                                We received your email with subject: <strong>"<?= $origSubject ?>"</strong>
                            </p>
                            <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 24px 0;">
                                Unfortunately, we could not process your order because some required information was missing or in an unrecognised format. Please see the details below.
                            </p>

                            <!-- Errors -->
                            <?php if (!empty($errorList)): ?>
                                <div style="padding: 18px 20px; background-color: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; margin-bottom: 20px;">
                                    <p style="margin: 0 0 10px 0; font-size: 14px; font-weight: 700; color: #991b1b;">❌ Issues Found (Order Not Placed):</p>
                                    <?php foreach ($errorList as $err): ?>
                                        <p style="margin: 4px 0; font-size: 14px; color: #991b1b; line-height: 1.5;">• <?= htmlspecialchars($err) ?></p>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <!-- Attachment Banner -->
                            <div style="padding: 16px 20px; background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; margin-bottom: 24px;">
                                <p style="margin: 0 0 6px 0; font-size: 14px; font-weight: 700; color: #1e40af;">📎 Official Product Catalog Attached:</p>
                                <p style="margin: 0; font-size: 13px; color: #1e3a8a; line-height: 1.5;">
                                    We have attached <strong>Biogenix_Product_Catalog.xlsx</strong> to this email. Please check the attachment for the exact product names recognized by our automated system (Column B) and resend your order.
                                </p>
                            </div>

                            <!-- Correct Template -->
                            <p style="color: #6b7280; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 12px 0;">
                                ✉️ Correct Email Format
                            </p>
                            <p style="color: #374151; font-size: 14px; line-height: 1.5; margin: 0 0 12px 0;">
                                Please re-send your order using the format below. Copy this template, fill in your details, and send it to this email address:
                            </p>

                            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px 24px; margin-bottom: 24px;">
                                <pre style="margin: 0; font-family: 'Courier New', monospace; font-size: 13px; color: #334155; line-height: 1.7; white-space: pre-wrap; word-wrap: break-word;">Subject: New Order — [Your Company Name]

Client Name: [Your Company Name]
Delivery Address: [Full delivery address]
Order Type: Product Order
Payment Terms: Credit
Dispatch Timeline: Immediate

Products:
1. [Product Name] | [Quantity] | [Unit]
2. [Product Name] | [Quantity] | [Unit]
3. [Product Name] | [Quantity] | [Unit]

Remarks: [Any special instructions]</pre>
                            </div>

                            <!-- Example -->
                            <p style="color: #6b7280; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 12px 0;">
                                📝 Filled Example
                            </p>
                            <div style="background-color: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; padding: 20px 24px; margin-bottom: 24px;">
                                <pre style="margin: 0; font-family: 'Courier New', monospace; font-size: 13px; color: #065f46; line-height: 1.7; white-space: pre-wrap; word-wrap: break-word;">Subject: New Order — ABC Diagnostics Pvt Ltd

Client Name: ABC Diagnostics Pvt Ltd
Delivery Address: 45 Industrial Area, Phase 2, Gurugram, Haryana 122001
Order Type: Product Order
Payment Terms: Credit
Dispatch Timeline: Immediate

Products:
1. COVID-19 Antigen Rapid Test Kit | 500 | Kits
2. Dengue NS1 Rapid Test | 200 | Kits
3. Malaria Pf/Pv Rapid Test | 100 | Boxes

Remarks: Please dispatch via Blue Dart. Contact: 9876543210</pre>
                            </div>

                            <!-- Field Guide -->
                            <p style="color: #6b7280; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 12px 0;">
                                📋 Field Reference
                            </p>
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; margin-bottom: 20px;">
                                <tr style="background-color: #f9fafb;">
                                    <td style="padding: 8px 14px; font-size: 12px; font-weight: 700; color: #6b7280; border-bottom: 1px solid #e5e7eb;">Field</td>
                                    <td style="padding: 8px 14px; font-size: 12px; font-weight: 700; color: #6b7280; border-bottom: 1px solid #e5e7eb;">Required</td>
                                    <td style="padding: 8px 14px; font-size: 12px; font-weight: 700; color: #6b7280; border-bottom: 1px solid #e5e7eb;">Note</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #374151; border-bottom: 1px solid #f3f4f6;">Client Name</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #dc2626; font-weight: 700; border-bottom: 1px solid #f3f4f6;">✅ Yes</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Your company/organisation name</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #374151; border-bottom: 1px solid #f3f4f6;">Products (at least 1)</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #dc2626; font-weight: 700; border-bottom: 1px solid #f3f4f6;">✅ Yes</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Name | Quantity | Unit</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #374151; border-bottom: 1px solid #f3f4f6;">Delivery Address</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Optional</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Full shipping address</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #374151; border-bottom: 1px solid #f3f4f6;">Order Type</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Optional</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Product Order, Sample Request, etc.</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #374151; border-bottom: 1px solid #f3f4f6;">Payment Terms</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Optional</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280; border-bottom: 1px solid #f3f4f6;">Paid, Credit, Pending</td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #374151;">Dispatch Timeline</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280;">Optional</td>
                                    <td style="padding: 8px 14px; font-size: 13px; color: #6b7280;">Immediate, 1 Week, Flexible</td>
                                </tr>
                            </table>

                            <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 0;">
                                Please correct the issues above and re-send your order. If you need assistance, reply to this email.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 24px 40px; border-top: 1px solid #e5e7eb; text-align: center;">
                            <p style="margin: 0; font-size: 13px; color: #9ca3af;">
                                <strong style="color: #6b7280;">Biogenix IVD</strong><br>
                                This is an automated email from the Biogenix Order Management System.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
