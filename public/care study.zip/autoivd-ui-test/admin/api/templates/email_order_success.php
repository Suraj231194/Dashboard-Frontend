<?php
/**
 * Email Template: Order Success Confirmation
 *
 * Variables available:
 *   $order_number  - string
 *   $order_id      - int (optional)
 *   $client_name   - string
 *   $items         - array of [product_name, quantity, unit]
 *   $warnings      - array of strings (optional)
 *   $is_duplicate  - bool (optional)
 */

$orderNumber = htmlspecialchars($order_number ?? 'N/A');
$clientName  = htmlspecialchars($client_name ?? 'Valued Customer');
$isDuplicate = $is_duplicate ?? false;
$itemsList   = $items ?? [];
$warningList = $warnings ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f4f6f9;">
        <tr>
            <td style="padding: 30px 20px;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.08);">

                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #1a7a4c 0%, #22a366 100%); padding: 32px 40px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 22px; font-weight: 700; letter-spacing: -0.02em;">
                                <?php if ($isDuplicate): ?>
                                    ℹ️ Duplicate Order Email
                                <?php else: ?>
                                    ✅ Order Received Successfully
                                <?php endif; ?>
                            </h1>
                        </td>
                    </tr>

                    <!-- Body -->
                    <tr>
                        <td style="padding: 36px 40px;">
                            <?php if ($isDuplicate): ?>
                                <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0;">
                                    Dear <strong><?= $clientName ?></strong>,
                                </p>
                                <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 24px 0;">
                                    We have already received and processed this order. Your order number is
                                    <strong style="color: #1a7a4c; font-size: 17px;">#<?= $orderNumber ?></strong>.
                                    No duplicate order has been created.
                                </p>
                            <?php else: ?>
                                <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 16px 0;">
                                    Dear <strong><?= $clientName ?></strong>,
                                </p>
                                <p style="color: #374151; font-size: 15px; line-height: 1.6; margin: 0 0 24px 0;">
                                    Thank you for your order. We have successfully received and registered it in our system.
                                    Your order number is:
                                </p>

                                <!-- Order Number Badge -->
                                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <tr>
                                        <td style="text-align: center; padding: 16px 0 28px 0;">
                                            <span style="display: inline-block; background-color: #ecfdf5; border: 2px solid #a7f3d0; border-radius: 8px; padding: 12px 28px; font-size: 20px; font-weight: 700; color: #065f46; letter-spacing: 0.5px;">
                                                #<?= $orderNumber ?>
                                            </span>
                                        </td>
                                    </tr>
                                </table>

                                <?php if (!empty($itemsList)): ?>
                                    <!-- Items Table -->
                                    <p style="color: #6b7280; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 12px 0;">
                                        Order Items
                                    </p>
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
                                        <tr style="background-color: #f9fafb;">
                                            <td style="padding: 10px 16px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb;">#</td>
                                            <td style="padding: 10px 16px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb;">Product</td>
                                            <td style="padding: 10px 16px; font-size: 12px; font-weight: 700; color: #6b7280; text-transform: uppercase; border-bottom: 1px solid #e5e7eb; text-align: right;">Qty</td>
                                        </tr>
                                        <?php foreach ($itemsList as $idx => $item): ?>
                                            <tr>
                                                <td style="padding: 10px 16px; font-size: 14px; color: #374151; border-bottom: 1px solid #f3f4f6;"><?= $idx + 1 ?></td>
                                                <td style="padding: 10px 16px; font-size: 14px; color: #374151; border-bottom: 1px solid #f3f4f6;"><?= htmlspecialchars($item['product_name'] ?? '') ?></td>
                                                <td style="padding: 10px 16px; font-size: 14px; color: #374151; border-bottom: 1px solid #f3f4f6; text-align: right; font-weight: 600;"><?= number_format($item['quantity'] ?? 0, 0) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </table>
                                <?php endif; ?>

                                <?php if (!empty($warningList)): ?>
                                    <div style="margin-top: 20px; padding: 14px 18px; background-color: #fffbeb; border: 1px solid #fcd34d; border-radius: 8px;">
                                        <p style="margin: 0 0 6px 0; font-size: 13px; font-weight: 700; color: #92400e;">⚠️ Notes:</p>
                                        <?php foreach ($warningList as $w): ?>
                                            <p style="margin: 2px 0; font-size: 13px; color: #92400e;">• <?= htmlspecialchars($w) ?></p>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                            <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 28px 0 0 0;">
                                Our team will review and process your order shortly. For any queries, please reply to this email or contact us.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 24px 40px; border-top: 1px solid #e5e7eb; text-align: center;">
                            <p style="margin: 0; font-size: 13px; color: #9ca3af;">
                                <strong style="color: #6b7280;">Biogenix IVD</strong><br>
                                This is an automated email from the Biogenix Order Management System.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
