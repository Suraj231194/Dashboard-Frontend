<?php
require_once('../db.php');
require_once('../constant.php');
require_once('../functions.php');

require_once(__DIR__ . '/helpers/common.php');

$config = require(__DIR__ . '/config/api.php');

spl_autoload_register(function ($class) {
    $folders = ['controllers', 'services'];
    foreach ($folders as $folder) {
        $file = __DIR__ . "/$folder/" . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

function getAuthorizationHeader()
{
    if (isset($_SERVER['Authorization'])) {
        return trim($_SERVER["Authorization"]);
    }
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        return trim($_SERVER["HTTP_AUTHORIZATION"]);
    }
    if (function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        return $headers['Authorization'] ?? '';
    }
    return '';
}

function verifyApiToken()
{
    $configuredToken = defined('ERP_API_ACCESS_TOKEN')
        ? trim((string) ERP_API_ACCESS_TOKEN)
        : '';
    if ($configuredToken === '' || in_array(strtolower($configuredToken), [
        'your-shared-sync-token-here',
        'test-token-123456',
        'change-me',
    ], true)) {
        apiResponse(false, 'ERP API token is not configured.');
    }

    $authHeader = getAuthorizationHeader();

    if (!$authHeader) {
        apiResponse(false, 'Token Missing');
    }

    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        apiResponse(false, 'Invalid Token Format');
    }

    if (!hash_equals($configuredToken, $matches[1])) {
        apiResponse(false, 'Invalid Token');
    }
}

function getRequestData()
{
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method === 'GET') {
        return $_GET;
    }
    if ($method === 'POST') {
        $contentType = $_SERVER["CONTENT_TYPE"] ?? '';
        if (strpos($contentType, 'application/json') !== false) {
            return json_decode(file_get_contents("php://input"), true);
        }
        return $_POST;
    }
    return [];
}


function apiResponse($status = false, $message = '', $data = [])
{
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

// function fetchApiRecords($conn, $table, $filters = [], $options = [])
// {
//     $columns = $options['columns'] ?? ['*'];
//     $joins   = $options['joins'] ?? [];
//     $orderBy = $options['order_by'] ?? '';
//     $order   = $options['order'] ?? 'ASC';
//     $limit   = $options['limit'] ?? null;
//     $offset  = $options['offset'] ?? null;
//     $groupBy = $options['group_by'] ?? '';
//     $having  = $options['having'] ?? [];
//     $search  = $options['search'] ?? [];
//     $allowedColumns = $options['allowed_columns'] ?? [];

//     $types = '';
//     $values = [];
//     $whereSql = [];
//     $havingSql = [];

//     $sql = "SELECT " . implode(',', $columns) . " FROM $table";

//     foreach ($joins as $join) {
//         $type  = $join['type'] ?? 'LEFT';
//         $tableJoin = $join['table'];
//         $on = $join['on'];

//         $sql .= " $type JOIN $tableJoin ON $on";

//         if (!empty($join['conditions'])) {

//             foreach ($join['conditions'] as $column => $condition) {

//                 $whereSql[] = "$column = ?";

//                 $values[] = $condition;

//                 $types .= is_int($condition) ? 'i' : 's';
//             }
//         }
//     }

//     foreach ($filters as $column => $condition) {

//         if (is_array($condition) && isset($condition['op'])) {

//             $op = strtoupper($condition['op']);
//             $value = $condition['value'];

//             if ($op === 'IN' && is_array($value)) {

//                 $placeholders = implode(',', array_fill(0, count($value), '?'));

//                 $whereSql[] = "$column IN ($placeholders)";

//                 foreach ($value as $v) {
//                     $values[] = $v;
//                     $types .= is_int($v) ? 'i' : 's';
//                 }

//             } else {

//                 $whereSql[] = "$column $op ?";

//                 $values[] = $value;

//                 $types .= is_int($value) ? 'i' : (is_float($value) ? 'd' : 's');
//             }

//         } else {

//             $whereSql[] = "$column = ?";

//             $values[] = $condition;

//             $types .= is_int($condition) ? 'i' : 's';
//         }
//     }

//     if (!empty($search['value']) && !empty($search['columns'])) {

//         $searchParts = [];

//         foreach ($search['columns'] as $col) {

//             $searchParts[] = "$col LIKE ?";

//             $values[] = '%' . $search['value'] . '%';

//             $types .= 's';
//         }

//         $whereSql[] = '(' . implode(' OR ', $searchParts) . ')';
//     }

//     if (!empty($whereSql)) {
//         $sql .= " WHERE " . implode(' AND ', $whereSql);
//     }

//     if (!empty($groupBy)) {
//         $sql .= " GROUP BY $groupBy";
//     }

//     if (!empty($having)) {

//         foreach ($having as $column => $value) {

//             $havingSql[] = "$column = ?";

//             $values[] = $value;

//             $types .= is_int($value) ? 'i' : 's';
//         }

//         if ($havingSql) {
//             $sql .= " HAVING " . implode(' AND ', $havingSql);
//         }
//     }

//     if ($orderBy) {
//         $sql .= " ORDER BY $orderBy $order";
//     }

//     if ($limit !== null) {

//         $sql .= " LIMIT ?";

//         $values[] = $limit;

//         $types .= 'i';

//         if ($offset !== null) {

//             $sql .= " OFFSET ?";

//             $values[] = $offset;

//             $types .= 'i';
//         }
//     }

//     $stmt = mysqli_prepare($conn, $sql);

//     if (!$stmt) {
//         apiResponse(false, 'Database error');
//         // return mysqli_error($conn);
//     }

//     if (!empty($values)) {
//         mysqli_stmt_bind_param($stmt, $types, ...$values);
//     }

//     mysqli_stmt_execute($stmt);

//     $result = mysqli_stmt_get_result($stmt);

//     $rows = [];

//     while ($row = mysqli_fetch_assoc($result)) {
//         $rows[] = $row;
//     }

//     return $rows;
// }

function fetchApiRecords($conn, $table, $filters = [], $options = [])
{
    $columns = $options['columns'] ?? ['*'];
    $joins   = $options['joins'] ?? [];
    $orderBy = $options['order_by'] ?? '';
    $order   = strtoupper($options['order'] ?? 'ASC');
    $limit   = $options['limit'] ?? null;
    $offset  = $options['offset'] ?? null;
    $groupBy = $options['group_by'] ?? '';
    $having  = $options['having'] ?? [];
    $search  = $options['search'] ?? [];

    $allowedColumns       = $options['allowed_columns'] ?? [];
    $allowedOrder         = $options['allowed_order'] ?? [];
    $allowedSearchColumns = $options['allowed_search_columns'] ?? [];
    $allowedGroup         = $options['allowed_group'] ?? [];

    $types = '';
    $values = [];
    $whereSql = [];
    $havingSql = [];
    $sql = "SELECT " . implode(',', $columns) . " FROM $table";
    foreach ($joins as $join) {

        $type  = strtoupper($join['type'] ?? 'LEFT');
        $tableJoin = $join['table'];
        $on = $join['on'];

        $sql .= " $type JOIN $tableJoin ON $on";

        if (!empty($join['conditions'])) {

            foreach ($join['conditions'] as $column => $condition) {

                if (!empty($allowedColumns) && !in_array($column, $allowedColumns)) {
                    continue;
                }

                $whereSql[] = "$column = ?";
                $values[] = $condition;
                $types .= is_int($condition) ? 'i' : 's';
            }
        }
    }

    foreach ($filters as $column => $condition) {
        if (!empty($allowedColumns) && !in_array($column, $allowedColumns)) {
            continue;
        }
        if (is_array($condition) && isset($condition['op'])) {
            $op = strtoupper($condition['op']);
            $value = $condition['value'];
            if ($op === 'IN' && is_array($value)) {
                $placeholders = implode(',', array_fill(0, count($value), '?'));
                $whereSql[] = "$column IN ($placeholders)";
                foreach ($value as $v) {
                    $values[] = $v;
                    $types .= is_int($v) ? 'i' : 's';
                }
            } else {
                $whereSql[] = "$column $op ?";
                $values[] = $value;
                $types .= is_int($value) ? 'i' : (is_float($value) ? 'd' : 's');
            }
        } else {
            $whereSql[] = "$column = ?";
            $values[] = $condition;
            $types .= is_int($condition) ? 'i' : 's';
        }
    }

    if (!empty($search['value']) && !empty($search['columns'])) {
        $searchParts = [];
        foreach ($search['columns'] as $col) {
            if (!empty($allowedSearchColumns) && !in_array($col, $allowedSearchColumns)) {
                continue;
            }
            $searchParts[] = "$col LIKE ?";
            $values[] = '%' . $search['value'] . '%';
            $types .= 's';
        }
        if (!empty($searchParts)) {
            $whereSql[] = '(' . implode(' OR ', $searchParts) . ')';
        }
    }
    if (!empty($whereSql)) {
        $sql .= " WHERE " . implode(' AND ', $whereSql);
    }
    if ($groupBy && in_array($groupBy, $allowedGroup)) {
        $sql .= " GROUP BY $groupBy";
    }
    if (!empty($having)) {
        foreach ($having as $column => $value) {
            if (!empty($allowedColumns) && !in_array($column, $allowedColumns)) {
                continue;
            }
            $havingSql[] = "$column = ?";
            $values[] = $value;
            $types .= is_int($value) ? 'i' : 's';
        }
        if (!empty($havingSql)) {
            $sql .= " HAVING " . implode(' AND ', $havingSql);
        }
    }

    if ($orderBy && in_array($orderBy, $allowedOrder)) {
        $order = ($order === 'DESC') ? 'DESC' : 'ASC';
        $sql .= " ORDER BY $orderBy $order";
    }
    if ($limit !== null) {
        $limit = intval($limit);
        if ($limit <= 0) $limit = 100;
        if ($limit > 500) $limit = 500;
        $sql .= " LIMIT ?";
        $values[] = $limit;
        $types .= 'i';
        if ($offset !== null) {
            $offset = intval($offset);
            if ($offset < 0) $offset = 0;
            $sql .= " OFFSET ?";
            $values[] = $offset;
            $types .= 'i';
        }
    }

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log(mysqli_error($conn));
        apiResponse(false, 'Database error');
    }
    if (!empty($values)) {
        mysqli_stmt_bind_param($stmt, $types, ...$values);
    }
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

// $options = [
//     'columns' => ['p.*', 'c.name as category_name'],
//     'joins' => [
//         [
//             'type' => 'LEFT',
//             'table' => 'categories c',
//             'on' => 'c.id = p.category_id'
//         ]
//     ],
//     'allowed_columns' => ['p.id', 'p.status', 'p.category_id'],
//     'allowed_order' => ['p.id', 'p.product_name'],
//     'allowed_search_columns' => ['p.product_name'],
//     'allowed_group' => ['p.category_id'],
//     'order_by' => 'p.id',
//     'limit' => 50
// ];
