<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="py-3 mb-2"><span class="fw-light"><?= $pageTitle ?></span></h4>
    <div class="misc-wrapper text-center">
        <h2 class="mb-1 mx-2">You are not authorized!</h2>
        <p class="mb-4 mx-2">
          You do not have permission to view this page using the credentials that you have provided while login. <br />
          Please contact your site administrator.
        </p>
         <a href="index.php" class="btn btn-primary mb-4">Back to Dashborad</a>
        <div class="mt-4">
          <img
            src="<?= asset('assets/img/illustrations/page-misc-you-are-not-authorized.png'); ?>"
            alt="page-misc-not-authorized"
            width="170"
            class="img-fluid" />
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    // Write your script here
</script>
<?php endSection(); ?>
