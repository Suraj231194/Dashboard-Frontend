<?php
date_default_timezone_set('Asia/Kolkata');
require_once 'db.php';
require_once 'functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}
?>
