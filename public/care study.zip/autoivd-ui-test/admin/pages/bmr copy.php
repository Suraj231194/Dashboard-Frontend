<div class="container-xxl container-p-y">
    <div class="row my-4">
        <div class="col">
            <div class="accordion" id="collapsibleBomSettingsSection">
                <div class="card accordion-item ">
                    <h2 class="accordion-header" id="headingInstitutionsOptions">
                        <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseBomOptions" aria-expanded="false" aria-controls="collapseBomOptions">
                            BMR Template Designer
                        </button>
                    </h2>
                    <div id="collapseBomOptions" class="accordion-collapse collapse" aria-labelledby="headingInstitutionsOptions" data-bs-parent="#collapsibleBomSettingsSection">
                        <div class="accordion-body">
                            <div class="row col-md-12">
                                <div class="p-3">
                                    <form id="bmrTemplateCreateForm">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <h5>Template Details</h5>
                                                <input class="form-control mb-2" id="product_name" name="product_name" placeholder="Product Name">
                                                <input class="form-control mb-2" id="template_name" name="template_name" placeholder="Template Name">
                                            </div>
                                            <div class="col-md-5">
                                                <h5>Add Section</h5>
                                                <input class="form-control mb-2" id="section_title" placeholder="Section Title">

                                                <select class="form-control mb-2" id="section_type">
                                                    <option value="">Select</option>
                                                    <option value="1">Normal Block</option>
                                                    <option value="2">Table</option>
                                                    <option value="3">Static Text</option>
                                                </select>
                                                <input type="number" class="form-control mb-2" id="page_no" placeholder="Page No">
                                            </div>
                                            <div class="col-md-3">
                                                <button class="btn btn-primary" type="button" id="addSectionBtn">Add Section</button>
                                            </div>
                                        </div>

                                        <div id="sectionList"></div>

                                        <hr>
                                        <button type="submit" class="btn btn-success">FINAL SAVE TEMPLATE</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="bmrPreviewModal">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">

                <div class="modal-header">
                    <h5>BMR Template Preview</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body scroll-y-70vh" id="bmrPreviewBody">

                </div>

            </div>
        </div>
    </div>

</div>



<?php startSection('scripts'); ?>
<script src="<?= asset('assets/vendor/libs/sortablejs/sortable.js') ?>"></script>
<script src="<?= asset('assets/js/extended-ui-drag-and-drop.js') ?>"></script>
<script>
    let sectionIndex = 0;

    function addSection() {

        let title = $('#section_title').val().trim();
        let type = $('#section_type').val();
        let pageNo = $('#page_no').val();

        if (title === '') {
            toastr.error('Section Title Required');
            return;
        }

        if (type === '') {
            toastr.error('Section Type Required');
            return;
        }

        if (pageNo === '' || isNaN(pageNo) || pageNo <= 0) {
            toastr.error('Valid Page Number Required');
            return;
        }

        html = `
        <div class="card p-3 mb-3 section-card" id="section_${sectionIndex}">

            <input type="hidden" name="sections[${sectionIndex}][title]" value="${title}">
            <input type="hidden" name="sections[${sectionIndex}][type]" value="${type}">
            <input type="hidden" name="sections[${sectionIndex}][page_no]" value="${pageNo}">

            <div class="d-flex justify-content-between">
                <b>${title} | Page ${pageNo}</b>

                ${type==1 ? `<button type="button"
                    class="btn btn-info btn-sm mb-2"
                    onclick="addFieldRow(${sectionIndex})">
                    Add Field
                    </button>`:''}

                ${type==2 ? `<button type="button"
                    class="btn btn-warning btn-sm mb-2"
                    onclick="addColumnRow(${sectionIndex})">
                    Add Column
                    </button>`:''}  

                ${type==3 ? `
                    <textarea 
                    class="form-control mt-2"
                    name="sections[${sectionIndex}][static_text]"
                    placeholder="Static Content"></textarea>
                    ` : ''}
                

                <button type="button" class="btn btn-icon btn-label-danger btn-sm mb-2" onclick="removeSection(${sectionIndex})">
                    <span class="ti ti-trash"></span>
                </button>
            </div>
            <div id="field_area_${sectionIndex}" >
            </div>       

        </div>`;

        $('#sectionList').append(html);

        sectionIndex++;

        $('#section_title').val('');
        $('#section_type').val('');
        $('#page_no').val('');
    }

    function addFieldRow(i) {
        let count = $('#field_area_' + i + ' div.field-row').length;
        let html = `
            <div class="row field-row mb-1 border rounded p-1" data-index="${count}">
                <div class="col-md-3 mb-1">  
                    <input name="sections[${i}][fields][${count}][label]" class="form-control" placeholder="Label" />                
                </div>
                <div class="col-md-3 mb-1">
                    <input name="sections[${i}][fields][${count}][key]" class="form-control" placeholder="Key" />
                </div>               
                <div class="col-md-2 mb-1">                
                    <select name="sections[${i}][fields][${count}][type]" class="form-control" required>                       
                        <option value="1">Text</option>
                        <option value="2">Number</option>
                        <option value="3">Date</option>
                        <option value="4">Time</option>
                        <option value="5">Textarea</option>
                    </select>
                </div>   
                <div class="col-md-2 mb-1">                  
                    <select name="sections[${i}][fields][${count}][required]" class="form-control" required>
                        <option value="0">Optional</option>
                        <option value="1">Required</option>
                    </select>
                </div>   
                <div class="col-md-1 mb-1 d-flex align-items-end">
                    <button type="button" class="btn btn-icon btn-label-danger" onclick="$(this).closest('.field-row').remove()"><span class="ti ti-trash"></span></button>               
                </div>
            </div>`;

        $('#field_area_' + i).append(html);
    }

    function addColumnRow(i) {

        let count = $('#field_area_' + i + ' div.field-row').length;

        let html = `
        <div class="row field-row mb-1 border rounded p-1" data-index="${count}">
            <div class="col-md-3 mb-1">  
                <input name="sections[${i}][columns][${count}][label]" class="form-control" placeholder="Column Label" />                
            </div>
            <div class="col-md-3 mb-1">
                <input name="sections[${i}][columns][${count}][key]" class="form-control" placeholder="Column Key" />
            </div> 
            <div class="col-md-3 mb-1">
                <select name="sections[${i}][columns][${count}][type]" class="form-control">
                    <option value="1">Text</option>
                    <option value="2">Number</option>
                    <option value="3">Date</option>
                    <option value="4">Time</option>
                </select>
            </div>         
            <select name="sections[${i}][columns][${count}][cell_type]" class="form-control">
                <option value="label">Prefilled Label</option>
                <option value="input">User Input</option>
                <option value="static">Static Value</option>
            </select>     
            
            <div class="col-md-1 mb-1 d-flex align-items-end">
                <button type="button" class="btn btn-icon btn-label-danger" onclick="$(this).closest('.field-row').remove()"><span class="ti ti-trash"></span></button>               
            </div>
        </div>`;

        $('#field_area_' + i).append(html);
    }

    function removeSection(i) {
        $('#section_' + i).remove();
    }


    $(document).ready(function() {
        $("#addSectionBtn").on('click', function(e) {
            e.preventDefault();
            addSection();
        });

        $("#bmrTemplateCreateForm").on('submit', function(e) {
            e.preventDefault();
            let form = document.getElementById('bmrTemplateCreateForm');
            let formData = new FormData(form);
            formData.append('saveBmrTemplate', 'saveBmrTemplate');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        $('#bmrTemplateCreateForm')[0].reset();
                        $('#sectionList').html('');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function() {
                    toastr.error('Server Error');
                }

            });

        });

    });

    function showPreview(template_id) {
        $.post("ajax.php", {
                previewBMRTemplate: 1,
                template_id: template_id
            },
            function(res) {

                $("#bmrPreviewBody").html(res);

                $("#bmrPreviewModal").modal("show");

            });

    }
</script>
<?php endSection(); ?>
