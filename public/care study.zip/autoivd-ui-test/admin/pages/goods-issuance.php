<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage goods issued to Production records</p>
        </div>
    </div>

    <!-- Upcoming Issuance Requests Widget -->
    <div id="upcomingIssuanceWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" style="display: none;">
        <div class="overflow-hidden rounded-xl border border-slate-200 p-4 shadow-sm transition-all hover:shadow-md hover:bg-slate-50" style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: var(--appearance-accent-light, #f3e8ff); border-radius: 0.75rem;">
                    <i class="ti ti-clipboard-data" style="font-size: 1.5rem; color: var(--appearance-accent, #7c3aed);"></i>
                    <span id="upcomingIssuanceCountBadge" style="position: absolute; top: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7c3aed); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">0</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: var(--appearance-accent, #4c1d95); margin: 0;">Upcoming Issuance Request(s)!</h3>
                    </div>
                    <p class="font-medium mt-1 mb-0" style="font-size: 0.875rem;">
                        You have <span id="upcomingIssuanceCountText" class="font-bold">0</span> upcoming issuance request(s) sent from Material Requisition. Click here to review and produce.
                    </p>
                </div>
            </div>
            <div class="">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>
    <div class="w-full mb-6">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="goodsIssuancePerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="goods-issuance-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="goods-issuance-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="goods-issuance-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="goods-issuance-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="goods-issuance-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="goods-issuance-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <!-- Search input -->
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>


                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-full md:w-36 h-11" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="created_at" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="product_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Product <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3">Quantity</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="client_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Client Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="outward_type" data-order="asc">
                                <span class="inline-flex items-center gap-1">Dispatch Type <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="place_of_dispatch" data-order="asc">
                                <span class="inline-flex items-center gap-1">City/Area <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="category" data-order="asc">
                                <span class="inline-flex items-center gap-1">Category <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="created_by" data-order="asc">
                                <span class="inline-flex items-center gap-1">Issuance Placed By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="stockOutwardsTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- ═══════════ View Stock Outward Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="viewStockOutwardModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Issuance Details</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="viewStockOutward">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════ Edit Stock Outward Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="outwardStocksEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Issuance Details</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="outwardStocksEditForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="goodsDispatchedExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>
                        
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">DATE RANGE</label>
                            <div class="flex items-center gap-2">
                                <input type="date" id="exportFromDate" class="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" placeholder="From Date" />
                                <span class="text-sm text-slate-400">to</span>
                                <input type="date" id="exportToDate" class="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" placeholder="To Date" />
                            </div>
                        </div>

                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Timestamp" checked />
                                        <span class="text-sm font-medium text-slate-700">Timestamp</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product" checked />
                                        <span class="text-sm font-medium text-slate-700">Product</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Quantity" checked />
                                        <span class="text-sm font-medium text-slate-700">Quantity</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Client Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Client Name</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Dispatch Type" checked />
                                        <span class="text-sm font-medium text-slate-700">Dispatch Type</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="City Area" checked />
                                        <span class="text-sm font-medium text-slate-700">City Area</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Category" checked />
                                        <span class="text-sm font-medium text-slate-700">Category</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let productIndex = 0;
    let currentSortColumn = 'created_at';
    let currentSortOrder = 'DESC';
    let dispatch_type = APP_CONST.STOCKS_OUTWARDS.DISPATCH_MGMT_LABEL.InternalManufacturing;


    function loadStocksOutwordTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadStocksOutword: 'loadStocksOutword',
                page: page,
                per_page: perPage,
                search: search,
                dispatch_type: dispatch_type,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            dataType: 'json',
            success: function (response) {
                $('#stockOutwardsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');

                // This response is the main issuance-record table. Its total must
                // not overwrite the Upcoming Issuance badge, which represents only
                // pending Material Requisitions and is set by loadUpcomingIssuances.
            },
            error: function () {
                $('#stockOutwardsTableBody').html('<tr><td colspan="10" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }


    $(document).ready(function () {
        loadStocksOutwordTable();
        loadUpcomingIssuances(1, false);
        $('#searchUsers').on('input', function () {
            loadStocksOutwordTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadStocksOutwordTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadStocksOutwordTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.goods-issuance-per-page-item', function () {
            const val = $(this).data('val');
            $('#goodsIssuancePerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });


        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            $('#exportTypeSelect').val(val);
            $('#exportTypeText').text($(this).text());
        });

        $(document).on('click', '#deselectAllColumnsBtn', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('.column-filter').prop('checked', false);
                $(this).text('Select All');
            } else {
                $('.column-filter').prop('checked', true);
                $(this).text('Deselect All');
            }
        });

        $(document).on('change', '.column-filter', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('#deselectAllColumnsBtn').text('Deselect All');
            } else {
                $('#deselectAllColumnsBtn').text('Select All');
            }
        });

        function updateColumnsText() {
            const count = $('.column-filter:checked').length;
            $('#columnsSelectedText').text(count > 0 ? count + ' Columns' : 'Columns');
        }
        $(document).on('change', '.column-filter', function () { updateColumnsText(); });
        updateColumnsText();
    });

    $(document).on('click', '.outwardStocksDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteStockOutward: 'deleteStockOutward',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadStocksOutwordTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.outwardStocksViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewStockOutward').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewStockOutwardRecord: 'viewStockOutwardRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewStockOutwardModel').modal('show');
                        $('#viewStockOutward').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('.sortable').on('click', function () {
        const column = $(this).data('column');
        let order = $(this).data('order') || 'asc';
        order = order === 'asc' ? 'desc' : 'asc';

        $('.sortable').data('order', 'asc');
        $('.sortable i').removeClass('ti-sort-ascending ti-sort-descending text-emerald-500').addClass('ti-arrows-sort text-slate-400');

        $(this).data('order', order);
        const icon = $(this).find('i');
        icon.removeClass('ti-arrows-sort text-slate-400');
        if (order === 'asc') {
            icon.addClass('ti-sort-ascending text-emerald-500');
        } else {
            icon.addClass('ti-sort-descending text-emerald-500');
        }

        currentSortColumn = column;
        currentSortOrder = order;
        loadStocksOutwordTable(currentPage);
    });


    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $('#goodsDispatchedExportForm').on('submit', function (e) {
        e.preventDefault();
        page = 1;
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#exportFromDate').val();
        const toDate = $('#exportToDate').val();
        const form = document.getElementById('goodsDispatchedExportForm');
        const formData = new FormData(form);
        formData.append('exportGoodsDispatched', 'exportGoodsDispatched');
        formData.append('search', search);
        formData.append('perPage', perPage);
        formData.append('page', page);
        formData.append('fromDate', fromDate);
        formData.append('toDate', toDate);
        // formData.append('conditions', JSON.stringify(selectedPhysicalConditionType));
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');

        $.ajax({
            url: 'exportajax.php', // Change to your handler script
            type: 'POST',
            data: formData,
            contentType: false, // Must for FormData
            processData: false,
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.outwardStocksEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#outwardStocksEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchStockOutwardEditRecord: 'fetchStockOutwardEditRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#outwardStocksEditModal').modal('show');
                        $('#outwardStocksEditForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#outwardStocksEditForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('outwardStocksEditForm');
        const formData = new FormData(form);
        formData.append('updateStockOutwardEditRecord', 'updateStockOutwardEditRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#outwardStocksEditModal').modal('hide');
                    $('#outwardStocksEditForm').find('modal-body').html();
                    loadStocksOutwordTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    // Upcoming Issuances Logic
    let currentUpcomingIssuancePage = 1;

    function issuanceAlertPageButtons(totalPages, currentPage) {
        const pages = [...new Set([1, totalPages, currentPage - 2, currentPage - 1, currentPage, currentPage + 1, currentPage + 2]
            .filter(page => page >= 1 && page <= totalPages))].sort((a, b) => a - b);
        let previous = 0;
        return pages.map(function (page) {
            const gap = previous && page > previous + 1 ? '<span class="px-1 text-slate-400">&hellip;</span>' : '';
            previous = page;
            const active = page === currentPage ? 'bg-emerald-800 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100';
            return gap + `<button type="button" data-page="${page}" class="issuance-alert-page inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-sm font-bold ${active}">${page}</button>`;
        }).join('');
    }

    function loadUpcomingIssuances(page = 1, showLoader = false) {
        if (showLoader) {
            $('#upcomingIssuanceTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadUpcomingIssuances: 'loadUpcomingIssuances',
                page: page
            },
            success: function (response) {
                if (response.status !== 'success') {
                    return;
                }

                const issuances = Array.isArray(response.issuances) ? response.issuances : [];
                const totalRows = Number(response.totalRows || 0);
                const totalPages = Math.max(1, Number(response.totalPages || 1));
                currentUpcomingIssuancePage = Math.min(Math.max(1, Number(response.page || 1)), totalPages);
                $('#upcomingIssuanceCountBadge').text(totalRows);
                $('#upcomingIssuanceCountText').text(totalRows);
                $('#upcomingIssuanceCount').text(totalRows);

                if (totalRows > 0) {
                    $('#upcomingIssuanceWidget').show();
                } else {
                    $('#upcomingIssuanceWidget').hide();
                }

                if (issuances.length === 0) {
                    $('#upcomingIssuanceTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-slate-500 bg-white">No upcoming issuances available.</td></tr>');
                } else {
                    const rows = issuances.map((item, index) => {
                        const globalIndex = ((currentUpcomingIssuancePage - 1) * 10) + index + 1;
                        return `<tr class="transition-colors hover:bg-slate-50/50">
                            <td class="px-6 py-4 font-semibold text-slate-900">${globalIndex}</td>
                            <td class="px-6 py-4 font-medium text-slate-600">${item.date || ''}</td>
                            <td class="px-6 py-4 font-bold text-slate-900">${$('<span>').text(item.product_name || '').html()}<span class="mt-1 block text-xs font-medium text-slate-600">${$('<span>').text(item.production_plan_no || '').html()}</span></td>
                            <td class="px-6 py-4 font-medium text-slate-600">${item.batch_no || ''}</td>
                            <td class="px-6 py-4 font-medium text-slate-600">${item.batch_size || ''} ${item.unit || ''}</td>
                            <td class="px-6 py-4 text-right">
                                ${item.bom_master_id > 0 ? `<button type="button" class="upcomingIssuanceLocateBtn inline-flex h-8 items-center justify-center rounded-lg px-3 text-[11px] font-bold ring-1 ring-inset bg-white text-purple-700 ring-purple-200 transition-colors hover:bg-purple-50" data-req-id="${item.id}" data-bom-id="${item.bom_master_id}" data-batch-size="${item.batch_size}" data-product="${item.product_name}" data-batch="${item.batch_no}">View BOM</button>` : `<span class="text-xs text-slate-400">No BOM</span>`}
                            </td>
                        </tr>`;
                    }).join('');
                    $('#upcomingIssuanceTableBody').html(rows);
                }

                const shownThrough = Math.min(currentUpcomingIssuancePage * 10, totalRows);
                const startRow = totalRows === 0 ? 0 : ((currentUpcomingIssuancePage - 1) * 10) + 1;
                $('#upcomingIssuanceSummary').text(`Showing ${startRow} to ${shownThrough} of ${totalRows} entries`);
                $('#upcomingIssuanceCurrentPage').html(issuanceAlertPageButtons(totalPages, currentUpcomingIssuancePage));
                $('#upcomingIssuancePrev').prop('disabled', currentUpcomingIssuancePage <= 1);
                $('#upcomingIssuanceNext').prop('disabled', currentUpcomingIssuancePage >= totalPages);
            },
            error: function () {
                if (showLoader) {
                    $('#upcomingIssuanceTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-rose-500 bg-white">Error loading data.</td></tr>');
                }
            }
        });
    }

    $(document).on('click', '#upcomingIssuanceWidget', function () {
        loadUpcomingIssuances(1, true);
        $('#upcomingIssuanceModal').modal('show');
    });

    $(document).on('keydown', '#upcomingIssuanceWidget', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            $(this).trigger('click');
        }
    });

    $(document).on('click', '#upcomingIssuancePrev', function () {
        if (currentUpcomingIssuancePage > 1) {
            loadUpcomingIssuances(currentUpcomingIssuancePage - 1, true);
        }
    });

    $(document).on('click', '#upcomingIssuanceNext', function () {
        loadUpcomingIssuances(currentUpcomingIssuancePage + 1, true);
    });

    $(document).on('click', '.issuance-alert-page', function () {
        loadUpcomingIssuances(Number($(this).data('page') || 1), true);
    });

    // View BOM Logic
    $(document).on('click', '.upcomingIssuanceLocateBtn', function () {
        const reqId = $(this).data('req-id');
        const productName = $(this).data('product');
        const batchNo = $(this).data('batch');

        $('#issueBomSubmitBtn').data('req-id', reqId);
        $('#upcomingIssuanceModal').modal('hide');
        $('#viewBomModalBatchTitle').text(`Review required components for Batch ${batchNo} | ${productName}`);
        $('#viewBomModalTableBody').html('<tr><td colspan="4" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        $('#viewBomModal').modal('show');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getMaterialRequisitionItemsForIssuance: 'getMaterialRequisitionItemsForIssuance',
                req_id: reqId
            },
            success: function(response) {
                if (response.status === 'success' || (response.items && Array.isArray(response.items))) {
                    const items = response.items || [];
                    if (items.length === 0) {
                        $('#viewBomModalTableBody').html('<tr><td colspan="5" class="px-6 py-10 text-center text-sm font-medium text-slate-500">No components found in BOM.</td></tr>');
                    } else {
                        let hasShortage = false;
                        const rows = items.map((item, idx) => {
                            const unitName = item.unit_name ? `${item.unit_name}` : '';
                            const reqQty = Number(item.required || 0);
                            const reqQtyDisplay = `${reqQty.toLocaleString('en-IN', { maximumFractionDigits: 8 })} ${unitName}`.trim();
                            const availQty = Number(item.available_stock || 0);
                            const availQtyDisplay = `${availQty.toLocaleString('en-IN', { maximumFractionDigits: 8 })} ${unitName}`.trim();
                            const isSufficient = availQty >= (reqQty - 0.000001);
                            if (!isSufficient) hasShortage = true;

                            const stockBadge = isSufficient
                                ? `<span class="inline-flex items-center gap-1 rounded-md bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-600/20"><i class="ti ti-check text-xs"></i> ${availQtyDisplay}</span>`
                                : `<span class="inline-flex items-center gap-1 rounded-md bg-rose-50 px-2 py-1 text-xs font-semibold text-rose-700 ring-1 ring-inset ring-rose-600/20" title="Deficit: ${(reqQty - availQty).toFixed(4)} ${unitName}"><i class="ti ti-alert-triangle text-xs"></i> ${availQtyDisplay} (Short)</span>`;

                            const prodId = item.product_id || 0;
                            const unitId = item.unit_id || 0;
                            const catId = item.category_id || 0;
                            const mrItemId = item.mr_item_id || 0;
                            return `<tr class="transition-colors hover:bg-slate-50/50" data-mr-item-id="${mrItemId}" data-product-id="${prodId}" data-unit-id="${unitId}" data-category-id="${catId}">
                                <td class="px-6 py-4 font-semibold text-slate-900">${idx + 1}</td>
                                <td class="px-6 py-4 font-bold text-slate-900">${$('<div>').text(item.product_name || '').html()}</td>
                                <td class="px-6 py-4 font-bold text-slate-900">${reqQtyDisplay}</td>
                                <td class="px-6 py-4">${stockBadge}</td>
                                <td class="px-6 py-4">
                                    <input type="number" min="0.00000001" max="${reqQty}" step="any" class="issuedQtyInput form-control form-control-sm !rounded-lg w-full max-w-[140px] font-bold text-slate-700" value="${reqQty}" aria-label="Issued quantity for ${$('<div>').text(item.product_name || '').html()}">
                                </td>
                            </tr>`;
                        }).join('');
                        $('#viewBomModalTableBody').html(rows);
                    }
                } else {
                    $('#viewBomModalTableBody').html(`<tr><td colspan="4" class="px-6 py-10 text-center text-rose-500">${response.message || 'Error loading BOM'}</td></tr>`);
                }
            },
            error: function() {
                $('#viewBomModalTableBody').html('<tr><td colspan="4" class="px-6 py-10 text-center text-rose-500">Error loading data.</td></tr>');
            }
        });
    });

    $(document).on('click', '#issueBomSubmitBtn', function () {
        const reqId = $(this).data('req-id');
        const items = [];

        $('#viewBomModalTableBody tr').each(function () {
            const mrItemId = $(this).data('mr-item-id');
            const productId = $(this).data('product-id');
            const unitId = $(this).data('unit-id');
            const catId = $(this).data('category-id');
            const issuedQtyStr = $(this).find('input.issuedQtyInput').val() || '';
            const issuedQty = parseFloat(issuedQtyStr.replace(/[^0-9.]/g, '')) || 0;

            if (mrItemId && productId) {
                items.push({
                    mr_item_id: mrItemId,
                    product_id: productId,
                    issued_qty: issuedQty,
                    unit_id: unitId,
                    category_id: catId
                });
            }
        });

        const $btn = $(this);
        $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin me-2 text-lg"></i> Issuing...');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                issueBomItems: 'issueBomItems',
                csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
                req_id: reqId,
                items: JSON.stringify(items)
            },
            success: function (res) {
                $btn.prop('disabled', false).html('<i class="ti ti-edit me-2 text-lg"></i> Issue BOM');
                if (res.status === 'success') {
                    toastr.success(res.message || 'BOM items issued successfully!');
                    $('#viewBomModal').modal('hide');
                    loadStocksOutwordTable(1);
                    loadUpcomingIssuances(1, false);
                    if (res.redirect_url) {
                        setTimeout(function () {
                            window.location.href = res.redirect_url;
                        }, 700);
                    }
                } else {
                    toastr.error(res.message || 'Failed to issue BOM.');
                }
            },
            error: function () {
                $btn.prop('disabled', false).html('<i class="ti ti-edit me-2 text-lg"></i> Issue BOM');
                toastr.error('Server error while issuing BOM.');
            }
        });
    });

    let manualBomData = null;

    function escapeGoodsIssueText(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function loadManualFinishedProducts() {
        const $select = $('#manualFinishedProduct');
        $select.html('<option value="">Loading products...</option>');
        $.post('ajax.php', { loadFinishedProductsWithBom: 'loadFinishedProductsWithBom' }, function (response) {
            if (!response || response.status !== 'success') {
                toastr.error(response && response.message ? response.message : 'Unable to load finished products.');
                return;
            }
            let options = '<option value="">Select finished product</option>';
            (response.products || []).forEach(function (product) {
                options += `<option value="${product.id}" data-unit-name="${escapeGoodsIssueText(product.unit_name)}" data-product-name="${escapeGoodsIssueText(product.product_name)}">${escapeGoodsIssueText(product.product_name)}</option>`;
            });
            $select.html(options).trigger('change');
        }, 'json').fail(function () {
            toastr.error('Unable to load finished products.');
        });
    }

    $(document).on('click', '#openManualBomIssuanceBtn', function () {
        manualBomData = null;
        $('#manualBomIssuanceForm')[0].reset();
        $('#manualBomItemsBody').html('<tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-500">Select a finished product and batch size to load its BOM.</td></tr>');
        $('#submitManualBomIssuanceBtn').prop('disabled', true);
        loadManualFinishedProducts();
        $('#manualBomIssuanceModal').modal('show');
    });

    $(document).on('change', '#manualFinishedProduct', function () {
        const unitName = $(this).find(':selected').data('unit-name') || '';
        $('#manualBatchUnit').val(unitName);
        manualBomData = null;
        $('#submitManualBomIssuanceBtn').prop('disabled', true);
    });

    $(document).on('input', '#manualBatchSize', function () {
        manualBomData = null;
        $('#submitManualBomIssuanceBtn').prop('disabled', true);
    });

    $(document).on('click', '#loadManualBomBtn', function () {
        const productId = Number($('#manualFinishedProduct').val() || 0);
        const batchSize = Number($('#manualBatchSize').val() || 0);
        if (!productId || batchSize <= 0) {
            toastr.error('Select a finished product and enter a batch size greater than zero.');
            return;
        }
        const $button = $(this);
        $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Loading');
        $.post('ajax.php', {
            getScaledBomForManualIssuance: 'getScaledBomForManualIssuance',
            finished_product_id: productId,
            batch_size: batchSize
        }, function (response) {
            if (!response || response.status !== 'success' || !response.bom) {
                manualBomData = null;
                $('#submitManualBomIssuanceBtn').prop('disabled', true);
                const errMsg = escapeGoodsIssueText(response && response.message ? response.message : 'Unable to load BOM.');
                const selectedName = escapeGoodsIssueText($('#manualFinishedProduct option:selected').data('product-name') || $('#manualFinishedProduct option:selected').text() || '');
                $('#manualBomItemsBody').html(`
                    <tr>
                        <td colspan="4" class="px-6 py-6 text-center">
                            <div class="flex flex-col items-center gap-3">
                                <div class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-50 text-amber-600">
                                    <i class="ti ti-alert-triangle text-2xl"></i>
                                </div>
                                <p class="text-sm font-semibold text-rose-600 m-0">${errMsg}</p>
                                <p class="text-xs text-slate-500 m-0">Please ensure the BOM is created and approved before issuing goods.</p>
                                <div class="flex items-center gap-2">
                                    <a href="index.php?page=store-setting" target="_blank" class="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50">
                                        <i class="ti ti-external-link text-sm"></i> Open BOM Management
                                    </a>
                                    <button type="button" id="giCreateCloneBomBtn" class="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-sm transition-colors hover:bg-indigo-700" data-product-id="${productId}" data-product-name="${selectedName}">
                                        <i class="ti ti-copy text-sm"></i> Create / Clone BOM
                                    </button>
                                </div>
                            </div>
                        </td>
                    </tr>
                `);
                return;
            }
            manualBomData = response.bom;
            const rows = (manualBomData.items || []).map(function (item, index) {
                const required = Number(item.required_qty || 0);
                return `<tr class="manual-bom-item" data-product-id="${item.product_id}">
                    <td class="px-6 py-3 font-semibold text-slate-500">${index + 1}</td>
                    <td class="px-6 py-3 font-bold text-slate-900">${escapeGoodsIssueText(item.product_name)}</td>
                    <td class="px-6 py-3 font-semibold text-slate-700">${required.toLocaleString('en-IN', { maximumFractionDigits: 8 })} ${escapeGoodsIssueText(item.unit_name)}</td>
                    <td class="px-6 py-3"><input type="number" min="0.00000001" max="${required}" step="any" value="${required}" class="manual-issued-qty input-theme" required></td>
                </tr>`;
            }).join('');
            $('#manualBomItemsBody').html(rows || '<tr><td colspan="4" class="px-6 py-8 text-center text-sm text-rose-600">No BOM materials found.</td></tr>');
            $('#submitManualBomIssuanceBtn').prop('disabled', !rows);
        }, 'json').fail(function () {
            toastr.error('Unable to load BOM.');
        }).always(function () {
            $button.prop('disabled', false).html('<i class="ti ti-sitemap"></i> Load BOM');
        });
    });

    $(document).on('submit', '#manualBomIssuanceForm', function (event) {
        event.preventDefault();
        if (!manualBomData) {
            toastr.error('Load the BOM before issuing goods.');
            return;
        }
        const items = [];
        let invalid = false;
        $('#manualBomItemsBody .manual-bom-item').each(function () {
            const input = this.querySelector('.manual-issued-qty');
            const issued = Number(input.value || 0);
            const maximum = Number(input.max || 0);
            if (issued <= 0 || issued > maximum + 0.00000001) {
                invalid = true;
                input.reportValidity();
                return false;
            }
            items.push({ product_id: Number($(this).data('product-id')), issued_qty: issued });
        });
        if (invalid || !items.length) {
            toastr.error('Every issued quantity must be greater than zero and cannot exceed its required quantity.');
            return;
        }
        const $button = $('#submitManualBomIssuanceBtn');
        $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Issuing...');
        $.post('ajax.php', {
            createManualBomIssuance: 'createManualBomIssuance',
            finished_product_id: manualBomData.finished_product_id,
            batch_size: manualBomData.batch_size,
            items: JSON.stringify(items)
        }, function (response) {
            if (response && response.status === 'success') {
                toastr.success(response.message || 'Goods issued to Production successfully.');
                $('#manualBomIssuanceModal').modal('hide');
                loadStocksOutwordTable(1);
                loadUpcomingIssuances(1, false);
            } else {
                toastr.error(response && response.message ? response.message : 'Unable to issue BOM materials.');
            }
        }, 'json').fail(function () {
            toastr.error('Unable to issue BOM materials.');
        }).always(function () {
            $button.prop('disabled', false).html('<i class="ti ti-package-export"></i> Issue to Production');
        });
    });
</script>

<div class="modal fade animate__animated fadeIn" id="manualBomIssuanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-6 !py-4">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700"><i class="ti ti-package-export text-xl"></i></span>
                    <div><h5 class="m-0 text-lg font-bold text-slate-900">Goods Issued to Production</h5><p class="m-0 text-sm text-slate-500">Issue materials from the finished-product BOM</p></div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
            </div>
            <form id="manualBomIssuanceForm">
                <div class="modal-body bg-slate-50/50 !px-6 !py-5">
                    <div class="grid grid-cols-1 gap-3 md:grid-cols-4 mb-4">
                        <div class="md:col-span-2"><label class="mb-1 block text-sm font-medium text-slate-800">Finished Product <strong class="text-rose-500">*</strong></label><select id="manualFinishedProduct" class="input-theme" required></select></div>
                        <div><label class="mb-1 block text-sm font-medium text-slate-800">Batch Size <strong class="text-rose-500">*</strong></label><input id="manualBatchSize" type="number" min="0.00000001" step="any" class="input-theme" required></div>
                        <div><label class="mb-1 block text-sm font-medium text-slate-800">Unit</label><input id="manualBatchUnit" type="text" class="input-theme bg-slate-100" readonly></div>
                    </div>
                    <div class="mb-4 flex justify-end"><button type="button" id="loadManualBomBtn" class="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-bold text-white hover:bg-indigo-700"><i class="ti ti-sitemap"></i> Load BOM</button></div>
                    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white"><div class="overflow-x-auto"><table class="w-full text-left"><thead class="border-b border-slate-100 bg-slate-50"><tr><th class="px-6 py-3 text-xs font-bold text-slate-500">#</th><th class="px-6 py-3 text-xs font-bold text-slate-500">Material</th><th class="px-6 py-3 text-xs font-bold text-slate-500">Required Qty</th><th class="px-6 py-3 text-xs font-bold text-slate-500">Issued Qty</th></tr></thead><tbody id="manualBomItemsBody"><tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-500">Select a finished product and batch size to load its BOM.</td></tr></tbody></table></div></div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-6 !py-4"><button type="button" class="inline-flex h-10 items-center rounded-xl border border-slate-200 px-5 text-sm font-bold text-slate-700" data-bs-dismiss="modal">Cancel</button><button type="submit" id="submitManualBomIssuanceBtn" class="inline-flex h-10 items-center gap-2 rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white hover:bg-emerald-800" disabled><i class="ti ti-package-export"></i> Issue to Production</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Upcoming Issuance Modal -->
<div class="modal fade animate__animated fadeIn" id="upcomingIssuanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Modal Header -->
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4 relative">
                <div class="flex items-center gap-4">
                    <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.5rem; height: 3.5rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                        <i class="ti ti-clipboard-data" style="font-size: 1.75rem; color: var(--appearance-accent, #7e22ce);"></i>
                        <span style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                    </div>
                    <div>
                        <h5 class="modal-title m-0 font-bold leading-tight" style="font-size: 1.25rem; color: var(--ui-text, #1e293b);">Goods Issued to Production</h5>
                        <p class="m-0 mt-1 font-medium" style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">These ordered items have been sent from Material Requisition and need to be produced.</p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none ml-auto" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full border-collapse text-left">
                        <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                            <tr>
                                <th class="w-12 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">#</th>
                                <th class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">Date</th>
                                <th class="w-48 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">Product</th>
                                <th class="w-44 min-w-[160px] px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">Lot #</th>
                                <th class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">Batch Size</th>
                                <th class="w-20 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody id="upcomingIssuanceTableBody" class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                            <tr>
                                <td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-slate-500">Loading upcoming issuances...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Footer -->
                <div class="flex flex-col md:flex-row items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
                    <span id="upcomingIssuanceSummary" class="text-sm font-medium text-slate-500">Showing 0 to 0 of 0 entries</span>
                    <div class="flex items-center gap-1">
                        <button id="upcomingIssuancePrev" type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40" title="Previous page" disabled><i class="ti ti-arrow-left text-sm"></i></button>
                        <div id="upcomingIssuanceCurrentPage" class="flex items-center gap-1"></div>
                        <button id="upcomingIssuanceNext" type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40" title="Next page" disabled><i class="ti ti-arrow-right text-sm"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- View BOM Modal -->
<div class="modal fade animate__animated fadeIn" id="viewBomModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Modal Header -->
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4 relative">
                <div class="flex items-center gap-4">
                    <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.5rem; height: 3.5rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                        <i class="ti ti-sitemap" style="font-size: 1.75rem; color: var(--appearance-accent, #7e22ce);"></i>
                    </div>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold leading-tight text-slate-900">View BOM</h5>
                    </div>
                </div>
                <button type="button" class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600 focus:outline-none ml-auto" data-bs-dismiss="modal" aria-label="Close" onclick="$('#upcomingIssuanceModal').modal('show');">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            
            <div class="modal-body p-6 bg-slate-50/50">
                <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div class="overflow-x-auto w-full">
                        <table class="w-full border-collapse text-left">
                            <thead class="border-b border-slate-100 bg-slate-50/30 whitespace-nowrap">
                                <tr>
                                    <th class="w-16 px-6 py-4 text-[12px] font-bold text-slate-400">#</th>
                                    <th class="px-6 py-4 text-[12px] font-bold text-slate-400">Product Name</th>
                                    <th class="px-6 py-4 text-[12px] font-bold text-slate-400">Req. Qty</th>
                                    <th class="px-6 py-4 text-[12px] font-bold text-slate-400">In Stock</th>
                                    <th class="px-6 py-4 text-[12px] font-bold text-slate-400">Issued Qty</th>
                                </tr>
                            </thead>
                            <tbody id="viewBomModalTableBody" class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                                <tr>
                                    <td colspan="5" class="px-6 py-10 text-center text-sm font-medium text-slate-500">Loading BOM details...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer border-t border-slate-100 bg-white px-6 py-4 flex justify-end gap-3">
                <button type="button" id="issueBomSubmitBtn" class="inline-flex h-10 items-center justify-center rounded-xl px-6 text-sm font-bold text-white transition-colors" style="background-color: #6d28d9;">
                    <i class="ti ti-edit me-2 text-lg"></i> Issue BOM
                </button>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/clone-bom-modal.php'; ?>

<script>
$(function() {
    // ── Create/Clone BOM button handler for Goods Issuance ──
    $(document).on('click', '#giCreateCloneBomBtn', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const productId = Number($(this).data('product-id') || $('#manualFinishedProduct').val() || 0);
        const productName = $(this).data('product-name') || $('#manualFinishedProduct option:selected').text() || '';

        if (!productId) {
            toastr.error('Please select a finished product first.');
            return;
        }

        // Close the manual issuance modal first, then open clone modal
        const $giModal = $('#manualBomIssuanceModal');
        const launchClone = function() {
            // Remove stale backdrops
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open');

            if (typeof window.openCloneBomModal === 'function') {
                window.openCloneBomModal(productId, productName, null, function(newBomRes) {
                    toastr.info('BOM submitted for approval. Once approved, the product will appear in the Goods Issuance dropdown and you can proceed.');
                });
            } else {
                toastr.error('Clone BOM modal is not available.');
            }
        };

        if ($giModal.length && $giModal.hasClass('show')) {
            $giModal.one('hidden.bs.modal', function() {
                setTimeout(launchClone, 50);
            });
            $giModal.modal('hide');
        } else {
            launchClone();
        }
    });
});
</script>

<?php endSection(); ?>
