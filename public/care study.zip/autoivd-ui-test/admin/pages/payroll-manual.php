<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
        </div>
    </div>
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelectPayrollManual" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="payrollManualPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="payroll-manual-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="payroll-manual-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="payroll-manual-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="payroll-manual-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="payroll-manual-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="payroll-manual-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchPayrollManual"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <div class="flex flex-col md:flex-row items-stretch md:items-center gap-2 shrink-0 w-full md:w-auto">
                        <input type="text" name="monthPay" id="monthPayrollManual" value="<?= date('Y-m') ?>"
                            class="flatpickr-month h-10 w-full md:w-32 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors hover:bg-slate-50 hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Select Month" />

                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex h-10 w-full md:w-auto items-center justify-between md:justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dropdown-toggle"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span>Company</span> <i class="ti ti-filter"></i>
                            </button>
                            <div class="dropdown-menu min-w-48 !rounded-xl border border-slate-200 p-2 shadow-xl">
                                <?php if (!empty(Constant::EMPLOYEES['COMPANY_TYPE_LIST'])) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox"
                                            class="company-filter rounded border-slate-300 accent-emerald-600" value="all">
                                        <span>All</span>
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['COMPANY_TYPE_LIST'] as $sfpckey => $sfpcval) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox"
                                                class="company-filter rounded border-slate-300 accent-emerald-600"
                                                value="<?php echo $sfpckey; ?>"> <span><?php echo $sfpcval['label']; ?></span>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>

                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex h-10 w-full md:w-auto items-center justify-between md:justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dropdown-toggle"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span>Status</span> <i class="ti ti-filter"></i>
                            </button>
                            <div class="dropdown-menu min-w-48 !rounded-xl border border-slate-200 p-2 shadow-xl">
                                <?php if (!empty(Constant::EMPLOYEES['STATUS_TYPES'])) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox"
                                            class="status-filter rounded border-slate-300 accent-emerald-600" value="all">
                                        <span>All</span>
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['STATUS_TYPES'] as $sfpckey => $sfpcval) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox"
                                                class="status-filter rounded border-slate-300 accent-emerald-600"
                                                value="<?php echo $sfpckey; ?>"> <span><?php echo $sfpcval['label']; ?></span>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>

                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex h-10 w-full md:w-auto items-center justify-between md:justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dropdown-toggle"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span>Category</span> <i class="ti ti-filter"></i>
                            </button>
                            <div class="dropdown-menu min-w-48 !rounded-xl border border-slate-200 p-2 shadow-xl">
                                <?php if (!empty(Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'])) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox"
                                            class="category-filter rounded border-slate-300 accent-emerald-600" value="all">
                                        <span>All</span>
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'] as $sipckey => $sipcval) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox"
                                                class="category-filter rounded border-slate-300 accent-emerald-600"
                                                value="<?php echo $sipckey; ?>"> <span><?php echo $sipcval['label']; ?></span>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="border-b border-slate-200 bg-white px-6 py-3">
                <div class="flex flex-col md:flex-row flex-wrap items-stretch md:items-center gap-3 justify-between w-full">
                    <div class="flex flex-col md:flex-row flex-wrap items-stretch md:items-center gap-2 w-full md:w-auto">
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl bg-slate-800 px-3 text-sm font-bold text-white shadow-sm ring-1 ring-slate-900/10 transition-colors hover:bg-slate-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-slate-500/30"
                            id="addEmployeeAttendanceFormModalBtn">
                            <i class="ti ti-calendar-plus text-lg"></i> <span class="whitespace-nowrap">Bulk Attendance</span>
                        </button>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl bg-blue-600 px-3 text-sm font-bold text-white shadow-sm ring-1 ring-blue-900/10 transition-colors hover:bg-blue-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                            id="addEmployeeHalfdayAttendanceFormModalBtn">
                            <i class="ti ti-clock text-lg"></i> <span class="whitespace-nowrap">Mark Halfday</span>
                        </button>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-3 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="addEmpSalaryModalBtn">
                            <i class="ti ti-cash text-lg"></i> <span class="whitespace-nowrap">Salary</span>
                        </button>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl px-3 text-sm font-bold text-white shadow-sm transition-all hover:opacity-90 focus:outline-none"
                            style="background-color: #f97316;"
                            id="reviewAccountUpdateBtn"
                            data-bs-toggle="modal" data-bs-target="#reviewAccountUpdateModal">
                            <i class="ti ti-file-text text-lg"></i> <span class="whitespace-nowrap">Review Account Update</span>
                        </button>
                        <button type="button" 
                            class="d-none hidden inline-flex h-10 shrink-0 items-center justify-center gap-2 !rounded-xl bg-orange-500 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-orange-600/10 transition-colors hover:bg-orange-600 focus:outline-none" 
                            id="sendRequestBtn"
                            data-bs-toggle="modal" data-bs-target="#sendRequestModal">
                            <i class="ti ti-send text-lg"></i> <span class="whitespace-nowrap">Send Request</span>
                        </button>
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-full md:w-32 h-10" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                </div>
            </div>


            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="px-6 py-3">#</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50 whitespace-nowrap"
                                data-column="emp.emp_code" data-default="asc" data-bs-toggle="popover"
                                data-bs-placement="top" data-bs-original-title="Emp Code">
                                <span class="inline-flex items-center gap-1">Emp Code <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50 whitespace-nowrap"
                                data-column="emp.first_name" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" data-bs-original-title="Name">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Category">Category</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Status">Status</th>
                            <th class="px-6 py-3 whitespace-nowrap" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Monthly Salary">Monthly Salary</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Daily Wage">Daily Wage</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Total Working Days">TW Days</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Absents">Absents</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Week Off Days">Week Off</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Total Holidays">Holidays</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Gross Earned">Gross Earned</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="PF Amount">PF Amount</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="ESIC Amount">ESIC Amount</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Advance Count">Advance Count</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Advance AMT">Advance AMT</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Net Salary">Net Salary</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="UAN">UAN</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="ESIC">ESIC</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Acc No">Acc No</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                data-bs-original-title="Bank">Bank</th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="payrollManualTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <style>#footerPerPageSelectPayrollManual + .dropdown { display: none !important; }</style>
                <?= getPaginationFooter('paginationWrapperPayrollManual', 'paginationSummaryPayrollManual', 'footerPerPageSelectPayrollManual') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addEmployeeSalaryFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable my-4" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-cash text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Employee Salary</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update employee salary and allowances
                                details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addEmployeeSalaryForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="employeeList" class="form-label">Employee <strong
                                        class="text-danger">*</strong></label>
                                <select name="employeeListId" id="employeeList" class="form-control select2" required>
                                    <option value="">--Select Employee--</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="basicCapingSalary" class="form-label">Basic Capping Salary For PF/ESI
                                    <strong class="text-danger">*</strong></label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="basicCapingSalary" name="basicCapingSalary" placeholder="0.00" required />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="monthlySalary" class="form-label">Monthly Salary <strong
                                        class="text-danger">*</strong></label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="monthlySalary" name="monthlySalary" placeholder="0.00" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="hra" class="form-label">HRA </label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="hra" name="hra" placeholder="0.00" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="convenceAllowance" class="form-label">Convence Allw.</label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="convenceAllowance" name="convenceAllowance" placeholder="0.00" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="medicalAllowance" class="form-label">Medical Allw.</label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="medicalAllowance" name="medicalAllowance" placeholder="0.00" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="specialAllowance" class="form-label">Special Allw.</label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="specialAllowance" name="specialAllowance" placeholder="0.00" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="incentives" class="form-label">Incentives</label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="incentives" name="incentives" placeholder="0.00" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="deductions" class="form-label">Deductions</label>
                                <input type="number" step="any" min="0" class="form-control" autocomplete="false"
                                    id="deductions" name="deductions" placeholder="0.00" />
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="salaryEffectiveFromDate" class="form-label">Effective From <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" class="form-control flatpickr-date" autocomplete="false"
                                    id="salaryEffectiveFromDate" name="salaryEffectiveFromDate" placeholder="YYYY-MM-DD"
                                    required />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="salaryEffectiveToDate" class="form-label">Effective To </label>
                                <input type="text" class="form-control flatpickr-date" autocomplete="false"
                                    id="salaryEffectiveToDate" name="salaryEffectiveToDate" placeholder="YYYY-MM-DD" />
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer p-4 pt-0 flex justify-end gap-3 border-0 bg-transparent">
                        <button type="button"
                            class="inline-flex h-10 items-center justify-center rounded-xl bg-rose-100 px-6 text-sm font-semibold text-rose-600 transition-colors hover:bg-rose-200 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 items-center justify-center rounded-full bg-emerald-600 px-6 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addEmployeeAttendanceFormModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable my-4" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-calendar-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Employee Attendance</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Add bulk attendance for employees</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addEmployeeAttendanceForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div id="productsWrapperWhole"></div>
                            <div class="mb-1">
                                <button type="button"
                                    class="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-emerald-100 px-4 text-sm font-semibold text-emerald-700 transition-colors hover:bg-emerald-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addEmployeeBtn"><i class="ti ti-plus text-lg"></i> Add Employee</button>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-28 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-32 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addEmployeeHalfdayAttendanceFormModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable my-4" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-clock text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Mark Employee Halfday</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update halfday details for multiple
                                employees</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addEmployeeHalfdayAttendanceForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div id="productsWrapperWholeHalfday"></div>
                            <div class="mb-1">
                                <button type="button"
                                    class="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-emerald-100 px-4 text-sm font-semibold text-emerald-700 transition-colors hover:bg-emerald-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addEmployeeListBtn"><i class="ti ti-plus text-lg"></i> Add Employee</button>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-28 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-32 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="payroLLManualExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportType" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Employee Code" checked /> <span class="text-sm font-medium text-slate-700">Employee Code</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Name" checked /> <span class="text-sm font-medium text-slate-700">Name</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Category" checked /> <span class="text-sm font-medium text-slate-700">Category</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked /> <span class="text-sm font-medium text-slate-700">Status</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Basic Salary" checked /> <span class="text-sm font-medium text-slate-700">Basic Salary</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Day Pay" checked /> <span class="text-sm font-medium text-slate-700">Daily Wage</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Working Days" checked /> <span class="text-sm font-medium text-slate-700">Working Days</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Absents" checked /> <span class="text-sm font-medium text-slate-700">Absents</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Week Off" checked /> <span class="text-sm font-medium text-slate-700">Week Off</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Holidays" checked /> <span class="text-sm font-medium text-slate-700">Holidays</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Gross Earned" checked /> <span class="text-sm font-medium text-slate-700">Gross Earned</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="PF Amount" checked /> <span class="text-sm font-medium text-slate-700">PF Amount</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="ESIC Amount" checked /> <span class="text-sm font-medium text-slate-700">ESIC Amount</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Advance Count" checked /> <span class="text-sm font-medium text-slate-700">Advance Count</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Advance AMT" checked /> <span class="text-sm font-medium text-slate-700">Advance AMT</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Net Salary" checked /> <span class="text-sm font-medium text-slate-700">Net Salary</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="UAN" checked /> <span class="text-sm font-medium text-slate-700">UAN</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="ESIC" checked /> <span class="text-sm font-medium text-slate-700">ESIC</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Acc No" checked /> <span class="text-sm font-medium text-slate-700">Acc No</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Bank" checked /> <span class="text-sm font-medium text-slate-700">Bank</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php startSection('scripts'); ?>
<script src="<?= asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js') ?>"></script>
<!-- Review Account Update Modal -->
<div class="modal fade animate__animated fadeIn" id="reviewAccountUpdateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Header -->
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-6 !py-4">
                <div class="flex items-center gap-4">
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-100/50 text-[#1a4331] ring-1 ring-[#1a4331]/20">
                        <i class="ti ti-credit-card text-2xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-xl font-bold text-slate-900">Salary Account Update Requests</h5>
                        <p class="m-0 text-[13px] text-slate-500 mt-0.5">Review and manage employee bank details change requests</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-700 transition-colors"
                    data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            
            <!-- Body -->
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full table-auto text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400 whitespace-nowrap">
                            <tr>
                                <th class="px-6 py-3">Employee Name</th>
                                <th class="px-6 py-3">Current Account Name</th>
                                <th class="px-6 py-3">Current Account Number</th>
                                <th class="px-6 py-3">New Account Name</th>
                                <th class="px-6 py-3">New Account Number</th>
                                <th class="px-6 py-3 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="reviewAccountRequestsBody" class="bg-white divide-y divide-slate-100 text-sm text-slate-600 whitespace-nowrap">
                            <tr>
                                <td colspan="6" class="px-6 py-8 text-center text-slate-400 font-medium">
                                    <i class="ti ti-loader ti-spin text-lg mr-1"></i> Loading...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="modal-footer flex items-center justify-between border-t border-slate-200 bg-slate-50/50 !px-6 !py-4">
                <span class="text-xs text-slate-500 italic" id="pendingRequestsCount">Showing 0 pending requests</span>
                <button type="button"
                    class="inline-flex h-10 px-6 items-center justify-center !rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 hover:border-slate-400 focus:outline-none"
                    data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade animate__animated fadeIn" id="sendRequestModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Header -->
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-6 !py-4">
                <div class="flex items-center gap-4">
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-100/50 text-[#1a4331] ring-1 ring-[#1a4331]/20">
                        <i class="ti ti-send text-2xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-xl font-bold text-slate-900">Send Request</h5>
                        <p class="m-0 text-[13px] text-slate-500 mt-0.5">Submit and review new requests</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-700 transition-colors"
                    data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            
            <!-- Body -->
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full table-auto text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400 whitespace-nowrap">
                            <tr>
                                <th class="px-6 py-3">Employee Name</th>
                                <th class="px-6 py-3">Current Account Name</th>
                                <th class="px-6 py-3">Current Account Number</th>
                                <th class="px-6 py-3">New Account Name</th>
                                <th class="px-6 py-3">New Account Number</th>
                                <th class="px-6 py-3 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600 whitespace-nowrap">
                            <!-- No hardcoded data here -->
                            <tr>
                                <td colspan="6" class="px-6 py-8 text-center text-slate-400 font-medium">No pending requests found</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="modal-footer flex items-center justify-between border-t border-slate-200 bg-slate-50/50 !px-6 !py-4">
                <p class="text-[13px] text-slate-500 italic m-0">Showing 0 pending requests</p>
                <button type="button"
                    class="inline-flex h-10 px-6 items-center justify-center !rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 hover:border-slate-400 focus:outline-none"
                    data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    let currentPage = 1;
    let currentSortColumn = 'emp.id';
    let currentSortDirection = 'DESC';
    let employeesListOptionsForBulkAttendance = [];
    let selectedCategoryType = [];
    let selectedStatusFilters = [];
    let selectedCompanyFilters = [];
    let departmentListOptions = [];
    let itemIndex = 1;

    function loadPayrollManualTable(page = 1) {
        currentPage = page;
        const search = $('#searchPayrollManual').val().trim();
        const perPage = $('#perPageSelectPayrollManual').val();
        const monthPay = $('#monthPayrollManual').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadPayrollManually: 'loadPayrollManually',
                page: page,
                per_page: perPage,
                search: search,
                monthPay: monthPay,
                categoryType: selectedCategoryType,
                companyType: selectedCompanyFilters,
                selectedStatus: selectedStatusFilters,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#payrollManualTableBody').html(response.table || '');
                $('#paginationWrapperPayrollManual').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryPayrollManual', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectPayrollManual');
            },
            error: function () {
                $('#payrollManualTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperPayrollManual').html('');
            }
        });
    }

    function loadEmployeesList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadEmployeesListOption: 'loadEmployeesListOption'
            },
            success: function (response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">--Select Employee--</option>';
                departmentOptions.forEach(emp => {
                    optionsHtml += `<option value="${emp.id}">(${emp.emp_code}) ${emp.first_name} ${emp.last_name}</option>`;
                });
                $("#employeeList").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load employees:", error);
            }
        });
    }
    function loadEmployeesListAttendance(callback) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadEmployeesListOption: 'loadEmployeesListOption'
            },
            success: function (response) {
                employeesListOptionsForBulkAttendance = response;
                if (typeof callback === 'function') callback();
            },
            error: function (xhr, status, error) {
                console.error("Failed to load employees:", error);
            }
        });
    }

    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function (response) {
                departmentListOptions = response;
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function bindPayrollManualSelect2Scroll(modalSelector) {
        setTimeout(function() {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.payrollManualModalScroll')
                .on('wheel.payrollManualModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $(modalSelector + ' .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $(modalSelector + ' .select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }



    $(document).ready(function () {
        $(".category-filter").prop("checked", true);
        $(".status-filter").prop("checked", true);
        $(".company-filter").prop("checked", true);

        selectedCategoryType = [];
        $(".category-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCategoryType.push($(this).val());
            }
        });

        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });
        selectedCompanyFilters = [];
        $(".company-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCompanyFilters.push($(this).val());
            }
        });
        loadDepartmentsList();
        loadPayrollManualTable();
        function positionPayrollFlatpickr(self, customPositionElement) {
            if (!self.calendarContainer) return;
            const posElem = customPositionElement || self._positionElement || self._input;
            if (!posElem) return;

            const calendarHeight = self.calendarContainer.offsetHeight || Array.prototype.reduce.call(self.calendarContainer.children, (acc, child) => acc + child.offsetHeight, 0) || 360;
            const calendarWidth = self.calendarContainer.offsetWidth || 315;
            const inputBounds = posElem.getBoundingClientRect();
            const distanceFromBottom = window.innerHeight - inputBounds.bottom;
            const distanceFromTop = inputBounds.top;

            // Flip above if not enough room below or if more room above when cramped
            const showOnTop = (distanceFromBottom < (calendarHeight + 15) && distanceFromTop > distanceFromBottom) ||
                              (distanceFromBottom < calendarHeight && distanceFromTop >= calendarHeight);

            let top;
            if (showOnTop) {
                top = window.pageYOffset + inputBounds.top - calendarHeight - 2;
                if (top < window.pageYOffset + 10) {
                    top = window.pageYOffset + 10;
                }
            } else {
                top = window.pageYOffset + inputBounds.bottom + 2;
                const maxTop = window.pageYOffset + window.innerHeight - calendarHeight - 10;
                if (top > maxTop && distanceFromTop > 80) {
                    top = Math.max(window.pageYOffset + 10, maxTop);
                }
            }

            self.calendarContainer.classList.toggle("arrowTop", !showOnTop);
            self.calendarContainer.classList.toggle("arrowBottom", showOnTop);

            let left = window.pageXOffset + inputBounds.left;
            const rightEdge = window.pageXOffset + document.body.offsetWidth - 10;
            if (left + calendarWidth > rightEdge) {
                left = Math.max(window.pageXOffset + 10, rightEdge - calendarWidth);
            }

            self.calendarContainer.style.top = top + "px";
            self.calendarContainer.style.left = left + "px";
            self.calendarContainer.style.right = "auto";
            self.calendarContainer.style.zIndex = "999999";
        }

        $(document).on('select2:open', function(e) {
            const $modal = $(e.target).closest('#addEmployeeSalaryFormModal, #addEmployeeAttendanceFormModal, #addEmployeeHalfdayAttendanceFormModal');
            if (!$modal.length) return;
            bindPayrollManualSelect2Scroll('#' + $modal.attr('id'));
        });
        $('#addEmployeeSalaryFormModal .modal-body, #addEmployeeAttendanceFormModal .modal-body, #addEmployeeHalfdayAttendanceFormModal .modal-body, #addEmployeeSalaryFormModal, #addEmployeeAttendanceFormModal, #addEmployeeHalfdayAttendanceFormModal').on('scroll', function() {
            $(this).closest('.modal').find('.select2-hidden-accessible').select2('close');
            $('.flatpickr-input').each(function() {
                if (this._flatpickr && this._flatpickr.isOpen) {
                    this._flatpickr.close();
                }
            });
        });
        $('#searchPayrollManual').on('input', function () {
            loadPayrollManualTable(1);
        });
        $('#monthPayrollManual').on('input', function () {
            loadPayrollManualTable(1);
        });
        $('#footerPerPageSelectPayrollManual').on('change', function () {
            $('#perPageSelectPayrollManual').val($(this).val());
            loadPayrollManualTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.payroll-manual-per-page-item', function () {
            const val = $(this).data('val');
            $('#payrollManualPerPageText').text($(this).text());
            $('#footerPerPageSelectPayrollManual').val(val).trigger('change');
        });

        $('.flatpickr-date').flatpickr({
            dateFormat: 'Y-m-d',
            appendTo: document.body,
            position: positionPayrollFlatpickr,
            onOpen: function(selectedDates, dateStr, instance) {
                positionPayrollFlatpickr(instance);
            }
        });

        $('.flatpickr-month').flatpickr({
            dateFormat: 'Y-m',
            disableMobile: "true"
        });
        function updateColumnsSelectedText() {
            const checkedCount = $('.column-filter:checked').length;
            const totalCount = $('.column-filter').length;
            if (checkedCount === totalCount) {
                $('#columnsSelectedText').text(totalCount + ' items selected');
            } else if (checkedCount > 2) {
                $('#columnsSelectedText').text(checkedCount + ' items selected');
            } else if (checkedCount > 0) {
                let names = [];
                $('.column-filter:checked').each(function () {
                    names.push($(this).val());
                });
                $('#columnsSelectedText').text(names.join(', '));
            } else {
                $('#columnsSelectedText').text('----Select Columns----');
            }
        }

        $(document).on('change', '.column-filter', function () {
            updateColumnsSelectedText();
        });

        $(document).on('click', '#selectAllColumns', function () {
            $('.column-filter').prop('checked', true);
            updateColumnsSelectedText();
        });

        $(document).on('click', '#deselectAllColumns', function () {
            $('.column-filter').prop('checked', false);
            updateColumnsSelectedText();
        });

        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            $('#exportTypeText').text($(this).text());
            $('#exportType').val(val);
        });

        $('#addEmpSalaryModalBtn').on('click', function () {
            loadEmployeesList();
            $('#addEmployeeSalaryFormModal').modal('show');
        });

        $('#addEmployeeAttendanceFormModalBtn').on('click', function () {
            loadEmployeesListAttendance(function () {
                $('#productsWrapperWhole').html('');
                if ($('#productsWrapperWhole .product-entry').length === 0) {
                    $('#addEmployeeBtn').trigger('click');
                }
                $('#addEmployeeAttendanceFormModal').modal('show');
            });
        });

        $('#addEmployeeHalfdayAttendanceFormModalBtn').on('click', function () {
            loadEmployeesListAttendance(function () {
                $('#productsWrapperWholeHalfday').html('');
                if ($('#productsWrapperWholeHalfday .product-entry').length === 0) {
                    $('#addEmployeeListBtn').trigger('click');
                }
                $('#addEmployeeHalfdayAttendanceFormModal').modal('show');
            });
        });


        $('#payroLLManualExportForm').on('submit', function (e) {
            e.preventDefault();
            page = 1;
            currentPage = page;
            const search = $('#searchPayrollManual').val().trim();
            const perPage = $('#perPageSelectPayrollManual').val();
            const monthPay = $('#monthPayrollManual').val();

            if (!$('#exportType').val()) {
                toastr.error('Please select an export type.');
                return;
            }

            const form = document.getElementById('payroLLManualExportForm');
            const formData = new FormData(form);
            formData.append('exportPayrollManual', 'exportPayrollManual');
            formData.append('search', search);
            formData.append('perPage', perPage);
            formData.append('page', page);
            formData.append('monthPay', monthPay);
            formData.append('categoryType', JSON.stringify(selectedCategoryType));
            formData.append('selectedStatus', JSON.stringify(selectedStatusFilters));
            formData.append('companyType', JSON.stringify(selectedCompanyFilters));

            $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').removeClass('inline-flex').attr('style', 'display: none !important;');

            $.ajax({
                url: 'exportajax.php', // Change to your handler script
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    if (response.success === 'success') {
                        $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportType').val().toUpperCase()).removeClass('hidden d-none').addClass('inline-flex').attr('style', 'display: inline-flex !important;');
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addEmployeeSalaryForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addEmployeeSalaryForm');
            const formData = new FormData(form);
            formData.append('addEmployeeSalary', 'addEmployeeSalary');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addEmployeeSalaryFormModal').modal('hide');
                        $('#addEmployeeSalaryForm')[0].reset();
                        loadPayrollManualTable();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addEmployeeAttendanceFormModal').on('hidden.bs.modal', function () {
            $('#productsWrapperWhole .flatpickr-input').each(function() {
                if (this._flatpickr) {
                    this._flatpickr.destroy();
                }
            });
            $('#addEmployeeAttendanceForm')[0].reset();
            $('#addEmployeeAttendanceForm .select2').val(null).trigger('change');
            $('#productsWrapperWhole').empty();
        });

        $('#addEmployeeBtn').click(function () {
            let qtyUnitHtml = '<option value="">--Select Employee--</option>';
            employeesListOptionsForBulkAttendance.forEach(e => {
                qtyUnitHtml += `<option value="${e.id}">(${e.emp_code}) ${e.first_name} ${e.last_name}</option>`;
            });
            let department = '<option value="">--Select--</option>';
            departmentListOptions.forEach(dept => {
                department += `<option value="${dept.id}">${dept.name}</option>`;
            });

            const productBlock = `
            <div class="row product-entry mb-1 border rounded p-2" data-index="">
                <div class="col-md-3 mb-2">
                    <select name="employeesAttendList[]" class="select2 form-select form-select-lg employeesAttendList" data-allow-clear="true" required>                    
                        ${qtyUnitHtml}
                    </select>
                </div>                
                <div class="col-md-2 mb-2">
                    <select name="departmentAttendance[]" class="form-select form-select-md" data-allow-clear="true" required>                       
                        ${department}
                    </select>
                </div>                
                <div class="col-md-6 mb-2">                 
                    <input type="text" name="multiDate[]" class="form-control flatpickr-multi" placeholder="YYYY-MM-DD" />
                </div>                
                <div class="col-md-1 mb-2 d-flex align-items-end">
                    <button type="button" class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600 transition-colors hover:bg-red-100 hover:text-red-700 focus:outline-none focus:ring-2 focus:ring-red-500/30 removeEmpBtn"><i class="ti ti-trash text-lg"></i></button>               
                </div>
            </div>`;

            const $productBlock = $(productBlock);
            $('#productsWrapperWhole').append($productBlock);

            // Initialize Select2 on new fields only
            $productBlock.find('.select2').select2({
                placeholder: '--Select--',
                dropdownParent: $('#addEmployeeAttendanceFormModal')
            });
            $productBlock.find('.flatpickr-multi').flatpickr({
                dateFormat: "Y-m-d H:i",
                mode: "multiple",
                enableTime: true,
                appendTo: document.body,
                position: positionPayrollFlatpickr,
                onOpen: function(selectedDates, dateStr, instance) {
                    positionPayrollFlatpickr(instance);
                }
            });
        });

        $(document).on('click', '.removeEmpBtn', function () {
            $(this).closest('.product-entry').find('.flatpickr-input').each(function() {
                if (this._flatpickr) {
                    this._flatpickr.destroy();
                }
            });
            $(this).closest('.product-entry').remove();
        });

        $('#addEmployeeAttendanceForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addEmployeeAttendanceForm');
            const formData = new FormData(form);
            formData.append('addEmployeeBulkAttendance', 'addEmployeeBulkAttendance');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addEmployeeAttendanceFormModal').modal('hide');
                        $('#addEmployeeAttendanceForm')[0].reset();
                        loadPayrollManualTable();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addEmployeeHalfdayAttendanceFormModal').on('hidden.bs.modal', function () {
            $('#productsWrapperWholeHalfday .flatpickr-input').each(function() {
                if (this._flatpickr) {
                    this._flatpickr.destroy();
                }
            });
            $('#addEmployeeHalfdayAttendanceForm')[0].reset();
            $('#addEmployeeHalfdayAttendanceForm .select2').val(null).trigger('change');
            $('#productsWrapperWholeHalfday').empty();
            itemIndex = 1;
        });

        $('#addEmployeeListBtn').click(function () {
            let qtyUnitHtml = '<option value="">--Select Employee--</option>';
            employeesListOptionsForBulkAttendance.forEach(e => {
                qtyUnitHtml += `<option value="${e.id}">(${e.emp_code}) ${e.first_name} ${e.last_name}</option>`;
            });
            const productBlock = `
            <div class="row product-entry mb-1 border rounded p-2" data-index="`+ itemIndex + `">
                <div class="col-md-5 mb-2">
                    <select name="item[`+ itemIndex + `][employeeId]" class="select2 form-select form-select-lg employeesAttendList" data-allow-clear="true" required>                    
                        ${qtyUnitHtml}
                    </select>
                </div>                
                                
                <div class="col-md-6 mb-2">                 
                    <input type="text" name="item[`+ itemIndex + `][halfdayDate]" class="form-control flatpickr-datetime" placeholder="YYYY-MM-DD HH:MM" />
                </div>                
                <div class="col-md-1 mb-2 d-flex align-items-end">
                    <button type="button" class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600 transition-colors hover:bg-red-100 hover:text-red-700 focus:outline-none focus:ring-2 focus:ring-red-500/30 removeEmpBtn"><i class="ti ti-trash text-lg"></i></button>               
                </div>
            </div>`;

            const $productBlock = $(productBlock);
            $('#productsWrapperWholeHalfday').append($productBlock);

            // Initialize Select2 on new fields only
            $productBlock.find('.select2').select2({
                placeholder: '--Select--',
                dropdownParent: $('#addEmployeeHalfdayAttendanceFormModal')
            });
            $productBlock.find('.flatpickr-datetime').flatpickr({
                enableTime: true,
                dateFormat: 'Y-m-d H:i',
                appendTo: document.body,
                position: positionPayrollFlatpickr,
                onOpen: function(selectedDates, dateStr, instance) {
                    positionPayrollFlatpickr(instance);
                }
            });
            itemIndex++;
        });

        $('#addEmployeeHalfdayAttendanceForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addEmployeeHalfdayAttendanceForm');
            const formData = new FormData(form);
            formData.append('addEmployeeHalfdayAttendance', 'addEmployeeHalfdayAttendance');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addEmployeeHalfdayAttendanceFormModal').modal('hide');
                        $('#addEmployeeHalfdayAttendanceForm')[0].reset();
                        loadPayrollManualTable();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });

    // Employee Category filter (checkboxes)
    $(document).on('change', '.category-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".category-filter").prop("checked", allChecked);
        }

        selectedCategoryType = [];
        $(".category-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCategoryType.push($(this).val());
            }
        });

        loadPayrollManualTable();
    });

    $(document).on('change', '.status-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".status-filter").prop("checked", allChecked);
        }

        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });

        loadPayrollManualTable();
    });
    $(document).on('change', '.company-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".company-filter").prop("checked", allChecked);
        }

        selectedCompanyFilters = [];
        $(".company-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCompanyFilters.push($(this).val());
            }
        });

        loadPayrollManualTable();
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = $(this).data('default') || 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadPayrollManualTable(1);
    });

    $('#reviewAccountUpdateModal').on('show.bs.modal', function () {
        loadPendingAccountRequests();
    });

    $(document).on('click', '#reviewAccountUpdateBtn', function () {
        loadPendingAccountRequests();
    });

    $(document).on('click', '.approve-bank-req', function() {
        let reqId = $(this).data('id');
        let $btn = $(this);
        if (confirm("Are you sure you want to approve this bank details update request?")) {
            $btn.prop('disabled', true).html('<i class="ti ti-loader ti-spin text-sm"></i>');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { approveBankRequest: '1', request_id: reqId, csrf_token: <?= json_encode($_SESSION['csrf_token'] ?? '') ?> },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        loadPendingAccountRequests();
                    } else {
                        toastr.error(response.message);
                        $btn.prop('disabled', false).html('<i class="ti ti-check"></i>');
                    }
                },
                error: function() {
                    toastr.error('Server communication error');
                    $btn.prop('disabled', false).html('<i class="ti ti-check"></i>');
                }
            });
        }
    });

    $(document).on('click', '.reject-bank-req', function() {
        let reqId = $(this).data('id');
        let $btn = $(this);
        if (confirm("Are you sure you want to reject this bank details update request?")) {
            $btn.prop('disabled', true).html('<i class="ti ti-loader ti-spin text-sm"></i>');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { rejectBankRequest: '1', request_id: reqId, csrf_token: <?= json_encode($_SESSION['csrf_token'] ?? '') ?> },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        loadPendingAccountRequests();
                    } else {
                        toastr.error(response.message);
                        $btn.prop('disabled', false).html('<i class="ti ti-x"></i>');
                    }
                },
                error: function() {
                    toastr.error('Server communication error');
                    $btn.prop('disabled', false).html('<i class="ti ti-x"></i>');
                }
            });
        }
    });

    function loadPendingAccountRequests() {
        $('#reviewAccountRequestsBody').html(`
            <tr>
                <td colspan="6" class="px-6 py-8 text-center text-slate-400 font-medium">
                    <i class="ti ti-loader ti-spin text-lg mr-1"></i> Loading requests...
                </td>
            </tr>
        `);
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { getPendingBankRequests: '1', csrf_token: <?= json_encode($_SESSION['csrf_token'] ?? '') ?> },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    let html = '';
                    let count = response.requests.length;
                    $('#pendingRequestsCount').text(`Showing ${count} pending request${count !== 1 ? 's' : ''}`);
                    
                    if (count > 0) {
                        response.requests.forEach(function(req) {
                            let initials = ((req.first_name || '').charAt(0) + (req.last_name || '').charAt(0)).toUpperCase() || 'EE';
                            let curBank = req.current_bank_name || 'Not Set';
                            let curAcc = req.current_bank_account_number || 'Not Set';
                            let curAccMask = curAcc !== 'Not Set' && curAcc.length > 4 ? '•••• ' + curAcc.slice(-4) : curAcc;
                            
                            let newBank = req.new_bank_name || 'Not Set';
                            let newAcc = req.bank_account_number || '';
                            let newAccMask = newAcc.length > 4 ? '•••• ' + newAcc.slice(-4) : newAcc;
                            
                            html += `
                            <tr class="hover:bg-slate-50/50 transition-colors">
                                <td class="px-6 py-3">
                                    <div class="flex items-center gap-3">
                                        <div class="h-9 w-9 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-800 font-bold text-[11px]">${initials}</div>
                                        <div class="flex flex-col">
                                            <span class="font-bold text-slate-800">${req.first_name} ${req.last_name}</span>
                                            <span class="text-xs text-slate-400">${req.emp_code}</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-3">${curBank}</td>
                                <td class="px-6 py-3 text-slate-500">${curAccMask}</td>
                                <td class="px-6 py-3 font-semibold text-slate-900">${newBank}</td>
                                <td class="px-6 py-3 font-semibold text-slate-900">${newAccMask}</td>
                                <td class="px-6 py-3 text-center">
                                    <div class="flex items-center justify-center gap-2">
                                        <button class="w-8 h-8 rounded bg-emerald-100 text-emerald-700 hover:bg-emerald-200 flex items-center justify-center transition-colors approve-bank-req" data-id="${req.id}"><i class="ti ti-check"></i></button>
                                        <button class="w-8 h-8 rounded bg-rose-100 text-rose-600 hover:bg-rose-200 flex items-center justify-center transition-colors reject-bank-req" data-id="${req.id}"><i class="ti ti-x"></i></button>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        $('#reviewAccountRequestsBody').html(html);
                    } else {
                        $('#reviewAccountRequestsBody').html(`
                            <tr>
                                <td colspan="6" class="px-6 py-8 text-center text-slate-400 font-medium">No pending requests found</td>
                            </tr>
                        `);
                    }
                } else {
                    toastr.error('Failed to load pending requests');
                }
            },
            error: function() {
                toastr.error('Failed to load requests from server');
            }
        });
    }

</script>
<?php endSection(); ?>
