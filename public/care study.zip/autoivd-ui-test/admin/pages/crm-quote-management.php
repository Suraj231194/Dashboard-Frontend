<?php
global $conn;
$currentRoleId = (int) ($_SESSION['role_id'] ?? 0);
$canAddQuote = roleHasPermission($currentRoleId, 'crm_quote_add');
$canEditQuote = roleHasPermission($currentRoleId, 'crm_quote_edit');
$canDeleteQuote = roleHasPermission($currentRoleId, 'crm_quote_delete');

// Preload products for quote line items with SKU, GST, and latest unit price
$productsList = [];
$rateMap = [];

// Check latest rates from quotation_request_items
$rQ1 = $conn->query("SELECT product_id, unit_price FROM quotation_request_items WHERE unit_price > 0 ORDER BY id DESC");
if ($rQ1) {
    while ($r = $rQ1->fetch_assoc()) {
        if (!isset($rateMap[$r['product_id']])) {
            $rateMap[$r['product_id']] = (float)$r['unit_price'];
        }
    }
}

// Check latest rates from proforma_invoice_items
$rQ2 = $conn->query("SELECT p.id AS product_id, pii.prod_rate FROM proforma_invoice_items pii JOIN products p ON LOWER(TRIM(p.product_name)) COLLATE utf8mb4_unicode_ci = LOWER(TRIM(pii.product)) WHERE pii.prod_rate > 0 ORDER BY pii.id DESC");
if ($rQ2) {
    while ($r = $rQ2->fetch_assoc()) {
        if (!isset($rateMap[$r['product_id']])) {
            $rateMap[$r['product_id']] = (float)$r['prod_rate'];
        }
    }
}

$pQ = $conn->query("SELECT id, product_name, product_code, marg_code, gst_rate FROM products WHERE status = 1 AND deleted_at IS NULL ORDER BY product_name ASC");
if ($pQ) {
    while ($p = $pQ->fetch_assoc()) {
        $p['sku'] = !empty($p['product_code']) ? $p['product_code'] : (!empty($p['marg_code']) ? $p['marg_code'] : 'PRD-' . str_pad($p['id'], 4, '0', STR_PAD_LEFT));
        $p['gst_rate'] = (!empty($p['gst_rate']) && (float)$p['gst_rate'] > 0) ? (float)$p['gst_rate'] : 18.00;
        $p['default_rate'] = isset($rateMap[$p['id']]) ? (float)$rateMap[$p['id']] : 100.00;
        $productsList[] = $p;
    }
}
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <!-- Header -->
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                CRM Quote Management
            </h1>
            <p style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Generate, manage, and convert commercial sales quotations
            </p>
        </div>
    </div>

    <!-- Quotes Main Card -->
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:items-center">
                    
                    <!-- Search Input -->
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="quoteSearchInput" 
                               placeholder="Search quotations..." 
                               class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                               oninput="applyQuoteFilter('search', this.value)">
                    </div>

                    <!-- Status Filter Dropdown -->
                    <div class="dropdown w-full shrink-0 md:w-auto">
                        <button class="flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap md:w-44" type="button" data-bs-toggle="dropdown">
                            <span class="inline-flex items-center gap-2">
                                <i class="ti ti-circle-check text-base text-slate-400"></i>
                                <span id="quoteStatusLabel">All Quotes</span>
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'all', 'All Quotes')">All Quotes</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'draft', 'Draft')">Draft</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'generated', 'Generated')">Generated</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'sent', 'Sent')">Sent</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'accepted', 'Accepted')">Accepted</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'rejected', 'Rejected')">Rejected</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyQuoteFilter('status', 'expired', 'Expired')">Expired</a></li>
                        </ul>
                    </div>

                    <!-- Reset Button -->
                    <button type="button" class="inline-flex h-10 w-full items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 cursor-pointer shrink-0 md:w-auto" onclick="resetQuoteFilters()" title="Reset Filters">
                        <i class="ti ti-rotate text-sm text-slate-400"></i> Reset
                    </button>

                    <!-- Create Quote Dropdown Button at Far Right -->
                    <?php if ($canAddQuote): ?>
                        <div class="dropdown w-full shrink-0 md:w-auto">
                            <button class="inline-flex h-10 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 hover:bg-emerald-800 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap cursor-pointer md:w-auto" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="ti ti-plus text-lg"></i> Create Quote <i class="ti ti-chevron-down text-xs ml-1"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end !rounded-xl border border-slate-200 p-1 shadow-xl text-sm font-medium">
                                <li>
                                    <a class="block cursor-pointer rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2" onclick="openQuoteModal('blank')">
                                        <i class="ti ti-file-plus text-emerald-600"></i> New Quote
                                    </a>
                                </li>
                                <li>
                                    <a class="block cursor-pointer rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2" onclick="openFromLeadsModal()">
                                        <i class="ti ti-user-check text-emerald-600"></i> From Existing Leads
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quotes Table -->
            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr class="text-nowrap">
                            <th class="px-6 py-3.5">Quote #</th>
                            <th class="px-6 py-3.5">Customer / Company</th>
                            <th class="px-6 py-3.5">Linked Lead</th>
                            <th class="px-6 py-3.5">Date</th>
                            <th class="px-6 py-3.5">Total Amount</th>
                            <th class="px-6 py-3.5">Status</th>
                            <th class="px-6 py-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="quotesTableBody" class="divide-y divide-slate-100">
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400">
                                <div class="spinner-border text-emerald-600" role="status"></div>
                                <p class="mt-2 text-xs">Loading quotations...</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div id="quotesPagination" class="px-6 py-4 border-t border-slate-100 flex items-center justify-between text-sm text-slate-500">
                <!-- Pagination -->
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal: From Existing Leads Pop-up                                         -->
<!-- ========================================================================= -->
<div class="modal fade" id="fromLeadsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                        <i class="ti ti-user-check text-xl"></i>
                    </div>
                    <div>
                        <h5 class="modal-title font-bold text-slate-800 text-base">Select Lead for Quotation</h5>
                        <p class="text-xs text-slate-500 mt-0.5">Pick an accepted lead to automatically populate quotation details and products</p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <div class="modal-body p-0">
                <div class="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                    <div class="relative w-full max-w-sm">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-base text-slate-400"></i>
                        </div>
                        <input type="text" id="leadSelectSearch" placeholder="Search leads by name, company, territory, city..." class="form-control !rounded-xl border-slate-200 text-xs py-2 pr-3" style="padding-left: 2.5rem !important;" oninput="loadLeadsForQuoteSelection(1)">
                    </div>
                </div>
                <div class="overflow-x-auto w-full">
                    <table class="w-full table-auto text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                            <tr class="text-nowrap">
                                <th class="px-5 py-3">Sr.</th>
                                <th class="px-5 py-3">Source</th>
                                <th class="px-5 py-3">Timestamp</th>
                                <th class="px-5 py-3">Lead ID</th>
                                <th class="px-5 py-3">Lead Name</th>
                                <th class="px-5 py-3">Company</th>
                                <th class="px-5 py-3 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="leadsForQuoteTableBody" class="divide-y divide-slate-100">
                            <!-- Populated via AJAX -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-3 flex items-center justify-between" id="leadsForQuotePagination">
                <button type="button" class="inline-flex items-center justify-center px-4 py-2 border border-slate-200 bg-white text-slate-700 font-bold text-xs !rounded-xl hover:bg-slate-50 transition shadow-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal: Quote Create / Edit Modal                                          -->
<!-- ========================================================================= -->
<div class="modal fade" id="quoteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <form id="quoteForm" class="issue3-modal-form" onsubmit="saveQuoteForm(event)">
                <input type="hidden" id="quoteFormId" name="quote_id" value="">
                <input type="hidden" id="quoteLeadId" name="lead_id" value="">
                <input type="hidden" name="source_origin" value="crm">

                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                            <i class="ti ti-file-invoice text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title font-bold text-slate-800 text-base" id="quoteModalTitle">Create Quotation</h5>
                            <span id="linkedLeadBadge" class="text-xs text-emerald-600 font-medium"></span>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>

                <div class="modal-body px-6 py-5 max-h-[75vh] overflow-y-auto space-y-6 issue3-modal-scroll-body issue3-quote-modal-body">
                    <!-- Section 1: Quote Header Details -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50/70 p-4 rounded-xl border border-slate-200/60">
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Company / Organization <span class="text-rose-500">*</span></label>
                            <input type="text" id="quoteTargetCompany" name="target_company_name" required class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Contact Person <span class="text-rose-500">*</span></label>
                            <input type="text" id="quoteTargetName" name="target_name" required class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Email</label>
                            <input type="email" id="quoteTargetEmail" name="target_email" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Phone / Mobile</label>
                            <input type="text" id="quoteTargetPhone" name="target_phone" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Customer GSTIN</label>
                            <input type="text" id="quoteCustomerGstin" name="customer_gstin" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Status</label>
                            <select id="quoteStatus" name="status" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white">
                                <option value="draft">Draft</option>
                                <option value="generated" selected>Generated</option>
                                <option value="sent">Sent</option>
                                <option value="accepted">Accepted</option>
                                <option value="rejected">Rejected</option>
                            </select>
                        </div>
                        <div class="col-span-full md:col-span-2">
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Billing Address</label>
                            <textarea id="quoteBillingAddress" name="billing_address" rows="2" class="form-control !rounded-xl border-slate-200 text-sm py-2 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white"></textarea>
                        </div>
                        <div class="col-span-full md:col-span-1">
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Shipping Address</label>
                            <textarea id="quoteShippingAddress" name="shipping_address" rows="2" class="form-control !rounded-xl border-slate-200 text-sm py-2 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white"></textarea>
                        </div>
                    </div>

                    <!-- Section 2: Quotation Items -->
                    <div>
                        <div class="flex items-center justify-between mb-3">
                            <div>
                                <label class="text-xs font-bold text-slate-700 uppercase tracking-wider block">Quotation Items</label>
                                <span class="text-[11px] text-slate-400">Add products, quantities, rates, and tax calculations</span>
                            </div>
                            <button type="button" onclick="addQuoteItemRow()" class="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white !rounded-xl text-xs font-bold transition shadow-sm cursor-pointer">
                                <i class="ti ti-plus"></i> Add Product Item
                            </button>
                        </div>
                        <div id="quoteItemsList" class="space-y-3">
                            <!-- Rows added dynamically as spacious cards -->
                        </div>
                    </div>

                    <!-- Section 3: Summary Totals & Notes -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Terms & Conditions / Notes</label>
                            <textarea id="quoteNotes" name="notes" rows="4" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm" placeholder="Delivery timeline, payment terms, validity period..."></textarea>
                        </div>
                        <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-3.5">
                            <h6 class="text-xs font-bold uppercase tracking-wider text-slate-700 pb-2 border-b border-slate-100 flex items-center justify-between">
                                <span>Pricing & Tax Summary</span>
                                <i class="ti ti-calculator text-base text-emerald-600"></i>
                            </h6>
                            
                            <!-- Subtotal -->
                            <div class="flex items-center justify-between text-xs text-slate-600 font-medium">
                                <span>Subtotal (Taxable Value):</span>
                                <span id="quoteSummarySubtotal" class="font-bold text-slate-900 text-sm">₹0.00</span>
                            </div>

                            <!-- Total Tax -->
                            <div class="flex items-center justify-between text-xs text-slate-600 font-medium">
                                <span>Total Tax (GST Amount):</span>
                                <span id="quoteSummaryTax" class="font-bold text-slate-900 text-sm">₹0.00</span>
                            </div>

                            <!-- Discount Row -->
                            <div class="flex items-center justify-between text-xs text-slate-600 font-medium pt-1">
                                <span>Discount:</span>
                                <div class="relative" style="width: 130px;">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-2.5 text-xs text-slate-400 font-bold">₹</div>
                                    <input type="number" step="0.01" min="0" id="quoteDiscountAmount" name="discount_amount" value="0.00" 
                                           style="width: 130px; max-width: 130px;"
                                           class="h-9 !rounded-xl border border-slate-200 bg-white py-1.5 pl-6 pr-2.5 text-right font-bold text-xs text-slate-800 shadow-sm outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20" 
                                           oninput="calculateQuoteTotals()">
                                </div>
                            </div>

                            <!-- Grand Total Highlight Bar -->
                            <div class="rounded-xl bg-emerald-50/80 border border-emerald-100 p-3.5 flex items-center justify-between mt-2">
                                <div>
                                    <span class="block text-[11px] font-bold uppercase tracking-wider text-emerald-800">Grand Total</span>
                                    <span class="text-[10px] text-emerald-600">Inclusive of all taxes & discounts</span>
                                </div>
                                <span id="quoteSummaryTotal" class="text-emerald-700 text-lg font-extrabold font-mono">₹0.00</span>
                            </div>

                            <input type="hidden" id="hiddenSubtotal" name="subtotal" value="0.00">
                            <input type="hidden" id="hiddenTaxAmount" name="tax_amount" value="0.00">
                            <input type="hidden" id="hiddenTotalAmount" name="total_amount" value="0.00">
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-4 flex items-center justify-end gap-3 issue3-modal-footer">
                    <button type="button" class="inline-flex items-center justify-center px-4 py-2.5 border border-slate-200 bg-white text-slate-700 font-bold text-sm !rounded-xl hover:bg-slate-50 transition shadow-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" id="saveQuoteBtn" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm !rounded-xl transition shadow-sm ring-1 ring-emerald-900/10 cursor-pointer">
                        <i class="ti ti-check text-base"></i> Save Quotation
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
const crmCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
$.ajaxPrefilter(function (options) {
    if (String(options.type || 'GET').toUpperCase() !== 'POST' || !crmCsrfToken) return;
    if (options.data instanceof FormData) {
        if (!options.data.has('csrf_token')) options.data.append('csrf_token', crmCsrfToken);
    } else if (typeof options.data === 'string') {
        if (!/(^|&)csrf_token=/.test(options.data)) options.data += (options.data ? '&' : '') + 'csrf_token=' + encodeURIComponent(crmCsrfToken);
    } else {
        options.data = Object.assign({}, options.data || {}, { csrf_token: crmCsrfToken });
    }
});

let currentQuoteFilter = { status: 'all', search: '', page: 1 };
const productOptionsData = <?= json_encode($productsList) ?>;

$(document).ready(function () {
    loadQuotesList(1);
    const urlParams = new URLSearchParams(window.location.search);
    const incomingLeadId = urlParams.get('lead_id');
    if (incomingLeadId) {
        selectLeadForQuote(incomingLeadId);
    }
});

function applyQuoteFilter(type, value, labelText) {
    if (type === 'status') {
        currentQuoteFilter.status = value;
        $('#quoteStatusLabel').text(labelText || 'Status');
    } else if (type === 'search') {
        currentQuoteFilter.search = value.trim();
    }
    loadQuotesList(1);
}

function resetQuoteFilters() {
    $('#quoteSearchInput').val('');
    $('#quoteStatusLabel').text('All Quotes');
    currentQuoteFilter = { status: 'all', search: '', page: 1 };
    loadQuotesList(1);
}

function loadQuotesList(page = 1) {
    currentQuoteFilter.page = page;
    $('#quotesTableBody').html('<tr><td colspan="7" class="py-12 text-center text-slate-400"><div class="spinner-border text-primary-600" role="status"></div><p class="mt-2 text-xs">Loading quotations...</p></td></tr>');

    $.post('ajax.php', {
        action: 'crm_load_quotes',
        status: currentQuoteFilter.status,
        search: currentQuoteFilter.search,
        page: currentQuoteFilter.page
    }, function (res) {
        if (res.status === 'success') {
            $('#quotesTableBody').html(res.html || '<tr><td colspan="7" class="py-8 text-center text-slate-400">No CRM quotations found.</td></tr>');
            $('#quotesPagination').html(res.pagination || '');
        } else {
            $('#quotesTableBody').html('<tr><td colspan="7" class="py-8 text-center text-red-500">' + (res.message || 'Failed to load quotes') + '</td></tr>');
        }
    }, 'json');
}

function openFromLeadsModal() {
    $('#leadsForQuoteTableBody').html('<tr><td colspan="7" class="py-8 text-center text-slate-400"><div class="spinner-border text-primary-600" role="status"></div><p class="mt-2 text-xs">Loading leads...</p></td></tr>');
    const modal = new bootstrap.Modal(document.getElementById('fromLeadsModal'));
    modal.show();
    loadLeadsForQuoteSelection();
}

function loadLeadsForQuoteSelection(page = 1) {
    const search = $('#leadSelectSearch').val().trim();
    $.post('ajax.php', { action: 'crm_load_leads_for_quote', search: search, page: page }, function (res) {
        if (res.status === 'success') {
            $('#leadsForQuoteTableBody').html(res.html || '<tr><td colspan="7" class="py-8 text-center text-slate-400">No accepted leads available.</td></tr>');
            renderLeadsForQuotePagination(res);
        } else {
            $('#leadsForQuoteTableBody').html('<tr><td colspan="7" class="py-8 text-center text-red-500">' + (res.message || 'Error loading leads') + '</td></tr>');
        }
    }, 'json');
}

function renderLeadsForQuotePagination(res) {
    const currentPage = Number(res.page || 1);
    const totalPages = Number(res.total_pages || 1);
    let pageButtons = '';
    for (let page = Math.max(1, currentPage - 2); page <= Math.min(totalPages, currentPage + 2); page++) {
        const pageClass = page === currentPage ? 'bg-emerald-700 text-white' : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50';
        pageButtons += `<button type="button" class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-bold ${pageClass}" onclick="loadLeadsForQuoteSelection(${page})">${page}</button>`;
    }
    $('#leadsForQuotePagination').html(`
        <span class="text-xs font-medium text-slate-500">Showing <strong>${res.from || 0}</strong>–<strong>${res.to || 0}</strong> of <strong>${res.total_count || 0}</strong> accepted leads</span>
        <div class="flex items-center gap-1">
            <button type="button" class="inline-flex h-8 items-center justify-center rounded-lg border border-slate-200 bg-white px-2 text-xs font-bold text-slate-700 disabled:opacity-40" ${currentPage <= 1 ? 'disabled' : ''} onclick="loadLeadsForQuoteSelection(${currentPage - 1})"><i class="ti ti-chevron-left"></i></button>
            ${pageButtons}
            <button type="button" class="inline-flex h-8 items-center justify-center rounded-lg border border-slate-200 bg-white px-2 text-xs font-bold text-slate-700 disabled:opacity-40" ${currentPage >= totalPages ? 'disabled' : ''} onclick="loadLeadsForQuoteSelection(${currentPage + 1})"><i class="ti ti-chevron-right"></i></button>
        </div>
        <button type="button" class="inline-flex items-center justify-center px-4 py-2 border border-slate-200 bg-white text-slate-700 font-bold text-xs !rounded-xl hover:bg-slate-50 transition shadow-sm" data-bs-dismiss="modal">Close</button>`);
}

function selectLeadForQuote(leadId) {
    const fromLeadsEl = document.getElementById('fromLeadsModal');
    if (fromLeadsEl) {
        const modalInst = bootstrap.Modal.getInstance(fromLeadsEl);
        if (modalInst) modalInst.hide();
    }
    
    // Fetch lead details and prefill quote form
    $.post('ajax.php', { action: 'crm_get_lead_for_quote_prefill', lead_id: leadId }, function (res) {
        if (res.status === 'success') {
            openQuoteModal('lead', res.lead, res.products);
        } else {
            toastr.error(res.message || 'Failed to prefill lead data');
        }
    }, 'json');
}

function openQuoteModal(mode, leadData = null, productsData = []) {
    $('#quoteForm')[0].reset();
    $('#quoteFormId').val('');
    $('#quoteLeadId').val('');
    $('#quoteItemsList').empty();
    $('#linkedLeadBadge').text('');

    if (mode === 'blank') {
        $('#quoteModalTitle').text('Create Blank Quotation');
        addQuoteItemRow();
    } else if (mode === 'lead' && leadData) {
        $('#quoteModalTitle').text('Create Quotation from Lead');
        $('#quoteLeadId').val(leadData.id);
        $('#linkedLeadBadge').text('Linked to: ' + leadData.lead_number + ' (' + (leadData.company_name || '') + ')');
        $('#quoteTargetCompany').val(leadData.company_name || '');
        $('#quoteTargetName').val(leadData.contact_person || '');
        $('#quoteTargetEmail').val(leadData.email || '');
        $('#quoteTargetPhone').val(leadData.mobile_number || '');
        $('#quoteBillingAddress').val([leadData.territory, leadData.city, leadData.state, leadData.region].filter(Boolean).join(', '));
        $('#quoteShippingAddress').val([leadData.territory, leadData.city, leadData.state, leadData.region].filter(Boolean).join(', '));

        if (productsData && productsData.length > 0) {
            productsData.forEach(p => {
                const pSku = p.sku || p.product_code || ('PRD-' + String(p.id).padStart(4, '0'));
                const pRate = (p.default_rate !== undefined && p.default_rate !== null) ? p.default_rate : 100.00;
                const pGst = (p.gst_rate !== undefined && p.gst_rate !== null) ? p.gst_rate : 18;
                addQuoteItemRow(p.id, p.product_name, pSku, 1, pRate, pGst);
            });
        } else {
            addQuoteItemRow();
        }
    }

    calculateQuoteTotals();
    const modal = new bootstrap.Modal(document.getElementById('quoteModal'));
    modal.show();
}

function addQuoteItemRow(productId = '', productName = '', sku = '', qty = 1, unitPrice = 0, gstRate = 18) {
    let optionsHtml = '<option value="">-- Choose Product --</option>';
    if (Array.isArray(productOptionsData)) {
        productOptionsData.forEach(p => {
            const isSel = (String(p.id) === String(productId)) ? 'selected' : '';
            const pSku = p.sku || p.product_code || ('PRD-' + String(p.id).padStart(4, '0'));
            const pGst = (p.gst_rate !== undefined && p.gst_rate !== null) ? p.gst_rate : 18;
            const pRate = (p.default_rate !== undefined && p.default_rate !== null) ? p.default_rate : 100.00;
            optionsHtml += `<option value="${p.id}" data-sku="${pSku}" data-gst="${pGst}" data-rate="${pRate}" ${isSel}>${p.product_name}</option>`;
        });
    }

    const rowId = 'item_row_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    const rowHtml = `
    <div id="${rowId}" class="quote-item-row p-4 rounded-2xl bg-white border border-slate-200 shadow-sm transition-all hover:border-emerald-200 relative group">
        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
            <div class="md:col-span-8">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">Product <span class="text-rose-500">*</span></label>
                <select name="items[${rowId}][product_id]" class="form-select !rounded-xl border-slate-200 text-sm py-2 px-3 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm bg-white item-product-select w-full" onchange="onProductSelect(this, '${rowId}')" required>
                    ${optionsHtml}
                </select>
                <input type="hidden" name="items[${rowId}][product_name]" class="item-product-name" value="${productName}">
            </div>
            <div class="md:col-span-4">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">Product Code / SKU</label>
                <input type="text" name="items[${rowId}][sku]" class="form-control !rounded-xl border-slate-200 bg-slate-50 text-sm py-2 px-3 item-sku" value="${sku}" placeholder="Auto-filled SKU" readonly>
            </div>
            
            <div class="md:col-span-2">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">Quantity <span class="text-rose-500">*</span></label>
                <input type="number" name="items[${rowId}][quantity]" class="form-control !rounded-xl border-emerald-200 bg-emerald-50/30 text-sm font-bold text-emerald-700 py-2 px-3 text-right item-qty" value="${qty}" min="1" step="1" oninput="calculateRowTotal('${rowId}')" placeholder="Qty" required>
            </div>
            <div class="md:col-span-3">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">Unit Rate (₹) <span class="text-rose-500">*</span></label>
                <input type="number" name="items[${rowId}][unit_price]" class="form-control !rounded-xl border-slate-200 bg-white text-sm py-2 px-3 text-right item-price font-medium" value="${unitPrice}" min="0" step="0.01" oninput="calculateRowTotal('${rowId}')" placeholder="Rate" required>
            </div>
            <div class="md:col-span-2">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">GST (%)</label>
                <input type="number" name="items[${rowId}][gst_rate]" class="form-control !rounded-xl border-slate-200 bg-white text-sm py-2 px-3 text-right item-gst font-medium" value="${gstRate}" min="0" step="0.01" oninput="calculateRowTotal('${rowId}')" placeholder="GST %" required>
            </div>
            <div class="md:col-span-3">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">Line Total (₹)</label>
                <div class="h-10 !rounded-xl border border-slate-200 bg-slate-100 flex items-center justify-end px-3 font-extrabold text-sm text-slate-900 item-row-total">₹0.00</div>
            </div>
            <div class="md:col-span-2 flex items-center justify-end gap-1.5 pb-0.5">
                <button type="button" class="inline-flex h-10 w-10 items-center justify-center !rounded-xl bg-amber-50 text-amber-600 shadow-sm ring-1 ring-amber-100 transition-colors hover:bg-amber-100 hover:text-amber-700 cursor-pointer" title="Duplicate Item" onclick="duplicateQuoteItemRow('${rowId}')">
                    <i class="ti ti-copy text-lg"></i>
                </button>
                <button type="button" class="inline-flex h-10 w-10 items-center justify-center !rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 cursor-pointer" title="Remove Item" onclick="removeQuoteItemRow('${rowId}')">
                    <i class="ti ti-trash text-lg"></i>
                </button>
            </div>
        </div>
    </div>`;

    $('#quoteItemsList').append(rowHtml);
    calculateRowTotal(rowId);
}

function duplicateQuoteItemRow(rowId) {
    const $row = $('#' + rowId);
    const prodId = $row.find('.item-product-select').val();
    const prodName = $row.find('.item-product-name').val();
    const sku = $row.find('.item-sku').val();
    const qty = $row.find('.item-qty').val();
    const price = $row.find('.item-price').val();
    const gst = $row.find('.item-gst').val();

    addQuoteItemRow(prodId, prodName, sku, qty, price, gst);
}

function removeQuoteItemRow(rowId) {
    if ($('#quoteItemsList .quote-item-row').length <= 1) {
        toastr.warning('Quotation must have at least one product item');
        return;
    }
    $('#' + rowId).remove();
    calculateQuoteTotals();
}

function onProductSelect(sel, rowId) {
    const $opt = $(sel).find(':selected');
    const name = $opt.text();
    const sku = $opt.data('sku') || '';
    const gst = ($opt.data('gst') !== undefined && $opt.data('gst') !== null && $opt.data('gst') !== '') ? $opt.data('gst') : 18;
    const rate = ($opt.data('rate') !== undefined && $opt.data('rate') !== null && $opt.data('rate') !== '') ? parseFloat($opt.data('rate')) : 100.00;

    const $row = $('#' + rowId);
    $row.find('.item-product-name').val(name);
    $row.find('.item-sku').val(sku);
    $row.find('.item-gst').val(gst);
    $row.find('.item-price').val(rate.toFixed(2));

    // If quantity is empty or 0, default to 1
    const curQty = parseFloat($row.find('.item-qty').val());
    if (!curQty || curQty <= 0) {
        $row.find('.item-qty').val(1);
    }

    calculateRowTotal(rowId);
}

function calculateRowTotal(rowId) {
    const $row = $('#' + rowId);
    const qty = parseFloat($row.find('.item-qty').val()) || 0;
    const price = parseFloat($row.find('.item-price').val()) || 0;
    const gst = parseFloat($row.find('.item-gst').val()) || 0;

    const subtotal = qty * price;
    const tax = subtotal * (gst / 100);
    const total = subtotal + tax;

    $row.find('.item-row-total').text('₹' + total.toFixed(2));
    calculateQuoteTotals();
}

function calculateQuoteTotals() {
    let subtotal = 0;
    let totalTax = 0;

    $('#quoteItemsList .quote-item-row').each(function () {
        const qty = parseFloat($(this).find('.item-qty').val()) || 0;
        const price = parseFloat($(this).find('.item-price').val()) || 0;
        const gst = parseFloat($(this).find('.item-gst').val()) || 0;

        const lineSubtotal = qty * price;
        const lineTax = lineSubtotal * (gst / 100);

        subtotal += lineSubtotal;
        totalTax += lineTax;
    });

    const discount = parseFloat($('#quoteDiscountAmount').val()) || 0;
    const grandTotal = Math.max(0, subtotal + totalTax - discount);

    $('#quoteSummarySubtotal').text('₹' + subtotal.toFixed(2));
    $('#quoteSummaryTax').text('₹' + totalTax.toFixed(2));
    $('#quoteSummaryTotal').text('₹' + grandTotal.toFixed(2));

    $('#hiddenSubtotal').val(subtotal.toFixed(2));
    $('#hiddenTaxAmount').val(totalTax.toFixed(2));
    $('#hiddenTotalAmount').val(grandTotal.toFixed(2));
}

function saveQuoteForm(e) {
    e.preventDefault();
    const formData = $('#quoteForm').serialize() + '&action=crm_save_quote';
    $('#saveQuoteBtn').prop('disabled', true).text('Saving...');

    $.post('ajax.php', formData, function (res) {
        $('#saveQuoteBtn').prop('disabled', false).text('Save Quotation');
        if (res.status === 'success') {
            toastr.success(res.message || 'Quotation saved successfully');
            bootstrap.Modal.getInstance(document.getElementById('quoteModal')).hide();
            loadQuotesList(currentQuoteFilter.page);
        } else {
            toastr.error(res.message || 'Failed to save quotation');
        }
    }, 'json');
}

function editCrmQuote(quoteId) {
    $.post('ajax.php', { action: 'crm_get_quote_detail', quote_id: quoteId }, function (res) {
        if (res.status === 'success') {
            const q = res.quote;
            $('#quoteFormId').val(q.id);
            $('#quoteLeadId').val(q.lead_id || '');
            $('#quoteTargetCompany').val(q.target_company_name || '');
            $('#quoteTargetName').val(q.target_name || '');
            $('#quoteTargetEmail').val(q.target_email || '');
            $('#quoteTargetPhone').val(q.target_phone || '');
            $('#quoteCustomerGstin').val(q.customer_gstin || '');
            $('#quoteStatus').val(q.status || 'generated');
            $('#quoteBillingAddress').val(q.billing_address || '');
            $('#quoteShippingAddress').val(q.shipping_address || '');
            $('#quoteNotes').val(q.notes || '');
            $('#quoteDiscountAmount').val(q.discount_amount || '0.00');

            $('#quoteItemsList').empty();
            if (res.items && res.items.length > 0) {
                res.items.forEach(it => {
                    addQuoteItemRow(it.product_id, it.product_name, it.sku, it.quantity, it.unit_price, it.gst_rate);
                });
            } else {
                addQuoteItemRow();
            }

            $('#quoteModalTitle').text('Edit Quotation (' + q.quotation_number + ')');
            const modal = new bootstrap.Modal(document.getElementById('quoteModal'));
            modal.show();
        } else {
            toastr.error(res.message || 'Failed to load quotation');
        }
    }, 'json');
}

function deleteCrmQuote(quoteId) {
    if (!confirm('Are you sure you want to delete this quotation?')) return;
    $.post('ajax.php', { action: 'crm_delete_quote', quote_id: quoteId }, function (res) {
        if (res.status === 'success') {
            toastr.success(res.message || 'Quotation deleted');
            loadQuotesList(currentQuoteFilter.page);
        } else {
            toastr.error(res.message || 'Failed to delete');
        }
    }, 'json');
}
</script>
<?php endSection(); ?>
