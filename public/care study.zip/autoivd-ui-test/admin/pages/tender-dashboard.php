<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
        </div>
    </div>
    <div class="mb-6" id="tenderAnalyticsCards">
        <h5 class="mb-3 text-base font-bold text-slate-800">Tender Analytics <span
                class="ml-2 inline-flex items-center rounded-full bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold text-indigo-700 ring-1 ring-inset ring-indigo-700/10"
                id="totalTender">0</span></h5>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">

            <div
                class="relative overflow-hidden rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md">
                <div class="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-amber-50 opacity-50"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="m-0 text-xs font-bold uppercase tracking-wider text-slate-500">Pending</p>
                        <p class="m-0 mt-1 text-2xl font-bold text-slate-900" id="pendingCount">0</p>
                    </div>
                    <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-600">
                        <i class="ti ti-clock text-xl"></i>
                    </div>
                </div>
            </div>

            <div
                class="relative overflow-hidden rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md">
                <div class="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-blue-50 opacity-50"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="m-0 text-xs font-bold uppercase tracking-wider text-slate-500">Participated</p>
                        <p class="m-0 mt-1 text-2xl font-bold text-slate-900" id="participatedCount">0</p>
                    </div>
                    <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
                        <i class="ti ti-file-text text-xl"></i>
                    </div>
                </div>
            </div>

            <div
                class="relative overflow-hidden rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md">
                <div class="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-rose-50 opacity-50"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="m-0 text-xs font-bold uppercase tracking-wider text-slate-500">Rejected</p>
                        <p class="m-0 mt-1 text-2xl font-bold text-slate-900" id="rejectedCount">0</p>
                    </div>
                    <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-600">
                        <i class="ti ti-x text-xl"></i>
                    </div>
                </div>
            </div>

            <div
                class="relative overflow-hidden rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md">
                <div class="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-emerald-50 opacity-50"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="m-0 text-xs font-bold uppercase tracking-wider text-slate-500">Completed</p>
                        <p class="m-0 mt-1 text-2xl font-bold text-slate-900" id="completedCount">0</p>
                    </div>
                    <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
                        <i class="ti ti-check text-xl"></i>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="w-full">
        <div
            class="overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-sm transition-all hover:shadow-md">

            <div class="flex items-center justify-between border-b border-slate-200 bg-slate-50/80 px-6 py-4">
                <div class="flex items-center gap-3">
                    <span
                        class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 ring-1 ring-rose-100">
                        <i class="ti ti-bell text-xl"></i>
                    </span>
                    <div>
                        <h5 class="m-0 text-lg font-bold text-slate-800">Tender Reminders</h5>
                        <p class="m-0 text-xs text-slate-500">Tenders requiring your attention</p>
                    </div>
                </div>

                <div class="flex items-center gap-3">
                    <span
                        class="inline-flex items-center rounded-full bg-rose-50 px-2.5 py-0.5 text-sm font-semibold text-rose-600 ring-1 ring-inset ring-rose-500/10"
                        id="tenderReminderCount">0</span>
                    <button type="button"
                        class="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-slate-500 shadow-sm ring-1 ring-slate-200 transition-colors hover:bg-slate-50 hover:text-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        id="refreshTenderReminder" title="Refresh">
                        <i class="ti ti-refresh text-xl"></i>
                    </button>
                </div>
            </div>

            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="tenderDashboardPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="tender-dashboard-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="tender-dashboard-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="tender-dashboard-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="tender-dashboard-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="tender-dashboard-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="tender-dashboard-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <!-- Search input -->
                    <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchTenders"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Tenders...">
                    </div>

                    <div class="flex flex-nowrap items-center gap-2 shrink-0">
                        <button type="button" data-val="csv" class="export-btn inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-file-text text-base"></i> CSV
                        </button>
                        <button type="button" data-val="excel" class="export-btn inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-file-spreadsheet text-base"></i> Excel
                        </button>
                        <button type="button" data-val="print" class="export-btn inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-printer text-base"></i> Print
                        </button>
                        
                        <!-- hidden download link -->
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-btn-download hidden"><i class="ti ti-download text-lg"></i> Download</a>
                    </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-600" id="datatablesTenderReminder">
                    <thead
                        class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr>
                            <th class="border-b border-slate-200 px-6 py-3 px-6 py-4 font-semibold">#</th>
                            <th class="border-b border-slate-200 px-6 py-3 px-6 py-4 font-semibold">Tender Number</th>
                            <th class="border-b border-slate-200 px-6 py-3 px-6 py-4 font-semibold">Institution</th>
                            <th class="border-b border-slate-200 px-6 py-3 px-6 py-4 font-semibold">Status</th>
                            <th class="border-b border-slate-200 px-6 py-3 px-6 py-4 font-semibold">Last Activity</th>
                            <th class="border-b border-slate-200 px-6 py-3 px-6 py-4 font-semibold">Duration</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100" id="tenderReminderBody">
                        <!-- Rows rendered dynamically -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination Footer -->
            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>

        </div>
    </div>

    <?php startSection('styles'); ?>
    <style>
        .dt-buttons { display: none !important; }
        .table-info { background-color: #cff4fc !important; color: #055160 !important; }
        .table-primary { background-color: #cfe2ff !important; color: #084298 !important; }
        .table-warning { background-color: #fff3cd !important; color: #664d03 !important; }
        .table-danger { background-color: #f8d7da !important; color: #842029 !important; }
        .blink { animation: blinker 1.5s linear infinite; }
        @keyframes blinker { 50% { opacity: 0.5; } }
    </style>

    <?php startSection('scripts'); ?>

    <script>
        const DASHBOARD_REFRESH_TIME = 60000; // 60 sec

        function tenderStatusLabel(status) {
            return APP_CONST?.TENDERS?.BASE_STATUS_TYPE?.[status]?.label ?? 'Unknown';
        }

        function tenderRowClass(days) {
            if (days <= 1) return 'table-info';
            if (days <= 2) return 'table-primary';
            if (days <= 3) return 'table-warning';
            if (days <= 5) return 'table-danger blink';
            return 'table-danger blink';
        }

        function updateTenderAnalytics(data) {
            if (
                data.pending === 0 &&
                data.participated === 0 &&
                data.rejected === 0 &&
                data.total === 0 &&
                data.inprogress === 0 &&
                data.completed === 0
            ) {
                $('#tenderAnalyticsCards').addClass('hidden');
                return;
            }

            $('#pendingCount').text(data.pending);
            $('#participatedCount').text(data.participated);
            $('#rejectedCount').text(data.rejected);
            $('#completedCount').text(data.completed);
            $('#totalTender').text(data.total);
            $('#inprogressTender').text(data.inprogress);

            $('#tenderAnalyticsCards').removeClass('hidden');
        }

        let tenderReminderTable = null;

        function initTenderReminderTable() {
            if ($.fn.DataTable.isDataTable('#datatablesTenderReminder')) {
                $('#datatablesTenderReminder').DataTable().destroy();
            }

            tenderReminderTable = $('#datatablesTenderReminder').DataTable({
                pageLength: 10,
                dom: 'Bt', // Only Buttons and Table
                buttons: [
                    'csv', 'excel', 'print'
                ],
                ordering: false,
                autoWidth: false,
                createdRow: function (row, data) {
                    let daysText = $(data[5]).text() || data[5];
                    let days = parseInt(daysText) || 0;
                    $(row).addClass(tenderRowClass(days)).addClass('border-b border-slate-100 transition-colors');
                    $('td', row).addClass('px-6 py-4 whitespace-nowrap');
                }
            });

            // Hide DataTables default buttons container
            tenderReminderTable.buttons().container().hide();
            $('.dt-buttons').hide();

            // Export handlers via exportajax.php (matching Purchase Management pattern)
            function handleTenderExport(format, $btn) {
                const search = $('#searchTenders').val().trim();
                const originalHtml = $btn.html();
                $btn.prop('disabled', true).addClass('opacity-75').html('<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Exporting...');

                $.ajax({
                    url: 'exportajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        exportTenderReminders: 1,
                        exportType: format,
                        search: search
                    },
                    success: function (response) {
                        if (response.success === 'success' && response.fileurl) {
                            const link = document.createElement('a');
                            link.href = response.fileurl;
                            link.download = response.file || ('tender_reminders.' + (format === 'excel' ? 'xlsx' : format));
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);

                            if (window.toastr) {
                                toastr.success((format === 'excel' ? 'Excel' : format.toUpperCase()) + ' exported successfully.');
                            }
                        } else {
                            if (window.toastr) {
                                toastr.error(response.message || 'Failed to export file.');
                            } else {
                                alert(response.message || 'Failed to export file.');
                            }
                        }
                    },
                    error: function () {
                        if (window.toastr) {
                            toastr.error('Server error while exporting.');
                        } else {
                            alert('Server error while exporting.');
                        }
                    },
                    complete: function () {
                        $btn.prop('disabled', false).removeClass('opacity-75').html(originalHtml);
                    }
                });
            }

            $('.export-btn[data-val="csv"]').off('click').on('click', function(e) {
                e.preventDefault();
                handleTenderExport('csv', $(this));
            });

            $('.export-btn[data-val="excel"]').off('click').on('click', function(e) {
                e.preventDefault();
                handleTenderExport('excel', $(this));
            });

            $('.export-btn[data-val="print"]').off('click').on('click', function(e) {
                e.preventDefault();
                const printWindow = window.open('', '_blank', 'height=700,width=900');
                if (!printWindow) {
                    window.print();
                    return;
                }
                const count = $('#tenderReminderCount').text() || '0';
                let rowsHtml = '';
                $('#datatablesTenderReminder tbody tr').each(function() {
                    let cells = [];
                    $(this).find('td').each(function() {
                        cells.push('<td style="padding: 8px 12px; border-bottom: 1px solid #e2e8f0; font-size: 12px;">' + $(this).html() + '</td>');
                    });
                    if (cells.length) {
                        rowsHtml += '<tr>' + cells.join('') + '</tr>';
                    }
                });
                printWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Tender Reminders Report</title>
                        <style>
                            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 20px; color: #1e293b; }
                            h2 { margin: 0 0 4px 0; font-size: 18px; color: #0f172a; }
                            p { margin: 0 0 16px 0; font-size: 12px; color: #64748b; }
                            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                            th { background-color: #f8fafc; color: #475569; font-size: 11px; font-weight: bold; text-transform: uppercase; padding: 8px 12px; border-bottom: 2px solid #cbd5e1; text-align: left; }
                            @media print {
                                @page { margin: 1cm; size: landscape; }
                            }
                        </style>
                    </head>
                    <body>
                        <h2>Biogenix - Tender Reminders Report</h2>
                        <p>Generated on: ${new Date().toLocaleString()} | Total Reminders: ${count}</p>
                        <table>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tender Number</th>
                                    <th>Institution</th>
                                    <th>Status</th>
                                    <th>Last Activity</th>
                                    <th>Duration</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${rowsHtml}
                            </tbody>
                        </table>
                    </body>
                    </html>
                `);
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 400);
            });

            // Map custom search to DataTables
            $('#searchTenders').off('keyup').on('keyup', function () {
                tenderReminderTable.search(this.value).draw();
            });

            // Map custom per page select to DataTables
            $('#perPageSelect, #footerPerPageSelect').off('change').on('change', function () {
                var val = $(this).val();
                $('#perPageSelect').val(val);
                $('#footerPerPageSelect').val(val);
                tenderReminderTable.page.len(parseInt(val)).draw();
            });

            // Top-strip per-page dropdown handler
            $(document).on('click', '.tender-dashboard-per-page-item', function () {
                const val = $(this).data('val');
                $('#tenderDashboardPerPageText').text($(this).text());
                $('#footerPerPageSelect').val(val).trigger('change');
            });

            tenderReminderTable.on('draw', function() {
                updateCustomPaginationUI();
            });
        }

        function updateCustomPaginationUI() {
            if (!tenderReminderTable) return;
            let info = tenderReminderTable.page.info();
            let html = '';
            let totalPages = info.pages;
            let currentPage = info.page + 1;
            
            if (totalPages > 0) {
                let prevDisabled = (currentPage === 1) ? 'pointer-events-none text-slate-300 bg-slate-50' : 'text-slate-500 hover:bg-slate-50 bg-white';
                let prevClick = (currentPage === 1) ? '' : `onclick="gotoTenderPage(${currentPage - 1})"`;
                html += `<a href="javascript:void(0)" ${prevClick} class="relative inline-flex items-center rounded-l-md px-2 py-2 text-sm font-semibold ring-1 ring-inset ring-slate-300 focus:z-20 focus:outline-offset-0 ${prevDisabled}">
                            <span class="sr-only">Previous</span>
                            <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd" /></svg>
                        </a>`;
                
                html += `<span class="relative z-10 inline-flex items-center bg-emerald-600 px-4 py-2 text-sm font-semibold text-white focus:z-20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-600">${currentPage}</span>`;
                
                let nextDisabled = (currentPage === totalPages) ? 'pointer-events-none text-slate-300 bg-slate-50' : 'text-slate-500 hover:bg-slate-50 bg-white';
                let nextClick = (currentPage === totalPages) ? '' : `onclick="gotoTenderPage(${currentPage + 1})"`;
                html += `<a href="javascript:void(0)" ${nextClick} class="relative inline-flex items-center rounded-r-md px-2 py-2 text-sm font-semibold ring-1 ring-inset ring-slate-300 focus:z-20 focus:outline-offset-0 ${nextDisabled}">
                            <span class="sr-only">Next</span>
                            <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" /></svg>
                        </a>`;
            }
            
            $('#paginationWrapper').html(html);
            
            if (typeof window.updatePaginationSummary === 'function') {
                window.updatePaginationSummary('paginationSummary', info.recordsDisplay, currentPage, 'footerPerPageSelect');
            }
        }

        window.gotoTenderPage = function(page) {
            if (tenderReminderTable) {
                tenderReminderTable.page(page - 1).draw('page');
            }
        };

        function getTenderStatusBadge(status) {
            const label = tenderStatusLabel(status);
            return `<span class="inline-flex items-center rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-700/10">${label}</span>`;
        }

        function updateTenderReminders(res) {
            $('#tenderReminderCount').text(res.count);
            tenderReminderTable.clear();
            
            if (res.count > 0 && res.data) {
                let sr = 1;
                res.data.forEach(row => {
                    let daysClass = 'font-semibold text-slate-700';
                    let days = parseInt(row.aging_days) || 0;

                    tenderReminderTable.row.add([
                        `<span class="font-medium text-slate-900">${sr++}</span>`,
                        `<span class="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-700 ring-1 ring-slate-200">${row.tender_no || ''}</span>`,
                        row.tender_title ?? '',
                        getTenderStatusBadge(row.status),
                        `<span class="text-slate-500">${row.last_activity_datetime || ''}</span>`,
                        `<span class="${daysClass}">${row.aging_days} Days</span>`
                    ]);
                });
            }
            tenderReminderTable.draw();
        }

        function loadDashboardData() {
            $.ajax({
                url: 'dashboardajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    getTenderDashboardData: 'getTenderDashboardData'
                },
                success: function (res) {
                    if (res.status !== 'success') return;
                    updateTenderAnalytics(res.analytics);
                },
                error: function () {
                    console.error('Dashboard data fetch failed');
                }
            });
            fetchTenderReminders(false);
        }

        function fetchTenderReminders(animate = false) {
            if (animate) {
                $('#refreshTenderReminder').addClass('animate-spin');
            }

            $.ajax({
                url: 'dashboardajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchTenderReminders: 'fetchTenderReminders'
                },
                success: function (res) {
                    if (res.status !== 'success') return;
                    updateTenderReminders(res.reminders);
                },
                complete: function () {
                    $('#refreshTenderReminder').removeClass('animate-spin');
                }
            });
        }

        $('#refreshTenderReminder').on('click', function () {
            fetchTenderReminders(true);
        });

        $(document).ready(function () {
            initTenderReminderTable();
            loadDashboardData();
        });

    </script>



    <?php endSection(); ?>