<?php
$orderId = intval($_GET['id'] ?? 0);
if ($orderId <= 0) {
    echo '<div class="container-xxl flex-grow-1 container-p-y font-sans"><div class="alert alert-danger">Invalid Order ID.</div></div>';
    return;
}

// Fetch order
$stmt = $conn->prepare("SELECT `orders`.*,
        COALESCE(NULLIF(`customer`.`company_name`, ''), `customer`.`name`, `orders`.`client_name`) AS `current_client_name`,
        `customer`.`detailed_address` AS `current_customer_address`, `customer`.`gstin` AS `current_customer_gstin`,
        `customer`.`pan` AS `current_customer_pan`, `customer`.`state_province` AS `current_customer_state`,
        `customer`.`state_code` AS `current_customer_state_code`, `customer`.`contact_person` AS `current_customer_contact`,
        `customer`.`phone` AS `current_customer_phone`, `customer`.`email` AS `current_customer_email`
    FROM `order_received` AS `orders`
    LEFT JOIN `customers` AS `customer` ON `customer`.`id` = `orders`.`customer_id`
    WHERE `orders`.`id` = ? AND `orders`.`deleted_at` IS NULL");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    echo '<div class="container-xxl flex-grow-1 container-p-y font-sans"><div class="alert alert-danger">Order not found.</div></div>';
    return;
}

// Fetch items
$itemsQ = $conn->prepare("SELECT oi.*, p.product_code FROM `order_received_items` oi LEFT JOIN `products` p ON p.product_name = oi.product_name WHERE oi.order_id = ? AND oi.deleted_at IS NULL");
$itemsQ->bind_param("i", $orderId);
$itemsQ->execute();
$itemsResult = $itemsQ->get_result();
$items = [];
while ($row = $itemsResult->fetch_assoc()) {
    $items[] = $row;
}
$itemsQ->close();

$auditRows = [];
$auditStmt = $conn->prepare("SELECT `audit`.*, COALESCE(`user`.`name`, 'System') AS `user_name`
    FROM `order_management_audit` AS `audit`
    LEFT JOIN `users` AS `user` ON `user`.`id` = `audit`.`user_id`
    WHERE `audit`.`order_id` = ? ORDER BY `audit`.`created_at` DESC LIMIT 25");
if ($auditStmt) {
    $auditStmt->bind_param('i', $orderId);
    $auditStmt->execute();
    $auditRows = $auditStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $auditStmt->close();
}

$statusInfo = Constant::ORDER_RECEIVED['STATUS_TYPES'][$order['status']] ?? ['label' => 'Unknown', 'class' => 'bg-label-secondary'];
$sourceInfo = Constant::ORDER_RECEIVED['SOURCE_TYPES'][$order['source_type']] ?? ['label' => 'ERP', 'class' => 'bg-label-primary'];
$orderTypeVal = Constant::ORDER_RECEIVED['ORDER_TYPE_OPTIONS'][$order['order_type']] ?? 'Product Order';
$urgency = Constant::ORDER_RECEIVED['DISPATCH_TIMELINE'][$order['dispatch_timeline']] ?? 'Immediate';
$paymentTerms = Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM'][$order['payment_tems_status']] ?? 'Credit';
$unitMap = fetch_table_records($conn, 'standard_units', [], 'fullname');
$unitMapping = [];
foreach ($unitMap as $u) {
    $unitMapping[$u['id']] = $u['fullname'];
}
$canResolveOrderMapping = roleHasPermission((int) ($_SESSION['role_id'] ?? 0), 'store_order_received_edit');
?>

<div class="container-fluid flex-grow-1 container-p-y font-sans px-8">
    <!-- Header Section -->
    <div class="mb-5 d-flex align-items-center gap-3">
        <!-- Back Arrow Button -->
        <a href="index.php?page=order-received" class="d-inline-flex align-items-center justify-content-center" style="width: 2.25rem; height: 2.25rem; border-radius: 0.5rem; background-color: #f1f5f9; color: #475569; text-decoration: none; transition: all 0.2s;" onmouseover="this.style.backgroundColor='#e2e8f0'; this.style.color='#0f172a';" onmouseout="this.style.backgroundColor='#f1f5f9'; this.style.color='#475569';">
            <i class="ti ti-arrow-left text-lg"></i>
        </a>
        <div>
            <div class="text-sm font-medium mb-1" style="color: #64748b;">
                <a href="index.php?page=order-received" class="hover:text-slate-600" style="text-decoration: none; color: inherit;">Orders</a> <span class="mx-1">/</span> <span>Order <?= htmlspecialchars($order['order_number']) ?></span>
            </div>
            <h1 class="text-2xl font-bold tracking-tight m-0" style="color: #1e293b;">Order <?= htmlspecialchars($order['order_number']) ?> Management</h1>
        </div>
    </div>

    <!-- Main Layout -->
    <div class="row g-4">
        <!-- Left Side: Order details & Products (8 Cols) -->
        <div class="col-12 col-lg-8 space-y-6">
            <!-- Order Details Card -->
            <div class="bg-white border rounded-2xl p-6 shadow-sm" style="border-color: #e2e8f0;">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-bold m-0" style="color: #1a4d2e;">Order Information</h3>
                    <div class="flex items-center gap-3">
                        <button type="button" id="saveOrderCustomerInfoBtn" class="btn-primary inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white rounded-lg shadow-sm transition-all hover:opacity-90 cursor-pointer">
                            <i class="ti ti-device-floppy text-sm"></i> SAVE DETAILS
                        </button>
                        <span class="badge px-3 py-1.5 text-xs tracking-wider font-extrabold rounded-full uppercase" style="background-color: #c6e6d1; color: #1a4d2e;"><?= htmlspecialchars($statusInfo['label']) ?></span>
                    </div>
                </div>
                
                <form id="orderCustomerInfoForm">
                    <input type="hidden" name="updateOrderCustomerInfo" value="1">
                    <input type="hidden" name="order_id" value="<?= $orderId ?>">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Order Number</label>
                            <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($order['order_number']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Client Name</label>
                            <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($order['current_client_name'] ?? $order['client_name']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Order Date</label>
                            <div class="relative">
                                <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($order['date_order_received']) ?>">
                                <i class="ti ti-calendar absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Source</label>
                            <div class="relative">
                                <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($sourceInfo['label']) ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Order Type</label>
                            <div class="relative">
                                <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($orderTypeVal) ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Urgency</label>
                            <div class="relative">
                                <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($urgency) ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Payment Terms</label>
                            <div class="relative">
                                <input type="text" readonly class="input-theme cursor-default bg-slate-50" value="<?= htmlspecialchars($paymentTerms) ?>">
                            </div>
                        </div>
                        <div class="col-md-8"></div>
                        
                        <div class="col-12">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Delivery Address</label>
                            <textarea name="delivery_address" id="orderDeliveryAddress" class="input-theme resize-none" style="min-height: 70px;" placeholder="Enter delivery address..."><?= htmlspecialchars($order['delivery_address'] ?: ($order['current_customer_address'] ?? $order['customer_address_snapshot'] ?? $order['area_city'] ?? '')) ?></textarea>
                        </div>

                        <div class="col-md-3">
                            <label class="mb-1 block text-sm font-medium text-slate-800">GSTIN</label>
                            <input type="text" name="customer_gstin" id="orderCustomerGstin" class="input-theme uppercase" placeholder="e.g. 09AAAGZ0020L2Z7" value="<?= htmlspecialchars($order['customer_gstin_snapshot'] ?: ($order['current_customer_gstin'] ?? '')) ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="mb-1 block text-sm font-medium text-slate-800">PAN</label>
                            <input type="text" name="customer_pan" id="orderCustomerPan" class="input-theme uppercase" placeholder="e.g. AAAGZ0020L" value="<?= htmlspecialchars($order['customer_pan_snapshot'] ?: ($order['current_customer_pan'] ?? '')) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">State / Province</label>
                            <input type="text" name="customer_state" id="orderCustomerState" class="input-theme uppercase" placeholder="e.g. UTTAR PRADESH" value="<?= htmlspecialchars($order['customer_state_snapshot'] ?: ($order['current_customer_state'] ?? '')) ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="mb-1 block text-sm font-medium text-slate-800">State Code</label>
                            <input type="text" name="customer_state_code" id="orderCustomerStateCode" class="input-theme" placeholder="e.g. 09" value="<?= htmlspecialchars($order['customer_state_code_snapshot'] ?: ($order['current_customer_state_code'] ?? '')) ?>">
                        </div>

                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Contact Person</label>
                            <input type="text" name="customer_contact_person" id="orderCustomerContactPerson" class="input-theme" placeholder="Contact person name" value="<?= htmlspecialchars($order['customer_contact_person_snapshot'] ?: ($order['current_customer_contact'] ?? '')) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Contact Number</label>
                            <input type="text" name="customer_contact_phone" id="orderCustomerContactPhone" class="input-theme" placeholder="Phone number" value="<?= htmlspecialchars($order['customer_contact_number_snapshot'] ?: ($order['current_customer_phone'] ?? '')) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Email Address</label>
                            <input type="email" name="customer_email" id="orderCustomerEmail" class="input-theme" placeholder="Email address" value="<?= htmlspecialchars($order['customer_email_snapshot'] ?: ($order['current_customer_email'] ?? '')) ?>">
                        </div>
                    </div>
                </form>
            </div>

            <!-- Ordered Product Line Items -->
            <div class="bg-white border rounded-2xl shadow-sm overflow-hidden pb-4" style="border-color: #e2e8f0; margin-top: 1.5rem;">
                <div class="px-6 py-4 flex items-center justify-between">
                    <h3 class="text-lg font-bold m-0" style="color: #1a4d2e;">Product Line Items</h3>
                    <button type="button" class="text-xs font-bold tracking-wide flex items-center gap-1 hover:underline uppercase" style="color: #1a4d2e;">
                        <i class="ti ti-circle-plus text-base"></i> ADD PRODUCT
                    </button>
                </div>
                <div class="overflow-x-auto w-full">
                    <table class="w-full border-collapse text-left text-sm whitespace-nowrap">
                        <thead class="text-xs font-extrabold uppercase tracking-widest border-y" style="background-color: #f5f6f8; color: #1a4d2e; border-color: #e2e8f0;">
                            <tr>
                                <th class="px-6 py-3">Product Name</th>
                                <th class="px-6 py-3 w-28 text-center">Qty</th>
                                <th class="px-6 py-3 w-28 text-center">Unit</th>
                                <th class="px-6 py-3 w-32 text-center">Status</th>
                                <th class="px-6 py-3 w-20 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-100 text-slate-700">
                            <?php foreach ($items as $item): ?>
                                <tr id="orderItemRow-<?= (int) $item['id'] ?>" class="align-middle">
                                    <td class="px-6 py-4">
                                        <div class="order-item-product-name font-bold text-slate-800 text-sm"><?= htmlspecialchars($item['product_name']) ?></div>
                                        <div class="order-item-product-code text-xs text-slate-400 mt-1 uppercase tracking-wider font-semibold">SKU: <?= htmlspecialchars($item['product_code'] ?? '-') ?></div>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <input type="text" readonly class="order-item-quantity form-control text-center px-1 py-1 text-sm font-semibold focus:outline-none" style="width: 4rem; background-color: #ffffff; color: #334155; border-color: #e2e8f0;" value="<?= floatval($item['quantity']) ?>">
                                    </td>
                                    <td class="px-6 py-4 text-center font-bold text-sm" style="color: #1e293b;">
                                        <?= htmlspecialchars($unitMapping[$item['unit']] ?? 'Units') ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="badge font-bold text-xs tracking-widest uppercase stock-item-status rounded px-2.5 py-1.5" style="background-color: #e0e7ff; color: #3730a3;" data-item-id="<?= (int) $item['id'] ?>">AWAITING QC</span>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <div class="line-fulfillment-actions inline-flex flex-wrap justify-center gap-1" data-item-id="<?= (int) $item['id'] ?>"></div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Bottom Action Footer -->
            <div class="bg-white border rounded-2xl p-4 shadow-sm flex items-center justify-between" style="border-color: #e2e8f0; margin-top: 1.5rem;">
                <div class="flex items-center gap-4 pl-2" style="color: #94a3b8;">
                    <i class="ti ti-printer text-xl cursor-pointer hover:text-slate-600"></i>
                    <i class="ti ti-trash text-xl cursor-pointer hover:text-red-500"></i>
                </div>
                <div id="actionButtonsContainer" class="hidden d-flex align-items-center gap-3"></div>
            </div>
        </div>

        <!-- Right Side: Fulfillment & Stock Analysis (1 Col) -->
        <div class="col-12 col-lg-4 space-y-6">
            <!-- Fulfillment Card -->
            <div class="bg-white border rounded-2xl p-5 shadow-sm" style="border-color: #e2e8f0;">
                <h3 class="text-base font-bold mb-4 m-0" style="color: #0f172a;">Fulfillment Analysis</h3>
                <div class="space-y-4">
                    <button type="button" id="checkStockBtn" class="btn-primary w-full hidden h-11 items-center justify-center gap-2 rounded-xl text-white text-sm font-bold transition-colors shadow-sm focus:outline-none" aria-hidden="true">
                        <i class="ti ti-refresh text-lg animate-spin hidden" id="stockSpinner"></i>
                        <i class="ti ti-clipboard-check text-lg" id="stockSearchIcon"></i> RECALCULATE STOCK
                    </button>
                    <div id="automaticStockNotice" class="flex items-center gap-2 rounded-xl border border-emerald-100 bg-emerald-50 p-3 text-xs font-semibold text-emerald-800">
                        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span> Checking saleable stock and reservations automatically…
                    </div>

                    <!-- Stock Check Result Block -->
                    <div id="stockAnalysisResult" class="hidden space-y-4 pt-2">
                        <div class="bg-white border rounded-xl p-4" style="border-color: #e2e8f0;">
                            <div class="flex items-center justify-between mb-4">
                                <div>
                                    <div class="text-[10px] font-bold uppercase tracking-wider mb-1" style="color: #94a3b8;">STOCK STATUS</div>
                                    <div class="font-bold text-sm leading-tight" style="color: #0f172a;">Global Stock<br>Overview</div>
                                </div>
                                <span id="overallStockBadge" class="badge px-3 py-1.5 text-[10px] tracking-wider font-extrabold rounded-full" style="background-color: #c6e6d1; color: #1a4d2e;">SUFFICIENT</span>
                            </div>
                            
                            <div class="mb-2 flex items-center justify-between">
                                <span class="text-xs font-medium" style="color: #64748b;">Ordered Quantity</span>
                                <span id="orderedQtyText" class="text-xs font-bold" style="color: #0f172a;">-</span>
                            </div>
                            
                            <div class="w-full rounded-full h-2 mb-2" style="background-color: #e2e8f0;">
                                <div id="stockProgressBar" class="h-2 rounded-full transition-all duration-500" style="width: 0%; background-color: #1a4d2e;"></div>
                            </div>
                            
                            <div class="mb-5 flex items-center justify-between">
                                <span class="text-xs font-medium" style="color: #64748b;">Available Stock</span>
                                <span id="availableQtyText" class="text-xs font-bold" style="color: #0f172a;">-</span>
                            </div>
                            
                            <!-- Message -->
                            <div class="rounded-lg p-3 border text-xs font-medium leading-relaxed flex gap-2 items-start" id="overallStockMessageWrapper" style="background-color: #f8fafc; border-color: #f1f5f9;">
                                <i class="ti ti-circle-check-filled text-base mt-0.5 shrink-0" id="overallStockIcon" style="color: #1a4d2e;"></i>
                                <span id="overallStockMessage" style="color: #475569;">All line items are currently in stock across the regional distribution hubs.</span>
                            </div>
                            <div id="stockItemDetails" class="mt-4"></div>
                        </div>

                        <!-- Notes Area -->
                        <div class="space-y-2 pt-2">
                            <label class="mb-1 block text-xs font-bold text-slate-800">Fulfillment Notes</label>
                            <textarea id="fulfillmentNotes" class="input-theme rounded-xl p-3 text-sm focus:outline-none min-h-[100px] resize-none" placeholder="Add internal notes regarding logistics or warehouse handling..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white border rounded-2xl p-5 shadow-sm" style="border-color: #e2e8f0;">
                <h3 class="text-base font-bold mb-3 m-0 text-slate-900">Order Audit Trail</h3>
                <div class="max-h-72 space-y-2 overflow-y-auto">
                    <?php if (empty($auditRows)): ?>
                        <p class="m-0 text-xs text-slate-500">No audited modifications yet.</p>
                    <?php else: foreach ($auditRows as $audit): ?>
                        <div class="rounded-lg border border-slate-100 bg-slate-50 p-2 text-xs">
                            <div class="font-bold text-slate-800"><?= htmlspecialchars(ucwords(str_replace('_', ' ', (string) $audit['action']))) ?></div>
                            <div class="mt-1 text-slate-500"><?= htmlspecialchars($audit['user_name']) ?> · <?= htmlspecialchars(formatDateDMYTime($audit['created_at'])) ?></div>
                            <?php if (!empty($audit['reason'])): ?><div class="mt-1 text-slate-700"><b>Reason:</b> <?= htmlspecialchars($audit['reason']) ?></div><?php endif; ?>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        let isStockChecked = false;
        let overallStatus = '';
        const canResolveOrderMapping = <?= $canResolveOrderMapping ? 'true' : 'false' ?>;

        function escapeOrderDetailText(value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        }

        function mappingResolverHtml(item) {
            if (!['NOT_FOUND', 'INVALID_QUANTITY'].includes(item.status)) {
                return '';
            }

            if (!canResolveOrderMapping) {
                return '<div class="mt-3 border-t border-amber-200 pt-3 text-xs font-medium text-amber-800">Order edit permission is required to resolve this item.</div>';
            }

            const reason = item.status === 'NOT_FOUND'
                ? 'Select the matching active Product Master item.'
                : 'Enter a quantity greater than zero and confirm the Product Master item.';

            return `<div class="order-mapping-resolver mt-3 border-t border-amber-200 bg-amber-50/60 pt-3" data-item-id="${Number(item.id)}">
                <p class="mb-3 text-xs font-semibold text-amber-800">${reason}</p>
                <div class="space-y-3">
                    <div>
                        <label class="mb-1 block text-[11px] font-bold uppercase text-slate-500">Product Master</label>
                        <select class="order-product-mapping-select w-full" aria-label="Select Product Master item"></select>
                    </div>
                    <div class="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-2">
                        <div>
                            <label class="mb-1 block text-[11px] font-bold uppercase text-slate-500">Quantity</label>
                            <input type="number" min="0.001" step="any" class="order-mapping-quantity input-theme h-10" value="${escapeOrderDetailText(item.quantity)}">
                        </div>
                        <button type="button" class="saveOrderItemMappingBtn inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-emerald-700 px-4 text-xs font-bold text-white shadow-sm hover:bg-emerald-800">
                            <i class="ti ti-check text-base"></i> Resolve
                        </button>
                    </div>
                </div>
            </div>`;
        }

        function initializeOrderMappingSearch() {
            $('.order-product-mapping-select').each(function () {
                const select = $(this);
                if (select.hasClass('select2-hidden-accessible')) {
                    return;
                }
                select.select2({
                    width: '100%',
                    placeholder: 'Search Product Master...',
                    minimumInputLength: 2,
                    ajax: {
                        url: 'ajax.php',
                        type: 'POST',
                        dataType: 'json',
                        delay: 250,
                        data: function (params) {
                            return {
                                searchActiveProductsForOrderMapping: '1',
                                term: params.term || ''
                            };
                        },
                        processResults: function (response) {
                            return { results: Array.isArray(response.results) ? response.results : [] };
                        }
                    }
                });
            });
        }

        $('#checkStockBtn').on('click', function () {
            const btn = $(this);
            const spinner = $('#stockSpinner');
            const icon = $('#stockSearchIcon');

            btn.prop('disabled', true).css('opacity', '0.7');
            icon.hide();
            spinner.show();
            $('#actionButtonsContainer').addClass('hidden').empty();

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { checkOrderStockAvailability: '1', order_id: <?= $orderId ?> },
                dataType: 'json',
                success: function (res) {
                    btn.prop('disabled', false).css('opacity', '1');
                    spinner.hide();
                    icon.show();

                    if (res.status === 'success') {
                        $('#automaticStockNotice').addClass('hidden');
                        isStockChecked = true;
                        overallStatus = res.overall_status;
                        
                        // Update individual badges
                        res.items.forEach(function (item) {
                            const badge = $(`.stock-item-status[data-item-id="${Number(item.id)}"]`);
                            if (item.status === 'SUFFICIENT') {
                                badge.css({backgroundColor: '#dcfce7', color: '#15803d'}).text('STOCK AVAILABLE');
                            } else if (item.status === 'COMPLETED') {
                                badge.css({backgroundColor: '#f1f5f9', color: '#475569'}).text('COMPLETED');
                            } else if (item.status === 'NOT_FOUND') {
                                badge.css({backgroundColor: '#fef3c7', color: '#b45309'}).text('MAPPING REQUIRED');
                            } else if (item.status === 'INVALID_QUANTITY') {
                                badge.css({backgroundColor: '#fef3c7', color: '#b45309'}).text('QUANTITY REQUIRED');
                            } else if (item.status === 'PARTIAL') {
                                badge.css({backgroundColor: '#dbeafe', color: '#1d4ed8'}).text('PARTIALLY AVAILABLE');
                            } else {
                                badge.css({backgroundColor: '#fee2e2', color: '#dc2626'}).text('STOCK UNAVAILABLE');
                            }
                            const actions = $(`.line-fulfillment-actions[data-item-id="${Number(item.id)}"]`);
                            if (item.status === 'COMPLETED' || ['completed', 'dispatched'].includes(item.fulfillment_status)) {
                                const finalLabel = item.fulfillment_status === 'dispatched' ? 'Dispatched' : 'Completed';
                                actions.html(`<span class="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600">${finalLabel}</span>`);
                            } else if (item.status === 'SUFFICIENT') {
                                actions.html(`<button type="button" class="processLineDispatch rounded-lg bg-emerald-700 px-2 py-1 text-[10px] font-bold text-white" data-item-id="${Number(item.id)}">Process item</button>`);
                            } else if (item.fulfillment_action === 'production') {
                                actions.html('<span class="rounded-lg bg-blue-50 px-2 py-1 text-[10px] font-bold text-blue-700">Production in progress</span>');
                            } else if (item.fulfillment_action === 'procurement') {
                                actions.html('<span class="rounded-lg bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-700">Procurement in progress</span>');
                            } else if (!['NOT_FOUND', 'INVALID_QUANTITY', 'COMPLETED'].includes(item.status)) {
                                actions.html(`<button type="button" class="routeLineProcurement rounded-lg bg-amber-100 px-2 py-1 text-[10px] font-bold text-amber-800" data-item-id="${Number(item.id)}">Procure</button><button type="button" class="routeLineProduction rounded-lg bg-blue-100 px-2 py-1 text-[10px] font-bold text-blue-800" data-item-id="${Number(item.id)}">Produce</button>`);
                            } else {
                                actions.empty();
                            }
                        });

                        // Show right side panel details
                        let detailsHtml = '';
                        res.items.forEach(function (item) {
                            const isInvalid = ['NOT_FOUND', 'INVALID_QUANTITY'].includes(item.status);
                            const statusClass = item.status === 'SUFFICIENT'
                                ? 'text-[#1a4d2e]'
                                : (isInvalid ? 'text-amber-700' : 'text-rose-600');
                            const statusLabels = {
                                SUFFICIENT: 'Sufficient',
                                COMPLETED: 'Completed',
                                PARTIAL: 'Partially available',
                                UNAVAILABLE: 'Stock unavailable',
                                LOW: 'Short',
                                NOT_FOUND: 'Mapping required',
                                INVALID_QUANTITY: 'Quantity required'
                            };
                            const statusText = statusLabels[item.status] || 'Review required';
                            const unitFactor = Math.max(Number(item.unit_factor || 1), 0.00000001);
                            const unitName = item.unit_name || 'Units';
                            // Stock is stored in base units, but the order panel must show the
                            // quantity in the unit selected on the order (e.g. 10 mg, not 0.01).
                            const qtyOrdered = Number(item.quantity || 0);
                            const qtyAvail = Number(item.reserved_base || item.available_stock || 0) / unitFactor;
                            const qtyShort = Number(item.shortfall_base || 0) / unitFactor;
                            const minimumRequired = Number(item.minimum_required_base || 0) / unitFactor;
                            const pct = qtyOrdered > 0 ? Math.min(100, (qtyAvail / qtyOrdered) * 100) : 0;
                            const barColor = item.status === 'SUFFICIENT'
                                ? 'bg-[#1a4d2e]'
                                : (isInvalid ? 'bg-amber-500' : 'bg-rose-500');

                            detailsHtml += `
                                <div class="space-y-1 mb-4 pb-3 border-b border-slate-100 last:border-0 last:mb-0 last:pb-0">
                                    <div class="flex justify-between items-center text-[11px] font-bold text-slate-800 mb-2">
                                        <span>${escapeOrderDetailText(item.product_name)}</span>
                                        <span class="${statusClass}">${statusText}</span>
                                    </div>
                                    <div class="flex justify-between text-xs font-medium text-slate-500 mb-1">
                                        <span>Ordered</span>
                                        <span class="font-bold text-slate-700">${qtyOrdered} ${escapeOrderDetailText(unitName)}</span>
                                    </div>
                                    <div class="w-full bg-slate-100 rounded-full h-1.5 mb-1">
                                        <div class="${barColor} h-1.5 rounded-full" style="width: ${pct}%"></div>
                                    </div>
                                    <div class="flex justify-between text-xs font-medium text-slate-500">
                                        <span>Reserved / available</span>
                                        <span class="font-bold ${statusClass}">${qtyAvail} ${escapeOrderDetailText(unitName)}</span>
                                    </div>
                                    <div class="flex justify-between text-xs font-medium text-slate-500">
                                        <span>Shortfall</span>
                                        <span class="font-bold text-rose-600">${qtyShort} ${escapeOrderDetailText(unitName)}</span>
                                    </div>
                                    <div class="flex justify-between text-xs font-medium text-slate-500">
                                        <span>Minimum stock retained</span>
                                        <span class="font-bold text-slate-700">${minimumRequired} ${escapeOrderDetailText(unitName)}</span>
                                    </div>
                                    ${mappingResolverHtml(item)}
                                </div>`;
                        });
                        $('#stockItemDetails').html(detailsHtml);
                        initializeOrderMappingSearch();

                        // Populate quantity strings
                        const unitIds = [...new Set(res.items.map(item => Number(item.unit || 0)))];
                        const hasSingleUnit = unitIds.length === 1;
                        const summaryUnit = hasSingleUnit ? (res.items[0].unit_name || 'Units') : 'mixed units';
                        const orderedQuantity = res.items.reduce(function (total, item) {
                            return total + Number(item.quantity || 0);
                        }, 0);
                        const availableStock = res.items.reduce(function (total, item) {
                            const factor = Math.max(Number(item.unit_factor || 1), 0.00000001);
                            return total + (Number(item.reserved_base || item.available_stock || 0) / factor);
                        }, 0);
                        const reqText = hasSingleUnit ? `${orderedQuantity.toLocaleString()} ${summaryUnit}` : 'Multiple units';
                        const availText = hasSingleUnit ? `${availableStock.toLocaleString()} ${summaryUnit}` : 'Multiple units';
                        $('#orderedQtyText').text(reqText);
                        $('#availableQtyText').text(availText);
                        
                        // Calculate percentage
                        const orderedBaseQuantity = res.items.reduce(function (total, item) {
                            return total + Number(item.required_base || 0);
                        }, 0);
                        const availableBaseStock = res.items.reduce(function (total, item) {
                            return total + Number(item.reserved_base || item.available_stock || 0);
                        }, 0);
                        let pct = 0;
                        if (orderedBaseQuantity > 0) {
                             pct = Math.min(100, Math.round((availableBaseStock / orderedBaseQuantity) * 100));
                        }

                        const invalidItems = res.items.filter(function (item) {
                            return ['NOT_FOUND', 'INVALID_QUANTITY'].includes(item.status);
                        });

                        if (res.terminal) {
                            $('#overallStockBadge').css({backgroundColor: '#e2e8f0', color: '#475569'}).text('COMPLETED');
                            $('#stockProgressBar').css({width: '100%', backgroundColor: '#64748b'});
                            $('#overallStockMessageWrapper').css({backgroundColor: '#f8fafc', borderColor: '#e2e8f0'});
                            $('#overallStockIcon').removeClass().addClass('ti ti-circle-check-filled text-base mt-0.5 shrink-0').css('color', '#64748b');
                            $('#overallStockMessage').text('This order is already in a terminal fulfillment state. No further routing action is available.').css('color', '#475569');
                            $('#actionButtonsContainer').addClass('hidden').empty();
                        } else if (invalidItems.length > 0) {
                            $('#overallStockBadge').css({backgroundColor: '#fef3c7', color: '#b45309'}).text('ACTION REQUIRED');
                            $('#stockProgressBar').css({width: pct + '%', backgroundColor: '#f59e0b'});
                            $('#overallStockMessageWrapper').css({backgroundColor: '#fffbeb', borderColor: '#fde68a'});
                            $('#overallStockIcon').removeClass().addClass('ti ti-alert-triangle-filled text-base mt-0.5 shrink-0').css('color', '#d97706');
                            $('#overallStockMessage').text('Resolve the highlighted product mapping or quantity before routing this order.').css('color', '#92400e');
                            $('#actionButtonsContainer').addClass('hidden').empty();
                        } else if (res.overall_status === 'SUFFICIENT') {
                            // Render Sufficient UI
                            $('#overallStockBadge').css({backgroundColor: '#c6e6d1', color: '#1a4d2e'}).text('SUFFICIENT');
                            $('#stockProgressBar').css({width: pct + '%', backgroundColor: '#1a4d2e'});
                            
                            $('#overallStockMessageWrapper').css({backgroundColor: '#f8fafc', borderColor: '#f1f5f9'});
                            $('#overallStockIcon').removeClass().addClass('ti ti-circle-check-filled text-base mt-0.5 shrink-0').css('color', '#1a4d2e');
                            $('#overallStockMessage').text('All line items are currently in stock across the regional distribution hubs.').css('color', '#475569');
                            
                            // Render dispatch button
                            const extraActions = `
                                <button type="button" class="btnHoldOrderModalBtn inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50" data-id="<?= $orderId ?>" title="Hold Order">
                                    <i class="ti ti-player-pause text-sm"></i> Hold Order
                                </button>
                                <button type="button" class="btnCancelOrderModalBtn inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-white px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50" data-id="<?= $orderId ?>" title="Cancel Order">
                                    <i class="ti ti-circle-x text-sm"></i> Cancel Order
                                </button>
                            `;
                            $('#actionButtonsContainer').html(`
                                <button type="button" id="dispatchBtn" class="btn-primary d-inline-flex align-items-center justify-center gap-2 px-4 py-2 text-sm font-bold text-white shadow-sm focus:outline-none" style="border-radius: 0.375rem;">
                                    <i class="ti ti-truck-delivery text-lg"></i> SEND TO DISPATCH FOR PROCESSING
                                </button>
                                ${extraActions}
                            `);
                        } else {
                            // Render Low Stock UI
                            $('#overallStockBadge').css({backgroundColor: '#fee2e2', color: '#ef4444'}).text(res.overall_status === 'PARTIAL' ? 'PARTIALLY AVAILABLE' : 'STOCK UNAVAILABLE');
                            $('#stockProgressBar').css({width: pct + '%', backgroundColor: '#ef4444'});
                            
                            $('#overallStockMessageWrapper').css({backgroundColor: '#fef2f2', borderColor: '#fee2e2'});
                            $('#overallStockIcon').removeClass().addClass('ti ti-alert-triangle-filled text-base mt-0.5 shrink-0').css('color', '#ef4444');
                            $('#overallStockMessage').text('Insufficient stock available for the current order. Please initiate procurement or production.').css('color', '#991b1b');
                            
                            const extraActions = `
                                <button type="button" class="btnHoldOrderModalBtn inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50" data-id="<?= $orderId ?>" title="Hold Order">
                                    <i class="ti ti-player-pause text-sm"></i> Hold Order
                                </button>
                                <button type="button" class="btnCancelOrderModalBtn inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-white px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50" data-id="<?= $orderId ?>" title="Cancel Order">
                                    <i class="ti ti-circle-x text-sm"></i> Cancel Order
                                </button>
                            `;
                            $('#actionButtonsContainer').html(`<div class="flex items-center gap-2"><span class="text-xs font-semibold text-slate-500 me-2">Choose Production or Procurement on each shortfall line.</span>${extraActions}</div>`);
                        }

                        if (invalidItems.length === 0 && !res.terminal) {
                            $('#actionButtonsContainer').removeClass('hidden');
                        }
                        $('#stockAnalysisResult').show().hide().fadeIn('slow');
                        toastr.success('Stock checked successfully.');
                    } else {
                        toastr.error(res.message || 'Failed to check stock.');
                    }
                },
                error: function () {
                    $('#stockSpinner').hide();
                    $('#stockSearchIcon').show();
                    $('#checkStockBtn').prop('disabled', false).css('opacity', '1');
                    $('#automaticStockNotice').removeClass('hidden').removeClass('bg-emerald-50 text-emerald-800').addClass('bg-rose-50 text-rose-700').html('<i class="ti ti-alert-circle"></i> Automatic fulfillment analysis could not be loaded.');
                    toastr.error('Request failed.');
                }
            });
        });

        function runLineAction(action, itemId, successRedirect) {
            const payload = { order_id: <?= $orderId ?>, order_item_id: itemId, fulfillment_notes: $('#fulfillmentNotes').val().trim() };
            payload[action] = '1';
            $.ajax({
                url: 'ajax.php', type: 'POST', dataType: 'json', data: payload,
                success: function (response) {
                    if (response.status !== 'success') {
                        toastr.error(response.message || 'Unable to process this item.');
                        return;
                    }
                    toastr.success(response.message);
                    if (successRedirect) {
                        setTimeout(() => window.location.href = successRedirect, 900);
                    } else {
                        $('#checkStockBtn').trigger('click');
                    }
                },
                error: function () { toastr.error('Unable to process this item.'); }
            });
        }

        $(document).on('click', '.processLineDispatch', function () {
            runLineAction('processOrderItemForDispatch', Number($(this).data('item-id') || 0));
        });
        $(document).on('click', '.routeLineProcurement', function () {
            runLineAction('sendOrderToProcurement', Number($(this).data('item-id') || 0), 'index.php?page=purchase-management&open_inbound=1');
        });
        $(document).on('click', '.routeLineProduction', function () {
            runLineAction('sendOrderToProduction', Number($(this).data('item-id') || 0), 'index.php?page=production-plan');
        });

        $(document).on('click', '.btnHoldOrderModalBtn', function () {
            if (!confirm('Are you sure you want to place this order on Hold?')) return;
            $.post('ajax.php', { changeOrderStatusReceived: '1', id: <?= $orderId ?>, status: 2, csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '' }, function (res) {
                try { res = typeof res === 'string' ? JSON.parse(res) : res; } catch (e) {}
                if (res && res.status === 'success') {
                    toastr.success(res.message || 'Order placed on Hold.');
                    setTimeout(() => location.reload(), 800);
                } else {
                    toastr.error(res && res.message ? res.message : 'Failed to update order status.');
                }
            });
        });

        $(document).on('click', '.btnCancelOrderModalBtn', function () {
            if (!confirm('Are you sure you want to Cancel this order?')) return;
            $.post('ajax.php', { changeOrderStatusReceived: '1', id: <?= $orderId ?>, status: 6, csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '' }, function (res) {
                try { res = typeof res === 'string' ? JSON.parse(res) : res; } catch (e) {}
                if (res && res.status === 'success') {
                    toastr.success(res.message || 'Order cancelled.');
                    setTimeout(() => location.reload(), 800);
                } else {
                    toastr.error(res && res.message ? res.message : 'Failed to cancel order.');
                }
            });
        });

        $('#checkStockBtn').trigger('click');

        $(document).on('click', '.saveOrderItemMappingBtn', function () {
            const button = $(this);
            const resolver = button.closest('.order-mapping-resolver');
            const orderItemId = Number(resolver.data('item-id') || 0);
            const productId = Number(resolver.find('.order-product-mapping-select').val() || 0);
            const quantity = Number(resolver.find('.order-mapping-quantity').val() || 0);

            if (!productId || quantity <= 0) {
                toastr.error('Select a Product Master item and enter a quantity greater than zero.');
                return;
            }

            const originalContent = button.html();
            button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" aria-hidden="true"></span> Saving');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    resolveOrderItemMapping: '1',
                    order_id: <?= $orderId ?>,
                    order_item_id: orderItemId,
                    product_id: productId,
                    quantity: quantity
                },
                success: function (response) {
                    if (response.status !== 'success') {
                        button.prop('disabled', false).html(originalContent);
                        toastr.error(response.message || 'Unable to update the product mapping.');
                        return;
                    }

                    const item = response.item || {};
                    const row = $(`#orderItemRow-${Number(item.id || orderItemId)}`);
                    row.find('.order-item-product-name').text(item.product_name || '');
                    row.find('.order-item-product-code').text('SKU: ' + (item.product_code || '-'));
                    row.find('.order-item-quantity').val(Number(item.quantity || quantity));
                    toastr.success(response.message);
                    $('#checkStockBtn').trigger('click');
                },
                error: function (xhr) {
                    button.prop('disabled', false).html(originalContent);
                    const message = xhr.responseJSON && xhr.responseJSON.message
                        ? xhr.responseJSON.message
                        : 'Unable to update the product mapping.';
                    toastr.error(message);
                }
            });
        });

        // Trigger Dispatch
        $(document).on('click', '#dispatchBtn', function () {
            let notes = $('#fulfillmentNotes').val().trim();
            Swal.fire({
                title: 'Confirm Dispatch?',
                text: "Route order to Dispatch and allocate stock?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, Send to Dispatch',
                customClass: {
                    confirmButton: 'btn btn-primary inline-flex rounded-xl px-4 py-2 text-sm font-bold text-white mr-2',
                    cancelButton: 'inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: { sendOrderToDispatch: '1', order_id: <?= $orderId ?>, fulfillment_notes: notes },
                        success: function (res) {
                            if (res.status === 'success') {
                                 toastr.success(res.message);
                                 setTimeout(function () {
                                     window.location.href = 'index.php?page=order-received';
                                 }, 1500);
                            } else {
                                toastr.error(res.message);
                            }
                        }
                    });
                }
            });
        });

        // Trigger Procurement
        $(document).on('click', '#procureBtn', function () {
            let notes = $('#fulfillmentNotes').val().trim();
            Swal.fire({
                title: 'Initiate Procurement?',
                text: "Send the shortfall items to Purchase Management for review?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, Route to Procurement',
                customClass: {
                    confirmButton: 'inline-flex rounded-xl bg-amber-600 px-4 py-2 text-sm font-bold text-white mr-2',
                    cancelButton: 'inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: { sendOrderToProcurement: '1', order_id: <?= $orderId ?>, fulfillment_notes: notes },
                        success: function (res) {
                            if (res.status === 'success') {
                                toastr.success(res.message);
                                setTimeout(function () {
                                    window.location.href = 'index.php?page=purchase-management&open_inbound=1';
                                }, 1500);
                            } else {
                                toastr.error(res.message);
                            }
                        }
                    });
                }
            });
        });

        // Trigger Production
        $(document).on('click', '#produceBtn', function () {
            let notes = $('#fulfillmentNotes').val().trim();
            Swal.fire({
                title: 'Initiate Production?',
                text: "Create a production plan for the items in this order?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, Route to Production',
                customClass: {
                    confirmButton: 'btn btn-primary inline-flex rounded-xl px-4 py-2 text-sm font-bold text-white mr-2',
                    cancelButton: 'inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: { sendOrderToProduction: '1', order_id: <?= $orderId ?>, fulfillment_notes: notes },
                        success: function (res) {
                            if (res.status === 'success') {
                                toastr.success(res.message);
                                if (Array.isArray(res.bom_review_required) && res.bom_review_required.length > 0) {
                                    toastr.warning('BOM review required for: ' + res.bom_review_required.join(', '));
                                }
                                setTimeout(function () {
                                    let orderNumber = encodeURIComponent(res.order_number || '');
                                    window.location.href = 'index.php?page=production-plan&order=' + orderNumber;
                                }, 1500);
                            } else {
                                toastr.error(res.message);
                            }
                        }
                    });
                }
            });
        });

        // Save Customer and Order Info
        $('#saveOrderCustomerInfoBtn').on('click', function () {
            const btn = $(this);
            const originalHtml = btn.html();
            btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span> SAVING...');

            const formData = $('#orderCustomerInfoForm').serialize();

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function (res) {
                    btn.prop('disabled', false).html(originalHtml);
                    if (res && res.status === 'success') {
                        toastr.success(res.message || 'Details saved successfully.');
                    } else {
                        toastr.error(res && res.message ? res.message : 'Failed to save details.');
                    }
                },
                error: function () {
                    btn.prop('disabled', false).html(originalHtml);
                    toastr.error('An error occurred while saving details.');
                }
            });
        });

        // Auto-extract PAN and State Code from GSTIN
        $('#orderCustomerGstin').on('input blur', function () {
            const val = $(this).val().trim().toUpperCase();
            if (val.length === 15) {
                const panField = $('#orderCustomerPan');
                const stateCodeField = $('#orderCustomerStateCode');
                if (!panField.val().trim()) {
                    panField.val(val.substring(2, 12));
                }
                if (!stateCodeField.val().trim()) {
                    stateCodeField.val(val.substring(0, 2));
                }
            }
        });
    });
</script>
<?php endSection(); ?>
