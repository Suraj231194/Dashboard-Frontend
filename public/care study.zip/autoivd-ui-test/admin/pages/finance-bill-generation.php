<?php
$financeView = 'bill_generation';
require __DIR__ . '/finance-page.php';
