<?php
if (!defined('PAYROLL_CONTEXT')) define('PAYROLL_CONTEXT', true);
require_once __DIR__ . '/../payroll/payroll_common.php';

$canViewPayRuns = payrollCan($conn, 'payroll_pay_runs_view');
$canManagePayRuns = payrollCan($conn, 'payroll_pay_runs_manage');
$payrollScope = $canViewPayRuns ? payrollCurrentScope($conn, (int) ($_SESSION['user_id'] ?? 0)) : null;
$payRunHistory = $payrollScope ? payrollRunRows($conn, $payrollScope) : [];
$initialMonth = date('Y-m');
$initialPaymentDate = $payrollScope && payrollSchemaReady($conn)
    ? payrollDefaultPaymentDate($conn, $initialMonth, $payrollScope)
    : date('Y-m-d');
$showHistory = ($_GET['tab'] ?? '') === 'history';
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <?php if (!$canViewPayRuns): ?>
        <div class="card border border-rose-200 bg-rose-50 rounded-2xl"><div class="card-body p-6 text-center text-rose-700"><i class="ti ti-lock fs-2 d-block mb-3"></i>Pay Runs are restricted to authorized Payroll users.</div></div>
    <?php elseif (!payrollSchemaReady($conn)): ?>
        <div class="card border border-amber-200 bg-amber-50 rounded-2xl"><div class="card-body p-6 text-center text-amber-700">Payroll Management is not configured. Apply the Payroll migration before using this page.</div></div>
    <?php else: ?>
        <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-6 ui-page-header-with-actions">
            <div class="ui-page-title-banner">
                <h2 class="mb-1 text-2xl fw-bold text-slate-900" style="font-family:'Sora',sans-serif">Pay Runs</h2>
                <p class="mb-0 text-sm text-slate-500">Create attendance-linked monthly payroll and download the bank disbursement PDF.</p>
            </div>
            <?php if ($canManagePayRuns): ?>
                <button class="btn btn-primary rounded-xl px-4 d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#createPayRunModal">
                    <i class="ti ti-plus"></i> Create Pay Run
                </button>
            <?php endif; ?>
        </div>

        <div class="d-flex gap-2 mb-4" role="tablist">
            <button class="btn <?= $showHistory ? 'btn-outline-primary' : 'btn-primary active' ?> rounded-xl payroll-tab" data-target="payrollRunPanel">Run Payroll</button>
            <button class="btn <?= $showHistory ? 'btn-primary active' : 'btn-outline-primary' ?> rounded-xl payroll-tab" data-target="payrollHistoryPanel">Payroll History</button>
        </div>

        <section id="payrollRunPanel" class="payroll-panel<?= $showHistory ? ' d-none' : '' ?>">
            <div id="payRunEmptyState" class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                <div class="card-body p-6 p-lg-8 d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4">
                    <div class="d-flex align-items-center gap-4">
                        <span class="d-inline-flex align-items-center justify-content-center rounded-2xl bg-emerald-50 text-emerald-700" style="width:56px;height:56px"><i class="ti ti-calendar-dollar fs-3"></i></span>
                        <div><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Current Month</div><h4 class="mb-1 fw-bold text-slate-900"><?= htmlspecialchars(date('F Y')) ?></h4><p class="mb-0 text-sm text-slate-500">Select Create Pay Run to choose the duration and company payment date.</p></div>
                    </div>
                    <div class="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"><div class="text-xs fw-bold text-slate-400 text-uppercase">Generated Runs</div><div class="text-2xl fw-bold text-slate-900"><?= count($payRunHistory) ?></div></div>
                </div>
            </div>

            <div id="payRunPreview" class="d-none">
                <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                    <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex flex-column flex-lg-row justify-content-between gap-3">
                        <div><h5 class="mb-1 fw-bold text-slate-900" id="payRunPreviewTitle">Payroll Preview</h5><p class="mb-0 text-sm text-slate-500" id="payRunPreviewSubtitle"></p></div>
                        <div class="d-flex flex-wrap gap-2">
                            <div class="position-relative">
                                <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:12px"></i>
                                <input type="search" class="form-control form-control-sm rounded-xl ps-5" id="payRunPreviewSearch" placeholder="Search employee..." aria-label="Search payroll preview">
                            </div>
                            <span class="badge rounded-pill bg-slate-100 text-slate-700 px-3 py-2" id="payRunEmployeeCount"></span>
                            <span class="badge rounded-pill bg-emerald-100 text-emerald-700 px-3 py-2" id="payRunTotal"></span>
                        </div>
                    </div>
                    <div id="payRunValidation" class="d-none border-bottom border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-800"></div>
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead class="bg-slate-50"><tr>
                                <th class="px-4 py-3 text-xs text-uppercase text-slate-500">Serial #</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Employee Code</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Name</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Monthly Salary</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Actual Salary</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Total Working Days</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">PF Amount</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">ESIC Amount</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Advance Taken</th>
                                <th class="py-3 text-xs text-uppercase text-slate-500">Bank Account #</th>
                                <th class="px-4 py-3 text-xs text-uppercase text-slate-500">Bank Name</th>
                            </tr></thead>
                            <tbody id="payRunPreviewBody"></tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end gap-3 border-top border-slate-200 bg-white px-4 py-3">
                        <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm" id="cancelPayRunPreview">Cancel</button>
                        <?php if ($canManagePayRuns): ?><button type="button" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm" id="generatePayRun"><i class="ti ti-file-type-pdf text-lg"></i> Generate</button><?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <section id="payrollHistoryPanel" class="payroll-panel<?= $showHistory ? '' : ' d-none' ?>">
            <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                <div class="card-header bg-white border-bottom border-slate-100 p-5"><h5 class="mb-1 fw-bold text-slate-900">Generated Pay Runs</h5><p class="mb-0 text-sm text-slate-500">Generated payroll snapshots remain fixed and available for download.</p></div>
                <div class="table-responsive"><table class="table align-middle mb-0"><thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Run</th><th class="py-3 text-xs text-uppercase text-slate-500">Month</th><th class="py-3 text-xs text-uppercase text-slate-500">Payment Date</th><th class="py-3 text-xs text-uppercase text-slate-500">Employees</th><th class="py-3 text-xs text-uppercase text-slate-500">Salary</th><th class="py-3 text-xs text-uppercase text-slate-500">Generated</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500 text-end">Action</th></tr></thead><tbody>
                    <?php if (!$payRunHistory): ?><tr><td colspan="7" class="text-center py-10 text-slate-500">No pay runs generated yet.</td></tr>
                    <?php else: foreach ($payRunHistory as $run): ?><tr><td class="px-5 py-4 fw-bold text-slate-800"><?= htmlspecialchars($run['run_number']) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars(date('F Y', strtotime($run['payroll_month'] . '-01'))) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars(date('d M Y', strtotime($run['payment_date']))) ?></td><td class="py-4 text-slate-600"><?= (int) $run['employee_count'] ?></td><td class="py-4 fw-bold text-slate-800">₹<?= payrollMoney($run['actual_salary_total']) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars(date('d M Y, h:i A', strtotime($run['generated_at']))) ?></td><td class="px-5 py-4 text-end"><div class="d-inline-flex gap-2"><button type="button" class="btn btn-sm btn-icon btn-outline-primary rounded-lg preview-pay-run" data-run="<?=htmlspecialchars($run['run_number'],ENT_QUOTES)?>" data-preview="payroll-file.php?type=pay-run-preview&amp;id=<?=(int)$run['id']?>" data-download="payroll-file.php?type=pay-run&amp;id=<?=(int)$run['id']?>" title="Preview full payroll PDF"><i class="ti ti-eye"></i></button><a class="btn btn-sm btn-icon btn-outline-primary rounded-lg" href="payroll-file.php?type=pay-run&amp;id=<?=(int)$run['id']?>" title="Download bank PDF"><i class="ti ti-download"></i></a></div></td></tr><?php endforeach; endif; ?>
                </tbody></table></div>
            </div>
        </section>

        <section id="payRunPdfPreview" class="d-none mt-6">
            <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                    <div><h5 class="mb-1 fw-bold text-slate-900">Generated PDF Preview</h5><p class="mb-0 text-sm text-slate-500" id="payRunPdfTitle"></p></div>
                    <div class="d-flex gap-2"><a class="btn btn-outline-primary rounded-xl" id="downloadPayRunPdf"><i class="ti ti-download me-2"></i>Download PDF</a><button type="button" class="btn btn-icon btn-outline-secondary rounded-xl" id="closePayRunPdf" title="Close preview"><i class="ti ti-x"></i></button></div>
                </div>
                <iframe id="payRunPdfFrame" title="Generated payroll PDF" class="w-100 border-0 bg-slate-100" style="height:min(70vh,820px);min-height:480px"></iframe>
            </div>
        </section>

        <div class="modal fade animate__animated fadeIn" id="createPayRunModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                    <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                        <div class="flex items-center gap-3"><span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i class="ti ti-plus text-xl"></i></span><div><h5 class="modal-title m-0 text-lg font-bold text-slate-900">Create Pay Run</h5><p class="m-0 text-sm font-medium text-slate-500">Choose the payroll duration and company salary date.</p></div></div>
                        <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                    </div>
                    <form id="createPayRunForm">
                        <div class="modal-body bg-slate-50/70 !px-4 !py-4"><div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div><label class="mb-1 block text-sm font-medium text-slate-800" for="payrollMonth">Payroll Month <strong class="text-rose-500">*</strong></label><input class="input-theme" type="month" id="payrollMonth" name="payroll_month" value="<?= htmlspecialchars($initialMonth) ?>" required></div>
                            <div><label class="mb-1 block text-sm font-medium text-slate-800" for="payrollPaymentDate">Payment Date <strong class="text-rose-500">*</strong></label><input class="input-theme" type="date" id="payrollPaymentDate" name="payment_date" value="<?= htmlspecialchars($initialPaymentDate) ?>" required><small class="d-block mt-1 text-slate-500">Saved as the configurable company salary date.</small></div>
                        </div></div>
                        <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3"><button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm" data-bs-dismiss="modal">Close</button><button type="submit" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm"><i class="ti ti-eye text-lg"></i> Preview</button></div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($canViewPayRuns && payrollSchemaReady($conn)): startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded',()=>{
    const csrf=<?=json_encode($_SESSION['csrf_token'])?>,money=value=>Number(value||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
    const notify=(type,message)=>window.toastr?toastr[type](message):alert(message);
    const post=async form=>{const response=await fetch('payroll-api.php',{method:'POST',body:form,credentials:'same-origin'}),data=await response.json().catch(()=>({status:'error',message:'Invalid response.'}));if(!response.ok||data.status!=='success')throw new Error(data.message||'Request failed.');return data;};
    document.querySelectorAll('.payroll-tab').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('.payroll-tab').forEach(item=>{item.classList.remove('btn-primary','active');item.classList.add('btn-outline-primary')});button.classList.remove('btn-outline-primary');button.classList.add('btn-primary','active');document.querySelectorAll('.payroll-panel').forEach(panel=>panel.classList.toggle('d-none',panel.id!==button.dataset.target));}));
    const form=document.getElementById('createPayRunForm'),preview=document.getElementById('payRunPreview'),empty=document.getElementById('payRunEmptyState'),body=document.getElementById('payRunPreviewBody'),validation=document.getElementById('payRunValidation'),pdfPreview=document.getElementById('payRunPdfPreview'),pdfFrame=document.getElementById('payRunPdfFrame');
    const showPdfPreview=(title,previewUrl,downloadUrl)=>{document.getElementById('payRunPdfTitle').textContent=title;pdfFrame.src=previewUrl;document.getElementById('downloadPayRunPdf').href=downloadUrl;pdfPreview.classList.remove('d-none');pdfPreview.scrollIntoView({behavior:'smooth',block:'start'});};
    form?.elements.payroll_month?.addEventListener('change',event=>{const month=event.target.value;if(!/^\d{4}-\d{2}$/.test(month))return;const current=form.elements.payment_date.value,day=current?Math.max(1,Math.min(28,Number(current.slice(-2)))):7,[year,monthNumber]=month.split('-').map(Number),paymentMonth=new Date(year,monthNumber,1),paymentYear=paymentMonth.getFullYear(),paymentMonthNumber=String(paymentMonth.getMonth()+1).padStart(2,'0');form.elements.payment_date.value=`${paymentYear}-${paymentMonthNumber}-${String(day).padStart(2,'0')}`;});
    form?.addEventListener('submit',async event=>{event.preventDefault();const button=form.querySelector('[type="submit"]');button.disabled=true;try{const payload=new FormData(form);payload.set('action','preview_pay_run');const data=await post(payload);if(!data.rows.length)throw new Error('No employees with attendance were found for this payroll month.');body.innerHTML=data.rows.map((row,index)=>`<tr class="pay-run-preview-row"><td class="px-4 py-3">${index+1}</td><td>${escapeHtml(row.employee_code)}</td><td class="fw-semibold text-slate-800">${escapeHtml(row.employee_name)}</td><td>₹${money(row.monthly_salary)}</td><td class="fw-bold text-emerald-700">₹${money(row.actual_salary)}</td><td>${Number(row.present_days).toFixed(1)}/${row.month_days}</td><td>₹${money(row.pf_amount)}</td><td>₹${money(row.esic_amount)}</td><td>₹${money(row.advance_taken)}</td><td>${escapeHtml(row.bank_account_number)}</td><td class="px-4">${escapeHtml(row.bank_name)}</td></tr>`).join('');document.getElementById('payRunPreviewSearch').value='';document.getElementById('payRunPreviewTitle').textContent='Payroll Preview · '+new Date(form.elements.payroll_month.value+'-01T00:00:00').toLocaleDateString('en-IN',{month:'long',year:'numeric'});document.getElementById('payRunPreviewSubtitle').textContent='Payment date: '+new Date(form.elements.payment_date.value+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});document.getElementById('payRunEmployeeCount').textContent=data.rows.length+' employees';document.getElementById('payRunTotal').textContent='Net ₹'+money(data.totals.actual_salary);validation.classList.toggle('d-none',!data.validation.length);validation.innerHTML=data.validation.length?'<strong>Complete before Generate:</strong> '+data.validation.map(escapeHtml).join('; '):'';const generateButton=document.getElementById('generatePayRun');if(generateButton){generateButton.classList.remove('d-none');generateButton.disabled=data.validation.length>0;generateButton.title=data.validation.length?'Resolve the listed employee payroll details before generating.':'';}empty.classList.add('d-none');preview.classList.remove('d-none');bootstrap.Modal.getInstance(document.getElementById('createPayRunModal'))?.hide();notify('success',data.message);}catch(error){notify('error',error.message);}finally{button.disabled=false;}});
    document.getElementById('payRunPreviewSearch')?.addEventListener('input',event=>{const term=event.target.value.trim().toLowerCase();document.querySelectorAll('.pay-run-preview-row').forEach(row=>row.classList.toggle('d-none',Boolean(term)&&!row.textContent.toLowerCase().includes(term)));});
    document.getElementById('cancelPayRunPreview')?.addEventListener('click',()=>{preview.classList.add('d-none');empty.classList.remove('d-none');});
    document.getElementById('generatePayRun')?.addEventListener('click',async event=>{const button=event.currentTarget;button.disabled=true;try{const payload=new FormData(form);payload.set('action','generate_pay_run');payload.set('csrf_token',csrf);const data=await post(payload);notify('success',data.message);showPdfPreview(data.run_number,data.preview_url,data.download_url);button.classList.add('d-none');}catch(error){notify('error',error.message);button.disabled=false;}});
    document.querySelectorAll('.preview-pay-run').forEach(button=>button.addEventListener('click',()=>showPdfPreview(button.dataset.run,button.dataset.preview,button.dataset.download)));
    document.getElementById('closePayRunPdf')?.addEventListener('click',()=>{pdfFrame.src='about:blank';pdfPreview.classList.add('d-none');});
    function escapeHtml(value){const node=document.createElement('div');node.textContent=value??'';return node.innerHTML;}
});
</script>
<?php endSection(); endif; ?>
