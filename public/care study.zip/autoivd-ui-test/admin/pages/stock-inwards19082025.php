<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="row col-md-12">
        <div class="card">
            <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                <div class="d-flex align-items-center gap-2">
                    <label for="perPageSelect" class="mb-0">Show</label>
                    <select id="perPageSelect" class="form-select form-select-sm w-auto">
                        <option value="5">5</option>
                        <option value="10" selected>10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <input type="text" id="searchUsers" class="form-control form-control-sm" placeholder="Search Data...">
                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_stock_inwards_add')) { ?>
                        <button type="button" class="btn btn-sm w-50 btn-success" id="addStockInwardsModalBtn">Add New</button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr class="text-nowrap">
                            <th class="border-b border-slate-200 px-6 py-3">#</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Date Of Entry"> Date Of Entry</th>
                            <th class="table-col-150 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Material type"> Material type</th>
                            <th class="table-col-200 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Product"> Product</th>
                            <th class="table-col-200 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Supplier"> Supplier</th>
                            <th class="table-col-150-200 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Received By"> Received By</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Physical Condition"> Physical Condition</th>
                            <th class="border-b border-slate-200 px-6 py-3 table-col-300">Action </th>
                            
                            <!-- <th class="border-b border-slate-200 px-6 py-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <span>Physical Condition</span>
                                    <div class="dropdown me-2">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow show" data-bs-toggle="dropdown" aria-expanded="true">
                                            <i class="ti ti-dots-vertical"></i>
                                        </button>
                                        <div class="dropdown-menu show" data-popper-placement="top-start">
                                            <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>
                                            <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-trash me-1"></i> Delete</a>
                                        </div>
                                    </div>
                                </div>
                            </th> -->

                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white" id="stocksInwardsTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addStockInwardsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Add Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="addStockInwardsForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="do_entry" class="form-label">Date of Entry</label>
                                <input type="date" id="do_entry" autocomplete="off" name="do_entry" class="form-control" placeholder="Enter DOB" required />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="select2SupplierList" class="form-label">Supplier</label>
                                <select id="select2SupplierList" name="select2SupplierList" class="select2 form-select form-select-lg form-control" data-allow-clear="true" required>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="receivedBy" class="form-label">Received By</label>
                                <select id="receivedBy" name="receivedBy" class="select2 form-select form-select-lg" data-allow-clear="true" required>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-2">
                                <label for="" class="form-label">Product Details</label>
                            </div>
                            <div id="productsWrapperWhole"></div>
                            <div class="mb-3">
                                <button type="button" class="btn btn-success btn-sm" id="addProductBtn">+ Add Product</button>
                            </div>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editStockInwardsModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="editStockInwardsForm">
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="stockInwardsViewModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">View Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="stockInwardsView">
                    <div class="modal-body">                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let productIndex = 0;

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function(response) {
                qtyUnitOptions = response;
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadStockInwardsTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadStockInwards: 'loadStockInwards',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function(response) {
                $('#stocksInwardsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function() {
                $('#stocksInwardsTableBody').html('<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function loadSupliersOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadSupplierListOptions: 'loadSupplierListOptions'
            },
            dataType: 'json',
            success: function(response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function(supplier) {
                    html += `<option value="${supplier.key}">${supplier.value}</option>`;
                });
                $('#select2SupplierList').html(html).trigger('change');
            }
        });
    }

    function loadMaterialTypeOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialTypeOption: 'loadMaterialTypeOption'
            },
            dataType: 'json',
            success: function(response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function(prodCateg) {
                    html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                });
                $('#materialTypeList').html(html).trigger('change');
            }
        });
    }

    function loadReceiverEmployeeOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadReceivedByEmpOption: 'loadReceivedByEmpOption'
            },
            dataType: 'json',
            success: function(response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function(prodCateg) {
                    html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                });
                $('#receivedBy').html(html).trigger('change');
            }
        });
    }

    function loadProductsByMaterialType(materialTypeId) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                materialTypeId: materialTypeId,
                loadProductsByMaterialType: 'loadProductsByMaterialType'
            },
            dataType: 'json',
            success: function(response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function(product) {
                    html += `<option value="${product.key}">${product.value}</option>`;
                });
                $('#productsList').html(html).trigger('change');
            }
        });
    }

    $(document).ready(function() {
        loadStockInwardsTable();
        loadSupliersOption();
        loadReceiverEmployeeOption();
        loadStandardUnit();
        $('#searchUsers').on('input', function() {
            loadStockInwardsTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadStockInwardsTable(1);
        });



        $('#addProductBtn').click(function() {
            let qtyUnitHtml = '<option value="">----Select----</option>';
            qtyUnitOptions.forEach(unit => {
                qtyUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });

            const productBlock = `
            <div class="row product-entry mb-2 border rounded p-2" data-index="${productIndex}">
                <div class="col-md-3 mb-2">
                    <label class="form-label">Material Type</label>
                    <select name="materialTypeList[]" class="select2 form-select form-select-lg materialTypeList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Product</label>
                    <select name="productsList[]" class="select2 form-select form-select-lg productsList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Quantity</label>
                    <input type="number" step="any" min="0" name="prodQuantity[]" class="form-control" placeholder="Enter Quantity" required />
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Quantity Unit</label>
                    <select name="prodQuantityUnit[]" class="form-control" required>
                        ${qtyUnitHtml}
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Physical Condition</label>
                    <select name="phycalCondition[]" class="form-control" required>
                        <option value="">----Select----</option>
                        <?php foreach (Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'] as $pckey => $pcval) {
                            echo '<option value="' . $pckey . '">' . $pcval['label'] . '</option>';
                        } ?>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Mfg Date (If any)</label>
                    <input type="date" name="mfgDate[]" class="form-control" placeholder="Enter Mfg" />
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Expiary Date (If any)</label>
                    <input type="date" name="expiaryDate[]" class="form-control" placeholder="Enter Expiary" />
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Enter LOT No.</label>
                    <input type="text" name="lotNumber[]" class="form-control" placeholder="Enter LOT No." />
                </div>
                <div class="col-md-4 mb-3">
                    <label for="remark" class="form-label">Remark</label>
                    <textarea id="remark" rows="1" autocomplete="off" name="remark[]" class="form-control" placeholder="Enter Remark"></textarea>
                </div>
                <div class="col-md-3 mb-2 d-flex align-items-end">
                    <button type="button" class="btn btn-icon btn-label-danger removeProductBtn"><span class="ti ti-trash"></span></button>               
                </div>
            </div>`;

            $('#productsWrapperWhole').append(productBlock);

            // Initialize Select2 on new fields
            $('#productsWrapperWhole .select2').select2({
                placeholder: '----Select Option----',
                dropdownParent: $('#productsWrapperWhole')
            });

            // Load material types in the new block
            const $newMaterialSelect = $(`.product-entry[data-index="${productIndex}"] .materialTypeList`);
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadMaterialTypeOption: 'loadMaterialTypeOption'
                },
                dataType: 'json',
                success: function(response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function(item) {
                        html += `<option value="${item.key}">${item.value}</option>`;
                    });
                    $newMaterialSelect.html(html).trigger('change');
                }
            });

            productIndex++;
        });

        $(document).on('click', '.removeProductBtn', function() {
            $(this).closest('.product-entry').remove();
        });

        $(document).on('click','#addStockInwardsModalBtn', function(){
            $('#addStockInwardsModal').modal('show');
            $('#addProductBtn').trigger('click');
        });

        $('#addStockInwardsForm').on('submit', function(e) {
            e.preventDefault();

            const productCount = $('#productsWrapperWhole .product-entry').length;

            if (productCount === 0) {
                toastr.error('Please add at least one product.');
                return false;
            }

            const form = document.getElementById('addStockInwardsForm');
            const formData = new FormData(form);
            formData.append('addStockInwardsRecord', 'addStockInwardsRecord');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        $('#addStockInwardsModal').modal('hide');
                        $('#addStockInwardsForm')[0].reset();
                        loadStockInwardsTable();
                        toastr.success(response.message);
                    } else if (response.status === 'error') {
                        toastr.error(response.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });





    $(document).on('change', '.materialTypeList', function() {
        const $parentRow = $(this).closest('.product-entry');
        const $productSelect = $parentRow.find('.productsList');
        const materialTypeId = $(this).val();

        if (materialTypeId) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    materialTypeId: materialTypeId,
                    loadProductsByMaterialType: 'loadProductsByMaterialType'
                },
                dataType: 'json',
                success: function(response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function(product) {
                        html += `<option value="${product.key}">${product.value}</option>`;
                    });
                    $productSelect.html(html).trigger('change');
                }
            });
        } else {
            $productSelect.html('<option value="">----Select Option----</option>').trigger('change');
        }
    });


    $(document).on('click', '.stocksInwardsEditModalBtn1', function() {
        let id = $(this).data('id');
        if (id) {
            $('#editStockInwardsForm').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchStockInwardsRecord: 'fetchStockInwardsRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#editStockInwardsModel').modal('show');
                        $('#editStockInwardsForm').find('.modal-body').html(res.data);
                    } else {
                        toastr.error(res.message || 'Unexpected error');
                    }
                },
                error: function(xhr) {
                    toastr.error('Server error occurred.');
                    console.error("Response:", xhr.responseText);
                }
            });
        }
    });

    $(document).on('click', '.stocksInwardsViewModalBtn', function() {
        let id = $(this).data('id');
        
        if (id) {
            $('#stockInwardsView').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchStockInwardsViewRecord: 'fetchStockInwardsViewRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#stockInwardsViewModel').modal('show');
                        $('#stockInwardsView').find('.modal-body').html(res.data);
                    } else {
                        toastr.error(res.message || 'Unexpected error');
                    }
                },
                error: function(xhr) {
                    toastr.error('Server error occurred.');
                    console.error("Response:", xhr.responseText);
                }
            });
        }
    });

    $(document).on('click', '.stockInwardDeleteBtn', function() {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function(result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteStockInwardsRecord: 'deleteStockInwardsRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.status === 'success') {
                            loadStockInwardsTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

  

</script>
<?php endSection(); ?>
