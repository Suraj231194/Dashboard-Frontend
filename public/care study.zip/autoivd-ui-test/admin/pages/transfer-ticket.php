<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage transfer tickets, exports, and record details</p>
        </div>
    </div>

    <!-- Incoming Transfer Tickets widget -->
    <div id="incomingTransferTicketsWidget"
        class="mb-6 cursor-pointer overflow-hidden rounded-xl border p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md w-full md:w-1/2"
        style="border-color: color-mix(in srgb, var(--appearance-accent, #d97706) 24%, #fed7aa); background-color: color-mix(in srgb, var(--appearance-accent, #d97706) 7%, #fff7ed);"
        role="button" tabindex="0" aria-controls="incomingTransferTicketsModal">
        <div class="flex items-center justify-between gap-4">
            <div class="flex min-w-0 items-center gap-3">
                <span class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white shadow-sm"
                    style="background-color: var(--appearance-accent, #d97706);">
                    <i class="ti ti-file-invoice text-2xl"></i>
                </span>
                <div class="min-w-0">
                    <div class="flex flex-wrap items-center gap-2">
                        <h3 class="m-0 text-base font-extrabold text-slate-900">Incoming Transfer Tickets</h3>
                        <span id="incomingTransferTicketsCount"
                            class="inline-flex min-w-6 items-center justify-center rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white"
                            style="background-color: var(--appearance-accent, #d97706);">6</span>
                    </div>
                    <p class="m-0 mt-1 text-xs font-medium text-slate-600">
                        You have incoming tickets waiting. Click here to review and process.
                    </p>
                </div>
            </div>
            <i class="ti ti-chevron-right shrink-0 text-xl" style="color: var(--appearance-accent, #d97706);"></i>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="ttPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="tt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                </div>
            </div>

            <div class="border-b border-slate-200 bg-white px-6 py-3">
                <div class="flex flex-wrap items-center gap-3 w-full">
                    <div class="flex items-center gap-2">
                        <label for="fromDate" class="text-sm font-medium text-slate-700 whitespace-nowrap">From:</label>
                        <input type="date" id="fromDate" value="<?= date('Y-m-d', strtotime('-30 days')) ?>"
                            class="input-theme h-10" style="width: 160px !important;" />
                    </div>
                    <div class="flex items-center gap-2">
                        <label for="toDate" class="text-sm font-medium text-slate-700 whitespace-nowrap">To:</label>
                        <input type="date" id="toDate" value="<?= date('Y-m-d') ?>" class="input-theme h-10"
                            style="width: 160px !important;" />
                    </div>
                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="date"><span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-44 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="ticket_no"><span class="inline-flex items-center gap-1">Transfer Ticket No
                                    <i class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-column="production_plan_no">Plan No</th>
                            <th class="sortable w-44 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="fg_coa_no"><span class="inline-flex items-center gap-1">FG COA No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="code"><span class="inline-flex items-center gap-1">Code <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="batch_no"><span class="inline-flex items-center gap-1">Batch Number <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-52 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="product_description"><span class="inline-flex items-center gap-1">Product
                                    Description <i class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="w-40 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Transferred Qty</th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="status"><span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="user_name"><span class="inline-flex items-center gap-1">Created By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th
                                class="w-48 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="transferTableTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer since it's now in the top strip -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addTransferTicketModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">New Transfer Ticket</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a transfer ticket record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addTransferTicketForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="transferTicketNo"
                                    class="mb-1 block text-sm font-medium text-slate-800">Transfer Ticket Number <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="transferTicketNo" autocomplete="off" name="transferTicketNo"
                                    class="input-theme" placeholder="Enter Transfer Ticket Number" required />
                            </div>
                            <div>
                                <label for="finishedGoodCoaNo"
                                    class="mb-1 block text-sm font-medium text-slate-800">Finished Good COA No <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="finishedGoodCoaNo" autocomplete="off" name="finishedGoodCoaNo"
                                    class="input-theme" placeholder="Enter Finished Good COA No" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="code" class="mb-1 block text-sm font-medium text-slate-800">Code <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="code" autocomplete="off" name="code" class="input-theme"
                                    placeholder="Enter Code" required />
                            </div>
                            <div>
                                <label for="transferTicketDate"
                                    class="mb-1 block text-sm font-medium text-slate-800">Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="transferTicketDate" autocomplete="off" name="transferTicketDate"
                                    class="input-theme" placeholder="Enter Date" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 gap-3 mb-4">
                            <div>
                                <label for="productDescription"
                                    class="mb-1 block text-sm font-medium text-slate-800">Product Description <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="productDescription" autocomplete="off" name="productDescription"
                                    class="input-theme" placeholder="Enter Product Description" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="pack_size" class="mb-1 block text-sm font-medium text-slate-800">Pack Size
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="number" min="0" id="pack_size" autocomplete="off" name="pack_size"
                                    class="input-theme" placeholder="Enter Pack Size" required />
                            </div>
                            <div>
                                <label for="pack_size_unit" class="mb-1 block text-sm font-medium text-slate-800">Pack
                                    Size Unit <strong class="text-rose-500">*</strong></label>
                                <select name="pack_size_unit" id="pack_size_unit" class="input-theme select2" required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="productCode" class="mb-1 block text-sm font-medium text-slate-800">Product
                                    Code <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="productCode" autocomplete="off" name="productCode"
                                    class="input-theme" placeholder="Enter Product Code" required />
                            </div>
                            <div>
                                <label for="batchNumber" class="mb-1 block text-sm font-medium text-slate-800">Batch
                                    Number <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="batchNumber" autocomplete="off" name="batchNumber"
                                    class="input-theme" placeholder="Enter Batch Number" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="transferTicketMfgDate"
                                    class="mb-1 block text-sm font-medium text-slate-800">Mfg Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="transferTicketMfgDate" autocomplete="off"
                                    name="transferTicketMfgDate" class="input-theme" placeholder="Enter Mfg Date"
                                    required />
                            </div>
                            <div>
                                <label for="transferTicketExpDate"
                                    class="mb-1 block text-sm font-medium text-slate-800">Exp Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="transferTicketExpDate" autocomplete="off"
                                    name="transferTicketExpDate" class="input-theme" placeholder="Enter Exp Date"
                                    required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="sampleTakenByQa"
                                    class="mb-1 block text-sm font-medium text-slate-800">Sample Taken By QA <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="number" min="0" id="sampleTakenByQa" autocomplete="off"
                                    name="sampleTakenByQa" class="input-theme" placeholder="Enter Sample Taken By QA"
                                    required />
                            </div>
                            <div>
                                <label for="sampleTakenByQaUnit"
                                    class="mb-1 block text-sm font-medium text-slate-800">Sample Unit <strong
                                        class="text-rose-500">*</strong></label>
                                <select name="sampleTakenByQaUnit" id="sampleTakenByQaUnit" class="input-theme select2"
                                    required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="quantityTransferred"
                                    class="mb-1 block text-sm font-medium text-slate-800">Quantity Tranferred <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="number" min="0" id="quantityTransferred" autocomplete="off"
                                    name="quantityTransferred" class="input-theme"
                                    placeholder="Enter Quantity Tranferred" required />
                            </div>
                            <div>
                                <label for="quantityUnit" class="mb-1 block text-sm font-medium text-slate-800">Quantity
                                    Unit <strong class="text-rose-500">*</strong></label>
                                <select name="quantityUnit" id="quantityUnit" class="input-theme select2" required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label for="ttRemark"
                                    class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea name="ttRemark" id="ttRemark" class="input-theme min-h-[80px]"
                                    placeholder="Enter Remark"></textarea>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            type="radio" id="activStatus" name="productStatus" value="1" required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            type="radio" id="inactiveStatus" name="productStatus" value="0" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="transferTicketViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Transfer Ticket Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review transfer ticket information</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="transferTicketView">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="transferTicketEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Transfer Ticket</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update transfer ticket details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="transferTicketEditForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="transferTicketViewPdfModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-file-download text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Transfer Ticket PDF Preview
                            </h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview export content before download</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="transferTicketViewPdf">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="transferTicketExportForm" class="transfer-ticket-export-form">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Date" checked />
                                        <span class="text-sm font-medium text-slate-700">Date</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Transfer Ticket No" checked />
                                        <span class="text-sm font-medium text-slate-700">Transfer Ticket No</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="FG COA No" checked />
                                        <span class="text-sm font-medium text-slate-700">FG COA No</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Code" checked />
                                        <span class="text-sm font-medium text-slate-700">Code</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Batch Number" checked />
                                        <span class="text-sm font-medium text-slate-700">Batch Number</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product Description" checked />
                                        <span class="text-sm font-medium text-slate-700">Product Description</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product Code" checked />
                                        <span class="text-sm font-medium text-slate-700">Product Code</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Pack Size" checked />
                                        <span class="text-sm font-medium text-slate-700">Pack Size</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="MFG Date" checked />
                                        <span class="text-sm font-medium text-slate-700">MFG Date</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="EXP Date" checked />
                                        <span class="text-sm font-medium text-slate-700">EXP Date</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="QA Sampled" checked />
                                        <span class="text-sm font-medium text-slate-700">QA Sampled</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Quantity Transferred" checked />
                                        <span class="text-sm font-medium text-slate-700">Quantity Transferred</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Created By" checked />
                                        <span class="text-sm font-medium text-slate-700">Created By</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Incoming Transfer Tickets - Select COA modal -->
    <div class="modal fade" id="incomingTransferTicketsModal" tabindex="-1"
        aria-labelledby="incomingTransferTicketsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" style="max-width: 1000px;">
            <div class="modal-content overflow-hidden rounded-2xl border-0 bg-white shadow-2xl">
                <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                    <div class="flex min-w-0 items-start gap-3">
                        <span class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                            style="background-color: color-mix(in srgb, var(--appearance-accent, #d97706) 10%, white); color: var(--appearance-accent, #d97706);">
                            <i class="ti ti-file-invoice text-xl"></i>
                        </span>
                        <div>
                            <h5 id="incomingTransferTicketsModalLabel" class="modal-title m-0 text-lg font-extrabold text-slate-900">
                                Incoming Transfer Tickets - Select COA
                            </h5>
                            <p class="m-0 mt-1 text-xs font-medium text-slate-500">
                                Select a finished goods COA record to continue creating its transfer ticket.
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>

                <div class="modal-body bg-slate-50/60 px-6 py-5">
                    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white">
                        <div class="overflow-x-auto">
                            <table class="w-full border-collapse text-left">
                                <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                                    <tr>
                                        <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#</th>
                                        <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Testing Date</th>
                                        <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">F.G COA #</th>
                                        <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Product</th>
                                        <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Created By</th>
                                        <th class="px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="incomingTransferTicketsTableBody" class="divide-y divide-slate-100 bg-white"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal-footer flex-nowrap border-t border-slate-200 bg-slate-50/80 px-6 py-4">
                    <div class="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <span id="incomingTransferTicketsSummary" class="text-xs font-medium text-slate-500">
                            Showing 0 to 0 of 0 entries
                        </span>
                        <div class="flex items-center gap-1">
                            <button id="incomingTransferTicketsPrevious" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-slate-400 shadow-sm ring-1 ring-slate-200 transition-colors hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Previous page" disabled>
                                <i class="ti ti-chevron-left"></i>
                            </button>
                            <span id="incomingTransferTicketsCurrentPage"
                                class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-extrabold text-white shadow-sm"
                                style="background-color: var(--appearance-accent, #d97706);">1</span>
                            <button id="incomingTransferTicketsNext" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-slate-400 shadow-sm ring-1 ring-slate-200 transition-colors hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Next page" disabled>
                                <i class="ti ti-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        #incomingTransferTicketFormModal {
            z-index: 1070 !important;
        }

        .modal-backdrop.incoming-transfer-ticket-form-backdrop {
            z-index: 1065 !important;
        }

        #incomingTransferTicketFormModal .modal-dialog-scrollable .modal-content {
            display: flex !important;
            flex-direction: column !important;
            max-height: calc(100vh - 3.5rem) !important;
            overflow: hidden !important;
        }

        #incomingTransferTicketFormModal form {
            display: flex !important;
            flex-direction: column !important;
            flex: 1 1 auto !important;
            min-height: 0 !important;
            overflow: hidden !important;
        }

        #incomingTransferTicketFormModal .modal-body {
            flex: 1 1 auto !important;
            overflow-y: auto !important;
            min-height: 0 !important;
        }

        #incomingTransferTicketFormModal .modal-header,
        #incomingTransferTicketFormModal .modal-footer {
            flex-shrink: 0 !important;
        }
    </style>

    <!-- Nested Transfer Ticket Form modal -->
    <div class="modal fade" id="incomingTransferTicketFormModal" tabindex="-1"
        aria-labelledby="incomingTransferTicketFormModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content overflow-hidden rounded-2xl border-0 bg-white shadow-2xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4 relative">
                    <div class="flex items-center gap-4">
                        <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.5rem; height: 3.5rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                            <i class="ti ti-file-invoice" style="font-size: 1.75rem; color: var(--appearance-accent, #7e22ce);"></i>
                            <span style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                        </div>
                        <div>
                            <h5 id="incomingTransferTicketFormModalLabel" class="modal-title m-0 font-bold leading-tight" style="font-size: 1.25rem; color: var(--ui-text, #1e293b);">Transfer Ticket Form</h5>
                            <p class="m-0 mt-1 font-medium" style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">Please review and complete the transfer details below.</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none ml-auto" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-lg"></i>
                    </button>
                </div>

                <form id="incomingTransferTicketForm">
                    <input type="hidden" id="incomingTransferTicketSelectedId">
                    <input type="hidden" id="incomingTransferTicketQuantityUnitId">
                    <div class="modal-body bg-white px-6 py-5">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="incomingTransferTicketFgCoa" class="mb-1 block text-sm font-medium text-slate-800">F.G COA #</label>
                                <input id="incomingTransferTicketFgCoa" type="text" readonly class="input-theme">
                            </div>
                            <div>
                                <label for="incomingTransferTicketBatchSize" class="mb-1 block text-sm font-medium text-slate-800">Batch Size</label>
                                <input id="incomingTransferTicketBatchSize" type="text" readonly class="input-theme">
                            </div>
                            <div>
                                <label for="incomingTransferTicketBatchNumber" class="mb-1 block text-sm font-medium text-slate-800">Batch #</label>
                                <input id="incomingTransferTicketBatchNumber" type="text" readonly class="input-theme font-mono">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="incomingTransferTicketDate" class="mb-1 block text-sm font-medium text-slate-800">Date</label>
                                <input id="incomingTransferTicketDate" type="text" readonly class="input-theme">
                            </div>
                            <div>
                                <label for="incomingTransferTicketMfgDate" class="mb-1 block text-sm font-medium text-slate-800">Mfg. Date</label>
                                <input id="incomingTransferTicketMfgDate" type="date" class="input-theme">
                            </div>
                            <div>
                                <label for="incomingTransferTicketExpDate" class="mb-1 block text-sm font-medium text-slate-800">Exp. Date</label>
                                <input id="incomingTransferTicketExpDate" type="date" class="input-theme">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div class="md:col-span-2">
                                <label for="incomingTransferTicketProduct" class="mb-1 block text-sm font-medium text-slate-800">Product</label>
                                <input id="incomingTransferTicketProduct" type="text" readonly class="input-theme">
                            </div>
                            <div>
                                <label for="incomingTransferTicketQuantity" class="mb-1 block text-sm font-medium text-slate-800">Qty. Transferred</label>
                                <div class="flex">
                                    <input id="incomingTransferTicketQuantity" type="number" min="0" step="any" class="input-theme !rounded-r-none" style="flex: 1;">
                                    <span id="incomingTransferTicketQuantityUnit" class="inline-flex items-center justify-center rounded-r-xl border border-l-0 border-slate-300 bg-slate-50 px-3 text-sm font-medium text-slate-600">
                                        pcs
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 gap-3 mb-4">
                            <div>
                                <label for="incomingTransferTicketSampledBy" class="mb-1 block text-sm font-medium text-slate-800">Sample Taken By (QC)</label>
                                <select id="incomingTransferTicketSampledBy" class="input-theme select2">
                                    <option value="Atharv Srivastava">Atharv Srivastava</option>
                                    <option value="Neha Kulkarni">Neha Kulkarni</option>
                                    <option value="Rahul Sharma">Rahul Sharma</option>
                                    <option value="Priya Nair">Priya Nair</option>
                                    <option value="Amit Patil">Amit Patil</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer flex justify-end gap-3 border-t border-slate-200 bg-white px-6 py-4">
                        <button type="button" id="btnBackToTransferTicketList"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60">
                            <i class="ti ti-arrow-left text-lg mr-1"></i> Back
                        </button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl border-0 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-black/10 transition-colors hover:brightness-110 focus:outline-none focus:ring-2 focus:ring-black/20"
                            style="background-color: var(--appearance-accent, #d97706);">
                            <i class="ti ti-check text-lg"></i> Submit Ticket
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';
    let incomingTransferTicketsPage = 1;
    const incomingTransferTicketsPerPage = 5;
    let incomingTransferTicketsRecords = [];
    const transferWorkflowCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    function escapeIncomingTransferTicketText(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function loadIncomingTransferTicketWorkflow(resetPage = true, silent = false) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadIncomingTransferTicketWorkflow: 'loadIncomingTransferTicketWorkflow',
                csrf_token: transferWorkflowCsrf
            },
            success: function (response) {
                if (response.status !== 'success') {
                    if (!silent) toastr.error(response.message || 'Unable to load incoming Transfer Tickets.');
                    return;
                }
                incomingTransferTicketsRecords = response.data?.records || [];
                if (resetPage) incomingTransferTicketsPage = 1;
                renderIncomingTransferTickets();
            },
            error: function (xhr) {
                if (silent) return;
                toastr.error(xhr.responseJSON?.message || 'Unable to load incoming Transfer Tickets.');
                incomingTransferTicketsRecords = [];
                renderIncomingTransferTickets();
            }
        });
    }

    function refreshIncomingTransferTicketWorkflow() {
        if (!document.hidden) loadIncomingTransferTicketWorkflow(false, true);
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) refreshIncomingTransferTicketWorkflow();
    });

    function renderIncomingTransferTickets() {
        const totalRows = incomingTransferTicketsRecords.length;
        const totalPages = Math.max(1, Math.ceil(totalRows / incomingTransferTicketsPerPage));
        incomingTransferTicketsPage = Math.min(Math.max(1, incomingTransferTicketsPage), totalPages);
        const offset = (incomingTransferTicketsPage - 1) * incomingTransferTicketsPerPage;
        const visibleRows = incomingTransferTicketsRecords.slice(offset, offset + incomingTransferTicketsPerPage);

        if (visibleRows.length === 0) {
            $('#incomingTransferTicketsTableBody').html(`<tr>
                <td colspan="6" class="px-5 py-12 text-center text-sm font-semibold text-slate-500">
                    No incoming transfer tickets available.
                </td>
            </tr>`);
        } else {
            $('#incomingTransferTicketsTableBody').html(visibleRows.map(function (record, index) {
                return `<tr class="group transition-colors hover:bg-slate-50/50">
                    <td class="px-6 py-3 align-middle text-[13px] font-semibold text-slate-900 whitespace-nowrap">${offset + index + 1}</td>
                    <td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-600 whitespace-nowrap">${escapeIncomingTransferTicketText(record.testing_date)}</td>
                    <td class="px-6 py-3 align-middle text-[13px] font-bold font-mono text-slate-700">${escapeIncomingTransferTicketText(record.fg_coa_number)}</td>
                    <td class="px-6 py-3 align-middle text-[13px] font-bold text-slate-800 whitespace-nowrap">${escapeIncomingTransferTicketText(record.product)}</td>
                    <td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-600 whitespace-nowrap">${escapeIncomingTransferTicketText(record.created_by)}</td>
                    <td class="px-6 py-3 align-middle text-center whitespace-nowrap">
                        <button type="button"
                            class="incoming-transfer-ticket-select-coa inline-flex h-8 w-8 items-center justify-center rounded-lg text-white shadow-sm transition-opacity hover:opacity-90"
                            style="background-color: var(--appearance-accent, #d97706);"
                            data-id="${escapeIncomingTransferTicketText(record.id)}"
                            title="Select COA" aria-label="Select ${escapeIncomingTransferTicketText(record.fg_coa_number)}">
                            <i class="ti ti-chevron-right"></i>
                        </button>
                    </td>
                </tr>`;
            }).join(''));
        }

        const first = totalRows === 0 ? 0 : offset + 1;
        const last = totalRows === 0 ? 0 : Math.min(offset + incomingTransferTicketsPerPage, totalRows);
        $('#incomingTransferTicketsSummary').text(`Showing ${first} to ${last} of ${totalRows} entries`);
        $('#incomingTransferTicketsCurrentPage').text(incomingTransferTicketsPage);
        $('#incomingTransferTicketsPrevious').prop('disabled', incomingTransferTicketsPage <= 1);
        $('#incomingTransferTicketsNext').prop('disabled', incomingTransferTicketsPage >= totalPages);
        $('#incomingTransferTicketsCount').text(totalRows);
    }

    function openIncomingTransferTicketForm(button) {
        const recordId = String($(button).data('id') || '');
        const record = incomingTransferTicketsRecords.find(function (item) {
            return item.id === recordId;
        });

        if (!record) return;

        $('#incomingTransferTicketSelectedId').val(record.id);
        $('#incomingTransferTicketFgCoa').val(record.fg_coa_number);
        $('#incomingTransferTicketBatchSize').val(record.batch_size);
        $('#incomingTransferTicketBatchNumber').val(record.batch_number);
        $('#incomingTransferTicketDate').val(record.testing_date);
        $('#incomingTransferTicketMfgDate').val(record.mfg_date);
        $('#incomingTransferTicketExpDate').val(record.exp_date);
        $('#incomingTransferTicketProduct').val(record.product);
        $('#incomingTransferTicketQuantity').val(record.quantity);
        $('#incomingTransferTicketQuantityUnit').text(record.unit);
        $('#incomingTransferTicketQuantityUnitId').val(record.unit_id || '');
        const sampledBy = record.sampled_by || record.created_by || '';
        if (sampledBy) {
            if ($('#incomingTransferTicketSampledBy option[value="' + sampledBy + '"]').length === 0) {
                $('#incomingTransferTicketSampledBy').append(new Option(sampledBy, sampledBy, true, true));
            }
            $('#incomingTransferTicketSampledBy').val(sampledBy).trigger('change');
        }
        $('#incomingTransferTicketsModal').modal('hide');
        setTimeout(function() {
            $('#incomingTransferTicketFormModal').modal('show');
        }, 200);
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#pack_size_unit").html(optionsHtml).trigger('change');
                $("#sampleTakenByQaUnit").html(optionsHtml).trigger('change');
                $("#quantityUnit").html(optionsHtml).trigger('change');
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadProductCategoryList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getProductCategoryList: 'getProductCategoryList'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#productCategory").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }


    function loadTransferTicketTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#fromDate').val();
        const toDate = $('#toDate').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadTransferTicket: 'loadTransferTicket',
                page: page,
                per_page: perPage,
                search: search,
                fromDate: fromDate,
                toDate: toDate,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#transferTableTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const shownThrough = totalRows ? Math.min(page * Number(perPage), totalRows) : 0;

            },
            error: function () {
                $('#transferTableTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    $(document).ready(function () {
        loadTransferTicketTable();
        loadIncomingTransferTicketWorkflow();
        loadStandardUnit();

        $('#searchProducts').on('input', function () {
            loadTransferTicketTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadTransferTicketTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadTransferTicketTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.tt-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#ttPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        $('#fromDate').on('change', function () {
            loadTransferTicketTable(1);
        });
        $('#toDate').on('change', function () {
            loadTransferTicketTable(1);
        });

        // $('#addTransferTicketForm').on('submit', function(e) {
        //     e.preventDefault();

        //     const form = document.getElementById('addTransferTicketForm');
        //     const formData = new FormData(form);
        //     formData.append('addTransferTicket', 'addTransferTicket'); // Backend handler flag

        //     $.ajax({
        //         url: 'ajax.php',
        //         type: 'POST',
        //         data: formData,
        //         contentType: false, // Must for FormData
        //         processData: false,
        //         success: function(response) {
        //             let res;
        //             try {
        //                 res = JSON.parse(response);
        //             } catch (e) {
        //                 toastr.error('Invalid response from server.');
        //                 return;
        //             }

        //             if (res.status === 'success') {
        //                 $('#addTransferTicketModal').modal('hide');
        //                 $('#addTransferTicketForm')[0].reset();
        //                 loadTransferTicketTable();
        //                 toastr.success(res.message);
        //             } else if (res.status === 'error') {
        //                 toastr.error(res.message);
        //             } else {
        //                 toastr.error('Unexpected response.');
        //             }
        //         },
        //         error: function() {
        //             toastr.error('Server error occurred.');
        //         }
        //     });
        // });

        $('#addTransferTicketModal').on('hidden.bs.modal', function () {
            $('#addTransferTicketForm')[0].reset();
        });

        $('#addTransferTicketForm').on('submit', function (e) {
            e.preventDefault();

            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');

            const form = this;
            const formData = new FormData(form);
            formData.append('addTransferTicket', 'addTransferTicket');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $submitBtn.prop('disabled', true).text('Saving...');
                },

                success: function (res) {
                    if (res.status === 'success') {
                        $('#addTransferTicketModal').modal('hide');
                        form.reset();
                        loadTransferTicketTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).text('Save');
                }
            });
        });


        function updateColumnsSelectedText() {
            const checkedCount = $('.column-filter:checked').length;
            const totalCount = $('.column-filter').length;
            if (checkedCount === totalCount) {
                $('#columnsSelectedText').text(totalCount + ' items selected');
            } else if (checkedCount > 2) {
                $('#columnsSelectedText').text(checkedCount + ' items selected');
            } else if (checkedCount > 0) {
                let names = [];
                $('.column-filter:checked').each(function () {
                    names.push($(this).val());
                });
                $('#columnsSelectedText').text(names.join(', '));
            } else {
                $('#columnsSelectedText').text('----Select Columns----');
            }
        }

        $(document).on('change', '.column-filter', function () {
            updateColumnsSelectedText();
        });

        $(document).on('click', '#selectAllColumns', function () {
            $('.column-filter').prop('checked', true);
            updateColumnsSelectedText();
        });

        $(document).on('click', '#deselectAllColumns', function () {
            $('.column-filter').prop('checked', false);
            updateColumnsSelectedText();
        });
    });

    $(document).on('click', '.transferTicketViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#transferTicketView').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    transferTicketViewRecord: 'transferTicketViewRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#transferTicketViewModal').modal('show');
                        $('#transferTicketView').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.transfer-ticket-row', function (event) {
        if ($(event.target).closest('button, a, input, select, textarea').length) return;
        $('.transferTicketViewModalBtn[data-id="' + Number($(this).data('id') || 0) + '"]').first().trigger('click');
    });

    $(document).on('keydown', '.transfer-ticket-row', function (event) {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
    });


    $(document).on('click', '.transferTicketEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#transferTicketEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchTransferTicketRecord: 'fetchTransferTicketRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#transferTicketEditModal').modal('show');
                        $('#transferTicketEditForm').find('.modal-body').html(res.data);
                        $('#transferTicketEditForm .select2').select2({ dropdownParent: $(document.body), width: '100%' });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '.transferTicketDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'mr-3 inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteTransfetTicketRecord: 'deleteTransfetTicketRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadTransferTicketTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                            }
                        });
                    }
                });
            }
        });
    });

    $('#transferTicketEditForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('transferTicketEditForm');
        const formData = new FormData(form);
        formData.append('updateTransferTicket', 'updateTransferTicket');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#transferTicketEditModal').modal('hide');
                    $('#transferTicketEditForm').find('modal-body').html();
                    loadTransferTicketTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.previewTransferTicketPdf', function () {
        let id = $(this).data('id');
        if (id) {
            $('#transferTicketViewPdf').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    transferTicketViewPdfRecord: 'transferTicketViewPdfRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#transferTicketViewPdfModal').modal('show');
                        $('#transferTicketViewPdf').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfTransferTicketDownloadBtn', function (e) {
        e.preventDefault();
        e.stopPropagation();
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/transfer_ticket_template.php?id=" + encodeURIComponent(id) + "&triggerDownload=1";
            const link = document.createElement('a');
            link.href = url;
            link.target = '_blank';
            link.download = '';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            toastr.success('Transfer ticket PDF is being downloaded.');
        }
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        if (currentSortDirection === 'ASC') {
            $(this).addClass('asc');
        } else {
            $(this).addClass('desc');
        }
        loadTransferTicketTable(1);
    });

    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $('#transferTicketExportForm').on('submit', function (e) {
        e.preventDefault();
        page = 1;
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#fromDate').val();
        const toDate = $('#toDate').val();

        if (!$('#exportTypeSelect').val()) {
            toastr.error('Please select an export type.');
            return;
        }

        const form = document.getElementById('transferTicketExportForm');
        const formData = new FormData(form);
        formData.append('exportTransferTicketManual', 'exportTransferTicketManual');
        formData.append('search', search);
        formData.append('perPage', perPage);
        formData.append('page', page);
        formData.append('fromDate', fromDate);
        formData.append('toDate', toDate);
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortDirection);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');

        $.ajax({
            url: 'exportajax.php', // Change to your handler script
            type: 'POST',
            data: formData,
            contentType: false, // Must for FormData
            processData: false,
            dataType: 'json',
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.export-type-item', function () {
        const val = $(this).data('val');
        $('#exportTypeText').text($(this).text());
        $('#exportTypeSelect').val(val);
    });

    $(document).on('click', '#deselectAllColumnsBtn', function() {
        const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
        if (isAllSelected) {
            $('.column-filter').prop('checked', false);
            $(this).text('Select All');
        } else {
            $('.column-filter').prop('checked', true);
            $(this).text('Deselect All');
        }
    });

    $(document).on('change', '.column-filter', function() {
        const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
        if (isAllSelected) {
            $('#deselectAllColumnsBtn').text('Deselect All');
        } else {
            $('#deselectAllColumnsBtn').text('Select All');
        }
    });

    $(document).on('select2:open', function(e) {
        const $modal = $(e.target).closest('.modal');
        if (!$modal.length) return;
        bindModalSelect2Scroll('#' + $modal.attr('id'));
    });

    $('#addTransferTicketModal .modal-body, #transferTicketEditModal .modal-body').on('scroll', function() {
        $(this).closest('.modal').find('select.select2-hidden-accessible').select2('close');
    });

    function bindModalSelect2Scroll(modalSelector) {
        setTimeout(function() {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.myModalScroll')
                .on('wheel.myModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $(modalSelector + ' .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $(modalSelector + ' select.select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    $(document).on('click keydown', '#incomingTransferTicketsWidget', function (event) {
        if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
        if (event.type === 'keydown') event.preventDefault();
        incomingTransferTicketsPage = 1;
        renderIncomingTransferTickets();
        $('#incomingTransferTicketsModal').modal('show');
    });

    $(document).on('click', '#incomingTransferTicketsPrevious', function () {
        if (incomingTransferTicketsPage > 1) {
            incomingTransferTicketsPage--;
            renderIncomingTransferTickets();
        }
    });

    $(document).on('click', '#incomingTransferTicketsNext', function () {
        incomingTransferTicketsPage++;
        renderIncomingTransferTickets();
    });

    $(document).on('click', '.incoming-transfer-ticket-select-coa', function () {
        openIncomingTransferTicketForm(this);
    });

    $(document).on('click', '#btnBackToTransferTicketList', function () {
        $('#incomingTransferTicketFormModal').modal('hide');
        setTimeout(function() {
            $('#incomingTransferTicketsModal').modal('show');
        }, 200);
    });

    $(document).on('shown.bs.modal', '#incomingTransferTicketFormModal', function () {
        $('.modal-backdrop').last().addClass('incoming-transfer-ticket-form-backdrop');
    });

    $(document).on('hidden.bs.modal', '#incomingTransferTicketFormModal', function () {
        $('.modal-backdrop.incoming-transfer-ticket-form-backdrop').removeClass('incoming-transfer-ticket-form-backdrop');
        if ($('#incomingTransferTicketsModal').hasClass('show')) {
            $('body').addClass('modal-open');
        }
    });

    $(document).on('submit', '#incomingTransferTicketForm', function (event) {
        event.preventDefault();
        const formData = new FormData();
        formData.append('createTransferTicketFromFg', 'createTransferTicketFromFg');
        formData.append('csrf_token', transferWorkflowCsrf);
        formData.append('source_fg_coa_id', $('#incomingTransferTicketSelectedId').val());
        formData.append('mfg_date', $('#incomingTransferTicketMfgDate').val());
        formData.append('exp_date', $('#incomingTransferTicketExpDate').val());
        formData.append('sampled_by', $('#incomingTransferTicketSampledBy').val());
        formData.append('quantity', $('#incomingTransferTicketQuantity').val());

        const $submitButton = $(this).find('button[type="submit"]');
        const originalHtml = $submitButton.html();
        $submitButton.prop('disabled', true)
            .html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    $('#incomingTransferTicketFormModal').modal('hide');
                    toastr.success(response.message);
                    loadIncomingTransferTicketWorkflow();
                    loadTransferTicketTable();
                } else {
                    toastr.error(response.message || 'Unable to create the Transfer Ticket.');
                }
            },
            error: function (xhr) {
                toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
            },
            complete: function () {
                $submitButton.prop('disabled', false).html(originalHtml);
            }
        });
    });

</script>
<?php endSection(); ?>
