<?php
$companyProfileCanAdd = roleHasPermission((int) ($_SESSION['role_id'] ?? 0), 'company_add');
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 ui-page-title-banner">
        <h1 class="text-3xl font-bold mb-2" style="font-family: 'Sora', 'Manrope', sans-serif; color: var(--appearance-accent, #1e293b);">Company Directory</h1>
        <p class="text-slate-500 text-sm max-w-2xl font-medium">Manage your registered entities and track their onboarding status across the global Biogenix network.</p>
    </div>

    <!-- Stats -->
    <div class="flex flex-col sm:flex-row gap-4 mb-6">
        <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-4 min-w-[240px] shadow-sm">
            <div class="w-12 h-12 rounded-xl flex items-center justify-center shadow-sm" style="background-color: var(--color-primary-50, #f1f5f9); color: var(--appearance-accent, #1e293b);">
                <i class="ti ti-building text-xl"></i>
            </div>
            <div>
                <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5">TOTAL COMPANIES</p>
                <h3 id="companyProfileTotal" class="text-2xl font-extrabold m-0 leading-none" style="color: var(--appearance-accent, #1e293b);">0</h3>
            </div>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-4 min-w-[240px] shadow-sm">
            <div class="w-12 h-12 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center shadow-sm">
                <i class="ti ti-folder-off text-xl"></i>
            </div>
            <div>
                <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5">INACTIVE COMPANIES</p>
                <h3 id="companyProfileInactive" class="text-2xl font-extrabold text-rose-600 m-0 leading-none">0</h3>
            </div>
        </div>
    </div>

    <!-- Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-6">
        <div id="companyProfileCards" class="contents">
            <div class="col-span-full py-12 text-center text-sm font-semibold text-slate-500">
                <div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div>
            </div>
        </div>

        <!-- Register New Entity -->
        <?php if ($companyProfileCanAdd): ?>
        <div class="border-[1.5px] border-dashed border-slate-300 bg-slate-50/50 hover:border-indigo-300 hover:bg-indigo-50/30 rounded-2xl p-5 flex flex-col items-center justify-center text-center cursor-pointer transition-colors relative min-h-[220px] group" data-bs-toggle="modal" data-bs-target="#companyAddModal">
            <div class="w-12 h-12 bg-[#eef2ff] rounded-full flex items-center justify-center text-indigo-500 mb-4 group-hover:scale-110 transition-transform shadow-sm">
                <i class="ti ti-building-store text-xl"></i>
            </div>
            <h4 class="text-base font-bold text-slate-800 m-0 mb-1">Register New Entity</h4>
            <p class="text-xs font-medium text-slate-500 max-w-[200px]">Start the onboarding process for a new subsidiary or branch.</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <div class="flex items-center justify-between pt-2 pb-6">
        <span id="companyProfileSummary" class="text-sm font-medium text-slate-500">Loading companies...</span>
        <div id="companyProfilePagination" class="flex items-center gap-2"></div>
    </div>

    <!-- Wizard CSS -->
    <style>
    .wizard-step { display: none; }
    .wizard-step.active { display: block; }
    .upload-box { border: 1px dashed var(--slate-300, #cbd5e1); border-radius: 0.5rem; padding: 1rem; text-align: center; cursor: pointer; transition: all 0.2s; background: #f8fafc; }
    .upload-box:hover { border-color: var(--appearance-accent, #1e293b); background: #f1f5f9; }
    .upload-card { border: 1px solid var(--slate-200, #e2e8f0); border-radius: 0.5rem; padding: 0.75rem; display: flex; align-items: center; gap: 0.75rem; background: #f8fafc; }
    .upload-icon { background: var(--slate-200, #e2e8f0); border-radius: 0.25rem; padding: 0.5rem; }
    .radio-card { border: 1px solid var(--slate-200, #e2e8f0); border-radius: 0.5rem; padding: 1rem; cursor: pointer; transition: all 0.2s; display: flex; align-items: flex-start; gap: 1rem; }
    .radio-card.selected { border-color: var(--appearance-accent, #1e293b); background: var(--color-primary-50, #f1f5f9); }
    .counter-box { display: flex; align-items: center; border: 1px solid var(--slate-200, #e2e8f0); border-radius: 0.5rem; overflow: hidden; }
    .counter-btn { background: #f8fafc; border: none; padding: 0.5rem 0.75rem; cursor: pointer; color: var(--slate-600); }
    .counter-btn:hover { background: #e2e8f0; }
    .counter-input { width: 40px; text-align: center; border: none; border-left: 1px solid var(--slate-200); border-right: 1px solid var(--slate-200); font-weight: 600; padding: 0.5rem; outline: none; }
    .company-profile-dialog { width: calc(100% - 1rem); max-width: 960px; margin: 0.5rem auto; }
    .company-wizard-heading { gap: 0.75rem; flex-wrap: wrap; }
    .company-wizard-stepper > div { min-width: 0; }
    .location-card { min-width: 0; border: 1px solid var(--slate-200, #e2e8f0); border-radius: 0.75rem; overflow: hidden; background: #fff; }
    .location-card-header { padding: 1rem; border-bottom: 1px solid var(--slate-200); display: flex; align-items: center; justify-content: space-between; border-left: 4px solid var(--appearance-accent, #1e293b); }
    .location-card-body { padding: 1rem; }
    .company-review-success-icon { width: 5rem; height: 5rem; }
    #companyAddModal .form-check-input:checked { background-color: var(--appearance-accent, #1e293b); border-color: var(--appearance-accent, #1e293b); }
    @media (max-width: 639.98px) {
        .company-profile-dialog .modal-content { max-height: calc(100vh - 1rem); }
        .company-profile-dialog .modal-body { padding-left: 1rem !important; padding-right: 1rem !important; }
        .company-wizard-stepper { gap: 0.25rem; font-size: 0.625rem; }
        .company-wizard-stepper > div { justify-content: center; text-align: center; }
        .location-card-header { align-items: flex-start; flex-wrap: wrap; gap: 0.75rem; }
        .location-card-header > .flex:first-child { flex: 1 1 12rem; }
        .location-card-header > .flex:last-child { margin-left: auto; }
    }
    </style>

    <!-- Company Add Wizard Modal -->
    <div class="modal fade animate__animated fadeIn" id="companyAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered company-profile-dialog" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <form id="addCompanyForm">
                    <input type="hidden" name="companyProfileId" id="companyProfileId">
                    
                    <!-- Step 1: Company Profile -->
                    <div class="wizard-step active" id="step1">
                        <div class="flex flex-col items-start justify-center border-b border-slate-200 bg-white px-6 py-4 relative rounded-t-xl">
                            <button type="button" class="absolute text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 w-8 h-8 rounded-full flex items-center justify-center transition-colors z-10" style="top: 1rem; right: 1rem;" data-bs-dismiss="modal"><i class="ti ti-x text-lg"></i></button>
                            <div class="company-wizard-heading w-full flex justify-between items-end mb-2">
                                <div>
                                    <p class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Step 1 of 4</p>
                                    <h4 class="m-0 text-2xl font-bold" style="color: var(--appearance-accent, #1e293b);">Company Profile</h4>
                                </div>
                                <div class="text-sm font-bold text-slate-600">25% Complete</div>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                                <div class="h-1.5 rounded-full" style="width: 25%; background-color: var(--appearance-accent, #1e293b);"></div>
                            </div>
                        </div>
                        <div class="modal-body bg-slate-50/50 !px-6 !py-5" style="max-height: calc(90vh - 200px); overflow-y: auto;">
                            <!-- Core Identity & Contact -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                                    <h6 class="font-bold flex items-center gap-2 mb-4 text-slate-800"><i class="ti ti-id-badge text-xl"></i> Core Identity</h6>
                                    <div class="mb-4">
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Company Legal Name</label>
                                        <input type="text" name="legalName" class="form-control input-theme bg-slate-50" placeholder="Biogenix Life Sciences Pvt Ltd" required>
                                    </div>
                                    <div class="grid grid-cols-2 gap-3">
                                        <div>
                                            <label class="mb-1 block text-xs font-bold text-slate-600">Brand/Trade Name</label>
                                            <input type="text" name="companyName" class="form-control input-theme bg-slate-50" placeholder="Biogenix" required>
                                        </div>
                                        <div>
                                            <label class="mb-1 block text-xs font-bold text-slate-600">Company Type</label>
                                            <select name="companyType" class="form-select input-theme bg-slate-50" required>
                                                <option value="">Select company type</option>
                                                <option value="Private Limited">Private Limited</option>
                                                <option value="Public Limited">Public Limited</option>
                                                <option value="Partnership">Partnership</option>
                                                <option value="Limited Liability Partnership">Limited Liability Partnership</option>
                                                <option value="Proprietorship">Proprietorship</option>
                                                <option value="Subsidiary">Subsidiary</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Industry</label>
                                        <input type="text" name="industry" class="form-control input-theme bg-slate-50" placeholder="e.g. Diagnostics, Biotechnology" required>
                                    </div>
                                </div>
                                <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                                    <h6 class="font-bold flex items-center gap-2 mb-4 text-slate-800"><i class="ti ti-address-book text-xl"></i> Contact Details</h6>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div class="min-w-0">
                                            <div class="mb-1 flex items-center justify-between">
                                                <label class="block text-xs font-bold text-slate-600">Email Address(es)</label>
                                                <button type="button" id="addCompanyEmail" class="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50" title="Add email"><i class="ti ti-plus"></i></button>
                                            </div>
                                            <div id="companyEmailFields" class="space-y-2"></div>
                                        </div>
                                        <div class="min-w-0">
                                            <div class="mb-1 flex items-center justify-between">
                                                <label class="block text-xs font-bold text-slate-600">Contact Number(s)</label>
                                                <button type="button" id="addCompanyPhone" class="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50" title="Add contact number"><i class="ti ti-plus"></i></button>
                                            </div>
                                            <div id="companyPhoneFields" class="space-y-2"></div>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                                        <div>
                                            <label class="mb-1 block text-xs font-bold text-slate-600">Website</label>
                                            <input type="url" name="website" class="form-control input-theme bg-slate-50" placeholder="https://www.example.com">
                                        </div>
                                        <div>
                                            <label class="mb-1 block text-xs font-bold text-slate-600">Company Status</label>
                                            <select name="profileStatus" class="form-select input-theme bg-slate-50">
                                                <option value="1">Active</option>
                                                <option value="2">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                            <!-- Statutory Documents -->
                            <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm mb-6">
                                <h6 class="font-bold flex items-center gap-2 mb-4 text-slate-800"><i class="ti ti-shield-check text-xl"></i> Statutory Documents</h6>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">CIN Certificate</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="cinCertificate" class="company-file-input hidden" accept=".pdf,.png,.jpg,.jpeg" data-document-type="cin_certificate">
                                            <i class="ti ti-upload mr-1"></i><span class="company-file-label" data-document-type="cin_certificate">Upload CIN</span>
                                        </label>
                                        <input type="text" name="cinNumber" class="form-control input-theme bg-slate-50 mt-2" placeholder="CIN number">
                                    </div>
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">GST Certificate</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="gstCertificate" class="company-file-input hidden" accept=".pdf,.png,.jpg,.jpeg" data-document-type="gst_certificate">
                                            <i class="ti ti-upload mr-1"></i><span class="company-file-label" data-document-type="gst_certificate">Upload GST</span>
                                        </label>
                                        <input type="text" name="gstNumber" class="form-control input-theme bg-slate-50 mt-2" placeholder="GST number">
                                    </div>
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Udyam Registration</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="udyamCertificate" class="company-file-input hidden" accept=".pdf,.png,.jpg,.jpeg" data-document-type="udyam_certificate">
                                            <i class="ti ti-upload mr-1"></i><span class="company-file-label" data-document-type="udyam_certificate">Upload Udyam</span>
                                        </label>
                                        <input type="text" name="udyamNumber" class="form-control input-theme bg-slate-50 mt-2" placeholder="Udyam number">
                                    </div>
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Manufacturing License</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="manufacturingLicense" class="company-file-input hidden" accept=".pdf,.png,.jpg,.jpeg" data-document-type="manufacturing_license">
                                            <i class="ti ti-upload mr-1"></i><span class="company-file-label" data-document-type="manufacturing_license">Upload License</span>
                                        </label>
                                        <input type="text" name="manufacturingLicenseNumber" class="form-control input-theme bg-slate-50 mt-2" placeholder="License number">
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Company Logo</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="companyLogo" class="company-file-input hidden" accept=".png,.jpg,.jpeg" data-document-type="logo">
                                            <i class="ti ti-photo mr-1"></i><span class="company-file-label" data-document-type="logo">Upload Logo</span>
                                        </label>
                                    </div>
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Letterhead Header</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="letterheadHeader" class="company-file-input hidden" accept=".png,.jpg,.jpeg" data-document-type="letterhead_header">
                                            <i class="ti ti-layout-navbar mr-1"></i><span class="company-file-label" data-document-type="letterhead_header">Upload Header</span>
                                        </label>
                                    </div>
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Letterhead Logo</label>
                                        <label class="upload-box block text-sm font-medium text-slate-600">
                                            <input type="file" name="letterheadLogo" class="company-file-input hidden" accept=".png,.jpg,.jpeg" data-document-type="letterhead_logo">
                                            <i class="ti ti-letter-l mr-1"></i><span class="company-file-label" data-document-type="letterhead_logo">Upload Letterhead Logo</span>
                                        </label>
                                    </div>
                                    <div class="grid grid-cols-2 gap-2">
                                        <div>
                                            <label class="mb-1 block text-xs font-bold text-slate-600">Stamp</label>
                                            <label class="upload-box block text-xs font-medium text-slate-600">
                                                <input type="file" name="companyStamp" class="company-file-input hidden" accept=".png,.jpg,.jpeg" data-document-type="stamp">
                                                <i class="ti ti-rubber-stamp"></i><span class="company-file-label block mt-1" data-document-type="stamp">Upload</span>
                                            </label>
                                        </div>
                                        <div>
                                            <label class="mb-1 block text-xs font-bold text-slate-600">Signature</label>
                                            <label class="upload-box block text-xs font-medium text-slate-600">
                                                <input type="file" name="digitalSignature" class="company-file-input hidden" accept=".png,.jpg,.jpeg" data-document-type="digital_signature">
                                                <i class="ti ti-signature"></i><span class="company-file-label block mt-1" data-document-type="digital_signature">Upload</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                            <!-- Facility Addresses -->
                            <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                                <h6 class="font-bold flex items-center gap-2 mb-4 text-slate-800"><i class="ti ti-map-pin text-xl"></i> Facility Addresses</h6>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                    <div class="min-w-0">
                                        <div class="mb-1 flex items-center justify-between">
                                            <label class="block text-xs font-bold text-slate-600">Registered Office Address(es)</label>
                                            <button type="button" id="addRegisteredAddress" class="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50" title="Add registered address"><i class="ti ti-plus"></i></button>
                                        </div>
                                        <div id="registeredAddressFields" class="space-y-2"></div>
                                    </div>
                                    <div>
                                        <label class="mb-1 block text-xs font-bold text-slate-600">Main Factory Address</label>
                                        <textarea name="factoryAddress" class="form-control input-theme bg-slate-50" rows="3" placeholder="Enter the main factory address" required></textarea>
                                    </div>
                                    <div class="flex flex-col">
                                        <label class="mb-1 block text-xs font-bold text-slate-600">&nbsp;</label>
                                        <div class="bg-slate-50 border border-slate-200 rounded-lg p-3 flex justify-between items-center h-full">
                                            <div class="pr-2">
                                                <div class="text-xs font-bold text-slate-700 leading-tight mb-1">Warehouse is same as factory</div>
                                                <div class="text-[10px] text-slate-500 leading-tight">Toggle if you use the same facility</div>
                                            </div>
                                            <div class="form-check form-switch m-0 shrink-0">
                                                <input class="form-check-input" type="checkbox" name="warehouseSameAsFactory" id="warehouseSameAsFactory" value="1" checked style="background-color: var(--appearance-accent, #1e293b); border-color: var(--appearance-accent, #1e293b);">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="warehouseAddressField" class="hidden">
                                    <label class="mb-1 block text-xs font-bold text-slate-600">Warehouse Address</label>
                                    <textarea name="warehouseAddress" class="form-control input-theme bg-slate-50" rows="2" placeholder="Enter the warehouse address"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-between items-center border-t border-slate-200 bg-white px-6 py-4">
                            <button type="button" class="text-sm font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1" data-bs-dismiss="modal"><i class="ti ti-arrow-left"></i> Cancel</button>
                            <button type="button" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl px-6 text-sm font-bold text-white shadow-sm ring-1 transition-colors hover:opacity-90 next-step" style="background-color: var(--appearance-accent, #1e293b);">
                                Continue to Step 2 <i class="ti ti-arrow-right text-lg"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Step 2: Multi-Location Setup -->
                    <div class="wizard-step" id="step2">
                        <div class="flex flex-col items-start justify-center border-b border-slate-200 bg-white px-6 py-4 relative rounded-t-xl">
                            <button type="button" class="absolute text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 w-8 h-8 rounded-full flex items-center justify-center transition-colors z-10" style="top: 1rem; right: 1rem;" data-bs-dismiss="modal"><i class="ti ti-x text-lg"></i></button>
                            <div class="company-wizard-heading w-full flex justify-between items-end mb-2">
                                <div>
                                    <h4 class="m-0 text-2xl font-bold" style="color: var(--appearance-accent, #1e293b);">Step 2 of 4: Multi-Location Setup</h4>
                                </div>
                                <div class="text-sm font-bold text-slate-600">50% Complete</div>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                                <div class="h-1.5 rounded-full" style="width: 50%; background-color: var(--appearance-accent, #1e293b);"></div>
                            </div>
                        </div>
                        <div class="modal-body bg-slate-50/50 !px-6 !py-5" style="max-height: calc(90vh - 200px); overflow-y: auto;">
                            <h6 class="font-bold text-slate-800 mb-3">Does your company operate across multiple offices, plants, or facilities?</h6>
                            <div class="grid grid-cols-2 gap-4 mb-8" id="multiLocationOptions">
                                <label class="radio-card" id="cardNo" data-multi-location="0">
                                    <input type="radio" name="multiLocation" value="0" id="radioNo" class="mt-1" style="accent-color: var(--appearance-accent, #1e293b);">
                                    <div>
                                        <div class="font-bold text-sm text-slate-800">No</div>
                                        <div class="text-xs text-slate-500 mt-1">We operate from a single, centralized site.</div>
                                    </div>
                                </label>
                                <label class="radio-card selected" id="cardYes" data-multi-location="1">
                                    <input type="radio" name="multiLocation" value="1" id="radioYes" class="mt-1" checked style="accent-color: var(--appearance-accent, #1e293b);">
                                    <div>
                                        <div class="font-bold text-sm text-slate-800">Yes</div>
                                        <div class="text-xs text-slate-500 mt-1">We have multiple regional or functional sites.</div>
                                    </div>
                                </label>
                            </div>

                            <div id="facilitiesCounterSection">
                                <h6 class="font-bold text-slate-800 mb-1">How many of each facility type do you currently operate?</h6>
                                <p class="text-xs text-slate-500 mb-4">Adjust the counts below for each active site category.</p>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
                                <div class="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-[#eef2ff] text-indigo-600 flex items-center justify-center"><i class="ti ti-building"></i></div>
                                        <span class="text-sm font-bold text-slate-700">Head / Regional Office(s)</span>
                                    </div>
                                    <div class="counter-box">
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="-1">-</button>
                                        <input type="text" name="locationCounts[head_office]" class="counter-input location-count" data-location-type="head_office" value="1" readonly>
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="1">+</button>
                                    </div>
                                </div>
                                <div class="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-orange-50 text-orange-600 flex items-center justify-center"><i class="ti ti-building-factory"></i></div>
                                        <span class="text-sm font-bold text-slate-700">Manufacturing Unit</span>
                                    </div>
                                    <div class="counter-box">
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="-1">-</button>
                                        <input type="text" name="locationCounts[manufacturing_unit]" class="counter-input location-count" data-location-type="manufacturing_unit" value="0" readonly>
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="1">+</button>
                                    </div>
                                </div>
                                <div class="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-emerald-50 text-emerald-600 flex items-center justify-center"><i class="ti ti-building-warehouse"></i></div>
                                        <span class="text-sm font-bold text-slate-700">Warehouse</span>
                                    </div>
                                    <div class="counter-box">
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="-1">-</button>
                                        <input type="text" name="locationCounts[warehouse]" class="counter-input location-count" data-location-type="warehouse" value="0" readonly>
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="1">+</button>
                                    </div>
                                </div>
                                <div class="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-cyan-50 text-cyan-600 flex items-center justify-center"><i class="ti ti-flask"></i></div>
                                        <span class="text-sm font-bold text-slate-700">QA / QC Lab</span>
                                    </div>
                                    <div class="counter-box">
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="-1">-</button>
                                        <input type="text" name="locationCounts[qa_qc_lab]" class="counter-input location-count" data-location-type="qa_qc_lab" value="0" readonly>
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="1">+</button>
                                    </div>
                                </div>
                                <div class="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-violet-50 text-violet-600 flex items-center justify-center"><i class="ti ti-building-community"></i></div>
                                        <span class="text-sm font-bold text-slate-700">Office</span>
                                    </div>
                                    <div class="counter-box">
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="-1">-</button>
                                        <input type="text" name="locationCounts[office]" class="counter-input location-count" data-location-type="office" value="0" readonly>
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="1">+</button>
                                    </div>
                                </div>
                                <div class="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center shadow-sm">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-amber-50 text-amber-600 flex items-center justify-center"><i class="ti ti-tools"></i></div>
                                        <span class="text-sm font-bold text-slate-700">Service Center</span>
                                    </div>
                                    <div class="counter-box">
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="-1">-</button>
                                        <input type="text" name="locationCounts[service_center]" class="counter-input location-count" data-location-type="service_center" value="0" readonly>
                                        <button type="button" class="counter-btn location-counter-btn" data-delta="1">+</button>
                                    </div>
                                </div>
                                </div>

                                <div class="bg-[#f8fafc] border border-slate-200 rounded-xl p-4 flex gap-4 items-start max-w-xl">
                                    <div class="w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-white mt-1" style="background-color: var(--appearance-accent, #1e293b);"><i class="ti ti-info-circle"></i></div>
                                    <div>
                                        <div class="text-xs font-bold text-slate-800 mb-1">Why define locations?</div>
                                        <div class="text-xs text-slate-600">Defining location types allows the ERP to automatically assign compliance checklists and asset maintenance schedules specific to each site's function.</div>
                                    </div>
                                </div>
                            </div>
    
                        </div>
                        <div class="flex justify-between items-center border-t border-slate-200 bg-white px-6 py-4">
                            <button type="button" class="text-sm font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 prev-step"><i class="ti ti-arrow-left"></i> Back</button>
                            <button type="button" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl px-6 text-sm font-bold text-white shadow-sm ring-1 transition-colors hover:opacity-90 next-step" style="background-color: var(--appearance-accent, #1e293b);">
                                Continue to Step 3 <i class="ti ti-arrow-right text-lg"></i>
                            </button>
                        </div>
                    </div>
    
                    <!-- Step 3: Location Details -->
                    <div class="wizard-step" id="step3">
                        <div class="flex flex-col items-start justify-center border-b border-slate-200 bg-white px-6 py-4 relative rounded-t-xl">
                            <button type="button" class="absolute text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 w-8 h-8 rounded-full flex items-center justify-center transition-colors z-10" style="top: 1rem; right: 1rem;" data-bs-dismiss="modal"><i class="ti ti-x text-lg"></i></button>
                            
                            <!-- Top stepper -->
                            <div class="company-wizard-stepper w-full flex justify-between items-center mb-4 text-xs font-bold text-slate-400 pr-12">
                                <div class="flex items-center gap-1 text-slate-800"><i class="ti ti-circle-check text-emerald-600"></i> Company</div>
                                <div class="flex items-center gap-1 text-slate-800"><i class="ti ti-circle-check text-emerald-600"></i> Types</div>
                                <div class="flex items-center gap-1" style="color: var(--appearance-accent, #1e293b);"><div class="w-4 h-4 rounded-full flex items-center justify-center text-[10px] text-white" style="background-color: var(--appearance-accent, #1e293b);">3</div> Locations</div>
                                <div class="flex items-center gap-1"><div class="w-4 h-4 rounded-full border border-slate-300 flex items-center justify-center text-[10px]">4</div> Review</div>
                            </div>
    
                            <div class="company-wizard-heading w-full flex justify-between items-end mb-2">
                                <div>
                                    <h4 class="m-0 text-2xl font-bold" style="color: var(--appearance-accent, #1e293b);">Configure Your Locations</h4>
                                    <p class="text-xs text-slate-500 m-0 mt-1">Provide specific operational details for each facility. These details are essential for localized compliance and logistics.</p>
                                </div>
                                <div class="text-sm font-bold text-slate-600 whitespace-nowrap">75% Complete</div>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                                <div class="h-1.5 rounded-full" style="width: 75%; background-color: var(--appearance-accent, #1e293b);"></div>
                            </div>
                        </div>
                        <div class="modal-body bg-slate-50/50 !px-6 !py-5" style="max-height: calc(90vh - 200px); overflow-y: auto;">
                            
                            <div id="locationFormsContainer" class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6"></div>
    
                            <!-- Add Another Location -->
                            <button type="button" id="addAnotherCompanyLocation" class="w-full border border-dashed border-slate-300 rounded-xl p-6 text-center cursor-pointer hover:bg-slate-100 transition-colors">
                                <i class="ti ti-map-pin-plus text-2xl text-slate-500 mb-2"></i>
                                <div class="text-sm font-bold text-slate-800">Add Another Location</div>
                                <div class="text-xs text-slate-500">Choose a facility type and add another site</div>
                            </button>
    
                        </div>
                        <div class="flex justify-between items-center border-t border-slate-200 bg-white px-6 py-4">
                            <button type="button" class="text-sm font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 prev-step"><i class="ti ti-arrow-left"></i> Back</button>
                            <button type="button" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl px-6 text-sm font-bold text-white shadow-sm ring-1 transition-colors hover:opacity-90 next-step" style="background-color: var(--appearance-accent, #1e293b);">
                                Continue to Step 4 <i class="ti ti-arrow-right text-lg"></i>
                            </button>
                        </div>
                    </div>
    
                    <!-- Step 4: Review & Submit -->
                    <div class="wizard-step" id="step4">
                        <div class="flex flex-col items-start justify-center border-b border-slate-200 bg-white px-6 py-4 relative rounded-t-xl">
                            <button type="button" class="absolute text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 w-8 h-8 rounded-full flex items-center justify-center transition-colors z-10" style="top: 1rem; right: 1rem;" data-bs-dismiss="modal"><i class="ti ti-x text-lg"></i></button>
                            
                            <div class="company-wizard-stepper w-full flex justify-between items-center mb-4 text-xs font-bold text-slate-400 pr-12">
                                <div class="flex items-center gap-1 text-slate-800"><i class="ti ti-circle-check text-emerald-600"></i> Company</div>
                                <div class="flex items-center gap-1 text-slate-800"><i class="ti ti-circle-check text-emerald-600"></i> Types</div>
                                <div class="flex items-center gap-1 text-slate-800"><i class="ti ti-circle-check text-emerald-600"></i> Locations</div>
                                <div class="flex items-center gap-1" style="color: var(--appearance-accent, #1e293b);"><div class="w-4 h-4 rounded-full flex items-center justify-center text-[10px] text-white" style="background-color: var(--appearance-accent, #1e293b);">4</div> Review</div>
                            </div>
    
                            <div class="company-wizard-heading w-full flex justify-between items-end mb-2">
                                <div>
                                    <h4 class="m-0 text-2xl font-bold" style="color: var(--appearance-accent, #1e293b);">Review & Complete</h4>
                                    <p class="text-xs text-slate-500 m-0 mt-1">Review the provided details before finalizing the entity registration.</p>
                                </div>
                                <div class="text-sm font-bold text-emerald-600 whitespace-nowrap">100% Ready</div>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                                <div class="h-1.5 rounded-full" style="width: 100%; background-color: var(--appearance-accent, #1e293b);"></div>
                            </div>
                        </div>
                        <div class="modal-body bg-slate-50/50 !px-6 !py-8" style="max-height: calc(90vh - 200px); overflow-y: auto;">
                            <div class="company-review-success-icon shrink-0 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-4">
                                <i class="ti ti-check text-4xl"></i>
                            </div>
                            <h4 id="companyReviewTitle" class="text-xl font-bold text-slate-800 mb-2 text-center">Review Company Registration</h4>
                            <p id="companyReviewSummary" class="text-slate-500 max-w-2xl mx-auto text-center mb-5"></p>
                            <div id="companyReviewDetails" class="grid grid-cols-1 md:grid-cols-2 gap-3 text-left"></div>
                        </div>
                        <div class="flex justify-between items-center border-t border-slate-200 bg-white px-6 py-4">
                            <button type="button" class="text-sm font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 prev-step"><i class="ti ti-arrow-left"></i> Back</button>
                            <button type="submit" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl px-6 text-sm font-bold text-white shadow-sm ring-1 transition-colors hover:opacity-90" style="background-color: var(--appearance-accent, #1e293b);">
                                <i class="ti ti-device-floppy text-lg"></i> Submit Registration
                            </button>
                        </div>
                    </div>
    
                </form>
            </div>
        </div>
    </div>
<?php startSection('scripts'); ?>
<script src="<?php echo asset('assets/js/company-profile-setup.js'); ?>"></script>
<?php endSection(); ?>
