<?php
global $conn;
$piProductCatalog = getPiProductCatalog($conn);
?>
<style>
/* Select2 styling in Add/Edit PI modals */
#addProformaInvoiceModal .select2-container--default .select2-selection--single,
#editProformaInvoiceModel .select2-container--default .select2-selection--single {
    height: 2.25rem !important;
    border-radius: 0.75rem !important;
    border: 1px solid #e2e8f0 !important;
    background-color: #ffffff !important;
    padding: 0.25rem 0.5rem !important;
    display: flex !important;
    align-items: center !important;
    transition: all 0.15s ease-in-out !important;
}
#addProformaInvoiceModal .select2-container--default .select2-selection--single .select2-selection__rendered,
#editProformaInvoiceModel .select2-container--default .select2-selection--single .select2-selection__rendered {
    color: #334155 !important;
    font-size: 0.875rem !important;
    font-weight: 500 !important;
    line-height: 1.5rem !important;
    padding-left: 0.25rem !important;
    padding-right: 1.5rem !important;
}
#addProformaInvoiceModal .select2-container--default .select2-selection--single .select2-selection__arrow,
#editProformaInvoiceModel .select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 2.25rem !important;
    right: 0.5rem !important;
}
#addProformaInvoiceModal .select2-container--default.select2-container--focus .select2-selection--single,
#addProformaInvoiceModal .select2-container--default.select2-container--open .select2-selection--single,
#editProformaInvoiceModel .select2-container--default.select2-container--focus .select2-selection--single,
#editProformaInvoiceModel .select2-container--default.select2-container--open .select2-selection--single {
    border-color: #10b981 !important;
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2) !important;
    outline: none !important;
}
.select2-dropdown {
    border-radius: 0.75rem !important;
    border: 1px solid #e2e8f0 !important;
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
    overflow: hidden !important;
    z-index: 99999 !important;
}
.select2-container--default .select2-search--dropdown .select2-search__field {
    border-radius: 0.5rem !important;
    border: 1px solid #e2e8f0 !important;
    padding: 0.375rem 0.75rem !important;
    font-size: 0.875rem !important;
}
.select2-container--default .select2-results__option--highlighted[aria-selected] {
    background-color: #059669 !important;
    color: #ffffff !important;
}
.select2-container--default .select2-results__option[aria-selected=true] {
    background-color: #ecfdf5 !important;
    color: #065f46 !important;
    font-weight: 600 !important;
}
</style>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?? 'PI Management' ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage and generate Proforma Invoices (ERP &amp; Website synced)</p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <button id="piExportButton" type="button" data-bs-toggle="modal" data-bs-target="#exportModal" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36">
                <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
            </button>
            <button id="piImportButton" type="button" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-emerald-200 bg-emerald-50 px-4 text-sm font-bold text-emerald-700 shadow-sm ring-1 ring-emerald-900/5 transition-colors hover:bg-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                <i class="ti ti-refresh text-lg"></i>Sync Website
            </button>
            <?php if (roleHasPermission($_SESSION['role_id'], 'sales_billing_pi_generate_add') || roleHasPermission($_SESSION['role_id'], 'sync_pi_view')) { ?>
                <div class="dropdown shrink-0">
                    <button type="button"
                        class="inline-flex h-10 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="ti ti-plus text-lg"></i> Create PI <i class="ti ti-chevron-down text-xs ml-1"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end rounded-2xl border border-slate-100 shadow-xl p-1 text-sm font-medium">
                        <li>
                            <a class="dropdown-item rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer" id="addProformaInvoiceModalBtn">
                                <i class="ti ti-file-plus text-emerald-600"></i> New Proforma Invoice
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer" onclick="openSelectLeadForPiModal()">
                                <i class="ti ti-user-check text-primary-600"></i> From Existing Leads
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer" onclick="openSelectQuoteForPiModal()">
                                <i class="ti ti-file-text text-amber-600"></i> From Existing Quotes
                            </a>
                        </li>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:items-center">

                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="piGeneratorPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="pi-generator-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="pi-generator-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="pi-generator-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="pi-generator-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="pi-generator-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="pi-generator-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchPORaw"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <button type="button" id="piClearSearchBtn" class="inline-flex h-10 items-center justify-center gap-1 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60" onclick="$('#searchPORaw').val('').trigger('input');">
                        <i class="ti ti-filter-off text-base"></i>Clear
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr class="text-nowrap">
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="cursor-pointer px-6 py-3 sortable transition-colors hover:bg-slate-50/50"
                                data-column="created_at" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Timestamp"><span
                                    class="inline-flex items-center gap-1">Timestamp <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="cursor-pointer px-6 py-3 sortable transition-colors hover:bg-slate-50/50"
                                data-column="enquiry_date" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Enq Date"><span
                                    class="inline-flex items-center gap-1">Enq Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="cursor-pointer px-6 py-3 sortable transition-colors hover:bg-slate-50/50"
                                data-column="pi_auto_batch" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="PI No"><span class="inline-flex items-center gap-1">PI No
                                    <i class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="cursor-pointer px-6 py-3 sortable transition-colors hover:bg-slate-50/50"
                                data-column="company_name" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Company Name"><span
                                    class="inline-flex items-center gap-1">Company Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                title="Products Name">Products Name</th>
                            <th class="px-6 py-3">Total Value</th>
                            <th class="px-6 py-3">Created By</th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="proformaInvoiceTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="addProformaInvoiceModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-file-invoice text-xl"></i>
                        </span>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-800" id="exampleModalLabel5">Add PI</h5>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addProformaInvoiceFormMob">
                    <input type="hidden" id="piLeadId" name="lead_id" value="">
                    <input type="hidden" id="piQuoteRequestId" name="quote_request_id" value="">
                    <div class="modal-body !px-5 !py-5">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div>
                                <label for="companyName" class="mb-1 block text-sm font-medium text-slate-800">Company
                                    Name <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="companyName" autocomplete="off" name="companyName"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Company Name" required />
                            </div>
                            <div>
                                <label for="companyAddress"
                                    class="mb-1 block text-sm font-medium text-slate-800">Company Address <strong
                                        class="text-rose-500">*</strong></label>
                                <textarea id="companyAddress" rows="1" autocomplete="off" name="companyAddress"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 resize-none"
                                    placeholder="Enter Address" required></textarea>
                            </div>
                            <div>
                                <label for="gstNo" class="mb-1 block text-sm font-medium text-slate-800">Company GST No
                                </label>
                                <input type="text" id="gstNo" autocomplete="off" name="gstNo"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter GST No" />
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                <input type="checkbox" id="isShippingSame" name="isShippingSame" value="1"
                                    class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600">
                                Is Shipping Address Same ?
                            </label>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div>
                                <label for="companyShippinigName"
                                    class="mb-1 block text-sm font-medium text-slate-800">Company Shipping Name <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="companyShippinigName" autocomplete="off"
                                    name="companyShippinigName"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Company Shipping Name" required />
                            </div>
                            <div>
                                <label for="companyShippingAddress"
                                    class="mb-1 block text-sm font-medium text-slate-800">Company Shipping Address
                                    <strong class="text-rose-500">*</strong></label>
                                <textarea id="companyShippingAddress" rows="1" autocomplete="off"
                                    name="companyShippingAddress"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 resize-none"
                                    placeholder="Enter Address" required></textarea>
                            </div>
                            <div>
                                <label for="gstShippingNo" class="mb-1 block text-sm font-medium text-slate-800">Company
                                    GST No </label>
                                <input type="text" id="gstShippingNo" autocomplete="off" name="gstShippingNo"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter GST No" />
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="attendPerson"
                                    class="mb-1 block text-sm font-medium text-slate-800">Attending Person <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="attendPerson" autocomplete="off" name="attendPerson"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Attending Person" required />
                            </div>
                            <div>
                                <label for="attendPersonContact"
                                    class="mb-1 block text-sm font-medium text-slate-800">Attending Contact </label>
                                <input type="text" id="attendPersonContact" autocomplete="off"
                                    name="attendPersonContact"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Attending Person Contact" />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div>
                                <label for="enquiryMedium" class="mb-1 block text-sm font-medium text-slate-800">Enquiry
                                    Medium <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="enquiryMedium" autocomplete="off" name="enquiryMedium"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Enquiry Medium" required />
                            </div>
                            <div>
                                <label for="enquiryDate" class="mb-1 block text-sm font-medium text-slate-800">Enquiry
                                    Date <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="enquiryDate" autocomplete="off" name="enquiryDate"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Enquiry Date" required />
                            </div>
                        </div>

                        <div class="pi-product-section">
                            <div class="pi-section-title">
                                <span>Product Details</span>
                                <small>Add product pricing, GST and totals</small>
                            </div>
                            <div class="pi-products-list">
                            <div id="productsList"></div>
                            </div>
                            <div class="px-4 pb-4">
                            <button type="button"
                                class="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-500/20"
                                id="addProductBtn">
                                <i class="ti ti-plus"></i> Add Product
                            </button>
                            </div>
                        </div>

                        <div
                            class="grid grid-cols-1 md:grid-cols-4 gap-3 shadow-sm bg-slate-50 border border-slate-200 rounded-xl p-4 mb-4 mt-4">
                            <div>
                                <label for="totalQty"
                                    class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wider">Total
                                    QTY</label>
                                <input type="text" id="totalQty" autocomplete="off" name="totalQty"
                                    class="w-full bg-transparent border-0 border-b-2 border-slate-300 px-0 py-1 text-sm font-bold text-slate-800 focus:ring-0 focus:border-emerald-500"
                                    placeholder="Enter Total QTY" readonly />
                            </div>
                            <div>
                                <label for="totalGstAmount"
                                    class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wider">Total
                                    GST</label>
                                <input type="text" id="totalGstAmount" autocomplete="off" name="totalGstAmount"
                                    class="w-full bg-transparent border-0 border-b-2 border-slate-300 px-0 py-1 text-sm font-bold text-slate-800 focus:ring-0 focus:border-emerald-500"
                                    placeholder="Enter Total GST" readonly />
                            </div>
                            <div>
                                <label for="roundOffValue"
                                    class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wider">Round
                                    Off </label>
                                <input type="text" id="roundOffValue" autocomplete="off" name="roundOffValue"
                                    class="w-full bg-transparent border-0 border-b-2 border-slate-300 px-0 py-1 text-sm font-bold text-slate-800 focus:ring-0 focus:border-emerald-500"
                                    placeholder="Round Off Value" readonly />
                            </div>
                            <div>
                                <label for="totalPriceAmount"
                                    class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wider">Total
                                    Price </label>
                                <input type="text" id="totalPriceAmount" autocomplete="off" name="totalPriceAmount"
                                    class="w-full bg-transparent border-0 border-b-2 border-slate-300 px-0 py-1 text-sm font-bold text-emerald-700 focus:ring-0 focus:border-emerald-500"
                                    placeholder="Enter Total Price" readonly />
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                            <div>
                                <label for="freightAmount" class="mb-1 block text-sm font-medium text-slate-800">Freight
                                    Amount</label>
                                <input type="number" min="0" step="any" id="freightAmount" autocomplete="off"
                                    name="freightAmount"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 freightAmount"
                                    placeholder="Enter Freight" />
                            </div>
                            <div>
                                <label for="freightAmountTaxPercent"
                                    class="mb-1 block text-sm font-medium text-slate-800">Freight Tax Percent</label>
                                <input type="number" min="0" max="100" value="18" step="any"
                                    id="freightAmountTaxPercent" autocomplete="off" name="freightAmountTaxPercent"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 freightAmountTaxPercent"
                                    placeholder="Enter Freight Percent" />
                            </div>
                            <div>
                                <label for="freightAmountTax"
                                    class="mb-1 block text-sm font-medium text-slate-800">Freight Tax Amount</label>
                                <input type="number" min="0" step="any" id="freightAmountTax" autocomplete="off"
                                    name="freightAmountTax"
                                    class="w-full h-10 !rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 shadow-none outline-none freightAmountTax"
                                    placeholder="Enter Freight Tax Amount" readonly />
                            </div>
                            <div>
                                <label for="totalFreight" class="mb-1 block text-sm font-medium text-slate-800">Total
                                    Freight</label>
                                <input type="number" min="0" step="any" id="totalFreight" autocomplete="off"
                                    name="totalFreight"
                                    class="w-full h-10 !rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-sm font-bold text-slate-700 shadow-none outline-none totalFreight"
                                    placeholder="Total Freight" readonly />
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="freightNotice" class="mb-1 block text-sm font-medium text-slate-800">Freight
                                    Notice</label>
                                <textarea name="freightNotice" id="freightNotice"
                                    class="w-full !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 resize-none min-h-[60px]"
                                    placeholder="Enter Freight Notice"></textarea>
                            </div>
                            <div>
                                <label for="supplyPeriod" class="mb-1 block text-sm font-medium text-slate-800">Supply
                                    Period <strong class="text-rose-500">*</strong></label>
                                <textarea name="supplyPeriod" id="supplyPeriod"
                                    class="w-full !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 resize-none min-h-[60px]"
                                    placeholder="Enter Supply Period"
                                    required>Supply within 4-5 week after confirmation order along with 100% advance payment.</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3 rounded-b-3xl">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewPurchaseOrderRawModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-800" id="exampleModalLabel5">Proforma
                            Invoice Details</h5>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="viewPurchaseOrderRaw">
                    <div class="modal-body !px-5 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editProformaInvoiceModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-800" id="exampleModalLabel5">Edit
                            Proforma Invoice</h5>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editProformaInvoice">
                    <div class="modal-body !px-5 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Website PI Detail Modal -->
    <div class="modal fade pi-detail-modal" id="piModal" tabindex="-1" aria-labelledby="piModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" style="max-width: 900px;">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header border-b border-slate-100 bg-slate-50/80 px-4 py-3 flex items-center justify-between">
                    <div>
                        <h5 id="piModalTitle" class="modal-title text-base font-extrabold text-slate-800 m-0">PI Details</h5>
                        <p class="mb-0 mt-0.5 text-[10px] font-bold text-slate-400">Website Proforma Invoice Snapshot</p>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <div id="piModalBody" class="modal-body bg-slate-50 p-4">Loading...</div>
                <div class="modal-footer border-t border-slate-100 bg-white px-4 py-2">
                    <button type="button" class="inline-flex h-9 items-center rounded-xl px-4 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Modal -->
    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="piRequestsExportForm" method="POST" action="exportajax.php">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>

                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="piDeselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="PI Number" checked /><span class="text-sm font-medium text-slate-700">PI Number</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Source" checked /><span class="text-sm font-medium text-slate-700">Source (ERP / Website)</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Customer Name" checked /><span class="text-sm font-medium text-slate-700">Customer Name</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="PI Date" checked /><span class="text-sm font-medium text-slate-700">PI Date</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Total Amount" checked /><span class="text-sm font-medium text-slate-700">Total Amount</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Created By" checked /><span class="text-sm font-medium text-slate-700">Created By</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Created At" checked /><span class="text-sm font-medium text-slate-700">Created At</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none !rounded-xl" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="inline-flex h-10 w-28 items-center justify-center gap-2 !rounded-xl text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534);"><i class="ti ti-download text-base"></i> Export</button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="hidden d-none inline-flex h-10 w-auto items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534); display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Selection Modal: Select Lead for PI -->
    <div class="modal fade" id="selectLeadForPiModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                            <i class="ti ti-user-check text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title font-bold text-slate-800 text-base">Select Lead for Proforma Invoice</h5>
                            <p class="text-xs text-slate-500 mt-0.5">Pre-fill PI company, address, and interested products from lead master</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <div class="modal-body p-0">
                    <div class="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                        <div class="relative w-full max-w-sm">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <i class="ti ti-search text-base text-slate-400"></i>
                            </div>
                            <input type="text" id="leadPiSearch" placeholder="Search leads by name, company, territory, city..." class="form-control !rounded-xl border-slate-200 text-xs py-2 pr-3" style="padding-left: 2.5rem !important;" oninput="loadLeadsForPiSelection(1)">
                        </div>
                    </div>
                    <div class="overflow-x-auto w-full">
                        <table class="w-full table-auto text-left text-sm text-slate-600">
                            <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                <tr class="text-nowrap">
                                    <th class="px-5 py-3">Sr.</th>
                                    <th class="px-5 py-3">Source</th>
                                    <th class="px-5 py-3">Timestamp</th>
                                    <th class="px-5 py-3">Lead ID</th>
                                    <th class="px-5 py-3">Lead Name</th>
                                    <th class="px-5 py-3">Company</th>
                                    <th class="px-5 py-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="leadsForPiTableBody" class="divide-y divide-slate-100">
                                <!-- Populated via AJAX -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-3 flex items-center justify-between" id="leadsForPiPagination"></div>
            </div>
        </div>
    </div>

    <!-- Selection Modal: Select Quote for PI -->
    <div class="modal fade" id="selectQuoteForPiModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                            <i class="ti ti-file-text text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title font-bold text-slate-800 text-base">Select CRM Quote for Proforma Invoice</h5>
                            <p class="text-xs text-slate-500 mt-0.5">Convert commercial quote line items and pricing into a PI</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <div class="modal-body p-0">
                    <div class="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                        <div class="relative w-full max-w-sm">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <i class="ti ti-search text-base text-slate-400"></i>
                            </div>
                            <input type="text" id="quotePiSearch" placeholder="Search quotes by number, contact, company..." class="form-control !rounded-xl border-slate-200 text-xs py-2 pr-3" style="padding-left: 2.5rem !important;" oninput="loadQuotesForPiSelection(1)">
                        </div>
                    </div>
                    <div class="overflow-x-auto w-full">
                        <table class="w-full table-auto text-left text-sm text-slate-600">
                            <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                <tr class="text-nowrap">
                                    <th class="px-5 py-3">Sr.</th>
                                    <th class="px-5 py-3">Source</th>
                                    <th class="px-5 py-3">Timestamp</th>
                                    <th class="px-5 py-3">Quote ID</th>
                                    <th class="px-5 py-3">Quote Name</th>
                                    <th class="px-5 py-3">Company</th>
                                    <th class="px-5 py-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="quotesForPiTableBody" class="divide-y divide-slate-100">
                                <!-- Populated via AJAX -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-3 flex items-center justify-between" id="quotesForPiPagination"></div>
            </div>
        </div>
    </div>

</div>

<?php startSection('scripts'); ?>
<script>
const crmCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
$.ajaxPrefilter(function (options) {
    if (String(options.type || 'GET').toUpperCase() !== 'POST' || !crmCsrfToken) return;
    if (options.data instanceof FormData) {
        if (!options.data.has('csrf_token')) options.data.append('csrf_token', crmCsrfToken);
    } else if (typeof options.data === 'string') {
        if (!/(^|&)csrf_token=/.test(options.data)) options.data += (options.data ? '&' : '') + 'csrf_token=' + encodeURIComponent(crmCsrfToken);
    } else {
        options.data = Object.assign({}, options.data || {}, { csrf_token: crmCsrfToken });
    }
});

    let currentPage = 1;
    let productIndex = 0;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';
    const piCatalog = <?= json_encode($piProductCatalog ?? []) ?>;

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function getPiProductOptionsHtml(selectedVal = '') {
        let html = '<option value="">-- Select Product --</option>';
        let found = false;
        const normalizedSelected = String(selectedVal || '').trim().toLowerCase();
        for (let i = 0; i < piCatalog.length; i++) {
            const p = piCatalog[i];
            const isSel = (normalizedSelected !== '' && normalizedSelected === String(p.product_name || '').trim().toLowerCase());
            if (isSel) found = true;
            const codeSuffix = p.cat_no ? ` (${p.cat_no})` : '';
            html += `<option value="${escapeHtml(p.product_name)}" data-id="${p.id}" data-cat="${escapeHtml(p.cat_no || '')}" data-pack="${escapeHtml(p.pack_size || '')}" data-rate="${p.rate !== '' ? p.rate : ''}" data-gst="${p.gst_rate || '18'}" ${isSel ? 'selected' : ''}>${escapeHtml(p.product_name)}${escapeHtml(codeSuffix)}</option>`;
        }
        if (selectedVal && !found) {
            html += `<option value="${escapeHtml(selectedVal)}" selected>${escapeHtml(selectedVal)}</option>`;
        }
        return html;
    }

    function createProductRowHtml(idx, selectedVal = '', isEdit = false) {
        const optionsHtml = getPiProductOptionsHtml(selectedVal);
        const selectClass = isEdit ? 'pi-product-select-edit' : 'pi-product-select';
        const qtyClass = isEdit ? 'prodQtyEdit' : 'prodQty';
        const rateClass = isEdit ? 'prodRateEdit' : 'prodRate';
        const valClass = isEdit ? 'prodValueEdit' : 'prodValue';
        const gstPctClass = isEdit ? 'prodGstPercentEdit' : 'prodGstPercent';
        const gstAmtClass = isEdit ? 'prodGstEdit' : 'prodGst';
        const priceClass = isEdit ? 'prodPriceEdit' : 'prodPrice';
        const copyBtnClass = isEdit ? 'copyProductBtnEdit' : 'copyProductBtn';
        const removeBtnClass = isEdit ? 'removeProductBtnEdit' : 'removeProductBtn';
        const hiddenItemId = isEdit ? '<input type="hidden" name="prodItemId[]" value="" />' : '';

        return `<div class="pi-product-row product-row grid grid-cols-1 md:grid-cols-[1fr_2fr_1fr_min-content] gap-2 items-start mb-3 p-3 rounded-2xl bg-white border border-slate-200 shadow-sm transition-all hover:shadow-md hover:border-emerald-200 relative group" data-index="${idx}">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 col-span-1 md:col-span-3">
                <div>
                    ${hiddenItemId}
                    <input type="text" name="catNo[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500/20" placeholder="Cat No" />
                </div>
                <div class="md:col-span-2">                    
                    <select name="productName[]" class="${selectClass} select2 w-full h-9 !rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20" required>
                        ${optionsHtml}
                    </select>
                </div>
                <div>
                    <input type="text" name="packSize[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500/20" placeholder="Pack Size" />
                </div>
                <div>
                    <input type="number" min="0" step="any" name="quantity[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-emerald-200 bg-emerald-50/30 px-3 py-1.5 text-sm font-bold text-emerald-700 shadow-sm outline-none transition-all hover:border-emerald-300 focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 ${qtyClass}" placeholder="Qty" required />
                </div>                
                <div>
                    <input type="number" min="0" step="any" name="rate[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 ${rateClass}" placeholder="Rate" />
                </div>
                <div>
                    <input type="number" min="0" step="any" name="value[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm font-medium text-slate-700 shadow-none outline-none ${valClass}" placeholder="Value" required readonly />
                </div> 
                <div>
                    <input type="number" min="0" step="any" name="gstPercent[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 ${gstPctClass}" placeholder="GST %" />
                </div>
                <div>
                    <input type="number" min="0" step="any" name="gst[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm font-medium text-slate-700 shadow-none outline-none ${gstAmtClass}" placeholder="GST Amt" readonly />
                </div>
                <div>
                    <input type="number" min="0" step="any" name="totalPrice[]" autocomplete="off" class="w-full h-9 !rounded-xl border border-slate-200 bg-slate-100 px-3 py-1.5 text-sm font-bold text-slate-800 shadow-none outline-none ${priceClass}" placeholder="Total" readonly />
                </div>
            </div>
            <div class="flex items-center justify-center h-full pt-1 gap-2 flex-col md:flex-row">
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600 shadow-sm ring-1 ring-amber-100 transition-colors hover:bg-amber-100 hover:text-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/30 ${copyBtnClass}" title="Duplicate Product">
                    <i class="ti ti-copy text-lg"></i>
                </button>                    
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30 ${removeBtnClass}" title="Remove Product">
                    <i class="ti ti-trash text-lg"></i>
                </button>                    
            </div>
        </div>`;
    }

    function initPiSelect2($container, modalSelector) {
        $container.find('.select2').each(function() {
            if ($(this).hasClass('select2-hidden-accessible')) {
                $(this).select2('destroy');
            }
            $(this).select2({
                dropdownParent: $(modalSelector),
                width: '100%',
                placeholder: '-- Select Product --',
                allowClear: true
            });
        });
    }

    function loadProformaInvoicesTable(page = 1) {
        currentPage = page;
        const search = $('#searchPORaw').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProformaInvoiceTable: 'loadProformaInvoiceTable',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#proformaInvoiceTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');

                let summaryText = 'Showing 0 results of 0';
                if (response.totalRows > 0) {
                    let startItem = ((currentPage - 1) * (perPage === 'all' ? response.totalRows : perPage)) + 1;
                    let endItem = startItem + response.visibleRows - 1;
                    summaryText = `Showing ${startItem} to ${endItem} of ${response.totalRows} results`;
                }

            },
            error: function () {
                $('#proformaInvoiceTableBody').html('<tr><td colspan="9" class="text-center text-danger py-4">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    function calculateTotals() {
        let totalQty = 0;
        let totalGst = 0;
        let totalPrice = 0;
        let freightAmount = parseFloat($('#freightAmount').val()) || 0;
        let freightTaxPercent = parseFloat($('#freightAmountTaxPercent').val()) || 0;

        let freightTaxAmt = freightAmount * (freightTaxPercent / 100);
        let totalFreight = freightAmount + freightTaxAmt;
        $('.product-row').each(function () {
            let qty = parseFloat($(this).find('.prodQty').val()) || 0;
            let rate = parseFloat($(this).find('.prodRate').val()) || 0;
            let gstPercent = parseFloat($(this).find('.prodGstPercent').val()) || 0;
            let value = qty * rate;
            let gstAmount = value * (gstPercent / 100);
            let finalPrice = value + gstAmount;
            $(this).find('.prodValue').val(value.toFixed(2));
            $(this).find('.prodGst').val(gstAmount.toFixed(2));
            $(this).find('.prodPrice').val(finalPrice.toFixed(2));
            totalQty += qty;
            totalGst += gstAmount;
            totalPrice += finalPrice;
        });
        totalPrice += totalFreight;
        let roundedTotal = Math.round(totalPrice);
        let roundDiff = roundedTotal - totalPrice;
        let roundDiffFormatted = (roundDiff >= 0 ? "+" : "") + roundDiff.toFixed(2);
        $('#totalQty').val(totalQty.toFixed(2));
        $('#totalGstAmount').val(totalGst.toFixed(2));
        $('#totalFreight').val(totalFreight.toFixed(2));
        $('#freightAmountTax').val(freightTaxAmt.toFixed(2));
        $('#totalPriceAmount').val(roundedTotal.toFixed(2));
        $('#roundOffValue').val(roundDiffFormatted);
    }

    function calculateTotalsEdit() {
        let totalQty = 0;
        let totalGst = 0;
        let totalPrice = 0;
        let freightAmount = parseFloat($('#freightAmountEdit').val()) || 0;
        let freightTaxPercent = parseFloat($('#freightAmountTaxPercentEdit').val()) || 0;

        let freightTaxAmt = freightAmount * (freightTaxPercent / 100);
        let totalFreight = freightAmount + freightTaxAmt;
        $('.product-row').each(function () {
            let qty = parseFloat($(this).find('.prodQtyEdit').val()) || 0;
            let rate = parseFloat($(this).find('.prodRateEdit').val()) || 0;
            let gstPercent = parseFloat($(this).find('.prodGstPercentEdit').val()) || 0;
            let value = qty * rate;
            let gstAmount = value * (gstPercent / 100);
            let finalPrice = value + gstAmount;
            $(this).find('.prodValueEdit').val(value.toFixed(2));
            $(this).find('.prodGstEdit').val(gstAmount.toFixed(2));
            $(this).find('.prodPriceEdit').val(finalPrice.toFixed(2));
            totalQty += qty;
            totalGst += gstAmount;
            totalPrice += finalPrice;
        });
        totalPrice += totalFreight;
        let roundedTotal = Math.round(totalPrice);
        let roundDiff = roundedTotal - totalPrice;
        let roundDiffFormatted = (roundDiff >= 0 ? "+" : "") + roundDiff.toFixed(2);
        $('#totalQtyEdit').val(totalQty.toFixed(2));
        $('#totalGstAmountEdit').val(totalGst.toFixed(2));
        $('#totalFreightEdit').val(totalFreight.toFixed(2));
        $('#freightAmountTaxEdit').val(freightTaxAmt.toFixed(2));
        $('#totalPriceAmountEdit').val(roundedTotal.toFixed(2));
        $('#roundOffValueEdit').val(roundDiffFormatted);
    }

    $(document).on('input', '.prodQty, .prodRate, .prodValue, .prodGstPercent, .prodGst, .prodPrice, #freightAmount, #freightAmountTaxPercent', function () {
        calculateTotals();
    });

    $(document).on('change', '.pi-product-select', function () {
        const $select = $(this);
        const $row = $select.closest('.product-row');
        const $selected = $select.find('option:selected');
        const val = $select.val();

        if (val) {
            const catNo = $selected.data('cat') || '';
            const packSize = $selected.data('pack') || '';
            const rate = $selected.data('rate') !== undefined ? $selected.data('rate') : '';
            const gstRate = $selected.data('gst') !== undefined ? $selected.data('gst') : 18;

            $row.find('input[name="catNo[]"]').val(catNo);
            $row.find('input[name="packSize[]"]').val(packSize);
            $row.find('input[name="rate[]"]').val(rate !== '' ? rate : '');
            $row.find('input[name="gstPercent[]"]').val(gstRate);

            // Focus on quantity for user entry
            const $qty = $row.find('input[name="quantity[]"]');
            $qty.focus();
        } else {
            $row.find('input[name="catNo[]"]').val('');
            $row.find('input[name="packSize[]"]').val('');
            $row.find('input[name="rate[]"]').val('');
            $row.find('input[name="gstPercent[]"]').val('18');
        }
        calculateTotals();
    });

    $(document).ready(function () {
        $('#addProformaInvoiceModal').on('hidden.bs.modal', function () {
            $('#addProformaInvoiceFormMob')[0].reset();
            $('#productsList').empty();
            $('#companyShippinigName, #companyShippingAddress, #gstShippingNo').prop('readonly', false);
            productIndex = 0;
            calculateTotals();
        });
        loadProformaInvoicesTable();
        $('#searchPORaw').on('input', function () {
            loadProformaInvoicesTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadProformaInvoicesTable(1);
        });

        $('#piImportButton').on('click', function () {
            importPiRows(this);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.pi-generator-per-page-item', function () {
            const val = $(this).data('val');
            $('#piGeneratorPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#addProformaInvoiceModalBtn').on('click', function () {
            $('#addProformaInvoiceModal').modal('show');
            $('#productsList').html('');
            $('#addProductBtn').trigger('click');
        });

        $('#addProductBtn').click(function () {
            const rowHtml = createProductRowHtml(productIndex);
            const $row = $(rowHtml);
            $('#productsList').append($row);
            initPiSelect2($row, '#addProformaInvoiceModal');
            calculateTotals();
            productIndex++;
        });

        // Delete button handler
        $('#productsList').on('click', '.removeProductBtn', function () {
            $(this).closest('.product-row').remove();
            calculateTotals();
        });

        // COPY PRODUCT ROW
        $(document).on('click', '.copyProductBtn', function () {
            let $currentRow = $(this).closest('.product-row');
            let selectedProd = $currentRow.find('.pi-product-select').val() || '';
            let catVal = $currentRow.find('input[name="catNo[]"]').val();
            let packVal = $currentRow.find('input[name="packSize[]"]').val();
            let qtyVal = $currentRow.find('input[name="quantity[]"]').val();
            let rateVal = $currentRow.find('input[name="rate[]"]').val();
            let gstVal = $currentRow.find('input[name="gstPercent[]"]').val();
            let valVal = $currentRow.find('input[name="value[]"]').val();
            let gstAmtVal = $currentRow.find('input[name="gst[]"]').val();
            let totalVal = $currentRow.find('input[name="totalPrice[]"]').val();

            const rowHtml = createProductRowHtml(productIndex, selectedProd);
            const $newRow = $(rowHtml);

            $newRow.find('input[name="catNo[]"]').val(catVal);
            $newRow.find('input[name="packSize[]"]').val(packVal);
            $newRow.find('input[name="quantity[]"]').val(qtyVal);
            $newRow.find('input[name="rate[]"]').val(rateVal);
            $newRow.find('input[name="gstPercent[]"]').val(gstVal);
            $newRow.find('input[name="value[]"]').val(valVal);
            $newRow.find('input[name="gst[]"]').val(gstAmtVal);
            $newRow.find('input[name="totalPrice[]"]').val(totalVal);

            $('#productsList').append($newRow);
            initPiSelect2($newRow, '#addProformaInvoiceModal');
            calculateTotals();
            productIndex++;
        });


        $('#addProformaInvoiceFormMob').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addProformaInvoiceFormMob');
            const formData = new FormData(form);
            formData.append('addProformaInvoiceMobile', 'addProformaInvoiceMobile'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#addProformaInvoiceModal').modal('hide');
                        $('#addProformaInvoiceFormMob')[0].reset();
                        $('#productsList').html('');
                        loadProformaInvoicesTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#isShippingSame').on('change', function () {
            if ($(this).is(':checked')) {
                $('#companyShippinigName').val($('#companyName').val());
                $('#companyShippingAddress').val($('#companyAddress').val());
                $('#gstShippingNo').val($('#gstNo').val());
                $('#companyShippinigName, #companyShippingAddress, #gstShippingNo')
                    .prop('readonly', true);

            } else {
                $('#companyShippinigName').val('');
                $('#companyShippingAddress').val('');
                $('#gstShippingNo').val('');                // Enable fields
                $('#companyShippinigName, #companyShippingAddress, #gstShippingNo')
                    .prop('readonly', false);
            }
        });
    });

    $(document).on('input', '.prodQtyEdit, .prodRateEdit, .prodValueEdit, .prodGstPercentEdit, .prodGstEdit, .prodPriceEdit, #freightAmountEdit, #freightAmountTaxPercentEdit', function () {
        calculateTotalsEdit();
    });

    $(document).on('click', '.proformaInvoiceDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteProfInvoiceRecord: 'deleteProfInvoiceRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadProformaInvoicesTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.viewProformaInvoicesPdfModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewOrderReceived').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    viewProformaInvoicePdfRecord: 'viewProformaInvoicePdfRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewPurchaseOrderRawModel').modal('show');
                        $('#viewPurchaseOrderRaw').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfPurchaseOrderRawDownloadBtn', function (e) {
        e.preventDefault();
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/pi_template.php?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');
            toastr.success('Purchase Order PDF is being downloaded.');
        }
    });

    $(document).on('click', '.editProformaInvoiceModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editProformaInvoice').find('.modal-body').html('<div class="py-12 text-center text-slate-400"><div class="spinner-border text-primary-600" role="status"></div><p class="mt-2 text-xs">Loading PI details...</p></div>');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchProformaInvoiceEditRecord: 'fetchProformaInvoiceEditRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editProformaInvoiceModel').modal('show');
                        $('#editProformaInvoice').find('.modal-body').html(res.data);
                        initPiSelect2($('#editProformaInvoice'), '#editProformaInvoiceModel');
                        calculateTotalsEdit();
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '#addProductBtnEdit', function () {
        const rowHtml = createProductRowHtml(productIndex, '', true);
        const $row = $(rowHtml);
        $('#productsListEdit').append($row);
        initPiSelect2($row, '#editProformaInvoiceModel');
        calculateTotalsEdit();
        productIndex++;
    });

    $(document).on('change', '.pi-product-select-edit', function () {
        const $select = $(this);
        const $row = $select.closest('.product-row');
        const $selected = $select.find('option:selected');
        const val = $select.val();

        if (val) {
            const catNo = $selected.data('cat') || '';
            const packSize = $selected.data('pack') || '';
            const rate = $selected.data('rate') !== undefined ? $selected.data('rate') : '';
            const gstRate = $selected.data('gst') !== undefined ? $selected.data('gst') : 18;

            $row.find('input[name="catNo[]"]').val(catNo);
            $row.find('input[name="packSize[]"]').val(packSize);
            $row.find('input[name="rate[]"]').val(rate !== '' ? rate : '');
            $row.find('input[name="gstPercent[]"]').val(gstRate);

            // Focus on quantity for user entry
            const $qty = $row.find('input[name="quantity[]"]');
            $qty.focus();
        } else {
            $row.find('input[name="catNo[]"]').val('');
            $row.find('input[name="packSize[]"]').val('');
            $row.find('input[name="rate[]"]').val('');
            $row.find('input[name="gstPercent[]"]').val('18');
        }
        calculateTotalsEdit();
    });

    $(document).on('click', '.copyProductBtnEdit', function () {
        let $currentRow = $(this).closest('.product-row');
        let selectedProd = $currentRow.find('.pi-product-select-edit').val() || '';
        let catVal = $currentRow.find('input[name="catNo[]"]').val();
        let packVal = $currentRow.find('input[name="packSize[]"]').val();
        let qtyVal = $currentRow.find('input[name="quantity[]"]').val();
        let rateVal = $currentRow.find('input[name="rate[]"]').val();
        let gstVal = $currentRow.find('input[name="gstPercent[]"]').val();
        let valVal = $currentRow.find('input[name="value[]"]').val();
        let gstAmtVal = $currentRow.find('input[name="gst[]"]').val();
        let totalVal = $currentRow.find('input[name="totalPrice[]"]').val();

        const rowHtml = createProductRowHtml(productIndex, selectedProd, true);
        const $newRow = $(rowHtml);

        $newRow.find('input[name="catNo[]"]').val(catVal);
        $newRow.find('input[name="packSize[]"]').val(packVal);
        $newRow.find('input[name="quantity[]"]').val(qtyVal);
        $newRow.find('input[name="rate[]"]').val(rateVal);
        $newRow.find('input[name="gstPercent[]"]').val(gstVal);
        $newRow.find('input[name="value[]"]').val(valVal);
        $newRow.find('input[name="gst[]"]').val(gstAmtVal);
        $newRow.find('input[name="totalPrice[]"]').val(totalVal);

        $('#productsListEdit').append($newRow);
        initPiSelect2($newRow, '#editProformaInvoiceModel');
        calculateTotalsEdit();
        productIndex++;
    });

    $(document).on('click', '.removeProductBtnEdit', function () {
        let id = $(this).data('id');
        let row = $(this).closest('.product-row');
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                row.remove();
                calculateTotalsEdit();
                if (id) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deletePISubItemRecord: 'deletePISubItemRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            }
        });
    });

    $('#editProformaInvoice').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editProformaInvoice');
        const formData = new FormData(form);
        formData.append('updateProformaInvoice', 'updateProformaInvoice');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editProformaInvoiceModel').modal('hide');
                    $('#editProformaInvoice').find('.modal-body').html('');
                    loadProformaInvoicesTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.duplicateProformaInvoiceModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            Swal.fire({
                title: 'Duplicate Proforma Invoice?',
                text: 'A new proforma invoice will be created with the same details.',
                icon: 'warning',
                confirmButtonText: 'Yes, duplicate it!',
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            duplicateProformaInvoice: 'duplicateProformaInvoice',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                loadProformaInvoicesTable();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Duplicated!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        }
    });

    $(document).on('change', '#isShippingSameEdit', function () {
        if ($(this).is(':checked')) {
            $('#companyShippinigNameEdit').val($('#companyNameE').val());
            $('#companyShippingAddressEdit').val($('#companyAddressE').val());
            $('#gstShippingNoEdit').val($('#gstNoE').val());
            $('#companyShippinigNameEdit, #companyShippingAddressEdit, #gstShippingNoEdit')
                .prop('readonly', true);
        } else {
            $('#companyShippinigNameEdit').val('');
            $('#companyShippingAddressEdit').val('');
            $('#gstShippingNoEdit').val('');
            $('#companyShippinigNameEdit, #companyShippingAddressEdit, #gstShippingNoEdit')
                .prop('readonly', false);
        }
    });

    // =========================================================================
    // CRM Lead & Quote Selection for PI
    // =========================================================================
    function openSelectLeadForPiModal() {
        $('#leadsForPiTableBody').html('<tr><td colspan="7" class="py-8 text-center text-slate-400"><div class="spinner-border text-primary-600" role="status"></div><p class="mt-2 text-xs">Loading leads...</p></td></tr>');
        const modal = new bootstrap.Modal(document.getElementById('selectLeadForPiModal'));
        modal.show();
        loadLeadsForPiSelection(1);
    }

    function loadLeadsForPiSelection(page = 1) {
        const search = $('#leadPiSearch').val().trim();
        $.post('ajax.php', { action: 'crm_load_leads_for_quote', search: search, page: page }, function (res) {
            if (res.status === 'success') {
                let html = '';
                if (res.html) {
                    html = res.html.replace(/selectLeadForQuote/g, 'selectLeadForPi');
                }
                $('#leadsForPiTableBody').html(html || '<tr><td colspan="7" class="py-8 text-center text-slate-400">No accepted leads available.</td></tr>');
                renderPiSelectionPagination('leadsForPiPagination', res, 'loadLeadsForPiSelection');
            } else {
                $('#leadsForPiTableBody').html('<tr><td colspan="7" class="py-8 text-center text-red-500">' + (res.message || 'Error loading leads') + '</td></tr>');
            }
        }, 'json');
    }

    function selectLeadForPi(leadId) {
        bootstrap.Modal.getInstance(document.getElementById('selectLeadForPiModal')).hide();
        $.post('ajax.php', { action: 'crm_get_lead_for_quote_prefill', lead_id: leadId }, function (res) {
            if (res.status === 'success') {
                const lead = res.lead;
                $('#addProformaInvoiceFormMob')[0].reset();
                $('#piLeadId').val(lead.id);
                $('#piQuoteRequestId').val('');
                $('#companyName').val(lead.company_name || '');
                $('#companyAddress').val([lead.territory, lead.city, lead.state, lead.region].filter(Boolean).join(', '));
                $('#attendPerson').val(lead.contact_person || '');
                $('#attendPersonContact').val(lead.mobile_number || '');
                $('#enquiryMedium').val(lead.source_type || '');
                
                $('#productsList').html('');
                if (res.products && res.products.length > 0) {
                    res.products.forEach(p => {
                        const rowHtml = createProductRowHtml(productIndex++, p.product_name);
                        const $row = $(rowHtml);
                        if (p.sku) $row.find('input[name="catNo[]"]').val(p.sku);
                        if (p.gst_rate) $row.find('input[name="gstPercent[]"]').val(p.gst_rate);
                        $('#productsList').append($row);
                        initPiSelect2($row, '#addProformaInvoiceModal');
                    });
                } else {
                    const rowHtml = createProductRowHtml(productIndex++);
                    const $row = $(rowHtml);
                    $('#productsList').append($row);
                    initPiSelect2($row, '#addProformaInvoiceModal');
                }
                calculateTotals();

                $('#addProformaInvoiceModal').modal('show');
            } else {
                toastr.error(res.message || 'Failed to prefill lead data');
            }
        }, 'json');
    }

    function openSelectQuoteForPiModal() {
        $('#quotesForPiTableBody').html('<tr><td colspan="7" class="py-8 text-center text-slate-400"><div class="spinner-border text-primary-600" role="status"></div><p class="mt-2 text-xs">Loading quotes...</p></td></tr>');
        const modal = new bootstrap.Modal(document.getElementById('selectQuoteForPiModal'));
        modal.show();
        loadQuotesForPiSelection(1);
    }

    function loadQuotesForPiSelection(page = 1) {
        const search = $('#quotePiSearch').val().trim();
        $.post('ajax.php', { action: 'crm_load_quotes_for_pi', search: search, page: page }, function (res) {
            if (res.status === 'success') {
                $('#quotesForPiTableBody').html(res.html || '<tr><td colspan="7" class="py-8 text-center text-slate-400">No quotes available.</td></tr>');
                renderPiSelectionPagination('quotesForPiPagination', res, 'loadQuotesForPiSelection');
            } else {
                $('#quotesForPiTableBody').html('<tr><td colspan="7" class="py-8 text-center text-red-500">' + (res.message || 'Error loading quotes') + '</td></tr>');
            }
        }, 'json');
    }

    function renderPiSelectionPagination(containerId, res, loaderName) {
        const currentPage = Number(res.page || 1);
        const totalPages = Number(res.total_pages || 1);
        let pageButtons = '';
        for (let page = Math.max(1, currentPage - 2); page <= Math.min(totalPages, currentPage + 2); page++) {
            const pageClass = page === currentPage ? 'bg-emerald-700 text-white' : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50';
            pageButtons += `<button type="button" class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-bold ${pageClass}" onclick="${loaderName}(${page})">${page}</button>`;
        }
        $('#' + containerId).html(`
            <span class="text-xs font-medium text-slate-500">Showing <strong>${res.from || 0}</strong>–<strong>${res.to || 0}</strong> of <strong>${res.total_count || 0}</strong></span>
            <div class="flex items-center gap-1">
                <button type="button" class="inline-flex h-8 items-center justify-center rounded-lg border border-slate-200 bg-white px-2 text-xs font-bold text-slate-700 disabled:opacity-40" ${currentPage <= 1 ? 'disabled' : ''} onclick="${loaderName}(${currentPage - 1})"><i class="ti ti-chevron-left"></i></button>
                ${pageButtons}
                <button type="button" class="inline-flex h-8 items-center justify-center rounded-lg border border-slate-200 bg-white px-2 text-xs font-bold text-slate-700 disabled:opacity-40" ${currentPage >= totalPages ? 'disabled' : ''} onclick="${loaderName}(${currentPage + 1})"><i class="ti ti-chevron-right"></i></button>
            </div>`);
    }

    function selectQuoteForPi(quoteId) {
        bootstrap.Modal.getInstance(document.getElementById('selectQuoteForPiModal')).hide();
        $.post('ajax.php', { action: 'crm_get_quote_detail', quote_id: quoteId }, function (res) {
            if (res.status === 'success') {
                const q = res.quote;
                $('#addProformaInvoiceFormMob')[0].reset();
                $('#piQuoteRequestId').val(q.id);
                $('#piLeadId').val(q.lead_id || '');
                $('#companyName').val(q.target_company_name || q.target_name || '');
                $('#companyAddress').val(q.billing_address || '');
                $('#gstNo').val(q.customer_gstin || '');
                $('#attendPerson').val(q.target_name || '');
                $('#attendPersonContact').val(q.target_phone || '');
                
                $('#productsList').html('');
                if (res.items && res.items.length > 0) {
                    res.items.forEach(it => {
                        const rowHtml = createProductRowHtml(productIndex++, it.product_name);
                        const $row = $(rowHtml);
                        if (it.sku) $row.find('input[name="catNo[]"]').val(it.sku);
                        if (it.quantity) $row.find('input[name="quantity[]"]').val(it.quantity);
                        if (it.unit_price) $row.find('input[name="rate[]"]').val(it.unit_price);
                        if (it.gst_rate) $row.find('input[name="gstPercent[]"]').val(it.gst_rate);
                        if (it.quantity && it.unit_price) $row.find('input[name="value[]"]').val((it.quantity * it.unit_price).toFixed(2));
                        $('#productsList').append($row);
                        initPiSelect2($row, '#addProformaInvoiceModal');
                    });
                } else {
                    const rowHtml = createProductRowHtml(productIndex++);
                    const $row = $(rowHtml);
                    $('#productsList').append($row);
                    initPiSelect2($row, '#addProformaInvoiceModal');
                }
                calculateTotals();

                $('#addProformaInvoiceModal').modal('show');
            }
        });
    }

    window.openSelectLeadForPiModal = openSelectLeadForPiModal;
    window.loadLeadsForPiSelection = loadLeadsForPiSelection;
    window.selectLeadForPi = selectLeadForPi;
    window.openSelectQuoteForPiModal = openSelectQuoteForPiModal;
    window.loadQuotesForPiSelection = loadQuotesForPiSelection;
    window.selectQuoteForPi = selectQuoteForPi;

    // =========================================================================
    // Convert Confirmed PI to Order (Phase 6 per Section 6)
    // =========================================================================
    $(document).on('click', '.convertPiToOrderBtn', function () {
        const piId = $(this).data('id');
        const piBatch = $(this).data('batch') || 'PI';

        Swal.fire({
            title: 'Confirm PI and create Sales Order?',
            text: `This confirms ${piBatch} and creates an official Sales Order with all line items in Order Management.`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Confirm & Create Order',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-success waves-effect waves-light',
                cancelButton: 'btn btn-outline-secondary waves-effect'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const $button = $(this);
                const originalHtml = $button.html();
                $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Creating...');
                $.ajax({
                    url: 'crm/crm_ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                    action: 'crm_convert_pi_to_order',
                    pi_id: piId,
                    csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || ''
                    }
                }).done(function (res) {
                    if (res.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Order Created!',
                            text: res.message,
                            footer: `<a href="index.php?page=order-received" class="font-bold text-emerald-600 underline">Go to Order Management (${res.order_number})</a>`
                        });
                        loadProformaInvoicesTable();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Conversion Failed',
                            text: res.message || 'Unable to convert PI to Order'
                        });
                    }
                }).fail(function (xhr) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Conversion Failed',
                        text: xhr.responseJSON?.message || 'The Sales Order conversion request failed. Please refresh and try again.'
                    });
                }).always(function () {
                    $button.prop('disabled', false).html(originalHtml);
                });
            }
        });
    });
    function importPiRows(button) {
        if (!button) button = document.getElementById('piImportButton');
        if (button) {
            button.disabled = true;
            button.innerHTML = '<i class="ti ti-loader-2 animate-spin text-lg"></i> Syncing...';
        }
        $.post('syncAjax.php', {
            action: 'triggerEntitySync',
            entity: 'pi',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || ''
        }, null, 'json').done(function(response) {
            if (window.toastr) {
                if (response.success || response.status === 'success') toastr.success(response.message || 'Website PI sync completed.');
                else toastr.error(response.message || 'Website PI sync failed.');
            } else {
                alert(response.message || 'Website PI sync completed.');
            }
            loadProformaInvoicesTable(1);
        }).fail(function(xhr) {
            const msg = xhr && xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'PI sync failed.';
            if (window.toastr) toastr.error(msg);
            else alert(msg);
        }).always(function() {
            if (button) {
                button.disabled = false;
                button.innerHTML = '<i class="ti ti-refresh text-lg"></i>Sync Website';
            }
        });
    }

    function viewPiDetails(id) {
        $('#piModalTitle').text('PI Details');
        $('#piModalBody').html('Loading...');
        $('#piModal').modal('show');
        $.getJSON('ajax.php?action=getPiDetails', { id: id }).done(function(response) {
            if (response.status !== 'success') {
                $('#piModalBody').html('<div class="text-rose-600 font-bold">' + escapePiHtml(response.message || 'PI details are unavailable.') + '</div>');
                return;
            }
            renderPiDetails(response.data);
        }).fail(function(xhr) {
            $('#piModalBody').html('<div class="text-rose-600 font-bold">' + escapePiHtml(xhr && xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'PI details are unavailable.') + '</div>');
        });
    }

    function escapePiHtml(value) {
        return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }

    function formatPiDate(value) {
        if (!value) return '—';
        const date = new Date(String(value).slice(0, 10) + 'T00:00:00');
        return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    function formatPiMoney(value, currency) {
        return (currency || 'INR') + ' ' + Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function renderPiDetails(pi) {
        $('#piModalTitle').text('PI Details: ' + (pi.pi_number || ''));
        const card = (label, primary, secondary) => `<div class="p-3 bg-white rounded-xl border border-slate-200"><div class="text-[9px] font-black uppercase tracking-widest text-slate-400">${escapePiHtml(label)}</div><div class="mt-1 text-xs font-bold text-slate-800">${escapePiHtml(primary || '—')}</div><div class="mt-0.5 text-[10px] text-slate-500">${escapePiHtml(secondary || '')}</div></div>`;
        const summary = `<div class="grid grid-cols-1 gap-2 md:grid-cols-4">${card('Customer', pi.target_name, pi.target_email)}${card('Company', pi.target_company_name, pi.target_company_gstin ? 'GSTIN: ' + pi.target_company_gstin : '')}${card('Owner / Source', pi.owner_user_name || pi.created_by_name || 'Website', pi.owner_user_email)}${card('PI Date', formatPiDate(pi.pi_date || pi.created_at), 'Status: ' + (pi.status || 'Active'))}</div>`;
        const addresses = `<div class="mt-2 grid grid-cols-1 gap-2 md:grid-cols-2">${card('Billing Address', pi.billing_address, pi.customer_gstin ? 'Customer GSTIN: ' + pi.customer_gstin : '')}${card('Shipping Address', pi.shipping_address, pi.seller_gstin ? 'Seller GSTIN: ' + pi.seller_gstin : '')}</div>`;
        const items = Array.isArray(pi.items) ? pi.items : [];
        const itemsHtml = `<div class="mt-3 overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="w-full text-left text-xs"><thead class="border-b border-slate-100 bg-slate-50/70 text-[10px] font-bold uppercase text-slate-400"><tr><th class="p-2.5">Product</th><th class="p-2.5">SKU / Variant</th><th class="p-2.5">Qty</th><th class="p-2.5">Unit Price</th><th class="p-2.5">GST %</th><th class="p-2.5 text-right">Total</th></tr></thead><tbody class="divide-y divide-slate-100">${items.length ? items.map(item => `<tr><td class="p-2.5 font-bold text-slate-800">${escapePiHtml(item.product_name || '—')}</td><td class="p-2.5 text-slate-600">${escapePiHtml([item.sku, item.variant_name].filter(Boolean).join(' / ') || '—')}</td><td class="p-2.5 font-bold text-slate-700">${Number(item.quantity || 0)}</td><td class="p-2.5 text-slate-600">${formatPiMoney(item.unit_price, pi.currency)}</td><td class="p-2.5 text-slate-600">${Number(item.gst_rate || 0).toFixed(2)}%</td><td class="p-2.5 text-right font-bold text-slate-900">${formatPiMoney(item.line_total, pi.currency)}</td></tr>`).join('') : '<tr><td colspan="6" class="p-4 text-center text-slate-400">No synchronized line items.</td></tr>'}</tbody></table></div>`;
        const totals = `<div class="mt-2 grid grid-cols-2 gap-2 md:grid-cols-4">${card('Subtotal', formatPiMoney(pi.subtotal, pi.currency), '')}${card('Tax', formatPiMoney(pi.tax_amount, pi.currency), '')}${card('Discount', formatPiMoney(pi.discount_amount, pi.currency), '')}${card('Grand Total', formatPiMoney(pi.total_amount, pi.currency), 'Currency: ' + (pi.currency || 'INR'))}</div>`;
        $('#piModalBody').html(summary + addresses + itemsHtml + totals);
    }

    $(document).on('submit', '#piRequestsExportForm', function (e) {
        e.preventDefault();
        if ($('#piRequestsExportForm .column-filter:checked').length === 0) {
            if (window.toastr) toastr.error('Select at least one column to export.');
            else alert('Select at least one column to export.');
            return;
        }
        const search = $('#searchPORaw').val() || '';
        const formData = new FormData(this);
        formData.append('exportPiRequests', '1');
        formData.append('search', search);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
        const $submitBtn = $('#piRequestsExportForm button[type="submit"]');
        $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Exporting...');

        $.ajax({
            url: 'exportajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                if (response.success === 'success' || response.status === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                    if (window.toastr) toastr.success(response.message);
                    else alert(response.message);
                } else {
                    if (window.toastr) toastr.error(response.message);
                    else alert(response.message);
                }
            },
            error: function () {
                if (window.toastr) toastr.error('Server error occurred.');
                else alert('Server error occurred.');
            },
            complete: function () {
                $submitBtn.prop('disabled', false).html('<i class="ti ti-download text-base"></i> Export');
            }
        });
    });

    $(document).on('click', '#piRequestsExportForm .export-type-item', function () {
        const val = $(this).data('val');
        $('#exportTypeText').text($(this).text());
        $('#exportTypeSelect').val(val);
    });

    $(document).on('click', '#piDeselectAllColumnsBtn', function () {
        const allCheckboxes = $('#piRequestsExportForm .column-filter');
        const shouldSelect = allCheckboxes.filter(':checked').length === 0;
        allCheckboxes.prop('checked', shouldSelect).trigger('change');
    });

    $(document).on('change', '#piRequestsExportForm .column-filter', function () {
        const anySelected = $('#piRequestsExportForm .column-filter:checked').length > 0;
        $('#piDeselectAllColumnsBtn').text(anySelected ? 'Deselect All' : 'Select All');
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });
</script>
<?php endSection(); ?>
