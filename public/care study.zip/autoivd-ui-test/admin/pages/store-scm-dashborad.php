<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="row col-md-12" id="dashboard"></div>   
</div>

<?php startSection('scripts'); ?>
<script>
    // Write your script here
    function loadDashboardData() {
        $('#dashboard').html();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadEmployeesDashboard: 'loadEmployeesDashboard'
            },
            success: function(response) {
                $('#dashboard').html(response.data || '');
            },
            error: function() {
                $('#dashboard').html('');
            }
        });
    }
    $(document).ready(function(){
        loadDashboardData();
    });
</script>
<?php endSection(); ?>
