<?php
/**
 * Website Quiz leads replicated into ERP as a one-way activity feed.
 * Question Mapping remains Website-only.
 */
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$quizCsrfToken = (string) $_SESSION['csrf_token'];
?>
<style>
    .quiz-feed-page { color: var(--ui-text, #263b30); }
    .quiz-feed-page .quiz-control { height: 38px; border: 1px solid #dfe8e2; border-radius: 8px; background: #fff; color: #4b5e53; font-size: 11px; font-weight: 700; outline: none; }
    .quiz-feed-page .quiz-control:focus { border-color: var(--appearance-accent, #167043); box-shadow: 0 0 0 3px color-mix(in srgb, var(--appearance-accent, #167043) 12%, transparent); }
    .quiz-feed-page .quiz-kpi { min-height: 80px; border: 1px solid var(--color-primary-100, #dfe8e2); border-radius: 12px; background: #fff; padding: 14px 16px; box-shadow: 0 5px 18px rgba(0, 0, 0, .06); }
    .quiz-feed-page .quiz-kpi--distribution { background: var(--color-primary-900, #062d1c); color: #fff; }
    .quiz-feed-page .quiz-panel { overflow: hidden; border: 1px solid #e1eae4; border-radius: 14px; background: #fff; box-shadow: 0 6px 22px rgba(0, 0, 0, .06); }
    .quiz-feed-page .quiz-table { width: 100%; min-width: 780px; border-collapse: collapse; }
    .quiz-feed-page .quiz-table th { padding: 12px 14px; border-bottom: 1px solid #e7eee9; background: #fbfdfc; color: #89958e; font-size: 9px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; }
    .quiz-feed-page .quiz-table td { padding: 12px 14px; border-bottom: 1px solid #edf2ef; color: #4d5d54; font-size: 11px; vertical-align: middle; }
    .quiz-feed-page .quiz-table tbody tr { cursor: pointer; }
    .quiz-feed-page .quiz-table tbody tr:hover { background: #fbfdfc; }
    .quiz-feed-page .quiz-avatar { display: inline-flex; width: 28px; height: 28px; align-items: center; justify-content: center; border-radius: 999px; background: #e9efff; color: #2563eb; font-size: 9px; font-weight: 900; }
    .quiz-feed-page .quiz-pill { display: inline-flex; align-items: center; gap: 5px; border-radius: 999px; padding: 4px 8px; font-size: 9px; font-weight: 900; text-transform: uppercase; }
    .quiz-feed-page .quiz-page-btn { display: inline-flex; width: 30px; height: 30px; align-items: center; justify-content: center; border: 1px solid #dde6e0; border-radius: 7px; background: #fff; color: #64736b; font-size: 10px; font-weight: 900; }
    .quiz-feed-page .quiz-page-btn.is-active { border-color: var(--appearance-accent, #166534); background: var(--appearance-accent, #166534); color: #fff; }
    .quiz-feed-page .quiz-page-btn:disabled { opacity: .4; }
    .quiz-detail-modal .modal-dialog { max-width: 860px; }
    .quiz-detail-modal .modal-content { overflow: hidden; border: 0; border-radius: 16px; box-shadow: 0 25px 75px rgba(0, 0, 0, .24); }
    .quiz-detail-modal .quiz-detail-header { display: flex; align-items: flex-start; justify-content: space-between; padding: 18px 20px; border-bottom: 1px solid #e7eee9; }
    .quiz-detail-modal .quiz-detail-body { max-height: calc(100vh - 180px); overflow-y: auto; padding: 18px; background: #fbfdfc; }
    .quiz-detail-modal .quiz-detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; }
    .quiz-detail-modal .quiz-detail-field { min-height: 66px; border: 1px solid #eef2ef; border-radius: 11px; padding: 11px; background: #fff; }
    .quiz-detail-modal .quiz-detail-field--wide { grid-column: 1 / -1; }
    .quiz-detail-modal .quiz-detail-label { display: block; color: #8b9790; font-size: 8px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; }
    .quiz-detail-modal .quiz-detail-value { display: block; margin-top: 5px; color: #35493e; font-size: 11px; font-weight: 800; }
    .quiz-detail-modal .quiz-insights { margin-top: 12px; border: 1px solid var(--color-primary-200, #cfeadb); border-radius: 12px; padding: 13px; background: var(--color-primary-50, #f5fcf7); }
    .quiz-detail-modal .quiz-insight-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 10px; }
    .quiz-detail-modal .quiz-answer { border: 1px solid #e4ebe7; border-radius: 11px; padding: 12px; background: #fff; }
    .quiz-detail-modal .quiz-answer + .quiz-answer { margin-top: 9px; }
    .quiz-detail-modal .quiz-answer-choice { margin-top: 8px; border-radius: 8px; padding: 8px 10px; background: #f5f8f6; color: #52645a; font-size: 10px; font-weight: 700; }
    @media (max-width: 767.98px) {
        .quiz-detail-modal .quiz-detail-grid, .quiz-detail-modal .quiz-insight-grid { grid-template-columns: 1fr; }
        .quiz-detail-modal .quiz-detail-field--wide { grid-column: auto; }
    }
</style>

<div class="quiz-feed-page container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1 class="m-0 text-2xl font-extrabold tracking-tight text-slate-800">Quiz Management</h1>
            <p class="mb-0 mt-1 text-sm text-slate-500">Manage Website diagnostic quiz leads synchronized into ERP.</p>
        </div>
        <div class="text-xs font-bold uppercase tracking-widest" style="color: var(--appearance-accent, #166534);"><i class="ti ti-shield-check mr-1"></i>Quiz Activity Feed</div>
    </div>

    <div class="mb-5 grid grid-cols-1 gap-3 lg:grid-cols-2">
        <div class="quiz-kpi">
            <div class="text-[9px] font-black uppercase tracking-widest text-slate-400">Total leads</div>
            <div id="quizTotalLeads" class="mt-2 text-2xl font-black text-slate-800">0</div>
        </div>
        <div class="quiz-kpi quiz-kpi--distribution">
            <div class="text-[9px] font-black uppercase tracking-widest text-emerald-300">Segment distribution</div>
            <div class="mt-3 grid grid-cols-2 gap-5">
                <div><div class="flex justify-between text-[9px] font-black"><span>B2B</span><span id="quizB2bPercent">0%</span></div><div class="mt-2 h-1 overflow-hidden rounded-full bg-white/15"><div id="quizB2bBar" class="h-full bg-emerald-400" style="width:0%"></div></div></div>
                <div><div class="flex justify-between text-[9px] font-black"><span>B2C</span><span id="quizB2cPercent">0%</span></div><div class="mt-2 h-1 overflow-hidden rounded-full bg-white/15"><div id="quizB2cBar" class="h-full bg-blue-400" style="width:0%"></div></div></div>
            </div>
        </div>
    </div>

    <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                <input type="hidden" id="quizPageSize" value="10">

                <!-- Per-page dropdown -->
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="quizPerPageText" class="whitespace-nowrap">10 per page</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="quiz-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                        <li><a class="quiz-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 per page</a></li>
                        <li><a class="quiz-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 per page</a></li>
                        <li><a class="quiz-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 per page</a></li>
                        <li><a class="quiz-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 per page</a></li>
                    </ul>
                </div>

                <!-- Search input -->
                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="ti ti-search text-lg text-slate-400"></i>
                    </div>
                    <input type="text" id="quizSearchInput" class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" placeholder="Search leads...">
                </div>

                <!-- Segment dropdown -->
                <input type="hidden" id="quizSegmentFilter" value="">
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="quizSegmentText" class="whitespace-nowrap">All segments</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="quiz-segment-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="">All segments</a></li>
                        <li><a class="quiz-segment-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="b2b">B2B</a></li>
                        <li><a class="quiz-segment-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="b2c">B2C</a></li>
                        <li><a class="quiz-segment-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="common">Common</a></li>
                    </ul>
                </div>

                <!-- Status dropdown -->
                <input type="hidden" id="quizStatusFilter" value="">
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="quizStatusText" class="whitespace-nowrap">All statuses</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="">All statuses</a></li>
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="submitted">Submitted</a></li>
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="contacted">Contacted</a></li>
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="discarded">Discarded</a></li>
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="new">New</a></li>
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="converted">Converted</a></li>
                        <li><a class="quiz-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="lost">Lost</a></li>
                    </ul>
                </div>

                <div class="ml-auto flex flex-wrap items-center gap-2">
                    <button type="button" id="quizExportButton" data-bs-toggle="modal" data-bs-target="#exportModal" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                    <button type="button" id="quizImportButton" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors focus:outline-none focus:ring-2" style="background: var(--appearance-accent, #166534);">
                        <i class="ti ti-download text-lg"></i>Import
                    </button>
                </div>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="quiz-table">
                <thead><tr><th>Name</th><th>Email</th><th>Segment</th><th>Score</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
                <tbody id="quizTableBody"><tr><td colspan="6" class="!py-10 text-center !text-slate-400">Loading quiz leads...</td></tr></tbody>
            </table>
        </div>
        <div class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/50 px-4 py-3 text-xs font-bold text-slate-500"><span id="quizShowingText">Showing 0 entries</span><div id="quizPagination" class="flex items-center gap-1"></div></div>
    </div>
</div>

<div class="modal fade quiz-detail-modal" id="quizLeadModal" tabindex="-1" aria-labelledby="quizLeadModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="quiz-detail-header">
                <div><h5 id="quizLeadModalTitle" class="m-0 text-lg font-extrabold text-slate-800">Lead Details</h5><p class="mb-0 mt-1 text-[9px] font-black uppercase tracking-widest text-blue-600">Diagnostic quiz participant</p></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="quiz-detail-body">
                <div id="quizDetailFields" class="quiz-detail-grid"></div>
                <section id="quizProfilingSection" class="quiz-insights d-none"><div class="text-[9px] font-black uppercase tracking-widest" style="color: var(--appearance-accent, #166534);">Profiling Insights Summary</div><div id="quizProfilingInsights" class="quiz-insight-grid"></div></section>
                <section class="mt-4"><h6 class="mb-3 text-[10px] font-black uppercase tracking-widest text-slate-500">Question &amp; Answer Details</h6><div id="quizAnswerDetails"></div></section>
            </div>
            <div class="flex flex-wrap items-center justify-end gap-2 border-t border-slate-100 bg-white px-5 py-3">
                <select id="quizDetailStatus" class="quiz-control px-3"><option value="submitted">Submitted</option><option value="contacted">Contacted</option><option value="discarded">Discarded</option><option value="new">New</option><option value="converted">Converted</option><option value="lost">Lost</option></select>
                <button type="button" id="quizSaveStatus" class="inline-flex h-9 items-center rounded-lg border px-3 text-[10px] font-black" style="border-color: var(--appearance-accent, #166534); color: var(--appearance-accent, #166534); background: #fff;">Save Status</button>
                <button type="button" class="inline-flex h-9 items-center rounded-lg px-4 text-[10px] font-black text-white" style="background: var(--appearance-accent, #166534);" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
const quizCsrfToken = <?= json_encode($quizCsrfToken, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
let quizRows = [];
let quizFilteredRows = [];
let quizCurrentPage = 1;
let quizCurrentLeadId = 0;

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('quizSearchInput').addEventListener('input', function() { quizCurrentPage = 1; renderQuizFeed(); });

    // Per-page dropdown items
    document.querySelectorAll('.quiz-per-page-item').forEach(function(item) {
        item.addEventListener('click', function() {
            var val = this.dataset.val;
            document.getElementById('quizPageSize').value = val;
            document.getElementById('quizPerPageText').textContent = Number(val) >= 100000000 ? 'All items' : val + ' per page';
            quizCurrentPage = 1;
            renderQuizFeed();
        });
    });

    // Segment dropdown items
    document.querySelectorAll('.quiz-segment-item').forEach(function(item) {
        item.addEventListener('click', function() {
            document.getElementById('quizSegmentFilter').value = this.dataset.val;
            document.getElementById('quizSegmentText').textContent = this.textContent;
            quizCurrentPage = 1;
            renderQuizFeed();
        });
    });

    // Status dropdown items
    document.querySelectorAll('.quiz-status-item').forEach(function(item) {
        item.addEventListener('click', function() {
            document.getElementById('quizStatusFilter').value = this.dataset.val;
            document.getElementById('quizStatusText').textContent = this.textContent;
            quizCurrentPage = 1;
            renderQuizFeed();
        });
    });
    document.getElementById('quizPagination').addEventListener('click', function(event) {
        const button = event.target.closest('[data-quiz-page]');
        if (!button || button.disabled) return;
        quizCurrentPage = Number(button.dataset.quizPage);
        renderQuizFeed();
    });
    document.getElementById('quizImportButton').addEventListener('click', function() { runQuizImport(this); });
    document.getElementById('quizSaveStatus').addEventListener('click', saveQuizLeadStatus);
    loadQuizGrid();
});

function loadQuizGrid() {
    $('#quizTableBody').html('<tr><td colspan="6" class="!py-10 text-center !text-slate-400">Loading quiz leads...</td></tr>');
    $.getJSON('ajax.php?action=loadQuizGrid').done(function(response) {
        quizRows = response.status === 'success' && Array.isArray(response.data) ? response.data : [];
        updateQuizStats();
        quizCurrentPage = 1;
        renderQuizFeed();
    }).fail(function(xhr) {
        $('#quizTableBody').html('<tr><td colspan="6" class="!py-10 text-center !text-rose-600">' + escapeQuizHtml(responseMessage(xhr, 'Failed to load quiz leads.')) + '</td></tr>');
    });
}

function updateQuizStats() {
    const total = quizRows.length;
    const b2b = quizRows.filter(row => quizSegment(row) === 'b2b').length;
    const b2c = quizRows.filter(row => quizSegment(row) === 'b2c').length;
    const b2bPercent = total ? Math.round((b2b / total) * 100) : 0;
    const b2cPercent = total ? Math.round((b2c / total) * 100) : 0;
    $('#quizTotalLeads').text(total.toLocaleString('en-IN'));
    $('#quizB2bPercent').text(b2b + ' (' + b2bPercent + '%)');
    $('#quizB2cPercent').text(b2c + ' (' + b2cPercent + '%)');
    $('#quizB2bBar').css('width', b2bPercent + '%');
    $('#quizB2cBar').css('width', b2cPercent + '%');
}

function renderQuizFeed() {
    const search = String($('#quizSearchInput').val() || '').trim().toLowerCase();
    const segment = String($('#quizSegmentFilter').val() || '').toLowerCase();
    const status = String($('#quizStatusFilter').val() || '').toLowerCase();
    const pageSize = Number($('#quizPageSize').val() || 10);
    quizFilteredRows = quizRows.filter(function(row) {
        const profile = quizProfile(row);
        const haystack = [row.participant_first_name, row.participant_last_name, row.participant_email, row.participant_phone, row.reward_coupon_code, profile.profile_alignment_score].join(' ').toLowerCase();
        return (!search || haystack.includes(search)) && (!segment || quizSegment(row) === segment) && (!status || String(row.lead_status || '').toLowerCase() === status);
    });
    const pages = Math.max(1, Math.ceil(quizFilteredRows.length / pageSize));
    quizCurrentPage = Math.min(quizCurrentPage, pages);
    const start = (quizCurrentPage - 1) * pageSize;
    renderQuizTable(quizFilteredRows.slice(start, start + pageSize));
    renderQuizPagination(pages);
    const first = quizFilteredRows.length ? start + 1 : 0;
    const last = Math.min(start + pageSize, quizFilteredRows.length);
    $('#quizShowingText').text('Showing ' + first + '-' + last + ' of ' + quizFilteredRows.length + ' entries');
}

function renderQuizTable(rows) {
    if (!rows.length) {
        $('#quizTableBody').html('<tr><td colspan="6" class="!py-10 text-center !text-slate-400">No quiz leads match the selected filters.</td></tr>');
        return;
    }
    $('#quizTableBody').html(rows.map(function(row) {
        const fullName = [row.participant_first_name, row.participant_last_name].filter(Boolean).join(' ') || 'Unnamed lead';
        const initials = fullName.split(/\s+/).slice(0, 2).map(part => part.charAt(0)).join('').toUpperCase();
        const segment = quizSegment(row).toUpperCase();
        const profile = quizProfile(row);
        const score = profile.profile_alignment_score || (Number(row.total_questions || 0) ? Number(row.total_correct_answers || 0) + '/' + Number(row.total_questions || 0) : '—');
        const status = String(row.lead_status || 'submitted').toLowerCase();
        return `<tr onclick="viewQuizLead(${Number(row.id)})">
            <td><div class="flex items-center gap-2"><span class="quiz-avatar">${escapeQuizHtml(initials)}</span><span class="font-extrabold text-slate-800">${escapeQuizHtml(fullName)}</span></div></td>
            <td class="text-slate-500">${escapeQuizHtml(row.participant_email || '—')}</td>
            <td><span class="quiz-pill ${segment === 'B2B' ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-600'}">${escapeQuizHtml(segment)}</span></td>
            <td class="font-extrabold text-slate-700">${escapeQuizHtml(score)}</td>
            <td>${quizStatusPill(status)}</td>
            <td class="text-right"><button type="button" onclick="event.stopPropagation();viewQuizLead(${Number(row.id)})" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-emerald-700 hover:bg-emerald-50" title="View lead details"><i class="ti ti-eye"></i></button></td>
        </tr>`;
    }).join(''));
}

function renderQuizPagination(totalPages) {
    let html = `<button class="quiz-page-btn" data-quiz-page="${Math.max(1, quizCurrentPage - 1)}" ${quizCurrentPage === 1 ? 'disabled' : ''}><i class="ti ti-chevron-left"></i></button>`;
    const start = Math.max(1, quizCurrentPage - 2);
    const end = Math.min(totalPages, start + 4);
    for (let page = start; page <= end; page++) html += `<button class="quiz-page-btn ${page === quizCurrentPage ? 'is-active' : ''}" data-quiz-page="${page}">${page}</button>`;
    html += `<button class="quiz-page-btn" data-quiz-page="${Math.min(totalPages, quizCurrentPage + 1)}" ${quizCurrentPage === totalPages ? 'disabled' : ''}><i class="ti ti-chevron-right"></i></button>`;
    $('#quizPagination').html(html);
}

function viewQuizLead(id) {
    quizCurrentLeadId = Number(id);
    $('#quizDetailFields').html('<div class="quiz-detail-field quiz-detail-field--wide">Loading lead details...</div>');
    $('#quizLeadModal').modal('show');
    $.getJSON('ajax.php?action=getQuizDetails', { id: id }).done(function(response) {
        if (response.status !== 'success') {
            $('#quizDetailFields').html('<div class="quiz-detail-field quiz-detail-field--wide text-rose-600">' + escapeQuizHtml(response.message || 'Lead details are unavailable.') + '</div>');
            return;
        }
        renderQuizDetails(response.data);
    }).fail(function(xhr) {
        $('#quizDetailFields').html('<div class="quiz-detail-field quiz-detail-field--wide text-rose-600">' + escapeQuizHtml(responseMessage(xhr, 'Lead details are unavailable.')) + '</div>');
    });
}

function renderQuizDetails(lead) {
    const fullName = [lead.participant_first_name, lead.participant_last_name].filter(Boolean).join(' ') || 'Unnamed lead';
    const profile = quizProfile(lead);
    const fields = [
        ['Name', fullName], ['Email', lead.participant_email || '—'], ['Phone', lead.participant_phone || '—'],
        ['Segment', quizSegment(lead).toUpperCase()], ['Coupon', lead.reward_coupon_code || '—'],
        ['Profile Alignment', profile.profile_alignment_score || (Number(lead.total_questions || 0) ? Number(lead.total_correct_answers || 0) + '/' + Number(lead.total_questions || 0) : '—')],
        ['Submitted', formatQuizDate(lead.submitted_at || lead.created_at), true]
    ];
    $('#quizDetailFields').html(fields.map(field => `<div class="quiz-detail-field ${field[2] ? 'quiz-detail-field--wide' : ''}"><span class="quiz-detail-label">${escapeQuizHtml(field[0])}</span><span class="quiz-detail-value">${escapeQuizHtml(field[1])}</span></div>`).join(''));
    $('#quizDetailStatus').val(String(lead.lead_status || 'submitted').toLowerCase());
    const insightFields = [['Diagnostic Fit', profile.diagnostic_fit], ['Procurement Efficiency', profile.procurement_efficiency], ['Product Strategy', profile.product_strategy]];
    const hasInsights = insightFields.some(field => field[1]);
    $('#quizProfilingSection').toggleClass('d-none', !hasInsights);
    $('#quizProfilingInsights').html(insightFields.map(field => `<div><span class="quiz-detail-label">${escapeQuizHtml(field[0])}</span><span class="quiz-detail-value !text-[10px]">${escapeQuizHtml(field[1] || '—')}</span></div>`).join(''));
    const answers = Array.isArray(lead.answers) ? lead.answers : [];
    $('#quizAnswerDetails').html(answers.length ? answers.map(function(answer, index) {
        const phase = answer.phase_title ? ' · ' + escapeQuizHtml(answer.phase_title) : '';
        const selected = (answer.selected_label ? escapeQuizHtml(answer.selected_label) + ': ' : '') + escapeQuizHtml(answer.selected_option || '—');
        return `<div class="quiz-answer"><div class="quiz-detail-label">Question ${index + 1}${phase}</div><div class="mt-1 text-[11px] font-extrabold leading-5 text-slate-700">${escapeQuizHtml(answer.question_text || 'Question unavailable')}</div><div class="quiz-answer-choice">Selected ${selected}</div></div>`;
    }).join('') : '<div class="quiz-answer text-[10px] font-semibold text-slate-500">No submitted answers were available in the synchronized record.</div>');
}

function saveQuizLeadStatus() {
    if (!quizCurrentLeadId) return;
    const button = this;
    button.disabled = true;
    $.ajax({ url: 'ajax.php?action=updateQuizLeadStatus', type: 'POST', dataType: 'json', data: { id: quizCurrentLeadId, lead_status: $('#quizDetailStatus').val(), csrf_token: quizCsrfToken } })
        .done(function(response) { if (response.status !== 'success') { alert(response.message || 'Status update failed.'); return; } $('#quizLeadModal').modal('hide'); loadQuizGrid(); })
        .fail(function(xhr) { alert(responseMessage(xhr, 'Status update failed.')); })
        .always(function() { button.disabled = false; });
}

function runQuizImport(button) {
    button.disabled = true;
    button.innerHTML = '<i class="ti ti-loader-2 animate-spin"></i>Importing';
    $.post('syncAjax.php', { action: 'triggerEntitySync', entity: 'quiz', csrf_token: quizCsrfToken }, null, 'json')
        .done(function(response) {
            alert(response.message || (response.success ? 'Quiz import completed.' : 'Quiz import failed.'));
            if (response.success === true || response.status === 'success') loadQuizGrid();
        })
        .fail(function(xhr) { alert(responseMessage(xhr, 'Quiz import failed.')); })
        .always(function() { button.disabled = false; button.innerHTML = '<i class="ti ti-download"></i>Import'; });
}

function exportQuizLeads() {
    const rows = [['Name','Email','Phone','Segment','Score','Coupon','Status','Submitted']];
    quizFilteredRows.forEach(function(row) { const profile = quizProfile(row); rows.push([[row.participant_first_name,row.participant_last_name].filter(Boolean).join(' '),row.participant_email || '',row.participant_phone || '',quizSegment(row).toUpperCase(),profile.profile_alignment_score || row.score_percentage || '',row.reward_coupon_code || '',row.lead_status || '',row.submitted_at || row.created_at || '']); });
    downloadQuizCsv('quiz-lead-activity.csv', rows);
}

function downloadQuizCsv(filename, rows) {
    const csv = rows.map(row => row.map(value => '"' + String(value == null ? '' : value).replace(/"/g, '""') + '"').join(',')).join('\r\n');
    const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8;'})); link.download = filename; document.body.appendChild(link); link.click(); URL.revokeObjectURL(link.href); link.remove();
}

function quizProfile(row) { if (row && typeof row.profiling_data === 'object' && row.profiling_data) return row.profiling_data; try { return JSON.parse(row.profiling_data || '{}') || {}; } catch (error) { return {}; } }
function quizSegment(row) { const type = String(row.user_type || 'common').toLowerCase(); return ['b2b','lab','dealer'].includes(type) ? 'b2b' : (type === 'common' ? 'common' : 'b2c'); }
function quizStatusPill(status) { const styles = status === 'contacted' || status === 'converted' ? 'bg-blue-50 text-blue-700' : (status === 'discarded' || status === 'lost' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'); return `<span class="quiz-pill ${styles}"><span class="h-1.5 w-1.5 rounded-full bg-current"></span>${escapeQuizHtml(status || 'submitted')}</span>`; }
function formatQuizDate(value) { if (!value) return '—'; const date = new Date(String(value).replace(' ', 'T')); return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('en-IN', {day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}); }
function responseMessage(xhr, fallback) { return xhr && xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : fallback; }
function escapeQuizHtml(value) { return String(value == null ? '' : value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }

$(document).on('submit', '#quizActivityExportForm', function (e) {
    e.preventDefault();
    const search = $('#quizSearchInput').val() || '';
    const formData = new FormData(this);
    formData.append('exportQuizActivityFeed', '1');
    formData.append('search', search);

    $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    const $submitBtn = $('#quizActivityExportForm button[type="submit"]');
    $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Exporting...');

    $.ajax({
        url: 'exportajax.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (response) {
            if (response.success === 'success') {
                $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                if (window.toastr) toastr.success(response.message);
                else alert(response.message);
            } else {
                if (window.toastr) toastr.error(response.message);
                else alert(response.message);
            }
        },
        error: function () {
            if (window.toastr) toastr.error('Server error occurred.');
            else alert('Server error occurred.');
        },
        complete: function () {
            $submitBtn.prop('disabled', false).html('<i class="ti ti-download text-base"></i> Export');
        }
    });
});

$(document).on('click', '#quizActivityExportForm .export-type-item', function () {
    const val = $(this).data('val');
    $('#exportTypeText').text($(this).text());
    $('#exportTypeSelect').val(val);
});

$(document).on('click', '#quizDeselectAllColumnsBtn', function () {
    const isAllSelected = $('#quizActivityExportForm .column-filter:checked').length === $('#quizActivityExportForm .column-filter').length;
    if (isAllSelected) {
        $('#quizActivityExportForm .column-filter').prop('checked', false);
        $(this).text('Select All');
    } else {
        $('#quizActivityExportForm .column-filter').prop('checked', true);
        $(this).text('Deselect All');
    }
});
</script>
<?php endSection(); ?>

<!-- Export Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="quizActivityExportForm">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                        <div class="dropdown w-full">
                            <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                            <button type="button" id="quizDeselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2">
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Lead ID" checked /><span class="text-sm font-medium text-slate-700">Lead ID</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Full Name" checked /><span class="text-sm font-medium text-slate-700">Full Name</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Email" checked /><span class="text-sm font-medium text-slate-700">Email</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Phone" checked /><span class="text-sm font-medium text-slate-700">Phone</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Segment" checked /><span class="text-sm font-medium text-slate-700">Segment</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Score" checked /><span class="text-sm font-medium text-slate-700">Score</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Status" checked /><span class="text-sm font-medium text-slate-700">Status</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Submitted At" checked /><span class="text-sm font-medium text-slate-700">Submitted At</span></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none !rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="inline-flex h-10 w-28 items-center justify-center gap-2 !rounded-xl text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534);"><i class="ti ti-download text-base"></i> Export</button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="hidden d-none inline-flex h-10 w-auto items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534); display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                </div>
            </form>
        </div>
    </div>
</div>
