<?php
$currentRoleId = (int) ($_SESSION['role_id'] ?? 0);
$canCreateCompleteRole = roleHasPermission($currentRoleId, 'roles_add')
    && roleHasPermission($currentRoleId, 'role_has_permission_add')
    && roleHasPermission($currentRoleId, 'user_edit');
$canViewRolePermissions = roleHasPermission($currentRoleId, 'role_has_permission_menu_list');
?>
<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage users, roles, account status, and access actions</p>
        </div>
    </div>

    <div class="users-page-toolbar mb-5" style="display: grid; grid-template-columns: minmax(220px, 1fr) auto auto auto auto; align-items: center; gap: 0.75rem; max-width: 100%;">
        <div class="relative h-10 w-full">
            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3" style="color: #94a3b8; font-size: 0.95rem;">
                <i class="ti ti-search" aria-hidden="true"></i>
            </div>
            <input type="text" id="searchUsersTop"
                class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                placeholder="Search roles by name or description...">
        </div>

        <div class="flex items-center gap-2" style="white-space: nowrap;">
            <span class="text-sm font-bold text-slate-500">Show</span>
            <div class="dropdown shrink-0">
                <button
                    class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                    type="button" data-bs-toggle="dropdown">
                    <span id="usersPerPageTopText" class="whitespace-nowrap">10 items</span>
                    <span style="color: #64748b; font-size: 0.75rem;">v</span>
                </button>
                <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                    <li><a class="users-top-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                    <li><a class="users-top-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                    <li><a class="users-top-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                    <li><a class="users-top-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                    <li><a class="users-top-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                    <li><a class="users-top-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                </ul>
            </div>
        </div>

        <div class="dropdown shrink-0">
            <button
                class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                type="button" data-bs-toggle="dropdown" aria-label="Sort roles">
                <i class="ti ti-arrows-sort" aria-hidden="true"></i>
                <span id="roleSortLabel" class="whitespace-nowrap">Name A-Z</span>
                <i class="ti ti-chevron-down text-sm text-slate-400" aria-hidden="true"></i>
            </button>
            <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                <li><button type="button" class="role-sort-item block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50" data-sort="name_asc">Name A-Z</button></li>
                <li><button type="button" class="role-sort-item block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50" data-sort="name_desc">Name Z-A</button></li>
                <li><button type="button" class="role-sort-item block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50" data-sort="status">Status</button></li>
                <li><button type="button" class="role-sort-item block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50" data-sort="department">Department</button></li>
                <li><button type="button" class="role-sort-item block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50" data-sort="users_desc">Most Users</button></li>
                <li><button type="button" class="role-sort-item block w-full rounded-xl px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50" data-sort="permissions_desc">Most Permissions</button></li>
            </ul>
        </div>

        <?php if ($canCreateCompleteRole) { ?>
            <button type="button" id="openCreateRoleWorkflowBtn"
                style="display: inline-flex; height: 44px; align-items: center; justify-content: center; gap: 0.5rem; white-space: nowrap; border: 1px solid var(--appearance-accent, #064e3b); border-radius: 999px; background: var(--appearance-accent, #064e3b); padding: 0 1.25rem; color: #ffffff; font-size: 0.875rem; font-weight: 800; box-shadow: 0 4px 12px rgba(15, 23, 42, 0.08);">
                <i class="ti ti-plus" aria-hidden="true"></i>
                Create New Role
            </button>
        <?php } ?>

        <?php if (roleHasPermission($_SESSION['role_id'], 'user_add')) { ?>
            <button type="button"
                class="shadow-sm"
                style="display: inline-flex; height: 44px; align-items: center; justify-content: center; gap: 0.5rem; white-space: nowrap; border: 1px solid var(--ui-border, #d9dfda); border-radius: 999px; background: var(--ui-surface, #ffffff); padding: 0 1.25rem; color: var(--ui-text, #1a1e1a); font-size: 0.875rem; font-weight: 800;"
                data-bs-toggle="modal" data-bs-target="#animationModal">
                <i class="ti ti-user-plus" aria-hidden="true"></i>
                Create New User
            </button>
        <?php } ?>
    </div>

    <div class="grid gap-4 md:grid-cols-3">
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="mb-1 text-sm font-semibold text-slate-500">Total Users</p>
            <div class="flex items-end gap-2">
                <span class="text-4xl font-extrabold leading-none text-emerald-800" id="totalUsersOverview">0</span>
                <span class="mb-1 text-sm font-bold text-slate-700">Users</span>
            </div>
        </div>
        <button type="button"
            class="group rounded-xl border border-slate-200 bg-white p-5 text-left shadow-sm transition-colors hover:border-emerald-200 hover:bg-emerald-50/40"
            data-bs-toggle="modal" data-bs-target="#manageUsersModal">
            <span class="mb-3 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-800 ring-1 ring-emerald-100" style="font-size: 1rem; font-weight: 800;">
                <i class="ti ti-users" aria-hidden="true"></i>
            </span>
            <span class="block text-sm font-extrabold text-slate-900">Manage All Users</span>
            <span class="mt-1 block text-xs font-semibold text-slate-500">Open the existing users table</span>
        </button>
    </div>

    <style>
        .users-role-widget-section {
            margin-top: 18px;
        }

        .users-role-view-tabs {
            display: inline-flex;
            gap: 3px;
            margin-top: 18px;
            padding: 3px;
            border: 1px solid var(--ui-border, #d9dfda);
            border-radius: 7px;
            background: var(--ui-surface-muted, #f7f8f7);
        }

        .users-role-view-tab {
            display: inline-flex;
            min-height: 34px;
            align-items: center;
            gap: 7px;
            border: 0;
            border-radius: 5px;
            background: transparent;
            color: var(--ui-text-muted, #626b64);
            padding: 6px 12px;
            font-size: 0.72rem;
            font-weight: 800;
        }

        .users-role-view-tab.is-active {
            background: var(--ui-surface, #ffffff);
            color: var(--appearance-accent, #1a4d2e);
            box-shadow: 0 1px 4px rgba(15, 23, 42, 0.08);
        }

        .users-role-widget-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
        }

        .user-role-widget {
            position: relative;
            display: flex;
            width: 100%;
            min-width: 0;
            min-height: 218px;
            flex-direction: column;
            border: 1px solid var(--ui-border, #d9dfda);
            border-radius: 7px;
            background: var(--ui-surface, #ffffff);
            color: var(--ui-text, #1a1e1a) !important;
            padding: 14px;
            text-align: left;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
            transition: border-color 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
        }

        .user-role-widget.is-editable {
            cursor: pointer;
        }

        .user-role-widget.is-editable:hover,
        .user-role-widget.is-editable:focus-visible {
            border-color: color-mix(in srgb, var(--appearance-accent, #1a4d2e) 46%, var(--ui-border, #d9dfda));
            background: color-mix(in srgb, var(--appearance-accent, #1a4d2e) 3%, var(--ui-surface, #ffffff));
            box-shadow: 0 7px 18px rgba(15, 23, 42, 0.08);
            outline: none;
        }

        .user-role-widget-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
        }

        .user-role-widget-head-actions {
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .user-role-widget-delete {
            display: inline-flex;
            width: 28px;
            height: 28px;
            flex: 0 0 28px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, #dc2626 18%, var(--ui-border, #d9dfda));
            border-radius: 5px;
            background: color-mix(in srgb, #dc2626 5%, var(--ui-surface, #ffffff));
            color: #b91c1c;
            font-size: 0.82rem;
        }

        .user-role-widget-delete:hover,
        .user-role-widget-delete:focus-visible {
            border-color: #ef4444;
            background: #fef2f2;
            outline: none;
        }

        .user-role-widget-icon {
            display: inline-flex;
            width: 40px;
            height: 40px;
            flex: 0 0 40px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--appearance-accent, #1a4d2e) 18%, var(--ui-border, #d9dfda));
            border-radius: 6px;
            background: color-mix(in srgb, var(--appearance-accent, #1a4d2e) 10%, var(--ui-surface, #ffffff));
            color: var(--appearance-accent, #1a4d2e);
            font-size: 1.05rem;
        }

        .user-role-widget:nth-child(3n + 2) .user-role-widget-icon {
            background: var(--ui-surface-subtle, #eef2ef);
            color: var(--ui-text-muted, #6b706b);
        }

        .user-role-widget-count {
            display: inline-flex;
            min-height: 25px;
            align-items: center;
            border-radius: 999px;
            background: var(--ui-surface-subtle, #eef2ef);
            color: var(--ui-text-muted, #5f6962);
            padding: 4px 9px;
            font-size: 0.68rem;
            font-weight: 800;
            white-space: nowrap;
        }

        .user-role-widget-name {
            margin: 13px 0 5px;
            overflow-wrap: anywhere;
            color: var(--ui-text, #1a1e1a) !important;
            font-size: 0.82rem;
            font-weight: 800;
            line-height: 1.25rem;
        }

        .user-role-widget-description {
            display: -webkit-box;
            min-height: 3.45rem;
            margin: 0;
            overflow: hidden;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 3;
            color: var(--ui-text-muted, #626b64) !important;
            font-size: 0.72rem;
            font-weight: 600;
            line-height: 1.15rem;
        }

        .user-role-widget-footer {
            display: flex;
            min-height: 38px;
            align-items: flex-end;
            justify-content: space-between;
            gap: 10px;
            margin-top: auto;
            padding-top: 10px;
            border-top: 1px solid var(--ui-border, #d9dfda);
        }

        .user-role-widget-avatars {
            display: flex;
            min-width: 0;
            align-items: center;
        }

        .user-role-widget-avatar {
            display: inline-flex;
            width: 25px;
            height: 25px;
            align-items: center;
            justify-content: center;
            margin-left: -5px;
            border: 2px solid var(--ui-surface, #ffffff);
            border-radius: 999px;
            background: color-mix(in srgb, var(--appearance-accent, #1a4d2e) 12%, var(--ui-surface, #ffffff));
            color: var(--appearance-accent, #1a4d2e);
            font-size: 0.54rem;
            font-weight: 900;
        }

        .user-role-widget-avatar:first-child {
            margin-left: 0;
        }

        .user-role-widget-more {
            margin-left: 5px;
            color: var(--ui-text-muted, #6b706b);
            font-size: 0.62rem;
            font-weight: 800;
        }

        .user-role-widget-status {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: var(--appearance-accent, #1a4d2e);
            font-size: 0.61rem;
            font-weight: 800;
            white-space: nowrap;
        }

        .user-role-widget-status::before {
            width: 6px;
            height: 6px;
            border-radius: 999px;
            background: currentColor;
            content: "";
        }

        .user-role-widget.is-inactive {
            opacity: 0.78;
        }

        .user-role-widget.is-inactive .user-role-widget-status {
            color: #b45309;
        }

        .users-role-widget-loading,
        .users-role-widget-empty {
            display: grid;
            min-height: 150px;
            place-items: center;
            border: 1px dashed var(--ui-border, #d9dfda);
            border-radius: 7px;
            color: var(--ui-text-muted, #6b706b);
            font-size: 0.78rem;
            font-weight: 700;
        }

        .users-role-widget-pagination {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 6px;
            margin-top: 12px;
        }

        .users-role-widget-page-button {
            display: inline-flex;
            width: 34px;
            height: 34px;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--ui-border, #d9dfda);
            border-radius: 6px;
            background: var(--ui-surface, #ffffff);
            color: var(--ui-text, #1a1e1a);
            font-size: 0.69rem;
            font-weight: 800;
        }

        .users-role-widget-page-button.is-active {
            border-color: var(--appearance-accent, #1a4d2e);
            background: var(--appearance-accent, #1a4d2e);
            color: #ffffff;
        }

        .users-role-widget-page-button:disabled {
            cursor: not-allowed;
            opacity: 0.4;
        }

        .users-role-permission-table-wrap {
            margin-top: 12px;
            overflow: hidden;
            border: 1px solid var(--ui-border, #d9dfda);
            border-radius: 7px;
            background: var(--ui-surface, #ffffff);
        }

        .users-role-permission-table {
            width: 100%;
            border-collapse: collapse;
            color: var(--ui-text, #1a1e1a);
            font-size: 0.72rem;
        }

        .users-role-permission-table th,
        .users-role-permission-table td {
            padding: 11px 13px;
            border-bottom: 1px solid var(--ui-border, #d9dfda);
            text-align: left;
            vertical-align: middle;
        }

        .users-role-permission-table th {
            background: var(--ui-surface-muted, #f7f8f7);
            color: var(--ui-text-muted, #626b64);
            font-size: 0.62rem;
            font-weight: 900;
            text-transform: uppercase;
        }

        .users-role-permission-table tbody tr:last-child td {
            border-bottom: 0;
        }

        .users-role-permission-summary {
            color: var(--ui-text-muted, #626b64);
            font-weight: 600;
            line-height: 1.15rem;
        }

        .users-role-permission-edit {
            display: inline-flex;
            width: 30px;
            height: 30px;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--ui-border, #d9dfda);
            border-radius: 5px;
            background: var(--ui-surface, #ffffff);
            color: var(--appearance-accent, #1a4d2e);
        }

        #editRoleModal {
            z-index: 20030 !important;
        }

        html[data-appearance-theme="dark"] .users-role-widget-section,
        html[data-appearance-theme="dark"] #editRoleModal {
            --ui-surface: #17211d;
            --ui-surface-muted: #1d2923;
            --ui-surface-subtle: #24332b;
            --ui-border: #3a4b41;
            --ui-text: #edf5f0;
            --ui-text-muted: #a8bbb0;
        }

        #editRoleModal .modal-content,
        #editRoleModal .modal-header,
        #editRoleModal .modal-body,
        #editRoleModal .user-role-edit-footer {
            border-color: var(--ui-border, #d9dfda) !important;
            background: var(--ui-surface, #ffffff) !important;
            color: var(--ui-text, #1a1e1a) !important;
        }

        #editRoleModal .modal-header {
            background: var(--ui-surface-muted, #f7f8f7) !important;
        }

        #editRoleModal .modal-title,
        #editRoleModal .modal-body label,
        #editRoleModal .modal-body label span {
            color: var(--ui-text, #1a1e1a) !important;
        }

        #editRoleModal .modal-header p {
            color: var(--ui-text-muted, #6b706b) !important;
        }

        #editRoleModal .user-role-edit-footer button[data-bs-dismiss="modal"] {
            border-color: var(--ui-border, #d9dfda) !important;
            background: var(--ui-surface, #ffffff) !important;
            color: var(--ui-text, #1a1e1a) !important;
        }

        #editRoleModal .input-theme {
            border-color: var(--ui-border, #d9dfda) !important;
            background: var(--ui-surface, #ffffff) !important;
            color: var(--ui-text, #1a1e1a) !important;
        }

        @media (prefers-color-scheme: dark) {
            html[data-appearance-theme="auto"] .users-role-widget-section,
            html[data-appearance-theme="auto"] #editRoleModal {
                --ui-surface: #17211d;
                --ui-surface-muted: #1d2923;
                --ui-surface-subtle: #24332b;
                --ui-border: #3a4b41;
                --ui-text: #edf5f0;
                --ui-text-muted: #a8bbb0;
            }
        }

        @media (max-width: 980px) {
            .users-role-widget-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 600px) {
            .users-role-widget-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <?php if ($canViewRolePermissions) { ?>
        <div class="users-role-view-tabs" role="tablist" aria-label="Role management views">
            <button type="button" class="users-role-view-tab is-active" data-role-view="roles" role="tab" aria-selected="true">
                <i class="ti ti-users-group" aria-hidden="true"></i><span>Roles</span>
            </button>
            <button type="button" class="users-role-view-tab" data-role-view="permissions" role="tab" aria-selected="false">
                <i class="ti ti-shield-lock" aria-hidden="true"></i><span>Role Permissions</span>
            </button>
        </div>
    <?php } ?>

    <section class="users-role-widget-section" id="usersRolesView" aria-label="Roles">
        <div class="users-role-widget-grid" id="usersRoleCards" aria-live="polite">
            <div class="users-role-widget-loading" style="grid-column: 1 / -1;">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            </div>
        </div>
        <div class="users-role-widget-empty" id="usersRoleCardsEmpty" hidden>No roles found.</div>
        <nav class="users-role-widget-pagination" id="usersRoleCardsPagination" aria-label="Role pages"></nav>
    </section>

    <?php if ($canViewRolePermissions) { ?>
        <section id="usersRolePermissionsView" aria-label="Role permissions" hidden>
            <div class="users-role-permission-table-wrap">
                <div class="overflow-x-auto">
                    <table class="users-role-permission-table">
                        <thead>
                            <tr>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Permissions</th>
                                <th>Status</th>
                                <th style="width: 72px; text-align: center;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="usersRolePermissionsBody"></tbody>
                    </table>
                </div>
            </div>
            <nav class="users-role-widget-pagination" id="usersRolePermissionsPagination" aria-label="Role permission pages"></nav>
        </section>
    <?php } ?>

    <div class="modal fade animate__animated fadeIn" id="manageUsersModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100" style="font-size: 1rem; font-weight: 800;">
                            UI
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Manage All Users</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Search, sort, and manage user records</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div class="modal-body bg-slate-50/70 !p-4">
                    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="usersPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="users-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="users-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="users-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="users-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="users-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="users-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'user_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-56 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="u.name" data-default="asc">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-64 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="u.email">
                                <span class="inline-flex items-center gap-1">Email <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="r.name">
                                <span class="inline-flex items-center gap-1">Role <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-48 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Company Name
                            </th>
                            <th class="w-48 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Branch Name
                            </th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Status</th>
                            <th
                                class="w-56 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="usersTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        #createRoleWorkflowModal {
            --rw-surface: var(--ui-surface, #ffffff);
            --rw-muted-surface: var(--ui-surface-muted, #f7f8f7);
            --rw-subtle-surface: var(--ui-surface-subtle, #f1f3f1);
            --rw-border: var(--ui-border, #dfe5e0);
            --rw-text: var(--ui-text, #1a1e1a);
            --rw-muted: var(--ui-text-muted, #6b706b);
            --rw-accent: var(--appearance-accent, #174d37);
            z-index: 20020 !important;
        }

        #createRoleWorkflowModal .modal-dialog {
            width: calc(100% - 2rem);
            max-width: 920px;
        }

        #createRoleWorkflowModal .modal-content {
            overflow: hidden;
            border: 1px solid var(--rw-border);
            border-radius: 8px;
            background: var(--rw-surface) !important;
            color: var(--rw-text) !important;
            box-shadow: 0 26px 76px rgba(15, 23, 42, 0.28);
        }

        .role-wizard-progress-shell {
            position: relative;
            padding: 18px 28px 14px;
            border-bottom: 1px solid var(--rw-border);
            background: color-mix(in srgb, var(--rw-accent) 5%, var(--rw-surface)) !important;
        }

        .role-wizard-close {
            position: absolute;
            top: 10px;
            right: 12px;
            display: inline-flex;
            width: 34px;
            height: 34px;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--rw-border);
            border-radius: 6px;
            background: var(--rw-surface);
            color: var(--rw-muted);
            font-size: 1.15rem;
        }

        .role-wizard-progress {
            position: relative;
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            max-width: 720px;
            margin: 0 auto;
        }

        .role-wizard-progress::before {
            position: absolute;
            top: 14px;
            left: 12.5%;
            right: 12.5%;
            height: 1px;
            background: var(--rw-border);
            content: "";
        }

        .role-wizard-progress-fill {
            position: absolute;
            top: 14px;
            left: 12.5%;
            width: 0;
            height: 1px;
            background: var(--rw-accent);
            transition: width 180ms ease;
        }

        .role-wizard-progress-step {
            position: relative;
            z-index: 1;
            display: grid;
            justify-items: center;
            gap: 6px;
            color: var(--rw-muted);
            font-size: 0.66rem;
            font-weight: 700;
        }

        .role-wizard-progress-step span:first-child {
            display: inline-flex;
            width: 29px;
            height: 29px;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--rw-border);
            border-radius: 999px;
            background: var(--rw-surface);
            color: var(--rw-muted);
            font-size: 0.72rem;
        }

        .role-wizard-progress-step.is-active,
        .role-wizard-progress-step.is-complete {
            color: var(--rw-text);
        }

        .role-wizard-progress-step.is-active span:first-child,
        .role-wizard-progress-step.is-complete span:first-child {
            border-color: var(--rw-accent);
            background: var(--rw-accent);
            color: #ffffff;
        }

        #createRoleWorkflowModal .modal-body {
            position: relative;
            min-height: 480px;
            max-height: min(68vh, 670px);
            overflow-y: auto;
            padding: 22px 28px;
            background: var(--rw-surface) !important;
        }

        .role-wizard-loading {
            position: absolute;
            z-index: 5;
            inset: 0;
            display: none;
            place-items: center;
            background: color-mix(in srgb, var(--rw-surface) 88%, transparent);
            color: var(--rw-muted);
            font-size: 0.8rem;
            font-weight: 800;
        }

        .role-wizard-loading.is-visible {
            display: grid;
        }

        .role-wizard-pane {
            display: none;
        }

        .role-wizard-pane.is-active {
            display: block;
        }

        .role-wizard-heading {
            margin-bottom: 20px;
        }

        .role-wizard-heading h3 {
            margin: 0;
            color: var(--rw-text) !important;
            font-size: 1.35rem;
            font-weight: 800;
        }

        .role-wizard-heading p {
            margin: 4px 0 0;
            color: var(--rw-muted) !important;
            font-size: 0.76rem;
            font-weight: 600;
        }

        .role-wizard-field {
            margin-bottom: 15px;
        }

        .role-wizard-label {
            display: block;
            margin-bottom: 6px;
            color: var(--rw-text) !important;
            font-size: 0.72rem;
            font-weight: 800;
        }

        .role-wizard-input,
        .role-wizard-select,
        .role-wizard-textarea {
            width: 100%;
            border: 1px solid var(--rw-border);
            border-radius: 6px;
            background: var(--rw-surface) !important;
            color: var(--rw-text) !important;
            font-size: 0.78rem;
            font-weight: 600;
            outline: none;
        }

        .role-wizard-input,
        .role-wizard-select {
            min-height: 42px;
            padding: 8px 11px;
        }

        .role-wizard-textarea {
            min-height: 100px;
            resize: vertical;
            padding: 10px 11px;
        }

        .role-wizard-input:focus,
        .role-wizard-select:focus,
        .role-wizard-textarea:focus {
            border-color: var(--rw-accent);
            box-shadow: 0 0 0 3px color-mix(in srgb, var(--rw-accent) 14%, transparent);
        }

        .role-wizard-help {
            display: flex;
            justify-content: space-between;
            margin-top: 5px;
            color: var(--rw-muted);
            font-size: 0.62rem;
            font-weight: 600;
        }

        .role-wizard-status-options {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .role-wizard-status-option {
            display: inline-flex;
            min-height: 40px;
            min-width: 120px;
            align-items: center;
            gap: 8px;
            border: 1px solid var(--rw-border);
            border-radius: 6px;
            background: var(--rw-surface);
            color: var(--rw-text);
            padding: 8px 11px;
            font-size: 0.75rem;
            font-weight: 700;
            cursor: pointer;
        }

        .role-wizard-toolbar {
            display: grid;
            grid-template-columns: minmax(180px, 1fr) auto auto;
            gap: 8px;
            margin-bottom: 12px;
        }

        .role-wizard-mini-button {
            min-height: 38px;
            border: 1px solid var(--rw-border);
            border-radius: 6px;
            background: var(--rw-surface);
            color: var(--rw-text);
            padding: 0 12px;
            font-size: 0.7rem;
            font-weight: 800;
        }

        .role-wizard-permission-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 7px;
        }

        .role-wizard-check-row {
            display: flex;
            min-height: 38px;
            align-items: center;
            gap: 8px;
            padding: 7px 9px;
            border: 1px solid var(--rw-border);
            border-radius: 5px;
            background: var(--rw-surface) !important;
            color: var(--rw-text);
            font-size: 0.69rem;
            font-weight: 700;
            cursor: pointer;
        }

        .role-wizard-check-row:has(input:checked) {
            border-color: color-mix(in srgb, var(--rw-accent) 58%, var(--rw-border));
            background: color-mix(in srgb, var(--rw-accent) 7%, var(--rw-surface)) !important;
        }

        .role-wizard-check-row input,
        .role-wizard-user-check {
            width: 15px;
            height: 15px;
            flex: 0 0 15px;
            accent-color: var(--rw-accent);
        }

        .role-wizard-role-pill,
        .role-wizard-selected-summary {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 12px;
            padding: 9px 11px;
            border: 1px solid color-mix(in srgb, var(--rw-accent) 20%, var(--rw-border));
            border-radius: 6px;
            background: color-mix(in srgb, var(--rw-accent) 6%, var(--rw-surface)) !important;
            color: var(--rw-text);
            font-size: 0.7rem;
            font-weight: 800;
        }

        .role-wizard-user-filters {
            display: grid;
            grid-template-columns: 180px minmax(220px, 1fr);
            gap: 8px;
            margin-bottom: 10px;
        }

        .role-wizard-selected-chips {
            display: flex;
            min-height: 31px;
            flex-wrap: wrap;
            align-items: center;
            gap: 5px;
        }

        .role-wizard-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 7px;
            border-radius: 999px;
            background: color-mix(in srgb, var(--rw-accent) 9%, var(--rw-surface));
            color: var(--rw-accent);
            font-size: 0.62rem;
            font-weight: 800;
        }

        .role-wizard-user-table-wrap {
            overflow: auto;
            border: 1px solid var(--rw-border);
            border-radius: 6px;
        }

        .role-wizard-user-table {
            width: 100%;
            min-width: 720px;
            border-collapse: collapse;
        }

        .role-wizard-user-table th,
        .role-wizard-user-table td {
            padding: 8px 9px;
            border-bottom: 1px solid var(--rw-border);
            color: var(--rw-text);
            font-size: 0.65rem;
            text-align: left;
            vertical-align: middle;
        }

        .role-wizard-user-table th {
            background: var(--rw-muted-surface) !important;
            color: var(--rw-muted);
            font-size: 0.59rem;
            text-transform: uppercase;
        }

        .role-wizard-user-table tr:last-child td {
            border-bottom: 0;
        }

        .role-wizard-user-cell {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 800;
        }

        .role-wizard-user-avatar {
            display: inline-flex;
            width: 28px;
            height: 28px;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            background: color-mix(in srgb, var(--rw-accent) 11%, var(--rw-surface));
            color: var(--rw-accent);
            font-size: 0.61rem;
            font-weight: 900;
        }

        .role-wizard-active-badge {
            display: inline-flex;
            padding: 3px 7px;
            border-radius: 999px;
            background: color-mix(in srgb, var(--rw-accent) 10%, var(--rw-surface));
            color: var(--rw-accent);
            font-size: 0.58rem;
            font-weight: 900;
        }

        .role-wizard-review-grid {
            display: grid;
            gap: 10px;
        }

        .role-wizard-review-card {
            border: 1px solid var(--rw-border);
            border-radius: 6px;
            background: var(--rw-surface) !important;
            padding: 12px 14px;
        }

        .role-wizard-review-card h4 {
            margin: 0 0 10px;
            color: var(--rw-text) !important;
            font-size: 0.76rem;
            font-weight: 900;
        }

        .role-wizard-review-details {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px 18px;
        }

        .role-wizard-review-item span,
        .role-wizard-review-item strong {
            display: block;
        }

        .role-wizard-review-item span {
            color: var(--rw-muted);
            font-size: 0.61rem;
            font-weight: 700;
        }

        .role-wizard-review-item strong {
            margin-top: 3px;
            color: var(--rw-text);
            font-size: 0.72rem;
        }

        .role-wizard-review-list {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 5px 14px;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .role-wizard-review-list li {
            color: var(--rw-text);
            font-size: 0.67rem;
            font-weight: 700;
        }

        .role-wizard-review-list li::before {
            margin-right: 6px;
            color: var(--rw-accent);
            content: "\2713";
            font-weight: 900;
        }

        .role-wizard-footer {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 18px;
            border-top: 1px solid var(--rw-border);
            background: color-mix(in srgb, var(--rw-accent) 5%, var(--rw-surface)) !important;
        }

        .role-wizard-footer-spacer {
            flex: 1;
        }

        .role-wizard-button {
            display: inline-flex;
            min-width: 88px;
            height: 40px;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            padding: 0 16px;
            font-size: 0.72rem;
            font-weight: 900;
        }

        .role-wizard-button-secondary {
            border: 1px solid var(--rw-border);
            background: var(--rw-surface);
            color: var(--rw-text);
        }

        .role-wizard-button-primary {
            border: 1px solid var(--rw-accent);
            background: var(--rw-accent);
            color: #ffffff;
        }

        .role-wizard-button:disabled {
            cursor: not-allowed;
            opacity: 0.45;
        }

        html[data-appearance-theme="dark"] #createRoleWorkflowModal,
        #createRoleWorkflowModal.role-wizard-dark {
            --rw-surface: #17211d;
            --rw-muted-surface: #1d2923;
            --rw-subtle-surface: #24332b;
            --rw-border: #3a4b41;
            --rw-text: #edf5f0;
            --rw-muted: #a8bbb0;
        }

        @media (max-width: 900px) {
            .users-page-toolbar {
                grid-template-columns: minmax(220px, 1fr) auto !important;
            }

            .users-page-toolbar > button {
                width: 100%;
            }
        }

        @media (max-width: 640px) {
            .users-page-toolbar {
                grid-template-columns: 1fr !important;
            }

            #createRoleWorkflowModal .modal-dialog {
                width: calc(100% - 1rem);
                margin: 0.5rem auto;
            }

            #createRoleWorkflowModal .modal-body {
                max-height: calc(100vh - 190px);
                min-height: 430px;
                padding: 18px 16px;
            }

            .role-wizard-progress-shell {
                padding-left: 8px;
                padding-right: 8px;
            }

            .role-wizard-progress-step {
                font-size: 0.57rem;
            }

            .role-wizard-toolbar,
            .role-wizard-user-filters,
            .role-wizard-review-details,
            .role-wizard-review-list {
                grid-template-columns: 1fr;
            }

            .role-wizard-permission-grid {
                grid-template-columns: 1fr;
            }

            .role-wizard-footer {
                flex-wrap: wrap;
            }
        }
    </style>

    <div class="modal fade animate__animated fadeIn" id="createRoleWorkflowModal" tabindex="-1"
        aria-labelledby="createRoleWorkflowTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="role-wizard-progress-shell">
                    <button type="button" class="role-wizard-close" data-bs-dismiss="modal" aria-label="Close">&times;</button>
                    <div class="role-wizard-progress" id="roleWizardProgress" aria-label="Role creation progress">
                        <span class="role-wizard-progress-fill" id="roleWizardProgressFill"></span>
                        <div class="role-wizard-progress-step is-active" data-role-wizard-progress="1"><span>1</span><span>Role Details</span></div>
                        <div class="role-wizard-progress-step" data-role-wizard-progress="2"><span>2</span><span>Permissions</span></div>
                        <div class="role-wizard-progress-step" data-role-wizard-progress="3"><span>3</span><span>Assign Users</span></div>
                        <div class="role-wizard-progress-step" data-role-wizard-progress="4"><span>4</span><span>Review</span></div>
                    </div>
                </div>

                <form id="createRoleWorkflowForm">
                    <div class="modal-body">
                        <div class="role-wizard-loading" id="roleWizardLoading">Loading role setup...</div>

                        <section class="role-wizard-pane is-active" data-role-wizard-step="1">
                            <div class="role-wizard-heading">
                                <h3 id="createRoleWorkflowTitle">Create New Role</h3>
                                <p id="roleWizardDetailsHelp">Step 1 of 4: Define the role identity and department for the new access level.</p>
                            </div>
                            <div class="role-wizard-field">
                                <label class="role-wizard-label" for="roleWizardDepartment">Select Department *</label>
                                <select class="role-wizard-select input-theme select2" id="roleWizardDepartment" name="department_id"
                                    data-placeholder="Choose a department..." required>
                                    <option value="">Choose a department...</option>
                                </select>
                            </div>
                            <div class="role-wizard-field">
                                <label class="role-wizard-label" for="roleWizardName">Role Name *</label>
                                <input class="role-wizard-input" type="text" id="roleWizardName" maxlength="100"
                                    placeholder="e.g. Lead Operations Analyst" autocomplete="off" required>
                            </div>
                            <div class="role-wizard-field">
                                <label class="role-wizard-label" for="roleWizardDescription">Role Description *</label>
                                <textarea class="role-wizard-textarea" id="roleWizardDescription" maxlength="250"
                                    placeholder="Briefly describe the responsibilities and scope of this role..." required></textarea>
                                <div class="role-wizard-help"><span>Maximum 250 characters.</span><span id="roleWizardDescriptionCount">0 / 250</span></div>
                            </div>
                            <div class="role-wizard-field" id="roleWizardStatusField" hidden>
                                <span class="role-wizard-label">Status *</span>
                                <div class="role-wizard-status-options">
                                    <label class="role-wizard-status-option">
                                        <input type="radio" name="roleWizardStatus" value="1" checked>
                                        <span>Active</span>
                                    </label>
                                    <label class="role-wizard-status-option">
                                        <input type="radio" name="roleWizardStatus" value="0">
                                        <span>Inactive</span>
                                    </label>
                                </div>
                            </div>
                        </section>

                        <section class="role-wizard-pane" data-role-wizard-step="2">
                            <div class="role-wizard-heading">
                                <h3>Assign Permissions</h3>
                                <p>Step 2 of 4: Select the permissions this role receives.</p>
                            </div>
                            <div class="role-wizard-role-pill"><span>Role</span><strong id="roleWizardPermissionRole">-</strong></div>
                            <div class="role-wizard-toolbar">
                                <input class="role-wizard-input" type="search" id="roleWizardPermissionSearch" placeholder="Search permissions...">
                                <button class="role-wizard-mini-button" type="button" id="roleWizardSelectAllPermissions">Select All</button>
                                <button class="role-wizard-mini-button" type="button" id="roleWizardClearPermissions">Clear</button>
                            </div>
                            <div class="role-wizard-permission-grid" id="roleWizardPermissionGrid"></div>
                        </section>

                        <section class="role-wizard-pane" data-role-wizard-step="3">
                            <div class="role-wizard-heading">
                                <h3>Assign Users</h3>
                                <p>Step 3 of 4: Select onboarded employees who should receive this role.</p>
                            </div>
                            <div class="role-wizard-user-filters">
                                <select class="role-wizard-select input-theme select2" id="roleWizardUserCategoryFilter"
                                    data-placeholder="All employee categories">
                                    <option value="">All employee categories</option>
                                </select>
                                <input class="role-wizard-input" type="search" id="roleWizardUserSearch" placeholder="Search by name, employee ID, or email...">
                            </div>
                            <div class="role-wizard-selected-summary">
                                <div class="role-wizard-selected-chips" id="roleWizardSelectedUsers"><span>No users selected</span></div>
                                <button class="role-wizard-mini-button" type="button" id="roleWizardClearUsers">Clear All</button>
                            </div>
                            <div class="role-wizard-user-table-wrap">
                                <table class="role-wizard-user-table">
                                    <thead><tr><th style="width:36px;"></th><th>User</th><th>Employee Category</th><th>Designation</th><th>Email</th><th>Status</th></tr></thead>
                                    <tbody id="roleWizardUserRows"></tbody>
                                </table>
                            </div>
                        </section>

                        <section class="role-wizard-pane" data-role-wizard-step="4">
                            <div class="role-wizard-heading">
                                <h3>Review & Confirm</h3>
                                <p id="roleWizardReviewHelp">Step 4 of 4: Review the role, permissions, and selected users before submitting.</p>
                            </div>
                            <div class="role-wizard-review-grid">
                                <div class="role-wizard-review-card">
                                    <h4>Role Details</h4>
                                    <div class="role-wizard-review-details" id="roleWizardReviewDetails"></div>
                                </div>
                                <div class="role-wizard-review-card">
                                    <h4 id="roleWizardReviewPermissionsTitle">Selected Permissions</h4>
                                    <ul class="role-wizard-review-list" id="roleWizardReviewPermissions"></ul>
                                </div>
                                <div class="role-wizard-review-card">
                                    <h4 id="roleWizardReviewUsersTitle">Assigned Users</h4>
                                    <ul class="role-wizard-review-list" id="roleWizardReviewUsers"></ul>
                                </div>
                            </div>
                        </section>
                    </div>

                    <div class="role-wizard-footer">
                        <button type="button" class="role-wizard-button role-wizard-button-secondary" data-bs-dismiss="modal">Cancel</button>
                        <span class="role-wizard-footer-spacer"></span>
                        <button type="button" class="role-wizard-button role-wizard-button-secondary" id="roleWizardBackBtn" disabled>Back</button>
                        <button type="button" class="role-wizard-button role-wizard-button-primary" id="roleWizardNextBtn">Next&nbsp; &rarr;</button>
                        <button type="submit" class="role-wizard-button role-wizard-button-primary" id="roleWizardSubmitBtn" hidden>Submit&nbsp; &rarr;</button>
                        <button type="button" class="role-wizard-button role-wizard-button-primary" id="roleWizardFinishBtn" hidden>Finish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-user-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                User</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a user account and assign role
                                access</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addUsersForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="space-y-4">
                            <div>
                                <label for="userName" class="mb-1 block text-sm font-medium text-slate-800">Name</label>
                                <input type="text" id="userName" autocomplete="new-password" name="userName" class="input-theme"
                                    placeholder="Enter Name" required />
                            </div>
                            <div>
                                <label for="userEmail"
                                    class="mb-1 block text-sm font-medium text-slate-800">Email</label>
                                <input type="email" id="userEmail" autocomplete="new-password" name="userEmail"
                                    class="input-theme" placeholder="Enter Email" required />
                            </div>
                            <div>
                                <label for="userPassword"
                                    class="mb-1 block text-sm font-medium text-slate-800">Password</label>
                                <div class="relative">
                                    <input type="password" id="userPassword" autocomplete="new-password" name="userPassword"
                                        class="input-theme !pr-12" placeholder="Enter Password" required />
                                    <button type="button" class="toggle-user-password absolute inset-y-0 right-0 inline-flex w-11 items-center justify-center text-slate-500 hover:text-slate-800" data-target="userPassword" aria-label="Show password" aria-pressed="false">
                                        <i class="ti ti-eye-off text-lg" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label for="userConfirmPassword"
                                    class="mb-1 block text-sm font-medium text-slate-800">Confirm Password</label>
                                <div class="relative">
                                    <input type="password" id="userConfirmPassword" autocomplete="new-password"
                                        name="userConfirmPassword" class="input-theme !pr-12" placeholder="Enter Confirm Password"
                                        required />
                                    <button type="button" class="toggle-user-password absolute inset-y-0 right-0 inline-flex w-11 items-center justify-center text-slate-500 hover:text-slate-800" data-target="userConfirmPassword" aria-label="Show confirm password" aria-pressed="false">
                                        <i class="ti ti-eye-off text-lg" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label for="userRoleType" class="mb-1 block text-sm font-medium text-slate-800">Select
                                    Role</label>
                                <select id="userRoleType" autocomplete="off" name="userRoleType" class="input-theme select2"
                                    required>
                                </select>
                            </div>
                            <div>
                                 <label for="userCompanyType" class="mb-1 block text-sm font-medium text-slate-800">Company Name</label>
                                 <select id="userCompanyType" autocomplete="off" name="userCompanyType" class="input-theme select2" required>
                                     <option value="">--Select Company--</option>
                                 </select>
                            </div>
                            <div>
                                 <label for="userBranchType" class="mb-1 block text-sm font-medium text-slate-800">Branch Name</label>
                                 <select id="userBranchType" autocomplete="off" name="userBranchType" class="input-theme select2" required>
                                     <option value="">--Select Branch--</option>
                                 </select>
                            </div>
                            <div>
                                <p class="mb-2 text-sm font-semibold text-slate-800">Status</p>
                                <div class="flex flex-wrap gap-3">
                                    <label
                                        class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700">
                                        <input class="accent-emerald-600" type="radio" id="activStatus"
                                            name="userStatus" value="1" required />
                                        Active
                                    </label>
                                    <label
                                        class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700">
                                        <input class="accent-emerald-600" type="radio" id="inactiveStatus"
                                            name="userStatus" value="0" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <style>
        #editUserModel {
            --edit-surface: var(--ui-surface, #ffffff);
            --edit-surface-muted: var(--ui-surface-muted, #f7f8f7);
            --edit-surface-subtle: var(--ui-surface-subtle, #f1f3f1);
            --edit-text: var(--ui-text, #1a1e1a);
            --edit-muted: var(--ui-text-muted, #6b706b);
            --edit-border: var(--ui-border, #d9dfda);
            --edit-accent: var(--appearance-accent, #1a4d2e);
            z-index: 20000 !important;
        }

        html[data-appearance-theme="dark"] #editUserModel {
            --edit-surface: #17211d;
            --edit-surface-muted: #1d2923;
            --edit-surface-subtle: #24332b;
            --edit-text: #edf5f0;
            --edit-muted: #a8bbb0;
            --edit-border: #3a4b41;
        }

        html[data-appearance-theme="dark"] #editUserModel .modal-content,
        html[data-appearance-theme="dark"] #editUserModel .modal-body {
            background: #1d2923 !important;
            color: #edf5f0 !important;
        }

        html[data-appearance-theme="dark"] #editUserModel :is(.user-edit-profile-header, .user-edit-section, .user-edit-input, .select2-selection--single, .user-edit-close) {
            background: #17211d !important;
            color: #edf5f0 !important;
        }

        html[data-appearance-theme="dark"] #editUserModel :is(.user-edit-readonly, .user-edit-status-option, .user-edit-summary-item) {
            background: #24332b !important;
            color: #edf5f0 !important;
        }

        #editUserModel.user-edit-dark .modal-content,
        #editUserModel.user-edit-dark .modal-body {
            background: #1d2923 !important;
            color: #edf5f0 !important;
        }

        #editUserModel.user-edit-dark :is(.user-edit-profile-header, .user-edit-section, .user-edit-input, .select2-selection--single, .user-edit-close) {
            background: #17211d !important;
            color: #edf5f0 !important;
        }

        #editUserModel.user-edit-dark :is(.user-edit-readonly, .user-edit-status-option, .user-edit-summary-item) {
            background: #24332b !important;
            color: #edf5f0 !important;
        }

        @media (prefers-color-scheme: dark) {
            html[data-appearance-theme="auto"] #editUserModel {
                --edit-surface: #17211d;
                --edit-surface-muted: #1d2923;
                --edit-surface-subtle: #24332b;
                --edit-text: #edf5f0;
                --edit-muted: #a8bbb0;
                --edit-border: #3a4b41;
            }

            html[data-appearance-theme="auto"] #editUserModel .modal-content,
            html[data-appearance-theme="auto"] #editUserModel .modal-body {
                background: #1d2923 !important;
                color: #edf5f0 !important;
            }

            html[data-appearance-theme="auto"] #editUserModel :is(.user-edit-profile-header, .user-edit-section, .user-edit-input, .select2-selection--single, .user-edit-close) {
                background: #17211d !important;
                color: #edf5f0 !important;
            }

            html[data-appearance-theme="auto"] #editUserModel :is(.user-edit-readonly, .user-edit-status-option, .user-edit-summary-item) {
                background: #24332b !important;
                color: #edf5f0 !important;
            }
        }

        #editUserModel .modal-dialog {
            width: calc(100% - 2rem);
            max-width: 1120px;
        }

        #editUserModel .modal-content {
            overflow: hidden;
            border: 1px solid var(--edit-border);
            border-radius: 8px;
            background: var(--edit-surface-muted) !important;
            color: var(--edit-text) !important;
            box-shadow: 0 24px 70px rgba(15, 23, 42, 0.24);
        }

        #editUserModel .modal-body {
            max-height: min(90vh, 900px);
            overflow-y: auto;
            padding: 0;
            background: var(--edit-surface-muted) !important;
        }

        .user-edit-profile-header {
            display: grid;
            grid-template-columns: auto minmax(0, 1fr) auto;
            align-items: center;
            gap: 14px;
            padding: 12px 16px;
            border-bottom: 1px solid var(--edit-border);
            background: var(--edit-surface) !important;
        }

        .user-edit-avatar {
            position: relative;
            display: inline-flex;
            width: 64px;
            height: 64px;
            flex: 0 0 64px;
            align-items: center;
            justify-content: center;
            border: 3px solid color-mix(in srgb, var(--edit-accent) 22%, var(--edit-surface));
            border-radius: 8px;
            background: color-mix(in srgb, var(--edit-accent) 13%, var(--edit-surface));
            color: var(--edit-accent);
            font-size: 1.35rem;
            font-weight: 800;
            overflow: hidden;
            margin: 0;
        }

        .user-edit-avatar-shell {
            position: relative;
            display: inline-flex;
        }

        .user-edit-avatar-upload:not(.is-disabled) {
            cursor: pointer;
        }

        .user-edit-avatar-upload.is-disabled {
            cursor: default;
        }

        .user-edit-avatar-photo {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-edit-avatar-initials {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .user-edit-avatar-photo.hidden,
        .user-edit-avatar-initials.hidden {
            display: none;
        }

        .user-edit-avatar-action {
            position: absolute;
            right: 3px;
            bottom: 3px;
            display: inline-flex;
            width: 20px;
            height: 20px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--edit-accent) 25%, var(--edit-border));
            border-radius: 5px;
            background: var(--edit-surface) !important;
            color: var(--edit-accent);
            font-size: 0.75rem;
            box-shadow: 0 1px 4px rgba(15, 23, 42, 0.14);
        }

        .user-edit-avatar-upload.is-disabled .user-edit-avatar-action {
            display: none;
        }

        .user-edit-photo-input {
            position: absolute;
            width: 1px;
            height: 1px;
            overflow: hidden;
            clip: rect(0 0 0 0);
            white-space: nowrap;
        }

        .user-edit-profile-name {
            margin: 0;
            color: var(--edit-text) !important;
            font-size: 1.05rem;
            font-weight: 800;
        }

        .user-edit-profile-meta,
        .user-edit-profile-joined {
            margin: 3px 0 0;
            color: var(--edit-muted) !important;
            font-size: 0.78rem;
            font-weight: 600;
        }

        .user-edit-profile-joined {
            display: inline-flex;
            margin-top: 8px;
            padding: 5px 9px;
            border-radius: 999px;
            background: color-mix(in srgb, var(--edit-accent) 9%, var(--edit-surface));
            color: var(--edit-accent);
        }

        .user-edit-header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .user-edit-status-badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 10px;
            border-radius: 999px;
            background: color-mix(in srgb, var(--edit-accent) 11%, var(--edit-surface));
            color: var(--edit-accent);
            font-size: 0.72rem;
            font-weight: 800;
        }

        .user-edit-save,
        .user-edit-close {
            display: inline-flex;
            height: 40px;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 800;
        }

        .user-edit-save {
            min-width: 130px;
            border: 1px solid var(--edit-accent);
            background: var(--edit-accent);
            color: #ffffff;
        }

        .user-edit-save:hover {
            filter: brightness(0.92);
        }

        .user-edit-close {
            width: 40px;
            border: 1px solid var(--edit-border);
            background: var(--edit-surface) !important;
            color: var(--edit-muted);
            font-size: 1.25rem;
        }

        .user-edit-layout {
            display: grid;
            grid-template-columns: minmax(0, 2fr) minmax(260px, 0.95fr);
            gap: 16px;
            padding: 16px;
        }

        .user-edit-main,
        .user-edit-side {
            display: grid;
            align-content: start;
            gap: 16px;
        }

        .user-edit-section {
            overflow: hidden;
            border: 1px solid var(--edit-border);
            border-radius: 8px;
            background: var(--edit-surface);
        }

        .user-edit-section-title {
            margin: 0;
            padding: 9px 14px;
            border-bottom: 1px solid var(--edit-border);
            background: color-mix(in srgb, var(--edit-accent) 8%, var(--edit-surface));
            color: var(--edit-text) !important;
            font-size: 0.8rem;
            font-weight: 800;
        }

        .user-edit-section-body {
            padding: 11px 14px;
        }

        .user-edit-fields {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px 18px;
        }

        .user-edit-field-wide {
            grid-column: 1 / -1;
        }

        .user-edit-label {
            display: block;
            margin-bottom: 5px;
            color: var(--edit-muted) !important;
            font-size: 0.72rem;
            font-weight: 700;
        }

        #editUserModel .user-edit-input,
        #editUserModel .select2-selection--single {
            width: 100%;
            min-height: 34px;
            border: 1px solid var(--edit-border) !important;
            border-radius: 6px !important;
            background: var(--edit-surface) !important;
            color: var(--edit-text) !important;
            font-size: 0.8rem;
            font-weight: 600;
            box-shadow: none !important;
        }

        #editUserModel .user-edit-input {
            padding: 6px 9px;
            outline: none;
        }

        #editUserModel textarea.user-edit-input {
            min-height: 58px;
            resize: vertical;
        }

        #editUserModel .user-edit-input:disabled {
            background: var(--edit-surface-subtle) !important;
            color: var(--edit-muted) !important;
            cursor: not-allowed;
        }

        #editUserModel .user-edit-input:focus,
        #editUserModel .select2-container--open .select2-selection--single {
            border-color: var(--edit-accent) !important;
            box-shadow: 0 0 0 3px color-mix(in srgb, var(--edit-accent) 16%, transparent) !important;
        }

        #editUserModel .select2-container {
            width: 100% !important;
        }

        #editUserModel .select2-selection__rendered {
            padding: 3px 34px 3px 9px !important;
            color: var(--edit-text) !important;
            line-height: 26px !important;
        }

        #editUserModel .select2-selection__arrow {
            height: 32px !important;
        }

        #editUserModel .select2-dropdown {
            border-color: var(--edit-border);
            background: var(--edit-surface);
            color: var(--edit-text);
        }

        #editUserModel .select2-search__field {
            border-color: var(--edit-border) !important;
            border-radius: 6px;
            background: var(--edit-surface) !important;
            color: var(--edit-text) !important;
        }

        #editUserModel .select2-results__option--highlighted {
            background: var(--edit-accent) !important;
            color: #ffffff !important;
        }

        .user-edit-loading {
            display: grid;
            min-height: 320px;
            place-items: center;
            color: var(--edit-muted);
            font-size: 0.8rem;
            font-weight: 700;
        }

        .user-edit-readonly {
            min-height: 40px;
            padding: 9px 10px;
            border: 1px solid var(--edit-border);
            border-radius: 6px;
            background: var(--edit-surface-subtle) !important;
            color: var(--edit-text) !important;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .user-edit-status-options {
            display: grid;
            gap: 10px;
        }

        .user-edit-status-option {
            display: grid;
            grid-template-columns: auto minmax(0, 1fr);
            gap: 10px;
            align-items: center;
            margin: 0;
            padding: 11px 12px;
            border: 1px solid var(--edit-border);
            border-radius: 6px;
            background: var(--edit-surface-muted) !important;
            color: var(--edit-text) !important;
            cursor: pointer;
        }

        .user-edit-status-option:has(input:checked) {
            border-color: var(--edit-accent);
            background: color-mix(in srgb, var(--edit-accent) 9%, var(--edit-surface));
        }

        .user-edit-status-option input {
            width: 16px;
            height: 16px;
            margin: 0;
            accent-color: var(--edit-accent);
        }

        .user-edit-status-copy strong,
        .user-edit-status-copy small {
            display: block;
        }

        .user-edit-status-copy strong {
            font-size: 0.78rem;
        }

        .user-edit-status-copy small {
            margin-top: 2px;
            color: var(--edit-muted) !important;
            font-size: 0.68rem;
            font-weight: 600;
        }

        .user-edit-summary-list {
            display: grid;
            gap: 10px;
        }

        .user-edit-summary-item {
            padding: 10px 11px;
            border: 1px solid var(--edit-border);
            border-radius: 6px;
            background: var(--edit-surface-muted) !important;
        }

        .user-edit-summary-item span,
        .user-edit-summary-item strong {
            display: block;
        }

        .user-edit-summary-item span {
            color: var(--edit-muted) !important;
            font-size: 0.67rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .user-edit-summary-item strong {
            margin-top: 3px;
            overflow-wrap: anywhere;
            color: var(--edit-text) !important;
            font-size: 0.76rem;
        }

        #editUserModel .user-edit-layout.user-edit-reference-layout {
            grid-template-columns: minmax(0, 2.05fr) minmax(280px, 0.95fr);
            align-items: stretch;
        }

        #editUserModel .user-edit-reference-layout .user-edit-side {
            min-height: 100%;
        }

        #editUserModel .user-edit-reference-layout .user-edit-side .user-edit-section {
            min-height: 100%;
        }

        #editUserModel .user-edit-reference-layout .user-edit-fields {
            gap: 8px 24px;
        }

        #editUserModel .user-edit-reference-layout .user-edit-readonly {
            min-height: 24px;
            border-color: transparent;
            background: transparent !important;
            padding: 3px 0;
        }

        #editUserModel .user-edit-reference-layout .user-edit-personal-address {
            grid-column: 1 / -1;
        }

        #editUserModel .user-edit-reference-layout .user-edit-personal-status .user-edit-status-options {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        #editUserModel .user-edit-reference-layout .user-edit-personal-status .user-edit-status-option {
            display: inline-flex;
            width: auto;
            min-height: 32px;
            padding: 6px 9px;
            border-radius: 5px;
            gap: 6px;
        }

        #editUserModel .user-edit-reference-layout .user-edit-personal-status .user-edit-status-option input {
            width: 14px;
            height: 14px;
        }

        #editUserModel .user-edit-reference-layout .user-edit-personal-status .user-edit-status-copy small {
            display: none;
        }

        #editUserModel .user-edit-reference-layout .user-edit-financial-panel {
            margin-top: 14px;
            padding: 13px 14px;
            border: 1px solid color-mix(in srgb, var(--edit-accent) 20%, var(--edit-border));
            border-radius: 7px;
            background: color-mix(in srgb, var(--edit-accent) 9%, var(--edit-surface)) !important;
        }

        #editUserModel .user-edit-financial-title {
            margin: 0 0 12px;
            color: var(--edit-text) !important;
            font-size: 0.71rem;
            font-weight: 800;
            text-transform: uppercase;
        }

        #editUserModel .user-edit-financial-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
        }

        #editUserModel .user-edit-financial-item span,
        #editUserModel .user-edit-financial-item strong {
            display: block;
        }

        #editUserModel .user-edit-financial-item span {
            color: var(--edit-muted) !important;
            font-size: 0.65rem;
            font-weight: 700;
        }

        #editUserModel .user-edit-financial-item strong {
            margin-top: 4px;
            color: var(--edit-text) !important;
            font-size: 0.73rem;
            font-weight: 800;
            overflow-wrap: anywhere;
        }

        #editUserModel .user-edit-documents-body {
            display: grid;
            align-content: start;
            gap: 16px;
            padding: 14px;
        }

        #editUserModel .user-edit-document-group-title {
            margin: 0 0 7px;
            color: var(--edit-muted) !important;
            font-size: 0.61rem;
            font-weight: 800;
            text-transform: uppercase;
        }

        #editUserModel .user-edit-document-list {
            display: grid;
            gap: 8px;
        }

        #editUserModel .user-edit-document-row {
            display: grid;
            grid-template-columns: 34px minmax(0, 1fr) 30px;
            align-items: center;
            gap: 9px;
            width: 100%;
            min-height: 54px;
            padding: 8px;
            border: 1px solid var(--edit-border);
            border-radius: 6px;
            background: var(--edit-surface-muted) !important;
            color: inherit;
            text-align: left;
            cursor: pointer;
            transition: border-color 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
        }

        #editUserModel .user-edit-document-row:hover,
        #editUserModel .user-edit-document-row:focus-visible {
            border-color: color-mix(in srgb, var(--edit-accent) 42%, var(--edit-border));
            background: color-mix(in srgb, var(--edit-accent) 5%, var(--edit-surface)) !important;
            box-shadow: 0 0 0 2px color-mix(in srgb, var(--edit-accent) 10%, transparent);
            outline: none;
        }

        #editUserModel .user-edit-document-mark {
            display: inline-flex;
            width: 34px;
            height: 36px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--edit-accent) 20%, var(--edit-border));
            border-radius: 5px;
            background: color-mix(in srgb, var(--edit-accent) 8%, var(--edit-surface));
            color: var(--edit-accent);
            font-size: 0.57rem;
            font-weight: 900;
        }

        #editUserModel .user-edit-document-copy {
            min-width: 0;
        }

        #editUserModel .user-edit-document-copy strong,
        #editUserModel .user-edit-document-copy small {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        #editUserModel .user-edit-document-copy strong {
            color: var(--edit-text) !important;
            font-size: 0.72rem;
        }

        #editUserModel .user-edit-document-copy small {
            margin-top: 2px;
            color: var(--edit-muted) !important;
            font-size: 0.58rem;
            font-weight: 700;
        }

        #editUserModel .user-edit-document-eye {
            display: inline-flex;
            width: 30px;
            height: 30px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--edit-accent) 18%, var(--edit-border));
            border-radius: 6px;
            background: var(--edit-surface) !important;
            color: var(--edit-accent);
            font-size: 0.95rem;
        }

        #editUserModel .user-edit-document-row:not(.is-available) .user-edit-document-eye {
            border-color: var(--edit-border);
            color: var(--edit-muted);
        }

        #editUserModel .user-edit-document-row.is-available .user-edit-document-copy small {
            color: var(--edit-accent) !important;
        }

        #editUserModel.user-edit-dark .user-edit-document-row {
            background: #24332b !important;
        }

        @media (max-width: 767px) {
            #editUserModel .modal-dialog {
                width: calc(100% - 1rem);
                margin: 0.5rem auto;
            }

            #editUserModel .modal-body {
                max-height: calc(100vh - 1rem);
            }

            .user-edit-profile-header {
                grid-template-columns: auto minmax(0, 1fr);
            }

            .user-edit-header-actions {
                grid-column: 1 / -1;
                justify-content: flex-end;
            }

            .user-edit-status-badge {
                margin-right: auto;
            }

            .user-edit-layout,
            .user-edit-fields {
                grid-template-columns: 1fr;
            }

            #editUserModel .user-edit-layout.user-edit-reference-layout,
            #editUserModel .user-edit-financial-grid {
                grid-template-columns: 1fr;
            }

            .user-edit-field-wide {
                grid-column: auto;
            }
        }
    </style>

    <style>
        #employeeDocumentPreviewModal {
            --doc-preview-surface: #ffffff;
            --doc-preview-muted-surface: #f3f6f4;
            --doc-preview-border: #dbe3de;
            --doc-preview-text: #17221b;
            --doc-preview-muted: #6b756e;
            --doc-preview-accent: var(--appearance-accent, #1a4d2e);
            z-index: 20060 !important;
        }

        #employeeDocumentPreviewModal .modal-dialog {
            width: calc(100% - 2rem);
            max-width: 1180px;
            margin: 1rem auto;
        }

        #employeeDocumentPreviewModal .modal-content {
            height: min(88vh, 820px);
            overflow: hidden;
            border: 1px solid var(--doc-preview-border);
            border-radius: 8px;
            background: var(--doc-preview-surface);
            color: var(--doc-preview-text);
            box-shadow: 0 28px 80px rgba(15, 23, 42, 0.28);
        }

        .employee-document-preview-header {
            display: flex;
            min-height: 62px;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            border-bottom: 1px solid var(--doc-preview-border);
            background: var(--doc-preview-surface);
        }

        .employee-document-preview-header-icon {
            display: inline-flex;
            width: 36px;
            height: 40px;
            flex: 0 0 36px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--doc-preview-accent) 24%, var(--doc-preview-border));
            border-radius: 5px;
            background: color-mix(in srgb, var(--doc-preview-accent) 8%, #ffffff);
            color: var(--doc-preview-accent);
            font-size: 1.05rem;
        }

        .employee-document-preview-heading {
            min-width: 0;
            flex: 1;
        }

        .employee-document-preview-heading h5 {
            margin: 0;
            overflow: hidden;
            color: var(--doc-preview-text);
            font-size: 0.95rem;
            font-weight: 800;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .employee-document-preview-heading p {
            margin: 3px 0 0;
            overflow: hidden;
            color: var(--doc-preview-muted);
            font-size: 0.67rem;
            font-weight: 700;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .employee-document-preview-header-actions {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .employee-document-preview-icon-button {
            display: inline-flex;
            width: 36px;
            height: 36px;
            align-items: center;
            justify-content: center;
            border: 1px solid transparent;
            border-radius: 6px;
            background: transparent;
            color: var(--doc-preview-muted);
            font-size: 1rem;
        }

        .employee-document-preview-icon-button:hover:not(:disabled),
        .employee-document-preview-icon-button:focus-visible:not(:disabled) {
            border-color: var(--doc-preview-border);
            background: var(--doc-preview-muted-surface);
            color: var(--doc-preview-text);
            outline: none;
        }

        .employee-document-preview-icon-button:disabled {
            cursor: not-allowed;
            opacity: 0.4;
        }

        .employee-document-preview-body {
            display: grid;
            min-height: 0;
            flex: 1;
            grid-template-columns: minmax(0, 1fr) 310px;
        }

        .employee-document-preview-stage {
            display: grid;
            min-width: 0;
            min-height: 0;
            overflow: auto;
            place-items: center;
            padding: 18px;
            background: #eef2f0;
        }

        .employee-document-preview-canvas {
            display: grid;
            width: 100%;
            height: 100%;
            min-height: 520px;
            place-items: center;
        }

        .employee-document-preview-frame,
        .employee-document-preview-image {
            width: 100%;
            height: 100%;
            border: 1px solid #d6ded9;
            border-radius: 2px;
            background: #ffffff;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
        }

        .employee-document-preview-frame {
            min-height: 600px;
        }

        .employee-document-preview-image {
            display: block;
            object-fit: contain;
        }

        .employee-document-preview-empty {
            display: flex;
            width: min(100%, 680px);
            min-height: 600px;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border: 1px solid #d7dfda;
            background: #ffffff;
            padding: 32px;
            color: var(--doc-preview-text);
            text-align: center;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
        }

        .employee-document-preview-empty-icon {
            display: inline-flex;
            width: 58px;
            height: 64px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--doc-preview-accent) 22%, var(--doc-preview-border));
            border-radius: 7px;
            background: color-mix(in srgb, var(--doc-preview-accent) 7%, #ffffff);
            color: var(--doc-preview-accent);
            font-size: 1.55rem;
        }

        .employee-document-preview-empty h6 {
            margin: 18px 0 0;
            color: var(--doc-preview-text);
            font-size: 1rem;
            font-weight: 800;
        }

        .employee-document-preview-empty p {
            max-width: 360px;
            margin: 8px 0 0;
            color: var(--doc-preview-muted);
            font-size: 0.78rem;
            font-weight: 600;
            line-height: 1.6;
        }

        .employee-document-preview-sidebar {
            display: grid;
            min-height: 0;
            grid-template-rows: auto minmax(0, 1fr) auto;
            border-left: 1px solid var(--doc-preview-border);
            background: var(--doc-preview-surface);
        }

        .employee-document-preview-sidebar-title {
            display: flex;
            align-items: center;
            gap: 7px;
            min-height: 46px;
            margin: 0;
            padding: 0 12px;
            border-bottom: 1px solid var(--doc-preview-border);
            color: var(--doc-preview-muted);
            font-size: 0.65rem;
            font-weight: 800;
            text-transform: uppercase;
        }

        .employee-document-preview-list {
            display: grid;
            align-content: start;
            gap: 8px;
            overflow-y: auto;
            padding: 10px;
        }

        .employee-document-preview-list-item {
            display: grid;
            width: 100%;
            grid-template-columns: 34px minmax(0, 1fr) auto;
            align-items: center;
            gap: 9px;
            min-height: 62px;
            border: 1px solid var(--doc-preview-border);
            border-radius: 6px;
            background: var(--doc-preview-surface);
            padding: 8px;
            color: var(--doc-preview-text);
            text-align: left;
            transition: border-color 160ms ease, background-color 160ms ease;
        }

        .employee-document-preview-list-item:hover,
        .employee-document-preview-list-item:focus-visible,
        .employee-document-preview-list-item.is-selected {
            border-color: color-mix(in srgb, var(--doc-preview-accent) 42%, var(--doc-preview-border));
            background: color-mix(in srgb, var(--doc-preview-accent) 5%, #ffffff);
            outline: none;
        }

        .employee-document-preview-list-mark {
            display: inline-flex;
            width: 34px;
            height: 38px;
            align-items: center;
            justify-content: center;
            border: 1px solid color-mix(in srgb, var(--doc-preview-accent) 20%, var(--doc-preview-border));
            border-radius: 5px;
            background: color-mix(in srgb, var(--doc-preview-accent) 7%, #ffffff);
            color: var(--doc-preview-accent);
            font-size: 0.55rem;
            font-weight: 900;
        }

        .employee-document-preview-list-copy {
            min-width: 0;
        }

        .employee-document-preview-list-copy strong,
        .employee-document-preview-list-copy small {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .employee-document-preview-list-copy strong {
            font-size: 0.72rem;
        }

        .employee-document-preview-list-copy small {
            margin-top: 3px;
            color: var(--doc-preview-muted);
            font-size: 0.58rem;
            font-weight: 700;
        }

        .employee-document-preview-view-label {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            border-radius: 5px;
            background: color-mix(in srgb, var(--doc-preview-accent) 8%, #ffffff);
            padding: 5px 7px;
            color: var(--doc-preview-accent);
            font-size: 0.61rem;
            font-weight: 800;
        }

        .employee-document-preview-security {
            padding: 12px;
            border-top: 1px solid var(--doc-preview-border);
            background: var(--doc-preview-muted-surface);
        }

        .employee-document-preview-security strong,
        .employee-document-preview-security small {
            display: block;
        }

        .employee-document-preview-security strong {
            color: var(--doc-preview-text);
            font-size: 0.68rem;
        }

        .employee-document-preview-security small {
            margin-top: 4px;
            color: var(--doc-preview-muted);
            font-size: 0.56rem;
            font-weight: 600;
            line-height: 1.45;
        }

        html[data-appearance-theme="dark"] #employeeDocumentPreviewModal,
        #employeeDocumentPreviewModal.employee-document-preview-dark {
            --doc-preview-surface: #17211d;
            --doc-preview-muted-surface: #1d2923;
            --doc-preview-border: #3a4b41;
            --doc-preview-text: #edf5f0;
            --doc-preview-muted: #a8bbb0;
        }

        html[data-appearance-theme="dark"] #employeeDocumentPreviewModal :is(.employee-document-preview-stage, .employee-document-preview-empty),
        #employeeDocumentPreviewModal.employee-document-preview-dark :is(.employee-document-preview-stage, .employee-document-preview-empty) {
            background: #111916;
        }

        @media (max-width: 767px) {
            #employeeDocumentPreviewModal .modal-dialog {
                width: calc(100% - 1rem);
                margin: 0.5rem auto;
            }

            #employeeDocumentPreviewModal .modal-content {
                height: calc(100vh - 1rem);
            }

            .employee-document-preview-body {
                grid-template-columns: 1fr;
                grid-template-rows: minmax(360px, 1fr) minmax(220px, 42vh);
                overflow-y: auto;
            }

            .employee-document-preview-sidebar {
                min-height: 300px;
                border-top: 1px solid var(--doc-preview-border);
                border-left: 0;
            }

            .employee-document-preview-stage {
                padding: 10px;
            }

            .employee-document-preview-canvas,
            .employee-document-preview-frame,
            .employee-document-preview-empty {
                min-height: 420px;
            }

            .employee-document-preview-heading p {
                max-width: 210px;
            }
        }
    </style>

    <div class="modal fade animate__animated fadeIn" id="editUserModel" tabindex="-1"
        aria-labelledby="editUserModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form id="editUsersForm">
                    <div class="modal-body"></div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="employeeDocumentPreviewModal" tabindex="-1"
        aria-labelledby="employeeDocumentPreviewTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <header class="employee-document-preview-header">
                    <span class="employee-document-preview-header-icon" aria-hidden="true"><i class="ti ti-file-description"></i></span>
                    <div class="employee-document-preview-heading">
                        <h5 id="employeeDocumentPreviewTitle">Employee Document Preview</h5>
                        <p id="employeeDocumentPreviewReference">Internal Reference Only</p>
                    </div>
                    <div class="employee-document-preview-header-actions">
                        <button type="button" class="employee-document-preview-icon-button" id="employeeDocumentPrintBtn"
                            title="Print document" aria-label="Print document" disabled><i class="ti ti-printer"></i></button>
                        <button type="button" class="employee-document-preview-icon-button" data-bs-dismiss="modal"
                            title="Close preview" aria-label="Close preview"><i class="ti ti-x"></i></button>
                    </div>
                </header>
                <div class="employee-document-preview-body">
                    <main class="employee-document-preview-stage" aria-live="polite">
                        <div class="employee-document-preview-canvas" id="employeeDocumentPreviewCanvas"></div>
                    </main>
                    <aside class="employee-document-preview-sidebar" aria-label="Employee documents">
                        <h6 class="employee-document-preview-sidebar-title"><i class="ti ti-folder"></i> Other Documents</h6>
                        <div class="employee-document-preview-list" id="employeeDocumentPreviewList"></div>
                        <div class="employee-document-preview-security">
                            <strong><i class="ti ti-lock"></i> Secure Access Protocol</strong>
                            <small>These documents are view-only employee records. Access is limited to authorized users.</small>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="changePasswordUserModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 ring-1 ring-indigo-900/10">
                            <i class="ti ti-key text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Change
                                Password</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Set a new password for this user account
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="changePasswordForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="space-y-4">
                            <div>
                                <label for="userNewPassword" class="mb-1 block text-sm font-medium text-slate-800">Enter
                                    New Password</label>
                                <div
                                    class="flex overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm ring-1 ring-slate-900/5">
                                    <input type="password" id="userNewPassword"
                                        class="min-h-[44px] flex-grow border-0 bg-white px-4 py-2 text-sm font-medium text-slate-700 outline-none placeholder:text-slate-400 focus:ring-0"
                                        name="userNewPassword" autocomplete="off" placeholder="Enter password"
                                        aria-describedby="password" required />
                                    <span
                                        class="seeUserNewPassword inline-flex w-12 cursor-pointer items-center justify-center text-slate-500 hover:bg-slate-50"><i
                                            class="ti ti-eye-off text-lg"></i></span>
                                </div>
                                <input type="hidden" name="user_id" id="user_id" value="" />
                            </div>
                            <div>
                                <label for="userNewConfirmPassword"
                                    class="mb-1 block text-sm font-medium text-slate-800">Confirm New Password</label>
                                <div
                                    class="flex overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm ring-1 ring-slate-900/5">
                                    <input type="password" id="userNewConfirmPassword"
                                        class="min-h-[44px] flex-grow border-0 bg-white px-4 py-2 text-sm font-medium text-slate-700 outline-none placeholder:text-slate-400 focus:ring-0"
                                        name="userNewConfirmPassword" autocomplete="off" placeholder="Confirm password"
                                        aria-describedby="password" required />
                                    <span
                                        class="seeUserNewConfirmPassword inline-flex w-12 cursor-pointer items-center justify-center text-slate-500 hover:bg-slate-50"><i
                                            class="ti ti-eye-off text-lg"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center rounded-2xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="submitChangePasswordBtn"><i class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="userExtraPermissionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-shield-lock text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">User
                                Permissions</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review and save extra permission access
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="userPermissionForm">
                    <div class="modal-body max-h-[70vh] overflow-y-auto bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';

    const roleWidgetState = {
        roles: [],
        userCounts: new Map(),
        page: 1,
        perPage: 10,
        search: '',
        sort: 'name_asc',
        view: 'roles'
    };

    function roleWidgetRequest(data) {
        return $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: data,
            dataType: 'json'
        });
    }

    function parseRoleWidgetRows(tableHtml) {
        const wrapper = $('<table><tbody></tbody></table>');
        wrapper.find('tbody').html(tableHtml || '');
        const roles = [];

        wrapper.find('tbody > tr').each(function () {
            const row = $(this);
            const cells = row.children('td');
            if (cells.length < 4) return;

            const name = cells.eq(1).text().trim();
            if (!name) return;
            roles.push({
                id: Number(row.find('.editRolesBtn').first().data('id') || 0),
                name: name,
                description: cells.eq(2).text().trim(),
                status: cells.eq(3).text().trim() || 'Inactive'
            });
        });

        return roles;
    }

    function parseRoleWidgetUsers(tableHtml) {
        const wrapper = $('<table><tbody></tbody></table>');
        wrapper.find('tbody').html(tableHtml || '');
        const counts = new Map();

        wrapper.find('tbody > tr').each(function () {
            const cells = $(this).children('td');
            if (cells.length < 4) return;
            const userName = cells.eq(1).text().trim();
            const roleName = cells.eq(3).text().trim();
            if (!userName || !roleName || roleName === 'N/A') return;

            const key = roleName.toLowerCase();
            if (!counts.has(key)) counts.set(key, { count: 0, users: [] });
            const entry = counts.get(key);
            entry.count += 1;
            entry.users.push(userName);
        });

        return counts;
    }

    function getRoleWidgetInitials(name) {
        const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
        if (!parts.length) return 'U';
        return (parts[0].charAt(0) + (parts.length > 1 ? parts[parts.length - 1].charAt(0) : '')).toUpperCase();
    }

    function getRoleWidgetIcon(roleName, index) {
        const name = String(roleName || '').toLowerCase();
        if (name.includes('admin') || name.includes('security')) return 'ti-shield-lock';
        if (name.includes('quality') || name.includes('qc') || name.includes('qa')) return 'ti-microscope';
        if (name.includes('warehouse') || name.includes('store')) return 'ti-building-warehouse';
        if (name.includes('logistic') || name.includes('dispatch')) return 'ti-truck';
        if (name.includes('human') || name.includes('hr')) return 'ti-id';
        if (name.includes('finance') || name.includes('account')) return 'ti-building-bank';
        if (name.includes('operation') || name.includes('production')) return 'ti-settings';
        return ['ti-users', 'ti-checklist', 'ti-briefcase'][index % 3];
    }

    function appendRoleWidgetPaginationButton(container, label, page, options) {
        const button = $('<button>', {
            type: 'button',
            class: 'users-role-widget-page-button',
            'data-role-widget-page': page,
            'aria-label': options.ariaLabel || label,
            disabled: Boolean(options.disabled)
        });
        if (options.icon) button.append($('<i>').addClass('ti ' + options.icon).attr('aria-hidden', 'true'));
        else button.text(label);
        if (options.active) button.addClass('is-active').attr('aria-current', 'page');
        container.append(button);
    }

    function getFilteredRoleWidgets() {
        const search = roleWidgetState.search.toLowerCase();
        const filteredRoles = roleWidgetState.roles.filter(function (role) {
            const permissionNames = (role.permissions || []).map(function (permission) { return permission.name; }).join(' ');
            const searchable = [role.name, role.description, role.department_name, permissionNames].join(' ').toLowerCase();
            return !search || searchable.includes(search);
        });

        filteredRoles.sort(function (left, right) {
            const nameComparison = String(left.name || '').localeCompare(String(right.name || ''));
            if (roleWidgetState.sort === 'name_desc') return -nameComparison;
            if (roleWidgetState.sort === 'status') return Number(right.status) - Number(left.status) || nameComparison;
            if (roleWidgetState.sort === 'department') {
                return String(left.department_name || 'Not assigned').localeCompare(String(right.department_name || 'Not assigned')) || nameComparison;
            }
            if (roleWidgetState.sort === 'users_desc') return Number(right.user_count || 0) - Number(left.user_count || 0) || nameComparison;
            if (roleWidgetState.sort === 'permissions_desc') return Number(right.permission_count || 0) - Number(left.permission_count || 0) || nameComparison;
            return nameComparison;
        });
        return filteredRoles;
    }

    function getRoleWidgetPageData() {
        const filteredRoles = getFilteredRoleWidgets();
        const usesAll = roleWidgetState.perPage >= 100000000;
        const pageSize = usesAll ? Math.max(filteredRoles.length, 1) : roleWidgetState.perPage;
        const totalPages = Math.max(1, Math.ceil(filteredRoles.length / pageSize));
        roleWidgetState.page = Math.min(roleWidgetState.page, totalPages);
        const start = (roleWidgetState.page - 1) * pageSize;
        return {
            roles: filteredRoles.slice(start, start + pageSize),
            totalPages: totalPages,
            usesAll: usesAll,
            start: start
        };
    }

    function renderRoleWidgetPagination(container, pageData) {
        container.empty();
        if (pageData.usesAll || pageData.totalPages <= 1) return;
        appendRoleWidgetPaginationButton(container, 'Previous', roleWidgetState.page - 1, {
            ariaLabel: 'Previous role page',
            icon: 'ti-chevron-left',
            disabled: roleWidgetState.page === 1
        });
        for (let page = 1; page <= pageData.totalPages; page += 1) {
            appendRoleWidgetPaginationButton(container, String(page), page, {
                active: page === roleWidgetState.page
            });
        }
        appendRoleWidgetPaginationButton(container, 'Next', roleWidgetState.page + 1, {
            ariaLabel: 'Next role page',
            icon: 'ti-chevron-right',
            disabled: roleWidgetState.page === pageData.totalPages
        });
    }

    function renderRoleWidgets() {
        const pageData = getRoleWidgetPageData();
        const visibleRoles = pageData.roles;
        const cards = $('#usersRoleCards').empty();
        const empty = $('#usersRoleCardsEmpty');

        empty.prop('hidden', visibleRoles.length > 0);
        visibleRoles.forEach(function (role, index) {
            const users = Array.isArray(role.users) ? role.users : [];
            const userCount = Number(role.user_count || users.length || 0);
            const canEdit = Boolean(role.can_edit && role.id > 0);
            const card = $('<article>', { class: 'user-role-widget', 'data-id': role.id });
            const isActive = Number(role.status) === 1;
            if (!isActive) card.addClass('is-inactive');
            if (canEdit) {
                card.addClass('is-editable editRoleCardBtn')
                    .attr({ role: 'button', tabindex: 0, 'aria-label': 'Edit ' + role.name + ' role' });
            }

            const head = $('<div>').addClass('user-role-widget-head').appendTo(card);
            $('<span>').addClass('user-role-widget-icon')
                .append($('<i>').addClass('ti ' + getRoleWidgetIcon(role.name, pageData.start + index)).attr('aria-hidden', 'true'))
                .appendTo(head);
            const headActions = $('<span>').addClass('user-role-widget-head-actions').appendTo(head);
            $('<span>').addClass('user-role-widget-count')
                .text(userCount + (userCount === 1 ? ' User' : ' Users'))
                .appendTo(headActions);
            if (role.can_delete && !role.is_system) {
                $('<button>', {
                    type: 'button',
                    class: 'user-role-widget-delete deleteRoleCardBtn',
                    'data-id': role.id,
                    title: 'Delete role',
                    'aria-label': 'Delete ' + role.name + ' role'
                }).append($('<i>').addClass('ti ti-trash').attr('aria-hidden', 'true')).appendTo(headActions);
            }
            $('<h3>').addClass('user-role-widget-name').text(role.name).appendTo(card);
            $('<p>').addClass('user-role-widget-description')
                .text(role.description || 'No role description provided.')
                .appendTo(card);

            const footer = $('<div>').addClass('user-role-widget-footer').appendTo(card);
            const avatars = $('<div>').addClass('user-role-widget-avatars').appendTo(footer);
            users.slice(0, 3).forEach(function (user) {
                const userName = user.name || 'Unnamed User';
                $('<span>').addClass('user-role-widget-avatar').attr('title', userName).text(getRoleWidgetInitials(userName)).appendTo(avatars);
            });
            if (!users.length) {
                $('<span>').addClass('user-role-widget-more').text('No assigned users').appendTo(avatars);
            } else if (userCount > 3) {
                $('<span>').addClass('user-role-widget-more').text('+' + (userCount - 3)).appendTo(avatars);
            }
            $('<span>').addClass('user-role-widget-status').text(isActive ? 'Active' : 'Inactive').appendTo(footer);
            cards.append(card);
        });

        renderRoleWidgetPagination($('#usersRoleCardsPagination'), pageData);
    }

    function renderRolePermissionOverview() {
        const body = $('#usersRolePermissionsBody');
        if (!body.length) return;
        const pageData = getRoleWidgetPageData();
        body.empty();
        pageData.roles.forEach(function (role) {
            const row = $('<tr>');
            const roleCell = $('<td>').appendTo(row);
            $('<strong>').text(role.name).appendTo(roleCell);
            $('<div>').addClass('users-role-permission-summary')
                .text(Number(role.user_count || 0) + (Number(role.user_count || 0) === 1 ? ' assigned user' : ' assigned users'))
                .appendTo(roleCell);
            $('<td>').text(role.department_name || 'Not assigned').appendTo(row);

            const permissions = Array.isArray(role.permissions) ? role.permissions : [];
            const permissionText = permissions.slice(0, 3).map(function (permission) { return permission.name; }).join(', ');
            const permissionCell = $('<td>').appendTo(row);
            $('<strong>').text(Number(role.permission_count || permissions.length) + ' permissions').appendTo(permissionCell);
            $('<div>').addClass('users-role-permission-summary')
                .text(permissionText ? permissionText + (permissions.length > 3 ? ' +' + (permissions.length - 3) + ' more' : '') : 'No permissions assigned')
                .appendTo(permissionCell);

            $('<td>').append($('<span>').addClass('user-role-widget-status').text(Number(role.status) === 1 ? 'Active' : 'Inactive')).appendTo(row);
            const actionCell = $('<td>').css('text-align', 'center').appendTo(row);
            if (role.can_manage_permissions) {
                $('<button>', {
                    type: 'button',
                    class: 'users-role-permission-edit editRolePermissionsBtn',
                    'data-id': role.id,
                    title: 'Edit role permissions',
                    'aria-label': 'Edit permissions for ' + role.name
                }).append($('<i>').addClass('ti ti-pencil').attr('aria-hidden', 'true')).appendTo(actionCell);
            } else {
                $('<span>').text('-').appendTo(actionCell);
            }
            body.append(row);
        });
        if (!pageData.roles.length) {
            $('<tr>').append($('<td>', { colspan: 5 }).css('text-align', 'center').text('No roles found.')).appendTo(body);
        }
        renderRoleWidgetPagination($('#usersRolePermissionsPagination'), pageData);
    }

    function renderActiveRoleView() {
        const permissionsView = roleWidgetState.view === 'permissions' && $('#usersRolePermissionsView').length;
        $('#usersRolesView').prop('hidden', Boolean(permissionsView));
        $('#usersRolePermissionsView').prop('hidden', !permissionsView);
        $('.users-role-view-tab').each(function () {
            const isActive = $(this).data('role-view') === roleWidgetState.view;
            $(this).toggleClass('is-active', isActive).attr('aria-selected', isActive ? 'true' : 'false');
        });
        if (permissionsView) renderRolePermissionOverview();
        else renderRoleWidgets();
    }

    async function loadRoleWidgets() {
        $('#usersRoleCardsEmpty').prop('hidden', true);
        $('#usersRoleCardsPagination').empty();
        $('#usersRoleCards').html('<div class="users-role-widget-loading" style="grid-column: 1 / -1;"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></div>');

        try {
            const response = await roleWidgetRequest({ loadRoleManagementOverview: 'loadRoleManagementOverview' });
            if (!response || response.status !== 'success') throw new Error('Unable to load role management.');
            roleWidgetState.roles = Array.isArray(response.roles) ? response.roles : [];
            renderActiveRoleView();
        } catch (error) {
            roleWidgetState.roles = [];
            renderActiveRoleView();
            toastr.error('Unable to load role management.');
        }
    }

    const roleWizardState = {
        mode: 'create',
        step: 1,
        ready: false,
        submitting: false,
        roleId: 0,
        loadToken: 0,
        baseline: null,
        departments: [],
        permissions: [],
        employees: [],
        selectedPermissions: new Set(),
        selectedUsers: new Set()
    };

    function getRoleWizardSnapshot() {
        return JSON.stringify({
            department: String($('#roleWizardDepartment').val() || ''),
            name: String($('#roleWizardName').val() || '').trim(),
            description: String($('#roleWizardDescription').val() || '').trim(),
            status: String($('[name="roleWizardStatus"]:checked').val() || ''),
            permissions: [...roleWizardState.selectedPermissions].sort(),
            users: [...roleWizardState.selectedUsers].sort()
        });
    }

    function roleWizardHasChanges() {
        if (roleWizardState.mode !== 'edit' || roleWizardState.baseline === null) return true;
        return getRoleWizardSnapshot() !== roleWizardState.baseline;
    }

    const roleWizardCategoryLabels = {
        '1': 'Worker',
        '2': 'Employee',
        '3': 'House Keeping',
        '4': 'Store'
    };

    function roleWizardRequest(data, dataType) {
        return new Promise(function (resolve, reject) {
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: data,
                dataType: dataType,
                success: resolve,
                error: reject
            });
        });
    }

    function parseRoleWizardResponse(response) {
        if (typeof response !== 'string') return response;
        try {
            return JSON.parse(response);
        } catch (error) {
            return response;
        }
    }

    function syncRoleWizardAppearance() {
        const theme = document.documentElement.getAttribute('data-appearance-theme') || 'light';
        const isDark = theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        $('#createRoleWorkflowModal').toggleClass('role-wizard-dark', isDark);
    }

    function getRoleWizardSubmitLabel() {
        return roleWizardState.mode === 'edit' ? 'Update Role  \u2192' : 'Submit  \u2192';
    }

    function syncRoleWizardCopy() {
        const isEdit = roleWizardState.mode === 'edit';
        $('#createRoleWorkflowTitle').text(isEdit ? 'Edit Role' : 'Create New Role');
        $('#roleWizardDetailsHelp').text(isEdit
            ? 'Step 1 of 4: Review and update the role identity, department, and status.'
            : 'Step 1 of 4: Define the role identity and department for the new access level.');
        $('#roleWizardReviewHelp').text(isEdit
            ? 'Step 4 of 4: Review all role changes before updating.'
            : 'Step 4 of 4: Review the role, permissions, and selected users before submitting.');
        $('#roleWizardProgress').attr('aria-label', isEdit ? 'Role editing progress' : 'Role creation progress');
        $('#roleWizardStatusField').prop('hidden', !isEdit);
        $('#roleWizardSubmitBtn').text(getRoleWizardSubmitLabel());
    }

    function resetRoleWizard(mode) {
        const form = document.getElementById('createRoleWorkflowForm');
        if (form) form.reset();
        roleWizardState.mode = mode === 'edit' ? 'edit' : 'create';
        roleWizardState.step = 1;
        roleWizardState.ready = false;
        roleWizardState.submitting = false;
        roleWizardState.roleId = 0;
        roleWizardState.loadToken += 1;
        roleWizardState.baseline = null;
        roleWizardState.departments = [];
        roleWizardState.permissions = [];
        roleWizardState.employees = [];
        roleWizardState.selectedPermissions.clear();
        roleWizardState.selectedUsers.clear();
        $('#roleWizardPermissionGrid, #roleWizardUserRows, #roleWizardReviewDetails, #roleWizardReviewPermissions, #roleWizardReviewUsers').empty();
        $('#roleWizardSelectedUsers').html('<span>No users selected</span>');
        $('#roleWizardDescriptionCount').text('0 / 250');
        $('#roleWizardPermissionSearch, #roleWizardUserSearch').val('');
        $('#roleWizardLoading').removeClass('is-visible');
        $('#roleWizardSubmitBtn').prop('disabled', false);
        syncRoleWizardCopy();
        syncRoleWizardStep();
    }

    function syncRoleWizardStep() {
        const step = roleWizardState.step;
        $('[data-role-wizard-step]').removeClass('is-active');
        $('[data-role-wizard-step="' + step + '"]').addClass('is-active');
        $('[data-role-wizard-progress]').each(function () {
            const itemStep = Number($(this).data('role-wizard-progress'));
            $(this).toggleClass('is-active', itemStep === step);
            $(this).toggleClass('is-complete', itemStep < step);
        });
        $('#roleWizardProgressFill').css('width', ((step - 1) * 25) + '%');
        $('#roleWizardBackBtn').prop('disabled', step === 1 || roleWizardState.submitting);
        $('#roleWizardNextBtn').prop('hidden', step === 4).prop('disabled', !roleWizardState.ready || roleWizardState.submitting);
        const hasChanges = roleWizardHasChanges();
        $('#roleWizardSubmitBtn').prop('hidden', step !== 4 || !hasChanges);
        $('#roleWizardFinishBtn').prop('hidden', step !== 4 || hasChanges);

        if (step === 2) {
            $('#roleWizardPermissionRole').text($('#roleWizardName').val().trim() || '-');
        }
        if (step === 4) renderRoleWizardReview();
    }

    function validateRoleWizardStep(step) {
        if (step === 1) {
            if ($('#roleWizardDepartment').val() === '') {
                toastr.error('Please select a department.');
                $('#roleWizardDepartment').trigger('focus');
                return false;
            }
            if (!$('#roleWizardName').val().trim()) {
                toastr.error('Please enter a role name.');
                $('#roleWizardName').trigger('focus');
                return false;
            }
            if (!$('#roleWizardDescription').val().trim()) {
                toastr.error('Please enter a role description.');
                $('#roleWizardDescription').trigger('focus');
                return false;
            }
        }
        if (step === 2 && roleWizardState.mode === 'create' && roleWizardState.selectedPermissions.size === 0) {
            toastr.error('Please select at least one permission.');
            return false;
        }
        if (step === 3 && roleWizardState.mode === 'create' && roleWizardState.selectedUsers.size === 0) {
            toastr.error('Please select at least one onboarded user.');
            return false;
        }
        return true;
    }

    function renderRoleWizardPermissions() {
        const search = $('#roleWizardPermissionSearch').val().trim().toLowerCase();
        const grid = $('#roleWizardPermissionGrid').empty();
        const visiblePermissions = roleWizardState.permissions.filter(function (permission) {
            return !search || permission.name.toLowerCase().includes(search);
        });

        visiblePermissions.forEach(function (permission) {
            const label = $('<label>').addClass('role-wizard-check-row');
            $('<input>', {
                type: 'checkbox',
                class: 'role-wizard-permission-check',
                value: permission.id,
                checked: roleWizardState.selectedPermissions.has(String(permission.id))
            }).appendTo(label);
            $('<span>').text(permission.name).appendTo(label);
            grid.append(label);
        });

        if (!visiblePermissions.length) {
            $('<div>').addClass('role-wizard-check-row').text('No permissions found.').appendTo(grid);
        }
    }

    function renderRoleWizardUserCategories() {
        const select = $('#roleWizardUserCategoryFilter');
        const currentValue = select.val() || '';
        select.html('<option value="">All employee categories</option>');
        const categories = [...new Set(roleWizardState.employees.map(function (employee) { return employee.category; }).filter(Boolean))].sort();
        categories.forEach(function (category) {
            $('<option>', { value: category, text: category }).appendTo(select);
        });
        select.val(currentValue).trigger('change.select2');
    }

    function getRoleWizardInitials(name) {
        const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
        if (!parts.length) return 'U';
        return (parts[0].charAt(0) + (parts.length > 1 ? parts[parts.length - 1].charAt(0) : '')).toUpperCase();
    }

    function renderRoleWizardUsers() {
        const search = $('#roleWizardUserSearch').val().trim().toLowerCase();
        const category = $('#roleWizardUserCategoryFilter').val();
        const rows = $('#roleWizardUserRows').empty();
        const employees = roleWizardState.employees.filter(function (employee) {
            const matchesCategory = !category || employee.category === category;
            const searchable = [employee.name, employee.empCode, employee.email, employee.designation].join(' ').toLowerCase();
            return matchesCategory && (!search || searchable.includes(search));
        });

        employees.forEach(function (employee) {
            const row = $('<tr>');
            const checkCell = $('<td>').appendTo(row);
            $('<input>', {
                type: 'checkbox',
                class: 'role-wizard-user-check',
                value: employee.userId,
                checked: roleWizardState.selectedUsers.has(String(employee.userId)),
                'aria-label': 'Select ' + employee.name
            }).appendTo(checkCell);

            const userCell = $('<td>').appendTo(row);
            const userWrap = $('<div>').addClass('role-wizard-user-cell').appendTo(userCell);
            $('<span>').addClass('role-wizard-user-avatar').text(getRoleWizardInitials(employee.name)).appendTo(userWrap);
            const identity = $('<span>').appendTo(userWrap);
            $('<strong>').css('display', 'block').text(employee.name).appendTo(identity);
            $('<small>').css({ display: 'block', color: 'var(--rw-muted)', marginTop: '2px' }).text(employee.empCode || 'No employee ID').appendTo(identity);

            $('<td>').text(employee.category || 'Not assigned').appendTo(row);
            $('<td>').text(employee.designation || 'Not assigned').appendTo(row);
            $('<td>').text(employee.email || 'Not available').appendTo(row);
            const statusCell = $('<td>').appendTo(row);
            $('<span>').addClass('role-wizard-active-badge').text(employee.status).appendTo(statusCell);
            rows.append(row);
        });

        if (!employees.length) {
            $('<tr>').append($('<td>', { colspan: 6 }).css('text-align', 'center').text('No onboarded employees found.')).appendTo(rows);
        }
        renderRoleWizardSelectedUsers();
    }

    function renderRoleWizardSelectedUsers() {
        const selected = roleWizardState.employees.filter(function (employee) {
            return roleWizardState.selectedUsers.has(String(employee.userId));
        });
        const container = $('#roleWizardSelectedUsers').empty();
        if (!selected.length) {
            container.append($('<span>').text('No users selected'));
            return;
        }
        selected.slice(0, 5).forEach(function (employee) {
            $('<span>').addClass('role-wizard-chip').text(employee.name).appendTo(container);
        });
        if (selected.length > 5) {
            $('<span>').addClass('role-wizard-chip').text('+' + (selected.length - 5) + ' more').appendTo(container);
        }
    }

    function renderRoleWizardReview() {
        const departmentName = $('#roleWizardDepartment option:selected').text();
        const roleName = $('#roleWizardName').val().trim();
        const description = $('#roleWizardDescription').val().trim();
        const status = Number($('[name="roleWizardStatus"]:checked').val() || 0) === 1 ? 'Active' : 'Inactive';
        const details = $('#roleWizardReviewDetails').empty();
        const detailItems = [
            ['Department', departmentName],
            ['Role', roleName],
            ['Description', description],
            ['Users Selected', String(roleWizardState.selectedUsers.size)]
        ];
        if (roleWizardState.mode === 'edit') detailItems.splice(3, 0, ['Status', status]);
        detailItems.forEach(function (item) {
            const wrapper = $('<div>').addClass('role-wizard-review-item').appendTo(details);
            $('<span>').text(item[0]).appendTo(wrapper);
            $('<strong>').text(item[1]).appendTo(wrapper);
        });

        const selectedPermissions = roleWizardState.permissions.filter(function (permission) {
            return roleWizardState.selectedPermissions.has(String(permission.id));
        });
        $('#roleWizardReviewPermissionsTitle').text('Selected Permissions (' + selectedPermissions.length + ')');
        const permissionList = $('#roleWizardReviewPermissions').empty();
        selectedPermissions.forEach(function (permission) {
            $('<li>').text(permission.name).appendTo(permissionList);
        });
        if (!selectedPermissions.length) $('<li>').text('No permissions assigned').appendTo(permissionList);

        const selectedUsers = roleWizardState.employees.filter(function (employee) {
            return roleWizardState.selectedUsers.has(String(employee.userId));
        });
        $('#roleWizardReviewUsersTitle').text('Assigned Users (' + selectedUsers.length + ')');
        const userList = $('#roleWizardReviewUsers').empty();
        selectedUsers.forEach(function (employee) {
            $('<li>').text(employee.name + (employee.empCode ? ' - ' + employee.empCode : '')).appendTo(userList);
        });
        if (!selectedUsers.length) $('<li>').text('No users assigned').appendTo(userList);
    }

    async function loadRoleWizardData(editRoleId) {
        const requestedRoleId = Number(editRoleId || 0);
        const loadToken = roleWizardState.loadToken;
        roleWizardState.ready = false;
        $('#roleWizardLoading').addClass('is-visible');
        syncRoleWizardStep();
        try {
            const requests = [
                roleWizardRequest({ getDepartmentList: 'getDepartmentList' }, 'json'),
                roleWizardRequest({ loadPermissionOptions: 'loadPermissionOptions' }),
                roleWizardRequest({ loadRoleAssignableUsers: 'loadRoleAssignableUsers' }, 'json'),
                roleWizardRequest({ loadDesignationsOptions: 'loadDesignationsOptions' }, 'json')
            ];
            if (requestedRoleId) {
                requests.push(roleWizardRequest({ fetchRoleWorkflowRecord: 'fetchRoleWorkflowRecord', id: requestedRoleId }, 'json'));
            }
            const responses = await Promise.all(requests);
            if (loadToken !== roleWizardState.loadToken || requestedRoleId !== roleWizardState.roleId) return;

            const workflowResponse = requestedRoleId ? responses[4] : null;
            if (requestedRoleId && (!workflowResponse || workflowResponse.status !== 'success')) {
                throw new Error((workflowResponse && workflowResponse.message) || 'Unable to load this role.');
            }
            const roleRecord = workflowResponse ? workflowResponse.role : null;
            roleWizardState.selectedPermissions = new Set(
                workflowResponse ? (workflowResponse.permission_ids || []).map(String) : []
            );
            roleWizardState.selectedUsers = new Set(
                workflowResponse ? (workflowResponse.assigned_users || []).map(function (user) { return String(user.userId); }) : []
            );

            roleWizardState.departments = Array.isArray(responses[0]) ? responses[0] : [];
            const permissionResponse = parseRoleWizardResponse(responses[1]);
            roleWizardState.permissions = (Array.isArray(permissionResponse) ? permissionResponse : []).map(function (permission) {
                return { id: Number(permission.key), name: String(permission.value || '') };
            }).sort(function (a, b) { return a.name.localeCompare(b.name); });

            const designations = Array.isArray(responses[3]) ? responses[3] : [];
            const designationMap = {};
            designations.forEach(function (designation) { designationMap[String(designation.id)] = designation.name; });

            const employeeMap = new Map();
            (Array.isArray(responses[2]) ? responses[2] : []).forEach(function (employee) {
                const userId = Number(employee.user_id || 0);
                if (!userId || employeeMap.has(userId)) return;
                const name = [employee.first_name, employee.last_name].filter(Boolean).join(' ').trim() || employee.user_email || 'Unnamed User';
                employeeMap.set(userId, {
                    userId: userId,
                    name: name,
                    empCode: String(employee.emp_code || ''),
                    email: String(employee.user_email || employee.email || ''),
                    category: roleWizardCategoryLabels[String(employee.emp_categ_type || '')] || 'Other',
                    designation: designationMap[String(employee.designation_id || '')] || 'Not assigned',
                    status: Number(employee.is_login_allowed || 0) === 1 ? 'Active' : 'Onboarded'
                });
            });
            (workflowResponse ? workflowResponse.assigned_users || [] : []).forEach(function (user) {
                const userId = Number(user.userId || 0);
                if (!userId || employeeMap.has(userId)) return;
                employeeMap.set(userId, {
                    userId: userId,
                    name: String(user.name || user.email || 'Unnamed User'),
                    empCode: String(user.empCode || ''),
                    email: String(user.email || ''),
                    category: String(user.category || 'Other'),
                    designation: String(user.designation || 'Not assigned'),
                    status: String(user.status || 'Onboarded')
                });
            });
            roleWizardState.employees = [...employeeMap.values()].sort(function (a, b) { return a.name.localeCompare(b.name); });

            const departmentSelect = $('#roleWizardDepartment').html('<option value="">Choose a department...</option>');
            if (roleWizardState.mode === 'edit') {
                $('<option>', { value: 0, text: 'Not assigned' }).appendTo(departmentSelect);
            }
            roleWizardState.departments.forEach(function (department) {
                $('<option>', { value: department.id, text: department.name }).appendTo(departmentSelect);
            });
            if (roleRecord) {
                const departmentId = Number(roleRecord.department_id || 0);
                if (departmentId > 0 && !departmentSelect.find('option[value="' + departmentId + '"]').length) {
                    $('<option>', {
                        value: departmentId,
                        text: String(roleRecord.department_name || ('Department #' + departmentId)) + ' (Unavailable)'
                    }).appendTo(departmentSelect);
                }
                departmentSelect.val(String(departmentId)).trigger('change.select2');
                $('#roleWizardName').val(roleRecord.name || '');
                $('#roleWizardDescription').val(roleRecord.description || '');
                $('[name="roleWizardStatus"][value="' + Number(roleRecord.status) + '"]').prop('checked', true);
                $('#roleWizardDescriptionCount').text(String((roleRecord.description || '').length) + ' / 250');
            }
            renderRoleWizardPermissions();
            renderRoleWizardUserCategories();
            renderRoleWizardUsers();
            roleWizardState.ready = true;
            roleWizardState.baseline = roleWizardState.mode === 'edit' ? getRoleWizardSnapshot() : null;
        } catch (error) {
            toastr.error(error.message || 'Unable to load role workflow data. Please try again.');
        } finally {
            if (loadToken === roleWizardState.loadToken) {
                $('#roleWizardLoading').removeClass('is-visible');
                syncRoleWizardStep();
            }
        }
    }

    async function resolveRoleWizardRoleId(roleName) {
        const response = parseRoleWizardResponse(await roleWizardRequest({ loadRolesOptions: 'loadRolesOptions' }));
        const match = (Array.isArray(response) ? response : []).find(function (role) {
            return String(role.value || '').trim().toLowerCase() === roleName.trim().toLowerCase();
        });
        return match ? Number(match.key) : 0;
    }

    async function assignRoleWizardUser(userId, roleId) {
        const fetchResponse = parseRoleWizardResponse(await roleWizardRequest({ fetchUserRecord: 'fetchUserRecord', id: userId }));
        if (!fetchResponse || fetchResponse.status !== 'success') {
            throw new Error('Unable to load user ' + userId + '.');
        }
        const holder = $('<div>').html(fetchResponse.data);
        const updatePayload = {
            updateUsers: 'updateUsers',
            userIdEdit: Number(userId),
            userNameEdit: holder.find('[name="userNameEdit"]').val() || '',
            userEmailEdit: holder.find('[name="userEmailEdit"]').val() || '',
            userRoleTypeEdit: Number(roleId),
            userCompanyTypeEdit: Number(holder.find('[name="userCompanyTypeEdit"]').val() || 0),
            userBranchTypeEdit: Number(holder.find('[name="userBranchTypeEdit"]').val() || 0),
            userStatusEdit: Number(holder.find('[name="userStatusEdit"]').val() || 0)
        };
        const updateResponse = parseRoleWizardResponse(await roleWizardRequest(updatePayload));
        if (!updateResponse || updateResponse.status !== 'success') {
            throw new Error((updateResponse && updateResponse.message) || 'Unable to assign a selected user.');
        }
    }

    async function submitRoleWizard() {
        if (roleWizardState.submitting) return;
        roleWizardState.submitting = true;
        const isEdit = roleWizardState.mode === 'edit';
        $('#roleWizardSubmitBtn').prop('disabled', true).text(isEdit ? 'Updating...' : 'Creating...');
        syncRoleWizardStep();

        try {
            const roleName = $('#roleWizardName').val().trim();
            const roleDescription = $('#roleWizardDescription').val().trim();
            const departmentId = Number($('#roleWizardDepartment').val() || 0);

            if (isEdit) {
                const updateResponse = parseRoleWizardResponse(await roleWizardRequest({
                    updateRoleWorkflow: 'updateRoleWorkflow',
                    role_id: roleWizardState.roleId,
                    role_name: roleName,
                    role_description: roleDescription,
                    department_id: departmentId,
                    role_status: Number($('[name="roleWizardStatus"]:checked').val() || 0),
                    permissions: [...roleWizardState.selectedPermissions],
                    user_ids: [...roleWizardState.selectedUsers]
                }));
                if (!updateResponse || updateResponse.status !== 'success') {
                    throw new Error((updateResponse && updateResponse.message) || 'Unable to update the role.');
                }
            } else if (!roleWizardState.roleId) {
                const createResponse = await roleWizardRequest({
                    addRoles: 'addRoles',
                    rolesName: roleName,
                    rolesDesc: roleDescription,
                    department_id: departmentId
                });
                if (String(createResponse).trim() === 'exists') {
                    throw new Error('A role with this name already exists.');
                }
                if (String(createResponse).trim() !== 'success') {
                    throw new Error('Unable to create the role.');
                }
                roleWizardState.roleId = await resolveRoleWizardRoleId(roleName);
                if (!roleWizardState.roleId) throw new Error('The new role was created but could not be loaded.');
            }

            if (!isEdit) {
                const permissionResponse = parseRoleWizardResponse(await roleWizardRequest({
                    assignPermissionsToRole: 'assignPermissionsToRole',
                    role_id: roleWizardState.roleId,
                    permission_intent: 'create',
                    permissions: [...roleWizardState.selectedPermissions]
                }));
                if (!permissionResponse || permissionResponse.status !== 'success') {
                    throw new Error((permissionResponse && permissionResponse.message) || 'Unable to assign permissions.');
                }

                for (const userId of roleWizardState.selectedUsers) {
                    await assignRoleWizardUser(Number(userId), roleWizardState.roleId);
                }
            }

            toastr.success(isEdit
                ? 'Role, permissions, and user assignments updated successfully.'
                : 'Role, permissions, and users were updated successfully.');
            roleWizardState.submitting = false;
            $('#createRoleWorkflowModal').modal('hide');
            if (typeof loadRolesOption === 'function') loadRolesOption();
            loadUsersTable(1);
            loadRoleWidgets();
        } catch (error) {
            toastr.error(error.message || 'Unable to complete the role workflow.');
        } finally {
            roleWizardState.submitting = false;
            $('#roleWizardSubmitBtn').prop('disabled', false).text(getRoleWizardSubmitLabel());
            syncRoleWizardStep();
        }
    }

    $(document).on('click', '#openCreateRoleWorkflowBtn', function () {
        resetRoleWizard('create');
        syncRoleWizardAppearance();
        $('#createRoleWorkflowModal').modal('show');
        loadRoleWizardData();
    });

    $(document).on('input', '#roleWizardDescription', function () {
        $('#roleWizardDescriptionCount').text(String($(this).val().length) + ' / 250');
    });

    $(document).on('click', '#roleWizardNextBtn', function () {
        if (!roleWizardState.ready || !validateRoleWizardStep(roleWizardState.step)) return;
        roleWizardState.step = Math.min(4, roleWizardState.step + 1);
        syncRoleWizardStep();
        $('#createRoleWorkflowModal .modal-body').scrollTop(0);
    });

    $(document).on('click', '#roleWizardBackBtn', function () {
        if (roleWizardState.submitting) return;
        roleWizardState.step = Math.max(1, roleWizardState.step - 1);
        syncRoleWizardStep();
        $('#createRoleWorkflowModal .modal-body').scrollTop(0);
    });

    $(document).on('click', '#roleWizardFinishBtn', function () {
        $('#createRoleWorkflowModal').modal('hide');
    });

    $(document).on('input', '#roleWizardPermissionSearch', renderRoleWizardPermissions);
    $(document).on('change', '.role-wizard-permission-check', function () {
        const id = String($(this).val());
        if (this.checked) roleWizardState.selectedPermissions.add(id);
        else roleWizardState.selectedPermissions.delete(id);
    });

    $(document).on('click', '#roleWizardSelectAllPermissions', function () {
        roleWizardState.permissions.forEach(function (permission) {
            roleWizardState.selectedPermissions.add(String(permission.id));
        });
        renderRoleWizardPermissions();
    });

    $(document).on('click', '#roleWizardClearPermissions', function () {
        roleWizardState.selectedPermissions.clear();
        renderRoleWizardPermissions();
    });

    $(document).on('input', '#roleWizardUserSearch', renderRoleWizardUsers);
    $(document).on('change', '#roleWizardUserCategoryFilter', renderRoleWizardUsers);
    $(document).on('change', '.role-wizard-user-check', function () {
        const id = String($(this).val());
        if (this.checked) roleWizardState.selectedUsers.add(id);
        else roleWizardState.selectedUsers.delete(id);
        renderRoleWizardSelectedUsers();
    });

    $(document).on('click', '#roleWizardClearUsers', function () {
        roleWizardState.selectedUsers.clear();
        renderRoleWizardUsers();
    });

    $('#createRoleWorkflowForm').on('submit', function (event) {
        event.preventDefault();
        if (roleWizardState.step < 4) {
            $('#roleWizardNextBtn').trigger('click');
            return;
        }
        if (validateRoleWizardStep(1) && validateRoleWizardStep(2) && validateRoleWizardStep(3)) {
            submitRoleWizard();
        }
    });

    $('#createRoleWorkflowModal').on('shown.bs.modal', function () {
        $('.modal-backdrop').last().css('z-index', 20010);
    }).on('hide.bs.modal', function (event) {
        if (roleWizardState.submitting) event.preventDefault();
    }).on('hidden.bs.modal', function () {
        resetRoleWizard();
    });

    syncRoleWizardAppearance();
    new MutationObserver(syncRoleWizardAppearance).observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-appearance-theme']
    });

    $(document).on('click', '[data-role-widget-page]', function () {
        const nextPage = Number($(this).data('role-widget-page'));
        if (!nextPage || $(this).prop('disabled')) return;
        roleWidgetState.page = nextPage;
        renderActiveRoleView();
        const targetId = roleWidgetState.view === 'permissions' ? 'usersRolePermissionsView' : 'usersRoleCards';
        document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    $(document).on('click', '.editRoleCardBtn', function () {
        const id = Number($(this).data('id') || 0);
        if (!id) return;

        resetRoleWizard('edit');
        roleWizardState.roleId = id;
        syncRoleWizardAppearance();
        $('#createRoleWorkflowModal').modal('show');
        loadRoleWizardData(id);
    });

    $(document).on('keydown', '.editRoleCardBtn', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        if ($(event.target).closest('button').length) return;
        event.preventDefault();
        $(this).trigger('click');
    });

    $(document).on('click', '.editRolePermissionsBtn', async function () {
        const id = Number($(this).data('id') || 0);
        if (!id) return;

        resetRoleWizard('edit');
        roleWizardState.roleId = id;
        syncRoleWizardAppearance();
        $('#createRoleWorkflowModal').modal('show');
        await loadRoleWizardData(id);
        if (!roleWizardState.ready || roleWizardState.roleId !== id) return;
        roleWizardState.step = 2;
        syncRoleWizardStep();
        $('#createRoleWorkflowModal .modal-body').scrollTop(0);
    });

    $(document).on('click', '.deleteRoleCardBtn', function (event) {
        event.preventDefault();
        event.stopPropagation();
        const id = Number($(this).data('id') || 0);
        if (!id) return;

        Swal.fire({
            title: 'Delete this role?',
            text: 'Roles assigned to active users cannot be deleted.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete Role',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white',
                cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (!result.isConfirmed) return;
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: { deleteRole: 'deleteRole', id: id },
                success: function (response) {
                    if (response.status !== 'success') {
                        toastr.error(response.message || 'Unable to delete this role.');
                        return;
                    }
                    toastr.success(response.message || 'Role deleted successfully.');
                    roleWidgetState.page = 1;
                    loadRoleWidgets();
                    if (typeof loadRolesOption === 'function') loadRolesOption();
                },
                error: function (xhr) {
                    const message = xhr.responseJSON && xhr.responseJSON.message
                        ? xhr.responseJSON.message
                        : 'Unable to delete this role.';
                    toastr.error(message);
                }
            });
        });
    });


    function loadUsersTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#usersTableBody').html('<tr><td colspan="8" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadUsers: 'loadUsers',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#usersTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                $('#totalUsersOverview').text(response.totalRows || 0);
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.totalRows || 0);
                const visibleRows = Number(response.visibleRows || 0);
                const perPageValue = parseInt(perPage, 10) || 10;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * perPageValue) + visibleRows, totalRows) : 0;

            },
            error: function () {
                $('#usersTableBody').html('<tr><td colspan="8" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    function loadRolesOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadRolesOptions: 'loadRolesOptions'
            },
            success: function (response) {
                const options = JSON.parse(response); // Step 1: parse JSON
                let html = '<option value="">----Select---</option>';

                options.forEach(function (role) {
                    html += `<option value="${role.key}">${role.value}</option>`;
                });
                $('#userRoleType').html(html).trigger('change');
            }
        });
    }

    function loadCompaniesOption() {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadCompanyOptions: 'loadCompanyOptions' },
            dataType: 'json',
            success: function (options) {
                let html = '<option value="">--Select Company--</option>';
                options.forEach(function (company) {
                    html += `<option value="${company.key}">${company.value}</option>`;
                });
                $('#userCompanyType').html(html).trigger('change');
            }
        });
    }

    function loadBranchesOption(companyId) {
        if (!companyId) {
            $('#userBranchType').html('<option value="">--Select Branch--</option>').trigger('change');
            return;
        }
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadBranchOptions: 'loadBranchOptions', company_id: companyId },
            dataType: 'json',
            success: function (options) {
                let html = '<option value="">--Select Branch--</option>';
                options.forEach(function (branch) {
                    html += `<option value="${branch.key}">${branch.value}</option>`;
                });
                $('#userBranchType').html(html).trigger('change');
            }
        });
    }

    $(document).ready(function () {
        loadUsersTable();
        loadRoleWidgets();
        loadRolesOption();
        loadCompaniesOption();

        $(document).on('change', '#userCompanyType', function() {
            const companyId = $(this).val();
            loadBranchesOption(companyId);
        });

        $(document).on('change', '#userCompanyTypeEdit', function() {
            const companyId = $(this).val();
            const branchSelect = $('#userBranchTypeEdit');
            if (!companyId) {
                branchSelect.html('<option value="">--Select Branch--</option>').trigger('change');
                return;
            }
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { loadBranchOptions: 'loadBranchOptions', company_id: companyId },
                dataType: 'json',
                success: function (options) {
                    let html = '<option value="">--Select Branch--</option>';
                    options.forEach(function (branch) {
                        html += `<option value="${branch.key}">${branch.value}</option>`;
                    });
                    branchSelect.html(html).trigger('change');
                }
            });
        });
        
        $('#animationModal .select2').select2({ dropdownParent: $('#animationModal') });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addUsersForm')[0].reset();
            $('#userRoleType').val('').trigger('change');
        });
        $('#searchUsers').on('input', function () {
            loadUsersTable(1);
        });
        $('#searchUsersTop').on('input', function () {
            roleWidgetState.search = $(this).val().trim();
            roleWidgetState.page = 1;
            renderActiveRoleView();
        });
        $('#perPageSelect').on('change', function () {
            loadUsersTable(1);
        });

        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadUsersTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.users-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#usersPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $(document).on('click', '.users-top-per-page-item', function () {
            const val = Number($(this).data('val')) || 10;
            const label = $(this).text();
            $('#usersPerPageTopText').text(label);
            roleWidgetState.perPage = val;
            roleWidgetState.page = 1;
            renderActiveRoleView();
        });

        $(document).on('click', '.role-sort-item', function () {
            roleWidgetState.sort = String($(this).data('sort') || 'name_asc');
            roleWidgetState.page = 1;
            $('#roleSortLabel').text($(this).text().trim());
            renderActiveRoleView();
        });

        $(document).on('click', '[data-role-view]', function () {
            const view = String($(this).data('role-view') || 'roles');
            if (view === 'permissions' && !$('#usersRolePermissionsView').length) return;
            roleWidgetState.view = view;
            roleWidgetState.page = 1;
            $('#searchUsersTop').attr('placeholder', view === 'permissions'
                ? 'Search roles or permissions...'
                : 'Search roles by name or description...');
            renderActiveRoleView();
        });

        $('#addUsersForm').on('submit', function (e) {
            e.preventDefault();

            const password = $('#userPassword').val().trim();
            const confirmPassword = $('#userConfirmPassword').val().trim();

            // Client-side password match validation
            if (password !== confirmPassword) {
                toastr.error('Password and Confirm Password do not match.');
                return;
            }

            const form = document.getElementById('addUsersForm');
            const formData = new FormData(form);
            formData.append('addUsers', 'addUsers'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addUsersForm')[0].reset();
                        loadUsersTable();
                        loadRoleWidgets();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $(document).on('click', '.toggle-user-password', function () {
            const input = document.getElementById(String(this.dataset.target || ''));
            if (!input) return;

            const showPassword = input.type === 'password';
            input.type = showPassword ? 'text' : 'password';
            this.setAttribute('aria-pressed', String(showPassword));
            this.setAttribute('aria-label', (showPassword ? 'Hide ' : 'Show ') + (input.id === 'userConfirmPassword' ? 'confirm password' : 'password'));
            $(this).find('i').toggleClass('ti-eye-off', !showPassword).toggleClass('ti-eye', showPassword);
        });

        $('.seeUserNewPassword').on('click', function () {
            const input = $('#userNewPassword');
            const icon = $(this).find('i');

            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('ti-eye-off').addClass('ti-eye');
            } else {
                input.attr('type', 'password');
                icon.removeClass('ti-eye').addClass('ti-eye-off');
            }
        });

        $('.seeUserNewConfirmPassword').on('click', function () {
            const input = $('#userNewConfirmPassword');
            const icon = $(this).find('i');

            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('ti-eye-off').addClass('ti-eye');
            } else {
                input.attr('type', 'password');
                icon.removeClass('ti-eye').addClass('ti-eye-off');
            }
        });
    });

    function syncEditUserModalAppearance() {
        const theme = document.documentElement.getAttribute('data-appearance-theme') || 'light';
        const isDark = theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        $('#editUserModel').toggleClass('user-edit-dark', isDark);
        $('#employeeDocumentPreviewModal').toggleClass('employee-document-preview-dark', isDark);
    }

    syncEditUserModalAppearance();
    new MutationObserver(syncEditUserModalAppearance).observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-appearance-theme']
    });

    const employeeDocumentCatalog = [
        { type: 'resume', label: 'Resume', group: 'personal', mark: 'DOC' },
        { type: 'pan', label: 'PAN Card', group: 'personal', mark: 'ID' },
        { type: 'aadhar', label: 'Aadhaar Card', group: 'personal', mark: 'ID' },
        { type: 'offer_letter', label: 'Offer Letter', group: 'official', mark: 'DOC' },
        { type: 'joining_letter', label: 'Joining Letter', group: 'official', mark: 'DOC' },
        { type: 'appointment_letter', label: 'Appointment Letter', group: 'official', mark: 'DOC' },
        { type: 'nda', label: 'NDA', group: 'official', mark: 'DOC' },
        { type: 'hr_docs', label: 'HR Docs', group: 'official', mark: 'DOC' }
    ];

    const employeeDocumentPreviewState = {
        employee: { name: 'Employee', code: '' },
        documents: [],
        selectedType: ''
    };

    function defaultEmployeeDocuments() {
        return employeeDocumentCatalog.map(function (documentItem) {
            return Object.assign({}, documentItem, {
                id: 0,
                available: false,
                file_name: '',
                mime_type: '',
                file_size: 0,
                updated_at: '',
                preview_url: ''
            });
        });
    }

    function normalizeEmployeeDocuments(documents) {
        const mapped = new Map((Array.isArray(documents) ? documents : []).map(function (documentItem) {
            return [String(documentItem.type || ''), documentItem];
        }));

        return employeeDocumentCatalog.map(function (definition) {
            return Object.assign({}, definition, mapped.get(definition.type) || {});
        });
    }

    function employeeDocumentStatus(documentItem) {
        if (!documentItem.available) return 'Not uploaded';
        return documentItem.file_name || 'Available to preview';
    }

    function documentRow(documentItem) {
        const row = $('<button>', {
            type: 'button',
            class: 'user-edit-document-row' + (documentItem.available ? ' is-available' : ''),
            title: 'View ' + documentItem.label,
            'aria-label': 'View ' + documentItem.label,
            'data-document-type': documentItem.type
        });
        $('<span>').addClass('user-edit-document-mark').text(documentItem.mark).appendTo(row);
        const copy = $('<span>').addClass('user-edit-document-copy').appendTo(row);
        $('<strong>').text(documentItem.label).appendTo(copy);
        $('<small>').text(employeeDocumentStatus(documentItem)).appendTo(copy);
        $('<span>').addClass('user-edit-document-eye').attr('aria-hidden', 'true')
            .append($('<i>').addClass('ti ti-eye')).appendTo(row);
        return row;
    }

    function renderEmployeeDocumentPanel(container, documents) {
        const normalized = normalizeEmployeeDocuments(documents);
        const groups = [
            { key: 'personal', label: 'Identification & Personal Docs' },
            { key: 'official', label: 'Official HR Records' }
        ];

        employeeDocumentPreviewState.documents = normalized;
        container.empty();
        groups.forEach(function (group) {
            const groupElement = $('<div>').addClass('user-edit-document-group').appendTo(container);
            $('<p>').addClass('user-edit-document-group-title').text(group.label).appendTo(groupElement);
            const list = $('<div>').addClass('user-edit-document-list').appendTo(groupElement);
            normalized.filter(function (documentItem) {
                return documentItem.group === group.key;
            }).forEach(function (documentItem) {
                list.append(documentRow(documentItem));
            });
        });
    }

    function loadEmployeeDocuments(userId, container) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadEmployeeDocuments: 'loadEmployeeDocuments', user_id: userId },
            success: function (response) {
                if (!response || response.status !== 'success') return;
                if (String($('#editUserModel [name="userIdEdit"]').val() || '') !== String(userId)) return;
                employeeDocumentPreviewState.employee = response.employee || employeeDocumentPreviewState.employee;
                renderEmployeeDocumentPanel(container, response.documents);
            }
        });
    }

    function getEmployeeDocument(type) {
        return employeeDocumentPreviewState.documents.find(function (documentItem) {
            return documentItem.type === type;
        }) || null;
    }

    function renderEmployeeDocumentPreviewList() {
        const list = $('#employeeDocumentPreviewList').empty();
        employeeDocumentPreviewState.documents.forEach(function (documentItem) {
            const item = $('<button>', {
                type: 'button',
                class: 'employee-document-preview-list-item' + (documentItem.type === employeeDocumentPreviewState.selectedType ? ' is-selected' : ''),
                'data-preview-document-type': documentItem.type,
                'aria-label': 'View ' + documentItem.label
            }).appendTo(list);
            $('<span>').addClass('employee-document-preview-list-mark').text(documentItem.mark).appendTo(item);
            const copy = $('<span>').addClass('employee-document-preview-list-copy').appendTo(item);
            $('<strong>').text(documentItem.label).appendTo(copy);
            $('<small>').text(employeeDocumentStatus(documentItem)).appendTo(copy);
            $('<span>').addClass('employee-document-preview-view-label')
                .append($('<i>').addClass('ti ti-eye').attr('aria-hidden', 'true'))
                .append(document.createTextNode(' View'))
                .appendTo(item);
        });
    }

    function renderEmployeeDocumentPreview() {
        const documentItem = getEmployeeDocument(employeeDocumentPreviewState.selectedType);
        if (!documentItem) return;

        const groupTitle = documentItem.group === 'personal'
            ? 'Identification & Personal Docs Preview'
            : 'Official HR Records Preview';
        const employee = employeeDocumentPreviewState.employee || {};
        const referenceParts = ['Internal Reference Only'];
        if (employee.code) referenceParts.push('Employee ID: ' + employee.code);
        if (employee.name) referenceParts.push(employee.name);

        $('#employeeDocumentPreviewTitle').text(groupTitle);
        $('#employeeDocumentPreviewReference').text(referenceParts.join(' - '));
        $('#employeeDocumentPrintBtn').prop('disabled', !documentItem.available || !documentItem.preview_url);

        const canvas = $('#employeeDocumentPreviewCanvas').empty();
        if (!documentItem.available || !documentItem.preview_url) {
            const empty = $('<div>').addClass('employee-document-preview-empty').appendTo(canvas);
            $('<span>').addClass('employee-document-preview-empty-icon')
                .append($('<i>').addClass('ti ti-file-off').attr('aria-hidden', 'true')).appendTo(empty);
            $('<h6>').text(documentItem.label + ' is not uploaded').appendTo(empty);
            $('<p>').text('This employee record does not currently contain a mapped file for preview. Once HRM provides the document, it will appear here automatically.').appendTo(empty);
        } else if (String(documentItem.mime_type || '').toLowerCase().startsWith('image/')) {
            $('<img>', {
                id: 'employeeDocumentPreviewImage',
                class: 'employee-document-preview-image',
                src: documentItem.preview_url,
                alt: documentItem.label + ' preview'
            }).appendTo(canvas);
        } else {
            $('<iframe>', {
                id: 'employeeDocumentPreviewFrame',
                class: 'employee-document-preview-frame',
                src: documentItem.preview_url,
                title: documentItem.label + ' preview'
            }).attr('loading', 'eager').appendTo(canvas);
        }

        renderEmployeeDocumentPreviewList();
    }

    function openEmployeeDocumentPreview(type) {
        if (!getEmployeeDocument(type)) return;
        employeeDocumentPreviewState.selectedType = type;
        syncEditUserModalAppearance();
        renderEmployeeDocumentPreview();
        $('#employeeDocumentPreviewModal').modal('show');
    }

    function enhanceEditUserModalLayout() {
        const modal = $('#editUserModel');
        const layout = modal.find('.user-edit-layout');

        if (!layout.length) {
            return;
        }

        layout.addClass('user-edit-reference-layout');
        modal.find('.user-edit-close')
            .html('<i class="ti ti-x" aria-hidden="true"></i>')
            .attr({ title: 'Close profile', 'aria-label': 'Close profile' });

        const documentsBody = modal.find('.user-edit-documents-body');
        const profileName = modal.find('.user-edit-profile-name').text().trim() || 'Employee';
        const profileMeta = modal.find('.user-edit-profile-meta').text();
        const codeMatch = profileMeta.match(/ID:\s*([^|]+)/i);
        employeeDocumentPreviewState.employee = {
            name: profileName,
            code: codeMatch ? codeMatch[1].trim() : ''
        };
        renderEmployeeDocumentPanel(documentsBody, defaultEmployeeDocuments());
        loadEmployeeDocuments(modal.find('[name="userIdEdit"]').val(), documentsBody);
    }

    $(document).on('change', '#userProfilePhotoEdit', function () {
        const file = this.files && this.files[0];
        if (!file) return;
        if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) {
            this.value = '';
            toastr.error('Select a PNG, JPG, JPEG, or WEBP image smaller than 5 MB.');
            return;
        }

        const photo = $('#editUserModel .user-edit-avatar-photo');
        const previewUrl = URL.createObjectURL(file);
        photo.one('load', function () { URL.revokeObjectURL(previewUrl); }).attr('src', previewUrl).removeClass('hidden');
        $('#editUserModel .user-edit-avatar-initials').addClass('hidden');
    });

    $(document).on('click', '.user-edit-document-row', function () {
        openEmployeeDocumentPreview(String($(this).attr('data-document-type') || ''));
    });

    $(document).on('click', '[data-preview-document-type]', function () {
        employeeDocumentPreviewState.selectedType = String($(this).attr('data-preview-document-type') || '');
        renderEmployeeDocumentPreview();
    });

    $(document).on('click', '#employeeDocumentPrintBtn', function () {
        const documentItem = getEmployeeDocument(employeeDocumentPreviewState.selectedType);
        if (!documentItem || !documentItem.available || !documentItem.preview_url) return;

        const frame = document.getElementById('employeeDocumentPreviewFrame');
        if (frame && frame.contentWindow) {
            try {
                frame.contentWindow.focus();
                frame.contentWindow.print();
                return;
            } catch (error) {
                // The browser PDF viewer may block direct print access.
            }
        }
        window.open(documentItem.preview_url, '_blank', 'noopener,noreferrer');
    });

    $('#employeeDocumentPreviewModal').on('shown.bs.modal', function () {
        $('.modal-backdrop').last().css('z-index', 20050);
    }).on('hidden.bs.modal', function () {
        $('#employeeDocumentPreviewCanvas, #employeeDocumentPreviewList').empty();
        if ($('#editUserModel').hasClass('show')) {
            $('body').addClass('modal-open');
        }
    });

    $(document).on('click', '.userEditModal', function () {
        let id = $(this).data('id');
        if (id) {
            syncEditUserModalAppearance();
            $('#editUsersForm').find('.modal-body').html('<div class="user-edit-loading"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></div>');
            $('#editUserModel').modal('show');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchUserRecord: 'fetchUserRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = typeof response === 'string' ? JSON.parse(response) : response;
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editUsersForm').find('.modal-body').html(res.data);
                        enhanceEditUserModalLayout();
                        $('#editUsersForm .select2').select2({ dropdownParent: $('#editUserModel') });
                    } else if (res.status === 'error') {
                        $('#editUserModel').modal('hide');
                        toastr.error(res.message);
                    } else {
                        $('#editUserModel').modal('hide');
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    $('#editUserModel').modal('hide');
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editUserModel').on('shown.bs.modal', function () {
        $('.modal-backdrop').last().css('z-index', 19990);
    }).on('hidden.bs.modal', function () {
        $('#editUsersForm').find('.modal-body').empty();
        if ($('#manageUsersModal').hasClass('show')) {
            $('body').addClass('modal-open');
        }
    });

    $(document).on('change', '#editUserModel input[name="userStatusEdit"]', function () {
        $('#editUserModel .user-edit-status-badge').text($(this).val() === '1' ? 'Active' : 'Inactive');
    });

    $(document).on('click', '.userChangePasswordModal', function () {
        let id = $(this).data('id');
        $('#user_id').val('');
        if (id) {
            $('#user_id').val(id);
            $('#changePasswordUserModel').modal('show');
        }
    });

    $(document).on('click', '.userExtraPermissionModalBtn', function () {
        let id = $(this).data('id');
        let roleId = $(this).data('role-id');
        $('#user_id').val('');
        if (id) {
            $('#userPermissionForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchUserPermissionsRecord: 'fetchUserPermissionsRecord', id: id, roleId: roleId },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#userExtraPermissionModal').modal('show');
                        $('#userPermissionForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.userDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white',
                cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteUserRecord: 'deleteUserRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadUsersTable();
                            loadRoleWidgets();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                            }
                        });
                    }
                });
            }
        });
    });

    $('#editUsersForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editUsersForm');
        const formData = new FormData(form);
        formData.append('updateUsers', 'updateUsers');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = typeof response === 'string' ? JSON.parse(response) : response;
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editUserModel').modal('hide');
                    $('#editUsersForm').find('.modal-body').empty();
                    loadUsersTable();
                    loadRoleWidgets();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function (xhr) {
                let message = 'Server error occurred.';
                try {
                    const response = xhr.responseJSON || JSON.parse(xhr.responseText || '{}');
                    message = response.message || message;
                } catch (error) {
                    // Keep the generic message when the server does not return JSON.
                }
                toastr.error(message);
            }
        });
    });

    $('#userPermissionForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('userPermissionForm');
        const formData = new FormData(form);
        formData.append('updateUserPermissions', 'updateUserPermissions');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#userExtraPermissionModal').modal('hide');
                    $('#userPermissionForm').find('modal-body').html();
                    loadUsersTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('submit', '#changePasswordForm', function (e) {
        e.preventDefault();

        const $form = $(this);
        const password = $('#userNewPassword').val().trim();
        const confirmPassword = $('#userNewConfirmPassword').val().trim();
        const $submitBtn = $('#submitChangePasswordBtn');
        if (password !== confirmPassword) {
            toastr.error("Passwords do not match.");
            return;
        }
        const formData = new FormData(this);
        formData.append('changeUserPassword', 'changeUserPassword');

        $submitBtn.prop('disabled', true).html('Please wait... <span class="spinner-border spinner-border-sm ms-2"></span>');
        // Send AJAX
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error("Invalid server response.");
                    return;
                }

                if (res.status === 'success') {
                    toastr.success(res.message || "Password updated.");
                    $('#changePasswordUserModel').modal('hide');
                    $form[0].reset();
                } else {
                    toastr.error(res.message || "Something went wrong.");
                }
            },
            error: function () {
                toastr.error("Server error occurred.");
            },
            complete: function () {
                // Re-enable the button
                $submitBtn.prop('disabled', false).html('Submit');
            }
        });
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = $(this).data('default') || 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadUsersTable(1);
    });

</script>
<?php endSection(); ?>
