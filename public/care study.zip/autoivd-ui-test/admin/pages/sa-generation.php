<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">View and manage sampling advice COA records</p>
        </div>
    </div>

    <!-- Pending Sample Advice Alert Widget -->
    <div id="incomingSaGenerationWidget"
        class="mb-6 cursor-pointer overflow-hidden rounded-xl border p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md w-full md:w-1/2"
        style="border-color: color-mix(in srgb, var(--appearance-accent, #0284c7) 24%, #bae6fd); background-color: color-mix(in srgb, var(--appearance-accent, #0284c7) 7%, #f0f9ff);"
        role="button" tabindex="0">
        <div class="flex items-center justify-between gap-4">
            <div class="flex min-w-0 items-center gap-3">
                <span class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm ring-1 ring-black/5"
                    style="color: var(--appearance-accent, #0284c7);">
                    <i class="ti ti-test-pipe text-2xl"></i>
                </span>
                <div class="min-w-0">
                    <div class="flex flex-wrap items-center gap-2">
                        <h3 class="m-0 text-base font-extrabold text-slate-900">Pending Sample Advice Requests</h3>
                        <span id="incomingSaGenerationCount"
                            class="inline-flex min-w-6 items-center justify-center rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white"
                            style="background-color: var(--appearance-accent, #0284c7);">0</span>
                    </div>
                    <p class="m-0 mt-1 text-xs font-medium text-slate-600">
                        Click here to review pending sampling advice records awaiting QA approval.
                    </p>
                </div>
            </div>
            <i class="ti ti-chevron-right shrink-0 text-xl" style="color: var(--appearance-accent, #0284c7);"></i>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="saPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="sa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="sa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="sa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="sa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="sa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="sa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchSaCoa"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto w-full border-t border-slate-200">
                <table class="w-full border-collapse whitespace-nowrap text-left">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="coa.name">
                                <span class="inline-flex items-center gap-1">Product Description <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="coa.coa_number">
                                <span class="inline-flex items-center gap-1">COA Number <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-44 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="coa.suplier_name">
                                <span class="inline-flex items-center gap-1">Supplier <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="coa.approval_status">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-36 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="u.name">
                                <span class="inline-flex items-center gap-1">Created By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="saCoaTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- View SA Data Modal -->
    <div class="modal fade animate__animated fadeIn" id="viewRapiData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">SA Generation Data</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">View sampling advice details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body bg-slate-50/70 !px-4 !py-3" id="viewRapiDataModalBody">
                </div>
            </div>
        </div>
    </div>

    <!-- Incoming Pending Sample Advice Modal -->
    <div class="modal fade animate__animated fadeIn" id="incomingSaGenerationModal" tabindex="-1" aria-labelledby="incomingSaGenerationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content overflow-hidden !rounded-2xl border-0 shadow-2xl">
                <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                    <div>
                        <h5 id="incomingSaGenerationModalLabel" class="modal-title m-0 text-lg font-extrabold" style="color: var(--appearance-accent, #0284c7);">
                            Pending Sample Advice Requests
                        </h5>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-500">
                            Select a pending record to review and complete its Sampling Advice approval.
                        </p>
                    </div>
                    <button type="button" class="btn-close mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body bg-white px-6 py-5">
                    <div class="overflow-hidden rounded-xl border border-slate-200">
                        <div class="overflow-x-auto w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                    <tr>
                                        <th class="w-12 border-b border-slate-200 px-4 py-3">S.No</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Date</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Item Name</th>
                                        <th class="border-b border-slate-200 px-4 py-3">COA Number</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Batch No</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Supplier</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="incomingSaGenerationTableBody" class="divide-y divide-slate-200 bg-white"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal-footer flex-nowrap border-t border-slate-200 bg-slate-50/80 px-6 py-4">
                    <div class="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <span id="incomingSaGenerationSummary" class="inline-flex items-center gap-2 text-xs font-medium text-slate-500">
                            <i class="ti ti-info-circle text-base"></i>
                            Showing 0 pending SA requests.
                        </span>
                        <div class="flex items-center gap-1">
                            <button id="incomingSaGenerationPrevious" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Previous page" disabled>
                                <i class="ti ti-chevron-left"></i>
                            </button>
                            <span id="incomingSaGenerationCurrentPage"
                                class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-extrabold"
                                style="color: var(--appearance-accent, #0284c7);">1</span>
                            <button id="incomingSaGenerationNext" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Next page" disabled>
                                <i class="ti ti-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- PDF Preview Modal -->
    <div class="modal fade animate__animated fadeIn" id="materialRequisitionViewPdfModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-file-text text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Sampling Advice Preview</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview the sampling advice PDF</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div id="materialRequisitionViewPdf">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'coa.id';
    let currentSortOrder = 'DESC';
    let currentStatusFilter = '';

    let incomingSaGenerationPage = 1;
    const incomingSaGenerationPerPage = 7;
    let incomingSaGenerationRecords = [];

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function loadIncomingSaWorkflow() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadIncomingSaGenerationWorkflow: 1 },
            success: function (response) {
                if (response.status === 'success' && response.data) {
                    incomingSaGenerationRecords = response.data.records || [];
                    const total = typeof response.data.total !== 'undefined' ? response.data.total : incomingSaGenerationRecords.length;
                    $('#incomingSaGenerationCount').text(total);
                    renderIncomingSaGenerationRecords();
                }
            },
            error: function () {
                incomingSaGenerationRecords = [];
                renderIncomingSaGenerationRecords();
            }
        });
    }

    function renderIncomingSaGenerationRecords() {
        const totalRows = incomingSaGenerationRecords.length;
        const totalPages = Math.max(1, Math.ceil(totalRows / incomingSaGenerationPerPage));
        incomingSaGenerationPage = Math.min(Math.max(1, incomingSaGenerationPage), totalPages);
        const offset = (incomingSaGenerationPage - 1) * incomingSaGenerationPerPage;
        const visibleRows = incomingSaGenerationRecords.slice(offset, offset + incomingSaGenerationPerPage);

        if (visibleRows.length === 0) {
            $('#incomingSaGenerationTableBody').html(`<tr>
                <td colspan="7" class="px-6 py-10 text-center text-sm font-semibold text-slate-500">
                    No pending SA generation requests available.
                </td>
            </tr>`);
        } else {
            $('#incomingSaGenerationTableBody').html(visibleRows.map(function (record, index) {
                return `<tr>
                    <td class="px-4 py-3 align-middle whitespace-nowrap text-xs font-semibold text-slate-700">${String(offset + index + 1).padStart(2, '0')}</td>
                    <td class="px-4 py-3 align-middle whitespace-nowrap text-xs text-slate-600">${escapeHtml(record.date_formatted || '')}</td>
                    <td class="px-4 py-3 align-middle text-xs font-bold text-slate-900">${escapeHtml(record.name || '')}</td>
                    <td class="px-4 py-3 align-middle text-xs font-medium text-slate-700">${escapeHtml(record.coa_number || '')}</td>
                    <td class="px-4 py-3 align-middle text-xs text-slate-600">${escapeHtml(record.batch_number || '-')}</td>
                    <td class="px-4 py-3 align-middle text-xs text-slate-600">${escapeHtml(record.suplier_name || '-')}</td>
                    <td class="px-4 py-3 align-middle text-center whitespace-nowrap">
                        <button type="button" class="btn btn-sm btn-primary rounded-xl px-3 py-1 font-semibold incoming-sa-review-btn" data-id="${escapeHtml(record.id)}">
                            <i class="ti ti-checklist me-1"></i> Review
                        </button>
                    </td>
                </tr>`;
            }).join(''));
        }

        $('#incomingSaGenerationSummary').html(
            `<i class="ti ti-info-circle text-base"></i>Showing ${totalRows} pending SA requests.`
        );
        $('#incomingSaGenerationCurrentPage').text(incomingSaGenerationPage);
        $('#incomingSaGenerationPrevious').prop('disabled', incomingSaGenerationPage <= 1);
        $('#incomingSaGenerationNext').prop('disabled', incomingSaGenerationPage >= totalPages);
    }

    function openSaViewModal(id) {
        $('#viewRapiDataModalBody').html('<div class="p-8 text-center"><div class="spinner-border text-sky-600" role="status"><span class="visually-hidden">Loading...</span></div></div>');
        $('#viewRapiData').modal('show');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                fetchSaCoaData: 'fetchSaCoaData',
                id: id
            },
            success: function (response) {
                try {
                    const res = typeof response === 'string' ? JSON.parse(response) : response;
                    if (res.status === 'success') {
                        $('#viewRapiDataModalBody').html(res.data);
                    } else {
                        toastr.error(res.message || 'Something went wrong.');
                    }
                } catch (e) {
                    console.error('Invalid JSON:', e);
                    toastr.error('Invalid server response.');
                }
            },
            error: function () {
                toastr.error('Invalid server response.');
            }
        });
    }

    function loadRapidTable(page = 1) {
        currentPage = page;
        const search = $('#searchSaCoa').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#saCoaTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadSaCoaData: 'loadSaCoaData',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder,
                status_filter: currentStatusFilter
            },
            dataType: 'json',
            success: function (response) {
                $('#saCoaTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const visibleRows = $('#saCoaTableBody tr').length;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * parseInt(perPage)) + visibleRows, totalRows) : 0;
                $('#saPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
                if (typeof response.pending_sa_count !== 'undefined') {
                    $('#incomingSaGenerationCount').text(response.pending_sa_count);
                }
            },
            error: function () {
                $('#saCoaTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#saPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    $(document).ready(function () {
        loadRapidTable();
        loadIncomingSaWorkflow();

        $(document).on('click keydown', '#incomingSaGenerationWidget', function (e) {
            if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
            if (e.type === 'keydown') e.preventDefault();
            incomingSaGenerationPage = 1;
            loadIncomingSaWorkflow();
            $('#incomingSaGenerationModal').modal('show');
        });

        $(document).on('click', '#incomingSaGenerationPrevious', function () {
            if (incomingSaGenerationPage > 1) {
                incomingSaGenerationPage--;
                renderIncomingSaGenerationRecords();
            }
        });

        $(document).on('click', '#incomingSaGenerationNext', function () {
            incomingSaGenerationPage++;
            renderIncomingSaGenerationRecords();
        });

        $(document).on('click', '.incoming-sa-review-btn', function () {
            const id = $(this).attr('data-id');
            if (id) {
                $('#incomingSaGenerationModal').modal('hide');
                openSaViewModal(id);
            }
        });

        $(document).on('click', '.modalViewDataAnimate', function () {
            const id = $(this).attr('data-id');
            if (id) {
                openSaViewModal(id);
            }
        });

        $('#searchSaCoa').on('input', function () {
            loadRapidTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadRapidTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadRapidTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.sa-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#saPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });
    });

    $(document).on('change', 'input[name="approvalStatus"]', function () {
        if ($('#approvalStatusReject').is(':checked')) {
            $('#remarksQc').prop('required', true);
        } else {
            $('#remarksQc').prop('required', false);
        }
    });

    $(document).on('submit', '#saCoaApprovalForm', function (e) {
        e.preventDefault();
        const $form = $(this);
        let formData = $form.serialize();
        formData += '&saCoaApprovalFrom=saCoaApprovalFrom';
        const $submitBtn = $form.find('#submitApprovalBtn');
        const $loader = $form.find('#submitLoaderApproval');

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            beforeSend: function () {
                $submitBtn.prop('disabled', true);
                $loader.removeClass('d-none').addClass('d-inline-block');
            },
            success: function (response) {
                if (response.status === 'success') {
                    toastr.success(response.message || 'Submitted successfully');
                    $form[0].reset();
                    $('#viewRapiData').modal('hide');
                    if (typeof loadRapidTable === 'function') {
                        loadRapidTable();
                    }
                    loadIncomingSaWorkflow();
                } else {
                    toastr.error(response.message || 'Something went wrong while submitting.');
                }
            },
            error: function (xhr) {
                toastr.error('Server error occurred. Please try again.');
            },
            complete: function () {
                $submitBtn.prop('disabled', false);
                $loader.removeClass('d-inline-block').addClass('d-none');
            }
        });
    });

    $(document).on('click', '.generateSaPdfBtn', function () {
        let $btn = $(this);
        let id = $btn.attr('data-id');
        if (id) {
            const pdfWindow = window.open('', '_blank');
            let originalHtml = $btn.html();
            $btn.prop('disabled', true);
            $btn.html('<span class="spinner-border spinner-border-sm text-primary"></span>');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { id: id, generateSaPdfFunction: 'generateSaPdfFunction' },
                success: function (response) {
                    $btn.prop('disabled', false);
                    $btn.html(originalHtml);
                    try {
                        const json = JSON.parse(response);
                        if (json.status === 'success' && json.pdf_url) {
                            if (pdfWindow) {
                                pdfWindow.opener = null;
                                pdfWindow.location.href = json.pdf_url;
                            } else {
                                window.location.href = json.pdf_url;
                            }
                            toastr.success(json.message || 'PDF generated successfully!');
                        } else {
                            if (pdfWindow) pdfWindow.close();
                            toastr.error(json.message || 'Something went wrong during PDF generation.');
                        }
                    } catch (e) {
                        if (pdfWindow) pdfWindow.close();
                        toastr.error('Invalid response format.');
                    }
                },
                error: function () {
                    if (pdfWindow) pdfWindow.close();
                    toastr.error("Something went wrong.");
                    $btn.prop('disabled', false);
                    $btn.html(originalHtml);
                }
            });
        }
    });

    $(document).on('click', '.previewSaPdfBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#materialRequisitionViewPdf').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    sampleAdviceViewPdfRecord: 'sampleAdviceViewPdfRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }
                    if (res.status === 'success') {
                        $('#materialRequisitionViewPdfModal').modal('show');
                        $('#materialRequisitionViewPdf').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfSampleAdviceDownloadBtn', function () {
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/sample_advice_template.php?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');
            toastr.success('Sample Advice PDF is being downloaded.');
        }
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        loadRapidTable(1);
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
    });
</script>
<?php endSection(); ?>
