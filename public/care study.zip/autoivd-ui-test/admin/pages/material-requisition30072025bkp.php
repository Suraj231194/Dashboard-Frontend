<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>      
    <div class="row col-md-12">
        <div class="card">            
            <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                <div class="d-flex align-items-center gap-2">
                    <label for="perPageSelect" class="mb-0">Show</label>
                    <select id="perPageSelect" class="form-select form-select-sm w-auto">
                        <option value="5">5</option>
                        <option value="10" selected>10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <input type="text" id="searchProducts" class="form-control form-control-sm" placeholder="Search Data...">
                    <?php if (roleHasPermission($_SESSION['role_id'], 'production_material_requisition_add')) { ?>
                        <button type="button" class="btn btn-sm w-50 btn-success" id="addMaterialRquisitionModalBtn">Add New</button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr class="text-nowrap">
                            <th class="border-b border-slate-200 px-6 py-3">#</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Date"> Date</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Product Name"> Product Name</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Lot/Batch No"> LOT/Batch No</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Batch Size"> Batch Size</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Requested By"> Requested By</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>                           
                            <th class="border-b border-slate-200 px-6 py-3">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white" id="productsTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addMaterialRquisitionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Add Requisition</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="addMaterialRequisitionForm">
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col-12 mb-2">
                                <small class="text-dark fw-medium d-block">Requisition For</small>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check">
                                <input class="form-check-input requisition-checkbox" type="checkbox" id="mrRaw" name="mrForRaw" value="1" />
                                <label class="form-check-label" for="mrRaw">Raw Material</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-check">
                                <input class="form-check-input requisition-checkbox" type="checkbox" id="mrPacking" name="mrForPacking" value="1" />
                                <label class="form-check-label" for="mrPacking">Packing Material</label>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-check">
                                <input class="form-check-input requisition-checkbox" type="checkbox" id="mrConsumable" name="mrForConsumable" value="1" />
                                <label class="form-check-label" for="mrConsumable">Consumables</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="mrDate" class="form-label">Date</label>
                                <input type="date" id="mrDate" autocomplete="off" name="mrDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" placeholder="Enter Date" required />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="mrProductName" class="form-label">Product Name</label>
                                <input type="text" id="mrProductName" autocomplete="off" name="mrProductName" class="form-control" placeholder="Enter Product Name" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="mrBatchNumber" class="form-label">Lot No./Batch No.</label>
                                <input type="text" id="mrBatchNumber" autocomplete="off" name="mrBatchNumber" class="form-control" placeholder="Enter Lot No./Batch No." required />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="mrBatchSize" class="form-label">Batch Size</label>
                                <input type="number" min="0" id="mrBatchSize" autocomplete="off" name="mrBatchSize" class="form-control" placeholder="Enter Batch Size" required />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="mrBatchSizeUnit" class="form-label">Batch Size Unit</label>
                                <select id="mrBatchSizeUnit" name="mrBatchSizeUnit" class="form-control" placeholder="Enter Batch Size" required></select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="mrSlipNo" class="form-label">Slip No.</label>
                                <input type="text" id="mrSlipNo" autocomplete="off" name="mrSlipNo" class="form-control" placeholder="Enter Slip No." />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="mrDepartment" class="form-label">Department</label>
                                <select id="mrDepartment"  name="mrDepartment" class="form-control" required></select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="mrRequestedBy" class="form-label">Requested By</label>
                                <input type="text" id="mrRequestedBy" autocomplete="off" name="mrRequestedBy" class="form-control" placeholder="Enter Requested By" required />
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col mb-2">
                                <label for="" class="form-label">Material Lines</label>
                            </div>
                            <div id="mrProductsWrapper"></div>
                            <div class="mb-2">
                                <button type="button" class="btn btn-success btn-sm" id="addMrProducts">+ Add Product</button>
                            </div>
                        </div>   
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewMatRequiModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">View Material Requisition Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="viewMatRequi">
                    <div class="modal-body">                                    
                    </div>                  
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editMatRequiModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Material Requisition Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="editMatRequiForm">
                    <div class="modal-body">                                    
                    </div>                  
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let productIndex = 1;
    let qtyUnitOptions = [];   

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function(response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#productUnit").html(optionsHtml);
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }
    
    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function(response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                departmentOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#mrDepartment").html(optionsHtml);
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }


    function loadMaterialRequisitionTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialRequisition: 'loadMaterialRequisition',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function(response) {
                const parts = response.split('|||');
                $('#productsTableBody').html(parts[0]);
                $('#paginationWrapper').html(parts[1] || '');
            },
            error: function() {
                $('#productsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }
    
    function updateItemNumbers() {
        $('#mrProductsWrapper .product-row').each(function(index) {
            $(this).attr('data-index', index + 1);
            $(this).find('legend').text('Item ' + (index + 1));
        });
        productIndex = $('#mrProductsWrapper .product-row').length + 1;
    }
    $(document).ready(function() {        
        loadMaterialRequisitionTable();
        loadStandardUnit();
        loadDepartmentsList();
        $('#searchProducts').on('input', function() {
            loadMaterialRequisitionTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadMaterialRequisitionTable(1);
        });

        $('#addMaterialRquisitionModalBtn').on('click', function(){
            $('#addMaterialRquisitionModal').modal('show');
            $('#mrBatchSizeUnit').html('');
            if ($('#mrProductsWrapper .product-row').length === 0) {
                $('#addMrProducts').trigger('click');
            }
            let optionsUnitHtml = '<option value="">---Select----</option>';
            qtyUnitOptions.forEach(unit => {
                optionsUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });
            $('#mrBatchSizeUnit').append(optionsUnitHtml);
        });

        
        $('#addMrProducts').click(function() {
            let optionsUnitHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
            const productRow = `
            <div class="row align-items-end mb-2 product-row border rounded shadow-sm p-2" data-index="${productIndex}">   
                <div class="col-12">
                    <legend class="fw-bold text-primary mb-2 fs-6">Item ${productIndex}</legend>
                </div>              
                <div class="col-md-5 mb-1">
                    <input type="text" name="ProductItemDesciption[]" class="form-control" placeholder="Product Description" required />
                </div>
                <div class="col-md-3 mb-1">
                    <input type="number" min="0" name="ProductItemquantity[]" class="form-control" placeholder="Product quantity" required />
                </div>
                <div class="col-md-3 mb-1">
                    <select name="ProductItemquantityUnit[]" class="form-control" placeholder="Quantity Unit" required>`+optionsUnitHtml+`</select>
                </div>
                <div class="col-md-1 mb-1">
                    <button type="button" class="btn btn-icon btn-label-danger removeProductBtn" >
                        <span class="ti ti-trash"></span>
                    </button>                    
                </div>
            </div>
            `;
            $('#mrProductsWrapper').append(productRow);
            productIndex++;
        });

         $('#mrProductsWrapper').on('click', '.removeProductBtn', function() {
            $(this).closest('.product-row').remove();
            updateItemNumbers();
        });

        $('#addMaterialRequisitionForm').on('submit', function (e) {
            e.preventDefault();
            if ($('.requisition-checkbox:checked').length === 0) {
                toastr.error('Please select at least one requisition type.');
                $('.requisition-checkbox').first().focus();
                return;
            }

            const form = document.getElementById('addMaterialRequisitionForm');
            const formData = new FormData(form);
            formData.append('addMaterialRequisitionForm', 'addMaterialRequisitionForm'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#addMaterialRquisitionModal').modal('hide');
                        $('#addMaterialRequisitionForm')[0].reset();
                        loadMaterialRequisitionTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });          
    });

    $(document).on('click', '#addParametersEdit', function(){
        let optionsUnitHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });
        const productRow = `<div class="row align-items-end mb-2 product-row border rounded shadow-sm p-2" data-index="${productIndex}">  
                    <div class="col-md-5 mb-1">
                        <input type="hidden" name="matRequiItemIdEdit[]" />
                        <input type="text" name="ProductItemDesciptionEdit[]" class="form-control" placeholder="Product Description" required />
                    </div>
                    <div class="col-md-3 mb-1">
                        <input type="number" min="0" name="ProductItemquantityEdit[]"  class="form-control" placeholder="Product quantity" required />
                    </div>
                    <div class="col-md-3 mb-1">
                        <select name="ProductItemquantityUnitEdit[]" class="form-control" placeholder="Quantity Unit" required>`+optionsUnitHtml+`</select>
                    </div>
                    <div class="col-md-1 mb-1">
                        <button type="button" class="btn btn-icon btn-label-danger removeMatRequiItemBtn">
                            <span class="ti ti-trash"></span>
                        </button>                    
                    </div>
            </div>`;
        $('#templateParametersEdit').append(productRow);
        productIndex++;
    });
    
    $(document).on('click','.materialRequisitionEditModalBtn', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#editMatRequiForm').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {fetchMaterialRequisitionRecord:'fetchMaterialRequisitionRecord', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editMatRequiModel').modal('show');
                    $('#editMatRequiForm').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

   
    $(document).on('click', '.materialRequisitionDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid Material Requisition ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteMaterialRequisitionRecord: 'deleteMaterialRequisitionRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadMaterialRequisitionTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });
    
    $('#editMatRequiForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editMatRequiForm');
        const formData = new FormData(form);
        formData.append('updateMatRequiRecord', 'updateMatRequiRecord'); 
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editMatRequiModel').modal('hide');
                    $('#editMatRequiForm').find('modal-body').html();
                    loadMaterialRequisitionTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click','.viewMatReqModalBtn', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#viewMatRequi').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {viewMatRequiRecord:'viewMatRequiRecord', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#viewMatRequiModel').modal('show');
                    $('#viewMatRequi').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

    $(document).on('click', '.removeMatRequiItemBtn', function(e){
        e.preventDefault();
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            buttonClicked.closest('.product-row').remove();
            Swal.fire({
                icon: 'success',
                title: 'Removed !!',
                text: 'Material Requisition Item removed.',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'btn btn-success waves-effect waves-light'
                }
            });
            return;
        }
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function(result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteMatRequiItemRecord: 'deleteMatRequiItemRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                            buttonClicked.closest('.product-row').remove();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });
 
</script>
<?php endSection(); ?>
