<?php
$procureProductsParam = trim($_GET['procure_products'] ?? '');
$procureProductIds = array_values(array_unique(array_filter(array_map('intval', explode(',', $procureProductsParam)))));
$procurementSourceParam = trim($_GET['procurement_source'] ?? '');
$purchaseSupplierOptions = [];
$purchaseSupplierOptionsHtml = '<option value="">----Select Vendor----</option>';
$purchaseBranchOptionsHtml = '<option value="">----Select Shipment Address----</option>';
$purchaseUnitOptionsHtml = '<option value="">----Select Unit----</option>';
$purchaseCriticalOptionsHtml = '<option value="">----Select Criticality----</option>';
$defaultSupplierEmailBody = "Please find attached Purchase Order {PO_NUMBER} from Biogenix Inc Pvt. Ltd.\n\nKindly acknowledge receipt and confirm the delivery timeline.";
foreach (Constant::LOW_STOCK['CRITICAL_STATUS'] as $criticalKey => $criticalValue) {
    $purchaseCriticalOptionsHtml .= '<option value="' . (int) $criticalKey . '">' . htmlspecialchars($criticalValue['label'], ENT_QUOTES, 'UTF-8') . '</option>';
}
if (isset($conn)) {
    $supplierResult = $conn->query("SELECT `id`, `name`, `contact_details` FROM `suppliers` WHERE `status` = 1 AND `deleted_at` IS NULL ORDER BY `name` ASC");
    if ($supplierResult) {
        while ($supplierRow = $supplierResult->fetch_assoc()) {
            $supplierName = trim($supplierRow['name'] ?? '');
            if ($supplierName === '') {
                continue;
            }
            $purchaseSupplierOptions[] = [
                'id' => (int) $supplierRow['id'],
                'name' => $supplierName,
                'email' => trim($supplierRow['contact_details'] ?? '')
            ];
            $purchaseSupplierOptionsHtml .= '<option value="' . htmlspecialchars($supplierName, ENT_QUOTES, 'UTF-8') . '" data-id="' . (int) $supplierRow['id'] . '" data-email="' . htmlspecialchars($supplierRow['contact_details'] ?? '', ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($supplierName, ENT_QUOTES, 'UTF-8') . '</option>';
        }
    }
    $currentCompanyId = (int) ($_SESSION['company_id'] ?? 0);
    if ($currentCompanyId > 0) {
        $branchStmt = $conn->prepare("SELECT `id`, `branch_name`, `city`, `state` FROM `erp_branches` WHERE `company_id` = ? AND `status` = 1 AND `deleted_at` IS NULL ORDER BY `is_head_office` DESC, `branch_name` ASC");
        $branchStmt->bind_param('i', $currentCompanyId);
        $branchStmt->execute();
        $branchResult = $branchStmt->get_result();
    } else {
        $branchStmt = null;
        $branchResult = $conn->query("SELECT `id`, `branch_name`, `city`, `state` FROM `erp_branches` WHERE `status` = 1 AND `deleted_at` IS NULL ORDER BY `is_head_office` DESC, `branch_name` ASC");
    }
    if ($branchResult) {
        while ($branchRow = $branchResult->fetch_assoc()) {
            $branchLabel = trim((string) $branchRow['branch_name']);
            $locationLabel = implode(', ', array_filter([
                trim((string) ($branchRow['city'] ?? '')),
                trim((string) ($branchRow['state'] ?? '')),
            ]));
            if ($locationLabel !== '') {
                $branchLabel .= ' - ' . $locationLabel;
            }
            $purchaseBranchOptionsHtml .= '<option value="' . (int) $branchRow['id'] . '">' . htmlspecialchars($branchLabel, ENT_QUOTES, 'UTF-8') . '</option>';
        }
    }
    if ($branchStmt) {
        $branchStmt->close();
    }
    $qtyUnitsJson = [];
    $unitResult = $conn->query("SELECT `id`, `fullname`, `short_name` FROM `standard_units` WHERE `status` = 1 ORDER BY `fullname` ASC");
    if ($unitResult) {
        while ($unitRow = $unitResult->fetch_assoc()) {
            $unitLabel = trim((string) ($unitRow['fullname'] ?? ''));
            if (trim((string) ($unitRow['short_name'] ?? '')) !== '') {
                $unitLabel .= ' (' . trim((string) $unitRow['short_name']) . ')';
            }
            $purchaseUnitOptionsHtml .= '<option value="' . (int) $unitRow['id'] . '">' . htmlspecialchars($unitLabel, ENT_QUOTES, 'UTF-8') . '</option>';
            $qtyUnitsJson[] = [
                'id' => (int) $unitRow['id'],
                'label' => $unitLabel
            ];
        }
    }

    $purchaseMaterialsList = [];
    $materialsResult = $conn->query("SELECT `product_name` FROM `products` WHERE `status` = 1 AND `deleted_at` IS NULL ORDER BY `product_name` ASC");
    if ($materialsResult) {
        while ($matRow = $materialsResult->fetch_assoc()) {
            if (!empty(trim($matRow['product_name']))) {
                $purchaseMaterialsList[] = trim($matRow['product_name']);
            }
        }
    }
}
?>
<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage purchase requests and low stock items</p>
        </div>
    </div>

    <!-- Inbound Purchase Requests (Pending) Widget Banner -->
    <div id="inboundPurchaseRequestsWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" data-bs-toggle="modal"
        data-bs-target="#inboundPurchaseRequestsModal">
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
            style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div
                    style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: #fef3c7; border-radius: 0.75rem;">
                    <i class="ti ti-bell text-amber-600" style="font-size: 1.5rem;"></i>
                    <span
                        style="position: absolute; top: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: #d97706; color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: #1e293b; margin: 0;">
                            Inbound Purchase Requests (Pending)</h3>
                        <span id="inboundPurchaseRequestsCount"
                            style="display: flex; align-items: center; justify-content: center; min-width: 1.25rem; height: 1.25rem; padding: 0 4px; background-color: #d97706; color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px;">0</span>
                    </div>
                    <p class="font-medium text-slate-500 mt-1 mb-0" style="font-size: 0.875rem;">
                        Click on widget to view pending purchase requests.
                    </p>
                </div>
            </div>
            <div class="text-slate-400">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-visible">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3 rounded-t-2xl">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="pmPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl z-[1050]">
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100">100 items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="1000">1000 items</a></li>
                            <li><a class="pm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <div class="dropdown shrink-0 w-full md:w-auto">
                        <button
                            class="flex h-11 w-full md:w-40 items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                <i class="ti ti-filter text-base text-slate-400"></i>
                                Status
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <div
                            class="dropdown-menu max-h-72 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-2xl z-[1050]">
                            <?php if (!empty(Constant::LOW_STOCK['STATUS'])) { ?>
                                <label
                                    class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox" class="status-filter rounded border-slate-300 accent-emerald-600"
                                        value="all"> <span>All</span>
                                </label>
                                <?php foreach (Constant::LOW_STOCK['STATUS'] as $sfpckey => $sfpcval) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="status-filter rounded border-slate-300 accent-emerald-600"
                                            value="<?php echo $sfpckey; ?>"> <span><?php echo $sfpcval['label']; ?></span>
                                    </label>
                                <?php }
                            } ?>
                        </div>
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36"
                        data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>

                    <button type="button"
                        class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        id="addPurchaseOrderMenuBtn" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                        <i class="ti ti-plus text-lg"></i>
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto w-full min-h-[320px] rounded-b-2xl">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="w-28 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 cursor-pointer sortable transition-colors hover:bg-slate-50/50"
                                data-column="created_date" data-default="desc" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort by Date">
                                <span class="inline-flex items-center gap-1">Date</span>
                            </th>
                            <th class="w-64 min-w-[220px] px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 cursor-pointer sortable transition-colors hover:bg-slate-50/50"
                                data-column="vendor" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort by Vendor">
                                <span class="inline-flex items-center gap-1">Vendor</span>
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 cursor-pointer sortable transition-colors hover:bg-slate-50/50"
                                data-column="category" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort by Category">
                                <span class="inline-flex items-center gap-1">Category</span>
                            </th>
                            <th class="w-80 min-w-[300px] px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 cursor-pointer sortable transition-colors hover:bg-slate-50/50"
                                data-column="product" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort by Product Name">
                                <span class="inline-flex items-center gap-1">Product Name</span>
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 cursor-pointer sortable transition-colors hover:bg-slate-50/50"
                                data-column="req_qty" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort by Req Qty">
                                <span class="inline-flex items-center gap-1">Req Qty</span>
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Is
                                Critical</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 cursor-pointer sortable transition-colors hover:bg-slate-50/50"
                                data-column="status" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort by Status">
                                <span class="inline-flex items-center gap-1">Status</span>
                            </th>
                            <th class="w-40 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Requested By</th>
                            <th
                                class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="employeesTableBody">
                    </tbody>
                </table>
            </div>

            <style>
                #footerPerPageSelect+.dropdown {
                    display: none !important;
                }
                #vendorName + .select2-container,
                #vendorNameRaw + .select2-container {
                    min-width: 280px !important;
                }
                @media (max-width: 575.98px) {
                    #vendorName + .select2-container,
                    #vendorNameRaw + .select2-container {
                        min-width: 0 !important;
                        max-width: 100% !important;
                    }
                }
                .select2-small-dropdown .select2-results__options {
                    max-height: 100px !important;
                    overflow-y: auto !important;
                }
                #addLowStockModal .modal-dialog {
                    width: 100%;
                    max-width: 710px; /* Increased breadth by 20% from 590px */
                    height: min(55rem, calc(100vh - 2rem));
                    height: min(55rem, calc(100dvh - 2rem));
                    margin-top: 1rem;
                    margin-bottom: 1rem;
                    margin-left: auto;
                    margin-right: auto;
                }
                #addLowStockModal .modal-content {
                    height: 100%;
                    max-height: 100%;
                    border-radius: 1.5rem !important;
                    box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35), 0 0 0 1px rgba(15, 23, 42, 0.08) !important;
                }
                @media (max-width: 575.98px) {
                    #addLowStockModal .modal-dialog {
                        max-width: calc(100% - 1rem);
                        height: calc(100vh - 1rem);
                        height: calc(100dvh - 1rem);
                        margin: 0.5rem auto;
                    }
                }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addLowStockModal" tabindex="-1" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden !rounded-3xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Low
                                Stock - Purchase Request Form</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Fill whenever any item goes out of stock.
                                Provide complete and accurate details.</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addLowStocksForm">
                    <div class="modal-body space-y-3 bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <label for="reportingPerson" class="mb-1 block text-sm font-medium text-slate-800">Name
                                    of Person Reporting <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="reportingPerson" autocomplete="off" name="reportingPerson"
                                    class="input-theme" placeholder="Enter Name" required />
                            </div>
                            <div>
                                <label for="dateOfReport" class="mb-1 block text-sm font-medium text-slate-800">Date of
                                    Report <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="dateOfReport" autocomplete="off" name="dateOfReport"
                                    class="input-theme" placeholder="Enter Date" value="<?php echo date('Y-m-d'); ?>" required />
                            </div>
                        </div>
                        <div>
                            <label class="mb-2 block text-sm font-medium text-slate-800">Material Lines</label>
                            <div id="mrProductsWrapper"></div>
                            <div>
                                <button type="button"
                                    class="inline-flex h-11 w-40 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addMrProducts">
                                    <i class="ti ti-plus text-lg"></i> <span class="whitespace-nowrap">Add
                                        Product</span>
                                </button>
                            </div>
                        </div>

                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="purchaseOrderEditModal" tabindex="-1" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Finalise Purchase Order Request
                            </h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="purchaseOrderEditForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="productionPlanViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View Purchase Order Request
                            </h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="productionPlanViewForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addRmPmSelectionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 450px;">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-select text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-base font-bold text-slate-900">Add Purchase Order</h5>
                            <p class="m-0 text-xs font-medium text-slate-500">Select material type to proceed</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-rose-50 text-rose-700 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-base"></i></button>
                </div>
                <div class="modal-body bg-white !px-4 !py-4">
                    <div class="mb-4">
                        <label for="materialTypeSelect" class="mb-2 block text-sm font-semibold text-slate-800">Select
                            Material Type <strong class="text-rose-500">*</strong></label>
                        <select id="materialTypeSelect" class="input-theme select2" style="width: 100%;">
                            <option value="">----Select Option----</option>
                            <option value="RM">Raw Material (RM)</option>
                            <option value="PM">Packing Material (PM)</option>
                            <option value="CONSUMABLE">Consumables</option>
                            <option value="FG">Finished Goods (FG)</option>
                        </select>
                    </div>
                </div>
                <div class="flex justify-end gap-3 border-t border-slate-200 bg-slate-50/80 px-4 py-3">
                    <button type="button"
                        class="inline-flex h-9 min-w-24 items-center justify-center !rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
                        data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="btnNextRmPm"
                        class="inline-flex h-9 min-w-24 items-center justify-center gap-1.5 !rounded-xl bg-emerald-700 px-4 text-xs font-bold text-white shadow-sm transition-colors hover:bg-emerald-800">
                        Next <i class="ti ti-chevron-right text-sm"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before
                            downloading.</p>
                    </div>
                    <button type="button"
                        class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="purchaseManagementExportForm" class="purchase-management-export-form">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label
                                class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE
                                FORMAT</label>
                            <div class="dropdown w-full">
                                <button
                                    class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                                    type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                            data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                            data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                            data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>

                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT
                                    COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn"
                                    class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect
                                    All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Sr No" checked />
                                        <span class="text-sm font-medium text-slate-700">Sr No</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Date of Report" checked />
                                        <span class="text-sm font-medium text-slate-700">Date of Report</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Vendor" checked />
                                        <span class="text-sm font-medium text-slate-700">Vendor</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Category" checked />
                                        <span class="text-sm font-medium text-slate-700">Category</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Product Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Product Name</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Req Qty" checked />
                                        <span class="text-sm font-medium text-slate-700">Req Qty</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Is Critical" checked />
                                        <span class="text-sm font-medium text-slate-700">Is Critical</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Status</span>
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]"
                                            class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                            value="Requested By" checked />
                                        <span class="text-sm font-medium text-slate-700">Requested By</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button"
                            class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none"
                            style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile"
                            class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none"
                            style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Finalized Purchase Order Modal (PM) -->
    <div class="modal fade animate__animated fadeIn" id="addPurchaseOrderModal" tabindex="-1" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Purchase Order</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div id="purchaseOrderFormContainer">
                    <div class="modal-body bg-white !px-6 !py-5">
                        <div class="col-xl-12 col-md-12 col-12 mb-md-0 mb-4">
                            <div class="card">
                                <div class="overflow-auto w-100">
                                    <div class="po-doc">
                                        <div class="transfer-copy">
                                            <div class="po-doc-box">
                                                <table class="po-doc-table po-doc-table-auto whitespace-nowrap">
                                                    <tr>
                                                        <td class="po-doc-logo-cell">
                                                            <table class="po-doc-table">
                                                                <tr>
                                                                    <td class="po-doc-logo-wrap">
                                                                        <img src="<?= asset('assets/img/logo3.jpeg'); ?>"
                                                                            alt="Biogenix Logo" class="po-doc-logo">
                                                                        <div class="po-doc-cin">
                                                                            CIN NO. U24304UP2016PTC082775
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-company">
                                                                        B19/A S.I.L. Ancillary Estate, Amausi<br>
                                                                        Industrial Area, Nadarganj-226008<br>
                                                                        (Lucknow)<br>
                                                                        GSTN: 09AACGB6941G1ZJ
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="po-doc-title-cell">
                                                            <strong class="fs-6">TITLE: Purchase Order</strong>
                                                        </td>
                                                        <td class="po-doc-meta-cell">
                                                            <table class="po-doc-meta-table">
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Document No.</td>
                                                                    <td class="po-doc-meta-value">BIPL-F-PO-01</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Issue No.</td>
                                                                    <td class="po-doc-meta-value">01</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Revision No.</td>
                                                                    <td class="po-doc-meta-value">02</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Effective Date</td>
                                                                    <td class="po-doc-meta-value">03/04/2025</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Review Date</td>
                                                                    <td class="po-doc-meta-value">02/04/2028</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Department</td>
                                                                    <td class="po-doc-meta-value">Purchase</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label po-doc-meta-last">
                                                                        Supersedes</td>
                                                                    <td class="po-doc-meta-value po-doc-meta-last">Nil
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <form id="purchaseOrderFormAdd">
                                                <div id="procurementOrderContextPM"
                                                    class="mx-3 mt-3 hidden grid grid-cols-1 gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 sm:grid-cols-2">
                                                    <div>
                                                        <label for="procurementOrderReferencePM"
                                                            class="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-500">Order
                                                            Reference</label>
                                                        <input type="text" id="procurementOrderReferencePM"
                                                            class="input-theme cursor-default" readonly />
                                                    </div>
                                                    <div>
                                                        <label for="procurementCategoryPM"
                                                            class="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-500">Product
                                                            Category</label>
                                                        <input type="text" id="procurementCategoryPM"
                                                            class="input-theme cursor-default" readonly />
                                                    </div>
                                                </div>
                                                <div class="p-3">
                                                    <table class="po-doc-table">
                                                        <tr class="po-doc-row">
                                                            <td class="po-doc-field-main">
                                                                <input type="text" name="poNumber" id="poNumber"
                                                                    value="<?= generateUniquePoOrderNum($conn); ?>"
                                                                    readonly />
                                                            </td>
                                                            <td class="po-doc-field-side">Date:
                                                                <input type="text"
                                                                    value="<?= formatDatePO(date('Y-m-d')); ?>"
                                                                    readonly />
                                                                <input type="hidden" name="poDate"
                                                                    value="<?= date('Y-m-d'); ?>" />
                                                            </td>
                                                        </tr>
                                                        <tr class="po-doc-row">
                                                            <td class="po-doc-field-main">
                                                                <div
                                                                    style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <span>To :</span>
                                                                    <select name="vendorName" id="vendorName"
                                                                        class="input-theme select2" style="width: 50%; min-width: 280px;"
                                                                        required><?= $purchaseSupplierOptionsHtml ?></select>
                                                                </div>
                                                            </td>
                                                            <td class="po-doc-field-side"></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <table id="poTable" class="po-doc-form-table">
                                                    <thead
                                                        class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                                        <tr>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Material(s)</th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Pack Size</th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Quantity Req.</th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Price in
                                                                <select name="poCurrency" id="poCurrency" required>
                                                                    <?php
                                                                    if (!empty(Constant::PURCHASE_MANAGEMENT['CURRENCY'])) {
                                                                        $html = '<option value="">--Select Option--</option>';
                                                                        foreach (Constant::PURCHASE_MANAGEMENT['CURRENCY'] as $key => $value) {
                                                                            $html .= '<option value="' . $key . '">' . $value['label'] . ' (' . $value['symbol'] . ') </option>';
                                                                        }
                                                                        echo $html;
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">#
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="poTableBody">
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="2" class="text-center p-2">
                                                                <button type="button" id="addRowBtn"
                                                                    class="inline-flex h-11 min-w-40 whitespace-nowrap shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none"><i
                                                                        class="ti ti-plus text-lg"></i> Add New</button>
                                                            </td>
                                                            <td colspan="3" class="text-center p-2">
                                                                <button type="submit"
                                                                    class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none"><i
                                                                        class="ti ti-check text-lg"></i> Submit</button>
                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Finalized Purchase Order View Modal (PM) -->
    <div class="modal fade animate__animated fadeIn" id="finalPurchaseOrderViewPdfModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Final Purchase Order PDF Preview</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <!-- Company Address Selector for Viewed PO (PM) -->
                <div class="px-6 py-2 border-b border-slate-200 bg-slate-50 flex items-center gap-3">
                    <i class="ti ti-building text-indigo-500 text-base shrink-0"></i>
                    <label for="poViewCompanyAddressSelectPM"
                        class="text-xs font-bold text-slate-600 whitespace-nowrap shrink-0">Company Address (on PO
                        Print/View):</label>
                    <select id="poViewCompanyAddressSelectPM"
                        class="input-theme text-xs h-8 py-0 flex-1 poViewCompanyAddressSelectClass">
                        <option value="">--- Use Default ---</option>
                    </select>
                </div>
                <div id="finalPurchaseOrderViewPdf">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Raw Purchase Order Add Modal (RM) -->
    <div class="modal fade animate__animated fadeIn" id="addPurchaseOrderRawModal" tabindex="-1" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 1104px !important;" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Purchase Order Raw</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addPurchaseOrderRawForm">
                    <div class="modal-body bg-white !px-6 !py-5">
                        <div class="col-xl-12 col-md-12 col-12 mb-md-0 mb-4">
                            <div class="card">
                                <div class="overflow-auto w-100">
                                    <div class="po-doc">
                                        <div class="transfer-copy">
                                            <div class="po-doc-box">
                                                <table class="po-doc-table po-doc-table-auto whitespace-nowrap">
                                                    <tr>
                                                        <td class="po-doc-logo-cell">
                                                            <table class="po-doc-table">
                                                                <tr>
                                                                    <td class="po-doc-logo-wrap">
                                                                        <img src="<?= asset('assets/img/logo3.jpeg'); ?>"
                                                                            alt="Biogenix Logo" class="po-doc-logo">
                                                                        <div class="po-doc-cin">
                                                                            CIN NO. U24304UP2016PTC082775
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-company">
                                                                        B19/A S.I.L. Ancillary Estate, Amausi<br>
                                                                        Industrial Area, Nadarganj-226008<br>
                                                                        (Lucknow)<br>
                                                                        GSTN: 09AACGB6941G1ZJ
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="po-doc-title-cell">
                                                            <strong class="fs-6">TITLE: Purchase Order</strong>
                                                        </td>
                                                        <td class="po-doc-meta-cell">
                                                            <table class="po-doc-meta-table">
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Document No.</td>
                                                                    <td class="po-doc-meta-value">BIPL-F-PO-01</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Issue No.</td>
                                                                    <td class="po-doc-meta-value">01</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Revision No.</td>
                                                                    <td class="po-doc-meta-value">02</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Effective Date</td>
                                                                    <td class="po-doc-meta-value">03/04/2025</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Review Date</td>
                                                                    <td class="po-doc-meta-value">02/04/2028</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Department</td>
                                                                    <td class="po-doc-meta-value">Purchase</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label po-doc-meta-last">
                                                                        Supersedes</td>
                                                                    <td class="po-doc-meta-value po-doc-meta-last">Nil
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            
                                            <div id="procurementOrderContextRM"
                                                class="mx-3 mt-3 hidden grid grid-cols-1 gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 sm:grid-cols-2">
                                                <div>
                                                    <label for="procurementOrderReferenceRM"
                                                        class="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-500">Order
                                                        Reference</label>
                                                    <input type="text" id="procurementOrderReferenceRM" class="input-theme cursor-default"
                                                        readonly />
                                                </div>
                                                <div>
                                                    <label for="procurementCategoryRM"
                                                        class="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-500">Product
                                                        Category</label>
                                                    <input type="text" id="procurementCategoryRM" class="input-theme cursor-default"
                                                        readonly />
                                                </div>
                                            </div>

                                            <div class="p-3">
                                                <table class="po-doc-table">
                                                    <tr class="po-doc-row">
                                                        <td class="po-doc-field-main">
                                                            <input type="text" name="poNumberRaw" id="poNumberRaw"
                                                                value="<?= generateUniquePoOrderNumForRaw($conn); ?>"
                                                                readonly />
                                                        </td>
                                                        <td class="po-doc-field-side">Date:
                                                            <input type="text"
                                                                value="<?= formatDatePO(date('Y-m-d')); ?>"
                                                                readonly />
                                                            <input type="hidden" name="poDate"
                                                                value="<?= date('Y-m-d'); ?>" />
                                                        </td>
                                                    </tr>
                                                    <tr class="po-doc-row">
                                                        <td class="po-doc-field-main">
                                                            <div
                                                                style="display: flex; align-items: center; gap: 0.5rem;">
                                                                <span>To :</span>
                                                                <select name="vendorName" id="vendorNameRaw"
                                                                    class="input-theme select2" style="width: 50%; min-width: 280px;"
                                                                    required><?= $purchaseSupplierOptionsHtml ?></select>
                                                            </div>
                                                        </td>
                                                        <td class="po-doc-field-side"></td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <table id="poTableRaw" class="po-doc-form-table">
                                                <thead
                                                    class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                                    <tr>
                                                        <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                            Material(s)</th>
                                                        <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                            Size</th>
                                                        <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                            Thickness</th>
                                                        <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                            Quantity Req.</th>
                                                        <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                            Price in
                                                            <select name="poCurrency" id="poCurrencyRaw" required>
                                                                <?php
                                                                if (!empty(Constant::PURCHASE_MANAGEMENT['CURRENCY'])) {
                                                                    $html = '<option value="">--Select Option--</option>';
                                                                    foreach (Constant::PURCHASE_MANAGEMENT['CURRENCY'] as $key => $value) {
                                                                        $html .= '<option value="' . $key . '">' . $value['label'] . ' (' . $value['symbol'] . ') </option>';
                                                                    }
                                                                    echo $html;
                                                                }
                                                                ?>
                                                            </select>
                                                        </th>
                                                        <th class="border-b border-slate-200 px-6 py-3 po-doc-th">#
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody id="productsList">
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="3" class="text-center p-2">
                                                            <button type="button" id="addProductBtn"
                                                                class="inline-flex h-11 min-w-40 whitespace-nowrap shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none"><i
                                                                    class="ti ti-plus text-lg"></i> Add New</button>
                                                        </td>
                                                        <td colspan="3" class="text-center p-2">
                                                            <button type="submit"
                                                                class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none"><i
                                                                    class="ti ti-check text-lg"></i> Submit</button>
                                                        </td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Raw Purchase Order View Modal (RM) -->
    <div class="modal fade animate__animated fadeIn" id="viewPurchaseOrderRawModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Purchase Order Details</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <!-- Company Address Selector for Viewed PO (RM) -->
                <div class="px-6 py-2 border-b border-slate-200 bg-slate-50 flex items-center gap-3">
                    <i class="ti ti-building text-indigo-500 text-base shrink-0"></i>
                    <label for="poViewCompanyAddressSelect"
                        class="text-xs font-bold text-slate-600 whitespace-nowrap shrink-0">Company Address (on PO
                        Print/View):</label>
                    <select id="poViewCompanyAddressSelect"
                        class="input-theme text-xs h-8 py-0 flex-1 poViewCompanyAddressSelectClass">
                        <option value="">--- Use Default ---</option>
                    </select>
                </div>
                <form id="viewPurchaseOrderRaw">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Raw Purchase Order Edit Modal (RM) -->
    <div class="modal fade animate__animated fadeIn" id="editOrderReceivedModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 960px !important;" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Purchase Order</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editPurchaseOrderRawForm">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Final Purchase Order Edit Modal (PM) -->
    <div class="modal fade animate__animated fadeIn" id="editOrderReceivedModalPM" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 960px !important;" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Final Purchase Order</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editPurchaseOrderFinalForm">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Inbound Purchase Requests Modal -->
<div class="modal fade animate__animated fadeIn" id="inboundPurchaseRequestsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div
                class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <span
                        class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                        <i class="ti ti-bell text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Pending Purchase Requests</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Review and generate POs</p>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <button type="button" id="generateBulkPOBtn"
                        class="inline-flex h-9 items-center gap-1.5 rounded-lg bg-emerald-700 px-3 text-xs font-bold text-white transition-all hover:bg-emerald-800 disabled:bg-slate-400 disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled>
                        <i class="ti ti-file-text text-sm"></i> Generate Bulk PO for Selected Items
                    </button>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
            </div>
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full border-collapse text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-100 bg-slate-50/70 whitespace-nowrap">
                            <tr>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 w-10">
                                    <input type="checkbox" id="selectAllPendingRequests" class="form-check-input" />
                                </th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Date</th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Order #</th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Product Name</th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Category</th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Req
                                    Qty</th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Priority</th>
                                <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">By
                                </th>
                                <th
                                    class="px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400 sticky right-0 bg-slate-50 shadow-[-4px_0_6px_-1px_rgba(0,0,0,0.05)] z-10">
                                    Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 bg-white" id="inboundPurchaseRequestsTableBody">
                            <!-- Dynamically populated via AJAX -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="flex items-center justify-between border-t border-slate-200 bg-white px-4 py-3">
                <div class="text-sm font-medium text-slate-500" id="selectedPendingCountText">
                    0 items selected
                </div>
                <div class="flex items-center gap-3">
                    <span class="text-sm font-medium text-slate-500" id="pendingRequestsPageIndicator">Page 1 of 1</span>
                    <button type="button" id="prevPendingPageBtn" class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 transition-colors hover:bg-slate-50 disabled:opacity-50" disabled>
                        <i class="ti ti-chevron-left text-base"></i>
                    </button>
                    <button type="button" id="nextPendingPageBtn" class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 transition-colors hover:bg-slate-50 disabled:opacity-50" disabled>
                        <i class="ti ti-chevron-right text-base"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Purchase Request Modal -->
<div class="modal fade animate__animated fadeIn" id="editPurchaseRequestModal" tabindex="-1" aria-hidden="true" data-bs-focus="false">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                        <i class="ti ti-pencil text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Purchase Request</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Modify the details of your pending procurement request.</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                    data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
            </div>
            <div class="modal-body space-y-4 bg-slate-50/70 !px-4 !py-4">

                 <!-- Row 1: Reporter Name + Date of Report -->
                 <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                     <div>
                         <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-400">Reporter Name <strong class="text-rose-500">*</strong></label>
                         <input type="text" id="eprReporterName"
                             class="input-theme cursor-not-allowed bg-slate-100 text-slate-500"
                             placeholder="Reporter name" readonly aria-readonly="true"
                             title="Reporter name is assigned when the purchase request is created." required />
                     </div>
                     <div>
                         <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-400">Date of Report <strong class="text-rose-500">*</strong></label>
                         <input type="date" id="eprDateOfReport" class="input-theme" required />
                     </div>
                 </div>

                <!-- Product Details Section -->
                <div>
                    <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-400">Product Details</label>
                    <div id="eprProductsWrapper" class="space-y-2"></div>
                    <button type="button" id="eprAddProductBtn"
                        class="mt-2 inline-flex h-9 items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-700 transition-colors hover:bg-emerald-100 focus:outline-none">
                        <i class="ti ti-plus text-sm"></i> Add Another Product
                    </button>
                </div>

                <!-- Row: Vendor Selection + Critical Priority -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                    <div>
                        <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-400">Vendor Selection</label>
                        <select id="eprVendorName" class="input-theme select2" style="width:100%;">
                            <?php echo $purchaseSupplierOptionsHtml; ?>
                        </select>
                    </div>
                    <div>
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-400">Critical Priority</label>
                        <div class="inline-flex w-full sm:w-auto items-center gap-1 rounded-xl bg-slate-100 p-1 border border-slate-200/40" id="eprCriticalPriorityGroup">
                            <?php foreach (Constant::LOW_STOCK['CRITICAL_STATUS'] as $critKey => $critVal): ?>
                                <label class="epr-radio-label inline-flex cursor-pointer items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-500 transition-all hover:text-slate-800"
                                    data-badge="<?php echo htmlspecialchars($critVal['badge'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                                    <input type="radio" name="eprCriticalPriority" value="<?php echo (int)$critKey; ?>" class="sr-only epr-radio-input" />
                                    <span class="epr-radio-dot h-2.5 w-2.5 rounded-full bg-slate-400"></span>
                                    <span><?php echo htmlspecialchars($critVal['label'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Expected Date of Delivery -->
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-400">Expected Date of Delivery</label>
                    <input type="date" id="eprExpectedDelivery" class="input-theme" />
                </div>

            </div>
            <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                <button type="button" id="eprCancelBtn"
                    class="inline-flex h-10 min-w-24 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="eprGeneratePOBtn"
                    class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    Generate PO <i class="ti ti-arrow-right text-base"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let productIndex = 1;
    let productIndexPor = 0;
    let currentSortColumn = 'created_date';
    let currentSortOrder = 'DESC';
    let selectedStatusFilters = [];
    const LOW_STOCK = <?php echo json_encode(Constant::LOW_STOCK['CRITICAL_STATUS']); ?>;
    const PROCUREMENT_PRODUCT_IDS = <?php echo json_encode($procureProductIds); ?>;
    const PROCUREMENT_SOURCE = <?php echo json_encode($procurementSourceParam); ?>;
    const DEFAULT_REPORTING_PERSON = <?php echo json_encode($_SESSION['user_name'] ?? ($_SESSION['username'] ?? ($_SESSION['name'] ?? ''))); ?>;
    const TODAY_DATE = <?php echo json_encode(date('Y-m-d')); ?>;
    const PURCHASE_CURRENCIES = <?php echo json_encode(Constant::PURCHASE_MANAGEMENT['CURRENCY']); ?>;
    const PURCHASE_SUPPLIERS = <?php echo json_encode($purchaseSupplierOptions); ?>;
    const PURCHASE_MATERIALS = <?php echo json_encode($purchaseMaterialsList ?? []); ?>;
    let qtyUnitOptions = <?php echo json_encode($qtyUnitsJson ?? []); ?>;

    function loadStandardUnit() {
        // qtyUnitOptions is prefilled synchronously above
    }

    function loadMaterialTypeOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialTypeOption: 'loadMaterialTypeOption'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (prodCateg) {
                    html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                });
                $('#materialTypeList').html(html).trigger('change');
            }
        });
    }

    function loadLowStockRequestTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const selectedStatuses = [];
        $('.status-filter:checked').each(function () {
            const val = $(this).val();
            if (val !== 'all') {
                selectedStatuses.push(val);
            }
        });

        $('#employeesTableBody').html('<tr><td colspan="10" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        // 1. Fetch Inbound Purchase Requests (Pending) Cards/Table
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadInboundRequests: 'loadInboundRequests'
            },
            success: function (response) {
                $('#inboundPurchaseRequestsTableBody').html(response.html || '');
                $('#inboundPurchaseRequestsCount').text(response.count || 0);
                $('#inboundPurchaseRequestsWidget').show(); // Always show as requested
            },
            error: function () {
                $('#inboundPurchaseRequestsTableBody').html('<tr><td colspan="9" class="text-center py-6 text-sm font-medium text-rose-600 bg-white">Error loading pending requests.</td></tr>');
                $('#inboundPurchaseRequestsCount').text(0);
            }
        });

        // 2. Fetch Finalized Purchase Orders Table
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadFinalizedPurchaseOrders: 'loadFinalizedPurchaseOrders',
                page: page,
                per_page: perPage,
                search: search,
                selectedStatuses: selectedStatuses,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#employeesTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') {
                    window.updatePaginationSummary('paginationSummary', response.totalRows, currentPage, 'footerPerPageSelect');
                }
            },
            error: function () {
                $('#employeesTableBody').html('<tr><td colspan="10" class="px-6 py-10 text-center text-sm font-medium text-rose-600">Error loading finalized purchase orders.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function updateItemNumbers() {
        $('#mrProductsWrapper .product-row').each(function (index) {
            $(this).attr('data-index', index + 1);
            $(this).find('h6.item-title').text('Item ' + (index + 1));
        });
        productIndex = $('#mrProductsWrapper .product-row').length + 1;
    }

    function escapeHtml(value) {
        return $('<div>').text(value === null || value === undefined ? '' : value).html();
    }

    function loadProductsForSelect($productSelect, materialTypeId, selectedProductId) {
        materialTypeId = materialTypeId || '';
        selectedProductId = selectedProductId || '';
        $productSelect.prop('disabled', true);
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProductsByMaterialType: 'loadProductsByMaterialType',
                materialTypeId: materialTypeId
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                if (Array.isArray(response) && response.length > 0) {
                    response.forEach(function (product) {
                        const catAttr = product.category_id ? ` data-category-id="${product.category_id}"` : '';
                        const unitAttr = product.unit_id ? ` data-unit-id="${product.unit_id}"` : '';
                        const isSelected = String(product.key) === String(selectedProductId) ? ' selected' : '';
                        html += `<option value="${product.key}"${catAttr}${unitAttr}${isSelected}>${escapeHtml(product.value)}</option>`;
                    });
                } else if (materialTypeId) {
                    html += '<option value="" disabled>No products in this category</option>';
                }
                $productSelect.empty().html(html);
                $productSelect.val(selectedProductId || '');
                $productSelect.prop('disabled', false).trigger('change');
            },
            error: function () {
                $productSelect.prop('disabled', false);
            }
        });
    }

    function buildUnitOptions(selected = '') {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            const isSelected = String(unit.id) === String(selected) ? 'selected' : '';
            optionsHtml += `<option value="${unit.id}" ${isSelected}>${escapeHtml(unit.label)}</option>`;
        });
        return optionsHtml;
    }

    function buildCriticalOptions(selected = '') {
        let criticalOptionsHtml = '<option value="">---Select----</option>';
        Object.entries(LOW_STOCK).forEach(([key, data]) => {
            const isSelected = String(key) === String(selected) ? 'selected' : '';
            criticalOptionsHtml += `<option value="${key}" data-badge="${escapeHtml(data.badge || '')}" ${isSelected}>${escapeHtml(data.label || '')}</option>`;
        });
        return criticalOptionsHtml;
    }

    function buildCurrencyOptions(selected = '') {
        let currencyOptionsHtml = '<option value="">--Select Option--</option>';
        Object.entries(PURCHASE_CURRENCIES || {}).forEach(([key, data]) => {
            const isSelected = String(key) === String(selected) ? 'selected' : '';
            currencyOptionsHtml += `<option value="${key}" ${isSelected}>${escapeHtml(data.label || '')}</option>`;
        });
        return currencyOptionsHtml;
    }

    function buildMaterialOptions(selected = '') {
        let html = '<option value="">--Select Material--</option>';
        let found = false;
        (PURCHASE_MATERIALS || []).forEach(mat => {
            let isSelected = String(mat).toLowerCase() === String(selected || '').toLowerCase() ? 'selected' : '';
            if (isSelected) found = true;
            html += `<option value="${escapeHtml(mat)}" ${isSelected}>${escapeHtml(mat)}</option>`;
        });
        if (selected && !found) {
            html += `<option value="${escapeHtml(selected)}" selected>${escapeHtml(selected)}</option>`;
        }
        return html;
    }

    function buildSupplierOptions(selected = '') {
        let supplierOptionsHtml = '<option value="">----Select Vendor----</option>';
        (PURCHASE_SUPPLIERS || []).forEach(supplier => {
            const supplierName = supplier.name || '';
            const isSelected = String(supplierName).toLowerCase() === String(selected || '').toLowerCase() ? 'selected' : '';
            supplierOptionsHtml += `<option value="${escapeHtml(supplierName)}" data-email="${escapeHtml(supplier.email || '')}" ${isSelected}>${escapeHtml(supplierName)}</option>`;
        });
        return supplierOptionsHtml;
    }

    function setSupplierSelectValue(selector, supplierName) {
        const $select = $(selector);
        if (!$select.length) return;
        const value = (supplierName || '').toString().trim();
        if (!value) {
            $select.val('').trigger('change');
            return;
        }

        // 1. Match by exact option value (case-insensitive)
        let $match = $select.find('option').filter(function () {
            return $(this).val().trim().toLowerCase() === value.toLowerCase();
        });

        // 2. Match by data-id (numeric supplier ID)
        if (!$match.length) {
            $match = $select.find('option').filter(function () {
                return String($(this).data('id') || '').trim() === value;
            });
        }

        // 3. Match by option text (case-insensitive)
        if (!$match.length) {
            $match = $select.find('option').filter(function () {
                return $(this).text().trim().toLowerCase() === value.toLowerCase();
            });
        }

        // 4. Match by partial substring match
        if (!$match.length && value.length >= 3) {
            $match = $select.find('option').filter(function () {
                const optVal = $(this).val().trim().toLowerCase();
                const optText = $(this).text().trim().toLowerCase();
                const search = value.toLowerCase();
                return (optVal && (optVal.includes(search) || search.includes(optVal))) ||
                       (optText && (optText.includes(search) || search.includes(optText)));
            });
        }

        if ($match.length) {
            $select.val($match.first().val()).trigger('change');
        } else {
            // Append and select
            $select.append(`<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`);
            $select.val(value).trigger('change');
        }
    }
    function buildPackSizeOptions(packSizes, selected = '') {
        let packSizeOptionsHtml = '<option value="">----Select Option----</option>';
        (packSizes || []).forEach(packSize => {
            const isSelected = String(packSize.id) === String(selected) ? 'selected' : '';
            packSizeOptionsHtml += `<option value="${packSize.id}" ${isSelected}>${escapeHtml(packSize.name || '')}</option>`;
        });
        return packSizeOptionsHtml;
    }

    function getSourceLabel(source) {
        if (source === 'OUT_OF_STOCK') {
            return 'Out of Stock';
        }
        if (source === 'LOW_STOCK') {
            return 'Low Stock';
        }
        return '';
    }

    function appendManualProductRow() {
        let productRow = `
            <div class="product-row mb-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm" data-index="${productIndex}">
                <input type="hidden" name="packSizeId[]" value="" />
                <input type="hidden" name="procurementSource[]" value="" />
                <input type="hidden" name="branchId[]" value="" />
                <input type="hidden" name="warehouseId[]" value="" />
                <input type="hidden" name="currentStock[]" value="" />
                <input type="hidden" name="reorderLevel[]" value="" />
                <div class="mb-2">
                    <h6 class="item-title text-sm font-bold text-emerald-700">Item ${productIndex}</h6>
                </div>
                <div class="grid grid-cols-1 gap-3 md:grid-cols-4">
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Item Type <strong class="text-rose-500">*</strong></label>
                        <select name="itemType[]" class="input-theme select2 itemTypeSelect" required>
                            <option value="inventory" selected>Standard Inventory</option>
                            <option value="non_inventory">Office / Non-Inventory Supply</option>
                        </select>
                    </div>
                    <div class="inventory-field-group">
                        <label class="mb-1 block text-sm font-medium text-slate-800">Material Category <strong class="text-rose-500">*</strong></label>
                        <select name="materialCategory[]" class="select2 input-theme materialTypeList" data-allow-clear="true" required>
                            <option value="">----Select Option----</option>
                        </select>
                    </div>
                    <div class="inventory-field-group">
                        <label class="mb-1 block text-sm font-medium text-slate-800">Product <strong class="text-rose-500">*</strong></label>
                        <select name="productsList[]" class="select2 input-theme productsList" data-allow-clear="true" required>
                            <option value="">----Select Option----</option>
                        </select>
                    </div>
                    <div class="non-inventory-field-group hidden md:col-span-2">
                        <label class="mb-1 block text-sm font-medium text-slate-800">Item Description (Non-Inventory) <strong class="text-rose-500">*</strong></label>
                        <input type="text" name="nonInventoryItemName[]" class="input-theme nonInventoryInput" placeholder="Enter supply/office item description..." />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Quantity Required Size <strong class="text-rose-500">*</strong></label>
                        <input type="number" min="0" step="any" name="ProductItemquantity[]" class="input-theme" placeholder="Product quantity" required />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Quantity Required Unit <strong class="text-rose-500">*</strong></label>
                        <select name="ProductItemquantityUnit[]" class="input-theme select2 select2-unit" required>${buildUnitOptions()}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Vendor Name <strong class="text-rose-500">*</strong></label>
                        <select name="vendorName[]" class="input-theme supplier-select" required>${buildSupplierOptions()}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Currency Type</label>
                        <select name="currencyType[]" class="input-theme">${buildCurrencyOptions()}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Price in Value</label>
                        <input type="number" min="0" step="any" autocomplete="off" name="priceInValue[]" class="input-theme" placeholder="Enter Price" />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Is This a Critical Item? <strong class="text-rose-500">*</strong></label>
                        <select name="isThisCritical[]" class="input-theme" required>${buildCriticalOptions()}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Expected Date of Delivery</label>
                        <input type="date" autocomplete="off" name="dateOfDelivery[]" class="input-theme" />
                    </div>
                    <div class="flex items-end">
                        <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center rounded-full bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove product">
                            <span class="ti ti-trash text-base"></span>
                        </button>
                    </div>
                </div>
            </div>`;
        $('#mrProductsWrapper').append(productRow);
        
        $(`.product-row[data-index="${productIndex}"] .select2-unit`).select2({
            placeholder: '----Select Option----',
            width: '100%',
            dropdownParent: $('#addLowStockModal'),
            dropdownCssClass: 'select2-small-dropdown'
        });
        
        $(`.product-row[data-index="${productIndex}"] .select2:not(.select2-unit)`).select2({
            placeholder: '----Select Option----',
            width: '100%',
            dropdownParent: $('#addLowStockModal')
        });

        const $newRow = $(`.product-row[data-index="${productIndex}"]`);
        const $newMaterialSelect = $newRow.find('.materialTypeList');
        const $newProductSelect = $newRow.find('.productsList');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialTypeOption: 'loadMaterialTypeOption',
                onlyWithProducts: 1
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (item) {
                    html += `<option value="${item.key}">${escapeHtml(item.value)}</option>`;
                });
                $newMaterialSelect.html(html);
            }
        });

        // Immediately load active products into the product dropdown so it is never empty
        loadProductsForSelect($newProductSelect, '');
        productIndex++;
        updateItemNumbers();
    }

    $(document).on('change', '.itemTypeSelect', function () {
        const $row = $(this).closest('.product-row');
        const isNonInventory = $(this).val() === 'non_inventory';
        if (isNonInventory) {
            $row.find('.inventory-field-group').addClass('hidden');
            $row.find('.materialTypeList, .productsList').prop('required', false);
            $row.find('.non-inventory-field-group').removeClass('hidden');
            $row.find('.nonInventoryInput').prop('required', true).focus();
        } else {
            $row.find('.non-inventory-field-group').addClass('hidden');
            $row.find('.nonInventoryInput').prop('required', false);
            $row.find('.inventory-field-group').removeClass('hidden');
            $row.find('.materialTypeList, .productsList').prop('required', true);
        }
    });

    function appendProcurementProductRow(item) {
        const source = item.source || PROCUREMENT_SOURCE || '';
        const sourceLabel = getSourceLabel(source);
        const currentStock = item.current_stock || '0.000';
        const reorderLevel = Math.round(parseFloat(item.reorder_level || '0'));
        const currentStockText = currentStock + (item.quantity_unit_name ? ' ' + item.quantity_unit_name : '');
        let productRow = `
            <div class="product-row mb-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm" data-index="${productIndex}">
                <input type="hidden" name="materialCategory[]" value="${escapeHtml(item.category_id || '')}" />
                <input type="hidden" name="productsList[]" value="${escapeHtml(item.product_id || '')}" />
                <input type="hidden" name="procurementSource[]" value="${escapeHtml(source)}" />
                <input type="hidden" name="branchId[]" value="${escapeHtml(item.branch_id || '')}" />
                <input type="hidden" name="warehouseId[]" value="${escapeHtml(item.warehouse_id || '')}" />
                <input type="hidden" name="currentStock[]" value="${escapeHtml(currentStock)}" />
                <input type="hidden" name="reorderLevel[]" value="${escapeHtml(reorderLevel)}" />
                <div class="mb-2">
                    <h6 class="item-title text-sm font-bold text-emerald-700">Item ${productIndex}</h6>
                </div>
                <div class="grid grid-cols-1 gap-3 md:grid-cols-4">
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Material Category</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(item.category_name || '')}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Product</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(item.product_name || '')}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Pack Size</label>
                        <select name="packSizeId[]" class="input-theme">${buildPackSizeOptions(item.pack_sizes || [], item.pack_size_id || '')}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Current Stock</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(currentStockText)}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">L/S Reorder Level</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(reorderLevel)}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Source</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(sourceLabel)}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Branch</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(item.branch_name || '')}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Warehouse</label>
                        <input type="text" class="input-theme bg-slate-100" value="${escapeHtml(item.warehouse_name || '')}" readonly />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Quantity Required Size <strong class="text-rose-500">*</strong></label>
                        <input type="number" min="0" step="any" name="ProductItemquantity[]" class="input-theme" value="" placeholder="Product quantity" required />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Quantity Required Unit <strong class="text-rose-500">*</strong></label>
                        <select name="ProductItemquantityUnit[]" class="input-theme select2 select2-unit" required>${buildUnitOptions(item.required_qty_unit || '')}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Vendor Name <strong class="text-rose-500">*</strong></label>
                        <select name="vendorName[]" class="input-theme supplier-select" required>${buildSupplierOptions()}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Currency Type</label>
                        <select name="currencyType[]" class="input-theme">${buildCurrencyOptions()}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Price in Value</label>
                        <input type="number" min="0" step="any" autocomplete="off" name="priceInValue[]" class="input-theme" placeholder="Enter Price" />
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Is This a Critical Item? <strong class="text-rose-500">*</strong></label>
                        <select name="isThisCritical[]" class="input-theme" required>${buildCriticalOptions('')}</select>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-slate-800">Expected Date of Delivery</label>
                        <input type="date" autocomplete="off" name="dateOfDelivery[]" class="input-theme" />
                    </div>
                    <div class="flex items-end">
                        <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center rounded-full bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove product">
                            <span class="ti ti-trash text-base"></span>
                        </button>
                    </div>
                </div>
            </div>`;
        $('#mrProductsWrapper').append(productRow);
        
        $(`.product-row[data-index="${productIndex}"] .select2-unit`).select2({
            placeholder: '----Select Option----',
            width: '100%',
            dropdownParent: $('#addLowStockModal'),
            dropdownCssClass: 'select2-small-dropdown'
        });

        productIndex++;
        updateItemNumbers();
    }

    function openProcurementCreateMode(productIds, attempt = 0) {
        if (!productIds || productIds.length === 0) {
            return;
        }
        if (qtyUnitOptions.length === 0 && attempt < 20) {
            setTimeout(function () {
                openProcurementCreateMode(productIds, attempt + 1);
            }, 150);
            return;
        }
        $('#addLowStocksForm')[0].reset();
        $('#reportingPerson').val(DEFAULT_REPORTING_PERSON);
        $('#dateOfReport').val(TODAY_DATE);
        $('#mrProductsWrapper').html('<div class="rounded-xl border border-slate-200 bg-white p-4 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></div>');
        productIndex = 1;
        $('#addLowStockModal').modal('show');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                fetchProcurementPrefillProducts: 'fetchProcurementPrefillProducts',
                productIds: productIds,
                procurementSource: PROCUREMENT_SOURCE
            },
            success: function (response) {
                $('#mrProductsWrapper').empty();
                if (response.status === 'success' && response.items && response.items.length > 0) {
                    response.items.forEach(function (item) {
                        appendProcurementProductRow(item);
                    });
                    updateItemNumbers();
                } else {
                    toastr.error(response.message || 'No products available.');
                }
            },
            error: function () {
                $('#mrProductsWrapper').empty();
                toastr.error('Server error occurred.');
            }
        });
        if (window.history && window.history.replaceState) {
            window.history.replaceState({}, document.title, 'index.php?page=purchase-management');
        }
    }
    $(document).ready(function () {
        const shouldOpenInboundRequests = new URLSearchParams(window.location.search).get('open_inbound') === '1';
        $(".status-filter").prop("checked", true);
        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });
        loadLowStockRequestTable();
        loadStandardUnit();

        $(document).on('select2:open', function (e) {
            setTimeout(function() {
                const select = e.target;
                const $container = $(select).next('.select2-container');
                if ($container.length === 0) return;
                
                const $dropdown = $('.select2-dropdown:visible');
                if ($dropdown.length === 0) return;
                
                if ($dropdown.hasClass('select2-dropdown--below')) {
                    const containerOffset = $container.offset();
                    const containerHeight = $container.outerHeight();
                    const dropdownHeight = $dropdown.outerHeight();
                    const windowScrollTop = $(window).scrollTop();
                    const viewportHeight = $(window).height();
                    
                    const distanceToBottom = viewportHeight - (containerOffset.top + containerHeight - windowScrollTop);
                    const distanceToTop = containerOffset.top - windowScrollTop;
                    
                    if (distanceToBottom < dropdownHeight + 20 && distanceToTop > distanceToBottom) {
                        $dropdown.removeClass('select2-dropdown--below').addClass('select2-dropdown--above');
                        const $dropdownContainer = $dropdown.parent();
                        $dropdownContainer.css({
                            top: containerOffset.top - dropdownHeight
                        });
                    }
                }
            }, 50);
        });

        // Keep purchase-order dropdowns positioned inside their owning modal.
        $('#vendorNameRaw').select2({
            dropdownParent: $('#addPurchaseOrderRawModal'),
            width: '100%'
        });

        $('#vendorName').select2({
            dropdownParent: $('#addPurchaseOrderModal'),
            width: '100%'
        });

        $('#materialTypeSelect').select2({
            placeholder: '----Select Option----',
            dropdownParent: $('#addRmPmSelectionModal')
        });

        window.procureProductIds = null;
        if (PROCUREMENT_PRODUCT_IDS && PROCUREMENT_PRODUCT_IDS.length > 0) {
            window.procureProductIds = PROCUREMENT_PRODUCT_IDS;
            $('#materialTypeSelect').val('').trigger('change');
            $('#addRmPmSelectionModal').modal('show');
            if (window.history && window.history.replaceState) {
                window.history.replaceState({}, document.title, 'index.php?page=purchase-management');
            }
        }

        if (shouldOpenInboundRequests) {
            $('#inboundPurchaseRequestsModal').modal('show');
            if (window.history && window.history.replaceState) {
                window.history.replaceState({}, document.title, 'index.php?page=purchase-management');
            }
        }

        $('#searchUsers').on('input', function () {
            loadLowStockRequestTable(1);
        });

        $(document).on('change', '.status-filter', function () {
            const val = $(this).val();
            const checked = $(this).is(':checked');

            if (val === 'all') {
                $('.status-filter').prop('checked', checked);
            } else {
                const otherCheckboxes = $('.status-filter:not([value="all"])');
                const allOthersChecked = otherCheckboxes.length === $('.status-filter:not([value="all"]):checked').length;
                $('.status-filter[value="all"]').prop('checked', allOthersChecked);
            }

            selectedStatusFilters = [];
            $('.status-filter:checked').each(function () {
                if ($(this).val() !== 'all') {
                    selectedStatusFilters.push($(this).val());
                }
            });

            loadLowStockRequestTable(1);
        });

        $('#perPageSelect').on('change', function () {
            loadLowStockRequestTable(1);
        });

        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadLowStockRequestTable(1);
        });

        $(document).on('click', '.pm-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#pmPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        window.selectedLowStockId = null;

        function resetProcurementOrderContexts() {
            $('#procurementOrderContextRM, #procurementOrderContextPM').addClass('hidden');
            $('#procurementOrderReferenceRM, #procurementOrderReferencePM, #procurementCategoryRM, #procurementCategoryPM').val('');
            window.eprSelectedProducts = null;
        }

        function applyProcurementOrderContext(type, item) {
            const suffix = type === 'RM' ? 'RM' : 'PM';
            const hasOrder = Number(item.order_id || 0) > 0;
            $('#procurementOrderContext' + suffix).toggleClass('hidden', !hasOrder);
            $('#procurementOrderReference' + suffix).val(item.order_number || '');
            $('#procurementCategory' + suffix).val(item.categname || '');
        }

        function eprSetDateValue(selector, dateVal) {
            const $el = $(selector);
            if ($el[0] && $el[0]._flatpickr) {
                $el[0]._flatpickr.setDate(dateVal || '');
            } else {
                $el.val(dateVal || '');
            }
        }

        function openNewPurchaseRequestForm() {
            window.selectedLowStockId = null;
            window.procureProductIds = null;
            resetProcurementOrderContexts();

            // Reset edit modal state to blank/default (no prefilled values)
            const todayStr = new Date().toISOString().split('T')[0];
            $('#eprReporterName').val(DEFAULT_REPORTING_PERSON);
            eprSetDateValue('#eprDateOfReport', todayStr);
            $('#eprProductsWrapper').empty();
            
            // Starts with a single empty product detail row
            eprAppendProductRow('', '', '');

            $('#eprVendorName').val('').trigger('change');
            $('input[name="eprCriticalPriority"]').prop('checked', false);
            eprUpdateRadioDots();
            eprSetDateValue('#eprExpectedDelivery', '');

            $('#editPurchaseRequestModal').modal('show');
        }

        function openNewPurchaseOrderModal() {
            window.selectedLowStockId = null;
            window.procureProductIds = null;
            window.eprSelectedProducts = null;
            if (typeof resetProcurementOrderContexts === 'function') {
                resetProcurementOrderContexts();
            }
            $('#materialTypeSelect').val('').trigger('change');
            $('#addRmPmSelectionModal').modal('show');
        }

        $('#addLowStockModalBtn').on('click', function () {
            openNewPurchaseOrderModal();
        });

        $(document).on('click', '#addPurchaseOrderMenuBtn', function () {
            openNewPurchaseOrderModal();
        });

        window.eprIsLoading = false;
        function openProcurementTypeSelection(id, $btn = null) {
            if (window.eprIsLoading) {
                return;
            }
            if (!id) {
                toastr.error('Invalid procurement request.');
                return;
            }
            window.eprIsLoading = true;
            window.selectedLowStockId = id;
            resetProcurementOrderContexts();

            // Reset edit modal state
            $('#eprReporterName').val('');
            eprSetDateValue('#eprDateOfReport', '');
            $('#eprProductsWrapper').empty();
            $('#eprVendorName').val('').trigger('change');
            $('input[name="eprCriticalPriority"]').prop('checked', false);
            eprUpdateRadioDots();
            eprSetDateValue('#eprExpectedDelivery', '');

            if ($btn) {
                $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i>');
            }

            // AJAX prefill
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    fetchLowStockRequestById: 'fetchLowStockRequestById',
                    id: id
                },
                success: function (response) {
                    window.eprIsLoading = false;
                    if ($btn) {
                        $btn.prop('disabled', false).html('<i class="ti ti-check text-base"></i>');
                    }
                    if (response.status === 'success' && response.data) {
                        const item = response.data;

                        // Close inbound list instantly to avoid double-animation overlap/flicker
                        const $inboundModal = $('#inboundPurchaseRequestsModal');
                        $inboundModal.removeClass('fade animate__animated fadeIn');
                        $inboundModal.modal('hide');
                        setTimeout(function () {
                            $inboundModal.addClass('fade animate__animated fadeIn');
                        }, 300);

                        // Pre-populate with current user and today's date (which user can change)
                        const todayStr = new Date().toISOString().split('T')[0];
                        $('#eprReporterName').val(DEFAULT_REPORTING_PERSON);
                        eprSetDateValue('#eprDateOfReport', todayStr);

                        // Store original values for DB updates
                        window.eprOriginalCategoryId = item.category_id || 0;
                        window.eprOriginalProductId = item.product_id || 0;
                        window.eprOriginalCoaNumber = item.coa_number || '';

                        // Clear and append product row (pre-filled from existing record)
                        $('#eprProductsWrapper').empty();
                        eprAppendProductRow(item.product_name || '', item.required_qty || '', item.required_qty_unit || '');

                        // Vendor
                        const vendorVal = item.vendor_name || '';
                        setSupplierSelectValue('#eprVendorName', vendorVal);

                        // Critical Priority radio
                        const critVal = String(item.critical_item || '');
                        $(`input[name="eprCriticalPriority"][value="${critVal}"]`).prop('checked', true);
                        eprUpdateRadioDots();

                        // Expected delivery
                        eprSetDateValue('#eprExpectedDelivery', item.expected_delivery_date || '');

                        // Bypass intermediate Edit PR modal and proceed directly to PO creation
                        window.eprSelectedProducts = [{
                            productName: item.product_name || '',
                            qty: item.required_qty || '',
                            unitId: item.required_qty_unit || '',
                            lowStockId: item.id || id
                        }];
                        window.selectedLowStockId = item.id || id;

                        const inventoryTypeMap = { '1': 'FG', '2': 'PM', '3': 'RM', '4': 'CONSUMABLE' };
                        const targetMatType = inventoryTypeMap[String(item.inventory_group)] || '';

                        if (targetMatType) {
                            $('#materialTypeSelect').val(targetMatType);
                            $('#btnNextRmPm').trigger('click');
                        } else {
                            $('#materialTypeSelect').val('').trigger('change');
                            $('#addRmPmSelectionModal').modal('show');
                        }
                    } else {
                        toastr.error(response.message || 'Error fetching purchase request details.');
                    }
                },
                error: function (xhr, status, error) {
                    window.eprIsLoading = false;
                    if ($btn) {
                        $btn.prop('disabled', false).html('<i class="ti ti-check text-base"></i>');
                    }
                    let msg = 'Error fetching request details.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    } else if (xhr.responseText) {
                        try {
                            const parsed = JSON.parse(xhr.responseText);
                            if (parsed.message) msg = parsed.message;
                        } catch (e) {
                            msg += ' ' + (error || status || 'Server error occurred.');
                        }
                    }
                    toastr.error(msg);
                }
            });
        }

        // ── Helpers for edit modal product rows ──────────────────────────────

        let eprProductIndex = 0;

        function eprAppendProductRow(productName, qty, unitId, lowStockId = null) {
            const idx = eprProductIndex++;
            const productNameOpts = buildMaterialOptions(productName);
            const unitOpts = buildUnitOptions(unitId);
            const row = `
                <div class="epr-product-row rounded-xl border border-slate-200 bg-white p-3 shadow-sm" data-epr-index="${idx}" data-epr-low-stock-id="${lowStockId || ''}">
                    <div class="grid grid-cols-12 gap-2 items-end">
                        <div class="col-span-6">
                            <label class="mb-1 block text-xs font-semibold text-slate-600">Product Name</label>
                            <select class="input-theme select2 epr-product-name-select" style="width:100%;">${productNameOpts}</select>
                        </div>
                        <div class="col-span-3">
                            <label class="mb-1 block text-xs font-semibold text-slate-600">Quantity</label>
                            <input type="number" min="0" step="any" class="input-theme epr-qty-input" value="${escapeHtml(String(qty))}" placeholder="Qty" />
                        </div>
                        <div class="col-span-2">
                            <label class="mb-1 block text-xs font-semibold text-slate-600">Unit</label>
                            <select class="input-theme epr-unit-select select2">${unitOpts}</select>
                        </div>
                        <div class="col-span-1 flex items-end justify-center pb-0.5">
                            <button type="button" class="epr-remove-row inline-flex h-9 w-9 items-center justify-center rounded-full bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none" title="Remove">
                                <span class="ti ti-trash text-sm"></span>
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#eprProductsWrapper').append(row);
            // Init Select2 on the new product name dropdown
            $(`[data-epr-index="${idx}"] .epr-product-name-select`).select2({
                placeholder: '----Select Product or Type Item Name----',
                tags: true,
                dropdownParent: $('#editPurchaseRequestModal'),
                width: '100%'
            });
            // Init Select2 on the new unit dropdown
            $(`[data-epr-index="${idx}"] .epr-unit-select`).select2({
                placeholder: 'Unit',
                dropdownParent: $('#editPurchaseRequestModal'),
                width: '100%',
                dropdownCssClass: 'select2-small-dropdown'
            });
        }

        function eprUpdateRadioDots() {
            $('#eprCriticalPriorityGroup .epr-radio-label').each(function () {
                const checked = $(this).find('input[type="radio"]').is(':checked');
                const badge = $(this).data('badge') || '';
                const $dot = $(this).find('.epr-radio-dot');
                $dot.removeClass('bg-slate-400 bg-red-500 bg-emerald-500 bg-blue-500 bg-amber-500 bg-slate-500');
                
                if (checked) {
                    $(this).addClass('bg-white text-slate-800 shadow-sm').removeClass('text-slate-500');
                    if (badge.includes('danger')) $dot.addClass('bg-red-500');
                    else if (badge.includes('success')) $dot.addClass('bg-emerald-500');
                    else if (badge.includes('info')) $dot.addClass('bg-blue-500');
                    else if (badge.includes('warning')) $dot.addClass('bg-amber-500');
                    else $dot.addClass('bg-slate-500');
                } else {
                    $(this).removeClass('bg-white text-slate-800 shadow-sm').addClass('text-slate-500');
                    $dot.addClass('bg-slate-400');
                }
            });
        }

        // ── Event Handlers ───────────────────────────────────────────────────

        // Add another product row inside edit modal
        $('#eprAddProductBtn').on('click', function () {
            eprAppendProductRow('', '', '');
        });

        // Remove product row
        $(document).on('click', '.epr-remove-row', function () {
            const $wrapper = $('#eprProductsWrapper');
            if ($wrapper.find('.epr-product-row').length <= 1) {
                toastr.warning('At least one product is required.');
                return;
            }
            $(this).closest('.epr-product-row').remove();
        });

        // Radio button visual update
        $(document).on('change', 'input[name="eprCriticalPriority"]', function () {
            eprUpdateRadioDots();
        });

        // Init vendor Select2 for edit modal
        $('#eprVendorName').select2({
            placeholder: '----Select Vendor----',
            dropdownParent: $('#editPurchaseRequestModal'),
            width: '100%'
        });

        // ── Generate PO button ───────────────────────────────────────────────

        $('#eprGeneratePOBtn').on('click', function () {
            // Collect all products
            window.eprSelectedProducts = [];
            let isValid = true;

            const lowStockIds = [];
            const productNames = [];
            const quantities = [];
            const unitIds = [];

            $('#eprProductsWrapper .epr-product-row').each(function () {
                const pName = $(this).find('.epr-product-name-select').val();
                const pQty = $(this).find('.epr-qty-input').val();
                const pUnit = $(this).find('.epr-unit-select').val();
                const lowStockId = $(this).attr('data-epr-low-stock-id') || '0';

                if (!pName) {
                    toastr.error('Please select a product name for all rows.');
                    isValid = false;
                    return false;
                }
                if (!pQty || parseFloat(pQty) <= 0) {
                    toastr.error('Please enter a valid quantity for all products.');
                    isValid = false;
                    return false;
                }

                window.eprSelectedProducts.push({
                    productName: pName,
                    qty: pQty,
                    unitId: pUnit,
                    lowStockId: lowStockId
                });

                lowStockIds.push(lowStockId);
                productNames.push(pName);
                quantities.push(pQty);
                unitIds.push(pUnit);
            });

            if (!isValid) {
                return;
            }

            const vendorName = $('#eprVendorName').val() || '';
            const criticalItem = $('input[name="eprCriticalPriority"]:checked').val() || '';
            const expectedDelivery = $('#eprExpectedDelivery').val() || '';
            const reportingPerson = $('#eprReporterName').val() || '';
            const dateOfReport = $('#eprDateOfReport').val() || '';

            const $btn = $(this);
            $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span> Saving...');

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    saveBulkPurchaseRequests: 'saveBulkPurchaseRequests',
                    reportingPerson: reportingPerson,
                    dateOfReport: dateOfReport,
                    vendorName: vendorName,
                    criticalItem: criticalItem,
                    expectedDelivery: expectedDelivery,
                    lowStockIds: lowStockIds,
                    productNames: productNames,
                    quantities: quantities,
                    unitIds: unitIds
                },
                success: function (response) {
                    $btn.prop('disabled', false).html('Generate PO <i class="ti ti-arrow-right text-base"></i>');
                    if (response.status === 'success') {
                        if (response.ids && response.ids.length > 0) {
                            // Map returned database IDs back into our products context
                            response.ids.forEach(function (dbId, idx) {
                                if (window.eprSelectedProducts[idx]) {
                                    window.eprSelectedProducts[idx].lowStockId = dbId;
                                }
                            });
                            window.selectedLowStockId = response.ids[0]; // fallback for single-id logic
                        }
                        $('#editPurchaseRequestModal').modal('hide');
                        // Do NOT call resetProcurementOrderContexts here because we want to preserve window.eprSelectedProducts and window.selectedLowStockId for the subsequent PO screens!
                        $('#materialTypeSelect').val('').trigger('change');
                        setTimeout(function () {
                            $('#addRmPmSelectionModal').modal('show');
                        }, 200);
                        loadLowStockRequestTable();
                    } else {
                        toastr.error(response.message || 'Failed to process request.');
                    }
                },
                error: function () {
                    $btn.prop('disabled', false).html('Generate PO <i class="ti ti-arrow-right text-base"></i>');
                    toastr.error('Server error. Please try again.');
                }
            });
        });

        $(document).on('click', '.initiateProcurementBtn', function () {
            openProcurementTypeSelection($(this).data('id'), $(this));
        });

        $(document).on('click keydown', '.inboundPurchaseRequestRow', function (event) {
            if ($(event.target).closest('button, a, input[type="checkbox"], .pending-request-select-cell').length) {
                return;
            }
            if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') {
                return;
            }
            event.preventDefault();
            const $btn = $(this).find('.initiateProcurementBtn');
            openProcurementTypeSelection($(this).data('id'), $btn);
        });

        function updatePendingSelectionUI() {
            const totalCheckboxes = $('.selectPendingRequestRow').length;
            const checkedCheckboxes = $('.selectPendingRequestRow:checked').length;
            
            $('#selectedPendingCountText').text(checkedCheckboxes + ' items selected');
            $('#generateBulkPOBtn').prop('disabled', checkedCheckboxes === 0);
            
            const allChecked = totalCheckboxes > 0 && checkedCheckboxes === totalCheckboxes;
            $('#selectAllPendingRequests').prop('checked', allChecked);
        }

        // Handle Row Checkbox Click
        $(document).on('click', '.pending-request-select-cell', function (event) {
            event.stopPropagation();
            if ($(event.target).is('.selectPendingRequestRow')) {
                return;
            }

            const $checkbox = $(this).find('.selectPendingRequestRow');
            $checkbox.prop('checked', !$checkbox.prop('checked')).trigger('change');
        });

        $(document).on('change', '.selectPendingRequestRow', function () {
            updatePendingSelectionUI();
        });

        // Handle Select All Checkbox Click
        $(document).on('change', '#selectAllPendingRequests', function () {
            const isChecked = $(this).is(':checked');
            $('.selectPendingRequestRow').prop('checked', isChecked);
            updatePendingSelectionUI();
        });

        // Reset Selection UI when modal is loaded or closed
        $('#inboundPurchaseRequestsModal').on('show.bs.modal', function () {
            $('#selectAllPendingRequests').prop('checked', false);
            $('#selectedPendingCountText').text('0 items selected');
            $('#generateBulkPOBtn').prop('disabled', true);
        });

        // Handle Bulk PO Generation Button Click
        $(document).on('click', '#generateBulkPOBtn', function () {
            const ids = [];
            $('.selectPendingRequestRow:checked').each(function () {
                ids.push($(this).data('id'));
            });
            if (ids.length === 0) {
                toastr.error('Please select at least one purchase request.');
                return;
            }
            openBulkProcurementSelection(ids, $(this));
        });

        function openBulkProcurementSelection(ids, $btn = null) {
            if (!ids || ids.length === 0) {
                toastr.error('No procurement requests selected.');
                return;
            }
            if (window.eprIsLoading) {
                return;
            }
            window.eprIsLoading = true;
            window.selectedLowStockId = ids[0]; // fallback for single request logic
            resetProcurementOrderContexts();

            // Reset edit modal state
            $('#eprReporterName').val('');
            eprSetDateValue('#eprDateOfReport', '');
            $('#eprProductsWrapper').empty();
            $('#eprVendorName').val('').trigger('change');
            $('input[name="eprCriticalPriority"]').prop('checked', false);
            eprUpdateRadioDots();
            eprSetDateValue('#eprExpectedDelivery', '');

            let oldHtml = '';
            if ($btn) {
                oldHtml = $btn.html();
                $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-sm"></i> Loading...');
            }

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    fetchMultipleLowStockRequestsByIds: 'fetchMultipleLowStockRequestsByIds',
                    ids: ids
                },
                success: function (response) {
                    window.eprIsLoading = false;
                    if ($btn) {
                        $btn.prop('disabled', false).html(oldHtml);
                    }
                    if (response.status === 'success' && response.data && response.data.length > 0) {
                        const list = response.data;

                        // Close inbound list instantly
                        const $inboundModal = $('#inboundPurchaseRequestsModal');
                        $inboundModal.removeClass('fade animate__animated fadeIn');
                        $inboundModal.modal('hide');
                        setTimeout(function () {
                            $inboundModal.addClass('fade animate__animated fadeIn');
                        }, 300);

                        // Pre-populate with current user and today's date
                        const todayStr = new Date().toISOString().split('T')[0];
                        $('#eprReporterName').val(DEFAULT_REPORTING_PERSON);
                        eprSetDateValue('#eprDateOfReport', todayStr);

                        // Clear and populate product rows
                        $('#eprProductsWrapper').empty();
                        
                        let highestCriticality = 0;
                        let commonVendor = null;
                        let isFirstVendor = true;
                        let commonDelivery = null;
                        let isFirstDelivery = true;

                        list.forEach(function (item) {
                            eprAppendProductRow(item.product_name || '', item.required_qty || '', item.required_qty_unit || '', item.id);
                            
                            // Check highest criticality (1 = Critical, 2 = Medium, 3 = Low/Routine)
                            const crit = Number(item.critical_item || 0);
                            if (highestCriticality === 0 || (crit > 0 && crit < highestCriticality)) {
                                highestCriticality = crit;
                            }

                            // Check common vendor
                            const vendor = item.vendor_name || '';
                            if (isFirstVendor) {
                                commonVendor = vendor;
                                isFirstVendor = false;
                            } else if (commonVendor !== vendor) {
                                commonVendor = null; // different vendors
                            }

                            // Check common delivery date
                            const deliv = item.expected_delivery_date || '';
                            if (isFirstDelivery) {
                                commonDelivery = deliv;
                                isFirstDelivery = false;
                            } else if (commonDelivery !== deliv) {
                                commonDelivery = null; // different dates
                            }
                        });

                        // Prefill vendor if they all match
                        if (commonVendor) {
                            setSupplierSelectValue('#eprVendorName', commonVendor);
                        } else {
                            $('#eprVendorName').val('').trigger('change');
                        }

                        // Prefill priority
                        const finalCrit = highestCriticality > 0 ? String(highestCriticality) : '3';
                        $(`input[name="eprCriticalPriority"][value="${finalCrit}"]`).prop('checked', true);
                        eprUpdateRadioDots();

                        // Prefill expected delivery date if matches
                        eprSetDateValue('#eprExpectedDelivery', commonDelivery || '');

                        // Store first item's details as default context fallbacks
                        window.eprOriginalCategoryId = list[0].category_id || 0;
                        window.eprOriginalProductId = list[0].product_id || 0;
                        window.eprOriginalCoaNumber = list[0].coa_number || '';

                        // Bypass intermediate Edit PR modal and proceed directly to PO creation (PDF requirement 5.1)
                        window.eprSelectedProducts = list.map(item => ({
                            productName: item.product_name || '',
                            qty: item.required_qty || '',
                            unitId: item.required_qty_unit || '',
                            lowStockId: item.id
                        }));
                        window.selectedLowStockId = list[0].id;
                        window.bulkLowStockIds = ids;

                        const inventoryTypeMap = { '1': 'FG', '2': 'PM', '3': 'RM', '4': 'CONSUMABLE' };
                        const selectedTypes = [...new Set(list.map(item => inventoryTypeMap[String(item.inventory_group)] || ''))];
                        const targetMatType = selectedTypes.length === 1 ? selectedTypes[0] : '';

                        if (selectedTypes.length > 1) {
                            toastr.error('Selected requests belong to different inventory groups. Create a separate PO for each group.');
                            return;
                        }

                        if (targetMatType) {
                            $('#materialTypeSelect').val(targetMatType);
                            $('#btnNextRmPm').trigger('click');
                        } else {
                            $('#materialTypeSelect').val('').trigger('change');
                            $('#addRmPmSelectionModal').modal('show');
                        }
                    } else {
                        toastr.error(response.message || 'Error fetching purchase request details.');
                    }
                },
                error: function (xhr, status, error) {
                    window.eprIsLoading = false;
                    if ($btn) {
                        $btn.prop('disabled', false).html(oldHtml);
                    }
                    let msg = 'Error fetching request details.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    } else if (xhr.responseText) {
                        try {
                            const parsed = JSON.parse(xhr.responseText);
                            if (parsed.message) msg = parsed.message;
                        } catch (e) {
                            msg += ' ' + (error || status || 'Server error occurred.');
                        }
                    }
                    toastr.error(msg);
                }
            });
        }

        $('#btnNextRmPm').on('click', function () {
            const matType = $('#materialTypeSelect').val();
            if (!matType) {
                toastr.error('Please select a material type.');
                return;
            }
            $('#addRmPmSelectionModal').modal('hide');

            const prefillId = window.selectedLowStockId;
            const procureProductIds = window.procureProductIds;

            if (matType === 'RM') {
                $('#productsList').html('');
                productIndexPor = 0;

                if (prefillId) {
                    $.ajax({
                        url: 'ajax.php',
                        method: 'POST',
                        dataType: 'json',
                        data: {
                            fetchLowStockRequestById: 'fetchLowStockRequestById',
                            id: prefillId
                        },
                        success: function (response) {
                            if (response.status === 'success' && response.data) {
                                const item = response.data;
                                setSupplierSelectValue('#vendorNameRaw', item.vendor_name || '');
                                applyProcurementOrderContext('RM', item);
                                $('#quantityRequiredUnitRM').val(String(item.required_qty_unit || '')).trigger('change');
                                $('#criticalItemRM').val(String(item.critical_item || '')).trigger('change');
                                $('#expectedDeliveryDateRM').val(item.expected_delivery_date || '');
                                $('#extraNoteRaw').val(item.order_number ? 'Originating Order: ' + item.order_number : '');

                                if (window.eprSelectedProducts && window.eprSelectedProducts.length > 0) {
                                    window.eprSelectedProducts.forEach(function (p, index) {
                                        const productName = escapeHtml(p.productName || '');
                                        const requiredQty = escapeHtml(String(p.qty || ''));
                                        const lowStockIdVal = p.lowStockId || '';

                                        const productRow = `
                                        <tr class="po-doc-row" data-index="${productIndexPor}">
                                            <td class="po-doc-td">
                                                <input type="hidden" name="poLowStockId[]" value="${lowStockIdVal}" />
                                                <select name="productName[]" class="input-theme select2" required>${buildMaterialOptions(productName)}</select>
                                            </td>
                                            <td class="po-doc-td">
                                                <input type="text" name="size[]" class="input-theme" value="" placeholder="Size (e.g., 10x20)" />
                                            </td>
                                            <td class="po-doc-td">
                                                <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness (mm)" />
                                            </td>
                                            <td class="po-doc-td">
                                                <input type="text" name="quantity[]" class="input-theme" value="${requiredQty}" placeholder="Quantity" required />
                                            </td>
                                            <td class="po-doc-td">
                                                <input type="text" name="poPrice[]" class="input-theme" placeholder="Price" />
                                            </td>
                                            <td class="po-doc-td text-center">
                                                <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" title="Remove product">
                                                    <span class="ti ti-trash text-base"></span>
                                                </button>
                                            </td>
                                        </tr>
                                        `;
                                        $('#productsList').append(productRow);
                                        $(`.po-doc-row[data-index="${productIndexPor}"] .select2`).select2({
                                            width: '100%',
                                            dropdownParent: $('#addPurchaseOrderRawModal')
                                        });
                                        productIndexPor++;
                                    });
                                } else {
                                    const productName = escapeHtml(item.product_name || '');
                                    const requiredQty = escapeHtml(item.required_qty || '');

                                    const productRow = `
                                    <tr class="po-doc-row" data-index="${productIndexPor}">
                                        <td class="po-doc-td">
                                            <input type="hidden" name="poLowStockId[]" value="${item.id}" />
                                            <select name="productName[]" class="input-theme select2" required>${buildMaterialOptions(productName)}</select>
                                        </td>
                                        <td class="po-doc-td">
                                            <input type="text" name="size[]" class="input-theme" value="" placeholder="Size (e.g., 10x20)" />
                                        </td>
                                        <td class="po-doc-td">
                                            <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness (mm)" />
                                        </td>
                                        <td class="po-doc-td">
                                            <input type="text" name="quantity[]" class="input-theme" value="${requiredQty}" placeholder="Quantity" required />
                                        </td>
                                        <td class="po-doc-td">
                                            <input type="text" name="poPrice[]" class="input-theme" placeholder="Price" />
                                        </td>
                                        <td class="po-doc-td text-center">
                                            <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" title="Remove product">
                                                <span class="ti ti-trash text-base"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    `;
                                    $('#productsList').append(productRow);
                                    $(`.po-doc-row[data-index="${productIndexPor}"] .select2`).select2({
                                        width: '100%',
                                        dropdownParent: $('#addPurchaseOrderRawModal')
                                    });
                                    productIndexPor++;
                                }
                                $('#addPurchaseOrderRawModal').modal('show');
                            } else {
                                toastr.error(response.message || 'Error fetching prefill data.');
                            }
                        },
                        error: function (xhr, status, error) {
                            let msg = 'Error fetching prefill data.';
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                msg = xhr.responseJSON.message;
                            } else if (xhr.responseText) {
                                try {
                                    const parsed = JSON.parse(xhr.responseText);
                                    if (parsed.message) msg = parsed.message;
                                } catch (e) {
                                    msg += ' ' + (error || status || 'Server error');
                                }
                            }
                            toastr.error(msg);
                        }
                    });
                } else if (procureProductIds && procureProductIds.length > 0) {
                    $.ajax({
                        url: 'ajax.php',
                        method: 'POST',
                        dataType: 'json',
                        data: {
                            fetchProductsDetailsForPO: 'fetchProductsDetailsForPO',
                            ids: procureProductIds.join(',')
                        },
                        success: function (response) {
                            if (response.status === 'success' && response.data && response.data.length > 0) {
                                response.data.forEach(function (item) {
                                    const productRow = `
                                    <div class="product-row mb-2 rounded-xl border border-slate-200 bg-white p-2 shadow-sm" data-index="${productIndexPor}">
                                        <input type="hidden" name="poLowStockId[]" value="" />
                                        <div class="grid grid-cols-1 gap-2 md:grid-cols-12 items-center">                    
                                            <div class="md:col-span-3">
                                                <input type="text" name="productName[]" class="input-theme" value="${item.product_name || ''}" placeholder="Product Name" required />
                                            </div>
                                            <div class="md:col-span-2">
                                                <input type="text" name="catNo[]" class="input-theme" value="${item.product_code || ''}" placeholder="Cat No" />
                                            </div>
                                            <div class="md:col-span-2">
                                                <input type="text" name="size[]" class="input-theme" placeholder="Size" />
                                            </div>
                                            <div class="md:col-span-2">
                                                <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness" />
                                            </div>
                                            <div class="md:col-span-2">
                                                <input type="text" name="quantity[]" class="input-theme" placeholder="Quantity" required />
                                            </div>
                                            <div class="md:col-span-1 text-center">
                                                <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" title="Remove product">
                                                     <span class="ti ti-trash text-base"></span>
                                                </button>
                                            </div>                    
                                        </div>
                                    </div>
                                    `;
                                    $('#productsList').append(productRow);
                                    productIndexPor++;
                                });
                                $('#addPurchaseOrderRawModal').modal('show');
                            } else {
                                toastr.error(response.message || 'Error fetching prefill data.');
                            }
                        },
                        error: function (xhr, status, error) {
                            let msg = 'Error fetching prefill data.';
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                msg = xhr.responseJSON.message;
                            } else if (xhr.responseText) {
                                try {
                                    const parsed = JSON.parse(xhr.responseText);
                                    if (parsed.message) msg = parsed.message;
                                } catch (e) {
                                    msg += ' ' + (error || status || 'Server error');
                                }
                            }
                            toastr.error(msg);
                        }
                    });
                } else {
                    if ($('#addPurchaseOrderRawForm')[0]) {
                        const curPoNum = $('#poNumberRaw').val();
                        $('#addPurchaseOrderRawForm')[0].reset();
                        if (curPoNum) $('#poNumberRaw').val(curPoNum);
                    }
                    setSupplierSelectValue('#vendorNameRaw', '');
                    $('#quantityRequiredUnitRM').val('').trigger('change');
                    $('#criticalItemRM').val('').trigger('change');
                    $('#expectedDeliveryDateRM').val('');
                    $('#extraNoteRaw').val('');
                    if ($('#poCurrencyRaw').length) {
                        $('#poCurrencyRaw').val($('#poCurrencyRaw option:first').val() || '').trigger('change');
                    }
                    $('#productsList').html('');
                    productIndexPor = 0;
                    $('#addProductBtn').trigger('click');
                    setTimeout(function () {
                        $('#addPurchaseOrderRawModal').modal('show');
                    }, 200);
                }

            } else if (['PM', 'CONSUMABLE', 'FG'].includes(matType)) {
                $('#poTableBody').html('');

                if (prefillId) {
                    $.ajax({
                        url: 'ajax.php',
                        method: 'POST',
                        dataType: 'json',
                        data: {
                            fetchLowStockRequestById: 'fetchLowStockRequestById',
                            id: prefillId
                        },
                        success: function (response) {
                            if (response.status === 'success' && response.data) {
                                const item = response.data;
                                setSupplierSelectValue('#vendorName', item.vendor_name || '');
                                applyProcurementOrderContext('PM', item);
                                $('#quantityRequiredUnitPM').val(String(item.required_qty_unit || '')).trigger('change');
                                $('#purchaseOrderFormAdd [name="criticalItem"]').val(String(item.critical_item || '')).trigger('change');
                                $('#purchaseOrderFormAdd [name="expectedDeliveryDate"]').val(item.expected_delivery_date || '');
                                if (item.currency_type) {
                                    $('#poCurrency').val(item.currency_type).trigger('change');
                                }

                                if (window.eprSelectedProducts && window.eprSelectedProducts.length > 0) {
                                    window.eprSelectedProducts.forEach(function (p, index) {
                                        const productName = escapeHtml(p.productName || '');
                                        const requiredQty = escapeHtml(String(p.qty || ''));
                                        const lowStockIdVal = p.lowStockId || '';

                                        let newRow = `<tr>
                                            <td class="po-doc-td">
                                                <input type="hidden" name="poLowStockId[]" value="${lowStockIdVal}" />
                                                <select name="poMaterial[]" class="input-theme select2" required>${buildMaterialOptions(productName)}</select>
                                            </td>
                                            <td class="po-doc-td"><input type="text" name="poPackSize[]" class="input-theme" value="" placeholder="Pack Size" required /></td>
                                            <td class="po-doc-td"><input type="number" min="0" step="any" name="poQuantity[]" class="input-theme" value="${requiredQty}" placeholder="Quantity" required /></td>
                                            <td class="po-doc-td"><input type="text" name="poPrice[]" class="input-theme" value="" placeholder="Price" aria-label="Price" required /></td>
                                            <td class="po-doc-td">
                                            <button type="button" class="removeRow inline-flex h-9 w-9 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" title="Remove row"><span class="ti ti-trash text-base"></span></button>
                                            </td>
                                        </tr>`;
                                        $('#poTableBody').append(newRow);
                                        $('#poTableBody').find('tr:last .select2').select2({
                                            placeholder: '----Select Option----',
                                            width: '100%',
                                            dropdownParent: $('#addPurchaseOrderModal')
                                        });
                                    });
                                } else {
                                    const productName = escapeHtml(item.product_name || '');
                                    const requiredQty = escapeHtml(item.required_qty || '');
                                    const priceValue = escapeHtml(item.price_value || '');

                                    let newRow = `<tr>
                                        <td class="po-doc-td">
                                            <input type="hidden" name="poLowStockId[]" value="${item.id}" />
                                            <select name="poMaterial[]" class="input-theme select2" required>${buildMaterialOptions(productName)}</select>
                                        </td>
                                        <td class="po-doc-td"><input type="text" name="poPackSize[]" class="input-theme" value="" placeholder="Pack Size" required /></td>
                                        <td class="po-doc-td"><input type="number" min="0" step="any" name="poQuantity[]" class="input-theme" value="${requiredQty}" placeholder="Quantity" required /></td>
                                        <td class="po-doc-td"><input type="text" name="poPrice[]" class="input-theme" value="${priceValue}" placeholder="Price" aria-label="Price" required /></td>
                                        <td class="po-doc-td">
                                        <button type="button" class="removeRow inline-flex h-9 w-9 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" title="Remove row"><span class="ti ti-trash text-base"></span></button>
                                        </td>
                                    </tr>`;
                                    $('#poTableBody').append(newRow);
                                    $('#poTableBody').find('tr:last .select2').select2({
                                        placeholder: '----Select Option----',
                                        width: '100%',
                                        dropdownParent: $('#addPurchaseOrderModal')
                                    });
                                }
                                $('#addPurchaseOrderModal').modal('show');
                            } else {
                                toastr.error(response.message || 'Error fetching prefill data.');
                            }
                        },
                        error: function (xhr, status, error) {
                            let msg = 'Error fetching prefill data.';
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                msg = xhr.responseJSON.message;
                            } else if (xhr.responseText) {
                                try {
                                    const parsed = JSON.parse(xhr.responseText);
                                    if (parsed.message) msg = parsed.message;
                                } catch (e) {
                                    msg += ' ' + (error || status || 'Server error');
                                }
                            }
                            toastr.error(msg);
                        }
                    });
                } else if (procureProductIds && procureProductIds.length > 0) {
                    $.ajax({
                        url: 'ajax.php',
                        method: 'POST',
                        dataType: 'json',
                        data: {
                            fetchProductsDetailsForPO: 'fetchProductsDetailsForPO',
                            ids: procureProductIds.join(',')
                        },
                        success: function (response) {
                            if (response.status === 'success' && response.data && response.data.length > 0) {
                                response.data.forEach(function (item) {
                                    let newRow = `<tr>                
                                        <td class="po-doc-td">
                                            <input type="hidden" name="poLowStockId[]" value="" />
                                            <select name="poMaterial[]" class="input-theme select2" required>${buildMaterialOptions(item.product_name || '')}</select>
                                        </td>
                                        <td class="po-doc-td"><input type="text" name="poPackSize[]" class="input-theme" placeholder="Pack Size" required /></td>
                                        <td class="po-doc-td"><input type="number" min="0" step="any" name="poQuantity[]" class="input-theme" placeholder="Quantity" required /></td>
                                        <td class="po-doc-td"><input type="text"  name="poPrice[]" class="input-theme" placeholder="Price" required /></td>
                                        <td class="po-doc-td">
                                        <button type="button" class="removeRow inline-flex h-9 w-9 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" title="Remove row"><span class="ti ti-trash text-base"></span></button>
                                        </td>
                                    </tr>`;
                                    $('#poTableBody').append(newRow);
                                    $('#poTableBody').find('tr:last .select2').select2({
                                        placeholder: '----Select Option----',
                                        width: '100%',
                                        dropdownParent: $('#addPurchaseOrderModal')
                                    });
                                });
                                $('#addPurchaseOrderModal').modal('show');
                            } else {
                                toastr.error(response.message || 'Error fetching prefill data.');
                            }
                        },
                        error: function (xhr, status, error) {
                            let msg = 'Error fetching prefill data.';
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                msg = xhr.responseJSON.message;
                            } else if (xhr.responseText) {
                                try {
                                    const parsed = JSON.parse(xhr.responseText);
                                    if (parsed.message) msg = parsed.message;
                                } catch (e) {
                                    msg += ' ' + (error || status || 'Server error');
                                }
                            }
                            toastr.error(msg);
                        }
                    });
                } else {
                    if ($('#purchaseOrderFormAdd')[0]) {
                        const curPoNum = $('#poNumber').val();
                        $('#purchaseOrderFormAdd')[0].reset();
                        if (curPoNum) $('#poNumber').val(curPoNum);
                    }
                    setSupplierSelectValue('#vendorName', '');
                    $('#quantityRequiredUnitPM').val('').trigger('change');
                    $('#purchaseOrderFormAdd [name="criticalItem"]').val('').trigger('change');
                    $('#purchaseOrderFormAdd [name="expectedDeliveryDate"]').val('');
                    if ($('#poCurrency').length) {
                        $('#poCurrency').val('INR').trigger('change');
                    }
                    $('#poTableBody').html('');
                    $('#addRowBtn').trigger('click');
                    setTimeout(function () {
                        $('#addPurchaseOrderModal').modal('show');
                    }, 200);
                }
            }
        });

        // Add row dynamically in Raw PO form (RM)
        $('#addProductBtn').on('click', function (e, lowStockId = '') {
            const productRow = `
            <tr class="po-doc-row" data-index="${productIndexPor}">
                <td class="po-doc-td">
                    <input type="hidden" name="poLowStockId[]" value="${lowStockId}" />
                    <select name="productName[]" class="input-theme select2" required>${buildMaterialOptions()}</select>
                </td>
                <td class="po-doc-td">
                    <input type="text" name="size[]" class="input-theme" placeholder="Size (e.g., 10x20)" />
                </td>
                <td class="po-doc-td">
                    <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness (mm)" />
                </td>
                <td class="po-doc-td">
                    <input type="text" name="quantity[]" class="input-theme" placeholder="Quantity" required />
                </td>
                <td class="po-doc-td">
                    <input type="text" name="poPrice[]" class="input-theme" placeholder="Price" />
                </td>
                <td class="po-doc-td text-center">
                    <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove product">
                         <span class="ti ti-trash text-base"></span>
                    </button>
                </td>
            </tr>
            `;
            $('#productsList').append(productRow);
            $(`.po-doc-row[data-index="${productIndexPor}"] .select2`).select2({
                width: '100%',
                dropdownParent: $('#addPurchaseOrderRawModal')
            });
            productIndexPor++;
        });

        $('#productsList').on('click', '.removeProductBtn', function () {
            $(this).closest('tr').remove();
        });

        // Add row dynamically in Final PO form (PM)
        $('#addRowBtn').on('click', function (e, lowStockId = '') {
            let newRow = `<tr>                
                <td class="po-doc-td">
                    <input type="hidden" name="poLowStockId[]" value="${lowStockId}" />
                    <select name="poMaterial[]" class="input-theme select2" required>${buildMaterialOptions()}</select>
                </td>
                <td class="po-doc-td"><input type="text" name="poPackSize[]" class="input-theme" placeholder="Pack Size" aria-label="Pack size" required /></td>
                <td class="po-doc-td"><input type="number" min="0" step="any" name="poQuantity[]" class="input-theme" placeholder="Quantity" aria-label="Quantity required" required /></td>
                <td class="po-doc-td"><input type="text" name="poPrice[]" class="input-theme" placeholder="Price" aria-label="Price" required /></td>
                <td class="po-doc-td">
                <button type="button" class="removeRow inline-flex h-9 w-9 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none" title="Remove row"><span class="ti ti-trash text-base"></span></button>
                </td>
            </tr>`;
            $('#poTableBody').append(newRow);
            $('#poTableBody').find('tr:last .select2').select2({
                placeholder: '----Select Option----',
                width: '100%',
                dropdownParent: $('#addPurchaseOrderModal')
            });
        });

        $('#poTableBody').on('click', '.removeRow', function () {
            $(this).closest('tr').remove();
        });

        // Submit listener for Raw PO form (RM)
        $('#addPurchaseOrderRawForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addPurchaseOrderRawForm');
            const formData = new FormData(form);
            formData.append('addPurchaseOrderRaw', 'addPurchaseOrderRaw');

            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = typeof response === 'object' ? response : JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#addPurchaseOrderRawModal').modal('hide');
                        $('#addPurchaseOrderRawForm')[0].reset();
                        $('#productsList').html('');
                        toastr.success(res.message || 'Raw Purchase Order created successfully.');
                        loadLowStockRequestTable();
                    } else if (res.status === 'error') {
                        toastr.error(res.message || 'Failed to create Purchase Order.');
                    } else {
                        toastr.error('Unexpected response from server.');
                    }
                },
                error: function (xhr, status, error) {
                    let msg = 'Failed to create Raw Purchase Order.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    } else if (xhr.responseText) {
                        try {
                            const parsed = JSON.parse(xhr.responseText);
                            if (parsed.message) msg = parsed.message;
                        } catch (e) {
                            msg += ' ' + (error || status || 'Server error');
                        }
                    }
                    toastr.error(msg);
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });

        // Submit listener for Final PO form (PM)
        $('#purchaseOrderFormAdd').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('purchaseOrderFormAdd');
            const formData = new FormData(form);
            formData.append('addPurchaseOrderForm', 'addPurchaseOrderForm');

            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addPurchaseOrderModal').modal('hide');
                        $('#purchaseOrderFormAdd')[0].reset();
                        $('#poTableBody').html('');
                        toastr.success(response.message || 'Purchase order created successfully.');
                        loadLowStockRequestTable();
                    } else {
                        toastr.error(response.message || 'Failed to create purchase order.');
                    }
                },
                error: function (xhr, status, error) {
                    let msg = 'Failed to create purchase order.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    } else if (xhr.responseText) {
                        try {
                            const parsed = JSON.parse(xhr.responseText);
                            if (parsed.message) msg = parsed.message;
                        } catch (e) {
                            msg += ' ' + (error || status || 'Server error');
                        }
                    }
                    toastr.error(msg);
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });

        // Submit listener for Raw PO edit form
        $('#editPurchaseOrderRawForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('editPurchaseOrderRawForm');
            const formData = new FormData(form);
            formData.append('updatePurchaseOrderRawRecord', 'updatePurchaseOrderRawRecord');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editOrderReceivedModal').modal('hide');
                        $('#editPurchaseOrderRawForm').find('.modal-body').html('');
                        toastr.success(res.message);
                        loadLowStockRequestTable();
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        // Actions: Final PO PDF View
        $(document).on('click', '.previewTransferTicketPdf', function (e) {
            e.stopPropagation();
            let purchaseOrderNum = $(this).data('purchase-order-num');
            if (purchaseOrderNum) {
                $('#finalPurchaseOrderViewPdf').find('.modal-body').html('');
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        purchaseOrderFinalViewPdfRecord: 'purchaseOrderFinalViewPdfRecord',
                        purchaseOrderNum: purchaseOrderNum
                    },
                    success: function (response) {
                        let res;
                        try {
                            res = typeof response === 'object' ? response : JSON.parse(response);
                        } catch (e) {
                            toastr.error('Invalid response from server.');
                            return;
                        }

                        if (res.status === 'success') {
                            $('#finalPurchaseOrderViewPdfModal').modal('show');
                            $('#finalPurchaseOrderViewPdf').find('.modal-body').html(res.data);
                        } else if (res.status === 'error') {
                            toastr.error(res.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                    },
                    error: function () {
                        toastr.error('Server error occurred.');
                    }
                });
            }
        });

        // Actions: Final PO Delete
        $(document).on('click', '.deletePOPdf', function (e) {
            e.stopPropagation();
            let id = $(this).data('purchase-order-num');

            if (!id) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid ID',
                    text: 'Invalid PO number provided.',
                    customClass: {
                        confirmButton: 'btn btn-danger waves-effect waves-light'
                    }
                });
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deletePOPdfRecord: 'deletePOPdfRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                loadLowStockRequestTable();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        });

        // Actions: Raw PO PDF View
        $(document).on('click', '.viewPurchaseOrderRawModalBtn', function (e) {
            e.stopPropagation();
            let id = $(this).data('id');
            if (id) {
                $('#viewPurchaseOrderRaw').find('.modal-body').html('');
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        viewPurchaseOrderRawRecord: 'viewPurchaseOrderRawRecord',
                        id: id
                    },
                    success: function (response) {
                        let res;
                        try {
                            res = typeof response === 'object' ? response : JSON.parse(response);
                        } catch (e) {
                            toastr.error('Invalid response from server.');
                            return;
                        }

                        if (res.status === 'success') {
                            $('#viewPurchaseOrderRawModel').modal('show');
                            $('#viewPurchaseOrderRaw').find('.modal-body').html(res.data);
                        } else if (res.status === 'error') {
                            toastr.error(res.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                    },
                    error: function () {
                        toastr.error('Server error occurred.');
                    }
                });
            }
        });

        // Actions: Unified row click to open Edit Modal
        $(document).on('click', '.finalized-po-row', function (e) {
            // Do not trigger edit if they clicked on any action buttons or their icons/spans
            if ($(e.target).closest('button, a, span, i').length) {
                return;
            }

            let type = $(this).data('type');
            if (type === 'PM') {
                let poNum = $(this).data('po-num');
                if (poNum) {
                    $('#editPurchaseOrderFinalForm').find('.modal-body').html('');
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            fetchPurchaseOrderFinalRecord: 'fetchPurchaseOrderFinalRecord',
                            po_num: poNum
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                $('#editOrderReceivedModalPM').modal('show');
                                $('#editPurchaseOrderFinalForm').find('.modal-body').html(res.data);
                            } else if (res.status === 'error') {
                                toastr.error(res.message);
                            } else {
                                toastr.error('Unexpected response.');
                            }
                        },
                        error: function () {
                            toastr.error('Server error occurred.');
                        }
                    });
                }
            } else if (type === 'RM') {
                let id = $(this).data('po-id');
                if (id) {
                    $('#editPurchaseOrderRawForm').find('.modal-body').html('');
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            fetchPurchaseOrderRawRecord: 'fetchPurchaseOrderRawRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                $('#editOrderReceivedModal').modal('show');
                                $('#editPurchaseOrderRawForm').find('.modal-body').html(res.data);
                            } else if (res.status === 'error') {
                                toastr.error(res.message);
                            } else {
                                toastr.error('Unexpected response.');
                            }
                        },
                        error: function () {
                            toastr.error('Server error occurred.');
                        }
                    });
                }
            }
        });

        // Add product row in PM Edit modal
        $(document).on('click', '#addProductBtnEditPM', function () {
            const productRow = `
                <div class="product-row-pm mb-2 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
                    <input type="hidden" name="poFinalId[]" value="" />
                    <div class="grid grid-cols-1 gap-2 md:grid-cols-12 items-center">
                        <div class="md:col-span-4">
                            <label class="block text-xs font-semibold text-slate-500 uppercase mb-1">Material Name</label>
                            <select name="poMaterial[]" class="input-theme select2" required>${buildMaterialOptions()}</select>
                        </div>
                        <div class="md:col-span-3">
                            <label class="block text-xs font-semibold text-slate-500 uppercase mb-1">Pack Size</label>
                            <input type="text" name="poPackSize[]" class="input-theme" placeholder="Pack Size" required />
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-xs font-semibold text-slate-500 uppercase mb-1">Quantity</label>
                            <input type="number" step="any" name="poQuantity[]" class="input-theme" placeholder="Quantity" required />
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-xs font-semibold text-slate-500 uppercase mb-1">Price</label>
                            <input type="text" name="poPrice[]" class="input-theme" placeholder="Price" required />
                        </div>
                        <div class="md:col-span-1 text-center pt-4">
                            <button type="button" class="deleteSubProductFromPurchaseOrderFinal inline-flex h-9 w-9 items-center justify-center rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" data-id="">
                                <span class="ti ti-trash text-base"></span>
                            </button>
                        </div>
                    </div>
                </div>
                `;
            $('#productsListEditPM').append(productRow);
            if (typeof window.initGlobalSelect2 === 'function') window.initGlobalSelect2($('#productsListEditPM').find('.product-row-pm:last .select2'));
        });

        // Delete/remove sub-product in PM Edit modal
        $(document).on('click', '.deleteSubProductFromPurchaseOrderFinal', function () {
            let id = $(this).data('id');
            let buttonClicked = $(this);
            if (!id) {
                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: 'Item removed successfully!!',
                    customClass: {
                        container: 'swal2-zindex-fix-custom',
                        confirmButton: 'btn btn-success waves-effect waves-light'
                    }
                });
                buttonClicked.closest('.product-row-pm').remove();
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deletePurchaseOrderFinalSubItem: 'deletePurchaseOrderFinalSubItem',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                                buttonClicked.closest('.product-row-pm').remove();
                                loadLowStockRequestTable();
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        });

        // Submit handler for PM Edit form
        $(document).on('submit', '#editPurchaseOrderFinalForm', function (e) {
            e.preventDefault();

            const form = document.getElementById('editPurchaseOrderFinalForm');
            const formData = new FormData(form);
            formData.append('updatePurchaseOrderFinalRecord', 'updatePurchaseOrderFinalRecord');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editOrderReceivedModalPM').modal('hide');
                        $('#editPurchaseOrderFinalForm').find('.modal-body').html('');
                        toastr.success(res.message);
                        loadLowStockRequestTable();
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        // Add product row in Edit modal
        $(document).on('click', '#addProductBtnEdit', function () {
            const productRow = `
                <div class="product-row mb-2 rounded-xl border border-slate-200 bg-white p-2 shadow-sm">
                    <div class="grid grid-cols-1 gap-2 md:grid-cols-12 items-center">    
                        <input type="hidden" name="subProductIdEdit[]" value="" />                
                        <div class="md:col-span-3">
                            <input type="text" name="productName[]" class="input-theme" placeholder="Product Name" required />
                        </div>
                        <div class="md:col-span-2">
                            <input type="text" name="catNo[]" class="input-theme" placeholder="Cat No" />
                        </div>
                        <div class="md:col-span-2">
                            <input type="text" name="size[]" class="input-theme" placeholder="Size" />
                        </div>
                        <div class="md:col-span-2">
                            <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness" />
                        </div>
                        <div class="md:col-span-2">
                            <input type="text" name="quantity[]" class="input-theme" placeholder="Quantity" required />
                        </div>
                        <div class="md:col-span-1 text-center">
                            <button type="button" class="deleteSubProductFromPurchaseOrderRaw inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove product" data-id="">
                                <span class="ti ti-trash text-base"></span>
                            </button>
                        </div>                    
                    </div>
                </div>
                `;
            $('#productsListEdit').append(productRow);
            productIndexPor++;
        });

        // Delete/remove sub-product in Edit modal
        $(document).on('click', '.deleteSubProductFromPurchaseOrderRaw', function () {
            let id = $(this).data('id');
            let buttonClicked = $(this);
            if (!id) {
                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: 'Item removed successfully!!',
                    customClass: {
                        container: 'swal2-zindex-fix-custom',
                        confirmButton: 'btn btn-success waves-effect waves-light'
                    }
                });
                buttonClicked.closest('.product-row').remove();
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deletePurchaseOrderRawSubProductRecord: 'deletePurchaseOrderRawSubProductRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                                buttonClicked.closest('.product-row').remove();
                                loadLowStockRequestTable();
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        container: 'swal2-zindex-fix-custom',
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        });

        // Actions: Raw PO Delete
        $(document).on('click', '.purchaseOrderRawDeleteBtn', function (e) {
            e.stopPropagation();
            let id = $(this).data('id');

            if (!id) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid ID',
                    text: 'Invalid PO ID provided.',
                    customClass: {
                        confirmButton: 'btn btn-danger waves-effect waves-light'
                    }
                });
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deletePurchaseOrderRawRecord: 'deletePurchaseOrderRawRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                loadLowStockRequestTable();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        });

        // Load company branches for PO company address preview dropdowns
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadErpBranches: 'loadErpBranches' },
            success: function (res) {
                if (res && res.branches) {
                    const $vsel = $('.poViewCompanyAddressSelectClass');
                    res.branches.forEach(function (b) {
                        $vsel.append(`<option value="${b.id}"
                            data-name="${b.branch_name}"
                            data-address="${b.address || ''}"
                            data-city="${b.city || ''}"
                            data-state="${b.state || ''}"
                            data-pincode="${b.pincode || ''}"
                            data-gst="${b.branch_gst_no || ''}"
                        >${b.branch_name}</option>`);
                    });
                }
            }
        });

        // Company Address change handler
        $(document).on('change', '.poViewCompanyAddressSelectClass', function () {
            const $opt = $(this).find('option:selected');
            const $addrBlocks = $('.po-doc-company-address-view');
            if (!$(this).val()) {
                $addrBlocks.html('B19/A S.I.L. Ancillary Estate, Amausi<br>Industrial Area, Nadarganj-226008<br>(Lucknow)<br>GSTN: 09AACGB6941G1ZJ');
            } else {
                const name = $opt.data('name') || '';
                const address = $opt.data('address') || '';
                const city = $opt.data('city') || '';
                const state = $opt.data('state') || '';
                const pincode = $opt.data('pincode') || '';
                const gst = $opt.data('gst') || '';
                let html = `<strong>${name}</strong><br>`;
                if (address) html += `${address}<br>`;
                if (city || state) html += `${city}${city && state ? ', ' : ''}${state}${pincode ? '-' + pincode : ''}<br>`;
                if (gst) html += `GSTN: ${gst}`;
                $addrBlocks.html(html);
            }
        });

        // Reset the select dropdown when view modals are shown/hidden
        $('#viewPurchaseOrderRawModel, #finalPurchaseOrderViewPdfModal').on('show.bs.modal', function () {
            $('.poViewCompanyAddressSelectClass').val('');
        });

        $('#addMrProducts').click(function () {
            appendManualProductRow();
        });

        $('#addLowStocksForm').on('submit', function (e) {
            e.preventDefault();
            if ($('#mrProductsWrapper .product-row').length === 0) {
                toastr.error('Please add at least one item before submitting.');
                return;
            }

            const form = document.getElementById('addLowStocksForm');
            const formData = new FormData(form);
            formData.append('addLowStocksRecord', 'addLowStocksRecord');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#addLowStockModal').modal('hide');
                        $('#addLowStocksForm')[0].reset();
                        $('#dateOfReport').val(TODAY_DATE);
                        loadLowStockRequestTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#listOfColumns').selectpicker({
            actionsBox: true,
            selectedTextFormat: 'count > 2',
            noneSelectedText: '----Select Columns----'
        });
        $('#listOfColumns').selectpicker('selectAll');
    });

    $(document).on('click', '.lowStockDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteLowStocksRecord: 'deleteLowStocksRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadLowStockRequestTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });


    $(document).on('click', '.purchaseOrderEditModalBtn', function () {
        let vendor = $(this).data('vendor');
        let createdDate = $(this).data('created-date');
        if (vendor && createdDate) {
            $('#purchaseOrderEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchPurchaseOrderRecord: 'fetchPurchaseOrderRecord', vendor: vendor, createdDate: createdDate },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#purchaseOrderEditModal').modal('show');
                        $('#purchaseOrderEditForm').find('.modal-body').html(res.data);
                        $('#purchaseOrderEditForm .select2').select2({
                            placeholder: '----Select Option----',
                            width: '100%',
                            dropdownParent: $('#purchaseOrderEditModal')
                        });
                        let selectedCat = $('#materialCategoryEdit').val();
                        if (selectedCat) {
                            $('#materialCategoryEdit').trigger('change');
                        }
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $('#purchaseOrderEditForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('purchaseOrderEditForm');
        const formData = new FormData(form);
        formData.append('insertPurchaseOrderFinalRecord', 'insertPurchaseOrderFinalRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#purchaseOrderEditModal').modal('hide');
                    $('#purchaseOrderEditForm').find('modal-body').html();
                    loadLowStockRequestTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.purchaseOrderViewModalBtn', function () {
        let vendor = $(this).data('vendor');
        let createdDate = $(this).data('created-date');

        if (vendor && createdDate) {
            $('#productionPlanViewForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewPurchaseManagementRecord: 'viewPurchaseManagementRecord', vendor: vendor, createdDate: createdDate },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#productionPlanViewModal').modal('show');
                        $('#productionPlanViewForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('change', '.materialTypeList', function (e) {
        if (e.namespace === 'from_product') {
            return;
        }
        const $parentRow = $(this).closest('.product-row');
        const $productSelect = $parentRow.find('.productsList');
        const materialTypeId = $(this).val();

        loadProductsForSelect($productSelect, materialTypeId, '');
    });

    $(document).on('change', '.productsList', function (e) {
        const $parentRow = $(this).closest('.product-row');
        const $selectedOpt = $(this).find(':selected');
        const catId = $selectedOpt.data('category-id');
        const unitId = $selectedOpt.data('unit-id');
        const $catSelect = $parentRow.find('.materialTypeList');
        const $unitSelect = $parentRow.find('select[name="ProductItemquantityUnit[]"], select[name="ProductItemquantityUnitPor[]"]');

        if (catId && $catSelect.length && String($catSelect.val()) !== String(catId)) {
            $catSelect.val(catId).trigger('change.from_product');
        }
        if (unitId && $unitSelect.length) {
            $unitSelect.val(unitId).trigger('change');
        }
    });

    $('#mrProductsWrapper').on('click', '.removeProductBtn', function () {
        $(this).closest('.product-row').remove();
        updateItemNumbers();
    });

    $(document).on('change', '#materialCategoryEdit', function () {
        let categoryId = $(this).val();
        let productDropdown = $('#productsListEdit');
        let preSelectedProd = productDropdown.data('selected') || productDropdown.val() || '';
        loadProductsForSelect(productDropdown, categoryId, preSelectedProd);
    });

    $(document).on('click', '.removePurcahseOrderItemBtn', function () {
        $(this).closest('.product-row').remove();
    });
    $(document).on('click', 'th.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
        loadLowStockRequestTable(1);
    });

    $(document).on('click', '.purchaseOrderStatusChangeBtn', function (e) {
        e.preventDefault();
        let id = $(this).data('id');
        let statusValue = $(this).data('status-value');
        if (id && statusValue) {
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { updateStatusPurchaseOrderRecord: 'updateStatusPurchaseOrderRecord', id: id, statusValue: statusValue },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        loadLowStockRequestTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfPurchaseOrderFinalDownloadBtn', function (e) {
        e.preventDefault();
        e.stopPropagation();
        let id = $(this).data('id');
        if (id) {
            let url = <?php echo json_encode(asset('admin/pages/purchase_order_template.php')); ?> + "?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');
            toastr.success('Purchase Order PDF is being downloaded.');
        }
    });

    $(document).on('click', '.pdfPurchaseOrderRawDownloadBtn', function (e) {
        e.preventDefault();
        e.stopPropagation();
        let id = $(this).data('id');
        if (id) {
            let url = <?php echo json_encode(asset('admin/pages/purchase_order_raw_template.php')); ?> + "?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');
            toastr.success('Purchase Order PDF is being downloaded.');
        }
    });

    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $('#purchaseManagementExportForm').on('submit', function (e) {
        e.preventDefault();

        const exportType = $('#exportTypeSelect').val();
        if (!exportType) {
            toastr.error('Please select an export format.');
            return;
        }

        page = 1;
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const form = document.getElementById('purchaseManagementExportForm');
        const formData = new FormData(form);
        formData.append('exportPurchaseManagementRecords', 'exportPurchaseManagementRecords');
        formData.append('search', search);
        formData.append('per_page', perPage);
        formData.append('page', page);
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);
        formData.append('selectedStatus', JSON.stringify(selectedStatusFilters));

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
        const $submitBtn = $('#purchaseManagementExportForm button[type="submit"]');
        $submitBtn.showLoader({ size: 'lg', overlay: true, text: 'Please wait...' });

        $.ajax({
            url: 'exportajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            },
            complete: function () {
                $submitBtn.hideLoader();
            }
        });
    });

    $('#downloadExortfile').on('click', function () {
        toastr.success('Export downloaded successfully.');
    });

    $(document).on('click', '.export-type-item', function () {
        const val = $(this).data('val');
        $('#exportTypeText').text($(this).text());
        $('#exportTypeSelect').val(val);
    });

    $(document).on('click', '#deselectAllColumnsBtn', function () {
        const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
        if (isAllSelected) {
            $('.column-filter').prop('checked', false);
            $(this).text('Select All');
        } else {
            $('.column-filter').prop('checked', true);
            $(this).text('Deselect All');
        }
    });

    $(document).on('change', '.column-filter', function () {
        const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
        if (isAllSelected) {
            $('#deselectAllColumnsBtn').text('Deselect All');
        } else {
            $('#deselectAllColumnsBtn').text('Select All');
        }
    });

</script>
<?php endSection(); ?>
