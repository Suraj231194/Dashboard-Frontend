<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <ul class="nav nav-pills flex-column flex-md-row mb-4  d-none">
                <li class="nav-item">
                    <a class="nav-link active" href="javascript:void(0);"><i class="ti-xs ti ti-users me-1"></i> Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pages-account-settings-security.html"><i class="ti-xs ti ti-lock me-1"></i> Security</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pages-account-settings-billing.html"><i class="ti-xs ti ti-file-description me-1"></i> Billing & Plans</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pages-account-settings-notifications.html"><i class="ti-xs ti ti-bell me-1"></i> Notifications</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pages-account-settings-connections.html"><i class="ti-xs ti ti-link me-1"></i> Connections</a>
                </li>
            </ul>
            <div class="card mb-4 d-none">
                <h5 class="card-header">Profile Details</h5>
                <!-- Account -->
                <div class="card-body">
                    <div class="d-flex align-items-start align-items-sm-center gap-4">
                        <img src="<?= asset('assets/img/avatars/14.png') ?>" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded" id="uploadedAvatar" />
                        <div class="button-wrapper">
                            <label for="upload" class="btn btn-primary me-2 mb-3" tabindex="0">
                                <span class="d-none d-sm-block">Upload new photo</span>
                                <i class="ti ti-upload d-block d-sm-none"></i>
                                <input type="file" id="upload" class="account-file-input" hidden accept="image/png, image/jpeg" />
                            </label>
                            <button type="button" class="btn btn-label-secondary account-image-reset mb-3">
                                <i class="ti ti-refresh-dot d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Reset</span>
                            </button>

                            <div class="text-muted">Allowed JPG, GIF or PNG. Max size of 800K</div>
                        </div>
                    </div>
                </div>
                
                <!-- /Account -->
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
                <div class="bg-slate-50 border-b border-slate-100 px-6 py-4">
                    <h5 class="text-lg font-bold text-slate-800 m-0">Change Password</h5>
                </div>
                <div class="p-6 sm:p-8">

                    <form id="changePasswordAccSettings">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label text-slate-700 font-medium mb-2" for="newPassword">New Password</label>
                                <div class="input-group input-group-merge border border-slate-200 rounded-lg overflow-hidden focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500 transition-shadow">
                                    <input class="form-control border-0 shadow-none px-4 py-2.5" type="password" id="newPassword" name="newPassword" placeholder="············">
                                    <span class="input-group-text border-0 bg-transparent cursor-pointer px-4 toggle-password text-slate-400 hover:text-emerald-600 transition-colors"><i class="ti ti-eye-off text-lg"></i></span>
                                </div>
                                <div class="error-div text-rose-500 text-sm mt-2 d-none">
                                    <div data-field="newPassword" data-validator="notEmpty">Please enter new password</div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label text-slate-700 font-medium mb-2" for="confirmPassword">Confirm New Password</label>
                                <div class="input-group input-group-merge border border-slate-200 rounded-lg overflow-hidden focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500 transition-shadow">
                                    <input class="form-control border-0 shadow-none px-4 py-2.5" type="password" name="confirmPassword" id="confirmPassword" placeholder="············">
                                    <span class="input-group-text border-0 bg-transparent cursor-pointer px-4 toggle-password text-slate-400 hover:text-emerald-600 transition-colors"><i class="ti ti-eye-off text-lg"></i></span>
                                </div>
                                <div class="error-div text-rose-500 text-sm mt-2 d-none">
                                    <div data-field="confirmPassword" data-validator="notEmpty">Please confirm new password</div>
                                </div>
                            </div>
                            
                            <div class="col-12 mt-6">
                                <h6 class="text-slate-700 font-semibold mb-3">Password Requirements:</h6>
                                <ul class="ps-4 mb-0 text-slate-500 text-sm space-y-2">
                                    <li class="mb-1"><span class="text-slate-600">Minimum 8 characters long</span> - the more, the better</li>
                                    <li class="mb-1"><span class="text-slate-600">At least one lowercase character</span></li>
                                    <li><span class="text-slate-600">At least one number, symbol, or whitespace character</span></li>
                                </ul>
                            </div>
                            
                            <div class="col-12 mt-8 pt-6 border-t border-slate-100 flex gap-3">
                                <button type="submit" class="btn btn-primary bg-emerald-600 hover:bg-emerald-700 border-0 rounded-lg px-6 py-2.5 font-medium shadow-sm transition-all">Save changes</button>
                                <button type="reset" class="btn btn-label-secondary bg-slate-100 hover:bg-slate-200 text-slate-700 border-0 rounded-lg px-6 py-2.5 font-medium transition-all">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
                <div class="bg-slate-50 border-b border-slate-100 px-6 py-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h5 class="text-lg font-bold text-slate-800 m-0">Resignation &amp; Offboarding</h5>
                        <p class="text-xs text-slate-500 mb-0">Submit a resignation request and initiate employee offboarding</p>
                    </div>
                    <span class="badge bg-rose-50 text-rose-700 border border-rose-200 rounded-lg px-2 py-1 text-xs fw-bold">Offboarding</span>
                </div>
                <div class="p-6 sm:p-8 d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-4">
                    <div>
                        <h6 class="fw-bold text-slate-800 mb-1">Looking to initiate resignation?</h6>
                        <p class="text-sm text-slate-500 mb-0">You can submit your formal resignation request online. Your HR manager will review it, set your last working date, and guide you through the exit questionnaire.</p>
                    </div>
                    <a href="index.php?page=offboarding&amp;open=resign" class="btn btn-outline-danger rounded-xl px-5 py-2.5 fw-bold flex-shrink-0 d-inline-flex align-items-center gap-2">
                        <i class="ti ti-logout-2"></i> Resign
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    $(document).ready(function() {

        // Toggle Password Visibility
        $('.toggle-password').on('click', function() {
            const $icon = $(this).find('i');
            const $input = $(this).siblings('input');
            
            if ($input.attr('type') === 'password') {
                $input.attr('type', 'text');
                $icon.removeClass('ti-eye-off').addClass('ti-eye');
            } else {
                $input.attr('type', 'password');
                $icon.removeClass('ti-eye').addClass('ti-eye-off');
            }
        });

        $('#changePasswordAccSettings').on('submit', function(e) {
            e.preventDefault();
            const newPassword = $('#newPassword').val().trim();
            const confirmPassword = $('#confirmPassword').val().trim();

            let isValid = true;
            resetErrors();
            const passwordRegex = /^(?=.*[a-z])(?=.*[\d\s\W]).{8,}$/;

            if (!newPassword) {
                showError('#newPassword', 'Please enter new password');
                isValid = false;
            }
            else if (!passwordRegex.test(newPassword)) {
                showError(
                    '#newPassword',
                    'Password must be at least 8 characters and include lowercase & number/symbol'
                );
                isValid = false;
            }
            if (!confirmPassword) {
                showError('#confirmPassword', 'Please confirm new password');
                isValid = false;
            }
            if (newPassword && confirmPassword && newPassword !== confirmPassword) {
                showError('#confirmPassword', 'Passwords do not match');
                isValid = false;
            }
            if (!isValid) return;

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    updatePasswordAccountSetting: 'updatePasswordAccountSetting',
                    newPassword: btoa(newPassword)
                },
                beforeSend: function() {
                    $('button[type="submit"]')
                        .prop('disabled', true)
                        .text('Saving...');
                },
                success: function(res) {
                    if (res.status === 'success') {
                        toastr.success('Password updated successfully');
                        $('#changePasswordAccSettings')[0].reset();
                    } else {
                       toastr.error(res.message || 'Something went wrong');
                    }
                },
                error: function() {
                    toastr.error('Server error');
                },
                complete: function() {
                    $('button[type="submit"]')
                        .prop('disabled', false)
                        .text('Save changes');
                }
            });
        });

        function showError(inputSelector, message) {
            const $input = $(inputSelector);
            const $inputGroup = $input.closest('.input-group');
            const $errorDiv = $input.closest('.col-md-6').find('.error-div');

            $inputGroup.addClass('border-rose-500 ring-1 ring-rose-500').removeClass('border-slate-200 focus-within:border-emerald-500 focus-within:ring-emerald-500');
            $errorDiv
                .removeClass('d-none')
                .text(message);
        }

        function resetErrors() {
            $('.input-group').removeClass('border-rose-500 ring-1 ring-rose-500').addClass('border-slate-200 focus-within:border-emerald-500 focus-within:ring-emerald-500');
            $('.error-div').addClass('d-none').text('');
        }

        $('.form-control').on('input', function() {
            $(this).closest('.input-group').removeClass('border-rose-500 ring-1 ring-rose-500').addClass('border-slate-200 focus-within:border-emerald-500 focus-within:ring-emerald-500');
            $(this).closest('.col-md-6').find('.error-div')
                .addClass('d-none')
                .text('');
        });

    });
</script>
<?php endSection(); ?>
