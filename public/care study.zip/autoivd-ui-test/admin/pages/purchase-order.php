<?php
$purchaseOrderMaterialNames = [];
$purchaseOrderVendorNames = [];
if (isset($conn)) {
    $materialResult = $conn->query("SELECT DISTINCT `product_name` FROM `products` WHERE `status` = 1 AND `deleted_at` IS NULL AND TRIM(`product_name`) != '' ORDER BY `product_name` ASC");
    if ($materialResult) {
        while ($materialRow = $materialResult->fetch_assoc()) {
            $purchaseOrderMaterialNames[] = trim((string) $materialRow['product_name']);
        }
    }

    $vendorResult = $conn->query("SELECT DISTINCT `name` FROM `suppliers` WHERE `status` = 1 AND `deleted_at` IS NULL AND TRIM(`name`) != '' ORDER BY `name` ASC");
    if ($vendorResult) {
        while ($vendorRow = $vendorResult->fetch_assoc()) {
            $purchaseOrderVendorNames[] = trim((string) $vendorRow['name']);
        }
    }
}
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage final purchase orders</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="fpoPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="fpo-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <button type="button"
                        class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        id="addPurchaseOrderModalBtn" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                        <i class="ti ti-plus text-lg"></i>
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left" id="rawFinalPurchaseOrderTable">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-28 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="created_date" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="po_order_num" data-order="asc">
                                <span class="inline-flex items-center gap-1">Purchase Order No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="vendor_name_po" data-order="asc">
                                <span class="inline-flex items-center gap-1">Vendor Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-40 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Product Description</th>
                            <th class="w-56 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Created By</th>
                            <th
                                class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="finalPurchaseOrderTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer since it's now in the top strip -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="finalPurchaseOrderViewPdfModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Final Purchase Order PDF Preview</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div id="finalPurchaseOrderViewPdf">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addPurchaseOrderModal" tabindex="-1" aria-hidden="true">
        <style>
            #addPurchaseOrderModal .po-doc-form-table {
                min-width: 820px;
                table-layout: fixed;
            }

            #addPurchaseOrderModal .po-doc-th {
                padding: 10px 8px;
                vertical-align: middle;
                white-space: normal;
            }

            #addPurchaseOrderModal .po-doc-td {
                padding: 8px;
                vertical-align: middle;
            }

            #addPurchaseOrderModal .po-line-control {
                display: block;
                width: 100%;
                min-width: 0;
                height: 40px;
            }

            #addPurchaseOrderModal .po-currency-control {
                display: block;
                width: 100%;
                max-width: 180px;
                height: 36px;
                margin: 6px auto 0;
                padding-top: 0;
                padding-bottom: 0;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 0;
                text-transform: none;
            }

            #addPurchaseOrderModal .po-vendor-field {
                display: flex;
                min-height: 44px;
                align-items: center;
                gap: 8px;
            }

            #addPurchaseOrderModal .po-vendor-field-label {
                flex: 0 0 auto;
                font-weight: 600;
            }

            #addPurchaseOrderModal .po-vendor-field-control {
                min-width: 0;
                width: 60%;
                max-width: 60%;
                flex: 0 1 60%;
                text-align: left;
            }
        </style>
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Purchase Order</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div id="purchaseOrderFormContainer">
                    <div class="modal-body bg-white !px-6 !py-5">
                        <div class="col-xl-12 col-md-12 col-12 mb-md-0 mb-4">
                            <div class="card">
                                <div class="overflow-auto w-100">
                                    <div class="po-doc">
                                        <!-- Phase F: Company Address Selector -->
                                        <div class="mb-3 flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5">
                                            <i class="ti ti-building text-indigo-500 text-base shrink-0"></i>
                                            <label for="poCompanyAddressSelect" class="text-xs font-bold text-slate-600 whitespace-nowrap shrink-0">Company Address (on PO):</label>
                                            <select id="poCompanyAddressSelect" class="input-theme text-xs h-8 py-0 flex-1">
                                                <option value="">--- Use Default ---</option>
                                            </select>
                                        </div>
                                        <div class="transfer-copy">
                                            <div class="po-doc-box">
                                                <table class="po-doc-table po-doc-table-auto whitespace-nowrap">
                                                    <tr>
                                                        <!-- Left side: Logo + Company Info -->
                                                        <td class="po-doc-logo-cell">
                                                            <table class="po-doc-table">
                                                                <tr>
                                                                    <td class="po-doc-logo-wrap">
                                                                        <img src="<?= asset('assets/img/logo3.jpeg'); ?>"
                                                                            alt="Biogenix Logo" class="po-doc-logo">
                                                                        <div class="po-doc-cin">
                                                                            CIN NO. U24304UP2016PTC082775
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-company" id="poDocCompanyAddress">
                                                                        B19/A S.I.L. Ancillary Estate, Amausi<br>
                                                                        Industrial Area, Nadarganj-226008<br>
                                                                        (Lucknow)<br>
                                                                        GSTN: 09AACGB6941G1ZJ
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td class="po-doc-title-cell">
                                                            <strong class="fs-6">TITLE: Purchase Order</strong>
                                                        </td>
                                                        <td class="po-doc-meta-cell">
                                                            <table class="po-doc-meta-table">
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Document No.</td>
                                                                    <td class="po-doc-meta-value">BIPL-F-PO-01</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Issue No.</td>
                                                                    <td class="po-doc-meta-value">01</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Revision No.</td>
                                                                    <td class="po-doc-meta-value">02</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Effective Date</td>
                                                                    <td class="po-doc-meta-value">03/04/2025</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Review Date</td>
                                                                    <td class="po-doc-meta-value">02/04/2028</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label">Department</td>
                                                                    <td class="po-doc-meta-value">Purchase</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="po-doc-meta-label po-doc-meta-last">
                                                                        Supersedes</td>
                                                                    <td class="po-doc-meta-value po-doc-meta-last">Nil
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <form id="purchaseOrderFormAdd">
                                                <div class="p-3">
                                                    <table class="po-doc-table">
                                                        <tr class="po-doc-row">
                                                            <td class="po-doc-field-main"> <input type="text"
                                                                    name="poNumber" id="poNumber"
                                                                    value="<?= generateUniquePoOrderNum($conn); ?>"
                                                                    readonly /></td>
                                                            <td class="po-doc-field-side">Date:
                                                                <input type="text"
                                                                    value="<?= formatDatePO(date('Y-m-d')); ?>" />
                                                                <input type="hidden" name="poDate"
                                                                    value="<?= date('Y-m-d'); ?>" />
                                                            </td>
                                                        </tr>
                                                        <tr class="po-doc-row">
                                                            <td class="po-doc-field-main">
                                                                <div class="po-vendor-field">
                                                                    <span class="po-vendor-field-label">To:</span>
                                                                    <div class="po-vendor-field-control">
                                                                        <select name="vendorName" id="poVendorName"
                                                                            class="input-theme select2"
                                                                            aria-label="Select vendor" required>
                                                                            <option value="">-- Select Vendor --</option>
                                                                            <?php foreach ($purchaseOrderVendorNames as $vendorName): ?>
                                                                                <option value="<?= htmlspecialchars($vendorName, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($vendorName, ENT_QUOTES, 'UTF-8') ?></option>
                                                                            <?php endforeach; ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td class="po-doc-field-side"></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <table id="poTable" class="po-doc-form-table">
                                                    <colgroup>
                                                        <col style="width: 30%;">
                                                        <col style="width: 20%;">
                                                        <col style="width: 20%;">
                                                        <col style="width: 24%;">
                                                        <col style="width: 6%;">
                                                    </colgroup>
                                                    <thead
                                                        class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                                        <tr>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Material(s)</th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Pack Size</th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                Quantity Req.</th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">
                                                                <span>Price in</span>
                                                                <select name="poCurrency" id="poCurrency"
                                                                    class="input-theme po-currency-control"
                                                                    aria-label="Select currency" required>
                                                                    <?php
                                                                    if (!empty(Constant::PURCHASE_MANAGEMENT['CURRENCY'])) {
                                                                        $html = '<option value="">--Select Option--</option>';
                                                                        foreach (Constant::PURCHASE_MANAGEMENT['CURRENCY'] as $key => $value) {
                                                                            $html .= '<option value="' . $key . '">' . $value['label'] . ' (' . $value['symbol'] . ') </option>';
                                                                        }
                                                                        echo $html;
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </th>
                                                            <th class="border-b border-slate-200 px-6 py-3 po-doc-th">#
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="poTableBody">
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="2" class="text-center p-2">
                                                                <button type="button" id="addRowBtn"
                                                                    class="inline-flex h-11 min-w-40 whitespace-nowrap shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                                                        class="ti ti-plus text-lg"></i> Add New</button>
                                                            </td>
                                                            <td colspan="3" class="text-center p-2">
                                                                <button type="submit"
                                                                    class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                                                        class="ti ti-check text-lg"></i> Submit</button>
                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelectPor" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="porPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="por-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchPORaw"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'operations_admin_po_raw_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="addPurchaseOrderRawModalBtn" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left" id="purchaseOrderRawTable">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-28 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="created_at" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="po_order_num" data-order="asc">
                                <span class="inline-flex items-center gap-1">PO No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="vendor_name_po" data-order="asc">
                                <span class="inline-flex items-center gap-1">Vendor Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-40 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Products Name</th>
                            <th class="w-56 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Created By</th>
                            <th
                                class="w-40 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="purchaseOrderRawTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer since it's now in the top strip -->
            <style>
                #footerPerPageSelectPor + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapperPro', 'paginationSummaryPro', 'footerPerPageSelectPor') ?>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addPurchaseOrderRawModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 960px !important;" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Purchase Order Raw</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addPurchaseOrderRawForm">
                    <div class="modal-body space-y-3 bg-white !px-6 !py-5">
                        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                            <div>
                                <label for="vendorName" class="mb-1 block text-sm font-medium text-slate-800">Vendor
                                    Name <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="vendorName" autocomplete="off" name="vendorName"
                                    class="input-theme" placeholder="Enter Vendor Name" required />
                            </div>
                            <div>
                                <label for="extraNote"
                                    class="mb-1 block text-sm font-medium text-slate-800">Note</label>
                                <textarea id="extraNote" autocomplete="off" name="extraNote" rows="2"
                                    class="input-theme min-h-[44px]" placeholder="Enter Note"></textarea>
                            </div>
                        </div>

                        <div>
                            <label class="mb-2 block text-sm font-medium text-slate-800">Product Details</label>
                            <div id="productsList"></div>
                            <div>
                                <button type="button"
                                    class="inline-flex h-11 w-40 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addProductBtn">
                                    <i class="ti ti-plus text-lg"></i> <span class="whitespace-nowrap">Add
                                        Product</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="viewPurchaseOrderRawModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Purchase Order Details</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <!-- Phase F: Company Address Selector for Viewed PO -->
                <div class="px-6 py-2 border-b border-slate-200 bg-slate-50 flex items-center gap-3">
                    <i class="ti ti-building text-indigo-500 text-base shrink-0"></i>
                    <label for="poViewCompanyAddressSelect" class="text-xs font-bold text-slate-600 whitespace-nowrap shrink-0">Company Address (on PO Print/View):</label>
                    <select id="poViewCompanyAddressSelect" class="input-theme text-xs h-8 py-0 flex-1">
                        <option value="">--- Use Default ---</option>
                    </select>
                </div>
                <form id="viewPurchaseOrderRaw">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editOrderReceivedModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 960px !important;" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Purchase Order</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editPurchaseOrderRawForm">
                    <div class="modal-body bg-white !px-6 !py-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="updateStatusOrderReceivedModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Update Status</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="updateStatusOrderReceivedForm">
                    <div class="modal-body bg-white !px-6 !py-5">
                        <div>
                            <input type="hidden" name="orderEditId" id="orderEditId" value="">
                            <label for="orderStatus" class="mb-1 block text-sm font-medium text-slate-800">Select
                                Status</label>
                            <select name="orderStatus" id="orderStatus" class="input-theme" required>
                                <?php
                                echo '<option value="">----Select----</option>';
                                foreach (Constant::ORDER_RECEIVED['STATUS_TYPES'] as $otpkey => $otplabel) {
                                    echo "<option value=\"$otpkey\">" . $otplabel['label'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<?php startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    let currentPage = 1;
    const purchaseOrderMaterialNames = <?= json_encode($purchaseOrderMaterialNames, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    let qtyUnitOptions = [];
    let currentSortColumn = 'created_date';
    let currentSortDirection = 'DESC';

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#pack_size_unit").html(optionsHtml);
                $("#sampleTakenByQaUnit").html(optionsHtml);
                $("#quantityUnit").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadProductCategoryList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getProductCategoryList: 'getProductCategoryList'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#productCategory").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }


    function loadFinalPurchaseOrderTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        // Show loader before making the AJAX request
        $('#finalPurchaseOrderTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadFinalPurchaseOrder: 'loadFinalPurchaseOrder',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#finalPurchaseOrderTableBody').html(response.table);
                $('#paginationWrapper').html(response.pagination);
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.totalRows || 0);
                const shownThrough = Math.min(currentPage * parseInt(perPage), totalRows);

            },
            error: function () {
                $('#finalPurchaseOrderTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center text-sm font-medium text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    $(document).ready(function () {
        loadFinalPurchaseOrderTable();

        const $vendorSelect = $('#poVendorName');
        if ($.fn.select2 && !$vendorSelect.hasClass('select2-hidden-accessible')) {
            $vendorSelect.select2({
                dropdownParent: $('#addPurchaseOrderModal'),
                placeholder: '-- Select Vendor --',
                width: '100%'
            });
        }

        // Phase F: Load company branches into selector
        $.ajax({
            url: 'ajax.php', method: 'POST', dataType: 'json',
            data: { loadErpBranches: 'loadErpBranches' },
            success: function (res) {
                if (res && res.branches) {
                    const $sel = $('#poCompanyAddressSelect');
                    const $vsel = $('#poViewCompanyAddressSelect');
                    res.branches.forEach(function (b) {
                        const optHtml = `<option value="${b.id}"
                            data-name="${b.branch_name}"
                            data-address="${b.address || ''}"
                            data-city="${b.city || ''}"
                            data-state="${b.state || ''}"
                            data-pincode="${b.pincode || ''}"
                            data-gst="${b.branch_gst_no || ''}"
                        >${b.branch_name}</option>`;
                        $sel.append(optHtml);
                        $vsel.append(optHtml);
                    });
                }
            }
        });

        // Update PO company address block on branch change (Add Modal)
        $('#poCompanyAddressSelect').on('change', function () {
            const $opt = $(this).find('option:selected');
            const $addrBlock = $('#poDocCompanyAddress');
            if (!$(this).val()) {
                $addrBlock.html('B19/A S.I.L. Ancillary Estate, Amausi<br>Industrial Area, Nadarganj-226008<br>(Lucknow)<br>GSTN: 09AACGB6941G1ZJ');
            } else {
                const name    = $opt.data('name') || '';
                const address = $opt.data('address') || '';
                const city    = $opt.data('city') || '';
                const state   = $opt.data('state') || '';
                const pincode = $opt.data('pincode') || '';
                const gst     = $opt.data('gst') || '';
                let html = `<strong>${name}</strong><br>`;
                if (address) html += `${address}<br>`;
                if (city || state) html += `${city}${city && state ? ', ' : ''}${state}${pincode ? '-' + pincode : ''}<br>`;
                if (gst) html += `GSTN: ${gst}`;
                $addrBlock.html(html);
            }
        });

        // Update PO company address block on branch change (View Modal)
        $('#poViewCompanyAddressSelect').on('change', function () {
            const $opt = $(this).find('option:selected');
            const $addrBlocks = $('.po-doc-company-address-view');
            if (!$(this).val()) {
                $addrBlocks.html('B19/A S.I.L. Ancillary Estate, Amausi<br>Industrial Area, Nadarganj-226008<br>(Lucknow)<br>GSTN: 09AACGB6941G1ZJ');
            } else {
                const name    = $opt.data('name') || '';
                const address = $opt.data('address') || '';
                const city    = $opt.data('city') || '';
                const state   = $opt.data('state') || '';
                const pincode = $opt.data('pincode') || '';
                const gst     = $opt.data('gst') || '';
                let html = `<strong>${name}</strong><br>`;
                if (address) html += `${address}<br>`;
                if (city || state) html += `${city}${city && state ? ', ' : ''}${state}${pincode ? '-' + pincode : ''}<br>`;
                if (gst) html += `GSTN: ${gst}`;
                $addrBlocks.html(html);
            }
        });

        // Reset the select dropdown when view modal is shown/hidden
        $('#viewPurchaseOrderRawModel').on('show.bs.modal', function () {
            $('#poViewCompanyAddressSelect').val('');
        });

        $('#searchProducts').on('input', function () {
            loadFinalPurchaseOrderTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadFinalPurchaseOrderTable(1);
        });

        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadFinalPurchaseOrderTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.fpo-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#fpoPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#addPurchaseOrderModalBtn').on('click', function () {
            $('#poTableBody').html('');
            $('#addRowBtn').trigger('click');
            $('#addPurchaseOrderModal').modal('show');
        });

        $('#addRowBtn').on('click', function () {
            const newRow = $(`<tr>
                <td class="po-doc-td">
                    <select name="poMaterial[]" class="input-theme po-line-control po-material-select select2" aria-label="Material name" required>
                        <option value="">-- Select Material --</option>
                    </select>
                </td>
                <td class="po-doc-td"><input type="text" name="poPackSize[]" class="input-theme po-line-control" placeholder="Pack size" aria-label="Pack size" required /></td>
                <td class="po-doc-td"><input type="number" min="0" step="any" name="poQuantity[]" class="input-theme po-line-control" placeholder="Quantity" aria-label="Quantity required" required /></td>
                <td class="po-doc-td"><input type="text" name="poPrice[]" class="input-theme po-line-control" placeholder="Price" aria-label="Price" inputmode="decimal" required /></td>
                <td class="po-doc-td">
                <button type="button" class="removeRow inline-flex h-9 w-9 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove row"><span class="ti ti-trash text-base"></span></button>
                </td>
            </tr>`);
            const $materialSelect = newRow.find('.po-material-select');
            purchaseOrderMaterialNames.forEach(function (materialName) {
                $('<option>', { value: materialName, text: materialName }).appendTo($materialSelect);
            });
            $('#poTableBody').append(newRow);
            if ($.fn.select2) {
                $materialSelect.select2({
                    dropdownParent: $('#addPurchaseOrderModal'),
                    placeholder: '-- Select Material --',
                    width: '100%'
                });
            }
        });

        $('#purchaseOrderFormAdd').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('purchaseOrderFormAdd');
            const formData = new FormData(form);
            formData.append('addPurchaseOrderForm', 'addPurchaseOrderForm'); // Important flag for PHP

            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addPurchaseOrderModal').modal('hide');
                        $('#purchaseOrderFormAdd')[0].reset();
                        toastr.success(response.message);
                        loadFinalPurchaseOrderTable();
                        location.reload();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });
    });

    $(document).on('click', '.removeRow', function () {
        $(this).closest('tr').remove();
    });



    $(document).on('click', '.transferTicketViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#transferTicketView').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    transferTicketViewRecord: 'transferTicketViewRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#transferTicketViewModal').modal('show');
                        $('#transferTicketView').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '.previewTransferTicketPdf', function () {
        let purchaseOrderNum = $(this).data('purchase-order-num');
        if (purchaseOrderNum) {
            $('#finalPurchaseOrderViewPdf').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    purchaseOrderFinalViewPdfRecord: 'purchaseOrderFinalViewPdfRecord',
                    purchaseOrderNum: purchaseOrderNum
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#finalPurchaseOrderViewPdfModal').modal('show');
                        $('#finalPurchaseOrderViewPdf').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfPurchaseOrderFinalDownloadBtn', function () {
        let id = $(this).data('id');
        if (id) {
            // Open printable PDF page in a new tab
            let url = "<?php echo APP_URL; ?>admin/pages/purchase_order_template.php?id=" + id + "&triggerDownload=1";
            const branchId = $('#poViewCompanyAddressSelect').val();
            if (branchId) {
                url += "&branch_id=" + branchId;
            }
            window.open(url, '_blank');

            // Show success message after triggering
            toastr.success('Purchase Order PDF is being downloaded.');
        }
    });

    $(document).on('click', '#rawFinalPurchaseOrderTable .sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadFinalPurchaseOrderTable(1);
    });

    // deletePOPdf

    $(document).on('click', '.deletePOPdf', function () {
        let id = $(this).data('purchase-order-num');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deletePOPdfRecord: 'deletePOPdfRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadFinalPurchaseOrderTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });
</script>

<script>
    let currentPagePor = 1;
   
    let productIndexPor = 0;
    let currentSortColumnPor = 'id';
    let currentSortOrderPor = 'DESC'; 
    
    function loadPurchaseOrderRawTable(page = 1) {
        currentPagePor = page;
        const searchPor = $('#searchPORaw').val().trim();
        const perPagePor = $('#perPageSelectPor').val();

        // Show loader before making the AJAX request
        $('#purchaseOrderRawTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadPurchaseOrderRaw: 'loadPurchaseOrderRaw',
                page: page,
                per_page: perPagePor,
                search: searchPor,
                sort_column: currentSortColumnPor,
                sort_order: currentSortOrderPor
            },
            success: function (response) {
                $('#purchaseOrderRawTableBody').html(response.table || '');
                $('#paginationWrapperPro').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryPro', response.totalRows, typeof currentPagePor !== 'undefined' ? currentPagePor : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectPor');
                const totalRows = Number(response.totalRows || 0);
                const shownThrough = Math.min(currentPagePor * parseInt(perPagePor), totalRows);

            },
            error: function () {
                $('#purchaseOrderRawTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center text-sm font-medium text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapperPro').html('');

            }
        });
    }

    $(document).ready(function () {
        loadPurchaseOrderRawTable();
        $('#searchPORaw').on('input', function () {
            loadPurchaseOrderRawTable(1);
        });
        $('#perPageSelectPor').on('change', function () {
            loadPurchaseOrderRawTable(1);
        });

        $('#footerPerPageSelectPor').on('change', function () {
            $('#perPageSelectPor').val($(this).val());
            loadPurchaseOrderRawTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.por-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#porPerPageText').text(label);
            $('#footerPerPageSelectPor').val(val).trigger('change');
        });

        $('#addPurchaseOrderRawModalBtn').on('click', function () {
            $('#addPurchaseOrderRawModal').modal('show');
            $('#productsList').html('');
            $('#addProductBtn').trigger('click');
        });

        $('#addPurchaseOrderRawModal').on('hidden.bs.modal', function () {
            $('#addPurchaseOrderRawForm')[0].reset();
            $('#productsList').html('');
        });


        $('#addProductBtn').click(function () {
            const productRow = `
            <div class="product-row mb-2 rounded-xl border border-slate-200 bg-white p-2 shadow-sm" data-index="${productIndexPor}">
                <div class="grid grid-cols-1 gap-2 md:grid-cols-12 items-center">                    
                    <div class="md:col-span-3">
                        <input type="text" name="productName[]" class="input-theme" placeholder="Product Name" required />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="catNo[]" class="input-theme" placeholder="Cat No" />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="size[]" class="input-theme" placeholder="Size" />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness" />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="quantity[]" class="input-theme" placeholder="Quantity" required />
                    </div>
                    <div class="md:col-span-1 text-center">
                        <button type="button" class="removeProductBtn inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove product">
                            <span class="ti ti-trash text-base"></span>
                        </button>
                    </div>                    
                </div>
            </div>
            `;
            $('#productsList').append(productRow);
            productIndexPor++;
        });

        // Delete button handler
        $('#productsList').on('click', '.removeProductBtn', function () {
            $(this).closest('.product-row').remove();
        });

        $('#addPurchaseOrderRawForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addPurchaseOrderRawForm');
            const formData = new FormData(form);
            formData.append('addPurchaseOrderRaw', 'addPurchaseOrderRaw'); // Backend handler flag

            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#addPurchaseOrderRawModal').modal('hide');
                        $('#addPurchaseOrderRawForm')[0].reset();
                        $('#productsList').html('');
                        loadPurchaseOrderRawTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });
    });



    $(document).on('click', '.viewPurchaseOrderRawModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewOrderReceived').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    viewPurchaseOrderRawRecord: 'viewPurchaseOrderRawRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewPurchaseOrderRawModel').modal('show');
                        $('#viewPurchaseOrderRaw').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfPurchaseOrderRawDownloadBtn', function (e) {
        e.preventDefault();
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/purchase_order_raw_template.php?id=" + id + "&triggerDownload=1";
            const branchId = $('#poViewCompanyAddressSelect').val();
            if (branchId) {
                url += "&branch_id=" + branchId;
            }
            window.open(url, '_blank');
            toastr.success('Purchase Order PDF is being downloaded.');
        }
    });

    $(document).on('click', '#addProductBtnEdit', function () {
        const productRow = `
            <div class="product-row mb-2 rounded-xl border border-slate-200 bg-white p-2 shadow-sm">
                <div class="grid grid-cols-1 gap-2 md:grid-cols-12 items-center">    
                    <input type="hidden" name="subProductIdEdit[]" value="" />                
                    <div class="md:col-span-3">
                        <input type="text" name="productName[]" class="input-theme" placeholder="Product Name" required />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="catNo[]" class="input-theme" placeholder="Cat No" />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="size[]" class="input-theme" placeholder="Size" />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="thickness[]" class="input-theme" placeholder="Thickness" />
                    </div>
                    <div class="md:col-span-2">
                        <input type="text" name="quantity[]" class="input-theme" placeholder="Quantity" required />
                    </div>
                    <div class="md:col-span-1 text-center">
                        <button type="button" class="deleteSubProductFromPurchaseOrderRaw inline-flex h-10 w-10 items-center justify-center !rounded-lg bg-rose-50 text-rose-700 ring-1 ring-rose-100 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30" title="Remove product" data-id="">
                            <span class="ti ti-trash text-base"></span>
                        </button>
                    </div>                    
                </div>
            </div>
            `;
        $('#productsListEdit').append(productRow);
        productIndexPor++;
    });




    $(document).on('click', '.purchaseOrderRawDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deletePurchaseOrderRawRecord: 'deletePurchaseOrderRawRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadPurchaseOrderRawTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });


    $('#editPurchaseOrderRawForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editPurchaseOrderRawForm');
        const formData = new FormData(form);
        formData.append('updatePurchaseOrderRawRecord', 'updatePurchaseOrderRawRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editOrderReceivedModal').modal('hide');
                    $('#editPurchaseOrderRawForm').find('modal-body').html();
                    loadPurchaseOrderRawTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteSubProductFromPurchaseOrderRaw', function () {
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            Swal.fire({
                icon: 'success',
                title: 'Deleted!',
                text: 'Item removed successfully!!',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'btn btn-success waves-effect waves-light'
                }
            });
            buttonClicked.closest('.product-row').remove();
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deletePurchaseOrderRawSubProductRecord: 'deletePurchaseOrderRawSubProductRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                            buttonClicked.closest('.product-row').remove();
                            loadPurchaseOrderRawTable();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });



    $(document).on('click', '.editPurchaseOrderRawModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editPurchaseOrderRawForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchPurchaseOrderRawRecord: 'fetchPurchaseOrderRawRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editOrderReceivedModal').modal('show');
                        $('#editPurchaseOrderRawForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '#purchaseOrderRawTable th.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumnPor === column) {
            currentSortOrderPor = (currentSortOrderPor === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumnPor = column;
            currentSortOrderPor = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrderPor.toLowerCase());

        loadPurchaseOrderRawTable(1);
    });
</script>
<?php endSection(); ?>
