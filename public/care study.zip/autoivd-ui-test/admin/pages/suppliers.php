<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage supplier records and approval status</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="suppliersPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="suppliers-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="suppliers-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="suppliers-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="suppliers-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="suppliers-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="suppliers-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchSupplier"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_supplier_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="sortable w-64 min-w-[220px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="name" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="gst_no" data-order="ASC">
                                <span class="inline-flex items-center gap-1">GST No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="contact_number" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Phone <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-72 min-w-[240px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="address" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Address <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="status" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="suppliersTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- Add Supplier Modal -->
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Supplier</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a new supplier record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addSupplierForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                <label for="supplierName"
                                    class="mb-1 block text-sm font-medium text-slate-800">Name</label>
                                <input type="text" id="supplierName" autocomplete="off" name="supplierName"
                                    class="input-theme" placeholder="Enter Name" required />
                            </div>
                                <div>
                                <label for="supplierCode"
                                    class="mb-1 block text-sm font-medium text-slate-800">Code</label>
                                <input type="text" id="supplierCode" autocomplete="off" name="supplierCode"
                                    class="input-theme" placeholder="Enter Code" />
                            </div>
                        </div>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                <label for="supplierContactPerson"
                                    class="mb-1 block text-sm font-medium text-slate-800">Contact Person</label>
                                <input type="text" id="supplierContactPerson" autocomplete="off"
                                    name="supplierContactPerson" class="input-theme"
                                    placeholder="Enter Contact Person Name" />
                            </div>
                                <div>
                                <label for="supplierContactPersonNumner"
                                    class="mb-1 block text-sm font-medium text-slate-800">Contact Person Number</label>
                                <input type="text" id="supplierContactPersonNumner" autocomplete="off"
                                    name="supplierContactPersonNumner" class="input-theme"
                                    placeholder="Enter Contact Person Number" />
                            </div>
                                <div>
                                <label for="supplierEmail"
                                    class="mb-1 block text-sm font-medium text-slate-800">Email</label>
                                <input type="email" id="supplierEmail" autocomplete="off"
                                    name="supplierEmail" class="input-theme"
                                    placeholder="Enter Email" />
                            </div>
                        </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                <label for="itemDescription" class="mb-1 block text-sm font-medium text-slate-800">Item
                                    Description</label>
                                <input type="text" id="itemDescription" autocomplete="off" name="itemDescription"
                                    class="input-theme" placeholder="Enter Item Description" />
                            </div>
                                <div>
                                <label for="dateofApproval" class="mb-1 block text-sm font-medium text-slate-800">Date
                                    of Approval</label>
                                <input type="date" id="dateofApproval" autocomplete="off" name="dateofApproval"
                                    class="input-theme" />
                            </div>
                                <div>
                                <label for="basisOfApproval" class="mb-1 block text-sm font-medium text-slate-800">Basis
                                    of Approval</label>
                                <input type="text" id="basisOfApproval" autocomplete="off" name="basisOfApproval"
                                    class="input-theme" placeholder="Basis of Approval" />
                            </div>
                                <div>
                                <label for="supplierGstNo" class="mb-1 block text-sm font-medium text-slate-800">GST
                                    No</label>
                                <input type="text" id="supplierGstNo" autocomplete="off" name="supplierGstNo"
                                    class="input-theme" placeholder="Enter GST NO" />
                            </div>
                                <div>
                                <label for="supplierContactDetails"
                                    class="mb-1 block text-sm font-medium text-slate-800">Contact Details</label>
                                <input type="text" id="supplierContactDetails" autocomplete="off"
                                    name="supplierContactDetails" class="input-theme"
                                    placeholder="Enter Contact Details" />
                            </div>
                                <div>
                                <label for="remark" class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea id="remark" autocomplete="off" name="remark" class="input-theme min-h-[60px]"
                                    placeholder="Enter Remarks"></textarea>
                            </div>
                        </div>
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div>
                                    <label class="inline-flex items-center gap-2 cursor-pointer">
                                        <input type="checkbox" value="1" name="is_supplier" id="is_supplier"
                                            class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600">
                                        <span class="text-sm font-medium text-slate-700">Is Supplier</span>
                                    </label>
                            </div>
                                <div>
                                    <label class="inline-flex items-center gap-2 cursor-pointer">
                                        <input type="checkbox" value="1" name="is_manufacturer" id="is_manufacturer"
                                            class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600">
                                        <span class="text-sm font-medium text-slate-700">Is Manufacturer</span>
                                    </label>
                            </div>
                                <div>
                                    <label class="inline-flex items-center gap-2 cursor-pointer">
                                        <input type="checkbox" value="1" name="is_vendor" id="is_vendor"
                                            class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600">
                                        <span class="text-sm font-medium text-slate-700">Is Vendor</span>
                                    </label>
                            </div>
                                <div>
                                    <label class="inline-flex items-center gap-2 cursor-pointer">
                                        <input type="checkbox" value="1" name="is_dealer" id="is_dealer"
                                            class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600">
                                        <span class="text-sm font-medium text-slate-700">Is Dealer</span>
                                    </label>
                            </div>
                        </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="mb-2 block text-sm font-medium text-slate-800">Is Approved</label>
                                    <div class="flex items-center gap-4">
                                        <label class="inline-flex items-center gap-2 cursor-pointer">
                                            <input type="radio" id="activStatusApproved" name="supplierStatusApproved"
                                                value="1" class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                                required />
                                            <span class="text-sm text-slate-700">Yes</span>
                                        </label>
                                        <label class="inline-flex items-center gap-2 cursor-pointer">
                                            <input type="radio" id="inactiveStatusApproved" name="supplierStatusApproved"
                                                value="0" class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                            <span class="text-sm text-slate-700">No</span>
                                        </label>
                                    </div>
                            </div>
                                <div>
                                    <label class="mb-2 block text-sm font-medium text-slate-800">Status</label>
                                    <div class="flex items-center gap-4">
                                        <label class="inline-flex items-center gap-2 cursor-pointer">
                                            <input type="radio" id="activStatus" name="supplierStatus" value="1"
                                                class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                                required />
                                            <span class="text-sm text-slate-700">Active</span>
                                        </label>
                                        <label class="inline-flex items-center gap-2 cursor-pointer">
                                            <input type="radio" id="inactiveStatus" name="supplierStatus" value="0"
                                                class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                            <span class="text-sm text-slate-700">Inactive</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Supplier Modal -->
    <div class="modal fade animate__animated fadeIn" id="editSupplierModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Supplier</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update supplier details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editSupplierForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3"></div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade animate__animated fadeIn" id="changePasswordUserModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-lock text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Change Password</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update account password</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="changePasswordForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col mb-3">
                                <label for="userNewPassword" class="mb-1 block text-sm font-medium text-slate-800">Enter
                                    New Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="userNewPassword" class="form-control"
                                        name="userNewPassword" autocomplete="off" placeholder="············"
                                        aria-describedby="password" required />
                                    <span class="input-group-text cursor-pointer seeUserNewPassword"><i
                                            class="ti ti-eye-off"></i></span>
                                </div>
                                <input type="hidden" name="user_id" id="user_id" class="form-control" value="" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="userNewConfirmPassword"
                                    class="mb-1 block text-sm font-medium text-slate-800">Confirm New Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="userNewConfirmPassword" class="form-control"
                                        name="userNewConfirmPassword" autocomplete="off" placeholder="············"
                                        aria-describedby="password" required />
                                    <span class="input-group-text cursor-pointer seeUserNewConfirmPassword"><i
                                            class="ti ti-eye-off"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="submitChangePasswordBtn"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let supplierSortColumn = 'id';
    let supplierSortOrder = 'DESC';

    function loadSuppliersTable(page = 1) {
        currentPage = page;
        const search = $('#searchSupplier').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#suppliersTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadSuppliers: 'loadSuppliers',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: supplierSortColumn,
                sort_order: supplierSortOrder
            },
            success: function (response) {
                $('#suppliersTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const visibleRows = $('#suppliersTableBody tr').length;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * parseInt(perPage)) + visibleRows, totalRows) : 0;
                $('#supplierPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
            },
            error: function () {
                $('#suppliersTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#supplierPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    $(document).ready(function () {
        loadSuppliersTable();
        $('#searchSupplier').on('input', function () { loadSuppliersTable(1); });
        $('#perPageSelect').on('change', function () { loadSuppliersTable(1); });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadSuppliersTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.suppliers-per-page-item', function () {
            const val = $(this).data('val');
            $('#suppliersPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addSupplierForm')[0].reset();
        });

        $('#addSupplierForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addSupplierForm');
            const formData = new FormData(form);
            formData.append('addSuppliers', 'addSuppliers');
            $.ajax({
                url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addSupplierForm')[0].reset();
                        loadSuppliersTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else { toastr.error('Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        });
    });

    $(document).on('click', '.supplierEditModal', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editSupplierForm').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { fetchSupplierRecord: 'fetchSupplierRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editSupplierModel').modal('show');
                        $('#editSupplierForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') { toastr.error(res.message); }
                    else { toastr.error('Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });

    $(document).on('click', '.suuplierDeleteBtn', function () {
        let id = $(this).data('id');
        if (!id) { Swal.fire({ icon: 'error', title: 'Invalid ID', text: 'Invalid supplier ID provided.', customClass: { confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); return; }
        Swal.fire({
            title: 'Are you sure?', text: "You won't be able to revert this!", icon: 'warning',
            showCancelButton: true, confirmButtonText: 'Yes, delete it!', cancelButtonText: 'Cancel',
            customClass: { confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white', cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700' },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php', type: 'POST',
                    data: { deleteSupplierRecord: 'deleteSupplierRecord', id: id }, dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadSuppliersTable();
                            Swal.fire({ icon: 'success', title: 'Deleted!', text: res.message, customClass: { confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white' } });
                        } else {
                            Swal.fire({ icon: 'error', title: 'Failed!', text: res.message, customClass: { confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
                        }
                    },
                    error: function (xhr, status, error) { Swal.fire({ icon: 'error', title: 'Server Error', text: error, customClass: { confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); }
                });
            }
        });
    });

    $('#editSupplierForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editSupplierForm');
        const formData = new FormData(form);
        formData.append('updateSupplier', 'updateSupplier');
        $.ajax({
            url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editSupplierModel').modal('hide');
                    loadSuppliersTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') { toastr.error(res.message); }
                else { toastr.error('Unexpected response.'); }
            },
            error: function () { toastr.error('Server error occurred.'); }
        });
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (supplierSortColumn === column) {
            supplierSortOrder = (supplierSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            supplierSortColumn = column;
            supplierSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(supplierSortOrder.toLowerCase());
        loadSuppliersTable(1);
    });
</script>
<?php endSection(); ?>
