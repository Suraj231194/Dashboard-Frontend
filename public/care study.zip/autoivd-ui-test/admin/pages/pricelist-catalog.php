<?php
$categoriesList = [];
if (isset($conn) && $conn) {
    $catRes = $conn->query("SELECT id, name FROM product_categories WHERE status = 1 AND deleted_at IS NULL ORDER BY name ASC");
    if ($catRes && $catRes->num_rows > 0) {
        while ($c = $catRes->fetch_assoc()) {
            $categoriesList[] = $c;
        }
    }
}
?>
<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <!-- Header Card -->
    <div class="mb-5 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div class="flex items-center gap-3">
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100 shadow-xs">
                    <i class="ti ti-tags text-2xl"></i>
                </span>
                <div>
                    <h4 class="m-0 text-xl font-bold tracking-tight text-slate-900">Price List Master</h4>
                    <p class="m-0 text-sm font-medium text-slate-500">Commercial Catalog &amp; Multi-Tier Pricing (B2B Selling Rate &amp; B2C MRP)</p>
                </div>
            </div>
            <div class="flex flex-wrap items-center gap-2.5">
                <a href="index.php?page=products" class="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-700 shadow-xs hover:bg-slate-50 transition-all">
                    <i class="ti ti-arrow-left text-base"></i> Back to Products
                </a>
                <button type="button" id="exportPriceListCsv" class="inline-flex h-10 items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-4 text-sm font-bold text-emerald-800 shadow-xs hover:bg-emerald-100 transition-all cursor-pointer">
                    <i class="ti ti-download text-base"></i> Export CSV
                </button>
            </div>
        </div>
    </div>

    <!-- Main Content Table Card -->
    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <!-- Filter and Search Toolbar -->
        <div class="flex flex-col gap-3 border-b border-slate-200/80 p-4 lg:flex-row lg:items-center lg:justify-between bg-slate-50/40">
            <div class="flex flex-wrap items-center gap-3">
                <!-- Search Box -->
                <div class="relative min-w-[240px]">
                    <i class="ti ti-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" id="priceSearchInput" class="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm text-slate-800 shadow-xs placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20" placeholder="Search by Product, CAT No, HSN...">
                </div>

                <!-- Category Filter -->
                <select id="priceCategoryFilter" class="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-700 shadow-xs focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20">
                    <option value="">All Categories</option>
                    <?php foreach ($categoriesList as $cat): ?>
                        <option value="<?= (int)$cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <!-- Per Page -->
                <select id="pricePerPage" class="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-700 shadow-xs focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20">
                    <option value="25">25 per page</option>
                    <option value="50" selected>50 per page</option>
                    <option value="100">100 per page</option>
                </select>
            </div>

            <div class="flex items-center gap-2 text-xs font-semibold text-slate-500">
                <span class="inline-block h-2 w-2 rounded-full bg-emerald-500"></span>
                <span>Tier 1: B2B Selling Rate</span>
                <span class="mx-1.5 text-slate-300">|</span>
                <span class="inline-block h-2 w-2 rounded-full bg-blue-500"></span>
                <span>Tier 2: B2C MRP</span>
            </div>
        </div>

        <!-- Price List Table -->
        <div class="overflow-x-auto">
            <table class="w-full border-collapse text-left" id="priceCatalogTable">
                <thead class="whitespace-nowrap border-b border-slate-100 bg-slate-50/75 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="w-12 px-4 py-3 text-center">#</th>
                        <th class="px-4 py-3">CAT No</th>
                        <th class="min-w-[220px] px-4 py-3">Product Name</th>
                        <th class="px-4 py-3">Category</th>
                        <th class="w-28 px-3 py-3">HSN Code</th>
                        <th class="w-36 px-3 py-3 bg-emerald-50/40 text-emerald-900">B2B Rate (₹)</th>
                        <th class="w-36 px-3 py-3 bg-blue-50/40 text-blue-900">B2C MRP (₹)</th>
                        <th class="w-24 px-3 py-3 text-center">GST %</th>
                        <th class="w-32 px-3 py-3">Effective Date</th>
                        <th class="w-28 px-4 py-3 text-center">Action</th>
                    </tr>
                </thead>
                <tbody id="priceCatalogTableBody" class="divide-y divide-slate-100 bg-white text-sm text-slate-700">
                    <tr>
                        <td colspan="10" class="p-8 text-center text-slate-400">
                            <span class="spinner-border spinner-border-sm text-emerald-700 me-2"></span> Loading Price List Master...
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Pagination Footer -->
        <div class="flex flex-col items-center justify-between gap-3 border-t border-slate-200 bg-white px-5 py-3.5 sm:flex-row text-xs text-slate-500">
            <span id="priceListSummary">Showing 0 of 0 entries</span>
            <div class="flex items-center gap-1.5" id="priceListPagination"></div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
$(document).ready(function () {
    let currentPage = 1;
    let totalPages = 1;
    let searchDebounceTimer = null;

    function loadPriceCatalog() {
        const search = $('#priceSearchInput').val().trim();
        const categoryId = $('#priceCategoryFilter').val();
        const perPage = $('#pricePerPage').val();

        $('#priceCatalogTableBody').html(`
            <tr>
                <td colspan="10" class="p-8 text-center text-slate-400">
                    <span class="spinner-border spinner-border-sm text-emerald-700 me-2"></span> Fetching catalog data...
                </td>
            </tr>
        `);

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                loadPriceListCatalog: '1',
                page: currentPage,
                per_page: perPage,
                search: search,
                category_id: categoryId
            },
            success: function (res) {
                if (res.status !== 'success') {
                    toastr.error(res.message || 'Unable to load catalog.');
                    $('#priceCatalogTableBody').html(`<tr><td colspan="10" class="p-8 text-center text-rose-500">${res.message || 'Error'}</td></tr>`);
                    return;
                }

                const rows = res.data.rows || [];
                totalPages = res.data.total_pages || 1;
                const total = res.data.total || 0;
                const from = res.data.from || 0;
                const to = res.data.to || 0;

                $('#priceListSummary').text(`Showing ${from} to ${to} of ${total} entries`);
                renderPagination(res.data);

                if (rows.length === 0) {
                    $('#priceCatalogTableBody').html(`
                        <tr>
                            <td colspan="10" class="p-8 text-center text-slate-400">No products matching the selected criteria.</td>
                        </tr>
                    `);
                    return;
                }

                let html = '';
                rows.forEach((row, idx) => {
                    const rowNum = from + idx;
                    const catNo = row.product_code || '—';
                    const effectiveDate = row.effective_from || new Date().toISOString().slice(0, 10);

                    html += `
                    <tr class="price-catalog-row border-b border-slate-100 hover:bg-slate-50/60 transition-colors" data-product-id="${row.product_id}">
                        <td class="px-4 py-2.5 text-center text-xs font-semibold text-slate-400">${rowNum}</td>
                        <td class="px-4 py-2.5 font-mono text-xs font-bold text-slate-600">${escapeHtml(catNo)}</td>
                        <td class="px-4 py-2.5 font-semibold text-slate-800">${escapeHtml(row.product_name)}</td>
                        <td class="px-4 py-2.5 text-xs text-slate-500">${escapeHtml(row.category_name || '—')}</td>
                        <td class="px-3 py-2">
                            <input type="text" data-field="hsn_code" class="form-control input-theme text-xs py-1 px-2 font-mono" value="${escapeHtml(row.hsn_code || '')}" placeholder="HSN" />
                        </td>
                        <td class="px-3 py-2 bg-emerald-50/30">
                            <div class="relative">
                                <span class="absolute left-2 top-1/2 -translate-y-1/2 text-xs font-bold text-emerald-700">₹</span>
                                <input type="number" min="0" step="0.01" data-field="selling_rate" class="form-control input-theme text-xs py-1 pl-5 pr-2 font-bold text-emerald-800" value="${parseFloat(row.selling_rate || 0).toFixed(2)}" />
                            </div>
                        </td>
                        <td class="px-3 py-2 bg-blue-50/30">
                            <div class="relative">
                                <span class="absolute left-2 top-1/2 -translate-y-1/2 text-xs font-bold text-blue-700">₹</span>
                                <input type="number" min="0" step="0.01" data-field="mrp" class="form-control input-theme text-xs py-1 pl-5 pr-2 font-bold text-blue-800" value="${parseFloat(row.mrp || 0).toFixed(2)}" />
                            </div>
                        </td>
                        <td class="px-3 py-2 text-center">
                            <input type="number" min="0" max="100" step="0.1" data-field="gst_rate" class="form-control input-theme text-xs py-1 px-2 text-center" value="${parseFloat(row.gst_rate || 0)}" />
                        </td>
                        <td class="px-3 py-2">
                            <input type="date" data-field="effective_from" class="form-control input-theme text-xs py-1 px-2" value="${effectiveDate}" />
                        </td>
                        <td class="px-4 py-2 text-center">
                            <button type="button" class="save-catalog-btn inline-flex h-8 items-center gap-1.5 rounded-lg bg-emerald-700 px-3 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 transition-all cursor-pointer">
                                <i class="ti ti-check text-sm"></i> Save
                            </button>
                        </td>
                    </tr>
                    `;
                });

                $('#priceCatalogTableBody').html(html);
            },
            error: function () {
                toastr.error('Failed to communicate with server.');
            }
        });
    }

    function renderPagination(data) {
        const pages = data.total_pages || 1;
        const cur = data.page || 1;
        let html = '';

        html += `<button type="button" class="page-nav-btn inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed" data-page="${cur - 1}" ${cur <= 1 ? 'disabled' : ''}><i class="ti ti-chevron-left text-sm"></i></button>`;

        let start = Math.max(1, cur - 2);
        let end = Math.min(pages, start + 4);
        if (end - start < 4) start = Math.max(1, end - 4);

        for (let p = start; p <= end; p++) {
            const active = p === cur ? 'bg-emerald-700 text-white font-bold' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50';
            html += `<button type="button" class="page-num-btn inline-flex h-8 w-8 items-center justify-center rounded-lg text-xs font-semibold ${active} cursor-pointer" data-page="${p}">${p}</button>`;
        }

        html += `<button type="button" class="page-nav-btn inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed" data-page="${cur + 1}" ${cur >= pages ? 'disabled' : ''}><i class="ti ti-chevron-right text-sm"></i></button>`;

        $('#priceListPagination').html(html);
    }

    function escapeHtml(str) {
        return $('<div>').text(str || '').html();
    }

    // Save individual row commercial rates
    $(document).on('click', '.save-catalog-btn', function () {
        const $btn = $(this);
        const $row = $btn.closest('.price-catalog-row');
        const productId = $row.data('product-id');

        const payload = {
            savePriceListCatalogItem: '1',
            product_id: productId,
            hsn_code: $row.find('[data-field="hsn_code"]').val().trim(),
            selling_rate: $row.find('[data-field="selling_rate"]').val(),
            mrp: $row.find('[data-field="mrp"]').val(),
            gst_rate: $row.find('[data-field="gst_rate"]').val(),
            effective_from: $row.find('[data-field="effective_from"]').val()
        };

        $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span>');

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: payload,
            success: function (res) {
                if (res.status === 'success') {
                    toastr.success(res.message || 'Commercial rates saved successfully!');
                    $btn.addClass('bg-emerald-800').html('<i class="ti ti-check-double text-sm"></i> Saved');
                    setTimeout(() => {
                        $btn.removeClass('bg-emerald-800').html('<i class="ti ti-check text-sm"></i> Save');
                    }, 1500);
                } else {
                    toastr.error(res.message || 'Error saving rate.');
                    $btn.html('<i class="ti ti-check text-sm"></i> Save');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
                $btn.html('<i class="ti ti-check text-sm"></i> Save');
            },
            complete: function () {
                $btn.prop('disabled', false);
            }
        });
    });

    // Filtering and Pagination Handlers
    $('#priceSearchInput').on('input', function () {
        clearTimeout(searchDebounceTimer);
        searchDebounceTimer = setTimeout(() => {
            currentPage = 1;
            loadPriceCatalog();
        }, 300);
    });

    $('#priceCategoryFilter, #pricePerPage').on('change', function () {
        currentPage = 1;
        loadPriceCatalog();
    });

    $(document).on('click', '.page-num-btn, .page-nav-btn', function () {
        const page = parseInt($(this).data('page'));
        if (page && page >= 1 && page <= totalPages && page !== currentPage) {
            currentPage = page;
            loadPriceCatalog();
        }
    });

    // Export to CSV
    $('#exportPriceListCsv').on('click', function () {
        const search = $('#priceSearchInput').val().trim();
        const categoryId = $('#priceCategoryFilter').val();
        window.location.href = `ajax.php?exportPriceListCsv=1&search=${encodeURIComponent(search)}&category_id=${encodeURIComponent(categoryId)}`;
    });

    // Initial Load
    loadPriceCatalog();
});
</script>
<?php endSection(); ?>
