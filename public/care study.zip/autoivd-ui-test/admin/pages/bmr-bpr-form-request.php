<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage upcoming and requested Batch Manufacturing Record and Batch Packaging Record forms
            </p>
        </div>
    </div>

    <!-- Upcoming BMR/BPR Form Requests Widget -->
    <div id="upcomingBmrBprWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" role="button" tabindex="0"
        aria-controls="upcomingBmrBprModal">
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
            style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div
                    style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                    <i class="ti ti-file-description"
                        style="font-size: 1.5rem; color: var(--appearance-accent, #7e22ce);"></i>
                    <span
                        style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight"
                            style="font-size: 1.125rem; color: var(--ui-text, #1e293b); margin: 0;">
                            Upcoming BMR/BPR Form Requests
                        </h3>
                        <span id="upcomingBmrBprCount" aria-live="polite"
                            style="display: flex; align-items: center; justify-content: center; min-width: 1.25rem; height: 1.25rem; padding: 0 0.3rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px;">0</span>
                    </div>
                    <p class="font-medium mt-1 mb-0" style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">
                        You have <span id="upcomingBmrBprCountText" class="font-bold">0</span> BMR/BPR form
                        request(s) waiting in the queue. Click here to review.
                    </p>
                </div>
            </div>
            <div style="color: var(--ui-text-muted, #94a3b8);">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <!-- BMR/BPR Form Request Table -->
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:items-center">
                    <input type="hidden" id="bmrBprPerPage" value="10">

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2"
                            style="--tw-ring-color: var(--appearance-accent, #7e22ce);" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <span id="bmrBprPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="bmr-bpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="bmr-bpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="bmr-bpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="bmr-bpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a class="bmr-bpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[180px] max-w-[360px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="search" id="bmrBprSearch"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:ring-2"
                            style="--tw-ring-color: var(--appearance-accent, #7e22ce);" placeholder="Search Data..."
                            autocomplete="off">
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36 h-11"
                        data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i>
                        <span>Export</span>
                    </button>
                </div>
            </div>

            <div class="w-full overflow-x-auto">
                <table class="w-full border-collapse text-left">
                    <thead class="whitespace-nowrap border-b border-slate-100 bg-white">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Serial #
                            </th>
                            <th class="bmr-bpr-sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="product_name">
                                <span class="inline-flex items-center gap-1">Product Name <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="bmr-bpr-sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="category_code">
                                <span class="inline-flex items-center gap-1">Cat # <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="bmr-bpr-sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="batch_size">
                                <span class="inline-flex items-center gap-1">Batch Size <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="bmr-bpr-sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="form_count">
                                <span class="inline-flex items-center gap-1">No. of BMR/BPR Forms <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="bmr-bpr-sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="pack_size">
                                <span class="inline-flex items-center gap-1">Pack Size <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="bmr-bpr-sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="lot_number">
                                <span class="inline-flex items-center gap-1">Lot No. <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th
                                class="w-28 px-6 py-3 text-right text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody id="bmrBprTableBody" class="divide-y divide-slate-100 bg-white">
                        <tr>
                            <td colspan="8" class="px-6 py-10 text-center">
                                <div class="inline-flex items-center gap-2 text-sm font-semibold text-slate-500">
                                    <span class="spinner-border spinner-border-sm" role="status"
                                        aria-hidden="true"></span>
                                    Loading requests...
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div
                class="flex flex-col items-center justify-between gap-3 border-t border-slate-200 bg-white px-6 py-4 md:flex-row">
                <p id="bmrBprPaginationSummary" class="m-0 text-sm font-medium text-slate-500">
                    Showing 0 to 0 of 0 entries
                </p>
                <div id="bmrBprPagination" class="flex items-center gap-2"></div>
            </div>
        </div>
    </div>
</div>

<!-- Export Document Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.
                    </p>
                </div>
                <button type="button"
                    class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none"
                    data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="bmrBprExportForm">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE
                            FORMAT</label>
                        <div class="dropdown w-full">
                            <button
                                class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                                type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">CSV (Comma Separated Values)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                        data-val="csv">CSV (Comma Separated Values)</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="csv">
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT
                                COLUMNS</label>
                            <button type="button" id="deselectAllColumnsBtn"
                                class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect
                                All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="S.No" checked />
                                    <span class="text-sm font-medium text-slate-700">S.No</span>
                                </label>
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="Product Name" checked />
                                    <span class="text-sm font-medium text-slate-700">Product Name</span>
                                </label>
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="Cat #" checked />
                                    <span class="text-sm font-medium text-slate-700">Cat #</span>
                                </label>
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="Batch Size" checked />
                                    <span class="text-sm font-medium text-slate-700">Batch Size</span>
                                </label>
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="No. of BMR/BPR Forms" checked />
                                    <span class="text-sm font-medium text-slate-700">No. of BMR/BPR Forms</span>
                                </label>
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="Pack Size" checked />
                                    <span class="text-sm font-medium text-slate-700">Pack Size</span>
                                </label>
                                <label
                                    class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]"
                                        class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="Lot No." checked />
                                    <span class="text-sm font-medium text-slate-700">Lot No.</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button"
                        class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none"
                        style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10"
                        id="exportModalSubmitBtn">
                        <i class="ti ti-download text-base"></i> Export
                    </button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile"
                        class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none"
                        style="display: none !important;"><i class="ti ti-download text-lg"></i> Download CSV</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Upcoming BMR/BPR Form Requests Modal -->
<div class="modal fade animate__animated fadeIn" id="upcomingBmrBprModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div
                class="modal-header relative flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                <div class="flex items-center gap-4">
                    <div
                        style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.5rem; height: 3.5rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                        <i class="ti ti-file-description"
                            style="font-size: 1.75rem; color: var(--appearance-accent, #7e22ce);"></i>
                        <span
                            style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                    </div>
                    <div>
                        <h5 class="modal-title m-0 font-bold leading-tight"
                            style="font-size: 1.25rem; color: var(--ui-text, #1e293b);">
                            Upcoming BMR/BPR Form Request Queue
                        </h5>
                        <p class="m-0 mt-1 font-medium"
                            style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">
                            Review production batches waiting for BMR/BPR form requests.
                        </p>
                    </div>
                </div>
                <button type="button"
                    class="ml-auto inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            <div class="modal-body p-0">
                <div class="w-full overflow-x-auto">
                    <table class="w-full border-collapse text-left">
                        <thead class="whitespace-nowrap border-b border-slate-100 bg-white">
                            <tr>
                                <th
                                    class="w-12 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    #
                                </th>
                                <th
                                    class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Date <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span>
                                </th>
                                <th
                                    class="min-w-[220px] px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Product Name <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span>
                                </th>
                                <th
                                    class="min-w-[150px] px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Lot # <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span>
                                </th>
                                <th
                                    class="w-36 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Batch Size <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span>
                                </th>
                                <th
                                    class="w-36 px-6 py-4 text-right text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody id="upcomingBmrBprTableBody"
                            class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                            <tr>
                                <td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-slate-500">
                                    Loading upcoming BMR/BPR form requests...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div
                    class="flex flex-col items-center justify-between border-t border-slate-200 bg-white px-6 py-4 md:flex-row">
                    <span id="upcomingBmrBprSummary" class="text-sm font-medium text-slate-500">
                        Showing 0 to 0 of 0 entries
                    </span>
                    <div class="flex items-center gap-1">
                        <button id="upcomingBmrBprPrev" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Previous page" disabled>
                            <i class="ti ti-arrow-left text-sm"></i>
                        </button>
                        <span id="upcomingBmrBprCurrentPage"
                            class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-sm font-bold text-white shadow-sm"
                            style="background-color: var(--appearance-accent, #7e22ce); box-shadow: 0 0 0 1px color-mix(in srgb, var(--appearance-accent, #7e22ce) 10%, transparent);">1</span>
                        <button id="upcomingBmrBprNext" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Next page" disabled>
                            <i class="ti ti-arrow-right text-sm"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    #bmrBprRequestModal {
        z-index: 1070 !important;
    }

    .modal-backdrop.bmr-bpr-request-backdrop {
        z-index: 1065 !important;
    }

    #bmrBprRequestModal .select2-container {
        width: 100% !important;
    }

    #bmrBprRequestModal .select2-container .select2-selection--single {
        height: 42px !important;
        border-radius: 0.75rem !important;
        border: 1px solid #cbd5e1 !important;
        padding: 6px 12px !important;
        background-color: #ffffff !important;
        display: flex !important;
        align-items: center !important;
    }

    #bmrBprRequestModal .select2-container--default .select2-selection--single .select2-selection__arrow {
        top: 8px !important;
        right: 10px !important;
    }

    #bmrBprRequestModal .bmr-bpr-template-dropdown.select2-dropdown--below {
        transform: translateY(calc(-100% - 46px));
    }

    #bmrBprRequestModal .select2-dropdown .select2-results > .select2-results__options {
        max-height: min(15rem, 40vh) !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        overscroll-behavior: contain;
    }

    #bmrBprRequestModal .select2-dropdown .select2-results__options--nested {
        max-height: none !important;
        overflow: visible !important;
    }

    #bmrBprRequestModal .select2-dropdown .select2-results__option {
        white-space: normal !important;
        word-break: break-word !important;
    }

    .select2-dropdown {
        z-index: 1080 !important;
        border-radius: 0.75rem !important;
        border: 1px solid #e2e8f0 !important;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05) !important;
    }

    .select2-results__group {
        font-size: 11px !important;
        font-weight: 700 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.05em !important;
        color: #64748b !important;
        padding: 6px 12px !important;
        background-color: #f8fafc !important;
        border-top: 1px solid #f1f5f9 !important;
    }
</style>

<!-- BMR/BPR Form Issuance Modal (UI only) -->
<div class="modal fade animate__animated fadeIn" id="bmrBprRequestModal" tabindex="-1" aria-hidden="true" aria-labelledby="bmrBprRequestModalTitle">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                        <i class="ti ti-clipboard-text text-xl"></i>
                    </span>
                    <div>
                        <h5 id="bmrBprRequestModalTitle" class="modal-title m-0 text-lg font-bold text-slate-900">
                            Request Form - BMR/BPR Form Issuance
                        </h5>
                        <p class="m-0 text-sm font-medium text-slate-500">
                            Confirm the requested forms for the selected production batch.
                        </p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-xl"></i>
                </button>
            </div>

            <form id="bmrBprRequestForm">
                <input type="hidden" id="bmrBprRequestId" value="">
                <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <div>
                            <label for="bmrBprRequestSerial" class="mb-1 block text-sm font-medium text-slate-800">Serial #</label>
                            <input type="text" id="bmrBprRequestSerial" class="input-theme bg-slate-50" readonly>
                        </div>
                        <div>
                            <label for="bmrBprRequestLot" class="mb-1 block text-sm font-medium text-slate-800">Lot #</label>
                            <input type="text" id="bmrBprRequestLot" class="input-theme bg-slate-50" readonly>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <div class="md:col-span-2">
                            <label for="bmrBprRequestProduct" class="mb-1 block text-sm font-medium text-slate-800">Product Name <strong class="text-rose-500">*</strong></label>
                            <select id="bmrBprRequestProduct" class="input-theme select2" required style="width: 100%;">
                                <option value="">Search / Select product...</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                        <div>
                            <label for="bmrBprRequestCategory" class="mb-1 block text-sm font-medium text-slate-800">CAT Number</label>
                            <input type="text" id="bmrBprRequestCategory" class="input-theme bg-slate-50" readonly>
                        </div>
                        <div>
                            <label for="bmrBprRequestBatchSize" class="mb-1 block text-sm font-medium text-slate-800">Batch Size <strong class="text-rose-500">*</strong></label>
                            <input type="number" id="bmrBprRequestBatchSize" class="input-theme" min="0.00000001" step="any" required readonly>
                        </div>
                        <div>
                            <label for="bmrBprRequestFormCount" class="mb-1 block text-sm font-medium text-slate-800">
                                No. of BMR/BPR Forms <strong class="text-rose-500">*</strong>
                            </label>
                            <input type="number" id="bmrBprRequestFormCount" class="input-theme" min="1" step="1" required>
                            <p id="bmrBprConfiguredCounts" class="mt-1 hidden text-xs font-semibold text-slate-500"></p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <div>
                            <label for="bmrBprRequestPackSize" class="mb-1 block text-sm font-medium text-slate-800">Pack Size</label>
                            <input type="text" id="bmrBprRequestPackSize" class="input-theme bg-slate-50" readonly>
                        </div>
                        <div>
                            <label for="bmrBprRequestRemarks" class="mb-1 block text-sm font-medium text-slate-800">Remarks</label>
                            <textarea id="bmrBprRequestRemarks" class="input-theme" rows="2" placeholder="Enter remarks for QA/QC"></textarea>
                        </div>
                    </div>

                    <div class="mt-4 pt-4 border-t border-slate-200">
                        <div class="flex items-center gap-2 mb-3">
                            <span class="inline-flex h-6 w-6 items-center justify-center rounded-lg bg-purple-50 text-purple-700 ring-1 ring-purple-100">
                                <i class="ti ti-file-text text-sm"></i>
                            </span>
                            <h6 class="m-0 text-xs font-bold uppercase tracking-wider text-slate-700">Document Template Specification</h6>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label for="bmrBprRequestBmrTemplate" class="mb-1 block text-sm font-bold text-slate-800">
                                    Select BMR <strong class="text-rose-500">*</strong>
                                </label>
                                <select id="bmrBprRequestBmrTemplate" class="input-theme select2" required style="width: 100%;">
                                    <option value="">Search BMR...</option>
                                </select>
                                <p id="bmrTemplateMatchBadge" class="mt-1 text-xs font-semibold text-emerald-600 hidden">
                                    <i class="ti ti-circle-check"></i> Exact product template mapping matched
                                </p>
                            </div>

                            <div>
                                <label for="bmrBprRequestBprTemplate" class="mb-1 block text-sm font-bold text-slate-800">
                                    Select BPR <strong class="text-rose-500">*</strong>
                                </label>
                                <select id="bmrBprRequestBprTemplate" class="input-theme select2" required style="width: 100%;">
                                    <option value="">Search BPR...</option>
                                </select>
                                <p id="bprTemplateMatchBadge" class="mt-1 text-xs font-semibold text-emerald-600 hidden">
                                    <i class="ti ti-circle-check"></i> Exact product template mapping matched
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                    <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-orange-500 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-orange-900/10 transition-colors hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500/30" style="background-color: #f2994a; border-color: #f2994a;">
                        <i class="ti ti-check text-lg"></i> Submit
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    (function () {
        'use strict';

        let bmrBprRequests = [];
        let bmrBprTemplates = { BMR: [], BPR: [] };
        let bmrBprMappedProducts = { BMR: [], BPR: [], all_products: [], template_products: { BMR: [], BPR: [] } };
        const bmrBprCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
        let currentPage = 1;
        let currentSortColumn = 'product_name';
        let currentSortDirection = 'asc';
        let currentUpcomingPage = 1;
        const upcomingPerPage = 5;

        function initTemplateSelect2() {
            $('#bmrBprRequestBmrTemplate, #bmrBprRequestBprTemplate').each(function () {
                const $select = $(this);
                const placeholder = $select.attr('id').includes('Bmr') ? 'Search BMR...' : 'Search BPR...';
                if ($select.hasClass('select2-hidden-accessible')) {
                    $select.select2('destroy');
                }
                $select.select2({
                    dropdownParent: $('#bmrBprRequestModal'),
                    dropdownCssClass: 'bmr-bpr-template-dropdown',
                    width: '100%',
                    placeholder: placeholder
                });
            });
        }

        function initProductSelect2() {
            const $prodSelect = $('#bmrBprRequestProduct');
            if ($prodSelect.hasClass('select2-hidden-accessible')) {
                $prodSelect.select2('destroy');
            }
            $prodSelect.select2({
                dropdownParent: $('#bmrBprRequestModal'),
                width: '100%',
                placeholder: 'Search / Select product...'
            });
        }

        function populateProductDropdown(selectedProductId = null, selectedPackSize = '', selectedProductName = '') {
            const $prodSelect = $('#bmrBprRequestProduct');
            const bmrList = bmrBprMappedProducts.BMR || [];
            const bprList = bmrBprMappedProducts.BPR || [];
            const allList = bmrBprMappedProducts.all_products || [];

            let html = '<option value="">Search / Select product...</option>';

            if (allList.length > 0) {
                let opts = '';
                allList.forEach(function (p) {
                    const isSel = selectedProductId && String(p.product_id) === String(selectedProductId);
                    const catCode = p.category_code ? ` [${escapeBmrBprText(p.category_code)}]` : '';
                    const bmrIds = (p.bmr_template_ids || []).join(',');
                    const bprIds = (p.bpr_template_ids || []).join(',');
                    opts += `<option value="${p.product_id}" data-cat="${escapeBmrBprText(p.category_code || '')}" data-pack="${escapeBmrBprText(p.pack_size || '')}" data-pack-key="${escapeBmrBprText(p.pack_size_key || '')}" data-bmr-ids="${bmrIds}" data-bpr-ids="${bprIds}" data-name="${escapeBmrBprText(p.product_name)}" ${isSel ? 'selected' : ''}>${escapeBmrBprText(p.product_name)}${catCode}</option>`;
                });
                html += `<optgroup label="📋 All Products (${allList.length})">${opts}</optgroup>`;
            }

            if (bmrList.length > 0) {
                let opts = '';
                bmrList.forEach(function (p) {
                    const catCode = p.category_code ? ` [${escapeBmrBprText(p.category_code)}]` : '';
                    opts += `<option value="${p.product_id}" data-cat="${escapeBmrBprText(p.category_code || '')}" data-pack="${escapeBmrBprText(p.pack_size || '')}" data-pack-key="${escapeBmrBprText(p.pack_size_key || '')}" data-bmr-ids="${p.template_id}" data-bpr-ids="" data-name="${escapeBmrBprText(p.product_name)}">🔬 ${escapeBmrBprText(p.product_name)}${catCode} → [${escapeBmrBprText(p.template_code)}]</option>`;
                });
                html += `<optgroup label="🔬 BMR Products (${bmrList.length} Mappings)">${opts}</optgroup>`;
            }

            if (bprList.length > 0) {
                let opts = '';
                bprList.forEach(function (p) {
                    const catCode = p.category_code ? ` [${escapeBmrBprText(p.category_code)}]` : '';
                    opts += `<option value="${p.product_id}" data-cat="${escapeBmrBprText(p.category_code || '')}" data-pack="${escapeBmrBprText(p.pack_size || '')}" data-pack-key="${escapeBmrBprText(p.pack_size_key || '')}" data-bmr-ids="" data-bpr-ids="${p.template_id}" data-name="${escapeBmrBprText(p.product_name)}">📦 ${escapeBmrBprText(p.product_name)}${catCode} → [${escapeBmrBprText(p.template_code)}]</option>`;
                });
                html += `<optgroup label="📦 BPR Products (${bprList.length} Mappings)">${opts}</optgroup>`;
            }

            if (selectedProductId && !html.includes(`value="${selectedProductId}"`)) {
                const customName = selectedProductName || `Product #${selectedProductId}`;
                html = `<option value="${selectedProductId}" selected>${escapeBmrBprText(customName)}</option>` + html;
            }

            $prodSelect.html(html);
            initProductSelect2();

            if (selectedProductId) {
                $prodSelect.val(String(selectedProductId)).trigger('change.select2');
            }
        }

        function populateBmrBprTemplateDropdowns(productId, exactTemplateIds = {}) {
            const bmrSelect = $('#bmrBprRequestBmrTemplate');
            const bprSelect = $('#bmrBprRequestBprTemplate');
            const templateProducts = bmrBprMappedProducts.template_products || {};
            const bmrList = templateProducts.BMR || [];
            const bprList = templateProducts.BPR || [];
            const exactBmrIds = new Set((exactTemplateIds.BMR || []).map(String));
            const exactBprIds = new Set((exactTemplateIds.BPR || []).map(String));

            function buildTemplateOptions(products, formType, exactIds) {
                const groupedProducts = {};
                let selectedOptionValue = '';
                let firstExactOptionValue = '';

                products.forEach(function (product) {
                    const templateId = String(product.template_id || '');
                    if (!templateId) return;

                    const groupKey = templateId;
                    if (!groupedProducts[groupKey]) {
                        groupedProducts[groupKey] = {
                            templateName: product.template_name || `${formType} Template`,
                            products: []
                        };
                    }

                    const optionValue = `${formType}-${product.mapping_id}`;
                    const isExact = exactIds.has(templateId);
                    if (!firstExactOptionValue && isExact) {
                        firstExactOptionValue = optionValue;
                    }
                    if (!selectedOptionValue && isExact && String(product.product_id) === String(productId || '')) {
                        selectedOptionValue = optionValue;
                    }

                    groupedProducts[groupKey].products.push({
                        optionValue: optionValue,
                        templateId: templateId,
                        productName: product.product_name || '',
                        isExact: isExact
                    });
                });

                let html = `<option value="">Search ${formType}...</option>`;
                Object.values(groupedProducts).forEach(function (group) {
                    let options = '';
                    group.products.forEach(function (product) {
                        options += `<option value="${escapeBmrBprText(product.optionValue)}" data-template-id="${escapeBmrBprText(product.templateId)}" data-exact="${product.isExact ? 1 : 0}">${escapeBmrBprText(product.productName)}</option>`;
                    });
                    html += `<optgroup label="${escapeBmrBprText(group.templateName)}">${options}</optgroup>`;
                });

                return {
                    html: html,
                    selectedOptionValue: selectedOptionValue || firstExactOptionValue
                };
            }

            const bmrRes = buildTemplateOptions(bmrList, 'BMR', exactBmrIds);
            const bprRes = buildTemplateOptions(bprList, 'BPR', exactBprIds);

            bmrSelect.html(bmrRes.html);
            bprSelect.html(bprRes.html);

            if (bmrRes.selectedOptionValue) {
                bmrSelect.val(bmrRes.selectedOptionValue);
                $('#bmrTemplateMatchBadge').removeClass('hidden');
            } else {
                bmrSelect.val('');
                $('#bmrTemplateMatchBadge').addClass('hidden');
            }

            if (bprRes.selectedOptionValue) {
                bprSelect.val(bprRes.selectedOptionValue);
                $('#bprTemplateMatchBadge').removeClass('hidden');
            } else {
                bprSelect.val('');
                $('#bprTemplateMatchBadge').addClass('hidden');
            }

            initTemplateSelect2();
        }

        function escapeBmrBprText(value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        }

        function requestSearchText(request) {
            return [
                request.product_name,
                request.category_code,
                request.batch_size,
                request.form_count,
                request.bmr_form_count,
                request.bpr_form_count,
                request.pack_size,
                request.lot_number
            ].join(' ').toLowerCase();
        }

        function filteredRequests() {
            const query = String($('#bmrBprSearch').val() || '').trim().toLowerCase();
            const rows = bmrBprRequests.filter(function (request) {
                return !query || requestSearchText(request).includes(query);
            });

            rows.sort(function (left, right) {
                const leftValue = left[currentSortColumn] == null ? '' : left[currentSortColumn];
                const rightValue = right[currentSortColumn] == null ? '' : right[currentSortColumn];
                const leftNumber = Number(leftValue);
                const rightNumber = Number(rightValue);
                let comparison;

                if (leftValue !== '' && rightValue !== '' && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) {
                    comparison = leftNumber - rightNumber;
                } else {
                    comparison = String(leftValue).localeCompare(String(rightValue), undefined, {
                        numeric: true,
                        sensitivity: 'base'
                    });
                }

                return currentSortDirection === 'asc' ? comparison : -comparison;
            });

            return rows;
        }

        function requestRow(request, serial) {
            return `<tr class="transition-colors hover:bg-slate-50/50">
                <td class="px-6 py-4 text-sm font-bold text-slate-900">${serial}</td>
                <td class="px-6 py-4 text-sm font-bold text-slate-900">${escapeBmrBprText(request.product_name || '-')}</td>
                <td class="px-6 py-4 text-sm font-medium text-slate-600">${escapeBmrBprText(request.category_code || '-')}</td>
                <td class="px-6 py-4 text-sm font-medium text-slate-600">${escapeBmrBprText(request.batch_size || '-')}</td>
                <td class="px-6 py-4 text-sm font-bold text-slate-900">${escapeBmrBprText(
                `${request.bmr_form_count || 0} BMR / ${request.bpr_form_count || 0} BPR`
            )}</td>
                <td class="px-6 py-4 text-sm font-medium text-slate-600">${escapeBmrBprText(request.pack_size || '-')}</td>
                <td class="px-6 py-4 text-sm font-medium text-slate-600">${escapeBmrBprText(request.lot_number || '-')}</td>
                <td class="px-6 py-4 text-right">
                    <div class="inline-flex items-center justify-end gap-2">
                        <button type="button" class="bmr-bpr-edit inline-flex h-8 w-8 items-center justify-center rounded-lg bg-amber-50 text-amber-600 ring-1 ring-amber-100 transition-colors hover:bg-amber-100" data-id="${escapeBmrBprText(request.id || '')}" title="Edit request" aria-label="Edit request">
                            <i class="ti ti-pencil text-base"></i>
                        </button>
                        <button type="button" class="bmr-bpr-delete inline-flex h-8 w-8 items-center justify-center rounded-lg bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition-colors hover:bg-rose-100" data-id="${escapeBmrBprText(request.id || '')}" title="Delete request" aria-label="Delete request">
                            <i class="ti ti-trash text-base"></i>
                        </button>
                    </div>
                </td>
            </tr>`;
        }

        function emptyTableRow(colspan, message) {
            return `<tr>
                <td colspan="${colspan}" class="px-6 py-12 text-center">
                    <div class="mx-auto flex max-w-sm flex-col items-center">
                        <span class="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-400">
                            <i class="ti ti-file-off text-2xl"></i>
                        </span>
                        <p class="m-0 text-sm font-bold text-slate-700">${escapeBmrBprText(message)}</p>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-400">New workflow records will appear here when generated.</p>
                    </div>
                </td>
            </tr>`;
        }

        function renderPagination(totalRows, perPage, totalPages) {
            const first = totalRows === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
            const last = totalRows === 0 ? 0 : Math.min(currentPage * perPage, totalRows);
            $('#bmrBprPaginationSummary').text(`Showing ${first} to ${last} of ${totalRows} entries`);

            const accent = 'var(--appearance-accent, #7e22ce)';
            const previousDisabled = currentPage <= 1 ? 'disabled' : '';
            const nextDisabled = currentPage >= totalPages ? 'disabled' : '';
            $('#bmrBprPagination').html(`
                <button type="button" id="bmrBprPreviousPage" ${previousDisabled}
                    class="inline-flex h-9 items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40">
                    <i class="ti ti-chevron-left"></i><span class="hidden sm:inline">Previous</span>
                </button>
                <span class="inline-flex h-9 min-w-9 items-center justify-center rounded-xl px-3 text-sm font-bold text-white shadow-sm" style="background-color: ${accent};">${currentPage}</span>
                <button type="button" id="bmrBprNextPage" ${nextDisabled}
                    class="inline-flex h-9 items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40">
                    <span class="hidden sm:inline">Next</span><i class="ti ti-chevron-right"></i>
                </button>
            `);
        }

        function renderBmrBprRequests() {
            const rows = filteredRequests();
            const perPage = Math.max(1, Number($('#bmrBprPerPage').val() || 10));
            const totalPages = Math.max(1, Math.ceil(rows.length / perPage));
            currentPage = Math.min(Math.max(1, currentPage), totalPages);
            const offset = (currentPage - 1) * perPage;
            const visibleRows = rows.slice(offset, offset + perPage);

            if (visibleRows.length === 0) {
                $('#bmrBprTableBody').html(emptyTableRow(8, 'No BMR/BPR form requests found.'));
            } else {
                $('#bmrBprTableBody').html(visibleRows.map(function (request, index) {
                    return requestRow(request, offset + index + 1);
                }).join(''));
            }

            $('#exportBmrBprRequests').prop('disabled', rows.length === 0);
            renderPagination(rows.length, perPage, totalPages);
        }

        function renderUpcomingRequests() {
            const pending = bmrBprRequests.filter(function (request) {
                return String(request.status_code || '').toUpperCase() === 'UPCOMING';
            });
            $('#upcomingBmrBprCount, #upcomingBmrBprCountText').text(pending.length);
            const totalPages = Math.max(1, Math.ceil(pending.length / upcomingPerPage));
            currentUpcomingPage = Math.min(Math.max(1, currentUpcomingPage), totalPages);
            const offset = (currentUpcomingPage - 1) * upcomingPerPage;
            const visibleRequests = pending.slice(offset, offset + upcomingPerPage);
            const first = pending.length === 0 ? 0 : offset + 1;
            const last = pending.length === 0 ? 0 : Math.min(offset + upcomingPerPage, pending.length);

            $('#upcomingBmrBprSummary').text(`Showing ${first} to ${last} of ${pending.length} entries`);
            $('#upcomingBmrBprCurrentPage').text(currentUpcomingPage);
            $('#upcomingBmrBprPrev').prop('disabled', currentUpcomingPage <= 1);
            $('#upcomingBmrBprNext').prop('disabled', currentUpcomingPage >= totalPages);

            if (visibleRequests.length === 0) {
                $('#upcomingBmrBprTableBody').html(emptyTableRow(6, 'No upcoming BMR/BPR form requests.'));
                return;
            }

            $('#upcomingBmrBprTableBody').html(visibleRequests.map(function (request, index) {
                return `<tr class="transition-colors hover:bg-slate-50/50">
                    <td class="px-6 py-4 text-sm font-bold text-slate-900">${offset + index + 1}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-600">${escapeBmrBprText(request.date || '-')}</td>
                    <td class="px-6 py-4 text-sm font-bold text-slate-900">${escapeBmrBprText(request.product_name || '-')}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-600">${escapeBmrBprText(request.lot_number || '-')}</td>
                    <td class="px-6 py-4 text-sm font-medium text-slate-600">${escapeBmrBprText(request.batch_size || '-')}</td>
                    <td class="px-6 py-4 text-right">
                        <button type="button" 
                            class="bmr-bpr-request-form biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-1.5 px-3 h-8 text-[11px]"
                            data-id="${escapeBmrBprText(request.id || '')}">
                            <i class="ti ti-file-plus text-sm"></i> Request Form
                        </button>
                    </td>
                </tr>`;
            }).join(''));
        }

        function notifyUiScaffold() {
            const message = 'Workflow requests are retained for audit and cannot be deleted from this screen.';
            if (window.toastr && typeof window.toastr.info === 'function') {
                window.toastr.info(message);
            }
        }

        function openBmrBprRequestModal(button) {
            const requestId = String($(button).data('id') || '');
            const requestIndex = bmrBprRequests.findIndex(function (request) {
                return String(request.id) === requestId;
            });
            if (requestIndex < 0) {
                notifyUiScaffold();
                return;
            }

            const request = bmrBprRequests[requestIndex];
            if (String(request.status_code || '').toUpperCase() !== 'UPCOMING') {
                toastr.info('This request has already been submitted and is read-only.');
                return;
            }
            $('#bmrBprRequestId').val(request.id || '');
            $('#bmrBprRequestSerial').val(request.request_no || requestIndex + 1);
            $('#bmrBprRequestLot').val(request.lot_number || '');
            $('#bmrBprRequestCategory').val(request.category_code || '');
            $('#bmrBprRequestBatchSize').val(request.batch_size_value || '');
            $('#bmrBprRequestFormCount').val(request.form_count || 1);
            $('#bmrBprRequestPackSize').val(request.pack_size || '');
            $('#bmrBprRequestRemarks').val(request.remarks || '');

            const prodName = request.product_name || '';
            const pSize = request.pack_size || '';

            populateProductDropdown(request.product_id, pSize, prodName);

            const hasConfiguration = Number(request.has_document_configuration || 0) === 1;
            if (hasConfiguration) {
                const bmrCount = Number(request.configured_bmr_form_count || 0);
                const bprCount = Number(request.configured_bpr_form_count || 0);
                $('#bmrBprRequestFormCount')
                    .val(bmrCount + bprCount)
                    .prop('readonly', true);
                $('#bmrBprConfiguredCounts')
                    .removeClass('hidden')
                    .text(`Product configuration: ${bmrCount} BMR document(s) and ${bprCount} BPR document(s).`);
            } else {
                $('#bmrBprRequestFormCount').prop('readonly', false);
                $('#bmrBprConfiguredCounts')
                    .removeClass('hidden')
                    .text('No product document configuration is available; the entered count is used for both types.');
            }

            populateBmrBprTemplateDropdowns(request.product_id, {
                BMR: request.exact_bmr_template_ids || [],
                BPR: request.exact_bpr_template_ids || []
            });

            $('#bmrBprRequestModal').data('source-product-id', request.product_id);
            $('#bmrBprRequestModal').data('source-batch-size', request.batch_size_value);

            const isUpcomingOpen = $('#upcomingBmrBprModal').hasClass('show');
            $('#bmrBprRequestModal').data('opened-from-upcoming', isUpcomingOpen);
            
            if (isUpcomingOpen) {
                $('#upcomingBmrBprModal').modal('hide');
                setTimeout(function() {
                    $('#bmrBprRequestModal').modal('show');
                }, 300);
            } else {
                $('#bmrBprRequestModal').modal('show');
            }
        }

        function loadBmrBprRequests(resetPage = true, silent = false) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    loadBmrBprFormRequests: 'loadBmrBprFormRequests',
                    csrf_token: bmrBprCsrf
                },
                success: function (response) {
                    if (response.status !== 'success') {
                        if (!silent) toastr.error(response.message || 'Unable to load BMR/BPR requests.');
                        return;
                    }
                    bmrBprRequests = response.data?.requests || [];
                    bmrBprTemplates = response.data?.templates || { BMR: [], BPR: [] };
                    bmrBprMappedProducts = response.data?.mapped_products || { BMR: [], BPR: [], all_products: [], template_products: { BMR: [], BPR: [] } };
                    if (resetPage) {
                        currentPage = 1;
                        currentUpcomingPage = 1;
                    }
                    renderBmrBprRequests();
                    renderUpcomingRequests();
                },
                error: function (xhr) {
                    if (silent) return;
                    const message = xhr.responseJSON?.message || 'Unable to load BMR/BPR requests.';
                    toastr.error(message);
                    bmrBprRequests = [];
                    bmrBprTemplates = { BMR: [], BPR: [] };
                    bmrBprMappedProducts = { BMR: [], BPR: [], all_products: [], template_products: { BMR: [], BPR: [] } };
                    renderBmrBprRequests();
                    renderUpcomingRequests();
                }
            });
        }

        function exportRequests() {
            const rows = filteredRequests();
            if (rows.length === 0) {
                notifyUiScaffold();
                return null;
            }

            const selectedCols = [];
            $('#exportModal input[name="listOfColumns[]"]:checked').each(function () {
                selectedCols.push($(this).val());
            });
            if (selectedCols.length === 0) {
                toastr.error('Select at least one column to export.');
                return null;
            }
            const effectiveCols = selectedCols;

            const columnGetters = {
                'S.No': (request, index) => index + 1,
                'Product Name': (request) => request.product_name || '',
                'Cat #': (request) => request.category_code || '',
                'Batch Size': (request) => request.batch_size || '',
                'No. of BMR/BPR Forms': (request) => `${request.bmr_form_count || 0} BMR / ${request.bpr_form_count || 0} BPR`,
                'Pack Size': (request) => request.pack_size || '',
                'Lot No.': (request) => request.lot_number || ''
            };

            const headerRow = effectiveCols;
            const dataRows = rows.map(function (request, index) {
                return effectiveCols.map(function (col) {
                    const getter = columnGetters[col];
                    return getter ? getter(request, index) : (request[col] || '');
                });
            });

            const csvRows = [headerRow, ...dataRows];
            const csv = csvRows.map(function (row) {
                return row.map(function (value) {
                    return `"${String(value).replace(/"/g, '""')}"`;
                }).join(',');
            }).join('\r\n');
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            return URL.createObjectURL(blob);
        }

        $(document).on('click', '#deselectAllColumnsBtn', function () {
            const allCheckboxes = $('#bmrBprExportForm .column-filter');
            const shouldSelect = allCheckboxes.filter(':checked').length === 0;
            allCheckboxes.prop('checked', shouldSelect).trigger('change');
        });

        $(document).on('change', '#bmrBprExportForm .column-filter', function () {
            const anySelected = $('#bmrBprExportForm .column-filter:checked').length > 0;
            $('#deselectAllColumnsBtn').text(anySelected ? 'Deselect All' : 'Select All');
            const downloadUrl = $('#downloadExortfile').attr('href');
            if (downloadUrl) URL.revokeObjectURL(downloadUrl);
            $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
            $('#exportModalSubmitBtn').show();
        });

        function refreshBmrBprRequests() {
            if (!document.hidden) {
                loadBmrBprRequests(false, true);
            }
        }

        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) refreshBmrBprRequests();
        });

        $(document).ready(function () {
            loadBmrBprRequests();
        });

        $(document).on('input search', '#bmrBprSearch', function () {
            currentPage = 1;
            renderBmrBprRequests();
        });

        $(document).on('click', '.bmr-bpr-per-page-item', function () {
            const value = String($(this).data('val'));
            $('#bmrBprPerPage').val(value);
            $('#bmrBprPerPageText').text(value === '100000000' ? 'All items' : `${value} items`);
            currentPage = 1;
            renderBmrBprRequests();
        });

        $(document).on('click', '.bmr-bpr-sortable', function () {
            const column = String($(this).data('column') || '');
            if (!column) return;
            if (currentSortColumn === column) {
                currentSortDirection = currentSortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                currentSortColumn = column;
                currentSortDirection = 'asc';
            }
            renderBmrBprRequests();
        });

        $(document).on('click', '#bmrBprPreviousPage', function () {
            if (currentPage > 1) {
                currentPage--;
                renderBmrBprRequests();
            }
        });

        $(document).on('click', '#bmrBprNextPage', function () {
            currentPage++;
            renderBmrBprRequests();
        });

        $(document).on('click keydown', '#upcomingBmrBprWidget', function (event) {
            if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
            if (event.type === 'keydown') event.preventDefault();
            currentUpcomingPage = 1;
            renderUpcomingRequests();
            $('#upcomingBmrBprModal').modal('show');
        });

        $(document).on('click', '#upcomingBmrBprPrev', function () {
            if (currentUpcomingPage > 1) {
                currentUpcomingPage--;
                renderUpcomingRequests();
            }
        });

        $(document).on('click', '#upcomingBmrBprNext', function () {
            currentUpcomingPage++;
            renderUpcomingRequests();
        });

        $(document).on('click', '.bmr-bpr-request-form', function (event) {
            event.preventDefault();
            event.stopPropagation();
            openBmrBprRequestModal(this);
        });

        $(document).on('shown.bs.modal', '#bmrBprRequestModal', function () {
            $('.modal-backdrop').last().addClass('bmr-bpr-request-backdrop');
            $('#bmrBprRequestFormCount').trigger('focus');
        });

        $(document).on('hidden.bs.modal', '#bmrBprRequestModal', function () {
            $('.modal-backdrop.bmr-bpr-request-backdrop').removeClass('bmr-bpr-request-backdrop');
            if ($('#bmrBprRequestModal').data('opened-from-upcoming')) {
                setTimeout(function() {
                    $('#upcomingBmrBprModal').modal('show');
                }, 300);
            }
        });

        $(document).on('change', '#bmrBprRequestProduct', function () {
            const $selected = $(this).find('option:selected');
            const productId = $(this).val();
            if (!productId) {
                return;
            }

            const catCode = $selected.data('cat') || '';
            const packSize = $selected.data('pack') || '';
            const prodName = $selected.data('name') || $selected.text() || '';
            const rawBmrIds = String($selected.data('bmr-ids') || '');
            const rawBprIds = String($selected.data('bpr-ids') || '');

            let bmrIds = rawBmrIds ? rawBmrIds.split(',').filter(Boolean) : [];
            let bprIds = rawBprIds ? rawBprIds.split(',').filter(Boolean) : [];

            if (catCode) {
                $('#bmrBprRequestCategory').val(catCode);
            }
            if (packSize) {
                $('#bmrBprRequestPackSize').val(packSize);
            }

            if (bmrIds.length === 0 || bprIds.length === 0) {
                const allList = bmrBprMappedProducts.all_products || [];
                const found = allList.find(p => String(p.product_id) === String(productId));
                if (found) {
                    if (bmrIds.length === 0) bmrIds = found.bmr_template_ids || [];
                    if (bprIds.length === 0) bprIds = found.bpr_template_ids || [];
                    if (!packSize && found.pack_size) $('#bmrBprRequestPackSize').val(found.pack_size);
                    if (!catCode && found.category_code) $('#bmrBprRequestCategory').val(found.category_code);
                }
            }

            populateBmrBprTemplateDropdowns(productId, {
                BMR: bmrIds,
                BPR: bprIds
            });
        });

        $(document).on('change', '#bmrBprRequestBmrTemplate', function () {
            const isExact = Number($(this).find('option:selected').data('exact') || 0) === 1;
            $('#bmrTemplateMatchBadge').toggleClass('hidden', !isExact);
        });

        $(document).on('change', '#bmrBprRequestBprTemplate', function () {
            const isExact = Number($(this).find('option:selected').data('exact') || 0) === 1;
            $('#bprTemplateMatchBadge').toggleClass('hidden', !isExact);
        });

        $(document).on('submit', '#bmrBprRequestForm', function (event) {
            event.preventDefault();
            const bmrTemplateId = $('#bmrBprRequestBmrTemplate option:selected').data('template-id');
            const bprTemplateId = $('#bmrBprRequestBprTemplate option:selected').data('template-id');
            if (!bmrTemplateId || !bprTemplateId) {
                toastr.error('Please select both a BMR and a BPR template specification.');
                return;
            }

            const formData = new FormData();
            formData.append('submitBmrBprFormRequest', 'submitBmrBprFormRequest');
            formData.append('csrf_token', bmrBprCsrf);
            formData.append('request_id', $('#bmrBprRequestId').val());
            const sourceProductId = $('#bmrBprRequestModal').data('source-product-id');
            const sourceBatchSize = $('#bmrBprRequestModal').data('source-batch-size');
            formData.append('product_id', sourceProductId || $('#bmrBprRequestProduct').val());
            formData.append('batch_size', sourceBatchSize || $('#bmrBprRequestBatchSize').val());
            formData.append('form_count', $('#bmrBprRequestFormCount').val());
            formData.append('bmr_template_id', bmrTemplateId);
            formData.append('bpr_template_id', bprTemplateId);
            formData.append('remarks', $('#bmrBprRequestRemarks').val());

            const $submitButton = $(this).find('button[type="submit"]');
            const originalHtml = $submitButton.html();
            $submitButton.prop('disabled', true)
                .html('<i class="ti ti-loader-2 animate-spin text-lg"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#bmrBprRequestModal').data('opened-from-upcoming', false);
                        $('#bmrBprRequestModal').modal('hide');
                        toastr.success(response.message);
                        loadBmrBprRequests();
                    } else {
                        toastr.error(response.message || 'Unable to submit the request.');
                    }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
                },
                complete: function () {
                    $submitButton.prop('disabled', false).html(originalHtml);
                }
            });
        });

        $('#bmrBprExportForm').on('submit', function (e) {
            e.preventDefault();
            const $submitBtn = $('#exportModalSubmitBtn');
            const originalHtml = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i>');

            setTimeout(function () {
                const url = exportRequests();
                if (url) {
                    $('#downloadExortfile')
                        .attr('href', url)
                        .attr('download', 'bmr-bpr-form-requests.csv')
                        .removeClass('hidden d-none')
                        .attr('style', 'display: inline-flex !important;');
                    toastr.success('File exported successfully.');
                    $submitBtn.hide();
                }
                $submitBtn.prop('disabled', false).html(originalHtml);
            }, 300);
        });

        $('#exportModal').on('hidden.bs.modal', function () {
            $('#downloadExortfile').addClass('hidden d-none').attr('style', 'display: none !important;');
            $('#exportModalSubmitBtn').show();
        });
        $(document).on('click', '.bmr-bpr-edit', function () {
            openBmrBprRequestModal(this);
        });
        $(document).on('click', '.bmr-bpr-delete', notifyUiScaffold);
    })();
</script>
<?php endSection(); ?>
