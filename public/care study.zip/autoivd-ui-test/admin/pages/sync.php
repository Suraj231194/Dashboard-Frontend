<style>
    .sync-page { color: var(--ui-text, #1f2937); }
    .sync-page .sync-panel { border: 1px solid #dfe9e3; border-radius: 14px; background: #fff; box-shadow: 0 5px 20px rgba(20, 70, 45, .06); }
    .sync-page .sync-flow { min-height: 270px; padding: 18px; }
    .sync-page .sync-stat-card { min-height: 126px; padding: 17px; }
    .sync-page .sync-stat-label { color: #718078; font-size: 9px; font-weight: 900; letter-spacing: .12em; text-transform: uppercase; }
    .sync-page .sync-stat-value { margin-top: 10px; color: #183f2b; font-size: 29px; line-height: 1; font-weight: 900; }
    .sync-page .sync-module-card { min-height: 174px; border: 1px solid #e1eae4; border-radius: 12px; background: #fff; padding: 15px; box-shadow: 0 3px 13px rgba(22, 70, 47, .05); }
    .sync-page .sync-module-icon { display: inline-flex; width: 34px; height: 34px; align-items: center; justify-content: center; border-radius: 9px; font-size: 17px; }
    .sync-page .sync-switch { position: relative; width: 34px; height: 19px; border: 0; border-radius: 999px; background: #cfd8d2; transition: background .2s ease; }
    .sync-page .sync-switch:after { content: ''; position: absolute; top: 3px; left: 3px; width: 13px; height: 13px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.2); transition: transform .2s ease; }
    .sync-page .sync-switch.is-on { background: var(--appearance-accent, #166534); }
    .sync-page .sync-switch.is-on:after { transform: translateX(15px); }
    .sync-page .sync-chip { display: inline-flex; align-items: center; border-radius: 999px; padding: 3px 8px; font-size: 9px; font-weight: 900; text-transform: uppercase; }
    .sync-page .sync-log-table { width: 100%; min-width: 920px; border-collapse: collapse; }
    .sync-page .sync-log-table th { padding: 11px 14px; border-bottom: 1px solid #e5ede8; background: #f9fbfa; color: #77837d; font-size: 9px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; }
    .sync-page .sync-log-table td { padding: 12px 14px; border-bottom: 1px solid #edf2ef; color: #415149; font-size: 11px; vertical-align: middle; }
</style>

<div class="sync-page container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1 class="m-0 text-2xl font-extrabold tracking-tight text-slate-800">Sync Settings</h1>
            <p class="mb-0 mt-1 text-sm text-slate-500">Monitor and control Website and ERP data flow from one dashboard.</p>
        </div>
        <button type="button" id="refreshSyncDashboard" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl border px-4 text-xs font-extrabold shadow-sm transition-colors" style="border-color: var(--color-primary-200, #bbf7d0); background: var(--color-primary-50, #f0fdf4); color: var(--appearance-accent, #166534);"><i class="ti ti-refresh"></i>Refresh dashboard</button>
    </div>

    <div id="syncSetupNotice" class="mb-4 hidden overflow-hidden rounded-xl border px-4 py-3 text-sm font-semibold"></div>
    <div id="syncActionNotice" class="mb-4 hidden overflow-hidden rounded-xl border px-4 py-3 text-sm font-semibold" role="status"></div>

    <div class="mb-4 grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,2fr)_minmax(245px,.8fr)]">
        <section class="sync-panel sync-flow">
            <div class="flex flex-wrap items-start justify-between gap-3">
                <div>
                    <div class="flex items-center gap-2 text-xs font-extrabold text-slate-700"><i class="ti ti-chart-line" style="color: var(--appearance-accent, #166534);"></i>Real-time data flow</div>
                    <div class="mt-1 text-[10px] text-slate-400"><span class="mr-3"><span class="mr-1 inline-block h-2 w-2 rounded-full" style="background: var(--appearance-accent, #166534);"></span>ERP to Website</span><span><span class="mr-1 inline-block h-2 w-2 rounded-full bg-sky-400"></span>Website to ERP</span></div>
                </div>
                <span id="syncGlobalStatus" class="sync-chip bg-slate-100 text-slate-600">Loading</span>
            </div>
            <svg class="mt-4 h-[155px] w-full" viewBox="0 0 720 170" preserveAspectRatio="none" aria-label="Recent sync direction activity">
                <g stroke="#e8efeb" stroke-width="1"><line x1="0" y1="30" x2="720" y2="30"/><line x1="0" y1="80" x2="720" y2="80"/><line x1="0" y1="130" x2="720" y2="130"/></g>
                <polyline id="erpWebsiteFlowLine" fill="none" stroke="var(--appearance-accent, #166534)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="0,130 720,130"/>
                <polyline id="websiteErpFlowLine" fill="none" stroke="#60a5fa" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="0,130 720,130"/>
            </svg>
            <div class="mt-2 flex flex-wrap items-end justify-between gap-3 border-t border-slate-100 pt-3">
                <div><div class="sync-stat-label">Total sync volume</div><div id="totalSyncVolume" class="mt-1 text-2xl font-black" style="color: var(--appearance-accent, #166534);">0</div></div>
                <div class="text-right"><div class="sync-stat-label">Last refreshed</div><div id="lastRefreshTime" class="mt-1 text-xs font-extrabold text-slate-600">--</div></div>
            </div>
        </section>
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-1">
            <section class="sync-panel sync-stat-card text-white" style="background: var(--appearance-accent, #166534); border-color: var(--appearance-accent, #166534);">
                <div class="flex items-center justify-between"><span class="!text-emerald-100 sync-stat-label">Success rate</span><i class="ti ti-circle-check text-lg text-emerald-200"></i></div>
                <div id="successRate" class="mt-3 text-3xl font-black">0%</div><div class="mt-2 text-[10px] text-emerald-100">Successful attempts across current activity</div>
            </section>
            <section class="sync-panel sync-stat-card">
                <div class="flex items-center justify-between"><span class="sync-stat-label">Sync alerts</span><i class="ti ti-alert-circle text-lg text-rose-500"></i></div>
                <div id="failedSyncCount" class="sync-stat-value">0</div><div class="mt-2 flex items-center gap-3 text-[10px]"><span class="font-bold text-amber-600"><span id="pendingSyncCount">0</span> pending</span><span class="font-bold text-rose-600">failed</span></div>
            </section>
        </div>
    </div>

    <section class="mb-4">
        <div class="mb-3 flex flex-wrap items-end justify-between gap-3">
            <div><h2 class="m-0 text-base font-extrabold text-slate-800">Sync modules</h2><p class="mb-0 mt-1 text-xs text-slate-500">Orders and Inventory are bidirectional. Customer, Meeting, Quiz, PI and Quotation modules pull Website data into ERP.</p></div>
            <div class="text-right"><div class="sync-stat-label">Enabled modules</div><div id="enabledModuleCount" class="mt-1 text-sm font-black" style="color: var(--appearance-accent, #166534);">0 / 7</div></div>
        </div>
        <div id="syncModulesGrid" class="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4"><div class="sync-module-card col-span-full flex items-center justify-center text-sm text-slate-400">Loading sync modules...</div></div>
    </section>

    <div class="sync-panel mb-4 flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between">
        <div class="flex items-center gap-3"><span class="inline-flex h-9 w-9 items-center justify-center rounded-full" style="background: var(--color-primary-50, #f0fdf4); color: var(--appearance-accent, #166534);"><i class="ti ti-heart-rate-monitor"></i></span><div><div class="text-[9px] font-black uppercase tracking-widest text-slate-400">Health status</div><div id="syncHealthText" class="mt-1 text-xs font-extrabold text-slate-700">Checking sync services...</div></div></div>
        <div class="flex flex-wrap items-center gap-2"><span id="syncHealthBadge" class="sync-chip bg-slate-100 text-slate-600">Checking</span><button type="button" id="forceSyncAll" class="inline-flex h-10 items-center gap-2 !rounded-xl px-4 text-xs font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534);"><i class="ti ti-bolt text-sm"></i>Run enabled pulls</button></div>
    </div>

    <section id="syncActivityPanel" class="sync-panel mb-4 overflow-hidden">
        <div class="flex flex-col gap-3 border-b border-slate-100 px-4 py-3 md:flex-row md:items-center">
            <div class="mr-auto"><h2 class="m-0 text-sm font-extrabold text-slate-800">Recent sync activity</h2><p id="syncLogSummary" class="mb-0 mt-1 text-[10px] text-slate-400">Latest matching attempts</p></div>
            <select id="syncEntityFilter" class="h-9 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700"><option value="">All modules</option><option value="orders">Orders</option><option value="inventory">Inventory</option><option value="users">Customer Management</option><option value="meetings">Meeting Requests</option><option value="quiz">Quiz Activity</option><option value="pi">PI Requests</option><option value="quotations">Quotation Requests</option></select>
            <select id="syncStatusFilter" class="h-9 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700"><option value="">All statuses</option><option value="success">Success</option><option value="pending">Pending</option><option value="failed">Failed</option></select>
        </div>
        <div class="w-full overflow-x-auto"><table class="sync-log-table"><thead><tr><th>Time</th><th>Module / ID</th><th>Direction</th><th>Status</th><th>Message</th><th class="text-center">Action</th></tr></thead><tbody id="syncLogsBody"><tr><td colspan="6" class="!py-9 text-center !text-slate-400">Loading activity...</td></tr></tbody></table></div>
    </section>

    <section class="sync-panel mb-4 overflow-hidden">
        <div class="flex flex-col gap-2 border-b border-slate-100 px-4 py-3 md:flex-row md:items-center md:justify-between">
            <div><h2 class="m-0 text-sm font-extrabold text-slate-800">Bio queue visibility</h2><p id="bioQueueSummary" class="mb-0 mt-1 text-[10px] text-slate-400">Checking Bio Order and Inventory queue jobs...</p></div>
            <div class="flex items-center gap-2"><span id="bioPendingBadge" class="sync-chip bg-amber-50 text-amber-700">0 pending</span><span id="bioFailedBadge" class="sync-chip bg-rose-50 text-rose-700">0 failed</span></div>
        </div>
        <div class="w-full overflow-x-auto"><table class="sync-log-table"><thead><tr><th>Bio time</th><th>Entity / Identifier</th><th>Status</th><th>Attempts</th><th>Last error</th><th class="text-center">Action</th></tr></thead><tbody id="bioQueueBody"><tr><td colspan="6" class="!py-9 text-center !text-slate-400">Loading Bio queue jobs...</td></tr></tbody></table></div>
    </section>

    <details class="sync-panel mb-4 overflow-hidden"><summary class="cursor-pointer bg-slate-50/70 px-5 py-3 text-xs font-extrabold text-slate-700">Legacy catalog sync tools</summary><div class="grid grid-cols-1 gap-4 p-5 md:grid-cols-2"><div class="rounded-xl border border-slate-200 p-4"><button type="button" id="btnSyncCategories" class="inline-flex h-9 items-center gap-2 !rounded-xl text-xs font-bold text-white shadow-sm transition-colors px-4" style="background: var(--appearance-accent, #166534);"><i class="ti ti-refresh"></i>Sync Categories</button><div id="syncCategoriesResult" class="mt-3 text-xs text-slate-600"></div></div><div class="rounded-xl border border-slate-200 p-4"><button type="button" id="btnSyncSubCategories" class="inline-flex h-9 items-center gap-2 !rounded-xl text-xs font-bold text-white shadow-sm transition-colors px-4" style="background: var(--appearance-accent, #166534);"><i class="ti ti-refresh"></i>Sync Sub Categories</button><div id="syncSubCategoriesResult" class="mt-3 text-xs text-slate-600"></div></div></div></details>
</div>

<?php startSection('scripts'); ?>
<script>
(function ($) {
    'use strict';

    var dashboardPermissions = { manage: false, retry: false };
    var pullEntities = ['users', 'meetings', 'quiz', 'pi', 'quotations'];
    var latestModules = [];
    var forceSyncRunning = false;
    var syncCsrfToken = $('meta[name="csrf-token"]').attr('content') || '';
    function syncPayload(data) { return $.extend({ csrf_token: syncCsrfToken }, data || {}); }
    var moduleMeta = {
        orders: { icon: 'ti-shopping-cart', iconClass: 'bg-emerald-50 text-emerald-700' },
        inventory: { icon: 'ti-building-warehouse', iconClass: 'bg-lime-50 text-lime-700' },
        users: { icon: 'ti-users', iconClass: 'bg-blue-50 text-blue-700' },
        meetings: { icon: 'ti-calendar-event', iconClass: 'bg-sky-50 text-sky-700' },
        quiz: { icon: 'ti-help-hexagon', iconClass: 'bg-indigo-50 text-indigo-700' },
        pi: { icon: 'ti-file-invoice', iconClass: 'bg-rose-50 text-rose-700' },
        quotations: { icon: 'ti-file-description', iconClass: 'bg-emerald-50 text-emerald-700' }
    };

    function escapeHtml(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function badge(status) {
        var styles = {
            success: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
            failed: 'bg-rose-50 text-rose-700 ring-rose-200',
            pending: 'bg-amber-50 text-amber-700 ring-amber-200',
            running: 'bg-sky-50 text-sky-700 ring-sky-200'
        };
        var key = status || 'pending';
        return '<span class="inline-flex rounded-full px-2.5 py-1 text-xs font-bold ring-1 ' +
            (styles[key] || styles.pending) + '">' + escapeHtml(key) + '</span>';
    }

    function directionLabel(direction) {
        return direction === 'bidirectional'
            ? '<span class="inline-flex items-center gap-1 text-sm font-bold text-indigo-700"><i class="ti ti-arrows-exchange"></i> Bidirectional</span>'
            : '<span class="inline-flex items-center gap-1 text-sm font-bold text-sky-700"><i class="ti ti-arrow-right"></i> Website to ERP</span>';
    }

    function showNotice(message, success) {
        $('#syncActionNotice')
            .removeClass('hidden border-emerald-200 bg-emerald-50 text-emerald-800 border-rose-200 bg-rose-50 text-rose-800')
            .addClass(success
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-rose-200 bg-rose-50 text-rose-800')
            .text(message);
    }

    function renderModules(modules, migrationReady) {
        var html = '';
        modules.forEach(function (module) {
            var enabled = Number(module.is_enabled) === 1;
            var lastRun = module.last_completed_at || module.last_started_at || 'Never';
            var actions = '';

            if (dashboardPermissions.manage && migrationReady) {
                actions += '<button type="button" class="sync-toggle inline-flex h-9 items-center justify-center !rounded-xl px-3 text-xs font-bold ' +
                    (enabled ? 'border border-slate-200 bg-white text-slate-700' : 'bg-emerald-700 text-white') +
                    '" data-entity="' + escapeHtml(module.entity_type) + '" data-enabled="' + (enabled ? '0' : '1') + '">' +
                    (enabled ? 'Disable' : 'Enable') + '</button>';
            }
            if (dashboardPermissions.manage && enabled && pullEntities.indexOf(module.entity_type) !== -1) {
                actions += '<button type="button" class="sync-pull ml-2 inline-flex h-9 items-center justify-center gap-1 !rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700" data-entity="' +
                    escapeHtml(module.entity_type) + '"><i class="ti ti-download"></i> Pull now</button>';
            }
            if (dashboardPermissions.manage && enabled && module.entity_type === 'inventory') {
                actions += '<button type="button" class="sync-inventory ml-2 inline-flex h-9 items-center justify-center gap-1 !rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700"><i class="ti ti-box"></i> Process pending</button>';
            }
            if (!actions) {
                actions = '<span class="text-xs text-slate-400">No action</span>';
            }

            html += '<tr>' +
                '<td class="px-6 py-4"><div class="font-bold text-slate-800">' + escapeHtml(module.display_name) + '</div><div class="mt-1 text-xs text-slate-400">' + escapeHtml(module.entity_type) + '</div></td>' +
                '<td class="px-6 py-4">' + directionLabel(module.direction) + '</td>' +
                '<td class="px-6 py-4">' + (enabled ? badge('success').replace('success', 'enabled') : '<span class="inline-flex rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600 ring-1 ring-slate-200">disabled</span>') + '</td>' +
                '<td class="px-6 py-4"><div class="text-sm font-semibold text-slate-700">' + escapeHtml(lastRun) + '</div><div class="mt-1 max-w-xs truncate text-xs text-slate-400" title="' + escapeHtml(module.last_message || '') + '">' + escapeHtml(module.last_message || '') + '</div></td>' +
                '<td class="px-6 py-4 text-xs font-semibold text-slate-600"><span class="text-emerald-700">' + Number(module.success_count) + ' success</span> · <span class="text-rose-700">' + Number(module.failed_count) + ' failed</span></td>' +
                '<td class="whitespace-nowrap px-6 py-4 text-center">' + actions + '</td>' +
                '</tr>';
        });
        $('#syncModulesBody').html(html || '<tr><td colspan="6" class="px-6 py-8 text-center text-sm text-slate-500">No modules found.</td></tr>');
    }

    function renderModuleCards(modules, migrationReady) {
        var html = '';
        latestModules = modules;
        modules.forEach(function (module) {
            var enabled = Number(module.is_enabled) === 1;
            var lastRun = module.last_completed_at || module.last_started_at || 'Never';
            var meta = moduleMeta[module.entity_type] || { icon: 'ti-refresh', iconClass: 'bg-slate-100 text-slate-600' };
            var totalEvents = Number(module.success_count || 0) + Number(module.failed_count || 0) + Number(module.pending_count || 0);
            var toggle = dashboardPermissions.manage && migrationReady
                ? '<button type="button" class="sync-toggle sync-switch ' + (enabled ? 'is-on' : '') + '" data-entity="' + escapeHtml(module.entity_type) + '" data-enabled="' + (enabled ? '0' : '1') + '" aria-label="' + (enabled ? 'Disable' : 'Enable') + ' ' + escapeHtml(module.display_name) + '"></button>'
                : '<span class="sync-switch ' + (enabled ? 'is-on' : '') + ' opacity-60"></span>';
            var actions = '';

            if (dashboardPermissions.manage && enabled && pullEntities.indexOf(module.entity_type) !== -1) {
                actions += '<button type="button" class="sync-pull inline-flex h-7 items-center gap-1 rounded-md border border-emerald-200 px-2 text-[9px] font-black uppercase text-emerald-700" data-entity="' + escapeHtml(module.entity_type) + '"><i class="ti ti-download"></i>Pull now</button>';
            }
            if (dashboardPermissions.manage && enabled && module.entity_type === 'inventory') {
                actions += '<button type="button" class="sync-inventory inline-flex h-7 items-center gap-1 rounded-md border border-emerald-200 px-2 text-[9px] font-black uppercase text-emerald-700"><i class="ti ti-box"></i>Process</button>';
            }

            html += '<article class="sync-module-card ' + (enabled ? '' : 'opacity-80') + '">' +
                '<div class="flex items-start justify-between gap-3"><span class="sync-module-icon ' + meta.iconClass + '"><i class="ti ' + meta.icon + '"></i></span>' + toggle + '</div>' +
                '<div class="mt-3 flex items-start justify-between gap-2"><div><h3 class="m-0 text-xs font-extrabold text-slate-800">' + escapeHtml(module.display_name) + '</h3><div class="mt-1 text-[9px] text-slate-400">' + escapeHtml(module.direction === 'bidirectional' ? 'ERP and Website' : 'Website to ERP') + '</div></div>' +
                '<span class="sync-chip ' + (enabled ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500') + '">' + (enabled ? 'Active' : 'Paused') + '</span></div>' +
                '<div class="mt-4 grid grid-cols-2 gap-3 border-t border-slate-100 pt-3"><div><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Events</div><div class="mt-1 text-sm font-black text-slate-700">' + totalEvents + '</div></div><div><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Last sync</div><div class="mt-1 truncate text-[10px] font-bold text-slate-600" title="' + escapeHtml(lastRun) + '">' + escapeHtml(lastRun) + '</div></div></div>' +
                '<div class="mt-3 flex min-h-[28px] items-center gap-2">' + (actions || '<span class="text-[9px] font-bold text-slate-400">' + Number(module.success_count || 0) + ' success / ' + Number(module.failed_count || 0) + ' failed</span>') + '</div>' +
                '</article>';
        });

        html += '<article class="sync-module-card flex flex-col justify-between bg-blue-50/60"><div><span class="sync-module-icon bg-blue-100 text-blue-700"><i class="ti ti-activity"></i></span><h3 class="mb-0 mt-3 text-xs font-extrabold text-slate-800">Activity logs</h3><p class="mb-0 mt-1 text-[10px] leading-4 text-slate-500"><span id="syncModuleLogCount">0</span> recent attempts available for review.</p></div><button type="button" class="scroll-sync-logs mt-4 inline-flex h-8 items-center justify-center gap-1 rounded-lg border border-blue-200 bg-white text-[9px] font-black uppercase text-blue-700"><i class="ti ti-list-details"></i>View logs</button></article>';
        html += '<article class="sync-module-card flex flex-col justify-between text-white" style="background: var(--appearance-accent, #166534); border-color: var(--appearance-accent, #166534);"><div><span class="sync-module-icon bg-white/15 text-white"><i class="ti ti-bolt"></i></span><h3 class="mb-0 mt-3 text-xs font-extrabold text-white">Force sync</h3><p class="mb-0 mt-1 text-[10px] leading-4 text-emerald-100">Run every enabled Website pull and process pending inventory.</p></div><button type="button" class="force-sync-trigger mt-4 inline-flex h-8 items-center justify-center gap-1 !rounded-xl bg-white text-[9px] font-black uppercase" style="color: var(--appearance-accent, #166534);"><i class="ti ti-player-play"></i>Run enabled</button></article>';
        $('#syncModulesGrid').html(html || '<div class="sync-module-card col-span-full flex items-center justify-center text-sm text-slate-400">No modules found.</div>');
    }

    function renderFlowChart(logs) {
        var entries = (logs.data || []).slice().reverse();
        var outbound = [0,0,0,0,0,0,0,0];
        var inbound = [0,0,0,0,0,0,0,0];
        entries.forEach(function (log, index) {
            var bucket = Math.min(7, Math.floor(index * 8 / Math.max(1, entries.length)));
            if (log.direction === 'outbound') outbound[bucket] += 1;
            if (log.direction === 'inbound') inbound[bucket] += 1;
        });
        var peak = Math.max(1, Math.max.apply(null, outbound.concat(inbound)));
        function points(values) {
            return values.map(function (value, index) {
                var x = index * (720 / 7);
                var y = 140 - ((value / peak) * 105);
                return x.toFixed(1) + ',' + y.toFixed(1);
            }).join(' ');
        }
        $('#erpWebsiteFlowLine').attr('points', points(outbound));
        $('#websiteErpFlowLine').attr('points', points(inbound));
    }

    function renderLogs(logs) {
        var html = '';
        (logs.data || []).forEach(function (log) {
            var retry = dashboardPermissions.retry && log.status === 'failed' && log.direction === 'outbound' && (log.entity_type === 'orders' || log.entity_type === 'inventory')
                ? '<button type="button" class="sync-retry inline-flex h-8 items-center justify-center gap-1 !rounded-xl border border-rose-200 bg-rose-50 px-3 text-xs font-bold text-rose-700" data-log-id="' + Number(log.id) + '"><i class="ti ti-refresh"></i> Retry</button>'
                : '<span class="text-xs text-slate-400">—</span>';
            html += '<tr>' +
                '<td class="whitespace-nowrap px-6 py-4 text-sm text-slate-600">' + escapeHtml(log.created_at || '') + '</td>' +
                '<td class="px-6 py-4"><div class="font-bold text-slate-800">' + escapeHtml(log.entity_type) + '</div><div class="text-xs text-slate-400">#' + escapeHtml(log.entity_id) + '</div></td>' +
                '<td class="px-6 py-4 text-sm font-semibold text-slate-600">' + escapeHtml(log.direction) + '</td>' +
                '<td class="px-6 py-4">' + badge(log.status) + '</td>' +
                '<td class="max-w-md px-6 py-4 text-sm text-slate-600"><div class="truncate" title="' + escapeHtml(log.error_message || '') + '">' + escapeHtml(log.error_message || (log.status === 'success' ? 'Completed' : '')) + '</div></td>' +
                '<td class="px-6 py-4 text-center">' + retry + '</td>' +
                '</tr>';
        });
        $('#syncLogsBody').html(html || '<tr><td colspan="6" class="px-6 py-8 text-center text-sm text-slate-500">No matching sync activity.</td></tr>');
        $('#syncLogSummary').text('Showing ' + (logs.data || []).length + ' of ' + Number(logs.total || 0) + ' matching attempts');
        $('#syncModuleLogCount').text(Number(logs.total || 0));
        renderFlowChart(logs);
    }

    function renderBioQueue(queue) {
        queue = queue || {};
        var summary = queue.summary || { pending: 0, failed: 0 };
        $('#bioPendingBadge').text(Number(summary.pending || 0) + ' pending');
        $('#bioFailedBadge').text(Number(summary.failed || 0) + ' failed');
        if (!queue.available) {
            $('#bioQueueSummary').text(queue.message || 'Bio queue visibility is unavailable.');
            $('#bioQueueBody').html('<tr><td colspan="6" class="px-6 py-8 text-center text-sm text-amber-700">' + escapeHtml(queue.message || 'Bio queue visibility is unavailable.') + '</td></tr>');
            return;
        }

        var jobs = (queue.failed || []).concat(queue.pending || []);
        var html = '';
        jobs.forEach(function (job) {
            var retry = dashboardPermissions.retry && job.status === 'failed' && job.retry_eligible
                ? '<button type="button" class="bio-queue-retry inline-flex h-8 items-center justify-center gap-1 !rounded-xl border border-rose-200 bg-rose-50 px-3 text-xs font-bold text-rose-700" data-uuid="' + escapeHtml(job.queue_reference || '') + '"><i class="ti ti-refresh"></i> Retry in Bio</button>'
                : '<span class="text-xs text-slate-400">-</span>';
            var eventTime = job.failed_at || job.available_at || job.created_at || '';
            html += '<tr>' +
                '<td class="whitespace-nowrap px-6 py-4 text-sm text-slate-600">' + escapeHtml(eventTime) + '</td>' +
                '<td class="px-6 py-4"><div class="font-bold text-slate-800">' + escapeHtml(job.entity_type || '') + '</div><div class="text-xs text-slate-400">' + escapeHtml(job.identifier || ('#' + Number(job.entity_id || 0))) + '</div></td>' +
                '<td class="px-6 py-4">' + badge(job.status || 'pending') + '</td>' +
                '<td class="px-6 py-4 text-sm font-bold text-slate-600">' + Number(job.attempt_count || 0) + '</td>' +
                '<td class="max-w-md px-6 py-4 text-sm text-slate-600"><div class="truncate" title="' + escapeHtml(job.last_error || '') + '">' + escapeHtml(job.last_error || (job.status === 'pending' ? 'Waiting in Bio queue' : 'No failure message')) + '</div></td>' +
                '<td class="px-6 py-4 text-center">' + retry + '</td>' +
                '</tr>';
        });
        $('#bioQueueBody').html(html || '<tr><td colspan="6" class="px-6 py-8 text-center text-sm text-slate-500">No pending or failed Bio Order/Inventory jobs.</td></tr>');
        $('#bioQueueSummary').text('Bio-side jobs are read through the secured sync-health API. Retries are executed by Bio.');
    }

    function loadDashboard() {
        $.ajax({
            url: 'syncAjax.php',
            method: 'POST',
            dataType: 'json',
            data: syncPayload({
                action: 'getSyncDashboard',
                entity_filter: $('#syncEntityFilter').val() || '',
                status_filter: $('#syncStatusFilter').val() || ''
            })
        }).done(function (response) {
            if (!response.success) {
                showNotice(response.message || 'Unable to load sync dashboard.', false);
                return;
            }
            var data = response.data;
            dashboardPermissions = data.permissions || dashboardPermissions;
            var summary = data.summary || { success: 0, pending: 0, failed: 0 };
            var bioQueue = data.bio_queue || { available: false, summary: { pending: 0, failed: 0 } };
            var bioSummary = bioQueue.summary || { pending: 0, failed: 0 };
            var totalVolume = Number(summary.success || 0) + Number(summary.pending || 0) + Number(summary.failed || 0);
            var successRate = totalVolume > 0 ? Math.round((Number(summary.success || 0) / totalVolume) * 100) : 100;
            $('#enabledModuleCount').text(Number(data.enabled_count || 0) + ' / 7');
            $('#successSyncCount').text(Number(summary.success || 0));
            $('#pendingSyncCount').text(Number(summary.pending || 0) + Number(bioSummary.pending || 0));
            $('#failedSyncCount').text(Number(summary.failed || 0) + Number(bioSummary.failed || 0));
            $('#totalSyncVolume').text(totalVolume.toLocaleString('en-IN'));
            $('#successRate').text(successRate + '%');
            $('#lastRefreshTime').text(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }));
            $('#syncGlobalStatus').removeClass('bg-slate-100 text-slate-600 bg-emerald-50 text-emerald-700').addClass(Number(data.enabled_count || 0) > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600').text(Number(data.enabled_count || 0) > 0 ? 'Live' : 'Standby');

            if (!data.migration_ready) {
                $('#syncSetupNotice').removeClass('hidden border-amber-200 bg-amber-50 text-amber-800')
                    .addClass('border-amber-200 bg-amber-50 text-amber-800')
                    .text('Setup required: review and apply the MANUVERSE sync files from admin/migrations. No migration has been executed by this implementation.');
            } else if (!data.configuration_ready.website_url || !data.configuration_ready.website_token) {
                $('#syncSetupNotice').removeClass('hidden border-amber-200 bg-amber-50 text-amber-800')
                    .addClass('border-amber-200 bg-amber-50 text-amber-800')
                    .text('Configuration required: WEBSITE_SYNC_BASE_URL and WEBSITE_SYNC_TOKEN must both be configured before enabling modules.');
            } else {
                $('#syncSetupNotice').removeClass('hidden border-emerald-200 bg-emerald-50 text-emerald-800')
                    .addClass('border-emerald-200 bg-emerald-50 text-emerald-800')
                    .text('Sync storage and ERP-to-Website credentials are configured. Enable only the modules whose website deployment is ready.');
            }

            var healthy = data.migration_ready && data.configuration_ready.website_url && data.configuration_ready.website_token && bioQueue.available;
            $('#syncHealthText').text(healthy ? 'Sync storage, ERP connection, and Bio queue visibility are ready.' : 'Sync setup or Bio queue visibility needs attention.');
            $('#syncHealthBadge').removeClass('bg-slate-100 text-slate-600 bg-emerald-50 text-emerald-700 bg-amber-50 text-amber-700').addClass(healthy ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700').text(healthy ? 'Healthy' : 'Attention');
            renderModuleCards(data.modules || [], data.migration_ready);
            renderLogs(data.logs || { total: 0, data: [] });
            renderBioQueue(bioQueue);
        }).fail(function (xhr) {
            var message = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Unable to load sync dashboard.';
            showNotice(message, false);
        });
    }

    $(document).on('click', '.sync-toggle', function () {
        var $button = $(this);
        $button.prop('disabled', true);
        $.post('syncAjax.php', syncPayload({
            action: 'updateSyncSetting',
            entity: $button.data('entity'),
            enabled: $button.data('enabled')
        }), null, 'json').done(function (response) {
            showNotice(response.message, response.success);
            loadDashboard();
        }).fail(function (xhr) {
            showNotice(xhr.responseJSON ? xhr.responseJSON.message : 'Unable to update setting.', false);
        }).always(function () {
            $button.prop('disabled', false);
        });
    });

    $(document).on('click', '.sync-pull', function () {
        var $button = $(this);
        $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Running');
        $.post('syncAjax.php', syncPayload({ action: 'triggerEntitySync', entity: $button.data('entity') }), null, 'json')
            .done(function (response) {
                showNotice(response.message, response.success);
                if (response.success === true) loadDashboard();
            }).fail(function (xhr) {
                showNotice(xhr.responseJSON ? xhr.responseJSON.message : 'Manual sync failed.', false);
            }).always(function () {
                $button.prop('disabled', false).html('<i class="ti ti-download"></i> Pull now');
            });
    });

    $(document).on('click', '.sync-retry', function () {
        var $button = $(this);
        $button.prop('disabled', true);
        $.post('syncAjax.php', syncPayload({ action: 'retrySyncLog', log_id: $button.data('log-id') }), null, 'json')
            .done(function (response) {
                showNotice(response.message, response.success);
                loadDashboard();
            }).fail(function (xhr) {
                showNotice(xhr.responseJSON ? xhr.responseJSON.message : 'Retry failed.', false);
            }).always(function () {
                $button.prop('disabled', false);
            });
    });

    $(document).on('click', '.bio-queue-retry', function () {
        var $button = $(this);
        $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Retrying');
        $.post('syncAjax.php', syncPayload({ action: 'retryBioQueueJob', uuid: $button.data('uuid') }), null, 'json')
            .done(function (response) {
                showNotice(response.message, response.success);
                loadDashboard();
            }).fail(function (xhr) {
                showNotice(xhr.responseJSON ? xhr.responseJSON.message : 'Bio retry failed.', false);
            }).always(function () {
                $button.prop('disabled', false).html('<i class="ti ti-refresh"></i> Retry in Bio');
            });
    });

    $(document).on('click', '.sync-inventory', function () {
        var $button = $(this);
        $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Running');
        $.post('syncAjax.php', syncPayload({ action: 'triggerInventorySync' }), null, 'json')
            .done(function (response) {
                showNotice(response.message, response.success);
                loadDashboard();
            }).fail(function (xhr) {
                showNotice(xhr.responseJSON ? xhr.responseJSON.message : 'Inventory sync failed.', false);
            }).always(function () {
                $button.prop('disabled', false).html('<i class="ti ti-box"></i> Process pending');
            });
    });

    $(document).on('click', '.scroll-sync-logs', function () {
        var panel = document.getElementById('syncActivityPanel');
        if (panel) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    $(document).on('click', '#forceSyncAll, .force-sync-trigger', function () {
        if (forceSyncRunning) return;
        if (!dashboardPermissions.manage) {
            showNotice('You do not have permission to run manual synchronization.', false);
            return;
        }

        var jobs = [];
        latestModules.forEach(function (module) {
            if (Number(module.is_enabled) !== 1) return;
            if (pullEntities.indexOf(module.entity_type) !== -1) {
                jobs.push({ action: 'triggerEntitySync', entity: module.entity_type });
            } else if (module.entity_type === 'inventory') {
                jobs.push({ action: 'triggerInventorySync' });
            }
        });

        if (!jobs.length) {
            showNotice('No enabled pull or inventory module is available to run.', false);
            return;
        }

        var $buttons = $('#forceSyncAll, .force-sync-trigger');
        var results = [];
        forceSyncRunning = true;
        $buttons.prop('disabled', true);
        showNotice('Running ' + jobs.length + ' enabled sync operation(s)...', true);

        function runNext(index) {
            if (index >= jobs.length) {
                var failed = results.filter(function (result) { return !result.success; }).length;
                showNotice('Enabled sync run completed: ' + (results.length - failed) + ' succeeded, ' + failed + ' failed.', failed === 0);
                forceSyncRunning = false;
                $buttons.prop('disabled', false);
                loadDashboard();
                return;
            }
            $.post('syncAjax.php', syncPayload(jobs[index]), null, 'json')
                .done(function (response) { results.push({ success: Boolean(response.success) }); })
                .fail(function () { results.push({ success: false }); })
                .always(function () { runNext(index + 1); });
        }
        runNext(0);
    });

    function bindLegacy(buttonSelector, action, resultSelector) {
        $(buttonSelector).on('click', function () {
            var $button = $(this);
            $button.prop('disabled', true);
            $(resultSelector).text('Syncing...');
            $.post('syncAjax.php', syncPayload({ action: action }), null, 'json').done(function (response) {
                if (response.website_to_erp && response.erp_to_website) {
                    $(resultSelector).html(
                        'ERP insert: ' + Number(response.website_to_erp.insert || 0) +
                        ' · ERP update: ' + Number(response.website_to_erp.update || 0) +
                        '<br>Website insert: ' + Number(response.erp_to_website.insert || 0) +
                        ' · Website update: ' + Number(response.erp_to_website.update || 0)
                    );
                } else {
                    $(resultSelector).text(response.message || 'Catalog sync finished.');
                }
            }).fail(function () {
                $(resultSelector).text('Catalog sync failed. Check server logs.');
            }).always(function () {
                $button.prop('disabled', false);
            });
        });
    }

    $('#refreshSyncDashboard').on('click', loadDashboard);
    $('#syncEntityFilter, #syncStatusFilter').on('change', loadDashboard);
    bindLegacy('#btnSyncCategories', 'syncCategories', '#syncCategoriesResult');
    bindLegacy('#btnSyncSubCategories', 'syncSubCategories', '#syncSubCategoriesResult');
    loadDashboard();
})(jQuery);
</script>
<?php endSection(); ?>
