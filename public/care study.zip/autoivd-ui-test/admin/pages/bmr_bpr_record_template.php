<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../workflow/bmr_bpr_common.php';

if (!isset($_SESSION['user_id']) || (int) $_SESSION['user_id'] <= 0) {
    http_response_code(401);
    exit('Your session has expired.');
}
if (!checkPermission('production_bmr_bpr_view', $conn)) {
    http_response_code(403);
    exit('You do not have permission to view this BMR/BPR record.');
}

$encryptedId = trim((string) ($_GET['id'] ?? ''));
$workItemId = $encryptedId === '' ? 0 : (int) base64_decrypt($encryptedId);
if ($workItemId <= 0) {
    http_response_code(400);
    exit('A valid BMR/BPR record is required.');
}

try {
    $form = bmrBprLoadWorkItemTemplate($conn, $workItemId);
} catch (Throwable $exception) {
    http_response_code(404);
    exit('The BMR/BPR record could not be found.');
}

if (empty($form['has_template'])) {
    http_response_code(422);
    exit('No approved product template is mapped to this BMR/BPR record.');
}

$layout = $form['layout'];
$sourceValues = $form['source_values'];
$payload = $form['form_payload'];
$savedFields = is_array($payload['fields'] ?? null) ? $payload['fields'] : [];
$customFields = is_array($payload['custom_fields'] ?? null) ? $payload['custom_fields'] : [];
$customByPage = [];
foreach ($customFields as $field) {
    $page = (int) ($field['page'] ?? 0);
    if ($page > 0) {
        $customByPage[$page][] = $field;
    }
}

$safeFilename = preg_replace(
    '/[^A-Za-z0-9_-]+/',
    '_',
    ($form['form_type'] ?? 'BMR')
    . '_'
    . ($sourceValues['product_name'] ?? 'Record')
    . '_'
    . ($sourceValues['batch_number'] ?? $workItemId)
);
$safeFilename = trim((string) $safeFilename, '_');
$triggerDownload = (string) ($_GET['triggerDownload'] ?? '') === '1';

if ((int) ($form['schema_version'] ?? 1) >= 2) {
    $structuredHtml = bmrBprRenderStructuredTemplate($form, false);
    if ($structuredHtml === '') {
        http_response_code(422);
        exit('The common BMR/BPR template profile is unavailable for this product.');
    }

    $documentHtml = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<title>' . htmlspecialchars($safeFilename, ENT_QUOTES, 'UTF-8') . '</title>'
        . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0;background:#e5e7eb}'
        . '@media print{html,body{background:#fff}}</style></head><body>'
        . $structuredHtml . '</body></html>';

    if ($triggerDownload) {
        require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
        $options = new Dompdf\Options();
        $options->set('isRemoteEnabled', false);
        $options->set('isHtml5ParserEnabled', true);
        $options->set('defaultFont', 'Helvetica');
        $dompdf = new Dompdf\Dompdf($options);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->loadHtml($documentHtml, 'UTF-8');
        $dompdf->render();
        $dompdf->stream(($safeFilename ?: 'BMR_BPR_Record') . '.pdf', ['Attachment' => true]);
        exit;
    }

    echo $documentHtml;
    exit;
}

function bmrBprTemplateFieldStyle(array $field): string
{
    $x = max(0, min(100, (float) ($field['x'] ?? 0)));
    $y = max(0, min(100, (float) ($field['y'] ?? 0)));
    $w = max(0.1, min(100 - $x, (float) ($field['w'] ?? 1)));
    $h = max(0.1, min(100 - $y, (float) ($field['h'] ?? 1)));
    $fontSize = max(7.0, min(13.0, $h * 5.2));
    $background = !empty($field['erase_background']) ? '#ffffff' : 'transparent';
    return sprintf(
        'left:%.5f%%;top:%.5f%%;width:%.5f%%;height:%.5f%%;font-size:%.2fpx;background:%s;',
        $x,
        $y,
        $w,
        $h,
        $fontSize,
        $background
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($safeFilename, ENT_QUOTES, 'UTF-8') ?></title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            background: #e5e7eb;
            font-family: Arial, Helvetica, sans-serif;
        }

        #bmrBprDownloadDocument {
            width: 794px;
            margin: 0 auto;
        }

        .bmr-bpr-pdf-page {
            position: relative;
            width: 794px;
            height: 1123px;
            overflow: hidden;
            background: #ffffff;
            page-break-after: always;
        }

        .bmr-bpr-pdf-page:last-child {
            page-break-after: auto;
        }

        .bmr-bpr-pdf-page > img {
            position: absolute;
            inset: 0;
            display: block;
            width: 100%;
            height: 100%;
        }

        .bmr-bpr-pdf-value {
            position: absolute;
            z-index: 2;
            display: flex;
            align-items: center;
            overflow: hidden;
            padding: 1px 3px;
            color: #000000;
            font-family: Arial, Helvetica, sans-serif;
            font-weight: 400;
            line-height: 1.08;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
        }

        .bmr-bpr-pdf-value.multiline {
            align-items: flex-start;
            padding-top: 2px;
        }

        @media screen {
            .bmr-bpr-pdf-page {
                margin-bottom: 20px;
                box-shadow: 0 8px 28px rgba(15, 23, 42, 0.18);
            }
        }
    </style>
</head>
<body>
    <main id="bmrBprDownloadDocument">
        <?php foreach (($layout['pages'] ?? []) as $page): ?>
            <?php $pageNumber = (int) ($page['page'] ?? 0); ?>
            <section class="bmr-bpr-pdf-page" data-page="<?= $pageNumber ?>">
                <img
                    src="<?= htmlspecialchars((string) ($page['image_url'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                    alt="<?= htmlspecialchars(($form['form_type'] ?? 'BMR') . ' page ' . $pageNumber, ENT_QUOTES, 'UTF-8') ?>">

                <?php foreach (($page['fields'] ?? []) as $field): ?>
                    <?php
                    $source = trim((string) ($field['source'] ?? ''));
                    $value = $source !== ''
                        ? (string) ($sourceValues[$source] ?? '')
                        : (string) ($savedFields[$field['id'] ?? ''] ?? '');
                    if ($value === '') {
                        continue;
                    }
                    ?>
                    <span
                        class="bmr-bpr-pdf-value<?= !empty($field['multiline']) ? ' multiline' : '' ?>"
                        style="<?= htmlspecialchars(bmrBprTemplateFieldStyle($field), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($value, ENT_QUOTES, 'UTF-8') ?></span>
                <?php endforeach; ?>

                <?php foreach (($customByPage[$pageNumber] ?? []) as $field): ?>
                    <span
                        class="bmr-bpr-pdf-value multiline"
                        style="<?= htmlspecialchars(bmrBprTemplateFieldStyle($field), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string) ($field['value'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
                <?php endforeach; ?>
            </section>
        <?php endforeach; ?>
    </main>

    <script>
        function fitBmrBprPdfValue(element) {
            const maximumFontSize = Number(element.dataset.maximumFontSize)
                || parseFloat(window.getComputedStyle(element).fontSize)
                || 13;
            const minimumFontSize = 4;
            let fontSize = maximumFontSize;

            element.dataset.maximumFontSize = String(maximumFontSize);
            element.style.fontSize = `${fontSize}px`;

            while (
                fontSize > minimumFontSize
                && (element.scrollWidth > element.clientWidth + 1 || element.scrollHeight > element.clientHeight + 1)
            ) {
                fontSize = Math.max(minimumFontSize, fontSize - 0.25);
                element.style.fontSize = `${fontSize}px`;
            }
        }

        window.addEventListener('load', function () {
            document.querySelectorAll('.bmr-bpr-pdf-value').forEach(fitBmrBprPdfValue);

            if (!<?= $triggerDownload ? 'true' : 'false' ?>) {
                return;
            }

            const element = document.getElementById('bmrBprDownloadDocument');
            const options = {
                margin: 0,
                filename: <?= json_encode(($safeFilename ?: 'BMR_BPR_Record') . '.pdf') ?>,
                image: {
                    type: 'jpeg',
                    quality: 0.98
                },
                html2canvas: {
                    scale: 1.95,
                    useCORS: true,
                    logging: false
                },
                jsPDF: {
                    unit: 'px',
                    format: [794, 1123],
                    orientation: 'portrait',
                    hotfixes: ['px_scaling']
                },
                pagebreak: {
                    mode: ['css', 'legacy']
                }
            };

            html2pdf().set(options).from(element).save().then(function () {
                window.close();
            });
        });
    </script>
</body>
</html>
