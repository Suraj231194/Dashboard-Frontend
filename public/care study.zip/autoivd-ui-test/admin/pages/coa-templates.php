<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage COA template categories, parameters, and status</p>
        </div>
    </div>
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="coaPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="coa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="coa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="coa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="coa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="coa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="coa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'coa_templates_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#addTemplateModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="category" data-order="asc">
                                <span class="inline-flex items-center gap-1">Category <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-56 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="product_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Product / Material <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-56 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-72 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Description</th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Status</th>
                            <th
                                class="w-48 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="productsTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addTemplateModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add COA
                                Template</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create template parameters and status</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addTempleteForm">
                    <div class="modal-body max-h-[70vh] overflow-y-auto bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="templateName" class="mb-1 block text-sm font-medium text-slate-800">Name
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="templateName" autocomplete="off" name="templateName"
                                    class="input-theme" placeholder="Enter Name" required />
                            </div>

                            <div>
                                <label for="templateDesciption"
                                    class="mb-1 block text-sm font-medium text-slate-800">Description</label>
                                <textarea id="templateDesciption" autocomplete="off" name="templateDesciption"
                                    class="input-theme" placeholder="Enter Description"></textarea>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800"
                                    for="productCategory">Product Category <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="productCategory" name="productCategory" class="input-theme productCategory select2"
                                    required>
                                    <option value="">Select Product Category</option>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800"
                                    for="templateProductId">Product / Material <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="templateProductId" name="templateProductId" class="input-theme select2"
                                    required disabled>
                                    <option value="">Select Product / Material</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-4 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
                            <div class="mb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <label class="mb-1 block text-sm font-semibold text-slate-800">Template Table
                                        Details</label>
                                </div>
                                <button type="button"
                                    class="inline-flex h-10 min-w-40 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addParameters"><i class="ti ti-plus text-lg"></i> <span
                                        class="whitespace-nowrap">Add Parameters</span></button>
                            </div>
                            <div id="templateParameters"></div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            type="radio" id="activStatus" name="templateStatus" value="1" required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            type="radio" id="inactiveStatus" name="templateStatus" value="0" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewCoaTemplateModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">View
                                COA Template</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review template details and parameters</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="viewCoaTemplate">
                    <div class="modal-body max-h-[70vh] overflow-y-auto bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editCoaTemplateModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Edit
                                COA Template</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update template fields and parameters</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editCoaTemplateForm">
                    <div class="modal-body max-h-[70vh] overflow-y-auto bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#productUnit").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadProductCategoryList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getProductCategoryList: 'getProductCategoryList'
            },
            success: function (response) {
                categoryOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                categoryOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $(".productCategory").html(optionsHtml).trigger('change');
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadTemplateProducts(categoryId, targetSelector) {
        const $target = $(targetSelector);
        $target.html('<option value="">Select Product / Material</option>').prop('disabled', true).trigger('change');
        if (!categoryId) return;

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadProductsByMaterialType: 'loadProductsByMaterialType',
                materialTypeId: categoryId
            },
            success: function (response) {
                response.forEach(product => {
                    $target.append(new Option(product.value, product.key, false, false));
                });
                $target.prop('disabled', false).trigger('change');
            },
            error: function () {
                toastr.error('Unable to load products for the selected category.');
            }
        });
    }

    $(document).on('change', '#productCategory', function () {
        loadTemplateProducts($(this).val(), '#templateProductId');
    });

    $(document).on('change', '[name="productCategoryEdit"]', function () {
        loadTemplateProducts($(this).val(), '#templateProductIdEdit');
    });


    function loadCoaTemplateTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#productsTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadCoaTemplates: 'loadCoaTemplates',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#productsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.totalRows || 0);
                const visibleRows = Number(response.visibleRows || 0);
                const perPageValue = parseInt(perPage, 10) || 10;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * perPageValue) + visibleRows, totalRows) : 0;

            },
            error: function () {
                $('#productsTableBody').html('<tr><td colspan="7" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    function bindEditCoaTemplateSelect2Scroll() {
        setTimeout(function() {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.editCoaTemplateModalScroll')
                .on('wheel.editCoaTemplateModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $('#editCoaTemplateModel .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $('#editCoaTemplateModel .select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    let productIndex = 0;
    $(document).ready(function () {
        loadCoaTemplateTable();
        loadStandardUnit();
        loadProductCategoryList();
        $('#addTemplateModal .select2').select2({ dropdownParent: $('#addTemplateModal') });
        $(document).on('select2:open', function(e) {
            if (!$(e.target).closest('#editCoaTemplateModel').length) return;
            bindEditCoaTemplateSelect2Scroll();
        });
        $('#editCoaTemplateModel .modal-body').on('scroll', function() {
            $('#editCoaTemplateModel .select2-hidden-accessible').select2('close');
        });
        $('#searchProducts').on('input', function () {
            loadCoaTemplateTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadCoaTemplateTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadCoaTemplateTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.coa-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#coaPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });


        $('#addParameters').click(function () {
            const productRow = `
            <div class="product-row mb-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm" data-index="${productIndex}">
                <div class="grid grid-cols-1 gap-3 md:grid-cols-12">
                    <div class="md:col-span-3">
                    <input type="text" name="srNo[]" class="input-theme" placeholder="Sr No" required />
                </div>
                    <div class="md:col-span-9">
                    <input type="text" name="tableHead[]" class="input-theme" placeholder="Parameter Head Name" />
                </div>
                    <div class="md:col-span-6">
                    <textarea name="parameter[]" rows="2" class="input-theme" placeholder="Parameter Value" required></textarea>
                </div>
                    <div class="md:col-span-5">
                    <textarea name="specification[]" rows="2" class="input-theme" placeholder="Specification Value" required></textarea>
                </div>
                    <div class="flex items-center md:col-span-1">
                    <button type="button" class="removeProductBtn inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none" title="Remove">
                        <span class="ti ti-trash text-base"></span>
                    </button>                    
                    </div>
                </div>
            </div>
            `;
            $('#templateParameters').append(productRow);
            productIndex++;
        });

        $('#templateParameters').on('click', '.removeProductBtn', function () {
            $(this).closest('.product-row').remove();
        });

        $('#addTemplateModal').on('hidden.bs.modal', function () {
            $('#addTempleteForm')[0].reset();
            $('#templateParameters').empty();
            productIndex = 0;
        });

        $('#addTempleteForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addTempleteForm');
            const formData = new FormData(form);
            formData.append('addCoaTemplate', 'addCoaTemplate'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#addTemplateModal').modal('hide');
                        $('#addTempleteForm')[0].reset();
                        loadCoaTemplateTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });

    $(document).on('click', '#addParametersEdit', function () {
        const productRow = `
        <div class="product-row mb-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm" data-index="${productIndex}">
            <div class="grid grid-cols-1 gap-3 md:grid-cols-12">
            <div class="md:col-span-3">
                <input type="hidden" name="coaItemIdEdit[]" value="" />
                <input type="text" name="srNoEdit[]" class="input-theme" placeholder="Sr No" required />
            </div>
            <div class="md:col-span-9">
                <input type="text" name="tableHeadEdit[]" class="input-theme" placeholder="Parameter Head Name" />
            </div>
            <div class="md:col-span-6">
                <textarea name="parameterEdit[]" rows="2" class="input-theme" placeholder="Parameter Value" required></textarea>
            </div>
            <div class="md:col-span-5">
                <textarea name="specificationEdit[]" rows="2" class="input-theme" placeholder="Specification Value" required></textarea>
            </div>
            <div class="flex items-center md:col-span-1">
                <button type="button" class="removeCoaItemBtn inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none" title="Remove">
                    <span class="ti ti-trash text-base"></span>
                </button>                    
            </div>
            </div>
        </div>
        `;
        $('#templateParametersEdit').append(productRow);
        productIndex++;
    });

    $(document).on('click', '.productEditModal', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editCoaTemplateForm').find('.modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchCoaTemplateRecord: 'fetchCoaTemplateRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editCoaTemplateModel').modal('show');
                        $('#editCoaTemplateForm').find('.modal-body').html(res.data);
                        $('#editCoaTemplateForm .select2').select2({
                            dropdownParent: $('#editCoaTemplateModel')
                        });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '.coaTemplateDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid template ID provided.',
                customClass: {
                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white',
                cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteCoaTemplateRecord: 'deleteCoaTemplateRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadCoaTemplateTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                            }
                        });
                    }
                });
            }
        });
    });

    $('#editCoaTemplateForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editCoaTemplateForm');
        const formData = new FormData(form);
        formData.append('updateCoaTemplateRecord', 'updateCoaTemplateRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editCoaTemplateModel').modal('hide');
                    $('#editCoaTemplateForm').find('modal-body').html();
                    loadCoaTemplateTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.viewCoaTemplateModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewCoaTemplate').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewCoaTemplateRecord: 'viewCoaTemplateRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#viewCoaTemplateModel').modal('show');
                        $('#viewCoaTemplate').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.removeCoaItemBtn', function (e) {
        e.preventDefault();
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            buttonClicked.closest('.product-row').remove();
            Swal.fire({
                icon: 'success',
                title: 'Removed !!',
                text: 'COA Template Item removed.',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white'
                }
            });
            return;
        }
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white',
                cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteCoaTemplateItemRecord: 'deleteCoaTemplateItemRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                            buttonClicked.closest('.product-row').remove();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                            }
                        });
                    }
                });
            }
        });
    });
    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadCoaTemplateTable(1);
    });

</script>
<?php endSection(); ?>
