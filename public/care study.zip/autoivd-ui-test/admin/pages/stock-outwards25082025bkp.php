<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="row col-md-12">
        <div class="card">
            <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                <div class="d-flex align-items-center gap-2">
                    <label for="perPageSelect" class="mb-0">Show</label>
                    <select id="perPageSelect" class="form-select form-select-sm w-auto">
                        <option value="5">5</option>
                        <option value="10" selected>10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <input type="text" id="searchUsers" class="form-control form-control-sm" placeholder="Search Data...">
                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_stock_outwards_add')) { ?>
                        <button type="button" class="btn btn-sm w-50 btn-success" id="animationModalBtn">Add New</button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr class="text-nowrap">
                            <th class="border-b border-slate-200 px-6 py-3">#</th>
                            <th class="table-col-200 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Client Name"> Client Name</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Place of Dispatch"> Place of Dispatch</th>
                            <th class="table-col-250 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Reciever Type"> Reciever Type</th>
                            <th class="table-col-200 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Type of Dispatch"> Type of Dispatch</th>
                            <th class="table-col-150 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Delivery Mode"> Delivery Mode</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Dispatched By"> Dispatched By</th>                            
                            <th class="border-b border-slate-200 px-6 py-3 table-col-250">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white" id="stockOutwardsTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">               
                <div class="modal-header d-flex-none">
                    <div class="d-flex flex-column">
                        <h5 class="modal-title mb-0" id="exampleModalLabel5">Add Stock Outward</h5>
                        <small class="text-muted">
                            This form is used to log every item dispatched from Biogenix's store, whether it's for clients, internal use at Labkem, or any external facility. Accurate and timely entries ensure real-time inventory tracking, smooth logistics coordination, and zero stock mismatches.
                           <br/><br/> Kindly fill this form <strong>immediately after dispatch,</strong> and make sure all details like quantity, date of dispatch, and delivery mode are entered correctly. this data will be used for:
                            <ul>
                                <li>Stock deduction</li>
                                <li>Delivery performance tracking</li>
                                <li>Client history logs, and</li>
                                <li>Dispatch auditing.</li>
                            </ul>
                        </small>
                    </div>
                    <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="addStockOutwardForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <small class="text-dark fw-medium d-block">Outward Type <strong class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input outward-type" type="radio" id="internalManufaturing" name="outwardType" value="1" required />
                                    <label class="form-check-label" for="internalManufaturing">Internal Manufacturing</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input outward-type" type="radio" id="externalDispatch" name="outwardType" value="2" />
                                    <label class="form-check-label" for="externalDispatch">External Dispatch</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3 d-none" id="internalDropdownRow">
                                <label class="form-label" for="manufacturingUnitDepartment">Department<strong class="text-danger">*</strong></label>
                                <select id="manufacturingUnitDepartment" name="manufacturingUnitDepartment" class="form-select">
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="clientName" class="form-label">Name of the Client <strong class="text-danger">*</strong></label>
                                <input type="text" id="clientName" autocomplete="off" name="clientName" class="form-control" placeholder="Enter client name" required />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="placeOfDispatch" class="form-label">Place of Dispatch (City/Country) <strong class="text-danger">*</strong></label>
                                <input type="text" id="placeOfDispatch" autocomplete="off" name="placeOfDispatch" class="form-control" placeholder="Enter place of dispatch" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="clientReceiverType" class="form-label">Client/Receiver Type <strong class="text-danger">*</strong></label>
                                <select name="clientReceiverType" id="clientReceiverType" class="form-control" required>
                                    <?php if (!empty(Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                    ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE'] as $crtkey => $crtval) {
                                            echo '<option value="' . $crtkey . '">' . $crtval . '</option>';
                                        ?>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3 d-none" id="clientReceiverTypeDetailsDiv">
                                <label for="clientReceiverTypeDetails" class="form-label">Client/Receiver Details <strong class="text-danger">*</strong></label>
                                <textarea id="clientReceiverTypeDetails" autocomplete="off" name="clientReceiverTypeDetails" class="form-control" placeholder="Enter details"></textarea>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="typeOfDispatch" class="form-label">Type Of Dispatched <strong class="text-danger">*</strong></label>
                                <select id="typeOfDispatch" name="typeOfDispatch" class="form-control">
                                     <?php if (!empty(Constant::STOCKS_OUTWARDS['TYPE_DISPATCH'])) {
                                        echo '<option value="">----Select----</option>';
                                    ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['TYPE_DISPATCH'] as $tdkey => $tdval) {
                                            echo '<option value="' . $tdkey . '">' . $tdval . '</option>';
                                        ?>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3 d-none" id="typeOfDispatchDetailsDiv">
                                <label for="typeOfDispatchDetails" class="form-label">Type Of Dispatched <strong class="text-danger">*</strong></label>
                                <textarea id="typeOfDispatchDetails" autocomplete="off" name="typeOfDispatchDetails" class="form-control" placeholder="Enter details"></textarea>
                            </div>
                        </div>                        
                        <div class="row">
                            <div class="col mb-2">
                                <label for="" class="form-label">Products Details</label>
                            </div>
                            <div id="productsWrapperWhole"></div>
                            <div class="mb-3">
                                <button type="button" class="btn btn-success btn-sm" id="addProductBtn">+ Add Product</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="deliveryMode" class="form-label">Delivery Mode <strong class="text-danger">*</strong></label>
                                <select id="deliveryMode" name="deliveryMode" class="form-control" required>
                                     <?php if (!empty(Constant::STOCKS_OUTWARDS['DELIVERY_MODE'])) {
                                        echo '<option value="">----Select----</option>';
                                    ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['DELIVERY_MODE'] as $dmkey => $dmval) {
                                            echo '<option value="' . $dmkey . '">' . $dmval . '</option>';
                                        ?>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="courierTransportService" class="form-label">Name of the Courier/Transport Service </label>
                                <select id="courierTransportService" name="courierTransportService" class="form-control">
                                     <?php if (!empty(Constant::STOCKS_OUTWARDS['COURIER_TRANSPORT_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                    ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['COURIER_TRANSPORT_TYPE'] as $tdkey => $tdval) {
                                            echo '<option value="' . $tdkey . '">' . $tdval . '</option>';
                                        ?>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="trackingId" class="form-label">Tracking ID</label>
                                <input type="text" id="trackingId" autocomplete="off" name="trackingId" class="form-control" placeholder="Enter tracking ID"  />
                            </div>                            
                            <div class="col-md-6 mb-3">
                                <label for="dispatchedBy" class="form-label">Dispatched By <strong class="text-danger">*</strong></label>
                                <select id="dispatchedBy" name="dispatchedBy" class="select2 form-select form-select-lg" data-allow-clear="true" required>
                                </select>
                            </div>    
                        </div>
                        <div class="row">    
                            <div class="col-md-6 mb-3">
                                <label for="remark" class="form-label">Remark</label>
                                <textarea id="remark" autocomplete="off" name="remark" class="form-control" placeholder="Enter Remark"></textarea>
                            </div>                        
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    
    <div class="modal fade animate__animated fadeIn" id="viewStockOutwardModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Stock Outward Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="viewStockOutward">
                    <div class="modal-body">                                    
                    </div>                  
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let productIndex = 0;

    function loadStocksOutwordTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadStocksOutword: 'loadStocksOutword',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function(response) {               
                $('#stockOutwardsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function() {
                $('#stockOutwardsTableBody').html('<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function(response) {
                qtyUnitOptions = response;
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadReceiverEmployeeOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadReceivedByEmpOption: 'loadReceivedByEmpOption'
            },
            dataType: 'json',
            success: function(response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function(prodCateg) {
                    html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                });
                $('#dispatchedBy').html(html).trigger('change');
            }
        });
    }
    
    function loadProductsCategoryTypeWithQuantity(materialTypeId) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                materialTypeId: materialTypeId,
                loadProductsCategoryTypeWithQuantity: 'loadProductsCategoryTypeWithQuantity'
            },
            dataType: 'json',
            success: function(response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function(product) {
                    html += `<option value="${product.key}">${product.value}</option>`;
                });
                $('#productsList').html(html).trigger('change');
            }
        });
    }

    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function(response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                departmentOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#manufacturingUnitDepartment").html(optionsHtml);
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    $(document).ready(function() {
        loadStocksOutwordTable();
        loadReceiverEmployeeOption();
        loadStandardUnit();
        $('#searchUsers').on('input', function() {
            loadStocksOutwordTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadStocksOutwordTable(1);
        });

        $('#animationModalBtn').on('click', function(){
            $('#animationModal').modal('show');
            if ($('.product-entry').length === 0) {
                $('#addProductBtn').trigger('click');
            }
        });

        $(".outward-type").on("change", function () {
                loadDepartmentsList();
            if ($("#internalManufaturing").is(":checked")) {
                $("#internalDropdownRow").removeClass("d-none");
                $("#manufacturingUnitDepartment").attr("required", true);
            } else {
                $("#manufacturingUnitDepartment").html();
                $("#internalDropdownRow").addClass("d-none");
                $("#manufacturingUnitDepartment").removeAttr("required").val("");
            }
        });
        $('#clientReceiverType').on('change', function(){
            let clientRecType = <?php echo Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE_LABEL']['Other']; ?>;
            let selectedOption = $(this).val();
            if(clientRecType == selectedOption)
            {
                $("#clientReceiverTypeDetailsDiv").removeClass("d-none");
                $("#clientReceiverTypeDetails").attr("required", true);
            } else {
                $("#clientReceiverTypeDetailsDiv").addClass("d-none");
                $("#clientReceiverTypeDetails").removeAttr("required").val("");
            }
        });
        
        $('#typeOfDispatch').on('change', function(){
            let clientRecType = <?php echo Constant::STOCKS_OUTWARDS['TYPE_DISPATCH_LABEL']['Other']; ?>;
            let selectedOption = $(this).val();
            if(clientRecType == selectedOption)
            {
                $("#typeOfDispatchDetailsDiv").removeClass("d-none");
                $("#typeOfDispatchDetails").attr("required", true);
            } else {
                $("#typeOfDispatchDetailsDiv").addClass("d-none");
                $("#typeOfDispatchDetails").removeAttr("required").val("");
            }
        });

        $('#addProductBtn').click(function() {
            let qtyUnitHtml = '<option value="">----Select----</option>';
            qtyUnitOptions.forEach(unit => {
                qtyUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });

            const productBlock = `
            <div class="row product-entry mb-2 border rounded p-2" data-index="${productIndex}">
                <div class="col-md-3 mb-2">
                    <label class="form-label">Product Category</label>
                    <select name="materialTypeList[]" class="select2 form-select form-select-lg materialTypeList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Product</label>
                    <select name="productsList[]" class="select2 form-select form-select-lg productsList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Available Quantity</label>
                    <input type="number" step="any" min="0" name="availableQuantity[]" class="form-control availableQuantity" readonly />
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Quantity</label>
                    <input type="number" step="any" min="0" name="prodQuantity[]" class="form-control" placeholder="Enter Quantity" required />
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Quantity Unit</label>
                    <select name="prodQuantityUnit[]" class="form-control" required>
                        ${qtyUnitHtml}
                    </select>
                </div>   
                <div class="col-md-3 mb-2">
                    <label class="form-label">Enter LOT No.</label>
                    <input type="text" name="lotNumber[]" class="form-control" placeholder="Enter LOT No." />
                </div>
                <div class="col-md-4 mb-3">
                    <label for="itemRemark" class="form-label">Remark</label>
                    <textarea id="itemRemark" rows="1" autocomplete="off" name="itemRemark[]" class="form-control" placeholder="Enter Remark"></textarea>
                </div>
                <div class="col-md-3 mb-2 d-flex align-items-end">
                    <button type="button" class="btn btn-icon btn-label-danger removeProductBtn"><span class="ti ti-trash"></span></button>               
                </div>
            </div>`;

            $('#productsWrapperWhole').append(productBlock);

            // Initialize Select2 on new fields
            $('#productsWrapperWhole .select2').select2({
                placeholder: '----Select Option----',
                dropdownParent: $('#productsWrapperWhole')
            });

            // Load material types in the new block
            const $newMaterialSelect = $(`.product-entry[data-index="${productIndex}"] .materialTypeList`);
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadProductCategoryStockOutwardOption: 'loadProductCategoryStockOutwardOption'
                },
                dataType: 'json',
                success: function(response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function(item) {
                        html += `<option value="${item.key}">${item.value}</option>`;
                    });
                    $newMaterialSelect.html(html).trigger('change');
                }
            });

            productIndex++;
        });

        $('#addStockOutwardForm').on('submit', function(e) {
            e.preventDefault();

            const form = document.getElementById('addStockOutwardForm');
            const formData = new FormData(form);
            formData.append('addStockOutward', 'addStockOutward'); 

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function(response) {
                    
                    if (response.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addStockOutwardForm')[0].reset();
                        loadStocksOutwordTable();
                        toastr.success(response.message);
                    } else if (response.status === 'error') {
                        toastr.error(response.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });

    $(document).on('click', '.removeProductBtn', function() {
        $(this).closest('.product-entry').remove();
    });

    $(document).on('change', '.materialTypeList', function() {
        const $parentRow = $(this).closest('.product-entry');
        const $productSelect = $parentRow.find('.productsList');
        const materialTypeId = $(this).val();

        if (materialTypeId) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    materialTypeId: materialTypeId,
                    loadProductsCategoryTypeWithQuantity: 'loadProductsCategoryTypeWithQuantity'
                },
                dataType: 'json',
                success: function(response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function(product) {
                        html += `<option value="${product.key}" data-quantity="${product.total_quantity}">${product.value}</option>`;
                    });
                    $productSelect.html(html).trigger('change');
                }
            });
        } else {
            $productSelect.html('<option value="">----Select Option----</option>').trigger('change');
        }
    });
    $(document).on('change', '.productsList', function() {
        const $parentRow = $(this).closest('.product-entry');
        const selectedOption = $(this).find(':selected');
        const qty = selectedOption.data('quantity') || 0;       
        $parentRow.find('.availableQuantity').val(qty);
    });

    $(document).on('click', '.outwardStocksDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteStockOutward: 'deleteStockOutward',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadStocksOutwordTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click','.outwardStocksViewModalBtn', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#viewStockOutward').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {viewStockOutwardRecord:'viewStockOutwardRecord', id:id},               
            success: function (res) {
                if (res.status === 'success') {
                    $('#viewStockOutwardModel').modal('show');
                    $('#viewStockOutward').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

</script>
<?php endSection(); ?>
