<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage and track employee attendance summary</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">

                    <div class="flex items-center gap-2 px-2 shrink-0">
                        <label for="monthAttSum" class="text-sm font-medium text-slate-700 m-0">Month:</label>
                        <input type="text" name="monthAttSum" id="monthAttSum" value="<?= date('Y-m') ?>"
                            class="flatpickr-month h-10 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-colors hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" />
                    </div>

                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="attendanceSummaryPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="attendance-summary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="attendance-summary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="attendance-summary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="attendance-summary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="attendance-summary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="attendance-summary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchAttSum"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <div class="flex flex-wrap md:flex-nowrap items-center gap-2 shrink-0 w-full md:w-auto">
                        <div class="dropdown w-[calc(50%-0.25rem)] md:w-auto">
                            <button type="button"
                                class="inline-flex w-full md:w-auto h-10 items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                data-bs-toggle="dropdown">
                                <span class="whitespace-nowrap">Company</span><i
                                    class="ti ti-chevron-down text-slate-400"></i>
                            </button>
                            <div class="dropdown-menu p-2 shadow-lg rounded-xl border border-slate-100">
                                <?php if (!empty(Constant::EMPLOYEES['COMPANY_TYPE'])) { ?>
                                    <label
                                        class="dropdown-item flex items-center gap-2 rounded-lg hover:bg-slate-50 cursor-pointer py-1.5 px-3">
                                        <input type="checkbox"
                                            class="company-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-600"
                                            value="all"> All
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['COMPANY_TYPE'] as $ctpckey => $ctpcval) { ?>
                                        <label
                                            class="dropdown-item flex items-center gap-2 rounded-lg hover:bg-slate-50 cursor-pointer py-1.5 px-3">
                                            <input type="checkbox"
                                                class="company-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-600"
                                                value="<?php echo $ctpckey; ?>"> <?php echo $ctpcval; ?>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>

                        <div class="dropdown w-[calc(50%-0.25rem)] md:w-auto">
                            <button type="button"
                                class="inline-flex w-full md:w-auto h-10 items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                data-bs-toggle="dropdown">
                                <span class="whitespace-nowrap">Status</span><i
                                    class="ti ti-chevron-down text-slate-400"></i>
                            </button>
                            <div class="dropdown-menu p-2 shadow-lg rounded-xl border border-slate-100">
                                <?php if (!empty(Constant::EMPLOYEES['STATUS_TYPES'])) { ?>
                                    <label
                                        class="dropdown-item flex items-center gap-2 rounded-lg hover:bg-slate-50 cursor-pointer py-1.5 px-3">
                                        <input type="checkbox"
                                            class="status-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-600"
                                            value="all"> All
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['STATUS_TYPES'] as $sfpckey => $sfpcval) { ?>
                                        <label
                                            class="dropdown-item flex items-center gap-2 rounded-lg hover:bg-slate-50 cursor-pointer py-1.5 px-3">
                                            <input type="checkbox"
                                                class="status-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-600"
                                                value="<?php echo $sfpckey; ?>"> <?php echo $sfpcval['label']; ?>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>

                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex w-full md:w-auto h-10 items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                data-bs-toggle="dropdown">
                                <span class="whitespace-nowrap">Category</span><i
                                    class="ti ti-chevron-down text-slate-400"></i>
                            </button>
                            <div class="dropdown-menu p-2 shadow-lg rounded-xl border border-slate-100">
                                <?php if (!empty(Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'])) { ?>
                                    <label
                                        class="dropdown-item flex items-center gap-2 rounded-lg hover:bg-slate-50 cursor-pointer py-1.5 px-3">
                                        <input type="checkbox"
                                            class="category-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-600"
                                            value="all"> All
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'] as $sipckey => $sipcval) { ?>
                                        <label
                                            class="dropdown-item flex items-center gap-2 rounded-lg hover:bg-slate-50 cursor-pointer py-1.5 px-3">
                                            <input type="checkbox"
                                                class="category-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-600"
                                                value="<?php echo $sipckey; ?>"> <?php echo $sipcval['label']; ?>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="border-b border-slate-200 bg-slate-50/50 px-6 py-2" id="legendData"></div>

            <div class="overflow-x-auto border-t border-slate-200">
                <table class="w-full min-w-max table-auto whitespace-nowrap text-left text-sm text-slate-600"
                    id="attendanceSummaryTableBody">
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let selectedCategoryType = [];
    let selectedStatusFilters = [];
    let selectedCompanyFilters = [];
    let currentSortColumn = 'id';
    let currentSortOrder = 'DESC';

    function loadAttendanceSummaryTable(page = 1) {
        currentPage = page;
        const search = $('#searchAttSum').val().trim();
        const perPage = $('#perPageSelect').val();
        const monthAttSum = $('#monthAttSum').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadAttendanceSummary: 'loadAttendanceSummary',
                page: page,
                per_page: perPage,
                search: search,
                monthAttSum: monthAttSum,
                categoryType: selectedCategoryType,
                selectedStatus: selectedStatusFilters,
                selectedCompany: selectedCompanyFilters,
                sort_by: currentSortColumn,
                sort_dir: currentSortOrder
            },
            success: function (response) {
                // Dispose existing tooltips to prevent orphaned popovers
                $('#attendanceSummaryTableBody [data-bs-toggle="tooltip"]').each(function() {
                    let tooltip = bootstrap.Tooltip.getInstance(this);
                    if (tooltip) tooltip.dispose();
                });

                $('#legendData').html(response.legend || '');
                $('#attendanceSummaryTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');

                // Initialize new tooltips
                $('#attendanceSummaryTableBody [data-bs-toggle="tooltip"]').each(function() {
                    new bootstrap.Tooltip(this);
                });
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');

                const visibleRows = Number(response.visibleRows || 0);
                const totalRows = Number(response.totalRows || 0);
                if (response.visibleRows !== undefined) {
                    const shownThrough = Math.min(currentPage * parseInt(perPage === 'all' ? totalRows : perPage), totalRows);
                    $('#paginationSummary').text(`Showing ${shownThrough > 0 ? ((currentPage - 1) * parseInt(perPage === 'all' ? totalRows : perPage)) + 1 : 0} to ${shownThrough} of ${totalRows} results`);
                }
            },
            error: function () {
                $('#attendanceSummaryTableBody').html('<tr><td colspan="35" class="px-6 py-10 text-center font-medium text-rose-500">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    $(document).ready(function () {
        if ($('.flatpickr-month').length) {
            $('.flatpickr-month').flatpickr({
                dateFormat: 'Y-m',
                disableMobile: "true"
            });
        }

        $(".category-filter").prop("checked", true);
        $(".status-filter").prop("checked", true);
        $(".company-filter").prop("checked", true);

        selectedCategoryType = [];
        $(".category-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCategoryType.push($(this).val());
            }
        });

        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });
        selectedCompanyFilters = [];
        $(".company-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCompanyFilters.push($(this).val());
            }
        });
        loadAttendanceSummaryTable();
        $('#searchAttSum').on('input', function () {
            loadAttendanceSummaryTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadAttendanceSummaryTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadAttendanceSummaryTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.attendance-summary-per-page-item', function () {
            const val = $(this).data('val');
            $('#attendanceSummaryPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        $('#monthAttSum').on('change', function () {
            loadAttendanceSummaryTable(1);
        });
    });

    $(document).on('change', '.category-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".category-filter").prop("checked", allChecked);
        }

        selectedCategoryType = [];
        $(".category-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCategoryType.push($(this).val());
            }
        });
        loadAttendanceSummaryTable(1);
    });

    $(document).on('change', '.status-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".status-filter").prop("checked", allChecked);
        }

        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });

        loadAttendanceSummaryTable(1);
    });

    $(document).on('change', '.company-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".company-filter").prop("checked", allChecked);
        }

        selectedCompanyFilters = [];
        $(".company-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCompanyFilters.push($(this).val());
            }
        });

        loadAttendanceSummaryTable(1);
    });



    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
        loadAttendanceSummaryTable(1);
    });
</script>
<?php endSection(); ?>
