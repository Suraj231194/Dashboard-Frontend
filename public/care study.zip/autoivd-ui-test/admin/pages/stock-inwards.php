<?php
$warehouses = [];
$whRes = $conn->query("SELECT id, warehouse_name FROM erp_warehouses WHERE status != 3 ORDER BY warehouse_name ASC");
if ($whRes) {
    while ($whRow = $whRes->fetch_assoc()) {
        $warehouses[] = $whRow;
    }
}
$warehouseOptions = '<option value="">----Select Warehouse----</option>';
foreach ($warehouses as $wh) {
    $warehouseOptions .= '<option value="' . $wh['id'] . '">' . htmlspecialchars($wh['warehouse_name']) . '</option>';
}
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <style>
        #addStockInwardsModal .modal-content,
        #editStockInwardsModel .modal-content,
        #stockInwardsViewModel .modal-content,
        #verifyInboundModal .modal-content {
            display: flex;
            flex-direction: column;
            max-height: calc(100dvh - 2rem);
        }

        #addStockInwardsModal .modal-header,
        #editStockInwardsModel .modal-header,
        #stockInwardsViewModel .modal-header,
        #verifyInboundModal .modal-header,
        #addStockInwardsForm > .flex,
        #stockInwardsView > .flex,
        #verifyInboundForm > .flex {
            flex: 0 0 auto;
        }

        #addStockInwardsForm,
        #editStockInwardsForm,
        #stockInwardsView,
        #verifyInboundForm {
            display: flex;
            flex: 1 1 auto;
            flex-direction: column;
            min-height: 0;
        }

        #addStockInwardsModal .modal-body,
        #editStockInwardsModel .modal-body,
        #stockInwardsViewModel .modal-body,
        #verifyInboundModal .modal-body {
            min-height: 0;
            overflow-y: auto;
        }

        #addStockInwardsModal .select2-container--open {
            z-index: 1095;
        }
    </style>
    <!-- Header -->
    <div class="mb-4 ui-page-title-banner">
        <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
        <p class="text-sm text-slate-500 mt-1">Manage stock inwards and receipts</p>
    </div>

    <!-- Phase D: QA/QC Inbound Materials Widget (Standalone) -->
    <div id="inboundMaterialWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2">
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md" style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: #fce8e8; border-radius: 0.75rem;">
                    <i class="ti ti-bell" style="font-size: 1.5rem; color: #d11f1f;"></i>
                    <span id="inboundMaterialsCount" style="position: absolute; top: -0.4rem; right: -0.55rem; display: flex; align-items: center; justify-content: center; min-width: 1.5rem; height: 1.5rem; padding: 0 0.3rem; background-color: #d11f1f; color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">0</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: #1e293b; margin: 0;">Inbound Material(s)!</h3>
                    </div>
                    <p class="font-medium text-slate-500 mt-1 mb-0" style="font-size: 0.875rem;">
                        Click on Widgets for upcoming items.
                    </p>
                </div>
            </div>
            <div class="text-slate-400">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <!-- Inbound Material(s)! Requests Modal -->
    <div class="modal fade animate__animated fadeIn" id="inboundMaterialsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <!-- Standard Header -->
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-700 ring-1 ring-rose-100">
                            <i class="ti ti-bell-ringing text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Inbound Material(s)!</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Pending goods received items</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body" style="padding: 1.25rem; background-color: #f8fafc;">
                    <div class="overflow-x-auto overflow-y-auto w-full" style="max-height: 55vh; padding-right: 5px;">
                        <div id="inboundMaterialsContainer" class="space-y-4">
                            <!-- Dynamically populated inbound cards -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden Purchase Order section (Kept for backwards compatibility but hidden) -->
    <div class="d-none">
        <select id="perPageSelectPurchaseOrd" class="form-select">
            <option value="5" selected>5</option>
        </select>
        <input type="text" id="searchPurchaseOrd" class="form-control" />
        <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
            <tbody id="purchaseOrderTableBody"></tbody>
        </table>
        <?= getPaginationFooter('paginationWrapperPurchaseOrder', 'paginationSummaryPurchaseOrder', 'footerPerPageSelectPurchaseOrder') ?>
    </div>

    <!-- Toolbar -->
    <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
            <div
                class="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                <input type="hidden" id="perPageSelect" value="10">
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="stockInwardsPerPageText" class="whitespace-nowrap">10 items</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="stock-inwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                        <li><a class="stock-inwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                        <li><a class="stock-inwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                        <li><a class="stock-inwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                        <li><a class="stock-inwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                        <li><a class="stock-inwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                    </ul>
                </div>
                <!-- Search -->
                <div class="relative h-10 min-w-[120px] max-w-[200px] flex-1">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="ti ti-search text-lg text-slate-400"></i>
                    </div>
                    <input type="text" id="searchInwards"
                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                        placeholder="Search inwards..." />
                </div>

                <!-- Physical Condition Filter -->
                <div class="dropdown shrink-0">
                    <button
                        class="flex h-10 min-w-[140px] w-auto items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                        <span class="inline-flex items-center gap-2 whitespace-nowrap">
                            <i class="ti ti-filter text-base text-slate-400"></i>
                            Phy. Condition
                        </span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <div
                        class="dropdown-menu max-h-64 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl">
                        <?php if (!empty(Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'])) { ?>
                            <label
                                class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                <input type="checkbox"
                                    class="physicalCondition-filter rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                    value="all"> <span>All Conditions</span>
                            </label>
                            <div class="my-1 h-px bg-slate-100"></div>
                            <?php foreach (Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'] as $sfpckey => $sfpcval) { ?>
                                <label
                                    class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox"
                                        class="physicalCondition-filter rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500"
                                        value="<?php echo $sfpckey; ?>"> <span><?php echo $sfpcval['label']; ?></span>
                                </label>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>

                <!-- Export Button (opens modal) -->
                <button type="button"
                    class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36"
                    data-bs-toggle="modal" data-bs-target="#exportModal">
                    <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                </button>

                <?php if (roleHasPermission($_SESSION['role_id'], 'store_stock_inwards_add')) { ?>
                    <button type="button" id="addStockInwardsModalBtn"
                        class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                        <i class="ti ti-plus text-lg"></i>
                    </button>
                <?php } ?>
            </div>
        </div>

        <!-- Table Section -->
        <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-slate-200/50">
            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50 whitespace-nowrap"
                                data-column="stkin.date_of_entry" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date Of Entry <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i><span
                                        class="sort-icon"></span></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50 d-none"
                                data-column="prodcateg.name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Material type <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i><span
                                        class="sort-icon"></span></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="prod.product_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Product <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i><span
                                        class="sort-icon"></span></span>
                            </th>
                            <th class="px-6 py-3">Quantity</th>
                            <th class="sortable w-64 min-w-[220px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="sup.name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Supplier <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i><span
                                        class="sort-icon"></span></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="recemp.name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Received By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i><span
                                        class="sort-icon"></span></span>
                            </th>
                            <th class="px-6 py-3">Phy. Cond</th>
                            <th class="px-6 py-3">Created By</th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="stocksInwardsTableBody"
                        class="bg-white divide-y divide-slate-100 text-sm text-slate-600">
                        <!-- Loaded via AJAX -->
                    </tbody>
                </table>
            </div>

            <!-- Footer / Pagination -->
            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>

    <!-- Export Modal -->
    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="goodsReceivedExportForm" class="goods-received-export-form">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportType" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Timestamp" checked />
                                        <span class="text-sm font-medium text-slate-700">Timestamp</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Date Of Entry" checked />
                                        <span class="text-sm font-medium text-slate-700">Date Of Entry</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product" checked />
                                        <span class="text-sm font-medium text-slate-700">Product</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Quantity" checked />
                                        <span class="text-sm font-medium text-slate-700">Quantity</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Supplier" checked />
                                        <span class="text-sm font-medium text-slate-700">Supplier</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Received By" checked />
                                        <span class="text-sm font-medium text-slate-700">Received By</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Physical Condition" checked />
                                        <span class="text-sm font-medium text-slate-700">Physical Condition</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Created By" checked />
                                        <span class="text-sm font-medium text-slate-700">Created By</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="modalExportSubmitBtn" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

        <!-- Modals -->
        <!-- Verify Inbound Modal -->
        <div class="modal fade animate__animated fadeIn" id="verifyInboundModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered" style="max-width: 1370px;">
                <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-2xl bg-white">
                    <!-- Header -->
                    <div class="modal-header flex items-center justify-between border-b border-slate-100 bg-white !px-6 !py-4">
                        <div class="flex items-center gap-3">
                            <span class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800 border border-emerald-200">
                                <i class="ti ti-circle-check text-xl"></i>
                            </span>
                            <div>
                                <h5 class="modal-title m-0 text-base font-extrabold text-slate-800">Verify & Receive Inbound Order</h5>
                                <p class="m-0 text-xs font-semibold text-slate-400 mt-0.5">Record incoming quantity, condition, and invoice details</p>
                            </div>
                        </div>
                        <button type="button" class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-lg"></i>
                        </button>
                    </div>
                    <form id="verifyInboundForm" enctype="multipart/form-data">
                        <!-- Modal Body -->
                        <div class="modal-body bg-white !px-6 !py-6">
                            <!-- Top Form Fields & Attachment Grid (Exactly Three Columns in Row) -->
                            <div class="row mb-4">
                                <!-- Column 1: PO Number, Invoice Number, Date of Receipt -->
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">PO Number</label>
                                        <input type="text" name="verifyPoNumber" id="verifyPoNumber" class="form-control !bg-slate-100 border-slate-200 text-slate-600 font-bold" readonly style="background-color: #f1f5f9 !important;" />
                                        <input type="hidden" name="verifyMaterialType" id="verifyMaterialType" />
                                        <input type="hidden" name="receiptSubmissionToken" id="receiptSubmissionToken" />
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">Invoice Number</label>
                                        <input type="text" name="verifyInvoiceNumber" id="verifyInvoiceNumber" placeholder="Enter Invoice # (optional)" class="form-control border-slate-200 text-slate-700" />
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">Date of Receipt</label>
                                        <input type="date" name="verifyReceiptDate" id="verifyReceiptDate" class="form-control border-slate-200 text-slate-700" value="<?php echo date('Y-m-d'); ?>" required />
                                    </div>
                                </div>

                                <!-- Column 2: Supplier/Vendor, Invoice Date, Warehouse Location -->
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">Supplier/Vendor</label>
                                        <input type="text" name="verifyVendorName" id="verifyVendorName" class="form-control !bg-slate-100 border-slate-200 text-slate-600 font-bold" readonly style="background-color: #f1f5f9 !important;" />
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">Invoice Date</label>
                                        <input type="date" name="verifyInvoiceDate" id="verifyInvoiceDate" class="form-control border-slate-200 text-slate-700" />
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">Warehouse Location</label>
                                        <select name="verifyWarehouseId" id="verifyWarehouseId" class="form-select border-slate-200 text-slate-700" required>
                                            <?= $warehouseOptions ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Column 3: Invoice Attachment -->
                                <div class="col-md-4 d-flex flex-column">
                                    <div class="mb-3 flex-grow-1 d-flex flex-column">
                                        <label class="form-label text-xs font-bold text-slate-500 uppercase tracking-wider">Invoice Attachment</label>
                                        <div id="invoiceUploadContainer" class="flex-grow-1 d-flex flex-column align-items-center justify-content-center border border-dashed border-slate-200 bg-slate-50/50 rounded-3 p-4 cursor-pointer hover:bg-slate-50 hover:border-emerald-300 transition-colors relative" style="min-h: 210px; height: calc(100% - 1.75rem);">
                                            <input type="file" name="verifyInvoiceFile" id="verifyInvoiceFile" accept="image/*,application/pdf" class="position-absolute w-100 h-100 top-0 start-0 opacity-0 cursor-pointer" style="z-index: 5;" />
                                            
                                            <!-- Default State -->
                                            <div id="uploadDefaultState" class="text-center">
                                                <span class="d-inline-flex h-12 w-12 align-items-center justify-content-center rounded-circle bg-slate-100 text-slate-400 mb-2">
                                                    <i class="ti ti-upload text-xl"></i>
                                                </span>
                                                <p class="m-0 text-xs font-semibold text-slate-600">Drag & drop or click to upload</p>
                                                <p class="m-0 text-[10px] text-slate-400">PDF, PNG, JPG (Max 5MB)</p>
                                            </div>

                                            <!-- File Selected State -->
                                            <div id="uploadActiveState" class="hidden text-center" style="position: relative; z-index: 10;">
                                                <div class="position-relative d-inline-block mb-3">
                                                    <span class="d-inline-flex h-16 w-14 align-items-center justify-center rounded bg-white text-slate-400 border border-slate-200 shadow-sm">
                                                        <i class="ti ti-file-text text-2xl"></i>
                                                    </span>
                                                    <span class="position-absolute top-0 start-100 translate-middle d-inline-flex h-4.5 w-4.5 align-items-center justify-content-center rounded-circle bg-emerald-500 text-white text-[9px] font-bold border-2 border-white shadow-sm" style="transform: translate(-40%, -40%) !important;">
                                                        <i class="ti ti-check"></i>
                                                    </span>
                                                </div>
                                                <p id="uploadedFileName" class="m-0 text-xs font-bold text-slate-700 truncate max-w-[200px]"></p>
                                                <div class="mt-2 d-flex align-items-center justify-content-center gap-2 text-xs font-semibold">
                                                    <span class="text-emerald-700 hover:text-emerald-800 cursor-pointer selectNewFileBtn">Change</span>
                                                    <span class="text-slate-300">|</span>
                                                    <span class="text-rose-600 hover:text-rose-700 cursor-pointer removeInvoiceFileBtn">Remove</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Items expected grid -->
                            <div class="bg-white rounded-xl border border-slate-200 overflow-hidden mb-4">
                                <div class="bg-slate-50/50 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between">
                                    <h6 class="m-0 text-xs font-bold uppercase tracking-wider text-slate-500">PO Items Verification</h6>
                                    <span id="itemsDetectedBadge" class="badge bg-emerald-50 text-emerald-700 font-bold px-2 py-1 text-[10px] rounded-lg border border-emerald-100">0 ITEMS DETECTED</span>
                                </div>
                                <div class="overflow-x-auto">
                                    <table class="w-full text-left border-collapse text-slate-600">
                                        <thead class="border-b border-slate-200 bg-slate-50/50">
                                            <tr class="whitespace-nowrap">
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[160px]">Materials</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[80px]">EXP QTY</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[70px]">Unit</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[90px]">Received Qty</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[140px]">Physical Condition</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 w-44 min-w-[160px]">Batch Number</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[160px]">Mfg. Date</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[160px]">Expiry Date</th>
                                                <th class="px-4 py-3 text-xs font-bold uppercase tracking-widest text-slate-400 min-w-[100px]">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody id="verifyPoItemsBody" class="divide-y divide-slate-100 bg-white">
                                            <!-- Pre-filled dynamic PO items -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Footer -->
                        <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-6 py-4">
                            <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none"><i class="ti ti-check text-lg"></i> Submit Receipt</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Add Stock Inwards Modal -->
        <div class="modal fade" id="addStockInwardsModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-xl">
                    <div
                        class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                        <div class="flex items-center gap-3">
                            <span
                                class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                                <i class="ti ti-plus text-xl"></i>
                            </span>
                            <div>
                                <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                    Stock Inward</h5>
                            </div>
                        </div>
                        <button type="button"
                            class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-xl"></i>
                        </button>
                    </div>
                    <form id="addStockInwardsForm">
                        <div class="modal-body p-6">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="do_entry" class="form-label text-sm font-semibold text-slate-700">Date
                                        of Entry</label>
                                    <input type="date" id="do_entry" autocomplete="off" name="do_entry"
                                        class="form-control" required />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="select2SupplierList"
                                        class="form-label text-sm font-semibold text-slate-700">Supplier</label>
                                    <select id="select2SupplierList" name="select2SupplierList"
                                        class="input-theme select2" data-allow-clear="true"
                                        required>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="receivedBy"
                                        class="form-label text-sm font-semibold text-slate-700">Received By</label>
                                    <select id="receivedBy" name="receivedBy" class="input-theme select2"
                                        data-allow-clear="true" required>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label for="receiptStatus" class="form-label text-sm font-semibold text-slate-700">Receipt Completeness</label>
                                    <select id="receiptStatus" name="receiptStatus" class="input-theme select2" data-allow-clear="true">
                                        <option value="">-- Select Status --</option>
                                        <?php 
                                        foreach (Constant::STOCKS_INWARDS['RECEIPT_STATUS'] as $k => $v) {
                                            echo "<option value=\"$k\">{$v['label']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="invoiceNumber" class="form-label text-sm font-semibold text-slate-700">Invoice Number</label>
                                    <input type="text" id="invoiceNumber" name="invoiceNumber" class="form-control" />
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="invoiceDate" class="form-label text-sm font-semibold text-slate-700">Invoice Date</label>
                                    <input type="date" id="invoiceDate" name="invoiceDate" class="form-control" />
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="invoiceImages" class="form-label text-sm font-semibold text-slate-700">Invoice Images</label>
                                    <input type="file" id="invoiceImages" name="invoiceImages[]" class="form-control" multiple accept="image/*,application/pdf" />
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col mb-2">
                                    <label class="form-label text-sm font-semibold text-slate-700">Product
                                        Details</label>
                                </div>
                                <div id="productsWrapperWhole" class="d-flex flex-column gap-3"></div>
                                <div class="mt-4 mb-3">
                                    <button type="button"
                                        class="inline-flex h-9 items-center gap-2 !rounded-xl bg-emerald-50 px-4 text-sm font-medium text-emerald-700 shadow-sm ring-1 ring-emerald-900/10 hover:bg-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                        id="addProductBtn">
                                        <i class="ti ti-plus"></i> Add Product
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                            <button type="button"
                                class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                                data-bs-dismiss="modal">Close</button>
                            <button type="submit"
                                class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                    class="ti ti-check text-lg"></i> Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Stock Inwards Modal -->
        <div class="modal fade" id="editStockInwardsModel" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-xl">
                    <div
                        class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                        <div class="flex items-center gap-3">
                            <span
                                class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                                <i class="ti ti-pencil text-xl"></i>
                            </span>
                            <div>
                                <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">
                                    Edit Stock Inward</h5>
                            </div>
                        </div>
                        <button type="button"
                            class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-xl"></i>
                        </button>
                    </div>
                    <form id="editStockInwardsForm">
                        <div class="modal-body p-6">
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- View Stock Inwards Modal -->
        <div class="modal fade" id="stockInwardsViewModel" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-xl">
                    <div
                        class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                        <div class="flex items-center gap-3">
                            <span
                                class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                                <i class="ti ti-eye text-xl"></i>
                            </span>
                            <div>
                                <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">
                                    View Stock Inward</h5>
                            </div>
                        </div>
                        <button type="button"
                            class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-xl"></i>
                        </button>
                    </div>
                    <div id="stockInwardsView">
                        <div class="modal-body p-6">
                        </div>
                        <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                            <button type="button"
                                class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                                data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php startSection('scripts'); ?>
    <script>
        let currentPage = 1;
        let qtyUnitOptions = [];
        let productIndex = 0;
        let currentSortColumn = 'recent';
        let currentSortOrder = 'DESC';
        let selectedConditions = [];
        let selectedPhysicalConditionType = [];

        function loadPurchaseOrderTable(page = 1) {
            currentPageOrdRec = page;
            const search = $('#searchPurchaseOrd').val().trim();
            const perPage = $('#perPageSelectPurchaseOrd').val();

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadGoodInwardsFinalPurchaseOrder: 'loadGoodInwardsFinalPurchaseOrder',
                    page: page,
                    per_page: perPage,
                    search: search
                },
                success: function (response) {
                    $('#purchaseOrderTableBody').html(response.table || '');
                    $('#paginationWrapperPurchaseOrder').html(response.pagination || '');
                    if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryPurchaseOrder', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectPurchaseOrder');
                },
                error: function () {
                    $('#purchaseOrderTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                    $('#paginationWrapperPurchaseOrder').html('');
                }
            });
        }

        function loadStandardUnit() {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    getQtyUnits: 'getQtyUnits'
                },
                success: function (response) {
                    qtyUnitOptions = response;
                },
                error: function (xhr, status, error) {
                    console.error("Failed to load qty units:", error);
                }
            });
        }

        function loadInboundMaterials() {
            $('#inboundMaterialsContainer').html('<div class="text-center py-6"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    loadInboundMaterials: 'loadInboundMaterials'
                },
                success: function (response) {
                    $('#inboundMaterialsContainer').html(response.html || '');
                    $('#inboundMaterialsCount').text(Number(response.count || 0));
                },
                error: function () {
                    $('#inboundMaterialsContainer').html('<div class="text-center py-6 text-sm font-medium text-rose-600">Error loading inbound materials.</div>');
                    $('#inboundMaterialsCount').text('0');
                }
            });
        }

        $(document).on('click', '.seeMoreBtn', function () {
            const targetId = $(this).data('target');
            $(`#${targetId}`).toggleClass('hidden');
            $(this).text($(this).text().trim() === 'See More' ? 'See Less' : 'See More');
        });

        const physicalConditionSelectOptions = `
            <?php if (!empty(Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'])) {
                foreach (Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'] as $key => $val) {
                    echo '<option value="' . $key . '">' . htmlspecialchars($val['label']) . '</option>';
                }
            } ?>
        `;

        function getReceiptStatusLabel(expectedQty, receivedQty, alreadyReceivedQty = 0) {
            const expected = parseFloat(expectedQty) || 0;
            const received = (parseFloat(receivedQty) || 0) + (parseFloat(alreadyReceivedQty) || 0);
            if (expected > 0 && Math.abs(received - expected) < 0.000001) return 'Complete';
            if (received > expected) return 'Excess Received';
            if (expected > 0 && Math.abs(received - (expected / 2)) < 0.000001) return 'Half Received';
            if (received > 0 && received < expected) return 'Partially Received';
            return 'Pending';
        }

        function refreshReceiptStatus($row) {
            const expected = parseFloat($row.find('input[name="expectedQty[]"]').val()) || 0;
            const received = parseFloat($row.find('input[name="receivedQty[]"]').val()) || 0;
            const alreadyReceived = parseFloat($row.data('already-received')) || 0;
            
            const label = getReceiptStatusLabel(expected, received, alreadyReceived);
            const $statusSpan = $row.find('.autoReceiptStatus');
            $statusSpan.text(label);
            
            $statusSpan.removeClass('bg-emerald-50 text-emerald-700 border-emerald-100 bg-amber-50 text-amber-700 border-amber-100 bg-blue-50 text-blue-700 border-blue-100 bg-slate-50 text-slate-700 border-slate-200 rounded border px-2 py-1 rounded-xl px-2.5 py-1.5');
            
            if (label === 'Complete') {
                $statusSpan.addClass('bg-emerald-50 text-emerald-700 border-emerald-100 rounded-xl px-2.5 py-1.5');
            } else if (label === 'Half Received') {
                $statusSpan.addClass('bg-amber-50 text-amber-700 border-amber-100 rounded-xl px-2.5 py-1.5');
            } else if (label === 'Partially Received') {
                $statusSpan.addClass('bg-blue-50 text-blue-700 border-blue-100 rounded-xl px-2.5 py-1.5');
            } else {
                $statusSpan.addClass('bg-slate-50 text-slate-700 border-slate-200 rounded-xl px-2.5 py-1.5');
            }
        }

        // File Uploader Interaction Handlers
        $(document).on('change', '#verifyInvoiceFile', function (e) {
            const file = e.target.files[0];
            if (file) {
                $('#uploadedFileName').text(file.name);
                $('#uploadDefaultState').addClass('hidden');
                $('#uploadActiveState').removeClass('hidden');
                $('#invoiceUploadContainer').removeClass('border-dashed border-slate-200 bg-slate-50/50').addClass('border-solid border-blue-200 bg-blue-50/20');
            } else {
                clearInvoiceUpload();
            }
        });

        $(document).on('click', '.removeInvoiceFileBtn', function (e) {
            e.stopPropagation();
            clearInvoiceUpload();
        });

        function clearInvoiceUpload() {
            $('#verifyInvoiceFile').val('');
            $('#uploadActiveState').addClass('hidden');
            $('#uploadDefaultState').removeClass('hidden');
            $('#invoiceUploadContainer').addClass('border-dashed border-slate-200 bg-slate-50/50').removeClass('border-solid border-blue-200 bg-blue-50/20');
        }

        $(document).on('click', '.verifyInboundBtn', function () {
            const poNumber = $(this).data('po');
            const type = $(this).data('type');
            const vendor = $(this).data('vendor');
            
            $('#verifyPoNumber').val(poNumber);
            $('#verifyMaterialType').val(type);
            $('#receiptSubmissionToken').val(
                window.crypto && window.crypto.randomUUID
                    ? window.crypto.randomUUID()
                    : `${Date.now()}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}`
            );
            $('#verifyVendorName').val(vendor);
            clearInvoiceUpload();
            $('#verifyInvoiceNumber').val('');
            $('#verifyInvoiceDate').val(new Date().toISOString().slice(0, 10));
            $('#verifyReceiptDate').val(new Date().toISOString().slice(0, 10));
            $('#verifyWarehouseId').val('');
            $('#verifyPoItemsBody').html('<tr><td colspan="9" class="px-4 py-6 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
            $('#itemsDetectedBadge').text('0 ITEMS DETECTED');
            $('#verifyInboundModal').modal('show');

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    fetchInboundPoDetails: 'fetchInboundPoDetails',
                    po_number: poNumber,
                    type: type
                },
                success: function (response) {
                    if (response.status === 'success' && response.items) {
                        let html = '';
                        response.items.forEach(function (item, idx) {
                            html += `
                            <tr data-already-received="${item.already_received || 0}">
                                <td class="px-4 py-2.5">
                                    <input type="hidden" name="poItemId[]" value="${item.po_item_id}" />
                                    <input type="hidden" name="itemName[]" value="${item.name}" />
                                    <div class="flex flex-col">
                                        <span class="text-sm font-bold text-slate-800">${item.name}</span>
                                        ${item.mat_id ? `<span class="text-[10px] text-slate-400 font-semibold mt-0.5">ID: ${item.mat_id}</span>` : ''}
                                    </div>
                                </td>
                                <td class="px-4 py-2.5">
                                    <input type="hidden" name="expectedQty[]" value="${item.expected_qty}" />
                                    <span class="text-sm font-semibold text-slate-700">${item.expected_qty}</span>
                                </td>
                                <td class="px-4 py-2.5">
                                    <input type="hidden" name="itemUnit[]" value="${item.unit || ''}" />
                                    <span class="text-sm text-slate-500">${item.unit || '-'}</span>
                                </td>
                                <td class="px-4 py-2.5">
                                    <input type="number" min="0" step="any" name="receivedQty[]" class="input-theme !py-1.5 !px-2 receivedQtyInput" value="${item.remaining_qty}" required />
                                </td>
                                <td class="px-4 py-2.5">
                                    <select name="physicalCondition[]" class="input-theme !py-1.5 !px-2" required>
                                        ${physicalConditionSelectOptions}
                                    </select>
                                </td>
                                <td class="px-4 py-2.5">
                                    <input type="text" name="lotNumber[]" class="input-theme !py-1.5 !px-2" placeholder="Lot #" />
                                </td>
                                <td class="px-4 py-2.5 min-w-[160px]">
                                    <input type="date" name="mfgDate[]" class="input-theme !py-1.5 !px-2.5 text-xs w-full min-w-[145px]" />
                                </td>
                                <td class="px-4 py-2.5 min-w-[160px]">
                                    <input type="date" name="expiryDate[]" class="input-theme !py-1.5 !px-2.5 text-xs w-full min-w-[145px]" />
                                </td>
                                <td class="px-4 py-2.5">
                                    <span class="autoReceiptStatus inline-flex min-w-20 justify-center rounded border text-xs font-semibold"></span>
                                </td>
                            </tr>
                            `;
                        });
                        $('#verifyPoItemsBody').html(html);
                        $('#itemsDetectedBadge').text(`${response.items.length} ${response.items.length === 1 ? 'ITEM' : 'ITEMS'} DETECTED`);
                        $('#verifyPoItemsBody tr').each(function () { refreshReceiptStatus($(this)); });
                    } else {
                        $('#verifyPoItemsBody').html('<tr><td colspan="9" class="px-4 py-6 text-center text-sm font-medium text-rose-600">Failed to load items.</td></tr>');
                    }
                },
                error: function () {
                    $('#verifyPoItemsBody').html('<tr><td colspan="9" class="px-4 py-6 text-center text-sm font-medium text-rose-600">Server error occurred.</td></tr>');
                }
            });
        });

        $(document).on('input', 'input[name="receivedQty[]"]', function () {
            refreshReceiptStatus($(this).closest('tr'));
        });

        $(document).on('submit', '#verifyInboundForm', function (e) {
            e.preventDefault();
            const form = document.getElementById('verifyInboundForm');
            const formData = new FormData(form);
            formData.append('submitInboundVerification', 'submitInboundVerification');

            const $submitBtn = $('#verifyInboundForm button[type="submit"]');
            const originalHtml = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#verifyInboundModal').modal('hide');
                        $('#verifyInboundForm')[0].reset();
                        clearInvoiceUpload();
                        toastr.success(response.message || 'Receipt submitted successfully.');
                        loadInboundMaterials();
                        loadStockInwardsTable();
                    } else {
                        toastr.error(response.message || 'Error submitting receipt.');
                    }
                    $submitBtn.prop('disabled', false).html(originalHtml);
                },
                error: function () {
                    toastr.error('Server error occurred.');
                    $submitBtn.prop('disabled', false).html(originalHtml);
                }
            });
        });

        function loadStockInwardsTable(page = 1) {
            currentPage = page;
            const search = ($('#searchInwards').val() || '').trim();
            const perPage = $('#perPageSelect').val();

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadStockInwards: 'loadStockInwards',
                    page: page,
                    per_page: perPage,
                    search: search,
                    sort_column: currentSortColumn,
                    sort_order: currentSortOrder,
                    // conditions: selectedConditions,
                    conditions: selectedPhysicalConditionType
                },
                success: function (response) {
                    $('#stocksInwardsTableBody').html(response.table || '');
                    $('#paginationWrapper').html(response.pagination || '');
                    if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');

                    const total = response.total_rows || 0;
                    let start = total === 0 ? 0 : ((page - 1) * perPage) + 1;
                    let end = Math.min(page * perPage, total);
                    $('#tableInfo').text(`Showing ${start} to ${end} of ${total}`);
                },
                error: function () {
                    $('#stocksInwardsTableBody').html('<tr><td colspan="10" class="px-6 py-10 text-center text-sm font-medium text-slate-500">Error loading data.</td></tr>');
                    $('#paginationWrapper').html('');
                    $('#tableInfo').text('Showing 0 to 0 of 0');
                }
            });
        }

        function loadSupliersOption() {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadSupplierListOptions: 'loadSupplierListOptions'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (supplier) {
                        html += `<option value="${supplier.key}">${supplier.value}</option>`;
                    });
                    $('#select2SupplierList').html(html).trigger('change');
                }
            });
        }

        function loadMaterialTypeOption() {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadMaterialTypeOption: 'loadMaterialTypeOption'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (prodCateg) {
                        html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                    });
                    $('#materialTypeList').html(html).trigger('change');
                }
            });
        }

        function loadReceiverEmployeeOption() {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadReceivedByEmpOption: 'loadReceivedByEmpOption'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (prodCateg) {
                        html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                    });
                    $('#receivedBy').html(html).trigger('change');
                }
            });
        }

        function loadProductsByMaterialType(materialTypeId) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    materialTypeId: materialTypeId,
                    loadProductsByMaterialType: 'loadProductsByMaterialType'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (product) {
                        html += `<option value="${product.key}">${product.value}</option>`;
                    });
                    $('#productsList').html(html).trigger('change');
                }
            });
        }

        function initStockInwardsSelect2($element, options = {}) {
            $element.each(function() {
                const $select = $(this);
                if ($select.hasClass('select2-hidden-accessible')) {
                    $select.select2('destroy');
                }
                $select.select2($.extend({
                    dropdownParent: $('#addStockInwardsModal'),
                    width: '100%'
                }, options));
            });
        }

        function constrainStockInwardsSelect2Dropdown() {
            const $dropdown = $('.select2-container--open .select2-dropdown');
            const $results = $dropdown.find('.select2-results__options');
            const $modalContent = $('#addStockInwardsModal .modal-content');
            const $modalFooter = $('#addStockInwardsForm > .flex').last();

            if (!$dropdown.length || !$results.length || !$modalContent.length) return;

            const dropdownTop = $dropdown[0].getBoundingClientRect().top;
            const footerTop = $modalFooter.length
                ? $modalFooter[0].getBoundingClientRect().top
                : $modalContent[0].getBoundingClientRect().bottom;
            const availableHeight = Math.max(120, footerTop - dropdownTop - 12);

            $results.css('max-height', Math.min(260, availableHeight) + 'px');
        }

        function bindStockInwardsSelect2Scroll() {
            setTimeout(function() {
                constrainStockInwardsSelect2Dropdown();
                $('.select2-container--open .select2-dropdown')
                    .off('wheel.stockInwardsModalScroll')
                    .on('wheel.stockInwardsModalScroll', function(e) {
                        const deltaY = e.originalEvent.deltaY || 0;
                        if (!deltaY) return;

                        const el = $(this).find('.select2-results__options').get(0);
                        if (!el) return;

                        const canScrollUp = el.scrollTop > 0;
                        const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                        const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                        if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                            e.preventDefault();
                            e.stopPropagation();
                            el.scrollTop += deltaY;
                            return;
                        }

                        if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                            e.preventDefault();
                            e.stopPropagation();

                            const $modalBody = $('#addStockInwardsModal .modal-body');
                            $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                            $('#addStockInwardsModal .select2-hidden-accessible').select2('close');
                        }
                    });
            }, 0);
        }

        $(document).on('click', '.sortable', function () {
            const column = $(this).data('column');
            let order = $(this).data('order');

            currentSortColumn = column;
            currentSortOrder = order;

            // Reset all arrows first
            $('.sortable').each(function () {
                $(this).find('.sort-icon').remove();
            });

            // Add arrow to the clicked column
            let arrow = order === "asc"
                ? '<i class="ti ti-arrow-up sort-icon ms-1"></i>'
                : '<i class="ti ti-arrow-down sort-icon ms-1"></i>';

            $(this).append(arrow);

            // Toggle asc/desc for next click
            $(this).data('order', order === "asc" ? "desc" : "asc");

            // reload
            loadStockInwardsTable(1);
        });

        $(document).ready(function () {
            $(".physicalCondition-filter").prop("checked", true);

            selectedPhysicalConditionType = [];
            $(".physicalCondition-filter:checked").each(function () {
                if ($(this).val() !== "all") {
                    selectedPhysicalConditionType.push($(this).val());
                }
            });
            loadPurchaseOrderTable();
            loadStockInwardsTable();
            loadInboundMaterials();
            loadSupliersOption();
            loadReceiverEmployeeOption();
            loadStandardUnit();
            initStockInwardsSelect2($('#addStockInwardsModal .select2'), {
                placeholder: 'Select value'
            });
            $(document).on('select2:open', function(e) {
                if (!$(e.target).closest('#addStockInwardsModal').length) return;
                bindStockInwardsSelect2Scroll();
            });
            $('#addStockInwardsModal .modal-body').on('scroll', function() {
                $('#addStockInwardsModal .select2-hidden-accessible').select2('close');
            });
            $('#searchInwards').on('input', function () {
                loadStockInwardsTable(1);
            });
            $('#perPageSelect').on('change', function () {
                loadStockInwardsTable(1);
            });
            $('#footerPerPageSelect').on('change', function () {
                $('#perPageSelect').val($(this).val());
                loadStockInwardsTable(1);
            });

            // Top-strip per-page dropdown handler
            $(document).on('click', '.stock-inwards-per-page-item', function () {
                const val = $(this).data('val');
                $('#stockInwardsPerPageText').text($(this).text());
                $('#footerPerPageSelect').val(val).trigger('change');
            });
            $('#searchPurchaseOrd').on('input', function () {
                loadPurchaseOrderTable(1);
            });
            $('#perPageSelectPurchaseOrd').on('change', function () {
                loadPurchaseOrderTable(1);
            });

            $('#addStockInwardsModal').on('hidden.bs.modal', function () {
                $('#addStockInwardsForm')[0].reset();
                $('#select2SupplierList').val(null).trigger('change');
                $('#receivedBy').val(null).trigger('change');
                $('#productsWrapperWhole').empty();
            });


            $('#addProductBtn').click(function () {
                let qtyUnitHtml = '<option value="">----Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    qtyUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });

                const productBlock = `
            <div class="row product-entry mb-2 border rounded p-2" data-index="${productIndex}">
                <div class="col-md-3 mb-2">
                    <label class="form-label">Material Type</label>
                    <select name="materialTypeList[]" class="input-theme select2 materialTypeList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Product</label>
                    <select name="productsList[]" class="input-theme select2 productsList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Quantity</label>
                    <input type="number" step="any" min="0" name="prodQuantity[]" class="form-control" placeholder="Enter Quantity" required />
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Quantity Unit</label>
                    <select name="prodQuantityUnit[]" class="input-theme select2" required>
                        ${qtyUnitHtml}
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <label class="form-label">Physical Condition</label>
                    <select name="phycalCondition[]" class="input-theme select2" required>
                        <option value="">----Select----</option>
                        <?php foreach (Constant::STOCKS_INWARDS['PHYSICAL_CONDITION'] as $pckey => $pcval) {
                            echo '<option value="' . $pckey . '">' . $pcval['label'] . '</option>';
                        } ?>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Mfg Date (If any)</label>
                    <input type="date" name="mfgDate[]" class="form-control" placeholder="Enter Mfg" />
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Expiary Date (If any)</label>
                    <input type="date" name="expiaryDate[]" class="form-control" placeholder="Enter Expiary" />
                </div>
                <div class="col-md-3 mb-2">
                    <label class="form-label">Enter LOT No.</label>
                    <input type="text" name="lotNumber[]" class="form-control" placeholder="Enter LOT No." />
                </div>
                <div class="col-md-4 mb-3">
                    <label for="remark" class="form-label">Remark</label>
                    <textarea id="remark" rows="1" autocomplete="off" name="remark[]" class="form-control" placeholder="Enter Remark"></textarea>
                </div>
                <div class="col-md-3 mb-2 d-flex align-items-end">
                    <button type="button" class="btn btn-icon btn-label-danger removeProductBtn"><span class="ti ti-trash"></span></button>               
                </div>
            </div>`;

                $('#productsWrapperWhole').append(productBlock);

                // Initialize Select2 on new fields
                const $newRow = $(`.product-entry[data-index="${productIndex}"]`);
                initStockInwardsSelect2($newRow.find('.select2'), {
                    placeholder: '----Select Option----'
                });

                // Load material types in the new block
                const $newMaterialSelect = $newRow.find('.materialTypeList');
                $.ajax({
                    url: 'ajax.php',
                    method: 'POST',
                    data: {
                        loadMaterialTypeOption: 'loadMaterialTypeOption'
                    },
                    dataType: 'json',
                    success: function (response) {
                        let html = '<option value="">----Select Option----</option>';
                        response.forEach(function (item) {
                            html += `<option value="${item.key}">${item.value}</option>`;
                        });
                        $newMaterialSelect.html(html).trigger('change');
                    }
                });

                productIndex++;
            });

            $(document).on('click', '.removeProductBtn', function () {
                $(this).closest('.product-entry').remove();
            });

            $(document).on('click', '#addStockInwardsModalBtn', function () {
                $('#addStockInwardsModal').modal('show');
                if ($('.product-entry').length === 0) {
                    $('#addProductBtn').trigger('click');
                }
            });

            $('#addStockInwardsForm').on('submit', function (e) {
                e.preventDefault();

                const productCount = $('#productsWrapperWhole .product-entry').length;

                if (productCount === 0) {
                    toastr.error('Please add at least one product.');
                    return false;
                }

                const form = document.getElementById('addStockInwardsForm');
                const formData = new FormData(form);
                formData.append('addStockInwardsRecord', 'addStockInwardsRecord');

                // Disable submit button to prevent double submission
                const $submitBtn = $('#addStockInwardsForm button[type="submit"]');
                $submitBtn.prop('disabled', true);

                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function (response) {
                        if (response.status === 'success') {
                            $('#addStockInwardsModal').modal('hide');
                            $('#addStockInwardsForm')[0].reset();
                            loadStockInwardsTable();
                            toastr.success(response.message);
                        } else if (response.status === 'error') {
                            toastr.error(response.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                        // Re-enable submit button after success
                        $submitBtn.prop('disabled', false);
                    },
                    error: function () {
                        toastr.error('Server error occurred.');
                        // Re-enable submit button after error
                        $submitBtn.prop('disabled', false);
                    }
                });
            });

            $('#listOfColumns').selectpicker({
                actionsBox: true,
                selectedTextFormat: 'count > 2',
                noneSelectedText: '----Select Columns----'
            });
            $('#listOfColumns').selectpicker('selectAll');
        });





        $(document).on('change', '.materialTypeList', function () {
            const $parentRow = $(this).closest('.product-entry');
            const $productSelect = $parentRow.find('.productsList');
            const materialTypeId = $(this).val();

            if (materialTypeId) {
                $.ajax({
                    url: 'ajax.php',
                    method: 'POST',
                    data: {
                        materialTypeId: materialTypeId,
                        loadProductsByMaterialType: 'loadProductsByMaterialType'
                    },
                    dataType: 'json',
                    success: function (response) {
                        let html = '<option value="">----Select Option----</option>';
                        response.forEach(function (product) {
                            html += `<option value="${product.key}">${product.value}</option>`;
                        });
                        $productSelect.html(html).trigger('change');
                    }
                });
            } else {
                $productSelect.html('<option value="">----Select Option----</option>').trigger('change');
            }
        });


        $(document).on('click', '.stocksInwardsEditModalBtn', function () {
            let id = $(this).data('id');
            if (id) {
                $('#editStockInwardsForm').find('.modal-body').html('');
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        fetchStockInwardsRecord: 'fetchStockInwardsRecord',
                        id: id
                    },
                    success: function (res) {
                        if (res.status === 'success') {
                            $('#editStockInwardsModel').modal('show');
                            $('#editStockInwardsForm').find('.modal-body').html(res.data);
                        } else {
                            toastr.error(res.message || 'Unexpected error');
                        }
                    },
                    error: function (xhr) {
                        toastr.error('Server error occurred.');
                        console.error("Response:", xhr.responseText);
                    }
                });
            }
        });

        $(document).on('submit', '#editStockInwardsForm', function (e) {
            e.preventDefault();
            let formData = $(this).serialize() + '&updateStockInwardsRecord=1';
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        toastr.success(res.message || 'Stock inward updated successfully');
                        $('#editStockInwardsModel').modal('hide');
                        $('#stockInwardsTable').DataTable().ajax.reload(null, false);
                    } else {
                        toastr.error(res.message || 'Failed to update stock inward');
                    }
                },
                error: function (xhr) {
                    toastr.error('Server error occurred.');
                    console.error("Response:", xhr.responseText);
                }
            });
        });

        $(document).on('click', '.stocksInwardsViewModalBtn', function () {
            let id = $(this).data('id');

            if (id) {
                $('#stockInwardsView').find('.modal-body').html('');
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        fetchStockInwardsViewRecord: 'fetchStockInwardsViewRecord',
                        id: id
                    },
                    success: function (res) {
                        if (res.status === 'success') {
                            $('#stockInwardsViewModel').modal('show');
                            $('#stockInwardsView').find('.modal-body').html(res.data);
                        } else {
                            toastr.error(res.message || 'Unexpected error');
                        }
                    },
                    error: function (xhr) {
                        toastr.error('Server error occurred.');
                        console.error("Response:", xhr.responseText);
                    }
                });
            }
        });

        $(document).on('click', '.stockInwardDeleteBtn', function () {
            let id = $(this).data('id');

            if (!id) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid ID',
                    text: 'Invalid ID provided.',
                    customClass: {
                        confirmButton: 'btn btn-danger waves-effect waves-light'
                    }
                });
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deleteStockInwardsRecord: 'deleteStockInwardsRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function (res) {
                            if (res.status === 'success') {
                                loadStockInwardsTable();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        });

        $(document).on('change', '.physicalCondition-filter', function () {
            const isAll = $(this).val() === "all";

            if (isAll) {
                // Toggle all on or off based on "All"
                const allChecked = $(this).is(":checked");
                $(".physicalCondition-filter").prop("checked", allChecked);
            }

            selectedPhysicalConditionType = [];
            $(".physicalCondition-filter:checked").each(function () {
                if ($(this).val() !== "all") {
                    selectedPhysicalConditionType.push($(this).val());
                }
            });

            loadStockInwardsTable();
        });

        $('#exportModal').on('hidden.bs.modal', function () {
            $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
        });

        $('#goodsReceivedExportForm').on('submit', function (e) {
            e.preventDefault();
            const exportType = $('#exportType').val();
            if (!exportType) {
                toastr.error('Please select an export format.');
                return;
            }
            page = 1;
            currentPage = page;
            const search = ($('#searchInwards').val() || '').trim();
            const perPage = $('#perPageSelect').val();
            const form = document.getElementById('goodsReceivedExportForm');
            const formData = new FormData(form);
            formData.append('exportGoodsReceived', 'exportGoodsReceived');
            formData.append('search', search);
            formData.append('perPage', perPage);
            formData.append('page', page);
            formData.append('conditions', JSON.stringify(selectedPhysicalConditionType));
            formData.append('sort_column', currentSortColumn);
            formData.append('sort_order', currentSortOrder);

            $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');

            $.ajax({
                url: 'exportajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response.success === 'success') {
                        $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportType').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $(document).on('change', '#perPageSelectPurchaseOrder', function () { loadPurchaseOrderTable(1); });

        // Export type dropdown handler
        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            $('#exportTypeText').text($(this).text());
            $('#exportType').val(val);
        });

        // Deselect All columns button
        $('#deselectAllColumnsBtn').on('click', function () {
            const allChecked = $('#columnsCheckboxList .column-filter:checked').length === $('#columnsCheckboxList .column-filter').length;
            $('#columnsCheckboxList .column-filter').prop('checked', !allChecked);
            $(this).text(allChecked ? 'Select All' : 'Deselect All');
        });

        // Column filter handlers
        function updateColumnsSelectedText() {
            const checkedBoxes = $('.column-filter:checked');
            const checkedCount = checkedBoxes.length;
            if (checkedCount === 0) {
                $('#columnsSelectedText').text('----Select Columns----');
            } else if (checkedCount <= 2) {
                const text = checkedBoxes.map(function () { return $(this).val(); }).get().join(', ');
                $('#columnsSelectedText').text(text);
            } else {
                $('#columnsSelectedText').text(checkedCount + ' items selected');
            }
        }

        $(document).on('change', '.column-filter-all', function () {
            const isChecked = $(this).is(':checked');
            $('.column-filter').prop('checked', isChecked);
            updateColumnsSelectedText();
        });

        $(document).on('change', '.column-filter', function () {
            const total = $('.column-filter').length;
            const checked = $('.column-filter:checked').length;
            $('.column-filter-all').prop('checked', total === checked);
            updateColumnsSelectedText();
        });

        updateColumnsSelectedText();

        // Per page item handler
        $(document).on('click', '.per-page-item', function () {
            const val = $(this).data('val');
            $('#perPageText').text($(this).text());
            $('#footerPerPageSelect').val(val);
            $('#perPageSelect').val(val).trigger('change');
        });

        // Open Inbound Materials modal
        $(document).on('click', '#inboundMaterialWidget', function () {
            $('#inboundMaterialsModal').modal('show');
        });
    </script>
    <?php endSection(); ?>
