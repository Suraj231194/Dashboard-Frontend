<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= htmlspecialchars($pageTitle ?? 'BMR/BPR', ENT_QUOTES, 'UTF-8') ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage incoming batch manufacturing and batch packaging records
            </p>
        </div>
    </div>

    <!-- Incoming record widgets -->
    <div class="mb-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <div id="incomingProductionBmrWidget"
            class="incoming-production-form-widget cursor-pointer overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
            role="button" tabindex="0" aria-controls="incomingProductionBmrBprModal" data-form-type="BMR">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <p class="m-0 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">Incoming BMR(s)</p>
                    <p id="productionBmrCount" class="m-0 mt-2 text-3xl font-extrabold leading-none"
                        style="color: var(--appearance-accent, #166534);">0</p>
                    <p class="m-0 mt-2 text-xs font-medium text-slate-600">Pending your approval</p>
                </div>
                <span class="inline-flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl"
                    style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 14%, white); color: var(--appearance-accent, #166534);">
                    <i class="ti ti-bell-ringing text-3xl"></i>
                </span>
            </div>
        </div>

        <div id="incomingProductionBprWidget"
            class="incoming-production-form-widget cursor-pointer overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
            role="button" tabindex="0" aria-controls="incomingProductionBmrBprModal" data-form-type="BPR">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <p class="m-0 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">Incoming BPR(s)</p>
                    <p id="productionBprCount" class="m-0 mt-2 text-3xl font-extrabold leading-none"
                        style="color: var(--appearance-accent, #166534);">0</p>
                    <p class="m-0 mt-2 text-xs font-medium text-slate-600">Awaiting initial review</p>
                </div>
                <span class="inline-flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl"
                    style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 11%, white); color: var(--appearance-accent, #166534);">
                    <i class="ti ti-file-description text-3xl"></i>
                </span>
            </div>
        </div>
    </div>

    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
            <div class="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                <div class="dropdown shrink-0">
                    <button type="button"
                        class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <span id="productionBmrBprPerPageText" class="whitespace-nowrap">10 items</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu min-w-28 !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><button type="button" class="production-bmr-bpr-per-page dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-value="100000000">All items</button></li>
                        <li><button type="button" class="production-bmr-bpr-per-page dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-value="5">5 items</button></li>
                        <li><button type="button" class="production-bmr-bpr-per-page dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-value="10">10 items</button></li>
                        <li><button type="button" class="production-bmr-bpr-per-page dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-value="25">25 items</button></li>
                        <li><button type="button" class="production-bmr-bpr-per-page dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-value="50">50 items</button></li>
                        <li><button type="button" class="production-bmr-bpr-per-page dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-value="100">100 items</button></li>
                    </ul>
                </div>

                <div class="dropdown shrink-0">
                    <button type="button" class="flex h-10 items-center gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm" data-bs-toggle="dropdown">
                        <i class="ti ti-progress-check text-slate-400"></i><span id="productionBmrBprStatusText">All Statuses</span><i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu min-w-40 !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><button type="button" class="production-bmr-bpr-status-filter dropdown-item rounded-xl px-3 py-2 text-sm" data-status="all">All Statuses</button></li>
                        <li><button type="button" class="production-bmr-bpr-status-filter dropdown-item rounded-xl px-3 py-2 text-sm" data-status="QUEUED">Incoming</button></li>
                        <li><button type="button" class="production-bmr-bpr-status-filter dropdown-item rounded-xl px-3 py-2 text-sm" data-status="PENDING">Pending</button></li>
                        <li><button type="button" class="production-bmr-bpr-status-filter dropdown-item rounded-xl px-3 py-2 text-sm" data-status="IN_PROCESS">Draft / In-Process</button></li>
                        <li><button type="button" class="production-bmr-bpr-status-filter dropdown-item rounded-xl px-3 py-2 text-sm" data-status="COMPLETE">Completed</button></li>
                    </ul>
                </div>

                <div class="dropdown shrink-0">
                    <button type="button"
                        class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="inline-flex items-center gap-2 whitespace-nowrap">
                            <i class="ti ti-filter text-base text-slate-400"></i>
                            <span id="productionBmrBprFilterText">All Records</span>
                        </span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu min-w-36 !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><button type="button" class="production-bmr-bpr-filter dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-type="all">All Records</button></li>
                        <li><button type="button" class="production-bmr-bpr-filter dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-type="BMR">BMR Only</button></li>
                        <li><button type="button" class="production-bmr-bpr-filter dropdown-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-type="BPR">BPR Only</button></li>
                    </ul>
                </div>

                <div class="relative h-10 min-w-[180px] flex-1">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="ti ti-search text-lg text-slate-400"></i>
                    </div>
                    <input id="productionBmrBprSearch" type="search"
                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                        placeholder="Quick search..." autocomplete="off">
                </div>

                <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36 h-11" data-bs-toggle="modal" data-bs-target="#exportModal">
                    <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                </button>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full border-collapse text-left">
                <thead class="border-b border-slate-200 bg-slate-50/70 whitespace-nowrap">
                    <tr>
                        <th class="px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">S.No</th>
                        <th class="production-bmr-bpr-sortable cursor-pointer px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500 hover:bg-slate-100/60"
                            data-column="date">
                            <span class="inline-flex items-center gap-1">Date <i class="ti ti-arrows-sort text-xs"></i></span>
                        </th>
                        <th class="production-bmr-bpr-sortable cursor-pointer px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500 hover:bg-slate-100/60"
                            data-column="production_plan_no">
                            <span class="inline-flex items-center gap-1">Plan No <i class="ti ti-arrows-sort text-xs"></i></span>
                        </th>
                        <th class="production-bmr-bpr-sortable cursor-pointer px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500 hover:bg-slate-100/60"
                            data-column="product_name">
                            <span class="inline-flex items-center gap-1">Product Name <i class="ti ti-arrows-sort text-xs"></i></span>
                        </th>
                        <th class="production-bmr-bpr-sortable cursor-pointer px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500 hover:bg-slate-100/60"
                            data-column="lot_number">
                            <span class="inline-flex items-center gap-1">Lot Number <i class="ti ti-arrows-sort text-xs"></i></span>
                        </th>
                        <th class="px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">BMR Status</th>
                        <th class="px-6 py-4 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">BPR Status</th>
                        <th class="px-6 py-4 text-center text-[10px] font-extrabold uppercase tracking-widest text-slate-500">Action</th>
                    </tr>
                </thead>
                <tbody id="productionBmrBprTableBody" class="divide-y divide-slate-100 bg-white"></tbody>
            </table>
        </div>

        <div class="flex flex-col gap-3 border-t border-slate-200 bg-white px-6 py-4 sm:flex-row sm:items-center sm:justify-between">
            <span id="productionBmrBprSummary" class="text-sm font-medium text-slate-500">Showing 0 to 0 of 0 records</span>
            <div class="flex items-center gap-1">
                <button id="productionBmrBprPrevious" type="button"
                    class="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                    aria-label="Previous page" disabled>
                    <i class="ti ti-chevron-left"></i>
                </button>
                <div id="productionBmrBprCurrentPage" class="flex items-center gap-1"></div>
                <button id="productionBmrBprNext" type="button"
                    class="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                    aria-label="Next page" disabled>
                    <i class="ti ti-chevron-right"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="productionBmrBprLotModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-2xl">
            <div class="modal-header border-b border-slate-200 bg-white px-6 py-4">
                <div><h5 id="productionBmrBprLotTitle" class="m-0 text-lg font-extrabold text-slate-900">Plan / Lot Details</h5><p id="productionBmrBprLotSubtitle" class="m-0 mt-1 text-sm text-slate-500"></p></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-slate-50/60 px-6 py-5">
                <div class="overflow-hidden rounded-xl border border-slate-200 bg-white"><div class="overflow-x-auto"><table class="w-full text-left"><thead class="border-b border-slate-200 bg-slate-50"><tr><th class="px-5 py-3 text-xs font-bold text-slate-500">Form</th><th class="px-5 py-3 text-xs font-bold text-slate-500">Template</th><th class="px-5 py-3 text-xs font-bold text-slate-500">Status</th><th class="px-5 py-3 text-right text-xs font-bold text-slate-500">Action</th></tr></thead><tbody id="productionBmrBprLotItems" class="divide-y divide-slate-100"></tbody></table></div></div>
            </div>
        </div>
    </div>
</div>

<!-- Shared Incoming BMR/BPR Form Requests modal -->
<div class="modal fade" id="incomingProductionBmrBprModal" tabindex="-1"
    aria-labelledby="incomingProductionBmrBprModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-2xl">
            <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                <div>
                    <h5 id="incomingProductionBmrBprModalLabel" class="modal-title m-0 text-lg font-extrabold"
                        style="color: var(--appearance-accent, #166534);">
                        Incoming BMR / BPR Form Requests
                    </h5>
                    <p id="incomingProductionBmrBprModalSubtitle" class="m-0 mt-1 text-xs font-medium text-slate-500">
                        Select a record to issue the manufacturing or production form for the cleanroom staff.
                    </p>
                </div>
                <button type="button" class="btn-close mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body bg-white px-6 py-5">
                <div class="overflow-hidden rounded-xl border border-slate-200">
                    <div class="incoming-production-table-scroll">
                        <table class="w-full table-auto text-left text-sm text-slate-600">
                            <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                <tr>
                                    <th class="w-12 border-b border-slate-200 px-4 py-3">S.No</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Date</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Item Name</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Pack Size</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Batch Size</th>
                                    <th class="border-b border-slate-200 px-4 py-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="incomingProductionBmrBprTableBody" class="bg-white divide-y divide-slate-200"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="modal-footer flex-nowrap border-t border-slate-200 bg-slate-50/80 px-6 py-4">
                <div class="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <span id="incomingProductionBmrBprSummary" class="inline-flex items-center gap-2 text-xs font-medium text-slate-500">
                        <i class="ti ti-info-circle text-base"></i>
                        Showing 0 pending validation requests for today's shift.
                    </span>
                    <div class="flex items-center gap-1">
                        <button id="incomingProductionBmrBprPrevious" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                            aria-label="Previous page" disabled>
                            <i class="ti ti-chevron-left"></i>
                        </button>
                        <span id="incomingProductionBmrBprCurrentPage"
                            class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-extrabold"
                            style="color: var(--appearance-accent, #166534);">1</span>
                        <button id="incomingProductionBmrBprNext" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                            aria-label="Next page" disabled>
                            <i class="ti ti-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Export Document Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="productionBmrBprExportForm">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                        <div class="dropdown w-full">
                            <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                    </div>
                    
                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                            <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="S.No" checked />
                                    <span class="text-sm font-medium text-slate-700">S.No</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Date" checked />
                                    <span class="text-sm font-medium text-slate-700">Date</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product Name" checked />
                                    <span class="text-sm font-medium text-slate-700">Product Name</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Form Type" checked />
                                    <span class="text-sm font-medium text-slate-700">Form Type</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Lot Number" checked />
                                    <span class="text-sm font-medium text-slate-700">Lot Number</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked />
                                    <span class="text-sm font-medium text-slate-700">Status</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                        <i class="ti ti-download text-base"></i> Export
                    </button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    #incomingProductionBmrBprModal .modal-dialog {
        width: calc(100% - 2rem);
        max-width: 1480px;
    }

    #incomingProductionBmrBprModal .incoming-production-item-cell {
        min-width: 520px;
    }

    #incomingProductionBmrBprModal .incoming-production-item-name {
        white-space: nowrap;
    }

    #incomingProductionBmrBprModal .incoming-production-item-dot {
        flex: 0 0 auto;
    }

    #incomingProductionBmrBprModal .incoming-production-item-meta {
        margin-top: 0.25rem;
        padding-left: 0.875rem;
    }

    #incomingProductionBmrBprModal .incoming-production-table-scroll {
        height: 334px;
        overflow-x: auto;
        overflow-y: auto;
        scrollbar-gutter: stable;
    }

    #incomingProductionBmrBprModal .incoming-production-table-scroll thead {
        position: sticky;
        top: 0;
        z-index: 2;
    }

    #productionBmrBprFormModal {
        z-index: 1070;
    }

    .modal-backdrop.production-bmr-bpr-form-backdrop {
        z-index: 1065;
    }

    #productionBmrBprFormModal .modal-dialog {
        width: calc(100% - 2rem);
        max-width: 1320px;
    }

    #productionBmrBprFormModal .modal-body {
        overflow-x: hidden;
    }

    #productionBmrBprFormModal .production-bmr-bpr-preview-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 250px;
        align-items: start;
        gap: 1.25rem;
    }

    #productionBmrBprFormModal .production-bmr-bpr-preview-document {
        min-width: 0;
    }

    #productionBmrBprFormModal .production-bmr-bpr-actions-sidebar {
        position: sticky;
        top: 0;
        grid-column: 2;
        min-width: 0;
        align-self: start;
    }

    #productionBmrBprFormModal .production-bmr-bpr-actions-card {
        overflow: hidden;
        border: 1px solid #e2e8f0;
        border-radius: .75rem;
        background: #fff;
        box-shadow: 0 1px 3px rgba(15, 23, 42, .08);
    }

    #productionBmrBprFormModal .production-bmr-bpr-actions-card-header {
        border-bottom: 1px solid #e2e8f0;
        background: #f8fafc;
        padding: .8rem 1rem;
    }

    #productionBmrBprFormModal .production-bmr-bpr-actions-card-body {
        padding: 1rem;
    }

    .production-bmr-bpr-document {
        overflow-x: auto;
        color: #172033;
        font-family: Arial, Helvetica, sans-serif;
    }

    .production-bmr-bpr-document table {
        margin: 0;
    }

    .production-bmr-bpr-document th,
    .production-bmr-bpr-document td {
        border-color: #cbd5e1;
    }

    .production-bmr-bpr-document .bmr-v2-document th,
    .production-bmr-bpr-document .bmr-v2-document td {
        border-color: #111;
    }

    .production-bmr-bpr-document .bmr-v2-page {
        box-shadow: 0 1px 4px rgba(15, 23, 42, 0.18);
    }

    .production-bmr-bpr-document .bmr-v2-page + .bmr-v2-page {
        margin-top: 1rem;
    }

    .production-bmr-bpr-document-section-title {
        border-left: 4px solid var(--appearance-accent, #166534);
        background: #eef2ff;
    }

    .bmr-bpr-template-page {
        position: relative;
        width: 100%;
        overflow: hidden;
        background: #fff;
        box-shadow: 0 1px 4px rgba(15, 23, 42, 0.18);
    }

    .bmr-bpr-template-page + .bmr-bpr-template-page {
        margin-top: 1rem;
    }

    .bmr-bpr-template-page-image {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: fill;
        pointer-events: none;
        user-select: none;
    }

    .bmr-bpr-template-field {
        position: absolute;
        z-index: 2;
        margin: 0;
        min-width: 0;
        min-height: 0;
        border: 1px dashed transparent;
        border-radius: 2px;
        background: rgba(254, 249, 195, 0.24);
        color: #111827;
        font-family: Arial, Helvetica, sans-serif;
        line-height: 1.05;
        padding: 1px 2px;
        resize: none;
        overflow: hidden;
        outline: none;
    }

    .bmr-bpr-template-field:hover,
    .bmr-bpr-template-field:focus {
        border-color: color-mix(in srgb, var(--appearance-accent, #166534) 65%, white);
        background: rgba(254, 249, 195, 0.68);
        box-shadow: 0 0 0 1px color-mix(in srgb, var(--appearance-accent, #166534) 18%, transparent);
    }

    .bmr-bpr-template-field:disabled {
        border-color: transparent;
        background: transparent;
        opacity: 1;
        -webkit-text-fill-color: #111827;
    }

    .bmr-bpr-template-field.is-custom {
        z-index: 4;
        min-width: 80px;
        min-height: 24px;
        resize: both;
    }

    .bmr-bpr-template-source-value {
        position: absolute;
        z-index: 3;
        display: flex;
        align-items: center;
        overflow: hidden;
        padding: 1px 3px;
        color: #000;
        font-family: Arial, Helvetica, sans-serif;
        font-weight: 400;
        line-height: 1.05;
        pointer-events: none;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
    }

    @media (max-width: 899.98px) {
        #productionBmrBprFormModal .modal-dialog {
            max-width: none;
        }

        #productionBmrBprFormModal .production-bmr-bpr-preview-layout {
            grid-template-columns: minmax(0, 1fr);
        }

        #productionBmrBprFormModal .production-bmr-bpr-actions-sidebar {
            position: static;
            grid-column: 1;
        }
    }
</style>

<!-- Nested BMR/BPR document preview modal -->
<div class="modal fade" id="productionBmrBprFormModal" tabindex="-1"
    aria-labelledby="productionBmrBprFormModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-2xl">
            <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                <div class="flex min-w-0 items-start gap-3">
                    <span class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                        style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 10%, white); color: var(--appearance-accent, #166534);">
                        <i class="ti ti-file-description text-xl"></i>
                    </span>
                    <div>
                        <h5 id="productionBmrBprFormModalLabel" class="modal-title m-0 text-base font-extrabold text-slate-900">
                            Batch Manufacturing Record
                        </h5>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-500">
                            Review and complete the selected production record.
                        </p>
                    </div>
                </div>
                <button type="button" class="btn-close mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body bg-slate-100 p-4 md:p-5">
                <input type="hidden" id="productionBmrBprSelectedRequestId">
                <div class="production-bmr-bpr-preview-layout">
                    <article class="production-bmr-bpr-document production-bmr-bpr-preview-document border border-slate-300 bg-white p-5 shadow-sm md:p-7">
                        <div class="grid grid-cols-1 border border-slate-700 md:grid-cols-[210px_minmax(0,1fr)_180px]">
                            <div class="flex min-h-28 items-center justify-center border-b border-slate-700 p-4 md:border-b-0 md:border-r">
                                <div class="text-center">
                                    <div class="flex items-center justify-center gap-2">
                                        <span class="inline-flex h-9 w-9 items-center justify-center rounded-full text-base font-black text-white"
                                            style="background-color: var(--appearance-accent, #166534);">B</span>
                                        <span class="text-xl font-black tracking-tight text-slate-800">BIOGENIX</span>
                                    </div>
                                    <p class="m-0 mt-2 text-[8px] font-bold leading-3 text-slate-500">
                                        BIOGENIX HEALTHCARE PVT. LTD.<br>
                                        Industrial Area, Maharashtra
                                    </p>
                                </div>
                            </div>
                            <div class="flex min-h-28 items-center justify-center border-b border-slate-700 p-4 text-center md:border-b-0 md:border-r">
                                <div>
                                    <h6 id="productionBmrBprDocumentTitle" class="m-0 text-lg font-black uppercase text-slate-800">
                                        Batch Manufacturing Record
                                    </h6>
                                    <p id="productionBmrBprDocumentType" class="m-0 mt-2 text-xs font-bold text-slate-600">(BMR)</p>
                                </div>
                            </div>
                            <div class="grid grid-cols-[72px_minmax(0,1fr)] text-[9px]">
                                <span class="border-b border-r border-slate-300 px-2 py-1 font-bold">Doc No.</span>
                                <span id="productionBmrBprDocNumber" class="border-b border-slate-300 px-2 py-1 text-right">BMR-F-001</span>
                                <span class="border-b border-r border-slate-300 px-2 py-1 font-bold">Issue No.</span>
                                <span class="border-b border-slate-300 px-2 py-1 text-right">01</span>
                                <span class="border-b border-r border-slate-300 px-2 py-1 font-bold">Rev No.</span>
                                <span class="border-b border-slate-300 px-2 py-1 text-right">02</span>
                                <span class="border-b border-r border-slate-300 px-2 py-1 font-bold">Eff. Date</span>
                                <span class="border-b border-slate-300 px-2 py-1 text-right">03/04/2025</span>
                                <span class="border-b border-r border-slate-300 px-2 py-1 font-bold">Rev. Date</span>
                                <span class="border-b border-slate-300 px-2 py-1 text-right">03/04/2028</span>
                                <span class="border-b border-r border-slate-300 px-2 py-1 font-bold">Dept.</span>
                                <span class="border-b border-slate-300 px-2 py-1 text-right">Production</span>
                                <span class="border-r border-slate-300 px-2 py-1 font-bold">Page</span>
                                <span class="px-2 py-1 text-right">1 of 4</span>
                            </div>
                        </div>

                        <div class="mt-6 border-b-2 border-slate-700 pb-3">
                            <h3 id="productionBmrBprProductName" class="m-0 text-xl font-black uppercase"
                                style="color: var(--appearance-accent, #166534);">Product Name</h3>
                            <p id="productionBmrBprProductDescription" class="m-0 mt-1 text-xs font-medium text-slate-600"></p>
                        </div>

                        <section class="mt-5">
                            <h4 class="production-bmr-bpr-document-section-title m-0 px-3 py-2 text-xs font-black uppercase tracking-wide">
                                01. Batch Information
                            </h4>
                            <div class="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                                <div class="border border-slate-300 bg-indigo-50 px-3 py-2">
                                    <p class="m-0 text-[8px] font-black uppercase tracking-wide text-slate-500">Batch Number</p>
                                    <p id="productionBmrBprBatchNumber" class="m-0 mt-1 font-mono text-base font-black text-slate-800"></p>
                                </div>
                                <div class="border border-slate-300 bg-indigo-50 px-3 py-2">
                                    <p class="m-0 text-[8px] font-black uppercase tracking-wide text-slate-500">Mfg. Date</p>
                                    <p id="productionBmrBprMfgDate" class="m-0 mt-1 text-base font-black text-slate-800">JUL 2026</p>
                                </div>
                                <div class="border border-slate-300 bg-indigo-50 px-3 py-2">
                                    <p class="m-0 text-[8px] font-black uppercase tracking-wide text-slate-500">Exp. Date</p>
                                    <p id="productionBmrBprExpDate" class="m-0 mt-1 text-base font-black text-slate-800">JUN 2028</p>
                                </div>
                                <div class="border border-slate-300 bg-indigo-50 px-3 py-2">
                                    <p class="m-0 text-[8px] font-black uppercase tracking-wide text-slate-500">Batch Size</p>
                                    <p id="productionBmrBprBatchSize" class="m-0 mt-1 text-base font-black text-slate-800"></p>
                                </div>
                                <div class="border border-slate-300 bg-indigo-50 px-3 py-2">
                                    <p class="m-0 text-[8px] font-black uppercase tracking-wide text-slate-500">Market</p>
                                    <p class="m-0 mt-1 text-base font-black text-slate-800">Domestic / Export</p>
                                </div>
                                <div class="border border-slate-300 bg-indigo-50 px-3 py-2">
                                    <p class="m-0 text-[8px] font-black uppercase tracking-wide text-slate-500">PO Reference</p>
                                    <p id="productionBmrBprPoReference" class="m-0 mt-1 font-mono text-sm font-black text-slate-800"></p>
                                </div>
                            </div>
                        </section>

                        <section class="mt-5">
                            <h4 class="production-bmr-bpr-document-section-title m-0 px-3 py-2 text-xs font-black uppercase tracking-wide">
                                02. Bill of Materials (Raw Materials)
                            </h4>
                            <div class="mt-3 overflow-x-auto border border-slate-300">
                                <table class="w-full border-collapse text-left text-[9px]">
                                    <thead class="bg-indigo-100/80">
                                        <tr>
                                            <th class="border-r border-slate-300 px-3 py-2 text-center font-black">S.No</th>
                                            <th class="border-r border-slate-300 px-3 py-2 font-black">Material Name</th>
                                            <th class="border-r border-slate-300 px-3 py-2 font-black">CAT / Item No.</th>
                                            <th class="border-r border-slate-300 px-3 py-2 text-center font-black">Unit</th>
                                            <th class="px-3 py-2 text-right font-black">Planned Qty</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">1</td>
                                            <td class="border-r border-slate-300 px-3 py-2">Active Reagent Base (Multi-Cal)</td>
                                            <td class="border-r border-slate-300 px-3 py-2 font-mono">ARB-MC-004</td>
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">Ltr</td>
                                            <td class="px-3 py-2 text-right font-mono">66.00</td>
                                        </tr>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">2</td>
                                            <td class="border-r border-slate-300 px-3 py-2">Stabilizing Buffer Solution</td>
                                            <td class="border-r border-slate-300 px-3 py-2 font-mono">SBS-2024</td>
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">Ltr</td>
                                            <td class="px-3 py-2 text-right font-mono">124.50</td>
                                        </tr>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">3</td>
                                            <td class="border-r border-slate-300 px-3 py-2">Purified Water (Pharma Grade)</td>
                                            <td class="border-r border-slate-300 px-3 py-2 font-mono">PW-USP-99</td>
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">Ltr</td>
                                            <td class="px-3 py-2 text-right font-mono">309.50</td>
                                        </tr>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">4</td>
                                            <td class="border-r border-slate-300 px-3 py-2">Coloration Dye - Sky Blue</td>
                                            <td class="border-r border-slate-300 px-3 py-2 font-mono">DYE-B44</td>
                                            <td class="border-r border-slate-300 px-3 py-2 text-center">gm</td>
                                            <td class="px-3 py-2 text-right font-mono">0.02</td>
                                        </tr>
                                    </tbody>
                                    <tfoot class="border-t border-slate-300 bg-indigo-50">
                                        <tr>
                                            <td colspan="4" class="border-r border-slate-300 px-3 py-2 text-right font-black">Total Volume</td>
                                            <td class="px-3 py-2 text-right font-mono font-black">500.02 Ltr</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </section>

                        <section class="mt-5">
                            <h4 class="production-bmr-bpr-document-section-title m-0 px-3 py-2 text-xs font-black uppercase tracking-wide">
                                03. Process Parameters Checklist
                            </h4>
                            <div class="mt-3 overflow-x-auto border border-slate-300">
                                <table class="w-full border-collapse text-left text-[9px]">
                                    <thead class="bg-indigo-50">
                                        <tr>
                                            <th class="border-r border-slate-300 px-3 py-2 text-center font-black">No.</th>
                                            <th class="border-r border-slate-300 px-3 py-2 font-black">Critical Parameter Description</th>
                                            <th class="border-r border-slate-300 px-3 py-2 font-black">Standard Limit</th>
                                            <th class="px-3 py-2 text-center font-black">Observed</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-3 text-center">3.1</td>
                                            <td class="border-r border-slate-300 px-3 py-3">Mixing Speed (Vessel A-04)</td>
                                            <td class="border-r border-slate-300 px-3 py-3">450 ± 20 RPM</td>
                                            <td class="px-3 py-3 text-center"><input id="productionBmrBprObserved1" name="observed_1" type="text" class="h-7 w-16 border border-slate-300 bg-slate-50 px-1 text-center text-xs outline-none"></td>
                                        </tr>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-3 text-center">3.2</td>
                                            <td class="border-r border-slate-300 px-3 py-3">pH Value after Stabilization</td>
                                            <td class="border-r border-slate-300 px-3 py-3">7.40 ± 0.05</td>
                                            <td class="px-3 py-3 text-center"><input id="productionBmrBprObserved2" name="observed_2" type="text" class="h-7 w-16 border border-slate-300 bg-slate-50 px-1 text-center text-xs outline-none"></td>
                                        </tr>
                                        <tr class="border-t border-slate-300">
                                            <td class="border-r border-slate-300 px-3 py-3 text-center">3.3</td>
                                            <td class="border-r border-slate-300 px-3 py-3">Final Solution Temperature</td>
                                            <td class="border-r border-slate-300 px-3 py-3">18°C - 22°C</td>
                                            <td class="px-3 py-3 text-center"><input id="productionBmrBprObserved3" name="observed_3" type="text" class="h-7 w-16 border border-slate-300 bg-slate-50 px-1 text-center text-xs outline-none"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </section>

                        <div class="mt-10 grid grid-cols-1 gap-8 text-[8px] uppercase text-slate-500 sm:grid-cols-3">
                            <div>
                                <div class="border-t border-slate-400 pt-2 font-bold">Prepared By (Production)</div>
                                <p class="m-0 mt-7 text-xs font-black normal-case text-slate-700">MR/QA Team</p>
                                <p class="m-0 mt-1 normal-case text-slate-400">Date: 29-Jul-2026</p>
                            </div>
                            <div>
                                <div class="border-t border-slate-400 pt-2 font-bold">Verified By (QC)</div>
                                <div class="mt-4 inline-flex h-12 w-12 items-center justify-center border border-slate-300 bg-slate-50">
                                    <i class="ti ti-fingerprint text-2xl text-slate-400"></i>
                                </div>
                            </div>
                            <div>
                                <div class="border-t border-slate-400 pt-2 font-bold">Approved By (QA Head)</div>
                                <p class="m-0 mt-7 text-xs font-black normal-case text-slate-700">Director - Operations</p>
                                <p class="m-0 mt-1 normal-case text-slate-400">Date: 29-Jul-2026</p>
                            </div>
                        </div>

                        <div class="mt-10 border-t border-slate-300 pt-3 text-center text-[7px] font-bold uppercase tracking-wider text-slate-400">
                            © 2026 Biogenix Healthcare Pvt Ltd | Confidential Manufacturing Record | Internal Use Only
                        </div>
                    </article>

                    <aside class="production-bmr-bpr-actions-sidebar invoice-actions space-y-4">
                        <section class="production-bmr-bpr-actions-card">
                            <div class="production-bmr-bpr-actions-card-header">
                                <h6 class="m-0 text-[11px] font-black uppercase tracking-wide text-slate-600">Record Actions</h6>
                            </div>
                            <div class="production-bmr-bpr-actions-card-body">
                                <div class="space-y-3">
                                <button type="button" class="production-bmr-bpr-form-action inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg text-sm font-bold text-white shadow-sm transition-opacity hover:opacity-90"
                                    style="background-color: var(--appearance-accent, #166534);" data-action="submit">
                                    <i class="ti ti-circle-check text-lg"></i>Submit
                                </button>
                                <button type="button" class="production-bmr-bpr-form-action inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-slate-300 bg-indigo-50 text-sm font-bold text-slate-700 transition-colors hover:bg-indigo-100"
                                    data-action="draft">
                                    <i class="ti ti-mail text-lg"></i>Save Draft
                                </button>
                                </div>
                                <div class="my-4 flex items-center gap-2">
                                    <span class="h-px flex-1 bg-slate-200"></span>
                                    <span class="text-[8px] font-black uppercase tracking-widest text-slate-400">Reporting</span>
                                    <span class="h-px flex-1 bg-slate-200"></span>
                                </div>
                                <button type="button"
                                    class="production-bmr-bpr-form-action biogenix-btn-download inline-flex h-11 w-full items-center justify-center gap-2 text-sm font-bold"
                                    data-action="download">
                                    <i class="ti ti-download text-lg"></i>Download PDF
                                </button>
                            </div>
                        </section>

                        <section class="rounded-xl border border-blue-200 bg-blue-50 p-4 shadow-sm">
                            <h6 class="m-0 text-[10px] font-black uppercase tracking-wide text-blue-700">Record Metadata</h6>
                            <dl class="m-0 mt-3 space-y-2 text-[10px]">
                                <div class="flex items-center justify-between gap-3">
                                    <dt class="font-medium text-slate-500">Created By:</dt>
                                    <dd class="m-0 text-right font-bold text-slate-700">System Admin</dd>
                                </div>
                                <div class="flex items-center justify-between gap-3">
                                    <dt class="font-medium text-slate-500">Template ID:</dt>
                                    <dd id="productionBmrBprTemplateId" class="m-0 text-right font-mono font-bold text-slate-700">BMR-STD-V2.1</dd>
                                </div>
                                <div class="flex items-center justify-between gap-3">
                                    <dt class="font-medium text-slate-500">Last Saved:</dt>
                                    <dd class="m-0 text-right font-bold text-slate-700">Today, 10:45 AM</dd>
                                </div>
                            </dl>
                        </section>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    (function () {
        'use strict';

        let productionBmrBprRecords = [];
        let incomingProductionFormRequests = { BMR: [], BPR: [] };
        let productionBmrBprListRequest = null;
        let productionBmrBprOpenRequestPending = false;
        let productionBmrBprActiveForm = null;
        const productionBmrBprFallbackDocumentHtml = $('.production-bmr-bpr-document').html();
        const productionBmrBprCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

        let productionBmrBprPage = 1;
        let productionBmrBprPerPage = 10;
        let productionBmrBprType = 'all';
        let productionBmrBprStatus = 'all';
        let productionBmrBprSortColumn = 'activity_at';
        let productionBmrBprSortDirection = 'desc';
        let incomingProductionFormType = 'BMR';
        let incomingProductionFormPage = 1;
        const incomingProductionFormsPerPage = 10;

        function escapeProductionBmrBprText(value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        }

        function productionBmrBprStatusBadge(status) {
            const normalized = String(status || '').toLowerCase();
            const styles = {
                'complete': ['#ecfdf5', '#047857', '#a7f3d0'],
                'pending': ['#fffbeb', '#b45309', '#fde68a'],
                'in-process': ['#eff6ff', '#2563eb', '#bfdbfe'],
                'incoming': ['#f5f3ff', '#6d28d9', '#ddd6fe'],
                'not configured': ['#f8fafc', '#64748b', '#e2e8f0']
            };
            const selected = styles[normalized] || ['#f8fafc', '#475569', '#e2e8f0'];
            return `<span class="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold"
                style="background-color: ${selected[0]}; color: ${selected[1]}; border: 1px solid ${selected[2]};">
                <span class="h-1.5 w-1.5 rounded-full" style="background-color: ${selected[1]};"></span>
                ${escapeProductionBmrBprText(status)}
            </span>`;
        }

        function productionBmrBprTemplateFamily(record) {
            const templateCode = String(record?.template_code || '').trim().toUpperCase();
            if (templateCode.startsWith('COMMON_SEROLOGY_')) {
                return 'Serology';
            }
            if (templateCode.startsWith('COMMON_MICROBIOLOGY_')) {
                return 'Microbiology';
            }
            if (templateCode.startsWith('COMMON_UROLOGY_')) {
                return 'Urology';
            }
            if (templateCode.startsWith('COMMON_BIOCHEMISTRY_')) {
                return 'Biochemistry';
            }
            if (templateCode.startsWith('COMMON_RAPID_')) {
                return 'Rapid';
            }
            return '';
        }

        function productionBmrBprTemplateFamilyText(record) {
            const family = productionBmrBprTemplateFamily(record);
            return family === ''
                ? ''
                : `<span class="ml-2 text-[10px] font-extrabold tracking-wide text-violet-700">
                    ${escapeProductionBmrBprText(family)}
                </span>`;
        }

        function loadProductionBmrBprRecords(resetPage = true, silent = false) {
            if (
                productionBmrBprOpenRequestPending
                || (productionBmrBprListRequest && productionBmrBprListRequest.readyState !== 4)
            ) {
                return;
            }
            productionBmrBprListRequest = $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    loadProductionBmrBpr: 'loadProductionBmrBpr',
                    csrf_token: productionBmrBprCsrf
                },
                success: function (response) {
                    if (response.status !== 'success') {
                        if (!silent) toastr.error(response.message || 'Unable to load Production BMR/BPR records.');
                        return;
                    }
                    productionBmrBprRecords = response.data?.records || [];
                    incomingProductionFormRequests = response.data?.incoming || { BMR: [], BPR: [] };
                    const counts = response.data?.counts || {};
                    $('#productionBmrCount').text(String(Number(counts.BMR || 0)).padStart(2, '0'));
                    $('#productionBprCount').text(String(Number(counts.BPR || 0)).padStart(2, '0'));
                    if (resetPage) productionBmrBprPage = 1;
                    renderProductionBmrBprRecords();
                    renderIncomingProductionFormRequests();
                },
                error: function (xhr) {
                    if (silent) return;
                    toastr.error(xhr.responseJSON?.message || 'Unable to load Production BMR/BPR records.');
                    productionBmrBprRecords = [];
                    incomingProductionFormRequests = { BMR: [], BPR: [] };
                    $('#productionBmrCount, #productionBprCount').text('00');
                    renderProductionBmrBprRecords();
                    renderIncomingProductionFormRequests();
                },
                complete: function () {
                    productionBmrBprListRequest = null;
                }
            });
        }

        function productionBmrBprAggregateStatus(items, formType) {
            const statuses = items.filter(item => item.form_type === formType).map(item => String(item.status_code || '').toUpperCase());
            if (!statuses.length) return 'Not configured';
            if (statuses.includes('IN_PROCESS')) return 'In-Process';
            if (statuses.includes('PENDING')) return 'Pending';
            if (statuses.includes('QUEUED')) return 'Incoming';
            if (statuses.every(status => status === 'COMPLETE')) return 'Complete';
            return statuses[0];
        }

        function groupedProductionBmrBprRecords() {
            const groups = new Map();
            productionBmrBprRecords.forEach(function (record) {
                const productionPlanId = Number(record.production_plan_id || 0);
                const normalizedLot = String(record.lot_number || '').trim().toLowerCase();
                const key = productionPlanId > 0
                    ? `plan:${productionPlanId}|lot:${normalizedLot}`
                    : `request:${record.request_id || record.id}|lot:${normalizedLot}`;
                if (!groups.has(key)) {
                    groups.set(key, {
                        group_key: key,
                        request_id: record.request_id,
                        request_ids: [],
                        serial_number: productionPlanId || Number(record.request_id || record.id),
                        activity_at: record.activity_at || '',
                        date: record.date,
                        production_plan_id: record.production_plan_id,
                        production_plan_no: record.production_plan_no || '-',
                        product_name: record.product_name,
                        lot_number: record.lot_number,
                        items: []
                    });
                }
                if (!groups.get(key).request_ids.includes(String(record.request_id))) {
                    groups.get(key).request_ids.push(String(record.request_id));
                }
                groups.get(key).items.push(record);
                if (String(record.activity_at || '') > String(groups.get(key).activity_at || '')) {
                    groups.get(key).activity_at = record.activity_at || '';
                }
            });
            return Array.from(groups.values()).map(function (group) {
                group.bmr_status = productionBmrBprAggregateStatus(group.items, 'BMR');
                group.bpr_status = productionBmrBprAggregateStatus(group.items, 'BPR');
                return group;
            });
        }

        function filteredProductionBmrBprRecords() {
            const query = String($('#productionBmrBprSearch').val() || '').trim().toLowerCase();
            const rows = groupedProductionBmrBprRecords().filter(function (record) {
                const matchesType = productionBmrBprType === 'all' || record.items.some(item => item.form_type === productionBmrBprType);
                const matchesStatus = productionBmrBprStatus === 'all' || record.items.some(item => String(item.status_code).toUpperCase() === productionBmrBprStatus);
                const searchable = [
                    record.serial_number,
                    record.date,
                    record.production_plan_no,
                    record.product_name,
                    record.lot_number,
                    record.bmr_status,
                    record.bpr_status,
                    record.items.map(item => productionBmrBprTemplateFamily(item)).join(' ')
                ].join(' ').toLowerCase();
                return matchesType && matchesStatus && (!query || searchable.includes(query));
            });

            rows.sort(function (left, right) {
                const comparison = String(left[productionBmrBprSortColumn] || '').localeCompare(
                    String(right[productionBmrBprSortColumn] || ''),
                    undefined,
                    { numeric: true, sensitivity: 'base' }
                );
                return productionBmrBprSortDirection === 'asc' ? comparison : -comparison;
            });
            return rows;
        }

        function renderProductionBmrBprRecords() {
            const rows = filteredProductionBmrBprRecords();
            const totalPages = Math.max(1, Math.ceil(rows.length / productionBmrBprPerPage));
            productionBmrBprPage = Math.min(Math.max(1, productionBmrBprPage), totalPages);
            const offset = (productionBmrBprPage - 1) * productionBmrBprPerPage;
            const visibleRows = rows.slice(offset, offset + productionBmrBprPerPage);

            if (visibleRows.length === 0) {
                $('#productionBmrBprTableBody').html(`<tr>
                    <td colspan="8" class="px-6 py-12 text-center">
                        <span class="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-400">
                            <i class="ti ti-file-off text-2xl"></i>
                        </span>
                        <p class="m-0 text-sm font-bold text-slate-700">No BMR/BPR records found.</p>
                    </td>
                </tr>`);
            } else {
                $('#productionBmrBprTableBody').html(visibleRows.map(function (record, index) {
                    return `<tr class="production-bmr-bpr-lot-row cursor-pointer transition-colors hover:bg-slate-50/60" data-group-key="${escapeProductionBmrBprText(record.group_key)}" tabindex="0">
                        <td class="px-6 py-4 text-xs font-bold text-slate-700">${String(offset + index + 1).padStart(2, '0')}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-xs font-medium text-slate-600">${escapeProductionBmrBprText(record.date)}</td>
                        <td class="px-6 py-4 whitespace-nowrap font-mono text-xs font-bold text-indigo-700">${escapeProductionBmrBprText(record.production_plan_no)}</td>
                        <td class="px-6 py-4 text-sm font-bold" style="color: var(--appearance-accent, #166534);">
                            ${escapeProductionBmrBprText(record.product_name)}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap font-mono text-xs font-bold text-slate-600">${escapeProductionBmrBprText(record.lot_number)}</td>
                        <td class="px-6 py-4">${productionBmrBprStatusBadge(record.bmr_status)}</td>
                        <td class="px-6 py-4">${productionBmrBprStatusBadge(record.bpr_status)}</td>
                        <td class="px-6 py-4 text-center">
                            <button type="button" class="production-bmr-bpr-lot-view inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition-colors hover:bg-slate-100"
                                data-group-key="${escapeProductionBmrBprText(record.group_key)}" title="View plan/lot" aria-label="View ${escapeProductionBmrBprText(record.product_name)}">
                                <i class="ti ti-eye text-base"></i>
                            </button>
                        </td>
                    </tr>`;
                }).join(''));
            }

            const first = rows.length === 0 ? 0 : offset + 1;
            const last = rows.length === 0 ? 0 : Math.min(offset + productionBmrBprPerPage, rows.length);
            $('#productionBmrBprSummary').text(`Showing ${first} to ${last} of ${rows.length} records`);
            $('#productionBmrBprCurrentPage').html(productionBmrBprPageButtons(totalPages, productionBmrBprPage));
            $('#productionBmrBprPrevious').prop('disabled', productionBmrBprPage <= 1);
            $('#productionBmrBprNext').prop('disabled', productionBmrBprPage >= totalPages);
            $('#exportProductionBmrBpr').prop('disabled', rows.length === 0);
        }

        function productionBmrBprPageButtons(totalPages, currentPage) {
            const pages = [...new Set([1, totalPages, currentPage - 2, currentPage - 1, currentPage, currentPage + 1, currentPage + 2].filter(page => page >= 1 && page <= totalPages))].sort((a, b) => a - b);
            let previous = 0;
            return pages.map(function (page) {
                const gap = previous && page > previous + 1 ? '<span class="px-1 text-slate-400">&hellip;</span>' : '';
                previous = page;
                const active = page === currentPage ? 'bg-emerald-800 text-white' : 'border border-slate-200 bg-white text-slate-600 hover:bg-slate-50';
                return gap + `<button type="button" data-page="${page}" class="production-bmr-bpr-page inline-flex h-9 min-w-9 items-center justify-center rounded-xl px-3 text-sm font-bold ${active}">${page}</button>`;
            }).join('');
        }

        function openProductionBmrBprLot(groupKey) {
            const group = groupedProductionBmrBprRecords().find(item => String(item.group_key) === String(groupKey));
            if (!group) return;
            $('#productionBmrBprLotTitle').text(`${group.production_plan_no || 'Production Plan'} · ${group.lot_number || 'No Lot'}`);
            $('#productionBmrBprLotSubtitle').text(`${group.product_name} · ${group.date}`);
            $('#productionBmrBprLotItems').html(group.items.map(function (record) {
                const complete = String(record.status_code).toUpperCase() === 'COMPLETE';
                return `<tr><td class="px-5 py-3 font-bold text-slate-900">${escapeProductionBmrBprText(record.form_label || record.form_type)}</td><td class="px-5 py-3 text-xs text-slate-600">${escapeProductionBmrBprText(record.template_code || 'Compatibility form')}</td><td class="px-5 py-3">${productionBmrBprStatusBadge(record.status)}</td><td class="px-5 py-3 text-right"><button type="button" class="production-bmr-bpr-lot-form rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white" data-id="${record.id}"><i class="ti ti-eye mr-1"></i>${complete ? 'View' : 'Open'}</button></td></tr>`;
            }).join(''));
            $('#productionBmrBprLotModal').modal('show');
        }

        function renderIncomingProductionFormRequests() {
            const records = incomingProductionFormRequests[incomingProductionFormType] || [];
            const totalPages = Math.max(1, Math.ceil(records.length / incomingProductionFormsPerPage));
            incomingProductionFormPage = Math.min(Math.max(1, incomingProductionFormPage), totalPages);
            const offset = (incomingProductionFormPage - 1) * incomingProductionFormsPerPage;
            const visibleRecords = records.slice(offset, offset + incomingProductionFormsPerPage);

            $('#incomingProductionBmrBprModalLabel').text(`Incoming ${incomingProductionFormType} Form Requests`);
            $('#incomingProductionBmrBprModalSubtitle').text(
                incomingProductionFormType === 'BMR'
                    ? 'Select a record to issue the manufacturing form for the cleanroom staff.'
                    : 'Select a record to issue the production form for the cleanroom staff.'
            );

            if (visibleRecords.length === 0) {
                $('#incomingProductionBmrBprTableBody').html(`<tr>
                    <td colspan="6" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">
                        No incoming ${escapeProductionBmrBprText(incomingProductionFormType)} form requests available.
                    </td>
                </tr>`);
            } else {
                $('#incomingProductionBmrBprTableBody').html(visibleRecords.map(function (record) {
                    const templateFamily = productionBmrBprTemplateFamily(record);
                    const canOpen = Boolean(record.can_open);
                    const waitingForIpCoa = record.form_type === 'BPR'
                        && record.bmr_status_code === 'COMPLETE'
                        && !record.ip_coa_approved;
                    const waitingTitle = waitingForIpCoa
                        ? 'An approved In-Process COA is required before opening this BPR.'
                        : 'Complete every related BMR before opening this BPR.';
                    const waitingLabel = waitingForIpCoa ? 'Waiting for IP COA' : 'Waiting for BMR';
                    const templateFamilyText = templateFamily === ''
                        ? ''
                        : `<span class="text-[10px] font-extrabold tracking-wide text-violet-700">
                            ${escapeProductionBmrBprText(templateFamily)}
                        </span>`;
                    return `<tr>
                        <td class="px-4 py-2 align-middle whitespace-nowrap">${String(record.serial_number).padStart(2, '0')}</td>
                        <td class="px-4 py-2 align-middle whitespace-nowrap">${escapeProductionBmrBprText(record.date)}</td>
                        <td class="incoming-production-item-cell px-4 py-2 align-middle">
                            <div class="flex items-center gap-2">
                                <span class="incoming-production-item-dot h-1.5 w-1.5 rounded-full" style="background-color: var(--appearance-accent, #166534);"></span>
                                <span class="incoming-production-item-name">${escapeProductionBmrBprText(record.item_name)}</span>
                            </div>
                            <div class="incoming-production-item-meta flex items-center gap-2">
                                <span class="badge bg-label-secondary" style="font-size: 9px; padding: 0.25rem 0.4rem;">
                                    ${escapeProductionBmrBprText(record.form_label || record.form_type)}
                                </span>
                                ${templateFamilyText}
                            </div>
                        </td>
                        <td class="px-4 py-2 align-middle whitespace-nowrap">${escapeProductionBmrBprText(record.pack_size)}</td>
                        <td class="px-4 py-2 align-middle whitespace-nowrap">${escapeProductionBmrBprText(record.batch_size)}</td>
                        <td class="px-4 py-2 align-middle whitespace-nowrap text-center">
                            ${canOpen
                                ? `<button type="button"
                                    class="incoming-production-get-form btn btn-sm btn-primary"
                                    data-id="${escapeProductionBmrBprText(record.id)}">
                                    Get Form
                                </button>`
                                : `<button type="button"
                                    class="btn btn-sm btn-label-secondary cursor-not-allowed"
                                    disabled
                                    title="${escapeProductionBmrBprText(waitingTitle)}">
                                    ${escapeProductionBmrBprText(waitingLabel)}
                                </button>`}
                        </td>
                    </tr>`;
                }).join(''));
            }

            $('#incomingProductionBmrBprSummary').html(
                `<i class="ti ti-info-circle text-base"></i>Showing ${records.length} pending ${escapeProductionBmrBprText(incomingProductionFormType)} validation requests for today's shift.`
            );
            $('#incomingProductionBmrBprCurrentPage').text(incomingProductionFormPage);
            $('#incomingProductionBmrBprPrevious').prop('disabled', incomingProductionFormPage <= 1);
            $('#incomingProductionBmrBprNext').prop('disabled', incomingProductionFormPage >= totalPages);
        }

        function openIncomingProductionFormModal(widget) {
            incomingProductionFormType = String($(widget).data('form-type') || 'BMR').toUpperCase();
            incomingProductionFormPage = 1;
            renderIncomingProductionFormRequests();
            $('#incomingProductionBmrBprModal').modal('show');
        }

        function productionBmrBprFieldStyle(field) {
            const x = Math.max(0, Math.min(100, Number(field.x || 0)));
            const y = Math.max(0, Math.min(100, Number(field.y || 0)));
            const width = Math.max(0.1, Math.min(100 - x, Number(field.w || 1)));
            const height = Math.max(0.1, Math.min(100 - y, Number(field.h || 1)));
            const fontSize = Math.max(7, Math.min(13, height * 5.2));
            const background = field.erase_background ? '#fff' : '';
            return `left:${x}%;top:${y}%;width:${width}%;height:${height}%;font-size:${fontSize}px;${background ? `background:${background};` : ''}`;
        }

        function fitProductionBmrBprFieldText(element) {
            if (!element) return;

            const maximumFontSize = Number(element.dataset.maximumFontSize)
                || parseFloat(window.getComputedStyle(element).fontSize)
                || 13;
            const minimumFontSize = 4;
            let fontSize = maximumFontSize;

            element.dataset.maximumFontSize = String(maximumFontSize);
            element.style.fontSize = `${fontSize}px`;

            while (
                fontSize > minimumFontSize
                && (element.scrollWidth > element.clientWidth + 1 || element.scrollHeight > element.clientHeight + 1)
            ) {
                fontSize = Math.max(minimumFontSize, fontSize - 0.25);
                element.style.fontSize = `${fontSize}px`;
            }
        }

        function fitProductionBmrBprTemplateText(container) {
            $(container)
                .find('.bmr-bpr-template-field, .bmr-bpr-template-source-value')
                .each(function () {
                    fitProductionBmrBprFieldText(this);
                });
        }

        function renderProductionBmrBprTemplate(form, complete) {
            const layout = form?.layout || {};
            const pages = Array.isArray(layout.pages) ? layout.pages : [];
            const savedFields = form?.form_payload?.fields || {};
            const sourceValues = form?.source_values || {};
            const customFields = Array.isArray(form?.form_payload?.custom_fields)
                ? form.form_payload.custom_fields
                : [];

            if (Number(form?.schema_version || layout?.schema_version || 1) >= 2) {
                const structuredHtml = String(form?.rendered_html || '');
                if (!form?.has_template || !structuredHtml) {
                    $('.production-bmr-bpr-document').html(productionBmrBprFallbackDocumentHtml);
                    return false;
                }
                const instruction = `<div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-800">
                    Fill the highlighted batch fields on every page. Product, approved formula, document-control
                    and packing-profile values are supplied by the mapped common template.
                </div>`;
                $('.production-bmr-bpr-document').html(instruction + structuredHtml);
                return true;
            }

            if (!form?.has_template || pages.length === 0) {
                $('.production-bmr-bpr-document').html(productionBmrBprFallbackDocumentHtml);
                return false;
            }

            const instruction = `<div class="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-semibold text-amber-800">
                Fill the highlighted blank cells. Double-click another blank area to add a positioned entry.
                Right-click a positioned entry to remove it.
                Product, batch, pack and record values are controlled by the linked workflow.
            </div>`;

            const pageHtml = pages.map(function (page) {
                const pageNumber = Number(page.page || 0);
                const pageWidth = Math.max(1, Number(page.width || 596));
                const pageHeight = Math.max(1, Number(page.height || 842));
                const fields = Array.isArray(page.fields) ? page.fields : [];
                const fieldHtml = fields.map(function (field) {
                    const fieldId = String(field.id || '');
                    if (!fieldId) return '';
                    const source = String(field.source || '');
                    if (source) {
                        return `<div class="bmr-bpr-template-source-value"
                            style="${productionBmrBprFieldStyle(field)}"
                            data-source="${escapeProductionBmrBprText(source)}">${escapeProductionBmrBprText(sourceValues[source] || '')}</div>`;
                    }
                    if (!field.editable) return '';
                    return `<textarea
                        class="bmr-bpr-template-field"
                        data-field-id="${escapeProductionBmrBprText(fieldId)}"
                        aria-label="Editable ${escapeProductionBmrBprText(form.form_type)} field"
                        style="${productionBmrBprFieldStyle(field)}"
                        ${complete ? 'disabled' : ''}>${escapeProductionBmrBprText(savedFields[fieldId] || '')}</textarea>`;
                }).join('');

                const customHtml = customFields
                    .filter(function (field) {
                        return Number(field.page || 0) === pageNumber;
                    })
                    .map(function (field, index) {
                        return `<textarea
                            class="bmr-bpr-template-field is-custom"
                            data-custom-id="${escapeProductionBmrBprText(field.id || `custom_${index + 1}`)}"
                            aria-label="Custom positioned entry"
                            style="${productionBmrBprFieldStyle(field)}"
                            ${complete ? 'disabled' : ''}>${escapeProductionBmrBprText(field.value || '')}</textarea>`;
                    }).join('');

                return `<section class="bmr-bpr-template-page"
                    data-page="${pageNumber}"
                    data-complete="${complete ? '1' : '0'}"
                    style="aspect-ratio:${pageWidth}/${pageHeight};">
                    <img class="bmr-bpr-template-page-image"
                        src="${escapeProductionBmrBprText(page.image_url || '')}"
                        alt="${escapeProductionBmrBprText(form.form_type)} page ${pageNumber}">
                    ${fieldHtml}
                    ${customHtml}
                </section>`;
            }).join('');

            $('.production-bmr-bpr-document').html(instruction + pageHtml);
            window.requestAnimationFrame(function () {
                fitProductionBmrBprTemplateText('.production-bmr-bpr-document');
            });
            return true;
        }

        function populateProductionBmrBprFormModal(record, form) {
            const recordType = String(record.form_type || incomingProductionFormType).toUpperCase() === 'BPR' ? 'BPR' : 'BMR';
            const recordTitle = recordType === 'BPR' ? 'Batch Packaging Record' : 'Batch Manufacturing Record';
            const serial = String(record.serial_number || record.id).padStart(2, '0');
            productionBmrBprActiveForm = form || null;

            $('#productionBmrBprSelectedRequestId').val(record.id);
            $('#productionBmrBprFormModalLabel').text(recordTitle);
            const complete = String(record.status_code || '').toUpperCase() === 'COMPLETE';
            const renderedTemplate = renderProductionBmrBprTemplate(form, complete);
            if (!renderedTemplate) {
                toastr.warning('No approved product template is mapped to this record. The compatibility form is shown.');
            }
            $('#productionBmrBprDocumentTitle').text(recordTitle);
            $('#productionBmrBprDocumentType').text(`(${recordType})`);
            $('#productionBmrBprDocNumber').text(`${recordType}-F-${serial}`);
            $('#productionBmrBprProductName').text(record.item_name);
            $('#productionBmrBprProductDescription').text(
                recordType === 'BMR'
                    ? `Product Description: ${record.item_name} manufacturing documentation`
                    : `Product Description: ${record.item_name} packaging and production documentation`
            );
            $('#productionBmrBprBatchNumber').text(record.batch_number || record.lot_number || '-');
            $('#productionBmrBprBatchSize').text(record.batch_size);
            $('#productionBmrBprPoReference').text(`REQUEST-${String(record.request_id || record.id).padStart(6, '0')}`);
            $('#productionBmrBprTemplateId').text(form?.template_code || 'Not mapped');
            $('#productionBmrBprObserved1, #productionBmrBprObserved2, #productionBmrBprObserved3').val('');
            const payload = record.form_payload || {};
            $('#productionBmrBprObserved1').val(payload.observed_1 || '');
            $('#productionBmrBprObserved2').val(payload.observed_2 || '');
            $('#productionBmrBprObserved3').val(payload.observed_3 || '');
            $('#productionBmrBprFormModal .production-bmr-bpr-document')
                .find('input, textarea, select')
                .prop('disabled', complete);
            $('#productionBmrBprFormModal .production-bmr-bpr-document .bmr-v2-document')
                .toggleClass('is-disabled', complete);
            if (complete) {
                $('#productionBmrBprFormModal .production-bmr-bpr-document')
                    .find('.bmr-v2-sig-upload-btn, .bmr-v2-sig-clear-btn')
                    .hide();
            }
            $('#productionBmrBprObserved1, #productionBmrBprObserved2, #productionBmrBprObserved3')
                .prop('readonly', complete)
                .toggleClass('cursor-not-allowed opacity-70', complete);
            $('#productionBmrBprFormModal .production-bmr-bpr-form-action[data-action="download"]')
                .prop('disabled', !form?.has_template)
                .toggleClass('opacity-50 cursor-not-allowed', !form?.has_template);
            $('.production-bmr-bpr-form-action[data-action="draft"], .production-bmr-bpr-form-action[data-action="submit"]')
                .prop('disabled', complete)
                .toggleClass('opacity-50 cursor-not-allowed', complete);
            $('#productionBmrBprFormModal').modal('show');
        }

        function openProductionBmrBprFormModal(button) {
            if (productionBmrBprOpenRequestPending) return;
            const workItemId = String($(button).data('id') || '');
            const availableRecords = productionBmrBprRecords
                .concat(incomingProductionFormRequests.BMR || [])
                .concat(incomingProductionFormRequests.BPR || []);
            const record = availableRecords.find(function (item) {
                return String(item.id) === workItemId;
            });
            if (!record) return;

            const formData = new FormData();
            formData.append('openProductionBmrBpr', 'openProductionBmrBpr');
            formData.append('csrf_token', productionBmrBprCsrf);
            formData.append('work_item_id', workItemId);
            const $button = $(button);
            const originalHtml = $button.html();
            productionBmrBprOpenRequestPending = true;
            $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i>');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        record.status_code = response.data?.status_code || record.status_code;
                        record.status = response.data?.status || record.status;
                        if (!productionBmrBprRecords.some(function (item) {
                            return String(item.id) === workItemId;
                        })) {
                            productionBmrBprRecords.unshift(record);
                        }
                        incomingProductionFormType = record.form_type;
                        record.form_payload = response.data?.form?.form_payload || record.form_payload || {};
                        const showSelectedForm = function () {
                            populateProductionBmrBprFormModal(record, response.data?.form || null);
                            productionBmrBprOpenRequestPending = false;
                            loadProductionBmrBprRecords();
                        };
                        const $incomingModal = $('#incomingProductionBmrBprModal');
                        if ($incomingModal.hasClass('show')) {
                            $incomingModal.one('hidden.bs.modal', showSelectedForm);
                            $incomingModal.modal('hide');
                        } else {
                            showSelectedForm();
                        }
                    } else {
                        productionBmrBprOpenRequestPending = false;
                        toastr.error(response.message || 'Unable to open this form.');
                    }
                },
                error: function (xhr) {
                    productionBmrBprOpenRequestPending = false;
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
                },
                complete: function () {
                    $button.prop('disabled', false).html(originalHtml);
                }
            });
        }

        function selectProductionBmrBprFilter(button) {
            const selectedButton = $(button);
            productionBmrBprType = String(selectedButton.data('type') || 'all');
            const labels = {
                'all': 'All Records',
                'BMR': 'BMR Only',
                'BPR': 'BPR Only'
            };
            $('#productionBmrBprFilterText').text(labels[productionBmrBprType] || 'All Records');
            productionBmrBprPage = 1;
            renderProductionBmrBprRecords();
        }



        function refreshProductionBmrBprRecords() {
            if (!document.hidden) {
                loadProductionBmrBprRecords(false, true);
            }
        }

        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) refreshProductionBmrBprRecords();
        });

        $(document).ready(function () {
            loadProductionBmrBprRecords();
        });

        $(document).on('input search', '#productionBmrBprSearch', function () {
            productionBmrBprPage = 1;
            renderProductionBmrBprRecords();
        });

        $(document).on('click', '.production-bmr-bpr-filter', function () {
            selectProductionBmrBprFilter(this);
        });

        $(document).on('click', '.production-bmr-bpr-status-filter', function () {
            productionBmrBprStatus = String($(this).data('status') || 'all');
            const labels = { all: 'All Statuses', QUEUED: 'Incoming', PENDING: 'Pending', IN_PROCESS: 'Draft / In-Process', COMPLETE: 'Completed' };
            $('#productionBmrBprStatusText').text(labels[productionBmrBprStatus] || 'All Statuses');
            productionBmrBprPage = 1;
            renderProductionBmrBprRecords();
        });

        $(document).on('click', '.production-bmr-bpr-per-page', function () {
            productionBmrBprPerPage = Math.max(1, Number($(this).data('value') || 10));
            $('#productionBmrBprPerPageText').text($(this).text().trim());
            productionBmrBprPage = 1;
            renderProductionBmrBprRecords();
        });

        $(document).on('click', '.production-bmr-bpr-sortable', function () {
            const column = String($(this).data('column') || '');
            if (!column) return;
            if (productionBmrBprSortColumn === column) {
                productionBmrBprSortDirection = productionBmrBprSortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                productionBmrBprSortColumn = column;
                productionBmrBprSortDirection = 'asc';
            }
            renderProductionBmrBprRecords();
        });

        $(document).on('click', '#productionBmrBprPrevious', function () {
            if (productionBmrBprPage > 1) {
                productionBmrBprPage--;
                renderProductionBmrBprRecords();
            }
        });

        $(document).on('click', '#productionBmrBprNext', function () {
            productionBmrBprPage++;
            renderProductionBmrBprRecords();
        });

        $(document).on('click', '.production-bmr-bpr-page', function () {
            productionBmrBprPage = Number($(this).data('page') || 1);
            renderProductionBmrBprRecords();
        });

        $(document).on('click', '.production-bmr-bpr-lot-view, .production-bmr-bpr-lot-row', function (event) {
            if ($(this).hasClass('production-bmr-bpr-lot-view')) event.stopPropagation();
            if ($(event.target).closest('button, a, input, select, textarea').length && !$(event.target).closest('.production-bmr-bpr-lot-view').length) return;
            openProductionBmrBprLot($(this).data('group-key') || $(this).closest('[data-group-key]').data('group-key'));
        });

        $(document).on('keydown', '.production-bmr-bpr-lot-row', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openProductionBmrBprLot($(this).data('group-key'));
            }
        });

        $(document).on('click', '.production-bmr-bpr-lot-form', function () {
            const button = this;
            const $modal = $('#productionBmrBprLotModal');
            $modal.one('hidden.bs.modal', function () { openProductionBmrBprFormModal(button); });
            $modal.modal('hide');
        });

        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            const labelMap = {
                csv: 'CSV (Comma Separated Values)',
                excel: 'Excel Spreadsheet (.xlsx)',
                pdf: 'PDF Document'
            };
            $('#exportTypeSelect').val(val);
            $('#exportTypeText').text(labelMap[val] || val.toUpperCase());
        });

        $(document).on('click', '#deselectAllColumnsBtn', function () {
            const allChecked = $('.column-filter:checked').length === $('.column-filter').length;
            if (allChecked) {
                $('.column-filter').prop('checked', false);
                $(this).text('Select All');
            } else {
                $('.column-filter').prop('checked', true);
                $(this).text('Deselect All');
            }
        });

        $('#exportModal').on('hidden.bs.modal', function () {
            $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
        });

        $('#productionBmrBprExportForm').on('submit', function (e) {
            e.preventDefault();
            const search = $('#productionBmrBprSearch').val().trim();
            const form = document.getElementById('productionBmrBprExportForm');
            const formData = new FormData(form);
            formData.append('exportProductionBmrBpr', 'exportProductionBmrBpr');
            formData.append('search', search);
            formData.append('selectedFormType', productionBmrBprType);

            $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
            $.ajax({
                url: 'exportajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.success === 'success') {
                        $('#downloadExortfile')
                            .attr('href', response.fileurl)
                            .attr('download', response.file)
                            .html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase())
                            .removeClass('hidden d-none')
                            .attr('style', 'display: inline-flex !important;');
                        toastr.success(response.message || 'File exported successfully.');
                    } else {
                        toastr.error(response.message || 'Export failed.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $(document).on('click keydown', '.incoming-production-form-widget', function (event) {
            if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
            if (event.type === 'keydown') event.preventDefault();
            openIncomingProductionFormModal(this);
        });

        $(document).on('click', '#incomingProductionBmrBprPrevious', function () {
            if (incomingProductionFormPage > 1) {
                incomingProductionFormPage--;
                renderIncomingProductionFormRequests();
            }
        });

        $(document).on('click', '#incomingProductionBmrBprNext', function () {
            incomingProductionFormPage++;
            renderIncomingProductionFormRequests();
        });

        $(document).on('click', '.incoming-production-get-form', function () {
            openProductionBmrBprFormModal(this);
        });

        $(document).on('shown.bs.modal', '#productionBmrBprFormModal', function () {
            $('.modal-backdrop').last().addClass('production-bmr-bpr-form-backdrop');
        });

        $(document).on('hidden.bs.modal', '#productionBmrBprFormModal', function () {
            $('.modal-backdrop.production-bmr-bpr-form-backdrop').removeClass('production-bmr-bpr-form-backdrop');
            if ($('#incomingProductionBmrBprModal').hasClass('show')) {
                $('body').addClass('modal-open');
            }
        });

        $(document).on('click', '.production-bmr-bpr-form-action', function () {
            const action = String($(this).data('action') || '');
            if (action === 'download') {
                if (!productionBmrBprActiveForm?.has_template || !productionBmrBprActiveForm?.download_url) {
                    toastr.error('No approved product template is mapped to this record.');
                    return;
                }
                window.open(productionBmrBprActiveForm.download_url, '_blank', 'noopener,noreferrer');
                toastr.success('The BMR/BPR PDF is being generated.');
                return;
            }
            if (!['draft', 'submit'].includes(action)) return;

            let formPayload;
            if (productionBmrBprActiveForm?.has_template) {
                if (Number(productionBmrBprActiveForm?.schema_version || 1) >= 2) {
                    const fields = {};
                    $('#productionBmrBprFormModal [data-bmr-field]').each(function () {
                        const fieldKey = String($(this).data('bmr-field') || '');
                        const value = String($(this).val() || '').trim();
                        if (fieldKey && value) fields[fieldKey] = value;
                    });
                    formPayload = {
                        schema_version: 2,
                        fields: fields
                    };
                } else {
                const fields = {};
                $('.bmr-bpr-template-field[data-field-id]').each(function () {
                    const value = String($(this).val() || '').trim();
                    if (value) fields[String($(this).data('field-id'))] = value;
                });
                const customFields = [];
                $('.bmr-bpr-template-field.is-custom').each(function (index) {
                    const value = String($(this).val() || '').trim();
                    if (!value) return;
                    const element = this;
                    const page = element.closest('.bmr-bpr-template-page');
                    if (!page) return;
                    const pageRect = page.getBoundingClientRect();
                    const fieldRect = element.getBoundingClientRect();
                    customFields.push({
                        id: String($(element).data('custom-id') || `custom_${index + 1}`),
                        page: Number(page.dataset.page || 0),
                        x: ((fieldRect.left - pageRect.left) / pageRect.width) * 100,
                        y: ((fieldRect.top - pageRect.top) / pageRect.height) * 100,
                        w: (fieldRect.width / pageRect.width) * 100,
                        h: (fieldRect.height / pageRect.height) * 100,
                        value: value
                    });
                });
                formPayload = {
                    schema_version: 1,
                    fields: fields,
                    custom_fields: customFields
                };
                }
            } else {
                formPayload = {
                    observed_1: $('#productionBmrBprObserved1').val(),
                    observed_2: $('#productionBmrBprObserved2').val(),
                    observed_3: $('#productionBmrBprObserved3').val()
                };
            }
            const formData = new FormData();
            formData.append('updateProductionBmrBpr', 'updateProductionBmrBpr');
            formData.append('csrf_token', productionBmrBprCsrf);
            formData.append('work_item_id', $('#productionBmrBprSelectedRequestId').val());
            formData.append('record_action', action);
            formData.append('form_payload', JSON.stringify(formPayload));

            const $button = $(this);
            const originalHtml = $button.html();
            $button.prop('disabled', true)
                .html('<i class="ti ti-loader-2 animate-spin text-base"></i> Saving...');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#productionBmrBprFormModal').modal('hide');
                        toastr.success(response.message);
                        loadProductionBmrBprRecords();
                    } else {
                        toastr.error(response.message || 'Unable to update the BMR/BPR record.');
                    }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
                },
                complete: function () {
                    $button.prop('disabled', false).html(originalHtml);
                }
            });
        });

        $(document).on('click', '.production-bmr-bpr-view', function () {
            openProductionBmrBprFormModal(this);
        });

        $(document).on('input', '.bmr-bpr-template-field', function () {
            fitProductionBmrBprFieldText(this);
        });

        $(document).on('shown.bs.modal', '#productionBmrBprFormModal', function () {
            fitProductionBmrBprTemplateText(this);
        });

        $(document).on('dblclick', '.bmr-bpr-template-page', function (event) {
            if (String(this.dataset.complete || '') === '1' || $(event.target).is('textarea')) {
                return;
            }
            const rect = this.getBoundingClientRect();
            const x = Math.max(0, Math.min(80, ((event.clientX - rect.left) / rect.width) * 100));
            const y = Math.max(0, Math.min(96, ((event.clientY - rect.top) / rect.height) * 100));
            const customId = `custom_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
            const input = $(`<textarea class="bmr-bpr-template-field is-custom"
                data-custom-id="${customId}" aria-label="Custom positioned entry"></textarea>`);
            input.css({
                left: `${x}%`,
                top: `${y}%`,
                width: '20%',
                height: '3%',
                fontSize: '10px'
            });
            $(this).append(input);
            input.trigger('focus');
        });

        $(document).on('input change', '.bmr-v2-sig-text', function () {
            const $widget = $(this).closest('.bmr-v2-sig-widget');
            $widget.find('.bmr-v2-sig-value').val($(this).val());
        });

        $(document).on('change', '.bmr-v2-sig-file-input', function () {
            const file = this.files && this.files[0];
            if (!file) return;

            const maxSizeBytes = 250 * 1024;
            if (file.size > maxSizeBytes) {
                toastr.error('Signed image size must not exceed 250 KB.');
                $(this).val('');
                return;
            }

            if (!file.type.match(/^image\//i)) {
                toastr.error('Please upload a valid image file (PNG, JPG, JPEG, WEBP).');
                $(this).val('');
                return;
            }

            const $widget = $(this).closest('.bmr-v2-sig-widget');
            const reader = new FileReader();
            reader.onload = function (e) {
                const dataUri = e.target.result;
                $widget.find('.bmr-v2-sig-value').val(dataUri);
                let $img = $widget.find('.bmr-v2-sig-preview-img');
                if (!$img.length) {
                    $img = $('<img class="bmr-v2-sig-preview-img" alt="Signature">');
                    $widget.find('.bmr-v2-sig-preview').prepend($img);
                }
                $img.attr('src', dataUri);
                $widget.find('.bmr-v2-sig-preview').show();
                $widget.find('.bmr-v2-sig-input-group').hide();
                $widget.find('.bmr-v2-sig-text').val('');
            };
            reader.readAsDataURL(file);
            $(this).val('');
        });

        $(document).on('click', '.bmr-v2-sig-clear-btn', function () {
            const $widget = $(this).closest('.bmr-v2-sig-widget');
            $widget.find('.bmr-v2-sig-value').val('');
            $widget.find('.bmr-v2-sig-preview-img').attr('src', '');
            $widget.find('.bmr-v2-sig-preview').hide();
            $widget.find('.bmr-v2-sig-input-group').show();
            $widget.find('.bmr-v2-sig-text').val('').trigger('focus');
        });

        $(document).on('contextmenu', '.bmr-bpr-template-field.is-custom', function (event) {
            if (this.disabled) return;
            event.preventDefault();
            $(this).remove();
        });
    })();
</script>
<?php endSection(); ?>
