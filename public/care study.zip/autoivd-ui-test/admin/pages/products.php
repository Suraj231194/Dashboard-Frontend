<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage product catalogue and inventory items</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="productsPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="products-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="products-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="products-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="products-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="products-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="products-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <a href="index.php?page=pricelist-catalog"
                        class="inline-flex h-10 items-center gap-1.5 !rounded-xl border border-emerald-300 bg-emerald-50 px-3.5 text-sm font-bold text-emerald-800 shadow-sm hover:bg-emerald-100 transition-colors cursor-pointer"
                        title="Price List Master">
                        <i class="ti ti-tags text-base"></i><span class="hidden sm:inline">Price List Master</span>
                    </a>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_product_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#addProductModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="product_code" data-order="ASC">
                                <span class="inline-flex items-center gap-1">CAT No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-80 min-w-[300px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="product_name" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-72 min-w-[250px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="description" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Description <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-44 px-6 py-3">Pack Size(s)</th>
                            <th class="sortable w-44 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="category_name" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Product Category <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-28 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="gst_rate" data-order="ASC">
                                <span class="inline-flex items-center gap-1">GST % <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-24 px-6 py-3">Image</th>
                            <th class="w-36 px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="productsTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addProductModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Product</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a new product record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addProductForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="space-y-4">
                            <div>
                                <label for="productName" class="mb-1 block text-sm font-medium text-slate-800">Product Name</label>
                                <input type="text" id="productName" autocomplete="off" name="productName" class="input-theme" placeholder="Enter Product Name" required />
                            </div>
                            <div>
                                <label for="productCode" class="mb-1 block text-sm font-medium text-slate-800">CAT No</label>
                                <input type="text" id="productCode" autocomplete="off" name="productCode" class="input-theme cursor-not-allowed bg-slate-100 text-slate-600" placeholder="Auto-generated on save" readonly aria-readonly="true" />
                            </div>
                            <div>
                                <label for="hsnCode" class="mb-1 block text-sm font-medium text-slate-800">HSN Code</label>
                                <input type="text" id="hsnCode" autocomplete="off" name="hsnCode" maxlength="20" class="input-theme" placeholder="Enter HSN Code" />
                            </div>
                            <div>
                                <label for="productDescription" class="mb-1 block text-sm font-medium text-slate-800">Description</label>
                                <textarea id="productDescription" autocomplete="off" name="productDescription" class="input-theme min-h-[80px]" placeholder="Enter Description"></textarea>
                            </div>
                            <div>
                                <div class="mb-2 flex items-center justify-between gap-3">
                                    <label class="mb-0 block text-sm font-medium text-slate-800">Pack Size(s)</label>
                                    <button type="button" class="inline-flex h-9 items-center justify-center gap-2 !rounded-xl bg-emerald-50 px-4 text-sm font-bold text-emerald-700 shadow-sm ring-1 ring-emerald-900/10 hover:bg-emerald-100" id="addPackSizeBtn"><i class="ti ti-plus"></i> Add</button>
                                </div>
                                <div id="packSizeWrapper"></div>
                            </div>
                            <div>
                                <label for="productCategory" class="mb-1 block text-sm font-medium text-slate-800">Product Category</label>
                                <select name="productCategory" id="productCategory" class="input-theme select2" required></select>
                            </div>
                            <div>
                                <label for="productImage" class="mb-1 block text-sm font-medium text-slate-800">Image Upload</label>
                                <input type="file" id="productImage" name="productImage" class="input-theme" accept="image/png,image/jpeg,image/webp" />
                            </div>
                            <div>
                                <label for="gstRate" class="mb-1 block text-sm font-medium text-slate-800">GST %</label>
                                <input type="number" step="any" min="0" id="gstRate" autocomplete="off" name="gstRate" class="input-theme" placeholder="Enter GST %" />
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editProductModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Product</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update product details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editProductForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3"></div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';

    function buildPackUnitOptions(selected = '') {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            const isSelected = String(selected) === String(unit.id) ? 'selected' : '';
            optionsHtml += `<option value="${unit.id}" ${isSelected}>${unit.label}</option>`;
        });
        return optionsHtml;
    }

    function addPackSizeRow(wrapper, dropdownParent, packSize = '', packUnit = '') {
        const rowHtml = `<div class="row product-pack-size-row mb-2">
            <div class="col-md-7 mb-2">
                <input type="text" name="packSize[]" value="${packSize}" class="input-theme" placeholder="Pack Size" />
            </div>
            <div class="col-md-4 mb-2">
                <select name="packSizeUnit[]" class="input-theme select2">${buildPackUnitOptions(packUnit)}</select>
            </div>
            <div class="col-md-1 mb-2 d-flex align-items-center">
                <button type="button" class="btn btn-icon btn-label-danger removePackSizeBtn"><span class="ti ti-trash"></span></button>
            </div>
        </div>`;
        const $row = $(rowHtml);
        $(wrapper).append($row);
        $row.find('.select2').select2({ dropdownParent: $(dropdownParent) });
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php', method: 'POST', dataType: 'json',
            data: { getQtyUnits: 'getQtyUnits' },
            success: function (response) {
                qtyUnitOptions = response;
                if ($('#packSizeWrapper .product-pack-size-row').length === 0) {
                    addPackSizeRow('#packSizeWrapper', '#addProductModal');
                }
            },
            error: function (xhr, status, error) { console.error("Failed to load qty units:", error); }
        });
    }

    function loadProductCategoryList() {
        $.ajax({
            url: 'ajax.php', method: 'POST', dataType: 'json',
            data: { getProductCategoryList: 'getProductCategoryList' },
            success: function (response) {
                let optionsHtml = '<option value="">---Select----</option>';
                response.forEach(unit => { optionsHtml += `<option value="${unit.id}">${unit.name}</option>`; });
                $("#productCategory").html(optionsHtml);
                $("#productCategory").select2({ dropdownParent: $('#addProductModal') });
                $("#productCategory").trigger("change");
            },
            error: function (xhr, status, error) { console.error("Failed to load categories:", error); }
        });
    }
    function loadProductsTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#productsTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php', method: 'POST', dataType: 'json',
            data: {
                loadProducts: 'loadProducts', page: page, per_page: perPage,
                search: search, sort_column: currentSortColumn, sort_order: currentSortOrder
            },
            success: function (response) {
                $('#productsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const visibleRows = $('#productsTableBody tr').length;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * parseInt(perPage)) + visibleRows, totalRows) : 0;
                $('#productPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
            },
            error: function () {
                $('#productsTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#productPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    $(document).ready(function () {
        loadProductsTable();
        loadStandardUnit();
        loadProductCategoryList();

        $('#searchProducts').on('input', function () { loadProductsTable(1); });
        $('#perPageSelect').on('change', function () { loadProductsTable(1); });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadProductsTable(1);
        });

        $(document).on('click', '.products-per-page-item', function () {
            const val = $(this).data('val');
            $('#productsPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#addProductModal').on('hidden.bs.modal', function () {
            $('#addProductForm')[0].reset();
            $('#packSizeWrapper').empty();

            addPackSizeRow('#packSizeWrapper', '#addProductModal');
        });


        $(document).on('click', '#addPackSizeBtn', function () {
            addPackSizeRow('#packSizeWrapper', '#addProductModal');
        });

        $(document).on('click', '.removePackSizeBtn', function () {
            $(this).closest('.product-pack-size-row').remove();
        });

        $(document).on('click', '#addPackSizeEditBtn', function () {
            const rowHtml = `<div class="row product-pack-size-row mb-2">
                <div class="col-md-7 mb-2">
                    <input type="text" name="packSizeEdit[]" class="input-theme" placeholder="Pack Size" />
                </div>
                <div class="col-md-4 mb-2">
                    <select name="packSizeUnitEdit[]" class="input-theme select2">${buildPackUnitOptions()}</select>
                </div>
                <div class="col-md-1 mb-2 d-flex align-items-center">
                    <button type="button" class="btn btn-icon btn-label-danger removePackSizeBtn"><span class="ti ti-trash"></span></button>
                </div>
            </div>`;
            const $row = $(rowHtml);
            $('#packSizeEditWrapper').append($row);
            $row.find('.select2').select2({ dropdownParent: $('#editProductModel') });
        });
        $('#addProductForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addProductForm');
            const formData = new FormData(form);
            formData.append('addProduct', 'addProduct');
            $.ajax({
                url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
                success: function (response) {
                    let res;
                    try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response from server.'); return; }
                    if (res.status === 'success') {
                        $('#addProductModal').modal('hide');
                        $('#addProductForm')[0].reset();
                        loadProductsTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') { toastr.error(res.message); }
                    else { toastr.error('Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        });
    });

    $(document).on('click', '.productEditModal', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editProductForm').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { fetchProductRecord: 'fetchProductRecord', id: id },
                success: function (response) {
                    let res;
                    try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response from server.'); return; }
                    if (res.status === 'success') {
                        $('#editProductModel').modal('show');
                        $('#editProductForm').find('.modal-body').html(res.data);
                        $('#editProductForm .select2').select2({ dropdownParent: $('#editProductModel') });

                    } else if (res.status === 'error') { toastr.error(res.message); }
                    else { toastr.error('Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });

    $(document).on('click', '.productDeleteBtn', function () {
        let id = $(this).data('id');
        if (!id) { Swal.fire({ icon: 'error', title: 'Invalid ID', text: 'Invalid product ID provided.', customClass: { confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); return; }
        Swal.fire({
            title: 'Are you sure?', text: "You won't be able to revert this!", icon: 'warning',
            showCancelButton: true, confirmButtonText: 'Yes, delete it!', cancelButtonText: 'Cancel',
            customClass: { confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white', cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700' },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php', type: 'POST',
                    data: { deleteProductRecord: 'deleteProductRecord', id: id }, dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadProductsTable();
                            Swal.fire({ icon: 'success', title: 'Deleted!', text: res.message, customClass: { confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white' } });
                        } else {
                            Swal.fire({ icon: 'error', title: 'Failed!', text: res.message, customClass: { confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
                        }
                    },
                    error: function (xhr, status, error) { Swal.fire({ icon: 'error', title: 'Server Error', text: error, customClass: { confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); }
                });
            }
        });
    });

    $('#editProductForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editProductForm');
        const formData = new FormData(form);
        formData.append('updateProduct', 'updateProduct');
        $.ajax({
            url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (response) {
                let res;
                try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response from server.'); return; }
                if (res.status === 'success') {
                    $('#editProductModel').modal('hide');
                    loadProductsTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') { toastr.error(res.message); }
                else { toastr.error('Unexpected response.'); }
            },
            error: function () { toastr.error('Server error occurred.'); }
        });
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
        loadProductsTable(1);
    });
</script>
<?php endSection(); ?>
