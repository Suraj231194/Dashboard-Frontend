<?php
/** Website quotations replicated into ERP through the existing one-way pull. */
?>
<style>
    .quote-feed-page { color: var(--ui-text, #2b3d33); }
    .quote-feed-page .quote-kpi { min-height: 82px; border: 1px solid var(--color-primary-100, #e1e9e4); border-radius: 12px; padding: 14px; background: #fff; box-shadow: 0 5px 18px rgba(0,0,0,.06); }
    .quote-feed-page .quote-panel { overflow: hidden; border: 1px solid #e1e9e4; border-radius: 14px; background: #fff; box-shadow: 0 6px 22px rgba(0,0,0,.06); }
    .quote-feed-page .quote-control { height: 38px; border: 1px solid #dde7e1; border-radius: 8px; background: #fff; color: #526259; font-size: 11px; font-weight: 700; outline: none; }
    .quote-feed-page .quote-control:focus { border-color: var(--appearance-accent, #166534); box-shadow: 0 0 0 3px color-mix(in srgb, var(--appearance-accent, #166534) 12%, transparent); }
    .quote-feed-page .quote-table { width: 100%; min-width: 1040px; border-collapse: collapse; }
    .quote-feed-page .quote-table th { padding: 11px 12px; border-bottom: 1px solid #e7eee9; background: #fbfdfc; color: #88958e; font-size: 8px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; }
    .quote-feed-page .quote-table td { padding: 11px 12px; border-bottom: 1px solid #edf2ef; color: #536159; font-size: 9px; vertical-align: middle; }
    .quote-feed-page .quote-table tbody tr { cursor: pointer; }
    .quote-feed-page .quote-table tbody tr:hover { background: #fbfdfc; }
    .quote-feed-page .quote-index { display: inline-flex; width: 20px; height: 20px; align-items: center; justify-content: center; border-radius: 5px; background: #f1f5f2; color: #738078; font-size: 8px; font-weight: 900; }
    .quote-feed-page .quote-page-btn { display: inline-flex; width: 29px; height: 29px; align-items: center; justify-content: center; border: 1px solid #dce5df; border-radius: 7px; background: #fff; color: #68776f; font-size: 9px; font-weight: 900; }
    .quote-feed-page .quote-page-btn.is-active { border-color: var(--appearance-accent, #166534); background: var(--appearance-accent, #166534); color: #fff; }
    .quote-detail-modal .modal-dialog { max-width: 900px; }
    .quote-detail-modal .modal-content { overflow: hidden; border: 0; border-radius: 15px; box-shadow: 0 24px 70px rgba(0,0,0,.2); }
    .quote-detail-modal .quote-summary { border: 1px solid #e5ece7; border-radius: 10px; padding: 12px; background: #fff; }
    .quote-detail-modal .quote-items { width: 100%; min-width: 650px; border-collapse: collapse; }
    .quote-detail-modal .quote-items th, .quote-detail-modal .quote-items td { padding: 10px; border-bottom: 1px solid #edf2ef; font-size: 10px; }
    .quote-detail-modal .quote-items th { color: #839087; font-size: 8px; font-weight: 900; text-transform: uppercase; }
</style>

<div class="quote-feed-page container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1 class="m-0 text-2xl font-extrabold tracking-tight text-slate-800">Quotations Management</h1>
            <p class="mb-0 mt-1 text-sm text-slate-500">Website quotation snapshots synchronized into ERP workspace.</p>
        </div>
        <div class="flex items-center gap-2">
            <button id="quoteExportButton" type="button" data-bs-toggle="modal" data-bs-target="#exportModal" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36">
                <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
            </button>
            <button id="quoteImportButton" type="button" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl border px-4 text-sm font-bold shadow-sm transition-colors focus:outline-none focus:ring-2" style="border-color: var(--color-primary-200, #bbf7d0); background: var(--color-primary-50, #f0fdf4); color: var(--appearance-accent, #166534);">
                <i class="ti ti-download text-lg"></i>Import
            </button>
        </div>
    </div>

    <div class="mb-5 grid grid-cols-1 gap-3 md:grid-cols-2">
        <div class="quote-kpi">
            <div class="flex items-start justify-between">
                <div>
                    <div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Total quotations</div>
                    <div id="quoteTotalCount" class="mt-2 text-2xl font-black text-slate-800">0</div>
                    <div class="mt-1 text-[8px] font-bold" style="color: var(--appearance-accent, #166534);"><i class="ti ti-trending-up mr-1"></i>All-time total</div>
                </div>
                <span class="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-blue-100 bg-blue-50 text-blue-600"><i class="ti ti-file-text"></i></span>
            </div>
        </div>
        <div class="quote-kpi">
            <div class="flex items-start justify-between">
                <div>
                    <div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Generated today</div>
                    <div id="quoteTodayCount" class="mt-2 text-2xl font-black text-slate-800">0</div>
                    <div class="mt-1 text-[8px] font-bold text-blue-600" id="quoteTodayLabel">Today</div>
                </div>
                <span class="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-blue-100 bg-blue-50 text-blue-600"><i class="ti ti-calendar-event"></i></span>
            </div>
        </div>
    </div>

    <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                <input type="hidden" id="quotePageSize" value="10">

                <!-- Per-page dropdown -->
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="quotePerPageText" class="whitespace-nowrap">10 per page</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="quote-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                        <li><a class="quote-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 per page</a></li>
                        <li><a class="quote-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 per page</a></li>
                        <li><a class="quote-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 per page</a></li>
                        <li><a class="quote-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 per page</a></li>
                    </ul>
                </div>

                <!-- Search input -->
                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="ti ti-search text-lg text-slate-400"></i>
                    </div>
                    <input type="text" id="quoteSearchInput" class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" placeholder="Search quotation or customer...">
                </div>

                <!-- Product filter -->
                <select id="quoteProductFilter" class="h-10 w-auto !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><option value="">All Products</option></select>

                <!-- Date range -->
                <input type="date" id="quoteDateFrom" class="h-10 w-auto !rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" aria-label="Quotation start date">
                <span class="text-xs font-bold text-slate-400">to</span>
                <input type="date" id="quoteDateTo" class="h-10 w-auto !rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" aria-label="Quotation end date">

                <button type="button" id="quoteClearFilters" class="inline-flex h-10 items-center justify-center gap-1 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60">
                    <i class="ti ti-filter-off text-base"></i>Clear
                </button>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="quote-table">
                <thead><tr><th>#</th><th>Quote No.</th><th>Date</th><th>Customer</th><th>Email</th><th>Mobile</th><th>Product</th><th>Quote Amount</th></tr></thead>
                <tbody id="quoteTableBody"><tr><td colspan="8" class="!py-10 text-center !text-slate-400">Loading quotations...</td></tr></tbody>
            </table>
        </div>
        <div class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/50 px-4 py-3 text-xs font-bold text-slate-500"><span id="quoteShowingText">Showing 0 quotations</span><div id="quotePagination" class="flex items-center gap-1"></div></div>
    </div>
</div>

<div class="modal fade quote-detail-modal" id="quoteModal" tabindex="-1" aria-labelledby="quoteModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header border-bottom"><div><h5 id="quoteModalTitle" class="modal-title text-base font-extrabold text-slate-800">Quotation Details</h5><p class="mb-0 mt-1 text-[9px] font-bold text-slate-400">Website quotation snapshot · Read-only in ERP</p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div id="quoteModalBody" class="modal-body bg-slate-50 p-4">Loading...</div>
            <div class="modal-footer border-top bg-white">
                <a id="quotePdfButton" href="#" target="_blank" rel="noopener" class="hidden inline-flex h-9 items-center gap-2 rounded-lg border px-4 text-[10px] font-black no-underline" style="border-color: var(--appearance-accent, #166534); color: var(--appearance-accent, #166534);"><i class="ti ti-file-type-pdf"></i>Download PDF</a>
                <button type="button" class="inline-flex h-9 items-center rounded-lg px-4 text-[10px] font-black text-white" style="background: var(--appearance-accent, #166534);" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Export Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="quotationRequestsExportForm" method="POST" action="exportajax.php">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                        <div class="dropdown w-full">
                            <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                            <button type="button" id="quoteDeselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2">
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Quotation Number" checked /><span class="text-sm font-medium text-slate-700">Quotation Number</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Website Quote ID" checked /><span class="text-sm font-medium text-slate-700">Website Quote ID</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Date" checked /><span class="text-sm font-medium text-slate-700">Date</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Customer Name" checked /><span class="text-sm font-medium text-slate-700">Customer Name</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Email" checked /><span class="text-sm font-medium text-slate-700">Email</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Mobile" checked /><span class="text-sm font-medium text-slate-700">Mobile</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Products" checked /><span class="text-sm font-medium text-slate-700">Products</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Quote Amount" checked /><span class="text-sm font-medium text-slate-700">Quote Amount</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Currency" checked /><span class="text-sm font-medium text-slate-700">Currency</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Status" checked /><span class="text-sm font-medium text-slate-700">Status</span></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none !rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="inline-flex h-10 w-28 items-center justify-center gap-2 !rounded-xl text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534);"><i class="ti ti-download text-base"></i> Export</button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="hidden d-none inline-flex h-10 w-auto items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534); display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
let quotationRows = [];
let quotationFilteredRows = [];
let quotationCurrentPage = 1;

document.addEventListener('DOMContentLoaded', function() {
    ['quoteProductFilter','quoteDateFrom','quoteDateTo'].forEach(id=>document.getElementById(id).addEventListener('change',resetQuotationView));
    document.getElementById('quoteSearchInput').addEventListener('input',resetQuotationView);

    // Per-page dropdown items
    document.querySelectorAll('.quote-per-page-item').forEach(function(item) {
        item.addEventListener('click', function() {
            var val = this.dataset.val;
            document.getElementById('quotePageSize').value = val;
            document.getElementById('quotePerPageText').textContent = Number(val) >= 100000000 ? 'All items' : val + ' per page';
            resetQuotationView();
        });
    });
    document.getElementById('quoteClearFilters').addEventListener('click',function(){$('#quoteProductFilter,#quoteDateFrom,#quoteDateTo,#quoteSearchInput').val('');resetQuotationView();});
    document.getElementById('quotePagination').addEventListener('click',function(event){const button=event.target.closest('[data-quote-page]');if(!button||button.disabled)return;quotationCurrentPage=Number(button.dataset.quotePage);renderQuotationView();});
    document.getElementById('quoteImportButton').addEventListener('click',function(){importQuotationRows(this);});
    loadQuotationGrid();
});

function loadQuotationGrid(){ $('#quoteTableBody').html('<tr><td colspan="8" class="!py-10 text-center !text-slate-400">Loading quotations...</td></tr>'); $.getJSON('ajax.php?action=loadQuotationGrid').done(function(response){quotationRows=response.status==='success'&&Array.isArray(response.data)?response.data:[];updateQuotationStats();populateQuotationProducts();quotationCurrentPage=1;renderQuotationView();}).fail(function(xhr){$('#quoteTableBody').html('<tr><td colspan="8" class="!py-10 text-center !text-rose-600">'+escapeQuoteHtml(quoteResponseMessage(xhr,'Failed to load quotations.'))+'</td></tr>');}); }
function resetQuotationView(){quotationCurrentPage=1;renderQuotationView();}
function quoteProducts(row){return String(row.product_names||'').split('||').map(value=>value.trim()).filter(Boolean);}
function quoteRecordDate(row){return String(row.source_created_at||row.created_at||'').slice(0,10);}
function updateQuotationStats(){const today=localDateKey(new Date());$('#quoteTotalCount').text(quotationRows.length.toLocaleString('en-IN'));$('#quoteTodayCount').text(quotationRows.filter(row=>quoteRecordDate(row)===today).length.toLocaleString('en-IN'));$('#quoteTodayLabel').text(new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}));}
function populateQuotationProducts(){const current=$('#quoteProductFilter').val();const products=[...new Set(quotationRows.flatMap(quoteProducts))].sort((a,b)=>a.localeCompare(b));$('#quoteProductFilter').html('<option value="">All Products</option>'+products.map(product=>'<option value="'+escapeQuoteHtml(product)+'">'+escapeQuoteHtml(product)+'</option>').join('')).val(current);}
function renderQuotationView(){const product=$('#quoteProductFilter').val();const from=$('#quoteDateFrom').val();const to=$('#quoteDateTo').val();const search=String($('#quoteSearchInput').val()||'').trim().toLowerCase();const size=Number($('#quotePageSize').val()||10);quotationFilteredRows=quotationRows.filter(row=>{const date=quoteRecordDate(row);const haystack=[row.quotation_number,row.target_name,row.target_email,row.target_phone,row.product_names].join(' ').toLowerCase();return(!product||quoteProducts(row).includes(product))&&(!from||date>=from)&&(!to||date<=to)&&(!search||haystack.includes(search));});const pages=Math.max(1,Math.ceil(quotationFilteredRows.length/size));quotationCurrentPage=Math.min(quotationCurrentPage,pages);const start=(quotationCurrentPage-1)*size;renderQuotationTable(quotationFilteredRows.slice(start,start+size),start);renderQuotationPagination(pages);const first=quotationFilteredRows.length?start+1:0,last=Math.min(start+size,quotationFilteredRows.length);$('#quoteShowingText').text('Showing '+first+'-'+last+' of '+quotationFilteredRows.length+' quotations');}
function renderQuotationTable(rows,offset){if(!rows.length){$('#quoteTableBody').html('<tr><td colspan="8" class="!py-10 text-center !text-slate-400">No quotations match the selected filters.</td></tr>');return;}$('#quoteTableBody').html(rows.map((row,index)=>{const products=quoteProducts(row);const productLabel=products.length?products[0]+(products.length>1?' +'+(products.length-1):''):'—';return `<tr onclick="viewQuoteDetails(${Number(row.id)})"><td><span class="quote-index">${String(offset+index+1).padStart(2,'0')}</span></td><td class="font-extrabold text-slate-800">${escapeQuoteHtml(row.quotation_number||'—')}</td><td>${escapeQuoteHtml(formatQuoteDate(row.source_created_at||row.created_at))}</td><td class="font-extrabold text-slate-700">${escapeQuoteHtml(row.target_name||'—')}</td><td>${escapeQuoteHtml(row.target_email||'—')}</td><td>${escapeQuoteHtml(row.target_phone||'—')}</td><td title="${escapeQuoteHtml(products.join(', '))}">${escapeQuoteHtml(productLabel)}</td><td class="font-black text-slate-800">${formatQuoteMoney(row.total_amount,row.currency)}</td></tr>`;}).join(''));}
function renderQuotationPagination(totalPages){let html=`<button class="quote-page-btn" data-quote-page="${Math.max(1,quotationCurrentPage-1)}" ${quotationCurrentPage===1?'disabled':''}><i class="ti ti-chevron-left"></i></button>`;const from=Math.max(1,quotationCurrentPage-2),to=Math.min(totalPages,from+4);for(let page=from;page<=to;page++)html+=`<button class="quote-page-btn ${page===quotationCurrentPage?'is-active':''}" data-quote-page="${page}">${page}</button>`;html+=`<button class="quote-page-btn" data-quote-page="${Math.min(totalPages,quotationCurrentPage+1)}" ${quotationCurrentPage===totalPages?'disabled':''}><i class="ti ti-chevron-right"></i></button>`;$('#quotePagination').html(html);}
function viewQuoteDetails(id){$('#quoteModalTitle').text('Quotation Details');$('#quoteModalBody').html('Loading...');$('#quotePdfButton').addClass('hidden').attr('href','#');$('#quoteModal').modal('show');$.getJSON('ajax.php?action=getQuoteDetails',{id:id}).done(function(response){if(response.status!=='success'){ $('#quoteModalBody').html('<div class="text-rose-600">'+escapeQuoteHtml(response.message||'Quotation details are unavailable.')+'</div>');return;}$('#quotePdfButton').removeClass('hidden').attr('href','quotation-snapshot-pdf.php?id='+encodeURIComponent(response.data.id));renderQuoteDetails(response.data);}).fail(function(xhr){$('#quoteModalBody').html('<div class="text-rose-600">'+escapeQuoteHtml(quoteResponseMessage(xhr,'Quotation details are unavailable.'))+'</div>');});}
function renderQuoteDetails(quote){$('#quoteModalTitle').text('Quotation Details: '+(quote.quotation_number||''));const summary=`<div class="grid grid-cols-1 gap-3 md:grid-cols-3"><div class="quote-summary"><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Customer</div><div class="mt-2 text-[11px] font-extrabold text-slate-700">${escapeQuoteHtml(quote.target_name||'—')}</div><div class="mt-1 text-[9px] text-slate-500">${escapeQuoteHtml(quote.target_email||'')}</div></div><div class="quote-summary"><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Generated</div><div class="mt-2 text-[11px] font-extrabold text-slate-700">${escapeQuoteHtml(formatQuoteDate(quote.created_at))}</div><div class="mt-1 text-[9px] uppercase text-slate-500">${escapeQuoteHtml(quote.status||'generated')}</div></div><div class="quote-summary"><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Quote Amount</div><div class="mt-2 text-base font-black" style="color: var(--appearance-accent, #166534);">${formatQuoteMoney(quote.total_amount,quote.currency)}</div><div class="mt-1 text-[9px] text-slate-500">${escapeQuoteHtml(quote.target_phone||'')}</div></div></div>`;const items=Array.isArray(quote.items)?quote.items:[];const itemTable=`<div class="mt-4 overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="quote-items"><thead><tr><th>Product</th><th>SKU</th><th>Qty</th><th>Unit Price</th><th>GST</th><th>Total</th></tr></thead><tbody>${items.length?items.map(item=>`<tr><td class="font-bold text-slate-700">${escapeQuoteHtml(item.product_name||'—')}</td><td>${escapeQuoteHtml(item.sku||'—')}</td><td>${Number(item.quantity||0)}</td><td>${formatQuoteMoney(item.unit_price,quote.currency)}</td><td>${Number(item.gst_rate||0).toFixed(2)}%</td><td class="font-black text-slate-700">${formatQuoteMoney(item.line_total,quote.currency)}</td></tr>`).join(''):'<tr><td colspan="6" class="text-center text-slate-400">No synchronized line items.</td></tr>'}</tbody></table></div>`;const notes=quote.notes?`<div class="quote-summary mt-3"><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">Notes</div><div class="mt-2 text-[10px] text-slate-600">${escapeQuoteHtml(quote.notes)}</div></div>`:'';$('#quoteModalBody').html(summary+itemTable+notes);}
function renderQuoteDetailsComplete(quote) {
    $('#quoteModalTitle').text('Quotation Details: ' + (quote.quotation_number || ''));
    const card = (label, primary, secondary) => `<div class="quote-summary"><div class="text-[8px] font-black uppercase tracking-widest text-slate-400">${escapeQuoteHtml(label)}</div><div class="mt-2 text-[11px] font-extrabold text-slate-700">${escapeQuoteHtml(primary || '—')}</div><div class="mt-1 text-[9px] text-slate-500">${escapeQuoteHtml(secondary || '')}</div></div>`;
    const summary = `<div class="grid grid-cols-1 gap-3 md:grid-cols-4">${card('Customer',quote.target_name,quote.target_email)}${card('Target company',quote.target_company_name,quote.target_company_gstin)}${card('Website owner',quote.owner_user_name||quote.created_by_name,quote.owner_company_name||quote.owner_user_email)}${card('Generated',formatQuoteDate(quote.source_created_at||quote.created_at),quote.status||'generated')}</div>`;
    const addresses = `<div class="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">${card('Billing address',quote.billing_address,'GSTIN: '+(quote.customer_gstin||'—'))}${card('Shipping address',quote.shipping_address,'Seller GSTIN: '+(quote.seller_gstin||'—'))}</div>`;
    const items = Array.isArray(quote.items) ? quote.items : [];
    const itemTable = `<div class="mt-4 overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="quote-items"><thead><tr><th>Product</th><th>SKU / Variant</th><th>Qty</th><th>Unit price</th><th>Unit tax</th><th>Discount</th><th>Taxable</th><th>Tax</th><th>Total</th></tr></thead><tbody>${items.length ? items.map(item => `<tr><td class="font-bold text-slate-700">${escapeQuoteHtml(item.product_name||'—')}</td><td>${escapeQuoteHtml([item.sku,item.variant_name].filter(Boolean).join(' / ')||'—')}</td><td>${Number(item.quantity||0)}</td><td>${formatQuoteMoney(item.unit_price,quote.currency)}</td><td>${formatQuoteMoney(item.unit_tax_amount,quote.currency)}</td><td>${Number(item.discount_percent||0).toFixed(2)}%<br>${formatQuoteMoney(item.line_discount_amount,quote.currency)}</td><td>${formatQuoteMoney(item.line_subtotal,quote.currency)}</td><td>${formatQuoteMoney(item.line_tax_amount,quote.currency)}</td><td class="font-black text-slate-700">${formatQuoteMoney(item.line_total,quote.currency)}</td></tr>`).join('') : '<tr><td colspan="9" class="text-center text-slate-400">No synchronized line items.</td></tr>'}</tbody></table></div>`;
    const totals = `<div class="mt-3 grid grid-cols-2 gap-3 md:grid-cols-6">${card('Subtotal',formatQuoteMoney(quote.subtotal,quote.currency),'')}${card('Discount',formatQuoteMoney(quote.discount_amount,quote.currency),'')}${card('Tax',formatQuoteMoney(quote.tax_amount,quote.currency),'')}${card('Freight',formatQuoteMoney(quote.freight_charges,quote.currency),'Tax '+formatQuoteMoney(quote.freight_tax_amount,quote.currency))}${card('Rounding',formatQuoteMoney(quote.rounding_amount,quote.currency),'')}${card('Document total',formatQuoteMoney(quote.total_amount,quote.currency),quote.currency||'INR')}</div>`;
    const text = [quote.terms ? card('Terms',quote.terms,'') : '', quote.notes ? card('Notes',quote.notes,'') : ''].filter(Boolean).join('');
    $('#quoteModalBody').html(summary + addresses + itemTable + totals + (text ? `<div class="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">${text}</div>` : ''));
}
renderQuoteDetails = renderQuoteDetailsComplete;

function importQuotationRows(button) {
    button.disabled = true;
    button.innerHTML = '<i class="ti ti-loader-2 animate-spin"></i>Importing';
    $.post('syncAjax.php', {
        action: 'triggerEntitySync',
        entity: 'quotations',
        csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || ''
    }, null, 'json').done(function(response) {
        if (window.toastr) {
            if (response.success || response.status === 'success') toastr.success(response.message || 'Quotation import completed.');
            else toastr.error(response.message || 'Quotation import failed.');
        } else {
            alert(response.message || (response.success ? 'Quotation import completed.' : 'Quotation import failed.'));
        }
        if (response.success === true || response.status === 'success') loadQuotationGrid();
    }).fail(function(xhr) {
        const msg = quoteResponseMessage(xhr, 'Quotation import failed.');
        if (window.toastr) toastr.error(msg);
        else alert(msg);
    }).always(function() {
        button.disabled = false;
        button.innerHTML = '<i class="ti ti-download"></i>Import';
    });
}

function exportQuotationRows() {
    const rows = [['Quotation Number','Date','Customer','Email','Mobile','Products','Amount','Currency','Status']];
    quotationFilteredRows.forEach(row => rows.push([row.quotation_number||'',quoteRecordDate(row),row.target_name||'',row.target_email||'',row.target_phone||'',quoteProducts(row).join(', '),row.total_amount||0,row.currency||'INR',row.status||'']));
    downloadQuoteCsv('quotation-management.csv', rows);
}

function downloadQuoteCsv(filename, rows) {
    const csv = rows.map(row => row.map(value => '"' + String(value == null ? '' : value).replace(/"/g, '""') + '"').join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    URL.revokeObjectURL(link.href);
    link.remove();
}

function localDateKey(date) {
    const offset = date.getTimezoneOffset();
    return new Date(date.getTime() - offset * 60000).toISOString().slice(0, 10);
}

function formatQuoteMoney(value, currency) {
    return (currency || 'INR') + ' ' + Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatQuoteDate(value) {
    if (!value) return '—';
    const date = new Date(String(value).replace(' ', 'T'));
    return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function quoteResponseMessage(xhr, fallback) {
    return xhr && xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : fallback;
}

function escapeQuoteHtml(value) {
    return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

$(document).on('submit', '#quotationRequestsExportForm', function (e) {
    e.preventDefault();
    const search = $('#quoteSearchInput').val() || '';
    const formData = new FormData(this);
    formData.append('exportQuotationRequests', '1');
    formData.append('search', search);

    $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    const $submitBtn = $('#quotationRequestsExportForm button[type="submit"]');
    $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Exporting...');

    $.ajax({
        url: 'exportajax.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (response) {
            if (response.success === 'success' || response.status === 'success') {
                $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                if (window.toastr) toastr.success(response.message);
                else alert(response.message);
            } else {
                if (window.toastr) toastr.error(response.message);
                else alert(response.message);
            }
        },
        error: function () {
            if (window.toastr) toastr.error('Server error occurred.');
            else alert('Server error occurred.');
        },
        complete: function () {
            $submitBtn.prop('disabled', false).html('<i class="ti ti-download text-base"></i> Export');
        }
    });
});

$(document).on('click', '#quotationRequestsExportForm .export-type-item', function () {
    const val = $(this).data('val');
    $('#exportTypeText').text($(this).text());
    $('#exportTypeSelect').val(val);
});

$(document).on('click', '#quoteDeselectAllColumnsBtn', function () {
    const allCheckboxes = $('#quotationRequestsExportForm .column-filter');
    const isAllSelected = allCheckboxes.filter(':checked').length === allCheckboxes.length;
    if (isAllSelected) {
        allCheckboxes.prop('checked', false);
        $(this).text('Select All');
    } else {
        allCheckboxes.prop('checked', true);
        $(this).text('Deselect All');
    }
});
</script>
<?php endSection(); ?>
