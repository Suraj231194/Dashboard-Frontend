<?php
$financeView = 'trade_receivables';
require __DIR__ . '/finance-page.php';
