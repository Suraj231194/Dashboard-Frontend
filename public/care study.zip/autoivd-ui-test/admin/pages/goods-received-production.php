<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= htmlspecialchars($pageTitle ?? 'Goods Received from Production') ?></h1>
            <p class="text-sm text-slate-500 mt-1">Acknowledge completed Transfer Tickets and reconcile finished-goods inventory</p>
        </div>
    </div>

    <!-- Incoming Transfer Tickets Widget -->
    <div id="incomingProductionReceiptAlert" class="mb-6 relative cursor-pointer w-full md:w-1/2" role="button" tabindex="0" aria-label="Show incoming Transfer Tickets">
        <div class="overflow-hidden rounded-xl border border-slate-200 p-4 shadow-sm transition-all hover:shadow-md hover:bg-slate-50" style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: var(--appearance-accent-light, #f3e8ff); border-radius: 0.75rem;">
                    <i class="ti ti-package-import" style="font-size: 1.5rem; color: var(--appearance-accent, #7c3aed);"></i>
                    <span id="incomingProductionReceiptCount" style="position: absolute; top: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7c3aed); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">0</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: var(--appearance-accent, #4c1d95); margin: 0;">Incoming Transfer Ticket(s)!</h3>
                    </div>
                    <p class="font-medium mt-1 mb-0" style="font-size: 0.875rem;">
                        <span id="incomingProductionReceiptText" class="font-bold">0</span> incoming transfer ticket(s) sent from Production. Click here to review and acknowledge receipt.
                    </p>
                </div>
            </div>
            <div>
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <!-- ═══════════ Main List Card ═══════════ -->
    <div id="productionReceiptList" class="w-full mb-6">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    
                    <!-- Per Page Dropdown -->
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="productionReceiptPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="production-receipt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="production-receipt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="production-receipt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="production-receipt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="production-receipt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="production-receipt-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <input type="hidden" id="productionReceiptPerPage" value="10">

                    <!-- Search Input -->
                    <div class="relative h-10 min-w-[160px] max-w-[280px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="productionReceiptSearch"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Plan, Lot, Product...">
                    </div>

                    <!-- Status Filter Dropdown -->
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="productionReceiptStatusText" class="whitespace-nowrap">All Statuses</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="production-receipt-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="ALL">All Statuses</a></li>
                            <li><a class="production-receipt-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="PENDING">Pending Acknowledgment</a></li>
                            <li><a class="production-receipt-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="RECEIVED">Received into Stock</a></li>
                        </ul>
                    </div>
                    <input type="hidden" id="productionReceiptStatus" value="ALL">

                </div>
            </div>

            <!-- Table -->
            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="px-6 py-3">Plan No</th>
                            <th class="px-6 py-3">Lot / Batch</th>
                            <th class="px-6 py-3">Transfer Ticket</th>
                            <th class="px-6 py-3">Product Name</th>
                            <th class="px-6 py-3">Transferred Qty</th>
                            <th class="px-6 py-3">Actual Received</th>
                            <th class="px-6 py-3">Status</th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="productionReceiptTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Pagination Footer -->
            <div class="flex flex-col sm:flex-row items-center justify-between border-t border-slate-200 px-6 py-4 gap-3">
                <span id="productionReceiptSummary" class="text-sm text-slate-500 font-medium"></span>
                <div class="flex items-center gap-1.5">
                    <button id="productionReceiptPrevious" class="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed">
                        <i class="ti ti-chevron-left text-base"></i>
                    </button>
                    <div id="productionReceiptPages" class="flex items-center gap-1.5"></div>
                    <button id="productionReceiptNext" class="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed">
                        <i class="ti ti-chevron-right text-base"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ═══════════ Production Receipt Modal ═══════════ -->
<div class="modal fade animate__animated fadeIn" id="incomingProductionReceiptModal" tabindex="-1" aria-hidden="true" aria-labelledby="incomingProductionReceiptModalTitle">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-6 !py-4">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-violet-50 text-violet-700 ring-1 ring-violet-100"><i class="ti ti-package-import text-xl"></i></span>
                    <div>
                        <h5 id="incomingProductionReceiptModalTitle" class="modal-title m-0 text-lg font-bold text-slate-900">Incoming Transfer Tickets</h5>
                        <p class="m-0 mt-0.5 text-xs font-medium text-slate-500">Review completed transfers from Production and acknowledge their receipt into Store.</p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
            </div>
            <div class="modal-body bg-slate-50/70 !p-0">
                <div class="overflow-x-auto bg-white">
                    <table class="w-full min-w-[760px] text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-100 bg-slate-50 text-[11px] font-bold uppercase tracking-widest text-slate-400"><tr><th class="px-5 py-3">Plan No</th><th class="px-5 py-3">Lot / Batch</th><th class="px-5 py-3">Transfer Ticket</th><th class="px-5 py-3">Product</th><th class="px-5 py-3">Transferred Qty</th><th class="px-5 py-3 text-center">Action</th></tr></thead>
                        <tbody id="incomingProductionReceiptTableBody" class="divide-y divide-slate-100 bg-white"></tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer flex items-center justify-between border-t border-slate-200 bg-white !px-6 !py-3">
                <span id="incomingProductionReceiptSummary" class="text-xs font-medium text-slate-500">Showing 0 to 0 of 0 incoming tickets</span>
                <div class="flex items-center gap-1.5">
                    <button id="incomingProductionReceiptPrevious" type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Previous page"><i class="ti ti-chevron-left"></i></button>
                    <span id="incomingProductionReceiptPage" class="inline-flex h-9 min-w-9 items-center justify-center rounded-xl bg-violet-700 px-3 text-sm font-bold text-white shadow-sm">1</span>
                    <button id="incomingProductionReceiptNext" type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Next page"><i class="ti ti-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade animate__animated fadeIn" id="productionReceiptModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                        <i class="ti ti-package-import text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Acknowledge Production Receipt</h5>
                        <p id="productionReceiptModalSubtitle" class="m-0 text-xs font-medium text-slate-500 leading-relaxed"></p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-xl"></i>
                </button>
            </div>
            <form id="productionReceiptForm">
                <div class="modal-body bg-slate-50/70 !px-6 !py-5 space-y-4">
                    <input type="hidden" id="productionReceiptId">
                    
                    <div id="productionReceiptDetails" class="grid grid-cols-1 md:grid-cols-2 gap-3"></div>

                    <div class="bg-white rounded-xl border border-slate-200 p-4 shadow-sm space-y-3">
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1" for="productionReceiptActual">
                                Actual Received Quantity <strong class="text-rose-500">*</strong>
                            </label>
                            <input id="productionReceiptActual" type="number" min="0.00000001" step="any"
                                class="h-10 w-full !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-900 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                placeholder="Enter received quantity" required>
                        </div>

                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1" for="productionReceiptRemarks">
                                Store Remarks / Notes
                            </label>
                            <textarea id="productionReceiptRemarks" rows="2"
                                class="w-full !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30 resize-none"
                                placeholder="Add any discrepancies or verification notes..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer flex items-center justify-between border-t border-slate-200 bg-white !px-6 !py-3">
                    <button type="button" class="inline-flex h-10 items-center justify-center rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button id="productionReceiptAcknowledge" type="submit" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-emerald-700 px-6 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <i class="ti ti-check text-lg"></i> Acknowledge Receipt
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
(function(){
    let receiptPage = 1, receiptTotalPages = 1, receiptRecords = [];
    let incomingReceiptPage = 1, incomingReceiptTotalPages = 1, incomingReceiptRecords = [];
    const esc = v => $('<div>').text(v == null ? '' : String(v)).html();

    function pageButtons() {
        const pages = [...new Set([1, receiptTotalPages, receiptPage - 2, receiptPage - 1, receiptPage, receiptPage + 1, receiptPage + 2].filter(p => p >= 1 && p <= receiptTotalPages))].sort((a, b) => a - b);
        let prev = 0;
        return pages.map(p => {
            const gap = prev && p > prev + 1 ? '<span class="px-1 text-slate-400">&hellip;</span>' : '';
            prev = p;
            return gap + `<button type="button" data-page="${p}" class="production-receipt-page inline-flex h-9 min-w-9 items-center justify-center rounded-xl px-3 text-sm font-bold transition-colors ${p === receiptPage ? 'bg-emerald-700 text-white shadow-sm ring-1 ring-emerald-900/10' : 'border border-slate-200 bg-white text-slate-600 hover:bg-slate-50'}">${p}</button>`;
        }).join('');
    }

    function loadReceipts(page = 1) {
        receiptPage = page;
        const search = $('#productionReceiptSearch').val().trim();
        const perPage = $('#productionReceiptPerPage').val();
        const status = $('#productionReceiptStatus').val();

        $('#productionReceiptTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.post('ajax.php', {
            loadGoodsReceivedProduction: 'loadGoodsReceivedProduction',
            page: page,
            per_page: perPage,
            search: search,
            receipt_status: status
        }, function(r) {
            if (!r || r.status !== 'success') {
                toastr.error(r?.message || 'Unable to load Production receipts.');
                $('#productionReceiptTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                return;
            }

            receiptRecords = r.records || [];
            receiptPage = Number(r.page || 1);
            receiptTotalPages = Number(r.totalPages || 1);

            const pendingCount = Number(r.pendingCount || 0);
            $('#incomingProductionReceiptCount').text(pendingCount > 99 ? '99+' : pendingCount);
            $('#incomingProductionReceiptText').text(pendingCount === 1 ? '1 Transfer Ticket is awaiting Store acknowledgement.' : `${pendingCount} Transfer Tickets are awaiting Store acknowledgement.`);
            $('#incomingProductionReceiptAlert').toggleClass('opacity-70', pendingCount === 0);

            const offset = (receiptPage - 1) * Number(r.perPage || 10);

            if (receiptRecords.length > 0) {
                $('#productionReceiptTableBody').html(receiptRecords.map((x, i) => {
                    const isReceived = x.receipt_status === 'RECEIVED';
                    const statusBadge = isReceived
                        ? `<span class="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 ring-1 ring-emerald-600/20"><i class="ti ti-circle-check text-sm"></i> Received</span>`
                        : `<span class="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-700 ring-1 ring-amber-600/20"><i class="ti ti-clock text-sm"></i> Pending</span>`;

                    const actionBtn = isReceived
                        ? `<button type="button" class="production-receipt-view inline-flex h-8 w-8 items-center justify-center rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors" data-id="${x.id}" title="View Details"><i class="ti ti-eye text-base"></i></button>`
                        : `<button type="button" class="production-receipt-view inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-emerald-700 text-white hover:bg-emerald-800 shadow-sm transition-colors" data-id="${x.id}" title="Acknowledge Receipt"><i class="ti ti-package-import text-sm"></i> Acknowledge</button>`;

                    return `<tr class="production-receipt-row cursor-pointer transition-colors hover:bg-slate-50/70" data-id="${x.id}" tabindex="0">
                        <td class="px-6 py-4 font-semibold text-slate-500">${offset + i + 1}</td>
                        <td class="px-6 py-4 font-bold text-emerald-700">${esc(x.production_plan_no)}</td>
                        <td class="px-6 py-4 whitespace-nowrap"><span class="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-mono font-semibold bg-slate-100 text-slate-800 border border-slate-200">${esc(x.lot_batch_no)}</span></td>
                        <td class="px-6 py-4 font-bold text-slate-900">${esc(x.ticket_no)}</td>
                        <td class="px-6 py-4 font-semibold text-slate-800">${esc(x.product_name)}</td>
                        <td class="px-6 py-4 font-medium text-slate-700">${Number(x.transferred_quantity).toLocaleString()} ${esc(x.unit_name)}</td>
                        <td class="px-6 py-4 font-bold ${x.actual_received_quantity != null ? 'text-emerald-700' : 'text-slate-400'}">${x.actual_received_quantity == null ? '-' : Number(x.actual_received_quantity).toLocaleString() + ' ' + esc(x.unit_name)}</td>
                        <td class="px-6 py-4">${statusBadge}</td>
                        <td class="px-6 py-4 text-center whitespace-nowrap">${actionBtn}</td>
                    </tr>`;
                }).join(''));
            } else {
                $('#productionReceiptTableBody').html('<tr><td colspan="9" class="px-6 py-12 text-center text-sm font-medium text-slate-500">No Production receipts found.</td></tr>');
            }

            const total = Number(r.totalRows || 0);
            const first = total > 0 ? offset + 1 : 0;
            const last = Math.min(offset + receiptRecords.length, total);
            $('#productionReceiptSummary').text(`Showing ${first} to ${last} of ${total} records`);
            $('#productionReceiptPages').html(pageButtons());
            $('#productionReceiptPrevious').prop('disabled', receiptPage <= 1);
            $('#productionReceiptNext').prop('disabled', receiptPage >= receiptTotalPages);
        }, 'json');
    }

    function loadIncomingReceipts(page = 1) {
        incomingReceiptPage = page;
        $('#incomingProductionReceiptTableBody').html('<tr><td colspan="6" class="px-5 py-10 text-center"><div class="spinner-border text-violet-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        $.post('ajax.php', {
            loadGoodsReceivedProduction: 'loadGoodsReceivedProduction',
            page: page,
            per_page: 10,
            search: '',
            receipt_status: 'PENDING'
        }, function(r) {
            if (!r || r.status !== 'success') {
                toastr.error(r?.message || 'Unable to load incoming Transfer Tickets.');
                $('#incomingProductionReceiptTableBody').html('<tr><td colspan="6" class="px-5 py-10 text-center text-sm font-semibold text-rose-600">Unable to load incoming Transfer Tickets.</td></tr>');
                return;
            }
            incomingReceiptRecords = r.records || [];
            incomingReceiptPage = Number(r.page || 1);
            incomingReceiptTotalPages = Number(r.totalPages || 1);
            const total = Number(r.totalRows || 0);
            const offset = (incomingReceiptPage - 1) * Number(r.perPage || 10);
            const first = total > 0 ? offset + 1 : 0;
            const last = Math.min(offset + incomingReceiptRecords.length, total);
            $('#incomingProductionReceiptSummary').text(`Showing ${first} to ${last} of ${total} incoming ticket${total === 1 ? '' : 's'}`);
            $('#incomingProductionReceiptPage').text(incomingReceiptPage);
            $('#incomingProductionReceiptPrevious').prop('disabled', incomingReceiptPage <= 1);
            $('#incomingProductionReceiptNext').prop('disabled', incomingReceiptPage >= incomingReceiptTotalPages);
            if (!incomingReceiptRecords.length) {
                $('#incomingProductionReceiptTableBody').html('<tr><td colspan="6" class="px-5 py-12 text-center text-sm font-medium text-slate-500">No incoming Transfer Tickets are awaiting acknowledgement.</td></tr>');
                return;
            }
            $('#incomingProductionReceiptTableBody').html(incomingReceiptRecords.map(function(x) {
                return `<tr class="transition-colors hover:bg-slate-50/70">
                    <td class="px-5 py-4 font-bold text-emerald-700">${esc(x.production_plan_no)}</td>
                    <td class="px-5 py-4 whitespace-nowrap"><span class="inline-flex rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 font-mono text-xs font-semibold text-slate-800">${esc(x.lot_batch_no)}</span></td>
                    <td class="px-5 py-4 font-bold text-slate-900">${esc(x.ticket_no)}</td>
                    <td class="px-5 py-4 font-semibold text-slate-800">${esc(x.product_name)}</td>
                    <td class="px-5 py-4 font-medium text-slate-700">${Number(x.transferred_quantity).toLocaleString()} ${esc(x.unit_name)}</td>
                    <td class="px-5 py-4 text-center"><button type="button" class="incoming-production-receipt-review inline-flex items-center gap-1.5 rounded-xl bg-emerald-700 px-3 py-1.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-emerald-800" data-id="${x.id}"><i class="ti ti-package-import text-sm"></i> Review & Acknowledge</button></td>
                </tr>`;
            }).join(''));
        }, 'json');
    }

    function openReceipt(id, records = receiptRecords) {
        const x = records.find(row => Number(row.id) === Number(id));
        if (!x) return;

        $('#productionReceiptId').val(x.id);
        $('#productionReceiptModalSubtitle').text(`${x.ticket_no} · ${x.product_name}`);
        
        $('#productionReceiptDetails').html(`
            <div class="rounded-xl border border-slate-200 bg-white p-3 shadow-xs">
                <span class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Production Plan / Lot</span>
                <p class="m-0 mt-1 text-sm font-bold text-slate-900">${esc(x.production_plan_no)} <span class="font-normal text-slate-400">·</span> <span class="font-mono text-emerald-700">${esc(x.lot_batch_no)}</span></p>
            </div>
            <div class="rounded-xl border border-slate-200 bg-white p-3 shadow-xs">
                <span class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Transferred Quantity</span>
                <p class="m-0 mt-1 text-sm font-bold text-slate-900">${Number(x.transferred_quantity).toLocaleString()} <span class="text-xs font-normal text-slate-500">${esc(x.unit_name)}</span></p>
            </div>
        `);

        $('#productionReceiptActual')
            .val(x.actual_received_quantity == null ? x.transferred_quantity : x.actual_received_quantity)
            .attr('max', x.transferred_quantity)
            .prop('readonly', x.receipt_status === 'RECEIVED');

        $('#productionReceiptRemarks')
            .val(x.remarks || '')
            .prop('readonly', x.receipt_status === 'RECEIVED');

        if (x.receipt_status === 'RECEIVED') {
            $('#productionReceiptAcknowledge').hide();
        } else {
            $('#productionReceiptAcknowledge').show();
        }

        $('#productionReceiptModal').modal('show');
    }

    $(document).ready(function() {
        loadReceipts();
    });

    $('#incomingProductionReceiptAlert').on('click keydown', function(e) {
        if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
        if (e.type === 'keydown') e.preventDefault();
        incomingReceiptPage = 1;
        $('#incomingProductionReceiptModal').modal('show');
        loadIncomingReceipts(1);
    });

    $(document).on('input', '#productionReceiptSearch', function() {
        loadReceipts(1);
    });

    $(document).on('click', '.production-receipt-per-page-item', function() {
        const val = $(this).data('val');
        $('#productionReceiptPerPage').val(val);
        $('#productionReceiptPerPageText').text($(this).text());
        loadReceipts(1);
    });

    $(document).on('click', '.production-receipt-status-item', function() {
        const val = $(this).data('val');
        $('#productionReceiptStatus').val(val);
        $('#productionReceiptStatusText').text($(this).text());
        loadReceipts(1);
    });

    $(document).on('click', '.production-receipt-page', function() {
        loadReceipts($(this).data('page'));
    });

    $('#productionReceiptPrevious').on('click', function() {
        if (receiptPage > 1) loadReceipts(receiptPage - 1);
    });

    $('#productionReceiptNext').on('click', function() {
        if (receiptPage < receiptTotalPages) loadReceipts(receiptPage + 1);
    });

    $(document).on('click', '.production-receipt-row', function(e) {
        if ($(e.target).closest('button, a, input').length && !$(e.target).closest('.production-receipt-view').length) return;
        openReceipt($(this).data('id'));
    });

    $(document).on('click', '.production-receipt-view', function(e) {
        e.stopPropagation();
        openReceipt($(this).data('id'));
    });

    $(document).on('click', '.incoming-production-receipt-review', function() {
        const receiptId = $(this).data('id');
        $('#incomingProductionReceiptModal').one('hidden.bs.modal', function() {
            $('#productionReceiptModal').data('opened-from-incoming', true);
            openReceipt(receiptId, incomingReceiptRecords);
        }).modal('hide');
    });

    $('#incomingProductionReceiptPrevious').on('click', function() {
        if (incomingReceiptPage > 1) loadIncomingReceipts(incomingReceiptPage - 1);
    });

    $('#incomingProductionReceiptNext').on('click', function() {
        if (incomingReceiptPage < incomingReceiptTotalPages) loadIncomingReceipts(incomingReceiptPage + 1);
    });

    $('#productionReceiptModal').on('hidden.bs.modal', function() {
        if ($(this).data('opened-from-incoming')) {
            $(this).data('opened-from-incoming', false);
            $('#incomingProductionReceiptModal').modal('show');
        }
    });

    $('#productionReceiptForm').on('submit', function(e) {
        e.preventDefault();
        const $btn = $('#productionReceiptAcknowledge');
        const origHtml = $btn.html();
        $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-lg"></i> Saving...');

        $.post('ajax.php', {
            acknowledgeGoodsReceivedProduction: 'acknowledgeGoodsReceivedProduction',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
            receipt_id: $('#productionReceiptId').val(),
            actual_received_quantity: $('#productionReceiptActual').val(),
            remarks: $('#productionReceiptRemarks').val()
        }, function(r) {
            if (r?.status === 'success') {
                toastr.success(r.message);
                const openedFromIncoming = $('#productionReceiptModal').data('opened-from-incoming') === true;
                $('#productionReceiptModal').data('opened-from-incoming', false);
                $('#productionReceiptModal').modal('hide');
                loadReceipts(receiptPage);
                if (openedFromIncoming) {
                    loadIncomingReceipts(incomingReceiptPage);
                    $('#incomingProductionReceiptModal').modal('show');
                }
            } else {
                toastr.error(r?.message || 'Unable to acknowledge receipt.');
            }
        }, 'json').always(function() {
            $btn.prop('disabled', false).html(origHtml);
        });
    });
})();
</script>
<?php endSection(); ?>
