<style>
    /* Hide scrollbar for sidebar */
    .sidebar-body-scroll::-webkit-scrollbar {
        width: 4px;
    }

    .sidebar-body-scroll::-webkit-scrollbar-thumb {
        background-color: #cbd5e1;
        border-radius: 4px;
    }

    .chat-history-body::-webkit-scrollbar {
        width: 6px;
    }

    .chat-history-body::-webkit-scrollbar-thumb {
        background-color: #94a3b8;
        border-radius: 4px;
    }

    .chat-contact-list-item.active>a {
        background-color: #ecfdf5 !important;
        color: #047857 !important;
        font-weight: 700;
    }

    .chat-contact-list-item.active>a i.ti-message-circle {
        color: #10b981 !important;
    }

    /* Animation for sending messages */
    .mic-btn.listening {
        background-color: #fce7f3;
        /* pink-100 */
        color: #be185d;
        /* pink-700 */
        animation: pulse 1.5s infinite;
    }

    @keyframes pulse {
        0% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.1);
        }

        100% {
            transform: scale(1);
        }
    }
    @media (min-width: 768px) {
        .chat-layout-container {
            flex-direction: row !important;
            height: calc(100vh - 13rem) !important;
        }
        .chat-sidebar {
            width: 20rem !important;
            height: auto !important;
            border-bottom: none !important;
            border-right: 1px solid #e2e8f0 !important;
        }
    }
</style>

<div class="container-xxl flex-grow-1 container-p-y">
    <!-- Header -->
    <div class="flex items-center justify-between mb-6">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1
                    style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                    <?= $pageTitle ?></h1>
            </div>
        </div>
    </div>

    <!-- Main Chat App Container -->
    <div class="flex flex-col overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-slate-900/5 chat-layout-container" style="height: calc(100vh - 10rem);">

        <!-- Sidebar -->
        <div class="w-full h-1/3 flex-shrink-0 flex flex-col border-b border-slate-200 bg-slate-50/50 chat-sidebar" id="app-chat-contacts">
            <div class="p-4 border-b border-slate-200">
                <button type="button"
                    class="new-chat-ai flex w-full h-10 items-center justify-center gap-2 bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                    style="border-radius: 0.75rem !important;">
                    <i class="ti ti-edit text-lg"></i>
                    New Chat
                </button>
            </div>

            <div class="flex-1 overflow-y-auto sidebar-body-scroll p-4 relative">
                <div class="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400 px-1">Your Chats</div>
                <ul class="flex flex-col gap-1 list-none p-0 m-0" id="chatAiLastTitle">
                    <!-- Chats will be loaded here -->
                </ul>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="flex-1 flex flex-col bg-white relative overflow-hidden chat-main-area">
            <!-- Chat Header -->
            <div
                class="flex items-center px-6 py-4 border-b border-slate-100 bg-white/80 backdrop-blur-sm z-10 sticky top-0 shadow-sm">
                <h5 class="m-0 font-bold text-slate-800 flex items-center gap-2">
                    <span class="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
                        <i class="ti ti-robot text-lg"></i>
                    </span>
                    AI Assistant
                </h5>
            </div>

            <!-- Messages Container -->
            <div class="flex-1 overflow-y-auto chat-history-body p-6 bg-slate-50/30">
                <div class="chat-preview flex flex-col gap-6">
                    <!-- Messages will be loaded here -->
                </div>
            </div>

            <!-- Input Area -->
            <div class="p-4 bg-white border-t border-slate-100 z-10">
                <form id="chatSearchForm" class="relative max-w-5xl mx-auto flex items-end gap-2">
                    <div
                        class="relative flex-1 flex items-center rounded-xl border border-slate-200 bg-white pl-4 pr-2 py-2 shadow-sm ring-1 ring-slate-900/5 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all">
                        <textarea name="question" id="chatSearch" rows="1"
                            class="w-full resize-none border-0 bg-transparent py-2 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-0 max-h-32 scrollbar-hide"
                            placeholder="Ask anything..." autocomplete="off"></textarea>

                        <div class="flex items-center gap-1 pl-2">
                            <button type="button"
                                class="mic-btn flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-emerald-600 transition-colors focus:outline-none">
                                <i class="ti ti-microphone text-xl"></i>
                            </button>
                            <button type="submit"
                                class="send-btn flex h-10 w-10 shrink-0 items-center justify-center bg-emerald-600 text-white shadow-sm hover:bg-emerald-700 transition-colors focus:outline-none disabled:opacity-50"
                                style="border-radius: 0.75rem !important;">
                                <i class="ti ti-send text-lg"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>

<!-- We don't strictly need app-chat.js if it conflicts with our Tailwind, but we keep it for any dependencies if it exists -->
<!-- <script src="<?= asset('assets/js/app-chat.js') ?>"></script> -->

<script>
    let chatRequest = null;
    let isProcessing = false;
    let currentConversationId = 0;
    let chatPage = 1;
    let isLoadingMessages = false;
    let hasMoreMessages = true;

    let convoOffset = 0;
    let convoLimit = 10;
    let convoHasMore = true;
    let convoLoading = false;

    function formatTextWithLineBreaks(text) {
        return text ? text.replace(/\n/g, '<br/>') : '';
    }

    function loadConversationList(reset = false) {
        if (convoLoading) return;

        if (reset) {
            convoOffset = 0;
            convoHasMore = true;
            $('#chatAiLastTitle').html('');
        }

        if (!convoHasMore) return;

        convoLoading = true;
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                loadAiChatMessage: 'loadAiChatMessage',
                limit: convoLimit,
                offset: convoOffset
            },
            success: function (res) {
                if (res.status === 'success') {

                    let html = '';
                    if (res.data.length === 0 && convoOffset === 0) {
                        html += `<li class="text-sm text-slate-400 text-center py-4">No chats found</li>`;
                    }

                    res.data.forEach(item => {
                        // Check if this item is currently active
                        let activeClass = (item.id == currentConversationId) ? 'active' : '';

                        html += `
                        <li class="chat-contact-list-item group relative ${activeClass}">
                            <a class="flex items-center justify-between w-full rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700 cursor-pointer chat-contact-name" data-id="${item.id}">
                                <div class="flex items-center gap-3 overflow-hidden">
                                    <i class="ti ti-message-circle text-slate-400 group-hover:text-emerald-500 transition-colors"></i>
                                    <span class="truncate">${item.title}</span>
                                </div>
                                <button type="button" class="delete-chat opacity-0 group-hover:opacity-100 flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-100 hover:text-rose-600 transition-all focus:outline-none shrink-0 ml-2" data-id="${item.id}">
                                    <i class="ti ti-trash"></i>
                                </button>
                            </a>
                        </li>`;
                    });

                    $('#chatAiLastTitle').append(html);

                    convoOffset += convoLimit;
                    if (res.data.length < convoLimit) {
                        convoHasMore = false;
                    } else {
                        convoHasMore = true;
                    }

                }
            },
            complete: function () {
                convoLoading = false;
            }
        });
    }

    function loadMessages(conversationId, page) {
        if (isLoadingMessages || !hasMoreMessages) return;
        isLoadingMessages = true;
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                loadOldChatAIMessages: 'loadOldChatAIMessages',
                conversation_id: conversationId,
                page: page
            },
            success: function (res) {

                if (res.status === 'success') {
                    if (res.data.length === 0) {
                        hasMoreMessages = false;
                        return;
                    }
                    let html = '';
                    // Since it's paginated, messages usually come descending. We may need to prepend or append depending on API design.
                    // The original code prepended them. We'll do the same.
                    // But we should reverse the array if we prepend so they stay in chronological order, or the original API already returned them properly.
                    res.data.forEach(msg => {
                        if (msg.role === 'user') {
                            html += `
                                <div class="flex justify-end w-full animate__animated animate__fadeInUp animate__faster">
                                    <div class="max-w-[85%] rounded-xl rounded-tr-sm bg-emerald-600 px-5 py-3 text-sm text-white shadow-sm leading-relaxed">
                                        ${formatTextWithLineBreaks(msg.message)}
                                    </div>
                                </div>`;
                        } else {
                            html += `
                                <div class="flex justify-start w-full animate__animated animate__fadeInUp animate__faster">
                                    <div class="flex gap-3 max-w-[85%]">
                                        <div class="flex-shrink-0 mt-1 flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
                                            <i class="ti ti-robot"></i>
                                        </div>
                                        <div class="rounded-xl rounded-tl-sm border border-slate-200 bg-white px-5 py-3 text-sm text-slate-700 shadow-sm leading-relaxed">
                                            ${formatTextWithLineBreaks(msg.message)}
                                        </div>
                                    </div>
                                </div>`;
                        }
                    });
                    $('.chat-preview').prepend(html);

                    // If it's the first page, scroll to bottom
                    if (page === 1) {
                        $('.chat-history-body').scrollTop($('.chat-history-body')[0].scrollHeight);
                    }
                }
            },
            complete: function () {
                isLoadingMessages = false;
            }
        });
    }

    $(document).ready(function () {
        let recognition;
        let isListening = false;
        loadConversationList(true);
        startNewChat(); // initialize with welcome screen

        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();

            recognition.lang = 'en-IN';
            recognition.interimResults = true;
            recognition.continuous = false;

            recognition.onstart = function () {
                isListening = true;
                $('.mic-btn').addClass('listening');
                $('#chatSearch').attr('placeholder', 'Listening...');
            };

            recognition.onend = function () {
                isListening = false;
                $('.mic-btn').removeClass('listening');
                $('#chatSearch').attr('placeholder', 'Ask anything...');
            };

            recognition.onresult = function (event) {
                let transcript = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    transcript += event.results[i][0].transcript;
                }
                $('#chatSearch').val(transcript);
            };

        } else {
            $('.mic-btn').hide();
        }

        $('.mic-btn').on('click', function () {
            if (!recognition) return;
            if (isListening) {
                recognition.stop();
            } else {
                recognition.start();
            }
        });

        // Auto-resize textarea
        $('#chatSearch').on('input', function () {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
            if (this.value === '') {
                this.style.height = 'auto';
            }
        });

        // Submit on enter (but shift+enter for new line)
        $('#chatSearch').on('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        function sendMessage() {
            if (isProcessing) return;
            let text = $('#chatSearch').val().trim();
            if (text === '') return;

            isProcessing = true;

            $('.send-btn i')
                .removeClass('ti-send')
                .addClass('ti-loader ti-spin');

            $('.send-btn').css('pointer-events', 'none');

            if (!currentConversationId || $('.chat-preview').find('.bot-msg.text-muted').length > 0) {
                // Clear the welcome message if it's a new chat
                $('.chat-preview').html('');
            }

            $('.chat-preview').append(`
                <div class="flex justify-end w-full animate__animated animate__fadeInUp animate__faster">
                    <div class="max-w-[85%] rounded-xl rounded-tr-sm bg-emerald-600 px-5 py-3 text-sm text-white shadow-sm leading-relaxed">
                        ${formatTextWithLineBreaks(text)}
                    </div>
                </div>
            `);

            $('#chatSearch').val('');
            $('#chatSearch').css('height', 'auto'); // reset height
            $('.chat-history-body').scrollTop($('.chat-history-body')[0].scrollHeight);

            chatRequest = $.ajax({
                url: 'curlajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    chatGptInputValData: 'chatGptInputValData',
                    conversation_id: currentConversationId,
                    question: text
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('.chat-preview').append(`
                            <div class="flex justify-start w-full animate__animated animate__fadeInUp animate__faster">
                                <div class="flex gap-3 max-w-[85%]">
                                    <div class="flex-shrink-0 mt-1 flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
                                        <i class="ti ti-robot"></i>
                                    </div>
                                    <div class="rounded-xl rounded-tl-sm border border-slate-200 bg-white px-5 py-3 text-sm text-slate-700 shadow-sm leading-relaxed">
                                        ${formatTextWithLineBreaks(res.answer)}
                                    </div>
                                </div>
                            </div>
                        `);
                    } else {
                        $('.chat-preview').append(`
                            <div class="flex justify-start w-full animate__animated animate__fadeInUp animate__faster">
                                <div class="rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-800 shadow-sm">
                                    <i class="ti ti-alert-triangle mr-1"></i> Search request failed.
                                </div>
                            </div>
                        `);
                    }

                    // Update ID and refresh list so the new chat shows up immediately
                    currentConversationId = res.conversation_id;
                    loadConversationList(true);

                    $('.chat-history-body').scrollTop($('.chat-history-body')[0].scrollHeight);
                },
                error: function () {
                    $('.chat-preview').append(`
                        <div class="flex justify-start w-full animate__animated animate__fadeInUp animate__faster">
                            <div class="rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-800 shadow-sm">
                                <i class="ti ti-alert-triangle mr-1"></i> Search request encountered an error.
                            </div>
                        </div>
                    `);
                },
                complete: function () {
                    isProcessing = false;
                    chatRequest = null;

                    $('.send-btn i')
                        .removeClass('ti-loader ti-spin')
                        .addClass('ti-send');

                    $('.send-btn').css('pointer-events', 'auto');

                    $('.chat-history-body').scrollTop($('.chat-history-body')[0].scrollHeight);
                }
            });
        }

        function stopChatRequest() {
            if (chatRequest) {
                chatRequest.abort();
                isProcessing = false;

                $('.send-btn i')
                    .removeClass('ti-loader ti-spin')
                    .addClass('ti-send');

                $('.send-btn').css('pointer-events', 'auto');

                $('.chat-preview').append(`
                    <div class="flex justify-start w-full animate__animated animate__fadeInUp animate__faster">
                        <div class="rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-800 shadow-sm">
                            <i class="ti ti-hand-stop mr-1"></i> Search manually stopped.
                        </div>
                    </div>
                `);
            }
        }

        $('#chatSearchForm').on('submit', function (e) {
            e.preventDefault();
            sendMessage();
        });

        $('.send-btn').on('click', function (e) {
            e.preventDefault();
            sendMessage();
        });

    });

    $(document).on('click', '.new-chat-ai', function () {
        startNewChat();
    });

    function startNewChat() {
        if (chatRequest) {
            chatRequest.abort();
            chatRequest = null;
        }

        currentConversationId = 0;
        chatPage = 1;
        hasMoreMessages = true;
        isLoadingMessages = false;
        isProcessing = false;

        $('.chat-preview').html('');
        $('.chat-contact-list-item').removeClass('active');

        // Welcome Screen
        $('.chat-preview').append(`
            <div class="flex justify-center w-full mt-12 bot-msg text-muted">
                <div class="flex flex-col items-center text-center animate__animated animate__fadeIn">
                    <div class="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-emerald-500 mb-4 ring-8 ring-emerald-50/50 shadow-sm">
                        <i class="ti ti-sparkles text-3xl"></i>
                    </div>
                    <h5 class="text-xl font-bold text-slate-800 mb-2">How can I help you today?</h5>
                    <p class="text-sm text-slate-500 max-w-sm">Ask me anything about your ERP data, operations, or settings.</p>
                </div>
            </div>
        `);

        $('#chatSearch').focus();
    }


    // Make sure we capture clicks on the 'a' wrapper or the 'h6' inside it properly
    $(document).on('click', '.chat-contact-name', function (e) {
        // Prevent trigger if clicking on delete button
        if ($(e.target).closest('.delete-chat').length > 0) {
            return;
        }

        // Find the conversation ID from the anchor tag
        const conversationId = $(this).closest('a').data('id');
        if (!conversationId || currentConversationId === conversationId) return;

        $('.chat-contact-list-item').removeClass('active');
        $(this).closest('li').addClass('active');

        if (chatRequest) {
            chatRequest.abort();
            chatRequest = null;
        }

        currentConversationId = conversationId;
        chatPage = 1;
        hasMoreMessages = true;
        isLoadingMessages = false;
        $('.chat-preview').html('');
        loadMessages(currentConversationId, chatPage);
    });

    // Pagination for chat history scrolling up
    $('.chat-history-body').on('scroll', function () {
        if ($(this).scrollTop() === 0 && hasMoreMessages) {
            chatPage++;
            loadMessages(currentConversationId, chatPage);
        }
    });

    // Pagination for sidebar
    $('.sidebar-body-scroll').on('scroll', function () {
        if ($(this).scrollTop() + $(this).innerHeight() >= this.scrollHeight - 10) {
            loadConversationList();
        }
    });


    $(document).on('click', '.delete-chat', function (e) {
        e.preventDefault();
        e.stopPropagation(); // prevent opening the chat when deleting

        let id = $(this).data('id');
        let buttonClicked = $(this);

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light bg-emerald-600 border-emerald-600 hover:bg-emerald-700',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteChatAiTitleRecord: 'deleteChatAiTitleRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                            loadConversationList(true);
                            startNewChat();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

</script>

<?php endSection(); ?>