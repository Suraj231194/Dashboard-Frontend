<?php
// $roleId = $_SESSION['role_id'] ?? 0;

// Optional: You can also use a switch by role_id or define role names dynamically.
// switch ($roleId) {
//     case 1:
//         echo "<div class='card'><h3>System Admin Panel</h3><p>You have full access to users, roles, and permissions.</p></div>";
//         break;

//     case 2:
//         echo "<div class='card'><h3>Store Dashboard</h3><p>Quick access to inventory and material requests.</p></div>";
//         break;

//     case 3:
//         echo "<div class='card'><h3>Production View</h3><p>Here you can see submitted production reports and submit new ones.</p></div>";
//         break;

//     default:
//         echo "<div class='card'><h3>General Dashboard</h3><p>Limited access view. Contact admin if you need more features.</p></div>";
// }


?>

<!-- Content -->
<section class="container-xxl flex-grow-1 container-p-y dashboard" style="font-family: var(--font-sans);">
    <header class="dashboard-header">
        <h1 class="dashboard-title"><?= htmlspecialchars($pageTitle); ?></h1>
    </header>
    <div id="dashboardAnalyser"></div>

    <div class="mb-6">
        <div class="rounded-xl p-6 shadow-sm dashboard-card mb-4" style="background-color: var(--color-primary-50); border-color: var(--color-primary-100);">
            <h3 class="text-2xl font-bold mb-2" style="color: var(--color-primary-900);">Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?> 👋</h3>
            <p class="m-0" style="color: var(--color-primary-700);">
                This is your centralized workspace for submitting and reviewing reports.
                Keep everything on track and up to date with just a few clicks.
            </p>
        </div>

        <div class="dashboard-grid">
            <article class="dashboard-card" id="widget-tasks" aria-label="Tasks widget">
                <div class="dashboard-card-icon">
                    <i class="ti ti-checkbox ti-md"></i>
                </div>
                <h2 class="dashboard-card-title">Pending Tasks</h2>
                <div class="dashboard-stat-value">12</div>
                <div class="dashboard-stat-label">Tasks awaiting your action</div>
            </article>

            <article class="dashboard-card" id="widget-reports" aria-label="Reports widget">
                <div class="dashboard-card-icon">
                    <i class="ti ti-file-analytics ti-md"></i>
                </div>
                <h2 class="dashboard-card-title">Recent Reports</h2>
                <div class="dashboard-stat-value">8 <span class="dashboard-trend positive"><i class="ti ti-arrow-up ti-xs me-1"></i> +2 this week</span></div>
                <div class="dashboard-stat-label">Submitted in the last 7 days</div>
            </article>

            <article class="dashboard-card" id="widget-activity" aria-label="Activity widget">
                <div class="dashboard-card-icon">
                    <i class="ti ti-activity ti-md"></i>
                </div>
                <h2 class="dashboard-card-title">System Health</h2>
                <div class="dashboard-stat-value">100% <span class="dashboard-trend positive"><i class="ti ti-check ti-xs me-1"></i> All good</span></div>
                <div class="dashboard-stat-label">All services operational</div>
            </article>
        </div>

        <!-- Website Analytics -->
        <div class="col-lg-6 mb-4 d-none">
            <div class="swiper-container swiper-container-horizontal swiper swiper-card-advance-bg"
                id="swiper-with-pagination-cards">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="row">
                            <div class="col-12">
                                <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                                <small>Total 28.5% Conversion Rate</small>
                            </div>
                            <div class="row">
                                <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                                    <h6 class="text-white mt-0 mt-md-3 mb-3">Traffic</h6>
                                    <div class="row">
                                        <div class="col-6">
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-flex mb-4 align-items-center">
                                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg">28%</p>
                                                    <p class="mb-0">Sessions</p>
                                                </li>
                                                <li class="d-flex align-items-center mb-2">
                                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg">1.2k</p>
                                                    <p class="mb-0">Leads</p>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-6">
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-flex mb-4 align-items-center">
                                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg">3.1k</p>
                                                    <p class="mb-0">Page Views</p>
                                                </li>
                                                <li class="d-flex align-items-center mb-2">
                                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg">12%</p>
                                                    <p class="mb-0">Conversions</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                                    <img src="<?= asset('assets/img/illustrations/card-website-analytics-1.png') ?>"
                                        alt="Website Analytics" width="170" class="card-website-analytics-img" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <div class="col-12">
                                <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                                <small>Total 28.5% Conversion Rate</small>
                            </div>
                            <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                                <h6 class="text-white mt-0 mt-md-3 mb-3">Spending</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <ul class="list-unstyled mb-0">
                                            <li class="d-flex mb-4 align-items-center">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">12h</p>
                                                <p class="mb-0">Spend</p>
                                            </li>
                                            <li class="d-flex align-items-center mb-2">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">127</p>
                                                <p class="mb-0">Order</p>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-6">
                                        <ul class="list-unstyled mb-0">
                                            <li class="d-flex mb-4 align-items-center">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">18</p>
                                                <p class="mb-0">Order Size</p>
                                            </li>
                                            <li class="d-flex align-items-center mb-2">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">2.3k</p>
                                                <p class="mb-0">Items</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                                <img src="<?= asset('assets/img/illustrations/card-website-analytics-2.png') ?>"
                                    alt="Website Analytics" width="170" class="card-website-analytics-img" />
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <div class="col-12">
                                <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                                <small>Total 28.5% Conversion Rate</small>
                            </div>
                            <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                                <h6 class="text-white mt-0 mt-md-3 mb-3">Revenue Sources</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <ul class="list-unstyled mb-0">
                                            <li class="d-flex mb-4 align-items-center">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">268</p>
                                                <p class="mb-0">Direct</p>
                                            </li>
                                            <li class="d-flex align-items-center mb-2">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">62</p>
                                                <p class="mb-0">Referral</p>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-6">
                                        <ul class="list-unstyled mb-0">
                                            <li class="d-flex mb-4 align-items-center">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">890</p>
                                                <p class="mb-0">Organic</p>
                                            </li>
                                            <li class="d-flex align-items-center mb-2">
                                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg">1.2k</p>
                                                <p class="mb-0">Campaign</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                                <img src="<?= asset('assets/img/illustrations/card-website-analytics-3.png') ?>"
                                    alt="Website Analytics" width="170" class="card-website-analytics-img" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
        <!--/ Website Analytics -->

        <!-- Sales Overview -->
        <div class="col-lg-3 col-sm-6 mb-4 d-none">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between">
                        <small class="d-block mb-1 text-muted">Sales Overview</small>
                        <p class="card-text text-success">+18.2%</p>
                    </div>
                    <h4 class="card-title mb-1">$42.5k</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <div class="d-flex gap-2 align-items-center mb-2">
                                <span class="badge bg-label-info p-1 rounded"><i
                                        class="ti ti-shopping-cart ti-xs"></i></span>
                                <p class="mb-0">Order</p>
                            </div>
                            <h5 class="mb-0 pt-1 text-nowrap">62.2%</h5>
                            <small class="text-muted">6,440</small>
                        </div>
                        <div class="col-4">
                            <div class="divider divider-vertical">
                                <div class="divider-text">
                                    <span class="badge-divider-bg bg-label-secondary">VS</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="d-flex gap-2 justify-content-end align-items-center mb-2">
                                <p class="mb-0">Visits</p>
                                <span class="badge bg-label-primary p-1 rounded"><i class="ti ti-link ti-xs"></i></span>
                            </div>
                            <h5 class="mb-0 pt-1 text-nowrap ms-lg-n3 ms-xl-0">25.5%</h5>
                            <small class="text-muted">12,749</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mt-4">
                        <div class="progress w-100 progress-sm">
                            <div class="progress-bar bg-info progress-bar-w-70" role="progressbar" aria-valuenow="70"
                                aria-valuemin="0" aria-valuemax="100"></div>
                            <div class="progress-bar bg-primary progress-bar-w-30" role="progressbar" aria-valuenow="30"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Sales Overview -->

        <!-- Revenue Generated -->
        <div class="col-lg-3 col-md-6 col-sm-6 mb-4 d-none">
            <div class="card">
                <div class="card-body pb-0">
                    <div class="card-icon">
                        <span class="badge bg-label-success rounded-pill p-2">
                            <i class="ti ti-credit-card ti-sm"></i>
                        </span>
                    </div>
                    <h5 class="card-title mb-0 mt-2">97.5k</h5>
                    <small>Revenue Generated</small>
                </div>
                <div id="revenueGenerated"></div>
            </div>
        </div>
        <!--/ Revenue Generated -->

        <!-- Earning Reports -->
        <div class="col-lg-6 mb-4 d-none">
            <div class="card h-100">
                <div class="card-header pb-0 d-flex justify-content-between mb-lg-n4">
                    <div class="card-title mb-0">
                        <h5 class="mb-0">Earning Reports</h5>
                        <small class="text-muted">Weekly Earnings Overview</small>
                    </div>
                    <div class="dropdown">
                        <button class="btn p-0" type="button" id="earningReportsId" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="earningReportsId">
                            <a class="dropdown-item" href="javascript:void(0);">View More</a>
                            <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                        </div>
                    </div>
                    <!-- </div> -->
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-4 d-flex flex-column align-self-end">
                            <div class="d-flex gap-2 align-items-center mb-2 pb-1 flex-wrap">
                                <h1 class="mb-0">$468</h1>
                                <div class="badge rounded bg-label-success">+4.2%</div>
                            </div>
                            <small>You informed of this week compared to last week</small>
                        </div>
                        <div class="col-12 col-md-8">
                            <div id="weeklyEarningReports"></div>
                        </div>
                    </div>
                    <div class="border rounded p-3 mt-4">
                        <div class="row gap-4 gap-sm-0">
                            <div class="col-12 col-sm-4">
                                <div class="d-flex gap-2 align-items-center">
                                    <div class="badge rounded bg-label-primary p-1">
                                        <i class="ti ti-currency-dollar ti-sm"></i>
                                    </div>
                                    <h6 class="mb-0">Earnings</h6>
                                </div>
                                <h4 class="my-2 pt-1">$545.69</h4>
                                <div class="progress w-75 progress-xs">
                                    <div class="progress-bar progress-bar-w-65" role="progressbar" aria-valuenow="65"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-4">
                                <div class="d-flex gap-2 align-items-center">
                                    <div class="badge rounded bg-label-info p-1"><i class="ti ti-chart-pie-2 ti-sm"></i>
                                    </div>
                                    <h6 class="mb-0">Profit</h6>
                                </div>
                                <h4 class="my-2 pt-1">$256.34</h4>
                                <div class="progress w-75 progress-xs">
                                    <div class="progress-bar bg-info progress-bar-w-50" role="progressbar"
                                        aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-4">
                                <div class="d-flex gap-2 align-items-center">
                                    <div class="badge rounded bg-label-danger p-1">
                                        <i class="ti ti-brand-paypal ti-sm"></i>
                                    </div>
                                    <h6 class="mb-0">Expense</h6>
                                </div>
                                <h4 class="my-2 pt-1">$74.19</h4>
                                <div class="progress w-75 progress-xs">
                                    <div class="progress-bar bg-danger progress-bar-w-65" role="progressbar"
                                        aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Earning Reports -->

        <!-- Support Tracker -->
        <div class="col-md-6 mb-4 d-none">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between pb-0">
                    <div class="card-title mb-0">
                        <h5 class="mb-0">Support Tracker</h5>
                        <small class="text-muted">Last 7 Days</small>
                    </div>
                    <div class="dropdown">
                        <button class="btn p-0" type="button" id="supportTrackerMenu" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="supportTrackerMenu">
                            <a class="dropdown-item" href="javascript:void(0);">View More</a>
                            <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-4 col-md-12 col-lg-4">
                            <div class="mt-lg-4 mt-lg-2 mb-lg-4 mb-2 pt-1">
                                <h1 class="mb-0">164</h1>
                                <p class="mb-0">Total Tickets</p>
                            </div>
                            <ul class="p-0 m-0">
                                <li class="d-flex gap-3 align-items-center mb-lg-3 pt-2 pb-1">
                                    <div class="badge rounded bg-label-primary p-1"><i class="ti ti-ticket ti-sm"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 text-nowrap">New Tickets</h6>
                                        <small class="text-muted">142</small>
                                    </div>
                                </li>
                                <li class="d-flex gap-3 align-items-center mb-lg-3 pb-1">
                                    <div class="badge rounded bg-label-info p-1">
                                        <i class="ti ti-circle-check ti-sm"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 text-nowrap">Open Tickets</h6>
                                        <small class="text-muted">28</small>
                                    </div>
                                </li>
                                <li class="d-flex gap-3 align-items-center pb-1">
                                    <div class="badge rounded bg-label-warning p-1"><i class="ti ti-clock ti-sm"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 text-nowrap">Response Time</h6>
                                        <small class="text-muted">1 Day</small>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-12 col-sm-8 col-md-12 col-lg-8">
                            <div id="supportTracker"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Support Tracker -->

        <!-- Sales By Country -->
        <div class="col-xl-4 col-md-6 mb-4 d-none">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between">
                    <div class="card-title mb-0">
                        <h5 class="m-0 me-2">Sales by Countries</h5>
                        <small class="text-muted">Monthly Sales Overview</small>
                    </div>
                    <div class="dropdown">
                        <button class="btn p-0" type="button" id="salesByCountry" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="salesByCountry">
                            <a class="dropdown-item" href="javascript:void(0);">Download</a>
                            <a class="dropdown-item" href="javascript:void(0);">Refresh</a>
                            <a class="dropdown-item" href="javascript:void(0);">Share</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="p-0 m-0">
                        <li class="d-flex align-items-center mb-4">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="fis fi fi-us rounded-circle fs-1"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0 me-1">$8,567k</h6>
                                    </div>
                                    <small class="text-muted">United states</small>
                                </div>
                                <div class="user-progress">
                                    <p class="text-success fw-medium mb-0 d-flex justify-content-center gap-1">
                                        <i class="ti ti-chevron-up"></i>
                                        25.8%
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="d-flex align-items-center mb-4">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="fis fi fi-br rounded-circle fs-1"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0 me-1">$2,415k</h6>
                                    </div>
                                    <small class="text-muted">Brazil</small>
                                </div>
                                <div class="user-progress">
                                    <p class="text-danger fw-medium mb-0 d-flex justify-content-center gap-1">
                                        <i class="ti ti-chevron-down"></i>
                                        6.2%
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="d-flex align-items-center mb-4">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="fis fi fi-in rounded-circle fs-1"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0 me-1">$865k</h6>
                                    </div>
                                    <small class="text-muted">India</small>
                                </div>
                                <div class="user-progress">
                                    <p class="text-success fw-medium mb-0 d-flex align-items-center gap-1">
                                        <i class="ti ti-chevron-up"></i>
                                        12.4%
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="d-flex align-items-center mb-4">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="fis fi fi-au rounded-circle fs-1"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0 me-1">$745k</h6>
                                    </div>
                                    <small class="text-muted">Australia</small>
                                </div>
                                <div class="user-progress">
                                    <p class="text-danger fw-medium mb-0 d-flex justify-content-center gap-1">
                                        <i class="ti ti-chevron-down"></i>
                                        11.9%
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="d-flex align-items-center mb-4">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="fis fi fi-us rounded-circle fs-1"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0 me-1">$45</h6>
                                    </div>
                                    <small class="text-muted">France</small>
                                </div>
                                <div class="user-progress">
                                    <p class="text-success fw-medium mb-0 d-flex justify-content-center gap-1">
                                        <i class="ti ti-chevron-up"></i>
                                        16.2%
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="d-flex align-items-center">
                            <div class="avatar flex-shrink-0 me-3">
                                <i class="fis fi fi-cn rounded-circle fs-1"></i>
                            </div>
                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                <div class="me-2">
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0 me-1">$12k</h6>
                                    </div>
                                    <small class="text-muted">China</small>
                                </div>
                                <div class="user-progress">
                                    <p class="text-success fw-medium mb-0 d-flex justify-content-center gap-1">
                                        <i class="ti ti-chevron-up"></i>
                                        14.8%
                                    </p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--/ Sales By Country -->

        <!-- Total Earning -->
        <div class="col-12 col-xl-4 mb-4 col-md-6 d-none">
            <div class="card">
                <div class="card-header d-flex justify-content-between pb-1">
                    <h5 class="mb-0 card-title">Total Earning</h5>
                    <div class="dropdown">
                        <button class="btn p-0" type="button" id="totalEarning" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="totalEarning">
                            <a class="dropdown-item" href="javascript:void(0);">View More</a>
                            <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <h1 class="mb-0 me-2">87%</h1>
                        <i class="ti ti-chevron-up text-success me-1"></i>
                        <p class="text-success mb-0">25.8%</p>
                    </div>
                    <div id="totalEarningChart"></div>
                    <div class="d-flex align-items-start my-4">
                        <div class="badge rounded bg-label-primary p-2 me-3 rounded">
                            <i class="ti ti-currency-dollar ti-sm"></i>
                        </div>
                        <div class="d-flex justify-content-between w-100 gap-2 align-items-center">
                            <div class="me-2">
                                <h6 class="mb-0">Total Sales</h6>
                                <small class="text-muted">Refund</small>
                            </div>
                            <p class="mb-0 text-success">+$98</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-start">
                        <div class="badge rounded bg-label-secondary p-2 me-3 rounded">
                            <i class="ti ti-brand-paypal ti-sm"></i>
                        </div>
                        <div class="d-flex justify-content-between w-100 gap-2 align-items-center">
                            <div class="me-2">
                                <h6 class="mb-0">Total Revenue</h6>
                                <small class="text-muted">Client Payment</small>
                            </div>
                            <p class="mb-0 text-success">+$126</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Total Earning -->

        <!-- Monthly Campaign State -->
        <div class="col-xl-4 col-md-6 mb-4 d-none">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between">
                    <div class="card-title mb-0">
                        <h5 class="mb-0">Monthly Campaign State</h5>
                        <small class="text-muted">8.52k Social Visiters</small>
                    </div>
                    <div class="dropdown">
                        <button class="btn p-0" type="button" id="MonthlyCampaign" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="MonthlyCampaign">
                            <a class="dropdown-item" href="javascript:void(0);">Refresh</a>
                            <a class="dropdown-item" href="javascript:void(0);">Download</a>
                            <a class="dropdown-item" href="javascript:void(0);">View All</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="p-0 m-0">
                        <li class="mb-4 pb-1 d-flex justify-content-between align-items-center">
                            <div class="badge bg-label-success rounded p-2"><i class="ti ti-mail ti-sm"></i></div>
                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                <h6 class="mb-0 ms-3">Emails</h6>
                                <div class="d-flex">
                                    <p class="mb-0 fw-medium">12,346</p>
                                    <p class="ms-3 text-success mb-0">0.3%</p>
                                </div>
                            </div>
                        </li>
                        <li class="mb-4 pb-1 d-flex justify-content-between align-items-center">
                            <div class="badge bg-label-info rounded p-2"><i class="ti ti-link ti-sm"></i></div>
                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                <h6 class="mb-0 ms-3">Opened</h6>
                                <div class="d-flex">
                                    <p class="mb-0 fw-medium">8,734</p>
                                    <p class="ms-3 text-success mb-0">2.1%</p>
                                </div>
                            </div>
                        </li>
                        <li class="mb-4 pb-1 d-flex justify-content-between align-items-center">
                            <div class="badge bg-label-warning rounded p-2"><i class="ti ti-click ti-sm"></i></div>
                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                <h6 class="mb-0 ms-3">Clicked</h6>
                                <div class="d-flex">
                                    <p class="mb-0 fw-medium">967</p>
                                    <p class="ms-3 text-success mb-0">1.4%</p>
                                </div>
                            </div>
                        </li>
                        <li class="mb-4 pb-1 d-flex justify-content-between align-items-center">
                            <div class="badge bg-label-primary rounded p-2"><i class="ti ti-users ti-sm"></i></div>
                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                <h6 class="mb-0 ms-3">Subscribe</h6>
                                <div class="d-flex">
                                    <p class="mb-0 fw-medium">345</p>
                                    <p class="ms-3 text-success mb-0">8.5k</p>
                                </div>
                            </div>
                        </li>
                        <li class="mb-4 pb-1 d-flex justify-content-between align-items-center">
                            <div class="badge bg-label-secondary rounded p-2">
                                <i class="ti ti-alert-triangle ti-sm text-body"></i>
                            </div>
                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                <h6 class="mb-0 ms-3">Complaints</h6>
                                <div class="d-flex">
                                    <p class="mb-0 fw-medium">10</p>
                                    <p class="ms-3 text-success mb-0">1.5%</p>
                                </div>
                            </div>
                        </li>
                        <li class="d-flex justify-content-between align-items-center">
                            <div class="badge bg-label-danger rounded p-2"><i class="ti ti-ban ti-sm"></i></div>
                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                <h6 class="mb-0 ms-3">Unsubscribe</h6>
                                <div class="d-flex">
                                    <p class="mb-0 fw-medium">86</p>
                                    <p class="ms-3 text-success mb-0">0.8%</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--/ Monthly Campaign State -->

        <!-- Source Visit -->
        <div class="col-xl-4 col-md-6 order-2 order-lg-1 mb-4 d-none">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="card-title mb-0">
                        <h5 class="mb-0">Source Visits</h5>
                        <small class="text-muted">38.4k Visitors</small>
                    </div>
                    <div class="dropdown">
                        <button class="btn p-0" type="button" id="sourceVisits" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="sourceVisits">
                            <a class="dropdown-item" href="javascript:void(0);">Refresh</a>
                            <a class="dropdown-item" href="javascript:void(0);">Download</a>
                            <a class="dropdown-item" href="javascript:void(0);">View All</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-3 pb-1">
                            <div class="d-flex align-items-start">
                                <div class="badge bg-label-secondary p-2 me-3 rounded">
                                    <i class="ti ti-shadow ti-sm"></i>
                                </div>
                                <div class="d-flex justify-content-between w-100 flex-wrap gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Direct Source</h6>
                                        <small class="text-muted">Direct link click</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0">1.2k</p>
                                        <div class="ms-3 badge bg-label-success">+4.2%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="mb-3 pb-1">
                            <div class="d-flex align-items-start">
                                <div class="badge bg-label-secondary p-2 me-3 rounded">
                                    <i class="ti ti-globe ti-sm"></i>
                                </div>
                                <div class="d-flex justify-content-between w-100 flex-wrap gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Social Network</h6>
                                        <small class="text-muted">Social Channels</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0">31.5k</p>
                                        <div class="ms-3 badge bg-label-success">+8.2%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="mb-3 pb-1">
                            <div class="d-flex align-items-start">
                                <div class="badge bg-label-secondary p-2 me-3 rounded">
                                    <i class="ti ti-mail ti-sm"></i>
                                </div>
                                <div class="d-flex justify-content-between w-100 flex-wrap gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Email Newsletter</h6>
                                        <small class="text-muted">Mail Campaigns</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0">893</p>
                                        <div class="ms-3 badge bg-label-success">+2.4%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="mb-3 pb-1">
                            <div class="d-flex align-items-start">
                                <div class="badge bg-label-secondary p-2 me-3 rounded">
                                    <i class="ti ti-external-link ti-sm"></i>
                                </div>
                                <div class="d-flex justify-content-between w-100 flex-wrap gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Referrals</h6>
                                        <small class="text-muted">Impact Radius Visits</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0">342</p>
                                        <div class="ms-3 badge bg-label-danger">-0.4%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="mb-3 pb-1">
                            <div class="d-flex align-items-start">
                                <div class="badge bg-label-secondary p-2 me-3 rounded">
                                    <i class="ti ti-discount-2 ti-sm"></i>
                                </div>
                                <div class="d-flex justify-content-between w-100 flex-wrap gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">ADVT</h6>
                                        <small class="text-muted">Google ADVT</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0">2.15k</p>
                                        <div class="ms-3 badge bg-label-success">+9.1%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="mb-2">
                            <div class="d-flex align-items-start">
                                <div class="badge bg-label-secondary p-2 me-3 rounded">
                                    <i class="ti ti-star ti-sm"></i>
                                </div>
                                <div class="d-flex justify-content-between w-100 flex-wrap gap-2">
                                    <div class="me-2">
                                        <h6 class="mb-0">Other</h6>
                                        <small class="text-muted">Many Sources</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0">12.5k</p>
                                        <div class="ms-3 badge bg-label-success">+6.2%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--/ Source Visit -->

        <!-- Projects table -->
        <div class="col-12 col-xl-8 col-sm-12 order-1 order-lg-2 mb-4 mb-lg-0 d-none">
            <div class="card">
                <div class="card-datatable table-responsive">
                    <table class="datatables-projects table border-top">
                        <thead
                            class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                            <tr>
                                <th class="border-b border-slate-200 px-6 py-3"></th>
                                <th class="border-b border-slate-200 px-6 py-3"></th>
                                <th class="border-b border-slate-200 px-6 py-3">Name</th>
                                <th class="border-b border-slate-200 px-6 py-3">Leader</th>
                                <th class="border-b border-slate-200 px-6 py-3">Team</th>
                                <th class="border-b border-slate-200 px-6 py-3 w-px-200">Status</th>
                                <th class="border-b border-slate-200 px-6 py-3">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <!--/ Projects table -->


    </div>
    <div id="productionDashboard" class="mb-4 d-none" style="width: 80%; margin-left: 15px;"></div>
</section>
<!-- / Content -->
<?php startSection('scripts'); ?>
<script>
    function loadDashboardData() {
        $("#dashboardAnalyser").html('');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDashboardData: 'getDashboardData'
            },
            success: function (response) {
                $("#dashboardAnalyser").html(response);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load data:", error);
            }
        });
    }

    function loadDashboardProduction() {

        $.post('dashboardajax.php', { loadDashboardProduction: 1 }, function (res) {
            let html = '';

            res.data.forEach(prod => {
                const titleText = prod.production_plan_title ? `: ${prod.production_plan_title}` : `#${prod.production_id}`;

                html += `
                    <article class="dashboard-card mb-6">
                        <h2 class="dashboard-card-title mb-4">
                            <i class="ti ti-box"></i> Production Plan ${titleText}
                        </h2>
                        <div class="d-flex align-items-center overflow-auto pb-4 pt-2 px-2" style="scrollbar-width: thin;">
                    `;

                html += `
                            <div class="d-flex flex-column align-items-center position-relative group" style="cursor: pointer; min-width: 80px;">
                                <div class="d-flex align-items-center justify-content-center rounded-circle shadow-sm transition-all" style="height: 3rem; width: 3rem; background-color: var(--color-primary-50); color: var(--color-primary-600); border: 1px solid var(--color-primary-100);">
                                    <i class="ti ti-player-play fs-4"></i>
                                </div>
                                <div class="position-absolute bg-white rounded shadow-sm border p-2 text-muted fw-bold" style="top: 3.5rem; font-size: 0.75rem; opacity: 0; pointer-events: none; transition: 0.2s; z-index: 10;">Start</div>
                            </div>
                            <div class="flex-shrink-0 mx-2 rounded-pill" style="height: 0.25rem; width: 3rem; background-color: var(--color-primary-100);"></div>
                    `;

                const colorMap = {
                    'primary': 'var(--color-primary-600)',
                    'secondary': '#64748b',
                    'success': '#22c55e',
                    'danger': '#ef4444',
                    'warning': '#f59e0b',
                    'info': '#0ea5e9',
                    'dark': '#334155'
                };

                prod.steps.forEach((step, index) => {
                    const iconColor = colorMap[step.color] || '#64748b';
                    const bgColor = step.color === 'primary' ? 'var(--color-primary-50)' : '#f8fafc';

                    html += `
                            <div class="d-flex flex-column align-items-center position-relative group" style="cursor: pointer; min-width: 80px;" onmouseenter="this.querySelector('.timeline-tooltip').style.opacity='1'" onmouseleave="this.querySelector('.timeline-tooltip').style.opacity='0'">
                                <div class="d-flex align-items-center justify-content-center rounded-circle shadow-sm position-relative transition-all" style="height: 3rem; width: 3rem; background-color: ${bgColor}; color: ${iconColor}; border: 1px solid ${iconColor};">
                                    <i class="${step.icon} fs-4"></i>
                                    <div class="position-absolute d-flex align-items-center justify-content-center rounded-circle text-white fw-bold shadow-sm" style="top: -0.25rem; right: -0.25rem; height: 1.25rem; width: 1.25rem; background-color: ${iconColor}; font-size: 0.65rem; border: 2px solid #fff;">
                                        ${index + 1}
                                    </div>
                                </div>
                                <div class="timeline-tooltip position-absolute bg-white p-3 rounded shadow border" style="top: 3.5rem; opacity: 0; transition: 0.2s; z-index: 10; min-width: 180px; pointer-events: none;">
                                    <div class="fw-bold mb-1 border-bottom pb-1" style="color: var(--color-primary-900);">${step.action}</div>
                                    ${step.remarks ? `<div class="text-muted mb-2 fst-italic" style="font-size: 0.7rem; white-space: normal; max-width: 200px; line-height: 1.2;">${step.remarks}</div>` : ''}
                                    <div class="d-flex flex-column gap-1 mt-1">
                                        <div class="d-flex align-items-center gap-1 text-muted fw-medium" style="font-size: 0.75rem;">
                                            <i class="ti ti-user"></i> ${step.user}
                                        </div>
                                        <div class="d-flex align-items-center gap-1 text-muted" style="font-size: 0.75rem;">
                                            <i class="ti ti-clock"></i> ${step.time}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex-shrink-0 mx-2 rounded-pill" style="height: 0.25rem; width: 4rem; background-color: ${iconColor}; opacity: 0.2;"></div>
                        `;
                });

                html += `
                            <div class="d-flex flex-column align-items-center position-relative group" style="cursor: pointer; min-width: 80px;">
                                <div class="d-flex align-items-center justify-content-center rounded-circle shadow-sm transition-all" style="height: 3rem; width: 3rem; background-color: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;">
                                    <i class="ti ti-player-stop fs-4"></i>
                                </div>
                                <div class="position-absolute bg-white rounded shadow-sm border p-2 text-muted fw-bold" style="top: 3.5rem; font-size: 0.75rem; opacity: 0; pointer-events: none; transition: 0.2s; z-index: 10;">End</div>
                            </div>
                        </div>
                    </article>
                    `;
            });
            $('#productionDashboard').html(html);

        }, 'json');
    }


    $(document).ready(function () {
        loadDashboardData();
        // loadDashboardProduction();
    });
</script>
<?php endSection(); ?>