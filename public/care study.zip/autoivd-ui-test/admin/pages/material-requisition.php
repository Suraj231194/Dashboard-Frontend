<style>
.swal2-container {
    z-index: 2000 !important;
}
#matReqSubmitBtn:disabled,
#matReqSubmitBtn[disabled] {
    opacity: 0.35 !important;
    cursor: not-allowed !important;
    pointer-events: none !important;
    background-color: #94a3b8 !important;
    border-color: #94a3b8 !important;
    color: #f1f5f9 !important;
    box-shadow: none !important;
    filter: grayscale(100%) !important;
}
/* BOM Modal Req. Qty input formatting & spinner suppression */
#viewBomModal .bom-input-wrap {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    width: 140px !important;
    min-width: 130px !important;
    max-width: 150px !important;
    height: 36px !important;
    border-radius: 8px !important;
    box-sizing: border-box !important;
    padding: 0 8px !important;
    background: #ffffff !important;
}
#viewBomModal .bomReqQtyInput {
    flex: 1 1 0% !important;
    min-width: 0 !important;
    width: 100% !important;
    height: 100% !important;
    border: none !important;
    outline: none !important;
    background: transparent !important;
    padding: 0 4px 0 0 !important;
    margin: 0 !important;
    text-align: right !important;
    font-weight: 700 !important;
    font-size: 13px !important;
    color: #1e293b !important;
    box-shadow: none !important;
    -moz-appearance: textfield !important;
    -webkit-appearance: none !important;
    appearance: textfield !important;
}
#viewBomModal .bomReqQtyInput::-webkit-outer-spin-button,
#viewBomModal .bomReqQtyInput::-webkit-inner-spin-button {
    -webkit-appearance: none !important;
    appearance: none !important;
    margin: 0 !important;
    display: none !important;
}
#viewBomModal .bom-unit-badge {
    flex-shrink: 0 !important;
    font-size: 11px !important;
    font-weight: 600 !important;
    color: #64748b !important;
    padding-left: 4px !important;
    user-select: none !important;
    white-space: nowrap !important;
}
</style>

<div class="container-xxl flex-grow-1 container-p-y font-sans">


    <!-- ═══════════════════════ MATERIAL REQUISITION TABLE ═══════════════════════ -->
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage material requisition requests and track item allocations</p>
        </div>
    </div>

    <!-- New Production Plan Widget -->
    <div id="newProductionPlanWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" role="button" tabindex="0"
        aria-controls="newProductionPlanModal">
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
            style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div
                    style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                    <i class="ti ti-clipboard-list"
                        style="font-size: 1.5rem; color: var(--appearance-accent, #7e22ce);"></i>
                    <span
                        style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight"
                            style="font-size: 1.125rem; color: var(--ui-text, #1e293b); margin: 0;">New Production Plan!
                        </h3>
                        <span id="newProductionPlanCount" aria-live="polite"
                            style="display: flex; align-items: center; justify-content: center; min-width: 1.25rem; height: 1.25rem; padding: 0 0.3rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px;">0</span>
                    </div>
                    <p class="font-medium mt-1 mb-0" style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">
                        Pending production plans, including items sent from Order Management.
                    </p>
                </div>
            </div>
            <div style="color: var(--ui-text-muted, #94a3b8);">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown for material requisition table -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="mrPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100">100 items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="1000">1000 items</a></li>
                            <li><a class="mr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Date</th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Auto Batch No</th>
                            <th
                                class="w-80 min-w-[300px] px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Product Name</th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                LOT/Batch No</th>
                            <th class="w-24 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Batch Size</th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Requested By</th>
                            <th class="w-24 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Store's Status</th>
                            <th
                                class="w-40 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="productsTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect+.dropdown {
                    display: none !important;
                }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- ═══════════════════════ ADD MATERIAL REQUISITION MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="addMaterialRquisitionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Requisition</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create new material requisition entry</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addMaterialRequisitionForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">

                        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 mb-4">
                            <!-- Requisition For -->
                            <div class="md:col-span-5">
                                <label class="mb-1 block text-sm font-medium text-slate-800">
                                    Requisition For <strong class="text-rose-500">*</strong>
                                </label>
                                <div class="flex flex-row items-center gap-3 md:gap-4 mt-1">
                                    <label
                                        class="flex cursor-pointer items-center gap-1.5 text-sm font-medium text-slate-700 whitespace-nowrap">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600 requisition-checkbox"
                                            type="checkbox" id="mrRaw" name="mrForRaw" value="1" />
                                        Raw Material
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-1.5 text-sm font-medium text-slate-700 whitespace-nowrap">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600 requisition-checkbox"
                                            type="checkbox" id="mrPacking" name="mrForPacking" value="1" />
                                        Packing Material
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-1.5 text-sm font-medium text-slate-700 whitespace-nowrap">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600 requisition-checkbox"
                                            type="checkbox" id="mrConsumable" name="mrForConsumable" value="1" />
                                        Consumables
                                    </label>
                                </div>
                            </div>

                            <!-- Date -->
                            <div class="md:col-span-3">
                                <label for="mrDate" class="mb-1 block text-sm font-medium text-slate-800">Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="mrDate" autocomplete="off" name="mrDate" class="input-theme"
                                    value="<?php echo date('Y-m-d'); ?>" placeholder="Enter Date" required />
                            </div>
                            <!-- Product Name -->
                            <div class="md:col-span-4">
                                <label for="mrProductName" class="mb-1 block text-sm font-medium text-slate-800">Product
                                    Name <strong class="text-rose-500">*</strong></label>
                                <input type="hidden" id="mrProdPlanId" name="mrProdPlanId" value="" />
                                <input type="hidden" id="mrProdBomId" name="mrProdBomId" value="" />
                                <input type="text" id="mrProductName" autocomplete="off" name="mrProductName"
                                    class="input-theme bg-slate-100 hidden" placeholder="Selected from BOM" readonly />
                                <select id="mrFinishedProductSelect" class="input-theme select2"
                                    style="width:100%;"></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="mrBatchNumber" class="mb-1 block text-sm font-medium text-slate-800">Lot
                                    No./Batch No. <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="mrBatchNumber" autocomplete="off" name="mrBatchNumber"
                                    class="input-theme" placeholder="Enter Lot No./Batch No." required />
                            </div>
                            <div>
                                <label for="mrBatchSize" class="mb-1 block text-sm font-medium text-slate-800">Batch
                                    Size <strong class="text-rose-500">*</strong></label>
                                <input type="number" min="0.00000001" step="any" id="mrBatchSize" autocomplete="off"
                                    name="mrBatchSize" class="input-theme" placeholder="Enter Batch Size" required />
                            </div>
                            <div>
                                <label for="mrBatchSizeUnit" class="mb-1 block text-sm font-medium text-slate-800">Batch
                                    Size Unit <strong class="text-rose-500">*</strong></label>
                                <select id="mrBatchSizeUnit" name="mrBatchSizeUnit" class="input-theme select2"
                                    placeholder="Enter Batch Size" required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="mrSlipNo" class="mb-1 block text-sm font-medium text-slate-800">Slip
                                    No.</label>
                                <input type="text" id="mrSlipNo" autocomplete="off" name="mrSlipNo" class="input-theme"
                                    placeholder="Enter Slip No." />
                            </div>
                            <div>
                                <label for="mrDepartment"
                                    class="mb-1 block text-sm font-medium text-slate-800">Department <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="mrDepartment" name="mrDepartment" class="input-theme select2"
                                    required></select>
                            </div>
                            <div>
                                <label for="mrRequestedBy"
                                    class="mb-1 block text-sm font-medium text-slate-800">Requested By <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="mrRequestedBy" autocomplete="off" name="mrRequestedBy"
                                    class="input-theme" placeholder="Enter Requested By" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 mb-4" id="mrBomFilterWrapper"></div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Material Lines</label>
                            <div id="mrProductsWrapper"></div>
                            <div class="mt-2 hidden" aria-hidden="true">
                                <button type="button"
                                    class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addMrProducts"><i class="ti ti-plus text-lg"></i> Add Product</button>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="matReqSubmitBtn"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <!-- ═══════════════════════ VIEW MATERIAL REQUISITION MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="viewMatRequiModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View Material Requisition
                                Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review requisition information</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="viewMatRequi">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ EDIT MATERIAL REQUISITION MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="editMatRequiModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Material Requisition
                                Request</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update requisition details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editMatRequiForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ EDIT QTY FINAL MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="materialRequisitionEditQtyFinalModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Material Requisition
                                Request</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update final quantities</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="materialRequisitionEditQtyFinalForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ MATERIAL REQUISITION PDF PREVIEW MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="materialRequisitionViewPdfModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-file-download text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Material Requisition Preview
                            </h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview export content before download</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="materialRequisitionViewPdf">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ OFFCANVAS: PRODUCTION PLAN HISTORY ═══════════════════════ -->
    <div class="col-lg-6 col-md-6">
        <div class="mt-3">
            <div class="offcanvas offcanvas-end" tabindex="-1" id="productionPlanHistoryView">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title">Production Plan History</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                </div>
                <div class="offcanvas-body">
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ VIEW COMPLETE PRODUCTION PLAN MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="completeProductionPlanViewModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View Production Plan Details
                            </h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review complete production plan
                                information</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="completeProductionPlanViewForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ DYNAMIC DOCUMENT VIEW MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="dynamicDocumentViewModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-file text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Document Preview</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview document details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="dynamicDocumentView">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════ ADD TRANSFER TICKET MODAL ═══════════════════════ -->
    <div class="modal fade animate__animated fadeIn" id="addTransferTicketModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Transfer Ticket</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a transfer ticket record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addTransferTicketForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="transferTicketNo"
                                    class="mb-1 block text-sm font-medium text-slate-800">Transfer Ticket Number <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="transferTicketNo" autocomplete="off" name="transferTicketNo"
                                    class="input-theme" placeholder="Enter Transfer Ticket Number" required />
                                <input type="hidden" name="prod_plan_id" id="prodPlanId" value="" />
                            </div>
                            <div>
                                <label for="finishedGoodCoaNo"
                                    class="mb-1 block text-sm font-medium text-slate-800">Finished Good COA No <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="finishedGoodCoaNo" autocomplete="off" name="finishedGoodCoaNo"
                                    class="input-theme" placeholder="Enter Finished Good COA No" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="code" class="mb-1 block text-sm font-medium text-slate-800">Code <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="code" autocomplete="off" name="code" class="input-theme"
                                    placeholder="Enter Code" required />
                            </div>
                            <div>
                                <label for="transferTicketDate"
                                    class="mb-1 block text-sm font-medium text-slate-800">Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="transferTicketDate" autocomplete="off" name="transferTicketDate"
                                    class="input-theme" placeholder="Enter Date" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 gap-3 mb-4">
                            <div>
                                <label for="productDescription"
                                    class="mb-1 block text-sm font-medium text-slate-800">Product Description <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="productDescription" autocomplete="off" name="productDescription"
                                    class="input-theme" placeholder="Enter Product Description" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="pack_size" class="mb-1 block text-sm font-medium text-slate-800">Pack Size
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="number" min="0" id="pack_size" autocomplete="off" name="pack_size"
                                    class="input-theme" placeholder="Enter Pack Size" required />
                            </div>
                            <div>
                                <label for="pack_size_unit" class="mb-1 block text-sm font-medium text-slate-800">Pack
                                    Size Unit <strong class="text-rose-500">*</strong></label>
                                <select name="pack_size_unit" id="pack_size_unit" class="input-theme select2"
                                    required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="productCode" class="mb-1 block text-sm font-medium text-slate-800">Product
                                    Code <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="productCode" autocomplete="off" name="productCode"
                                    class="input-theme" placeholder="Enter Product Code" required />
                            </div>
                            <div>
                                <label for="batchNumber" class="mb-1 block text-sm font-medium text-slate-800">Batch
                                    Number <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="batchNumber" autocomplete="off" name="batchNumber"
                                    class="input-theme" placeholder="Enter Batch Number" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="transferTicketMfgDate"
                                    class="mb-1 block text-sm font-medium text-slate-800">Mfg Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="transferTicketMfgDate" autocomplete="off"
                                    name="transferTicketMfgDate" class="input-theme" placeholder="Enter Mfg Date"
                                    required />
                            </div>
                            <div>
                                <label for="transferTicketExpDate"
                                    class="mb-1 block text-sm font-medium text-slate-800">Exp Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" id="transferTicketExpDate" autocomplete="off"
                                    name="transferTicketExpDate" class="input-theme" placeholder="Enter Exp Date"
                                    required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="sampleTakenByQa"
                                    class="mb-1 block text-sm font-medium text-slate-800">Sample Taken By QA <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="number" min="0" id="sampleTakenByQa" autocomplete="off"
                                    name="sampleTakenByQa" class="input-theme" placeholder="Enter Sample Taken By QA"
                                    required />
                            </div>
                            <div>
                                <label for="sampleTakenByQaUnit"
                                    class="mb-1 block text-sm font-medium text-slate-800">Sample Unit <strong
                                        class="text-rose-500">*</strong></label>
                                <select name="sampleTakenByQaUnit" id="sampleTakenByQaUnit" class="input-theme select2"
                                    required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="quantityTransferred"
                                    class="mb-1 block text-sm font-medium text-slate-800">Quantity Tranferred <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="number" min="0" id="quantityTransferred" autocomplete="off"
                                    name="quantityTransferred" class="input-theme"
                                    placeholder="Enter Quantity Tranferred" required />
                            </div>
                            <div>
                                <label for="quantityUnit" class="mb-1 block text-sm font-medium text-slate-800">Quantity
                                    Unit <strong class="text-rose-500">*</strong></label>
                                <select name="quantityUnit" id="quantityUnit" class="input-theme select2"
                                    required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label for="ttRemark"
                                    class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea name="ttRemark" id="ttRemark" class="input-theme min-h-[80px]"
                                    placeholder="Enter Remark"></textarea>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            type="radio" id="activStatus" name="productStatus" value="1" required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input
                                            class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            type="radio" id="inactiveStatus" name="productStatus" value="0" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div>

<?php startSection('scripts'); ?>
<script>
    let currentPageProdPlan = 1;
    let currentPage = 1;
    let productIndex = 1;
    let qtyUnitOptions = [];
    let qtyUnitRequest = null;
    function loadProductionPlanTable(page = 1) {
        // The legacy Production Plan grid is no longer rendered on this page.
        // Guard its loader so it cannot stop the Material Requisition controls
        // from initializing when those legacy elements are absent.
        if (!$('#productionPlanTableBody').length || !$('#searchProdPlan').length || !$('#perPageSelectProdPlan').length) {
            return;
        }

        currentPageProdPlan = page;
        const search = $('#searchProdPlan').val().trim();
        const perPage = $('#perPageSelectProdPlan').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProductionPlanWithMatRequi: 'loadProductionPlanWithMatRequi',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#productionPlanTableBody').html(response.table || '');
                $('#paginationWrapperpProductionPlan').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummarypProductionPlan', response.totalRows, typeof currentPageProdPlan !== 'undefined' ? currentPageProdPlan : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectpProductionPlan');
            },
            error: function () {
                $('#productionPlanTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapperpProductionPlan').html('');
                $('#paginationSummaryProdPlan').text('Showing 0 results');
            }
        });
    }

    function getQtyUnitOptionsHtml() {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });
        return optionsHtml;
    }

    function ensureStandardUnitsLoaded() {
        if (qtyUnitOptions.length) {
            const deferred = $.Deferred();
            deferred.resolve(qtyUnitOptions);
            return deferred.promise();
        }
        if (qtyUnitRequest) {
            return qtyUnitRequest;
        }
        qtyUnitRequest = $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            }
        }).done(function (response) {
            qtyUnitOptions = Array.isArray(response) ? response : [];
        }).fail(function (xhr, status, error) {
            console.error("Failed to load qty units:", error);
        }).always(function () {
            qtyUnitRequest = null;
        });
        return qtyUnitRequest;
    }

    function initMaterialRequisitionSelect2($element, options = {}) {
        $element.select2($.extend({
            dropdownParent: $('#addMaterialRquisitionModal')
        }, options));
    }

    function populateMrBatchSizeUnit(selectedValue = '') {
        const $select = $('#mrBatchSizeUnit');
        if ($select.hasClass('select2-hidden-accessible')) {
            $select.select2('destroy');
        }
        $select.html(getQtyUnitOptionsHtml());
        initMaterialRequisitionSelect2($select);
        if (selectedValue !== '' && selectedValue !== undefined && selectedValue !== null) {
            $select.val(String(selectedValue)).trigger('change');
        }
    }

    function loadStandardUnit() {
        return ensureStandardUnitsLoaded()
            .done(function () {
                const optionsHtml = getQtyUnitOptionsHtml();
                $("#productUnit").html(optionsHtml);
                $("#pack_size_unit").html(optionsHtml);
                $("#sampleTakenByQaUnit").html(optionsHtml);
                $("#quantityUnit").html(optionsHtml);
            })
            .fail(function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            });
    }

    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function (response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                departmentOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#mrDepartment").html(optionsHtml).select2({
                    dropdownParent: $('#addMaterialRquisitionModal'),
                    minimumResultsForSearch: Infinity
                });
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadMaterialRequisitionTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadMaterialRequisition: 'loadMaterialRequisition',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#productsTableBody').html(response.table);
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function () {
                $('#productsTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    function updateItemNumbers() {
        $('#mrProductsWrapper .product-row').each(function (index) {
            $(this).attr('data-index', index + 1);
            $(this).find('.item-number-label').text('Item ' + (index + 1));
        });
        productIndex = $('#mrProductsWrapper .product-row').length + 1;
    }

    function updateItemNumbersEdit() {
        $('#templateParametersEdit .product-row').each(function (index) {
            $(this).attr('data-index', index + 1);
            $(this).find('.item-number-label').text('Item ' + (index + 1));
        });
        productIndex = $('#templateParametersEdit .product-row').length + 1;
    }

    function bindMaterialRequisitionSelect2Scroll() {
        setTimeout(function () {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.materialRequisitionModalScroll')
                .on('wheel.materialRequisitionModalScroll', function (e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $('#addMaterialRquisitionModal .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $('#addMaterialRquisitionModal .select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    function openMaterialLineUnitDropdownAbove($select) {
        window.setTimeout(function () {
            const select2 = $select.data('select2');
            const $selectionContainer = select2 && select2.$container;
            const $dropdownContainer = $('.select2-container--open')
                .filter(function () {
                    return $(this).find('.select2-dropdown').length > 0;
                })
                .last();

            if (!$selectionContainer || !$selectionContainer.length || !$dropdownContainer.length) return;

            const currentTop = parseFloat($dropdownContainer.css('top')) || 0;
            const dropdownHeight = $dropdownContainer.outerHeight() || 0;
            const selectionHeight = $selectionContainer.outerHeight() || 0;

            $dropdownContainer.css('top', Math.max(0, currentTop - dropdownHeight - selectionHeight - 8) + 'px');
            $dropdownContainer
                .find('.select2-dropdown')
                .removeClass('select2-dropdown--below')
                .addClass('select2-dropdown--above material-line-unit-dropdown-above');
        }, 0);
    }

    function viewDynamicDocument(dataId, type) {
        if (dataId != '' && type != '') {
            $('#dynamicDocumentViewModel').find('modal-body').html();
            if (type == 'mr') {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: { materialRequisionViewPdfRecord: 'materialRequisionViewPdfRecord', id: dataId },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            $('#dynamicDocumentViewModel').modal('show');
                            $('#dynamicDocumentView').find('.modal-body').html(res.data);
                        } else if (res.status === 'error') {
                            toastr.error(res.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                    },
                    error: function () {
                        toastr.error('Server error occurred.');
                    }
                });
            }
            if (type == 'tt') {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: { transferTicketViewPdfRecord: 'transferTicketViewPdfRecord', id: dataId },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            $('#dynamicDocumentViewModel').modal('show');
                            $('#dynamicDocumentView').find('.modal-body').html(res.data);
                        } else if (res.status === 'error') {
                            toastr.error(res.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                    },
                    error: function () {
                        toastr.error('Server error occurred.');
                    }
                });
            }


        }
    }

    $(document).ready(function () {
        loadMaterialRequisitionTable();
        loadProductionPlanTable();
        loadStandardUnit();
        loadDepartmentsList();
        $(document).on('select2:open', function (e) {
            if (!$(e.target).closest('#addMaterialRquisitionModal').length) return;
            bindMaterialRequisitionSelect2Scroll();
            if ($(e.target).attr('name') === 'ProductItemquantityUnit[]') {
                openMaterialLineUnitDropdownAbove($(e.target));
            }
        });
        $('#addMaterialRquisitionModal .modal-body').on('scroll', function () {
            $('#addMaterialRquisitionModal .select2-hidden-accessible').select2('close');
        });
        $(document).on('input keyup search', '#searchProducts', function () {
            loadMaterialRequisitionTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadMaterialRequisitionTable(1);
        });
        $(document).on('change', '#footerPerPageSelect', function () {
            $('#perPageSelect').val($(this).val());
            loadMaterialRequisitionTable(1);
        });

        // Top-strip per-page dropdown handler (material requisition table)
        $(document).on('click', '.mr-per-page-item', function (e) {
            e.preventDefault();
            const val = $(this).attr('data-val') || $(this).data('val');
            const label = $.trim($(this).text());
            $('#mrPerPageText').text(label);
            $('#perPageSelect').val(val);
            if ($('#footerPerPageSelect').length) {
                $('#footerPerPageSelect').val(val);
            }
            loadMaterialRequisitionTable(1);
        });

        $('#perPageSelectProdPlan').on('change', function () {
            loadProductionPlanTable(1);
        });
        $(document).on('change', '#footerPerPageSelectpProductionPlan', function () {
            $('#perPageSelectProdPlan').val($(this).val());
            loadProductionPlanTable(1);
        });

        // Top-strip per-page dropdown handler (production plan table)
        $(document).on('click', '.mrpp-per-page-item', function (e) {
            e.preventDefault();
            const val = $(this).attr('data-val') || $(this).data('val');
            const label = $.trim($(this).text());
            $('#mrppPerPageText').text(label);
            $('#perPageSelectProdPlan').val(val);
            if ($('#footerPerPageSelectpProductionPlan').length) {
                $('#footerPerPageSelectpProductionPlan').val(val);
            }
            loadProductionPlanTable(1);
        });
        $(document).on('input keyup search', '#searchProdPlan', function () {
            loadProductionPlanTable(1);
        });

        function initMrFinishedProductSelect() {
            $('#mrFinishedProductSelect').select2({
                dropdownParent: $('#addMaterialRquisitionModal'),
                width: '100%',
                placeholder: 'Search finished product...',
                minimumInputLength: 0,
                ajax: {
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    delay: 200,
                    data: params => ({ getFinishedProductsWithBom: '1', term: params.term || '' }),
                    processResults: response => ({ results: Array.isArray(response.results) ? response.results : [] })
                }
            });
        }

        window._lastMatReqBomData = null;

        window.openCloneBomForCurrentProduct = function(productId, productName) {
            productId = productId || Number($('#mrFinishedProductSelect').val() || 0);
            let pName = productName;
            if (!pName) {
                const selectEl = $('#mrFinishedProductSelect');
                if (selectEl.length && selectEl.data('select2')) {
                    const data = selectEl.select2('data');
                    if (data && data[0]) {
                        pName = data[0].product_name || data[0].text;
                    }
                }
                if (!pName) {
                    pName = $('#mrProductName').val() || 'Selected product';
                }
            }

            const res = window._lastMatReqBomData || {};
            const refs = res.reference_boms || null;

            const launchClone = function() {
                if (typeof window.openCloneBomModal === 'function') {
                    window.openCloneBomModal(productId, pName, refs, function (newBomRes) {
                        toastr.info('BOM submitted for approval. Once approved, you can generate this material requisition.');
                    });
                } else if (typeof openCloneBomModal === 'function') {
                    openCloneBomModal(productId, pName, refs, function (newBomRes) {
                        toastr.info('BOM submitted for approval. Once approved, you can generate this material requisition.');
                    });
                }
            };

            const $mrModal = $('#addMaterialRquisitionModal');
            if ($mrModal.length && $mrModal.hasClass('show')) {
                $mrModal.one('hidden.bs.modal', function () {
                    $('.modal-backdrop').remove();
                    $('body').removeClass('modal-open');
                    setTimeout(launchClone, 50);
                });
                $mrModal.modal('hide');
            } else {
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open');
                launchClone();
            }
        };

        window.transitionToCloneBomModal = window.openCloneBomForCurrentProduct;

        // Delegated click handler for the inline Create / Clone BOM button
        $(document).off('click', '#mrCreateCloneBomInlineBtn, .btn-trigger-clone-bom').on('click', '#mrCreateCloneBomInlineBtn, .btn-trigger-clone-bom', function (e) {
            e.preventDefault();
            e.stopPropagation();
            window.openCloneBomForCurrentProduct();
        });

        function loadBomForManualMr() {
            const productId = Number($('#mrFinishedProductSelect').val() || 0);
            let batchSize = Number($('#mrBatchSize').val() || 0);
            if (!productId) {
                return;
            }
            if (batchSize <= 0) {
                batchSize = 1;
            }

            const selectedData = $('#mrFinishedProductSelect').select2('data')[0];
            const productName = selectedData ? (selectedData.product_name || selectedData.text) : '';
            $('#mrProductName').val(productName);

            $('#mrProductsWrapper').html('<div class="p-4 text-center text-slate-500"><i class="ti ti-loader-2 animate-spin me-2"></i> Loading BOM components...</div>');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    getFinishedProductBomForMatReq: '1',
                    productId: productId,
                    batchSize: batchSize
                },
                success: function (res) {
                    window._lastMatReqBomData = res;
                    if (res.status === 'no_bom' || (res.status === 'error' && (!res.items || res.items.length === 0)) || !res.items || res.items.length === 0) {
                        $('#mrProdBomId').val('');
                        // Disable submit button completely for products without approved BOM
                        $('#matReqSubmitBtn').prop('disabled', true).attr('disabled', 'disabled');

                        const pName = productName || (res.product ? res.product.product_name : 'Selected product');
                        const isPending = (res.existing_bom_status === 'PENDING_APPROVAL');
                        const cleanPName = escapeNewProductionPlanText(pName);
                        const confirmBtn = isPending ? '<i class="ti ti-edit me-1"></i> Edit Pending BOM' : '<i class="ti ti-copy me-1"></i> Create / Clone BOM';

                        $('#mrProductsWrapper').html(`
                            <div class="rounded-2xl border border-amber-300 bg-amber-50/80 p-5 text-center my-2">
                                <div class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 ring-1 ring-amber-200 mb-2">
                                    <i class="ti ti-ban text-2xl"></i>
                                </div>
                                <h6 class="text-sm font-bold text-amber-950 mb-1">Approved BOM Required</h6>
                                <p class="text-xs text-amber-800 max-w-md mx-auto mb-3">
                                    Material Requisition cannot be created for <strong>${cleanPName}</strong> because it does not have an approved BOM.
                                    ${isPending ? 'A formulation has been submitted and is awaiting management approval.' : 'A BOM must be created and approved before requisitioning materials.'}
                                </p>
                                <button type="button" id="mrCreateCloneBomInlineBtn" class="btn btn-sm btn-primary inline-flex items-center gap-1.5 !rounded-xl btn-trigger-clone-bom" onclick="window.openCloneBomForCurrentProduct && window.openCloneBomForCurrentProduct(); return false;">
                                    ${confirmBtn}
                                </button>
                            </div>
                        `);
                        return;
                    }
                    if (res.hasShortage) {
                        toastr.warning('Stock shortage detected for one or more BOM components. You may proceed with the requisition.');
                    }

                    $('#mrProdBomId').val(res.master_bom_id || 0);
                    // Enable submit button for products with approved BOM
                    $('#matReqSubmitBtn').prop('disabled', false).removeAttr('disabled');
                    let productRow = '';
                    productIndex = 1;
                    res.items.forEach(bomRecord => {
                        let batchUnitHtml = '<option value="">---Select----</option>';
                        qtyUnitOptions.forEach(unit => {
                            let selected = (unit.id == bomRecord.qty_unit_id) ? 'selected' : '';
                            batchUnitHtml += `<option value="${unit.id}" ${selected}>${unit.label}</option>`;
                        });
                        productRow += `
                        <div class="product-item-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border ${bomRecord.short ? 'border-rose-300 bg-rose-50/70' : 'border-emerald-300 bg-emerald-50/30'} p-3 shadow-sm md:grid-cols-[minmax(220px,1.4fr)_minmax(130px,1fr)_minmax(130px,1fr)_40px] product-row" data-index="${productIndex}">
                            <div>
                                <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide"><span class="item-number-label">Item ${productIndex}</span></label>
                                <input type="hidden" name="ProductItemId[]" value="${bomRecord.product_id}" />
                                <input type="hidden" name="ProductCategoryItemId[]" value="${bomRecord.product_category_id}" />
                                <input type="text" name="ProductItemDesciption[]" class="input-theme" placeholder="Product Description" value="${escapeNewProductionPlanText(bomRecord.product_name)}" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Required Qty</label>
                                <input type="number" min="0" step="any" name="ProductItemquantity[]" class="input-theme" placeholder="Product quantity" value="${bomRecord.required}" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Unit</label>
                                <select name="ProductItemquantityUnit[]" class="input-theme select2" placeholder="Quantity Unit" required>${batchUnitHtml}</select>
                            </div>
                            <div class="flex items-start justify-end md:justify-center md:pt-6">
                                <button type="button" class="removeProductBtn mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                                    <i class="ti ti-trash text-base"></i>
                                </button>
                            </div>
                        </div>`;
                        productIndex++;
                    });

                    $('#mrProductsWrapper').html(productRow);
                    $('#mrProductsWrapper select.select2').select2({
                        dropdownParent: $('#addMaterialRquisitionModal'),
                        width: '100%'
                    });
                    $('#matReqSubmitBtn').prop('disabled', false).removeAttr('disabled');
                },
                error: function () {
                    toastr.error('Server error while loading BOM components.');
                    $('#mrProductsWrapper').html('<div class="p-4 text-center text-rose-500">Error loading BOM components.</div>');
                }
            });
        }

        $(document).on('change', '#mrFinishedProductSelect', function () {
            const data = $(this).select2('data')[0];
            if (data && data.unit_id) {
                $('#mrBatchSizeUnit').val(data.unit_id).trigger('change');
            }
            loadBomForManualMr();
        });

        $(document).on('input change', '#mrBatchSize', function () {
            if ($('#mrFinishedProductSelect').val() && !$('#mrProdPlanId').val()) {
                loadBomForManualMr();
            }
        });

        $('#addMaterialRquisitionModalBtn, #addMaterialRquisitionModalBomBtn').on('click', function () {
            $('#addMaterialRequisitionForm')[0].reset();
            $('#mrProdPlanId').val('');
            $('#mrProdBomId').val('');
            $('#mrProductName').addClass('hidden');
            $('#mrFinishedProductSelect').removeClass('hidden').val(null).trigger('change');
            initMrFinishedProductSelect();
            $('#addMaterialRequisitionModal').modal('show');
            $('#mrBatchSizeUnit').html('');
            $('#mrProductsWrapper').html('');
            $('#mrBomFilterWrapper').html('');
            $('#matReqSubmitBtn').prop('disabled', true).attr('disabled', 'disabled');
            ensureStandardUnitsLoaded().done(function () {
                populateMrBatchSizeUnit();
            });
        });

        $('#addMrProducts').click(function () {
            let optionsUnitHtml = '<option value="">---Select----</option>';
            qtyUnitOptions.forEach(unit => {
                optionsUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });
            const productRow = `
            <div class="product-item-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-3 shadow-sm md:grid-cols-[minmax(220px,1.4fr)_minmax(130px,1fr)_minmax(130px,1fr)_40px] product-row" data-index="${productIndex}">
                <div>
                    <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide"><span class="item-number-label">Item ${productIndex}</span></label>
                    <input type="hidden" name="ProductItemId[]" value="" />
                    <input type="hidden" name="ProductCategoryItemId[]" value="" />
                    <input type="text" name="ProductItemDesciption[]" class="input-theme" placeholder="Product Description" required />
                </div>
                <div>
                    <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Required Qty</label>
                    <input type="number" min="0" step="any" name="ProductItemquantity[]" class="input-theme" placeholder="Product quantity" required />
                </div>
                <div>
                    <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Unit</label>
                    <select name="ProductItemquantityUnit[]" class="input-theme select2" placeholder="Quantity Unit" required>`+ optionsUnitHtml + `</select>
                </div>
                <div class="flex items-start justify-end md:justify-center md:pt-6">
                    <button type="button" class="removeProductBtn mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                        <i class="ti ti-trash text-base"></i>
                    </button>
                </div>
            </div>
            `;
            $('#mrProductsWrapper').append(productRow);
            $('#mrProductsWrapper select.select2').select2({
                dropdownParent: $('#addMaterialRquisitionModal'),
                width: '100%'
            });
            productIndex++;
        });

        $('#mrProductsWrapper').on('click', '.removeProductBtn', function () {
            $(this).closest('.product-row').remove();
            updateItemNumbers();
        });

        $('#addMaterialRquisitionModal').on('hidden.bs.modal', function () {
            $('#addMaterialRequisitionForm')[0].reset();
            $('#mrProductsWrapper').empty();
            $('#mrBomFilterWrapper').empty();
            $('#mrBatchSizeUnit').val(null).trigger('change');
            $('#mrDepartment').val(null).trigger('change');
            $('#matReqSubmitBtn').prop('disabled', false);
            productIndex = 1;
        });

        $(document).on('click', '#matReqSubmitBtn', function (e) {
            const bomId = Number($('#mrProdBomId').val() || 0);
            const productId = Number($('#mrFinishedProductSelect').val() || 0);
            const isPlanLinked = Number($('#mrProdPlanId').val() || 0) > 0;

            if (!productId && !isPlanLinked) {
                e.preventDefault();
                toastr.warning('Please select a finished product first.');
                return false;
            }

            if (!bomId || bomId <= 0) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        });

        $('#addMaterialRequisitionForm').on('submit', function (e) {
            e.preventDefault();
            const bomId = Number($('#mrProdBomId').val() || 0);
            const productId = Number($('#mrFinishedProductSelect').val() || 0);
            const isPlanLinked = Number($('#mrProdPlanId').val() || 0) > 0;

            if (!productId && !isPlanLinked) {
                toastr.warning('Please select a finished product first.');
                return false;
            }

            if (!bomId || bomId <= 0) {
                return false;
            }
            if ($('.requisition-checkbox:checked').length === 0) {
                toastr.error('Please select at least one requisition type.');
                $('.requisition-checkbox').first().focus();
                return;
            }

            const form = document.getElementById('addMaterialRequisitionForm');
            const formData = new FormData(form);
            formData.append('addMaterialRequisitionForm', 'addMaterialRequisitionForm'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#addMaterialRquisitionModal').modal('hide');
                        $('#addMaterialRequisitionForm')[0].reset();
                        loadMaterialRequisitionTable();
                        loadProductionPlanTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred while saving the material requisition.');
                }
            });
        });

        $('#addTransferTicketForm').on('submit', function (e) {
            e.preventDefault();
            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');
            const form = this;
            const formData = new FormData(form);
            formData.append('addTransferTicket', 'addTransferTicket');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $submitBtn.prop('disabled', true).text('Saving...');
                },

                success: function (res) {
                    if (res.status === 'success') {
                        $('#addTransferTicketModal').modal('hide');
                        form.reset();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).text('Save');
                }
            });
        });
    });

    $(document).on('change', '#bomType', function () {
        let bomType = $(this).val();
        $('#mrProductsWrapper').html('');
        productIndex = 1;
        $('#bomMaster').empty().append('<option value="">Select BOM</option>');
        if (!bomType) return;

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                loadBomList: 'loadBomList',
                bom_type: bomType
            },
            success: function (data) {
                data.forEach(item => {
                    let option = new Option(
                        item.name + ' (' + item.category_name + ')',
                        item.id,
                        false,
                        false
                    );
                    $(option).data({
                        finished_product_id: item.finished_product_id,
                        product_name: item.product_name
                    });
                    $('#bomMaster').append(option);
                });

                $('#bomMaster').trigger('change');
            }
        });
    });

    $(document).on('select2:select change', '#bomMaster', function () {
        const option = this.options[this.selectedIndex];
        if (!option) return;
        const productName = $(option).data('product_name') || '';
        $('#mrProductName').val(productName);
        $('#mrProductsWrapper').empty();
        $('#mrProdBomId').val('');
        $('#matReqSubmitBtn').prop('disabled', true);
    });

    $(document).on('click', '#checkBomBtn', function () {
        let mrBatchSize = $('#mrBatchSize').val();
        let bomType = $('#bomType').val();
        let bomMaster = $('#bomMaster').val();
        $("#mrProdBomId").val('');
        $('#mrProductsWrapper').html('');
        $('#matReqSubmitBtn').prop('disabled', true);
        productIndex = 1;

        // ---- VALIDATION ----
        if (!mrBatchSize || mrBatchSize <= 0) { toastr.error('Please enter valid Batch Size'); return; }
        if (!bomType) { toastr.error('Please select BOM Type'); return; }
        if (!bomMaster) { toastr.error('Please select BOM Product'); return; }
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                getBomItemListForMatReq: 'getBomItemListForMatReq',
                batchSize: mrBatchSize,
                masterBomId: bomMaster
            },
            beforeSend: function () {
                $('#checkBomBtn').prop('disabled', true).text('Checking...');
            },
            success: function (response) {
                if (!response || !Array.isArray(response.items) || response.items.length === 0) {
                    toastr.error(response && response.message ? response.message : 'No material lines are configured for this BOM.');
                    return;
                }
                bomRecordOptions = response.items;
                let productRow = '';
                bomRecordOptions.forEach(bomRecord => {
                    let batchUnitHtml = '<option value="">---Select----</option>';
                    qtyUnitOptions.forEach(unit => {
                        let selected = (unit.id == bomRecord.qty_unit_id) ? 'selected' : '';
                        batchUnitHtml += `<option value="${unit.id}" ${selected}>${unit.label}</option>`;
                    });
                    productRow += `
                    <div class="product-item-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border ${bomRecord.short ? 'border-rose-300 bg-rose-50/70' : 'border-emerald-300 bg-emerald-50/30'} p-3 shadow-sm md:grid-cols-[minmax(220px,1.4fr)_minmax(130px,1fr)_minmax(130px,1fr)_40px] product-row" data-index="${productIndex}">
                        <div>
                            <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide"><span class="item-number-label">Item ${productIndex}</span> ${bomRecord.short ? '→ Available: ' + bomRecord.available : ''}</label>
                            <input type="hidden" name="ProductItemId[]" value="${bomRecord.product_id}" />
                            <input type="hidden" name="ProductCategoryItemId[]" value="${bomRecord.product_category_id}" />
                            <input type="text" name="ProductItemDesciption[]" class="input-theme bg-slate-100" value="${bomRecord.product_name}" readonly required />
                        </div>
                        <div>
                            <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Required Qty</label>
                            <input type="number" min="0" step="any" name="ProductItemquantity[]" class="input-theme bg-slate-100" value="${bomRecord.required}" readonly required />
                        </div>
                        <div>
                            <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Unit</label>
                            <select name="ProductItemquantityUnit[]" class="input-theme select2 pointer-events-none bg-slate-100" tabindex="-1" required>`+ batchUnitHtml + `</select>
                        </div>
                        <div class="flex items-start justify-end md:justify-center md:pt-6">
                            <span class="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-emerald-50 text-emerald-700"><i class="ti ti-lock text-base"></i></span>
                        </div>
                    </div>
                    `;
                    productIndex++;
                });

                $('#mrProductsWrapper').append(productRow);
                $('#matReqSubmitBtn').prop('disabled', false);
                $('#mrProdBomId').val(bomMaster);
            },
            complete: function () {
                $('#checkBomBtn').prop('disabled', false).text('Check BOM');
            },
            error: function () {
                toastr.error('Something went wrong while checking BOM');
            }
        });
    });

    $(document).on('click', '#addParametersEdit', function () {
        let optionsUnitHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });
        const productRow = `<div class="product-item-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-3 shadow-sm md:grid-cols-[minmax(220px,1.4fr)_minmax(130px,1fr)_minmax(130px,1fr)_40px] product-row" data-index="${productIndex}">
                    <div>
                        <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide"><span class="item-number-label">Item ${productIndex}</span></label>
                        <input type="hidden" name="matRequiItemIdEdit[]" />
                        <input type="text" name="ProductItemDesciptionEdit[]" class="input-theme" placeholder="Product Description" required />
                    </div>
                    <div>
                        <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Required Qty</label>
                        <input type="number" min="0" step="any" name="ProductItemquantityEdit[]" class="input-theme" placeholder="Product quantity" required />
                    </div>
                    <div>
                        <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Unit</label>
                        <select name="ProductItemquantityUnitEdit[]" class="input-theme select2" placeholder="Quantity Unit" required>`+ optionsUnitHtml + `</select>
                    </div>
                    <div class="flex items-start justify-end md:justify-center md:pt-6">
                        <button type="button" class="removeMatRequiItemBtn mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                            <i class="ti ti-trash text-base"></i>
                        </button>
                    </div>
            </div>`;
        const productRowElement = $(productRow);
        $('#templateParametersEdit').append(productRowElement);
        productRowElement.find('.select2').select2({ dropdownParent: $('#editMatRequiModel') });
        productIndex++;
    });

    $(document).on('click', '.materialRequisitionEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editMatRequiForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchMaterialRequisitionRecord: 'fetchMaterialRequisitionRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editMatRequiModel').modal('show');
                        $('#editMatRequiForm').find('.modal-body').html(res.data);
                        $('#editMatRequiForm .select2').select2({ dropdownParent: $('#editMatRequiModel') });
                        updateItemNumbersEdit();
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.materialRequisitionDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid Material Requisition ID provided.',
                customClass: {
                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'mr-3 inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteMaterialRequisitionRecord: 'deleteMaterialRequisitionRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadMaterialRequisitionTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                            }
                        });
                    }
                });
            }
        });
    });

    $('#editMatRequiForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editMatRequiForm');
        const formData = new FormData(form);
        formData.append('updateMatRequiRecord', 'updateMatRequiRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editMatRequiModel').modal('hide');
                    $('#editMatRequiForm').find('modal-body').html();
                    loadMaterialRequisitionTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.viewMatReqModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewMatRequi').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewMatRequiRecord: 'viewMatRequiRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#viewMatRequiModel').modal('show');
                        $('#viewMatRequi').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.removeMatRequiItemBtn', function (e) {
        e.preventDefault();
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            buttonClicked.closest('.product-row').remove();
            updateItemNumbersEdit();
            Swal.fire({
                icon: 'success',
                title: 'Removed !!',
                text: 'Material Requisition Item removed.',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                }
            });
            return;
        }
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'mr-3 inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteMatRequiItemRecord: 'deleteMatRequiItemRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                }
                            });
                            buttonClicked.closest('.product-row').remove();
                            updateItemNumbersEdit();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.materialRequisitionEditQtyFinalModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#materialRequisitionEditQtyFinalForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { materialRequisitionFinalQtyUpdate: 'materialRequisitionFinalQtyUpdate', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#materialRequisitionEditQtyFinalModal').modal('show');
                        $('#materialRequisitionEditQtyFinalForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#materialRequisitionEditQtyFinalForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('materialRequisitionEditQtyFinalForm');
        const formData = new FormData(form);
        formData.append('materialRequisitionEditQtyFinal', 'materialRequisitionEditQtyFinal');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#materialRequisitionEditQtyFinalModal').modal('hide');
                    $('#materialRequisitionEditQtyFinalForm').find('modal-body').html();
                    loadMaterialRequisitionTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.previewMaterialRequisitionPdf', function () {
        let id = $(this).data('id');
        if (id) {
            $('#materialRequisitionViewPdf').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    materialRequisionViewPdfRecord: 'materialRequisionViewPdfRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#materialRequisitionViewPdfModal').modal('show');
                        $('#materialRequisitionViewPdf').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfPurchaseOrderFinalDownloadBtn', function () {
        let id = $(this).data('id');
        if (id) {
            // Open printable PDF page in a new tab
            let url = "<?php echo APP_URL; ?>admin/pages/material_requisition_template.php?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');

            // Show success message after triggering
            toastr.success('Material Requisition PDF is being downloaded.');
        }
    });

    $(document).on('click', '.pdfTransferTicketDownloadBtn', function (e) {
        e.preventDefault();
        e.stopPropagation();
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/transfer_ticket_template.php?id=" + encodeURIComponent(id) + "&triggerDownload=1";
            const link = document.createElement('a');
            link.href = url;
            link.target = '_blank';
            link.download = '';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            toastr.success('Transfer ticket PDF is being downloaded.');
        }
    });

    $(document).on('click', '.productionPlanToMatRequest', function () {
        let id = $(this).data('id');
        $('#addMaterialRequisitionForm')[0].reset();
        $('#matReqSubmitBtn').prop('disabled', false);
        let masterBomId = $(this).data('master-bom-id');
        let name = $(this).data('name');
        let lotBatchNo = $(this).data('lot-batch-no');
        let batchSize = $(this).data('batch-size');
        let batchSizeUnit = $(this).data('batch-size-unit');
        $('#mrProdPlanId').val(id);
        $('#mrProdBomId').val(masterBomId);
        $('#mrFinishedProductSelect').addClass('hidden');
        $('#mrProductName').removeClass('hidden').val(name);
        $('#mrBatchNumber').val(lotBatchNo);
        $('#mrBatchSize').val(batchSize);
        $('#addMaterialRquisitionModal').modal('show');
        $('#mrBatchSizeUnit').html('');
        $('#mrProductsWrapper').html('');
        $('#mrBomFilterWrapper').html('');
        productIndex = 1;
        ensureStandardUnitsLoaded().done(function () {
            if (masterBomId && masterBomId != 0) {
                $.ajax({
                    url: 'ajax.php',
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        getBomItemListForMatReq: 'getBomItemListForMatReq',
                        masterBomId: masterBomId,
                        batchSize: batchSize
                    },
                    success: function (response) {
                        bomRecordOptions = response.items;
                        let productRow = '';
                        bomRecordOptions.forEach(bomRecord => {
                            let batchUnitHtml = '<option value="">---Select----</option>';
                            qtyUnitOptions.forEach(unit => {
                                let selected = (unit.id == bomRecord.qty_unit_id) ? 'selected' : '';
                                batchUnitHtml += `<option value="${unit.id}" ${selected}>${unit.label}</option>`;
                            });
                            productRow += `
                            <div class="product-item-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border ${bomRecord.short ? 'border-rose-300 bg-rose-50/70' : 'border-emerald-300 bg-emerald-50/30'} p-3 shadow-sm md:grid-cols-[minmax(220px,1.4fr)_minmax(130px,1fr)_minmax(130px,1fr)_40px] product-row" data-index="${productIndex}">
                                <div>
                                    <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide"><span class="item-number-label">Item ${productIndex}</span></label>
                                    <input type="hidden" name="ProductItemId[]" value="${bomRecord.product_id}" />
                                    <input type="hidden" name="ProductCategoryItemId[]" value="${bomRecord.product_category_id}" />
                                    <input type="text" name="ProductItemDesciption[]" class="input-theme" placeholder="Product Description" value="${bomRecord.product_name}" required />
                                </div>
                                <div>
                                    <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Required Qty</label>
                                    <input type="number" min="0" step="any" name="ProductItemquantity[]" class="input-theme" placeholder="Product quantity" value="${bomRecord.required}" required />
                                </div>
                                <div>
                                    <label class="mb-1 block text-xs font-semibold text-slate-500 uppercase tracking-wide">Unit</label>
                                    <select name="ProductItemquantityUnit[]" class="input-theme select2" placeholder="Quantity Unit" required>`+ batchUnitHtml + `</select>
                                </div>
                                <div class="flex items-start justify-end md:justify-center md:pt-6">
                                    <button type="button" class="removeProductBtn mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                                        <i class="ti ti-trash text-base"></i>
                                    </button>
                                </div>
                            </div>`;
                            productIndex++;
                        });

                        $('#mrProductsWrapper').append(productRow);
                    },
                    error: function (xhr, status, error) {
                        console.error("Failed to load qty units:", error);
                    }
                });
            }
            else {
                if ($('#mrProductsWrapper .product-row').length === 0) {
                    $('#addMrProducts').trigger('click');
                }
            }
            populateMrBatchSizeUnit(batchSizeUnit);
        });

    });

    $(document).on('click', '.productionPlanViewHistoryBtn', function () {
        let id = $(this).data('id');

        if (!id) return;
        $('#productionPlanHistoryView').find('.offcanvas-body').html(
            '<div class="text-center py-3">Loading...</div>'
        );

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                productionPlanHistoryViewRecord: 'productionPlanHistoryViewRecord',
                id: id
            },
            success: function (res) {
                if (res.status === 'success') {
                    $('#productionPlanHistoryView').find('.offcanvas-body').html(res.data);
                    let el = document.getElementById('productionPlanHistoryView');
                    let offcanvas = bootstrap.Offcanvas.getOrCreateInstance(el);
                    offcanvas.show();

                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.completeProductionPlanViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#completeProductionPlanViewForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewCompleteProductionPlanRecord: 'viewCompleteProductionPlanRecord', id: id },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#completeProductionPlanViewModal').modal('show');
                        $('#completeProductionPlanViewForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.addTransferTicketByPlanBtn', function () {
        $('#prodPlanId').val($(this).data('id'));
        $("#addTransferTicketModal").modal('show');
    });



    $(document).on('change', '#perPageSelectpProductionPlan', function () { loadProductionPlanTable(1); });
    let currentNewProductionPlanPage = 1;

    function escapeNewProductionPlanText(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function materialAlertPageButtons(totalPages, currentPage) {
        const pages = [...new Set([1, totalPages, currentPage - 2, currentPage - 1, currentPage, currentPage + 1, currentPage + 2]
            .filter(page => page >= 1 && page <= totalPages))].sort((a, b) => a - b);
        let previous = 0;
        return pages.map(function (page) {
            const gap = previous && page > previous + 1 ? '<span class="px-1 text-slate-400">&hellip;</span>' : '';
            previous = page;
            const active = page === currentPage ? 'bg-emerald-800 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100';
            return gap + `<button type="button" data-page="${page}" class="material-alert-page inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-sm font-bold ${active}">${page}</button>`;
        }).join('');
    }

    function loadNewProductionPlans(page = 1, showLoader = false) {
        if (showLoader) {
            $('#newProductionPlanTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadNewProductionPlans: 'loadNewProductionPlans',
                context: 'material_requisition',
                page: page
            },
            success: function (response) {
                if (response.status !== 'success') {
                    return;
                }

                const plans = Array.isArray(response.plans) ? response.plans : [];
                const totalRows = Number(response.totalRows || 0);
                const totalPages = Math.max(1, Number(response.totalPages || 1));
                currentNewProductionPlanPage = Math.min(Math.max(1, Number(response.page || 1)), totalPages);
                $('#newProductionPlanCount').text(totalRows);

                if (plans.length === 0) {
                    $('#newProductionPlanTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-slate-500">No new production plans available.</td></tr>');
                } else {
                    const perPage = Number(response.perPage || 10);
                    const start = (currentNewProductionPlanPage - 1) * perPage;
                    const rows = plans.map(function (plan, index) {
                        return `<tr class="transition-colors hover:bg-slate-50/50">
                            <td class="px-6 py-4 text-slate-900 font-bold">${start + index + 1}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-slate-600">${escapeNewProductionPlanText(plan.date)}</td>
                            <td class="px-6 py-4 text-slate-900 font-bold uppercase">${escapeNewProductionPlanText(plan.product_name)}<span class="mt-1 block text-xs font-medium text-slate-600">${escapeNewProductionPlanText(plan.production_plan_no || '')}</span></td>
                            <td class="px-6 py-4 whitespace-nowrap text-slate-600">${escapeNewProductionPlanText(plan.batch_no)}</td>
                            <td class="px-6 py-4 text-slate-600">${escapeNewProductionPlanText(plan.batch_size)} ${escapeNewProductionPlanText(plan.unit)}</td>
                            <td class="px-6 py-4 text-right">
                                <button type="button" class="newProductionPlanLocateBtn inline-flex h-8 items-center justify-center rounded-lg px-3 text-[11px] font-bold ring-1 ring-inset bg-white text-purple-700 ring-purple-200 transition-colors hover:bg-purple-50" data-plan-id="${plan.id}" data-bom-id="${plan.bom_master_id}" data-batch-size="${plan.batch_size}" data-product="${escapeNewProductionPlanText(plan.product_name)}" data-batch="${escapeNewProductionPlanText(plan.batch_no)}">View BOM</button>
                            </td>
                        </tr>`;
                    }).join('');
                    $('#newProductionPlanTableBody').html(rows);
                }

                const perPage = Number(response.perPage || 10);
                const firstRow = totalRows === 0 ? 0 : ((currentNewProductionPlanPage - 1) * perPage) + 1;
                const lastRow = Math.min(currentNewProductionPlanPage * perPage, totalRows);
                $('#newProductionPlanSummary').text(`Showing ${firstRow} to ${lastRow} of ${totalRows} entries`);
                $('#newProductionPlanPrev').prop('disabled', currentNewProductionPlanPage <= 1);
                $('#newProductionPlanNext').prop('disabled', currentNewProductionPlanPage >= totalPages);
                $('#newProductionPlanCurrentPage').html(materialAlertPageButtons(totalPages, currentNewProductionPlanPage));
            },
            error: function () {
                $('#newProductionPlanTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-rose-500">Error loading data.</td></tr>');
            }
        });
    }

    $(document).on('click', '#newProductionPlanWidget', function () {
        loadNewProductionPlans(1, true);
        $('#newProductionPlanModal').modal('show');
    });

    $(document).on('keydown', '#newProductionPlanWidget', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            $(this).trigger('click');
        }
    });

    $(document).on('click', '#newProductionPlanPrev', function () {
        if (currentNewProductionPlanPage > 1) {
            loadNewProductionPlans(currentNewProductionPlanPage - 1, true);
        }
    });

    $(document).on('click', '#newProductionPlanNext', function () {
        loadNewProductionPlans(currentNewProductionPlanPage + 1, true);
    });

    $(document).on('click', '.material-alert-page', function () {
        loadNewProductionPlans(Number($(this).data('page') || 1), true);
    });

    $(document).on('click', '.newProductionPlanLocateBtn', function () {
        const bomId = $(this).data('bom-id');
        const batchSize = $(this).data('batch-size');
        const productName = $(this).data('product');
        const batchNo = $(this).data('batch');
        const planId = $(this).data('plan-id');

        if (!bomId || bomId == 0) {
            toastr.error(`No active BOM is configured for ${productName || 'this product'}. Material Requisition cannot proceed.`);
            return;
        }

        $('#generateBomConfirmBtn')
            .data('bom-id', bomId)
            .data('batch-size', batchSize)
            .data('product', productName)
            .data('batch', batchNo)
            .data('plan-id', planId);
        $('#generateBomConfirmBtn').prop('disabled', false);

        $('#newProductionPlanModal').modal('hide');
        $('#viewBomModalBatchTitle').text(`Review required components for Batch ${batchNo} | ${productName}`);
        $('#viewBomModalTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        $('#bomProcureBtn, #bomProduceBtn').prop('disabled', true);
        $('#selectAllBomShortage').prop('checked', false).prop('indeterminate', false);
        $('#viewBomModal').modal('show');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getBomItemListForMatReq: 'getBomItemListForMatReq',
                masterBomId: bomId,
                batchSize: batchSize
            },
            success: function (response) {
                const items = response && Array.isArray(response.items) ? response.items : [];
                if (items.length > 0) {
                    const rows = items.map((item, idx) => {
                        const unitName = item.unit_name ? `${item.unit_name}` : '';
                        const reqQtyNum = Number(item.required || 0);
                        const availableNum = Number(item.available || 0);
                        const isShort = Boolean(item.short) || ((availableNum + 0.00000001) < reqQtyNum);

                        const availDisplay = availableNum.toLocaleString('en-IN', { maximumFractionDigits: 4 });
                        const shortfallNum = Math.max(0, reqQtyNum - availableNum);
                        const shortDisplay = shortfallNum.toLocaleString('en-IN', { maximumFractionDigits: 4 });

                        return `<tr class="bom-item-row transition-colors ${isShort ? 'bg-rose-50/70 border-b border-rose-100' : 'hover:bg-slate-50/50'}" data-product-id="${item.product_id}">
                            <td class="px-3 py-3 text-center align-middle bom-select-cell">
                                ${isShort ? `
                                    <input type="checkbox" class="bom-shortage-checkbox form-check-input rounded border-rose-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                                        data-product-id="${item.product_id}"
                                        data-product-name="${escapeNewProductionPlanText(item.product_name)}"
                                        data-category-id="${item.product_category_id || 0}"
                                        data-category-name="${escapeNewProductionPlanText(item.category_name || '')}"
                                        data-unit-id="${item.qty_unit_id || 0}"
                                        data-unit-name="${escapeNewProductionPlanText(unitName)}"
                                        data-available="${availableNum}"
                                        checked />
                                ` : `
                                    <span class="inline-flex items-center justify-center text-emerald-500" title="In Stock - Shortage action not required">
                                        <i class="ti ti-check text-base font-bold"></i>
                                    </span>
                                `}
                            </td>
                            <td class="px-2 py-3 text-center text-xs font-bold text-slate-400 align-middle">${String(idx + 1).padStart(2, '0')}</td>
                            <td class="px-4 py-3 align-middle">
                                <div class="flex items-center gap-2.5">
                                    <div class="product-icon-wrap">
                                        ${isShort ? `
                                            <div class="flex h-7 w-7 items-center justify-center rounded-lg bg-rose-100 text-rose-600 shrink-0 border border-rose-200">
                                                <i class="ti ti-alert-triangle text-sm"></i>
                                            </div>
                                        ` : `
                                            <div class="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-50 text-amber-600 shrink-0 border border-amber-200">
                                                <i class="ti ti-box text-sm"></i>
                                            </div>
                                        `}
                                    </div>
                                    <div>
                                        <span class="font-bold text-slate-800 text-xs">${escapeNewProductionPlanText(item.product_name)}</span>
                                        <div class="product-shortage-label">
                                            ${isShort ? `<div class="text-[10px] font-black uppercase tracking-wider text-rose-600 mt-0.5">CRITICAL SHORTAGE</div>` : ''}
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-center align-middle">
                                <span class="category-badge inline-flex items-center rounded-md ${isShort ? 'bg-rose-100/70 text-rose-700 font-bold' : 'bg-slate-100 text-slate-600'} px-2.5 py-1 text-xs font-semibold">${escapeNewProductionPlanText(item.category_name || 'N/A')}</span>
                            </td>
                            <td class="px-4 py-3 text-center align-middle" style="width: 160px; min-width: 150px;">
                                <div class="bom-input-wrap inline-flex items-center justify-between rounded-lg border ${isShort ? 'border-rose-300 ring-1 ring-rose-200' : 'border-slate-200'} bg-white px-2 py-1 shadow-sm focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-100">
                                    <input type="number" step="any" min="0" class="bomReqQtyInput text-right font-bold text-slate-800 text-xs focus:outline-none border-0 p-0 pe-1 bg-transparent" value="${Number(item.required || 0)}" data-product-id="${item.product_id}" data-unit-id="${item.qty_unit_id || 0}" data-category-id="${item.product_category_id || 0}" data-unit-name="${escapeNewProductionPlanText(unitName)}" data-available="${availableNum}" data-category="${escapeNewProductionPlanText(item.category_name || 'N/A')}" data-product-name="${escapeNewProductionPlanText(item.product_name)}" />
                                    <span class="bom-unit-badge text-xs font-semibold text-slate-400 ms-1 shrink-0 select-none">${escapeNewProductionPlanText(unitName)}</span>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-right align-middle">
                                <div class="stockStatusContainer flex flex-col items-end">
                                    ${isShort ? `
                                        <span class="inline-flex items-center gap-1.5 rounded-full bg-rose-100 px-3 py-1 text-xs font-black text-rose-700 border border-rose-200 uppercase tracking-wide">
                                            <span class="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                                            ${availableNum <= 0 ? 'OUT OF STOCK (0 Available)' : `SHORTAGE (${availDisplay} Available)`}
                                        </span>
                                        <span class="text-[10px] font-bold text-rose-600 mt-1">Shortfall: -${shortDisplay} ${escapeNewProductionPlanText(unitName)}</span>
                                    ` : `
                                        <span class="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 border border-emerald-200 shadow-sm">
                                            <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                                            In Stock (${availDisplay} ${escapeNewProductionPlanText(unitName)})
                                        </span>
                                    `}
                                </div>
                            </td>
                        </tr>`;
                    }).join('');
                    $('#viewBomModalTableBody').html(rows);
                    refreshProcureProduceButtons();
                } else {
                    $('#viewBomModalTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-slate-500">No components found in BOM.</td></tr>');
                    refreshProcureProduceButtons();
                }
            },
            error: function () {
                $('#viewBomModalTableBody').html('<tr><td colspan="6" class="px-6 py-10 text-center text-rose-500">Error loading data.</td></tr>');
                $('#generateBomConfirmBtn').prop('disabled', true);
                $('#bomProcureBtn, #bomProduceBtn').prop('disabled', true);
            }
        });
    });

    // Real-time stock status re-evaluation when required quantity is modified
    function updateBomRowStockState($row) {
        const $input = $row.find('.bomReqQtyInput');
        const reqQty = parseFloat($input.val()) || 0;
        const available = parseFloat($input.data('available')) || 0;
        const unitName = $input.data('unit-name') || '';
        const isShort = (available + 0.00000001) < reqQty;
        const shortfall = Math.max(0, reqQty - available);
        const availDisplay = Number(available).toLocaleString('en-IN', { maximumFractionDigits: 4 });
        const shortDisplay = Number(shortfall).toLocaleString('en-IN', { maximumFractionDigits: 4 });

        if (isShort) {
            $row.addClass('bg-rose-50/70 border-b border-rose-100').removeClass('hover:bg-slate-50/50');
            // If row currently doesn't have shortage checkbox, insert one
            if ($row.find('.bom-shortage-checkbox').length === 0) {
                $row.find('.bom-select-cell').html(`
                    <input type="checkbox" class="bom-shortage-checkbox form-check-input rounded border-rose-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        data-product-id="${$input.data('product-id')}"
                        data-product-name="${escapeNewProductionPlanText($input.data('product-name') || '')}"
                        data-category-id="${$input.data('category-id') || 0}"
                        data-category-name="${escapeNewProductionPlanText($input.data('category') || '')}"
                        data-unit-id="${$input.data('unit-id') || 0}"
                        data-unit-name="${escapeNewProductionPlanText(unitName)}"
                        data-available="${available}"
                        checked />
                `);
            }
            $row.find('.product-icon-wrap').html('<div class="flex h-7 w-7 items-center justify-center rounded-lg bg-rose-100 text-rose-600 shrink-0 border border-rose-200"><i class="ti ti-alert-triangle text-sm"></i></div>');
            $row.find('.product-shortage-label').html('<div class="text-[10px] font-black uppercase tracking-wider text-rose-600 mt-0.5">CRITICAL SHORTAGE</div>');
            $row.find('.category-badge').removeClass('bg-slate-100 text-slate-600').addClass('bg-rose-100/70 text-rose-700 font-bold');
            $row.find('.bom-input-wrap').addClass('border-rose-300 ring-1 ring-rose-200').removeClass('border-slate-200');
            $row.find('.stockStatusContainer').html(`
                <span class="inline-flex items-center gap-1.5 rounded-full bg-rose-100 px-3 py-1 text-xs font-black text-rose-700 border border-rose-200 uppercase tracking-wide">
                    <span class="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                    ${available <= 0 ? 'OUT OF STOCK (0 Available)' : `SHORTAGE (${availDisplay} Available)`}
                </span>
                <span class="text-[10px] font-bold text-rose-600 mt-1">Shortfall: -${shortDisplay} ${escapeNewProductionPlanText(unitName)}</span>
            `);
        } else {
            $row.removeClass('bg-rose-50/70 border-b border-rose-100').addClass('hover:bg-slate-50/50');
            // If row has shortage checkbox, replace with in-stock checkmark
            $row.find('.bom-select-cell').html(`
                <span class="inline-flex items-center justify-center text-emerald-500" title="In Stock - Shortage action not required">
                    <i class="ti ti-check text-base font-bold"></i>
                </span>
            `);
            $row.find('.product-icon-wrap').html('<div class="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-50 text-amber-600 shrink-0 border border-amber-200"><i class="ti ti-box text-sm"></i></div>');
            $row.find('.product-shortage-label').empty();
            $row.find('.category-badge').removeClass('bg-rose-100/70 text-rose-700 font-bold').addClass('bg-slate-100 text-slate-600');
            $row.find('.bom-input-wrap').removeClass('border-rose-300 ring-1 ring-rose-200').addClass('border-slate-200');
            $row.find('.stockStatusContainer').html(`
                <span class="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 border border-emerald-200 shadow-sm">
                    <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                    In Stock (${availDisplay} ${escapeNewProductionPlanText(unitName)})
                </span>
            `);
        }
        refreshProcureProduceButtons();
    }

    function refreshProcureProduceButtons() {
        const totalShortCheckboxes = $('.bom-shortage-checkbox').length;
        const checkedShortCheckboxes = $('.bom-shortage-checkbox:checked').length;

        // Sync header "Select All" checkbox
        if (totalShortCheckboxes > 0 && checkedShortCheckboxes === totalShortCheckboxes) {
            $('#selectAllBomShortage').prop('checked', true).prop('indeterminate', false);
        } else if (checkedShortCheckboxes > 0) {
            $('#selectAllBomShortage').prop('checked', false).prop('indeterminate', true);
        } else {
            $('#selectAllBomShortage').prop('checked', false).prop('indeterminate', false);
        }

        if (checkedShortCheckboxes > 0) {
            $('#bomProcureBtn').prop('disabled', false).html(`<i class="ti ti-shopping-cart text-sm"></i> Procure (${checkedShortCheckboxes})`);
            $('#bomProduceBtn').prop('disabled', false).html(`<i class="ti ti-building-factory-2 text-sm"></i> Produce (${checkedShortCheckboxes})`);
        } else {
            $('#bomProcureBtn').prop('disabled', true).html('<i class="ti ti-shopping-cart text-sm"></i> Procure');
            $('#bomProduceBtn').prop('disabled', true).html('<i class="ti ti-building-factory-2 text-sm"></i> Produce');
        }
    }

    $(document).on('change', '#selectAllBomShortage', function () {
        const isChecked = $(this).is(':checked');
        $('.bom-shortage-checkbox').prop('checked', isChecked);
        refreshProcureProduceButtons();
    });

    $(document).on('change', '.bom-shortage-checkbox', function () {
        refreshProcureProduceButtons();
    });

    $(document).on('input', '.bomReqQtyInput', function () {
        updateBomRowStockState($(this).closest('.bom-item-row'));
    });

    // Procure Button Action
    $(document).on('click', '#bomProcureBtn', function () {
        const selectedItems = [];
        $('.bom-shortage-checkbox:checked').each(function() {
            const $chk = $(this);
            const $row = $chk.closest('.bom-item-row');
            const $input = $row.find('.bomReqQtyInput');
            const reqQty = parseFloat($input.val()) || 0;
            const available = parseFloat($chk.data('available')) || 0;
            const shortfall = Math.max(0, reqQty - available);
            selectedItems.push({
                product_id: Number($chk.data('product-id')),
                product_name: String($chk.data('product-name') || ''),
                category_id: Number($chk.data('category-id') || 0),
                category_name: String($chk.data('category-name') || ''),
                unit_id: Number($chk.data('unit-id') || 0),
                unit_name: String($chk.data('unit-name') || ''),
                required_qty: reqQty,
                available_qty: available,
                shortfall_qty: shortfall > 0 ? shortfall : reqQty
            });
        });

        if (selectedItems.length === 0) {
            toastr.warning('Please select at least one shortage item to procure.');
            return;
        }

        const batchNo = $('#generateBomConfirmBtn').data('batch') || '';
        const $btn = $(this);
        const originalHtml = $btn.html();
        $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-sm"></i> Sending...');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                procureBomShortageItems: 'procureBomShortageItems',
                batch_no: batchNo,
                items: JSON.stringify(selectedItems)
            },
            success: function (res) {
                $btn.prop('disabled', false).html(originalHtml);
                if (res.status === 'success') {
                    toastr.success(res.message || 'Items successfully sent to Purchase Management.');
                    setTimeout(() => {
                        window.location.href = 'index.php?page=purchase-management';
                    }, 800);
                } else {
                    toastr.error(res.message || 'Failed to send items to Purchase Management.');
                }
            },
            error: function (xhr) {
                $btn.prop('disabled', false).html(originalHtml);
                const msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Server error while sending items to Purchase Management.';
                toastr.error(msg);
            }
        });
    });

    // Produce Button Action
    $(document).on('click', '#bomProduceBtn', function () {
        const selectedItems = [];
        $('.bom-shortage-checkbox:checked').each(function() {
            const $chk = $(this);
            const $row = $chk.closest('.bom-item-row');
            const $input = $row.find('.bomReqQtyInput');
            const reqQty = parseFloat($input.val()) || 0;
            const available = parseFloat($chk.data('available')) || 0;
            const shortfall = Math.max(0, reqQty - available);
            selectedItems.push({
                product_id: Number($chk.data('product-id')),
                product_name: String($chk.data('product-name') || ''),
                category_id: Number($chk.data('category-id') || 0),
                category_name: String($chk.data('category-name') || ''),
                unit_id: Number($chk.data('unit-id') || 0),
                unit_name: String($chk.data('unit-name') || ''),
                required_qty: reqQty,
                available_qty: available,
                shortfall_qty: shortfall > 0 ? shortfall : reqQty
            });
        });

        if (selectedItems.length === 0) {
            toastr.warning('Please select at least one shortage item to produce.');
            return;
        }

        const batchNo = $('#generateBomConfirmBtn').data('batch') || '';
        const $btn = $(this);
        const originalHtml = $btn.html();
        $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-sm"></i> Sending...');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                produceBomShortageItems: 'produceBomShortageItems',
                batch_no: batchNo,
                items: JSON.stringify(selectedItems)
            },
            success: function (res) {
                $btn.prop('disabled', false).html(originalHtml);
                if (res.status === 'success') {
                    toastr.success(res.message || 'Items successfully sent to Production Plan Incoming Requests.');
                    setTimeout(() => {
                        window.location.href = 'index.php?page=production-plan';
                    }, 800);
                } else {
                    toastr.error(res.message || 'Failed to send items to Production Plan.');
                }
            },
            error: function (xhr) {
                $btn.prop('disabled', false).html(originalHtml);
                const msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Server error while sending items to Production Plan.';
                toastr.error(msg);
            }
        });
    });

    $(document).on('click', '#generateBomConfirmBtn', function () {
        const bomId = $(this).data('bom-id');
        const batchSize = $(this).data('batch-size');
        const productName = $(this).data('product');
        const batchNo = $(this).data('batch');
        const planId = $(this).data('plan-id');

        if (!bomId || !batchSize) {
            toastr.error('Invalid BOM or batch details.');
            return;
        }

        const customQuantities = {};
        $('#viewBomModalTableBody .bomReqQtyInput').each(function() {
            const pid = $(this).data('product-id');
            const qty = parseFloat($(this).val()) || 0;
            if (pid && qty > 0) {
                customQuantities[pid] = qty;
            }
        });

        const $btn = $(this);
        $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin me-2"></i> Generating...');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                generateBomFromPlan: 'generateBomFromPlan',
                csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
                bom_id: bomId,
                batch_size: batchSize,
                product_name: productName,
                batch_no: batchNo,
                plan_id: planId,
                custom_quantities: JSON.stringify(customQuantities)
            },
            success: function (res) {
                $btn.prop('disabled', false).html('Generate BOM &rarr;');
                if (res.status === 'success') {
                    toastr.success(res.message || 'BOM generated successfully!');
                    $('#viewBomModal').modal('hide');
                    $('#newProductionPlanModal').modal('hide');
                    if (typeof loadMaterialRequisitionTable === 'function') loadMaterialRequisitionTable(1);
                    loadNewProductionPlans(1, false);
                } else {
                    toastr.error(res.message || 'Failed to generate BOM.');
                }
            },
            error: function () {
                $btn.prop('disabled', false).html('Generate BOM &rarr;');
                toastr.error('Server error while generating BOM.');
            }
        });
    });

    $(document).ready(function () {
        loadNewProductionPlans(1, false);
    });
</script>

<!-- New Production Plan Modal -->
<div class="modal fade animate__animated fadeIn" id="newProductionPlanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Modal Header -->
            <div
                class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4 relative">
                <div class="flex items-center gap-4">
                    <div
                        style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.5rem; height: 3.5rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                        <i class="ti ti-clipboard-list"
                            style="font-size: 1.75rem; color: var(--appearance-accent, #7e22ce);"></i>
                        <span
                            style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                    </div>
                    <div>
                        <h5 class="modal-title m-0 font-bold leading-tight"
                            style="font-size: 1.25rem; color: var(--ui-text, #1e293b);">New Production Plan!</h5>
                        <p class="m-0 mt-1 font-medium"
                            style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">These ordered items have
                            been sent from Order Management and need to be produced.</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none ml-auto"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full border-collapse text-left">
                        <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                            <tr>
                                <th
                                    class="w-12 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    #</th>
                                <th
                                    class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Date</th>
                                <th
                                    class="w-48 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Product</th>
                                <th
                                    class="w-44 min-w-[160px] px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Lot #</th>
                                <th
                                    class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    Batch Size</th>
                                <th
                                    class="w-20 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400 text-right">
                                    Action</th>
                            </tr>
                        </thead>
                        <tbody id="newProductionPlanTableBody"
                            class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                            <tr>
                                <td colspan="6" class="px-6 py-10 text-center text-sm font-medium text-slate-500">
                                    Loading new production plans...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Footer -->
                <div
                    class="flex flex-col md:flex-row items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
                    <span id="newProductionPlanSummary" class="text-sm font-medium text-slate-500">Showing 0 to 0 of 0
                        entries</span>
                    <div class="flex items-center gap-1">
                        <button id="newProductionPlanPrev" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Previous page" disabled><i class="ti ti-arrow-left text-sm"></i></button>
                        <div id="newProductionPlanCurrentPage" class="flex items-center gap-1"></div>
                        <button id="newProductionPlanNext" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Next page" disabled><i class="ti ti-arrow-right text-sm"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/clone-bom-modal.php'; ?>

<?php endSection(); ?>

<!-- View BOM Modal -->
<div class="modal fade animate__animated fadeIn" id="viewBomModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 960px; width: 92%;">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Modal Header -->
            <div
                class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-3.5 relative">
                <div class="flex items-center gap-4">
                    <div
                        style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: #fef3c7; border-radius: 0.75rem; border: 1px solid #fde68a;">
                        <i class="ti ti-file-description"
                            style="font-size: 1.5rem; color: #d97706;"></i>
                    </div>
                    <div>
                        <h5 class="modal-title m-0 font-bold leading-tight"
                            style="font-size: 1.2rem; color: var(--ui-text, #1e293b);">View Bill of Materials (BOM)</h5>
                        <p id="viewBomModalBatchTitle" class="m-0 mt-0.5 font-medium"
                            style="font-size: 0.825rem; color: var(--ui-text-muted, #64748b);">Review required
                            components for Batch</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none ml-auto"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-base"></i>
                </button>
            </div>

            <div class="modal-body !p-4 bg-slate-50/50"
                style="overflow: hidden !important; overflow-y: hidden !important;">
                <div class="overflow-auto rounded-xl border border-slate-200 bg-white shadow-sm"
                    style="max-height: 420px;">
                    <table class="w-full border-collapse text-left">
                        <thead class="border-b border-slate-100 bg-slate-50/70 whitespace-nowrap sticky top-0 bg-white z-10">
                            <tr>
                                <th class="w-10 px-3 py-3 text-center">
                                    <input type="checkbox" id="selectAllBomShortage" class="form-check-input rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer" title="Select all shortage items" />
                                </th>
                                <th class="w-12 px-2 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-center">Sr. #</th>
                                <th class="px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-400">Product</th>
                                <th class="px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-center">Category</th>
                                <th class="w-44 min-w-[140px] px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-center" style="width: 160px; min-width: 150px;">Req. Qty</th>
                                <th class="px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right">Stock Status / Availability</th>
                            </tr>
                        </thead>
                        <tbody id="viewBomModalTableBody"
                            class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                            <tr>
                                <td colspan="6" class="px-6 py-8 text-center text-sm font-medium text-slate-500">Loading
                                    BOM details...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3 rounded-xl border border-blue-100 bg-blue-50/50 p-3 flex gap-3 items-start">
                    <i class="ti ti-info-circle text-base text-blue-600 shrink-0 mt-0.5"></i>
                    <p class="text-xs text-slate-600 italic leading-relaxed m-0">The quantities above are automatically
                        derived from the batch size and standard yield parameters defined in the Master Configuration
                        for this product SKU. Edited quantities will recalculate reserve requirements upon confirmation.</p>
                </div>
            </div>

            <div class="modal-footer border-t border-slate-100 bg-white !px-6 !py-3 flex items-center justify-between gap-3">
                <div class="flex items-center gap-2">
                    <button type="button" id="bomProcureBtn"
                        class="inline-flex h-9 items-center justify-center gap-1.5 rounded-xl border border-amber-300 bg-amber-50/80 px-4 text-xs font-bold text-amber-800 shadow-sm transition-colors hover:bg-amber-100 disabled:opacity-40 disabled:cursor-not-allowed"
                        disabled>
                        <i class="ti ti-shopping-cart text-sm"></i> Procure
                    </button>
                    <button type="button" id="bomProduceBtn"
                        class="inline-flex h-9 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
                        disabled>
                        <i class="ti ti-building-factory-2 text-sm"></i> Produce
                    </button>
                </div>
                <div class="flex items-center gap-3">
                    <button type="button"
                        class="inline-flex h-9 items-center justify-center rounded-xl bg-white px-5 text-sm font-bold text-slate-700 ring-1 ring-inset ring-slate-200 transition-colors hover:bg-slate-50"
                        data-bs-dismiss="modal" onclick="$('#newProductionPlanModal').modal('show');">Cancel</button>
                    <button type="button" id="generateBomConfirmBtn"
                        class="inline-flex h-9 min-w-36 items-center justify-center gap-2 !rounded-xl text-white font-bold shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                        style="background-color: #7f56d9; border-color: #7f56d9;">Generate BOM &rarr;</button>
                </div>
            </div>
        </div>
    </div>
</div>
