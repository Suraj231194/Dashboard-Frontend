<?php
if (!defined('PAYROLL_CONTEXT')) define('PAYROLL_CONTEXT', true);
require_once __DIR__ . '/../payroll/payroll_common.php';

$canViewAdvances = payrollCan($conn, 'payroll_advances_view');
$canManageAdvances = payrollCan($conn, 'payroll_advances_manage');
$advanceScope = $canViewAdvances ? payrollCurrentScope($conn, (int) ($_SESSION['user_id'] ?? 0)) : null;
$advancePeople = [];
$advanceRows = [];
if ($advanceScope && payrollSchemaReady($conn)) {
    $companyId = (int) $advanceScope['company_id'];
    $branchId = (int) $advanceScope['branch_id'];
    $peopleSql = "SELECT employee.id, employee.emp_code, employee.first_name, employee.last_name, employee.emp_categ_type
        FROM employees employee
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
                LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        WHERE employee.status != 3 AND employee.deleted_at IS NULL AND employee.emp_categ_type IN (1,2)
                    AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?
                    AND (? = 0 OR COALESCE(profile.branch_id, user.branch_id) = ?)
        ORDER BY employee.first_name, employee.last_name";
    $stmt = $conn->prepare($peopleSql);
    $stmt->bind_param('iii', $companyId, $branchId, $branchId);
    $stmt->execute();
    $advancePeople = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $rowSql = "SELECT advance_record.id, advance_record.issued_on, advance_record.amount,
            advance_record.payment_mode, advance_record.remarks, advance_record.status,
            advance_record.payroll_party_type, employee.emp_code, employee.first_name, employee.last_name,
            employee.emp_categ_type
        FROM employee_advances advance_record
        INNER JOIN employees employee ON employee.id = advance_record.employee_id AND employee.deleted_at IS NULL
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
                LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        WHERE advance_record.deleted_at IS NULL
                    AND COALESCE(advance_record.company_id, profile.company_id, user.company_id, legacy_company.id) = ?
                    AND (? = 0 OR COALESCE(advance_record.branch_id, profile.branch_id, user.branch_id) = ?)
        ORDER BY advance_record.issued_on DESC, advance_record.id DESC LIMIT 500";
    $stmt = $conn->prepare($rowSql);
    $stmt->bind_param('iii', $companyId, $branchId, $branchId);
    $stmt->execute();
    $advanceRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
$paymentModeLabels = ['cash'=>'Cash','bank_transfer'=>'Bank Transfer','cheque'=>'Cheque','upi'=>'UPI','other'=>'Other'];
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
<?php if (!$canViewAdvances): ?>
    <div class="card border border-rose-200 bg-rose-50 rounded-2xl"><div class="card-body p-6 text-center text-rose-700"><i class="ti ti-lock fs-2 d-block mb-3"></i>Advance Salary is restricted to authorized Payroll users.</div></div>
<?php elseif (!payrollSchemaReady($conn)): ?>
    <div class="card border border-amber-200 bg-amber-50 rounded-2xl"><div class="card-body p-6 text-center text-amber-700">Payroll Management is not configured.</div></div>
<?php else: ?>
    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-6 payroll-advances-page-header">
        <div><h2 class="mb-1 text-2xl fw-bold text-slate-900" style="font-family:'Sora',sans-serif">Advance Salary</h2><p class="mb-0 text-sm text-slate-500">Record employee advances that are deducted from the selected month’s final pay run.</p></div>
        <?php if ($canManageAdvances): ?><button class="btn btn-primary rounded-xl px-4 d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#recordAdvanceModal"><i class="ti ti-plus"></i> New Advance Salary</button><?php endif; ?>
    </div>

    <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
        <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex flex-column flex-md-row justify-content-between gap-3"><div><h5 class="mb-1 fw-bold text-slate-900">Recorded Advances</h5><p class="mb-0 text-sm text-slate-500">People are always selected from Employee Master.</p></div><div class="position-relative" style="max-width:320px;width:100%"><i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:14px"></i><input class="form-control rounded-xl ps-5" id="advanceSearch" placeholder="Search advances"></div></div>
        <div class="table-responsive"><table class="table align-middle mb-0" id="advanceTable"><thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Date</th><th class="py-3 text-xs text-uppercase text-slate-500">Type</th><th class="py-3 text-xs text-uppercase text-slate-500">Employee</th><th class="py-3 text-xs text-uppercase text-slate-500">Amount</th><th class="py-3 text-xs text-uppercase text-slate-500">Payment Mode</th><th class="py-3 text-xs text-uppercase text-slate-500">Reason</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Status</th></tr></thead><tbody>
            <?php if (!$advanceRows): ?><tr><td colspan="7" class="text-center py-10 text-slate-500">No advance salary records found.</td></tr>
            <?php else: foreach ($advanceRows as $advance): 
                $rawType = $advance['payroll_party_type'] ?: ((int)$advance['emp_categ_type'] === 1 ? 'worker' : 'employee'); 
                $type = strtolower($rawType);
                if ($type === 'worker') {
                    $typeBadge = '<span class="badge bg-label-info text-info rounded-pill px-3 py-1.5 fw-semibold text-xs d-inline-flex align-items-center gap-1"><i class="ti ti-user text-xs"></i> Worker</span>';
                } elseif ($type === 'employee') {
                    $typeBadge = '<span class="badge bg-label-primary text-primary rounded-pill px-3 py-1.5 fw-semibold text-xs d-inline-flex align-items-center gap-1"><i class="ti ti-briefcase text-xs"></i> Employee</span>';
                } else {
                    $typeBadge = '<span class="badge bg-label-secondary text-secondary rounded-pill px-3 py-1.5 fw-semibold text-xs d-inline-flex align-items-center gap-1"><i class="ti ti-user-check text-xs"></i> ' . htmlspecialchars(ucfirst($type)) . '</span>';
                }
            ?>
                <tr class="advance-row">
                    <td class="px-5 py-4 text-slate-600"><?= htmlspecialchars(date('d M Y', strtotime($advance['issued_on']))) ?></td>
                    <td class="py-4"><?= $typeBadge ?></td>
                    <td class="py-4"><div class="fw-bold text-slate-800"><?= htmlspecialchars(trim($advance['first_name'].' '.$advance['last_name'])) ?></div><div class="text-xs text-slate-400"><?= htmlspecialchars($advance['emp_code']) ?></div></td>
                    <td class="py-4 fw-bold text-slate-800">₹<?= payrollMoney($advance['amount']) ?></td>
                    <td class="py-4 text-slate-600"><?= htmlspecialchars($paymentModeLabels[$advance['payment_mode']] ?? 'Not recorded') ?></td>
                    <td class="py-4 text-slate-600"><?= htmlspecialchars($advance['remarks'] ?: '—') ?></td>
                    <td class="px-5 py-4">
                        <span class="badge rounded-pill px-3 py-1.5 fw-semibold text-xs d-inline-flex align-items-center gap-1 <?= (int)$advance['status'] === 1 ? 'bg-label-success text-success' : 'bg-label-secondary text-secondary' ?>">
                            <i class="ti <?= (int)$advance['status'] === 1 ? 'ti-circle-check' : 'ti-circle-minus' ?> text-xs"></i>
                            <?= (int)$advance['status'] === 1 ? 'Active' : 'Inactive' ?>
                        </span>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody></table></div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="recordAdvanceModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document"><div class="modal-content !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3"><div class="flex items-center gap-3"><span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i class="ti ti-plus text-xl"></i></span><div><h5 class="modal-title m-0 text-lg font-bold text-slate-900">Record Advance</h5><p class="m-0 text-sm font-medium text-slate-500">Select a person directly from Employee Master.</p></div></div><button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button></div>
            <form id="recordAdvanceForm"><input type="hidden" name="action" value="create_payroll_advance"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="modal-body bg-slate-50/70 !px-4 !py-4"><div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div><label class="mb-1 block text-sm font-medium text-slate-800" for="advancePartyType">Employee Master List <strong class="text-rose-500">*</strong></label><select class="input-theme" id="advancePartyType" name="payroll_party_type" required><option value="">Select Workers or Employees</option><option value="worker">Workers</option><option value="employee">Employees</option></select></div>
                    <div><label class="mb-1 block text-sm font-medium text-slate-800" for="advanceEmployee">Employee Name <strong class="text-rose-500">*</strong></label><select class="input-theme select2" id="advanceEmployee" name="employee_id" required disabled><option value="">Select employee name</option><?php foreach($advancePeople as $person):?><option value="<?=(int)$person['id']?>" data-party-type="<?=(int)$person['emp_categ_type']===1?'worker':'employee'?>"><?=htmlspecialchars('('.$person['emp_code'].') '.trim($person['first_name'].' '.$person['last_name']))?></option><?php endforeach;?></select></div>
                    <div><label class="mb-1 block text-sm font-medium text-slate-800" for="advanceAmount">Amount <strong class="text-rose-500">*</strong></label><input class="input-theme" type="number" id="advanceAmount" name="amount" min="0.01" step="0.01" placeholder="Enter advance amount" required></div>
                    <div><label class="mb-1 block text-sm font-medium text-slate-800" for="advanceDate">Date <strong class="text-rose-500">*</strong></label><input class="input-theme" type="date" id="advanceDate" name="issued_on" value="<?=date('Y-m-d')?>" required></div>
                    <div class="md:col-span-2"><label class="mb-1 block text-sm font-medium text-slate-800" for="advancePaymentMode">Mode of Payment <strong class="text-rose-500">*</strong></label><select class="input-theme" id="advancePaymentMode" name="payment_mode" required><option value="">Select payment mode</option><option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option><option value="cheque">Cheque</option><option value="upi">UPI</option><option value="other">Other</option></select></div>
                    <div class="md:col-span-2"><label class="mb-1 block text-sm font-medium text-slate-800" for="advanceReason">Reason <strong class="text-rose-500">*</strong></label><textarea class="input-theme min-h-[80px]" id="advanceReason" name="reason" placeholder="Enter reason for the advance salary" maxlength="255" required></textarea></div>
                </div></div>
                <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3"><button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm" data-bs-dismiss="modal">Close</button><button type="submit" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm"><i class="ti ti-check text-lg"></i> Submit</button></div>
            </form>
        </div></div>
    </div>
<?php endif; ?>
</div>

<?php if ($canViewAdvances && payrollSchemaReady($conn)): startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const type = document.getElementById('advancePartyType');
    const employee = document.getElementById('advanceEmployee');
    const allOptions = [...employee.querySelectorAll('option[data-party-type]')].map(option => ({
        value: option.value,
        text: option.textContent,
        type: option.dataset.partyType
    }));

    function initOrRefreshSelect2() {
        if (window.jQuery && jQuery.fn.select2) {
            const $emp = jQuery(employee);
            if ($emp.hasClass('select2-hidden-accessible')) {
                $emp.select2('destroy');
            }
            $emp.select2({
                dropdownParent: jQuery('#recordAdvanceModal'),
                width: '100%',
                placeholder: 'Select employee name'
            });
        }
    }

    function syncEmployeeOptions() {
        const selectedType = type.value || (window.jQuery ? jQuery(type).val() : '') || '';
        const matching = selectedType ? allOptions.filter(opt => opt.type === selectedType) : [];
        let html = '<option value="">Select employee name</option>';
        matching.forEach(opt => {
            html += `<option value="${opt.value}" data-party-type="${opt.type}">${escapeHtml(opt.text)}</option>`;
        });
        employee.innerHTML = html;
        employee.disabled = !selectedType;
        initOrRefreshSelect2();
        if (window.jQuery) {
            jQuery(employee).prop('disabled',!type.value).trigger('change');
        }
    }

    if (window.jQuery) {
        jQuery(type).on('change change.select2 select2:select', syncEmployeeOptions);
        jQuery('#recordAdvanceModal').on('shown.bs.modal', function () {
            initOrRefreshSelect2();
        });
    }
    type?.addEventListener('change', syncEmployeeOptions);

    const notify = (kind, message) => window.toastr ? toastr[kind](message) : alert(message);
    const form = document.getElementById('recordAdvanceForm');
    form?.addEventListener('submit', async event => {
        event.preventDefault();
        const button = form.querySelector('[type="submit"]');
        button.disabled = true;
        try {
            const response = await fetch('payroll-api.php', {
                method: 'POST',
                body: new FormData(form),
                credentials: 'same-origin'
            });
            const data = await response.json().catch(() => ({ status: 'error', message: 'Invalid response.' }));
            if (!response.ok || data.status !== 'success') throw new Error(data.message || 'Unable to record advance.');
            notify('success', data.message);
            window.location.reload();
        } catch (error) {
            notify('error', error.message);
            button.disabled = false;
        }
    });

    document.getElementById('advanceSearch')?.addEventListener('input', event => {
        const needle = event.target.value.trim().toLowerCase();
        document.querySelectorAll('.advance-row').forEach(row => {
            row.classList.toggle('d-none', needle && !row.textContent.toLowerCase().includes(needle));
        });
    });

    function escapeHtml(value) {
        const node = document.createElement('div');
        node.textContent = value ?? '';
        return node.innerHTML;
    }

    syncEmployeeOptions();
});
</script>
<?php endSection(); endif; ?>
