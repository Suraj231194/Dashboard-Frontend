<div class="container-xxl container-p-y">
    <div class="row my-4">
        <div class="col">
            <div class="accordion" id="collapsibleBomSettingsSection">
                <div class="card accordion-item ">
                    <h2 class="accordion-header" id="headingInstitutionsOptions">
                        <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseBomOptions" aria-expanded="false" aria-controls="collapseBomOptions">
                            Template Designer Header & Footer
                        </button>
                    </h2>
                    <div id="collapseBomOptions" class="accordion-collapse collapse" aria-labelledby="headingInstitutionsOptions" data-bs-parent="#collapsibleBomSettingsSection">
                        <div class="accordion-body">
                            <div class="row col-md-12">
                                <div class="p-3">
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row col-md-12">
        <div class="card">            
            <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                <div class="d-flex align-items-center gap-2">
                    <label for="perPageSelect" class="mb-0">Show</label>
                    <select id="perPageSelect" class="form-select form-select-sm w-auto">
                        <option value="5">5</option>
                        <option value="10" selected>10</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                        <option value="500">500</option>
                        <option value="1000">1000</option>
                    </select>
                    <span>entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <input type="text" id="searchData" class="form-control form-control-sm" placeholder="Search Data...">
                    <?php if (roleHasPermission($_SESSION['role_id'], 'hr_advance_salary_add')) { ?>
                        <button type="button" class="btn btn-sm w-50 btn-success" data-bs-toggle="modal" data-bs-target="#employeeAdvancePayModal">Add New</button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr class="text-nowrap">
                            <th class="border-b border-slate-200 px-6 py-3">#</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Timestamp">Timestamp</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Product Name"> Product Name</th>
                            <th class="sortable border-b border-slate-200 px-6 py-3" data-column="u.name" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Template Name"> Template Name</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Header">Header</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Footer">Footer</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-column="r.name" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Created By">Created By</th>
                            <th class="border-b border-slate-200 px-6 py-3">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white" id="advanceSalaryTableBody">
                    </tbody>
                </table>
            </div>

            <div class="demo-inline-spacing">
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="employeeAdvancePayModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Template</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>                
                <form id="bmrTemplateCreateForm">
                    <div class="modal-body"> 
                        <div class="row">
                            <div class="col-md-4">
                                <h5>Template Details</h5>
                                <input class="form-control mb-2" id="product_name" name="product_name" placeholder="Product Name">
                                <input class="form-control mb-2" id="template_name" name="template_name" placeholder="Template Name">
                            </div>
                            <div class="col-md-5">
                                <h5>Add Section</h5>
                                <input class="form-control mb-2" id="section_title" placeholder="Section Title">

                                <select class="form-control mb-2" id="section_type">
                                    <option value="">Select</option>
                                    <option value="1">Normal Block</option>
                                    <option value="2">Table</option>
                                    <option value="3">Static Text</option>
                                </select>
                                <input type="number" class="form-control mb-2" id="page_no" placeholder="Page No">
                            </div>
                            <div class="col-md-3">
                                <button class="btn btn-primary" type="button" id="addSectionBtn">Add Section</button>
                            </div>
                        </div>

                        <div id="sectionList"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">FINAL SAVE TEMPLATE</button>
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="bmrPreviewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">BMR Template Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="bmrPreviewBody">    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
</div>



<?php startSection('scripts'); ?>
<script src="<?= asset('assets/vendor/libs/sortablejs/sortable.js') ?>"></script>
<script>
    let sectionIndex = 0;
    let currentPage = 1;
    let currentSortColumn = 'u.name';
    let currentSortDirection = 'ASC';


    function loadBmrTemplateTable(page = 1) {
        currentPage = page;
        const search = $('#searchData').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadBmrTemplates: 'loadBmrTemplates',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function(response) {                
                $('#advanceSalaryTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function() {
                $('#advanceSalaryTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }  

    function addSection() {

        let title = $('#section_title').val().trim();
        let type = $('#section_type').val();
        let pageNo = $('#page_no').val();
        let html = ``;

        if (title === '') {
            toastr.error('Section Title Required');
            return;
        }

        if (type === '') {
            toastr.error('Section Type Required');
            return;
        }

        if (pageNo === '' || isNaN(pageNo) || pageNo <= 0) {
            toastr.error('Valid Page Number Required');
            return;
        }

        
        html = `
            <div class="card p-3 mb-3 section-card" id="section_${sectionIndex}">
                <input type="hidden" name="sections[${sectionIndex}][title]" value="${title}">
                <input type="hidden" name="sections[${sectionIndex}][type]" value="${type}">
                <input type="hidden" name="sections[${sectionIndex}][page_no]" value="${pageNo}">
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-2">
                    <div class="d-flex align-items-center gap-2">
                        <span class="ti ti-grip-vertical section-handle-move cursor-move"></span>
                        <b>${title} | Page ${pageNo}</b>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        ${type==1 ? `<button type="button" class="btn btn-info btn-sm" onclick="addFieldRow(${sectionIndex})"> Add Field </button>`:''}
                        ${type==2 ? `<button type="button" class="btn btn-warning btn-sm" onclick="addTableRow(${sectionIndex})"> Add Row </button>`:''}
                        ${type==3 ? `<button type="button" class="btn btn-secondary btn-sm" onclick="addStaticParagraph(${sectionIndex})"> Add Para </button>`:''}  

                        <button type="button" class="btn btn-icon btn-label-danger btn-sm" onclick="removeSection(${sectionIndex})"> <span class="ti ti-trash"></span> </button>
                    </div>
                </div>
                <div id="field_area_${sectionIndex}"></div>
            </div>`;
        $('#sectionList').append(html);
        enableChildDrag(sectionIndex);
        sectionIndex++;
        $('#section_title').val('');
        $('#section_type').val('');
        $('#page_no').val('');
    }

    function addFieldRow(i) {
        let count = $('#field_area_' + i + ' .field-row').length;
        let html = `
        <div class="row field-row align-items-center mb-2 border rounded p-1" data-index="${count}">            
            <div class="col-md-1 col-6 mb-1">
                <span class="ti ti-grip-vertical cursor-move section-child-move"></span>
                <button type="button" class="btn btn-icon btn-label-danger" onclick="removeFieldRow(this,${i})"> 
                    <span class="ti ti-trash"></span>
                </button>
            </div>
            <div class="col-md-3 col-12 mb-1">
                <input name="sections[${i}][fields][${count}][label]" 
                class="form-control" placeholder="Label">
            </div>
            <div class="col-md-3 col-12 mb-1">
                <input name="sections[${i}][fields][${count}][key]" 
                class="form-control" placeholder="Key">
            </div>
            <div class="col-md-2 col-6 mb-1">
                <select name="sections[${i}][fields][${count}][type]" 
                class="form-control">
                    <option value="1">Text</option>
                    <option value="2">Number</option>
                    <option value="3">Date</option>
                    <option value="4">Time</option>
                    <option value="5">Textarea</option>
                </select>
            </div>
            <div class="col-md-2 col-6 mb-1">
                <select name="sections[${i}][fields][${count}][required]" 
                class="form-control">
                    <option value="0">Optional</option>
                    <option value="1">Required</option>
                </select>
            </div>            
        </div>`;
        $('#field_area_' + i).append(html);
    }
    
    function addStaticParagraph(i) {
        // let count = $('#field_area_' + i + ' .field-row').length;
        let count = $('#field_area_' + i + ' textarea').length;
        let html = `
        <div class="row field-row align-items-start mb-2 border rounded p-2" data-index="${count}">            
            <div class="col-md-2 col-6 mb-1">
                <span class="ti ti-grip-vertical cursor-move section-child-move"></span>
                <button type="button" class="btn btn-icon btn-label-danger" onclick="removeFieldRow(this,${i})"> 
                    <span class="ti ti-trash"></span>
                </button>
            </div>
            <div class="col-md-10 col-12 mb-1">
                <textarea class="form-control" rows="1" name="sections[${i}][static][${count}][static_text]" placeholder="Static Content"></textarea>
            </div>            
        </div>`;
        $('#field_area_' + i).append(html);
    }

    function addTableRow(sectionId){
        let count = $('#field_area_'+sectionId+' .table-row').length;
        let html = `
        <div class="table-row border rounded p-2 mb-2" data-row="${count}">
            <input type="hidden" name="sections[${sectionId}][rows][${count}][row_index]" value="${count}" />
            <div class="d-flex mb-2">
                <span class="ti ti-grip-vertical cursor-move section-child-move"></span>
                <button type="button" class="btn btn-icon btn-label-danger ms-2"
                onclick="removeTableRow(this,${sectionId})">
                <span class="ti ti-trash"></span>
                </button>
            </div>
            <div class="cell-container" id="cell_area_${sectionId}_${count}"></div>

            <button type="button" class="btn btn-sm btn-primary mt-2"
            onclick="addCell(${sectionId},${count})">
            Add Cell
            </button>

        </div>`;
        $('#field_area_'+sectionId).append(html);        
        enableCellDrag(sectionId,count);
    }

    function addCell(sectionId,rowId){
        let count = $('#cell_area_'+sectionId+'_'+rowId+' .table-cell').length;

        let html = `
        <div class="row table-cell mb-1">
            <div class="col-md-1">
                <span class="ti ti-grip-vertical table-cell-move cursor-move"></span>
            
                <button type="button" class="btn btn-sm btn-danger" onclick="removeCell(this,${sectionId})">
                ×
                </button>
            </div>

            <div class="col-md-2">
                <select name="sections[${sectionId}][rows][${rowId}][cells][${count}][type]" class="form-control cell-type">
                    <option value="1">Label</option>
                    <option value="3">Static Value</option>
                    <option value="2">User Input</option>
                </select>
            </div>

            <div class="col-md-3">
                <input class="form-control"
                name="sections[${sectionId}][rows][${rowId}][cells][${count}][label]"
                placeholder="Label / Static value">
            </div>

            <div class="col-md-2">
                <input class="form-control cell-key"
                name="sections[${sectionId}][rows][${rowId}][cells][${count}][key]"
                placeholder="Field Key">
            </div>

            <div class="col-md-2">
                <input class="form-control"
                name="sections[${sectionId}][rows][${rowId}][cells][${count}][colspan]"
                value="1"
                placeholder="Colspan">
            </div>

            <div class="col-md-2">
                <input class="form-control"
                name="sections[${sectionId}][rows][${rowId}][cells][${count}][rowspan]"
                value="1"
                placeholder="Rowspan">
            </div>

        </div>`;

        $('#cell_area_'+sectionId+'_'+rowId).append(html);
    }

    function removeSection(i) {
        $('#section_' + i).remove();
        reindexSections(); 
    }

    function removeCell(btn,sectionId){
        $(btn).closest('.table-cell').remove();
        reindexFields(sectionId);
    }

    function enableCellDrag(sectionId,rowId){
        new Sortable(
            document.getElementById('cell_area_'+sectionId+'_'+rowId),
            {
                animation:150,
                ghostClass:'bg-light',
                handle:'.table-cell-move',
                onEnd:function(){
                    reindexFields(sectionId);
                }
            }
        );
    }

    function enableChildDrag(sectionId){
        new Sortable(
            document.getElementById('field_area_'+sectionId),
            {
                animation:150,
                ghostClass:'bg-light',
                handle:'.section-child-move',
                onEnd:function(){
                    reindexFields(sectionId);
                }
            }
        );
    }
    
    function reindexFields(sectionId){
        $('#field_area_'+sectionId+' .table-row').each(function(rowIndex){
            $(this).attr('data-row',rowIndex);
            $(this).find('.cell-container').attr('id','cell_area_'+sectionId+'_'+rowIndex);
            enableCellDrag(sectionId,rowIndex);
            $(this).find('button.btn-primary').attr('onclick','addCell('+sectionId+','+rowIndex+')');
            $(this).find('.table-cell').each(function(cellIndex){
                $(this).find('input,select').each(function(){
                    let name = $(this).attr('name');
                    if(name){
                        name = name.replace(/\[rows\]\[\d+\]/,'[rows]['+rowIndex+']');
                        name = name.replace(/\[cells\]\[\d+\]/,'[cells]['+cellIndex+']');
                        $(this).attr('name',name);
                    }
                });
            });
        });
    }

    function removeFieldRow(btn,sectionId){
        $(btn).closest('.field-row').remove();
        reindexFields(sectionId);
    }

    function removeTableRow(btn,sectionId){
        $(btn).closest('.table-row').remove();
        reindexFields(sectionId);
    }

    function reindexSections(){
        $('#sectionList .section-card').each(function(index){
            $(this).attr('id','section_'+index);
            $(this).find('input, textarea, select').each(function(){
                let name = $(this).attr('name');
                if(name){
                    name = name.replace(/sections\[\d+\]/,'sections['+index+']');
                    $(this).attr('name',name);
                }
            });
            $(this).find('[onclick]').each(function(){
                let onclick = $(this).attr('onclick');
                if(onclick){
                    onclick = onclick.replace(/\(\d+\)/,'('+index+')');
                    $(this).attr('onclick',onclick);
                }
            });
        });
    }

    $(document).on('click',"#addSectionBtn", function(e) {
        e.preventDefault();
        addSection();
    });
    $(document).ready(function() {
        // showPreview(2);
        loadBmrTemplateTable();
        new Sortable(document.getElementById('sectionList'), {
            animation:150,
            ghostClass:'bg-light',
            handle:'.section-handle-move',
            onEnd:function(){
                reindexSections();
            }
        });

      

        $("#bmrTemplateCreateForm").on('submit', function(e) {
            e.preventDefault();
            let form = document.getElementById('bmrTemplateCreateForm');
            let formData = new FormData(form);
            formData.append('saveBmrTemplate', 'saveBmrTemplate');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        $('#bmrTemplateCreateForm')[0].reset();
                        $('#sectionList').html('');
                        sectionIndex = 0; 
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function() {
                    toastr.error('Server Error');
                }
            });
        });
    });

    $(document).on('change','.cell-type',function(){
        let row = $(this).closest('.table-cell');
        let type = $(this).val();
        if(type == 2){
            row.find('.cell-key').prop('disabled',false);
        }else{
            row.find('.cell-key').prop('disabled',true);
        }
    });

    function showPreview(template_id) {
        $.post("ajax.php", {
            previewBMRTemplate: 1,
            template_id: template_id
        },
        function(res) {
            $("#bmrPreviewBody").html(res);
            $("#bmrPreviewModal").modal("show");
        });
    }
</script>
<?php endSection(); ?>
