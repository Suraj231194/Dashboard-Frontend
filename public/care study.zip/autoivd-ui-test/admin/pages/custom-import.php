<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="w-full max-w-5xl">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="px-6 py-4">Name</th>                                                    
                            <th class="px-6 py-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 bg-white">
                        <tr class="transition-colors hover:bg-slate-50/50">
                            <td class="px-6 py-4 font-medium text-slate-700">Import Employees</td>
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center justify-end gap-2">
                                    <a href="" target="_blank" class="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-indigo-50 px-4 text-sm font-bold text-indigo-600 transition-colors hover:bg-indigo-100">
                                        <i class="ti ti-download"></i> Download Sample
                                    </a>
                                    <button type="button" class="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-emerald-50 px-4 text-sm font-bold text-emerald-600 transition-colors hover:bg-emerald-100" data-bs-toggle="modal" data-bs-target="#animationModal">
                                        <i class="ti ti-file-import"></i> Import
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <tr class="transition-colors hover:bg-slate-50/50">
                            <td class="px-6 py-4 font-medium text-slate-700">Import Employee Salary</td>
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center justify-end gap-2">
                                    <a href="<?php echo APP_URL.'admin/import_samples/employee_salary_sample.xlsx';?>" target="_blank" download="employee_salary_sample.xlsx" class="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-indigo-50 px-4 text-sm font-bold text-indigo-600 transition-colors hover:bg-indigo-100">
                                        <i class="ti ti-download"></i> Download Sample
                                    </a>                               
                                    <button type="button" class="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-emerald-50 px-4 text-sm font-bold text-emerald-600 transition-colors hover:bg-emerald-100" data-bs-toggle="modal" data-bs-target="#employeeSalaryModal">
                                        <i class="ti ti-file-import"></i> Import
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-xl">
                <div class="modal-header border-b border-slate-100 bg-slate-50/50 px-6 py-4">
                    <h5 class="modal-title font-bold text-slate-800" id="exampleModalLabel5">Import Employees</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="importEmployees" enctype="multipart/form-data">
                    <div class="modal-body px-6 py-6">
                        <div class="mb-3">
                            <label for="fileUploadEmployee" class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Upload Excel File</label>
                            <input type="file" id="fileUploadEmployee" autocomplete="off" name="fileUploadEmployee" class="form-control rounded-xl border-slate-200" required />
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-4">
                        <button type="button" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-600 transition-colors hover:bg-slate-50" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white transition-colors hover:bg-indigo-700 shadow-sm">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="employeeSalaryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-xl">
                <div class="modal-header border-b border-slate-100 bg-slate-50/50 px-6 py-4">
                    <h5 class="modal-title font-bold text-slate-800" id="exampleModalLabel5">Import Employee Salary</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="importEmployeesSalary" enctype="multipart/form-data">
                    <div class="modal-body px-6 py-6">
                        <div class="mb-3">
                            <label for="fileUploadEmployeeSalary" class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Upload Excel File</label>
                            <input type="file" id="fileUploadEmployeeSalary" autocomplete="off" name="fileUploadEmployeeSalary" class="form-control rounded-xl border-slate-200" required />
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-4">
                        <button type="button" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-600 transition-colors hover:bg-slate-50" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white transition-colors hover:bg-indigo-700 shadow-sm">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>

<?php startSection('scripts'); ?>
<script>
    // let currentPage = 1;

    // function loadPermissionsTable(page = 1) {
    //     currentPage = page;
    //     const search = $('#searchPermissions').val().trim();

    //     $.ajax({
    //         url: 'ajax.php',
    //         method: 'POST',
    //         data: {
    //             loadPermissions: 'loadPermissions',
    //             page: page,
    //             search: search
    //         },
    //         success: function(response) {
    //             const parts = response.split('|||');
    //             $('#permissionsTableBody').html(parts[0]);
    //             $('#paginationWrapper').html(parts[1] || '');
    //         },
    //         error: function() {
    //             $('#permissionsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
    //             $('#paginationWrapper').html('');
    //         }
    //     });
    // }

    $(document).ready(function () {
        // loadPermissionsTable();

        // $('#searchPermissions').on('input', function () {
        //     loadPermissionsTable(1);
        // });

        $('#importEmployees').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('importEmployees');
            const formData = new FormData(form);
            formData.append('importEmployeesFile', 'importEmployeesFile'); // Important flag for PHP

            $.ajax({
                url: 'importajax.php',
                type: 'POST',
                data: formData,
                contentType: false, 
                processData: false, 
                dataType: 'json', 
                success: function (response) {
                    if (response.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#importEmployees')[0].reset();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
        $('#importEmployeesSalary').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('importEmployeesSalary');
            const formData = new FormData(form);
            formData.append('importEmployeesSalaryFile', 'importEmployeesSalaryFile'); // Important flag for PHP

            $.ajax({
                url: 'importajax.php',
                type: 'POST',
                data: formData,
                contentType: false, 
                processData: false, 
                dataType: 'json', 
                success: function (response) {
                    if (response.status === 'success') {
                        $('#employeeSalaryModal').modal('hide');
                        $('#importEmployeesSalary')[0].reset();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });

 
    

    $(document).on('change', '#perPageSelect', function() { loadPermissionsTable(1); });
</script>
<?php endSection(); ?>
