<?php
require_once "../db.php";
require_once "../functions.php";
require_once "../constant.php";
if (!isset($_GET['id']) || empty($_GET['id'])) {
    exit("No ID provided.");
}

$purchaseOrderNum = base64_decrypt($_GET['id']);

// ================= FETCH PURCHASE ORDER HEADER =================
$sqlHeader = "SELECT po_order_num, vendor_name_po, created_at, currency_type,
                     shipment_branch_id, shipment_address_snapshot, shipment_gst_snapshot
              FROM `purchase_order_final` 
              WHERE `po_order_num` = ? 
              LIMIT 1";
$stmt = $conn->prepare($sqlHeader);
$stmt->bind_param('s', $purchaseOrderNum);
$stmt->execute();
$headerResult = $stmt->get_result();
$header = $headerResult->fetch_assoc();
$stmt->close();

if (!$header) {
    exit("No Purchase Order found.");
}

$companyBranding = mvGetCompanyBranding($conn);
$companyLogoPath = $companyBranding['letterhead_logo'] ?: ($companyBranding['logo'] ?: 'assets/img/logo3.jpeg');
$companyStampPath = $companyBranding['stamp'] ?: ($companyBranding['digital_signature'] ?: 'assets/img/stamp_logo.jpeg');
$companyLetterheadHeaderPath = $companyBranding['letterhead_header'];

// ================= FETCH PURCHASE ORDER ITEMS =================
$sqlItems = "SELECT material_name, pack_size, quantity_required, price_value
            FROM `purchase_order_final`
            WHERE `po_order_num` = ?";
$stmt2 = $conn->prepare($sqlItems);
$stmt2->bind_param('s', $purchaseOrderNum);
$stmt2->execute();
$itemsResult = $stmt2->get_result();
$items = $itemsResult->fetch_all(MYSQLI_ASSOC);
$stmt2->close();

// ---- Build PO Data ----
$row = [
    'po_order_num'  => $header['po_order_num'],
    'currency_type' => $header['currency_type'] ?? '1',
    'vendor'        => $header['vendor_name_po'],
    'created_at'    => formatDatePO($header['created_at']),
    'items'         => []
];

$serial = 1;
foreach ($items as $item) {
    $formattedPrice = ($item['price_value'] > 0) ? number_format($item['price_value'], 2, '.', ',') : '-';
    $row['items'][] = [
        "serial" => $serial++,
        "name"   => $item['material_name'],
        "pack"   => $item['pack_size'],
        "qty"    => number_format($item['quantity_required']),
        // "price"  => number_format($item['price_value'], 2)
        "price"  => $formattedPrice
    ];
}

$companyAddressHtml = !empty($companyBranding['registered_address'])
    ? nl2br(htmlspecialchars($companyBranding['registered_address'], ENT_QUOTES, 'UTF-8'))
    : htmlspecialchars($companyBranding['legal_name'], ENT_QUOTES, 'UTF-8');
if (!empty($companyBranding['gst_no'])) {
    $companyAddressHtml .= '<br>GSTN: ' . htmlspecialchars($companyBranding['gst_no'], ENT_QUOTES, 'UTF-8');
}
if (!empty($header['shipment_address_snapshot'])) {
    $companyAddressHtml = nl2br(htmlspecialchars($header['shipment_address_snapshot'], ENT_QUOTES, 'UTF-8'));
    if (!empty($header['shipment_gst_snapshot'])) {
        $companyAddressHtml .= '<br>GSTN: ' . htmlspecialchars($header['shipment_gst_snapshot'], ENT_QUOTES, 'UTF-8');
    }
} elseif (!empty($header['shipment_branch_id']) || !empty($_GET['branch_id'])) {
    $branchId = (int) ($_GET['branch_id'] ?? $header['shipment_branch_id']);
    $bStmt = $conn->prepare("SELECT branch_name, address, city, state, pincode, branch_gst_no FROM erp_branches WHERE id = ? AND deleted_at IS NULL LIMIT 1");
    $bStmt->bind_param("i", $branchId);
    $bStmt->execute();
    $bRes = $bStmt->get_result();
    if ($bRow = $bRes->fetch_assoc()) {
        $name    = htmlspecialchars($bRow['branch_name']);
        $address = htmlspecialchars($bRow['address'] ?? '');
        $city    = htmlspecialchars($bRow['city'] ?? '');
        $state   = htmlspecialchars($bRow['state'] ?? '');
        $pincode = htmlspecialchars($bRow['pincode'] ?? '');
        $gst     = htmlspecialchars($bRow['branch_gst_no'] ?? '');
        $companyAddressHtml = "<strong>$name</strong><br>";
        if ($address) $companyAddressHtml .= "$address<br>";
        if ($city || $state) $companyAddressHtml .= "$city" . ($city && $state ? ', ' : '') . "$state" . ($pincode ? '-' . $pincode : '') . "<br>";
        if ($gst) $companyAddressHtml .= "GSTN: $gst";
    }
    $bStmt->close();
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Purchase Order</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        .page {
            width: 100%;
            min-height: 1000px;
            /* ~A4 height in pixels at 96 DPI */
            padding: 15px;
            box-sizing: border-box;
            position: relative;
            page-break-after: always;
        }

        .page:last-child {
            page-break-after: auto;
        }

        table {
            page-break-inside: auto;
        }

        tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }

        thead {
            display: table-header-group;
            /* repeat table header on new page */
        }

        tfoot {
            display: table-footer-group;
        }
    </style>

</head>

<body style="margin: 0;">
    <div id="purchaseOrderFinalPdfContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php
        // Split products into chunks of 15
        $rowsPerPage = 12;
        $chunks = array_chunk($row['items'], $rowsPerPage);
        foreach ($chunks as $pageIndex => $pageProducts) {
            $realCount = count($pageProducts);
            // Calculate how many blank rows to add
            $emptyRows = $rowsPerPage - $realCount;
        ?>

            <div class="page" style="page-break-after: <?= ($pageIndex == array_key_last($chunks)) ? 'auto' : 'always' ?>;">
                <?php if ($companyLetterheadHeaderPath): ?>
                    <img src="<?php echo asset($companyLetterheadHeaderPath); ?>" alt="Company Letterhead" style="display:block; width:100%; max-height:90px; object-fit:contain; margin-bottom:10px;">
                <?php endif; ?>
                <!-- ===== HEADER ===== -->
                <div style="border: 1px solid #000; margin-bottom:10px;">
                    <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                        <tr>
                            <!-- Left side: Logo + Company Info -->
                            <td style="width: 30%; border-right: 1px solid #000; padding:0; vertical-align: top;">
                                <table style="width:100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="border-bottom: 1px solid #000; padding:5px;">
                                            <img src="<?php echo asset($companyLogoPath); ?>" alt="Company Logo" style="height: 60px; vertical-align: middle; padding-left:10px;">
                                            <div style="font-size:11px; font-weight:700; margin-top:5px;">
                                                CIN NO. <?php echo htmlspecialchars($companyBranding['cin_no'] ?: '-', ENT_QUOTES, 'UTF-8'); ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding:6px; font-size:12px; line-height:1.3;">
                                            <?php echo $companyAddressHtml; ?>
                                        </td>
                                    </tr>
                                </table>
                            </td>

                            <!-- Middle: Title -->
                            <td style="width: 30%; border-right: 1px solid #000; text-align:center; vertical-align: middle;">
                                <strong style="font-size:16px;">TITLE: Purchase Order</strong>
                            </td>

                            <!-- Right side: Document details -->
                            <td style="width: 40%; vertical-align: top; padding:0px;">
                                <table style="width: 100%; border-collapse: collapse; font-size:12px;">
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; width:50%; font-weight:700;">Document No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">BIPL-F-PO-01</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Issue No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">01</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Revision No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">02</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Effective Date</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">03/04/2025</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Review Date</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">02/04/2028</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Department</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">Purchase</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;padding:4px; font-weight:700;">Supersedes</td>
                                        <td style="padding:4px;">Nil</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ===== DOCUMENT INFO ===== -->
                <div style="padding: 15px;">
                    <table style="width: 100%; border-collapse: collapse; margin-top: 0px;">
                        <tr style="line-height: 30px;">
                            <td style="width: 65%"><?php echo $row['po_order_num']; ?></td>
                            <td style="width: 25%;">Date: <?php echo $row['created_at']; ?></td>
                        </tr>
                        <tr style="line-height: 30px;">
                            <td style="width: 65%;">To : <?php echo $row['vendor']; ?></td>
                            <td style="width: 25%;"></td>
                        </tr>
                    </table>
                </div>

                <!-- ===== PRODUCTS TABLE ===== -->
                <table style="border-collapse:collapse; width:100%; text-align:center; font-family:Arial, sans-serif; font-size:14px;">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr style="font-weight:bold;">
                            <th class="border-b border-slate-200 px-6 py-3" style="border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Serial #</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Material(s)</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Pack Size</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Quantity Req.</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">Price in <?php echo Constant::PURCHASE_MANAGEMENT['CURRENCY'][$row['currency_type']]['label']; ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pageProducts as $p): ?>
                            <tr>
                                <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px; text-align:center;"><?= $p['serial'] ?></td>
                                <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;"><?= $p['name'] ?></td>
                                <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px; text-align:center;"><?= $p['pack'] ?></td>
                                <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px; text-align:center;"><?= $p['qty'] ?></td>
                                <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;border-right:1px solid #000;  text-align:center;"><?= $p['price'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php for ($i = 0; $i < $emptyRows; $i++): ?>
                            <tr>
                                <td style="border:1px solid #fff; padding:6px; height:24px;">&nbsp;</td>
                                <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                                <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                                <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                                <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>

                <div style="margin-top:15px; font-family: Arial, sans-serif;">
                    <div style="font-size:14px; margin-bottom:10px;">Yours Sincerely,</div>
                    <div style="display:flex; align-items:flex-start;">
                        <img src="<?php echo asset($companyStampPath); ?>"
                            alt="Company Stamp"
                            style="height:80px; width:auto; display:block;" />
                        <div style="flex:1;"></div>
                    </div>
                    <div style="margin-top:12px; font-size:14px;">
                        <?php echo htmlspecialchars($companyBranding['legal_name']); ?>
                    </div>
                </div>

                <div style="margin-top:20px;">
                    <table style="width:100%; border:1px solid #000; border-collapse:collapse; text-align:left; padding: 15px;">
                        <tr>
                            <td style="width:50%; border:1px solid #000; padding:15px;">
                                <b>Format Prepared by :</b> MR/QA
                            </td>
                            <td style="width:50%; border:1px solid #000; padding:15px;">
                                <b>Format Approved by:</b> Head of the organization
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

        <?php } ?>
    </div>
</body>
<script>
    window.onload = function() {
        const element = document.getElementById("purchaseOrderFinalPdfContent");
        const opt = {
            margin: [0.2, 0.2, 0.2, 0.2], // top, right, bottom, left
            filename: '<?= !empty($fileName) ? $fileName : "PO_$purchaseOrderNum" ?>.pdf',
            image: {
                type: 'jpeg',
                quality: 0.98
            },
            html2canvas: {
                scale: 1.95
            },
            jsPDF: {
                unit: 'in',
                format: 'a4',
                orientation: 'portrait'
            }
        };

        html2pdf().set(opt).from(element).save().then(() => {
            console.log("PDF downloaded.");
            window.close();
        });
    };
</script>

</html>
