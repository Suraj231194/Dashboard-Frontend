<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage product categories for inventory</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="productCatPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="product-cat-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="product-cat-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="product-cat-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="product-cat-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="product-cat-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="product-cat-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchCategory"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'product_category_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-48 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal">
                            <i class="ti ti-plus text-lg"></i> <span class="whitespace-nowrap">Add New</span>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Name"> Name</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Slug"> Slug</th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>
                            <th class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="categoryTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- Modals -->
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add Product Category</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a new category</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addCategoryForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="mb-4">
                            <label for="categoryName" class="mb-1 block text-sm font-medium text-slate-800">Category Name <strong class="text-rose-500">*</strong></label>
                            <input type="text" id="categoryName" autocomplete="off" name="categoryName" class="input-theme" placeholder="Enter Category Name" required />
                            <div class="text-rose-500 mt-1 text-xs font-semibold" id="categoryError"></div>
                        </div>
                        <div class="mb-4">
                            <label class="flex cursor-pointer items-center gap-1.5 text-sm font-medium text-slate-700 whitespace-nowrap">
                                <input class="mt-0.5 h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600 requisition-checkbox" type="checkbox" id="webSync" name="webSync" value="1">
                                Website Sync
                            </label>                            
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="modal fade animate__animated fadeIn" id="editProductCategoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Edit Product Category</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update category details</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editCategoryForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                    <!-- Submit button is inside AJAX response -->
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;

    function loadCategoryTable(page = 1) {
        currentPage = page;
        const search = $('#searchCategory').val().trim();
        const perPage = $('#perPageSelect').val();
        
        $('#categoryTableBody').html('<tr><td colspan="4" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProductCategory: 'loadProductCategory',
                page: page,
                per_page: perPage,
                search: search
            },
            dataType: 'json',
            success: function(response) {
                $('#categoryTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function() {
                $('#categoryTableBody').html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    $(document).ready(function() {
        loadCategoryTable();
        $('#searchCategory').on('input', function() {
            loadCategoryTable(1);
        });

        $('#perPageSelect').on('change', function() {
            loadCategoryTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadCategoryTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.product-cat-per-page-item', function () {
            const val = $(this).data('val');
            $('#productCatPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addCategoryForm')[0].reset();
            $('#categoryError').text('');
        });

        $('#addCategoryForm').on('submit', function(e) {
            e.preventDefault();
            const categoryName = $('#categoryName').val().trim();
            const isWebSync = $('#webSync').is(':checked') ? 1 : 0;
            $('#categoryError').text('');

            if (categoryName === '') {
                $('#categoryError').text('Category name is required');
                return;
            }

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    addProductCategory: 'addProductCategory',
                    categoryName: categoryName,
                    isWebSync:isWebSync
                },
                success: function(res) {
                    if (res.status === 'error') {
                        $('#categoryError').text(res.message);
                        toastr.error(res.message);
                    } else if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#categoryName').val('');
                        loadCategoryTable();
                        toastr.success(res.message);
                    } else {
                        $('#categoryError').text(res.message);
                        toastr.error('Unexpected response.');
                    }
                }                
            });
        });

        $(document).on('click', '.deleteProductCategoryModalBtn', function() {
            let id = $(this).data('id');

            if (!id) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid ID',
                    text: 'Invalid user ID provided.',
                    customClass: {
                        confirmButton: 'btn btn-danger waves-effect waves-light'
                    }
                });
                return;
            }

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'ajax.php',
                        type: 'POST',
                        data: {
                            deleteProductCategoryRecord: 'deleteProductCategoryRecord',
                            id: id
                        },
                        dataType: 'json',
                        success: function(res) {
                            if (res.status === 'success') {
                                loadCategoryTable();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-success waves-effect waves-light'
                                    }
                                });
                            } else if (res.status === 'error') {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Failed!',
                                    text: res.message,
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Unexpected',
                                    text: 'Unexpected server response.',
                                    customClass: {
                                        confirmButton: 'btn btn-danger waves-effect waves-light'
                                    }
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Server Error',
                                text: error,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    });
                }
            });
        });

        $(document).on('click', '.editProductCategoryModalBtn', function() {
            let id = $(this).data('id');
            if (id) {
                $('#editCategoryForm').find('.modal-body').html('');
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        fetchProductCategoryRecord: 'fetchProductCategoryRecord',
                        id: id
                    },
                    success: function(response) {
                        let res;
                        try {
                            res = JSON.parse(response);
                        } catch (e) {
                            toastr.error('Invalid response from server.');
                            return;
                        }

                        if (res.status === 'success') {
                            $('#editProductCategoryModal').modal('show');
                            $('#editCategoryForm').find('.modal-body').html(res.data);
                        } else if (res.status === 'error') {
                            toastr.error(res.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                    },
                    error: function() {
                        toastr.error('Server error occurred.');
                    }
                });
            }
        });

        $('#editCategoryForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('editCategoryForm');
            const formData = new FormData(form);
            formData.append('updateProductCategory', 'updateProductCategory'); 
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, 
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editProductCategoryModal').modal('hide');
                        $('#editCategoryForm').find('.modal-body').html('');
                        loadCategoryTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });
</script>
<?php endSection(); ?>
