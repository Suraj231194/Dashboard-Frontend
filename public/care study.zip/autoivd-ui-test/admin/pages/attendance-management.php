<?php
if (!defined('HRMS_CONTEXT')) define('HRMS_CONTEXT', true);
require_once __DIR__ . '/../hrms/hrms_common.php';

$canViewAttendance = hrmsCan($conn, 'hrms_attendance_view');
$canMarkAttendance = hrmsCan($conn, 'hrms_attendance_mark');
$canManageAttendance = $canViewAttendance;
$canConfigureBiometrics = hrmsCan($conn, 'hrms_biometric_manage');
$canManageShifts = hrmsCan($conn, 'hrms_shift_manage');
$attendanceRows = [];
$attendanceDevices = [];
$attendanceCompanies = [];
$attendanceBranches = [];
$attendanceBranchOptions = [];
$attendanceDepartments = [];
$presentAttendanceRows = [];
$companiesWithEmployees = [];
$trendData = [];
$recentAttendees = [];
$chartLabels = [];
$chartOnTime = [];
$chartLate = [];
$chartAbsent = [];
$biometricPushReady = false;
$manualAttendanceReady = false;
$metrics = ['total' => 0, 'on_time' => 0, 'late' => 0, 'absent' => 0];
$selectedDate = $_GET['attendance_date'] ?? date('Y-m-d');
$dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $selectedDate);
if (!$dateObject || $dateObject->format('Y-m-d') !== $selectedDate) $selectedDate = date('Y-m-d');

if ($canManageAttendance) {
    $pushColumnCheck = $conn->query("SHOW COLUMNS FROM hr_biometric_devices LIKE 'ingest_token_hash'");
    $pushTableCheck = $conn->query("SHOW TABLES LIKE 'hr_biometric_ingest_batches'");
    $manualTableCheck = $conn->query("SHOW TABLES LIKE 'hr_attendance_manual_marks'");
    $biometricPushReady = $pushColumnCheck && $pushColumnCheck->num_rows === 1 && $pushTableCheck && $pushTableCheck->num_rows === 1;
    $manualAttendanceReady = $manualTableCheck && $manualTableCheck->num_rows === 1;
    $scope = hrmsCurrentScope($conn, (int) ($_SESSION['user_id'] ?? 0));
    $selectedCompany = filter_input(INPUT_GET, 'company_id', FILTER_VALIDATE_INT) ?: $scope['company_id'];
    $selectedBranch = filter_input(INPUT_GET, 'branch_id', FILTER_VALIDATE_INT) ?: $scope['branch_id'];
    if ($scope['company_id'] !== null) $selectedCompany = $scope['company_id'];
    if ($scope['branch_id'] !== null) $selectedBranch = $scope['branch_id'];

    $companySql = 'SELECT id, company_name FROM erp_companies WHERE status=1 AND deleted_at IS NULL';
    if ($scope['company_id'] !== null) $companySql .= ' AND id=' . (int)$scope['company_id'];
    $companySql .= ' ORDER BY company_name';
    $result = $conn->query($companySql);
    $attendanceCompanies = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

    if ($scope['company_id'] === null && $selectedCompany) {
        $validCompanyIds = array_map(static fn(array $company): int => (int) $company['id'], $attendanceCompanies);
        if (!in_array((int) $selectedCompany, $validCompanyIds, true)) $selectedCompany = null;
    }

    $branchSql = 'SELECT id,company_id,branch_name FROM erp_branches WHERE status=1 AND deleted_at IS NULL';
    if ($scope['company_id'] !== null) $branchSql .= ' AND company_id=' . (int)$scope['company_id'];
    if ($scope['branch_id'] !== null) $branchSql .= ' AND id=' . (int)$scope['branch_id'];
    $branchSql .= ' ORDER BY branch_name';
    $result = $conn->query($branchSql);
    $attendanceBranchOptions = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $attendanceBranches = array_values(array_filter($attendanceBranchOptions, static function (array $branch) use ($selectedCompany): bool {
        return !$selectedCompany || (int) $branch['company_id'] === (int) $selectedCompany;
    }));
    if ($selectedBranch) {
        $validBranchIds = array_map(static fn(array $branch): int => (int) $branch['id'], $attendanceBranches);
        if (!in_array((int) $selectedBranch, $validBranchIds, true)) $selectedBranch = null;
    }

    $deviceSql = 'SELECT device.*,company.company_name,branch.branch_name FROM hr_biometric_devices device LEFT JOIN erp_companies company ON company.id=device.company_id LEFT JOIN erp_branches branch ON branch.id=device.branch_id WHERE device.status=1';
    if ($selectedCompany) $deviceSql .= ' AND device.company_id=' . (int)$selectedCompany;
    if ($selectedBranch) $deviceSql .= ' AND device.branch_id=' . (int)$selectedBranch;
    $deviceSql .= ' ORDER BY device.device_name';
    $result = $conn->query($deviceSql);
    $attendanceDevices = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

    $employeeFilter = '';
    if ($selectedCompany) $employeeFilter .= ' AND COALESCE(profile.company_id,user.company_id,legacy_company.id)=' . (int)$selectedCompany;
    if ($selectedBranch) $employeeFilter .= ' AND COALESCE(profile.branch_id,user.branch_id)=' . (int)$selectedBranch;
    $totalResult = $conn->query("SELECT COUNT(*) total FROM employees employee LEFT JOIN users user ON user.id=employee.user_id LEFT JOIN hr_employee_profiles profile ON profile.employee_id=employee.id LEFT JOIN erp_companies legacy_company ON legacy_company.id=employee.company AND legacy_company.status=1 AND legacy_company.deleted_at IS NULL WHERE employee.status=1 AND employee.deleted_at IS NULL{$employeeFilter}");
    $metrics['total'] = (int)($totalResult->fetch_assoc()['total'] ?? 0);

    $dailySql = "SELECT daily.id, employee.id employee_id,
            COALESCE(daily.company_id,profile.company_id,user.company_id,legacy_company.id) company_id,
            COALESCE(daily.branch_id,profile.branch_id,user.branch_id) branch_id,
            ? attendance_date,daily.shift_id,daily.first_punch_at,daily.last_punch_at,
            COALESCE(daily.worked_minutes,0) worked_minutes,COALESCE(daily.late_minutes,0) late_minutes,
            COALESCE(daily.classification,'absent') classification,COALESCE(daily.source,'biometric') source,
            employee.emp_code,employee.first_name,employee.last_name,employee.emp_categ_type,
            designation.name designation_name,
            profile.department_id,department.name department_name,
            company.company_name,CONCAT_WS(' / ',company.company_name,branch.branch_name) branch_name,
            shift.name shift_name
        FROM employees employee
        LEFT JOIN users user ON user.id=employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id=employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id=employee.company AND legacy_company.status=1 AND legacy_company.deleted_at IS NULL
        LEFT JOIN hr_attendance_daily daily ON daily.employee_id=employee.id AND daily.attendance_date=?
        LEFT JOIN departments department ON department.id=profile.department_id
        LEFT JOIN designations designation ON designation.id=employee.designation_id
        LEFT JOIN erp_companies company ON company.id=COALESCE(daily.company_id,profile.company_id,user.company_id,legacy_company.id)
        LEFT JOIN erp_branches branch ON branch.id=COALESCE(daily.branch_id,profile.branch_id,user.branch_id)
        LEFT JOIN shifts shift ON shift.id=daily.shift_id
        WHERE employee.status=1 AND employee.deleted_at IS NULL";
    if ($selectedCompany) $dailySql .= ' AND COALESCE(daily.company_id,profile.company_id,user.company_id,legacy_company.id)=' . (int)$selectedCompany;
    if ($selectedBranch) $dailySql .= ' AND COALESCE(daily.branch_id,profile.branch_id,user.branch_id)=' . (int)$selectedBranch;
    $dailySql .= ' ORDER BY employee.first_name,employee.last_name';
    $stmt = $conn->prepare($dailySql);
    if ($stmt) {
        $stmt->bind_param('ss', $selectedDate, $selectedDate);
        $stmt->execute();
        $attendanceRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }

    foreach ($attendanceRows as $row) {
        if ($row['classification'] === 'on_time') $metrics['on_time']++;
        if ($row['classification'] === 'late') $metrics['late']++;
        if ($row['classification'] === 'absent') $metrics['absent']++;
        if (!empty($row['first_punch_at'])) {
            $presentAttendanceRows[] = $row;
            $recentAttendees[] = $row;
            if (!empty($row['department_id'])) $attendanceDepartments[(int)$row['department_id']] = $row['department_name'] ?: 'Unassigned';
        }
    }
    asort($attendanceDepartments, SORT_NATURAL | SORT_FLAG_CASE);
    if (!$attendanceRows) $metrics['absent'] = $metrics['total'];

    // Sort recent attendees by latest first punch
    usort($recentAttendees, static fn($a, $b) => strcmp((string)$b['first_punch_at'], (string)$a['first_punch_at']));
    $recentAttendees = array_slice($recentAttendees, 0, 8);

    // Query all companies from Company Control Room with respective employee lists
    $compEmployeesSql = "SELECT 
            company.id AS company_id, 
            company.company_name, 
            company.company_code,
            employee.id AS employee_id,
            employee.emp_code,
            employee.first_name,
            employee.last_name,
            employee.email,
            employee.contact_no,
            designation.name AS designation,
            employee.status AS employee_status,
            branch.branch_name,
            department.name AS department_name
        FROM erp_companies company
        LEFT JOIN (
            SELECT emp.*, 
                   COALESCE(p.company_id, u.company_id, lc.id) AS assigned_company_id,
                   COALESCE(p.branch_id, u.branch_id) AS assigned_branch_id,
                   p.department_id
            FROM employees emp
            LEFT JOIN users u ON u.id = emp.user_id AND u.deleted_at IS NULL
            LEFT JOIN hr_employee_profiles p ON p.employee_id = emp.id
            LEFT JOIN erp_companies lc ON lc.id = emp.company AND lc.status = 1 AND lc.deleted_at IS NULL
            WHERE emp.status = 1 AND emp.deleted_at IS NULL
        ) employee ON employee.assigned_company_id = company.id
        LEFT JOIN erp_branches branch ON branch.id = employee.assigned_branch_id
        LEFT JOIN departments department ON department.id = employee.department_id
        LEFT JOIN designations designation ON designation.id = employee.designation_id
        WHERE company.status = 1 AND company.deleted_at IS NULL
        ORDER BY company.company_name, employee.first_name, employee.last_name";
    $compRes = $conn->query($compEmployeesSql);
    if ($compRes) {
        while ($row = $compRes->fetch_assoc()) {
            $cid = (int)$row['company_id'];
            if (!isset($companiesWithEmployees[$cid])) {
                $companiesWithEmployees[$cid] = [
                    'id' => $cid,
                    'name' => $row['company_name'],
                    'code' => $row['company_code'] ?? '',
                    'employees' => [],
                ];
            }
            if (!empty($row['employee_id'])) {
                $companiesWithEmployees[$cid]['employees'][] = [
                    'id' => (int)$row['employee_id'],
                    'emp_code' => $row['emp_code'] ?: 'No ID',
                    'name' => trim($row['first_name'] . ' ' . $row['last_name']),
                    'designation' => $row['designation'] ?: 'Employee',
                    'department' => $row['department_name'] ?: 'General',
                    'branch' => $row['branch_name'] ?: 'Main Branch',
                    'status' => (int)$row['employee_status'],
                    'email' => $row['email'] ?: '',
                    'contact' => $row['contact_no'] ?: '',
                ];
            }
        }
    }

    // Generate trend data for Monthly Attendance Summary chart
    for ($i = 6; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days", strtotime($selectedDate)));
        $chartLabels[] = date('d M', strtotime($d));
        $dayOnTime = 0;
        $dayLate = 0;
        $dayAbsent = 0;
        if ($d === $selectedDate) {
            $dayOnTime = $metrics['on_time'];
            $dayLate = $metrics['late'];
            $dayAbsent = $metrics['absent'];
        } else {
            $pastSql = "SELECT classification, COUNT(*) c FROM hr_attendance_daily WHERE attendance_date = ?";
            $pastTypes = 's';
            $pastParams = [$d];
            if ($selectedCompany) {
                $pastSql .= ' AND company_id = ?';
                $pastTypes .= 'i';
                $pastParams[] = (int) $selectedCompany;
            }
            if ($selectedBranch) {
                $pastSql .= ' AND branch_id = ?';
                $pastTypes .= 'i';
                $pastParams[] = (int) $selectedBranch;
            }
            $pastSql .= ' GROUP BY classification';
            $stmtPast = $conn->prepare($pastSql);
            if ($stmtPast) {
                $stmtPast->bind_param($pastTypes, ...$pastParams);
                $stmtPast->execute();
                $pRes = $stmtPast->get_result()->fetch_all(MYSQLI_ASSOC);
                $stmtPast->close();
                foreach ($pRes as $p) {
                    if ($p['classification'] === 'on_time') $dayOnTime = (int)$p['c'];
                    if ($p['classification'] === 'late') $dayLate = (int)$p['c'];
                    if ($p['classification'] === 'absent') $dayAbsent = (int)$p['c'];
                }
            }
        }
        $chartOnTime[] = (int)$dayOnTime;
        $chartLate[] = (int)$dayLate;
        $chartAbsent[] = (int)$dayAbsent;
    }
}

$classificationStyle = static fn(string $value): string => match ($value) {
    'on_time' => 'bg-emerald-100 text-emerald-700',
    'late' => 'bg-amber-100 text-amber-700',
    'absent' => 'bg-rose-100 text-rose-700',
    'half_day' => 'bg-sky-100 text-sky-700',
    default => 'bg-slate-100 text-slate-600'
};
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
<?php if (!$canManageAttendance): ?>
    <div class="card border border-rose-200 bg-rose-50 rounded-2xl">
        <div class="card-body p-6 text-center text-rose-700">
            <i class="ti ti-lock fs-2 d-block mb-3"></i>You do not have permission to access biometric attendance.
        </div>
    </div>
<?php else: ?>

    <!-- Top Action Toolbar -->
    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-5 ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h2 class="mb-1 text-2xl fw-bold text-slate-900" style="font-family:'Sora',sans-serif">Attendance Management</h2>
            <p class="mb-0 text-sm text-slate-500">Biometric punches classified automatically by employee shift rules.</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <?php if ($canManageShifts): ?>
                <a href="index.php?page=shift-management" class="btn btn-outline-primary rounded-xl">
                    <i class="ti ti-clock-cog me-2"></i>Shift Management
                </a>
            <?php endif; ?>
            <?php if ($canConfigureBiometrics): ?>
                <button type="button" class="btn btn-outline-primary rounded-xl" data-bs-toggle="modal" data-bs-target="#biometricDeviceModal">
                    <i class="ti ti-device-desktop me-2"></i>Devices
                </button>
                <button type="button" class="btn btn-primary rounded-xl" data-bs-toggle="modal" data-bs-target="#biometricImportModal" <?= $attendanceDevices ? '' : 'disabled' ?>>
                    <i class="ti ti-upload me-2"></i>Import Punches
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Daily Attendance Summary Filter Header (Matching Reference Screenshot) -->
    <form class="card border border-slate-200 shadow-sm rounded-2xl mb-5 overflow-hidden" method="get" id="attendanceReportForm">
        <input type="hidden" name="page" value="attendance-management">
        <div class="card-header bg-slate-50/70 border-bottom border-slate-100 p-4 d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-2">
                <span class="rounded-lg bg-primary/10 text-primary p-2 d-flex align-items-center justify-content-center" style="width:32px;height:32px;">
                    <i class="ti ti-calendar-stats fs-5"></i>
                </span>
                <span class="fw-bold text-slate-800 fs-6">Daily Attendance Summary Report</span>
            </div>
            <span class="text-xs text-slate-400 font-monospace">Date: <?= htmlspecialchars(date('d M Y', strtotime($selectedDate))) ?></span>
        </div>
        <div class="card-body p-4">
            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label fw-bold text-xs text-uppercase text-slate-500">Date</label>
                    <input type="date" class="form-control rounded-xl" name="attendance_date" value="<?= htmlspecialchars($selectedDate) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold text-xs text-uppercase text-slate-500">Organization</label>
                    <select class="form-select rounded-xl" name="company_id" id="attendanceCompanyFilter">
                        <option value="">All organizations</option>
                        <?php foreach ($attendanceCompanies as $company): ?>
                            <option value="<?= (int)$company['id'] ?>" <?= (int)$company['id'] === (int)$selectedCompany ? 'selected' : '' ?>>
                                <?= htmlspecialchars($company['company_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold text-xs text-uppercase text-slate-500">Branch</label>
                    <select class="form-select rounded-xl" name="branch_id" id="attendanceBranchFilter">
                        <option value="">All branches</option>
                        <?php foreach ($attendanceBranches as $branch): ?>
                            <option value="<?= (int)$branch['id'] ?>" data-company-id="<?= (int)$branch['company_id'] ?>" <?= (int)$branch['id'] === (int)$selectedBranch ? 'selected' : '' ?>>
                                <?= htmlspecialchars($branch['branch_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary rounded-xl flex-grow-1 fw-bold" id="attendanceReportButton">
                        <i class="ti ti-filter me-1"></i>Generate Report
                    </button>
                    <?php if ($canConfigureBiometrics): ?>
                        <button type="button" class="btn btn-outline-primary rounded-xl" id="recalculateAttendance" title="Recalculate attendance">
                            <i class="ti ti-refresh"></i>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </form>

    <!-- Top 4 Vibrant Dashboard Parameter Cards (Exact Colors from Screenshot) -->
    <div class="row g-4 mb-6">
        <!-- 1. Total Employee Count (Solid Blue #1565C0) -->
        <div class="col-sm-6 col-xl-3">
            <button type="button" class="card w-100 h-100 text-start border-0 shadow-sm rounded-2xl p-0 overflow-hidden text-white transition-all metric-card active" 
                    data-filter="all" 
                    data-bs-toggle="modal" 
                    data-bs-target="#companyEmployeesModal"
                    style="background: linear-gradient(135deg, #1e88e5 0%, #1565c0 100%); cursor: pointer;">
                <div class="card-body p-4 position-relative">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="rounded-xl d-flex align-items-center justify-content-center" style="width:44px;height:44px; background: rgba(255,255,255,0.2);">
                            <i class="ti ti-building fs-3 text-white"></i>
                        </span>
                        <span class="badge rounded-pill text-xs fw-bold px-2.5 py-1" style="background: rgba(255,255,255,0.25); color: #fff;">
                            Control Room <i class="ti ti-arrow-right ms-1"></i>
                        </span>
                    </div>
                    <div class="text-4xl fw-bold text-white mb-1" style="font-family:'Sora',sans-serif;"><?= $metrics['total'] ?></div>
                    <div class="text-sm fw-medium text-white-50">Total Employees</div>
                    <div class="text-xs text-white-50 mt-2 border-top border-white-10 pt-2 d-flex align-items-center justify-content-between">
                        <span>Click for company-wise list</span>
                        <i class="ti ti-list-details"></i>
                    </div>
                </div>
            </button>
        </div>

        <!-- 2. Employees On Time (Solid Green #2E7D32) -->
        <div class="col-sm-6 col-xl-3">
            <button type="button" class="card w-100 h-100 text-start border-0 shadow-sm rounded-2xl p-0 overflow-hidden text-white transition-all metric-card" 
                    data-filter="on_time"
                    style="background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); cursor: pointer;">
                <div class="card-body p-4 position-relative">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="rounded-xl d-flex align-items-center justify-content-center" style="width:44px;height:44px; background: rgba(255,255,255,0.2);">
                            <i class="ti ti-clock-check fs-3 text-white"></i>
                        </span>
                        <span class="badge rounded-pill text-xs fw-bold px-2.5 py-1" style="background: rgba(255,255,255,0.25); color: #fff;">
                            Biometric In
                        </span>
                    </div>
                    <div class="text-4xl fw-bold text-white mb-1" style="font-family:'Sora',sans-serif;"><?= $metrics['on_time'] ?></div>
                    <div class="text-sm fw-medium text-white-50">On Time</div>
                    <div class="text-xs text-white-50 mt-2 border-top border-white-10 pt-2 d-flex align-items-center justify-content-between">
                        <span>Click to filter on-time arrivals</span>
                        <i class="ti ti-filter"></i>
                    </div>
                </div>
            </button>
        </div>

        <!-- 3. Employees Late (Solid Red #D32F2F) -->
        <div class="col-sm-6 col-xl-3">
            <button type="button" class="card w-100 h-100 text-start border-0 shadow-sm rounded-2xl p-0 overflow-hidden text-white transition-all metric-card" 
                    data-filter="late"
                    style="background: linear-gradient(135deg, #e53935 0%, #c62828 100%); cursor: pointer;">
                <div class="card-body p-4 position-relative">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="rounded-xl d-flex align-items-center justify-content-center" style="width:44px;height:44px; background: rgba(255,255,255,0.2);">
                            <i class="ti ti-clock-exclamation fs-3 text-white"></i>
                        </span>
                        <span class="badge rounded-pill text-xs fw-bold px-2.5 py-1" style="background: rgba(255,255,255,0.25); color: #fff;">
                            Grace Exceeded
                        </span>
                    </div>
                    <div class="text-4xl fw-bold text-white mb-1" style="font-family:'Sora',sans-serif;"><?= $metrics['late'] ?></div>
                    <div class="text-sm fw-medium text-white-50">Late</div>
                    <div class="text-xs text-white-50 mt-2 border-top border-white-10 pt-2 d-flex align-items-center justify-content-between">
                        <span>Click to filter late arrivals</span>
                        <i class="ti ti-filter"></i>
                    </div>
                </div>
            </button>
        </div>

        <!-- 4. Absentees (Solid Orange #EF6C00) -->
        <div class="col-sm-6 col-xl-3">
            <button type="button" class="card w-100 h-100 text-start border-0 shadow-sm rounded-2xl p-0 overflow-hidden text-white transition-all metric-card" 
                    data-filter="absent"
                    style="background: linear-gradient(135deg, #fb8c00 0%, #e65100 100%); cursor: pointer;">
                <div class="card-body p-4 position-relative">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="rounded-xl d-flex align-items-center justify-content-center" style="width:44px;height:44px; background: rgba(255,255,255,0.2);">
                            <i class="ti ti-user-x fs-3 text-white"></i>
                        </span>
                        <span class="badge rounded-pill text-xs fw-bold px-2.5 py-1" style="background: rgba(255,255,255,0.25); color: #fff;">
                            No Biometric Punch
                        </span>
                    </div>
                    <div class="text-4xl fw-bold text-white mb-1" style="font-family:'Sora',sans-serif;"><?= $metrics['absent'] ?></div>
                    <div class="text-sm fw-medium text-white-50">Absent</div>
                    <div class="text-xs text-white-50 mt-2 border-top border-white-10 pt-2 d-flex align-items-center justify-content-between">
                        <span>Click to filter absentees</span>
                        <i class="ti ti-filter"></i>
                    </div>
                </div>
            </button>
        </div>
    </div>

    <!-- Monthly Attendance Summary Chart & Recent Attendees (Matching Screenshot 2nd Row) -->
    <div class="row g-4 mb-6">
        <!-- Monthly Attendance Summary Chart -->
        <div class="col-lg-8">
            <div class="card border border-slate-200 shadow-sm rounded-2xl h-100 overflow-hidden">
                <div class="card-header bg-white border-bottom border-slate-100 p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h5 class="mb-0 fw-bold text-slate-900">Monthly Attendance Summary</h5>
                        <p class="mb-0 text-xs text-slate-400">7-Day Biometric Attendance Trend (On Time, Late, Absent)</p>
                    </div>
                    <div class="d-flex align-items-center gap-3 text-xs fw-semibold">
                        <span class="d-inline-flex align-items-center gap-1"><span class="rounded-circle d-inline-block" style="width:10px;height:10px;background:#2e7d32;"></span> On Time</span>
                        <span class="d-inline-flex align-items-center gap-1"><span class="rounded-circle d-inline-block" style="width:10px;height:10px;background:#e53935;"></span> Late</span>
                        <span class="d-inline-flex align-items-center gap-1"><span class="rounded-circle d-inline-block" style="width:10px;height:10px;background:#fb8c00;"></span> Absent</span>
                    </div>
                </div>
                <div class="card-body p-4">
                    <div style="height: 240px; position: relative;">
                        <canvas id="monthlyAttendanceChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Attendees Widget (Right Panel in Screenshot) -->
        <div class="col-lg-4">
            <div class="card border border-slate-200 shadow-sm rounded-2xl h-100 overflow-hidden">
                <div class="card-header bg-white border-bottom border-slate-100 p-4 d-flex align-items-center justify-content-between">
                    <h5 class="mb-0 fw-bold text-slate-900">Recent Attendees</h5>
                    <span class="badge bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-pill text-xs fw-bold px-2.5 py-1">
                        <?= count($recentAttendees) ?> Punched In
                    </span>
                </div>
                <div class="card-body p-3" style="max-height: 270px; overflow-y: auto;">
                    <?php if (!$recentAttendees): ?>
                        <div class="text-center py-6 text-slate-400 text-sm">
                            <i class="ti ti-fingerprint-off fs-2 d-block mb-2 text-slate-300"></i>
                            No biometric punches recorded for this date.
                        </div>
                    <?php else: ?>
                        <div class="row g-2">
                            <?php foreach ($recentAttendees as $attendee): ?>
                                <div class="col-6">
                                    <div class="p-2.5 rounded-xl border border-slate-100 bg-slate-50/60 d-flex flex-column align-items-center text-center position-relative">
                                        <div class="position-relative mb-1.5">
                                            <div class="rounded-circle bg-slate-200 text-slate-700 fw-bold d-flex align-items-center justify-content-center text-xs shadow-2xs" style="width:44px;height:44px;">
                                                <?= htmlspecialchars(strtoupper(substr($attendee['first_name'], 0, 1) . substr($attendee['last_name'], 0, 1))) ?>
                                            </div>
                                            <span class="position-absolute bottom-0 end-0 rounded-circle bg-emerald-500 text-white d-flex align-items-center justify-content-center shadow-2xs" style="width:16px;height:16px; font-size:10px;">
                                                <i class="ti ti-check"></i>
                                            </span>
                                        </div>
                                        <div class="fw-bold text-slate-800 text-xs text-truncate w-100" title="<?= htmlspecialchars(trim($attendee['first_name'].' '.$attendee['last_name'])) ?>">
                                            <?= htmlspecialchars(trim($attendee['first_name'].' '.$attendee['last_name'])) ?>
                                        </div>
                                        <div class="text-slate-400 text-truncate w-100" style="font-size:10px;">
                                            <?= htmlspecialchars($attendee['designation_name'] ?: $attendee['department_name'] ?: 'Staff') ?>
                                        </div>
                                        <div class="text-emerald-700 fw-bold font-monospace mt-1" style="font-size:11px;">
                                            <?= htmlspecialchars(date('h:i A', strtotime($attendee['first_punch_at']))) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Biometric Attendance Records Detail Table -->
    <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6" id="attendanceDetailCard">
        <div class="card-header bg-white border-bottom border-slate-100 p-4 px-5 d-flex flex-column flex-md-row justify-content-between gap-3 align-items-md-center">
            <div>
                <h5 class="mb-1 fw-bold text-slate-900">
                    <span id="activeFilterTitle">All Attendance Records</span> — <?= htmlspecialchars(date('d M Y', strtotime($selectedDate))) ?>
                </h5>
                <p class="mb-0 text-xs text-slate-500">Punches are derived from the biometric system; click any top parameter card to filter classifications.</p>
            </div>
            <div class="d-flex align-items-center gap-2">
                <button type="button" class="btn btn-sm btn-outline-secondary rounded-xl d-none" id="resetFilterBtn">
                    <i class="ti ti-x me-1"></i>Clear Filter
                </button>
                <div class="position-relative" style="max-width:280px;width:100%">
                    <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:12px"></i>
                    <input id="attendanceSearch" class="form-control form-control-sm rounded-xl ps-5" placeholder="Search employee or code">
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table align-middle mb-0" id="attendanceTable">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-5 py-3 text-xs text-uppercase text-slate-500">Employee</th>
                        <th class="py-3 text-xs text-uppercase text-slate-500">Department</th>
                        <th class="py-3 text-xs text-uppercase text-slate-500">Shift</th>
                        <th class="py-3 text-xs text-uppercase text-slate-500">First Punch (Time In)</th>
                        <th class="py-3 text-xs text-uppercase text-slate-500">Last Punch (Time Out)</th>
                        <th class="py-3 text-xs text-uppercase text-slate-500">Worked</th>
                        <th class="px-5 py-3 text-xs text-uppercase text-slate-500">Classification</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$attendanceRows): ?>
                        <tr class="empty-row">
                            <td colspan="7" class="text-center py-10 text-slate-500">
                                <i class="ti ti-calendar-off fs-1 d-block mb-2 text-slate-300"></i>
                                No calculated attendance exists for this date. Import punches or run recalculation.
                            </td>
                        </tr>
                    <?php else: foreach ($attendanceRows as $row): ?>
                        <tr class="attendance-row" data-classification="<?= htmlspecialchars($row['classification']) ?>">
                            <td class="px-5 py-4">
                                <div class="fw-bold text-slate-800"><?= htmlspecialchars(trim($row['first_name'] . ' ' . $row['last_name'])) ?></div>
                                <div class="text-xs text-slate-400 font-monospace"><?= htmlspecialchars($row['emp_code'] ?: 'No ID') ?> · <?= htmlspecialchars($row['branch_name'] ?: 'No branch') ?></div>
                            </td>
                            <td class="py-4 text-slate-600"><?= htmlspecialchars($row['department_name'] ?: 'Unassigned') ?></td>
                            <td class="py-4 text-slate-600"><?= htmlspecialchars($row['shift_name'] ?: 'No shift') ?></td>
                            <td class="py-4 fw-semibold text-slate-800 font-monospace">
                                <?= $row['first_punch_at'] ? '<i class="ti ti-login text-emerald-600 me-1"></i>' . htmlspecialchars(date('h:i A', strtotime($row['first_punch_at']))) : '<span class="text-slate-400">—</span>' ?>
                            </td>
                            <td class="py-4 fw-semibold text-slate-800 font-monospace">
                                <?= $row['last_punch_at'] ? '<i class="ti ti-logout text-slate-500 me-1"></i>' . htmlspecialchars(date('h:i A', strtotime($row['last_punch_at']))) : '<span class="text-slate-400">—</span>' ?>
                            </td>
                            <td class="py-4 text-slate-600 font-monospace"><?= intdiv((int)$row['worked_minutes'], 60) ?>h <?= ((int)$row['worked_minutes'] % 60) ?>m</td>
                            <td class="px-5 py-4">
                                <span class="badge rounded-pill <?= $classificationStyle($row['classification']) ?> px-3 py-1.5 fw-bold text-xs">
                                    <?= htmlspecialchars(ucwords(str_replace('_', ' ', $row['classification']))) ?>
                                </span>
                                <?php if ((int)$row['late_minutes'] > 0): ?>
                                    <div class="text-xs text-danger fw-semibold mt-1">
                                        <i class="ti ti-alert-triangle me-1"></i><?= (int)$row['late_minutes'] ?> min late
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Biometric Push & Management Sections -->
    <?php if ($canConfigureBiometrics && $biometricPushReady): ?>
        <section class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mt-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-5">
                <h5 class="mb-1 fw-bold text-slate-900">Biometric Push Integration</h5>
                <p class="mb-0 text-sm text-slate-500">Provision secure device access for automatic attendance events.</p>
            </div>
            <form id="biometricPushForm">
                <div class="card-body p-5">
                    <input type="hidden" name="action" value="configure_biometric_push">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    <div class="row g-4 align-items-end">
                        <div class="col-lg-4">
                            <label class="form-label fw-bold">Device *</label>
                            <select class="form-select rounded-xl" name="device_id" id="pushDevice" required>
                                <option value="">Select device</option>
                                <?php foreach ($attendanceDevices as $device): ?>
                                    <option value="<?= (int)$device['id'] ?>" data-enabled="<?= (int)($device['ingest_enabled'] ?? 0) ?>" data-rate="<?= (int)($device['ingest_rate_limit'] ?? 120) ?>">
                                        <?= htmlspecialchars($device['device_name'] . ' (' . $device['device_code'] . ')') ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-lg-3">
                            <label class="form-label fw-bold">Endpoint</label>
                            <input class="form-control rounded-xl font-monospace" value="biometric-push-api.php" readonly>
                        </div>
                        <div class="col-sm-6 col-lg-2">
                            <label class="form-label fw-bold">Requests / minute</label>
                            <input type="number" class="form-control rounded-xl" name="ingest_rate_limit" min="1" max="10000" value="120" required>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex flex-column gap-2">
                                <label class="form-check">
                                    <input class="form-check-input" type="checkbox" name="ingest_enabled" value="1">
                                    <span class="form-check-label">Enable push ingestion</span>
                                </label>
                                <label class="form-check">
                                    <input class="form-check-input" type="checkbox" name="rotate_token" value="1">
                                    <span class="form-check-label">Generate or rotate token</span>
                                </label>
                            </div>
                        </div>
                        <div class="col-12 d-flex justify-content-end">
                            <button class="btn btn-primary rounded-xl px-4"><i class="ti ti-key me-2"></i>Save Device Access</button>
                        </div>
                    </div>
                    <div id="biometricTokenResult" class="d-none rounded-xl border border-amber-200 bg-amber-50 p-4 mt-4">
                        <label class="form-label fw-bold text-amber-900">One-time bearer token</label>
                        <div class="input-group">
                            <input id="biometricTokenValue" class="form-control font-monospace" readonly>
                            <button class="btn btn-outline-secondary" type="button" id="copyBiometricToken" title="Copy token"><i class="ti ti-copy"></i></button>
                        </div>
                    </div>
                </div>
            </form>
        </section>
    <?php elseif ($canConfigureBiometrics): ?>
        <div class="alert alert-warning mt-6 mb-0">Biometric push integration becomes available after the Care IO completion migration is applied.</div>
    <?php endif; ?>

    <!-- Present Employee Marking -->
    <?php if ($canMarkAttendance && $manualAttendanceReady): ?>
        <section class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mt-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-5">
                <h5 class="mb-1 fw-bold text-slate-900">Present Employee Marking</h5>
                <p class="mb-0 text-sm text-slate-500">Only employees detected by the biometric system for the selected date are listed.</p>
            </div>
            <form id="presentAttendanceForm">
                <div class="card-body border-bottom border-slate-100 p-4">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Type</label>
                            <select class="form-select rounded-xl" id="presentTypeFilter">
                                <option value="">Workers and Employees</option>
                                <option value="1">Workers</option>
                                <option value="2">Employees</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Department</label>
                            <select class="form-select rounded-xl" id="presentDepartmentFilter">
                                <option value="">All departments</option>
                                <?php foreach ($attendanceDepartments as $departmentId => $departmentName): ?>
                                    <option value="<?= (int)$departmentId ?>"><?= htmlspecialchars($departmentName) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Mark selected as</label>
                            <select class="form-select rounded-xl" name="classification" required>
                                <option value="full_day">Full Day</option>
                                <option value="half_day">Half Day</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-5"><input type="checkbox" class="form-check-input" id="selectAllPresent" title="Select visible employees"></th>
                                <th>Employee</th>
                                <th>Department</th>
                                <th>First Punch</th>
                                <th>Last Punch</th>
                                <th>Worked</th>
                                <th class="px-5">Biometric Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$presentAttendanceRows): ?>
                                <tr><td colspan="7" class="text-center py-8 text-slate-500">No employees are present in biometric data for this date.</td></tr>
                            <?php else: foreach ($presentAttendanceRows as $row): ?>
                                <tr class="present-mark-row" data-type="<?= (int)$row['emp_categ_type'] ?>" data-department="<?= (int)($row['department_id'] ?? 0) ?>">
                                    <td class="px-5"><input type="checkbox" class="form-check-input present-employee-check" value="<?= (int)$row['employee_id'] ?>"></td>
                                    <td class="py-3">
                                        <div class="fw-bold text-slate-800"><?= htmlspecialchars(trim($row['first_name'] . ' ' . $row['last_name'])) ?></div>
                                        <small class="text-slate-400"><?= htmlspecialchars($row['emp_code'] ?: 'No ID') ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($row['department_name'] ?: 'Unassigned') ?></td>
                                    <td><?= htmlspecialchars(date('h:i A', strtotime($row['first_punch_at']))) ?></td>
                                    <td><?= htmlspecialchars($row['last_punch_at'] ? date('h:i A', strtotime($row['last_punch_at'])) : '—') ?></td>
                                    <td><?= number_format((int)$row['worked_minutes'] / 60, 2) ?> hrs</td>
                                    <td class="px-5"><span class="badge rounded-pill <?= $classificationStyle($row['classification']) ?>"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $row['classification']))) ?></span></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer bg-white border-top border-slate-100 p-4 d-flex justify-content-end">
                    <button class="btn btn-primary rounded-xl px-5" <?= $presentAttendanceRows ? '' : 'disabled' ?>>
                        <i class="ti ti-check me-2"></i>Submit Attendance
                    </button>
                </div>
            </form>
        </section>
    <?php endif; ?>

<?php endif; ?>
</div>

<!-- Modal 1: Total Employees by Company (Company Control Room Drilldown) -->
<div class="modal fade" id="companyEmployeesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content rounded-2xl border-0 shadow-lg">
            <div class="modal-header p-4 px-5 border-bottom border-slate-100 d-flex align-items-center justify-content-between" style="background: linear-gradient(135deg, #1e88e5 0%, #1565c0 100%); color:#fff;">
                <div class="d-flex align-items-center gap-3">
                    <span class="rounded-xl d-flex align-items-center justify-content-center" style="width:42px;height:42px; background: rgba(255,255,255,0.2);">
                        <i class="ti ti-building fs-3 text-white"></i>
                    </span>
                    <div>
                        <h5 class="modal-title fw-bold text-white mb-0">Total Employee Count by Company</h5>
                        <p class="mb-0 text-xs text-white-50">Companies registered in Company Control Room and their respective employee rosters</p>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4 px-5">
                <!-- Search within company modal -->
                <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-3 mb-4">
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-primary px-3 py-2 rounded-xl fw-bold text-sm">
                            Total Companies: <?= count($companiesWithEmployees) ?>
                        </span>
                        <span class="badge bg-slate-100 text-slate-700 px-3 py-2 rounded-xl fw-bold text-sm border border-slate-200">
                            Total Employees: <?= $metrics['total'] ?>
                        </span>
                    </div>
                    <div class="position-relative" style="max-width: 320px; width: 100%;">
                        <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left: 12px;"></i>
                        <input type="text" class="form-control form-control-sm rounded-xl ps-5" id="companyEmployeeSearch" placeholder="Search employee, ID, department...">
                    </div>
                </div>

                <!-- Company-Wise Accordion / Cards List -->
                <div class="accordion d-flex flex-column gap-3" id="companyEmployeesAccordion">
                    <?php if (!$companiesWithEmployees): ?>
                        <div class="text-center py-10 text-slate-500">
                            <i class="ti ti-building-off fs-1 text-slate-300 d-block mb-2"></i>
                            No companies found in the Company Control Room.
                        </div>
                    <?php else: foreach ($companiesWithEmployees as $compIndex => $companyData): ?>
                        <div class="accordion-item border border-slate-200 rounded-2xl overflow-hidden shadow-2xs company-accordion-card">
                            <h2 class="accordion-header" id="headingCompany<?= $companyData['id'] ?>">
                                <button class="accordion-button <?= $compIndex === 0 ? '' : 'collapsed' ?> p-4 bg-slate-50/70" type="button" data-company-collapse="#collapseCompany<?= $companyData['id'] ?>" aria-controls="collapseCompany<?= $companyData['id'] ?>" aria-expanded="<?= $compIndex === 0 ? 'true' : 'false' ?>">
                                    <div class="d-flex align-items-center justify-content-between w-100 pe-3">
                                        <div class="d-flex align-items-center gap-3">
                                            <span class="rounded-xl bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-6" style="width:38px;height:38px;">
                                                <?= htmlspecialchars(strtoupper(substr($companyData['name'], 0, 2))) ?>
                                            </span>
                                            <div>
                                                <div class="fw-bold text-slate-900 fs-6"><?= htmlspecialchars($companyData['name']) ?></div>
                                                <small class="text-slate-400 font-monospace"><?= htmlspecialchars($companyData['code'] ?: 'CODE: COMP-'.$companyData['id']) ?></small>
                                            </div>
                                        </div>
                                        <span class="badge rounded-pill bg-primary/10 text-primary border border-primary/20 px-3 py-1.5 text-xs fw-bold">
                                            <?= count($companyData['employees']) ?> Employees
                                        </span>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapseCompany<?= $companyData['id'] ?>" class="accordion-collapse collapse <?= $compIndex === 0 ? 'show' : '' ?>" data-bs-parent="#companyEmployeesAccordion">
                                <div class="accordion-body p-0">
                                    <div class="table-responsive">
                                        <table class="table align-middle mb-0 company-employee-table">
                                            <thead class="bg-slate-100/60">
                                                <tr>
                                                    <th class="px-4 py-2.5 text-xs text-uppercase text-slate-500">Employee</th>
                                                    <th class="py-2.5 text-xs text-uppercase text-slate-500">Department</th>
                                                    <th class="py-2.5 text-xs text-uppercase text-slate-500">Designation</th>
                                                    <th class="py-2.5 text-xs text-uppercase text-slate-500">Branch</th>
                                                    <th class="px-4 py-2.5 text-xs text-uppercase text-slate-500 text-end">Contact</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (!$companyData['employees']): ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center py-6 text-slate-400 text-sm">
                                                            No active employees registered under this company.
                                                        </td>
                                                    </tr>
                                                <?php else: foreach ($companyData['employees'] as $emp): ?>
                                                    <tr class="company-emp-row">
                                                        <td class="px-4 py-3">
                                                            <div class="fw-bold text-slate-800 text-sm"><?= htmlspecialchars($emp['name']) ?></div>
                                                            <span class="text-xs text-slate-400 font-monospace"><?= htmlspecialchars($emp['emp_code']) ?></span>
                                                        </td>
                                                        <td class="py-3 text-slate-600 text-sm"><?= htmlspecialchars($emp['department']) ?></td>
                                                        <td class="py-3 text-slate-600 text-sm"><?= htmlspecialchars($emp['designation']) ?></td>
                                                        <td class="py-3 text-slate-500 text-xs"><?= htmlspecialchars($emp['branch']) ?></td>
                                                        <td class="px-4 py-3 text-end text-xs text-slate-600 font-monospace">
                                                            <?= htmlspecialchars($emp['email'] ?: $emp['contact'] ?: '—') ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
            <div class="modal-footer p-4 border-top border-slate-100">
                <button type="button" class="btn btn-outline-secondary rounded-xl px-4" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2: Biometric Device Modal -->
<?php if ($canManageAttendance): ?>
<div class="modal fade" id="biometricDeviceModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-2xl border-0">
            <div class="modal-header p-5 border-bottom border-slate-100">
                <div>
                    <h5 class="modal-title fw-bold">Biometric Devices</h5>
                    <p class="mb-0 text-sm text-slate-500">Register the organization and branch source for punch events.</p>
                </div>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-5">
                <form id="biometricDeviceForm">
                    <input type="hidden" name="action" value="save_biometric_device">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Organization *</label>
                            <select class="form-select rounded-xl" name="company_id" required>
                                <?php foreach ($attendanceCompanies as $company): ?>
                                    <option value="<?= (int)$company['id'] ?>" <?= (int)$company['id'] === (int)$selectedCompany ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($company['company_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Branch *</label>
                            <select class="form-select rounded-xl" name="branch_id" required>
                                <?php foreach ($attendanceBranches as $branch): ?>
                                    <option value="<?= (int)$branch['id'] ?>" <?= (int)$branch['id'] === (int)$selectedBranch ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($branch['branch_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Device Code *</label>
                            <input class="form-control rounded-xl" name="device_code" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Device Name *</label>
                            <input class="form-control rounded-xl" name="device_name" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Vendor</label>
                            <input class="form-control rounded-xl" name="vendor">
                        </div>
                        <div class="col-12 text-end">
                            <button class="btn btn-primary rounded-xl">Save Device</button>
                        </div>
                    </div>
                </form>
                <hr class="my-5">
                <?php if (!$attendanceDevices): ?>
                    <div class="text-center text-slate-500">No devices configured.</div>
                <?php else: foreach ($attendanceDevices as $device): ?>
                    <div class="rounded-xl border border-slate-200 p-4 mb-3 d-flex justify-content-between">
                        <div>
                            <div class="fw-bold text-slate-800"><?= htmlspecialchars($device['device_name']) ?></div>
                            <div class="text-xs text-slate-500"><?= htmlspecialchars($device['device_code']) ?> · <?= htmlspecialchars($device['branch_name'] ?: 'All branches') ?></div>
                        </div>
                        <div class="text-xs text-slate-400">Last sync<br><?= htmlspecialchars($device['last_synced_at'] ?: 'Never') ?></div>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal 3: Biometric Import Modal -->
<div class="modal fade" id="biometricImportModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-2xl border-0">
            <div class="modal-header p-5 border-bottom border-slate-100">
                <div>
                    <h5 class="modal-title fw-bold">Import Biometric Punches</h5>
                    <p class="mb-0 text-sm text-slate-500">Vendor-neutral JSON import with duplicate event protection.</p>
                </div>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="biometricImportForm">
                <div class="modal-body p-5">
                    <input type="hidden" name="action" value="import_biometric_punches">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Device *</label>
                        <select class="form-select rounded-xl" name="device_id" required>
                            <?php foreach ($attendanceDevices as $device): ?>
                                <option value="<?= (int)$device['id'] ?>"><?= htmlspecialchars($device['device_name'] . ' (' . $device['device_code'] . ')') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label fw-bold">Punch Events JSON *</label>
                        <textarea class="form-control rounded-xl font-monospace" name="events" rows="12" required placeholder='[{"external_event_id":"EVT-001","employee_code":"EMP-00001","punch_time":"<?= date('Y-m-d') ?> 09:00:00","punch_type":"in"}]'></textarea>
                        <div class="form-text">Required fields: external_event_id, employee_code, punch_time, punch_type.</div>
                    </div>
                </div>
                <div class="modal-footer p-4 border-top border-slate-100">
                    <button type="button" class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary rounded-xl">Import & Calculate</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Chart.js CDN for Monthly Attendance Summary -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<?php startSection('scripts'); ?>
<style>
.metric-card {
    transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s ease, outline 0.2s ease;
}
.metric-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.15) !important;
}
.metric-card.active {
    outline: 3px solid #0f172a;
    outline-offset: 2px;
}
.font-monospace {
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace !important;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Ajax post helper
    const post = async form => {
        const response = await fetch('hrms-api.php', { method: 'POST', body: form, credentials: 'same-origin' });
        const data = await response.json().catch(() => ({ status: 'error', message: 'Invalid response.' }));
        if (!response.ok || data.status !== 'success') throw new Error(data.message || 'Request failed.');
        return data;
    };
    const notify = (type, message) => window.toastr ? toastr[type](message) : alert(message);

    const attendanceBranchOptions = <?= json_encode($attendanceBranchOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const companyFilter = document.getElementById('attendanceCompanyFilter');
    const branchFilter = document.getElementById('attendanceBranchFilter');
    const populateBranchFilter = () => {
        if (!branchFilter) return;
        const companyId = companyFilter?.value || '';
        const selectedBranchId = branchFilter.value;
        branchFilter.replaceChildren(new Option('All branches', ''));
        attendanceBranchOptions
            .filter(branch => !companyId || String(branch.company_id) === companyId)
            .forEach(branch => branchFilter.add(new Option(branch.branch_name, String(branch.id))));
        if ([...branchFilter.options].some(option => option.value === selectedBranchId)) {
            branchFilter.value = selectedBranchId;
        }
    };
    companyFilter?.addEventListener('change', populateBranchFilter);

    document.getElementById('attendanceReportForm')?.addEventListener('submit', () => {
        const button = document.getElementById('attendanceReportButton');
        if (!button) return;
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Generating...';
    });

    // Forms submission
    for (const id of ['biometricDeviceForm', 'biometricImportForm']) {
        document.getElementById(id)?.addEventListener('submit', async event => {
            event.preventDefault();
            try {
                const data = await post(new FormData(event.currentTarget));
                notify('success', data.message);
                location.reload();
            } catch (error) {
                notify('error', error.message);
            }
        });
    }

    // Recalculate attendance button
    document.getElementById('recalculateAttendance')?.addEventListener('click', async () => {
        const form = new FormData();
        form.set('action', 'recalculate_attendance');
        form.set('csrf_token', <?= json_encode($_SESSION['csrf_token']) ?>);
        form.set('attendance_date', <?= json_encode($selectedDate) ?>);
        form.set('company_id', <?= json_encode((string)($selectedCompany ?? '')) ?>);
        form.set('branch_id', <?= json_encode((string)($selectedBranch ?? '')) ?>);
        try {
            const data = await post(form);
            notify('success', data.message);
            location.reload();
        } catch (error) {
            notify('error', error.message);
        }
    });

    // Filtering Biometric Attendance Detail Table
    let currentMetric = 'all';
    let searchNeedle = '';
    const filterTitleEl = document.getElementById('activeFilterTitle');
    const resetBtn = document.getElementById('resetFilterBtn');

    const filterTable = () => {
        let visibleCount = 0;
        document.querySelectorAll('.attendance-row').forEach(row => {
            const matchesMetric = (currentMetric === 'all') || (row.dataset.classification === currentMetric);
            const matchesSearch = !searchNeedle || row.textContent.toLowerCase().includes(searchNeedle);
            const isVisible = matchesMetric && matchesSearch;
            row.classList.toggle('d-none', !isVisible);
            if (isVisible) visibleCount++;
        });

        if (resetBtn) resetBtn.classList.toggle('d-none', currentMetric === 'all' && !searchNeedle);
        if (filterTitleEl) {
            const titles = {
                all: 'All Attendance Records',
                on_time: 'Employees On Time',
                late: 'Employees Late',
                absent: 'Absentees'
            };
            filterTitleEl.textContent = titles[currentMetric] || 'Filtered Attendance Records';
        }
    };

    // Metric Cards Click Handlers
    document.querySelectorAll('.metric-card').forEach(card => {
        card.addEventListener('click', () => {
            const filterType = card.dataset.filter;
            if (filterType === 'all') {
                // If it's Total Employees, modal triggers via data-bs-toggle
                currentMetric = 'all';
            } else {
                currentMetric = filterType;
                // Scroll smoothly to detail table
                document.getElementById('attendanceDetailCard')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
            document.querySelectorAll('.metric-card').forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            filterTable();
        });
    });

    // Reset button
    resetBtn?.addEventListener('click', () => {
        currentMetric = 'all';
        searchNeedle = '';
        if (document.getElementById('attendanceSearch')) document.getElementById('attendanceSearch').value = '';
        document.querySelectorAll('.metric-card').forEach(c => c.classList.remove('active'));
        document.querySelector('.metric-card[data-filter="all"]')?.classList.add('active');
        filterTable();
    });

    // Search filter input
    document.getElementById('attendanceSearch')?.addEventListener('input', event => {
        searchNeedle = event.target.value.trim().toLowerCase();
        filterTable();
    });

    // Search within Company Employees Modal
    document.getElementById('companyEmployeeSearch')?.addEventListener('input', event => {
        const term = event.target.value.trim().toLowerCase();
        document.querySelectorAll('.company-accordion-card').forEach(card => {
            let hasVisibleEmp = false;
            card.querySelectorAll('.company-emp-row').forEach(row => {
                const match = !term || row.textContent.toLowerCase().includes(term);
                row.classList.toggle('d-none', !match);
                if (match) hasVisibleEmp = true;
            });
            const compMatches = !term || card.textContent.toLowerCase().includes(term);
            card.classList.toggle('d-none', !hasVisibleEmp && !compMatches);
        });
    });

    document.querySelectorAll('[data-company-collapse]').forEach(button => {
        button.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            const target = document.querySelector(button.dataset.companyCollapse);
            if (!target) return;
            bootstrap.Collapse.getOrCreateInstance(target, { toggle: false }).toggle();
        });
    });
    document.querySelectorAll('#companyEmployeesAccordion .accordion-collapse').forEach(panel => {
        panel.addEventListener('shown.bs.collapse', () => {
            const button = document.querySelector('[data-company-collapse="#' + panel.id + '"]');
            button?.classList.remove('collapsed');
            button?.setAttribute('aria-expanded', 'true');
        });
        panel.addEventListener('hidden.bs.collapse', () => {
            const button = document.querySelector('[data-company-collapse="#' + panel.id + '"]');
            button?.classList.add('collapsed');
            button?.setAttribute('aria-expanded', 'false');
        });
    });

    // Present marking filter logic
    const filterPresentRows = () => {
        const type = document.getElementById('presentTypeFilter')?.value || '';
        const department = document.getElementById('presentDepartmentFilter')?.value || '';
        document.querySelectorAll('.present-mark-row').forEach(row => {
            const visible = (!type || row.dataset.type === type) && (!department || row.dataset.department === department);
            row.classList.toggle('d-none', !visible);
            if (!visible) {
                const chk = row.querySelector('.present-employee-check');
                if (chk) chk.checked = false;
            }
        });
        const selectAll = document.getElementById('selectAllPresent');
        if (selectAll) selectAll.checked = false;
    };

    document.getElementById('presentTypeFilter')?.addEventListener('change', filterPresentRows);
    document.getElementById('presentDepartmentFilter')?.addEventListener('change', filterPresentRows);
    document.getElementById('selectAllPresent')?.addEventListener('change', event => {
        document.querySelectorAll('.present-mark-row:not(.d-none) .present-employee-check').forEach(input => {
            input.checked = event.target.checked;
        });
    });

    document.getElementById('presentAttendanceForm')?.addEventListener('submit', async event => {
        event.preventDefault();
        const employeeIds = [...document.querySelectorAll('.present-employee-check:checked')].map(input => Number(input.value));
        if (!employeeIds.length) {
            notify('error', 'Select at least one present employee.');
            return;
        }
        const button = event.currentTarget.querySelector('button[type="submit"],button.btn-primary');
        if (button) button.disabled = true;
        const form = new FormData(event.currentTarget);
        form.set('action', 'mark_present_attendance');
        form.set('csrf_token', <?= json_encode($_SESSION['csrf_token']) ?>);
        form.set('employee_ids', JSON.stringify(employeeIds));
        form.set('attendance_date', <?= json_encode($selectedDate) ?>);
        try {
            const data = await post(form);
            notify('success', data.message);
            location.reload();
        } catch (error) {
            notify('error', error.message);
            if (button) button.disabled = false;
        }
    });

    // Initialize Monthly Attendance Summary Chart (Chart.js)
    const ctx = document.getElementById('monthlyAttendanceChart')?.getContext('2d');
    if (ctx && typeof Chart !== 'undefined') {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($chartLabels) ?>,
                datasets: [
                    {
                        label: 'On Time',
                        data: <?= json_encode($chartOnTime) ?>,
                        backgroundColor: '#2e7d32',
                        borderRadius: 6,
                        stack: 'attendance'
                    },
                    {
                        label: 'Late',
                        data: <?= json_encode($chartLate) ?>,
                        backgroundColor: '#e53935',
                        borderRadius: 6,
                        stack: 'attendance'
                    },
                    {
                        label: 'Absent',
                        data: <?= json_encode($chartAbsent) ?>,
                        backgroundColor: '#fb8c00',
                        borderRadius: 6,
                        stack: 'attendance'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#0f172a',
                        padding: 12,
                        titleFont: { family: 'Sora', size: 13 },
                        bodyFont: { size: 12 },
                        cornerRadius: 8
                    }
                },
                scales: {
                    x: {
                        stacked: true,
                        grid: { display: false },
                        ticks: { font: { size: 11 } }
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        grid: { color: '#f1f5f9' },
                        ticks: { precision: 0, font: { size: 11 } }
                    }
                }
            }
        });
    }
});
</script>
<?php endSection(); ?>
