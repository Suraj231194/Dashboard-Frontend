<?php
$financeView = 'trade_payables';
require __DIR__ . '/finance-page.php';
