<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <!-- Header -->
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage low stock alerts and purchase requests</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <!-- Toolbar -->
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="lowStocksPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="low-stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="low-stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="low-stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="low-stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="low-stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="low-stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <!-- Search input -->
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchLowStocks"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <!-- Right side: Add New -->
                    <?php if (roleHasPermission($_SESSION['role_id'], 'low_stocks_menu_add')) { ?>
                        <button type="button" id="addLowStockModalBtn"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 ms-auto" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <!-- Table Section -->
            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="date_report" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date of Report <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="vendor_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Vendor <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="category" data-order="asc">
                                <span class="inline-flex items-center gap-1">Category <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-80 min-w-[300px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="product_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Product Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="reporting_person" data-order="asc">
                                <span class="inline-flex items-center gap-1">Reporting Person <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3">Quantity Req</th>
                            <th class="px-6 py-3">Is Critical ?</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="expected_delivery_date" data-order="asc">
                                <span class="inline-flex items-center gap-1">Exp DOD <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="status" data-order="asc">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="employeesTableBody" class="bg-white divide-y divide-slate-100 text-sm text-slate-600">
                        <!-- Loaded via AJAX -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination Footer -->
            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- Modals -->
    <!-- Add Low Stock Modal -->
    <div class="modal fade animate__animated fadeIn" id="addLowStockModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-3xl">
                <div class="modal-header flex flex-col border-b border-slate-200 bg-slate-50/90 !px-4 !pt-3 !pb-3">
                    <div class="w-12 h-1 bg-slate-300 rounded-full mx-auto mb-2.5 opacity-80"></div>
                    <div class="flex items-center justify-between w-full gap-3">
                        <div class="flex items-center gap-2.5">
                            <span class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                                <i class="ti ti-plus text-lg"></i>
                            </span>
                            <div>
                                <h5 class="modal-title m-0 text-base font-bold text-slate-900 leading-tight" id="exampleModalLabel5">Low Stock - Purchase Request Form</h5>
                            </div>
                        </div>
                        <button type="button"
                            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-base"></i>
                        </button>
                    </div>
                    <p class="m-0 mt-2 text-xs font-medium text-slate-500 leading-relaxed bg-white p-2.5 rounded-xl border border-slate-200/70 shadow-2xs">
                        This form is to be filled <strong>whenever any item goes out of stock</strong> at the store. Please provide complete and accurate details so that the restocking process can begin immediately. Avoid WhatsApp/verbals — this form is your official communication tool.
                    </p>
                </div>
                <form id="addLowStocksForm" class="flex flex-col flex-1 min-h-0">
                    <div class="modal-body bg-slate-50/70 p-4 min-h-0">
                        <div class="row g-2 mb-3">
                            <div class="col-sm-6 col-12 mb-1">
                                <label for="reportingPerson"
                                    class="form-label text-xs font-semibold text-slate-700">Person Reporting
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="reportingPerson" autocomplete="off" name="reportingPerson"
                                    class="form-control form-control-sm text-xs bg-white" placeholder="Enter Name or Email"
                                    value="<?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>" required />
                            </div>
                            <div class="col-sm-6 col-12 mb-1">
                                <label for="dateOfReport" class="form-label text-xs font-semibold text-slate-700">Date
                                    of Report <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="dateOfReport" autocomplete="off" name="dateOfReport"
                                    class="form-control form-control-sm text-xs" placeholder="Enter Date" value="<?php echo date('Y-m-d'); ?>" required />
                            </div>
                        </div>
                        <div class="low-stock-material-lines">
                            <div class="low-stock-material-lines__toolbar">
                                <label class="form-label mb-0 text-xs font-bold uppercase tracking-wider text-slate-600">Material Lines</label>
                                <button type="button"
                                    class="inline-flex h-8 shrink-0 items-center gap-1.5 !rounded-lg bg-emerald-50 px-3 text-xs font-semibold text-emerald-700 shadow-xs ring-1 ring-emerald-900/10 hover:bg-emerald-100 focus:outline-none"
                                    id="addMrProducts">
                                    <i class="ti ti-plus text-sm"></i> Add Product
                                </button>
                            </div>
                            <div id="mrProductsWrapper" class="low-stock-material-lines__list d-flex flex-column gap-2.5"></div>
                        </div>
                    </div>
                <div class="flex items-center justify-between gap-2 border-t border-slate-200 bg-white px-4 py-3">
                    <button type="button"
                        class="inline-flex h-10 flex-1 items-center justify-center !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none"
                        data-bs-dismiss="modal">Close</button>
                    <?php if (canDoThis('operations_admin_production_plan_add')) { ?>
                        <button type="button" id="addLowStocksProduceBtn"
                            class="inline-flex h-10 flex-1 items-center justify-center gap-2 !rounded-xl bg-indigo-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-indigo-900/10 transition-colors hover:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/30" style="background-color: #4338ca !important; border: 1px solid #3730a3 !important; color: #ffffff !important;">
                            <i class="ti ti-building-factory-2 text-base"></i> Produce
                        </button>
                    <?php } ?>
                    <button type="submit"
                        class="inline-flex h-10 flex-1 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <i class="ti ti-shopping-cart-plus text-base"></i> Procure
                    </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Low Stock Modal -->
    <div class="modal fade animate__animated fadeIn" id="lowStockEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Edit
                                Low Stock Request</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="lowStocksEditForm" class="flex flex-col flex-1 min-h-0">
                    <div class="modal-body bg-slate-50/70 p-6 min-h-0"></div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Low Stock Modal -->
    <div class="modal fade animate__animated fadeIn" id="productionPlanViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden border-0 shadow-2xl rounded-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">View
                                Low Stock Request</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div id="productionPlanViewForm" class="flex flex-col flex-1 min-h-0">
                    <div class="modal-body bg-slate-50/70 p-6 min-h-0"></div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Mobile-like Portrait View for Low Stock Purchase Request Form */
    #addLowStockModal .modal-dialog {
        width: 100%;
        max-width: 710px; /* Increased breadth by 20% from 590px */
        height: min(55rem, calc(100vh - 2rem)); /* Long in length */
        height: min(55rem, calc(100dvh - 2rem));
        min-height: 0;
        margin-top: 1rem;
        margin-bottom: 1rem;
        margin-left: auto;
        margin-right: auto;
    }

    #addLowStockModal .modal-content {
        height: 100%;
        max-height: 100%;
        border-radius: 1.5rem !important; /* Smartphone card curves */
        box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35), 0 0 0 1px rgba(15, 23, 42, 0.08) !important;
        background: #ffffff;
    }

    #addLowStockModal .select2-container {
        width: 100% !important;
    }

    #addLowStockModal .select2-dropdown {
        border-radius: 0.75rem !important;
        border: 1px solid #e2e8f0 !important;
        box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.18) !important;
        z-index: 1065 !important;
    }

    #addLowStockModal #addLowStocksForm {
        min-height: 0;
        overflow: hidden;
    }

    #addLowStockModal .modal-body {
        display: flex;
        min-height: 0;
        flex-direction: column;
        overflow: hidden;
        padding: 0.875rem !important;
    }

    #addLowStockModal .modal-body > .row {
        flex: 0 0 auto;
    }

    #addLowStockModal .low-stock-material-lines {
        display: flex;
        min-height: 0;
        flex: 1 1 auto;
        flex-direction: column;
    }

    #addLowStockModal .low-stock-material-lines__toolbar {
        display: flex;
        flex: 0 0 auto;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
        margin-bottom: 0.5rem;
    }

    #addLowStockModal .low-stock-material-lines__list {
        min-height: 0;
        flex: 1 1 auto;
        overflow-x: hidden;
        overflow-y: auto;
        padding: 0.125rem 0.25rem 0.5rem 0.125rem;
        overscroll-behavior: contain;
        scrollbar-gutter: stable;
    }

    #addLowStockModal .low-stock-material-lines__list .product-row {
        flex: 0 0 auto;
        margin-right: 0;
        margin-left: 0;
        border-radius: 0.875rem !important;
    }

    @media (max-width: 575.98px) {
        #addLowStockModal .modal-dialog {
            max-width: calc(100% - 1rem);
            height: calc(100vh - 1rem);
            height: calc(100dvh - 1rem);
            margin: 0.5rem auto;
        }

        #addLowStockModal .modal-body {
            padding: 0.75rem !important;
        }

        #addLowStockModal .low-stock-material-lines__toolbar {
            align-items: stretch;
            flex-direction: column;
        }

        #addLowStockModal #addMrProducts {
            justify-content: center;
            width: 100%;
        }
    }
</style>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let productIndex = 1;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';
    let qtyUnitOptions = [];
    const LOW_STOCK = <?php echo json_encode(Constant::LOW_STOCK['CRITICAL_STATUS']); ?>;

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#prodPlanBatchSizeUnit").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadMaterialTypeOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialTypeOption: 'loadMaterialTypeOption'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (prodCateg) {
                    html += `<option value="${prodCateg.key}">${prodCateg.value}</option>`;
                });
                $('#materialTypeList').html(html).trigger('change');
            }
        });
    }

    function loadLowStocksTable(page = 1) {
        currentPage = page;
        const search = ($('#searchLowStocks').val() || '').trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadLowStocks: 'loadLowStocks',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#employeesTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.total_rows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function () {
                $('#employeesTableBody').html('<tr><td colspan="11" class="px-6 py-10 text-center text-sm font-medium text-slate-500">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function updateItemNumbers() {
        $('#mrProductsWrapper .product-row').each(function (index) {
            const num = index + 1;
            $(this).attr('data-index', num);
            $(this).find('.item-badge-num').text('#' + num);
            $(this).find('.item-title').text('Item ' + num);
        });
        productIndex = $('#mrProductsWrapper .product-row').length + 1;
    }

    function bindLowStockSelect2Scroll(modalSelector) {
        setTimeout(function () {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.lowStockModalScroll')
                .on('wheel.lowStockModalScroll', function (e) {
                    const isOverDropdown = $(e.target).closest('.select2-dropdown').length > 0;
                    if (isOverDropdown) {
                        const el = $(this).find('.select2-results__options').get(0);
                        if (el && el.scrollHeight > el.clientHeight) {
                            const deltaY = e.originalEvent.deltaY || 0;
                            const canScrollUp = el.scrollTop > 0;
                            const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                            if ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown)) {
                                el.scrollTop += deltaY;
                                e.preventDefault();
                                e.stopPropagation();
                            }
                        }
                    }
                });
        }, 0);
    }

    function escapeHtml(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function loadProductsForSelect($productSelect, materialTypeId, selectedProductId) {
        materialTypeId = materialTypeId || '';
        selectedProductId = selectedProductId || '';
        $productSelect.prop('disabled', true);
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProductsByMaterialType: 'loadProductsByMaterialType',
                materialTypeId: materialTypeId
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                if (Array.isArray(response) && response.length > 0) {
                    response.forEach(function (product) {
                        const catAttr = product.category_id ? ` data-category-id="${product.category_id}"` : '';
                        const unitAttr = product.unit_id ? ` data-unit-id="${product.unit_id}"` : '';
                        const isSelected = String(product.key) === String(selectedProductId) ? ' selected' : '';
                        html += `<option value="${product.key}"${catAttr}${unitAttr}${isSelected}>${escapeHtml(product.value)}</option>`;
                    });
                } else if (materialTypeId) {
                    html += '<option value="" disabled>No products in this category</option>';
                }
                $productSelect.empty().html(html);
                $productSelect.val(selectedProductId || '');
                $productSelect.prop('disabled', false).trigger('change');
            },
            error: function () {
                $productSelect.prop('disabled', false);
            }
        });
    }

    $(document).ready(function () {
        loadLowStocksTable();
        loadStandardUnit();
        $(document).on('select2:open', function (e) {
            const $modal = $(e.target).closest('#addLowStockModal, #lowStockEditModal');
            if (!$modal.length) return;
            bindLowStockSelect2Scroll('#' + $modal.attr('id'));
        });
        $('#mrProductsWrapper, #lowStockEditModal .modal-body').on('scroll', function () {
            $(this).closest('.modal').find('.select2-hidden-accessible').select2('close');
        });
        $('#searchLowStocks').on('input', function () {
            loadLowStocksTable(1);
        });

        $('#perPageSelect').on('change', function () {
            loadLowStocksTable(1);
        });

        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadLowStocksTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.low-stocks-per-page-item', function () {
            const val = $(this).data('val');
            $('#lowStocksPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        const DEFAULT_REPORTING_PERSON = '<?php echo htmlspecialchars($_SESSION['user_email'] ?? '', ENT_QUOTES); ?>';
        const TODAY_DATE = '<?php echo date('Y-m-d'); ?>';

        $('#addLowStockModalBtn').on('click', function () {
            $('#addLowStocksForm')[0].reset();
            $('#reportingPerson').val(DEFAULT_REPORTING_PERSON);
            $('#dateOfReport').val(TODAY_DATE);
            $('#mrProductsWrapper').empty();
            $('#addLowStockModal').modal('show');
            $('#addMrProducts').trigger('click');
            updateItemNumbers();
        });

        $('#addLowStockModal').on('show.bs.modal', function () {
            if (!$('#reportingPerson').val()) {
                $('#reportingPerson').val(DEFAULT_REPORTING_PERSON);
            }
            if (!$('#dateOfReport').val()) {
                $('#dateOfReport').val(TODAY_DATE);
            }
        });


        $('#addMrProducts').click(function () {
            let optionsUnitHtml = '<option value="">---Select----</option>';
            if (Array.isArray(qtyUnitOptions) && qtyUnitOptions.length > 0) {
                qtyUnitOptions.forEach(unit => {
                    optionsUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
            }
            let criticalOptionsHtml = '<option value="">---Select----</option>';

            Object.entries(LOW_STOCK).forEach(([key, data]) => {
                criticalOptionsHtml += `<option value="${key}" data-badge="${data.badge}">
                    ${data.label}
                </option>`;
            });
            let productRow = `
            <div class="row g-2 mb-2 product-row border border-slate-200 rounded-2xl bg-white shadow-2xs p-3" data-index="${productIndex}">   
                <div class="col-12 d-flex items-center justify-between border-b border-slate-200 pb-2 mb-2 bg-slate-100/80 -mx-3 -mt-3 px-3 pt-2.5 rounded-t-2xl">
                    <div class="d-flex items-center gap-2">
                        <span class="item-badge-num inline-flex items-center justify-center h-6 min-w-6 px-2 rounded-md bg-emerald-700 text-white text-xs font-black shadow-xs tracking-wider">#${productIndex}</span>
                        <h6 class="item-title m-0 text-sm font-bold text-slate-900 tracking-tight">Item ${productIndex}</h6>
                    </div>
                    <button type="button" class="btn btn-icon btn-sm btn-label-danger removeProductBtn inline-flex h-7 w-7 items-center justify-center rounded-lg text-rose-600 hover:bg-rose-100 border-0 p-0 transition-colors" title="Remove Item">
                        <span class="ti ti-trash text-base"></span>
                    </button>
                </div>              
                <div class="col-12 mb-1">
                    <label class="form-label text-xs font-semibold text-slate-700 mb-1">Item Type <strong class="text-danger">*</strong></label>
                    <select name="itemType[]" class="input-theme select2 itemTypeSelect" required>
                        <option value="inventory" selected>Standard Inventory</option>
                        <option value="non_inventory">Office / Non-Inventory Supply</option>
                    </select>
                </div>
                <div class="col-12 mb-1 inventory-field-group">
                    <label class="form-label text-xs font-semibold text-slate-700 mb-1">Material Category <strong class="text-danger">*</strong></label>
                    <select name="materialCategory[]" class="input-theme select2 materialTypeList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-12 mb-1 inventory-field-group">
                    <label class="form-label text-xs font-semibold text-slate-700 mb-1">Product <strong class="text-danger">*</strong></label>
                    <select name="productsList[]" class="input-theme select2 productsList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="col-12 mb-1 non-inventory-field-group d-none">
                    <label class="form-label text-xs font-semibold text-slate-700 mb-1">Item Description (Non-Inventory) <strong class="text-danger">*</strong></label>
                    <input type="text" name="nonInventoryItemName[]" class="form-control form-control-sm nonInventoryInput text-xs" placeholder="Enter supply/office item description..." />
                </div>                
                <div class="col-6 mb-1">
                    <label for="prodPlanBatchSize_${productIndex}" class="form-label text-xs font-semibold text-slate-700 mb-1">Quantity <strong class="text-danger">*</strong></label>
                    <input type="number" min="0" step="any" id="prodPlanBatchSize_${productIndex}" name="ProductItemquantity[]" class="form-control form-control-sm text-xs" placeholder="Qty" required />
                </div>
                <div class="col-6 mb-1">
                    <label for="prodPlanBatchSizeUnit_${productIndex}" class="form-label text-xs font-semibold text-slate-700 mb-1">Unit <strong class="text-danger">*</strong></label>
                    <select id="prodPlanBatchSizeUnit_${productIndex}" name="ProductItemquantityUnit[]" class="input-theme select2 select2-unit" placeholder="Unit" required>` + optionsUnitHtml + `</select>
                </div>    
                <div class="col-12 mb-1">
                    <label for="vendorName_${productIndex}" class="form-label text-xs font-semibold text-slate-700 mb-1">Vendor Name <strong class="text-danger">*</strong></label>
                    <select id="vendorName_${productIndex}" name="vendorName[]" class="input-theme select2 vendorNameSelect" data-allow-clear="true" required>
                        <option value="">----Select Vendor----</option>
                    </select>
                </div>
                <div class="col-sm-6 col-12 mb-1">
                    <label for="isThisCritical_${productIndex}" class="form-label text-xs font-semibold text-slate-700 mb-1">Critical Item? <strong class="text-danger">*</strong></label>
                    <select id="isThisCritical_${productIndex}" name="isThisCritical[]" class="input-theme select2 isThisCriticalSelect" required>
                    ${criticalOptionsHtml}
                    </select>
                </div>
                <div class="col-sm-6 col-12 mb-1">
                    <label for="dateOfDelivery_${productIndex}" class="form-label text-xs font-semibold text-slate-700 mb-1">Expected Delivery</label>
                    <input type="date" id="dateOfDelivery_${productIndex}" autocomplete="off" name="dateOfDelivery[]" class="form-control form-control-sm text-xs" placeholder="Enter Date" />
                </div>
            </div>`;

            let $newRow = $(productRow);
            $('#mrProductsWrapper').append($newRow);

            $newRow.find('.select2').select2({
                placeholder: '----Select Option----',
                width: '100%',
                dropdownParent: $('#addLowStockModal')
            });

            $newRow.find('.isThisCriticalSelect, .itemTypeSelect').select2({
                placeholder: '----Select Option----',
                width: '100%',
                minimumResultsForSearch: Infinity,
                dropdownParent: $('#addLowStockModal')
            });

            // Load material types in the new block (categories with products)
            const $newMaterialSelect = $newRow.find('.materialTypeList');
            const $newProductSelect = $newRow.find('.productsList');
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadMaterialTypeOption: 'loadMaterialTypeOption',
                    onlyWithProducts: 1
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (item) {
                        html += `<option value="${item.key}">${escapeHtml(item.value)}</option>`;
                    });
                    $newMaterialSelect.html(html);
                }
            });

            // Immediately load active products into the product dropdown so it is never empty
            loadProductsForSelect($newProductSelect, '');

            // Load vendor/supplier list for the new block
            const $newVendorSelect = $newRow.find('.vendorNameSelect');
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: { loadSupplierListOptions: 'loadSupplierListOptions' },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Vendor----</option>';
                    response.forEach(function (item) {
                        html += `<option value="${escapeHtml(item.value)}" data-id="${item.key}">${escapeHtml(item.value)}</option>`;
                    });
                    $newVendorSelect.html(html).trigger('change');
                },
                error: function (xhr, status, error) {
                    toastr.error('Failed to load vendors list: ' + (xhr.responseJSON?.message || error || 'Server error'));
                }
            });
            productIndex++;

            // Reveal the newly added line without moving the Add Product action.
            const linesList = document.getElementById('mrProductsWrapper');
            linesList.scrollTo({
                top: linesList.scrollHeight,
                behavior: 'smooth'
            });
        });

        $(document).on('change', '.itemTypeSelect', function () {
            const $row = $(this).closest('.product-row');
            const isNonInventory = $(this).val() === 'non_inventory';
            if (isNonInventory) {
                $row.find('.inventory-field-group').addClass('d-none');
                $row.find('.materialTypeList, .productsList').prop('required', false);
                $row.find('.non-inventory-field-group').removeClass('d-none');
                $row.find('.nonInventoryInput').prop('required', true).focus();
            } else {
                $row.find('.non-inventory-field-group').addClass('d-none');
                $row.find('.nonInventoryInput').prop('required', false);
                $row.find('.inventory-field-group').removeClass('d-none');
                $row.find('.materialTypeList, .productsList').prop('required', true);
            }
        });

        $('#addLowStocksForm').on('submit', function (e) {
            e.preventDefault();
            if ($('#mrProductsWrapper .product-row').length === 0) {
                toastr.error('Please add at least one item before submitting.');
                return;
            }

            const form = document.getElementById('addLowStocksForm');
            const formData = new FormData(form);
            formData.append('addLowStocksRecord', 'addLowStocksRecord');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#addLowStockModal').modal('hide');
                        $('#addLowStocksForm')[0].reset();
                        $('#reportingPerson').val(DEFAULT_REPORTING_PERSON);
                        $('#dateOfReport').val(TODAY_DATE);
                        loadLowStocksTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message || 'Failed to submit purchase request.');
                    } else {
                        toastr.error('Unexpected response from server.');
                    }
                },
                error: function (xhr, status, error) {
                    let msg = 'Failed to submit purchase request.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        msg = xhr.responseJSON.message;
                    } else if (xhr.responseText) {
                        try {
                            const parsed = JSON.parse(xhr.responseText);
                            if (parsed.message) msg = parsed.message;
                        } catch (e) {
                            msg += ' ' + (error || status || 'Server error occurred.');
                        }
                    }
                    toastr.error(msg);
                }
            });
        });

        $('#addLowStocksProduceBtn').on('click', function () {
            const $button = $(this);
            const reportingPerson = String($('#reportingPerson').val() || '').trim();
            const dateOfReport = String($('#dateOfReport').val() || '').trim();
            const items = [];
            const errors = [];

            if (!reportingPerson || !dateOfReport) {
                toastr.error('Please provide Person Reporting and Date of Report.');
                return;
            }
            $('#mrProductsWrapper .product-row').each(function (index) {
                const $row = $(this);
                if (String($row.find('.itemTypeSelect').val() || 'inventory') !== 'inventory') {
                    errors.push('Item ' + (index + 1) + ' is a non-inventory item and cannot be produced.');
                    return;
                }
                const categoryId = Number($row.find('.materialTypeList').val() || 0);
                const productId = Number($row.find('.productsList').val() || 0);
                const quantity = Number($row.find('input[name="ProductItemquantity[]"]').val() || 0);
                const unitId = Number($row.find('select[name="ProductItemquantityUnit[]"]').val() || 0);
                if (categoryId <= 0 || productId <= 0 || !Number.isFinite(quantity) || quantity <= 0 || unitId <= 0) {
                    errors.push('Item ' + (index + 1) + ' requires a category, product, quantity greater than zero, and unit.');
                    return;
                }
                items.push({
                    category_id: categoryId,
                    product_id: productId,
                    quantity: quantity,
                    unit_id: unitId
                });
            });

            if (errors.length > 0) {
                toastr.error(errors.join(' '));
                return;
            }
            if (items.length === 0) {
                toastr.error('Add at least one inventory item before sending it to Production.');
                return;
            }

            $button.prop('disabled', true);
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    createLowStockProductionPlans: '1',
                    reportingPerson: reportingPerson,
                    dateOfReport: dateOfReport,
                    items: JSON.stringify(items)
                },
                success: function (res) {
                    if (res.status === 'success') {
                        toastr.success(res.message || 'Production Plan request created.');
                        window.location.href = 'index.php?page=production-plan';
                    } else {
                        toastr.error(res.message || 'Unable to create Production Plan requests.');
                    }
                },
                error: function (xhr) {
                    const message = xhr.responseJSON && xhr.responseJSON.message
                        ? xhr.responseJSON.message
                        : 'Server error occurred while creating Production Plan requests.';
                    toastr.error(message);
                },
                complete: function () {
                    $button.prop('disabled', false);
                }
            });
        });
    });

    $(document).on('click', '.lowStockDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteLowStocksRecord: 'deleteLowStocksRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadLowStocksTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });


    $(document).on('click', '.lowStocksEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#lowStocksEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchLowStocksRecord: 'fetchLowStocksRecord', id: id },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#lowStockEditModal').modal('show');
                        $('#lowStocksEditForm').find('.modal-body').html(res.data);
                        $('#lowStocksEditForm .select2').select2({
                            placeholder: '----Select Option----',
                            dropdownParent: $('#lowStockEditModal')
                        });
                        let selectedCat = $('#materialCategoryEdit').val();
                        if (selectedCat) {
                            $('#materialCategoryEdit').trigger('change');
                        }
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $('#lowStocksEditForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('lowStocksEditForm');
        const formData = new FormData(form);
        formData.append('updateLowStocks', 'updateLowStocks');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#lowStockEditModal').modal('hide');
                    $('#lowStocksEditForm').find('modal-body').html();
                    loadLowStocksTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.lowStocksViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#productionPlanViewForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewLowStocksRecord: 'viewLowStocksRecord', id: id },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#productionPlanViewModal').modal('show');
                        $('#productionPlanViewForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('change', '.materialTypeList', function (e) {
        if (e.namespace === 'from_product') {
            return;
        }
        const $parentRow = $(this).closest('.product-row');
        const $productSelect = $parentRow.find('.productsList');
        const materialTypeId = $(this).val();

        loadProductsForSelect($productSelect, materialTypeId, '');
    });

    $(document).on('change', '.productsList', function (e) {
        const $parentRow = $(this).closest('.product-row');
        const $selectedOpt = $(this).find(':selected');
        const catId = $selectedOpt.data('category-id');
        const unitId = $selectedOpt.data('unit-id');
        const $catSelect = $parentRow.find('.materialTypeList');
        const $unitSelect = $parentRow.find('select[name="ProductItemquantityUnit[]"]');

        if (catId && $catSelect.length && String($catSelect.val()) !== String(catId)) {
            $catSelect.val(catId).trigger('change.from_product');
        }
        if (unitId && $unitSelect.length) {
            $unitSelect.val(unitId).trigger('change');
        }
    });

    $('#mrProductsWrapper').on('click', '.removeProductBtn', function () {
        $(this).closest('.product-row').remove();
        updateItemNumbers();
    });

    $(document).on('change', '#materialCategoryEdit', function () {
        let categoryId = $(this).val();
        let productDropdown = $('#productsListEdit');
        let preSelectedProd = productDropdown.data('selected') || productDropdown.val() || '';
        loadProductsForSelect(productDropdown, categoryId, preSelectedProd);
    });

    $(document).on('click', '.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        if (currentSortOrder === 'ASC') {
            $(this).addClass('asc');
        } else {
            $(this).addClass('desc');
        }
        loadLowStocksTable(1);
    });



</script>
<?php endSection(); ?>
