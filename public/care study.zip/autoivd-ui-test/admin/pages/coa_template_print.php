<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once "../db.php";
require_once "../functions.php";
require_once "../constant.php";
require_once "../document_pdf_helpers.php";

documentPdfRequireAnyPermission($conn, ['coa_generation_pdf']);
$coaOrderNum = documentPdfEncryptedPositiveId($_GET['id'] ?? '');

$sqlHeader = "SELECT * FROM `coa_rm_pm_table` WHERE `id` = ? AND `status` = 1 AND `deleted_at` IS NULL";
$stmt = $conn->prepare($sqlHeader);
$stmt->bind_param('i', $coaOrderNum);
$stmt->execute();
$headerResult = $stmt->get_result();
$header = $headerResult->fetch_assoc();
$stmt->close();

if (!$header) {
    http_response_code(404);
    exit('COA record not found.');
}

$sqlItems = "SELECT * FROM `coa_rm_pm_observations` WHERE `coa_id` = ? AND `status` = 1 AND `deleted_at` IS NULL ORDER BY `id` ASC";
$stmt2 = $conn->prepare($sqlItems);
$stmt2->bind_param('i', $coaOrderNum);
$stmt2->execute();
$itemsResult = $stmt2->get_result();
$items = $itemsResult->fetch_all(MYSQLI_ASSOC);
$stmt2->close();
$fileName = $header['coa_number'];
$unitMap = [];
$unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
while ($rowUnit = $unitQuery->fetch_assoc()) {
    $unitMap[$rowUnit['id']] = $rowUnit['short_name'];
}
$batchSizeUnit = $unitMap[$header['batch_unit_id']] ?? $header['batch_unit_id'];

$manufacturer = trim($header['manufacturer_name'] ?? '');
$supplier = trim($header['suplier_name'] ?? '');

if ($manufacturer && $supplier) {
    if (strcasecmp($manufacturer, $supplier) === 0) {       
        $manufacturerSupplier = $manufacturer;
    } else {
        $manufacturerSupplier = $manufacturer . ' / ' . $supplier;
    }
} elseif ($manufacturer) {
    $manufacturerSupplier = $manufacturer;
} elseif ($supplier) {
    $manufacturerSupplier = $supplier;
} else {
    $manufacturerSupplier = ''; 
}

$row = [
    'name'  => $header['name'],
    'manufacturer_supplier'  => $manufacturerSupplier,
    'coa_number'  => $header['coa_number'],
    'material_code_no'  => $header['material_code_no'],
    'testing_date'  => formatDateSlashDMY($header['testing_date']),
    'mfg_date'  => formatDateDMY($header['mfg_date']),
    'expiry_date'  => formatDateDMY($header['expiry_date']),
    'number_of_container_received'  => $header['number_of_container_received'],
    'container_sampled'  => $header['container_sampled'],
    'coa_ref_stp'  => $header['coa_ref_stp'],
    'lot_batch_number'  => $header['batch_number'],
    'lot_batch_size'  => $header['batch_size'].' '.$batchSizeUnit,
    'coa_approval_status'  => $header['coa_approval_status'],
    'coa_remark'  => $header['coa_remark'],
    'items'  => []
];

foreach ($items as $item) {
    $row['items'][] = [
        "serial"   => $item['sr_no'],
        "table_head"   => $item['table_head'],
        "parameter"   => $item['parameter'],
        "specification"   => $item['specification'],
        "observation"   => $item['observation']
    ];
}
$serverSideDownload = (string) ($_GET['triggerDownload'] ?? '') === '1';
$logoSource = documentPdfLocalImageDataUri(dirname(__DIR__, 2) . '/assets/img/logo3.jpeg');
if ($serverSideDownload) {
    ob_start();
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Purchase Order</title>
    <style>
        .page {
            width: 100%;
            min-height: 1000px;
            /* ~A4 height in pixels at 96 DPI */
            padding: 15px;
            box-sizing: border-box;
            position: relative;
            page-break-after: always;
        }

        .page:last-child {
            page-break-after: auto;
        }
        <?php if ($serverSideDownload) { ?>
        .page { min-height: 0; }
        <?php } ?>

        table {
            page-break-inside: auto;
        }

        tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }

        thead {
            display: table-header-group;
        }

        tfoot {
            display: table-footer-group;
        }
    </style>

</head>

<body style="margin: 0;">
    <div id="purchaseOrderFinalPdfContent" style="padding: 10px; max-width: 900px; margin: auto;">
        <?php      
        $rowsPerPage = 10;
        $chunks = array_chunk($row['items'], $rowsPerPage) ?: [[]];
        $lastPageIndex = array_key_last($chunks);
        $totalPages = count($chunks);
        foreach ($chunks as $pageIndex => $pageProducts) {
            $realCount = count($pageProducts);
            $emptyRows = $rowsPerPage - $realCount;
            $currentPage = $pageIndex + 1;
        ?>

            <div class="page" style="page-break-after: <?= ($pageIndex == array_key_last($chunks)) ? 'auto' : 'always' ?>;">          
                <div style="border: 1px solid #000; margin-bottom:10px;">
                    <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                        <tr>
                            <td style="width: 30%; border-right: 1px solid #000; padding:0; vertical-align: top;">
                                <table style="width:100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="border-bottom: 1px solid #000; padding:15px;">
                                            <img src="<?php echo htmlspecialchars($logoSource, ENT_QUOTES, 'UTF-8'); ?>" alt="Biogenix Logo" style="height: 60px; vertical-align: middle; padding-left:10px;">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding:6px; font-size:12px; line-height:1.5;">
                                            B19/A S.I.L. Ancillary Estate, Amausi<br>
                                            Industrial Area, Nadarganj-226008<br>
                                            (Lucknow)
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td style="width: 30%; border-right: 1px solid #000; text-align:center; vertical-align: middle;">
                                <strong style="font-size:16px;">TITLE: <br> CERTIFICATE OF ANALYSIS</strong>
                            </td>
                            <td style="width: 40%; vertical-align: top; padding:0px;">
                                <table style="width: 100%; border-collapse: collapse; font-size:12px;">
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; width:50%; font-weight:700;">Document No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">BIPL-F-COA-01</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Issue No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">01</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Revision No.</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">02</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Effective Date</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">03/04/2025</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Review Date</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">02/04/2028</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;border-bottom:1px solid #000;padding:4px; font-weight:700;">Department</td>
                                        <td style="padding:4px;border-bottom:1px solid #000;">Quality Control</td>
                                    </tr>
                                    <tr>
                                        <td style="border-right:1px solid #000;padding:4px; font-weight:700;">Supersedes</td>
                                        <td style="padding:4px;">Nil</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>

                <table style="border-collapse:collapse; width:100%; font-family:Arial, sans-serif; font-size:12px; margin-bottom:20px; line-height: 0.7;">
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Item Description</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['name'] ?? ""); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Manufacturer/Supplier</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['manufacturer_supplier'] ?? "");  ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">COA/AR No.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['coa_number'] ?? ""); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Item Code No.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['material_code_no'] ?? ""); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">G. R. No.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars('-' ?? "NA"); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Testing date</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['testing_date'] ?? "NA"); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Mfg. Date.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars(formatDateDMY($row['mfg_date']) ?? "-"); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Exp. Date.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars(formatDateDMY($row['expiry_date']) ?? "-"); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">No. of Packings received</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['number_of_container_received'] ?? ""); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">No. of Packings sampled</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['container_sampled'] ?? ""); ?></td>                   
                    </tr>
                    
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Reference specification no./STP no.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['coa_ref_stp'] ?? "NA"); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Lot No./ Batch no.</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['lot_batch_number'] ?? "NA"); ?></td>                   
                    </tr>
                    <tr>
                        <td style="width:31%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; border-bottom:1px solid #000;border-top:1px solid #000; padding:6px; font-weight:bold;">Lot Size/ Batch size</td>
                        <td style="width:69%; border-left:1px solid #000;border-top:1px solid #000;border-bottom:1px solid #000;border-top:1px solid #000; border-right:1px solid #000; padding:6px;"><?= htmlspecialchars($row['lot_batch_size'] ?? "NA"); ?></td>                   
                    </tr>
                </table>

                <table style="border-collapse:collapse; width:100%; font-family:Arial, sans-serif; font-size:12px;">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr style="font-weight:bold; text-align:center;">
                            <th class="border-b border-slate-200 px-6 py-3" style="width:10%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Sr. No.</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="width:32%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Parameter</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="width:32%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000; padding:6px;">Specification</th>
                            <th class="border-b border-slate-200 px-6 py-3" style="width:26%; background-color:#D3D3D3; border-left:1px solid #000;border-top:1px solid #000;border-right:1px solid #000; padding:6px;">Observation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pageProducts as $p){?>
                        <?php if($p['table_head']){ ?>
                        <tr style="font-weight:bold; text-align:left;">
                            <td colspan="4" style="background-color:#D3D3D3; border-bottom:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;border-top:1px solid #000; padding:6px;"><?= htmlspecialchars((string) $p['table_head'], ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>
                        <?php } ?>
                            
                        <tr style="text-align:left;">
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px; text-align:center;"><?= htmlspecialchars((string) $p['serial'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;"><?= htmlspecialchars((string) $p['parameter'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;"><?= htmlspecialchars((string) $p['specification'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-top:1px solid #000; padding:6px;border-right:1px solid #000; "><?= htmlspecialchars((string) $p['observation'], ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>
                        <?php } ?>
                        <?php for ($i = 0; $i < $emptyRows; $i++){ ?>
                        <tr>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                            <td style="border:1px solid #fff; padding:6px;">&nbsp;</td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <?php if ($pageIndex == $lastPageIndex) { ?>
                <div style="margin-top:5px;">
                    <table style="width:100%; border:1px solid #000; border-collapse:collapse; text-align:left; padding: 15px; font-size:12px;">
                        <tr>
                            <td style="width:3%; border:1px solid #000; padding:10px; font-size:15px;">
                                <?php echo ($row['coa_approval_status'] == 1 ? "&#x2611;" : "&#x2610;"); ?>
                            </td>
                            <td style="width:6%; border:1px solid #000; padding:10px;">
                                <b>Approved</b> 
                            </td>
                            <td rowspan="2" style="width:40%; border:1px solid #000; padding:10px; vertical-align: top;">
                                <b>Comments/Instructions :</b> <?= htmlspecialchars($row['coa_remark'] ?? ""); ?>
                            </td>
                            <td style="width:10%; border:1px solid #000; padding:10px;">
                                <b>Analysis by</b>
                            </td>
                            <td style="width:10%; border:1px solid #000; padding:10px;">                               
                            </td>
                        </tr>
                        <tr>
                            <td style="width:3%; border:1px solid #000; padding:10px; font-size:15px;">
                                <?php echo ($row['coa_approval_status'] == 2 ? "&#x2611;" : "&#x2610;"); ?>
                            </td>
                            <td style="width:6%; border:1px solid #000; padding:10px;">
                                <b>Rejected</b> 
                            </td>                            
                            <td style="width:10%; border:1px solid #000; padding:10px;">
                                <b>Verified and Approved by</b>
                            </td>
                            <td style="width:10%; border:1px solid #000; padding:10px;">                               
                            </td>
                        </tr>                        
                    </table>
                </div>
                <?php } ?>
                <div style="margin-top:5px;">
                    <table style="width:100%; border:1px solid #000; border-collapse:collapse; text-align:left; padding: 15px;font-size:12px;">
                        <tr>
                            <td style="width:40%; border:1px solid #000; padding:15px;">
                                <b>Format Prepared by :</b> MR/QA
                            </td>
                            <td style="width:40%; border:1px solid #000; padding:15px;">
                                <b>Format Approved by:</b> Head of the organization
                            </td>
                            <td style="width:20%; border:1px solid #000; padding:15px;">
                                Page No.: <?= $currentPage ?> of <?= $totalPages ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

        <?php } ?>
    </div>
</body>
</html>
<?php
if ($serverSideDownload) {
    documentPdfStream((string) ob_get_clean(), (string) ($fileName ?: 'COA'));
}
?>
