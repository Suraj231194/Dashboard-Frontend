<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once "../db.php";
require_once "../functions.php";
require_once "../document_pdf_helpers.php";

documentPdfRequireAnyPermission($conn, ['generate_rapid_pdf']);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('This download requires a POST request.');
}

$sessionToken = (string) ($_SESSION['csrf_token'] ?? '');
$requestToken = (string) ($_POST['csrf_token'] ?? '');
if ($sessionToken === '' || !hash_equals($sessionToken, $requestToken)) {
    http_response_code(419);
    exit('Your session token is invalid or expired. Refresh the page and try again.');
}

$rawIds = trim((string) ($_POST['ids'] ?? ''));
if ($rawIds === '') {
    http_response_code(422);
    exit('Select at least one Daily Production Report.');
}

$requestedIds = [];
foreach (explode(',', $rawIds) as $rawId) {
    $rawId = trim($rawId);
    if (preg_match('/^[1-9][0-9]*$/', $rawId) !== 1) {
        http_response_code(422);
        exit('The selected Daily Production Reports are invalid.');
    }
    $requestedIds[] = (int) $rawId;
}
$requestedIds = array_values(array_unique($requestedIds));

if (count($requestedIds) > 250) {
    http_response_code(422);
    exit('A maximum of 250 Daily Production Reports can be downloaded at once.');
}

$placeholders = implode(',', array_fill(0, count($requestedIds), '?'));
$entryParams = $requestedIds;
$entryStmt = $conn->prepare(
    "SELECT *
     FROM production_entries
     WHERE status != 3
       AND deleted_at IS NULL
       AND id IN ({$placeholders})"
);
$entryStmt->bind_param(str_repeat('i', count($entryParams)), ...$entryParams);
$entryStmt->execute();
$entryRows = $entryStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$entryStmt->close();

$entriesById = [];
foreach ($entryRows as $entryRow) {
    $entriesById[(int) $entryRow['id']] = $entryRow;
}

if (count($entriesById) !== count($requestedIds)) {
    http_response_code(404);
    exit('One or more selected Daily Production Reports are no longer available. Refresh the page and try again.');
}

$itemParams = $requestedIds;
$itemStmt = $conn->prepare(
    "SELECT *
     FROM production_particulars
     WHERE status != 3
       AND deleted_at IS NULL
       AND production_entry_id IN ({$placeholders})
     ORDER BY production_entry_id, id"
);
$itemStmt->bind_param(str_repeat('i', count($itemParams)), ...$itemParams);
$itemStmt->execute();
$itemRows = $itemStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$itemStmt->close();

$itemsByEntryId = [];
foreach ($itemRows as $itemRow) {
    $entryId = (int) $itemRow['production_entry_id'];
    $itemsByEntryId[$entryId][] = $itemRow;
}

$pages = [];
foreach ($requestedIds as $requestedId) {
    $chunks = array_chunk($itemsByEntryId[$requestedId] ?? [], 20) ?: [[]];
    foreach ($chunks as $chunk) {
        $pages[] = [
            'entry' => $entriesById[$requestedId],
            'items' => $chunk,
        ];
    }
}

ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Daily Production Reports</title>
    <style>
        .page {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }
        .page:last-child {
            page-break-after: auto !important;
        }
    </style>
</head>
<body style="margin: 0;">
    <div id="dailyProductionReportContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php foreach ($pages as $pageIndex => $reportPage): ?>
            <?php
                $row = $reportPage['entry'];
                $pageProducts = $reportPage['items'];
                $emptyRows = 20 - count($pageProducts);
                $isLastPage = $pageIndex === array_key_last($pages);
            ?>
            <div class="page" style="page-break-after: <?= $isLastPage ? 'auto' : 'always' ?>;">
                <div style="border-left: 1px solid #000; font-size:14px;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr style="line-height: 18px; border-top: 1px solid #000; border-bottom: 1px solid #000;">
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><strong>Date</strong></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><strong>Month/Year</strong></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><strong>Total Man Power</strong></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><strong>Total Working Hours</strong></td>
                            <td style="padding-left:5px; width: 25%; border-right: 1px solid #000;"><strong>Batch Number</strong></td>
                        </tr>
                        <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars(formatDateDMY((string) ($row['entry_date'] ?? '')), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><?= htmlspecialchars(formatMonthYearToMY((string) ($row['month_year'] ?? '')), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($row['total_man_power'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($row['total_working_hours'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 25%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($row['batch_number'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>
                    </table>
                </div>

                <div style="font-size:14px; margin-top:20px;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr style="line-height: 18px; background-color:#D3D3D3; border-bottom: 1px solid #000;">
                            <td style="width: 15%; border: 1px solid #000; text-align:center; font-weight: bold;">Department</td>
                            <td style="width: 15%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Particulars</td>
                            <td style="width: 20%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Product</td>
                            <td style="width: 15%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Yield</td>
                            <td style="width: 10%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Unit</td>
                            <td style="width: 10%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Man Power</td>
                            <td style="width: 15%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Filled By</td>
                        </tr>
                        <?php foreach ($pageProducts as $product): ?>
                            <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                                <td style="padding-left:5px; border-left: 1px solid #000; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['department'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td style="padding-left:5px; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['particular'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td style="padding-left:5px; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['product'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td style="padding-left:5px; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['total_yield'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                                <td style="padding-left:5px; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['qty_unit'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td style="padding-left:5px; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['man_power'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                                <td style="padding-left:5px; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($product['filled_by'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php for ($emptyIndex = 0; $emptyIndex < $emptyRows; $emptyIndex++): ?>
                            <tr style="line-height: 18px; border-bottom: 1px solid #fff;">
                                <td style="border-left: 1px solid #fff; border-right: 1px solid #fff;">&nbsp;</td>
                                <td style="border-right: 1px solid #fff;">&nbsp;</td>
                                <td style="border-right: 1px solid #fff;">&nbsp;</td>
                                <td style="border-right: 1px solid #fff;">&nbsp;</td>
                                <td style="border-right: 1px solid #fff;">&nbsp;</td>
                                <td style="border-right: 1px solid #fff;">&nbsp;</td>
                                <td style="border-right: 1px solid #fff;">&nbsp;</td>
                            </tr>
                        <?php endfor; ?>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
<?php
$html = (string) ob_get_clean();
documentPdfStream($html, 'daily_production_reports_' . date('Ymd_His'));
?>
