<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage system configurations</p>
        </div>
    </div>
    <div class="accordion mt-3" id="settingsAccordion">
        <div class="accordion-item mb-3 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="flex w-full items-center justify-between bg-slate-50/50 px-5 py-2.5 text-left text-sm font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none"
                    onclick="$('#collapseDesignationOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Designation</span>
                    <i class="ti ti-chevron-down chevron transition-transform duration-300"></i>
                </button>
            </h2>
            <div id="collapseDesignationOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div
                                class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <input type="hidden" id="perPageSelectDesignation" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="designationPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="designation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="designation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="designation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="designation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="designation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="designation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchDesignation"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search Data...">
                                </div>
                                <button type="button"
                                    class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    data-bs-toggle="modal" data-bs-target="#designationAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                    <i class="ti ti-plus text-lg"></i>
                                </button>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="w-16 border-b border-slate-200 px-6 py-3">#</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Name</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Short Name</th>
                                        <!-- <th class="border-b border-slate-200 px-6 py-3">Description</th> -->
                                        <th class="border-b border-slate-200 px-6 py-3">Status</th>
                                        <th class="w-48 border-b border-slate-200 px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="designationTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectDesignation + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperDesignation', 'paginationSummaryDesignation', 'footerPerPageSelectDesignation') ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item mb-3 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="flex w-full items-center justify-between bg-slate-50/50 px-5 py-2.5 text-left text-sm font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none"
                    onclick="$('#collapseHolidaysOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Holidays</span>
                    <i class="ti ti-chevron-down chevron transition-transform duration-300"></i>
                </button>
            </h2>
            <div id="collapseHolidaysOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <div class="border-b border-amber-200 bg-amber-50 px-6 py-3 text-sm text-amber-800">
                            <i class="ti ti-alert-triangle me-1"></i>
                            <strong>Superseded.</strong> Holidays are now maintained per company and year in
                            <a class="font-bold underline" href="index.php?page=annual-calendar">Annual Calendar &amp; Working Days</a>.
                            This legacy list is read-only and is kept for historical reference only.
                        </div>
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div
                                class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <input type="hidden" id="perPageSelectHolidays" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="holidaysPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="holidays-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="holidays-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="holidays-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="holidays-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="holidays-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="holidays-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchHolidays"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search Data...">
                                </div>
                                <a href="index.php?page=annual-calendar"
                                    class="inline-flex h-10 shrink-0 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50">
                                    <i class="ti ti-calendar-stats text-lg"></i>
                                    <span>Open Annual Calendar</span>
                                </a>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="w-16 border-b border-slate-200 px-6 py-3">#</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Date</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Name</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Type</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Status</th>
                                        <th class="w-48 border-b border-slate-200 px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="HolidaysTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectHolidays + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperHolidays', 'paginationSummaryHolidays', 'footerPerPageSelectHolidays') ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item mb-3 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="flex w-full items-center justify-between bg-slate-50/50 px-5 py-2.5 text-left text-sm font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none"
                    onclick="$('#collapseShiftsOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Shift</span>
                    <i class="ti ti-chevron-down chevron transition-transform duration-300"></i>
                </button>
            </h2>
            <div id="collapseShiftsOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div
                                class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <input type="hidden" id="perPageSelectShifts" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="shiftsPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchShifts"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search Data...">
                                </div>
                                <button type="button"
                                    class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    data-bs-toggle="modal" data-bs-target="#shiftAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                    <i class="ti ti-plus text-lg"></i>
                                </button>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="w-16 border-b border-slate-200 px-6 py-3">#</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Name</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Shift Timing</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Lunch Timing</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Days</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Status</th>
                                        <th class="w-48 border-b border-slate-200 px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="shiftsTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectShifts + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperShifts', 'paginationSummaryShifts', 'footerPerPageSelectShifts') ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item mb-3 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="flex w-full items-center justify-between bg-slate-50/50 px-5 py-2.5 text-left text-sm font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none"
                    onclick="$('#collapseShiftRoasterOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Shift Roaster</span>
                    <i class="ti ti-chevron-down chevron transition-transform duration-300"></i>
                </button>
            </h2>
            <div id="collapseShiftRoasterOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div
                                class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <input type="hidden" id="perPageSelectShiftRoaster" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="shiftRoasterPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="shiftroaster-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="shiftroaster-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="shiftroaster-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="shiftroaster-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="shiftroaster-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="shiftroaster-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchShiftRoaster"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search Data...">
                                </div>
                                <button type="button"
                                    class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    data-bs-toggle="modal" data-bs-target="#shiftRoasterAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                    <i class="ti ti-plus text-lg"></i>
                                </button>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="w-16 border-b border-slate-200 px-6 py-3">#</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Name</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Shift</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Type</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Shift Date</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Date Range</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Status</th>
                                        <th class="w-48 border-b border-slate-200 px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="shiftRoasterTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectShiftRoaster + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperShiftRoaster', 'paginationSummaryShiftRoaster', 'footerPerPageSelectShiftRoaster') ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item mb-3 rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="flex w-full items-center justify-between bg-slate-50/50 px-5 py-2.5 text-left text-sm font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none"
                    onclick="$('#collapseBanksOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Bank</span>
                    <i class="ti ti-chevron-down chevron transition-transform duration-300"></i>
                </button>
            </h2>
            <div id="collapseBanksOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div
                                class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <input type="hidden" id="perPageSelectBanks" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="banksPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchBanks"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search Data...">
                                </div>
                                <button type="button"
                                    class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    data-bs-toggle="modal" data-bs-target="#banksAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                    <i class="ti ti-plus text-lg"></i>
                                </button>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="w-16 border-b border-slate-200 px-6 py-3">#</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Name</th>
                                        <th class="border-b border-slate-200 px-6 py-3">Status</th>
                                        <th class="w-48 border-b border-slate-200 px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="banksTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectBanks + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperBanks', 'paginationSummaryBanks', 'footerPerPageSelectBanks') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="designationAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Designation</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="adddesignationForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="designationName" class="mb-1 block text-sm font-medium text-slate-800">Name
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="designationName" autocomplete="off" name="designationName"
                                    class="input-theme" placeholder="Enter Name" required />
                            </div>
                            <div>
                                <label for="designationShortName"
                                    class="mb-1 block text-sm font-medium text-slate-800">Short Name <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="text" id="designationShortName" autocomplete="off"
                                    name="designationShortName" class="input-theme" placeholder="Enter Short Name"
                                    required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="designationDescription"
                                    class="mb-1 block text-sm font-medium text-slate-800">Description</label>
                                <textarea id="designationDescription" autocomplete="off" name="designationDescription"
                                    class="input-theme" placeholder="Enter Description" rows="2"></textarea>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="activStatusDesignation" name="designationStatus"
                                            value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="inactiveStatusDesignation" name="designationStatus"
                                            value="0"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editDesignationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Designation</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editDesignationForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="holidaysAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Holiday</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addHolidaysForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="holidayDate" class="mb-1 block text-sm font-medium text-slate-800">Date
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="holidayDate" autocomplete="off" name="holidayDate"
                                    class="input-theme" placeholder="Enter Date" required />
                            </div>
                            <div>
                                <label for="holidayName" class="mb-1 block text-sm font-medium text-slate-800">Name
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="holidayName" autocomplete="off" name="holidayName"
                                    class="input-theme" placeholder="Enter Name" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="holidayType">Type
                                    <strong class="text-rose-500">*</strong></label>
                                <select name="holidayType" id="holidayType" class="input-theme" required>
                                    <option value="">----Select----</option>
                                    <?php if (isset(Constant::HR_SETTINGS['HOLIDAYS_TYPE'])) { ?>
                                        <?php foreach (Constant::HR_SETTINGS['HOLIDAYS_TYPE'] as $holidayTypeKey => $holidayTypeVal) { ?>
                                            <option value="<?php echo $holidayTypeKey; ?>">
                                                <?php echo $holidayTypeVal['label']; ?>
                                            </option>
                                        <?php } ?>
                                    <?php } ?>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="activStatusHoliday" name="holidayStatus" value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="inactiveStatusHoliday" name="holidayStatus" value="0"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editHolidaysModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Holiday</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editHolidayForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="shiftAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Shift</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addshiftForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="shiftName" class="mb-1 block text-sm font-medium text-slate-800">Name
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="shiftName" autocomplete="off" name="shiftName"
                                    class="input-theme" placeholder="Enter Name" required />
                            </div>
                            <div>
                                <label for="shiftStartTime" class="mb-1 block text-sm font-medium text-slate-800">Start
                                    Time <strong class="text-rose-500">*</strong></label>
                                <input type="time" id="shiftStartTime" autocomplete="off" name="shiftStartTime"
                                    class="input-theme" placeholder="Enter Start Time" required />
                            </div>
                            <div>
                                <label for="shiftEndTime" class="mb-1 block text-sm font-medium text-slate-800">End Time
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="time" id="shiftEndTime" autocomplete="off" name="shiftEndTime"
                                    class="input-theme" placeholder="Enter End Time" required />
                            </div>
                        </div>
                        <div class="mb-4 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
                            <label class="mb-2 block text-sm font-medium text-slate-800">Working Days <strong
                                    class="text-rose-500">*</strong></label>
                            <div class="flex flex-wrap gap-4">
                                <?php if (!empty(Constant::HR_SETTINGS['WORKING_DAYS'])) {
                                    foreach (Constant::HR_SETTINGS['WORKING_DAYS'] as $dayId => $day) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                            <input type="checkbox" id="workDay<?= $dayId ?>" name="WorkDay[]"
                                                value="<?= $dayId ?>"
                                                class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                            <?= $day['label'] ?>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="shiftLunchStartTime"
                                    class="mb-1 block text-sm font-medium text-slate-800">Lunch Start Time </label>
                                <input type="time" id="shiftLunchStartTime" autocomplete="off"
                                    name="shiftLunchStartTime" class="input-theme"
                                    placeholder="Enter Lunch Start Time" />
                            </div>
                            <div>
                                <label for="shiftLunchEndTime"
                                    class="mb-1 block text-sm font-medium text-slate-800">Lunch End Time </label>
                                <input type="time" id="shiftLunchEndTime" autocomplete="off" name="shiftLunchEndTime"
                                    class="input-theme" placeholder="Enter Lunch End Time" />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="shiftLateGraceTime"
                                    class="mb-1 block text-sm font-medium text-slate-800">Late Grace (Minutes) </label>
                                <input type="number" min="0" max="120" id="shiftLateGraceTime" autocomplete="off"
                                    name="shiftLateGraceTime" class="input-theme"
                                    placeholder="Enter Late Grace in Minutes" />
                            </div>
                            <div>
                                <label for="shiftEarlyLeaveTime"
                                    class="mb-1 block text-sm font-medium text-slate-800">Early Leaves (minutes)
                                </label>
                                <input type="number" min="0" max="120" id="shiftEarlyLeaveTime" autocomplete="off"
                                    name="shiftEarlyLeaveTime" class="input-theme"
                                    placeholder="Enter Early Leaves in Minutes" />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="shiftHalfDayHours"
                                    class="mb-1 block text-sm font-medium text-slate-800">Half Day (Hours) </label>
                                <input type="number" step="any" min="0" max="6" id="shiftHalfDayHours"
                                    autocomplete="off" name="shiftHalfDayHours" class="input-theme"
                                    placeholder="Enter Half Day Hours" />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="activStatusShift" name="shiftsStatus" value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="inactiveStatusShift" name="shiftsStatus" value="0"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editShiftModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Shift</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editShiftForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="banksAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Bank</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addBankForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="bankName" class="mb-1 block text-sm font-medium text-slate-800">Bank Name
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="bankName" autocomplete="off" name="bankName" class="input-theme"
                                    placeholder="Enter Bank Name" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="activStatusBank" name="bankStatus" value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="inactiveStatusBank" name="bankStatus" value="0"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="shiftRoasterAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-calendar-event text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Shift Roaster</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="employeeShiftRosterForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Employee <strong
                                        class="text-rose-500">*</strong></label>
                                <select name="employee_id[]" class="selectpicker" data-width="100%" data-container="#shiftRoasterAddModal" data-style="w-full h-9 rounded-xl border border-slate-200 bg-white px-3 py-[6px] text-sm font-medium text-slate-700 shadow-sm outline-none hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 2" title="---Select Employee---" id="employeeList" multiple
                                    required></select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Shift <strong
                                        class="text-rose-500">*</strong></label>
                                <select name="shift_id" class="input-theme" id="shiftList" required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Roster Type <strong
                                        class="text-rose-500">*</strong></label>
                                <select name="roster_type" id="roster_type" class="input-theme">
                                    <?php if (!empty(Constant::HR_SETTINGS['SHIFT_ROASTER_TYPE'])) {
                                        foreach (Constant::HR_SETTINGS['SHIFT_ROASTER_TYPE'] as $srtKey => $srtVal) { ?>
                                            <option value="<?= $srtKey ?>"><?= $srtVal['label']; ?></option>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="weekly-box">
                                <label class="mb-1 block text-sm font-medium text-slate-800">Select Duration <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-2">
                                    <input type="date" name="start_date" class="input-theme w-full">
                                    <input type="date" name="end_date" class="input-theme w-full">
                                </div>
                            </div>
                            <div class="custom-box hidden">
                                <label class="mb-1 block text-sm font-medium text-slate-800">Shift Date <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="date" name="shift_date" class="input-theme">
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Save Roster
                        </button>
                    </div>

                    <input type="hidden" name="addEmployeeShiftRoster" value="1">
                </form>
            </div>
        </div>
    </div>


</div>

<?php startSection('scripts'); ?>
<script>
    const settingsCsrfToken = <?= json_encode($_SESSION['csrf_token'] ?? '') ?>;
    let currentPage = 1;
    let currentDesignPage = 1;
    let currentShiftPage = 1;
    let currentBankPage = 1;

    function loadDesignationTable(page = 1) {
        currentDesignPage = page;
        const search = $('#searchDesignation').val().trim();
        const perPage = $('#perPageSelectDesignation').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadDesignations: 'loadDesignations',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#designationTableBody').html(response.table || '');
                $('#paginationWrapperDesignation').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryDesignation', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectDesignation');
            },
            error: function () {
                $('#designationTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperDesignation').html('');
            }
        });
    }

    function loadHolidaysTable(page = 1) {
        currentPage = page;
        const search = $('#searchHolidays').val().trim();
        const perPage = $('#perPageSelectHolidays').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadHolidays: 'loadHolidays',
                csrf_token: settingsCsrfToken,
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#HolidaysTableBody').html(response.table || '');
                $('#paginationWrapperHolidays').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryHolidays', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectHolidays');
            },
            error: function () {
                $('#HolidaysTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperHolidays').html('');
            }
        });
    }

    function loadShiftTable(page = 1) {
        currentShiftPage = page;
        const search = $('#searchShifts').val().trim();
        const perPage = $('#perPageSelectShifts').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadShifts: 'loadShifts',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#shiftsTableBody').html(response.table || '');
                $('#paginationWrapperShifts').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryShifts', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectShifts');
            },
            error: function () {
                $('#shiftsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperShifts').html('');
            }
        });
    }

    function loadShiftRoasterTable(page = 1) {
        currentShiftPage = page;
        const search = $('#searchShiftRoaster').val().trim();
        const perPage = $('#perPageSelectShiftRoaster').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadShiftRoaster: 'loadShiftRoaster',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#shiftRoasterTableBody').html(response.table || '');
                $('#paginationWrapperShiftRoaster').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryShiftRoaster', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectShiftRoaster');
            },
            error: function () {
                $('#shiftRoasterTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperShiftRoaster').html('');
            }
        });
    }

    function loadBankTable(page = 1) {
        currentBankPage = page;
        const search = $('#searchBanks').val().trim();
        const perPage = $('#perPageSelectBanks').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadBanks: 'loadBanks',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#banksTableBody').html(response.table || '');
                $('#paginationWrapperBanks').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryBanks', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectBanks');
            },
            error: function () {
                $('#banksTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperBanks').html('');
            }
        });
    }

    function loadAllBankList() {
        $('#bankNameList').html('');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                getBankList: 'getBankList'
            },
            success: function (response) {
                let html = '<option value="">----Select Bank----</option>';
                response.forEach(function (bankName) {
                    html += `<option value="${bankName.bank_name}">${bankName.bank_name}</option>`;
                });
                $('#bankNameList').html(html);
            },
            error: function () {
                $('#bankNameList').html('');
            }
        });
    }

    function loadEmployeesList() {
        return $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadEmployeesListOption: 'loadEmployeesListOption' }
        }).then(function (response) {
            let optionsHtml = '';
            response.forEach(emp => {
                optionsHtml += `<option value="${emp.id}">
                (${emp.emp_code}) ${emp.first_name} ${emp.last_name}
                </option>`;
            });
            $("#employeeList").html(optionsHtml);
            $('#employeeList').selectpicker('refresh');
        });
    }
    function loadShiftList() {
        return $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadShiftListOption: 'loadShiftListOption' }
        }).then(function (response) {
            let optionsHtml = '<option value="">---Select----</option>';
            response.forEach(sft => {
                optionsHtml += `<option value="${sft.id}">${sft.name}
                </option>`;
            });
            $("#shiftList").html(optionsHtml);
        });
    }

    $(document).ready(function () {
        loadDesignationTable();
        loadHolidaysTable();
        loadShiftTable();
        loadShiftRoasterTable();
        loadBankTable();
        loadEmployeesList();
        loadShiftList();
        $('#searchDesignation').on('input', function () {
            loadDesignationTable(1);
        });
        $('#footerPerPageSelectDesignation').on('change', function () {
            $('#perPageSelectDesignation').val($(this).val());
            loadDesignationTable(1);
        });
        $('#searchHolidays').on('input', function () {
            loadHolidaysTable(1);
        });
        $('#footerPerPageSelectHolidays').on('change', function () {
            $('#perPageSelectHolidays').val($(this).val());
            loadHolidaysTable(1);
        });
        $('#searchShifts').on('input', function () {
            loadShiftTable(1);
        });
        $('#footerPerPageSelectShifts').on('change', function () {
            $('#perPageSelectShifts').val($(this).val());
            loadShiftTable(1);
        });
        $('#searchShiftRoaster').on('input', function () {
            loadShiftRoasterTable(1);
        });
        $('#footerPerPageSelectShiftRoaster').on('change', function () {
            $('#perPageSelectShiftRoaster').val($(this).val());
            loadShiftRoasterTable(1);
        });
        $('#searchBanks').on('input', function () {
            loadBankTable(1);
        });
        $('#footerPerPageSelectBanks').on('change', function () {
            $('#perPageSelectBanks').val($(this).val());
            loadBankTable(1);
        });

        // Top-strip per-page dropdown handlers
        $(document).on('click', '.designation-per-page-item', function () {
            const val = $(this).data('val');
            $('#designationPerPageText').text($(this).text());
            $('#footerPerPageSelectDesignation').val(val).trigger('change');
        });
        $(document).on('click', '.holidays-per-page-item', function () {
            const val = $(this).data('val');
            $('#holidaysPerPageText').text($(this).text());
            $('#footerPerPageSelectHolidays').val(val).trigger('change');
        });
        $(document).on('click', '.shifts-per-page-item', function () {
            const val = $(this).data('val');
            $('#shiftsPerPageText').text($(this).text());
            $('#footerPerPageSelectShifts').val(val).trigger('change');
        });
        $(document).on('click', '.shiftroaster-per-page-item', function () {
            const val = $(this).data('val');
            $('#shiftRoasterPerPageText').text($(this).text());
            $('#footerPerPageSelectShiftRoaster').val(val).trigger('change');
        });
        $(document).on('click', '.banks-per-page-item', function () {
            const val = $(this).data('val');
            $('#banksPerPageText').text($(this).text());
            $('#footerPerPageSelectBanks').val(val).trigger('change');
        });

        $('#designationAddModal').on('hidden.bs.modal', function () {
            $('#adddesignationForm')[0].reset();
        });

        $('#holidaysAddModal').on('hidden.bs.modal', function () {
            $('#addHolidaysForm')[0].reset();
        });

        $('#shiftAddModal').on('hidden.bs.modal', function () {
            $('#addshiftForm')[0].reset();
        });

        $('#banksAddModal').on('hidden.bs.modal', function () {
            $('#addBankForm')[0].reset();
        });

        $('#shiftRoasterAddModal').on('hidden.bs.modal', function () {
            $('#employeeShiftRosterForm')[0].reset();
            if ($('#employeeList').length) {
                $('#employeeList').val('').selectpicker('refresh');
            }
            if ($('#shiftList').length) {
                $('#shiftList').val('').trigger('change');
            }
            if ($('#roster_type').length) {
                $('#roster_type').val('1').trigger('change');
            }
        });

        $('#adddesignationForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('adddesignationForm');
            const formData = new FormData(form);
            formData.append('addDesignation', 'addDesignation');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#designationAddModal').modal('hide');
                        $('#adddesignationForm')[0].reset();
                        loadDesignationTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
        $('#addHolidaysForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addHolidaysForm');
            const formData = new FormData(form);
            formData.append('addHoliday', 'addHoliday');
            formData.append('csrf_token', settingsCsrfToken);
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#holidaysAddModal').modal('hide');
                        $('#addHolidaysForm')[0].reset();
                        loadHolidaysTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addshiftForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addshiftForm');
            const formData = new FormData(form);
            formData.append('addShift', 'addShift');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#shiftAddModal').modal('hide');
                        $('#addshiftForm')[0].reset();
                        loadShiftTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addBankForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addBankForm');
            const formData = new FormData(form);
            formData.append('addBank', 'addBank');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#banksAddModal').modal('hide');
                        $('#addBankForm')[0].reset();
                        loadBankTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $("#banksBranchAddModalBtn").on('click', function () {
            loadAllBankList();
            $("#banksBranchAddModal").modal('show');
        });

        $("#roster_type").change(function () {
            if ($(this).val() == 1) {
                $(".weekly-box").show();
                $(".custom-box").addClass("d-none");
            } else {
                $(".weekly-box").hide();
                $(".custom-box").removeClass("d-none");
            }
        });

        $('#employeeShiftRosterForm').on('submit', function (e) {
            e.preventDefault();
            let employees = $('#employeeList').val();
            let type = $('#roster_type').val();
            let week = $('select[name="week_no"]').val();
            let date = $('input[name="shift_date"]').val();

            if (!employees || employees.length === 0) {
                toastr.error('Please select at least one employee');
                return false;
            }

            if (type == APP_CONST.HR_SETTINGS.SHIFT_ROASTER_TYPE_LABEL.Weekly && week == '') {
                toastr.error('Please select week no');

                return false;
            }

            if (type == APP_CONST.HR_SETTINGS.SHIFT_ROASTER_TYPE_LABEL.CustomDay && date == '') {
                toastr.error('Please select shift date');
                e.preventDefault();
                return false;
            }
            const form = document.getElementById('employeeShiftRosterForm');
            const formData = new FormData(form);
            formData.append('addEmployeeShiftRoster', 'addEmployeeShiftRoster');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#shiftRoasterAddModal').modal('hide');
                        $('#employeeShiftRosterForm').find('modal-body').html();
                        loadShiftRoasterTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });

    $(document).on('click', '.deleteDesignationBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteDesignation: 'deleteDesignation',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadDesignationTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editDesignationBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editDesignationForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchDesignationRecord: 'fetchDesignationRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editDesignationModal').modal('show');
                        $('#editDesignationForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editDesignationForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editDesignationForm');
        const formData = new FormData(form);
        formData.append('updateDesignation', 'updateDesignation');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editDesignationModal').modal('hide');
                    $('#editDesignationForm').find('modal-body').html();
                    loadDesignationTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteHolidayBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteHoliday: 'deleteHoliday',
                        csrf_token: settingsCsrfToken,
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadHolidaysTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editHolidayBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editHolidayForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchHolidayRecord: 'fetchHolidayRecord', csrf_token: settingsCsrfToken, id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editHolidaysModal').modal('show');
                        $('#editHolidayForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editHolidayForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editHolidayForm');
        const formData = new FormData(form);
        formData.append('updateHoliday', 'updateHoliday');
        formData.append('csrf_token', settingsCsrfToken);
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editHolidaysModal').modal('hide');
                    $('#editHolidayForm').find('modal-body').html();
                    loadHolidaysTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteShiftBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteShift: 'deleteShift',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadShiftTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editShiftBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editShiftForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchShiftRecord: 'fetchShiftRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editShiftModal').modal('show');
                        $('#editShiftForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editShiftForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editShiftForm');
        const formData = new FormData(form);
        formData.append('updateShift', 'updateShift');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editShiftModal').modal('hide');
                    $('#editShiftForm').find('modal-body').html();
                    loadShiftTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteBankBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteBank: 'deleteBank',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadBankTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.shiftRoasterDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        deleteRoaster: 'deleteRoaster',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadShiftRoasterTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.shiftRoasterUnlockBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You want unlock it!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, unlock it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        unlockRoaster: 'unlockRoaster',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadShiftRoasterTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Unlocked!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });
    $(document).on('click', '.shiftRoasterLockBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You wanted to lock it!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, lock it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        lockRoaster: 'lockRoaster',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadShiftRoasterTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Locked!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

</script>
<?php endSection(); ?>
