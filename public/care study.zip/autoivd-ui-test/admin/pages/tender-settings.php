<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
        </div>
    </div>
    <div class="accordion mt-3 flex flex-col gap-4" id="tenderSettingsAccordion">
        <div
            class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="group flex w-full items-center justify-between bg-white px-6 py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none border-b border-slate-100"
                    onclick="$('#collapseDesignationOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Tender Institution</span>
                    <span
                        class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200"><i
                            class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i></span>
                </button>
            </h2>
            <div id="collapseDesignationOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <!-- Search input -->
                                <input type="hidden" id="perPageSelectInstitutions" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="institutionsPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="institutions-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="institutions-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="institutions-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="institutions-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="institutions-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="institutions-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchInstitutions"
                                        class="block h-full w-full rounded-xl border-0 bg-transparent py-2 pl-10 pr-3 text-sm text-slate-700 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-0"
                                        placeholder="Search...">
                                </div>
                                <div class="flex h-10 items-center gap-2 border-l border-slate-200 pl-3 shrink-0">
                                    <!-- Add New button -->
                                    <button type="button"
                                        class="inline-flex h-9 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                        data-bs-toggle="modal" data-bs-target="#institutionsAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                        <i class="ti ti-plus text-lg"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="overflow-x-auto border-t border-slate-200 w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="px-6 py-3">#</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Name"> Name</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Short Name"> Short Name</th>
                                        <!-- <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Size"> Description</th> -->
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Status"> Status</th>
                                        <th class="px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="institutionsTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectInstitutions + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperInstitutions', 'InstitutionsTableInfo', 'footerPerPageSelectInstitutions') ?>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="group flex w-full items-center justify-between bg-white px-6 py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none border-b border-slate-100"
                    onclick="$('#collapseTenderVendorsOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Vendor List</span>
                    <span
                        class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200"><i
                            class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i></span>
                </button>
            </h2>
            <div id="collapseTenderVendorsOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <!-- Search input -->
                                <input type="hidden" id="perPageSelectVendors" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="vendorsPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="vendors-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="vendors-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="vendors-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="vendors-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="vendors-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="vendors-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchVendors"
                                        class="block h-full w-full rounded-xl border-0 bg-transparent py-2 pl-10 pr-3 text-sm text-slate-700 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-0"
                                        placeholder="Search...">
                                </div>
                                <div class="flex h-10 items-center gap-2 border-l border-slate-200 pl-3 shrink-0">
                                    <!-- Add New button -->
                                    <button type="button"
                                        class="inline-flex h-9 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                        data-bs-toggle="modal" data-bs-target="#tenderVendorsAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                        <i class="ti ti-plus text-lg"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="overflow-x-auto border-t border-slate-200 w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="px-6 py-3">#</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="right"
                                            data-bs-original-title="Vendor Name">Name</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="right"
                                            data-bs-original-title="GST">GST</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="right"
                                            data-bs-original-title="PAN">PAN</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="right"
                                            data-bs-original-title="Status"> Status</th>
                                        <th class="px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="VendorsTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectVendors + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperVendors', 'VendorsTableInfo', 'footerPerPageSelectVendors') ?>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="group flex w-full items-center justify-between bg-white px-6 py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none border-b border-slate-100 d-none"
                    onclick="$('#collapseShiftsOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Shift</span>
                    <span
                        class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200"><i
                            class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i></span>
                </button>
            </h2>
            <div id="collapseShiftsOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <!-- Search input -->
                                <input type="hidden" id="perPageSelectShifts" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="shiftsPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="shifts-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchShifts"
                                        class="block h-full w-full rounded-xl border-0 bg-transparent py-2 pl-10 pr-3 text-sm text-slate-700 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-0"
                                        placeholder="Search...">
                                </div>
                                <div class="flex h-10 items-center gap-2 border-l border-slate-200 pl-3 shrink-0">
                                    <!-- Add New button -->
                                    <button type="button"
                                        class="inline-flex h-9 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                        data-bs-toggle="modal" data-bs-target="#shiftAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                        <i class="ti ti-plus text-lg"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="overflow-x-auto border-t border-slate-200 w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="px-6 py-3">#</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Name"> Name</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Shift Timing"> Shift Timing</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Lunch Timing"> Lunch Timing</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Days"> Days</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Status"> Status</th>
                                        <th class="px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="shiftsTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectShifts + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperShifts', 'ShiftsTableInfo', 'footerPerPageSelectShifts') ?>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
            <h2 class="accordion-header m-0">
                <button type="button"
                    class="group flex w-full items-center justify-between bg-white px-6 py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none border-b border-slate-100"
                    onclick="$('#collapseBanksOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                    <span>Bank</span>
                    <span
                        class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200"><i
                            class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i></span>
                </button>
            </h2>
            <div id="collapseBanksOptions" style="display:none;">
                <div class="border-t border-slate-200 p-0">
                    <div class="">
                        <!-- Toolbar -->
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <!-- Search input -->
                                <input type="hidden" id="perPageSelectBanks" value="5">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="banksPerPageText" class="whitespace-nowrap">5 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="banks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>
                                <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchBanks"
                                        class="block h-full w-full rounded-xl border-0 bg-transparent py-2 pl-10 pr-3 text-sm text-slate-700 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-0"
                                        placeholder="Search...">
                                </div>
                                <div class="flex h-10 items-center gap-2 border-l border-slate-200 pl-3 shrink-0">
                                    <!-- Add New button -->
                                    <button type="button"
                                        class="inline-flex h-9 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                        data-bs-toggle="modal" data-bs-target="#banksAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                        <i class="ti ti-plus text-lg"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="overflow-x-auto border-t border-slate-200 w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="px-6 py-3">#</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Name"> Name</th>
                                        <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-original-title="Status"> Status</th>
                                        <th class="px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="banksTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelectBanks + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapperBanks', 'BanksTableInfo', 'footerPerPageSelectBanks') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="institutionsAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add Institution
                    </h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addTenderInstitutionsForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="designationName" class="form-label">Name <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="designationName" autocomplete="off" name="designationName"
                                    class="form-control" placeholder="Enter Name" required />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="designationShortName" class="form-label">Short Name <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="designationShortName" autocomplete="off"
                                    name="designationShortName" class="form-control" placeholder="Enter Short Name"
                                    required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="designationDescription" class="form-label">Description</label>
                                <textarea id="designationDescription" autocomplete="off" name="designationDescription"
                                    class="form-control" placeholder="Enter Description"></textarea>
                            </div>
                            <div class="col">
                                <small class="text-dark fw-medium d-block">Status <strong
                                        class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatusDesignation"
                                        name="designationStatus" value="1" required />
                                    <label class="form-check-label" for="activStatusDesignation">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input" type="radio" id="inactiveStatusDesignation"
                                        name="designationStatus" value="0" />
                                    <label class="form-check-label" for="inactiveStatusDesignation">Inactive</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editTenderInstitutionsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Edit
                        Institution</h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editTenderInstitutionsForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="tenderVendorsAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add Vendor</h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addTenderVendorsForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="vendorName" class="form-label">Name <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="vendorName" autocomplete="off" name="vendorName"
                                    class="form-control" placeholder="Enter Name" required />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="gstNumber" class="form-label">GST No</label>
                                <input type="text" id="gstNumber" autocomplete="off" name="gstNumber"
                                    class="form-control" placeholder="Enter GST" />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="panNo" class="form-label">PAN No</label>
                                <input type="text" id="panNo" autocomplete="off" name="panNo" class="form-control"
                                    placeholder="Enter PAN" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="contactPerson" class="form-label">Contact Person Name</label>
                                <input type="text" id="contactPerson" autocomplete="off" name="contactPerson"
                                    class="form-control" placeholder="Enter Contact Person Name" />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="mobile" class="form-label">Mobile</label>
                                <input type="text" id="mobile" autocomplete="off" name="mobile" class="form-control"
                                    placeholder="Enter Mobile" />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" id="email" autocomplete="off" name="email" class="form-control"
                                    placeholder="Enter Email" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea id="address" autocomplete="off" name="address" class="form-control"
                                    placeholder="Enter Address"></textarea>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="city" class="form-label">City</label>
                                <input type="text" id="city" autocomplete="off" name="city" class="form-control"
                                    placeholder="Enter City" />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="state" class="form-label">State</label>
                                <input type="text" id="state" autocomplete="off" name="state" class="form-control"
                                    placeholder="Enter State" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="pincode" class="form-label">Pincode</label>
                                <input type="text" id="pincode" autocomplete="off" name="pincode" class="form-control"
                                    placeholder="Enter Pincode" />
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_supplier" value="1" />
                                    <label class="form-check-label">
                                        Is Supplier ?
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_contractor" value="1" />
                                    <label class="form-check-label">
                                        Is Contractor ?
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_consultant" value="1" />
                                    <label class="form-check-label">
                                        Is Consultant ?
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <small class="text-dark fw-medium d-block">Status <strong
                                        class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatusVendor"
                                        name="vendorStatus" value="1" required />
                                    <label class="form-check-label" for="activStatusVendor">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input" type="radio" id="inactiveStatusVendor"
                                        name="vendorStatus" value="0" />
                                    <label class="form-check-label" for="inactiveStatusVendor">Inactive</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editTenderVendorModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Vendor</h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editTenderVendorForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="shiftAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add Shift</h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addshiftForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="shiftName" class="form-label">Name <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="shiftName" autocomplete="off" name="shiftName"
                                    class="form-control" placeholder="Enter Name" required />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="shiftStartTime" class="form-label">Start Time <strong
                                        class="text-danger">*</strong></label>
                                <input type="time" id="shiftStartTime" autocomplete="off" name="shiftStartTime"
                                    class="form-control" placeholder="Enter Start Time" required />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="shiftEndTime" class="form-label">End Time <strong
                                        class="text-danger">*</strong></label>
                                <input type="time" id="shiftEndTime" autocomplete="off" name="shiftEndTime"
                                    class="form-control" placeholder="Enter End Time" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <small class="text-dark fw-medium d-block">Working Days <strong
                                        class="text-danger">*</strong></small>
                                <?php if (!empty(Constant::HR_SETTINGS['WORKING_DAYS'])) {
                                    foreach (Constant::HR_SETTINGS['WORKING_DAYS'] as $dayId => $day) { ?>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="workDay<?= $dayId ?>"
                                                name="WorkDay[]" value="<?= $dayId ?>" />
                                            <label class="form-check-label"
                                                for="workDay<?= $dayId ?>"><?= $day['label'] ?></label>
                                        </div>
                                    <?php }
                                } ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="shiftLunchStartTime" class="form-label">Lunch Start Time </label>
                                <input type="time" id="shiftLunchStartTime" autocomplete="off"
                                    name="shiftLunchStartTime" class="form-control"
                                    placeholder="Enter Lunch Start Time" />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="shiftLunchEndTime" class="form-label">Lunch End Time </label>
                                <input type="time" id="shiftLunchEndTime" autocomplete="off" name="shiftLunchEndTime"
                                    class="form-control" placeholder="Enter Lunch End Time" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="shiftLateGraceTime" class="form-label">Late Grace (Minutes) </label>
                                <input type="number" min="0" max="120" id="shiftLateGraceTime" autocomplete="off"
                                    name="shiftLateGraceTime" class="form-control"
                                    placeholder="Enter Late Grace in Minutes" />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="shiftEarlyLeaveTime" class="form-label">Early Leaves (minutes) </label>
                                <input type="number" min="0" max="120" id="shiftEarlyLeaveTime" autocomplete="off"
                                    name="shiftEarlyLeaveTime" class="form-control"
                                    placeholder="Enter Early Leaves in Minutes" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="shiftHalfDayHours" class="form-label">Half Day (Hours) </label>
                                <input type="number" step="any" min="0" max="6" id="shiftHalfDayHours"
                                    autocomplete="off" name="shiftHalfDayHours" class="form-control"
                                    placeholder="Enter Half Day Hours" />
                            </div>
                            <div class="col-md-6">
                                <small class="text-dark fw-medium d-block">Status <strong
                                        class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatusShift"
                                        name="shiftsStatus" value="1" required />
                                    <label class="form-check-label" for="activStatusShift">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input" type="radio" id="inactiveStatusShift"
                                        name="shiftsStatus" value="0" />
                                    <label class="form-check-label" for="inactiveStatusShift">Inactive</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="editShiftModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Shift</h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editShiftForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="banksAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Bank</h5>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addBankForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="bankName" class="form-label">Bank Name <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="bankName" autocomplete="off" name="bankName" class="form-control"
                                    placeholder="Enter Bank Name" required />
                            </div>
                            <div class="col-md-6">
                                <small class="text-dark fw-medium d-block">Status <strong
                                        class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatusBank" name="bankStatus"
                                        value="1" required />
                                    <label class="form-check-label" for="activStatusBank">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input" type="radio" id="inactiveStatusBank"
                                        name="bankStatus" value="0" />
                                    <label class="form-check-label" for="inactiveStatusBank">Inactive</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentDesignPage = 1;
    let currentShiftPage = 1;
    let currentBankPage = 1;

    function loadTenderInstitutionsTable(page = 1) {
        currentDesignPage = page;
        const search = $('#searchInstitutions').val().trim();
        const perPage = $('#perPageSelectInstitutions').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadTenderInstitutions: 'loadTenderInstitutions',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#institutionsTableBody').html(response.table || '');
                $('#paginationWrapperInstitutions').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('InstitutionsTableInfo', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectInstitutions');
            },
            error: function () {
                $('#institutionsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperInstitutions').html('');
            }
        });
    }

    function loadTenderVendorsTable(page = 1) {
        currentPage = page;
        const search = $('#searchVendors').val().trim();
        const perPage = $('#perPageSelectVendors').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadTenderVendors: 'loadTenderVendors',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#VendorsTableBody').html(response.table || '');
                $('#paginationWrapperVendors').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('VendorsTableInfo', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectVendors');
            },
            error: function () {
                $('#VendorsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperVendors').html('');
            }
        });
    }

    function loadShiftTable(page = 1) {
        currentShiftPage = page;
        const search = $('#searchShifts').val().trim();
        const perPage = $('#perPageSelectShifts').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadShifts: 'loadShifts',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#shiftsTableBody').html(response.table || '');
                $('#paginationWrapperShifts').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('ShiftsTableInfo', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectShifts');
            },
            error: function () {
                $('#shiftsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperShifts').html('');
            }
        });
    }

    function loadBankTable(page = 1) {
        currentBankPage = page;
        const search = $('#searchBanks').val().trim();
        const perPage = $('#perPageSelectBanks').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadBanks: 'loadBanks',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#banksTableBody').html(response.table || '');
                $('#paginationWrapperBanks').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('BanksTableInfo', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectBanks');
            },
            error: function () {
                $('#banksTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperBanks').html('');
            }
        });
    }

    function loadAllBankList() {
        $('#bankNameList').html('');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                getBankList: 'getBankList'
            },
            success: function (response) {
                let html = '<option value="">----Select Bank----</option>';
                response.forEach(function (bankName) {
                    html += `<option value="${bankName.bank_name}">${bankName.bank_name}</option>`;
                });
                $('#bankNameList').html(html);
            },
            error: function () {
                $('#bankNameList').html('');
            }
        });
    }

    $(document).ready(function () {
        loadTenderInstitutionsTable();
        loadTenderVendorsTable();
        loadShiftTable();
        loadBankTable();
        $('#searchInstitutions').on('input', function () {
            loadTenderInstitutionsTable(1);
        });
        $('#footerPerPageSelectInstitutions').on('change', function () {
            $('#perPageSelectInstitutions').val($(this).val());
            loadTenderInstitutionsTable(1);
        });
        
        // Top-strip per-page dropdown handler for Institutions
        $(document).on('click', '.institutions-per-page-item', function () {
            const val = $(this).data('val');
            $('#institutionsPerPageText').text($(this).text());
            $('#footerPerPageSelectInstitutions').val(val).trigger('change');
        });
        $('#searchVendors').on('input', function () {
            loadTenderVendorsTable(1);
        });
        $('#footerPerPageSelectVendors').on('change', function () {
            $('#perPageSelectVendors').val($(this).val());
            loadTenderVendorsTable(1);
        });
        
        // Top-strip per-page dropdown handler for Vendors
        $(document).on('click', '.vendors-per-page-item', function () {
            const val = $(this).data('val');
            $('#vendorsPerPageText').text($(this).text());
            $('#footerPerPageSelectVendors').val(val).trigger('change');
        });
        $('#searchShifts').on('input', function () {
            loadShiftTable(1);
        });
        $('#footerPerPageSelectShifts').on('change', function () {
            $('#perPageSelectShifts').val($(this).val());
            loadShiftTable(1);
        });
        
        // Top-strip per-page dropdown handler for Shifts
        $(document).on('click', '.shifts-per-page-item', function () {
            const val = $(this).data('val');
            $('#shiftsPerPageText').text($(this).text());
            $('#footerPerPageSelectShifts').val(val).trigger('change');
        });
        $('#searchBanks').on('input', function () {
            loadBankTable(1);
        });
        $('#footerPerPageSelectBanks').on('change', function () {
            $('#perPageSelectBanks').val($(this).val());
            loadBankTable(1);
        });
        
        // Top-strip per-page dropdown handler for Banks
        $(document).on('click', '.banks-per-page-item', function () {
            const val = $(this).data('val');
            $('#banksPerPageText').text($(this).text());
            $('#footerPerPageSelectBanks').val(val).trigger('change');
        });

        // Form Resets
        $('#institutionsAddModal').on('hidden.bs.modal', function () {
            $('#addTenderInstitutionsForm')[0].reset();
        });
        $('#tenderVendorsAddModal').on('hidden.bs.modal', function () {
            $('#addTenderVendorsForm')[0].reset();
        });
        $('#shiftAddModal').on('hidden.bs.modal', function () {
            $('#addshiftForm')[0].reset();
        });
        $('#banksAddModal').on('hidden.bs.modal', function () {
            $('#addBankForm')[0].reset();
        });

        $('#addTenderInstitutionsForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addTenderInstitutionsForm');
            const formData = new FormData(form);
            formData.append('addDTenderInstitutions', 'addDTenderInstitutions');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#institutionsAddModal').modal('hide');
                        $('#addTenderInstitutionsForm')[0].reset();
                        loadTenderInstitutionsTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addTenderVendorsForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addTenderVendorsForm');
            const formData = new FormData(form);
            formData.append('addTenderVendors', 'addTenderVendors');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#tenderVendorsAddModal').modal('hide');
                        $('#addTenderVendorsForm')[0].reset();
                        loadTenderVendorsTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addshiftForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addshiftForm');
            const formData = new FormData(form);
            formData.append('addShift', 'addShift');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#shiftAddModal').modal('hide');
                        $('#addshiftForm')[0].reset();
                        loadShiftTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#addBankForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addBankForm');
            const formData = new FormData(form);
            formData.append('addBank', 'addBank');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#banksAddModal').modal('hide');
                        $('#addBankForm')[0].reset();
                        loadBankTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $("#banksBranchAddModalBtn").on('click', function () {
            loadAllBankList();
            $("#banksBranchAddModal").modal('show');
        });
    });

    $(document).on('click', '.deleteInstitutionBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteTenderInstitutions: 'deleteTenderInstitutions',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadTenderInstitutionsTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editInstitutionBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editTenderInstitutionsForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchTenderInstitutionRecord: 'fetchTenderInstitutionRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editTenderInstitutionsModal').modal('show');
                        $('#editTenderInstitutionsForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editTenderInstitutionsForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editTenderInstitutionsForm');
        const formData = new FormData(form);
        formData.append('updateTenderInstituution', 'updateTenderInstituution');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editTenderInstitutionsModal').modal('hide');
                    $('#editTenderInstitutionsForm').find('modal-body').html();
                    loadTenderInstitutionsTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteTenderVendorBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteTenderVendor: 'deleteTenderVendor',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadTenderVendorsTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editTenderVendorBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editTenderVendorForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchTenderVendorRecord: 'fetchTenderVendorRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editTenderVendorModal').modal('show');
                        $('#editTenderVendorForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editTenderVendorForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editTenderVendorForm');
        const formData = new FormData(form);
        formData.append('updateTenderVendor', 'updateTenderVendor');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editTenderVendorModal').modal('hide');
                    $('#editTenderVendorForm').find('modal-body').html();
                    loadTenderVendorsTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteShiftBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteShift: 'deleteShift',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadShiftTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editShiftBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editShiftForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchShiftRecord: 'fetchShiftRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editShiftModal').modal('show');
                        $('#editShiftForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editShiftForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editShiftForm');
        const formData = new FormData(form);
        formData.append('updateShift', 'updateShift');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editShiftModal').modal('hide');
                    $('#editShiftForm').find('modal-body').html();
                    loadShiftTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteBankBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteBank: 'deleteBank',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadBankTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });


</script>
<?php endSection(); ?>