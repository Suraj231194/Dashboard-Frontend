<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="row">
        <p>This is the bmr screen.</p>
    </div>
</div>
<div class="container-xxl flex-grow-1 container-p-y">

        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
        <div class="row col-md-12">
            <div class="card">
                <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                    <div class="d-flex align-items-center gap-2">
                        <label for="perPageSelect" class="mb-0">Show</label>
                        <select id="perPageSelect" class="form-select form-select-sm w-auto">
                            <option value="5">5</option>
                            <option value="10" selected>10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                            <option value="1000">1000</option>
                            <option value="3000">3000</option>
                        </select>
                        <span>entries</span>
                    </div>

                    <div class="d-flex align-items-center gap-2">
                        <input type="text" id="searchUsers" class="form-control form-control-sm" placeholder="Search Data...">
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-start mt-3">
                    <form id="bmrTemplateExportForm" class="d-flex flex-column flex-md-row gap-2 align-items-start align-items-md-center ">

                        <div class="col-12 col-md-auto">
                            <div class="d-flex align-items-center gap-2">
                                <label for="fromDate" class="form-label mb-0">From:</label>
                                <input type="date" id="fromDate" value="<?= date('Y-m-d', strtotime('-15 days')) ?>" class="form-control form-control-sm" />
                            </div>
                        </div>
                        <div class="col-12 col-md-auto">
                            <div class="d-flex align-items-center gap-2">
                                <label for="toDate" class="form-label mb-0">To:</label>
                                <input type="date" id="toDate" value="<?= date('Y-m-d') ?>" class="form-control form-control-sm" />
                            </div>
                        </div>


                        <select name="listOfColumns[]" id="listOfColumns" class="selectpicker" multiple data-style="btn-default" data-actions-box="true" required>
                            <option value="Timestamp">Timestamp</option>
                            <option value="Product">Product</option>
                            <option value="Quantity">Quantity</option>
                            <option value="Client Name">Client Name</option>
                            <option value="Dispatch Type">Dispatch Type</option>
                            <option value="City Area">City Area</option>
                            <option value="Category">Category</option>
                            <option value="Delivery Mode">Delivery Mode</option>
                            <option value="Dispatched By">Dispatched By</option>
                        </select>

                        <select class="form-control form-control-sm" name="exportType" id="exportType" required>
                            <option value="">----Select----</option>
                            <option value="csv">CSV</option>
                            <option value="excel">Excel</option>
                            <option value="pdf">PDF</option>
                        </select>
                        <button type="submit" class="btn btn-sm btn-success">Export</button>
                    </form>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-btn-download d-none"><i class="ti ti-download text-lg"></i> Download</a>
                </div>

                <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                            <tr class="text-nowrap">
                                <th class="border-b border-slate-200 px-6 py-3">#</th>
                                <th class="table-col-210 sortable border-b border-slate-200 px-6 py-3" data-column="created_at" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Timestamp"> Timestamp</th>
                                <th class="table-col-250 sortable border-b border-slate-200 px-6 py-3" data-column="product_name" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Product"> Product</th>
                                <th class="table-col-180 border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Quantity"> Quantity</th>
                                <th class="table-col-200 sortable border-b border-slate-200 px-6 py-3" data-column="client_name" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Client Name"> Client Name</th>
                                <th class="table-col-210 sortable border-b border-slate-200 px-6 py-3" data-column="outward_type" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Dispatch Type"> Dispatch Type</th>
                                <th data-bs-toggle="tooltip" class="sortable border-b border-slate-200 px-6 py-3" data-column="place_of_dispatch" data-bs-placement="top" data-bs-original-title="City/Area"> City/Area</th>
                                <th data-bs-toggle="tooltip" class="sortable border-b border-slate-200 px-6 py-3" data-column="category" data-bs-placement="top" data-bs-original-title="Category"> Category</th>
                                <th class="table-col-150 sortable border-b border-slate-200 px-6 py-3" data-column="delivery_mode" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Delivery Mode"> Delivery Mode</th>
                                <th data-bs-toggle="tooltip" class="sortable border-b border-slate-200 px-6 py-3" data-column="dispatcher" data-bs-placement="top" data-bs-original-title="Dispatched By"> Dispatched By</th>
                                <!-- <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>                             -->
                                <th class="border-b border-slate-200 px-6 py-3 table-col-250">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 bg-white" id="stockOutwardsTableBody">
                        </tbody>
                    </table>
                </div>
                <div class="demo-inline-spacing">
                    <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
                </div>
            </div>
        </div>
        <!-- Multiple Lists Draggable -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <h5 class="card-header">Multiple List</h5>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-12 mb-md-0 mb-4">
                                <p>Pending Tasks</p>
                                <ul class="list-group list-group-flush" id="pending-tasks">
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>Buy products.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/1.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>Reply to emails.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/2.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>Write blog post.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/3.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>Update packages.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/4.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>New blog layout.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/5.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6 col-12 mb-md-0 mb-4">
                                <p>Completed Tasks</p>
                                <ul class="list-group list-group-flush" id="completed-tasks">
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>New icons set for an iOS app.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/1.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span> Fix validation bugs and commit.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/2.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span> Help Web developers with HTML integration.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/3.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>Buy antivirus.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/4.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                    <li
                                        class="list-group-item drag-item cursor-move d-flex justify-content-between align-items-center">
                                        <span>Answer support tickets.</span>
                                        <img
                                            class="rounded-circle"
                                            src="../../assets/img/avatars/5.png"
                                            alt="avatar"
                                            height="32"
                                            width="32" />
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Multiple Lists Draggable ends -->


    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let sections = [];

    function addSection() {
        let title = $('#section_title').val().trim();
        let type = $('#section_type').val();
        let pageNo = $('#page_no').val();

        if (title === '') {
            toastr.error('Section Title Required');
            $('#section_title').focus();
            return;
        }

        if (type === '') {
            toastr.error('Section Type Required');
            $('#section_type').focus();
            return;
        }

        if (pageNo === '' || isNaN(pageNo) || pageNo <= 0) {
            toastr.error('Valid Page Number Required');
            $('#page_no').focus();
            return;
        }

        let exists = sections.some(sec =>
            sec.title.toLowerCase() === title.toLowerCase() &&
            sec.page_no == pageNo
        );

        if (exists) {
            toastr.error('Section Already Exists On This Page');
            return;
        }

        let obj = {
            title: title,
            type: type,
            page_no: parseInt(pageNo),
            fields: [],
            columns: []
        };

        sections.push(obj);
        renderSections();
        resetSectionInputs();
    }

    function resetSectionInputs() {
        $('#section_title').val('');
        $('#section_type').val('');
        $('#page_no').val('');
        $('#section_title').focus(); // UX ke liye
    }



    // function renderSections() {
    //     let html = '';

    //     sections.forEach((sec, i) => {

    //         html += `
    //         <div class="section-card">

    //         <b>${sec.title} | Page ${sec.page_no}</b><br><br>

    //         ${sec.type==1 ? `<button class="btn btn-sm btn-info mb-2" onclick="addFieldRow(${i})">Add Field</button>`:''}
    //         ${sec.type==2 ? `<button class="btn btn-sm btn-warning mb-2" onclick="addColumnRow(${i})">Add Column</button>`:''}

    //         <div id="field_area_${i}"></div>
    //         <div id="column_area_${i}"></div>

    //         </div>`;
    //     });

    //     $('#sectionList').html(html);
    // }


    function renderSections() {

        let html = '';

        sections.forEach((sec, i) => {

            html += `
            <div class="section-card" data-section="${i}">

            <input type="hidden" name="sections[${i}][title]" value="${sec.title}">
            <input type="hidden" name="sections[${i}][type]" value="${sec.type}">
            <input type="hidden" name="sections[${i}][page_no]" value="${sec.page_no}">

            <b>${sec.title} | Page ${sec.page_no}</b><br><br>

            ${sec.type==1 ? `<button type="button" class="btn btn-sm btn-info mb-2" onclick="addFieldRow(${i})">Add Field</button>`:''}
            ${sec.type==2 ? `<button type="button" class="btn btn-sm btn-warning mb-2" onclick="addColumnRow(${i})">Add Column</button>`:''}

            <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                <tbody id="field_area_${i}"></tbody>
            </table>

            </div>`;
        });

        $('#sectionList').html(html);
    }
    $(document).on('mouseenter', '.field-table tbody', function() {

        if (!$(this).hasClass('ui-sortable')) {

            $(this).sortable({
                items: 'tr',
                cursor: 'move',
                placeholder: 'bg-warning'
            });

        }

    });

    // function addField(i) {

    //     let label = prompt("Field Label");
    //     let key = prompt("Field Key");

    //     sections[i].fields.push({
    //         label: label,
    //         key: key,
    //         type: 1
    //     });

    //     showFields(i);
    // }


    // function addFieldRow(i) {

    //     let rowIndex = sections[i].fields.length;

    //     let rowHTML = `
    //     <div class="row mb-2 field-row" data-index="${rowIndex}">
    //         <div class="col-md-3">
    //             <input type="text" class="form-control field-label" placeholder="Field Label">
    //         </div>

    //         <div class="col-md-2">
    //             <input type="text" class="form-control field-key" placeholder="Field Key">
    //         </div>

    //         <div class="col-md-2">
    //             <select class="form-control field-type">
    //                 <option value="text">Text</option>
    //                 <option value="number">Number</option>
    //                 <option value="date">Date</option>
    //                 <option value="textarea">Textarea</option>
    //             </select>
    //         </div>

    //         <div class="col-md-2">
    //             <select class="form-control field-required">
    //                 <option value="0">Optional</option>
    //                 <option value="1">Required</option>
    //             </select>
    //         </div>

    //         <div class="col-md-3">
    //             <button class="btn btn-success btn-sm" onclick="saveField(${i}, this)">Save</button>
    //             <button class="btn btn-danger btn-sm" onclick="removeFieldRow(this)">Delete</button>
    //         </div>
    //     </div>`;

    //     $('#field_area_' + i).append(rowHTML);
    // }

    function addFieldRow(i) {

        let count = $('#field_area_' + i + ' tr').length;

        let rowHTML = `
        <tr>

            <td>
                <input name="sections[${i}][fields][${count}][label]"
                    class="form-control"
                    placeholder="Label">
            </td>

            <td>
                <input name="sections[${i}][fields][${count}][key]"
                    class="form-control"
                    placeholder="Key">
            </td>

            <td>
                <select name="sections[${i}][fields][${count}][type]"
                    class="form-control">
                    <option value="text">Text</option>
                    <option value="number">Number</option>
                    <option value="date">Date</option>
                </select>
            </td>

            <td>
                <select name="sections[${i}][fields][${count}][required]"
                    class="form-control">
                    <option value="0">Optional</option>
                    <option value="1">Required</option>
                </select>
            </td>

            <td>
                <button type="button" class="btn btn-danger btn-sm"
                    onclick="$(this).closest('tr').remove()">
                    Delete
                </button>
            </td>

        </tr>`;

        $('#field_area_' + i).append(rowHTML);
    }


    // function showFields(i) {

    //     let html = '';

    //     sections[i].fields.forEach(f => {
    //         html += `<span class="field-chip">${f.label}</span>`;
    //     });

    //     $('#field_area_' + i).html(html);
    // }

    function deleteField(sectionIndex, fieldIndex) {
        sections[sectionIndex].fields.splice(fieldIndex, 1);
        showFields(sectionIndex);
    }

    function showFields(i) {

        let html = '<table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">';
        html += `<tr>
                    <th class="border-b border-slate-200 px-6 py-3">Label</th>
                    <th class="border-b border-slate-200 px-6 py-3">Key</th>
                    <th class="border-b border-slate-200 px-6 py-3">Type</th>
                    <th class="border-b border-slate-200 px-6 py-3">Required</th>
                    <th class="border-b border-slate-200 px-6 py-3">Action</th>
                </tr>`;

        sections[i].fields.forEach((f, index) => {

            html += `<tr>
                        <td>${f.label}</td>
                        <td>${f.key}</td>
                        <td>${f.type}</td>
                        <td>${f.required == 1 ? 'Yes' : 'No'}</td>
                        <td>
                            <button class="btn btn-danger btn-sm" onclick="deleteField(${i}, ${index})">Delete</button>
                        </td>
                    </tr>`;
        });

        html += '</table>';

        $('#field_area_' + i).html(html);
    }

    function addColumn(i) {

        let label = prompt("Column Label");
        let key = prompt("Column Key");

        sections[i].columns.push({
            label: label,
            key: key,
            type: 1
        });

        showColumns(i);
    }

    function addColumnRow(i) {

        let rowHTML = `
        <div class="row mb-2 column-row">

            <div class="col-md-4">
                <input type="text" class="form-control col-label" placeholder="Column Label">
            </div>

            <div class="col-md-4">
                <input type="text" class="form-control col-key" placeholder="Column Key">
            </div>

            <div class="col-md-4">
                <button type="button" class="btn btn-success btn-sm"
                    onclick="saveColumn(${i}, this)">Save</button>

                <button type="button" class="btn btn-danger btn-sm"
                    onclick="removeFieldRow(this)">Delete</button>
            </div>

        </div>`;

        $('#field_area_' + i).append(rowHTML);
    }

    function showColumns(i) {

        let html = '';

        sections[i].columns.forEach(c => {
            html += `<span class="column-chip">${c.label}</span>`;
        });

        $('#column_area_' + i).html(html);
    }

    function saveField(sectionIndex, btn) {

        let row = $(btn).closest('.field-row');

        let label = row.find('.field-label').val();
        let key = row.find('.field-key').val();
        let type = row.find('.field-type').val();
        let required = row.find('.field-required').val();

        if (label == '' || key == '') {
            alert("Label and Key Required");
            return;
        }

        sections[sectionIndex].fields.push({
            label: label,
            key: key,
            type: type,
            required: required
        });

        row.remove();

        showFields(sectionIndex);
    }

    function saveColumn(i, btn) {

        let parent = $(btn).closest('.column-row');

        let label = parent.find('.col-label').val().trim();
        let key = parent.find('.col-key').val().trim();

        if (label === '') {
            alert('Column Label Required');
            return;
        }

        if (key === '') {
            alert('Column Key Required');
            return;
        }

        // 👉 SAME PUSH like your prompt code
        sections[i].columns.push({
            label: label,
            key: key,
            type: 1
        });

        // disable after save
        parent.find('input').prop('readonly', true);
        $(btn).prop('disabled', true);

        showColumns(i);
    }

    function saveTemplate() {
        let product_name = $('#product_name').val();
        let template_name = $('#template_name').val();
        if (product_name == '') {
            toastr.error("Product name required.");
            $('#product_name').focus();
            return false;
        }
        if (template_name == '') {
            toastr.error("Template name required.");
            return false;
        }
        $.ajax({
            url: "ajax.php",
            type: "POST",
            data: {
                save_bmr_template: 1,
                product_name: product_name,
                template_name: template_name,
                sections: JSON.stringify(sections)
            },
            success: function(res) {
                console.log(res);
                let r = JSON.parse(res);
                if (r.status) {
                    toastr.success("Template Saved Successfully");
                } else {
                    toastr.error(r.error);
                }
            }
        });
    }

    $(document).ready(function() {
        $("#bmrTemplateCreateForm").on('submit', function(e) {
            e.preventDefault();
            let form = document.getElementById('bmrTemplateCreateForm');
            let formData = new FormData(form);
            formData.append('saveBmrTemplate', 'saveBmrTemplate');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function(response) {
                    if (response.status === 'success') {
                        $('#bmrTemplateCreateForm')[0].reset();
                        toastr.success(response.message);
                    } else if (response.status === 'error') {
                        toastr.error(response.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });
</script>
<?php endSection(); ?>
