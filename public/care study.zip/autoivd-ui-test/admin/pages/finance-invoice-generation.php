<?php
$financeView = 'invoice_generation';
require __DIR__ . '/finance-page.php';
