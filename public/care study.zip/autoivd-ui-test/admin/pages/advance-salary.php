<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage employee advance salary records and add new payments</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">

                    <div class="flex items-center gap-2 px-2 shrink-0">
                        <label for="monthAdvanceSalary" class="text-sm font-medium text-slate-700 m-0">Month:</label>
                        <input type="month" name="monthPay" id="monthAdvanceSalary" value="<?= date('Y-m') ?>"
                            class="h-10 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-colors hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" />
                    </div>

                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="advanceSalaryPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="advance-salary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="advance-salary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="advance-salary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="advance-salary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="advance-salary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="advance-salary-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 w-full md:w-[60%] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchData"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'hr_advance_salary_add')) { ?>
                        <div class="flex items-center shrink-0 pr-1">
                            <button type="button"
                                class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap"
                                data-bs-toggle="modal" data-bs-target="#employeeAdvancePayModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                                <i class="ti ti-plus text-lg"></i>
                            </button>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr class="text-nowrap">
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Date">Date
                            </th>
                            <th class="cursor-pointer px-6 py-3 sortable transition-colors hover:bg-slate-50/50"
                                data-column="emp.emp_code" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Emp Code"><span
                                    class="inline-flex items-center gap-1">Emp Code <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="cursor-pointer px-6 py-3 sortable transition-colors hover:bg-slate-50/50"
                                data-column="emp.first_name" data-default="asc" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Name"><span class="inline-flex items-center gap-1">Name
                                    <i class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Amount">Amount
                            </th>
                            <th class="px-6 py-3" data-column="r.name" data-bs-toggle="tooltip" data-bs-placement="top"
                                title="Remark">Remark</th>
                            <th class="px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Status">Status
                            </th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="advanceSalaryTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="employeeAdvancePayModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-cash text-xl"></i>
                        </span>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-800">Advance Pay to Employee</h5>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="employeeAdvancePayForm">
                    <div class="modal-body !px-5 !py-5">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="employeeId" class="mb-1 block text-sm font-medium text-slate-800">Employee
                                    <strong class="text-rose-500">*</strong></label>
                                <select name="employeeId" id="employeeId"
                                    class="w-full !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 select2"
                                    placeholder="Select Employee" required></select>
                            </div>
                            <div>
                                <label for="entryDate" class="mb-1 block text-sm font-medium text-slate-800">Date
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="entryDate" autocomplete="off" name="entryDate"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    required />
                            </div>

                            <div>
                                <label for="amount" class="mb-1 block text-sm font-medium text-slate-800">Amount <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="number" step="any" min="0" id="amount" autocomplete="off" name="amount"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Amount" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800"
                                    for="deduction_type">Deduction Type <strong class="text-rose-500">*</strong></label>
                                <select name="deduction_type" id="deduction_type"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    required>
                                    <?php if (!empty(Constant::HR_SETTINGS['INSTALLMENT_ADVANCED'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::HR_SETTINGS['INSTALLMENT_ADVANCED'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div id="installment_amount_div">
                                <label for="installment_amount"
                                    class="mb-1 block text-sm font-medium text-slate-800">Installment Amount <span
                                        class="text-xs text-slate-400 font-normal">(if installment)</span></label>
                                <input type="number" step="any" min="0" id="installment_amount" autocomplete="off"
                                    name="installment_amount"
                                    class="w-full h-10 !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
                                    placeholder="Enter Amount" />
                            </div>
                            <div class="md:col-span-2">
                                <label for="Remark" class="mb-1 block text-sm font-medium text-slate-800">Remark <strong
                                        class="text-rose-500">*</strong></label>
                                <textarea id="Remark" autocomplete="off" name="remark"
                                    class="w-full !rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm outline-none transition-all hover:border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 resize-none min-h-[60px]"
                                    placeholder="Enter Remark" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';


    function loadAdvanceSalaryTable(page = 1) {
        currentPage = page;
        const search = $('#searchData').val().trim();
        const perPage = $('#perPageSelect').val();
        const monthAdvancePay = $('#monthAdvanceSalary').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadAdvanceSalary: 'loadAdvanceSalary',
                page: page,
                per_page: perPage,
                search: search,
                monthAdvancePay: monthAdvancePay,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#advanceSalaryTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');

                const visibleRows = Number(response.visibleRows || 0);
                const totalRows = Number(response.totalRows || 0);
                if (response.visibleRows !== undefined) {
                    const shownThrough = Math.min(currentPage * parseInt(perPage === 'all' ? totalRows : perPage), totalRows);
                    $('#paginationSummary').text(`Showing ${shownThrough > 0 ? ((currentPage - 1) * parseInt(perPage === 'all' ? totalRows : perPage)) + 1 : 0} to ${shownThrough} of ${totalRows} results`);
                }
            },
            error: function () {
                $('#advanceSalaryTableBody').html('<tr><td colspan="35" class="px-6 py-10 text-center font-medium text-rose-500">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    function loadEmployeesList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadEmployeesListOption: 'loadEmployeesListOption'
            },
            success: function (response) {
                employeeOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                employeeOptions.forEach(emp => {
                    optionsHtml += `<option value="${emp.id}">(${emp.emp_code}) ${emp.first_name} ${emp.last_name}</option>`;
                });
                $("#employeeId").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load employees:", error);
            }
        });
    }

    $(document).ready(function () {
        loadEmployeesList();
        loadAdvanceSalaryTable();
        $('#searchData').on('input', function () {
            loadAdvanceSalaryTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadAdvanceSalaryTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadAdvanceSalaryTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.advance-salary-per-page-item', function () {
            const val = $(this).data('val');
            $('#advanceSalaryPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        $('#monthAdvanceSalary').on('input', function () {
            loadAdvanceSalaryTable(1);
        });

        $('#employeeAdvancePayModal').on('shown.bs.modal', function () {
            const $modal = $(this);
            $modal.find('select.select2').each(function () {
                if ($(this).hasClass('select2-hidden-accessible')) {
                    $(this).select2('destroy');
                }
                $(this).select2({ dropdownParent: $modal, width: '100%' });
            });
        });

        $('#employeeAdvancePayModal').on('hidden.bs.modal', function () {
            $('#employeeAdvancePayForm')[0].reset();
            if ($('#employeeId').length) {
                $('#employeeId').val('').trigger('change');
            }
            if ($('#deduction_type').length) {
                $('#deduction_type').val('').trigger('change');
            }
            $('#installment_amount_div').hide();
            $('#installment_amount').removeAttr('required');
        });

        $(document).on('submit', '#employeeAdvancePayForm', function (e) {
            e.preventDefault();
            const form = document.getElementById('employeeAdvancePayForm');
            const formData = new FormData(form);
            formData.append('addAdvancePaymentToEployee', 'addAdvancePaymentToEployee');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#employeeAdvancePayModal').modal('hide');
                        $('#employeeAdvancePayForm')[0].reset();
                        loadAdvanceSalaryTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });

    $(document).on('click', '.advSalDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteAdvanceSalaryRecord: 'deleteAdvanceSalaryRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadAdvanceSalaryTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = $(this).data('default') || 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadAdvanceSalaryTable(1);
    });

</script>
<?php endSection(); ?>
