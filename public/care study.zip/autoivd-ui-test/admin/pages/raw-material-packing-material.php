<?php
$inboundPendingCount = 0;
$inboundPendingRes = $conn->query("
    SELECT COUNT(*) AS total
    FROM stock_inwards st
    WHERE st.id NOT IN (
        SELECT stock_inward_id FROM coa_rm_pm_table WHERE stock_inward_id IS NOT NULL
    ) AND st.deleted_at IS NULL
");
if ($inboundPendingRes) {
    $inboundPendingCount = (int) ($inboundPendingRes->fetch_assoc()['total'] ?? 0);
}
?>
<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage Raw Material and Packing Material COA records</p>
        </div>
    </div>

    <!-- Phase D: QA/QC Inbound Materials Widget (Standalone) -->
    <div id="inboundMaterialWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2">
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md" style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: #fce8e8; border-radius: 0.75rem;">
                    <i class="ti ti-bell" style="font-size: 1.5rem; color: #d11f1f;"></i>
                    <span id="inboundMaterialsCountBadge" style="position: absolute; top: -0.4rem; right: -0.55rem; display: flex; align-items: center; justify-content: center; min-width: 1.5rem; height: 1.5rem; padding: 0 0.35rem; background-color: #d11f1f; color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;"><?= number_format($inboundPendingCount) ?></span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: #1e293b; margin: 0;">Inbound Material(s)!</h3>
                        <span id="inboundMaterialsTextBadge" class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-700"><?= number_format($inboundPendingCount) ?> Requests</span>
                    </div>
                    <p class="font-medium text-slate-500 mt-1 mb-0" style="font-size: 0.875rem;">
                        <span id="inboundMaterialsSubtitleCount" class="font-bold text-slate-700"><?= number_format($inboundPendingCount) ?></span> received items pending QC/COA testing. Click to view requests.
                    </p>
                </div>
            </div>
            <div class="text-slate-400">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <!-- Inbound Material(s)! Requests Modal -->
    <div class="modal fade animate__animated fadeIn" id="inboundMaterialsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
                <!-- Standard Header -->
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-6 !py-4">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-700 ring-1 ring-rose-100">
                            <i class="ti ti-bell-ringing text-xl"></i>
                        </span>
                        <div>
                            <div class="flex items-center gap-2">
                                <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Inbound Material(s)! Requests</h5>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-700">
                                    <span id="qaInboundCount">0</span> Pending
                                </span>
                            </div>
                            <p class="m-0 text-xs font-medium text-slate-500 mt-0.5">Newly arrived items verified in Goods Received, pending quality COA generation</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>

                <div class="modal-body p-0 bg-white" id="qaInboundWidget">
                    <!-- Search & Per Page Strip -->
                    <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                        <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white p-2 shadow-sm">
                            <input type="hidden" id="qaInboundPerPage" value="10">
                            
                            <div class="dropdown shrink-0">
                                <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                    <span id="qaInboundPerPageText" class="whitespace-nowrap">10 items</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="qa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="-1">All items</a></li>
                                    <li><a class="qa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                    <li><a class="qa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                    <li><a class="qa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                    <li><a class="qa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                    <li><a class="qa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                </ul>
                            </div>

                            <div class="relative h-10 min-w-[160px] max-w-[280px] flex-grow">
                                <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                    <i class="ti ti-search text-lg text-slate-400"></i>
                                </div>
                                <input type="text" id="qaInboundSearch" class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" placeholder="Search Data...">
                            </div>
                        </div>
                    </div>

                    <!-- Table Container -->
                    <div class="overflow-x-auto overflow-y-auto w-full" style="max-height: 58vh;">
                        <table class="w-full border-collapse text-left text-sm text-slate-600 relative">
                            <thead class="border-b border-slate-100 bg-slate-50 whitespace-nowrap sticky top-0 z-10 shadow-sm">
                                <tr>
                                    <th class="w-80 min-w-[280px] px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Material Name</th>
                                    <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Category</th>
                                    <th class="w-64 min-w-[200px] px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Supplier</th>
                                    <th class="w-44 min-w-[150px] px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Lot/Batch No</th>
                                    <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Qty Received</th>
                                    <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Date Received</th>
                                    <th class="px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 bg-white" id="qaInboundList">
                                <tr id="qaInboundLoadingRow">
                                    <td colspan="7" class="text-center py-6 text-sm text-slate-400">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination Footer -->
                    <div class="flex flex-col items-center justify-between gap-4 border-t border-slate-200 bg-slate-50/50 px-6 py-3 sm:flex-row">
                        <div class="text-sm font-medium text-slate-500" id="qaInboundPaginationSummary">
                            Showing 0 to 0 of 0 entries
                        </div>
                        <div id="qaInboundPaginationWrapper" class="flex gap-1"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<style>
    #inboundCoaEntryModal .modal-dialog-scrollable .modal-content,
    #inboundCoaEntryModal .modal-content {
        display: flex !important;
        flex-direction: column !important;
        max-height: calc(100vh - 3.5rem) !important;
        overflow: hidden !important;
    }
    #inboundCoaEntryModal .modal-header,
    #inboundCoaEntryModal .modal-footer {
        flex-shrink: 0 !important;
    }
    #inboundCoaEntryModal .modal-body {
        flex: 1 1 auto !important;
        min-height: 0 !important;
        overflow-y: auto !important;
    }
</style>

    <!-- Inbound COA Entry & Testing Modal -->
    <div class="modal fade animate__animated fadeIn" id="inboundCoaEntryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
            <form id="inboundCoaEntryForm" class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
                <!-- Modal Header -->
                <div class="modal-header flex-shrink-0 flex items-center justify-between border-b border-slate-200 bg-gradient-to-r from-slate-50 to-emerald-50/40 !px-6 !py-4">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-700 text-white shadow-md shadow-emerald-200 ring-1 ring-emerald-600/20">
                            <i class="ti ti-certificate text-2xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Generate COA Record</h5>
                            <p class="m-0 text-xs font-medium text-slate-500">Review inbound procurement details &amp; record quality testing parameters</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>

                <input type="hidden" name="inbound_queue_id" id="inbound_queue_id" value="" />
                <input type="hidden" name="stock_inward_id" id="stock_inward_id" value="" />
                <input type="hidden" name="coa_digit" id="coa_digit" value="" />
                <input type="hidden" name="batch_unit_id" id="coa_batch_unit_id" value="" />
                
                <div class="modal-body flex-1 min-h-0 overflow-y-auto !p-6 space-y-6 bg-slate-50/40">
                    <!-- Section 1: Inbound Material Information Card -->
                    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div class="mb-4 flex items-center justify-between border-b border-slate-100 pb-3">
                            <div class="flex items-center gap-2">
                                <span class="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700">
                                    <i class="ti ti-package text-base"></i>
                                </span>
                                <h6 class="m-0 text-sm font-bold text-slate-900">Inbound Material &amp; Receipt Summary</h6>
                            </div>
                            <span class="badge bg-label-primary text-xs" id="inboundMaterialTypeBadge">RM Record</span>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Goods Type <strong class="text-rose-500">*</strong></label>
                                <select name="type" id="coa_goods_type" class="form-select input-theme !py-2 !px-3 text-sm font-semibold text-slate-800 bg-white border border-slate-300 rounded-xl" required>
                                    <option value="RM">Raw Material (RM)</option>
                                    <option value="PM">Packing Material (PM)</option>
                                    <option value="FG">Finished Goods (FG)</option>
                                    <option value="CON">Consumables (CON)</option>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">COA Auto Generated #</label>
                                <input type="text" name="coa_number" id="coa_number" class="input-theme bg-slate-100 font-bold text-emerald-800" readonly required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Material Code No</label>
                                <input type="text" name="material_code_no" id="coa_material_code" class="input-theme bg-slate-100" readonly required />
                            </div>
                            <div class="md:col-span-2">
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Product Description</label>
                                <input type="text" name="name" id="coa_product_name" class="input-theme bg-slate-100 font-semibold text-slate-900" readonly required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Batch / Lot Number <strong class="text-rose-500">*</strong></label>
                                <input type="text" name="batch_number" id="coa_batch_number" class="input-theme font-semibold" placeholder="Enter Batch / Lot Number" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Batch Qty (Received)</label>
                                <input type="number" step="any" name="batch_qty" id="coa_batch_qty" class="input-theme bg-slate-100 font-semibold" readonly required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Batch Size / Pack Count</label>
                                <input type="text" name="batch_size" id="coa_batch_size" class="input-theme bg-slate-100" placeholder="e.g. 30500 pcs" readonly required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Supplier Name</label>
                                <input type="text" name="suplier_name" id="coa_supplier_name" class="input-theme bg-slate-100" readonly required />
                            </div>
                        </div>
                    </div>

                    <!-- Section 2: Quality Testing Template Selection with Top Matching & Load Button -->
                    <div class="rounded-2xl border border-indigo-200 bg-white p-5 shadow-sm">
                        <div class="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-indigo-100 pb-3">
                            <div>
                                <div class="flex items-center gap-2">
                                    <span class="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700">
                                        <i class="ti ti-file-certificate text-base"></i>
                                    </span>
                                    <h6 class="m-0 text-sm font-bold text-slate-900">Material Quality Testing Template <span class="text-xs font-normal text-slate-500">(Optional)</span></h6>
                                </div>
                                <p class="m-0 mt-0.5 text-xs text-slate-500">Select configured template or configure a new template in Company Setup &gt; COA Templates</p>
                            </div>
                            <div class="flex items-center gap-2">
                                <span id="inboundTemplateBadge" class="badge bg-label-info text-xs">0 templates available</span>
                                <a href="index.php?page=coa-templates" target="_blank" class="inline-flex h-7 items-center justify-center gap-1 rounded-lg bg-indigo-50 px-2.5 text-[11px] font-bold text-indigo-700 hover:bg-indigo-100 transition-colors" title="Configure New Template in Company Setup > COA Templates">
                                    <i class="ti ti-settings-cog text-xs"></i> Configure Templates
                                </a>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-12 gap-3">
                            <div class="md:col-span-8">
                                <select name="coa_template_id" id="inboundCoaTemplateSelect" class="form-select input-theme" style="width: 100%;">
                                    <option value="">-- No Template / Optional --</option>
                                </select>
                            </div>
                            <div class="md:col-span-2">
                                <button type="button" id="inboundLoadTemplateBtn" class="w-full inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-indigo-600 px-3 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition-colors">
                                    <i class="ti ti-download"></i> Load Template
                                </button>
                            </div>
                            <div class="md:col-span-2">
                                <a href="index.php?page=coa-templates" target="_blank" class="w-full inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl border border-indigo-200 bg-indigo-50/80 px-3 text-xs font-bold text-indigo-700 shadow-sm hover:bg-indigo-100 transition-colors text-center">
                                    <i class="ti ti-plus"></i> New Template
                                </a>
                            </div>
                        </div>

                        <!-- Dynamic Testing Parameters Container -->
                        <div id="inboundDynamicCoaFields" class="mt-4">
                            <div class="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-5 text-center text-xs text-slate-500">
                                <i class="ti ti-list-details text-2xl block mb-1 text-slate-400"></i>
                                Select a testing template above and click "Load Template" to display parameter specifications, or proceed without a template.
                                <div class="mt-2">
                                    <a href="index.php?page=coa-templates" target="_blank" class="inline-flex items-center gap-1 rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-bold text-indigo-700 hover:bg-indigo-100">
                                        <i class="ti ti-plus"></i> Configure New Template in COA Templates
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Section 3: Testing Dates & Detailed Metadata -->
                    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div class="mb-4 flex items-center gap-2 border-b border-slate-100 pb-3">
                            <span class="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 text-slate-700">
                                <i class="ti ti-calendar-event text-base"></i>
                            </span>
                            <h6 class="m-0 text-sm font-bold text-slate-900">Testing Dates &amp; Compliance Details</h6>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Testing Date <strong class="text-rose-500">*</strong></label>
                                <input type="date" name="testing_date" id="coa_testing_date" class="input-theme" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Receipt Date</label>
                                <input type="date" name="receipt_date" id="coa_receipt_date" class="input-theme bg-slate-100" readonly />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Manufacturer Name <strong class="text-rose-500">*</strong></label>
                                <input type="text" name="manufacturer_name" id="coa_manufacturer_name" class="input-theme" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Mfg Date</label>
                                <input type="date" name="mfg_date" id="coa_mfg_date" class="input-theme" />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Expiry Date</label>
                                <input type="date" name="expiry_date" id="coa_expiry_date" class="input-theme" />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Invoice Number</label>
                                <input type="text" name="invoice_number" id="coa_invoice_number" class="input-theme bg-slate-100" readonly />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Invoice Date</label>
                                <input type="date" name="invoice_date" id="coa_invoice_date" class="input-theme bg-slate-100" readonly />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">No of Containers Received</label>
                                <input type="text" name="number_of_container_received" id="coa_containers" class="input-theme" placeholder="e.g. 5 drums / boxes" />
                            </div>
                            <div>
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">Storage Condition</label>
                                <input type="text" name="storage_condition" id="coa_storage" class="input-theme" placeholder="e.g. 2-8 °C / Ambient" />
                            </div>
                            <div class="md:col-span-3">
                                <label class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">QC Remarks / Notes</label>
                                <textarea name="remark_one" id="coa_remarks" class="input-theme min-h-[60px]" rows="2" placeholder="Optional testing observations or QC remarks..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer flex-shrink-0 flex items-center justify-between border-t border-slate-200 bg-slate-50/80 !px-6 !py-4">
                    <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-colors" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" id="inboundCoaSubmitBtn" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-xs font-bold text-white shadow-md shadow-emerald-200 hover:bg-emerald-800 transition-colors">
                        <i class="ti ti-check text-base"></i> Submit &amp; Generate COA
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="rmpmPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="rmpm-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchCategory"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'rm_pm_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#addRmPmModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.created_at">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.coa_number">
                                <span class="inline-flex items-center gap-1">COA <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-80 min-w-[300px] cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.name">
                                <span class="inline-flex items-center gap-1">Product Desc <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-36 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.batch_number">
                                <span class="inline-flex items-center gap-1">Batch No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Batch Size</th>
                            <th class="sortable w-44 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.suplier_name">
                                <span class="inline-flex items-center gap-1">Supplier <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-36 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.invoice_number">
                                <span class="inline-flex items-center gap-1">Invoice No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="c.approval_status">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Created By</th>
                            <th
                                class="w-36 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="rmpmTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="addRmPmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add RM / PM</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a new Raw Material or Packing
                                Material COA</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="createCoaRmPmForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="mb-1 block text-sm font-medium text-slate-800"
                                        for="formTypeSelect">Select Type</label>
                                    <select id="formTypeSelect" class="input-theme select2">
                                        <option value="">-- Select Type --</option>
                                        <option value="RM">Raw Material</option>
                                        <option value="PM">Packing Material</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="existingRm">Last
                                        RM Number</label>
                                    <input type="text" class="input-theme" id="existingRm" value="" readonly>
                                </div>
                                <div class="col-md-4">
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="existingPm">Last
                                        PM Number</label>
                                    <input type="text" class="input-theme" id="existingPm" value="" readonly>
                                </div>
                            </div>
                        </div>
                        <div id="particularRows"></div>
                    </div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="reset"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none">Reset</button>
                        <button type="submit" id="submitBtn"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <span class="spinner-border spinner-border-sm me-1 d-none" id="submitLoader" role="status"
                                aria-hidden="true"></span>
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewRmPmData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">RM / PM Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">View raw material or packing material
                                record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body bg-slate-50/70 !px-4 !py-3" id="viewRmPmDataModalBody">
                </div>
                <div
                    class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                    <button type="button"
                        class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editRmPmData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit RM / PM Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update raw material or packing material
                                record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editRmPmDataForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-indigo-900/10 transition-colors hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/30">
                            <i class="ti ti-check text-lg"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php startSection('scripts'); ?>
<script>
    let qtyUnitOptions = [];
    let qtyUnitRequest = null;
    let currentPage = 1;
    let existing_rm_coa = '';
    let existing_pm_coa = '';
    let rmCoaCounter = 0;
    let pmCoaCounter = 0;
    let subRowIndex = 0;
    let currentSortColumn = 'c.id';
    let currentSortOrder = 'DESC';

    const formTypeSelect = {
        "RM": ["RM"],
        "PM": ["PM"]
    };

    function initializeCoaCounters() {
        if (existing_rm_coa && existing_rm_coa.includes('-')) {
            rmCoaCounter = parseInt(existing_rm_coa.split('-').pop()) || 25264;
        } else {
            rmCoaCounter = 25264;
        }

        if (existing_pm_coa && existing_pm_coa.includes('-')) {
            pmCoaCounter = parseInt(existing_pm_coa.split('-').pop()) || 25246;
        } else {
            pmCoaCounter = 25246;
        }
    }

    function getBaseNumber(type) {
        const val = type === 'RM' ? existing_rm_coa : existing_pm_coa;

        if (val && typeof val === 'string' && val.includes('-')) {
            const parts = val.split('-');
            return parseInt(parts[3], 10) || 0; // Ensure numeric conversion
        }

        // Fallback to default starting points if COA is not found
        return type === 'RM' ? 25264 : 25246;
    }

    function regenerateCoaNumbers(departmentType) {
        const base = getBaseNumber(departmentType);
        let counter = 0;

        // For each sub-row of the selected type
        $('.sub-row').each(function () {
            const block = $(this).closest('.department-block').find('h4').text().trim();
            if (block === departmentType) {
                counter++;
                const coaValue = `BIPL-COA-${departmentType}-${base + counter}`;
                $(this).find('input[name="coaAutoGenerated[]"]').val(coaValue);
            }
        });
    }

    $('#formTypeSelect').on('change', function () {
        const formTypeDropdown = $(this).val();
        if (!formTypeDropdown) return;

        const blockId = `block-${formTypeDropdown.replace(/\s/g, '')}`;
        if ($('#' + blockId).length > 0) return;

        const particulars = formTypeSelect[formTypeDropdown];
        let html = `<div class="department-block mt-3 mb-4" id="${blockId}"  data-type="${formTypeDropdown}">`;
        html += `
            <div class="d-flex justify-content-between align-items-center mb-2">
            <h4 class="mb-0">${formTypeDropdown}</h4>
            <button type="button" class="btn btn-danger waves-effect waves-light btn-sm remove-department" data-target="${blockId}"><span class="ti-xs ti ti-trash me-1"></span>Remove Type</button>
            </div>
        `;
        particulars.forEach(function (p, index) {
            const safeParticular = p.replace(/\s/g, '_') + '_' + index;
            html += `
            <div class="card mt-2 mb-3 p-3 position-relative particular-block" data-particular="${safeParticular}"> 
            <div class="row-set"></div>`;
            html += `<div class="mt-2">
                        <button type="button" class="btn btn-sm btn-outline-primary add-sub-row" data-department-value ="${formTypeDropdown}" data-particular-type="${p}" data-target="${safeParticular}">➕ Add Product</button>
                    </div>`;
            html += `</div>`;
        });

        html += `</div>`;
        $('#particularRows').append(html);
        $(`#${blockId} .add-sub-row`).first().trigger('click');
    });

    $(document).on('click', '.remove-particular', function () {
        $(this).closest('.particular-block').remove();
    });

    $(document).on('click', '.remove-department', function () {
        const targetId = $(this).data('target');
        $('#' + targetId).remove();
    });

    function getQtyUnitOptionsHtml() {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });
        return optionsHtml;
    }

    function ensureStandardUnitsLoaded() {
        if (qtyUnitOptions.length) {
            const deferred = $.Deferred();
            deferred.resolve(qtyUnitOptions);
            return deferred.promise();
        }
        if (qtyUnitRequest) {
            return qtyUnitRequest;
        }
        qtyUnitRequest = $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            }
        }).done(function (response) {
            qtyUnitOptions = Array.isArray(response) ? response : [];
        }).fail(function (xhr, status, error) {
            console.error("Failed to load qty units:", error);
        }).always(function () {
            qtyUnitRequest = null;
        });
        return qtyUnitRequest;
    }

    function loadStandardUnit() {
        return ensureStandardUnitsLoaded();
    }

    $(document).on('click', '.add-sub-row', function () {
        const $button = $(this);
        ensureStandardUnitsLoaded().done(function () {
        const target = $button.data('target');
        const typeRmPm = $button.data('department-value');
        const particularType = $button.data('particular-type');
        const departmentValue = $button.data('department-value');
        const rowSet = $(`[data-particular="${target}"] .row-set`);

        if (typeRmPm === "RM") {
            rmCoaCounter++;
            coaValue = `BIPL-COA-RM-${rmCoaCounter}`;
        } else if (typeRmPm === "PM") {
            pmCoaCounter++;
            coaValue = `BIPL-COA-PM-${pmCoaCounter}`;
        }

        const optionsHtml = getQtyUnitOptionsHtml();
        let rowHtml = '';
        const currentIndex = subRowIndex++;
        rowHtml += `
          <div class="row g-2 mt-5 mb-2 align-items-end sub-row border-bottom border-secondary-subtle pb-3">
            <div class="row">
                <input type="hidden" id="dropdownSelectType" name="dropdownSelectType[]" value="${departmentValue}" />
                <input type="hidden" name="stockInwardId[]" class="stockInwardIdVal" value="" />
                <div class="col-md-6 mb-3">
                    <label for="productDesc" class="form-label">Product Description</label>
                    <input type="text" id="productDesc" autocomplete="off" name="productDesc[]" class="form-control" placeholder="Enter Product Description" required />
                    <div class="text-danger mt-1 small" id="productDescError"></div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="coaAutoGenerated" class="form-label">COA Auto Generated</label>
                    <input type="text" id="coaAutoGenerated" autocomplete="off" name="coaAutoGenerated[]" value="${coaValue}" class="form-control" readonly required />
                    <div class="text-danger mt-1 small" id="coaAutoGeneratedError"></div>
                </div>
            </div>            
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label class="form-label">Batch Number</label>
                    <input type="text" autocomplete="off" name="batchNumber[]" class="form-control" placeholder="Enter Batch Number" />
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">No. of Packs</label>
                    <input type="number" min="1" name="batchQty[]" class="form-control" placeholder="Enter No. of Packs" required/>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Batch Size</label>
                    <input type="number" min="1" step="any" name="batchSize[]" class="form-control" placeholder="Enter Batch Size" required/>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Batch Size Unit</label>
                    <select name="batchSizeUnit[]" class="input-theme select2" required>
                        ${optionsHtml}
                    </select>
                </div>
            </div>


            <div class="bifurcated-entries">                
                <div class="bifurcated-rows-wrapper" data-index="${currentIndex}" data-index-name="bifurcatedProductName[${currentIndex}]">
                </div>
                <div class="text-start mb-2">
                    <button type="button" class="btn btn-sm btn-outline-primary add-bifurcated-row">+ Add Sub Product Entry</button>
                </div>
            </div>
           
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="testingDate" class="form-label">Testing Date</label>
                    <input type="date" id="testingDate" name="testingDate[]" class="form-control" placeholder="Enter Testing Date" required />                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="suplierName" class="form-label">Suplier Name</label>
                    <input type="text" id="suplierName" name="suplierName[]" class="form-control" placeholder="Enter Suplier Name" required/>                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="manufacturerName" class="form-label">Manufacturer Name</label>
                    <input type="text" id="manufacturerName" name="manufacturerName[]" class="form-control" placeholder="Enter Manufacturer Name" required/>                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="invoiceNumber" class="form-label">Invoice Number</label>
                    <input type="text" autocomplete="off" id="invoiceNumber" name="invoiceNumber[]" class="form-control" placeholder="Enter Invoice Number" required/>                  
                </div>    
                <div class="col-md-4 mb-3">
                    <label for="invoiceDate" class="form-label">Invoice Date</label>
                    <input type="date" id="invoiceDate" name="invoiceDate[]" class="form-control" placeholder="Enter Invoice Date" required/>                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="materialCodeNumber" class="form-label">Material Code No</label>
                    <input type="text" autocomplete="off" id="materialCodeNumber" name="materialCodeNumber[]" class="form-control" placeholder="Enter Material Code No" required/>                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="receiptgDate" class="form-label">Receipt Date</label>
                    <input type="date" id="receiptgDate" name="receiptgDate[]" class="form-control" placeholder="Enter Receipt Date" />                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="numberOfContainerReceived" class="form-label">No of Container Received</label>
                    <input type="text" autocomplete="off" id="numberOfContainerReceived" name="numberOfContainerReceived[]" class="form-control" placeholder="Enter No of Container Received" />                  
                </div>
                <div class="col-md-4 mb-3">
                    <label for="mfgDate" class="form-label">Mfg Date</label>
                    <input type="date" id="mfgDate" name="mfgDate[]" class="form-control" placeholder="Enter Mfg Date" />                  
                </div>            
                <div class="col-md-4 mb-3">
                    <label for="expiryDate" class="form-label">Expiry Date</label>
                    <input type="date" id="expiryDate" name="expiryDate[]" class="form-control" placeholder="Enter Expiry Date" />                  
                </div>
            
                <div class="col-md-4 mb-3">
                    <label for="storageCondition" class="form-label">Storage Condition (°C)</label>
                    <textarea id="storageCondition" name="storageCondition[]" class="form-control" placeholder="Enter Storage Condition"></textarea>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="remarksOne" class="form-label">Remarks</label>
                    <textarea id="remarksOne" name="remarksOne[]" class="form-control" placeholder="Enter Remarks"></textarea>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="sampledContainer" class="form-label">No of Container Sampled</label>
                    <input type="text" autocomplete="off" id="sampledContainer" name="sampledContainer[]" class="form-control" placeholder="Enter No of Container Sampled" />
                </div>
                <div class="col-md-4 mb-3">
                    <label for="qauntitySampled" class="form-label">Quantity Used For Sampling</label>
                    <input type="number" id="qauntitySampled" name="qauntitySampled[]"  class="form-control" placeholder="Enter Quantity Used For Sampling" step="0.001" min="0" required />
                </div> 
                <div class="col-md-4 mb-3">
                    <label for="qauntitySampledUnit" class="form-label">Quantity Sampling Unit</label>
                    <select type="number" id="qauntitySampledUnit" name="qauntitySampledUnit[]"  class="input-theme select2" required>
                        ${optionsHtml}
                    </select>
                </div>   
            </div>
            <div class="row">
                <div class="col-md-3 mt-4">
                    <button type="button" class="btn btn-icon btn-outline-danger remove-sub-row"><i class="ti ti-trash"></i></button>                   
                </div>
            </div>
          </div>
        `;
        rowSet.append(rowHtml);
        rowSet.find('.bifurcated-rows-wrapper').last().data('index', currentIndex);
        rowSet.find('.select2').each(function() {
            initAddRmPmSelect2($(this));
        });
        regenerateCoaNumbers(typeRmPm);
        });
    });

    // Remove sub-row
    $(document).on('click', '.remove-sub-row', function () {
        const $subRow = $(this).closest('.sub-row');
        const $departmentBlock = $subRow.closest('.department-block');
        const departmentType = $departmentBlock.attr('data-type');
        $subRow.remove();
        regenerateCoaNumbers(departmentType);
    });

    function loadCoaRmPmExisting() {
        if (existing_rm_coa) {
            $('#existingRm').val(existing_rm_coa);
        }
        if (existing_pm_coa) {
            $('#existingPm').val(existing_pm_coa);
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                existingCoaRmPmFetch: 'existingCoaRmPmFetch'
            },
            success: function (response) {
                if (response) {
                    existing_rm_coa = response.rm;
                    existing_pm_coa = response.pm;
                    $('#existingRm').val(response.rm);
                    $('#existingPm').val(response.pm);
                    initializeCoaCounters();
                }
            },
            error: function (xhr, status, error) {
                console.error("Failed to existingCoaRmPmFetch:", error);
            }
        });
    }

    function resetAddRmPmModal() {
        $('#createCoaRmPmForm')[0].reset();
        $('#particularRows').empty();
        $('#formTypeSelect').val(null).trigger('change');
        subRowIndex = 0;
        loadCoaRmPmExisting();
    }

    function loadCoaRmPmTable(page = 1) {
        currentPage = page;
        const search = $('#searchCategory').val().trim();
        const perPage = $('#perPageSelect').val();

        // Show loader
        $('#rmpmTableBody').html('<tr><td colspan="11" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadCoaRmPmTable: 'loadCoaRmPmTable',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#rmpmTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const visibleRows = $('#rmpmTableBody tr').length;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * parseInt(perPage)) + visibleRows, totalRows) : 0;
                $('#rmpmPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
            },
            error: function () {
                $('#rmpmTableBody').html('<tr><td colspan="11" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#rmpmPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    function initAddRmPmSelect2($elements, options = {}) {
        $elements.select2($.extend({
            dropdownParent: $('#addRmPmModal')
        }, options));
    }

    function bindRmPmSelect2Scroll(modalSelector) {
        setTimeout(function() {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.rmPmModalScroll')
                .on('wheel.rmPmModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $(modalSelector + ' .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $(modalSelector + ' select.select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    $(document).ready(function () {
        initAddRmPmSelect2($('#formTypeSelect'), {
            minimumResultsForSearch: Infinity
        });

        $(document).on('select2:open', function(e) {
            const $modal = $(e.target).closest('#addRmPmModal, #editRmPmData');
            if (!$modal.length) return;
            bindRmPmSelect2Scroll('#' + $modal.attr('id'));
        });

        $('#addRmPmModal .modal-body, #editRmPmData .modal-body').on('scroll', function() {
            $(this).closest('.modal').find('select.select2-hidden-accessible').select2('close');
        });

        loadCoaRmPmTable();
        loadStandardUnit();
        loadCoaRmPmExisting();

        $('#addRmPmModal').on('show.bs.modal', function () {
            resetAddRmPmModal();
        });
        $('#searchCategory').on('input', function () {
            loadCoaRmPmTable(1);
        });

        $('#perPageSelect').on('change', function () {
            loadCoaRmPmTable(1);
        });

        $('#footerPerPageSelect').on('change', function () {
            const val = $(this).val();
            $('#perPageSelect').val(val).trigger('change');
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.rmpm-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#rmpmPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $(document).on('click', '.per-page-item', function () {
            const val = $(this).data('val');
            $('#perPageText').text(val + ' / page');
            $('#footerPerPageSelect').val(val);
            $('#perPageSelect').val(val).trigger('change');
        });

        $('#addRmPmModal').on('hidden.bs.modal', function () {
            resetAddRmPmModal();
        });

        $('#createCoaRmPmForm').on('submit', function (e) {
            e.preventDefault();

            const formElement = this;
            const form = new FormData(formElement);
            form.append('createCoaRmPm', 'createCoaRmPm');

            const $submitBtn = $('#submitBtn');
            const $loader = $('#submitLoader');
            $submitBtn.prop('disabled', true);
            $loader.removeClass('d-none');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: form,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addRmPmModal').modal('hide');
                        $('#createCoaRmPmForm')[0].reset();
                        loadCoaRmPmTable();

                        // Show main success message
                        toastr.success(response.message);
                        if (response.data_response && response.data_response.status === 'success') {
                            toastr.success(response.data_response.message);
                        } else if (response.data_response && response.data_response.status === 'error') {
                            toastr.error('Data submission failed: ' + response.data_response.message);
                        }

                        if (response.email_response && response.email_response.status === 'success') {
                            toastr.success(response.email_response.message);
                        } else if (response.email_response && response.email_response.status === 'error') {
                            toastr.error('Email sending failed: ' + response.email_response.message);
                        }

                    } else {
                        toastr.error('Server error occurred.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false);
                    $loader.addClass('d-none');
                }
            });
        });

    });

    $(document).on('click', '.modalAnimateViewRmPm', function () {
        $('#viewRmPmDataModalBody').html('');
        let id = $(this).attr('data-id');
        if (id) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    fetchRmPmData: 'fetchRmPmData',
                    id: id
                },
                success: function (response) {
                    try {
                        const res = typeof response === 'string' ? JSON.parse(response) : response;

                        if (res.status === 'success') {
                            $('#viewRmPmDataModalBody').html(res.data);
                            $('#viewRmPmData').modal('show');
                        } else {
                            toastr.error(res.message || 'Something went wrong.');
                        }
                    } catch (e) {
                        console.error('Invalid JSON:', e);
                        toastr.error('Invalid server response.');
                    }
                },
                error: function () {
                    toastr.error('Invalid server response.');
                }
            });
        }
    });

    $(document).on('click', '.add-bifurcated-row', function () {
        const $button = $(this);
        ensureStandardUnitsLoaded().done(function () {
        const parentWrapper = $button.closest('.bifurcated-entries').find('.bifurcated-rows-wrapper');
        const parentIndex = parseInt(parentWrapper.attr('data-index'), 10);

        if (typeof parentIndex === 'undefined') {
            alert("Parent index not set. Check if data-index is correctly assigned.");
            return;
        }

        const optionsHtml = getQtyUnitOptionsHtml();

        const newRow = `
            <div class="bifurcated-row d-flex flex-wrap align-items-end gap-1 mb-2">
                <div class="col-md-3">
                    <input type="text" name="bifurcatedProductName[${parentIndex}][]" class="form-control" placeholder="e.g., Cap, Bottle" required />
                </div>
                <div class="col-md-2">
                    <input type="number" step="any" name="bifurcatedPackCount[${parentIndex}][]" class="form-control" placeholder="No. of Packs" required />
                </div>
                <div class="col-md-2">
                    <input type="number" step="any" name="bifurcatedPackSize[${parentIndex}][]" class="form-control" placeholder="Pack Size" required />
                </div>
                <div class="col-md-2">
                    <select name="bifurcatedPackUnit[${parentIndex}][]" class="input-theme select2" required>
                        ${optionsHtml}
                    </select>
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-outline-danger remove-bifurcated-row"><i class="ti ti-trash"></i></button>
                </div>
            </div>`;

        parentWrapper.append(newRow);
        initAddRmPmSelect2(parentWrapper.find('.select2'));
        });
    });


    // Remove bifurcated row
    $(document).on('click', '.remove-bifurcated-row', function () {
        $(this).closest('.bifurcated-row').remove();
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        loadCoaRmPmTable(1);
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
    });

    $(document).on('click', '.modalAnimateEditRmPm', function () {
        $('#editRmPmDataForm').find('.modal-body').html('');
        let id = $(this).attr('data-id');
        if (id) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    fetchRecordRmPmData: 'fetchRecordRmPmData',
                    id: id
                },
                success: function (res) {
                    try {
                        if (res.status === 'success') {
                            $('#editRmPmDataForm').find('.modal-body').html(res.data);
                            $('#editRmPmData').modal('show');
                            $('#editRmPmDataForm select.select2').select2({
                                dropdownParent: $('#editRmPmData'),
                                width: '100%'
                            });
                        } else {
                            toastr.error(res.message || 'Something went wrong.');
                        }
                    } catch (e) {
                        console.error('Invalid JSON:', e);
                        toastr.error('Invalid server response.');
                    }
                },
                error: function () {
                    toastr.error('Invalid server response.');
                }
            });
        }
    });

    $('#editRmPmDataForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editRmPmDataForm');
        const formData = new FormData(form);
        formData.append('updateRmPmRecord', 'updateRmPmRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#editRmPmData').modal('hide');
                    $('#editRmPmDataForm').find('modal-body').html();
                    loadCoaRmPmTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.remove-bifurcated-row-edit', function () {
        let $btn = $(this);
        let id = $(this).data('id');
        if (!id) {
            $btn.closest('.bifurcated-row-edit').remove();
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteBifurcationItemsRecord: 'deleteBifurcationItemsRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                            $btn.closest('.bifurcated-row-edit').remove();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.add-bifurcated-row-edit', function () {
        const parentWrapper = $(this).closest('.bifurcated-entries-edit').find('.bifurcated-rows-wrapper-edit');
        const parentIndex = parseInt(parentWrapper.attr('data-index'), 10);

        if (typeof parentIndex === 'undefined') {
            alert("Parent index not set. Check if data-index is correctly assigned.");
            return;
        }

        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });

        const newRow = `
            <div class="bifurcated-row-edit d-flex flex-wrap align-items-end gap-1 mb-2">
                <div class="col-md-3">
                    <input type="hidden" name="bifurcatedItemId[]" value="">
                    <input type="text" name="bifurcatedProductName[]" class="form-control" placeholder="e.g., Cap, Bottle" required />
                </div>
                <div class="col-md-2">
                    <input type="number" step="any" name="bifurcatedPackCount[]" class="form-control" placeholder="No. of Packs" required />
                </div>
                <div class="col-md-2">
                    <input type="number" step="any" name="bifurcatedPackSize[]" class="form-control" placeholder="Pack Size" required />
                </div>
                <div class="col-md-2">
                    <select name="bifurcatedPackUnit[]" class="input-theme select2" required>
                        ${optionsHtml}
                    </select>
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-outline-danger btn-sm remove-bifurcated-row-edit"><i class="ti ti-trash"></i></button>
                </div>
            </div>`;

        parentWrapper.append(newRow);
        parentWrapper.find('.select2').last().select2({ dropdownParent: $('#editRmPmData') });
    });

    // ─── Phase D: QA/QC Inbound Materials Widget ────────────────────────────
    let qaPage = 1;
    let qaSearchTimer = null;

    function loadQaInboundMaterials(page = 1) {
        qaPage = Math.max(1, Number(page) || 1);
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadQaInboundMaterials: 'loadQaInboundMaterials',
                page: qaPage,
                per_page: $('#qaInboundPerPage').val(),
                search: $('#qaInboundSearch').val().trim()
            },
            success: function (res) {
                const $list = $('#qaInboundList');
                const $widget = $('#qaInboundWidget');
                const $count = $('#qaInboundCount');

                if (res && res.status === 'success') {
                    $list.html(res.html);
                    qaPage = Math.max(1, Number(res.page) || 1);
                    $widget.removeClass('hidden');
                    const totalPending = Number(res.totalPending) || 0;
                    const formattedCount = totalPending.toLocaleString();
                    $('#qaInboundCount').text(formattedCount);
                    $('#inboundMaterialsCountBadge').text(formattedCount);
                    $('#inboundMaterialsTextBadge').text(formattedCount + ' Requests');
                    $('#inboundMaterialsSubtitleCount').text(formattedCount);
                    renderQaPagination(res);
                } else {
                    $list.html('<tr><td colspan="7" class="text-center py-6 text-sm font-medium text-rose-600">Unable to load inbound materials.</td></tr>');
                    renderQaPagination({ page: 1, totalPages: 1, totalRows: 0, perPage: 10 });
                }
            },
            error: function () {
                $('#qaInboundList').html('<tr><td colspan="7" class="text-center py-6 text-sm font-medium text-rose-600">Failed to load inbound materials.</td></tr>');
                renderQaPagination({ page: 1, totalPages: 1, totalRows: 0, perPage: 10 });
            }
        });
    }

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function openInboundCoaForm(queueId, stockInwardId = 0) {
        if (!queueId && !stockInwardId) {
            toastr.error('Invalid inbound material selection.');
            return;
        }

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                fetchInboundMaterialForCoa: '1',
                id: queueId,
                stock_inward_id: stockInwardId
            },
            success: function (res) {
                if (res.status === 'success') {
                    const m = res.data || {};
                    $('#inbound_queue_id').val(m.id || queueId || '');
                    $('#stock_inward_id').val(m.stock_inward_id || stockInwardId || '');
                    $('#coa_goods_type').val(m.goods_type || 'RM');
                    $('#inboundMaterialTypeBadge').text((m.goods_type || 'RM') + ' Record');
                    $('#coa_number').val(res.generated_coa || '');
                    $('#coa_digit').val(res.generated_digit || '');
                    $('#coa_material_code').val(m.product_code || '—');
                    $('#coa_product_name').val(m.product_name || '');
                    $('#coa_batch_number').val(m.lot_number || '');
                    $('#coa_batch_qty').val(parseFloat(m.quantity) || 0);
                    $('#coa_batch_size').val((parseFloat(m.quantity) || 0) + ' ' + (m.unit_name || 'units'));
                    $('#coa_batch_unit_id').val(m.unit_id || m.quantity_unit || '');
                    $('#coa_supplier_name').val(m.supplier_name || '-');
                    $('#coa_manufacturer_name').val(m.supplier_name || '');
                    $('#coa_receipt_date').val(m.date_of_entry || '');
                    $('#coa_testing_date').val(new Date().toISOString().slice(0, 10));
                    $('#coa_mfg_date').val(m.prod_mfg_date || '');
                    $('#coa_expiry_date').val(m.prod_expiary_date || '');
                    $('#coa_invoice_number').val(m.invoice_number || '');
                    $('#coa_invoice_date').val(m.invoice_date || '');
                    $('#coa_containers').val('');
                    $('#coa_storage').val('Ambient');
                    $('#coa_remarks').val('');

                    const templates = Array.isArray(res.templates) ? res.templates : [];
                    $('#inboundTemplateBadge').text(templates.length + ' templates available');

                    let opts = '<option value="">-- Select a Testing Template --</option>';
                    let currentGroup = '';
                    let firstRecommendedId = null;

                    templates.forEach(function (t) {
                        const grp = t.group_label || '📋 All Available COA Templates';
                        if (grp !== currentGroup) {
                            if (currentGroup !== '') opts += '</optgroup>';
                            opts += `<optgroup label="${escapeHtml(grp)}">`;
                            currentGroup = grp;
                        }
                        const recBadge = t.is_recommended ? ' ⭐' : '';
                        const itemsBadge = t.item_count ? ` (${t.item_count} items)` : '';
                        opts += `<option value="${t.id}" data-recommended="${t.is_recommended ? '1' : '0'}" data-items="${t.item_count || 0}">${escapeHtml(t.name)}${recBadge}${itemsBadge}</option>`;
                        if (t.is_recommended && !firstRecommendedId) {
                            firstRecommendedId = t.id;
                        }
                    });
                    if (currentGroup !== '') opts += '</optgroup>';

                    const $tmplSelect = $('#inboundCoaTemplateSelect');
                    if ($tmplSelect.hasClass('select2-hidden-accessible')) {
                        try { $tmplSelect.select2('destroy'); } catch(e) {}
                    }
                    $tmplSelect.html(opts);
                    $tmplSelect.select2({
                        dropdownParent: $('#inboundCoaEntryModal'),
                        width: '100%'
                    });

                    // Auto-load first recommended template or first template
                    if (firstRecommendedId) {
                        $tmplSelect.val(firstRecommendedId).trigger('change.select2');
                        loadInboundTemplateFields(firstRecommendedId);
                    } else if (templates.length > 0) {
                        $tmplSelect.val(templates[0].id).trigger('change.select2');
                        loadInboundTemplateFields(templates[0].id);
                    } else {
                        $('#inboundDynamicCoaFields').html(`
                            <div class="rounded-xl border border-dashed border-slate-300 bg-slate-50/80 p-5 text-center text-xs text-slate-600">
                                <i class="ti ti-info-circle text-2xl block mb-1 text-indigo-600"></i>
                                <div class="font-medium text-slate-700 mb-1">No active testing template is configured for this material.</div>
                                <p class="text-slate-500 m-0 mb-3">Testing template is optional. You can proceed with COA generation or configure a template in Company Control Room.</p>
                                <a href="index.php?page=coa-templates" target="_blank" class="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-indigo-700 shadow-sm transition-all">
                                    <i class="ti ti-settings-cog"></i> Configure COA Templates
                                </a>
                            </div>
                        `);
                    }

                    // Hide inbound requests modal and open COA entry modal
                    $('#inboundMaterialsModal').modal('hide');
                    $('#inboundCoaEntryModal').modal('show');
                } else {
                    toastr.error(res.message || 'Unable to fetch material details.');
                }
            },
            error: function () {
                toastr.error('Unable to fetch inbound material for COA.');
            }
        });
    }

    function loadInboundTemplateFields(templateId) {
        if (!templateId) {
            $('#inboundDynamicCoaFields').html(`
                <div class="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-6 text-center text-xs text-slate-500">
                    <i class="ti ti-list-details text-2xl block mb-1 text-slate-400"></i>
                    Select a testing template above and click "Load Template" to display parameter specifications.
                </div>
            `);
            return;
        }

        $('#inboundDynamicCoaFields').html(`
            <div class="py-6 text-center text-slate-400 text-xs">
                <i class="ti ti-loader-2 animate-spin text-2xl block mb-1 text-indigo-600"></i>
                Loading template specifications &amp; test parameters...
            </div>
        `);

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                fetchTemplateFields: 'fetchTemplateFields',
                template_id: templateId
            },
            success: function (res) {
                if (res.status === 'success') {
                    $('#inboundDynamicCoaFields').html(res.data);
                } else {
                    toastr.error(res.message || 'Unable to load template fields.');
                    $('#inboundDynamicCoaFields').html(`
                        <div class="rounded-xl border border-dashed border-rose-300 bg-rose-50/60 p-5 text-center text-xs text-rose-700">
                            <i class="ti ti-alert-circle text-2xl block mb-1 text-rose-600"></i>
                            ${escapeHtml(res.message || 'Unable to load testing specifications for this template.')}
                        </div>
                    `);
                }
            },
            error: function () {
                toastr.error('Server error loading template fields.');
            }
        });
    }

    $(document).on('click', '.selectTestBtn', function () {
        const queueId = Number($(this).data('queue-id')) || 0;
        const stockInwardId = Number($(this).data('id')) || 0;
        openInboundCoaForm(queueId, stockInwardId);
    });

    $(document).on('click', '#inboundLoadTemplateBtn', function () {
        const tmplId = $('#inboundCoaTemplateSelect').val();
        if (!tmplId) {
            toastr.warning('Please select a testing template first.');
            return;
        }
        loadInboundTemplateFields(tmplId);
    });

    $(document).on('change', '#inboundCoaTemplateSelect', function () {
        const tmplId = $(this).val();
        if (tmplId) {
            loadInboundTemplateFields(tmplId);
        }
    });

    $(document).on('change', '#coa_goods_type', function () {
        const type = $(this).val();
        if (!type || !$('#inboundCoaEntryModal').hasClass('show')) {
            return;
        }
        $('#inboundMaterialTypeBadge').text(type + ' Record');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { previewInboundCoaNumber: '1', type: type },
            success: function (response) {
                const res = typeof response === 'string' ? JSON.parse(response) : response;
                if (res.status === 'success') {
                    $('#coa_number').val(res.coa_number);
                    $('#coa_digit').val(res.coa_digit);
                }
            }
        });
    });

    $('#inboundCoaEntryForm').on('submit', function (e) {
        e.preventDefault();
        const $submitBtn = $('#inboundCoaSubmitBtn');
        $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

        const formData = $(this).serialize() + '&submitInboundCoa=1';
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#inboundCoaEntryModal').modal('hide');
                    toastr.success(res.message || 'COA record generated successfully.');
                    loadQaInboundMaterials(1);
                    loadCoaRmPmTable();
                } else {
                    toastr.error(res.message || 'COA generation failed.');
                }
            },
            error: function () {
                toastr.error('Request failed. Please check required fields.');
            },
            complete: function () {
                $submitBtn.prop('disabled', false).html('<i class="ti ti-check text-base"></i> Submit &amp; Generate COA');
            }
        });
    });

    // -- QA/QC Inbound Materials Server-side Pagination & Search --
    function renderQaPagination(meta) {
        const total = Math.max(0, Number(meta.totalRows) || 0);
        const totalPages = Math.max(1, Number(meta.totalPages) || 1);
        const perPage = Number(meta.perPage) || 10;
        qaPage = Math.min(Math.max(1, Number(meta.page) || 1), totalPages);

        const start = total === 0 ? 0 : ((qaPage - 1) * (perPage === -1 ? total : perPage)) + 1;
        const end = total === 0 ? 0 : Math.min(start + $('#qaInboundList tr.inbound-row').length - 1, total);
        $('#qaInboundPaginationSummary').text(`Showing ${start} to ${end} of ${total} entries`);

        const buttonClass = 'qa-pagination-btn inline-flex h-9 min-w-9 items-center justify-center rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50';
        $('#qaInboundPaginationWrapper').html(`
            <button type="button" class="${buttonClass}" data-page="${qaPage - 1}" ${qaPage <= 1 ? 'disabled' : ''} aria-label="Previous page">
                <i class="ti ti-chevron-left"></i>
            </button>
            <span class="inline-flex h-9 items-center justify-center rounded-lg bg-slate-100 px-3 text-xs font-bold text-slate-700" aria-current="page">
                Page ${qaPage} of ${totalPages}
            </span>
            <button type="button" class="${buttonClass}" data-page="${qaPage + 1}" ${qaPage >= totalPages ? 'disabled' : ''} aria-label="Next page">
                <i class="ti ti-chevron-right"></i>
            </button>
        `);
    }

    $(document).on('click', '.qa-per-page-item', function(e) {
        e.preventDefault();
        let val = parseInt($(this).data('val'));
        let text = $(this).text();
        $('#qaInboundPerPage').val(val);
        $('#qaInboundPerPageText').text(text);
        loadQaInboundMaterials(1);
    });

    $(document).on('input', '#qaInboundSearch', function() {
        clearTimeout(qaSearchTimer);
        qaSearchTimer = setTimeout(function () {
            loadQaInboundMaterials(1);
        }, 250);
    });

    $(document).on('click', '.qa-pagination-btn', function () {
        if (!this.disabled) {
            loadQaInboundMaterials($(this).data('page'));
        }
    });

    // Load widget on page ready
    loadQaInboundMaterials();

    // Trigger popup modal for Inbound Materials
    $(document).on('click', '#inboundMaterialWidget', function () {
        loadQaInboundMaterials(1);
        $('#inboundMaterialsModal').modal('show');
    });

</script>
<?php endSection(); ?>
