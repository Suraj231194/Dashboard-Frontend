<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="tendersPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="tenders-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="tenders-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="tenders-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="tenders-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="tenders-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="tenders-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchData"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (canDoThis('tenders_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="addNewTendersModalBtn" data-bs-toggle="modal" data-bs-target="#animationModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Timestamp">Timestamp</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" style="width: 240px; min-width: 240px; max-width: 240px;" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Tend Number">Tend Num</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Institution"> Institution</th>
                            <th class="sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50" data-column="u.name" data-default="asc" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Publish Date"><span class="inline-flex items-center gap-1">Publish Date <i class="ti ti-arrows-sort text-xs text-slate-400"></i></span></th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Last Submission">Last Submission</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Submitted At">Submitted At</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-column="r.name" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Created By">Created By</th>
                            <th class="px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="tendersTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Tender</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create new tender entry</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addNewTenderForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
                            <div>
                                <label for="tenderNumber" class="mb-1 block text-sm font-medium text-slate-800">Tender Number <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="tenderNumber" autocomplete="off" name="tenderNumber" class="input-theme" placeholder="Enter Tender Number" required />
                            </div>
                            <div>
                                <label for="tenderSelfId" class="mb-1 block text-sm font-medium text-slate-800">Tender ID</label>
                                <input type="text" id="tenderSelfId" autocomplete="off" name="tenderSelfId" class="input-theme" placeholder="Enter Tender ID" />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="tenderInstitute">Institution Type <strong class="text-rose-500">*</strong></label>
                                <select name="tenderInstitute" id="tenderInstitute" class="input-theme select2" required>
                                    <option value="">--Select--</option>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="authorityType">Authority Type <strong class="text-rose-500">*</strong></label>
                                <select name="authorityType" id="authorityType" class="input-theme select2" required>
                                    <?php if (!empty(Constant::TENDERS['TENDER_AUTHORITY_TYPE'])) {
                                        echo '<option value="">--Select--</option>';
                                        foreach (Constant::TENDERS['TENDER_AUTHORITY_TYPE'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="tenderType">Tender Type <strong class="text-rose-500">*</strong></label>
                                <select name="tenderType" id="tenderType" class="input-theme select2" required>
                                    <?php if (!empty(Constant::TENDERS['TENDER_TYPE'])) {
                                        echo '<option value="">--Select--</option>';
                                        foreach (Constant::TENDERS['TENDER_TYPE'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="tenderCategory">Tender Category <strong class="text-rose-500">*</strong></label>
                                <select name="tenderCategory" id="tenderCategory" class="input-theme select2" required>
                                    <?php if (!empty(Constant::TENDERS['TENDER_CATEGORY'])) {
                                        echo '<option value="">--Select--</option>';
                                        foreach (Constant::TENDERS['TENDER_CATEGORY'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div>
                                <label for="publishDate" class="mb-1 block text-sm font-medium text-slate-800">Publish Date <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="publishDate" autocomplete="off" name="publishDate" class="input-theme" placeholder="Enter Publish Date" required />
                            </div>
                            <div>
                                <label for="submissionLasthDate" class="mb-1 block text-sm font-medium text-slate-800">Submission Last Date</label>
                                <input type="date" id="submissionLasthDate" autocomplete="off" name="submissionLasthDate" class="input-theme flatpickr-input-datetime" placeholder="Enter Submission Last Date" />
                            </div>
                            <div>
                                <label for="submissionAt" class="mb-1 block text-sm font-medium text-slate-800">Submission At</label>
                                <input type="date" id="submissionAt" autocomplete="off" name="submissionAt" class="input-theme flatpickr-input-datetime" placeholder="Enter Submission At" />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="emdType">EMD Type <strong class="text-rose-500">*</strong></label>
                                <select name="emdType" id="emdType" class="input-theme select2" required>
                                    <?php if (!empty(Constant::TENDERS['TENDER_EMD_TYPE'])) {
                                        echo '<option value="">--Select--</option>';
                                        foreach (Constant::TENDERS['TENDER_EMD_TYPE'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div class="d-none" id="emdCalculationWrap">
                                <label class="mb-1 block text-sm font-medium text-slate-800">EMD Calculation Type</label>
                                <select id="emdCalculationType" name="emdCalculationType" class="input-theme select2">
                                    <?php if (!empty(Constant::TENDERS['TENDER_EMD_CALCULATION_TYPE'])) {
                                        echo '<option value="">--Select--</option>';
                                        foreach (Constant::TENDERS['TENDER_EMD_CALCULATION_TYPE'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>

                            <div class="d-none" id="fixedEmdSection">
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="fixedEmdAmount">Fixed EMD Amount</label>
                                <input type="number" min="0" step="any" name="fixedEmdAmount" id="fixedEmdAmount" class="input-theme" placeholder="Enter Fixed EMD">
                            </div>
                            <div class="d-none" id="emdNItemsSection">
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="emdNItemsAmount">N Items EMD Amount</label>
                                <input type="number" min="0" step="any" name="emdNItemsAmount" id="emdNItemsAmount" class="input-theme" placeholder="Enter N Items EMD">
                            </div>
                            <div class="d-none" id="emdEachItemsSection">
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="emdEachItemsAmount">EachItems Tot EMD Amount</label>
                                <input type="number" min="0" step="any" name="emdEachItemsAmount" id="emdEachItemsAmount" value="" class="input-theme bg-slate-100" readonly placeholder="Calculated EMD">
                            </div>
                        </div>

                        <div class="mt-4 md:col-span-4" id="itemEmdSection">
                            <h6 class="text-sm font-bold text-indigo-700 mb-3 border-b border-indigo-100 pb-2">Tender Items</h6>

                            <div id="itemContainer">
                            </div>

                            <div class="mt-3">
                                <button type="button" class="inline-flex h-8 items-center justify-center gap-2 rounded-lg border border-indigo-200 bg-indigo-50 px-3 text-xs font-semibold text-indigo-700 transition-colors hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/30" id="addItemBtn">
                                    <i class="ti ti-plus text-sm"></i> Add Item
                                </button>
                            </div>
                        </div>

                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button" class="biogenix-nav-btn-logout" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="tenderViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <h5 class="modal-title flex items-center gap-2 text-base font-bold text-slate-800" id="exampleModalLabel5">
                        <i class="ti ti-eye text-xl text-indigo-600"></i> Tender Details
                    </h5>
                    <button type="button" class="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-200 hover:text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-300" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-lg"></i>
                    </button>
                </div>
                <div id="tenderView">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div id="tenderBasicSection"></div>
                        
                        <div class="mt-4 flex flex-col gap-4" id="tenderAccordion">
                            <div class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
                                <h2 class="accordion-header m-0">
                                    <button type="button" class="accordion-button group !flex !w-full items-center !justify-between bg-white !px-6 !py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none after:hidden" data-section="items" onclick="$('#sectionItems').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                                        <div class="flex-1 text-left">Tender Items</div>
                                        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200">
                                            <i class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i>
                                        </div>
                                    </button>
                                </h2>
                                <div id="sectionItems" style="display:none;">
                                    <div class="border-t border-slate-200 bg-slate-50/50 p-0">
                                        <div class="accordion-body !px-4 !py-3" id="itemsSection"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
                                <h2 class="accordion-header m-0">
                                    <button type="button" class="accordion-button group !flex !w-full items-center !justify-between bg-white !px-6 !py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none after:hidden" data-section="financial" onclick="$('#sectionFinancial').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                                        <div class="flex-1 text-left">Financial Evaluation</div>
                                        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200">
                                            <i class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i>
                                        </div>
                                    </button>
                                </h2>
                                <div id="sectionFinancial" style="display:none;">
                                    <div class="border-t border-slate-200 bg-slate-50/50 p-0">
                                        <div class="accordion-body !px-4 !py-3" id="financialSection"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden transition-shadow hover:shadow-md">
                                <h2 class="accordion-header m-0">
                                    <button type="button" class="accordion-button group !flex !w-full items-center !justify-between bg-white !px-6 !py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none after:hidden" data-section="contracts" onclick="$('#sectionContracts').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                                        <div class="flex-1 text-left">Contracts</div>
                                        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200">
                                            <i class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i>
                                        </div>
                                    </button>
                                </h2>
                                <div id="sectionContracts" style="display:none;">
                                    <div class="border-t border-slate-200 bg-slate-50/50 p-0">
                                        <div class="accordion-body !px-4 !py-3" id="contractsSection"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="tenderPaymentEmdFeeModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600 shadow-inner">
                            <i class="ti ti-cash text-xl"></i>
                        </div>
                        <h5 class="modal-title flex items-center gap-2 text-base font-bold text-slate-800" id="exampleModalLabel5">Tender Payments</h5>
                    </div>
                    <button type="button" class="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500 transition-colors hover:bg-slate-200 hover:text-slate-700" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-lg"></i>
                    </button>
                </div>
                <form id="tenderPaymentEmdFeeForm">
                    <div class="modal-body !p-6 bg-slate-50/30">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-6 col-md-6">
        <div class="mt-3">
            <div class="offcanvas offcanvas-end" tabindex="-1" id="tenderHistoryView">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title">Tender History</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                </div>
                <div class="offcanvas-body">

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="tenderStatusChangeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-arrows-exchange text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Tender Status Update</h5>
                            <p class="m-0 text-xs text-slate-500">Update current workflow stage and record remarks</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="tenderStatusChange">
                    <div class="modal-body !p-6 bg-slate-50/30" style="max-height: calc(100vh - 200px); overflow-y: auto;">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="tenderEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Tender Edit Details</h5>
                            <p class="m-0 text-xs text-slate-500">Edit tender parameters and item requirements</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="tenderEditForm">
                    <div class="modal-body !p-6 bg-slate-50/30" style="max-height: calc(100vh - 200px); overflow-y: auto;">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="tenderFinancialModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-user-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Tender Financial Details</h5>
                            <p class="m-0 text-xs text-slate-500">Manage financial evaluation quotes and results</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="tenderFinancialForm">
                    <div class="modal-body !p-6 bg-slate-50/30" style="max-height: calc(100vh - 200px); overflow-y: auto;">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="tenderAOCModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-award-filled rounded-circle text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Tender AOC Details</h5>
                            <p class="m-0 text-xs text-slate-500">Award of Contract information and records</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="tenderAOCForm">
                    <div class="modal-body !p-6 bg-slate-50/30" style="max-height: calc(100vh - 200px); overflow-y: auto;">
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<?php startSection('scripts'); ?>
<script src="<?= asset('assets/js/ui-popover.js') ?>"></script>

<script>
    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';
    let qtyUnitOptions = [];

    function initPopovers() {
        document.querySelectorAll('[data-bs-toggle="popover"]').forEach(el => {
            bootstrap.Popover.getOrCreateInstance(el, {
                container: 'body',
                html: true,
                sanitize: false
            });
        });
    }

    function loadTendersTable(page = 1) {
        currentPage = page;
        const search = $('#searchData').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadTenders: 'loadTenders',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function(response) {
                $('#tendersTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                initPopovers();
            },
            error: function() {
                $('#tendersTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function(response) {
                qtyUnitOptions = response;
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadTenderInstitutions() {
        $('#tenderInstitute').html('');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getTenderInstitutionsList: 'getTenderInstitutionsList'
            },
            success: function(response) {
                tenderInstitutionsOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                tenderInstitutionsOptions.forEach(tenIns => {
                    optionsHtml += `<option value="${tenIns.id}">${tenIns.name}</option>`;
                });
                $('#tenderInstitute').html(optionsHtml).trigger('change');
            },
            error: function(xhr, status, error) {
                console.error("Failed to load tender institutions:", error);
            }
        });
    }

    $(document).ready(function() {
        loadTendersTable();
        loadStandardUnit();
        loadTenderInstitutions();

        $('#animationModal .select2').select2({
            dropdownParent: $('#animationModal')
        });

        $('.modal, .modal-body').on('scroll', function() {
            $('.select2-hidden-accessible').select2('close');
        });

        $('#searchData').on('input', function() {
            loadTendersTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadTendersTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadTendersTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.tenders-per-page-item', function () {
            const val = $(this).data('val');
            $('#tendersPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#emdType').on('change', function() {
            let type = $(this).val();
            $('#itemContainer').html('');
            $('#fixedEmdAmount').attr('required', false).val(0);
            $('#fixedEmdSection').addClass('d-none');

            if (type === APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.Exempted) {
                return;
            }
            if (type == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.Fixed) {
                $('#fixedEmdSection').removeClass('d-none');
                $('#fixedEmdAmount').attr('required', true).val(0);
                $('#emdEachItemsSection').addClass('d-none');
            }

            $('#emdCalculationWrap').addClass('d-none');
            $('#emdNItemsSection').addClass('d-none');
            $('#emdNItemsAmount').attr('required', false).val(0);
            if (type == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.ItemWise) {
                $('#emdCalculationWrap').removeClass('d-none');
                $('#itemEmdSection').removeClass('d-none');
            }
        });

        $('#emdCalculationType').on('change', function() {
            $('#emdEachItemsSection, #emdNItemsSection').addClass('d-none');

            let calcType = $(this).val();

            if (calcType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.EachItem) {
                $('#emdEachItemsSection').removeClass('d-none');
            }

            if (calcType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.UptoNItems) {
                $('#emdNItemsSection').removeClass('d-none');
            }

            syncEachItemEmdVisibility();
        });

        $('#addItemBtn').on('click', function() {

            let emdType = $('#emdType').val();
            let emdCalculationType = $('#emdCalculationType').val();
            let index = Math.floor(Math.random() * 100000);
            let optionsHtml = '<option value="">---Select----</option>';
            qtyUnitOptions.forEach(unit => {
                optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });

            if (!emdType) {
                toastr.error('Please select EMD Type first');
                return;
            }
            if (emdType == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.ItemWise && !emdCalculationType) {
                toastr.error('Please select EMD Calculation Type first');
                return;
            }

            let showEachItemEmd =
                emdType == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.ItemWise &&
                emdCalculationType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.EachItem;
            let html = `
            <div class="row item-row mb-2">
                <div class="col-12">
                    <div class="p-1 mt-1 border rounded shadow-sm">
                        <div class="row">
                            <div class="col-md-3 mb-1">
                                <input type="text" name="items[${index}][item_name]" class="form-control" placeholder="Item Name" required>
                            </div>

                            <div class="col-md-3 mb-1">
                                <input type="text" name="items[${index}][item_code]" class="form-control" placeholder="Item Code">
                            </div>

                            <div class="col-md-3 mb-1">
                                <input type="number" step="0.01" name="items[${index}][quantity]" class="form-control" placeholder="Quantity" required>
                            </div>
                            <div class="col-md-3 mb-1">
                            <select class="form-control select2" name="items[${index}][quantity_unit]" required>` + optionsHtml + `
                            </select>
                            </div>

                            <div class="col-md-3 mb-1 each-item-emd d-none">
                                <input type="number" min="0" step="0.01" name="items[${index}][sub_item_emd_amount]" class="form-control sub_item_emd_amount" placeholder="EMD Amount">
                            </div>

                            <div class="col-md-5 mb-1">
                            <textarea class="form-control" name="items[${index}][specs]"  placeholder="Additional Specs..." rows="1"></textarea>
                            </div>
                            <div class="col-md-3 mb-1">
                                <input type="number" min="0" step="0.01" name="items[${index}][sub_item_qoute_price]" class="form-control" placeholder="Quote Price">
                            </div>

                            <div class="col-md-1 mb-1">
                                <button type="button" class="btn btn-danger removeItemBtn">
                                    <i class="ti ti-trash"></i>
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
                 `;

            $('#itemContainer').append(html);
            $('#itemContainer .select2').last().select2({ dropdownParent: $('#animationModal') });
            syncEachItemEmdVisibility();
        });

        $(document).on('click', '.removeItemBtn', function() {
            $(this).closest('.item-row').remove();
        });

        $(document).on('submit', '#addNewTenderForm', function(e) {
            e.preventDefault();
            let emdType = $('#emdType').val();
            let finalEmd = getFinalEmdAmount();

            if (emdType != APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.Exempted && finalEmd <= 0) {
                toastr.error('Invalid EMD amount');
                return;
            }
            const form = document.getElementById('addNewTenderForm');
            const formData = new FormData(form);
            formData.append('addTenderRecord', 'addTenderRecord');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addNewTenderForm')[0].reset();
                        loadTendersTable();
                        loadTenderInstitutions();
                        toastr.success(res.message);
                        $(document).find('#itemContainer').html('');
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });

    $(document).on('click', '.tenderDeleteBtn', function() {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function(result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteTenderRecord: 'deleteTenderRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.status === 'success') {
                            loadTendersTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.sortable', function() {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = $(this).data('default') || 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadTendersTable(1);
    });


    function calculateEachItemEmdTotal() {
        let total = 0;

        $('.sub_item_emd_amount').each(function() {
            let val = parseFloat($(this).val());
            if (!isNaN(val)) {
                total += val;
            }
        });

        $('#emdEachItemsAmount').val(total.toFixed(2));
    }

    $(document).on('input', '.sub_item_emd_amount', function() {
        calculateEachItemEmdTotal();
    });

    $(document).on('click', '#addItemBtn', function() {
        setTimeout(calculateEachItemEmdTotal, 100);
    });

    $(document).on('click', '.removeItemBtn', function() {
        $(this).closest('.item-row').remove();
        calculateEachItemEmdTotal();
    });

    $('.flatpickr-input-datetime').flatpickr({
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        time_24hr: true,
        minuteIncrement: 1,
        allowInput: true
    });

    function getFinalEmdAmount() {
        let emdType = $('#emdType').val();
        let calcType = $('#emdCalculationType').val();
        if (emdType == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.Exempted) {
            return 0;
        }

        if (emdType == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.Fixed) {
            return parseFloat($('#fixedEmdAmount').val()) || 0;
        }

        if (emdType == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.ItemWise) {

            if (calcType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.EachItem) {
                return parseFloat($('#emdEachItemsAmount').val()) || 0;
            }

            if (calcType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.UptoNItems) {
                return parseFloat($('#emdNItemsAmount').val()) || 0;
            }
        }
        return 0;
    }

    function syncEachItemEmdVisibility() {
        let calcType = $('#emdCalculationType').val();

        if (calcType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.EachItem) {
            $('.each-item-emd')
                .removeClass('d-none')
                .find('input')
                .prop('required', true);
        } else {
            $('.each-item-emd')
                .addClass('d-none')
                .find('input')
                .prop('required', false)
                .val(0);
        }
        calculateEachItemEmdTotal();
    }

    let loaded = {};
    let currentTenderId = null;

    $(document).on('click', '.tenderViewBtn', function () {

        currentTenderId = $(this).data('id');

        loaded = {};
        $('#tenderBasicSection').html('');
        $('.accordion-body').html('');

        $.post('ajax.php', {
            loadTenderBasic: 'loadTenderBasic',
            tender_id: currentTenderId
        }, function (res) {

            if (res.status === 'success') {
                $('#tenderBasicSection').html(res.html);
                $('#tenderViewModal').modal('show');
            }

        }, 'json');
    });

    $(document).on('click', '.accordion-button', function () {

        let section = $(this).data('section');

        if (loaded[section]) return;

        $.post('ajax.php', {
            loadTenderSection: 'loadTenderSection',
            action: 'load_' + section,
            tender_id: currentTenderId
        }, function (res) {

            if (res.status === 'success') {
                $('#' + section + 'Section').html(res.html);
                loaded[section] = true;
            }

        }, 'json');
    });

    $(document).on('click', '.loadContractItems', function () {
        let contractId = $(this).data('contract');
        let tenderId = $(this).data('tender-id');
        let container  = $('#contractItems_' + contractId);

        if (container.data('loaded')) return;

        $.post('ajax.php', {
            loadTenderSection: 'loadTenderSection',
            action: 'load_contract_items',
            contract_id: contractId,
            tender_id: tenderId
        }, function (res) {
            if (res.status === 'success') {
                container.html(res.html);
                container.data('loaded', true);
            }

        }, 'json');
    });

    $('#tenderViewModal').on('hidden.bs.modal', function () {
        loaded = {};
        currentTenderId = null;
    });




    $(document).on('click', '.tenderViewHistoryBtn', function() {
        let id = $(this).data('id');

        if (!id) return;
        $('#tenderHistoryView').find('.offcanvas-body').html(
            '<div class="text-center py-3">Loading...</div>'
        );

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                tendersHistoryViewRecord: 'tendersHistoryViewRecord',
                id: id
            },
            success: function(res) {
                if (res.status === 'success') {
                    $('#tenderHistoryView').find('.offcanvas-body').html(res.data);
                    let el = document.getElementById('tenderHistoryView');
                    let offcanvas = bootstrap.Offcanvas.getOrCreateInstance(el);
                    offcanvas.show();

                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function() {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.tenderPaymentEmdFeeModelBtn', function() {
        let id = $(this).data('id');
        if (id) {
            $('#tenderPaymentEmdFeeForm').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchTenderEmdPaymentRecord: 'fetchTenderEmdPaymentRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#tenderPaymentEmdFeeModel').modal('show');
                        $('#tenderPaymentEmdFeeForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('change', '.form-check-input[data-target], input[type="checkbox"][data-target]', function() {

        let targetId = $(this).data('target');
        let $section = $('#' + targetId);

        if ($(this).is(':checked')) {

            // show
            $section.removeClass('d-none');

            // enable + required
            $section.find('input, select').each(function() {
                $(this)
                    .prop('disabled', false)
                    .attr('required', true);
            });

        } else {

            // hide
            $section.addClass('d-none');

            // disable + remove required + clear
            $section.find('input, select').each(function() {
                $(this)
                    .prop('disabled', true)
                    .removeAttr('required')
                    .val('');
            });
        }
    });

    $(document).on('submit', '#tenderPaymentEmdFeeForm', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        formData.append('tenderPaymentsRecord', 'tenderPaymentsRecord');

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success(res) {
                if (res.status === 'success') {
                    toastr.success(res.message);
                    $('#tenderPaymentEmdFeeModel').modal('hide');
                    loadTendersTable();
                } else {
                    toastr.error(res.message);
                }
            }
        });
    });

    $(document).on('click', '.tenderStatusChangeBtn', function() {
        let id = $(this).data('id');
        if (id) {
            $('#tenderStatusChange').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchTenderStatusRecord: 'fetchTenderStatusRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#tenderStatusChangeModal').modal('show');
                        $('#tenderStatusChange').find('.modal-body').html(res.data);
                        $('#tenderStatusChangeModal .select2').select2({
                            dropdownParent: $('#tenderStatusChangeModal'),
                            width: '100%'
                        });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('submit', '#tenderStatusChange', function(e) {
        e.preventDefault();
        const form = document.getElementById('tenderStatusChange');
        const formData = new FormData(form);
        formData.append('changeTenderStatusRecord', 'changeTenderStatusRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(res) {
                if (res.status === 'success') {
                    $('#tenderStatusChangeModal').modal('hide');
                    loadTendersTable();
                    loadTenderInstitutions();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function() {
                toastr.error('Server error occurred.');
            }
        });
    });
    $(document).on('click', '.view-history-details', function() {
        let $btn = $(this);
        let $timelineEvent = $btn.closest('.timeline-event');
        let $details = $timelineEvent.find('.history-details');
        if ($details.length === 0) return;
        $details.toggleClass('d-none');
        if ($details.hasClass('d-none')) {
            $btn.text('View Details');
        } else {
            $btn.text('Hide Details');
        }
    });

    $(document).on('click', '.tenderEditModelBtn', function() {
        let id = $(this).data('id');
        if (id) {
            $('#tenderEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchTendersEditRecord: 'fetchTendersEditRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#tenderEditModal').modal('show');
                        $('#tenderEditForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                    $('.flatpickr-input-datetime').flatpickr({
                        enableTime: true,
                        dateFormat: "Y-m-d H:i"
                    });
                    $('#tenderEditModal .select2').select2({
                        dropdownParent: $('#tenderEditModal')
                    });
                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '#addItemEditBtn', function() {

        let emdType = $(document).find('#emdTypeEdit').val();
        let emdCalculationType = $(document).find('#emdCalcutionTypeEdit').val();
        let index = Math.floor(Math.random() * 100000);
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });

        let showEachItemEmd =
            emdType == APP_CONST.TENDERS.TENDER_EMD_TYPE_LABEL.ItemWise &&
            emdCalculationType == APP_CONST.TENDERS.TENDER_EMD_CALCULATION_TYPE_LABEL.EachItem;
        let eachItemEmdClass = showEachItemEmd ? '' : 'd-none';
        let html = `
            <div class="row item-row mb-2">
                <div class="col-12">
                    <div class="p-4 mt-1 rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Item Name</label>
                                <input type="hidden" name="items[${index}][id]" value="" >
                                <input type="text" name="items[${index}][item_name]" class="input-theme" placeholder="Enter Item Name" required>
                            </div>

                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Item Code</label>
                                <input type="text" name="items[${index}][item_code]" class="input-theme" placeholder="Enter Item Code">
                            </div>

                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Quantity</label>
                                <input type="number" step="any" name="items[${index}][quantity]" class="input-theme" placeholder="Enter Quantity" required>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Quantity Unit</label>
                                <select class="input-theme select2" name="items[${index}][quantity_unit]" required>` + optionsHtml + `
                                </select>
                            </div>

                            <div class="each-item-emd ${eachItemEmdClass}">
                                <label class="mb-1 block text-sm font-medium text-slate-800">EMD Amount</label>
                                <input type="number" min="0" step="any" name="items[${index}][sub_item_emd_amount]" class="input-theme sub_item_emd_amount" placeholder="Enter EMD Amount">
                            </div>

                            <div class="md:col-span-2">
                                <label class="mb-1 block text-sm font-medium text-slate-800">Additional Specs</label>
                                <textarea class="input-theme" name="items[${index}][specs]"  placeholder="Additional Specs..." rows="1"></textarea>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Quote Price</label>
                                <input type="number" min="0" step="any" name="items[${index}][sub_item_qoute_price]" class="input-theme" placeholder="Enter Quote Price">
                            </div>

                            <div class="flex items-end justify-start">
                                <button type="button" class="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-100 text-rose-600 transition-colors hover:bg-rose-200 removeItemBtnEdit" title="Delete Item">
                                    <i class="ti ti-trash text-lg"></i>
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>`;
        $('#itemContainerEdit').append(html);
        $('#itemContainerEdit .select2').last().select2({ dropdownParent: $('#tenderEditModal') });
    });

    $(document).on('click', '.removeItemBtnEdit', function() {
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            buttonClicked.closest('.item-row').remove();
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function(result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteTenderSubItemRecord: 'deleteTenderSubItemRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                            buttonClicked.closest('.item-row').remove();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $('#tenderEditForm').on('submit', function(e) {
        e.preventDefault();
        const form = document.getElementById('tenderEditForm');
        const formData = new FormData(form);
        formData.append('updateTenderRecord', 'updateTenderRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            contentType: false,
            processData: false,
            success: function(res) {
                if (res.status === 'success') {
                    $('#tenderEditModal').modal('hide');
                    $('#tenderEditForm').find('modal-body').html();
                    loadTendersTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function() {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.tenderFinancialListModelBtn', function() {
        let id = $(this).data('id');
        if (id) {
            $('#tenderFinancialForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchTenderFinacialEvalutionRecord: 'fetchTenderFinacialEvalutionRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#tenderFinancialModal').modal('show');
                        $('#tenderFinancialForm').find('.modal-body').html(res.data);
                        $('#tenderFinancialForm  .select2').select2({
                            dropdownParent: $('#tenderFinancialForm')
                        });

                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }

                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });
    $(document).on('click', '.itemRankLevelDelete', function() {
        $(this).closest('.itemRankLevel').remove();
    });
    $(document).on('click', '.itemLevelDelete', function() {
        $(this).closest('.itemLevel').remove();
    });


    $('#tenderFinancialForm').on('submit', function(e) {
        e.preventDefault();
        const form = document.getElementById('tenderFinancialForm');
        const formData = new FormData(form);
        formData.append('submitTenderFinancialEvaluation', 'submitTenderFinancialEvaluation');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            contentType: false,
            processData: false,
            success: function(res) {
                if (res.status === 'success') {
                    $('#tenderFinancialModal').modal('hide');
                    $('#tenderFinancialForm').find('modal-body').html();
                    loadTendersTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function() {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.tenderAOCListModelBtn', function() {
        let id = $(this).data('id');
        if (id) {
            $('#tenderAOCForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchTenderAOCRecord: 'fetchTenderAOCRecord',
                    id: id
                },
                success: function(res) {
                    if (res.status === 'success') {
                        $('#tenderAOCModal').modal('show');
                        $('#tenderAOCForm').find('.modal-body').html(res.data);
                        $('#tenderAOCForm  .select2').select2({
                            dropdownParent: $('#tenderAOCForm')
                        });

                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }

                },
                error: function() {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.itemAocSingleDelete', function() {
        $(this).closest('.item-row-aoc-single').remove();
    });

    $(document).on('change', '#pgbRequired', function() {
        if ($(this).is(':checked')) {
            $('#pgbRequiredDiv').removeClass('d-none');
            $('#contractPbgAmount').prop('required', true);
        } else {
            $('#pgbRequiredDiv').addClass('d-none');
            $('#contractPbgAmount').prop('required', false);
            $('#contractPbgAmount').val('');
        }
    });

    $('#tenderAOCForm').on('submit', function(e) {
        e.preventDefault();
        const form = document.getElementById('tenderAOCForm');
        const formData = new FormData(form);
        formData.append('submitAOCRecord', 'submitAOCRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            contentType: false,
            processData: false,
            success: function(res) {
                if (res.status === 'success') {
                    $('#tenderAOCModal').modal('hide');
                    $('#tenderAOCForm').find('modal-body').html();
                    loadTendersTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function() {
                toastr.error('Server error occurred.');
            }
        });
    });
</script>

<?php endSection(); ?>
