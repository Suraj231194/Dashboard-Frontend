<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once "../db.php";
require_once "../functions.php";
require_once "../document_pdf_helpers.php";

documentPdfRequireAnyPermission($conn, ['sa_generation_pdf']);

$id = documentPdfEncryptedPositiveId($_GET['id'] ?? '');
$unitMap = [];
$unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
while ($row = $unitQuery->fetch_assoc()) {
    $unitMap[$row['id']] = $row['short_name'];
}
$pdfData = [];
$pdfQuery = 'SELECT * FROM `coa_rm_pm_table` WHERE `id` = ?';
$stmtpdfQuery = $conn->prepare($pdfQuery);
$stmtpdfQuery->bind_param('i', $id);

if ($stmtpdfQuery->execute()) {
    $result = $stmtpdfQuery->get_result(); 
    if ($result && $result->num_rows > 0) {
        $rowPdf = $result->fetch_assoc(); 

        $batchUnitIdShortName       = $unitMap[$rowPdf['batch_unit_id']] ?? $rowPdf['batch_unit_id'];            
        $qauntitySampledUnitShortName = $unitMap[$rowPdf['qauntity_sampled_unit']] ?? $rowPdf['qauntity_sampled_unit'];            

        $pdfData = [
            'id'                     => $rowPdf['id'],
            'nameOfMaterial'         => $rowPdf['name'],
            'materialCodeNo'         => $rowPdf['material_code_no'],
            'manufacturer'           => $rowPdf['manufacturer_name'],
            'supplier'               => $rowPdf['suplier_name'],
            'invoiceNoAndDate'       => $rowPdf['invoice_number'].' / '.formatDateDMY($rowPdf['invoice_date']),
            'dateOfReceipt'          => formatDateDMY($rowPdf['receipt_date']),
            'quantityReceived'       => $rowPdf['batch_size'].' '.$batchUnitIdShortName,
            'noOfContainersReceived' => $rowPdf['number_of_container_received'],
            'batchNoOrLotNo'         => $rowPdf['batch_number'],
            'mfgDate'                => formatDateDMY($rowPdf['mfg_date']),
            'expDate'                => formatDateDMY($rowPdf['expiry_date']),
            'storageCondition'       => $rowPdf['storage_condition'],
            'noOfContainersSampled'  => $rowPdf['container_sampled'],
            'quantityUsedForSampling'=> $rowPdf['qauntity_sampled'].' '.$qauntitySampledUnitShortName,
            'quantityApproved'       => $rowPdf['batch_size'].' '.$batchUnitIdShortName,
            'coaOrARNo'              => $rowPdf['coa_number'],
            'category'               => $rowPdf['type'],
            'remarks'                => $rowPdf['remark'],
            'approvalStatus'         => $rowPdf['approval_status'],
        ];
    } else {            
        http_response_code(404);
        exit('Sample Advice record not found.');
    }
}
$stmtpdfQuery->close();
if(!empty($pdfData))
{
    $rawName  = $pdfData['coaOrARNo'].'-SampleAdvice';
    $fileName = preg_replace('/[^A-Za-z0-9]+/', '_', $rawName);
    $fileName = trim($fileName, '_'); 
}
$serverSideDownload = (string) ($_GET['triggerDownload'] ?? '') === '1';
$logoSource = documentPdfLocalImageDataUri(dirname(__DIR__, 2) . '/assets/img/logo3.jpeg');
if ($serverSideDownload) {
    ob_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sample Advice</title>
    <style>
        .page {
            width: 100%;
            min-height: 1020px; 
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }
        .page:last-child {
            page-break-after: avoid;
        }
        <?php if ($serverSideDownload) { ?>
        .page { min-height: 0; }
        <?php } ?>
    </style>
</head>
<body style="margin: 0;">
    <div id="sampleAdviceContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php
        function renderCheckbox($label, $value, $current) {
            $checked = ($current === $value) ? "☑" : "☐";
            return $checked . " " . $label . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        }
            $footers = ['STORE','PURCHASE','QA/QC'];
            foreach ($footers as $index => $footerLabel):
        ?>
        <div class="page" style="page-break-after: <?= ($index <= 1) ? 'always' : 'auto' ?>;">
            <div style="border: 1px solid #000; margin-bottom:0px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 20px; ">
                        <td style="width: 35%; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                            <img src="<?php echo htmlspecialchars($logoSource, ENT_QUOTES, 'UTF-8'); ?>" alt="Biogenix Logo" style="height: 50px;">
                        </td>
                        <td rowspan="2" style="width: 30%; border-right: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">TITLE: <br/> SAMPLING ADVICE</strong></td>
                        <td rowspan="2" style="width: 20%; border-right: 1px solid #000; text-align:center;"><strong>Document No.</strong></td>
                        <td rowspan="2" style="text-align:center;">BIPL-F-SA-01</td>
                    </tr>
                    <tr>
                        <td style="width: 35%; border-right: 1px solid #000; padding-left:10px;">
                            B19/A S.I.L Ancillary Estate,<br>
                            Amausi Industrial Area,<br>
                            Nadarganj-226008 (Lucknow)
                        </td>
                    </tr>
                </table>
            </div>

            <div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 5px;">
                    <tr style="line-height: 20px; background-color: #e0e0e0">
                        <td colspan="2" style="border-top: 1px solid #000; border-left: 1px solid #000;border-right: 1px solid #000; font-size: 14px;">
                            <div style="display: flex; justify-content: center; align-items: center; width: 100%; font-weight: bold;">
                               Part A-Intimation from Stores to QA/QC
                            </div>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Category</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000; padding-left:10px; font-size: 13px;">
                            <div style="display: flex; justify-content: space-between; width:100%;">
                                <span style="flex:1;">
                                    <?php echo ($pdfData['category'] == 'RM' ? "&#x2611;" : "&#x2610;"); ?> Raw material
                                </span>
                                <span style="flex:1;">
                                    <?php echo ($pdfData['category'] == 'PM' ? "&#x2611;" : "&#x2610;"); ?> Packing material
                                </span>
                                <span style="flex:1;">
                                    <?php echo ($pdfData['category'] == 'CM' ? "&#x2611;" : "&#x2610;"); ?> Consumables
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Name of the Material</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000; padding-left:10px;font-size: 14px;">
                           <?php echo htmlspecialchars($pdfData['nameOfMaterial'] ?? ""); ?>
                        </td>
                    </tr>
                    
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Material Code No.</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 13px;">
                           <?php echo htmlspecialchars($pdfData['materialCodeNo'] ?? ""); ?>
                        </td>
                    </tr>
                                      
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Manufacturer</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['manufacturer'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="vertical-align: top; border-left: 1px solid #000; border-top: 1px solid #000;padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Supplier</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 13px;">
                            <?php echo htmlspecialchars($pdfData['supplier'] ?? ""); ?>
                        </td>
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Invoice No./D.C. No. and Date</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 13px;">
                            <?php echo htmlspecialchars($pdfData['invoiceNoAndDate'] ?? ""); ?>
                        </td>
                    </tr>
                                      
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Date of Receipt</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['dateOfReceipt'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Quantity Received</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['quantityReceived'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>No. of Containers Received</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['noOfContainersReceived'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Batch No./Lot No.</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['batchNoOrLotNo'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Mfg. Date</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['mfgDate'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Exp. Date</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000; border-top: 1px solid #000; border-right: 1px solid #000;padding-left:10px; font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['expDate'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-bottom: 1px solid #000; border-left: 1px solid #000; border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Storage condition</span>
                            </div>
                        </td>
                        <td style="width: 70%; border: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['storageCondition'] ?? ""); ?>
                        </td>
                    </tr>
                </table>
            </div>

            <div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                    <!-- First Row -->
                    <tr style="line-height: 20px;">
                        <td style="width: 22%; border-left: 1px solid #000;border-top: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Department In charge
                        </td>
                        <td style="width: 28%; border-left: 1px solid #000;border-top: 1px solid #000; padding-left:10px; font-size: 13px;">
                            <?php echo htmlspecialchars($row['product_description'] ?? ""); ?>
                        </td>
                        <td style="width: 22%; border-left: 1px solid #000;border-top: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Receiving Signature
                        </td>
                        <td style="width: 28%; border-left: 1px solid #000;border-top: 1px solid #000;border-right: 1px solid #000; padding-left:10px; font-size: 13px;">
                            <?php echo htmlspecialchars($row['product_description'] ?? ""); ?>
                        </td>
                    </tr>

                    <!-- Second Row -->
                    <tr style="line-height: 20px;">
                        <td style="width: 22%; border-left: 1px solid #000;border-top: 1px solid #000;border-bottom: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 28%; border-left: 1px solid #000;border-top: 1px solid #000;border-bottom: 1px solid #000;  padding-left:10px; font-size: 13px;">
                            <?php echo htmlspecialchars($row['product_description'] ?? ""); ?>
                        </td>
                        <td style="width: 22%; border-left: 1px solid #000;border-top: 1px solid #000;border-bottom: 1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 28%; border-left: 1px solid #000;border-top: 1px solid #000;border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:10px; font-size: 13px;">
                            <?php echo htmlspecialchars($row['product_description'] ?? ""); ?>
                        </td>
                    </tr>
                </table>
            </div>


            <div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                    <tr style="line-height: 20px; background-color: #e0e0e0;">
                        <td colspan="2" style="border-left: 1px solid #000;border-top: 1px solid #000;border-right: 1px solid #000; font-size: 14px;">
                            <div style="display: flex; justify-content: center; align-items: center; width: 100%; font-weight: bold;">
                               Part B-Intimation From QA/QC to Stores
                            </div>
                        </td>
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000;border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>No. of Containers Sampled</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000;border-top: 1px solid #000;border-right: 1px solid #000; padding-left:10px;font-size: 13px;">
                            <?php echo htmlspecialchars($pdfData['noOfContainersSampled'] ?? ""); ?>
                        </td>
                    </tr>
                    
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000;border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Quantity Used for Sampling</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000;border-top: 1px solid #000;padding-left:10px;border-right: 1px solid #000;font-size: 13px;">
                            <?php echo htmlspecialchars($pdfData['quantityUsedForSampling'] ?? ""); ?>
                        </td>
                    </tr>
                                      
                    <tr style="line-height: 20px;">
                        <td style="width: 30%; border-left: 1px solid #000;border-top: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Quantity Approved</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000;border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 13px;">
                            <?php echo htmlspecialchars($pdfData['quantityApproved'] ?? ""); ?>
                        </td>
                    </tr>

                    <tr style="line-height: 20px; ">
                        <td style="vertical-align: top; border-left: 1px solid #000;border-top: 1px solid #000;padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>COA/A.R. No.</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000;border-top: 1px solid #000;border-right: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['coaOrARNo'] ?? ""); ?>
                        </td>
                    </tr>
                    <tr style="line-height: 20px; ">
                        <td style="width: 30%; border-left: 1px solid #000;border-top: 1px solid #000;border-bottom: 1px solid #000; padding-left:10px; font-size: 14px;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;">
                                <span>Remarks</span>
                            </div>
                        </td>
                        <td style="width: 70%; border-left: 1px solid #000;border-top: 1px solid #000;border-right: 1px solid #000;border-bottom: 1px solid #000;padding-left:10px;font-size: 14px;">
                            <?php echo htmlspecialchars($pdfData['remarks'] ?? ""); ?>
                        </td>
                    </tr>         
                </table>
            </div>

            <div style="margin-bottom: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">                    
                    <tr style="line-height: 20px;">                        
                        <td colspan="4" style="width: 20%; border-left: 1px solid #000; border-top:1px solid #000;border-right: 1px solid #000; padding-left:10px; font-size: 14px;">
                            The above material is
                            <span style="flex:1;">
                                <?php echo ($pdfData['approvalStatus'] == 1 ? "&#x2611;" : "&#x2610;"); ?> Approved
                            </span>
                            <span style="flex:1;">
                                <?php echo ($pdfData['approvalStatus'] == 2 ? "&#x2611;" : "&#x2610;"); ?> Not Approved
                            </span>
                            <span style="flex:1;">
                                <?php echo ($pdfData['approvalStatus'] == 3 ? "&#x2611;" : "&#x2610;"); ?> Released
                            </span>
                            <span style="flex:1;">
                                <?php echo ($pdfData['approvalStatus'] == 4 ? "&#x2611;" : "&#x2610;"); ?> Not Released for manufacturing
                            </span>
                        </td>                 
                    </tr>
                    <tr style="line-height: 20px;">
                        <td style="width: 20%; border-left: 1px solid #000; border-top:1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Checked By
                        </td>
                        <td style="width: 30%; border-left: 1px solid #000; border-top:1px solid #000; padding-left:10px; font-size: 13px;">
                            
                        </td>
                        <td style="width: 20%; border-left: 1px solid #000; border-top:1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Verified By
                        </td>
                        <td style="width: 30%; border-left: 1px solid #000; border-top:1px solid #000;border-right: 1px solid #000; padding-left:10px; font-size: 13px;">
                            
                        </td>
                    </tr>

                    <tr style="line-height: 20px;">
                        <td style="width: 20%; border-left: 1px solid #000; border-top:1px solid #000;border-bottom:1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 30%; border-left: 1px solid #000; border-top:1px solid #000;border-bottom:1px solid #000; padding-left:10px; font-size: 13px;">
                            
                        </td>
                        <td style="width: 20%; border-left: 1px solid #000; border-top:1px solid #000;border-bottom:1px solid #000; padding-left:10px; font-size: 14px; background-color: #e0e0e0; font-weight: bold;">
                            Date
                        </td>
                        <td style="width: 30%; border-left: 1px solid #000; border-top:1px solid #000; border-bottom:1px solid #000; padding-left:10px;border-right: 1px solid #000; font-size: 13px;">
                            
                        </td>
                    </tr>
                </table>
            </div>
            <div style="border-top: 1px solid #000; border-bottom: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; padding: 10px;">       
                <div style="margin-top: 20px; font-weight: bold;"><?php echo htmlspecialchars($footerLabel ?? ""); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
<?php
if ($serverSideDownload) {
    documentPdfStream((string) ob_get_clean(), $fileName ?: 'sample_advice_' . $id);
}
?>
