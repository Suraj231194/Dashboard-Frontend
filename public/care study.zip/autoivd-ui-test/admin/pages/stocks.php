<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div id="stockListContainer">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Real-time biogenic stock and reagent tracking system.</p>
        </div>
    </div>

    <!-- Summary Widgets -->
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-3 mb-6">
        <div class="bg-white border border-slate-200 rounded-2xl py-3 px-5 shadow-sm relative overflow-hidden flex items-center justify-between transition-all hover:shadow-md cursor-pointer hover:border-emerald-200" id="widgetAvailableCard" role="button" tabindex="0" aria-label="Show available inventory">
            <div class="absolute left-0 top-0 bottom-0 w-1.5 bg-emerald-500"></div>
            <div class="pl-3">
                <p class="text-[10px] font-black uppercase tracking-widest text-slate-400">AVAILABLE</p>
                <h3 class="mt-1 text-4xl font-extrabold text-emerald-600 kpi-card-value" style="color: #059669 !important;" id="widgetAvailable">—</h3>
                <p class="mt-1 text-[11px] font-medium text-slate-400"><span id="widgetAvailableCount">0</span> products in stock</p>
            </div>
            <div class="h-12 w-12 shrink-0 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center">
                <i class="ti ti-circle-check text-2xl"></i>
            </div>
        </div>
        <div class="bg-white border border-slate-200 rounded-2xl py-3 px-5 shadow-sm relative overflow-hidden flex items-center justify-between transition-all hover:shadow-md cursor-pointer hover:border-amber-200" id="widgetLowStockCard">
            <div class="absolute left-0 top-0 bottom-0 w-1.5 bg-amber-500"></div>
            <div class="pl-3">
                <p class="text-[10px] font-black uppercase tracking-widest text-slate-400">LOW ALERTS</p>
                <h3 class="mt-1 text-4xl font-extrabold text-amber-600 kpi-card-value" style="color: #d97706 !important;" id="widgetLowStock">—</h3>
                <p class="mt-1 text-[11px] font-medium text-slate-400">Products below reorder level</p>
            </div>
            <div class="h-12 w-12 shrink-0 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center">
                <i class="ti ti-alert-triangle text-2xl"></i>
            </div>
        </div>
        <div class="bg-white border border-slate-200 rounded-2xl py-3 px-5 shadow-sm relative overflow-hidden flex items-center justify-between transition-all hover:shadow-md cursor-pointer hover:border-rose-200" id="widgetOutOfStockCard">
            <div class="absolute left-0 top-0 bottom-0 w-1.5 bg-rose-500"></div>
            <div class="pl-3">
                <p class="text-[10px] font-black uppercase tracking-widest text-slate-400">OUT OF STOCK</p>
                <h3 class="mt-1 text-4xl font-extrabold text-rose-600 kpi-card-value" style="color: #e11d48 !important;" id="widgetOutOfStock">—</h3>
                <p class="mt-1 text-[11px] font-medium text-slate-400">Products with zero inventory</p>
            </div>
            <div class="h-12 w-12 shrink-0 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center">
                <i class="ti ti-circle-x text-2xl"></i>
            </div>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="stocksPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="stocks-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchData"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 min-w-[140px] w-auto items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                <i class="ti ti-category text-base text-slate-400"></i>
                                Categories
                            </span>
                            <i class="ti ti-filter text-base text-slate-500"></i>
                        </button>
                        <div class="dropdown-menu max-h-[450px] min-w-[540px] overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl"
                            id="productCategoryListOptions">
                        </div>
                    </div>

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 min-w-[140px] w-auto items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                <i class="ti ti-circle-check text-base text-slate-400"></i>
                                Statuses
                            </span>
                            <i class="ti ti-filter text-base text-slate-500"></i>
                        </button>
                        <div class="dropdown-menu max-h-64 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl"
                            id="productStatusListOptions">
                            <div class="p-1">
                                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox" class="stock-status-filter rounded border-slate-300 accent-emerald-600" value="all" checked />
                                    <span>All</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox" class="stock-status-filter rounded border-slate-300 accent-emerald-600" value="1" checked />
                                    <span>Available</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox" class="stock-status-filter rounded border-slate-300 accent-emerald-600" value="2" checked />
                                    <span>Low Stock</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox" class="stock-status-filter rounded border-slate-300 accent-emerald-600" value="0" checked />
                                    <span>Out of Stock</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <button type="button"
                        class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36"
                        data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>

                    <!-- Phase F: Import Button -->
                    <button type="button" id="importStockBtn"
                        class="inline-flex h-10 shrink-0 items-center justify-center gap-2 !rounded-xl border border-indigo-200 bg-indigo-50 px-4 text-sm font-semibold text-indigo-700 shadow-sm transition-colors hover:bg-indigo-100 focus:outline-none"
                        data-bs-toggle="modal" data-bs-target="#importStockModal">
                        <i class="ti ti-upload text-lg"></i> <span class="whitespace-nowrap">Import</span>
                    </button>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'stocks_add')) { ?>
                        <button type="button" onclick="showAddProductForm()"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add Item">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse whitespace-nowrap text-left">
                    <thead class="border-b border-slate-100 bg-white">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="prod.product_code" data-order="asc">
                                <span class="inline-flex items-center gap-1">CAT <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-52 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="prodcateg.name" data-order="asc">
                                <span class="inline-flex items-center gap-1">CATEGORY <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-80 min-w-[300px] cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="prod.product_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Total Qty
                            </th>
                            <th class="w-36 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Reserved
                            </th>
                            <th class="sortable w-52 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="qtysum.total_quantity" data-order="asc">
                                <span class="inline-flex items-center gap-1">Unreserved <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="prod.reorder_level" data-order="asc">
                                <span class="inline-flex items-center gap-1">L/S R.L <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="stock_status" data-order="asc">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th
                                class="w-36 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Auto</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="employeesTableBody">
                    </tbody>
                </table>
            </div>
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }

                /* Keep record separators visible for dynamically loaded stock rows. */
                #employeesTableBody > tr:not(:last-child) > td {
                    border-bottom: 1px solid #e2e8f0;
                }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    </div> <!-- End stockListContainer -->

    <!-- Add Product Form Container (Hidden by default) -->
    <div id="stockFormContainer" style="display: none;" class="w-full mt-2">
        <!-- Breadcrumb + Header -->
        <div class="mb-1">
            <nav class="flex items-center gap-1.5 text-xs font-medium text-slate-400 mb-3">
                <button type="button" onclick="hideAddProductForm()" class="hover:text-emerald-600 transition-colors flex items-center gap-1"><i class="ti ti-arrow-left text-sm"></i> Catalog</button>
                <i class="ti ti-chevron-right text-[10px]"></i>
                <span class="text-slate-400">Products</span>
                <i class="ti ti-chevron-right text-[10px]"></i>
                <span id="productFormBreadcrumb" class="text-emerald-600 font-semibold">Add New Product</span>
            </nav>
            <div class="flex items-center justify-between gap-4 mb-5">
                <div>
                    <h1 id="productFormTitle" style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                        Add New Product
                    </h1>
                    <p id="productFormSubtitle" style="font-size: 0.8rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                        Create a new product record with variants and category mapping
                    </p>
                </div>
                <div class="flex items-center gap-3 shrink-0">
                    <button type="button" onclick="hideAddProductForm()" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none">
                        Cancel
                    </button>
                    <button type="submit" id="productFormSubmitBtn" form="addProductForm" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <i class="ti ti-device-floppy text-lg"></i> Save Product
                    </button>
                </div>
            </div>
        </div>

        <form id="addProductForm" class="space-y-5">
            <input type="hidden" name="productId" id="productId" value="" />
            <input type="hidden" name="removeProductImage" id="removeProductImage" value="0" />
            <!-- Section 1: Product Information -->
            <div class="overflow-visible rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="flex items-center gap-3 border-b border-slate-100 bg-slate-50/60 px-5 py-3">
                    <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-sky-50 text-sky-600 ring-1 ring-sky-100">
                        <i class="ti ti-info-circle text-lg"></i>
                    </span>
                    <div>
                        <h3 class="m-0 text-sm font-bold text-slate-800">Product Information</h3>
                        <p class="m-0 text-xs font-medium text-slate-400">Basic details about the product</p>
                    </div>
                </div>
                <div class="px-5 py-4 space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="md:col-span-2">
                            <label for="productName" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Product Name <span class="text-rose-500">*</span></label>
                            <input type="text" id="productName" autocomplete="off" name="productName" class="input-theme" placeholder="e.g. HBsAg Rapid Test Kit" required />
                        </div>
                        <div>
                            <label for="productCategory" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Category <span class="text-rose-500">*</span></label>
                            <select name="productCategory" id="productCategory" class="input-theme select2" required>
                                <option value="">---Select----</option>
                            </select>
                        </div>
                        <div>
                            <label for="productStage" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Product Stage <span class="text-rose-500">*</span></label>
                            <select name="productStage" id="productStage" class="input-theme select2" required>
                                <option value="FG" selected>Finished Good (FG)</option>
                                <option value="SFG">Semi-Finished (SFG)</option>
                                <option value="UFG">Unfinished (UFG)</option>
                                <option value="RM">Raw Material (RM)</option>
                                <option value="PM">Packing Material (PM)</option>
                            </select>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <label for="productCode" class="mb-1.5 block text-[13px] font-semibold text-slate-700">CAT No <span class="text-slate-400 font-normal">(Auto-generated or enter manually)</span></label>
                            <input type="text" id="productCode" autocomplete="off" name="productCode" maxlength="100" class="input-theme font-mono text-slate-700" placeholder="e.g. BGX/RAP/FG/2026/000101" />
                        </div>
                        <div>
                            <label for="hsnCode" class="mb-1.5 block text-[13px] font-semibold text-slate-700">HSN Code <span class="text-slate-400 font-normal">(Optional)</span></label>
                            <input type="text" id="hsnCode" autocomplete="off" name="hsnCode" maxlength="20" class="input-theme" placeholder="e.g. 38220090" />
                        </div>
                        <div>
                            <label for="reorderLevel" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Reorder Level <span class="text-slate-400 font-normal">(Optional)</span></label>
                            <input type="number" step="0.001" min="0" id="reorderLevel" autocomplete="off" name="reorderLevel" class="input-theme" placeholder="e.g. 10.500" />
                        </div>
                        <div>
                            <label for="gstRate" class="mb-1.5 block text-[13px] font-semibold text-slate-700">GST Rate (%) <span class="text-slate-400 font-normal">(Optional)</span></label>
                            <input type="number" step="0.01" min="0" max="100" id="gstRate" autocomplete="off" name="gstRate" class="input-theme" placeholder="e.g. 18" />
                        </div>
                    </div>
                    <div>
                        <label for="productDescription" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Description</label>
                        <textarea id="productDescription" autocomplete="off" name="productDescription" class="input-theme min-h-[90px]" placeholder="Enter a brief product description..."></textarea>
                    </div>
                </div>
            </div>

            <!-- Section 2: Product variants and unified stock -->
            <div class="overflow-visible rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="flex items-center justify-between gap-3 border-b border-slate-100 bg-slate-50/60 px-5 py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-violet-50 text-violet-600 ring-1 ring-violet-100">
                            <i class="ti ti-packages text-lg"></i>
                        </span>
                        <div>
                            <h3 class="m-0 text-sm font-bold text-slate-800">Product Variants (Pack Sizes)</h3>
                            <p class="m-0 text-xs font-medium text-slate-400">Define pack labels and the product-level stock balance</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 items-center justify-center gap-2 !rounded-xl bg-emerald-50 px-4 text-sm font-bold text-emerald-700 shadow-sm ring-1 ring-emerald-900/10 hover:bg-emerald-100 transition-colors" id="addPackSizeBtn">
                        <i class="ti ti-plus text-base"></i> Add Pack Size
                    </button>
                </div>
                <div class="px-5 py-4">
                    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg">
                        <div>
                            <label for="unreservedStock" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Unreserved Stock <span class="text-rose-400">*</span></label>
                            <input type="number" step="0.00000001" min="0" id="unreservedStock" name="unreservedStock" class="input-theme" value="0" required />
                        </div>
                        <div>
                            <label for="reservedStock" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Reserved Stock</label>
                            <input type="number" step="0.00000001" min="0" id="reservedStock" name="reservedStock" class="input-theme cursor-not-allowed bg-slate-100 text-slate-600" value="0" readonly aria-readonly="true" />
                        </div>
                    </div>
                    <!-- Table header row -->
                    <div class="grid grid-cols-12 gap-3 mb-2 px-1">
                        <div class="col-span-5">
                            <span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Pack Size <span class="text-rose-400">*</span></span>
                        </div>
                        <div class="col-span-6 min-w-[120px]">
                            <span class="text-[10px] font-black uppercase tracking-widest text-slate-400">Unit <span class="text-rose-400">*</span></span>
                        </div>
                        <div class="col-span-1"></div>
                    </div>
                    <div id="packSizeWrapper" class="space-y-2"></div>
                </div>
            </div>

            <!-- Section 4: Media Assets -->
            <div class="overflow-visible rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="flex items-center gap-3 border-b border-slate-100 bg-slate-50/60 px-5 py-3">
                    <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100">
                        <i class="ti ti-photo text-lg"></i>
                    </span>
                    <div>
                        <h3 class="m-0 text-sm font-bold text-slate-800">Media Assets</h3>
                        <p class="m-0 text-xs font-medium text-slate-400">Upload product images</p>
                    </div>
                </div>
                <div class="px-5 py-4 space-y-3">
                    <label class="block text-[13px] font-semibold text-slate-700">Product Images <span class="text-slate-400 font-normal">(Optional)</span></label>
                    <input type="file" id="productImage" name="productImage" accept="image/png,image/jpeg,image/webp" class="hidden" />
                    <div id="productImageDropZone" class="border-2 border-dashed border-slate-200 rounded-2xl bg-white p-6 flex flex-col items-center justify-center text-center transition-colors hover:border-emerald-400 hover:bg-emerald-50/20 cursor-pointer">
                        <div class="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 mb-2 pointer-events-none">
                            <i class="ti ti-upload text-lg"></i>
                        </div>
                        <p class="text-sm font-bold text-slate-800 m-0 pointer-events-none">Drag and drop images here</p>
                        <p class="text-xs text-slate-400 mt-1 mb-3 pointer-events-none">PNG, JPG or WEBP up to 5MB each</p>
                        <button type="button" id="browseProductImageBtn" class="inline-flex h-9 items-center justify-center rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 hover:border-slate-300">
                            Browse Files
                        </button>
                    </div>
                    <div id="productImagePreviewContainer" class="mt-4 hidden items-center gap-4 p-3 rounded-2xl border border-slate-200 bg-slate-50/80">
                        <div class="relative w-32 h-32 md:w-36 md:h-36 shrink-0 rounded-2xl border border-slate-200 overflow-hidden shadow-md bg-white">
                            <img id="productImagePreview" src="" class="w-full h-full object-cover" alt="Product image preview" />
                            <button type="button" id="removeProductImageBtn" class="absolute top-2 right-2 flex h-7 w-7 items-center justify-center rounded-full bg-rose-600 text-white shadow-md hover:bg-rose-700 transition-colors focus:outline-none" style="z-index: 999 !important;" title="Remove image">
                                <i class="ti ti-x text-sm"></i>
                            </button>
                        </div>
                        <div class="space-y-1 overflow-hidden">
                            <p class="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Uploaded Image Preview</p>
                            <span id="productImageName" class="text-xs font-bold text-slate-700 block truncate max-w-[240px]"></span>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Legacy Edit Product Form Container (Commented out - now reusing addProductForm container)
    <div id="editProductFormContainer" style="display: none;" class="w-full max-w-[60rem] mr-auto mt-4">
        ...
    </div>
    -->

    <div class="modal fade animate__animated fadeIn" id="addStocksModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Stock</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Add new inventory stock entry</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addStocksForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Material Category</label>
                                <select name="materilCategoryList" id="materilCategoryList"
                                    class="select2 input-theme materilCategoryList" data-allow-clear="true" required>
                                    <option value="">----Select Option----</option>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Product</label>
                                <select name="productsList" class="select2 input-theme" id="productsList"
                                    data-allow-clear="true" required>
                                    <option value="">----Select Option----</option>
                                </select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800"
                                    for="prodQuantity">Quantity</label>
                                <input type="number" step="any" min="0" name="prodQuantity" id="prodQuantity"
                                    class="input-theme" placeholder="Enter Quantity" required />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800"
                                    for="prodQuantityUnit">Quantity Unit</label>
                                <select name="prodQuantityUnit" id="prodQuantityUnit" class="input-theme select2"
                                    required></select>
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="coaNo">COA No</label>
                                <input type="text" name="coaNo" id="coaNo" class="input-theme"
                                    placeholder="Enter COA" />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="lotBatchNo">LOT/Batch
                                    No</label>
                                <input type="text" name="lotBatchNo" id="lotBatchNo" class="input-theme"
                                    placeholder="Enter LOT" />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="mfgDate">Mfg Date (If
                                    any)</label>
                                <input type="date" name="mfgDate" id="mfgDate" class="input-theme" />
                            </div>
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="expiaryDate">Expiry
                                    Date (If any)</label>
                                <input type="date" name="expiryDate" id="expiryDate" class="input-theme" />
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-28 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-32 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="viewStocksModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-file-certificate text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Item Detail</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">COA, batch and quantity details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="viewStocksDiv">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="procurementProductsModal" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i class="ti ti-shopping-cart-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="procurementModalTitle">Low Stock Procurement</h5>
                            <p class="m-0 text-sm font-medium text-slate-500" id="procurementModalSubtitle">Review and initiate bulk orders for critical reagent stocks.</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <input type="hidden" id="procurementProductsSource" value="">
                <div class="modal-body bg-slate-50/70 !px-4 !py-4" style="max-height: fit-content; overflow-y: visible;">
                    <!-- Top Fields: Reporting Officer, Date of Report, COA No -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label class="mb-1 block text-sm font-semibold text-slate-800">Reporting Officer</label>
                            <input type="text" id="procurementReportingOfficer" class="input-theme !bg-slate-50" placeholder="Reporting Officer" value="<?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>" readonly />
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-semibold text-slate-800">Date of Report</label>
                            <input type="text" id="procurementReportDate" class="input-theme !bg-slate-50" value="<?php echo date('d-m-Y'); ?>" readonly />
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-semibold text-slate-800">COA No.</label>
                            <input type="text" id="procurementCoaNo" class="input-theme" placeholder="COA No. (e.g. COA-BX-2023-0092)" />
                        </div>
                    </div>
                    <div class="overflow-x-auto overflow-y-auto rounded-xl border border-slate-200 bg-white mb-3" style="max-height: 280px;">
                        <table class="w-full border-collapse text-left">
                            <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                                <tr>
                                    <th class="px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Material Category</th>
                                    <th class="px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Product Name</th>
                                    <th class="px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Current Stock</th>
                                    <th class="px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Min Level</th>
                                    <th class="px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Restock Qty Required</th>
                                    <th class="w-20 px-4 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                        <label class="flex items-center justify-center gap-1 cursor-pointer m-0">
                                            <input type="checkbox" id="procurementSelectAll" class="rounded border-slate-300 accent-emerald-600" checked />
                                            <span>Select</span>
                                        </label>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="procurementProductsTableBody" class="divide-y divide-slate-100 bg-white"></tbody>
                        </table>
                    </div>
                </div>
                <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                    <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none" data-bs-dismiss="modal">Cancel</button>
                    <?php if (canDoThis('operations_admin_production_plan_add')) { ?>
                        <button type="button" id="procurementProductsProduceBtn" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-indigo-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-indigo-900/10 transition-colors hover:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/30" style="background-color: #4338ca !important; border: 1px solid #3730a3 !important; color: #ffffff !important;"><i class="ti ti-building-factory-2 text-lg"></i> Produce</button>
                    <?php } ?>
                    <button type="button" id="procurementProductsSubmitBtn" class="inline-flex h-10 min-w-40 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i class="ti ti-shopping-cart-plus text-lg"></i> Procure Products</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editStocksModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Stocks</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update quantity, unit and batch details
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editStocksForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="stocksExportForm" class="stocks-export-form">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Sr No" checked />
                                        <span class="text-sm font-medium text-slate-700">Sr No</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product" checked />
                                        <span class="text-sm font-medium text-slate-700">Product</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Category" checked />
                                        <span class="text-sm font-medium text-slate-700">Category</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Available Qty" checked />
                                        <span class="text-sm font-medium text-slate-700">Available Qty</span>
                                    </label>                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="L/S R.L" checked />
                                        <span class="text-sm font-medium text-slate-700">L/S R.L</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Status</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="modalExportSubmitBtn" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- Phase F: Import Stock Modal -->
<div class="modal fade animate__animated fadeIn" id="importStockModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-start justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-start gap-3">
                    <span class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                        <i class="ti ti-file-upload text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Import Inventory Stock</h5>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-500">Upload a <strong>CSV file</strong> with columns: <code>product_name, quantity, unit</code>. First row must be a header row.</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-xl"></i>
                </button>
            </div>
            <form id="importStockForm" enctype="multipart/form-data">
                <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                    <!-- Drop zone -->
                    <div id="importDropZone"
                        class="flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-indigo-200 bg-white p-10 text-center transition-colors hover:border-indigo-400 hover:bg-indigo-50/40 cursor-pointer">
                        <i class="ti ti-cloud-upload text-4xl text-indigo-300"></i>
                        <div class="text-sm font-semibold text-slate-700">Click to upload or drag & drop</div>
                        <div class="text-xs text-slate-400">Supported: <strong>.csv</strong> — max 5 MB</div>
                        <input type="file" id="importStockFile" name="importStockFile" accept=".csv" class="hidden" />
                    </div>
                    <!-- Preview -->
                    <div id="importPreviewWrap" class="mt-4 hidden">
                        <div class="mb-2 flex items-center gap-2">
                            <i class="ti ti-table text-indigo-500 text-base"></i>
                            <span class="text-xs font-bold text-slate-600" id="importPreviewTitle">Preview (first 5 rows)</span>
                        </div>
                        <div id="importPreviewTable" class="overflow-x-auto rounded-xl border border-slate-200 bg-white"></div>
                        <div class="mt-3 text-xs text-slate-400" id="importRowCount"></div>
                    </div>
                    <!-- Result -->
                    <div id="importResultMsg" class="mt-4 hidden"></div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-4 !py-3 flex items-center justify-between gap-3">
                    <button type="button" id="downloadImportTemplate"
                        class="inline-flex h-10 items-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors">
                        <i class="ti ti-file-download text-base"></i> Download Template
                    </button>
                    <div class="flex items-center gap-3">
                        <button type="button" data-bs-dismiss="modal"
                            class="inline-flex h-10 items-center gap-2 !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50">Cancel</button>
                        <button type="submit" id="importStockSubmitBtn"
                            class="inline-flex h-10 items-center gap-2 !rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-indigo-700/20 transition-colors hover:bg-indigo-700 disabled:opacity-50" disabled>
                            <i class="ti ti-upload text-base"></i> Import
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    function showAddProductForm() {
        $('#stockListContainer').hide();
        $('#stockFormContainer').fadeIn();
        loadProductCategoryList();
    }

    function hideAddProductForm() {
        $('#stockFormContainer').hide();
        $('#stockListContainer').fadeIn();
        $('#productId').val('');
        $('#productFormTitle').text('Add New Product');
        $('#productFormSubtitle').text('Create a new product record with variants and category mapping');
        $('#productFormBreadcrumb').text('Add New Product');
        $('#productFormSubmitBtn').html('<i class="ti ti-device-floppy text-lg"></i> Save Product');
        $('#addProductForm')[0].reset();
        $('#unreservedStock').val('0');
        $('#reservedStock').val('0');
        $('#removeProductImage').val('0');
        if ($('#productCategory').hasClass('select2-hidden-accessible')) {
            $('#productCategory').val('').trigger('change');
        }
        $('#packSizeWrapper').empty();
        addPackSizeRow('#packSizeWrapper', null);
        clearProductImagePreview();
    }

    function clearProductImagePreview(resetRemoval = true) {
        $('#productImage').val('');
        $('#productImagePreview').off('error.productImage').attr('src', '');
        $('#productImageName').text('');
        $('#productImagePreviewContainer').removeClass('flex').addClass('hidden');
        if (resetRemoval) $('#removeProductImage').val('0');
    }

    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'desc';
    let selectedCategsType = [];
    let selectedSubcategsType = [];
    let selectedStatusesType = ['0', '1', '2'];
    let qtyUnitOptions = [];
    let allCategoriesData = [];
    let allSubcategoriesData = [];

    function loadStocksTable(page = 1) {
        currentPage = page;
        const search = $('#searchData').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#employeesTableBody').html('<tr><td colspan="8" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadStocks: 'loadStocks',
                page: page,
                per_page: perPage,
                search: search,
                selectedCategs: selectedCategsType,
                selectedSubcategs: selectedSubcategsType,
                selectedStatuses: selectedStatusesType,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#employeesTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const visibleRows = Number(response.visibleRows || 0);
                const totalRows = Number(response.totalRows || 0);
                const shownThrough = Math.min(currentPage * parseInt(perPage), totalRows);
                $('#stockPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
                if (response.stats) {
                    $('#widgetAvailable').text(response.stats.availablePct || '0%');
                    $('#widgetAvailableCount').text(response.stats.availableCount || 0);
                    $('#widgetLowStock').text(response.stats.lowStock || 0);
                    $('#widgetOutOfStock').text(response.stats.outOfStock || 0);
                }
            },
            error: function () {
                $('#employeesTableBody').html('<tr><td colspan="8" class="text-center text-danger py-4">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#stockPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    function loadProductsCategories() {
        $('#materilCategoryList').html('');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialTypeOption: 'loadMaterialTypeOption'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (item) {
                    html += `<option value="${item.key}">${item.value}</option>`;
                });
                $('#materilCategoryList').html(html);
            }
        });
    }
    
    function loadProductsCategoriesList() {
        $('#productCategoryListOptions').html('');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadInventoryFilterOptions: 'loadInventoryFilterOptions'
            },
            dataType: 'json',
            success: function (response) {
                allCategoriesData = response.categories || [];
                allSubcategoriesData = response.subcategories || [];

                selectedCategsType = allCategoriesData.map(i => String(i.key));
                selectedSubcategsType = allSubcategoriesData.map(i => String(i.key));

                let html = `
                <div class="p-2" style="width: 520px;">
                    <div class="row g-0">
                        <div class="col-6 pe-3 border-end border-slate-100">
                            <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">Top-Level Category</div>
                            <div class="flex flex-col gap-1" id="topLevelGroupContainer">
                                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-2.5 py-1.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 border border-transparent dynamic-group-item active-group" data-group-id="all">
                                    <input type="radio" name="top_group_radio" class="group-radio rounded-full border-slate-300 accent-emerald-600" value="all" checked /> 
                                    <span>All Categories</span>
                                </label>
                `;
                allCategoriesData.forEach(function (itemCateg) {
                    html += `
                                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-2.5 py-1.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 border border-transparent dynamic-group-item" data-group-id="${itemCateg.key}">
                                    <input type="radio" name="top_group_radio" class="group-radio rounded-full border-slate-300 accent-emerald-600" value="${itemCateg.key}" /> 
                                    <span>${itemCateg.value}</span>
                                </label>
                    `;
                });
                html += `
                            </div>
                        </div>
                        <div class="col-6 ps-3">
                            <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-1 flex justify-between items-center">
                                <span>Subcategories</span>
                                <button type="button" id="toggleAllSubcategories" class="text-[10px] text-emerald-700 hover:underline font-bold">Deselect All</button>
                            </div>
                            <div class="flex flex-col gap-1.5" id="subCategoryCheckboxContainer" style="max-height: 180px; overflow-y: auto;">
                            </div>
                        </div>
                    </div>
                </div>
                `;
                $('#productCategoryListOptions').html(html);
                renderSubcategoriesForGroup('all');
                loadStocksTable(1);
            }
        });
    }

    function renderSubcategoriesForGroup(groupId) {
        let subHtml = '';
        let filteredSub = allSubcategoriesData;
        if (groupId !== 'all') {
            filteredSub = allSubcategoriesData.filter(item => String(item.category_id) === String(groupId));
        }

        if (filteredSub.length === 0) {
            subHtml = '<div class="text-xs text-slate-400 text-center py-2">No subcategories</div>';
            $('#subCategoryCheckboxContainer').html(subHtml);
            $('#toggleAllSubcategories').hide();
            return;
        }

        $('#toggleAllSubcategories').show();
        let allChecked = true;

        filteredSub.forEach(function (itemSub) {
            const isChecked = selectedSubcategsType.includes(String(itemSub.key));
            if (!isChecked) {
                allChecked = false;
            }
            subHtml += `
                <label class="flex cursor-pointer items-center gap-2 rounded-xl px-2.5 py-1.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                    <input type="checkbox" class="subcateg-filter rounded border-slate-300 accent-emerald-600" value="${itemSub.key}" ${isChecked ? 'checked' : ''} /> 
                    <span>${itemSub.value}</span>
                </label>
            `;
        });

        $('#subCategoryCheckboxContainer').html(subHtml);
        $('#toggleAllSubcategories').text(allChecked ? 'Deselect All' : 'Select All');
    }
    function buildPackUnitOptions(selected = '') {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            const isSelected = String(selected) === String(unit.id) ? 'selected' : '';
            optionsHtml += `<option value="${unit.id}" ${isSelected}>${unit.label}</option>`;
        });
        return optionsHtml;
    }

    function addPackSizeRow(wrapper, dropdownParent, packSize = '', packUnit = '') {
        const rowHtml = `<div class="grid grid-cols-12 gap-3 items-center product-pack-size-row mb-2">
            <div class="col-span-5">
                <input type="text" name="packSize[]" value="${packSize}" class="input-theme" placeholder="Pack Size (e.g. 50 Tests)" required />
            </div>
            <div class="col-span-6 min-w-[120px]">
                <select name="packSizeUnit[]" class="input-theme select2 min-w-[120px]" style="min-width: 120px;" required>${buildPackUnitOptions(packUnit)}</select>
            </div>
            <div class="col-span-1 flex items-center justify-center">
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none removePackSizeBtn" title="Remove Pack Size"><i class="ti ti-trash text-base"></i></button>
            </div>
        </div>`;
        const $row = $(rowHtml);
        $(wrapper).append($row);
        if (dropdownParent) {
            $row.find('.select2').select2({ dropdownParent: $(dropdownParent) });
        } else {
            if (window.initGlobalSelect2) {
                window.initGlobalSelect2($row.find('.select2'));
            } else {
                $row.find('.select2').select2();
            }
        }
    }

    function loadProductCategoryList(selectedCategoryId = null) {
        $.ajax({
            url: 'ajax.php', method: 'POST', dataType: 'json',
            data: { getProductCategoryList: 'getProductCategoryList' },
            success: function (response) {
                if ($('#productCategory').hasClass('select2-hidden-accessible')) {
                    $('#productCategory').select2('destroy');
                }
                let optionsHtml = '<option value="">---Select----</option>';
                response.forEach(unit => {
                    const isSelected = (selectedCategoryId && String(unit.id) === String(selectedCategoryId)) ? 'selected' : '';
                    optionsHtml += `<option value="${unit.id}" ${isSelected}>${unit.name}</option>`;
                });
                $('#productCategory').html(optionsHtml);
                if (selectedCategoryId) {
                    $('#productCategory').val(selectedCategoryId);
                }
                if (window.initGlobalSelect2) {
                    window.initGlobalSelect2($('#productCategory'));
                } else {
                    $('#productCategory').select2();
                }
            },
            error: function (xhr, status, error) { console.error("Failed to load categories:", error); }
        });
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (item) {
                    html += `<option value="${item.id}">${item.label}</option>`;
                });
                $('#prodQuantityUnit').html(html).trigger('change');
                if ($('#packSizeWrapper .product-pack-size-row').length === 0) {
                    addPackSizeRow('#packSizeWrapper', null);
                }
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }
    $(document).ready(function () {
        loadProductsCategoriesList();
        loadStandardUnit();
        loadProductCategoryList();

        $(document).on('click', '#productImageDropZone, #browseProductImageBtn', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $('#productImage').trigger('click');
        });

        $(document).on('dragover dragenter', '#productImageDropZone', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('border-emerald-500 bg-emerald-50/40');
        });

        $(document).on('dragleave dragend drop', '#productImageDropZone', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('border-emerald-500 bg-emerald-50/40');
        });

        $(document).on('drop', '#productImageDropZone', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const dt = e.originalEvent.dataTransfer;
            if (dt && dt.files && dt.files.length > 0) {
                const fileInput = document.getElementById('productImage');
                fileInput.files = dt.files;
                $('#productImage').trigger('change');
            }
        });

        $('#productImage').on('change', function () {
            const file = this.files[0];
            if (file) {
                const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
                if (!allowedTypes.includes(file.type)) {
                    toastr.error('Product image must be a JPG, PNG, or WebP file.');
                    clearProductImagePreview();
                    return;
                }
                if (file.size > 5 * 1024 * 1024) {
                    toastr.error('Product image must not exceed 5 MB.');
                    clearProductImagePreview();
                    return;
                }
                $('#removeProductImage').val('0');
                const reader = new FileReader();
                reader.onload = function (e) {
                    $('#productImagePreview').attr('src', e.target.result);
                    $('#productImageName').text(file.name);
                    $('#productImagePreviewContainer').removeClass('hidden').addClass('flex');
                };
                reader.readAsDataURL(file);
            } else {
                clearProductImagePreview();
            }
        });

        $(document).on('click', '#removeProductImageBtn', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const isEditing = Number($('#productId').val() || 0) > 0;
            clearProductImagePreview(false);
            $('#removeProductImage').val(isEditing ? '1' : '0');
        });


        $('#addStocksModal select.select2').select2({
            placeholder: '--Select--',
            dropdownParent: $('#addStocksModal')
        });

        $('#addStocksModal').on('hidden.bs.modal', function () {
            $('#addStocksForm')[0].reset();
            $('#materilCategoryList').val('').trigger('change');
            $('#productsList').html('<option value="">----Select Option----</option>').trigger('change');
            $('#prodQuantityUnit').val('').trigger('change');
        });
        loadStocksTable();    
        $('#searchData').on('input', function () {
            loadStocksTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadStocksTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            const val = $(this).val();
            $('#perPageText').text(val);
            $('#perPageSelect').val(val).trigger('change');
        });

        $(document).on('click', '.stocks-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#stocksPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });


        $('#addStocksForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addStocksForm');
            const formData = new FormData(form);
            formData.append('addStocksDirect', 'addStocksDirect');

            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#addStocksModal').modal('hide');
                        $('#addStocksForm')[0].reset();
                        loadStocksTable();
                        toastr.success(response.message);
                    } else if (response.status === 'error') {
                        toastr.error(response.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });

        $('#addProductModal').on('hidden.bs.modal', function () {
            $('#addProductForm')[0].reset();
            $('#packSizeWrapper').empty();

            addPackSizeRow('#packSizeWrapper', null);
        });



        $(document).on('click', '#addPackSizeBtn', function () {
            addPackSizeRow('#packSizeWrapper', null);
        });

        $(document).on('click', '.removePackSizeBtn', function () {
            if ($('#packSizeWrapper .product-pack-size-row').length <= 1 && $(this).closest('#packSizeWrapper').length) {
                toastr.warning('At least one pack size is required.');
                return;
            }
            $(this).closest('.product-pack-size-row').remove();
        });

        $(document).on('click', '#addPackSizeEditBtn', function () {
            const rowHtml = `<div class="grid grid-cols-12 gap-3 items-center product-pack-size-row mb-2">
                <div class="col-span-5">
                    <input type="text" name="packSizeEdit[]" class="input-theme" placeholder="Pack Size" />
                </div>
                <div class="col-span-6 min-w-[150px]">
                    <select name="packSizeUnitEdit[]" class="input-theme select2 min-w-[150px]" style="min-width: 150px;">${buildPackUnitOptions()}</select>
                </div>
                <div class="col-span-1 flex items-center justify-center">
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none removePackSizeBtn" title="Remove Pack Size"><i class="ti ti-trash text-base"></i></button>
                </div>
            </div>`;
            const $row = $(rowHtml);
            $('#packSizeEditWrapper').append($row);
            if (window.initGlobalSelect2) {
                window.initGlobalSelect2($row.find('.select2'));
            } else {
                $row.find('.select2').select2();
            }
        });

        function updateProductCatPreview() {
            const categoryId = $('#productCategory').val();
            const stage = $('#productStage').val() || 'FG';
            const productId = $('#productId').val();
            if (productId) return;
            if (!categoryId) {
                $('#productCode').val('');
                return;
            }
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    generateProductCatPreview: 'generateProductCatPreview',
                    categoryId: categoryId,
                    stage: stage
                },
                dataType: 'json',
                success: function (res) {
                    if (res && res.status === 'success' && res.cat_code) {
                        $('#productCode').val(res.cat_code);
                    }
                }
            });
        }
        $(document).on('change', '#productCategory, #productStage', updateProductCatPreview);

        $('#addProductForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addProductForm');
            const formData = new FormData(form);
            const productId = $('#productId').val();

            if (productId) {
                formData.append('updateProduct', 'updateProduct');
                formData.append('editProductId', productId);
            } else {
                formData.append('addProduct', 'addProduct');
            }

            const $submitBtn = $(this).find('button[type="submit"]');
            const originalText = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
                success: function (response) {
                    let res = response;
                    if (typeof response === 'string') {
                        try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response from server.'); return; }
                    }
                    if (res.status === 'success') {
                        hideAddProductForm();
                        loadProductsCategoriesList();
                        loadStocksTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') { toastr.error(res.message); }
                    else { toastr.error('Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); },
                complete: function () {
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });
        $(document).on('click', '#deselectAllColumnsBtn', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('.column-filter').prop('checked', false);
                $(this).text('Select All');
            } else {
                $('.column-filter').prop('checked', true);
                $(this).text('Deselect All');
            }
        });

        $(document).on('change', '.column-filter', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('#deselectAllColumnsBtn').text('Deselect All');
            } else {
                $('#deselectAllColumnsBtn').text('Select All');
            }
        });
    });

    $(document).on('click', '#addStocksModalBtn', function () {
        $('#addStocksModal').modal('show');
        loadProductsCategories();
        loadStandardUnit();
    });

    $(document).on('click', '.stockViewModalBtn', function () {
        let product_id = $(this).data('product-id');
        let categ_id = $(this).data('categ-id');
        if (product_id && categ_id) {
            $('#viewStocksDiv').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchStocksViewRecord: 'fetchStocksViewRecord',
                    product_id: product_id,
                    categ_id: categ_id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewStocksModel').modal('show');
                        $('#viewStocksDiv').find('.modal-body').html(res.data);
                    } else {
                        toastr.error(res.message || 'Unexpected error');
                    }
                },
                error: function (xhr) {
                    toastr.error('Server error occurred.');
                    console.error("Response:", xhr.responseText);
                }
            });
        }
    });

    let modalCategoriesList = [];

    function openProcurementProductsModal(source, productId = '') {
        const selectedProductId = String(productId || '').trim();
        const isSingleProduct = selectedProductId !== '';
        $('#procurementProductsSource').val(source || '');
        $('#procurementCoaNo').val('');
        
        if (source === 'OUT_OF_STOCK') {
            $('#procurementModalTitle').text('Out of Stock Procurement');
            $('#procurementModalSubtitle').text('Review and initiate bulk orders for critical reagent stocks.');
        } else {
            $('#procurementModalTitle').text('Low Stock Procurement');
            $('#procurementModalSubtitle').text('Review and initiate bulk orders for critical reagent stocks.');
        }

        $('#procurementProductsTableBody').html('<tr><td colspan="6" class="px-4 py-8 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        $('#procurementProductsModal').modal('show');
        
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadProcurementCandidateProducts: 'loadProcurementCandidateProducts',
                procurementSource: source || '',
                productId: selectedProductId,
                singleProduct: isSingleProduct ? '1' : '0'
            },
            success: function (response) {
                if (response.status === 'success') {
                    modalCategoriesList = response.allCategories || [];
                    const items = response.items || [];
                    let rowsHtml = '';
                    
                    if (items.length === 0) {
                        $('#procurementProductsTableBody').html('<tr><td colspan="6" class="px-4 py-6 text-center text-sm font-medium text-slate-500">No products available.</td></tr>');
                        return;
                    }

                    items.forEach(function (item, index) {
                        rowsHtml += buildProcurementRowHtml(item, index);
                    });
                    
                    $('#procurementProductsTableBody').html(rowsHtml);
                    // Prefilled rows are selectable and bulk-selected by default
                    const enabledCheckboxes = $('#procurementProductsTableBody .procurement-product-checkbox:not(:disabled)');
                    if (enabledCheckboxes.length > 0) {
                        $('#procurementSelectAll').prop('disabled', false).prop('checked', true);
                    } else {
                        $('#procurementSelectAll').prop('disabled', true).prop('checked', false);
                    }
                } else {
                    $('#procurementProductsTableBody').html('<tr><td colspan="6" class="px-4 py-6 text-center text-sm font-medium text-rose-600">' + (response.message || 'No products available.') + '</td></tr>');
                }
            },
            error: function () {
                $('#procurementProductsTableBody').html('<tr><td colspan="6" class="px-4 py-6 text-center text-sm font-medium text-rose-600">Server error occurred.</td></tr>');
            }
        });
    }

    function buildProcurementRowHtml(item = null, index = 0) {
        const isPrefilled = item !== null;
        const selectedCatId = isPrefilled ? item.category_id : '';
        const selectedProdId = isPrefilled ? item.product_id : '';
        const hasPending = isPrefilled && !!item.has_pending_request;
        const isChecked = isPrefilled ? 'checked' : '';
        const isDisabled = isPrefilled ? 'disabled' : '';
        const hoverMessage = hasPending
            ? 'This product has an existing procurement request. You can re-select it to update or re-trigger.'
            : '';
        const hoverAttr = hasPending ? `title="${hoverMessage}"` : '';
        const rowStyle = hasPending ? 'style="background-color: #fffbeb;"' : '';
        const canProduce = isPrefilled ? (item.can_produce !== false && item.can_produce !== 0) : true;
        const produceHint = isPrefilled && !canProduce && item.produce_reason
            ? `<p class="mt-1 mb-0 text-xs font-medium text-amber-700"><i class="ti ti-info-circle"></i> ${item.produce_reason}</p>`
            : '';

        const currentStockText = isPrefilled 
            ? `${parseFloat(item.current_stock || 0).toLocaleString('en-IN', {minimumFractionDigits: 0, maximumFractionDigits: 3})} ${item.quantity_unit_name || ''}`
            : '-';
        const reorderLevelText = isPrefilled 
            ? `${parseFloat(item.reorder_level || 0).toLocaleString('en-IN', {minimumFractionDigits: 0, maximumFractionDigits: 3})} ${item.quantity_unit_name || ''}`
            : '-';
        const suggestedQtyText = isPrefilled 
            ? `${parseFloat(item.suggested_qty || 1).toLocaleString('en-IN', {minimumFractionDigits: 0, maximumFractionDigits: 3})} ${item.quantity_unit_name || ''}`
            : '-';

        let catOptions = '<option value="">--Select Category--</option>';
        modalCategoriesList.forEach(function (cat) {
            const selected = String(cat.id) === String(selectedCatId) ? 'selected' : '';
            catOptions += `<option value="${cat.id}" ${selected}>${cat.name}</option>`;
        });

        return `
            <tr class="procurement-item-row" ${hoverAttr} ${rowStyle}>
                <td class="px-4 py-2" ${hoverAttr}>
                    <select class="input-theme select2-procure procure-row-category" style="width: 100%;" ${isDisabled}>
                        ${catOptions}
                    </select>
                </td>
                <td class="px-4 py-2" ${hoverAttr}>
                    <select class="input-theme select2-procure procure-row-product" style="width: 100%;" ${isDisabled}>
                        <option value="">--Select Product--</option>
                        ${isPrefilled ? `<option value="${selectedProdId}" selected>${item.product_name}</option>` : ''}
                    </select>
                    ${produceHint}
                </td>
                <td class="px-4 py-2 whitespace-nowrap text-sm font-semibold text-slate-700" ${hoverAttr}>
                    ${currentStockText}
                </td>
                <td class="px-4 py-2 whitespace-nowrap text-sm font-medium text-slate-600" ${hoverAttr}>
                    ${reorderLevelText}
                </td>
                <td class="px-4 py-2 whitespace-nowrap text-sm font-bold text-emerald-700" ${hoverAttr}>
                    ${suggestedQtyText}
                </td>
                <td class="px-4 py-2 text-center align-middle" ${hoverAttr}>
                    <div class="d-flex align-items-center justify-content-center gap-2 m-0" ${hoverAttr}>
                        <input type="checkbox" class="procurement-product-checkbox rounded border-slate-300 accent-emerald-600" value="${selectedProdId}" data-can-produce="${canProduce ? '1' : '0'}" ${isChecked} ${hoverAttr} />
                        ${hasPending 
                            ? `<span class="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-1 rounded-md border border-amber-200" ${hoverAttr}><i class="ti ti-clock-pause"></i> Pending</span>`
                            : `<button type="button" class="btn btn-sm btn-icon btn-label-danger removeProcureRowBtn"><span class="ti ti-trash"></span></button>`
                        }
                    </div>
                </td>
            </tr>
        `;
    }

    function loadRowProducts(categoryId, selectElement, selectProductId = '') {
        if (!categoryId) {
            selectElement.html('<option value="">--Select Product--</option>').trigger('change');
            return;
        }
        
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                materialTypeId: categoryId,
                loadProductsByMaterialType: 'loadProductsByMaterialType'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">--Select Product--</option>';
                response.forEach(function (product) {
                    const isSelected = String(product.key) === String(selectProductId) ? 'selected' : '';
                    html += `<option value="${product.key}" ${isSelected}>${product.value}</option>`;
                });
                selectElement.html(html).trigger('change');
            }
        });
    }

    $(document).on('change', '.procure-row-category', function () {
        const row = $(this).closest('tr');
        const categoryId = $(this).val();
        const productSelect = row.find('.procure-row-product');
        loadRowProducts(categoryId, productSelect);
    });

    $(document).on('change', '.procure-row-product', function () {
        const row = $(this).closest('tr');
        const productId = $(this).val();
        row.find('.procurement-product-checkbox').val(productId);
    });

    $(document).on('click', '.removeProcureRowBtn', function () {
        $(this).closest('tr').remove();
    });

    $(document).on('change', '#procurementSelectAll', function () {
        const checked = $(this).is(':checked');
        $('.procurement-product-checkbox:not(:disabled)').prop('checked', checked);
    });

    $(document).on('click', '.procureSingleProductBtn', function (e) {
        e.preventDefault();
        openProcurementProductsModal($(this).attr('data-procurement-source') || '', $(this).attr('data-product-id') || '');
    });
    $(document).on('click', '.inventory-procurement-btn', function (e) {
        e.preventDefault();
        openProcurementProductsModal($(this).data('procurement-source') || '');
    });

    $('#widgetLowStockCard').on('click', function () {
        openProcurementProductsModal('LOW_STOCK');
    });

    function showStockStatus(status) {
        selectedStatusesType = [String(status)];
        $('.stock-status-filter').prop('checked', false);
        $('.stock-status-filter[value="' + status + '"]').prop('checked', true);
        loadStocksTable(1);
    }

    $('#widgetAvailableCard').on('click', function () {
        showStockStatus(1);
    }).on('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            showStockStatus(1);
        }
    });

    $('#widgetOutOfStockCard').on('click', function () {
        openProcurementProductsModal('OUT_OF_STOCK');
    });

    $(document).on('click', '#procurementProductsSubmitBtn', function () {
        const $button = $(this);
        const selectedProducts = [];
        $('.procurement-product-checkbox:checked').each(function () {
            if ($(this).val()) {
                selectedProducts.push($(this).val());
            }
        });
        if (selectedProducts.length === 0) {
            toastr.error('Please select at least one product.');
            return;
        }
        const source = $('#procurementProductsSource').val();
        $button.prop('disabled', true);
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                createInventoryProcurementRequests: '1',
                productIds: selectedProducts,
                procurementSource: source,
                coaNumber: $('#procurementCoaNo').val().trim(),
                reportingOfficer: $('#procurementReportingOfficer').val().trim()
            },
            success: function (response) {
                if (response.status === 'success') {
                    toastr.success(response.message);
                    window.location.href = 'index.php?page=purchase-management';
                } else {
                    toastr.error(response.message || 'Unable to create procurement requests.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            },
            complete: function () {
                $button.prop('disabled', false);
            }
        });
    });

    $(document).on('click', '#procurementProductsProduceBtn', function () {
        const $button = $(this);
        const selectedProducts = [];

        $('.procurement-product-checkbox:checked').each(function () {
            const productId = String($(this).val() || '').trim();
            if (!productId) {
                return;
            }
            selectedProducts.push(productId);
        });

        if (selectedProducts.length === 0) {
            toastr.error('Please select at least one product before sending to Production.');
            return;
        }

        $button.prop('disabled', true);
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                createInventoryProductionPlans: '1',
                productIds: selectedProducts,
                procurementSource: $('#procurementProductsSource').val()
            },
            success: function (response) {
                if (response.status === 'success') {
                    toastr.success(response.message || 'Production Plan request created.');
                    window.location.href = 'index.php?page=production-plan';
                } else {
                    toastr.error(response.message || 'Unable to create Production Plan requests.');
                }
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.message
                    ? xhr.responseJSON.message
                    : 'Server error occurred while creating Production Plan requests.';
                toastr.error(message);
            },
            complete: function () {
                $button.prop('disabled', false);
            }
        });
    });

    $(document).on('change', '#materilCategoryList', function () {
        const materialTypeId = $(this).val();
        if (materialTypeId) {
            $('#productsList').html('');
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    materialTypeId: materialTypeId,
                    loadProductsByMaterialType: 'loadProductsByMaterialType'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (product) {
                        html += `<option value="${product.key}">${product.value}</option>`;
                    });
                    $('#productsList').html(html).trigger('change');
                }
            });
        } else {
            $('#productsList').html('<option value="">----Select Option----</option>').trigger('change');
        }
    });


    $(document).on('click', '.productEditModal', function () {
        let id = $(this).data('id');
        if (id) {
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { fetchProductRecord: 'fetchProductRecord', id: id },
                success: function (response) {
                    let res;
                    try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response from server.'); return; }
                    if (res.status === 'success' && res.product) {
                        const prod = res.product;
                        
                        // Set headers & mode
                        $('#productId').val(prod.id);
                        $('#productFormTitle').text('Edit Product');
                        $('#productFormSubtitle').text('Update product details, variants and category mapping');
                        $('#productFormBreadcrumb').text('Edit Product');
                        $('#productFormSubmitBtn').html('<i class="ti ti-device-floppy text-lg"></i> Update Product');

                        // Pre-populate product info
                        $('#productName').val(prod.product_name || '');
                        $('#productCode').val(prod.product_code || '');
                        $('#hsnCode').val(prod.hsn_code || '');
                        $('#productDescription').val(prod.description || '');
                        $('#gstRate').val(prod.gst_rate || '');
                        $('#reorderLevel').val(prod.reorder_level || '');
                        $('#unreservedStock').val(prod.unreserved_stock ?? 0);
                        $('#reservedStock').val(prod.reserved_stock ?? 0);

                        // Load categories and select current
                        loadProductCategoryList(prod.category_id);

                        // Image preview
                        clearProductImagePreview();
                        if (prod.product_image) {
                            const imgPath = '../' + prod.product_image;
                            $('#productImagePreview')
                                .off('error.productImage')
                                .one('error.productImage', function () {
                                    $('#productImagePreviewContainer').removeClass('flex').addClass('hidden');
                                    toastr.warning('The saved product image file is not available on this server.');
                                })
                                .attr('src', imgPath);
                            $('#productImageName').text(prod.product_image.split('/').pop());
                            $('#productImagePreviewContainer').removeClass('hidden').addClass('flex');
                        }

                        // Populate pack sizes
                        $('#packSizeWrapper').empty();
                        if (prod.pack_sizes && prod.pack_sizes.length > 0) {
                            prod.pack_sizes.forEach(function (ps) {
                                addPackSizeRow('#packSizeWrapper', null, ps.pack_size, ps.pack_unit_id, ps.qty);
                            });
                        } else {
                            addPackSizeRow('#packSizeWrapper', null);
                        }

                        // Show form, hide list
                        $('#stockListContainer').hide();
                        $('#stockFormContainer').fadeIn();
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });
    $(document).on('click', '.editStockModalBtn', function () {
        let product_id = $(this).data('product-id');
        let categ_id = $(this).data('categ-id');
        if (product_id && categ_id) {
            $('#editStocksForm').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchStocksEditRecord: 'fetchStocksEditRecord',
                    product_id: product_id,
                    categ_id: categ_id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editStocksModel').modal('show');
                        $('#editStocksForm').find('.modal-body').html(res.data);
                        $('#editStocksForm select.select2').select2({ dropdownParent: $('#editStocksModel') });

                    } else {
                        toastr.error(res.message || 'Unexpected error');
                    }
                },
                error: function (xhr) {
                    toastr.error('Server error occurred.');
                    console.error("Response:", xhr.responseText);
                }
            });
        }
    });

    $(document).on('click', '.removeProductEntryBtn', function () {
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid product ID provided.',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'inline-flex h-10 items-center justify-center rounded-full bg-red-600 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500/30'
                },
                buttonsStyling: false
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'me-3 inline-flex h-10 items-center justify-center rounded-full bg-emerald-700 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex h-10 items-center justify-center rounded-full border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-400/20'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteStocksSingleRecord: 'deleteStocksSingleRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex h-10 items-center justify-center rounded-full bg-emerald-700 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                },
                                buttonsStyling: false
                            });
                            buttonClicked.closest('.product-entry-row').remove();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex h-10 items-center justify-center rounded-full bg-red-600 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500/30'
                                },
                                buttonsStyling: false
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex h-10 items-center justify-center rounded-full bg-red-600 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500/30'
                                },
                                buttonsStyling: false
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'inline-flex h-10 items-center justify-center rounded-full bg-red-600 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500/30'
                            },
                            buttonsStyling: false
                        });
                    }
                });
            }
        });
    });

    $("#editStocksForm").on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editStocksForm');
        const formData = new FormData(form);
        formData.append('updateStocksDirectRecord', 'updateStocksDirectRecord');

        const $submitBtn = $(this).find('button[type="submit"]');
        const originalText = $submitBtn.html();
        $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editStocksModel').modal('hide');
                    $('#editStocksForm').find('modal-body').html();
                    loadStocksTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            },
            complete: function () {
                $submitBtn.prop('disabled', false).html(originalText);
            }
        });
    });

    $(document).on('click', 'th.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'asc') ? 'desc' : 'asc';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'asc';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder);
        loadStocksTable(1);
    });

    $(document).on('change', '[name="top_group_radio"]', function () {
        const selectedGroupId = $(this).val();
        $('.dynamic-group-item').removeClass('active-group bg-slate-50 border-slate-200').addClass('border-transparent');
        $(this).closest('.dynamic-group-item').removeClass('border-transparent').addClass('active-group bg-slate-50 border-slate-200');
        
        if (selectedGroupId === 'all') {
            selectedCategsType = allCategoriesData.map(i => String(i.key));
            selectedSubcategsType = allSubcategoriesData.map(i => String(i.key));
        } else {
            selectedCategsType = [String(selectedGroupId)];
            const filteredSub = allSubcategoriesData.filter(item => String(item.category_id) === String(selectedGroupId));
            selectedSubcategsType = filteredSub.map(i => String(i.key));
        }
        
        renderSubcategoriesForGroup(selectedGroupId);
        loadStocksTable(1);
    });

    $(document).on('change', '.subcateg-filter', function () {
        const id = String($(this).val());
        const checked = $(this).is(':checked');
        if (checked) {
            if (!selectedSubcategsType.includes(id)) {
                selectedSubcategsType.push(id);
            }
        } else {
            selectedSubcategsType = selectedSubcategsType.filter(val => val !== id);
        }
        
        const activeGroup = $('input[name="top_group_radio"]:checked').val() || 'all';
        let filteredSub = allSubcategoriesData;
        if (activeGroup !== 'all') {
            filteredSub = allSubcategoriesData.filter(item => String(item.category_id) === String(activeGroup));
        }
        const allChecked = filteredSub.length > 0 && filteredSub.every(item => selectedSubcategsType.includes(String(item.key)));
        $('#toggleAllSubcategories').text(allChecked ? 'Deselect All' : 'Select All');

        loadStocksTable(1);
    });

    $(document).on('click', '#toggleAllSubcategories', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const activeGroup = $('input[name="top_group_radio"]:checked').val() || 'all';
        let filteredSub = allSubcategoriesData;
        if (activeGroup !== 'all') {
            filteredSub = allSubcategoriesData.filter(item => String(item.category_id) === String(activeGroup));
        }

        const anyUnchecked = filteredSub.some(item => !selectedSubcategsType.includes(String(item.key)));

        filteredSub.forEach(item => {
            const id = String(item.key);
            if (anyUnchecked) {
                if (!selectedSubcategsType.includes(id)) {
                    selectedSubcategsType.push(id);
                }
            } else {
                selectedSubcategsType = selectedSubcategsType.filter(val => val !== id);
            }
        });

        renderSubcategoriesForGroup(activeGroup);
        loadStocksTable(1);
    });

    $(document).on('change', '.stock-status-filter', function () {
        const val = $(this).val();
        const checked = $(this).is(':checked');

        if (val === 'all') {
            $('.stock-status-filter').prop('checked', checked);
        } else {
            const allCheckbox = $('.stock-status-filter[value="all"]');
            const otherCheckboxes = $('.stock-status-filter:not([value="all"])');
            const allOthersChecked = otherCheckboxes.length === $('.stock-status-filter:not([value="all"]):checked').length;
            allCheckbox.prop('checked', allOthersChecked);
        }

        selectedStatusesType = [];
        $('.stock-status-filter:checked').each(function () {
            const v = $(this).val();
            if (v !== 'all') {
                selectedStatusesType.push(String(v));
            }
        });

        loadStocksTable(1);
    });
    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $('#stocksExportForm').on('submit', function (e) {
        e.preventDefault();
        const exportType = $('#exportTypeSelect').val();
        if (!exportType) {
            toastr.error('Please select an export format.');
            return;
        }
        page = 1;
        currentPage = page;
        const search = $('#searchData').val().trim();
        const perPage = $('#perPageSelect').val();
        const form = document.getElementById('stocksExportForm');
        const formData = new FormData(form);
        formData.append('exportStocks', 'exportStocks');
        formData.append('search', search);
        formData.append('perPage', perPage);
        formData.append('page', page);
        formData.append('selectedCategs', JSON.stringify(selectedCategsType));
        formData.append('selectedSubcategs', JSON.stringify(selectedSubcategsType));
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');

        $.ajax({
            url: 'exportajax.php', // Change to your handler script
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.export-type-item', function () {
        const val = $(this).data('val');
        $('#exportTypeText').text($(this).text());
        $('#exportTypeSelect').val(val);
    });

    $(document).on('click', '.per-page-item', function () {
        const val = $(this).data('val');
        $('#perPageText').text($(this).text());
        $('#footerPerPageSelect').val(val);
        $('#perPageSelect').val(val).trigger('change');
    });

    $(document).on('click', '.export-type-item', function () {
        const val = $(this).data('val');
        $('#exportTypeText').text($(this).text());
        $('#exportType').val(val);
    });

    // ─── Phase F: Import CSV ──────────────────────────────────────────────────
    let importCsvRows = [];
    let importHeaders = [];

    // Click on drop zone opens file picker
    $('#importDropZone').on('click', function () {
        $('#importStockFile').trigger('click');
    });

    $('#importStockFile').on('click', function (e) {
        e.stopPropagation();
    });

    // Drag & drop
    $('#importDropZone').on('dragover', function (e) {
        e.preventDefault();
        $(this).addClass('border-indigo-500 bg-indigo-50/70');
    }).on('dragleave', function () {
        $(this).removeClass('border-indigo-500 bg-indigo-50/70');
    }).on('drop', function (e) {
        e.preventDefault();
        $(this).removeClass('border-indigo-500 bg-indigo-50/70');
        const file = e.originalEvent.dataTransfer.files[0];
        if (file) { handleImportFile(file); }
    });

    $('#importStockFile').on('change', function () {
        const file = this.files[0];
        if (file) { handleImportFile(file); }
    });

    function handleImportFile(file) {
        if (!file.name.endsWith('.csv')) { toastr.warning('Please upload a .csv file.'); return; }
        if (file.size > 5 * 1024 * 1024) { toastr.warning('File is too large (max 5 MB).'); return; }

        const reader = new FileReader();
        reader.onload = function (e) {
            const text = e.target.result;
            const lines = text.trim().split('\n').map(l => l.split(',').map(c => c.trim().replace(/^"|"$/g, '')));
            if (lines.length < 2) { toastr.warning('CSV appears empty or has no data rows.'); return; }

            importHeaders = lines[0];
            importCsvRows = lines.slice(1).filter(r => r.some(c => c !== ''));

            // Build preview table
            const previewRows = importCsvRows.slice(0, 5);
            let tableHtml = '<table class="w-full text-xs text-slate-600"><thead class="border-b border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide"><tr>';
            importHeaders.forEach(h => { tableHtml += `<th class="px-3 py-2 font-semibold text-left">${h}</th>`; });
            tableHtml += '</tr></thead><tbody class="divide-y divide-slate-100">';
            previewRows.forEach(row => {
                tableHtml += '<tr>';
                row.forEach(cell => { tableHtml += `<td class="px-3 py-2">${cell}</td>`; });
                tableHtml += '</tr>';
            });
            tableHtml += '</tbody></table>';

            $('#importPreviewTable').html(tableHtml);
            $('#importPreviewTitle').text(`Preview (first ${previewRows.length} of ${importCsvRows.length} rows)`);
            $('#importRowCount').text(`Total data rows detected: ${importCsvRows.length}`);
            $('#importPreviewWrap').removeClass('hidden');
            $('#importStockSubmitBtn').prop('disabled', false);
        };
        reader.readAsText(file);
    }

    // Download template CSV
    $('#downloadImportTemplate').on('click', function () {
        const csvContent = 'product_name,quantity,unit\nExample Product,100,pcs\n';
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'stock_import_template.csv';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    // Import form submit
    $('#importStockForm').on('submit', function (e) {
        e.preventDefault();
        const file = $('#importStockFile')[0].files[0];
        if (!file) { toastr.warning('No file selected.'); return; }

        const $btn = $('#importStockSubmitBtn');
        $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Importing...');
        $('#importResultMsg').addClass('hidden');

        const formData = new FormData();
        formData.append('importStockFile', file);
        formData.append('importStock', 'importStock');

        $.ajax({
            url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (res) {
                try { res = JSON.parse(res); } catch(e) { toastr.error('Invalid response.'); return; }
                if (res.status === 'success') {
                    toastr.success(res.message);
                    loadStocksTable();
                    $('#importResultMsg').html(
                        `<div class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800"><i class="ti ti-circle-check mr-2"></i>${res.message}</div>`
                    ).removeClass('hidden');
                    $('#importStockFile').val('');
                    $('#importPreviewWrap').addClass('hidden');
                    $btn.prop('disabled', true);
                } else {
                    toastr.error(res.message || 'Import failed.');
                    $('#importResultMsg').html(
                        `<div class="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700"><i class="ti ti-alert-octagon mr-2"></i>${res.message}</div>`
                    ).removeClass('hidden');
                }
            },
            error: function () { toastr.error('Server error.'); },
            complete: function () {
                $btn.prop('disabled', false).html('<i class="ti ti-upload text-base"></i> Import');
            }
        });
    });

    // Reset import modal on hide
    $('#importStockModal').on('hidden.bs.modal', function () {
        $('#importStockFile').val('');
        $('#importPreviewWrap').addClass('hidden');
        $('#importResultMsg').addClass('hidden');
        $('#importStockSubmitBtn').prop('disabled', true);
        importCsvRows = []; importHeaders = [];
    });

</script>
<?php endSection(); ?>
