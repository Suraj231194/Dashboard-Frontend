<style>
  .swal2-container {
    z-index: 2000 !important;
  }
  .profile-root-wrapper {
    font-family: 'Plus Jakarta Sans', 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: #1e293b;
  }
  
  /* Top Action Buttons */
  .profile-btn-cancel {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    color: #475569;
    border-radius: 9999px;
    padding: 7px 18px;
    font-size: 13px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    transition: all 0.15s ease;
    cursor: pointer;
  }
  .profile-btn-cancel:hover {
    background-color: #f8fafc;
    color: #0f172a;
    border-color: #94a3b8;
  }
  .profile-btn-save {
    background-color: #cb7725;
    border: 1px solid #cb7725;
    color: #ffffff;
    border-radius: 9999px;
    padding: 7px 22px;
    font-size: 13px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    transition: all 0.15s ease;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(203, 119, 37, 0.25);
  }
  .profile-btn-save:hover {
    background-color: #b8691e;
    border-color: #b8691e;
    color: #ffffff;
  }

  /* Hero Header Card */
  .profile-hero-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    overflow: hidden;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
  }
  .profile-hero-top {
    height: 130px;
    background-color: #064e3b;
    width: 100%;
  }
  .profile-hero-body {
    padding: 0 24px 18px 24px;
  }
  .profile-hero-identity {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 16px;
  }
  @media (min-width: 640px) {
    .profile-hero-identity {
      flex-direction: row;
      align-items: flex-end;
      gap: 20px;
    }
  }
  .profile-avatar-wrapper {
    position: relative;
    flex-shrink: 0;
    margin-top: -45px;
  }
  .profile-avatar-img {
    width: 90px;
    height: 90px;
    border-radius: 16px;
    border: 4px solid #ffffff;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    object-fit: cover;
    object-position: center top;
    background: #ffffff;
    display: block;
  }
  .profile-avatar-wrapper {
    cursor: pointer;
  }
  .profile-avatar-wrapper:hover .profile-avatar-img {
    filter: brightness(0.95);
    border-color: #a7f3d0;
  }
  .profile-camera-btn {
    position: absolute;
    bottom: -2px;
    right: -2px;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #ffffff;
    border: 1.5px solid #cbd5e1;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #1e293b;
    font-size: 13px;
    cursor: pointer;
    transition: all 0.15s ease;
    z-index: 10;
  }
  .profile-camera-btn:hover {
    background: #064e3b;
    border-color: #064e3b;
    color: #ffffff;
    transform: scale(1.1);
  }
  .profile-hero-meta {
    flex-grow: 1;
    text-align: center;
    min-width: 0;
  }
  @media (min-width: 640px) {
    .profile-hero-meta {
      text-align: left;
      padding-bottom: 2px;
    }
  }
  .profile-hero-name-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-bottom: 4px;
  }
  @media (min-width: 640px) {
    .profile-hero-name-row {
      justify-content: flex-start;
    }
  }
  .profile-hero-name {
    font-size: 20px;
    font-weight: 800;
    color: #0f172a;
    margin: 0;
    letter-spacing: -0.01em;
  }
  .profile-status-pill {
    background: #f1f5f9;
    color: #64748b;
    font-size: 11px;
    font-weight: 600;
    padding: 2px 10px;
    border-radius: 9999px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
  }
  .profile-status-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #10b981;
  }
  .profile-hero-details-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    gap: 16px;
    font-size: 12px;
    color: #64748b;
    font-weight: 500;
  }
  @media (min-width: 640px) {
    .profile-hero-details-row {
      justify-content: flex-start;
    }
  }
  .profile-hero-details-row i {
    color: #cb7725;
    font-size: 13px;
    margin-right: 4px;
  }
  .profile-hero-nav-tabs {
    border-top: 1px solid #f1f5f9;
    margin-top: 16px;
    padding-top: 14px;
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .profile-tab-pill {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 9999px;
    padding: 5px 16px;
    font-size: 11.5px;
    font-weight: 600;
    color: #475569;
    text-decoration: none;
    transition: all 0.15s ease;
  }
  .profile-tab-pill:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
    color: #064e3b;
  }

  /* Two Column Layout */
  .profile-main-layout {
    display: flex;
    flex-direction: column;
    gap: 24px;
  }
  @media (min-width: 992px) {
    .profile-main-layout {
      flex-direction: row;
      align-items: flex-start;
    }
    .profile-left-col {
      flex: 1 1 67%;
      min-width: 0;
    }
    .profile-right-col {
      width: 33%;
      min-width: 320px;
      flex-shrink: 0;
    }
  }

  /* Form Cards */
  .profile-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 24px 26px;
    margin-bottom: 24px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);
  }
  .profile-card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #f1f5f9;
    padding-bottom: 16px;
    margin-bottom: 20px;
  }
  .profile-card-header-left {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .profile-icon-badge {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: #ecfdf5;
    color: #059669;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.15rem;
    flex-shrink: 0;
  }
  .profile-card-title {
    font-size: 15px;
    font-weight: 700;
    color: #0f172a;
    margin: 0;
    line-height: 1.25;
  }
  .profile-card-subtitle {
    font-size: 12px;
    color: #94a3b8;
    font-weight: 500;
    margin: 0;
  }
  .profile-badge-editable {
    background: #ffedd5;
    color: #ea580c;
    border-radius: 9999px;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 12px;
    border: none;
  }

  /* Form Grid & Inputs */
  .profile-form-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 16px 20px;
  }
  @media (min-width: 640px) {
    .profile-form-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .profile-grid-full {
      grid-column: span 2;
    }
  }
  .profile-label {
    display: block;
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    color: #64748b;
    letter-spacing: 0.04em;
    margin-bottom: 6px;
  }
  .profile-input-field {
    width: 100%;
    height: 42px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    background: #ffffff;
    padding: 0 14px;
    font-size: 13.5px;
    font-weight: 500;
    color: #1e293b;
    outline: none;
    transition: all 0.15s ease;
  }
  .profile-input-field:focus {
    border-color: #059669;
    box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.1);
  }
  .profile-input-disabled {
    background-color: #f8fafc !important;
    color: #64748b !important;
    cursor: not-allowed;
  }
  .profile-textarea-field {
    width: 100%;
    height: 76px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    background: #ffffff;
    padding: 10px 14px;
    font-size: 13.5px;
    font-weight: 500;
    color: #1e293b;
    outline: none;
    transition: all 0.15s ease;
    resize: vertical;
  }
  .profile-textarea-field:focus {
    border-color: #059669;
    box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.1);
  }
  .profile-input-with-icon {
    position: relative;
  }
  .profile-input-icon-left {
    position: absolute;
    top: 50%;
    left: 14px;
    transform: translateY(-50%);
    color: #94a3b8;
    pointer-events: none;
    font-size: 15px;
  }
  .profile-input-icon-right {
    position: absolute;
    top: 50%;
    right: 14px;
    transform: translateY(-50%);
    color: #94a3b8;
    pointer-events: none;
    font-size: 15px;
  }
  .profile-input-padded-left {
    padding-left: 38px !important;
  }
  .profile-input-padded-right {
    padding-right: 38px !important;
  }

  /* Right Column: Employment Record (Dark Green) */
  .profile-employment-card {
    background-color: #074e36;
    color: #ffffff;
    border-radius: 16px;
    padding: 22px 24px;
    margin-bottom: 24px;
    box-shadow: 0 4px 12px rgba(7, 78, 54, 0.12);
  }
  .profile-emp-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    padding-bottom: 14px;
    margin-bottom: 16px;
  }
  .profile-emp-header-left {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .profile-emp-icon-box {
    width: 34px;
    height: 34px;
    border-radius: 9px;
    background: rgba(255, 255, 255, 0.12);
    color: #a7f3d0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    flex-shrink: 0;
  }
  .profile-emp-title {
    font-size: 13.5px;
    font-weight: 700;
    color: #ffffff;
    margin: 0;
    line-height: 1.2;
  }
  .profile-emp-subtitle {
    font-size: 10.5px;
    color: rgba(255, 255, 255, 0.65);
    font-weight: 500;
    margin: 0;
  }
  .profile-emp-badge {
    background: rgba(255, 255, 255, 0.12);
    color: #a7f3d0;
    font-size: 10px;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 9999px;
  }
  .profile-emp-list {
    display: flex;
    flex-direction: column;
    gap: 11px;
  }
  .profile-emp-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12px;
    padding: 1px 0;
  }
  .profile-emp-label {
    font-size: 10px;
    font-weight: 700;
    color: rgba(167, 243, 208, 0.8);
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }
  .profile-emp-value {
    font-size: 12.5px;
    font-weight: 700;
    color: #ffffff;
    text-align: right;
  }

  /* Right Column: Account Shortcuts (White) */
  .profile-shortcuts-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 22px 24px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);
  }
  .profile-shortcuts-title {
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
    margin: 0 0 2px 0;
  }
  .profile-shortcuts-subtitle {
    font-size: 11.5px;
    color: #94a3b8;
    margin: 0 0 16px 0;
  }
  .profile-shortcuts-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .profile-shortcut-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 10px;
    border-radius: 12px;
    text-decoration: none;
    color: #1e293b;
    transition: all 0.15s ease;
  }
  .profile-shortcut-item:hover {
    background-color: #f8fafc;
  }
  .profile-shortcut-left {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .profile-shortcut-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: #fff7ed;
    color: #ea580c;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    flex-shrink: 0;
  }
  .profile-shortcut-name {
    font-size: 12.5px;
    font-weight: 700;
    color: #1e293b;
    margin: 0;
    line-height: 1.2;
  }
  .profile-shortcut-desc {
    font-size: 10.5px;
    color: #94a3b8;
    margin: 0;
  }
  .profile-shortcut-chevron {
    color: #cbd5e1;
    font-size: 14px;
  }
</style>

<div class="container-xxl flex-grow-1 container-p-y font-sans profile-root-wrapper">
  <!-- Hidden Photo Input -->
  <input type="file" id="profilePhotoFileInput" accept="image/png,image/jpeg,image/jpg,image/webp" class="d-none" style="display:none;">

  <!-- Form Container -->
  <form id="userProfileForm" autocomplete="off">
    <input type="hidden" name="csrf_token" id="profileCsrfToken" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">

    <!-- Top Breadcrumbs & Action Buttons Row -->
    <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-3 mb-4">
      <div>
        <div class="text-xs text-slate-400 mb-1 font-semibold">
          <span>Dashboard</span> <span class="mx-1">&gt;</span> <span>My Account</span> <span class="mx-1">&gt;</span> <span class="text-slate-600">Profile</span>
        </div>
        <h1 class="h3 fw-bold text-slate-900 m-0" style="letter-spacing: -0.02em;">My Account Profile</h1>
      </div>

      <div class="d-flex align-items-center gap-2.5">
        <button type="button" id="btnCancelProfile" class="profile-btn-cancel">
          <i class="ti ti-rotate"></i>
          <span>Cancel</span>
        </button>
        <button type="button" id="btnSaveProfile" class="profile-btn-save">
          <i class="ti ti-check" id="saveBtnIcon"></i>
          <span class="spinner-border spinner-border-sm d-none" id="saveBtnSpinner" role="status" aria-hidden="true"></span>
          <span id="saveBtnText">Save Changes</span>
        </button>
      </div>
    </div>

    <!-- Hero Header Card -->
    <div class="profile-hero-card">
      <!-- Dark Green Banner -->
      <div class="profile-hero-top"></div>

      <!-- Identity Content -->
      <div class="profile-hero-body">
        <div class="profile-hero-identity">
          <!-- Avatar -->
          <div class="profile-avatar-wrapper" id="profileAvatarWrapper" title="Click to change profile photo">
            <img id="profilePhotoImg" src="<?= asset('assets/img/avatars/14.png') ?>" alt="Profile photo" class="profile-avatar-img">
            <button type="button" id="btnUploadPhoto" class="profile-camera-btn" title="Change profile photo">
              <i class="ti ti-camera" id="cameraIcon"></i>
              <span class="spinner-border spinner-border-sm d-none" id="cameraSpinner" role="status" style="width: 13px; height: 13px; border-width: 2px;"></span>
            </button>
          </div>

          <!-- Meta -->
          <div class="profile-hero-meta">
            <div class="profile-hero-name-row">
              <h2 class="profile-hero-name data-user-username">-</h2>
              <span class="profile-status-pill">
                <span class="profile-status-dot"></span>
                <span class="data-status-badge">Active Employee</span>
              </span>
            </div>

            <div class="profile-hero-details-row">
              <span>
                <i class="ti ti-briefcase"></i>
                <span class="data-emp-designation">-</span>
              </span>
              <span>
                <i class="ti ti-id"></i>
                <span class="data-emp-code">-</span>
              </span>
              <span>
                <i class="ti ti-building"></i>
                <span class="data-company-name-hero">Biogenix Inc Pvt Ltd.</span>
              </span>
            </div>
          </div>
        </div>

        <!-- Section Navigation Pills -->
        <div class="profile-hero-nav-tabs">
          <a href="#sectionBasicDetails" class="profile-tab-pill">Basic &amp; Contact</a>
          <a href="#sectionPersonalIdentity" class="profile-tab-pill">Personal &amp; Identity</a>
          <a href="#sectionFamilyAddress" class="profile-tab-pill">Family &amp; Address</a>
          <a href="#sectionEmploymentRecord" class="profile-tab-pill">Employment</a>
        </div>
      </div>
    </div>

    <?php if (canDoThis('bom_approval')): ?>
      <!-- BOM Approval Pending Widget (Inbound-style Alert on top of tables) -->
      <div id="bomApprovalPendingWidget" class="mb-4 relative cursor-pointer animate__animated fadeIn" style="display: none;">
        <div class="overflow-hidden rounded-2xl border border-amber-300 bg-gradient-to-r from-amber-50 via-white to-orange-50/60 p-4 shadow-sm transition-all hover:shadow-md hover:border-amber-400" style="display: flex; align-items: center; justify-content: space-between;">
          <div style="display: flex; align-items: center; gap: 1rem;">
            <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.25rem; height: 3.25rem; background-color: #fef3c7; border-radius: 1rem; border: 1px solid #fde68a;">
              <i class="ti ti-clipboard-check" style="font-size: 1.6rem; color: #d97706;"></i>
              <span id="bomPendingBadgeDot" style="position: absolute; top: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; min-width: 1.35rem; height: 1.35rem; padding: 0 4px; background-color: #ea580c; color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
            </div>
            <div style="display: flex; flex-direction: column;">
              <div style="display: flex; align-items: center; gap: 0.5rem;">
                <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: #1e293b; margin: 0;">BOM Approval(s) Pending!</h3>
                <span id="bomPendingCountPill" class="badge bg-label-warning text-xs font-bold">0 Pending Review</span>
              </div>
              <p class="font-medium text-slate-500 mt-1 mb-0" style="font-size: 0.875rem;">
                New product package variation BOMs require verification and management approval before release. Click to review.
              </p>
            </div>
          </div>
          <div class="d-none d-sm-flex align-items-center gap-2 text-amber-700 font-semibold text-xs bg-white/90 px-3.5 py-2 rounded-xl border border-amber-200 shadow-sm">
            <span>Review Requests</span>
            <i class="ti ti-external-link" style="font-size: 1.1rem;"></i>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <!-- Main Two-Column Layout -->
    <div class="profile-main-layout">

      <!-- LEFT COLUMN: Editable Form Cards -->
      <div class="profile-left-col">

        <!-- 1. Basic & Contact Details -->
        <section id="sectionBasicDetails" class="profile-card">
          <div class="profile-card-header">
            <div class="profile-card-header-left">
              <div class="profile-icon-badge">
                <i class="ti ti-user"></i>
              </div>
              <div>
                <h3 class="profile-card-title">Basic &amp; Contact Details</h3>
                <p class="profile-card-subtitle">Primary identification and communication channels.</p>
              </div>
            </div>
            <span class="profile-badge-editable">Editable</span>
          </div>

          <div class="profile-form-grid">
            <div>
              <label class="profile-label" for="profileSalutationSelect">Salutation</label>
              <select id="profileSalutationSelect" name="solutation" class="profile-input-field">
                <option value="">Select Salutation</option>
                <option value="Mr.">Mr.</option>
                <option value="Ms.">Ms.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Dr.">Dr.</option>
                <option value="Prof.">Prof.</option>
              </select>
            </div>

            <div>
              <label class="profile-label" for="profilePhoneInput">Primary Phone *</label>
              <div class="profile-input-with-icon">
                <i class="ti ti-phone profile-input-icon-left"></i>
                <input id="profilePhoneInput" name="profile_phone" type="tel" class="profile-input-field profile-input-padded-left" placeholder="Phone number" required>
              </div>
            </div>

            <div>
              <label class="profile-label" for="profileFirstNameInput">First Name *</label>
              <input id="profileFirstNameInput" name="first_name" type="text" class="profile-input-field" placeholder="First Name" required>
            </div>

            <div>
              <label class="profile-label" for="profileLastNameInput">Last Name</label>
              <input id="profileLastNameInput" name="last_name" type="text" class="profile-input-field" placeholder="Last Name">
            </div>

            <div class="profile-grid-full">
              <label class="profile-label" for="profileNameInput">Display Full Name *</label>
              <input id="profileNameInput" name="profile_name" type="text" class="profile-input-field" placeholder="Display Full Name" required>
            </div>

            <div class="profile-grid-full">
              <label class="profile-label" for="profileEmailInput">Corporate Email Address</label>
              <div class="profile-input-with-icon">
                <i class="ti ti-mail profile-input-icon-left"></i>
                <input id="profileEmailInput" name="profile_email" type="email" class="profile-input-field profile-input-disabled profile-input-padded-left profile-input-padded-right" placeholder="Email address" disabled>
                <i class="ti ti-lock profile-input-icon-right" title="Corporate SSO protected"></i>
              </div>
              <span class="d-block mt-1 text-xs text-slate-400 fst-italic" style="font-size: 11px;">
                Corporate email is managed via single sign-on (SSO) and cannot be modified directly.
              </span>
            </div>
          </div>
        </section>

        <!-- 2. Personal & Identity -->
        <section id="sectionPersonalIdentity" class="profile-card">
          <div class="profile-card-header">
            <div class="profile-card-header-left">
              <div class="profile-icon-badge">
                <i class="ti ti-id-badge-2"></i>
              </div>
              <div>
                <h3 class="profile-card-title">Personal &amp; Identity</h3>
                <p class="profile-card-subtitle">Demographic information and statutory personal identifiers.</p>
              </div>
            </div>
            <span class="profile-badge-editable">Editable</span>
          </div>

          <div class="profile-form-grid">
            <div>
              <label class="profile-label">Employee Code</label>
              <div class="profile-input-with-icon">
                <input type="text" class="profile-input-field profile-input-disabled data-emp-code-input profile-input-padded-right" value="-" disabled>
                <i class="ti ti-lock profile-input-icon-right"></i>
              </div>
            </div>

            <div>
              <label class="profile-label" for="profileDobInput">Date of Birth</label>
              <div class="profile-input-with-icon">
                <input id="profileDobInput" name="dob" type="date" class="profile-input-field profile-input-padded-right">
                <i class="ti ti-calendar profile-input-icon-right"></i>
              </div>
            </div>

            <div>
              <label class="profile-label" for="profileGenderSelect">Gender</label>
              <select id="profileGenderSelect" name="gender" class="profile-input-field">
                <option value="">Select Gender</option>
                <?php foreach (Constant::EMPLOYEES['GENDER'] as $genderId => $genderLabel): ?>
                  <option value="<?= (int) $genderId ?>"><?= htmlspecialchars($genderLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div>
              <label class="profile-label" for="profileBloodGroupSelect">Blood Group</label>
              <select id="profileBloodGroupSelect" name="blood_group" class="profile-input-field">
                <option value="">Select Blood Group</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select>
            </div>
          </div>
        </section>

        <!-- 3. Family & Address -->
        <section id="sectionFamilyAddress" class="profile-card">
          <div class="profile-card-header">
            <div class="profile-card-header-left">
              <div class="profile-icon-badge">
                <i class="ti ti-home"></i>
              </div>
              <div>
                <h3 class="profile-card-title">Family &amp; Address</h3>
                <p class="profile-card-subtitle">Family background, emergency contacts, and residential addresses.</p>
              </div>
            </div>
            <span class="profile-badge-editable">Editable</span>
          </div>

          <div class="profile-form-grid">
            <div>
              <label class="profile-label" for="profileFathersNameInput">Father's Name</label>
              <input id="profileFathersNameInput" name="fathers_name" type="text" class="profile-input-field" placeholder="Father's Name">
            </div>

            <div>
              <label class="profile-label" for="profileMaritalStatusSelect">Marital Status</label>
              <select id="profileMaritalStatusSelect" name="marital_status" class="profile-input-field">
                <option value="">Select Status</option>
                <?php foreach (Constant::EMPLOYEES['MARITAL_STATUS'] as $maritalStatusId => $maritalStatusLabel): ?>
                  <option value="<?= (int) $maritalStatusId ?>"><?= htmlspecialchars($maritalStatusLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div>
              <label class="profile-label" for="profileHusbandNameInput">Spouse / Husband's Name</label>
              <input id="profileHusbandNameInput" name="husband_name" type="text" class="profile-input-field" placeholder="Spouse full name">
            </div>

            <div>
              <label class="profile-label" for="profileAltContactInput">Alternate Contact 1</label>
              <input id="profileAltContactInput" name="alt_contact_no" type="tel" class="profile-input-field" placeholder="Alternate phone 1">
            </div>

            <div class="profile-grid-full">
              <label class="profile-label" for="profileAltContact2Input">Alternate Contact 2</label>
              <input id="profileAltContact2Input" name="alt_contact_no2" type="tel" class="profile-input-field" placeholder="Alternate phone 2 / Emergency contact">
            </div>

            <div class="profile-grid-full">
              <label class="profile-label" for="profileLocalAddressInput">Local / Current Residential Address</label>
              <textarea id="profileLocalAddressInput" name="local_address" class="profile-textarea-field" placeholder="Enter residential address"></textarea>
            </div>

            <div class="profile-grid-full">
              <div class="d-flex align-items-center justify-content-between mb-1.5">
                <label class="profile-label m-0" for="profilePermanentAddressInput">Permanent Address</label>
                <label class="d-inline-flex align-items-center gap-1.5 text-xs font-bold cursor-pointer" style="color: #064e3b;">
                  <input type="checkbox" id="syncPermanentAddressCheck" class="form-check-input m-0">
                  <span>Same as local address</span>
                </label>
              </div>
              <textarea id="profilePermanentAddressInput" name="permanent_address" class="profile-textarea-field" placeholder="Enter permanent address"></textarea>
            </div>
          </div>
        </section>
      </div>

      <!-- RIGHT COLUMN: Employment Record & Account Shortcuts -->
      <div class="profile-right-col">

        <!-- 4. Employment Record (Dark Green Card) -->
        <aside id="sectionEmploymentRecord" class="profile-employment-card">
          <div class="profile-emp-header">
            <div class="profile-emp-header-left">
              <div class="profile-emp-icon-box">
                <i class="ti ti-briefcase"></i>
              </div>
              <div>
                <h4 class="profile-emp-title">Employment Record</h4>
                <p class="profile-emp-subtitle">Corporate HR profile</p>
              </div>
            </div>
            <span class="profile-emp-badge">HR Managed</span>
          </div>

          <div class="profile-emp-list">
            <div class="profile-emp-row">
              <span class="profile-emp-label">Organization</span>
              <span class="profile-emp-value data-company-name">Biogenix Inc Pvt Ltd.</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Branch Location</span>
              <span class="profile-emp-value data-branch-name">—</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Assigned Role</span>
              <span class="profile-emp-value data-user-role">Super Administrator</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Designation</span>
              <span class="profile-emp-value data-designation">Collection Boy</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Employment Type</span>
              <span class="profile-emp-value data-employment-type">—</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Employee Category</span>
              <span class="profile-emp-value data-emp-categ-type">0</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Portal Access</span>
              <span class="profile-emp-value data-login-allowed">Yes</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Date of Joining</span>
              <span class="profile-emp-value data-doj">01 May 2026</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Notice Period</span>
              <span class="profile-emp-value data-notice-period">No</span>
            </div>

            <div class="profile-emp-row">
              <span class="profile-emp-label">Resignation Status</span>
              <span class="profile-emp-value data-resign-approved">Yes (01 Sept 2026)</span>
            </div>
          </div>
        </aside>

        <!-- 5. Account Shortcuts (White Card) -->
        <div class="profile-shortcuts-card">
          <h4 class="profile-shortcuts-title">Account Shortcuts</h4>
          <p class="profile-shortcuts-subtitle">Quick links to account settings</p>

          <div class="profile-shortcuts-list">
            <a href="index.php?page=account-settings" class="profile-shortcut-item">
              <div class="profile-shortcut-left">
                <div class="profile-shortcut-icon">
                  <i class="ti ti-shield-lock"></i>
                </div>
                <div>
                  <div class="profile-shortcut-name">Password &amp; Security</div>
                  <div class="profile-shortcut-desc">Update security credentials</div>
                </div>
              </div>
              <i class="ti ti-chevron-right profile-shortcut-chevron"></i>
            </a>

            <a href="index.php?page=salary-account" class="profile-shortcut-item">
              <div class="profile-shortcut-left">
                <div class="profile-shortcut-icon">
                  <i class="ti ti-credit-card"></i>
                </div>
                <div>
                  <div class="profile-shortcut-name">Salary Account</div>
                  <div class="profile-shortcut-desc">Bank details &amp; payout info</div>
                </div>
              </div>
              <i class="ti ti-chevron-right profile-shortcut-chevron"></i>
            </a>

            <?php if (!empty($navbar_claim_href)): ?>
            <a href="<?= $navbar_claim_href ?>" class="profile-shortcut-item">
              <div class="profile-shortcut-left">
                <div class="profile-shortcut-icon">
                  <i class="ti ti-file-text"></i>
                </div>
                <div>
                  <div class="profile-shortcut-name">Claim Reimbursement</div>
                  <div class="profile-shortcut-desc">Submit expense claims</div>
                </div>
              </div>
              <i class="ti ti-chevron-right profile-shortcut-chevron"></i>
            </a>
            <?php endif; ?>

            <a href="index.php?page=appearance" class="profile-shortcut-item">
              <div class="profile-shortcut-left">
                <div class="profile-shortcut-icon">
                  <i class="ti ti-palette"></i>
                </div>
                <div>
                  <div class="profile-shortcut-name">Appearance &amp; Theme</div>
                  <div class="profile-shortcut-desc">Color themes and display font</div>
                </div>
              </div>
              <i class="ti ti-chevron-right profile-shortcut-chevron"></i>
            </a>
          </div>
        </div>

      </div>
    </div>
  </form>
</div>

<?php if (canDoThis('bom_approval')): ?>
<!-- ─── Pending BOM Approvals Inbound-Style Modal ───────────────────────────── -->
<div class="modal fade animate__animated fadeIn" id="pendingBomApprovalsModal" tabindex="-1" aria-labelledby="pendingBomApprovalsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
      <!-- Modal Header -->
      <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-gradient-to-r from-amber-50/80 via-white to-orange-50/50 !px-6 !py-4">
        <div class="flex items-center gap-3">
          <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500 text-white shadow-md shadow-amber-200 ring-1 ring-amber-400/30">
            <i class="ti ti-clipboard-check text-2xl"></i>
          </span>
          <div>
            <div class="flex items-center gap-2">
              <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="pendingBomApprovalsModalLabel">BOM Approval(s) Pending</h5>
              <span class="badge bg-label-warning text-xs font-bold" id="modalPendingBomCountBadge">0 Pending Review</span>
            </div>
            <p class="m-0 text-xs font-medium text-slate-500">
              Product package variation BOMs submitted by production and awaiting management review
            </p>
          </div>
        </div>
        <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
          <i class="ti ti-x text-xl"></i>
        </button>
      </div>

      <!-- Modal Body (Scrollable table if too much pending) -->
      <div class="modal-body !p-5">
        <div class="overflow-x-auto rounded-xl border border-slate-200" style="max-height: 58vh; overflow-y: auto;">
          <table class="min-w-full divide-y divide-slate-200 text-left text-xs" id="modalPendingBomTable">
            <thead class="bg-slate-50 font-semibold text-slate-700 uppercase tracking-wider sticky top-0 z-10 shadow-sm">
              <tr>
                <th class="px-4 py-3 w-12 text-center bg-slate-50">#</th>
                <th class="px-4 py-3 bg-slate-50">BOM Name</th>
                <th class="px-4 py-3 bg-slate-50">Finished Good (Package)</th>
                <th class="px-4 py-3 bg-slate-50">Category</th>
                <th class="px-4 py-3 bg-slate-50">Source Formulation</th>
                <th class="px-4 py-3 bg-slate-50">Submitted By / Date</th>
                <th class="px-4 py-3 text-center bg-slate-50">Status</th>
                <th class="px-4 py-3 text-center bg-slate-50 w-28">Action</th>
              </tr>
            </thead>
            <tbody id="modalPendingBomTbody" class="divide-y divide-slate-100 bg-white">
              <tr>
                <td colspan="8" class="px-4 py-8 text-center text-slate-400 font-medium">
                  <i class="ti ti-loader-2 animate-spin text-2xl block mb-2 text-amber-600"></i>
                  Loading pending BOM approvals...
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="flex items-center justify-between border-t border-slate-200 bg-slate-50/80 px-6 py-3">
        <div class="text-xs text-slate-500 font-medium" id="modalPendingBomSummaryText">
          Select "Review" on any BOM to verify components and submit decision.
        </div>
        <button type="button" class="inline-flex h-9 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-colors" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>

<!-- ─── Modern Review BOM Modal ────────────────────────────────────────────── -->
<div class="modal fade animate__animated fadeIn" id="reviewBomModal" tabindex="-1" aria-labelledby="reviewBomModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
      <!-- Header -->
      <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-gradient-to-r from-slate-50 to-indigo-50/40 !px-6 !py-4">
        <div class="flex items-center gap-3">
          <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-200 ring-1 ring-indigo-500/20">
            <i class="ti ti-file-search text-2xl"></i>
          </span>
          <div>
            <div class="flex items-center gap-2">
              <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="reviewBomModalLabel">Review Bill of Materials (BOM)</h5>
              <span id="reviewBomStatusBadge" class="badge bg-label-warning text-xs">Pending Approval</span>
            </div>
            <p class="m-0 text-xs font-medium text-slate-500" id="reviewBomSubTitle">Review formulation details, components, and submit approval decision</p>
          </div>
        </div>
        <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
          <i class="ti ti-x text-xl"></i>
        </button>
      </div>

      <div class="modal-body !p-6 space-y-5">
        <input type="hidden" id="reviewCurrentBomId" value="">

        <!-- Product Overview Card -->
        <div class="rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div class="md:col-span-2">
              <span class="inline-block rounded-md bg-indigo-100 px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider text-indigo-800">Target Finished Good</span>
              <h4 class="mt-1 text-base font-bold text-slate-900" id="reviewTargetProduct">—</h4>
              <div class="mt-1 flex flex-wrap gap-2 text-xs text-slate-600">
                <span><strong>Code:</strong> <span id="reviewProductCode">—</span></span>
                <span>&bull;</span>
                <span><strong>Category:</strong> <span id="reviewProductCategory">—</span></span>
                <span>&bull;</span>
                <span><strong>Pack Unit:</strong> <span id="reviewProductUnit">—</span></span>
              </div>
            </div>
            <div>
              <span class="block text-xs font-semibold uppercase tracking-wider text-slate-500">Source Formulation</span>
              <div class="mt-1 text-xs font-bold text-slate-800" id="reviewSourceInfo">—</div>
              <div class="mt-1 text-xs text-slate-500" id="reviewCreatorInfo">—</div>
            </div>
            <div>
              <span class="block text-xs font-semibold uppercase tracking-wider text-slate-500">BOM Type &amp; Name</span>
              <div class="mt-1 text-xs font-bold text-slate-800" id="reviewBomName">—</div>
              <div class="mt-1 text-xs text-slate-500" id="reviewBomType">—</div>
            </div>
          </div>
          <div class="mt-3 pt-3 border-t border-slate-200/80 text-xs text-slate-600" id="reviewNotesWrapper">
            <strong>Notes / Instructions:</strong> <span id="reviewBomNotes" class="italic">None provided</span>
          </div>
        </div>

        <!-- Raw Materials Table -->
        <div>
          <div class="mb-2 flex items-center justify-between">
            <h6 class="m-0 text-sm font-bold text-slate-900">
              <i class="ti ti-flask text-indigo-600 me-1"></i> Bill of Materials Recipe Components
            </h6>
            <span class="badge bg-label-info text-xs" id="reviewComponentCountBadge">0 components</span>
          </div>

          <div class="overflow-x-auto rounded-xl border border-slate-200">
            <table class="min-w-full divide-y divide-slate-200 text-left text-xs" id="reviewComponentsTable">
              <thead class="bg-slate-50 font-semibold text-slate-700 uppercase tracking-wider">
                <tr>
                  <th class="px-4 py-3 w-10 text-center">#</th>
                  <th class="px-4 py-3">Raw Material / Component Name</th>
                  <th class="px-4 py-3">Category</th>
                  <th class="px-4 py-3 w-32">Unit</th>
                  <th class="px-4 py-3 w-40 text-end bg-indigo-50/50">Qty Per Unit (Batch)</th>
                </tr>
              </thead>
              <tbody id="reviewComponentsTbody" class="divide-y divide-slate-100 bg-white">
                <tr>
                  <td colspan="5" class="px-4 py-6 text-center text-slate-400">Loading components...</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Rejection Reason Display Box (Visible when already rejected) -->
        <div id="reviewExistingRejectionBox" class="rounded-xl border border-rose-200 bg-rose-50/70 p-4" style="display:none;">
          <div class="flex items-start gap-3">
            <span class="inline-flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-rose-100 text-rose-700">
              <i class="ti ti-alert-triangle text-lg"></i>
            </span>
            <div class="text-xs">
              <h6 class="m-0 font-bold text-rose-900">Previous Rejection Reason:</h6>
              <p class="m-0 mt-1 font-medium text-rose-800" id="reviewExistingReasonText">—</p>
            </div>
          </div>
        </div>

        <!-- Reason / Comments Field -->
        <div id="reviewDecisionBox" class="rounded-xl border border-slate-200 bg-slate-50/80 p-4">
          <div class="flex items-center justify-between mb-1.5">
            <label for="reviewDecisionReasonInput" class="m-0 block text-xs font-bold uppercase tracking-wider text-slate-700">
              <i class="ti ti-notes text-indigo-600 me-1"></i> Decision Reason / Comments
            </label>
            <span class="text-[11px] text-slate-500 font-medium">
              <span class="text-rose-600 font-bold">* Mandatory for Rejection</span> &bull; Optional for Approval
            </span>
          </div>
          <textarea id="reviewDecisionReasonInput" class="input-theme !bg-white border-slate-300 focus:border-indigo-500" rows="2" placeholder="Enter reason or comments for your decision (mandatory if rejecting, optional if approving)..."></textarea>
        </div>

        <!-- Audit History Accordion / Timeline -->
        <div class="rounded-xl border border-slate-200 bg-white p-3">
          <button class="w-full flex items-center justify-between text-xs font-bold text-slate-700 hover:text-indigo-600 transition-colors" type="button" data-bs-toggle="collapse" data-bs-target="#reviewAuditCollapse" aria-expanded="false">
            <span><i class="ti ti-history me-1.5 text-slate-400"></i> View Approval &amp; Transition History</span>
            <i class="ti ti-chevron-down text-slate-400"></i>
          </button>
          <div class="collapse mt-3 pt-3 border-t border-slate-100" id="reviewAuditCollapse">
            <div id="reviewAuditTimeline" class="space-y-3">
              <div class="text-xs text-slate-400">No audit history available.</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Footer Actions -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/80 px-6 py-4">
        <button type="button" id="reviewModalBackBtn" class="inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-colors">
          <i class="ti ti-arrow-left text-sm"></i> Back to Pending List
        </button>
        <div class="flex items-center gap-2" id="reviewActionButtonsWrapper">
          <button type="button" id="reviewDirectRejectBtn" class="inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-rose-50 border border-rose-200 px-4 text-xs font-bold text-rose-700 shadow-sm hover:bg-rose-100 transition-colors">
            <i class="ti ti-x text-sm"></i> Reject BOM
          </button>
          <button type="button" id="reviewApproveBtn" class="inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-emerald-600 px-5 text-xs font-bold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-colors">
            <i class="ti ti-check text-sm"></i> Approve BOM
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php startSection('scripts'); ?>
<script src="<?= asset('assets/js/pages-profile.js') ?>"></script>
<script>
    const genderMap = <?= json_encode(Constant::EMPLOYEES['GENDER'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const maritalStatusMap = <?= json_encode(Constant::EMPLOYEES['MARITAL_STATUS'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const boolMap = { 0: 'No', 1: 'Yes' };
    const statusMap = { 1: 'Active', 2: 'Inactive', 3: 'Terminated', 4: 'On Leave' };
    const defaultAvatarUrl = "<?= asset('assets/img/avatars/14.png') ?>";

    const notify = (type, message) => {
        if (window.toastr && toastr[type]) {
            toastr[type](message);
        } else {
            alert(message);
        }
    };

    function formatDate(dateString) {
        if (!dateString || dateString === '0000-00-00') return '—';
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return dateString;
        return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    function usersBase(data = {}) {
        const { name = '', role_name = '', email = '' } = data || {};

        if (name) {
            $('.data-user-username').text(name);
            $('#profileNameInput').val(name);
        }
        $('.data-user-role').text(role_name || '—');
        $('#profileEmailInput').val(email || '');
    }

    function employeeBase(data = {}) {
        const {
            emp_code, solutation, first_name, last_name, dob, gender,
            fathers_name, marital_status, husband_name, blood_group,
            local_address, permanent_address, contact_no, alt_contact_no, alt_contact_no2,
            date_of_join, date_of_resign, last_working_date,
            is_notice_period, notice_period_days,
            is_resign_approved, resign_approved_date,
            status, company_name, employment_type, emp_categ_type, designation, branch_name,
            is_login_allowed, profile_photo_id
        } = data || {};

        const fullName = `${first_name || ''} ${last_name || ''}`.trim();

        if (fullName) {
            $('#profileNameInput').val(fullName);
            $('.data-user-username').text(fullName);
        }

        // Profile Photo
        if (profile_photo_id && Number(profile_photo_id) > 0) {
            $('#profilePhotoImg').attr('src', 'hrms-document.php?id=' + profile_photo_id);
        } else {
            $('#profilePhotoImg').attr('src', defaultAvatarUrl);
        }

        // Basic Contact
        $('#profilePhoneInput').val(contact_no || '');

        // Personal & Identity Inputs
        $('.data-emp-code').text(emp_code || '—');
        $('.data-emp-code-input').val(emp_code || '—');
        $('#profileSalutationSelect').val(solutation || '');
        $('#profileFirstNameInput').val(first_name || '');
        $('#profileLastNameInput').val(last_name || '');
        $('#profileDobInput').val(dob && dob !== '0000-00-00' ? dob : '');
        $('#profileGenderSelect').val(gender ? String(gender) : '');
        $('#profileBloodGroupSelect').val(blood_group || '');

        // Family & Address Inputs
        $('#profileFathersNameInput').val(fathers_name || '');
        $('#profileMaritalStatusSelect').val(marital_status ? String(marital_status) : '');
        $('#profileHusbandNameInput').val(husband_name || '');
        $('#profileAltContactInput').val(alt_contact_no || '');
        $('#profileAltContact2Input').val(alt_contact_no2 || '');
        $('#profileLocalAddressInput').val(local_address || '');
        $('#profilePermanentAddressInput').val(permanent_address || '');

        if (local_address && permanent_address && local_address === permanent_address) {
            $('#syncPermanentAddressCheck').prop('checked', true);
        } else {
            $('#syncPermanentAddressCheck').prop('checked', false);
        }

        // Employment & HR
        $('.data-emp-designation').text(designation || 'Collection Boy');
        $('.data-designation').text(designation || 'Collection Boy');
        $('.data-company-name').text(company_name || 'Biogenix Inc Pvt Ltd.');
        $('.data-company-name-hero').text(company_name || 'Biogenix Inc Pvt Ltd.');
        $('.data-branch-name').text(branch_name || '—');
        
        $('.data-employment-type').text(employment_type || '—');
        $('.data-emp-categ-type').text(emp_categ_type !== null && emp_categ_type !== undefined ? emp_categ_type : '0');
        $('.data-status').text(statusMap[status] || status || 'Active');
        $('.data-status-badge').text(statusMap[status] ? `${statusMap[status]} Employee` : (status == 2 ? 'Inactive Employee' : 'Active Employee'));
        $('.data-login-allowed').text(boolMap[is_login_allowed] || (is_login_allowed == 1 ? 'Yes' : 'No') || 'Yes');

        $('.data-doj').text(formatDate(date_of_join) || '01 May 2026');
        $('.data-dor').text(formatDate(date_of_resign));
        $('.data-lwd').text(formatDate(last_working_date));
        
        const noticePeriodTxt = is_notice_period == 1 ? `Yes (${notice_period_days || 0} days)` : 'No';
        $('.data-notice-period').text(noticePeriodTxt);

        const resignApprovedTxt = is_resign_approved == 1 ? `Yes (${formatDate(resign_approved_date)})` : 'No';
        $('.data-resign-approved').text(resignApprovedTxt);
    }

    function loadProfileData() {
        $.ajax({
            url: 'dashboardajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                userProfileAllData: 'userProfileAllData'
            },
            success: function(response) {
                if (response.status !== 'success') return;
                usersBase(response.usersData);
                employeeBase(response.employeeData);
            },
            error: function(xhr, status, error) {
                console.error("Failed to load data:", error);
            }
        });
    }

    $(document).ready(function() {
        loadProfileData();

        // Sync Name fields dynamically
        $('#profileFirstNameInput, #profileLastNameInput').on('input', function() {
            const first = $('#profileFirstNameInput').val().trim();
            const last = $('#profileLastNameInput').val().trim();
            const combined = `${first} ${last}`.trim();
            if (combined) {
                $('#profileNameInput').val(combined);
                $('.data-user-username').text(combined);
            }
        });

        $('#profileNameInput').on('input', function() {
            const name = $(this).val().trim();
            $('.data-user-username').text(name || '-');
            const parts = name.split(/\s+/);
            if (parts.length > 0) {
                $('#profileFirstNameInput').val(parts[0] || '');
                $('#profileLastNameInput').val(parts.slice(1).join(' ') || '');
            }
        });

        // Sync Permanent Address Checkbox
        $('#syncPermanentAddressCheck').on('change', function() {
            if ($(this).is(':checked')) {
                $('#profilePermanentAddressInput').val($('#profileLocalAddressInput').val().trim());
            }
        });

        $('#profileLocalAddressInput').on('input', function() {
            if ($('#syncPermanentAddressCheck').is(':checked')) {
                $('#profilePermanentAddressInput').val($(this).val().trim());
            }
        });

        // Trigger photo file input on Camera button or Avatar click
        $('#btnUploadPhoto, #profilePhotoImg, #profileAvatarWrapper').on('click', function(e) {
            e.stopPropagation();
            $('#profilePhotoFileInput').val('').click();
        });

        // Handle Profile Photo Upload
        $('#profilePhotoFileInput').on('change', function() {
            const file = this.files && this.files[0];
            if (!file) return;

            if (file.size > 5 * 1024 * 1024) {
                notify('error', 'Profile photo must be smaller than 5 MB.');
                return;
            }

            const formData = new FormData();
            formData.append('action', 'upload_profile_photo');
            formData.append('csrf_token', $('#profileCsrfToken').val() || '');
            formData.append('profile_photo', file);

            const $btn = $('#btnUploadPhoto');
            $btn.prop('disabled', true);
            $('#cameraIcon').addClass('d-none');
            $('#cameraSpinner').removeClass('d-none');

            $.ajax({
                url: 'hrms-api.php',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(res) {
                    $btn.prop('disabled', false);
                    $('#cameraSpinner').addClass('d-none');
                    $('#cameraIcon').removeClass('d-none');

                    if (res.status === 'success') {
                        notify('success', res.message || 'Profile photo updated successfully.');
                        if (res.photo_url) {
                            const cacheBustUrl = res.photo_url + (res.photo_url.includes('?') ? '&t=' : '?t=') + new Date().getTime();
                            $('#profilePhotoImg').attr('src', cacheBustUrl);

                            // Update navbar dropdown avatar and navbar toggle icon
                            $('img[alt="Profile photo"], img[alt="Open profile settings"], .dropdown-user img').attr('src', cacheBustUrl);

                            // If navbar previously displayed initials circle, replace with image
                            $('.dropdown-user .avatar-initial').each(function() {
                                const $parent = $(this).parent();
                                if ($parent.is('a')) {
                                    $parent.html('<img src="' + cacheBustUrl + '" alt="Open profile settings" class="rounded-circle shadow-sm" style="width:36px;height:36px;object-fit:cover;border:2px solid #e2e8f0;" />');
                                } else {
                                    $parent.html('<img src="' + cacheBustUrl + '" alt="Profile photo" class="rounded-circle border border-2 border-white shadow-sm" style="width: 56px; height: 56px; object-fit: cover;" />');
                                }
                            });
                        }
                    } else {
                        notify('error', res.message || 'Failed to upload photo.');
                    }
                },
                error: function(xhr) {
                    $btn.prop('disabled', false);
                    $('#cameraSpinner').addClass('d-none');
                    $('#cameraIcon').removeClass('d-none');

                    const res = xhr.responseJSON || {};
                    notify('error', res.message || 'Error uploading profile photo.');
                }
            });
        });

        // Handle Save Profile Changes
        $('#btnSaveProfile').on('click', function() {
            const name = $('#profileNameInput').val().trim();
            const phone = $('#profilePhoneInput').val().trim();
            const firstName = $('#profileFirstNameInput').val().trim();
            const lastName = $('#profileLastNameInput').val().trim();

            if (!name && !firstName) {
                notify('error', 'Please enter your first name or full name.');
                $('#profileFirstNameInput').focus();
                return;
            }

            const formData = new FormData();
            formData.append('action', 'update_my_profile');
            formData.append('csrf_token', $('#profileCsrfToken').val() || '');
            formData.append('profile_name', name || `${firstName} ${lastName}`.trim());
            formData.append('first_name', firstName);
            formData.append('last_name', lastName);
            formData.append('profile_phone', phone);
            formData.append('solutation', $('#profileSalutationSelect').val() || '');
            formData.append('dob', $('#profileDobInput').val() || '');
            formData.append('gender', $('#profileGenderSelect').val() || '');
            formData.append('blood_group', $('#profileBloodGroupSelect').val() || '');
            formData.append('fathers_name', $('#profileFathersNameInput').val().trim());
            formData.append('marital_status', $('#profileMaritalStatusSelect').val() || '');
            formData.append('husband_name', $('#profileHusbandNameInput').val().trim());
            formData.append('alt_contact_no', $('#profileAltContactInput').val().trim());
            formData.append('alt_contact_no2', $('#profileAltContact2Input').val().trim());
            formData.append('local_address', $('#profileLocalAddressInput').val().trim());
            formData.append('permanent_address', $('#profilePermanentAddressInput').val().trim());

            const $btn = $(this);
            $btn.prop('disabled', true);
            $('#saveBtnIcon').addClass('d-none');
            $('#saveBtnSpinner').removeClass('d-none');
            $('#saveBtnText').text('Saving Changes...');

            $.ajax({
                url: 'hrms-api.php',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(res) {
                    $btn.prop('disabled', false);
                    $('#saveBtnSpinner').addClass('d-none');
                    $('#saveBtnIcon').removeClass('d-none');
                    $('#saveBtnText').text('Save Changes');

                    if (res.status === 'success') {
                        notify('success', res.message || 'Profile updated successfully.');
                        loadProfileData();
                    } else {
                        notify('error', res.message || 'Failed to update profile.');
                    }
                },
                error: function(xhr) {
                    $btn.prop('disabled', false);
                    $('#saveBtnSpinner').addClass('d-none');
                    $('#saveBtnIcon').removeClass('d-none');
                    $('#saveBtnText').text('Save Changes');

                    const res = xhr.responseJSON || {};
                    notify('error', res.message || 'Error updating profile.');
                }
            });
        });

        // Handle Cancel Button
        $('#btnCancelProfile').on('click', function() {
            loadProfileData();
            notify('info', 'Changes cancelled and reverted to saved values.');
        });

        <?php if (canDoThis('bom_approval')): ?>
        // ─── BOM Approval Flow Handlers in Profile ──────────────────────────────────
        let _reopenPendingBomModal = false;

        function checkProfilePendingBomCount() {
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: { getPendingBomApprovalCount: '1' },
                success: function(res) {
                    if (res.status === 'success' && res.has_permission) {
                        const count = Number(res.pending_count || 0);
                        if (count > 0) {
                            $('#bomApprovalPendingWidget').fadeIn();
                            $('#bomPendingCountPill').text(count + ' Pending Review');
                            $('#bomPendingBadgeDot').text(count);
                            $('#modalPendingBomCountBadge').text(count + ' Pending Review');
                        } else {
                            $('#bomApprovalPendingWidget').hide();
                            $('#modalPendingBomCountBadge').text('0 Pending Review');
                        }
                    }
                }
            });
        }

        function loadPendingBomApprovalsModalList() {
            $('#modalPendingBomTbody').html(`
                <tr>
                    <td colspan="8" class="px-4 py-8 text-center text-slate-400 font-medium">
                        <i class="ti ti-loader-2 animate-spin text-2xl block mb-2 text-amber-600"></i>
                        Loading pending BOM approvals...
                    </td>
                </tr>
            `);

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    loadBomApprovalList: '1',
                    filter: 'pending'
                },
                success: function(res) {
                    if (res.status === 'success') {
                        renderPendingBomModalTable(res.data || []);
                    } else {
                        $('#modalPendingBomTbody').html(`
                            <tr><td colspan="8" class="px-4 py-6 text-center text-rose-500">${res.message || 'Failed to load BOMs.'}</td></tr>
                        `);
                    }
                },
                error: function() {
                    $('#modalPendingBomTbody').html(`
                        <tr><td colspan="8" class="px-4 py-6 text-center text-rose-500">Server error loading BOM requests.</td></tr>
                    `);
                }
            });
        }

        function renderPendingBomModalTable(list) {
            const count = list ? list.length : 0;
            $('#modalPendingBomCountBadge').text(count + ' Pending Review');
            $('#bomPendingCountPill').text(count + ' Pending Review');
            $('#bomPendingBadgeDot').text(count);

            if (!list || list.length === 0) {
                $('#modalPendingBomTbody').html(`
                    <tr>
                        <td colspan="8" class="px-4 py-10 text-center text-slate-500 text-sm">
                            <i class="ti ti-circle-check text-4xl text-emerald-500 block mb-2"></i>
                            <strong class="text-slate-800 font-bold block mb-1">All BOM approvals are up to date!</strong>
                            No product package variation BOMs are currently pending review.
                        </td>
                    </tr>
                `);
                $('#modalPendingBomSummaryText').text('All pending requests have been processed.');
                return;
            }

            $('#modalPendingBomSummaryText').text(`Displaying ${count} pending BOM approval request(s).`);

            let rows = '';
            list.forEach(function(b, idx) {
                const num = idx + 1;
                let sourceText = '<span class="text-slate-500">Original Formulation</span>';
                if (b.source_type === 'CLONED' && b.source_bom_id) {
                    sourceText = `<span class="inline-flex items-center gap-1 text-slate-700 font-semibold" title="Cloned from BOM #${b.source_bom_id}"><i class="ti ti-copy text-indigo-500"></i> Cloned (#${b.source_bom_id})</span>`;
                }

                rows += `
                    <tr class="hover:bg-amber-50/40 transition-colors">
                        <td class="px-4 py-3 text-center text-slate-400 font-semibold">${num}</td>
                        <td class="px-4 py-3">
                            <span class="font-bold text-slate-900 block">${escapeHtmlText(b.name || '')}</span>
                            <span class="text-[11px] text-slate-400">BOM ID: #${b.id} &bull; ${b.item_count || 0} items</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="font-semibold text-slate-800 block">${escapeHtmlText(b.product_name || '—')}</span>
                            <span class="text-[11px] text-slate-500">${escapeHtmlText(b.product_code || '')} ${b.unit_name ? `(${b.unit_name})` : ''}</span>
                        </td>
                        <td class="px-4 py-3 text-slate-600">${escapeHtmlText(b.category_name || '—')}</td>
                        <td class="px-4 py-3">${sourceText}</td>
                        <td class="px-4 py-3">
                            <span class="text-slate-800 block">${escapeHtmlText(b.creator_name || 'System')}</span>
                            <span class="text-[11px] text-slate-400">${escapeHtmlText(b.created_at || '—')}</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <span class="badge bg-label-warning text-xs">Pending Review</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <button type="button" class="btn btn-primary btn-sm rounded-xl px-3 py-1.5 reviewBomBtn" data-id="${b.id}" title="Review BOM">
                                <i class="ti ti-file-search me-1"></i> Review
                            </button>
                        </td>
                    </tr>
                `;
            });

            $('#modalPendingBomTbody').html(rows);
        }

        function escapeHtmlText(str) {
            if (!str) return '';
            return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        // Widget Click -> Open Inbound-style Pending BOMs Modal
        $('#bomApprovalPendingWidget').on('click', function() {
            $('#pendingBomApprovalsModal').modal('show');
            loadPendingBomApprovalsModalList();
        });

        // Review BOM Button Click (from Pending Modal table)
        $(document).on('click', '.reviewBomBtn', function() {
            const bomId = Number($(this).data('id') || 0);
            if (!bomId) return;

            _reopenPendingBomModal = true;
            $('#pendingBomApprovalsModal').modal('hide');

            $('#reviewCurrentBomId').val(bomId);
            $('#reviewDecisionReasonInput').val('').removeClass('border-rose-500 ring-2 ring-rose-200');
            $('#reviewExistingRejectionBox').hide();
            $('#reviewAuditCollapse').collapse('hide');
            $('#reviewComponentsTbody').html(`
                <tr><td colspan="5" class="px-4 py-6 text-center text-slate-400"><i class="ti ti-loader-2 animate-spin text-xl block mb-1"></i> Loading details...</td></tr>
            `);

            $('#reviewBomModal').modal('show');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    getBomDetailsForReview: '1',
                    bom_id: bomId
                },
                success: function(res) {
                    if (res.status === 'success' && res.bom) {
                        const b = res.bom;
                        $('#reviewTargetProduct').text(b.product_name || '—');
                        $('#reviewProductCode').text(b.product_code || '—');
                        $('#reviewProductCategory').text(b.category_name || '—');
                        $('#reviewProductUnit').text(b.unit_name || '—');
                        $('#reviewBomName').text(b.name || '—');
                        $('#reviewBomNotes').text(b.descriptions || 'None provided');
                        $('#reviewCreatorInfo').text(`Submitted by ${b.creator_name || 'System'} on ${b.created_at || '—'}`);

                        let srcHtml = 'Original Formulation';
                        if (b.source_type === 'CLONED' && b.source_bom_id) {
                            srcHtml = `<span class="text-indigo-700 font-semibold"><i class="ti ti-copy me-1"></i> Cloned from BOM #${b.source_bom_id} (${escapeHtmlText(b.source_product_name || '')})</span>`;
                        }
                        $('#reviewSourceInfo').html(srcHtml);

                        // Status Badge
                        let statusBadgeClass = 'bg-label-warning';
                        let statusLabel = b.bom_status;
                        if (b.bom_status === 'APPROVED') {
                            statusBadgeClass = 'bg-label-success';
                            statusLabel = 'Approved';
                        } else if (b.bom_status === 'REJECTED') {
                            statusBadgeClass = 'bg-label-danger';
                            statusLabel = 'Rejected';
                        }
                        $('#reviewBomStatusBadge').attr('class', `badge ${statusBadgeClass} text-xs`).text(statusLabel);

                        // If already rejected, show existing rejection reason
                        if (b.bom_status === 'REJECTED' && b.reason) {
                            $('#reviewExistingReasonText').text(b.reason);
                            $('#reviewExistingRejectionBox').show();
                        } else {
                            $('#reviewExistingRejectionBox').hide();
                        }

                        // Configure action buttons according to status
                        if (b.bom_status === 'PENDING_APPROVAL') {
                            $('#reviewActionButtonsWrapper').html(`
                                <button type="button" id="reviewDirectRejectBtn" class="inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-rose-50 border border-rose-200 px-4 text-xs font-bold text-rose-700 shadow-sm hover:bg-rose-100 transition-colors">
                                    <i class="ti ti-x text-sm"></i> Reject BOM
                                </button>
                                <button type="button" id="reviewApproveBtn" class="inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-emerald-600 px-5 text-xs font-bold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-colors">
                                    <i class="ti ti-check text-sm"></i> Approve BOM
                                </button>
                            `);
                        } else if (b.bom_status === 'APPROVED') {
                            $('#reviewActionButtonsWrapper').html(`
                                <span class="badge bg-label-success text-xs py-2 px-3">
                                    <i class="ti ti-check me-1"></i> Approved by ${escapeHtmlText(b.approver_name || 'Management')} on ${escapeHtmlText(b.approved_at || '')}
                                </span>
                            `);
                        } else if (b.bom_status === 'REJECTED') {
                            $('#reviewActionButtonsWrapper').html(`
                                <span class="badge bg-label-danger text-xs py-2 px-3">
                                    <i class="ti ti-x me-1"></i> Rejected
                                </span>
                            `);
                        } else {
                            $('#reviewActionButtonsWrapper').html('');
                        }

                        // Render Components
                        const items = res.items || [];
                        $('#reviewComponentCountBadge').text(items.length + ' components');
                        if (items.length === 0) {
                            $('#reviewComponentsTbody').html(`
                                <tr><td colspan="5" class="px-4 py-4 text-center text-slate-400">No components defined in this BOM.</td></tr>
                            `);
                        } else {
                            let compRows = '';
                            items.forEach(function(it, cIdx) {
                                compRows += `
                                    <tr class="hover:bg-slate-50/50 transition-colors">
                                        <td class="px-4 py-3 text-center text-slate-400 font-semibold">${cIdx + 1}</td>
                                        <td class="px-4 py-3">
                                            <span class="font-bold text-slate-900 block">${escapeHtmlText(it.product_name || '')}</span>
                                            <span class="text-[11px] text-slate-400">${escapeHtmlText(it.product_code || '')}</span>
                                        </td>
                                        <td class="px-4 py-3 text-slate-600">${escapeHtmlText(it.category_name || '—')}</td>
                                        <td class="px-4 py-3 text-slate-700 font-medium">${escapeHtmlText(it.unit_name || '—')}</td>
                                        <td class="px-4 py-3 text-end font-bold text-indigo-700 bg-indigo-50/40">${Number(it.qty_per_unit || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 6 })}</td>
                                    </tr>
                                `;
                            });
                            $('#reviewComponentsTbody').html(compRows);
                        }

                        // Render Audit History
                        const history = res.history || [];
                        if (history.length === 0) {
                            $('#reviewAuditTimeline').html('<div class="text-xs text-slate-400">No history available.</div>');
                        } else {
                            let hHtml = '<div class="relative pl-6 space-y-3 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">';
                            history.forEach(function(h) {
                                let dotColor = 'bg-slate-400';
                                if (h.action === 'APPROVED') dotColor = 'bg-emerald-500';
                                else if (h.action === 'REJECTED') dotColor = 'bg-rose-500';
                                else if (h.action === 'SUBMITTED') dotColor = 'bg-blue-500';

                                hHtml += `
                                    <div class="relative text-xs">
                                        <span class="absolute -left-6 top-1.5 h-2.5 w-2.5 rounded-full ${dotColor} ring-4 ring-white"></span>
                                        <div class="font-bold text-slate-800">${escapeHtmlText(h.action)} &bull; <span class="font-normal text-slate-500">${escapeHtmlText(h.created_at || '')}</span></div>
                                        <div class="text-slate-600">By ${escapeHtmlText(h.user_name || 'System')}</div>
                                        ${h.comments ? `<div class="mt-1 text-slate-700 bg-slate-50 p-2 rounded border border-slate-100"><strong>Note:</strong> ${escapeHtmlText(h.comments)}</div>` : ''}
                                    </div>
                                `;
                            });
                            hHtml += '</div>';
                            $('#reviewAuditTimeline').html(hHtml);
                        }
                    } else {
                        toastr.error(res.message || 'Failed to fetch BOM review details.');
                    }
                },
                error: function() {
                    toastr.error('Server error fetching review details.');
                }
            });
        });

        // Back to Pending List Button Click
        $(document).on('click', '#reviewModalBackBtn', function() {
            $('#reviewBomModal').modal('hide');
            $('#pendingBomApprovalsModal').modal('show');
            loadPendingBomApprovalsModalList();
        });

        // Submit Rejection (MANDATORY REASON CHECK)
        $(document).on('click', '#reviewDirectRejectBtn', function() {
            const bomId = Number($('#reviewCurrentBomId').val() || 0);
            const reason = $.trim($('#reviewDecisionReasonInput').val());

            if (!bomId) {
                toastr.error('Missing BOM ID.');
                return;
            }

            if (!reason) {
                $('#reviewDecisionReasonInput').addClass('border-rose-500 ring-2 ring-rose-200').focus();
                Swal.fire({
                    icon: 'warning',
                    title: 'Rejection Reason Required',
                    text: 'Please enter a mandatory reason in the comments box before rejecting this BOM.',
                    customClass: { confirmButton: 'btn btn-warning' },
                    buttonsStyling: false
                });
                return;
            }

            Swal.fire({
                title: 'Reject this BOM?',
                text: 'Are you sure you want to reject this BOM with the specified reason?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: '<i class="ti ti-x me-1"></i> Yes, Reject',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light me-2',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then((result) => {
                if (!result.isConfirmed) return;

                const $btn = $('#reviewDirectRejectBtn');
                $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Rejecting...');

                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        rejectBom: '1',
                        bom_id: bomId,
                        reason: reason
                    },
                    success: function(res) {
                        $btn.prop('disabled', false).html('<i class="ti ti-x text-sm"></i> Reject BOM');
                        if (res.status === 'success') {
                            $('#reviewBomModal').modal('hide');
                            Swal.fire({
                                icon: 'info',
                                title: 'BOM Rejected',
                                text: res.message,
                                customClass: { confirmButton: 'btn btn-primary' },
                                buttonsStyling: false
                            });
                            checkProfilePendingBomCount();
                            setTimeout(function() {
                                $('#pendingBomApprovalsModal').modal('show');
                                loadPendingBomApprovalsModalList();
                            }, 300);
                        } else {
                            toastr.error(res.message || 'Failed to reject BOM.');
                        }
                    },
                    error: function() {
                        $btn.prop('disabled', false).html('<i class="ti ti-x text-sm"></i> Reject BOM');
                        toastr.error('Server error rejecting BOM.');
                    }
                });
            });
        });

        // Approve BOM (Reason / comments optional)
        $(document).on('click', '#reviewApproveBtn', function() {
            const bomId = Number($('#reviewCurrentBomId').val() || 0);
            const comments = $.trim($('#reviewDecisionReasonInput').val());
            if (!bomId) return;

            Swal.fire({
                title: 'Approve this BOM?',
                text: 'Once approved, this bill of materials will become active and available for production scheduling immediately.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: '<i class="ti ti-check me-1"></i> Yes, Approve',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-success waves-effect waves-light me-2',
                    cancelButton: 'btn btn-label-secondary waves-effect waves-light'
                },
                buttonsStyling: false
            }).then((result) => {
                if (!result.isConfirmed) return;

                const $btn = $('#reviewApproveBtn');
                $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Approving...');

                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        approveBom: '1',
                        bom_id: bomId,
                        comments: comments || 'Approved by management in Profile'
                    },
                    success: function(res) {
                        $btn.prop('disabled', false).html('<i class="ti ti-check text-sm"></i> Approve BOM');
                        if (res.status === 'success') {
                            $('#reviewBomModal').modal('hide');
                            Swal.fire({
                                icon: 'success',
                                title: 'BOM Approved!',
                                text: res.message,
                                customClass: { confirmButton: 'btn btn-success' },
                                buttonsStyling: false
                            });
                            checkProfilePendingBomCount();
                            setTimeout(function() {
                                $('#pendingBomApprovalsModal').modal('show');
                                loadPendingBomApprovalsModalList();
                            }, 300);
                        } else {
                            toastr.error(res.message || 'Failed to approve BOM.');
                        }
                    },
                    error: function() {
                        $btn.prop('disabled', false).html('<i class="ti ti-check text-sm"></i> Approve BOM');
                        toastr.error('Server error approving BOM.');
                    }
                });
            });
        });

        // Initial Load on Document Ready
        checkProfilePendingBomCount();
        <?php endif; ?>
    });
</script>
<?php endSection(); ?>
