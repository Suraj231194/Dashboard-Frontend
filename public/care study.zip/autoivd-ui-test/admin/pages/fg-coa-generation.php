<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage FG COA generation records and review details</p>
        </div>
    </div>

    <!-- Incoming FG COA Generation widget -->
    <div id="incomingFgCoaGenerationWidget"
        class="mb-6 cursor-pointer overflow-hidden rounded-xl border p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md w-full md:w-1/2"
        style="border-color: color-mix(in srgb, var(--appearance-accent, #d97706) 24%, #fed7aa); background-color: color-mix(in srgb, var(--appearance-accent, #d97706) 7%, #fff7ed);"
        role="button" tabindex="0" aria-controls="incomingFgCoaGenerationModal">
        <div class="flex items-center justify-between gap-4">
            <div class="flex min-w-0 items-center gap-3">
                <span class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm ring-1 ring-black/5"
                    style="color: var(--appearance-accent, #d97706);">
                    <i class="ti ti-file-description text-2xl"></i>
                </span>
                <div class="min-w-0">
                    <div class="flex flex-wrap items-center gap-2">
                        <h3 class="m-0 text-base font-extrabold text-slate-900">Incoming FG COA Generation Forms</h3>
                        <span id="incomingFgCoaGenerationCount"
                            class="inline-flex min-w-6 items-center justify-center rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white"
                            style="background-color: var(--appearance-accent, #d97706);">0</span>
                    </div>
                    <p class="m-0 mt-1 text-xs font-medium text-slate-600">
                        Click here to review and generate new finished goods COA records.
                    </p>
                </div>
            </div>
            <i class="ti ti-chevron-right shrink-0 text-xl" style="color: var(--appearance-accent, #d97706);"></i>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="fgcoaPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="fgcoa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <select id="fgCoaWorkflowFilter"
                        class="h-10 min-w-36 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30">
                        <option value="">All statuses</option>
                        <option value="DRAFT">Draft</option>
                        <option value="COMPLETED">Approved</option>
                        <option value="REJECTED">Rejected</option>
                        <option value="HOLD">Hold</option>
                        <option value="INVESTIGATION">Investigation</option>
                    </select>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><i
                                class="ti ti-search text-lg text-slate-400"></i></div><input type="text"
                            id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'fg_coa_generation_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#addFgCoaModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="created_at"><span class="inline-flex items-center gap-1">Timestamp <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-column="production_plan_no">Plan No</th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="coa_fg"><span class="inline-flex items-center gap-1">FG COA <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-36 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="test_date"><span class="inline-flex items-center gap-1">Testing Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="product_name"><span class="inline-flex items-center gap-1">Product Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-44 min-w-[160px] cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="batch_number"><span class="inline-flex items-center gap-1">Lot No/Batch No
                                    <i class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="batch_size"><span class="inline-flex items-center gap-1">Batch Size <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Workflow</th>
                            <th class="w-32 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Created By</th>
                            <th
                                class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="fgTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <style>
        #addFgCoaModal.coa-template-workspace-mode .modal-dialog {
            width: calc(100% - 2rem);
            max-width: 1320px;
        }

        #addFgCoaModal .modal-content {
            max-height: calc(100vh - 2rem);
        }

        #addFgCoaModal.coa-template-workspace-mode .modal-body {
            overflow-x: hidden;
            padding: 1rem !important;
        }

        #addFgCoaModal.coa-template-workspace-mode #fgCoaTemplatePanel {
            margin-top: 0 !important;
            border-radius: .75rem !important;
        }

        #incomingFgCoaGenerationModal .modal-dialog {
            width: calc(100% - 2rem);
            max-width: 1480px;
        }

        #incomingFgCoaGenerationModal .incoming-coa-item-cell {
            min-width: 520px;
        }

        #incomingFgCoaGenerationModal .incoming-coa-item-name {
            white-space: nowrap;
        }

        #incomingFgCoaGenerationModal .incoming-coa-item-dot {
            flex: 0 0 auto;
        }

        #incomingFgCoaGenerationModal .incoming-coa-item-meta {
            margin-top: .25rem;
            padding-left: .875rem;
        }

        #incomingFgCoaGenerationModal .incoming-coa-table-scroll {
            height: 334px;
            overflow-x: auto;
            overflow-y: auto;
            scrollbar-gutter: stable;
        }

        #incomingFgCoaGenerationModal .incoming-coa-table-scroll thead {
            position: sticky;
            top: 0;
            z-index: 2;
        }
    </style>

    <div class="modal fade animate__animated fadeIn" id="addFgCoaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span id="fgCoaModalIcon"
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 id="fgCoaModalTitle" class="modal-title m-0 text-lg font-bold text-slate-900">Add FG COA</h5>
                            <p id="fgCoaModalSubtitle" class="m-0 text-sm font-medium text-slate-500">Create a new FG COA record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addFgCoaGenerateForm">
                    <input type="hidden" id="fgWorkflowSourceIpId" name="fgWorkflowSourceIpId" value="">
                    <input type="hidden" id="fgCoaRecordId" value="">
                    <input type="hidden" id="fgCoaWorkflowAction" value="COMPLETED">
                    <input type="hidden" id="fgCoaTemplateId" value="">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div id="fgCoaBasicFields">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="fgCoaNo" class="mb-1 block text-sm font-medium text-slate-800">FG COA No.</label>
                                <input type="text" id="fgCoaNo" autocomplete="off" name="fgCoaNo" class="input-theme"
                                    placeholder="Auto-generated on save" readonly />
                            </div>
                            <div>
                                <label for="prodDepartment"
                                    class="mb-1 block text-sm font-medium text-slate-800">Department <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="prodDepartment" name="prodDepartment" class="input-theme select2"
                                    placeholder="Select Department" required></select>
                            </div>
                            <div>
                                <label for="fgProductId" class="mb-1 block text-sm font-medium text-slate-800">Product
                                    Name <strong class="text-rose-500">*</strong></label>
                                <select id="fgProductId" name="fgProductId" class="input-theme select2" required>
                                    <option value="">---Select----</option>
                                </select>
                                <input type="hidden" id="productName" name="productName" />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="fgLiveStockId" class="mb-1 block text-sm font-medium text-slate-800">Inventory Batch <span class="text-xs text-slate-400 font-normal">(Optional for New Production)</span></label>
                                <select id="fgLiveStockId" name="fgLiveStockId" class="input-theme select2">
                                    <option value="">---Select Inventory Batch (Optional)----</option>
                                </select>
                                <input type="hidden" id="lotNoBatchNo" name="lotNoBatchNo" />
                            </div>
                            <div>
                                <label for="prodBatchSize" class="mb-1 block text-sm font-medium text-slate-800">Batch
                                    Size <strong class="text-rose-500">*</strong></label>
                                <input type="number" min="0" step="any" id="prodBatchSize" autocomplete="off"
                                    name="prodBatchSize" class="input-theme" placeholder="Enter Batch Size" required />
                            </div>
                            <div>
                                <label for="prodBatchSizeUnit"
                                    class="mb-1 block text-sm font-medium text-slate-800">Batch Size Unit <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="prodBatchSizeUnit" name="prodBatchSizeUnit" class="input-theme select2"
                                    placeholder="Enter Batch Size" required></select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="testingDate" class="mb-1 block text-sm font-medium text-slate-800">Testing
                                    Date <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="testingDate" autocomplete="off" name="testingDate"
                                    class="input-theme" placeholder="Enter Date" required />
                            </div>
                            <div>
                                <div class="flex items-center justify-between mb-1">
                                    <label for="testedBy" class="block text-sm font-medium text-slate-800">Tested By</label>
                                    <label class="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 cursor-pointer hover:text-emerald-800" title="Upload signed image (max 250 KB)">
                                        <i class="ti ti-upload text-sm"></i> Sign
                                        <input type="file" class="coa-modal-sig-upload" data-target="#testedBy" accept="image/png,image/jpeg,image/jpg,image/webp" style="display:none;">
                                    </label>
                                </div>
                                <div class="relative">
                                    <input type="text" id="testedBy" autocomplete="off" name="testedBy" class="input-theme pr-8" placeholder="Enter Tested By / Sign" />
                                    <button type="button" class="coa-modal-sig-clear absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-600 hidden text-base font-bold" data-target="#testedBy" title="Clear signature">&times;</button>
                                </div>
                            </div>
                            <div>
                                <div class="flex items-center justify-between mb-1">
                                    <label for="reviewAndApproveBy" class="block text-sm font-medium text-slate-800">Review & Approved By</label>
                                    <label class="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 cursor-pointer hover:text-emerald-800" title="Upload signed image (max 250 KB)">
                                        <i class="ti ti-upload text-sm"></i> Sign
                                        <input type="file" class="coa-modal-sig-upload" data-target="#reviewAndApproveBy" accept="image/png,image/jpeg,image/jpg,image/webp" style="display:none;">
                                    </label>
                                </div>
                                <div class="relative">
                                    <input type="text" id="reviewAndApproveBy" autocomplete="off" name="reviewAndApproveBy" class="input-theme pr-8" placeholder="Enter Review & Approved By / Sign" />
                                    <button type="button" class="coa-modal-sig-clear absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-600 hidden text-base font-bold" data-target="#reviewAndApproveBy" title="Clear signature">&times;</button>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label for="prodRemark"
                                    class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea id="prodRemark" autocomplete="off" name="prodRemark"
                                    class="input-theme min-h-[80px]" placeholder="Enter Remark"></textarea>
                            </div>
                        </div>
                        </div>
                        <section id="fgCoaTemplatePanel"
                            class="coa-template-workspace-panel mt-5 hidden overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                            <div class="flex flex-col gap-2 border-b border-slate-200 bg-white px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <h6 id="fgCoaTemplateName" class="m-0 text-sm font-extrabold text-slate-900">
                                        Product FG COA Template
                                    </h6>
                                    <p id="fgCoaTemplateSource" class="m-0 mt-1 text-xs font-medium text-slate-500"></p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div id="fgCoaTemplateSwitchWrapper" class="hidden">
                                        <select id="fgCoaHeaderTemplateSwitch" class="h-8 text-xs font-bold rounded-lg border border-slate-200 bg-white px-2 py-1 text-slate-700 shadow-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-200">
                                            <option value="">Switch Form / Template...</option>
                                        </select>
                                    </div>
                                    <span id="fgCoaTemplateCode"
                                        class="inline-flex w-fit rounded-full bg-emerald-50 px-3 py-1 text-[11px] font-extrabold text-emerald-700 ring-1 ring-emerald-100"></span>
                                </div>
                            </div>
                            <div class="bg-slate-100 p-3 sm:p-5">
                                <div id="fgCoaTemplateDocument" class="overflow-x-auto pb-2"></div>
                            </div>
                        </section>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" data-workflow-action="DRAFT"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl border border-amber-200 bg-amber-50 px-5 text-sm font-bold text-amber-800 shadow-sm transition-colors hover:bg-amber-100 focus:outline-none focus:ring-2 focus:ring-amber-400/30"><i
                                class="ti ti-device-floppy text-lg"></i> Save Draft</button>
                        <button type="submit" data-workflow-action="COMPLETED"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Complete</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="ipCoaEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit FG COA</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update FG COA details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="ipCOAEditForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="ipCOAViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View FG COA</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review record details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="productionPlanViewForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Incoming FG COA Generation Forms modal -->
    <div class="modal fade" id="incomingFgCoaGenerationModal" tabindex="-1"
        aria-labelledby="incomingFgCoaGenerationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-2xl">
                <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                    <div>
                        <h5 id="incomingFgCoaGenerationModalLabel" class="modal-title m-0 text-lg font-extrabold"
                            style="color: var(--appearance-accent, #d97706);">
                            Incoming FG COA Generation Forms
                        </h5>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-500">
                            Select a record to complete its finished goods COA form.
                        </p>
                    </div>
                    <button type="button" class="btn-close mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body bg-white px-6 py-5">
                    <div class="overflow-hidden rounded-xl border border-slate-200">
                        <div class="incoming-coa-table-scroll">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                    <tr>
                                        <th class="w-12 border-b border-slate-200 px-4 py-3">S.No</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Date</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Item Name</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Lot No</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Batch Size</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="incomingFgCoaGenerationTableBody" class="divide-y divide-slate-200 bg-white"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal-footer flex-nowrap border-t border-slate-200 bg-slate-50/80 px-6 py-4">
                    <div class="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <span id="incomingFgCoaGenerationSummary" class="inline-flex items-center gap-2 text-xs font-medium text-slate-500">
                            <i class="ti ti-info-circle text-base"></i>
                            Showing 0 pending FG COA validation requests.
                        </span>
                        <div class="flex items-center gap-1">
                            <button id="incomingFgCoaGenerationPrevious" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Previous page" disabled>
                                <i class="ti ti-chevron-left"></i>
                            </button>
                            <span id="incomingFgCoaGenerationCurrentPage"
                                class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-extrabold"
                                style="color: var(--appearance-accent, #d97706);">1</span>
                            <button id="incomingFgCoaGenerationNext" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Next page" disabled>
                                <i class="ti ti-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';
    let incomingFgCoaGenerationPage = 1;
    const incomingFgCoaGenerationPerPage = 7;
    let incomingFgCoaGenerationRecords = [];
    let pendingFgWorkflowRecord = null;
    let activeFgCoaTemplate = null;
    let fgCoaTemplateRequestToken = 0;
    let activeFgCoaSubmitButton = null;
    let fgEditWorkflowAction = 'COMPLETED';
    const fgCoaWorkflowCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    function escapeIncomingFgCoaText(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function setFgCoaTemplateWorkspaceMode(enabled, record = null) {
        const $modal = $('#addFgCoaModal');
        const $basicFields = $('#fgCoaBasicFields');
        $modal.toggleClass('coa-template-workspace-mode', enabled);
        $basicFields.toggleClass('hidden', enabled);

        if (enabled) {
            $basicFields.find('[required]').attr('data-workflow-required', '1').prop('required', false);
            $('#fgCoaModalIcon').html('<i class="ti ti-file-description text-xl"></i>');
            $('#fgCoaModalTitle').text('FG COA Template');
            $('#fgCoaModalSubtitle').text(
                'Complete the controlled document for ' + String(record?.product_name || 'the selected product') + '.'
            );
        } else {
            $basicFields.find('[data-workflow-required="1"]')
                .prop('required', true)
                .removeAttr('data-workflow-required');
            $('#fgCoaModalIcon').html('<i class="ti ti-plus text-xl"></i>');
            $('#fgCoaModalTitle').text('Add FG COA');
            $('#fgCoaModalSubtitle').text('Create a new FG COA record');
        }
    }

    function selectFgWorkflowDepartment() {
        const $options = $('#prodDepartment option').filter(function () {
            return String($(this).val() || '') !== '';
        });
        if ($options.length === 0) return false;
        const $preferred = $options.filter(function () {
            return /(quality\s*control|qa\s*&\s*qc|\bqc\b)/i.test($(this).text());
        }).first();
        const value = String(($preferred.length ? $preferred : $options.first()).val() || '');
        $('#prodDepartment').val(value).trigger('change');
        return value !== '';
    }

    function resetFgCoaTemplatePanel() {
        activeFgCoaTemplate = null;
        fgCoaTemplateRequestToken++;
        $('#fgCoaTemplateId').val('');
        $('#fgCoaTemplateName').text('Product FG COA Template');
        $('#fgCoaTemplateCode, #fgCoaTemplateSource').text('');
        $('#fgCoaTemplateDocument').empty();
        $('#fgCoaTemplatePanel').addClass('hidden');
    }

    function syncFgCoaTemplateSources() {
        if (!activeFgCoaTemplate) return;
        const $modal = $('#addFgCoaModal');
        const testingDate = String($modal.find('#testingDate').val() || '');
        const testedBy = String($modal.find('#testedBy').val() || '');
        const reviewedBy = String($modal.find('#reviewAndApproveBy').val() || '');
        const remark = String($modal.find('#prodRemark').val() || '');
        $('#fgCoaTemplateDocument [data-coa-source="testing_date"]').text(testingDate || '\u00a0');
        const $analysisByName = $('#fgCoaTemplateDocument [data-coa-field="approval.analysis_by_name"]');
        const $analysisBy = $('#fgCoaTemplateDocument [data-coa-field="approval.analysis_by"]');
        if (testedBy) {
            if (!$analysisByName.val()) $analysisByName.val(testedBy);
            if (!$analysisBy.val() || !$analysisBy.val().startsWith('data:image/')) $analysisBy.val(testedBy);
        } else if ($analysisByName.val()) {
            $modal.find('#testedBy').val($analysisByName.val());
        }

        const $verifiedByName = $('#fgCoaTemplateDocument [data-coa-field="approval.verified_by_name"]');
        const $verifiedBy = $('#fgCoaTemplateDocument [data-coa-field="approval.verified_by"]');
        if (reviewedBy) {
            if (!$verifiedByName.val()) $verifiedByName.val(reviewedBy);
            if (!$verifiedBy.val() || !$verifiedBy.val().startsWith('data:image/')) $verifiedBy.val(reviewedBy);
        } else if ($verifiedByName.val()) {
            $modal.find('#reviewAndApproveBy').val($verifiedByName.val());
        }

        const $comments = $('#fgCoaTemplateDocument [data-coa-field="approval.comments"]');
        if (remark && !$comments.val()) {
            $comments.val(remark);
        } else if (!remark && $comments.val()) {
            $modal.find('#prodRemark').val($comments.val());
        }
    }

    let currentFgCoaRecord = null;

    function loadMappedFgCoaTemplate(record, manualTemplateId = 0, manualFamilyKey = '') {
        const requestToken = ++fgCoaTemplateRequestToken;
        activeFgCoaTemplate = null;
        currentFgCoaRecord = record;
        setFgCoaTemplateWorkspaceMode(true, record);
        $('#addFgCoaGenerateForm button[type="submit"]').prop('disabled', true);
        const showTemplateError = function (message) {
            resetFgCoaTemplatePanel();
            $('#fgCoaTemplatePanel').removeClass('hidden');
            $('#fgCoaTemplateName').text('FG COA template unavailable');
            $('#fgCoaTemplateDocument').text(message);
            toastr.error(message);
        };
        $('#fgCoaTemplateId').val('');
        $('#fgCoaTemplatePanel').removeClass('hidden');
        $('#fgCoaTemplateName').text('Loading product FG COA template...');
        $('#fgCoaTemplateCode, #fgCoaTemplateSource').text('');
        $('#fgCoaTemplateSwitchWrapper').addClass('hidden');
        $('#fgCoaTemplateDocument').html(
            '<div class="flex items-center justify-center gap-2 px-5 py-12 text-sm font-bold text-slate-500">' +
            '<i class="ti ti-loader-2 animate-spin text-xl"></i> Loading controlled document...</div>'
        );

        const postData = {
            openMappedCoaTemplate: 'openMappedCoaTemplate',
            coa_type: 'FG',
            source_id: record.id,
            testing_date: $('#addFgCoaModal #testingDate').val(),
            csrf_token: fgCoaWorkflowCsrf
        };
        if (manualTemplateId > 0 && manualFamilyKey) {
            postData.template_id = manualTemplateId;
            postData.family_key = manualFamilyKey;
            postData.save_mapping = '1';
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: postData,
            success: function (response) {
                if (requestToken !== fgCoaTemplateRequestToken) return;
                if (response.status !== 'success') {
                    showTemplateError(response.message || 'Unable to load the product FG COA template.');
                    return;
                }
                const data = response.data || {};
                if (!data.has_template) {
                    renderFgCoaTemplatePicker(record, data.available_templates || []);
                    return;
                }
                activeFgCoaTemplate = data;
                $('#addFgCoaGenerateForm button[type="submit"]').prop('disabled', false);
                $('#fgCoaTemplateId').val(data.template_id || '');
                $('#fgCoaTemplateName').text(data.template_name || 'Product FG COA Template');
                $('#fgCoaTemplateCode').text(data.template_code || '');
                $('#fgCoaTemplateSource').text(
                    (data.product_name || record.product_name || '') +
                    (data.source_document ? ' • Source: ' + data.source_document : '')
                );
                $('#fgCoaTemplateDocument').html(data.rendered_html || '');
                setupFgCoaHeaderTemplateSwitch(record, data);
                syncFgCoaTemplateSources();
            },
            error: function (xhr) {
                if (requestToken !== fgCoaTemplateRequestToken) return;
                showTemplateError(xhr.responseJSON?.message || 'Unable to load the product FG COA template.');
            }
        });
    }

    function renderFgCoaTemplatePicker(record, availableTemplates = []) {
        $('#fgCoaTemplatePanel').removeClass('hidden');
        $('#fgCoaTemplateName').text('Select FG COA Template / Form');
        $('#fgCoaTemplateCode').text('Select Form');
        $('#fgCoaTemplateSource').text(
            'No default template is mapped for ' + (record.product_name || 'this product') + '. Please choose a form below.'
        );
        $('#addFgCoaGenerateForm button[type="submit"]').prop('disabled', true);
        $('#fgCoaTemplateSwitchWrapper').addClass('hidden');

        let selectOptionsHtml = '<option value="">-- Choose FG COA Template / Form --</option>';
        const prodNameLower = String(record.product_name || '').toLowerCase().trim();
        let autoSelectedVal = '';

        availableTemplates.forEach(template => {
            const families = Array.isArray(template.families) ? template.families : [];
            if (families.length === 0) return;
            selectOptionsHtml += `<optgroup label="${escapeIncomingFgCoaText(template.template_name)} (${escapeIncomingFgCoaText(template.template_code)})">`;
            families.forEach(fam => {
                const optVal = `${template.id}:${fam.family_key}`;
                const famName = fam.product_name || fam.family_key;
                const famLower = famName.toLowerCase();
                const keyLower = fam.family_key.toLowerCase();
                
                let isMatch = false;
                if (prodNameLower && (prodNameLower.includes(keyLower) || prodNameLower.includes(famLower) || famLower.includes(prodNameLower.split(' ')[0]))) {
                    isMatch = true;
                    if (!autoSelectedVal) autoSelectedVal = optVal;
                }
                selectOptionsHtml += `<option value="${optVal}">${escapeIncomingFgCoaText(famName)}</option>`;
            });
            selectOptionsHtml += `</optgroup>`;
        });

        const pickerHtml = `
            <div class="rounded-2xl border border-amber-200 bg-amber-50/50 p-6 shadow-sm my-2">
                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 border border-amber-300 shadow-sm">
                        <i class="ti ti-template text-2xl"></i>
                    </div>
                    <div class="flex-grow min-w-0">
                        <h6 class="m-0 text-sm font-extrabold text-slate-800">Select FG COA Template / Form</h6>
                        <p class="m-0 mt-0.5 text-xs text-slate-600">Select the template form to load and complete the controlled FG COA document for <strong>${escapeIncomingFgCoaText(record.product_name)}</strong>.</p>
                        
                        <div class="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                            <div class="flex-grow">
                                <label for="fgCoaManualTemplateSelect" class="block text-xs font-bold text-slate-700 mb-1">Select Form / Template</label>
                                <select id="fgCoaManualTemplateSelect" class="w-full h-10 text-xs font-bold rounded-xl border border-slate-200 bg-white px-3 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200">
                                    ${selectOptionsHtml}
                                </select>
                            </div>
                            <div class="sm:self-end">
                                <button type="button" id="fgCoaApplyTemplateBtn" class="inline-flex h-10 w-full sm:w-auto shrink-0 items-center justify-center gap-2 rounded-xl bg-emerald-700 px-6 text-xs font-bold text-white shadow-sm hover:bg-emerald-800 focus:outline-none transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
                                    <i class="ti ti-file-check text-sm"></i> Load Form
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#fgCoaTemplateDocument').html(pickerHtml);

        if (autoSelectedVal) {
            $('#fgCoaManualTemplateSelect').val(autoSelectedVal);
        }
        $('#fgCoaApplyTemplateBtn').prop('disabled', !$('#fgCoaManualTemplateSelect').val());
    }

    function setupFgCoaHeaderTemplateSwitch(record, currentData) {
        const availableTemplates = Array.isArray(currentData.available_templates) ? currentData.available_templates : [];
        if (availableTemplates.length === 0) {
            $('#fgCoaTemplateSwitchWrapper').addClass('hidden');
            return;
        }

        let switchOptionsHtml = '<option value="">Switch Form / Template...</option>';
        const currentVal = `${currentData.template_id}:${currentData.family_key}`;

        availableTemplates.forEach(template => {
            const families = Array.isArray(template.families) ? template.families : [];
            if (families.length === 0) return;
            switchOptionsHtml += `<optgroup label="${escapeIncomingFgCoaText(template.template_name)}">`;
            families.forEach(fam => {
                const optVal = `${template.id}:${fam.family_key}`;
                const famName = fam.product_name || fam.family_key;
                const isSelected = optVal === currentVal;
                switchOptionsHtml += `<option value="${optVal}" ${isSelected ? 'selected' : ''}>${isSelected ? '✓ ' : ''}${escapeIncomingFgCoaText(famName)}</option>`;
            });
            switchOptionsHtml += `</optgroup>`;
        });

        $('#fgCoaHeaderTemplateSwitch').html(switchOptionsHtml);
        $('#fgCoaTemplateSwitchWrapper').removeClass('hidden');
    }

    function openFgCoaDraft(recordId) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                openSavedCoaTemplate: 'openSavedCoaTemplate',
                coa_type: 'FG',
                record_id: recordId,
                csrf_token: fgCoaWorkflowCsrf
            },
            success: function (response) {
                if (response.status !== 'success') {
                    toastr.error(response.message || 'Unable to open the FG COA draft.');
                    return;
                }
                const data = response.data || {};
                const record = data.record || {};
                const form = document.getElementById('addFgCoaGenerateForm');
                form.reset();
                $('#fgCoaRecordId').val(record.id || recordId);
                $('#fgWorkflowSourceIpId').val('');
                $('#fgCoaWorkflowAction').val('DRAFT');
                $('#fgProductId').val(String(record.product_id || '')).trigger('change');
                $('#fgLiveStockId').append(new Option(record.batch_number || 'Selected batch', String(record.live_stock_id || ''), true, true)).trigger('change');
                $('#prodDepartment').val(String(record.dept_id || '')).trigger('change');
                $('#productName').val(record.product_name || '').prop('readonly', true);
                $('#lotNoBatchNo').val(record.batch_number || '').prop('readonly', true);
                $('#prodBatchSize').val(record.batch_size || '').prop('readonly', true);
                $('#prodBatchSizeUnit').val(String(record.batch_size_unit || '')).trigger('change');
                $('#testingDate').val(record.test_date || '');
                $('#testedBy').val(record.tested_by || '');
                $('#reviewAndApproveBy').val(record.review_approved_by || '');
                $('#prodRemark').val(record.remark || '');
                activeFgCoaTemplate = data;
                $('#fgCoaTemplateId').val(data.template_id || '');
                $('#fgCoaTemplateName').text(data.template_name || 'Product FG COA Template');
                $('#fgCoaTemplateCode').text(data.template_code || '');
                $('#fgCoaTemplateSource').text(
                    (data.product_name || record.product_name || '') +
                    (data.source_document ? ' • Source: ' + data.source_document : '')
                );
                $('#fgCoaTemplateDocument').html(data.rendered_html || '');
                $('#fgCoaTemplatePanel').removeClass('hidden');
                setFgCoaTemplateWorkspaceMode(true, record);
                $('#addFgCoaGenerateForm button[type="submit"]').prop('disabled', false);
                $('#fgCoaModalTitle').text('Continue FG COA Draft');
                $('#addFgCoaModal').modal('show');
                syncFgCoaTemplateSources();
            },
            error: function (xhr) {
                toastr.error(xhr.responseJSON?.message || 'Unable to open the FG COA draft.');
            }
        });
    }

    function collectFgCoaTemplatePayload(requireComplete = true) {
        if (!activeFgCoaTemplate) return null;
        syncFgCoaTemplateSources();
        const fields = {};
        let firstInvalid = null;
        $('#fgCoaTemplateDocument [data-coa-field]').each(function () {
            const $field = $(this);
            const key = String($field.data('coa-field') || '');
            if (!key) return;
            if ($field.is(':radio') && !$field.is(':checked')) return;
            const value = String($field.val() || '').trim();
            fields[key] = value;
            if (requireComplete && $field.attr('data-coa-required') === '1' && !value && !firstInvalid) {
                firstInvalid = this;
            }
        });
        if (requireComplete && !fields['approval.decision']) {
            firstInvalid = firstInvalid || $('#fgCoaTemplateDocument [data-coa-field="approval.decision"]').get(0);
        }
        if (firstInvalid) {
            firstInvalid.focus();
            firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
            toastr.error('Complete every required field in the FG COA document.');
            return false;
        }
        return { schema_version: 1, fields: fields };
    }

    function loadIncomingFgCoaWorkflow(resetPage = true, silent = false) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadIncomingFgCoaWorkflow: 'loadIncomingFgCoaWorkflow',
                csrf_token: fgCoaWorkflowCsrf
            },
            success: function (response) {
                if (response.status !== 'success') {
                    if (!silent) toastr.error(response.message || 'Unable to load incoming FG COA forms.');
                    return;
                }
                incomingFgCoaGenerationRecords = response.data?.records || [];
                if (resetPage) incomingFgCoaGenerationPage = 1;
                renderIncomingFgCoaGenerationRecords();
            },
            error: function (xhr) {
                if (silent) return;
                toastr.error(xhr.responseJSON?.message || 'Unable to load incoming FG COA forms.');
                incomingFgCoaGenerationRecords = [];
                renderIncomingFgCoaGenerationRecords();
            }
        });
    }

    function refreshIncomingFgCoaWorkflow() {
        if (!document.hidden) loadIncomingFgCoaWorkflow(false, true);
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) refreshIncomingFgCoaWorkflow();
    });

    function renderIncomingFgCoaGenerationRecords() {
        const totalRows = incomingFgCoaGenerationRecords.length;
        const totalPages = Math.max(1, Math.ceil(totalRows / incomingFgCoaGenerationPerPage));
        incomingFgCoaGenerationPage = Math.min(Math.max(1, incomingFgCoaGenerationPage), totalPages);
        const offset = (incomingFgCoaGenerationPage - 1) * incomingFgCoaGenerationPerPage;
        const visibleRows = incomingFgCoaGenerationRecords.slice(offset, offset + incomingFgCoaGenerationPerPage);

        if (visibleRows.length === 0) {
            $('#incomingFgCoaGenerationTableBody').html(`<tr>
                <td colspan="6" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">
                    No incoming FG COA generation forms available.
                </td>
            </tr>`);
        } else {
            $('#incomingFgCoaGenerationTableBody').html(visibleRows.map(function (record, index) {
                return `<tr>
                    <td class="px-4 py-2 align-middle whitespace-nowrap">${String(offset + index + 1).padStart(2, '0')}</td>
                    <td class="px-4 py-2 align-middle whitespace-nowrap">${escapeIncomingFgCoaText(record.timestamp)}</td>
                    <td class="incoming-coa-item-cell px-4 py-2 align-middle">
                        <div class="flex items-center gap-2">
                            <span class="incoming-coa-item-dot h-1.5 w-1.5 rounded-full" style="background-color: var(--appearance-accent, #d97706);"></span>
                            <span class="incoming-coa-item-name">${escapeIncomingFgCoaText(record.product_name)}</span>
                        </div>
                        <div class="incoming-coa-item-meta flex items-center gap-2">
                            <span class="badge bg-label-secondary" style="font-size: 9px; padding: 0.25rem 0.4rem;">FG COA</span>
                            ${record.is_locked ? '<span class="badge bg-label-warning text-[9px] px-1.5 py-0.5"><i class="ti ti-lock text-[10px]"></i> SA Pending</span>' : ''}
                        </div>
                    </td>
                    <td class="px-4 py-2 align-middle whitespace-nowrap">${escapeIncomingFgCoaText(record.lot_number)}</td>
                    <td class="px-4 py-2 align-middle whitespace-nowrap">${escapeIncomingFgCoaText(record.batch_size)}</td>
                    <td class="px-4 py-2 align-middle whitespace-nowrap text-center">
                        ${record.is_locked ? `
                            <button type="button" class="btn btn-sm btn-secondary opacity-60 cursor-not-allowed" disabled title="Locked: Sample Advice (SA) pending QA approval">
                                <i class="ti ti-lock text-xs me-1"></i> Locked
                            </button>
                        ` : `
                            <button type="button"
                                class="incoming-fg-coa-fill-form btn btn-sm btn-primary"
                                data-id="${escapeIncomingFgCoaText(record.id)}">
                                Fill Form
                            </button>
                        `}
                    </td>
                </tr>`;
            }).join(''));
        }

        $('#incomingFgCoaGenerationSummary').html(
            `<i class="ti ti-info-circle text-base"></i>Showing ${totalRows} pending FG COA validation requests.`
        );
        $('#incomingFgCoaGenerationCurrentPage').text(incomingFgCoaGenerationPage);
        $('#incomingFgCoaGenerationPrevious').prop('disabled', incomingFgCoaGenerationPage <= 1);
        $('#incomingFgCoaGenerationNext').prop('disabled', incomingFgCoaGenerationPage >= totalPages);
        $('#incomingFgCoaGenerationCount').text(totalRows);
    }
    const initialFgCoaId = <?= isset($_GET['view_id']) && $_GET['view_id'] !== '' ? (int) base64_decrypt($_GET['view_id']) : 0 ?>;

    function openFgCoaDetail(id) {
        if (!id) return;
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { viewFgCoaRecord: 'viewFgCoaRecord', id: id },
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#ipCOAViewModal').modal('show');
                    $('#productionPlanViewForm').find('.modal-body').html(res.data);
                } else {
                    toastr.error(res.message || 'Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#prodBatchSizeUnit").html(optionsHtml);
                $("#prodBatchSizeUnit").select2({ dropdownParent: $('#addFgCoaModal') });
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function (response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                departmentOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#prodDepartment").html(optionsHtml);
                $("#prodDepartment").select2({ dropdownParent: $('#addFgCoaModal') });
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadFgProductsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadFgCoaProducts: '1' },
            success: function (response) {
                const productSelect = $('#fgProductId').empty();
                productSelect.append(new Option('---Select----', ''));
                (response.items || []).forEach(function (product) {
                    productSelect.append(new Option(product.product_name, product.id));
                });
                productSelect.trigger('change.select2');
            },
            error: function () {
                toastr.error('Unable to load finished goods products.');
            }
        });
    }

    function loadFgInventoryBatches(productId) {
        $('#fgLiveStockId').html('<option value="">---Loading----</option>').trigger('change.select2');
        if (!productId) {
            $('#fgLiveStockId').html('<option value="">---Select Product First----</option>').trigger('change.select2');
            return;
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadFgCoaInventoryBatches: '1', productId: productId },
            success: function (response) {
                const batchSelect = $('#fgLiveStockId').empty();
                batchSelect.append(new Option('---Select----', ''));
                (response.items || []).forEach(function (batch) {
                    const option = new Option(batch.label, batch.id);
                    $(option).attr({
                        'data-batch': batch.batch_number,
                        'data-size': batch.batch_size,
                        'data-unit': batch.batch_size_unit
                    });
                    batchSelect.append(option);
                });
                batchSelect.trigger('change.select2');
                if (pendingFgWorkflowRecord) {
                    const matchingOption = batchSelect.find('option').filter(function () {
                        return String($(this).data('batch') || '').toLowerCase()
                            === String(pendingFgWorkflowRecord.lot_number || '').toLowerCase();
                    }).first();
                    if (matchingOption.length) {
                        batchSelect.val(matchingOption.val()).trigger('change');
                    } else {
                        $('#lotNoBatchNo').val(pendingFgWorkflowRecord.lot_number || '');
                        $('#prodBatchSize').val(pendingFgWorkflowRecord.batch_size_value || '');
                        if (pendingFgWorkflowRecord.batch_unit_id) {
                            $('#prodBatchSizeUnit').val(pendingFgWorkflowRecord.batch_unit_id).trigger('change');
                        }
                    }
                }
            },
            error: function () {
                $('#fgLiveStockId').html('<option value="">---Unable to Load----</option>').trigger('change.select2');
                toastr.error('Unable to load inventory batches.');
            }
        });
    }

    function loadFgCoaGenerationTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const workflowStatus = $('#fgCoaWorkflowFilter').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadFgCoaGenerationRecords: 'loadFgCoaGenerationRecords',
                page: page,
                per_page: perPage,
                search: search,
                workflow_status: workflowStatus,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#fgTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const shownThrough = totalRows ? Math.min(page * Number(perPage), totalRows) : 0;

            },
            error: function () {
                $('#fgTableBody').html('<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    $(document).ready(function () {
        loadFgCoaGenerationTable();
        loadIncomingFgCoaWorkflow();
        loadStandardUnit();
        loadDepartmentsList();
        loadFgProductsList();
        $('#fgProductId, #fgLiveStockId').select2({ dropdownParent: $('#addFgCoaModal'), width: '100%' });
        if (initialFgCoaId > 0) {
            openFgCoaDetail(initialFgCoaId);
        }
        $('#searchUsers').on('input', function () {
            loadFgCoaGenerationTable(1);
        });
        $('#fgCoaWorkflowFilter').on('change', function () {
            loadFgCoaGenerationTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadFgCoaGenerationTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.fgcoa-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#fgcoaPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $(document).on('change', '#fgCoaManualTemplateSelect', function () {
            const val = $(this).val();
            $('#fgCoaApplyTemplateBtn').prop('disabled', !val);
        });

        $(document).on('click', '#fgCoaApplyTemplateBtn', function () {
            const val = $('#fgCoaManualTemplateSelect').val();
            if (!val || !currentFgCoaRecord) return;
            const parts = val.split(':');
            const templateId = parseInt(parts[0], 10);
            const familyKey = parts[1] || '';
            if (templateId && familyKey) {
                loadMappedFgCoaTemplate(currentFgCoaRecord, templateId, familyKey);
            }
        });

        $(document).on('change', '#fgCoaHeaderTemplateSwitch', function () {
            const val = $(this).val();
            if (!val || !currentFgCoaRecord) return;
            const parts = val.split(':');
            const templateId = parseInt(parts[0], 10);
            const familyKey = parts[1] || '';
            if (templateId && familyKey) {
                loadMappedFgCoaTemplate(currentFgCoaRecord, templateId, familyKey);
            }
        });

        $('#addFgCoaModal').on('show.bs.modal', function () {
            if (!$('#testingDate').val()) {
                $('#testingDate').val(new Date().toISOString().slice(0, 10));
            }
        });

        $('#addFgCoaModal').on('hidden.bs.modal', function () {
            setFgCoaTemplateWorkspaceMode(false);
            $('#addFgCoaGenerateForm button[type="submit"]').prop('disabled', false);
            $('#addFgCoaGenerateForm')[0].reset();
            $('#fgWorkflowSourceIpId').val('');
            $('#fgCoaRecordId').val('');
            $('#fgCoaWorkflowAction').val('COMPLETED');
            resetFgCoaTemplatePanel();
            pendingFgWorkflowRecord = null;
            $('#productName, #lotNoBatchNo, #prodBatchSize').prop('readonly', false);
            $('#prodDepartment').val(null).trigger('change');
            $('#prodBatchSizeUnit').val(null).trigger('change');
            $('#fgProductId').val(null).trigger('change');
            $('#fgLiveStockId').html('<option value="">---Select Product First----</option>').trigger('change');
        });

        $('#fgProductId').on('change', function () {
            const selectedProductName = $(this).find(':selected').text();
            $('#productName').val($(this).val() ? selectedProductName : '');
            $('#lotNoBatchNo').val('');
            $('#prodBatchSize').val('');
            $('#prodBatchSizeUnit').val(null).trigger('change');
            loadFgInventoryBatches($(this).val());
        });

        $('#fgLiveStockId').on('change', function () {
            const selected = $(this).find(':selected');
            $('#lotNoBatchNo').val(selected.data('batch') || '');
            $('#prodBatchSize').val(selected.data('size') || '');
            $('#prodBatchSizeUnit').val(selected.data('unit') || '').trigger('change');
        });

        $('#addFgCoaGenerateForm button[type="submit"][data-workflow-action]').on('click', function () {
            activeFgCoaSubmitButton = this;
            $('#fgCoaWorkflowAction').val(String($(this).data('workflow-action') || 'COMPLETED'));
        });

        $('#addFgCoaGenerateForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addFgCoaGenerateForm');
            const formData = new FormData(form);
            const workflowSourceId = String($('#fgWorkflowSourceIpId').val() || '');
            const recordId = String($('#fgCoaRecordId').val() || '');
            const workflowAction = String($('#fgCoaWorkflowAction').val() || 'COMPLETED').toUpperCase();
            const templatePayload = collectFgCoaTemplatePayload(workflowAction === 'COMPLETED');
            if (templatePayload === false) return;
            formData.append('coa_workflow_action', workflowAction);
            formData.append('csrf_token', fgCoaWorkflowCsrf);
            if (recordId) {
                formData.append('updateFGCoaRecord', 'updateFGCoaRecord');
                formData.append('ipCoaId', recordId);
                if (templatePayload) {
                    formData.append('coa_template_id', String($('#fgCoaTemplateId').val() || ''));
                    formData.append('coa_family_key', String(activeFgCoaTemplate?.family_key || activeFgCoaTemplate?.profile?.family_key || ''));
                    formData.append('coa_form_payload', JSON.stringify(templatePayload));
                }
            } else if (workflowSourceId) {
                formData.append('createFgCoaFromIp', 'createFgCoaFromIp');
                formData.append('source_ip_coa_id', workflowSourceId);
                if (templatePayload) {
                    formData.append('coa_template_id', String($('#fgCoaTemplateId').val() || ''));
                    formData.append('coa_family_key', String(activeFgCoaTemplate?.family_key || activeFgCoaTemplate?.profile?.family_key || ''));
                    formData.append('coa_form_payload', JSON.stringify(templatePayload));
                }
            } else {
                formData.append('addFgCoaRecord', 'addFgCoaRecord');
            }
            const $submitButton = $(activeFgCoaSubmitButton || this.querySelector('button[data-workflow-action="COMPLETED"]'));
            const originalHtml = $submitButton.html();
            $(this).find('button[type="submit"]').prop('disabled', true);
            $submitButton.prop('disabled', true)
                .html('<i class="ti ti-loader-2 animate-spin text-lg"></i> Submitting...');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#addFgCoaModal').modal('hide');
                        $('#addFgCoaGenerateForm')[0].reset();
                        loadFgCoaGenerationTable();
                        loadIncomingFgCoaWorkflow();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
                },
                complete: function () {
                    $('#addFgCoaGenerateForm button[type="submit"]').prop('disabled', false);
                    $submitButton.prop('disabled', false).html(originalHtml);
                    activeFgCoaSubmitButton = null;
                }
            });
        });
    });

    $(document).on('click', '.ipCoaDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'mr-3 inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteFgCoaRecord: 'deleteFgCoaRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadFgCoaGenerationTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                            }
                        });
                    }
                });
            }
        });
    });


    $(document).on('click', '.ipCOAEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#ipCOAEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchFgCOARecord: 'fetchFgCOARecord', id: id },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#ipCoaEditModal').modal('show');
                        $('#ipCOAEditForm').find('.modal-body').html(res.data);
                        $('#ipCOAEditForm .select2').select2({ dropdownParent: $('#ipCoaEditModal') });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '#ipCOAEditForm button[type="submit"][data-workflow-action]', function () {
        fgEditWorkflowAction = String($(this).data('workflow-action') || 'COMPLETED');
    });

    $('#ipCOAEditForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('ipCOAEditForm');
        const formData = new FormData(form);
        formData.append('updateFGCoaRecord', 'updateFGCoaRecord');
        formData.append('coa_workflow_action', fgEditWorkflowAction);
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#ipCoaEditModal').modal('hide');
                    $('#ipCOAEditForm').find('modal-body').html();
                    loadFgCoaGenerationTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.ipCOAViewModalBtn', function () {
        openFgCoaDetail($(this).data('id'));
    });

    $(document).on('click', '.coa-record-row', function (event) {
        if ($(event.target).closest('button, a, input, select, textarea').length) return;
        $('.ipCOAViewModalBtn[data-id="' + Number($(this).data('id') || 0) + '"]').first().trigger('click');
    });

    $(document).on('keydown', '.coa-record-row', function (event) {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadFgCoaGenerationTable(1);
    });

    $(document).on('click keydown', '#incomingFgCoaGenerationWidget', function (event) {
        if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
        if (event.type === 'keydown') event.preventDefault();
        incomingFgCoaGenerationPage = 1;
        renderIncomingFgCoaGenerationRecords();
        $('#incomingFgCoaGenerationModal').modal('show');
    });

    $(document).on('click', '#incomingFgCoaGenerationPrevious', function () {
        if (incomingFgCoaGenerationPage > 1) {
            incomingFgCoaGenerationPage--;
            renderIncomingFgCoaGenerationRecords();
        }
    });

    $(document).on('click', '#incomingFgCoaGenerationNext', function () {
        incomingFgCoaGenerationPage++;
        renderIncomingFgCoaGenerationRecords();
    });

    function openIncomingFgCoaForm(record, attempt = 0) {
        let productOption = $('#fgProductId option[value="' + String(record.product_id || '') + '"]');
        const referenceDataReady = $('#prodDepartment option').length > 1
            && $('#prodBatchSizeUnit option').length > 1;
        if ((productOption.length === 0 || !referenceDataReady) && attempt < 20) {
            setTimeout(function () {
                openIncomingFgCoaForm(record, attempt + 1);
            }, 150);
            return;
        }
        if (productOption.length === 0) {
            const sourceProductId = String(record.product_id || '');
            if (!sourceProductId) {
                toastr.error('No product is linked to this IP COA.');
                return;
            }
            const fallbackOption = new Option(
                record.product_name || ('Product #' + sourceProductId),
                sourceProductId
            );
            $(fallbackOption).attr('data-workflow-source', '1');
            $('#fgProductId').append(fallbackOption).trigger('change.select2');
            productOption = $(fallbackOption);
        }
        if (!referenceDataReady) {
            toastr.error('The FG COA workspace could not load its required reference data.');
            return;
        }
        $('#addFgCoaGenerateForm')[0].reset();
        resetFgCoaTemplatePanel();
        $('#fgWorkflowSourceIpId').val(record.id);
        pendingFgWorkflowRecord = record;
        $('#lotNoBatchNo').val(record.lot_number || '');
        $('#prodBatchSize').val(record.batch_size_value || '');
        if (record.batch_unit_id) {
            $('#prodBatchSizeUnit').val(record.batch_unit_id).trigger('change');
        }
        $('#fgProductId').val(String(record.product_id)).trigger('change');
        $('#testingDate').val(record.testing_date || new Date().toISOString().slice(0, 10));
        $('#incomingFgCoaGenerationModal').modal('hide');
        $('#addFgCoaModal').modal('show');
        loadMappedFgCoaTemplate(record);
    }

    $(document).on('input change', '#addFgCoaModal #testingDate, #addFgCoaModal #testedBy, #addFgCoaModal #reviewAndApproveBy, #addFgCoaModal #prodRemark', function () {
        syncFgCoaTemplateSources();
    });

    $(document).on('input change', '#fgCoaTemplateDocument [data-coa-field="approval.analysis_by_name"]', function () {
        $('#addFgCoaModal #testedBy').val($(this).val());
    });

    $(document).on('input change', '#fgCoaTemplateDocument [data-coa-field="approval.verified_by_name"]', function () {
        $('#addFgCoaModal #reviewAndApproveBy').val($(this).val());
    });

    $(document).on('input change', '#fgCoaTemplateDocument [data-coa-field="approval.comments"]', function () {
        $('#addFgCoaModal #prodRemark').val($(this).val());
    });

    $(document).on('click', '.incoming-fg-coa-fill-form', function () {
        const recordId = String($(this).data('id') || '');
        const record = incomingFgCoaGenerationRecords.find(function (item) {
            return String(item.id) === recordId;
        });
        if (record) openIncomingFgCoaForm(record);
    });

    $(document).on('click', '.coaDraftContinueBtn', function () {
        openFgCoaDraft(String($(this).data('id') || ''));
    });

    $(document).on('change', '.coa-modal-sig-upload', function () {
        const file = this.files && this.files[0];
        if (!file) return;

        const maxSizeBytes = 250 * 1024;
        if (file.size > maxSizeBytes) {
            toastr.error('Signed image size must not exceed 250 KB.');
            $(this).val('');
            return;
        }

        if (!file.type.match(/^image\//i)) {
            toastr.error('Please upload a valid image file (PNG, JPG, JPEG, WEBP).');
            $(this).val('');
            return;
        }

        const targetSelector = $(this).data('target');
        const reader = new FileReader();
        reader.onload = function (e) {
            $(targetSelector).val(e.target.result).trigger('change');
            $(`button.coa-modal-sig-clear[data-target="${targetSelector}"]`).removeClass('hidden');
        };
        reader.readAsDataURL(file);
        $(this).val('');
    });

    $(document).on('click', '.coa-modal-sig-clear', function () {
        const targetSelector = $(this).data('target');
        $(targetSelector).val('').trigger('change').trigger('focus');
        $(this).addClass('hidden');
    });

    $(document).on('input change', '.coa-v1-sig-text', function () {
        const $widget = $(this).closest('.coa-v1-sig-widget');
        const textVal = $(this).val();
        const $sigVal = $widget.find('.coa-v1-sig-value');
        if (!$sigVal.val() || !$sigVal.val().startsWith('data:image/')) {
            $sigVal.val(textVal);
        }
        const fieldKey = $(this).data('coa-field');
        if (fieldKey === 'approval.analysis_by_name' || $widget.find('[data-coa-field="approval.analysis_by"]').length) {
            $('#addIpCoaModal #testedBy, #addFgCoaModal #testedBy').val(textVal);
        }
        if (fieldKey === 'approval.verified_by_name' || $widget.find('[data-coa-field="approval.verified_by"]').length) {
            $('#addIpCoaModal #reviewAndApproveBy, #addFgCoaModal #reviewAndApproveBy').val(textVal);
        }
    });

    $(document).on('change', '.coa-v1-sig-file-input', function () {
        const file = this.files && this.files[0];
        if (!file) return;

        const maxSizeBytes = 250 * 1024;
        if (file.size > maxSizeBytes) {
            toastr.error('Signed image size must not exceed 250 KB.');
            $(this).val('');
            return;
        }

        if (!file.type.match(/^image\//i)) {
            toastr.error('Please upload a valid image file (PNG, JPG, JPEG, WEBP).');
            $(this).val('');
            return;
        }

        const $widget = $(this).closest('.coa-v1-sig-widget');
        const reader = new FileReader();
        reader.onload = function (e) {
            const dataUri = e.target.result;
            $widget.find('.coa-v1-sig-value').val(dataUri);
            let $img = $widget.find('.coa-v1-sig-preview-img');
            if (!$img.length) {
                $img = $('<img class="coa-v1-sig-preview-img" alt="Signature">');
                $widget.find('.coa-v1-sig-preview').prepend($img);
            }
            $img.attr('src', dataUri);
            $widget.find('.coa-v1-sig-preview').show();
        };
        reader.readAsDataURL(file);
        $(this).val('');
    });

    $(document).on('click', '.coa-v1-sig-clear-btn', function () {
        const $widget = $(this).closest('.coa-v1-sig-widget');
        const textVal = $widget.find('.coa-v1-sig-text').val() || '';
        $widget.find('.coa-v1-sig-value').val(textVal);
        $widget.find('.coa-v1-sig-preview-img').attr('src', '');
        $widget.find('.coa-v1-sig-preview').hide();
        $widget.find('.coa-v1-sig-text').trigger('focus');
    });
</script>
<?php endSection(); ?>
