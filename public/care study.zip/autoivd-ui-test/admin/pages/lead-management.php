<?php
global $conn;
$currentRoleId = (int) ($_SESSION['role_id'] ?? 0);
$canAddLead = roleHasPermission($currentRoleId, 'crm_lead_add');
$canEditLead = roleHasPermission($currentRoleId, 'crm_lead_edit');
$canDeleteLead = roleHasPermission($currentRoleId, 'crm_lead_delete');
$canAcceptLead = roleHasPermission($currentRoleId, 'crm_lead_accept');
$canRejectLead = roleHasPermission($currentRoleId, 'crm_lead_reject');
$canAssignLead = roleHasPermission($currentRoleId, 'crm_lead_assign');

// Preload products for manual lead create/edit form
$allProducts = [];
$prodQ = $conn->query("SELECT id, product_name, product_code FROM products WHERE status = 1 AND deleted_at IS NULL ORDER BY product_name ASC");
if ($prodQ) {
    while ($pRow = $prodQ->fetch_assoc()) {
        $allProducts[] = $pRow;
    }
}

// Preload active salespersons
$allSalespersons = [];
$spQ = $conn->query("SELECT id, salesperson_name, salesperson_code FROM salesperson_masters WHERE status = 1 AND deleted_at IS NULL ORDER BY salesperson_name ASC");
if ($spQ) {
    while ($spRow = $spQ->fetch_assoc()) {
        $allSalespersons[] = $spRow;
    }
}
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">

    <!-- Top Alert Box: New Incoming Leads (Section 2.2) -->
    <div id="newLeadsBanner" class="mb-6 relative cursor-pointer" onclick="openNewLeadsModal()">
        <div class="rounded-2xl border p-4 pr-10 shadow-sm relative transition-all hover:shadow-md" style="background-color: #f0fdf4; border-color: #bbf7d0;">
            <button type="button" class="text-slate-500 hover:text-slate-800" style="position: absolute; right: 1rem; top: 1rem; z-index: 10;" onclick="event.stopPropagation(); $('#newLeadsBanner').addClass('hidden');">
                <i class="ti ti-x text-lg"></i>
            </button>
            <div class="flex items-start gap-3" style="display: flex; align-items: flex-start; gap: 0.75rem;">
                <div class="mt-0.5 shrink-0 items-center justify-center rounded-full text-white" style="display: flex; height: 1.75rem; width: 1.75rem; background-color: #166534;">
                    <i class="ti ti-user-plus" style="font-size: 15px; line-height: 1;"></i>
                </div>
                <div class="flex flex-col items-start" style="display: flex; flex-direction: column;">
                    <h3 class="font-bold leading-tight" style="font-size: 16px; color: #166534; margin: 0;">New Incoming Leads Alert</h3>
                    <p id="newLeadsBannerText" class="font-medium text-slate-800 mt-1 mb-2.5" style="font-size: 13px;">
                        <span id="newLeadsCountBadge" class="font-extrabold text-emerald-800">0</span> incoming leads captured from Quiz, WhatsApp, meeting requests, and website forms require review.
                    </p>
                    <button type="button" class="inline-flex items-center justify-center rounded-xl border border-emerald-300 bg-white px-3.5 py-1.5 font-bold text-emerald-800 text-xs shadow-sm hover:bg-emerald-50 transition cursor-pointer" onclick="event.stopPropagation(); openNewLeadsModal();">
                        <span id="newLeadsBannerBtnText"><i class="ti ti-checklist mr-1.5 text-sm text-emerald-700"></i> Review Incoming Leads Queue</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Page Header -->
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                Lead Management
            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Capture, qualify, assign, and track lifecycle of sales leads
            </p>
        </div>
    </div>

    <!-- KPI Summary Metric Widgets -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <!-- Card 1: Total Leads -->
        <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm flex items-center justify-between cursor-pointer hover:bg-slate-50/80 hover:border-slate-300 hover:shadow-md transition-all" onclick="applyLeadFilter('status', 'all', 'All Statuses')" title="Click to view all leads">
            <div>
                <span class="text-xs font-bold uppercase tracking-wider text-slate-500">Total Leads</span>
                <h3 class="text-2xl font-extrabold text-slate-900 mt-1" id="statTotalLeads">0</h3>
                <span class="text-[11px] text-slate-400 font-medium">In CRM pipeline • Click to view all</span>
            </div>
            <div class="h-12 w-12 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center text-xl">
                <i class="ti ti-users"></i>
            </div>
        </div>
        
        <!-- Card 2: New / Incoming -->
        <div class="rounded-2xl border border-emerald-200 bg-emerald-50/40 p-4 shadow-sm flex items-center justify-between cursor-pointer hover:bg-emerald-50/70 transition" onclick="openNewLeadsModal()">
            <div>
                <span class="text-xs font-bold uppercase tracking-wider text-emerald-800">Incoming Queue</span>
                <h3 class="text-2xl font-extrabold text-emerald-800 mt-1" id="statNewLeads">0</h3>
                <span class="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
                    <i class="ti ti-bell-ringing text-xs"></i> Pending Review
                </span>
            </div>
            <div class="h-12 w-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-xl">
                <i class="ti ti-user-plus"></i>
            </div>
        </div>

        <!-- Card 3: Qualified Leads -->
        <div class="rounded-2xl border border-sky-200 bg-sky-50/40 p-4 shadow-sm flex items-center justify-between cursor-pointer hover:bg-sky-50/70 transition" onclick="applyLeadFilter('status', 'Qualified', 'Qualified')">
            <div>
                <span class="text-xs font-bold uppercase tracking-wider text-sky-800">Qualified</span>
                <h3 class="text-2xl font-extrabold text-sky-800 mt-1" id="statQualifiedLeads">0</h3>
                <span class="text-[11px] text-sky-700 font-medium">High commercial intent</span>
            </div>
            <div class="h-12 w-12 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center text-xl">
                <i class="ti ti-target"></i>
            </div>
        </div>

        <!-- Card 4: Converted Leads -->
        <div class="rounded-2xl border border-amber-200 bg-amber-50/40 p-4 shadow-sm flex items-center justify-between cursor-pointer hover:bg-amber-50/70 transition" onclick="applyLeadFilter('status', 'Converted', 'Converted')">
            <div>
                <span class="text-xs font-bold uppercase tracking-wider text-amber-800">Converted</span>
                <h3 class="text-2xl font-extrabold text-amber-800 mt-1" id="statConvertedLeads">0</h3>
                <span class="text-[11px] text-amber-700 font-medium">Won / PI Generated</span>
            </div>
            <div class="h-12 w-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl">
                <i class="ti ti-trophy"></i>
            </div>
        </div>
    </div>

    <!-- Main Card with Filter Bar & Grid View -->
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:flex-wrap md:items-center">
                    
                    <!-- Search Input -->
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="leadSearchInput" 
                               placeholder="Search leads..." 
                               class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                               oninput="applyLeadFilter('search', this.value)">
                    </div>

                    <!-- Status Filter Dropdown -->
                    <div class="dropdown w-full shrink-0 md:w-auto">
                        <button class="flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap md:w-44 issue3-lead-filter-control" type="button" data-bs-toggle="dropdown">
                            <span class="inline-flex items-center gap-2">
                                <i class="ti ti-circle-check text-base text-slate-400"></i>
                                <span id="leadStatusLabel">All Statuses</span>
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'all', 'All Statuses')">All Statuses</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'New', 'New')">New</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'Contacted', 'Contacted')">Contacted</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'Qualified', 'Qualified')">Qualified</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'Unqualified', 'Unqualified')">Unqualified</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'Converted', 'Converted')">Converted</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('status', 'Lost', 'Lost')">Lost</a></li>
                        </ul>
                    </div>

                    <!-- Source Filter Dropdown -->
                    <div class="dropdown w-full shrink-0 md:w-auto">
                        <button class="flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap md:w-36 issue3-lead-filter-control" type="button" data-bs-toggle="dropdown">
                            <span class="inline-flex items-center gap-2">
                                <i class="ti ti-source text-base text-slate-400"></i>
                                <span id="leadSourceLabel">Source</span>
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', '', 'All Sources')">All Sources</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'quiz', 'Quiz')">Quiz</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'whatsapp', 'WhatsApp')">WhatsApp</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'generate_code', 'Generate Code')">Generate Code</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'request_api', 'Request API')">Request API</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'meeting', 'Meeting Request')">Meeting Request</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'become_partner', 'Become Partner')">Become Partner</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('source', 'manual', 'Manual Entry')">Manual Entry</a></li>
                        </ul>
                    </div>

                    <!-- Customer Type Filter Dropdown -->
                    <div class="dropdown w-full shrink-0 md:w-auto">
                        <button class="flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap md:w-44 issue3-lead-filter-control" type="button" data-bs-toggle="dropdown">
                            <span class="inline-flex items-center gap-2">
                                <i class="ti ti-building text-base text-slate-400"></i>
                                <span id="leadTypeLabel">Customer Type</span>
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', '', 'All Customer Types')">All Customer Types</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', 'Distributor', 'Distributor')">Distributor</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', 'Dealer', 'Dealer')">Dealer</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', 'Hospital', 'Hospital')">Hospital</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', 'Lab', 'Lab')">Lab</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', 'Institution', 'Institution')">Institution</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('customer_type', 'Other', 'Other')">Other</a></li>
                        </ul>
                    </div>

                    <!-- Priority Filter Dropdown -->
                    <div class="dropdown w-full shrink-0 md:w-auto">
                        <button class="flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap md:w-36 issue3-lead-filter-control" type="button" data-bs-toggle="dropdown">
                            <span class="inline-flex items-center gap-2">
                                <i class="ti ti-flag text-base text-slate-400"></i>
                                <span id="leadPriorityLabel">Priority</span>
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('priority', '', 'All Priorities')">All Priorities</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('priority', 'High', 'High')">High</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('priority', 'Medium', 'Medium')">Medium</a></li>
                            <li><a class="block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" onclick="applyLeadFilter('priority', 'Low', 'Low')">Low</a></li>
                        </ul>
                    </div>

                    <!-- Reset Filters Button -->
                    <button type="button" class="inline-flex h-10 w-full items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 cursor-pointer shrink-0 md:w-auto" onclick="resetLeadFilters()" title="Reset all filters">
                        <i class="ti ti-rotate text-sm text-slate-400"></i> Reset
                    </button>

                    <button type="button" class="inline-flex h-10 w-full shrink-0 items-center justify-center gap-2 !rounded-xl border border-emerald-200 bg-emerald-50 px-4 text-sm font-bold text-emerald-800 shadow-sm transition-colors hover:bg-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 md:w-auto" onclick="openSalesPerformanceModal()">
                        <i class="ti ti-chart-bar text-base"></i> Sales Performance
                    </button>

                    <!-- Add New Lead (+) Button at Far Right -->
                    <?php if ($canAddLead): ?>
                        <button type="button" onclick="openLeadModal('add')" 
                                class="inline-flex h-10 w-full shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 cursor-pointer md:w-auto"
                                data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New Lead">
                            <i class="ti ti-plus text-lg"></i> Add
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Lead Tile View -->
            <div id="leadsGrid" class="grid grid-cols-1 gap-4 border-t border-slate-200 bg-slate-50/40 p-5 md:grid-cols-2 xl:grid-cols-3" aria-live="polite">
                <div class="col-span-full py-12 text-center text-slate-400">
                    <div class="spinner-border text-emerald-600" role="status"><span class="visually-hidden">Loading...</span></div>
                    <p class="mt-2 text-xs">Loading leads...</p>
                </div>
            </div>

            <!-- Pagination Container -->
            <div id="leadsPagination" class="px-6 py-4 flex items-center justify-between border-t border-slate-100 text-sm text-slate-500 bg-slate-50/50">
                <!-- Pagination rendered via AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal 1: Review Incoming Leads (Accept / Reject Pop-up)                     -->
<!-- ========================================================================= -->
<div class="modal fade" id="incomingLeadsModal" tabindex="-1" aria-labelledby="incomingLeadsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                        <i class="ti ti-inbox text-xl"></i>
                    </div>
                    <div>
                        <h5 class="modal-title font-bold text-slate-800 text-base" id="incomingLeadsModalLabel">Incoming Leads Review</h5>
                        <p class="text-xs text-slate-500 mt-0.5">Accept to assign and convert into active lead, or Reject to archive</p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full table-auto text-left text-sm text-slate-600">
                        <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                            <tr class="text-nowrap">
                                <th class="px-5 py-3">Sr.</th>
                                <th class="px-5 py-3">Source</th>
                                <th class="px-5 py-3">Timestamp</th>
                                <th class="px-5 py-3">Lead ID</th>
                                <th class="px-5 py-3">Lead Name</th>
                                <th class="px-5 py-3">Company</th>
                                <th class="px-5 py-3 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="incomingLeadsTableBody" class="divide-y divide-slate-100">
                            <!-- Populated via AJAX -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-3">
                <button type="button" class="btn btn-label-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal 1B: Accept & Assign Lead Modal (Section 3 Assignment Engine)        -->
<!-- ========================================================================= -->
<div class="modal fade" id="acceptAssignModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <form id="acceptAssignForm" onsubmit="confirmAcceptLead(event)">
                <input type="hidden" id="acceptLeadId" name="lead_id" value="">
                
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                            <i class="ti ti-user-check text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title font-bold text-slate-800 text-base">Accept & Assign Lead</h5>
                            <p class="text-xs text-slate-500 mt-0.5">Assign sales representative and move into active pipeline</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>

                <div class="modal-body px-6 py-5 space-y-4">
                    <!-- Lead Quick Card -->
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="font-mono font-bold text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100" id="acceptLeadNumber">LEAD-26-0000</span>
                            <span class="badge bg-label-info rounded-pill text-[11px]" id="acceptLeadSource">Website</span>
                        </div>
                        <div class="font-bold text-slate-900 text-sm" id="acceptLeadCompany">Company Name</div>
                        <div class="text-xs text-slate-500 font-medium" id="acceptLeadContact">Contact Person</div>
                        <div class="text-xs text-slate-600 flex items-center gap-1.5" id="acceptLeadLocation">
                            <i class="ti ti-map-pin text-slate-400"></i> Location
                        </div>
                        <div id="acceptLeadProducts" class="flex flex-wrap gap-1 pt-1"></div>
                    </div>

                    <!-- Auto-Assignment Evaluation Banner (Section 3) -->
                    <div class="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/60">
                        <div class="flex items-start gap-2.5">
                            <div class="mt-0.5 h-5 w-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs shrink-0">
                                <i class="ti ti-wand"></i>
                            </div>
                            <div>
                                <h6 class="font-bold text-xs text-emerald-900 mb-0.5">Auto-Assignment Rule Engine</h6>
                                <p class="text-[12px] text-emerald-800 font-medium leading-relaxed" id="acceptMatchReason">
                                    Evaluating rules...
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Assigned Salesperson Selection -->
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                            Assigned Sales Representative <span class="text-rose-500">*</span>
                        </label>
                        <select id="acceptSalespersonSelect" name="salesperson_id" required class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                            <!-- Populated via AJAX with auto-recommended preselected -->
                        </select>
                        <span class="text-[11px] text-slate-400 mt-1 block">Preselected via rule matching. You can override and change it if needed.</span>
                    </div>

                    <!-- Priority Selection -->
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Lead Priority</label>
                        <select id="acceptPrioritySelect" name="priority" class="form-select !rounded-xl border-slate-200 text-sm py-2 px-3 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                            <option value="Low">Low Priority</option>
                            <option value="Medium" selected>Medium Priority</option>
                            <option value="High">High Priority</option>
                        </select>
                    </div>

                    <!-- Optional Assignment Notes -->
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Assignment Notes / Instructions</label>
                        <textarea id="acceptNotesInput" name="assignment_notes" rows="2" placeholder="Optional remarks for the salesperson..." class="form-control !rounded-xl border-slate-200 text-xs py-2 px-3 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm"></textarea>
                    </div>
                </div>

                <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-3.5 flex items-center justify-between">
                    <button type="button" class="btn btn-label-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" id="confirmAcceptBtn" class="btn btn-primary btn-sm flex items-center gap-1.5 shadow-sm">
                        <i class="ti ti-check"></i> Confirm & Accept Lead
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal 2: Lead Master Record & Activity Detail Modal                       -->
<!-- ========================================================================= -->
<div class="modal fade" id="leadDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                        <i class="ti ti-id text-xl"></i>
                    </div>
                    <div>
                        <h5 class="modal-title font-bold text-slate-800 text-base" id="leadDetailTitle">Lead Details</h5>
                        <span id="leadDetailNumber" class="text-xs text-slate-400 font-mono"></span>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <div class="modal-body p-6 space-y-6" id="leadDetailBody">
                <!-- Loaded dynamically via AJAX -->
            </div>
            <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-3 flex items-center justify-between">
                <div class="flex items-center gap-2" id="leadDetailActions">
                    <!-- Dynamic action buttons -->
                </div>
                <button type="button" class="inline-flex items-center justify-center px-4 py-2 border border-slate-200 bg-white text-slate-700 font-bold text-xs !rounded-xl hover:bg-slate-50 transition shadow-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal 3: Sales Performance Report                                          -->
<!-- ========================================================================= -->
<div class="modal fade" id="salesPerformanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content !rounded-xl border border-slate-200 shadow-2xl overflow-hidden">
            <div class="modal-header border-b border-slate-200 bg-slate-50/80 px-4 py-3">
                <div class="flex items-center gap-3">
                    <div class="flex h-11 w-11 items-center justify-center rounded-xl border border-emerald-100 bg-emerald-50 text-emerald-700">
                        <i class="ti ti-chart-bar text-xl"></i>
                    </div>
                    <div>
                        <h5 class="modal-title text-base font-extrabold text-slate-900">Sales Performance</h5>
                        <p class="mt-0.5 text-xs font-medium text-slate-500">Lead lifecycle and commercial conversion by salesperson</p>
                    </div>
                </div>
                <button type="button" class="flex h-9 w-9 items-center justify-center rounded-xl border border-rose-100 bg-rose-50 text-rose-600 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            <div class="modal-body bg-slate-50/70 p-4">
                <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div class="overflow-x-auto">
                        <table class="w-full min-w-[1050px] border-collapse text-left">
                            <thead class="bg-white">
                                <tr class="border-b border-slate-200 text-[11px] font-extrabold uppercase tracking-wider text-slate-500">
                                    <th class="px-6 py-3">Salesperson</th>
                                    <th class="px-4 py-3 text-center">Leads</th>
                                    <th class="px-4 py-3 text-center">Contacted</th>
                                    <th class="px-4 py-3 text-center">Qualified</th>
                                    <th class="px-4 py-3 text-center">Unqualified</th>
                                    <th class="px-4 py-3 text-center">Converted</th>
                                    <th class="px-4 py-3 text-center">Lost</th>
                                    <th class="px-4 py-3 text-center">Quotes</th>
                                    <th class="px-4 py-3 text-center">PI</th>
                                    <th class="px-4 py-3 text-center">Orders</th>
                                    <th class="px-6 py-3 text-right">Conversion</th>
                                </tr>
                            </thead>
                            <tbody id="salesPerformanceBody" class="divide-y divide-slate-100 bg-white"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal 4: Add / Edit Lead Modal                                            -->
<!-- ========================================================================= -->
<div class="modal fade" id="leadFormModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <form id="leadForm" onsubmit="saveLeadForm(event)">
                <input type="hidden" id="leadFormId" name="lead_id" value="">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                            <i class="ti ti-user-edit text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title font-bold text-slate-800 text-base" id="leadFormModalTitle">Add New Lead</h5>
                            <p class="text-xs text-slate-500 mt-0.5">Fill in the lead master information</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <div class="modal-body px-6 py-5 max-h-[75vh] overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Company / Organization <span class="text-rose-500">*</span></label>
                        <input type="text" id="leadCompany" name="company_name" required class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Contact Person</label>
                        <input type="text" id="leadContactPerson" name="contact_person" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Mobile / Phone</label>
                        <input type="text" id="leadMobile" name="mobile_number" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Email</label>
                        <input type="email" id="leadEmail" name="email" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Customer Type</label>
                        <select id="leadCustomerType" name="customer_type" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                            <option value="Distributor">Distributor</option>
                            <option value="Dealer">Dealer</option>
                            <option value="Hospital">Hospital</option>
                            <option value="Lab">Lab</option>
                            <option value="Institution">Institution</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Priority</label>
                        <select id="leadPriority" name="priority" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                            <option value="Low">Low</option>
                            <option value="Medium" selected>Medium</option>
                            <option value="High">High</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">City</label>
                        <input type="text" id="leadCity" name="city" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">State</label>
                        <input type="text" id="leadState" name="state" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Territory</label>
                        <input type="text" id="leadTerritory" name="territory" placeholder="e.g. Pune Metro, South Mumbai" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Region</label>
                        <input type="text" id="leadRegion" name="region" placeholder="e.g. North, West, Central" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Assign Salesperson</label>
                        <select id="leadSalesperson" name="assigned_salesperson_id" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                            <option value="">-- Auto-Assign based on Territory/Product --</option>
                            <?php foreach ($allSalespersons as $sp): ?>
                                <option value="<?= (int)$sp['id'] ?>"><?= htmlspecialchars($sp['salesperson_name']) ?> (<?= htmlspecialchars($sp['salesperson_code'] ?? 'SP') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-span-full">
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Products Interested</label>
                        <select id="leadProducts" name="product_ids[]" multiple class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm" style="height: 110px;">
                            <?php foreach ($allProducts as $p): ?>
                                <option value="<?= (int)$p['id'] ?>"><?= htmlspecialchars($p['product_name']) ?> (<?= htmlspecialchars($p['product_code'] ?? 'N/A') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <p class="text-[11px] text-slate-400 mt-1">Hold Ctrl (Windows) or Cmd (Mac) to select multiple products.</p>
                    </div>
                    <div class="col-span-full">
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Notes / Requirements</label>
                        <textarea id="leadNotes" name="notes" rows="2" class="form-control !rounded-xl border-slate-200 text-sm py-2 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-4 flex items-center justify-end gap-3">
                    <button type="button" class="inline-flex items-center justify-center px-4 py-2.5 border border-slate-200 bg-white text-slate-700 font-bold text-sm !rounded-xl hover:bg-slate-50 transition shadow-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" id="saveLeadBtn" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm !rounded-xl transition shadow-sm ring-1 ring-emerald-900/10 cursor-pointer">
                        <i class="ti ti-check text-base"></i> Save Lead
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
const crmCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
const crmEscapeHtml = value => $('<div>').text(value == null ? '' : String(value)).html();
$.ajaxPrefilter(function (options) {
    if (String(options.type || 'GET').toUpperCase() !== 'POST' || !crmCsrfToken) return;
    if (options.data instanceof FormData) {
        if (!options.data.has('csrf_token')) options.data.append('csrf_token', crmCsrfToken);
    } else if (typeof options.data === 'string') {
        if (!/(^|&)csrf_token=/.test(options.data)) options.data += (options.data ? '&' : '') + 'csrf_token=' + encodeURIComponent(crmCsrfToken);
    } else {
        options.data = Object.assign({}, options.data || {}, { csrf_token: crmCsrfToken });
    }
});

let currentLeadFilter = {
    status: 'all',
    search: '',
    source: '',
    customer_type: '',
    priority: '',
    page: 1
};

$(document).ready(function () {
    checkNewIncomingLeads();
    loadLeadsGrid(1);

    // Global listener to ensure no orphaned modal backdrops or scroll locks remain
    $(document).on('hidden.bs.modal', '.modal', function () {
        if ($('.modal.show').length === 0) {
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open').css({ 'overflow': '', 'padding-right': '' });
        }
    });
});

function checkNewIncomingLeads() {
    $.post('ajax.php', { action: 'crm_get_lead_stats' }, function (res) {
        if (res.status === 'success') {
            const incoming = parseInt(res.incoming) || 0;
            $('#statTotalLeads').text(res.total || 0);
            $('#statNewLeads').text(incoming);
            $('#statQualifiedLeads').text(res.qualified || 0);
            $('#statConvertedLeads').text(res.converted || 0);
            $('#newLeadsCountBadge').text(incoming);

            if (incoming > 0) {
                $('#newLeadsBannerText').html('<span id="newLeadsCountBadge" class="font-extrabold text-emerald-800">' + incoming + '</span> incoming leads captured from Quiz, WhatsApp, meeting requests, and website forms require review and assignment.');
                $('#newLeadsBannerBtnText').html('<i class="ti ti-checklist mr-1.5 text-sm text-emerald-700"></i> Review Incoming Leads (' + incoming + ')');
            } else {
                $('#newLeadsBannerText').html('<span id="newLeadsCountBadge" class="font-extrabold text-emerald-800">0</span> pending leads &bull; All in-scope incoming lead sources are up to date.');
                $('#newLeadsBannerBtnText').html('<i class="ti ti-checklist mr-1.5 text-sm text-emerald-700"></i> View Incoming Leads Queue');
            }
            $('#newLeadsBanner').removeClass('hidden');
        }
    }, 'json');
}

function applyLeadFilter(type, value, labelText) {
    if (type === 'status') {
        currentLeadFilter.status = value;
        $('#leadStatusLabel').text(labelText || 'Status');
    } else if (type === 'source') {
        currentLeadFilter.source = value;
        $('#leadSourceLabel').text(labelText || 'Source');
    } else if (type === 'customer_type') {
        currentLeadFilter.customer_type = value;
        $('#leadTypeLabel').text(labelText || 'Customer Type');
    } else if (type === 'priority') {
        currentLeadFilter.priority = value;
        $('#leadPriorityLabel').text(labelText || 'Priority');
    } else if (type === 'search') {
        currentLeadFilter.search = value.trim();
    }
    loadLeadsGrid(1);
}

function resetLeadFilters() {
    $('#leadSearchInput').val('');
    $('#leadStatusLabel').text('All Statuses');
    $('#leadSourceLabel').text('Source');
    $('#leadTypeLabel').text('Customer Type');
    $('#leadPriorityLabel').text('Priority');
    currentLeadFilter = { status: 'all', search: '', source: '', customer_type: '', priority: '', page: 1 };
    loadLeadsGrid(1);
}

function loadLeadsGrid(page = 1) {
    currentLeadFilter.page = page;

    $('#leadsGrid').html('<div class="col-span-full py-12 text-center text-slate-400"><div class="spinner-border text-emerald-600" role="status"></div><p class="mt-2 text-xs">Loading leads...</p></div>');

    $.post('ajax.php', {
        action: 'crm_load_leads_grid',
        status: currentLeadFilter.status || 'all',
        search: currentLeadFilter.search || '',
        source: currentLeadFilter.source || '',
        customer_type: currentLeadFilter.customer_type || '',
        priority: currentLeadFilter.priority || '',
        page: currentLeadFilter.page || 1
    }, function (res) {
        if (res.status === 'success') {
            $('#leadsGrid').html(res.html || '<div class="col-span-full py-12 text-center text-slate-400"><i class="ti ti-mood-empty text-3xl mb-2"></i><p>No leads found matching your criteria.</p></div>');
            $('#leadsPagination').html(res.pagination || '');
        } else {
            $('#leadsGrid').html('<div class="col-span-full py-12 text-center text-red-500">' + (res.message || 'Failed to load leads') + '</div>');
        }
    }, 'json');
}

function openNewLeadsModal() {
    $('#incomingLeadsTableBody').html('<tr><td colspan="7" class="py-8 text-center text-slate-400"><div class="spinner-border text-emerald-600" role="status"></div><p class="mt-2 text-xs">Fetching pending incoming leads...</p></td></tr>');
    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('incomingLeadsModal'));
    modal.show();

    $.post('ajax.php', { action: 'crm_load_incoming_leads' }, function (res) {
        if (res.status === 'success') {
            $('#incomingLeadsTableBody').html(res.html || '<tr><td colspan="7" class="py-8 text-center text-slate-400">No pending incoming leads.</td></tr>');
        } else {
            $('#incomingLeadsTableBody').html('<tr><td colspan="7" class="py-8 text-center text-red-500">' + (res.message || 'Error loading leads') + '</td></tr>');
        }
    }, 'json');
}

function openAcceptLeadModal(leadId) {
    const incModalEl = document.getElementById('incomingLeadsModal');
    if (incModalEl) {
        const incModalInst = bootstrap.Modal.getInstance(incModalEl);
        if (incModalInst) incModalInst.hide();
    }
    
    $.post('ajax.php', { action: 'crm_get_lead_for_accept_modal', lead_id: leadId }, function (res) {
        if (res.status === 'success') {
            const lead = res.lead;
            $('#acceptLeadId').val(lead.id);
            $('#acceptLeadNumber').text(lead.lead_number);
            $('#acceptLeadSource').text(lead.source_type ? lead.source_type.toUpperCase() : 'INCOMING');
            $('#acceptLeadCompany').text(lead.company_name || 'N/A');
            $('#acceptLeadContact').text((lead.contact_person || 'N/A') + (lead.mobile_number ? ' (' + lead.mobile_number + ')' : ''));
            
            const loc = [lead.city, lead.state, lead.region].filter(Boolean).join(', ') || 'N/A';
            $('#acceptLeadLocation').html('<i class="ti ti-map-pin text-slate-400"></i> ' + crmEscapeHtml(loc));

            // Products
            let prodHtml = '';
            if (res.products && res.products.length > 0) {
                res.products.forEach(p => {
                    prodHtml += '<span class="px-2 py-0.5 bg-slate-200 text-slate-700 text-[11px] rounded-md font-medium mr-1 mb-1 inline-block">' + crmEscapeHtml(p.product_name) + '</span>';
                });
            } else {
                prodHtml = '<span class="text-slate-400 italic text-[11px]">General Products Inquiry</span>';
            }
            $('#acceptLeadProducts').html(prodHtml);

            // Match Reason
            $('#acceptMatchReason').text(res.match_reason || 'No assignment rule matched.');

            // Populate Salespersons with recommended preselected
            let spHtml = '<option value="">-- Lead Unassigned --</option>';
            if (res.salespersons && res.salespersons.length > 0) {
                res.salespersons.forEach(sp => {
                    const isRec = (String(sp.id) === String(res.recommended_sp_id));
                    const label = sp.salesperson_name + (sp.sales_team ? ' (' + sp.sales_team + ')' : '') + (isRec ? ' ★ [Auto-Matched]' : '');
                    spHtml += '<option value="' + Number(sp.id) + '" ' + (isRec ? 'selected' : '') + '>' + crmEscapeHtml(label) + '</option>';
                });
            }
            $('#acceptSalespersonSelect').html(spHtml);
            $('#acceptPrioritySelect').val(lead.priority || 'Medium');
            $('#acceptNotesInput').val('');

            const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('acceptAssignModal'));
            modal.show();
        } else {
            toastr.error(res.message || 'Failed to load lead details');
        }
    }, 'json');
}

function confirmAcceptLead(e) {
    e.preventDefault();
    const formData = $('#acceptAssignForm').serialize() + '&action=crm_confirm_accept_lead';
    $('#confirmAcceptBtn').prop('disabled', true).html('<span class="spinner-border spinner-border-sm mr-1"></span> Accepting...');

    $.post('ajax.php', formData, function (res) {
        $('#confirmAcceptBtn').prop('disabled', false).html('<i class="ti ti-check"></i> Confirm & Accept Lead');
        if (res.status === 'success') {
            toastr.success(res.message || 'Lead accepted and assigned successfully');
            const assignModalInst = bootstrap.Modal.getInstance(document.getElementById('acceptAssignModal'));
            if (assignModalInst) assignModalInst.hide();
            
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open').css({ 'overflow': '', 'padding-right': '' });

            checkNewIncomingLeads();
            loadLeadsGrid(1);
        } else {
            toastr.error(res.message || 'Failed to accept lead');
        }
    }, 'json');
}

function rejectLead(leadId) {
    if (!confirm('Are you sure you want to reject this incoming lead?')) return;
    $.post('ajax.php', { action: 'crm_reject_lead', lead_id: leadId }, function (res) {
        if (res.status === 'success') {
            toastr.info(res.message || 'Lead rejected');
            openNewLeadsModal();
            checkNewIncomingLeads();
            loadLeadsGrid(1);
        } else {
            toastr.error(res.message || 'Failed to reject lead');
        }
    }, 'json');
}

function viewLeadDetail(leadId) {
    $('#leadDetailBody').html('<div class="py-12 text-center text-slate-400"><div class="spinner-border text-primary-600" role="status"></div><p class="mt-2 text-sm">Loading details...</p></div>');
    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('leadDetailModal'));
    modal.show();

    $.post('ajax.php', { action: 'crm_get_lead_detail', lead_id: leadId }, function (res) {
        if (res.status === 'success') {
            $('#leadDetailTitle').text(res.lead.company_name || 'Lead Details');
            $('#leadDetailNumber').text(res.lead.lead_number);
            $('#leadDetailBody').html(res.html);
            $('#leadDetailActions').html(res.actionsHtml);
        } else {
            $('#leadDetailBody').html('<div class="py-12 text-center text-red-500">' + (res.message || 'Failed to load details') + '</div>');
        }
    }, 'json');
}

function openSalesPerformanceModal() {
    $('#salesPerformanceBody').html('<tr><td colspan="11" class="px-6 py-12 text-center text-slate-400"><div class="spinner-border spinner-border-sm text-emerald-600" role="status"></div><p class="mt-2 text-xs font-medium">Loading performance...</p></td></tr>');
    bootstrap.Modal.getOrCreateInstance(document.getElementById('salesPerformanceModal')).show();
    $.post('ajax.php', { action: 'crm_get_sales_performance' }, function (res) {
        if (res.status === 'success') {
            $('#salesPerformanceBody').html(res.html);
        } else {
            $('#salesPerformanceBody').html('<tr><td colspan="11" class="px-6 py-12 text-center text-sm font-medium text-rose-600">' + crmEscapeHtml(res.message || 'Unable to load sales performance.') + '</td></tr>');
        }
    }, 'json').fail(function () {
        $('#salesPerformanceBody').html('<tr><td colspan="11" class="px-6 py-12 text-center text-sm font-medium text-rose-600">Unable to load sales performance.</td></tr>');
    });
}

function openLeadModal(mode, leadId = null) {
    $('#leadForm')[0].reset();
    $('#leadFormId').val('');
    $('#leadProducts').val([]);
    
    if (mode === 'add') {
        $('#leadFormModalTitle').text('Add New Lead');
        const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('leadFormModal'));
        modal.show();
    } else {
        $('#leadFormModalTitle').text('Edit Lead');
        $.post('ajax.php', { action: 'crm_get_lead_for_edit', lead_id: leadId }, function (res) {
            if (res.status === 'success') {
                const lead = res.lead;
                $('#leadFormId').val(lead.id);
                $('#leadCompany').val(lead.company_name);
                $('#leadContactPerson').val(lead.contact_person);
                $('#leadMobile').val(lead.mobile_number);
                $('#leadEmail').val(lead.email);
                $('#leadCustomerType').val(lead.customer_type);
                $('#leadPriority').val(lead.priority);
                $('#leadCity').val(lead.city);
                $('#leadState').val(lead.state);
                $('#leadTerritory').val(lead.territory);
                $('#leadRegion').val(lead.region);
                $('#leadSalesperson').val(lead.assigned_salesperson_id || '');
                $('#leadNotes').val(lead.notes);
                if (res.product_ids) {
                    $('#leadProducts').val(res.product_ids);
                }
                const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('leadFormModal'));
                modal.show();
            } else {
                toastr.error(res.message || 'Failed to fetch lead data');
            }
        }, 'json');
    }
}

function saveLeadForm(e) {
    e.preventDefault();
    const formData = $('#leadForm').serialize() + '&action=crm_save_lead';
    $('#saveLeadBtn').prop('disabled', true).text('Saving...');

    $.post('ajax.php', formData, function (res) {
        $('#saveLeadBtn').prop('disabled', false).text('Save Lead');
        if (res.status === 'success') {
            toastr.success(res.message || 'Lead saved successfully');
            bootstrap.Modal.getInstance(document.getElementById('leadFormModal')).hide();
            loadLeadsGrid(currentLeadFilter.page);
        } else {
            toastr.error(res.message || 'Failed to save lead');
        }
    }, 'json');
}

function updateLeadStatus(leadId, newStatus) {
    $.post('ajax.php', { action: 'crm_update_lead_status', lead_id: leadId, status: newStatus }, function (res) {
        if (res.status === 'success') {
            toastr.success('Lead status updated to ' + newStatus);
            viewLeadDetail(leadId);
            loadLeadsGrid(currentLeadFilter.page);
        } else {
            toastr.error(res.message || 'Failed to update status');
        }
    }, 'json');
}

function addLeadComment(leadId) {
    const comment = $('#leadCommentInput').val().trim();
    if (!comment) return;
    $.post('ajax.php', { action: 'crm_add_lead_comment', lead_id: leadId, comment: comment }, function (res) {
        if (res.status === 'success') {
            toastr.success('Comment logged');
            $('#leadCommentInput').val('');
            viewLeadDetail(leadId);
        } else {
            toastr.error(res.message || 'Failed to add comment');
        }
    }, 'json');
}

function deleteLead(leadId) {
    if (!confirm('Are you sure you want to delete this lead?')) return;
    $.post('ajax.php', { action: 'crm_delete_lead', lead_id: leadId }, function (res) {
        if (res.status === 'success') {
            toastr.success(res.message || 'Lead deleted');
            loadLeadsGrid(currentLeadFilter.page);
        } else {
            toastr.error(res.message || 'Failed to delete lead');
        }
    }, 'json');
}

function selectLeadForQuote(leadId) {
    if (!leadId) return;
    window.location.href = 'index.php?page=crm-quote-management&lead_id=' + leadId;
}
</script>
<?php endSection(); ?>
