<?php
if (!defined('HRMS_CONTEXT')) define('HRMS_CONTEXT', true);
require_once __DIR__ . '/../hrms/hrms_common.php';
require_once __DIR__ . '/../hrms/annual_calendar_common.php';

$currentUserId = (int) ($_SESSION['user_id'] ?? 0);
$scope = hrmsCurrentScope($conn, $currentUserId);
$canManage = hrmsCan($conn, 'hrms_calendar_manage');
$canFinalize = hrmsCan($conn, 'hrms_calendar_finalize');
$canReopen = hrmsCan($conn, 'hrms_calendar_reopen');
$canExport = hrmsCan($conn, 'hrms_calendar_export');

// Tenant-scoped company selector.
$companies = [];
if ($scope['company_id'] !== null) {
    $companyId = (int) $scope['company_id'];
    $companyStmt = $conn->prepare('SELECT id, company_name FROM erp_companies WHERE id = ? AND status = 1 AND deleted_at IS NULL');
    $companyStmt->bind_param('i', $companyId);
    $companyStmt->execute();
    $companies = $companyStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $companyStmt->close();
} else {
    $companyResult = $conn->query('SELECT id, company_name FROM erp_companies WHERE status = 1 AND deleted_at IS NULL ORDER BY company_name');
    if ($companyResult) $companies = $companyResult->fetch_all(MYSQLI_ASSOC);
}

$defaultCompanyId = $scope['company_id'] ?? ($companies[0]['id'] ?? 0);
$currentYear = (int) date('Y');

$saturdayPolicies = Constant::HR_SETTINGS['SATURDAY_POLICY'] ?? [];
$holidayTypes = Constant::HR_SETTINGS['ANNUAL_CALENDAR_HOLIDAY_TYPE'] ?? [];
$weekDayLabels = [1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun'];
?>

<div class="container-xxl flex-grow-1 container-p-y">
    <!-- Page Header -->
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?></h1>
            <p class="mt-1 text-sm font-medium text-slate-500">Configure annual working days, holidays, and weekly-off policies</p>
        </div>
        <div class="flex items-center gap-3 flex-wrap">
            <!-- Company Selector -->
            <select id="acCompanySelect" class="input-theme" style="min-width:180px; max-width:260px;">
                <?php foreach ($companies as $company): ?>
                    <option value="<?= (int) $company['id'] ?>" <?= (int) $company['id'] === (int) $defaultCompanyId ? 'selected' : '' ?>>
                        <?= htmlspecialchars($company['company_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <!-- Year Selector -->
            <select id="acYearSelect" class="input-theme" style="min-width:120px; max-width:140px;">
                <?php for ($y = $currentYear - 10; $y <= $currentYear + 10; $y++): ?>
                    <option value="<?= $y ?>" <?= $y === $currentYear ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
            <!-- Load / Initialize Button -->
            <button type="button" id="acLoadBtn"
                class="inline-flex h-11 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                <i class="ti ti-refresh text-lg"></i>
                <span>Load Calendar</span>
            </button>
        </div>
    </div>

    <!-- No Calendar State -->
    <div id="acNoCalendarState" class="hidden">
        <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-8 text-center">
            <div class="inline-flex h-20 w-20 items-center justify-center rounded-3xl bg-emerald-50 text-emerald-600 mb-4">
                <i class="fas fa-calendar-plus text-3xl"></i>
            </div>
            <h3 class="text-xl font-bold text-slate-900 mb-2">No Calendar Configured</h3>
            <p class="text-sm text-slate-500 mb-6 max-w-md mx-auto">
                No annual calendar has been set up for the selected company and year.
                Click below to initialize it with default Indian holidays.
            </p>
            <?php if ($canManage): ?>
            <button type="button" id="acInitBtn"
                class="inline-flex h-11 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-6 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                <i class="ti ti-plus text-lg"></i>
                Initialize Annual Calendar
            </button>
            <div class="mt-4 flex items-center justify-center gap-2">
                <select id="acCopySourceYear" class="input-theme" style="max-width:150px;">
                    <?php for ($y = $currentYear - 3; $y <= $currentYear + 3; $y++): ?>
                        <option value="<?= $y ?>" <?= $y === $currentYear - 1 ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
                <button type="button" id="acCopyYearBtn"
                    class="inline-flex h-11 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50">
                    <i class="ti ti-copy text-lg"></i> Copy from year
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Calendar Content (shown after loading) -->
    <div id="acCalendarContent" class="hidden">
        <!-- Summary Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-6" id="acSummaryCards">
            <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-4 text-center cursor-pointer transition-all hover:shadow-md hover:border-slate-300 hover:-translate-y-0.5" data-tile-filter="all" title="View Full Year Calendar" role="button" tabindex="0">
                <div class="text-xs font-bold uppercase tracking-widest text-slate-400 mb-1">Calendar Days</div>
                <div class="text-2xl font-extrabold text-slate-900" id="acTotalDays">0</div>
            </div>
            <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-4 text-center cursor-pointer transition-all hover:shadow-md hover:border-rose-300 hover:-translate-y-0.5" data-tile-filter="sundays" role="button" tabindex="0">
                <div class="text-xs font-bold uppercase tracking-widest text-slate-400 mb-1">Sundays</div>
                <div class="text-2xl font-extrabold text-rose-600" id="acTotalSundays">0</div>
            </div>
            <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-4 text-center cursor-pointer transition-all hover:shadow-md hover:border-amber-300 hover:-translate-y-0.5" data-tile-filter="saturday_offs" role="button" tabindex="0">
                <div class="text-xs font-bold uppercase tracking-widest text-slate-400 mb-1">Saturday Offs</div>
                <div class="text-2xl font-extrabold text-amber-600" id="acTotalSatOffs">0</div>
            </div>
            <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-4 text-center cursor-pointer transition-all hover:shadow-md hover:border-purple-300 hover:-translate-y-0.5" data-tile-filter="holidays" role="button" tabindex="0">
                <div class="text-xs font-bold uppercase tracking-widest text-slate-400 mb-1">Holidays</div>
                <div class="text-2xl font-extrabold text-purple-600" id="acTotalHolidays">0</div>
                <div class="text-[11px] font-semibold text-slate-400 mt-1" id="acHolidayBreakdown">&nbsp;</div>
            </div>
            <div class="rounded-2xl border border-emerald-200 bg-emerald-50 shadow-sm p-4 text-center cursor-pointer transition-all hover:shadow-md hover:border-emerald-400 hover:-translate-y-0.5" data-tile-filter="working" role="button" tabindex="0">
                <div class="text-xs font-bold uppercase tracking-widest text-emerald-600 mb-1">Working Days</div>
                <div class="text-2xl font-extrabold text-emerald-700" id="acTotalWorking">0</div>
            </div>
            <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-4 text-center cursor-pointer transition-all hover:shadow-md hover:border-slate-300 hover:-translate-y-0.5" data-tile-filter="status" role="button" tabindex="0">
                <div class="text-xs font-bold uppercase tracking-widest text-slate-400 mb-1">Status</div>
                <div id="acStatusBadge">
                    <span class="badge bg-label-warning">Draft</span>
                </div>
            </div>
        </div>

        <!-- Saturday Policy & Actions Row -->
        <div class="rounded-2xl border border-slate-200 bg-white shadow-sm mb-6">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-600 ring-1 ring-amber-100">
                            <i class="fas fa-calendar-week text-lg"></i>
                        </span>
                        <div>
                            <h6 class="text-sm font-bold text-slate-800 m-0">Saturday Off Policy</h6>
                            <p class="text-xs text-slate-500 m-0">Configure which Saturdays are weekly offs</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 flex-wrap">
                        <select id="acSaturdayPolicy" class="input-theme" style="min-width:240px;" <?= $canManage ? '' : 'disabled' ?>>
                            <?php foreach ($saturdayPolicies as $key => $val): ?>
                                <option value="<?= htmlspecialchars($key) ?>"><?= htmlspecialchars($val['label']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($canFinalize || $canReopen || $canExport): ?>
                        <div class="flex flex-wrap items-center gap-2">
                            <?php if ($canExport): ?>
                            <a id="acExportPdfBtn" href="#" target="_blank"
                                class="hidden inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50">
                                <i class="ti ti-file-type-pdf text-lg"></i><span>PDF</span>
                            </a>
                            <a id="acExportCsvBtn" href="#"
                                class="hidden inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50">
                                <i class="ti ti-file-spreadsheet text-lg"></i><span>CSV</span>
                            </a>
                            <?php endif; ?>
                            <?php if ($canFinalize): ?>
                            <button type="button" id="acFinalizeBtn"
                                class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-emerald-200 bg-emerald-50 px-4 text-sm font-bold text-emerald-700 shadow-sm transition-colors hover:bg-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                title="Finalize Calendar">
                                <i class="ti ti-lock text-lg"></i>
                                <span>Finalize</span>
                            </button>
                            <?php endif; ?>
                            <?php if ($canReopen): ?>
                            <button type="button" id="acUnfinalizeBtn"
                                class="hidden inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-amber-200 bg-amber-50 px-4 text-sm font-bold text-amber-700 shadow-sm transition-colors hover:bg-amber-100 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                                title="Unlock Calendar">
                                <i class="ti ti-lock-open text-lg"></i>
                                <span>Unlock</span>
                            </button>
                            <?php endif; ?>
                            <?php if ($canManage): ?>
                            <button type="button" id="acDiscardDraftBtn"
                                class="hidden inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-rose-200 bg-rose-50 px-4 text-sm font-bold text-rose-700 shadow-sm transition-colors hover:bg-rose-100 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                                title="Discard this draft revision">
                                <i class="ti ti-trash text-lg"></i>
                                <span>Discard Draft</span>
                            </button>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="px-6 py-4">
                <div class="flex flex-col lg:flex-row lg:items-center gap-4">
                    <div>
                        <h6 class="text-sm font-bold text-slate-800 m-0">Weekly-Off Days</h6>
                        <p class="text-xs text-slate-500 m-0">Days that are always non-working for this company</p>
                    </div>
                    <div class="flex flex-wrap items-center gap-3" id="acWeeklyOffDays">
                        <?php foreach ($weekDayLabels as $dayNumber => $dayLabel): ?>
                            <label class="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-700">
                                <input type="checkbox" class="acWeeklyOffDay" value="<?= (int) $dayNumber ?>" <?= $canManage ? '' : 'disabled' ?>>
                                <?= htmlspecialchars($dayLabel) ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <?php if ($canManage): ?>
                    <button type="button" id="acSaveWeeklyOffDaysBtn"
                        class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm hover:bg-emerald-800">
                        <i class="ti ti-device-floppy text-lg"></i><span>Save Days</span>
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div id="acCustomOffPanel" class="hidden rounded-2xl border border-amber-200 bg-amber-50/60 shadow-sm mb-6 p-5">
            <div class="flex flex-col lg:flex-row lg:items-end gap-4">
                <div class="flex-grow">
                    <label for="acCustomOffDates" class="block text-sm font-bold text-slate-800 mb-1">Custom weekly-off dates</label>
                    <p class="text-xs text-slate-500 mb-2">Enter dates in YYYY-MM-DD format, separated by commas or new lines. Sundays are always weekly offs.</p>
                    <textarea id="acCustomOffDates" rows="3" class="input-theme w-full" placeholder="2026-01-10, 2026-01-24"></textarea>
                </div>
                <?php if ($canManage): ?>
                <button type="button" id="acSaveCustomOffsBtn"
                    class="inline-flex h-11 items-center justify-center gap-2 !rounded-xl bg-amber-600 px-5 text-sm font-bold text-white shadow-sm hover:bg-amber-700">
                    <i class="ti ti-device-floppy text-lg"></i><span>Save Custom Offs</span>
                </button>
                <?php endif; ?>
            </div>
        </div>

        <style>
            .ac-two-col-layout {
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
                width: 100%;
                align-items: stretch;
            }
            .ac-left-col {
                width: 100%;
                flex: 1 1 100%;
                min-width: 0;
                display: flex;
                flex-direction: column;
            }
            .ac-right-col {
                width: 100%;
                flex: 1 1 100%;
                min-width: 0;
                display: flex;
                flex-direction: column;
            }
            .ac-card-panel {
                height: 100% !important;
                display: flex !important;
                flex-direction: column !important;
            }
            .ac-table-area {
                flex: 1 1 auto !important;
            }
            @media (min-width: 1200px) {
                .ac-two-col-layout {
                    flex-direction: row;
                    justify-content: space-between;
                    align-items: stretch !important;
                }
                .ac-left-col {
                    flex: 0 0 60%;
                    max-width: 60%;
                    width: 60%;
                    display: flex;
                    flex-direction: column;
                }
                .ac-right-col {
                    flex: 0 0 calc(40% - 1.5rem);
                    max-width: calc(40% - 1.5rem);
                    width: calc(40% - 1.5rem);
                    margin-left: auto;
                    display: flex;
                    flex-direction: column;
                }
            }

            /* Responsive Toolbar styling */
            .ac-toolbar-box {
                box-sizing: border-box !important;
                max-width: 100% !important;
                overflow: visible !important;
                position: relative !important;
                z-index: 25 !important;
            }

            /* Holiday pagination styling */
            .ac-holiday-pagination-container > div {
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                flex-wrap: wrap !important;
                gap: 0.5rem !important;
                padding: 0.75rem 1.25rem !important;
                border-top: 1px solid #e2e8f0 !important;
                background: #ffffff !important;
            }
            .ac-holiday-pagination-container p {
                font-size: 0.8125rem !important;
                margin: 0 !important;
                white-space: nowrap !important;
            }
            .ac-holiday-pagination-container .pagination {
                margin: 0 !important;
                display: flex !important;
                flex-wrap: nowrap !important;
                gap: 2px !important;
            }
            .ac-holiday-pagination-container .page-link {
                padding: 0.25rem 0.6rem !important;
                font-size: 0.8125rem !important;
                min-width: 28px !important;
                height: 28px !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                border-radius: 6px !important;
            }

            /* Full Year Calendar styling */
            .ac-year-months-grid {
                display: grid !important;
                grid-template-columns: repeat(1, minmax(0, 1fr)) !important;
                gap: 1.25rem !important;
                padding: 1.25rem !important;
            }
            @media (min-width: 768px) {
                .ac-year-months-grid {
                    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
                }
            }
            @media (min-width: 1200px) {
                .ac-year-months-grid {
                    grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
                }
            }
            @media (min-width: 1600px) {
                .ac-year-months-grid {
                    grid-template-columns: repeat(4, minmax(0, 1fr)) !important;
                }
            }

            .ac-month-card {
                background: #ffffff !important;
                border: 1px solid #e2e8f0 !important;
                border-radius: 1rem !important;
                padding: 1rem !important;
                box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05) !important;
            }
            .ac-month-title {
                font-size: 0.925rem !important;
                font-weight: 800 !important;
                color: #1e293b !important;
                margin-bottom: 0.75rem !important;
                padding-bottom: 0.5rem !important;
                border-bottom: 1px solid #f1f5f9 !important;
            }
            .ac-month-grid {
                display: grid !important;
                grid-template-columns: repeat(7, minmax(0, 1fr)) !important;
                gap: 4px !important;
                text-align: center !important;
            }
            .ac-day-header {
                font-size: 11px !important;
                font-weight: 800 !important;
                color: #94a3b8 !important;
                padding: 2px 0 6px 0 !important;
                text-align: center !important;
            }
            .ac-day-cell {
                border-radius: 6px !important;
                border-width: 1px !important;
                border-style: solid !important;
                padding: 4px 2px !important;
                font-size: 11px !important;
                font-weight: 700 !important;
                line-height: 1.2 !important;
                min-height: 28px !important;
                display: flex !important;
                flex-direction: column !important;
                align-items: center !important;
                justify-content: center !important;
                cursor: default !important;
                transition: transform 0.12s ease, box-shadow 0.12s ease !important;
            }
            .ac-day-cell:hover {
                transform: scale(1.12) !important;
                z-index: 10 !important;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
            }
        </style>

        <!-- Main Content: Holiday Table (60%) & Monthly Breakdown (40%) -->
        <div class="ac-two-col-layout mb-6">
            <!-- Holiday Management Table (60% width) -->
            <div class="ac-left-col">
                <div class="rounded-2xl border border-slate-200 bg-white shadow-sm ac-card-panel" style="overflow: visible !important;">
                    <div class="border-b border-slate-200 bg-slate-50/70 p-3 rounded-t-2xl" style="min-height: 65px; display: flex; align-items: center; position: relative; z-index: 25; overflow: visible !important;">
                        <div class="flex flex-wrap items-center justify-between gap-2.5 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm w-full ac-toolbar-box">
                            <input type="hidden" id="acHolidayPerPage" value="10">

                            <div class="flex items-center gap-2 flex-grow" style="min-width: 180px;">
                                <div class="dropdown shrink-0" style="position: relative; z-index: 30;">
                                    <button
                                        class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                        type="button" data-bs-toggle="dropdown">
                                        <span id="acHolidayPerPageText" class="whitespace-nowrap">10 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl" style="z-index: 1060;">
                                        <li><a class="ac-holiday-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                                data-val="100000000">All items</a></li>
                                        <li><a class="ac-holiday-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                                data-val="5">5 items</a></li>
                                        <li><a class="ac-holiday-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                                data-val="10">10 items</a></li>
                                        <li><a class="ac-holiday-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                                data-val="25">25 items</a></li>
                                        <li><a class="ac-holiday-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                                data-val="50">50 items</a></li>
                                    </ul>
                                </div>

                                <div class="relative h-10 flex-grow min-w-[120px]">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="acHolidaySearch"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-3 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search holidays...">
                                </div>
                            </div>

                            <?php if ($canManage): ?>
                            <div class="flex items-center gap-2 shrink-0 flex-wrap">
                                <button type="button" id="acImportDefaultsBtn"
                                    class="inline-flex h-10 shrink-0 items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                                    title="Import default Indian holidays">
                                    <i class="ti ti-download text-base"></i>
                                    <span class="whitespace-nowrap">Import Defaults</span>
                                </button>
                                <button type="button" id="acImportCsvBtn"
                                    class="inline-flex h-10 shrink-0 items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                                    title="Import a jurisdiction-specific holiday list from CSV">
                                    <i class="ti ti-file-upload text-base"></i>
                                    <span class="whitespace-nowrap">Import CSV</span>
                                </button>
                                <button type="button" id="acAddHolidayBtn"
                                    class="inline-flex h-10 shrink-0 items-center justify-center gap-1.5 !rounded-xl bg-emerald-700 px-3.5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                                    <i class="ti ti-plus text-base"></i>
                                    <span class="whitespace-nowrap">Add Holiday</span>
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="overflow-x-auto flex-grow ac-table-area">
                        <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                            <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400 sticky top-0 z-10">
                                <tr>
                                    <th class="w-12 border-b border-slate-200 px-6 py-3">#</th>
                                    <th class="border-b border-slate-200 px-6 py-3">Date</th>
                                    <th class="border-b border-slate-200 px-6 py-3">Day</th>
                                    <th class="border-b border-slate-200 px-6 py-3">Holiday Name</th>
                                    <th class="border-b border-slate-200 px-6 py-3">Type</th>
                                    <th class="border-b border-slate-200 px-6 py-3">Status</th>
                                    <?php if ($canManage): ?>
                                    <th class="w-40 border-b border-slate-200 px-6 py-3 text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody id="acHolidayTableBody" class="bg-white divide-y divide-slate-100 text-sm text-slate-600">
                                <tr><td colspan="7" class="text-center px-6 py-8 text-slate-400">Select a year and click Load Calendar</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="ac-holiday-pagination-container mt-auto">
                        <style>
                            #acHolidayFooterPerPageSelect + .dropdown {
                                display: none !important;
                            }
                        </style>
                        <?= getPaginationFooter('acHolidayPaginationWrapper', 'acHolidayPaginationSummary', 'acHolidayFooterPerPageSelect') ?>
                    </div>
                </div>
            </div>

            <!-- Monthly Breakdown (Right side) -->
            <div class="ac-right-col">
                <div class="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden ac-card-panel">
                    <div class="border-b border-slate-200 bg-slate-50/70 px-5 py-3.5 flex items-center justify-between" style="min-height: 65px;">
                        <h6 class="text-sm font-bold text-slate-800 m-0">
                            <i class="fas fa-chart-bar text-emerald-600 me-2"></i>Monthly Breakdown
                        </h6>
                        <span class="badge bg-label-success">12 Months</span>
                    </div>
                    <div class="overflow-x-auto flex-grow ac-table-area">
                        <table class="w-full table-auto text-left text-sm text-slate-600">
                            <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400 sticky top-0 z-10">
                                <tr>
                                    <th class="border-b border-slate-200 px-4 py-2.5">Month</th>
                                    <th class="border-b border-slate-200 px-3 py-2.5 text-center">Days</th>
                                    <th class="border-b border-slate-200 px-3 py-2.5 text-center">Weekly Offs</th>
                                    <th class="border-b border-slate-200 px-3 py-2.5 text-center">Sun</th>
                                    <th class="border-b border-slate-200 px-3 py-2.5 text-center">Sat Off</th>
                                    <th class="border-b border-slate-200 px-3 py-2.5 text-center">Hol</th>
                                    <th class="border-b border-slate-200 px-3 py-2.5 text-center text-emerald-700 font-extrabold">WD</th>
                                </tr>
                            </thead>
                            <tbody id="acMonthlyBody" class="bg-white divide-y divide-slate-100 text-sm text-slate-600">
                                <tr><td colspan="7" class="text-center px-4 py-6 text-slate-400">—</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="border-t border-slate-200 bg-white px-5 py-3.5 flex items-center justify-between text-xs font-semibold text-slate-500 mt-auto" style="min-height: 53px;">
                        <span class="text-slate-600 font-bold"><i class="ti ti-calendar text-emerald-600 me-1.5"></i>Annual Summary</span>
                        <span class="text-slate-900 font-bold">12 Months &middot; 365 Days</span>
                    </div>
                </div>
            </div>
        </div>

        <div id="acFullYearCalendarSection" class="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden mb-6">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-4">
                <h6 class="text-sm font-bold text-slate-800 m-0"><i class="ti ti-calendar-month text-emerald-600 me-2"></i>Full Year Calendar</h6>
                <p class="text-xs text-slate-500 m-0 mt-1">Green = working day, amber = weekly off, purple = holiday, blue = optional (restricted) holiday. A dot marks a declared holiday; hover any date for its date, day, holiday name and type.</p>
            </div>
            <div id="acYearGrid" class="ac-year-months-grid"></div>
        </div>

        <div class="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden mb-6">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-4">
                <h6 class="text-sm font-bold text-slate-800 m-0"><i class="ti ti-calendar-cog text-emerald-600 me-2"></i>Date Overrides</h6>
                <p class="text-xs text-slate-500 m-0 mt-1">Force a specific date to be a working day (compensatory work) or a weekly off, regardless of the policy.</p>
                <p id="acOverrideLockHint" class="hidden text-xs font-semibold text-amber-700 m-0 mt-2"><i class="ti ti-lock me-1"></i>Unlock this finalized calendar to create a corrected draft before adding an override.</p>
            </div>
            <?php if ($canManage): ?>
            <div class="border-b border-slate-200 px-6 py-4">
                <div class="grid grid-cols-1 items-end gap-3 md:grid-cols-2 xl:grid-cols-12">
                    <div class="xl:col-span-2">
                        <label for="acOverrideDate" class="mb-1 block text-sm font-medium text-slate-800">Date</label>
                        <input type="date" id="acOverrideDate" class="input-theme">
                    </div>
                    <div class="xl:col-span-2">
                        <label for="acOverrideType" class="mb-1 block text-sm font-medium text-slate-800">Treat as</label>
                        <select id="acOverrideType" class="input-theme" style="min-width:200px;">
                            <option value="working_day">Working day</option>
                            <option value="weekly_off">Weekly off</option>
                        </select>
                    </div>
                    <div class="md:col-span-2 xl:col-span-6">
                        <label for="acOverrideNote" class="mb-1 block text-sm font-medium text-slate-800">Note</label>
                        <input type="text" id="acOverrideNote" class="input-theme w-full" maxlength="200" placeholder="e.g. Compensatory working Saturday for Diwali week">
                    </div>
                    <button type="button" id="acSaveOverrideBtn"
                        class="inline-flex h-11 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm hover:bg-emerald-800 md:col-span-2 xl:col-span-2">
                        <i class="ti ti-plus text-lg"></i><span>Add Override</span>
                    </button>
                </div>
            </div>
            <?php endif; ?>
            <div class="overflow-x-auto">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr><th class="px-5 py-3">Date</th><th class="px-5 py-3">Treatment</th><th class="px-5 py-3">Note</th><th class="px-5 py-3 text-center">Action</th></tr>
                    </thead>
                    <tbody id="acOverrideBody"><tr><td colspan="4" class="px-5 py-6 text-center text-slate-400">No date overrides</td></tr></tbody>
                </table>
            </div>
        </div>

        <div class="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden mb-6">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-4 flex flex-wrap items-center justify-between gap-3">
                <h6 class="text-sm font-bold text-slate-800 m-0"><i class="ti ti-history text-emerald-600 me-2"></i>Calendar Audit History</h6>
                <div class="flex items-center gap-2">
                    <input type="hidden" id="acAuditPerPage" value="10">
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="acAuditPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="ac-audit-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                            <li><a class="ac-audit-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="ac-audit-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="ac-audit-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="ac-audit-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                        </ul>
                    </div>
                    <input type="text" id="acAuditFilter" class="input-theme" style="max-width:220px;" placeholder="Filter action, user, reason">
                    <?php if ($canExport): ?>
                    <a id="acAuditExportBtn" href="#"
                        class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50">
                        <i class="ti ti-file-spreadsheet text-lg"></i><span>Export</span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr><th class="px-5 py-3">When</th><th class="px-5 py-3">Revision</th><th class="px-5 py-3">Action</th><th class="px-5 py-3">User</th><th class="px-5 py-3">Reason / Change</th></tr>
                    </thead>
                    <tbody id="acAuditBody"><tr><td colspan="5" class="px-5 py-6 text-center text-slate-400">No audit activity</td></tr></tbody>
                </table>
            </div>
            <style>
                #acAuditFooterPerPageSelect + .dropdown {
                    display: none !important;
                }
            </style>
            <?= getPaginationFooter('acAuditPaginationWrapper', 'acAuditPaginationSummary', 'acAuditFooterPerPageSelect') ?>
        </div>
    </div>
</div>

<!-- Add / Edit Holiday Modal -->
<div class="modal fade animate__animated fadeIn" id="acHolidayModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                        <i class="ti ti-calendar-plus text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="acHolidayModalTitle">Add Holiday</h5>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                    data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
            </div>
            <form id="acHolidayForm">
                <input type="hidden" id="acHolidayId" name="holiday_id" value="">
                <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <div>
                            <label for="acHolidayDate" class="mb-1 block text-sm font-medium text-slate-800">Date
                                <strong class="text-rose-500">*</strong></label>
                            <input type="date" id="acHolidayDate" name="holiday_date" class="input-theme" required />
                        </div>
                        <div>
                            <label for="acHolidayName" class="mb-1 block text-sm font-medium text-slate-800">Name
                                <strong class="text-rose-500">*</strong></label>
                            <input type="text" id="acHolidayName" name="holiday_name" class="input-theme"
                                placeholder="e.g. Republic Day" required />
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <div>
                            <label for="acHolidayType" class="mb-1 block text-sm font-medium text-slate-800">Type
                                <strong class="text-rose-500">*</strong></label>
                            <select name="holiday_type" id="acHolidayType" class="input-theme" required>
                                <option value="">----Select----</option>
                                <?php foreach ($holidayTypes as $typeKey => $typeVal): ?>
                                    <option value="<?= htmlspecialchars($typeKey) ?>"><?= htmlspecialchars($typeVal['label']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                    <button type="button"
                        class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                        data-bs-dismiss="modal">Close</button>
                    <button type="submit"
                        class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <i class="ti ti-check text-lg"></i> Save Holiday
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Holiday CSV Import Modal -->
<div class="modal fade animate__animated fadeIn" id="acImportCsvModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                        <i class="ti ti-file-upload text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Import Holiday List</h5>
                        <p class="m-0 text-xs text-slate-500">CSV columns: date, name, type[, optional]</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700"
                    data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
            </div>
            <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                    <div>
                        <label for="acImportJurisdiction" class="mb-1 block text-sm font-medium text-slate-800">Jurisdiction
                            <strong class="text-rose-500">*</strong></label>
                        <input type="text" id="acImportJurisdiction" class="input-theme" maxlength="60" placeholder="e.g. India - Maharashtra" />
                    </div>
                    <div>
                        <label for="acImportVersion" class="mb-1 block text-sm font-medium text-slate-800">Dataset version</label>
                        <input type="text" id="acImportVersion" class="input-theme" maxlength="40" placeholder="e.g. 2027.01" />
                    </div>
                </div>
                <div class="mb-3">
                    <label for="acImportFile" class="mb-1 block text-sm font-medium text-slate-800">Holiday CSV
                        <strong class="text-rose-500">*</strong></label>
                    <input type="file" id="acImportFile" accept=".csv" class="input-theme w-full" />
                    <p class="mt-1 text-xs text-slate-500">Holiday types: national, company, festival, restricted, other. Restricted holidays are treated as optional and never reduce working days.</p>
                </div>
                <div id="acImportPreview" class="hidden rounded-xl border border-slate-200 bg-white p-3">
                    <div id="acImportSummary" class="mb-2 text-sm font-bold text-slate-800"></div>
                    <div class="overflow-auto" style="max-height:260px;">
                        <table class="w-full table-auto text-left text-sm text-slate-600">
                            <thead class="text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                <tr><th class="px-3 py-2">Date</th><th class="px-3 py-2">Name</th><th class="px-3 py-2">Type</th><th class="px-3 py-2">Optional</th></tr>
                            </thead>
                            <tbody id="acImportPreviewBody"></tbody>
                        </table>
                    </div>
                    <ul id="acImportErrors" class="mt-2 list-disc ps-5 text-xs text-rose-600"></ul>
                </div>
            </div>
            <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                <button type="button"
                    class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50"
                    data-bs-dismiss="modal">Close</button>
                <button type="button" id="acImportPreviewBtn"
                    class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50">
                    <i class="ti ti-eye text-lg"></i> Preview
                </button>
                <button type="button" id="acImportConfirmBtn" disabled
                    class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm hover:bg-emerald-800 disabled:opacity-50">
                    <i class="ti ti-check text-lg"></i> Confirm Import
                </button>
            </div>
        </div>
    </div>
</div>
<?php startSection('scripts'); ?>
<script>
(function($) {
    const csrfToken = '<?= $_SESSION['csrf_token'] ?? '' ?>';
    const canManage = <?= $canManage ? 'true' : 'false' ?>;
    const canFinalize = <?= $canFinalize ? 'true' : 'false' ?>;
    const canReopen = <?= $canReopen ? 'true' : 'false' ?>;
    const canExport = <?= $canExport ? 'true' : 'false' ?>;
    const holidayTypeMeta = <?= json_encode($holidayTypes) ?>;

    let calendarData = null;
    let monthlyData = [];
    let saturdayOffs = [];
    let calendarDays = [];
    let auditEvents = [];
    let payrollRuns = [];
    let calendarTotals = null;

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>'"]/g, function(char) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;'}[char];
        });
    }

    function showToast(msg, type = 'success') {
        if (typeof Swal !== 'undefined') {
            Swal.fire({ toast: true, position: 'top-end', icon: type, title: msg, showConfirmButton: false, timer: 2500, timerProgressBar: true });
        } else { alert(msg); }
    }

    function hrmsPost(action, data = {}) {
        data.action = action;
        data.csrf_token = csrfToken;
        return $.ajax({ url: 'hrms-api.php', method: 'POST', data, dataType: 'json' });
    }

    function loadCalendar() {
        const companyId = $('#acCompanySelect').val();
        const year = $('#acYearSelect').val();
        if (!companyId || !year) return;

        $('#acLoadBtn').prop('disabled', true).find('span').text('Loading...');
        hrmsPost('load_annual_calendar', { company_id: companyId, year: year }).done(function(res) {
            if (res.status !== 'success') { showToast(res.message || 'Error loading calendar', 'error'); return; }

            if (!res.exists) {
                $('#acNoCalendarState').removeClass('hidden');
                $('#acCalendarContent').addClass('hidden');
                calendarData = null;
                return;
            }

            calendarData = res.calendar;
            monthlyData = res.monthly || [];
            saturdayOffs = res.saturday_offs || [];
            calendarDays = res.days || [];
            auditEvents = res.audit_events || [];
            payrollRuns = res.payroll_runs || [];
            calendarTotals = res.totals || null;
            $('#acNoCalendarState').addClass('hidden');
            $('#acCalendarContent').removeClass('hidden');
            renderSummary();
            renderHolidayTable();
            renderMonthly();
            renderPolicyUI();
            renderYearGrid();
            renderOverrides();
            renderAudit();
        }).fail(function() {
            showToast('Failed to load calendar.', 'error');
        }).always(function() {
            $('#acLoadBtn').prop('disabled', false).find('span').text('Load Calendar');
        });
    }

    function renderSummary() {
        if (!calendarData) return;
        $('#acTotalDays').text(calendarData.total_days);
        $('#acTotalSundays').text(calendarData.total_sundays);
        $('#acTotalSatOffs').text(calendarData.total_saturday_offs);
        $('#acTotalHolidays').text(calendarData.total_holidays);
        $('#acTotalWorking').text(calendarData.total_working_days);

        const declared = calendarTotals ? calendarTotals.total_declared_holidays : null;
        const optional = calendarTotals ? calendarTotals.total_optional_holidays : null;
        $('#acHolidayBreakdown').text(
            declared === null ? '\u00a0' : declared + ' declared \u00b7 ' + optional + ' optional'
        );

        const isFinalized = calendarData.lifecycle_status === 'finalized' && parseInt(calendarData.is_finalized) === 1;
        const revision = parseInt(calendarData.revision_no || 1);
        if (isFinalized) {
            let badge = '<span class="badge bg-label-success">Finalized \u00b7 Rev ' + revision + '</span>';
            if (payrollRuns.length) {
                badge += '<div class="mt-1 text-[11px] font-semibold text-amber-600">Locked by ' + payrollRuns.length + ' pay run(s)</div>';
            }
            $('#acStatusBadge').html(badge);
            $('#acFinalizeBtn').addClass('hidden');
            $('#acDiscardDraftBtn').addClass('hidden');
            if (canReopen) $('#acUnfinalizeBtn').removeClass('hidden').css('display', 'inline-flex');
            if (canExport) {
                const base = 'annual-calendar-export.php?calendar_id=' + encodeURIComponent(calendarData.id) + '&format=';
                $('#acExportPdfBtn').attr('href', base + 'pdf').removeClass('hidden').css('display', 'inline-flex');
                $('#acExportCsvBtn').attr('href', base + 'csv').removeClass('hidden').css('display', 'inline-flex');
            }
        } else {
            $('#acStatusBadge').html('<span class="badge bg-label-warning">Draft \u00b7 Rev ' + revision + '</span>');
            if (canFinalize) $('#acFinalizeBtn').removeClass('hidden');
            if (canManage) $('#acDiscardDraftBtn').removeClass('hidden').css('display', 'inline-flex');
            $('#acUnfinalizeBtn').addClass('hidden');
            $('#acExportPdfBtn, #acExportCsvBtn').addClass('hidden');
        }
        const canEditDraft = canManage && !isFinalized;
        $('#acSaturdayPolicy').prop('disabled', !canEditDraft);
        $('#acImportDefaultsBtn, #acAddHolidayBtn, #acSaveCustomOffsBtn, #acSaveWeeklyOffDaysBtn, #acImportCsvBtn').toggleClass('hidden', !canEditDraft);
        $('#acSaveOverrideBtn').prop('disabled', !canEditDraft).toggleClass('opacity-50 cursor-not-allowed', !canEditDraft)
            .attr('title', canEditDraft ? 'Add date override' : 'Unlock the finalized calendar before adding an override.');
        $('#acOverrideLockHint').toggleClass('hidden', canEditDraft);
        $('#acCustomOffDates, #acOverrideDate, #acOverrideType, #acOverrideNote').prop('disabled', !canEditDraft);
        $('.acWeeklyOffDay').prop('disabled', !canEditDraft);
    }

    function updateTotals(totals) {
        if (!totals || !calendarData) return;
        calendarData.total_days = totals.total_days;
        calendarData.total_sundays = totals.total_sundays;
        calendarData.total_saturday_offs = totals.total_saturday_offs;
        calendarData.total_holidays = totals.total_holidays;
        calendarData.total_working_days = totals.total_working_days;
        renderSummary();
        // Also refresh monthly
        hrmsPost('get_calendar_monthly_summary', { calendar_id: calendarData.id }).done(function(res) {
            if (res.monthly) { monthlyData = res.monthly; renderMonthly(); }
            if (res.days) { calendarDays = res.days; renderYearGrid(); }
        });
    }

    function renderPolicyUI() {
        if (!calendarData) return;
        $('#acSaturdayPolicy').val(calendarData.saturday_policy);
        const custom = calendarData.saturday_policy === 'custom';
        $('#acCustomOffPanel').toggleClass('hidden', !custom);
        $('#acCustomOffDates').val((calendarData.custom_offs || []).join('\n'));
        const weeklyOffDays = (calendarData.weekly_off_days || [7]).map(Number);
        $('.acWeeklyOffDay').each(function() {
            $(this).prop('checked', weeklyOffDays.indexOf(parseInt($(this).val())) !== -1);
        });
    }

    function renderOverrides() {
        const overrides = (calendarData && calendarData.day_overrides) || [];
        if (!overrides.length) {
            $('#acOverrideBody').html('<tr><td colspan="4" class="px-5 py-6 text-center text-slate-400">No date overrides</td></tr>');
            return;
        }
        const isDraft = calendarData.lifecycle_status === 'draft';
        let html = '';
        overrides.forEach(function(override) {
            html += '<tr class="border-b border-slate-100">';
            html += '<td class="px-5 py-3 whitespace-nowrap font-semibold text-slate-800">' + formatDate(override.override_date) + '</td>';
            html += '<td class="px-5 py-3">' + (override.override_type === 'working_day'
                ? '<span class="badge bg-label-success">Forced working day</span>'
                : '<span class="badge bg-label-warning">Forced weekly off</span>') + '</td>';
            html += '<td class="px-5 py-3">' + escapeHtml(override.note || '') + '</td>';
            html += '<td class="px-5 py-3 text-center">';
            if (canManage && isDraft) {
                html += '<button type="button" class="btn btn-icon btn-label-danger acDeleteOverride" data-id="' + parseInt(override.id) + '" title="Remove"><span class="ti ti-trash"></span></button>';
            } else {
                html += '<i class="ti ti-lock text-slate-400"></i>';
            }
            html += '</td></tr>';
        });
        $('#acOverrideBody').html(html);
    }

    function getTypeBadge(type) {
        const meta = holidayTypeMeta[type];
        if (!meta) return '<span class="badge bg-label-secondary">' + escapeHtml(type) + '</span>';
        return '<span class="badge ' + escapeHtml(meta.badge) + '">' + escapeHtml(meta.label) + '</span>';
    }

    function getDayName(dateStr) {
        const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        return days[new Date(dateStr + 'T00:00:00').getDay()];
    }

    function formatDate(dateStr) {
        const d = new Date(dateStr + 'T00:00:00');
        return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    function renderSmartPaginationJs(totalPages, currentPage, callbackName) {
        totalPages = Math.max(1, parseInt(totalPages) || 1);
        currentPage = Math.min(Math.max(1, parseInt(currentPage) || 1), totalPages);

        if (totalPages <= 1) {
            return '';
        }

        let html = '';

        // Previous
        const prev = currentPage - 1;
        const prevDisabled = (currentPage === 1) ? 'disabled' : '';
        const prevOnclick = (currentPage === 1) ? '' : 'onclick="' + callbackName + '(' + prev + ')"';
        html += '<li class="page-item ' + prevDisabled + '"><a class="page-link page-link-label" href="javascript:void(0)" ' + prevOnclick + '>Prev</a></li>';

        let pageCandidates = [1, totalPages];
        for (let p = Math.max(1, currentPage - 2); p <= Math.min(totalPages, currentPage + 2); p++) {
            pageCandidates.push(p);
        }
        pageCandidates = Array.from(new Set(pageCandidates)).sort(function(a, b) { return a - b; });

        let previousRenderedPage = 0;
        pageCandidates.forEach(function(p) {
            if (previousRenderedPage > 0 && p > previousRenderedPage + 1) {
                html += '<li class="page-item disabled"><span class="page-link">&hellip;</span></li>';
            }
            if (p === currentPage) {
                html += '<li class="page-item active" aria-current="page"><span class="page-link">' + p + '</span></li>';
            } else {
                html += '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="' + callbackName + '(' + p + ')">' + p + '</a></li>';
            }
            previousRenderedPage = p;
        });

        // Next
        const next = currentPage + 1;
        const nextDisabled = (currentPage === totalPages) ? 'disabled' : '';
        const nextOnclick = (currentPage === totalPages) ? '' : 'onclick="' + callbackName + '(' + next + ')"';
        html += '<li class="page-item ' + nextDisabled + '"><a class="page-link page-link-label" href="javascript:void(0)" ' + nextOnclick + '>Next</a></li>';

        return html;
    }

    let holidayCurrentPage = 1;

    function renderHolidayTable(page = 1) {
        if (!calendarData || !calendarData.holidays) { return; }
        holidayCurrentPage = parseInt(page) || 1;
        const search = ($('#acHolidaySearch').val() || '').toLowerCase();
        const perPage = parseInt($('#acHolidayPerPage').val() || '10');

        const holidays = calendarData.holidays.filter(function(h) {
            if (!search) return true;
            return (h.holiday_name || '').toLowerCase().includes(search) ||
                   (h.holiday_date || '').includes(search) ||
                   (h.holiday_type || '').toLowerCase().includes(search);
        });

        const totalRows = holidays.length;
        const totalPages = Math.ceil(totalRows / perPage) || 1;
        if (holidayCurrentPage > totalPages) holidayCurrentPage = totalPages;
        if (holidayCurrentPage < 1) holidayCurrentPage = 1;

        const startIndex = (holidayCurrentPage - 1) * perPage;
        const pageRows = holidays.slice(startIndex, startIndex + perPage);

        if (totalRows === 0) {
            $('#acHolidayTableBody').html('<tr><td colspan="7" class="text-center px-6 py-8 text-slate-400">No holidays found</td></tr>');
            $('#acHolidayPaginationWrapper').html('');
            $('#acHolidayPaginationSummary').text('Showing 0 results of 0');
            return;
        }

        let html = '';
        pageRows.forEach(function(h, i) {
            const rowNumber = startIndex + i + 1;
            const enabledClass = parseInt(h.is_enabled) === 1 ? '' : 'opacity-50';
            const statusBadge = parseInt(h.is_enabled) === 1
                ? '<span class="badge bg-label-success">Enabled</span>'
                : '<span class="badge bg-label-secondary">Disabled</span>';
            html += '<tr class="group transition-colors hover:bg-slate-50/50 ' + enabledClass + '">';
            html += '<td class="px-6 py-3 align-middle text-[13px] font-semibold text-slate-900 whitespace-nowrap">' + rowNumber + '</td>';
            html += '<td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-600">' + formatDate(h.holiday_date) + '</td>';
            html += '<td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-500">' + getDayName(h.holiday_date) + '</td>';
            html += '<td class="px-6 py-3 align-middle text-[13px] font-semibold text-slate-900">' + escapeHtml(h.holiday_name) + '</td>';
            html += '<td class="px-6 py-3 align-middle">' + getTypeBadge(h.holiday_type) + '</td>';
            html += '<td class="px-6 py-3 align-middle">' + statusBadge + '</td>';
            if (canManage && calendarData.lifecycle_status === 'draft') {
                html += '<td class="px-6 py-3 align-middle whitespace-nowrap text-center">';
                html += '<button type="button" class="btn btn-icon btn-label-info me-1 acToggleHoliday" data-id="' + parseInt(h.id) + '" title="' + (parseInt(h.is_enabled) === 1 ? 'Disable' : 'Enable') + '"><span class="ti ti-' + (parseInt(h.is_enabled) === 1 ? 'eye-off' : 'eye') + '"></span></button>';
                html += '<button type="button" class="btn btn-icon btn-label-warning me-1 acEditHoliday" data-id="' + parseInt(h.id) + '" title="Edit"><span class="ti ti-pencil"></span></button>';
                html += '<button type="button" class="btn btn-icon btn-label-danger me-1 acDeleteHoliday" data-id="' + parseInt(h.id) + '" title="Delete"><span class="ti ti-trash"></span></button>';
                html += '</td>';
            } else if (canManage) {
                html += '<td class="px-6 py-3 align-middle text-center text-slate-400"><i class="ti ti-lock"></i></td>';
            }
            html += '</tr>';
        });
        $('#acHolidayTableBody').html(html);

        $('#acHolidayPaginationWrapper').html(renderSmartPaginationJs(totalPages, holidayCurrentPage, 'changeHolidayPage'));
        const startItem = totalRows > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(startIndex + perPage, totalRows);
        $('#acHolidayPaginationSummary').text('Showing ' + startItem + ' to ' + endItem + ' results of ' + totalRows);
    }

    window.changeHolidayPage = function(page) {
        renderHolidayTable(page);
    };

    function renderMonthly() {
        if (!monthlyData || monthlyData.length === 0) {
            $('#acMonthlyBody').html('<tr><td colspan="7" class="text-center px-4 py-6 text-slate-400">\u2014</td></tr>');
            return;
        }
        let html = '';
        let totalDays = 0, totalWeeklyOff = 0, totalSun = 0, totalSatOff = 0, totalHol = 0, totalWd = 0;
        monthlyData.forEach(function(m) {
            const weeklyOffs = m.weekly_offs !== undefined ? m.weekly_offs : (m.sundays + m.sat_offs);
            totalDays += m.total_days; totalWeeklyOff += weeklyOffs; totalSun += m.sundays;
            totalSatOff += m.sat_offs; totalHol += m.holidays; totalWd += m.working_days;
            html += '<tr class="group transition-colors hover:bg-slate-50/50">';
            html += '<td class="px-4 py-2.5 text-[13px] font-semibold text-slate-900">' + m.month_name.substring(0, 3) + '</td>';
            html += '<td class="px-3 py-2.5 text-[13px] text-center text-slate-600">' + m.total_days + '</td>';
            html += '<td class="px-3 py-2.5 text-[13px] text-center text-slate-700 font-semibold">' + weeklyOffs + '</td>';
            html += '<td class="px-3 py-2.5 text-[13px] text-center text-rose-500 font-medium">' + m.sundays + '</td>';
            html += '<td class="px-3 py-2.5 text-[13px] text-center text-amber-500 font-medium">' + m.sat_offs + '</td>';
            html += '<td class="px-3 py-2.5 text-[13px] text-center text-purple-500 font-medium">' + m.holidays + '</td>';
            html += '<td class="px-3 py-2.5 text-[13px] text-center text-emerald-700 font-extrabold">' + m.working_days + '</td>';
            html += '</tr>';
        });
        // Total row
        html += '<tr class="border-t-2 border-slate-300 bg-slate-50 font-bold">';
        html += '<td class="px-4 py-2.5 text-[13px] font-extrabold text-slate-900">Total</td>';
        html += '<td class="px-3 py-2.5 text-[13px] text-center text-slate-900">' + totalDays + '</td>';
        html += '<td class="px-3 py-2.5 text-[13px] text-center text-slate-900">' + totalWeeklyOff + '</td>';
        html += '<td class="px-3 py-2.5 text-[13px] text-center text-rose-600">' + totalSun + '</td>';
        html += '<td class="px-3 py-2.5 text-[13px] text-center text-amber-600">' + totalSatOff + '</td>';
        html += '<td class="px-3 py-2.5 text-[13px] text-center text-purple-600">' + totalHol + '</td>';
        html += '<td class="px-3 py-2.5 text-[13px] text-center text-emerald-700 font-extrabold">' + totalWd + '</td>';
        html += '</tr>';
        $('#acMonthlyBody').html(html);
    }

    function renderYearGrid() {
        if (!calendarDays.length) {
            $('#acYearGrid').html('<div class="col-span-full py-8 text-center text-slate-400">No calendar dates available</div>');
            return;
        }
        const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        let html = '';
        monthNames.forEach(function(monthName, monthIndex) {
            const monthNumber = String(monthIndex + 1).padStart(2, '0');
            const monthDays = calendarDays.filter(day => day.calendar_date.substring(5, 7) === monthNumber);
            const leading = new Date(monthDays[0].calendar_date + 'T00:00:00').getDay();
            html += '<div class="ac-month-card">';
            html += '<div class="ac-month-title">' + monthName + '</div>';
            html += '<div class="ac-month-grid">';
            ['S','M','T','W','T','F','S'].forEach(label => { html += '<div class="ac-day-header">' + label + '</div>'; });
            for (let blank = 0; blank < leading; blank++) html += '<div></div>';
            monthDays.forEach(function(day) {
                const number = parseInt(day.calendar_date.substring(8, 10));
                let classes = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                if (day.day_type === 'weekly_off') classes = 'bg-amber-50 text-amber-700 border-amber-200';
                if (day.day_type === 'holiday') classes = 'bg-purple-50 text-purple-700 border-purple-200';
                if (parseInt(day.is_optional_holiday || 0) === 1) classes = 'bg-sky-50 text-sky-700 border-sky-200';
                let detail = formatDate(day.calendar_date) + ' \u00b7 ' + day.day_name
                    + ' \u00b7 ' + day.day_type.replace('_', ' ');
                if (day.holiday_names) {
                    detail += ' \u00b7 ' + day.holiday_names;
                    const typeLabels = String(day.holiday_types || '').split(',').filter(Boolean)
                        .map(type => (holidayTypeMeta[type] && holidayTypeMeta[type].label) || type);
                    if (typeLabels.length) detail += ' (' + typeLabels.join(', ') + ')';
                }
                if (parseInt(day.is_optional_holiday || 0) === 1) detail += ' \u00b7 optional, not deducted';
                if (parseInt(day.is_overridden || 0) === 1) detail += ' \u00b7 overridden';
                const marker = day.holiday_names
                    ? '<span style="display:inline-block; width:4px; height:4px; border-radius:50%; background-color:currentColor; margin-top:2px;"></span>'
                    : '';
                html += '<div class="ac-day-cell ' + classes + '" title="' + escapeHtml(detail) + '">'
                    + '<span>' + number + '</span>' + marker + '</div>';
            });
            html += '</div></div>';
        });
        $('#acYearGrid').html(html);
    }

    let auditCurrentPage = 1;

    function renderAudit(page = 1) {
        auditCurrentPage = parseInt(page) || 1;
        const filter = ($('#acAuditFilter').val() || '').toLowerCase();
        const perPage = parseInt($('#acAuditPerPage').val() || '10');

        const events = (auditEvents || []).filter(function(event) {
            if (!filter) return true;
            return [event.action, event.changed_by_name, event.reason, event.field_changed, event.new_value]
                .some(function(value) { return String(value || '').toLowerCase().includes(filter); });
        });

        if (canExport && calendarData) {
            $('#acAuditExportBtn').attr('href', 'annual-calendar-export.php?format=audit&calendar_id=' + encodeURIComponent(calendarData.id));
        }

        const totalRows = events.length;
        const totalPages = Math.ceil(totalRows / perPage) || 1;
        if (auditCurrentPage > totalPages) auditCurrentPage = totalPages;
        if (auditCurrentPage < 1) auditCurrentPage = 1;

        const startIndex = (auditCurrentPage - 1) * perPage;
        const pageRows = events.slice(startIndex, startIndex + perPage);

        if (!totalRows) {
            $('#acAuditBody').html('<tr><td colspan="5" class="px-5 py-6 text-center text-slate-400">No audit activity</td></tr>');
            $('#acAuditPaginationWrapper').html('');
            $('#acAuditPaginationSummary').text('Showing 0 results of 0');
            return;
        }

        let html = '';
        pageRows.forEach(function(event) {
            const change = event.reason || [event.old_value, event.new_value].filter(Boolean).join(' \u2192 ') || '\u2014';
            html += '<tr class="border-b border-slate-100">';
            html += '<td class="px-5 py-3 whitespace-nowrap">' + escapeHtml(event.changed_at) + '</td>';
            html += '<td class="px-5 py-3">Rev ' + parseInt(event.revision_no || 1) + '</td>';
            html += '<td class="px-5 py-3 font-semibold text-slate-800">' + escapeHtml(String(event.action || '').replaceAll('_', ' ')) + '</td>';
            html += '<td class="px-5 py-3">' + escapeHtml(event.changed_by_name) + '</td>';
            html += '<td class="px-5 py-3 max-w-md">' + escapeHtml(change) + '</td>';
            html += '</tr>';
        });
        $('#acAuditBody').html(html);

        $('#acAuditPaginationWrapper').html(renderSmartPaginationJs(totalPages, auditCurrentPage, 'changeAuditPage'));
        const startItem = totalRows > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(startIndex + perPage, totalRows);
        $('#acAuditPaginationSummary').text('Showing ' + startItem + ' to ' + endItem + ' results of ' + totalRows);
    }

    window.changeAuditPage = function(page) {
        renderAudit(page);
    };

    // Event Handlers
    $('#acLoadBtn').on('click', loadCalendar);

    $('#acInitBtn').on('click', function() {
        const companyId = $('#acCompanySelect').val();
        const year = $('#acYearSelect').val();
        $(this).prop('disabled', true).html('<i class="ti ti-loader animate-spin text-lg"></i> Initializing...');
        hrmsPost('initialize_annual_calendar', { company_id: companyId, year: year }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else {
                showToast(res.message || 'Initialization failed.', 'error');
            }
        }).fail(function() {
            showToast('Request failed.', 'error');
        }).always(function() {
            $('#acInitBtn').prop('disabled', false).html('<i class="ti ti-plus text-lg"></i> Initialize Annual Calendar');
        });
    });

    // Saturday policy change
    $('#acSaturdayPolicy').on('change', function() {
        if (!calendarData || calendarData.lifecycle_status !== 'draft') return;
        const policy = $(this).val();
        hrmsPost('update_saturday_policy', { calendar_id: calendarData.id, saturday_policy: policy }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                calendarData.saturday_policy = policy;
                renderPolicyUI();
                updateTotals(res.totals);
            } else {
                showToast(res.message || 'Error', 'error');
                renderPolicyUI();
            }
        }).fail(function() { showToast('Request failed.', 'error'); renderPolicyUI(); });
    });

    $('#acSaveCustomOffsBtn').on('click', function() {
        if (!calendarData || calendarData.lifecycle_status !== 'draft') return;
        const dates = ($('#acCustomOffDates').val() || '').split(/[\s,;]+/).map(value => value.trim()).filter(Boolean);
        hrmsPost('save_custom_weekly_offs', { calendar_id: calendarData.id, off_dates: JSON.stringify(dates) }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else {
                showToast(res.message || 'Unable to save custom weekly offs.', 'error');
            }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    $('#acSaveWeeklyOffDaysBtn').on('click', function() {
        if (!calendarData || calendarData.lifecycle_status !== 'draft') return;
        const days = $('.acWeeklyOffDay:checked').map(function() { return parseInt($(this).val()); }).get();
        if (!days.length) { showToast('Select at least one weekly-off day.', 'error'); return; }
        if (days.length >= 7) { showToast('At least one day of the week must remain a working day.', 'error'); return; }
        hrmsPost('update_weekly_off_days', { calendar_id: calendarData.id, weekly_off_days: JSON.stringify(days) }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    $('#acSaveOverrideBtn').on('click', function() {
        if (!calendarData) { showToast('Load a calendar before adding an override.', 'error'); return; }
        if (calendarData.lifecycle_status !== 'draft') { showToast('Unlock the calendar to add a date override. Only a draft revision can be edited.', 'error'); return; }
        const overrideDate = $('#acOverrideDate').val();
        if (!overrideDate) { showToast('Select a date to override.', 'error'); return; }
        hrmsPost('save_calendar_day_override', {
            calendar_id: calendarData.id,
            override_date: overrideDate,
            override_type: $('#acOverrideType').val(),
            note: $('#acOverrideNote').val() || ''
        }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                $('#acOverrideDate').val('');
                $('#acOverrideNote').val('');
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    $(document).on('click', '.acDeleteOverride', function() {
        const id = $(this).data('id');
        if (!confirm('Remove this date override?')) return;
        hrmsPost('delete_calendar_day_override', { override_id: id }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    $('#acCopyYearBtn').on('click', function() {
        const companyId = $('#acCompanySelect').val();
        const year = $('#acYearSelect').val();
        const sourceYear = $('#acCopySourceYear').val();
        if (String(sourceYear) === String(year)) { showToast('Select a different source year.', 'error'); return; }
        $(this).prop('disabled', true);
        hrmsPost('copy_calendar_from_year', { company_id: companyId, year: year, source_year: sourceYear }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) {
            showToast(xhr.responseJSON?.message || 'Request failed.', 'error');
        }).always(function() { $('#acCopyYearBtn').prop('disabled', false); });
    });

    $('#acDiscardDraftBtn').on('click', function() {
        if (!calendarData || calendarData.lifecycle_status !== 'draft') return;
        const reason = prompt('Enter the reason for discarding this draft revision:');
        if (reason === null) return;
        if (reason.trim().length < 5) { showToast('Enter a reason of at least 5 characters.', 'error'); return; }
        hrmsPost('discard_calendar_draft', { calendar_id: calendarData.id, reason: reason.trim() }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    // Holiday search & pagination
    $('#acHolidaySearch').on('input', function() {
        renderHolidayTable(1);
    });

    $(document).on('click', '.ac-holiday-per-page-item', function () {
        const val = $(this).data('val');
        const label = $(this).text();
        $('#acHolidayPerPageText').text(label);
        $('#acHolidayPerPage').val(val);
        $('#acHolidayFooterPerPageSelect').val(val);
        renderHolidayTable(1);
    });

    $('#acHolidayFooterPerPageSelect').on('change', function () {
        const val = $(this).val();
        $('#acHolidayPerPage').val(val);
        renderHolidayTable(1);
    });

    // Audit search & pagination
    $('#acAuditFilter').on('input', function() {
        renderAudit(1);
    });

    $(document).on('click', '.ac-audit-per-page-item', function () {
        const val = $(this).data('val');
        const label = $(this).text();
        $('#acAuditPerPageText').text(label);
        $('#acAuditPerPage').val(val);
        $('#acAuditFooterPerPageSelect').val(val);
        renderAudit(1);
    });

    $('#acAuditFooterPerPageSelect').on('change', function () {
        const val = $(this).val();
        $('#acAuditPerPage').val(val);
        renderAudit(1);
    });

    // Add Holiday
    $('#acAddHolidayBtn').on('click', function() {
        $('#acHolidayModalTitle').text('Add Holiday');
        $('#acHolidayId').val('');
        $('#acHolidayForm')[0].reset();
        // Set min/max for date
        const year = $('#acYearSelect').val();
        $('#acHolidayDate').attr('min', year + '-01-01').attr('max', year + '-12-31');
        const modal = new bootstrap.Modal(document.getElementById('acHolidayModal'));
        modal.show();
    });

    // Edit Holiday
    $(document).on('click', '.acEditHoliday', function() {
        const id = $(this).data('id');
        const holiday = calendarData.holidays.find(h => parseInt(h.id) === parseInt(id));
        if (!holiday) return;
        $('#acHolidayModalTitle').text('Edit Holiday');
        $('#acHolidayId').val(holiday.id);
        $('#acHolidayDate').val(holiday.holiday_date);
        $('#acHolidayName').val(holiday.holiday_name);
        $('#acHolidayType').val(holiday.holiday_type);
        const year = $('#acYearSelect').val();
        $('#acHolidayDate').attr('min', year + '-01-01').attr('max', year + '-12-31');
        const modal = new bootstrap.Modal(document.getElementById('acHolidayModal'));
        modal.show();
    });

    // Save Holiday (add/edit)
    $('#acHolidayForm').on('submit', function(e) {
        e.preventDefault();
        const id = $('#acHolidayId').val();
        const action = id ? 'update_calendar_holiday' : 'add_calendar_holiday';
        const data = {
            calendar_id: calendarData.id,
            holiday_date: $('#acHolidayDate').val(),
            holiday_name: $('#acHolidayName').val(),
            holiday_type: $('#acHolidayType').val(),
        };
        if (id) data.holiday_id = id;

        hrmsPost(action, data).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                bootstrap.Modal.getInstance(document.getElementById('acHolidayModal'))?.hide();
                loadCalendar();
            } else {
                showToast(res.message || 'Error', 'error');
            }
        }).fail(function() { showToast('Request failed.', 'error'); });
    });

    // Toggle Holiday
    $(document).on('click', '.acToggleHoliday', function() {
        const id = $(this).data('id');
        hrmsPost('toggle_calendar_holiday', { holiday_id: id }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function() { showToast('Request failed.', 'error'); });
    });

    // Delete Holiday
    $(document).on('click', '.acDeleteHoliday', function() {
        const id = $(this).data('id');
        const holiday = calendarData.holidays.find(h => parseInt(h.id) === parseInt(id));
        const name = holiday ? holiday.holiday_name : 'this holiday';
        if (!confirm('Remove "' + name + '" from this draft calendar?')) return;
        hrmsPost('delete_calendar_holiday', { holiday_id: id }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function() { showToast('Request failed.', 'error'); });
    });

    // Import Defaults
    $('#acImportDefaultsBtn').on('click', function() {
        if (!calendarData) return;
        if (!confirm('Import default Indian holidays for this year? Existing holidays will not be duplicated.')) return;
        hrmsPost('import_default_holidays', { calendar_id: calendarData.id }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function() { showToast('Request failed.', 'error'); });
    });

    // Holiday CSV import
    $('#acImportCsvBtn').on('click', function() {
        if (!calendarData) return;
        $('#acImportJurisdiction').val('');
        $('#acImportVersion').val('');
        $('#acImportFile').val('');
        $('#acImportPreview').addClass('hidden');
        $('#acImportPreviewBody').empty();
        $('#acImportErrors').empty();
        $('#acImportConfirmBtn').prop('disabled', true);
        new bootstrap.Modal(document.getElementById('acImportCsvModal')).show();
    });

    function postHolidayCsv(confirmImport) {
        const file = $('#acImportFile')[0].files[0];
        const jurisdiction = ($('#acImportJurisdiction').val() || '').trim();
        if (!file) { showToast('Select a CSV file.', 'error'); return null; }
        if (jurisdiction.length < 2) { showToast('Enter the jurisdiction this list applies to.', 'error'); return null; }
        const form = new FormData();
        form.append('action', 'import_holiday_csv');
        form.append('csrf_token', csrfToken);
        form.append('calendar_id', calendarData.id);
        form.append('jurisdiction', jurisdiction);
        form.append('dataset_version', ($('#acImportVersion').val() || '').trim());
        form.append('confirm', confirmImport ? '1' : '0');
        form.append('holiday_file', file);
        return $.ajax({
            url: 'hrms-api.php', method: 'POST', data: form,
            processData: false, contentType: false, dataType: 'json'
        });
    }

    $('#acImportPreviewBtn').on('click', function() {
        const request = postHolidayCsv(false);
        if (!request) return;
        $(this).prop('disabled', true);
        request.done(function(res) {
            if (res.status !== 'success') { showToast(res.message || 'Error', 'error'); return; }
            const rows = res.rows || [];
            const errors = res.errors || [];
            let html = '';
            rows.forEach(function(row) {
                html += '<tr class="border-b border-slate-100">';
                html += '<td class="px-3 py-1.5">' + escapeHtml(row.date) + '</td>';
                html += '<td class="px-3 py-1.5">' + escapeHtml(row.name) + '</td>';
                html += '<td class="px-3 py-1.5">' + escapeHtml(row.type) + '</td>';
                html += '<td class="px-3 py-1.5">' + (parseInt(row.is_optional) === 1 ? 'Yes' : 'No') + '</td>';
                html += '</tr>';
            });
            $('#acImportPreviewBody').html(html || '<tr><td colspan="4" class="px-3 py-3 text-center text-slate-400">No valid rows</td></tr>');
            $('#acImportErrors').html(errors.map(e => '<li>' + escapeHtml(e) + '</li>').join(''));
            $('#acImportSummary').text(res.message || '');
            $('#acImportPreview').removeClass('hidden');
            $('#acImportConfirmBtn').prop('disabled', rows.length === 0);
        }).fail(function(xhr) {
            showToast(xhr.responseJSON?.message || 'Request failed.', 'error');
        }).always(function() { $('#acImportPreviewBtn').prop('disabled', false); });
    });

    $('#acImportConfirmBtn').on('click', function() {
        const request = postHolidayCsv(true);
        if (!request) return;
        $(this).prop('disabled', true);
        request.done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                bootstrap.Modal.getInstance(document.getElementById('acImportCsvModal'))?.hide();
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) {
            showToast(xhr.responseJSON?.message || 'Request failed.', 'error');
        }).always(function() { $('#acImportConfirmBtn').prop('disabled', false); });
    });

    // Finalize
    $('#acFinalizeBtn').on('click', function() {
        if (!calendarData) { showToast('Load a calendar before finalizing it.', 'error'); return; }
        if (!confirm('Finalize and publish this revision as the company master calendar? The revision becomes immutable.')) return;
        hrmsPost('finalize_annual_calendar', { calendar_id: calendarData.id, lock_version: calendarData.lock_version }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    // Reopen as a successor revision
    $('#acUnfinalizeBtn').on('click', function() {
        if (!calendarData) { showToast('Load a calendar before unlocking it.', 'error'); return; }
        if (payrollRuns.length) {
            const runs = payrollRuns.map(run => run.run_number + ' (' + run.payroll_month + ')').join(', ');
            if (!confirm('This revision is locked to finalized payroll run(s): ' + runs
                + '.\n\nHistorical pay runs keep their own snapshot, but reports for open periods will move to the new revision once it is finalized.\n\nContinue?')) {
                return;
            }
        }
        const reason = prompt('Enter the reason for creating a corrected draft revision:');
        if (reason === null) return;
        if (reason.trim().length < 5) { showToast('Enter a reason of at least 5 characters.', 'error'); return; }
        hrmsPost('unfinalize_annual_calendar', {
            calendar_id: calendarData.id,
            reason: reason.trim(),
            acknowledge_payroll_impact: payrollRuns.length ? '1' : '0'
        }).done(function(res) {
            if (res.status === 'success') {
                showToast(res.message);
                loadCalendar();
            } else { showToast(res.message || 'Error', 'error'); }
        }).fail(function(xhr) { showToast(xhr.responseJSON?.message || 'Request failed.', 'error'); });
    });

    // Summary tile click-to-scroll/filter
    $('#acSummaryCards').on('click', '[data-tile-filter]', function() {
        const filter = $(this).data('tile-filter');
        // Highlight active tile
        $('#acSummaryCards [data-tile-filter]').removeClass('ring-2 ring-offset-2');
        $(this).addClass('ring-2 ring-offset-2');

        switch (filter) {
            case 'all':
                // Scroll to Full Year Calendar
                scrollTarget = document.getElementById('acFullYearCalendarSection') || document.getElementById('acYearGrid');
                break;
            case 'sundays':
            case 'saturday_offs':
            case 'working':
                // Scroll to monthly breakdown table
                scrollTarget = document.querySelector('.ac-right-col');
                break;
            case 'holidays':
                // Scroll to holiday table and clear search
                scrollTarget = document.getElementById('acHolidayTableBody')?.closest('.ac-left-col');
                break;
            case 'status':
                // Scroll to the Saturday Policy / finalize actions bar
                scrollTarget = document.getElementById('acFinalizeBtn')?.closest('.rounded-2xl') || document.getElementById('acSaturdayPolicy')?.closest('.rounded-2xl');
                break;
            default:
                // "all" - scroll to Full Year Calendar
                scrollTarget = document.getElementById('acFullYearCalendarSection') || document.getElementById('acYearGrid') || document.querySelector('.ac-right-col');
                break;
        }
        if (scrollTarget) {
            scrollTarget.scrollIntoView({ behavior: 'smooth', block: 'start' });
            if (filter === 'all') {
                const $section = $('#acFullYearCalendarSection');
                $section.addClass('ring-2 ring-emerald-500/50 ring-offset-2 transition-all');
                setTimeout(function() {
                    $section.removeClass('ring-2 ring-emerald-500/50 ring-offset-2');
                }, 1500);
            }
        }
    });
    // Keyboard accessibility for tiles
    $('#acSummaryCards').on('keydown', '[data-tile-filter]', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            $(this).trigger('click');
        }
    });

    // Auto-load on page ready
    $(document).ready(function() {
        if ($.fn.select2) {
            $('#acYearSelect').select2({ width: '140px', minimumResultsForSearch: 8 });
        }
        loadCalendar();
    });
})(jQuery);
</script>
<?php endSection(); ?>
