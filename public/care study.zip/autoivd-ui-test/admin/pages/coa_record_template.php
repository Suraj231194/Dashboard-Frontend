<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../document_pdf_helpers.php';
require_once __DIR__ . '/../workflow/bmr_bpr_common.php';
require_once __DIR__ . '/../workflow/coa_templates/common.php';

try {
    $coaType = coaTemplateNormalizeType((string) ($_GET['type'] ?? ''));
} catch (Throwable) {
    http_response_code(422);
    exit('A valid COA type is required.');
}

$permission = $coaType === 'IP' ? 'ip_coa_generation_view' : 'fg_coa_generation_view';
documentPdfRequireAnyPermission($conn, [$permission]);
$recordId = documentPdfEncryptedPositiveId($_GET['id'] ?? '');

$recordTable = $coaType === 'IP' ? 'ip_coa_generation' : 'fg_coa_generation';
$existenceStmt = $conn->prepare(
    "SELECT coa_template_id, template_snapshot_id
     FROM {$recordTable} WHERE id = ? AND deleted_at IS NULL LIMIT 1"
);
$existenceStmt->bind_param('i', $recordId);
$existenceStmt->execute();
$existingRecord = $existenceStmt->get_result()->fetch_assoc();
$existenceStmt->close();
if (!$existingRecord) {
    http_response_code(404);
    exit('COA record not found.');
}
if (
    (int) ($existingRecord['coa_template_id'] ?? 0) <= 0
    && (int) ($existingRecord['template_snapshot_id'] ?? 0) <= 0
) {
    http_response_code(422);
    exit('This record does not contain a structured COA document.');
}

try {
    $form = coaTemplateLoadSavedForm($conn, $coaType, $recordId);
    $form['branding_logo_data_uri'] = bmrBprBrandingLogoDataUri($conn);
    $renderedHtml = coaTemplateRender($form, false);
    if ($renderedHtml === '') {
        throw new RuntimeException('The structured COA document could not be rendered.');
    }
} catch (Throwable $exception) {
    http_response_code(422);
    exit(htmlspecialchars($exception->getMessage(), ENT_QUOTES, 'UTF-8'));
}

$sourceValues = $form['source_values'];
$profile = $form['profile'];
$safeFilename = preg_replace(
    '/[^A-Za-z0-9_-]+/',
    '_',
    $coaType
    . '_COA_'
    . ($profile['product_name'] ?? 'Record')
    . '_'
    . ($sourceValues['batch_number'] ?? $recordId)
);
$safeFilename = trim((string) $safeFilename, '_') ?: $coaType . '_COA_Record';
$documentHtml = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
    . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
    . '<title>' . htmlspecialchars($safeFilename, ENT_QUOTES, 'UTF-8') . '</title>'
    . '<style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0;background:#e5e7eb}'
    . '@media print{html,body{background:#fff}}</style></head><body>'
    . $renderedHtml . '</body></html>';

if ((string) ($_GET['triggerDownload'] ?? '') === '1') {
    documentPdfStream($documentHtml, $safeFilename);
}

echo $documentHtml;
