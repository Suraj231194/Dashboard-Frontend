<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage and track production plans</p>
        </div>
    </div>

    <!-- New Production Plan Widget -->
    <div id="newProductionPlanWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" role="button" tabindex="0"
        aria-controls="newProductionPlanModal">
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
            style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div
                    style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                    <i class="ti ti-clipboard-list"
                        style="font-size: 1.5rem; color: var(--appearance-accent, #7e22ce);"></i>
                    <span
                        style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight"
                            style="font-size: 1.125rem; color: var(--ui-text, #1e293b); margin: 0;">New Production Plan!
                        </h3>
                        <span id="newProductionPlanCount" aria-live="polite"
                            style="display: flex; align-items: center; justify-content: center; min-width: 1.25rem; height: 1.25rem; padding: 0 0.3rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px;">0</span>
                    </div>
                    <p class="font-medium mt-1 mb-0" style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">
                        Pending production plans, including items sent from Order Management.
                    </p>
                </div>
            </div>
            <div style="color: var(--ui-text-muted, #94a3b8);">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="ppPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100">100 items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="1000">1000 items</a></li>
                            <li><a class="pp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'operations_admin_production_plan_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-10 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal" title="Add New" aria-label="Add New">
                            <i class="ti ti-plus text-xl"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-28 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="date" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="production_plan_no" data-order="asc">
                                <span class="inline-flex items-center gap-1">Plan No <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Product Name <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-36 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="lo_batch_no" data-order="asc">
                                <span class="inline-flex items-center gap-1">Lot No/Batch No <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="batch_size" data-order="asc">
                                <span class="inline-flex items-center gap-1">Batch Size <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-24 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="timeline" data-order="asc">
                                <span class="inline-flex items-center gap-1">Timeline <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-24 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="status" data-order="asc">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-xs text-slate-400"></i></span>
                            </th>
                            <th class="w-48 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Created By</th>
                            <th
                                class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="employeesTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer since it's now in the top strip -->
            <style>
                #footerPerPageSelect+.dropdown {
                    display: none !important;
                }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                Production Plan</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create new production plan entry</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addProductionPlanForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <div>
                                <label for="dateEntry" class="mb-1 block text-sm font-medium text-slate-800">Date
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="dateEntry" autocomplete="off" name="dateEntry"
                                    class="input-theme" required />
                            </div>
                            <div>
                                <label for="lotNoBatchNo" class="mb-1 block text-sm font-medium text-slate-800">Lot / Batch Campaign No.</label>
                                <input type="text" id="lotNoBatchNo" autocomplete="off" name="lotNoBatchNo"
                                    class="input-theme bg-slate-100" placeholder="Generated automatically upon save" readonly />
                            </div>
                        </div>

                        <!-- Multi-Product Grouping Repeater (Items 8.2 & 8.4) -->
                        <div class="mb-4 rounded-xl border border-slate-200 bg-white p-3.5 shadow-xs">
                            <div class="mb-3 flex items-center justify-between">
                                <div>
                                    <h6 class="m-0 text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                                        <i class="ti ti-packages text-emerald-700 text-sm"></i> Products in Batch Run / Campaign
                                    </h6>
                                    <p class="m-0 text-[11px] text-slate-500">Group multiple finished products under a shared batch and timeline</p>
                                </div>
                                <button type="button" id="btnAddProductToBatch"
                                    class="inline-flex h-8 items-center gap-1.5 rounded-lg border border-emerald-300 bg-emerald-50 px-3 text-xs font-bold text-emerald-800 shadow-xs hover:bg-emerald-100 transition-all cursor-pointer">
                                    <i class="ti ti-plus"></i> Add Product
                                </button>
                            </div>

                            <div id="prodPlanProductsRepeater" class="space-y-3">
                                <div class="prod-plan-item-row rounded-lg border border-slate-200 bg-slate-50/50 p-3" data-row-idx="0">
                                    <div class="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-end">
                                        <div class="md:col-span-6">
                                            <label class="mb-1 block text-xs font-semibold text-slate-700">Product Name <strong class="text-rose-500">*</strong></label>
                                            <select name="productName[]" class="input-theme select2 pp-product-select" required>
                                                <option value="">----Select Product----</option>
                                            </select>
                                        </div>
                                        <div class="md:col-span-3">
                                            <label class="mb-1 block text-xs font-semibold text-slate-700">Batch Size <strong class="text-rose-500">*</strong></label>
                                            <input type="number" min="0.01" step="any" name="prodPlanBatchSize[]" class="input-theme" placeholder="Batch Size" required />
                                        </div>
                                        <div class="md:col-span-2">
                                            <label class="mb-1 block text-xs font-semibold text-slate-700">Unit <strong class="text-rose-500">*</strong></label>
                                            <select name="prodPlanBatchSizeUnit[]" class="input-theme pp-unit-select" required></select>
                                        </div>
                                        <div class="md:col-span-1 flex justify-center">
                                            <button type="button" class="remove-pp-item-btn inline-flex h-10 w-10 items-center justify-center rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors opacity-40 cursor-not-allowed" disabled title="Cannot remove initial product">
                                                <i class="ti ti-trash text-base"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Timeline <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="urgentlyStatus" name="timelineStatus" value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Urgently
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="flexibleStatus" name="timelineStatus" value="2"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Flexible
                                    </label>
                                </div>
                            </div>

                            <div>
                                <label for="prodPlanRemark"
                                    class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea id="prodPlanRemark" autocomplete="off" rows="2" name="prodPlanRemark"
                                    class="input-theme" placeholder="Enter Remark"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="editUserModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="editEmployeeForm">
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="productionPlanEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Production Plan</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="productionPlanEditForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="productionPlanViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View Production Plan</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="productionPlanViewForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="animationModalBom" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4">
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add Production
                        Plan</h5>
                    <button type="button"
                        class="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addProductionPlanFormBom">
                    <div class="modal-body bg-white !px-6 !py-5">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
                            <div>
                                <label for="dateEntryBom" class="mb-1 block text-sm font-medium text-slate-800">Date
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="date" id="dateEntryBom" autocomplete="off" name="dateEntryBom"
                                    class="input-theme" placeholder="Enter Date" required />
                            </div>
                            <div>
                                <label for="ppFinishedProductSelect"
                                    class="mb-1 block text-sm font-medium text-slate-800">Finished Product <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="ppFinishedProductSelect" class="input-theme select2" required>
                                    <option value="">Search finished product...</option>
                                </select>
                                <input type="hidden" id="productNameBom" name="productNameBom">
                            </div>
                            <div>
                                <label for="bomType" class="mb-1 block text-sm font-medium text-slate-800">BOM Type
                                    <strong class="text-rose-500">*</strong></label>
                                <select id="bomType" name="bomType" class="input-theme select2" required>
                                    <?php
                                    if (!empty(Constant::STOCKS['BOM_TYPES'])) {
                                        echo '<option value="">----Select----</option>';
                                        foreach (Constant::STOCKS['BOM_TYPES'] as $tdkey => $tdval) {
                                            echo '<option value="' . $tdkey . '">' . $tdval['label'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div>
                                <label for="bomMaster" class="mb-1 block text-sm font-medium text-slate-800">BOM Product
                                    <strong class="text-rose-500">*</strong></label>
                                <select id="bomMaster" autocomplete="off" name="bom_id" class="input-theme select2"
                                    required>
                                    <option value="">Select value</option>
                                </select>
                                <div id="ppNoBomAlert" class="mt-1.5" style="display: none;">
                                    <div class="flex items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2">
                                        <i class="ti ti-alert-triangle text-amber-600 text-base"></i>
                                        <span class="text-xs font-semibold text-amber-800">No approved BOM found for this product.</span>
                                        <button type="button" id="ppCreateCloneBomBtn" class="ms-auto inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-2.5 py-1 text-[11px] font-bold text-white shadow-sm transition-colors hover:bg-indigo-700">
                                            <i class="ti ti-copy text-sm"></i> Create / Clone BOM
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <input type="hidden" id="finishedProductId" name="finishedProductId">
                            <div>
                                <label for="productCategory"
                                    class="mb-1 block text-sm font-medium text-slate-800">Product Category</label>
                                <input type="text" id="productCategory" autocomplete="off" name="productCategory"
                                    class="input-theme bg-slate-100" placeholder="Product Category" readonly />
                            </div>
                            <div>
                                <label for="finishedGood" class="mb-1 block text-sm font-medium text-slate-800">Finished
                                    Good</label>
                                <input type="text" id="finishedGood" autocomplete="off" name="finishedGood"
                                    class="input-theme bg-slate-100" placeholder="Finished Good" readonly />
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="lotNoBatchNoBom" class="mb-1 block text-sm font-medium text-slate-800">Lot
                                    No./Batch No.</label>
                                <input type="text" id="lotNoBatchNoBom" autocomplete="off" name="lotNoBatchNoBom"
                                    class="input-theme bg-slate-100" placeholder="Generated automatically" readonly />
                            </div>
                            <div>
                                <label for="prodPlanBatchSizeBom"
                                    class="mb-1 block text-sm font-medium text-slate-800">Batch Size <strong
                                        class="text-rose-500">*</strong></label>
                                <input type="number" min="0" step="any" id="prodPlanBatchSizeBom" autocomplete="off"
                                    name="prodPlanBatchSizeBom" class="input-theme" placeholder="Enter Batch Size"
                                    required />
                            </div>
                            <div>
                                <label for="prodPlanBatchSizeUnitBom"
                                    class="mb-1 block text-sm font-medium text-slate-800">Batch Size Unit <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="prodPlanBatchSizeUnitBom" name="prodPlanBatchSizeUnitBom"
                                    class="input-theme select2" required></select>
                            </div>
                        </div>

                        <div id="bomCheckResult" class="mb-4"></div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Timeline <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="urgentlyStatusBom" name="timelineStatusBom" value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Urgently
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="flexibleStatusBom" name="timelineStatusBom" value="2"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Flexible
                                    </label>
                                </div>
                            </div>

                            <div>
                                <label for="prodPlanRemarkBom"
                                    class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea id="prodPlanRemarkBom" autocomplete="off" rows="2" name="prodPlanRemarkBom"
                                    class="input-theme" placeholder="Enter Remark"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white !px-6 !py-4">
                        <button type="button"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl text-white font-bold shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                            style="background-color: #f2994a; border-color: #f2994a;" id="checkBomBtn">
                            Check BOM & Stock
                        </button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl text-white font-bold shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                            style="background-color: #7f56d9; border-color: #7f56d9;" id="submitPlanBtn" disabled>
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-6 col-md-6">
        <div class="mt-3">
            <div class="offcanvas offcanvas-end" tabindex="-1" id="productionPlanHistoryView">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title">Production Plan History</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                </div>
                <div class="offcanvas-body">
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';
    let currentNewProductionPlanPage = 1;
    let productionPlanRefreshTimer = null;
    let cachedPlanProductsHtml = '<option value="">----Select Product----</option>';
    let cachedPlanUnitsHtml = '<option value="">---Select----</option>';

    $(document).on('click', '#employeesTableBody .production-plan-row', function (e) {
        if ($(e.target).closest('button, a, input, select, textarea, .dropdown').length) {
            return;
        }
        const $viewBtn = $(this).find('.productionPlanViewModalBtn');
        if ($viewBtn.length) {
            $viewBtn.trigger('click');
        }
    });

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                cachedPlanUnitsHtml = optionsHtml;
                $("#prodPlanBatchSizeUnit, .pp-unit-select").html(optionsHtml).trigger('change');
                $("#prodPlanBatchSizeUnitBom").html(optionsHtml).trigger('change');
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }
    function loadProductionPlanTable(page = 1, showLoader = true) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();

        if (showLoader) {
            $('#employeesTableBody').html('<tr><td colspan="10" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProductionPlan: 'loadProductionPlan',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#employeesTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const visibleRows = Number(response.visibleRows || 0);
                const totalRows = Number(response.totalRows || 0);
                if (response.visibleRows !== undefined) {
                    const shownThrough = Math.min(currentPage * parseInt(perPage), totalRows);

                }
            },
            error: function () {
                $('#employeesTableBody').html('<tr><td colspan="10" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    function escapeNewProductionPlanText(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function formatNewPlanDate(value) {
        if (!value) return '-';
        const str = String(value).trim();
        if (/^\d{4}-\d{2}-\d{2}/.test(str)) {
            const parts = str.split(' ')[0].split('-');
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return str;
    }

    function productionAlertPageButtons(totalPages, currentPage) {
        const pages = [...new Set([1, totalPages, currentPage - 2, currentPage - 1, currentPage, currentPage + 1, currentPage + 2]
            .filter(page => page >= 1 && page <= totalPages))].sort((a, b) => a - b);
        let previous = 0;
        return pages.map(function (page) {
            const gap = previous && page > previous + 1 ? '<span class="px-1 text-slate-400">&hellip;</span>' : '';
            previous = page;
            const active = page === currentPage ? 'bg-emerald-800 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100';
            return gap + `<button type="button" data-page="${page}" class="new-production-alert-page inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-sm font-bold ${active}">${page}</button>`;
        }).join('');
    }

    let productionPlansForReview = [];

    function loadNewProductionPlans(page = 1, showLoader = false) {
        if (showLoader) {
            $('#newProductionPlanTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadNewProductionPlans: 'loadNewProductionPlans',
                context: 'production',
                page: page
            },
            success: function (response) {
                if (response.status !== 'success') {
                    return;
                }

                const plans = Array.isArray(response.plans) ? response.plans : [];
                productionPlansForReview = plans;
                const totalRows = Number(response.totalRows || 0);
                const totalPages = Math.max(1, Number(response.totalPages || 1));
                currentNewProductionPlanPage = Math.min(Math.max(1, Number(response.page || 1)), totalPages);
                $('#newProductionPlanCount').text(totalRows);

                if (plans.length === 0) {
                    $('#newProductionPlanTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-medium text-slate-500">No new production plans available.</td></tr>');
                } else {
                    const perPage = Number(response.perPage || 10);
                    const start = (currentNewProductionPlanPage - 1) * perPage;
                    const rows = plans.map(function (plan, index) {
                        const urgencyClass = Number(plan.timeline) === 1
                            ? 'bg-rose-50 text-rose-600 ring-rose-500/10'
                            : 'bg-amber-50 text-amber-600 ring-amber-500/20';
                        const locateSearch = plan.batch_no || plan.production_plan_no || plan.product_name || '';

                        return `<tr class="transition-colors hover:bg-slate-50/50">
                            <td class="px-6 py-4 text-slate-900 font-bold">${start + index + 1}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-slate-600">${escapeNewProductionPlanText(formatNewPlanDate(plan.date))}</td>
                            <td class="px-6 py-4 text-slate-900 font-bold">${escapeNewProductionPlanText(plan.product_name)}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-slate-600">${escapeNewProductionPlanText(plan.production_plan_no || '-')}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-slate-600">${escapeNewProductionPlanText(plan.batch_no)}</td>
                            <td class="px-6 py-4 text-slate-600">${escapeNewProductionPlanText(plan.batch_size)}</td>
                            <td class="px-6 py-4 text-slate-600">${escapeNewProductionPlanText(plan.unit)}</td>
                            <td class="px-6 py-4"><span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold ring-1 ring-inset ${urgencyClass}">${escapeNewProductionPlanText(plan.urgency)}</span></td>
                            <td class="px-6 py-4 text-right"><button type="button" class="newProductionPlanLocateBtn inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700" data-plan-id="${plan.id}" data-search="${escapeNewProductionPlanText(locateSearch)}" title="Review Production Plan"><i class="ti ti-chevron-right text-lg"></i></button></td>
                        </tr>`;
                    }).join('');
                    $('#newProductionPlanTableBody').html(rows);
                }

                const perPage = Number(response.perPage || 10);
                const firstRow = totalRows === 0 ? 0 : ((currentNewProductionPlanPage - 1) * perPage) + 1;
                const lastRow = Math.min(currentNewProductionPlanPage * perPage, totalRows);
                $('#newProductionPlanSummary').text(`Showing ${firstRow} to ${lastRow} of ${totalRows} entries`);
                $('#newProductionPlanPrev').prop('disabled', currentNewProductionPlanPage <= 1);
                $('#newProductionPlanNext').prop('disabled', currentNewProductionPlanPage >= totalPages);
                $('#newProductionPlanCurrentPage').html(productionAlertPageButtons(totalPages, currentNewProductionPlanPage));
            },
            error: function () {
                if (showLoader) {
                    $('#newProductionPlanTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-medium text-rose-600">Unable to load new production plans.</td></tr>');
                }
            }
        });
    }

    function refreshProductionPlanData() {
        if (document.hidden) {
            return;
        }
        loadProductionPlanTable(currentPage, false);
        loadNewProductionPlans(currentNewProductionPlanPage, false);
    }

    $(document).ready(function () {
        const linkedOrderNumber = new URLSearchParams(window.location.search).get('order');
        if (linkedOrderNumber) {
            $('#searchUsers').val(linkedOrderNumber);
        }
        loadProductionPlanTable();
        loadNewProductionPlans(1);
        loadStandardUnit();

        $('#animationModal .select2').select2({
            dropdownParent: $('#animationModal')
        });

        // Load products into batch product dropdowns when modal opens
        $('#animationModal').on('show.bs.modal', function () {
            if ($('#prodPlanProductsRepeater .pp-product-select:first option').length <= 1) {
                $.ajax({
                    url: 'ajax.php',
                    method: 'POST',
                    data: { loadAllProductsForPlan: 'loadAllProductsForPlan' },
                    dataType: 'json',
                    success: function (response) {
                        let html = '<option value="">----Select Product----</option>';
                        if (Array.isArray(response)) {
                            response.forEach(function (p) {
                                html += `<option value="${p.key}" data-has-bom="${p.has_bom || 0}" data-product-name="${escapePlanText(p.product_name || p.value)}" data-unit-id="${p.unit_id || ''}">${escapePlanText(p.value)}</option>`;
                            });
                        }
                        cachedPlanProductsHtml = html;
                        $('.pp-product-select').each(function() {
                            const curVal = $(this).val();
                            $(this).html(html);
                            if (curVal) $(this).val(curVal);
                            $(this).trigger('change');
                        });
                    }
                });
            }
            if (cachedPlanUnitsHtml && cachedPlanUnitsHtml.length > 30) {
                $('.pp-unit-select').each(function () {
                    if ($(this).find('option').length <= 1) {
                        $(this).html(cachedPlanUnitsHtml).trigger('change');
                    }
                });
            }
        });

        // Add Product to Batch Campaign (Items 8.2 & 8.4)
        $('#btnAddProductToBatch').on('click', function () {
            const rowCount = $('#prodPlanProductsRepeater .prod-plan-item-row').length;
            const newRow = $(`
                <div class="prod-plan-item-row rounded-lg border border-slate-200 bg-slate-50/50 p-3" data-row-idx="${rowCount}">
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-end">
                        <div class="md:col-span-6">
                            <label class="mb-1 block text-xs font-semibold text-slate-700">Product Name <strong class="text-rose-500">*</strong></label>
                            <select name="productName[]" class="input-theme select2 pp-product-select" required>
                                ${cachedPlanProductsHtml}
                            </select>
                        </div>
                        <div class="md:col-span-3">
                            <label class="mb-1 block text-xs font-semibold text-slate-700">Batch Size <strong class="text-rose-500">*</strong></label>
                            <input type="number" min="0.01" step="any" name="prodPlanBatchSize[]" class="input-theme" placeholder="Batch Size" required />
                        </div>
                        <div class="md:col-span-2">
                            <label class="mb-1 block text-xs font-semibold text-slate-700">Unit <strong class="text-rose-500">*</strong></label>
                            <select name="prodPlanBatchSizeUnit[]" class="input-theme pp-unit-select" required>
                                ${cachedPlanUnitsHtml}
                            </select>
                        </div>
                        <div class="md:col-span-1 flex justify-center">
                            <button type="button" class="remove-pp-item-btn inline-flex h-10 w-10 items-center justify-center rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors cursor-pointer" title="Remove Product">
                                <i class="ti ti-trash text-base"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `);
            $('#prodPlanProductsRepeater').append(newRow);
            newRow.find('.select2').select2({ dropdownParent: $('#animationModal') });
            updatePpItemRemoveButtons();
        });

        $(document).on('click', '.remove-pp-item-btn', function () {
            if ($('#prodPlanProductsRepeater .prod-plan-item-row').length > 1) {
                $(this).closest('.prod-plan-item-row').remove();
                updatePpItemRemoveButtons();
            }
        });

        function updatePpItemRemoveButtons() {
            const rows = $('#prodPlanProductsRepeater .prod-plan-item-row');
            if (rows.length <= 1) {
                rows.find('.remove-pp-item-btn').prop('disabled', true).addClass('opacity-40 cursor-not-allowed');
            } else {
                rows.find('.remove-pp-item-btn').prop('disabled', false).removeClass('opacity-40 cursor-not-allowed');
            }
        }

        $('#animationModalBom .select2:not(#ppFinishedProductSelect)').select2({
            dropdownParent: $('#animationModalBom')
        });

        // Initialize product autocomplete select2 for production plan BOM form
        function initPpFinishedProductSelect() {
            if ($('#ppFinishedProductSelect').data('select2')) {
                try { $('#ppFinishedProductSelect').select2('destroy'); } catch(e) {}
            }
            $('#ppFinishedProductSelect').select2({
                dropdownParent: $('#animationModalBom'),
                width: '100%',
                placeholder: 'Search finished product...',
                minimumInputLength: 0,
                ajax: {
                    url: 'ajax.php',
                    type: 'POST',
                    dataType: 'json',
                    delay: 200,
                    data: params => ({ getFinishedProductsWithBom: '1', term: params.term || '' }),
                    processResults: response => ({ results: Array.isArray(response.results) ? response.results : [] })
                }
            });
        }
        initPpFinishedProductSelect();

        // Auto-detect BOM status when a product is selected in multi-product batch row
        $(document).on('change', '.pp-product-select', function () {
            const $row = $(this).closest('.prod-plan-item-row');
            const $opt = $(this).find('option:selected');
            const productId = Number($(this).val() || 0);
            const productName = $opt.data('product-name') || $opt.text() || '';
            const hasBom = Number($opt.data('has-bom') || 0);
            const unitId = $opt.data('unit-id');

            // Auto-select unit if available
            if (unitId && $row.find('.pp-unit-select').length) {
                $row.find('.pp-unit-select').val(unitId).trigger('change');
            }

            // Remove existing alert in this row
            $row.find('.pp-row-no-bom-alert').remove();

            // If product has no approved BOM, show warning & Create/Clone button
            if (productId > 0 && hasBom === 0) {
                const alertHtml = `
                    <div class="pp-row-no-bom-alert mt-2 flex items-center justify-between gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-xs animate__animated fadeIn">
                        <div class="flex items-center gap-1.5 text-amber-800 font-semibold">
                            <i class="ti ti-alert-triangle text-amber-600 text-base"></i>
                            <span>No approved BOM found for this product.</span>
                        </div>
                        <button type="button" class="pp-row-create-clone-bom-btn inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-2.5 py-1 text-[11px] font-bold text-white shadow-xs hover:bg-indigo-700 cursor-pointer" data-id="${productId}" data-name="${escapePlanText(productName)}">
                            <i class="ti ti-copy text-xs"></i> Create / Clone BOM
                        </button>
                    </div>
                `;
                $row.find('.md\\:col-span-6').append(alertHtml);
            }
        });

        // Click handler for row-level Create/Clone BOM button
        $(document).on('click', '.pp-row-create-clone-bom-btn', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const prodId = Number($(this).data('id') || 0);
            const prodName = String($(this).data('name') || '');

            if (!prodId) {
                toastr.error('Please select a finished product first.');
                return;
            }

            launchCloneModalFromPlan(prodId, prodName);
        });

        // When a finished product is selected in BOM stock-check modal, auto-populate & detect BOM
        $(document).on('select2:select', '#ppFinishedProductSelect', function (e) {
            const data = e.params.data;
            const productId = Number(data.id || 0);
            const productName = data.product_name || data.text || '';
            const hasBom = data.has_bom;
            $('#productNameBom').val(productName);
            $('#finishedProductId').val(productId);
            $('#finishedGood').val(productName);
            // Store for clone modal
            window._ppSelectedProductId = productId;
            window._ppSelectedProductName = productName;
            // Reset BOM selection
            $('#bomMaster').empty().append('<option value="">Select value</option>');
            $('#bomCheckResult').html('');
            $('#submitPlanBtn').prop('disabled', true);

            if (!hasBom) {
                $('#ppNoBomAlert').show();
            } else {
                $('#ppNoBomAlert').hide();
            }

            // Auto-trigger BOM type change to reload BOM list if a BOM type is selected
            if ($('#bomType').val()) {
                $('#bomType').trigger('change');
            }
        });

        // Clear fields when product is cleared
        $(document).on('select2:clear select2:unselect', '#ppFinishedProductSelect', function () {
            $('#productNameBom').val('');
            $('#finishedProductId').val('');
            $('#finishedGood').val('');
            $('#productCategory').val('');
            $('#bomMaster').empty().append('<option value="">Select value</option>');
            $('#bomCheckResult').html('');
            $('#submitPlanBtn').prop('disabled', true);
            $('#ppNoBomAlert').hide();
            window._ppSelectedProductId = null;
            window._ppSelectedProductName = null;
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addProductionPlanForm')[0].reset();
            $('#dateEntry').val('');
            $('#prodPlanProductsRepeater .prod-plan-item-row:not(:first)').remove();
            updatePpItemRemoveButtons();
            $('#animationModal .select2').val(null).trigger('change');
        });

        $('#animationModalBom').on('hidden.bs.modal', function () {
            $('#addProductionPlanFormBom')[0].reset();
            $('#dateEntryBom').val('');
            $('#animationModalBom .select2:not(#ppFinishedProductSelect)').val(null).trigger('change');
            if ($('#ppFinishedProductSelect').data('select2')) {
                $('#ppFinishedProductSelect').val(null).trigger('change');
            }
            $('#productNameBom').val('');
            $('#finishedProductId').val('');
            $('#finishedGood').val('');
            $('#productCategory').val('');
            $('#bomCheckResult').html('');
            $('#submitPlanBtn').prop('disabled', true);
            $('#ppNoBomAlert').hide();
            window._ppSelectedProductId = null;
            window._ppSelectedProductName = null;
        });
        $(document).on('input keyup search', '#searchUsers', function () {
            loadProductionPlanTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadProductionPlanTable(1);
        });
        $(document).on('change', '#footerPerPageSelect', function () {
            $('#perPageSelect').val($(this).val());
            loadProductionPlanTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.pp-per-page-item', function (e) {
            e.preventDefault();
            const val = $(this).attr('data-val') || $(this).data('val');
            const label = $.trim($(this).text());
            $('#ppPerPageText').text(label);
            $('#perPageSelect').val(val);
            if ($('#footerPerPageSelect').length) {
                $('#footerPerPageSelect').val(val);
            }
            loadProductionPlanTable(1);
        });

        $('#addProductionPlanForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addProductionPlanForm');
            const formData = new FormData(form);
            formData.append('addProductionPlan', 'addProductionPlan');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addProductionPlanForm')[0].reset();
                        $('#prodPlanProductsRepeater .prod-plan-item-row:not(:first)').remove();
                        updatePpItemRemoveButtons();
                        loadProductionPlanTable();
                        toastr.success(res.message);
                    } else if (res.status === 'bom_incomplete') {
                        // Graceful Incomplete BOM Verification Alert with direct Create/Clone action
                        let itemsHtml = '<div class="text-left text-xs text-slate-700 space-y-2 mt-3">';
                        (res.incomplete_products || []).forEach(p => {
                            itemsHtml += `
                                <div class="p-3 rounded-xl border border-amber-300 bg-amber-50 flex items-center justify-between gap-3">
                                    <div>
                                        <div class="font-bold text-amber-900 flex items-center gap-1.5"><i class="ti ti-alert-triangle text-amber-600"></i> ${escapePlanText(p.product_name)}</div>
                                        <div class="text-amber-800 text-[11px] mt-1">${escapePlanText(p.issue)}</div>
                                    </div>
                                    <button type="button" class="swal-clone-bom-btn inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-2.5 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 shrink-0 cursor-pointer" data-id="${p.product_id}" data-name="${escapePlanText(p.product_name)}">
                                        <i class="ti ti-copy text-sm"></i> Create / Clone BOM
                                    </button>
                                </div>
                            `;
                        });
                        itemsHtml += '</div>';

                        Swal.fire({
                            icon: 'warning',
                            title: 'Incomplete Bill of Materials (BOM)',
                            html: `<div>${escapePlanText(res.message)}</div>` + itemsHtml,
                            width: '600px',
                            showCancelButton: true,
                            showDenyButton: (res.incomplete_products && res.incomplete_products.length === 1),
                            denyButtonText: '<i class="ti ti-copy me-1"></i> Create / Clone BOM',
                            confirmButtonText: '<i class="ti ti-external-link me-1"></i> Open BOM Master',
                            cancelButtonText: 'Dismiss',
                            customClass: {
                                popup: 'rounded-2xl shadow-2xl p-4',
                                actions: 'd-flex align-items-center justify-content-center gap-2 mt-4 flex-wrap w-100',
                                denyButton: 'btn btn-primary rounded-xl px-3.5 py-2 m-0 font-medium',
                                confirmButton: 'btn btn-outline-secondary rounded-xl px-3.5 py-2 m-0 font-medium',
                                cancelButton: 'btn btn-light border text-slate-700 rounded-xl px-3.5 py-2 m-0 font-medium'
                            },
                            buttonsStyling: false
                        }).then((result) => {
                            if (result.isDenied && res.incomplete_products && res.incomplete_products.length === 1) {
                                const p = res.incomplete_products[0];
                                launchCloneModalFromPlan(p.product_id, p.product_name);
                            } else if (result.isConfirmed) {
                                window.open('index.php?page=store-setting', '_blank');
                            }
                        });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        function escapePlanText(str) {
            return $('<div>').text(str || '').html();
        }

        $('#bomType').on('change', function () {
            let bomType = $(this).val();
            $('#bomMaster').empty().append('<option value="">Select value</option>');
            $('#ppNoBomAlert').hide();
            $('#bomCheckResult').html('');
            $('#submitPlanBtn').prop('disabled', true);

            if (!bomType) return;

            const selectedProductId = Number($('#finishedProductId').val() || 0);

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    loadBomList: 'loadBomList',
                    bom_type: bomType
                },
                success: function (data) {
                    // If a finished product is selected, filter BOMs to show only matching ones
                    let filteredData = data;
                    if (selectedProductId > 0) {
                        filteredData = data.filter(item => Number(item.finished_product_id) === selectedProductId);
                    }

                    filteredData.forEach(item => {
                        let option = new Option(
                            item.name + ' (' + item.category_name + ')',
                            item.id,
                            false,
                            false
                        );

                        // extra data attach
                        $(option).data({
                            finished_product_id: item.finished_product_id,
                            category_name: item.category_name,
                            product_name: item.product_name
                        });

                        $('#bomMaster').append(option);
                    });

                    $('#bomMaster').trigger('change');

                    // Show create/clone BOM alert if no approved BOMs for the selected product
                    if (selectedProductId > 0 && filteredData.length === 0) {
                        $('#ppNoBomAlert').show();
                    } else {
                        $('#ppNoBomAlert').hide();
                    }
                }
            });
        });

        $('#bomMaster').on('select2:select', function (e) {
            let option = e.params.data.element;

            // data attributes from option
            let categoryName = $(option).data('category_name');
            let productName = $(option).data('product_name');
            let finishedId = $(option).data('finished_product_id');

            $('#productCategory').val(categoryName);
            $('#finishedGood').val(productName);
            if (finishedId) {
                $('#finishedProductId').val(finishedId);
            }

            $('#bomCheckResult').html('');
            $('#submitPlanBtn').prop('disabled', true);
            $('#ppNoBomAlert').hide();
        });

        $('#prodPlanBatchSizeBom, #prodPlanBatchSizeUnitBom').on('change input', function () {
            $('#bomCheckResult').html('');
            $('#submitPlanBtn').prop('disabled', true);
        });


        $('#checkBomBtn').on('click', function () {
            let formData = {
                checkBomStock: 'checkBomStock',
                bom_id: $('#bomMaster').val(),
                finished_product_id: $('#finishedProductId').val(),
                batch_size: $('#prodPlanBatchSizeBom').val(),
                batch_unit: $('#prodPlanBatchSizeUnitBom').val()
            };

            if (!formData.finished_product_id || !formData.batch_size || !formData.batch_unit) {
                toastr.error('Please fill required fields');
                return;
            }

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: formData,
                success: function (res) {
                    $('#bomCheckResult').html(res.html);
                    $('#submitPlanBtn').prop('disabled', res.status !== 'ok');
                }
            });
        });


        $('#addProductionPlanFormBom').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addProductionPlanFormBom');
            const formData = new FormData(form);
            formData.append('addProductionPlanBom', 'addProductionPlanBom');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#animationModalBom').modal('hide');
                        $('#addProductionPlanFormBom')[0].reset();
                        loadProductionPlanTable();
                        $('#bomMaster').val(null).trigger('change');
                        $('#prodPlanBatchSizeUnitBom').val(null).trigger('change');
                        $('#productCategory').val('');
                        $('#finishedGood').val('');
                        $('#finishedProductId').val('');
                        $('#bomCheckResult').html('');
                        $('#submitPlanBtn').prop('disabled', true);
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });


    });

    $(document).on('click', '.productionPlanDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteProductionPlanRecord: 'deleteProductionPlanRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadProductionPlanTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.productionPlanCompleteBtn', function () {
        const id = Number($(this).data('id') || 0);
        if (!id) {
            toastr.error('Invalid production plan ID.');
            return;
        }

        Swal.fire({
            title: 'Complete production plan?',
            text: 'The linked order status will be refreshed from current stock.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, mark complete',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (!result.isConfirmed) return;

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: { completeProductionPlan: 'completeProductionPlan', csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        toastr.success(res.message);
                        loadProductionPlanTable();
                    } else {
                        toastr.error(res.message || 'Unable to complete the production plan.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });


    $(document).on('click', '.productionPlanEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#productionPlanEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchProductionPlanRecord: 'fetchProductionPlanRecord', id: id },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#productionPlanEditModal').modal('show');
                        $('#productionPlanEditForm').find('.modal-body').html(res.data);
                        $('#productionPlanEditForm .select2').select2({ dropdownParent: $('#productionPlanEditModal') });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $('#productionPlanEditForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('productionPlanEditForm');
        const formData = new FormData(form);
        formData.append('updateProductionPlan', 'updateProductionPlan');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#productionPlanEditModal').modal('hide');
                    $('#productionPlanEditForm').find('modal-body').html();
                    loadProductionPlanTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.productionPlanViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#productionPlanViewForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewProductionPlanRecord: 'viewProductionPlanRecord', id: id },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#productionPlanViewModal').modal('show');
                        $('#productionPlanViewForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.production-plan-row', function (event) {
        if ($(event.target).closest('a, button, input, select, textarea, label').length) {
            return;
        }
        const planId = Number($(this).data('id') || 0);
        if (planId) {
            $('.productionPlanViewModalBtn[data-id="' + planId + '"]').first().trigger('click');
        }
    });

    $(document).on('keydown', '.production-plan-row', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            $(this).trigger('click');
        }
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = 'ASC';
        }
        $('.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadProductionPlanTable(1);
    });

    $(document).on('click', '.productionPlanViewHistoryBtn', function () {
        let id = $(this).data('id');

        if (!id) return;
        $('#productionPlanHistoryView').find('.offcanvas-body').html(
            '<div class="text-center py-3">Loading...</div>'
        );

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                productionPlanHistoryViewRecord: 'productionPlanHistoryViewRecord',
                id: id
            },
            success: function (res) {
                if (res.status === 'success') {
                    $('#productionPlanHistoryView').find('.offcanvas-body').html(res.data);
                    let el = document.getElementById('productionPlanHistoryView');
                    let offcanvas = bootstrap.Offcanvas.getOrCreateInstance(el);
                    offcanvas.show();

                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '#newProductionPlanWidget', function () {
        loadNewProductionPlans(1, true);
        $('#newProductionPlanModal').modal('show');
    });

    $(document).on('keydown', '#newProductionPlanWidget', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            $(this).trigger('click');
        }
    });

    $(document).on('click', '#newProductionPlanPrev', function () {
        if (currentNewProductionPlanPage > 1) {
            loadNewProductionPlans(currentNewProductionPlanPage - 1, true);
        }
    });

    $(document).on('click', '#newProductionPlanNext', function () {
        loadNewProductionPlans(currentNewProductionPlanPage + 1, true);
    });

    $(document).on('click', '.new-production-alert-page', function () {
        loadNewProductionPlans(Number($(this).data('page') || 1), true);
    });

    $(document).on('click', '.newProductionPlanLocateBtn', function () {
        const planId = Number($(this).data('plan-id') || 0);
        const plan = productionPlansForReview.find(function (item) { return Number(item.id) === planId; });
        if (!plan) {
            toastr.error('Refresh the Production Plan queue and try again.');
            return;
        }
        $('#productionPlanReviewId').val(plan.id);
        $('#productionPlanReviewNumber').val(plan.production_plan_no || '');
        $('#productionPlanReviewProduct').val(plan.product_name || '');
        $('#productionPlanReviewBatch').val(plan.batch_no || '');
        $('#productionPlanReviewQuantity').val(`${plan.batch_size} ${plan.unit || ''}`);
        $('#productionPlanReviewDate').val(plan.date_value || '');
        $('#productionPlanReviewTimeline').val(String(plan.timeline || 2));
        $('#productionPlanReviewRemarks').val('');
        $('#newProductionPlanModal').one('hidden.bs.modal', function () {
            $('#productionPlanReviewModal').modal('show');
        }).modal('hide');
    });

    $(document).on('submit', '#productionPlanReviewForm', function (event) {
        event.preventDefault();
        const planId = Number($('#productionPlanReviewId').val());
        const searchValue = $('#productionPlanReviewBatch').val();
        const $button = $(this).find('button[type="submit"]');
        const originalHtml = $button.html();
        $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-lg"></i>');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                acceptProductionPlan: 'acceptProductionPlan',
                csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
                plan_id: planId,
                plan_date: $('#productionPlanReviewDate').val(),
                timeline: $('#productionPlanReviewTimeline').val(),
                remarks: $('#productionPlanReviewRemarks').val()
            },
            success: function (response) {
                $button.prop('disabled', false).html(originalHtml);
                if (response.status !== 'success') {
                    toastr.error(response.message || 'Unable to accept the production plan.');
                    return;
                }

                toastr.success(response.message || 'Production plan accepted.');
                $('#productionPlanReviewModal').modal('hide');
                currentSortColumn = 'created_at';
                currentSortDirection = 'DESC';
                $('#searchUsers').val(searchValue);
                loadProductionPlanTable(1, true);
                loadNewProductionPlans(1, false);
            },
            error: function (xhr) {
                $button.prop('disabled', false).html(originalHtml);
                const message = xhr.responseJSON && xhr.responseJSON.message
                    ? xhr.responseJSON.message
                    : 'Server error while accepting the production plan.';
                toastr.error(message);
            }
        });
    });
</script>

<div class="modal fade" id="productionPlanReviewModal" tabindex="-1" aria-labelledby="productionPlanReviewTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <form id="productionPlanReviewForm" class="modal-content rounded-lg">
            <div class="modal-header">
                <h5 id="productionPlanReviewTitle" class="modal-title text-base font-bold">Review Production Plan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body grid grid-cols-1 gap-4 md:grid-cols-2">
                <input type="hidden" id="productionPlanReviewId">
                <div><label for="productionPlanReviewNumber" class="mb-1 block text-sm font-medium">Production Plan</label><input id="productionPlanReviewNumber" class="input-theme" readonly></div>
                <div><label for="productionPlanReviewProduct" class="mb-1 block text-sm font-medium">Product</label><input id="productionPlanReviewProduct" class="input-theme" readonly></div>
                <div><label for="productionPlanReviewBatch" class="mb-1 block text-sm font-medium">Lot / Batch</label><input id="productionPlanReviewBatch" class="input-theme" readonly></div>
                <div><label for="productionPlanReviewQuantity" class="mb-1 block text-sm font-medium">Planned Quantity</label><input id="productionPlanReviewQuantity" class="input-theme" readonly></div>
                <div><label for="productionPlanReviewDate" class="mb-1 block text-sm font-medium">Production Date</label><input id="productionPlanReviewDate" class="input-theme" type="date" required></div>
                <div><label for="productionPlanReviewTimeline" class="mb-1 block text-sm font-medium">Timeline</label><select id="productionPlanReviewTimeline" class="input-theme" required><option value="1">Urgently</option><option value="2">Flexible</option></select></div>
                <div class="md:col-span-2"><label for="productionPlanReviewRemarks" class="mb-1 block text-sm font-medium">Production Remarks</label><textarea id="productionPlanReviewRemarks" class="input-theme" rows="3" maxlength="5000"></textarea></div>
            </div>
            <div class="modal-footer flex-wrap gap-2">
                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="ti ti-check me-2"></i>Submit Production Plan</button>
            </div>
        </form>
    </div>
</div>

<!-- New Production Plan Modal -->
<div class="modal fade animate__animated fadeIn" id="newProductionPlanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <!-- Modal Header (Matches Banner) -->
            <div
                class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-6 !py-4 relative">
                <div class="flex items-center gap-4">
                    <div
                        style="position: relative; display: flex; align-items: center; justify-content: center; width: 3.5rem; height: 3.5rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.75rem;">
                        <i class="ti ti-clipboard-list"
                            style="font-size: 1.75rem; color: var(--appearance-accent, #7e22ce);"></i>
                        <span
                            style="position: absolute; bottom: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">!</span>
                    </div>
                    <div>
                        <h5 class="modal-title m-0 font-bold leading-tight"
                            style="font-size: 1.25rem; color: var(--ui-text, #1e293b);">New Production Plan!</h5>
                        <p class="m-0 mt-1 font-medium"
                            style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">Pending production plans,
                            including items sent from Order Management.</p>
                    </div>
                </div>
                <button type="button"
                    class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none ml-auto"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            <div class="modal-body p-0">
                <div class="overflow-x-auto w-full">
                    <table class="w-full border-collapse text-left">
                        <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                            <tr>
                                <th
                                    class="w-12 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    #</th>
                                <th
                                    class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Date <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-48 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Product <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-32 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Plan No <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-44 min-w-[160px] px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Batch No. <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Batch Size <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-20 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Unit <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-28 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <span class="inline-flex items-center gap-1">Urgency <i
                                            class="ti ti-arrows-sort text-xs text-slate-300"></i></span></th>
                                <th
                                    class="w-20 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400 text-right">
                                    Action</th>
                            </tr>
                        </thead>
                        <tbody id="newProductionPlanTableBody"
                            class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                            <tr>
                                <td colspan="9" class="px-6 py-10 text-center text-sm font-medium text-slate-500">
                                    Loading new production plans...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Footer -->
                <div
                    class="flex flex-col md:flex-row items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
                    <span id="newProductionPlanSummary" class="text-sm font-medium text-slate-500">Showing 0 to 0 of 0
                        entries</span>
                    <div class="flex items-center gap-1">
                        <button id="newProductionPlanPrev" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Previous page" disabled><i class="ti ti-arrow-left text-sm"></i></button>
                        <div id="newProductionPlanCurrentPage" class="flex items-center gap-1"></div>
                        <button id="newProductionPlanNext" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Next page" disabled><i class="ti ti-arrow-right text-sm"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/clone-bom-modal.php'; ?>

<script>
// Unified Clone BOM Launcher for Production Plan (works from either modal or SweetAlert)
function launchCloneModalFromPlan(productId, productName) {
    productId = Number(productId || $('#finishedProductId').val() || window._ppSelectedProductId || 0);
    productName = String(productName || $('#productNameBom').val() || window._ppSelectedProductName || '');

    if (!productId) {
        toastr.error('Please select a finished product first.');
        return;
    }

    const $activeModal = $('.modal.show');
    const launch = function() {
        $('.modal-backdrop').remove();
        $('body').removeClass('modal-open').css({ overflow: '', paddingRight: '' });

        if (typeof window.openCloneBomModal === 'function') {
            window.openCloneBomModal(productId, productName, null, function(newBomRes) {
                toastr.info('BOM submitted for approval. Once approved, you can proceed with the production plan.');
                // Invalidate cached product list so fresh BOM status is loaded next time
                cachedPlanProductsHtml = '';
                $('#prodPlanProductsRepeater .pp-product-select:first').empty().append('<option value="">----Select Product----</option>');
            });
        } else {
            toastr.error('Clone BOM modal is not available.');
        }
    };

    if ($activeModal.length) {
        $activeModal.one('hidden.bs.modal', function() {
            setTimeout(launch, 150);
        });
        $activeModal.modal('hide');
    } else {
        launch();
    }
}

$(function() {
    // ── Create/Clone BOM button handler from BOM modal alert ──
    $(document).on('click', '#ppCreateCloneBomBtn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        launchCloneModalFromPlan();
    });

    // ── Create/Clone BOM button handler from SweetAlert ──
    $(document).on('click', '.swal-clone-bom-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const prodId = Number($(this).data('id') || 0);
        const prodName = String($(this).data('name') || '');
        if (typeof Swal !== 'undefined' && Swal.isVisible()) {
            Swal.close();
        }
        launchCloneModalFromPlan(prodId, prodName);
    });

    // ── Also handle the checkBomStock incomplete response ──
    $(document).on('click', '#ppBomCheckCreateBtn', function(e) {
        e.preventDefault();
        launchCloneModalFromPlan();
    });
});
</script>
<?php endSection(); ?>
