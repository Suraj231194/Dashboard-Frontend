<?php
/**
 * CRM Reusable Filter Bar Partial
 * Standard ERP Toolbar with Search & Status Pill Tabs
 * 
 * Variables:
 *   $searchId (string)           - Input ID
 *   $searchPlaceholder (string)  - Placeholder text
 *   $filterPills (array)         - Key => Label pairs
 *   $activeFilter (string)       - Currently selected filter key
 *   $jsCallback (string)         - JS function to trigger
 */

$searchId = $searchId ?? 'crmSearchInput';
$searchPlaceholder = $searchPlaceholder ?? 'Search...';
$filterPills = $filterPills ?? ['all' => 'All'];
$activeFilter = $activeFilter ?? 'all';
$jsCallback = $jsCallback ?? 'applyCrmFilter';
?>
<div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
    <div class="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
        
        <!-- Search Box (Left) -->
        <div class="relative h-10 w-full lg:w-96 flex-grow">
            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <i class="ti ti-search text-lg text-slate-400"></i>
            </div>
            <input type="text" id="<?= htmlspecialchars($searchId) ?>" 
                   placeholder="<?= htmlspecialchars($searchPlaceholder) ?>" 
                   class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                   oninput="<?= htmlspecialchars($jsCallback) ?>('search', this.value)">
        </div>

        <!-- Status Filter Pills (Right) -->
        <div class="flex items-center gap-1.5 overflow-x-auto pb-0.5 max-w-full" id="<?= htmlspecialchars($searchId) ?>_pills">
            <?php foreach ($filterPills as $key => $label): ?>
                <?php $isActive = ((string)$key === (string)$activeFilter); ?>
                <button type="button" 
                        class="crm-filter-pill inline-flex items-center justify-center whitespace-nowrap px-3.5 py-1.5 !rounded-xl text-xs font-bold transition-all duration-150 cursor-pointer <?= $isActive ? 'bg-emerald-700 text-white shadow-sm ring-1 ring-emerald-900/10 active-pill' : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200/60' ?>"
                        data-filter="<?= htmlspecialchars($key) ?>"
                        onclick="<?= htmlspecialchars($jsCallback) ?>('status', '<?= htmlspecialchars($key) ?>', this)">
                    <?= htmlspecialchars($label) ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
</div>
