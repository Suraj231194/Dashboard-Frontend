<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage role definitions and status</p>
        </div>
    </div>
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="rolesPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="roles-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="roles-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="roles-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="roles-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="roles-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="roles-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchRoles"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'roles_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-56 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-72 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="description" data-order="asc">
                                <span class="inline-flex items-center gap-1">Description <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="status" data-order="asc">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th
                                class="w-48 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="rolesTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                Role</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a new role and description</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addRolesForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="space-y-4">
                            <div>
                                <label for="rolesName" class="mb-1 block text-sm font-medium text-slate-800">Role
                                    Name</label>
                                <input type="text" id="rolesName" autocomplete="off" name="rolesName"
                                    class="input-theme" placeholder="Enter Role Name" required />
                                <div class="mt-1 text-sm font-medium text-rose-600" id="rolesError"></div>
                            </div>
                            <div>
                                <label for="roleDesc" class="mb-1 block text-sm font-medium text-slate-800">Role
                                    Description</label>
                                <textarea id="roleDesc" autocomplete="off" name="roleDesc" rows="3"
                                    class="input-theme min-h-[80px]" placeholder="Enter Role Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="editRoleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Edit
                                Role</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update role details and status</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editRolesForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                    </div>
                    <div class="flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-28 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-32 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;

    function loadRolesTable(page = 1) {
        currentPage = page;
        const search = $('#searchRoles').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#rolesTableBody').html('<tr><td colspan="5" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadRoles: 'loadRoles',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#rolesTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.totalRows || 0);
                const visibleRows = Number(response.visibleRows || 0);
                const perPageValue = parseInt(perPage, 10) || 10;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * perPageValue) + visibleRows, totalRows) : 0;

            },
            error: function () {
                $('#rolesTableBody').html('<tr><td colspan="5" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    $(document).ready(function () {
        loadRolesTable();
        $('#searchRoles').on('input', function () {
            loadRolesTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadRolesTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadRolesTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.roles-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#rolesPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addRolesForm')[0].reset();
            $('#rolesError').text('');
        });

        $('#addRolesForm').on('submit', function (e) {
            e.preventDefault();
            const rolesName = $('#rolesName').val().trim();
            const roleDesc = $('#roleDesc').val().trim();
            $('#rolesError').text('');
            $.ajax({
                url: 'ajax.php', // Change to your handler script
                type: 'POST',
                data: {
                    addRoles: 'addRoles',
                    rolesName: rolesName,
                    rolesDesc: roleDesc
                },
                success: function (response) {
                    if (response === 'exists') {
                        toastr.error('Role already exists.');
                    } else if (response === 'success') {
                        $('#animationModal').modal('hide');
                        $('#rolesName').val('');
                        $('#roleDesc').val('');
                        loadRolesTable();
                        toastr.success('Role added successfully');
                    } else {
                        toastr.error('Something went wrong.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });

    $(document).on('click', '.deleteRolesBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white',
                cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteRole: 'deleteRole',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadRolesTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editRolesBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editRolesForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchRoleRecord: 'fetchRoleRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editRoleModal').modal('show');
                        $('#editRolesForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editRolesForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editRolesForm');
        const formData = new FormData(form);
        formData.append('updateRole', 'updateRole');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editRoleModal').modal('hide');
                    $('#editRolesForm').find('modal-body').html();
                    loadRolesTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });
</script>
<?php endSection(); ?>
