<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>      
    <div class="row col-md-12">
        <div class="card">            
            <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                <div class="d-flex align-items-center gap-2">
                    <label for="perPageSelect" class="mb-0">Show</label>
                    <select id="perPageSelect" class="form-select form-select-sm w-auto">
                        <option value="5">5</option>
                        <option value="10" selected>10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <input type="text" id="searchProducts" class="form-control form-control-sm" placeholder="Search Data...">                    
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr class="text-nowrap">
                            <th class="border-b border-slate-200 px-6 py-3">#</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Date"> Date</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Product Name"> Product Name</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Lot/Batch No"> LOT/Batch No</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Batch Size"> Batch Size</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Requested By"> Requested By</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>                           
                            <th class="border-b border-slate-200 px-6 py-3">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white" id="productsTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="materialRequstedStatusModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Update Material Request Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="materialRequestStatusChangeForm">
                    <div class="modal-body">
                    </div>                    
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewMaterialRequestModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">View Material Request Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="viewMaterialRequest">
                    <div class="modal-body">                                    
                    </div>                  
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editMatRequestModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Material Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="editMatRequestForm">
                    <div class="modal-body">                                    
                    </div>                  
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];   

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function(response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#productUnit").html(optionsHtml);
            },
            error: function(xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }
    
    function loadMaterialRequestTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialRequestTable: 'loadMaterialRequestTable',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function(response) {
                const parts = response.split('|||');
                $('#productsTableBody').html(parts[0]);
                $('#paginationWrapper').html(parts[1] || '');
            },
            error: function() {
                $('#productsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }
    
    $(document).ready(function() {        
        loadMaterialRequestTable();
        loadStandardUnit();
        $('#searchProducts').on('input', function() {
            loadMaterialRequestTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadMaterialRequestTable(1);
        });
    });

    $(document).on('click','.materialRequestStatusChangeModalBtn', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#materialRequestStatusChangeForm').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {fetchMaterialRequestStatusRecord:'fetchMaterialRequestStatusRecord', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#materialRequstedStatusModal').modal('show');
                    $('#materialRequestStatusChangeForm').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

    $(document).on('click','.viewMaterialRequestModalBtn', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#viewMaterialRequest').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {viewMaterialRequestRecord:'viewMaterialRequestRecord', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#viewMaterialRequestModel').modal('show');
                    $('#viewMaterialRequest').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

    $('#materialRequestStatusChangeForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('materialRequestStatusChangeForm');
        const formData = new FormData(form);
        formData.append('updateMaterialRequestStatusRecord', 'updateMaterialRequestStatusRecord'); 
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#materialRequstedStatusModal').modal('hide');
                    $('#materialRequestStatusChangeForm').find('modal-body').html();
                    loadMaterialRequestTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click','.materialRequisitionEditModalBtn', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#editMatRequestForm').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {fetchMaterialRequestRecord:'fetchMaterialRequestRecord', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editMatRequestModel').modal('show');
                    $('#editMatRequestForm').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

    $('#editMatRequestForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editMatRequestForm');
        const formData = new FormData(form);
        formData.append('updateMaterialReqestRecord', 'updateMaterialReqestRecord'); 
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editMatRequestModel').modal('hide');
                    $('#editMatRequestForm').find('modal-body').html();
                    loadMaterialRequestTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });
</script>
<?php endSection(); ?>
