<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage role permissions and assignments</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="rhpPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="rhp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="rhp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="rhp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="rhp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="rhp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="rhp-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchRoleHasPermissions"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission((int) ($_SESSION['role_id'] ?? 0), 'role_has_permission_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-48 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal">
                            <i class="ti ti-plus text-lg"></i> <span class="whitespace-nowrap">Assign Permission</span>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-12 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Role"> Role</th>
                            <th class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="roleHasPermissionsTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- Modals -->
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-shield-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Permission</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Assign permissions to a role</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addRoleHasPermissionsForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="mb-4">
                            <label for="roleddl" class="mb-1 block text-sm font-medium text-slate-800">Role <strong class="text-rose-500">*</strong></label>
                            <select name="roleddl" id="roleddl" class="input-theme select2" required>
                            </select>
                        </div>
                        <div class="mb-2">  
                            <label class="mb-1 block text-sm font-medium text-slate-800">Permissions <strong class="text-rose-500">*</strong></label>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2" id="permissionsList"> 
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="RoleHasPermissionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Assign Permissions</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Edit permissions for the role</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="assignRoleHasPermissionsForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">                        
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;

    function loadRoleHasPermissionsTable(page = 1) {
        currentPage = page;
        const search = $('#searchRoleHasPermissions').val().trim();
        const perPage = $('#perPageSelect').val();
        
        $('#roleHasPermissionsTableBody').html('<tr><td colspan="3" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadRolePermissionTable: 'loadRolePermissionTable',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function(response) {
                $('#roleHasPermissionsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function() {
                $('#roleHasPermissionsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }
    function loadRolesOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadRolesOptions: 'loadRolesOptions'
            },
            success: function(response) { 
                const options = JSON.parse(response);
                let html = '<option value="">----Select---</option>'; 

                options.forEach(function(role) {
                    html += `<option value="${role.key}">${role.value}</option>`;
                });
                $('#roleddl').html(html);             
            }
        });
    }
    
    function loadPermissionOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadPermissionOptions: 'loadPermissionOptions'
            },
            success: function(response) {
                const permissions = JSON.parse(response);
                let html = '';

                permissions.forEach((permission, index) => {
                    html += `
                        <div class="flex items-center gap-2 p-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 transition-colors">
                            <input class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600 rounded" type="checkbox" name="permissions[]" id="perm_${permission.key}" value="${permission.key}">
                            <label class="text-sm font-medium text-slate-700 cursor-pointer flex-grow" for="perm_${permission.key}">
                                ${permission.value}
                            </label>
                        </div>
                    `;
                });

                $('#permissionsList').html(html);
            }
        });
    }

    $(document).ready(function () {
        loadRoleHasPermissionsTable();
        loadRolesOption();
        loadPermissionOption();

        $('#searchRoleHasPermissions').on('input', function () {
            loadRoleHasPermissionsTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadRoleHasPermissionsTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadRoleHasPermissionsTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.rhp-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#rhpPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addRoleHasPermissionsForm')[0].reset();
            $('#animationModal .select2').val(null).trigger('change');
        });

        $('#addRoleHasPermissionsForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addRoleHasPermissionsForm');
            const formData = new FormData(form);
            formData.append('addRoleHasPermissions', 'addRoleHasPermissions'); 

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addRoleHasPermissionsForm')[0].reset();
                        loadRoleHasPermissionsTable();
                        toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });
    
    $(document).on('click','.roleHasPermissionEditModal', function(){
       let id = $(this).data('id');
       $('#RoleHasPermissionModal').modal('hide');
       if(id)
       {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {fetchRoleHasPermission:'fetchRoleHasPermission', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }
                if (res.status === 'success') {
                    $('#RoleHasPermissionModal').modal('show');
                    $('#assignRoleHasPermissionsForm').find('.modal-body').html(res.html);                    
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });
    

    $('#assignRoleHasPermissionsForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('assignRoleHasPermissionsForm');
        const formData = new FormData(form);
        formData.append('assignPermissionsToRole', 'assignPermissionsToRole'); 
        
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#RoleHasPermissionModal').modal('hide');
                    $('#assignRoleHasPermissionsForm')[0].reset();
                    loadRoleHasPermissionsTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

</script>
<?php endSection(); ?>
