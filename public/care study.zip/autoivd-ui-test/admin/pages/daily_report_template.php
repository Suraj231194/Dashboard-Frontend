<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once "../db.php";
require_once "../functions.php";
require_once "../document_pdf_helpers.php";

documentPdfRequireAnyPermission($conn, ['generate_rapid_pdf']);
$id = documentPdfEncryptedPositiveId($_GET['id'] ?? '');
$fileName = '';


$stmt = $conn->prepare("SELECT * FROM `production_entries` WHERE `status` != 3 AND `deleted_at` IS NULL AND `id` = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    http_response_code(404);
    exit('Daily production report not found.');
}

$stmtItems = $conn->prepare("SELECT * FROM `production_particulars` WHERE `status` != 3 AND `deleted_at` IS NULL AND `production_entry_id` = ?");
$stmtItems->bind_param('i', $id);
$stmtItems->execute();
$resultItems = $stmtItems->get_result();
$rowItems = $resultItems->fetch_all(MYSQLI_ASSOC); 
$stmtItems->close();

$rawName = $row['batch_number'];
$fileName = preg_replace('/[^A-Za-z0-9]+/', '_', $rawName);
$fileName = trim($fileName, '_');  
$serial = 1;
$serverSideDownload = (string) ($_GET['triggerDownload'] ?? '') === '1';
if ($serverSideDownload) {
    ob_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Daily Production Report</title>
    <style>
        .page {
            width: 100%;
            min-height: 1000px; /* ~A4 height in pixels at 96 DPI */
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }        
        .page:last-child {
            page-break-after: auto !important;
        }
        <?php if ($serverSideDownload) { ?>
        .page { min-height: 0; }
        <?php } ?>
    </style>
</head>
<body style="margin: 0;">
    <div id="materialRequisitionContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php           
            $rowsPerPage = 20;
            $chunks = array_chunk($rowItems, $rowsPerPage) ?: [[]];
            foreach ($chunks as $pageIndex => $pageProducts) {
                $realCount = count($pageProducts);
                $emptyRows = $rowsPerPage - $realCount;                
        ?>
        <div class="page" style="page-break-after: <?= ($pageIndex == array_key_last($chunks)) ? 'auto' : 'always' ?>;">                   
            <div style="border-left: 1px solid #000; font-size:14px;">
                <table style="width: 100%; border-collapse: collapse; ">
                    <tr style="line-height: 18px; border-top: 1px solid #000; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><strong>Date</strong></td>
                        <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><strong>Month/Year</strong></td>
                        <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><strong>Total Man Power</strong></td>
                        <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><strong>Total Working Hours</strong></td>                        
                        <td style="padding-left:5px; width: 25%; border-right: 1px solid #000;"><strong>Batch Number</strong></td>                        
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 15%;  border-right: 1px solid #000;"><?php echo formatDateDMY(htmlspecialchars($row['entry_date'] ?? "")); ?></td>
                        <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><?php echo formatMonthYearToMY(htmlspecialchars($row['month_year'] ?? "")); ?></td>
                        <td style="padding-left:5px; width: 20%;  border-right: 1px solid #000;"><?php echo htmlspecialchars($row['total_man_power'] ?? 0); ?></td>
                        <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><?php echo htmlspecialchars($row['total_working_hours'] ?? 0); ?></td>
                        <td style="padding-left:5px; width: 25%; border-right: 1px solid #000;"><?php echo htmlspecialchars($row['batch_number'] ?? 0); ?></td>
                    </tr>  
                </table>
            </div>

            <div style="font-size:14px; margin-top:20px;">
                <table style="width: 100%; border-collapse: collapse;"> 
                    <tr style="line-height: 18px; background-color:#D3D3D3; border-bottom: 1px solid #000;">
                        <td style="width: 15%; border-top: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Department</td>
                        <td style="width: 15%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Particulars</td>
                        <td style="width: 20%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Product</td>
                        <td style="width: 15%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Yield</td>
                        <td style="width: 10%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Unit</td>
                        <td style="width: 10%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Man Power</td>
                        <td style="width: 15%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Filled By</td>                        
                    </tr>
                    <?php if(!empty($pageProducts)): foreach ($pageProducts as $p): ?>
                        <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                            <td style="padding-left:5px; width: 15%; border-left: 1px solid #000;border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['department'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['particular'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['product'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['total_yield'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['qty_unit'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['man_power'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['filled_by'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>      
                    <?php endforeach; endif; ?>
                    <?php for ($i = 0; $i < $emptyRows; $i++): ?>
                        <tr style="line-height: 18px; border-bottom: 1px solid #fff;">
                            <td style="padding-left:5px; width: 15%; border-left: 1px solid #fff;border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 20%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>                           
                        </tr>     
                    <?php endfor; ?>
                </table>
                
            </div>
        </div>
            
        <?php }  ?>
    </div>

</body>
</html>
<?php
if ($serverSideDownload) {
    documentPdfStream((string) ob_get_clean(), $fileName ?: 'daily_production_report_' . $id);
}
?>
