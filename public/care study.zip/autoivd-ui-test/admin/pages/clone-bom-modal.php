<?php
// Clone / Create BOM Modal Component with Approval Workflow
// Can be included in store-setting.php, material-requisition.php, production-plan.php

global $conn;
if (!isset($conn) || !$conn) {
    require_once __DIR__ . '/../db.php';
}
if (!class_exists('Constant')) {
    require_once __DIR__ . '/../constant.php';
}

$categoriesForClone = [];
if (isset($conn) && $conn) {
    $catRes = $conn->query("SELECT id, name FROM product_categories WHERE status = 1 ORDER BY name ASC");
    if ($catRes) {
        $categoriesForClone = $catRes->fetch_all(MYSQLI_ASSOC);
    }
}

$unitsForClone = [];
if (isset($conn) && $conn) {
    $unitRes = $conn->query("SELECT id, short_name, fullname FROM standard_units WHERE status != 3 ORDER BY fullname ASC");
    if ($unitRes) {
        $unitsForClone = $unitRes->fetch_all(MYSQLI_ASSOC);
    }
}

$rawProductsForClone = [];
if (isset($conn) && $conn) {
    $rawRes = $conn->query("
        SELECT p.id, p.product_name, p.product_code, p.category_id, p.unit_id,
               COALESCE(pc.name, '') AS category_name,
               COALESCE(su.short_name, su.fullname, '') AS unit_name
        FROM products p
        LEFT JOIN product_categories pc ON pc.id = p.category_id
        LEFT JOIN standard_units su ON su.id = p.unit_id
        WHERE p.status = 1
        ORDER BY p.product_name ASC
    ");
    if ($rawRes) {
        $rawProductsForClone = $rawRes->fetch_all(MYSQLI_ASSOC);
    }
}
?>

<style>
.swal2-container {
    z-index: 3000 !important;
}
#cloneCreateBomModal {
    z-index: 2050 !important;
}
#cloneCreateBomModal.modal {
    --bs-modal-zindex: 2050 !important;
}
#cloneCreateBomModal .modal-dialog {
    z-index: 2051 !important;
    position: relative !important;
    pointer-events: auto !important;
}
#cloneCreateBomModal .modal-content {
    z-index: 2052 !important;
    position: relative !important;
    pointer-events: auto !important;
}
.clone-bom-backdrop {
    z-index: 2040 !important;
}
</style>

<!-- ─── Clone / Create BOM Modal ───────────────────────────────────────────── -->
<div class="modal fade animate__animated fadeIn" id="cloneCreateBomModal" tabindex="-1" aria-labelledby="cloneCreateBomModalLabel" aria-hidden="true" style="z-index: 2050 !important;">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
            <!-- Modal Header -->
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-gradient-to-r from-slate-50 to-indigo-50/40 !px-6 !py-4">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-200 ring-1 ring-indigo-500/20">
                        <i class="ti ti-copy text-2xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="cloneCreateBomModalLabel">Create / Clone BOM for Package</h5>
                        <p class="m-0 text-xs font-medium text-slate-500">Clone raw materials from an existing package BOM &amp; submit for approval</p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-xl"></i>
                </button>
            </div>

            <form id="cloneBomForm">
                <input type="hidden" id="cloneFinishedProductId" name="finished_product_id" value="">
                <input type="hidden" id="cloneCategoryId" name="category_id" value="">
                <input type="hidden" id="cloneSourceBomId" name="source_bom_id" value="">
                <input type="hidden" id="cloneSourceType" name="source_type" value="CLONED">
                <input type="hidden" id="cloneExistingBomId" name="existing_bom_id" value="">

                <div class="modal-body !p-6 space-y-5">
                    <!-- Pending BOM Alert Banner (Displayed when an existing pending BOM is found) -->
                    <div id="clonePendingAlertBanner" class="rounded-2xl border border-amber-300 bg-amber-50/90 p-4 shadow-sm animate__animated fadeIn" style="display: none;">
                        <div class="flex items-start gap-3.5">
                            <span class="inline-flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700 ring-1 ring-amber-200">
                                <i class="ti ti-clock-pause text-xl"></i>
                            </span>
                            <div class="flex-grow text-xs leading-relaxed">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <strong class="font-bold text-sm text-amber-950">Pending Approval Submission Found</strong>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-amber-200/80 px-2.5 py-0.5 text-[11px] font-bold text-amber-900">
                                        <i class="ti ti-edit text-xs"></i> Revision Mode
                                    </span>
                                </div>
                                <p class="mt-1 mb-0 text-amber-800" id="clonePendingAlertMsg">
                                    A BOM for this package has already been submitted and is currently awaiting management approval. You can edit the formulation below and re-submit it.
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Target Product Info Card -->
                    <div class="rounded-2xl border border-indigo-100 bg-indigo-50/40 p-4">
                        <div class="flex flex-wrap items-center justify-between gap-3">
                            <div>
                                <span class="inline-block rounded-md bg-indigo-100 px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider text-indigo-800">Target Product (No BOM)</span>
                                <h4 class="mt-1 text-base font-bold text-slate-900" id="cloneTargetProductName">—</h4>
                                <div class="mt-1 flex flex-wrap gap-3 text-xs text-slate-600">
                                    <span><strong>Code:</strong> <span id="cloneTargetProductCode">—</span></span>
                                    <span>&bull;</span>
                                    <span><strong>Category:</strong> <span id="cloneTargetCategoryName">—</span></span>
                                    <span>&bull;</span>
                                    <span><strong>Unit:</strong> <span id="cloneTargetUnitName">—</span></span>
                                </div>
                            </div>
                            <div class="text-end">
                                <span class="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800 ring-1 ring-amber-200">
                                    <i class="ti ti-alert-triangle text-sm"></i> BOM Unavailable for this Package
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Reference Package Selection Banner -->
                    <div id="cloneReferenceSection" class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                        <div class="mb-3 flex items-center justify-between">
                            <label class="block text-sm font-bold text-slate-800">
                                <i class="ti ti-git-branch text-indigo-600 me-1"></i> Reference Package to Clone From:
                            </label>
                            <span id="cloneRefCountBadge" class="badge bg-label-primary text-xs">0 available</span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                            <div class="md:col-span-3">
                                <select id="cloneReferenceBomSelect" onchange="applyCloneReferenceBom()" class="form-select input-theme !py-2.5 !px-3 text-sm font-semibold text-slate-800 bg-white border border-slate-300 rounded-xl shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200" data-native-select="true" style="width: 100%;">
                                    <option value="">-- Select a Reference Package BOM --</option>
                                </select>
                            </div>
                            <div class="md:col-span-1">
                                <button type="button" id="applyReferenceBomBtn" onclick="applyCloneReferenceBom()" class="w-full inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition-colors">
                                    <i class="ti ti-download"></i> Load Items
                                </button>
                            </div>
                        </div>
                        <p class="mt-2 text-xs text-slate-500">
                            <i class="ti ti-info-circle text-slate-400 me-1"></i>
                            Raw materials and baseline quantities are cloned from the selected package. You can edit any quantity to match this package's formulation.
                        </p>
                    </div>

                    <!-- BOM Header Information -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="md:col-span-2">
                            <label for="cloneBomName" class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">
                                BOM Name <strong class="text-rose-500">*</strong>
                            </label>
                            <input type="text" id="cloneBomName" name="bom_name" class="input-theme" placeholder="e.g. BOM for Product Name" required>
                        </div>
                        <div>
                            <label for="cloneBomType" class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">
                                BOM Type <strong class="text-rose-500">*</strong>
                            </label>
                            <select id="cloneBomType" name="bom_type" class="form-select input-theme !py-2.5 !px-3 text-sm font-medium text-slate-800 bg-white border border-slate-300 rounded-xl shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200" data-native-select="true" style="width: 100%;" required>
                                <?php
                                if (!empty(Constant::STOCKS['BOM_TYPES'])) {
                                    foreach (Constant::STOCKS['BOM_TYPES'] as $tdkey => $tdval) {
                                        $sel = ($tdkey == 4) ? 'selected' : '';
                                        echo '<option value="' . $tdkey . '" ' . $sel . '>' . htmlspecialchars($tdval['label']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="md:col-span-3">
                            <label for="cloneBomDescription" class="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-600">
                                Notes / Descriptions
                            </label>
                            <textarea id="cloneBomDescription" name="descriptions" class="input-theme" rows="2" placeholder="Optional notes about this package BOM formulation..."></textarea>
                        </div>
                    </div>

                    <!-- Items Table -->
                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <div>
                                <h6 class="m-0 text-sm font-bold text-slate-900">BOM Components / Raw Materials</h6>
                                <p class="m-0 text-xs text-slate-600 font-medium" id="cloneBomComponentsSubText">
                                    <i class="ti ti-info-circle text-indigo-500 me-1"></i> Raw materials will appear below. You can fine-tune quantities before submitting.
                                </p>
                            </div>
                            <button type="button" id="cloneAddCustomItemBtn" class="inline-flex h-9 items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-colors">
                                <i class="ti ti-plus text-sm"></i> Add Component
                            </button>
                        </div>

                        <div class="overflow-x-auto rounded-xl border border-slate-200">
                            <table class="min-w-full divide-y divide-slate-200 text-left text-xs" id="cloneBomItemsTable">
                                <thead class="bg-slate-50 font-semibold text-slate-700 uppercase tracking-wider">
                                    <tr>
                                        <th class="px-4 py-3 w-12 text-center">#</th>
                                        <th class="px-4 py-3">Raw Material / Component <strong class="text-rose-500">*</strong></th>
                                        <th class="px-4 py-3 w-44">Category</th>
                                        <th class="px-4 py-3 w-36">Unit <strong class="text-rose-500">*</strong></th>
                                        <th class="px-4 py-3 w-48 bg-amber-50/50">
                                            Qty Per Unit <strong class="text-rose-500">*</strong>
                                            <span class="block font-normal normal-case text-[10px] text-amber-700">(Enter value)</span>
                                        </th>
                                        <th class="px-4 py-3 w-16 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="cloneBomItemsTbody" class="divide-y divide-slate-100 bg-white">
                                    <tr id="cloneBomEmptyRow">
                                        <td colspan="6" class="px-4 py-6 text-center text-slate-400">
                                            <i class="ti ti-box text-2xl block mb-1"></i>
                                            Select a reference package above or click "Add Component" to populate raw materials.
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Approval Workflow Alert -->
                    <div class="rounded-xl border border-blue-200 bg-blue-50/70 p-3.5 flex items-start gap-3">
                        <span class="inline-flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-blue-100 text-blue-700">
                            <i class="ti ti-shield-check text-base"></i>
                        </span>
                        <div class="text-xs text-blue-900 leading-relaxed">
                            <strong>Approval Workflow Notice:</strong>
                            Newly created or cloned BOMs are submitted into the system with <code>PENDING APPROVAL</code> status.
                            An authorized manager must approve this BOM before it can be scheduled in production plans or material requisitions.
                        </div>
                    </div>
                </div>

                <!-- Modal Footer -->
                <div class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/80 px-6 py-4">
                    <button type="button" class="inline-flex h-10 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-colors" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <div class="flex items-center gap-2">
                        <button type="button" id="cloneSubmitApprovalBtn" class="inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-emerald-600 px-5 text-xs font-bold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-colors">
                            <i class="ti ti-send text-sm"></i> Submit for Approval
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ─── Approval History Modal ─────────────────────────────────────────────── -->
<div class="modal fade animate__animated fadeIn" id="viewBomHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-2xl border border-slate-200 bg-white shadow-2xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50 !px-5 !py-3">
                <div class="flex items-center gap-2.5">
                    <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                        <i class="ti ti-history text-lg"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-base font-bold text-slate-900">BOM Approval &amp; Audit Trail</h5>
                        <p class="m-0 text-xs font-medium text-slate-500" id="bomHistorySubTitle">History of status changes and approvals</p>
                    </div>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100" data-bs-dismiss="modal">
                    <i class="ti ti-x text-lg"></i>
                </button>
            </div>
            <div class="modal-body !p-5">
                <div id="bomHistoryContent" class="space-y-3">
                    <div class="text-center py-6 text-slate-400">Loading audit trail...</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Raw Material Options JSON for JS dynamic row adding -->
<script>
window.CLONE_BOM_CATEGORIES = <?php echo json_encode($categoriesForClone ?? []); ?>;
window.CLONE_BOM_UNITS = <?php echo json_encode($unitsForClone ?? []); ?>;
window.CLONE_BOM_RAW_PRODUCTS = <?php echo json_encode($rawProductsForClone ?? []); ?>;

/**
 * Opens the Clone / Create BOM Modal for a given product
 * @param {number} productId Target finished product ID
 * @param {string} productName Target finished product Name
 * @param {array|null} preloadedRefs Optional preloaded reference BOM array
 * @param {function|null} onSuccessCallback Callback function called when BOM is created/submitted
 */
function openCloneBomModal(productId, productName = '', preloadedRefs = null, onSuccessCallback = null) {
    window._cloneBomSuccessCallback = onSuccessCallback;

    $('#cloneFinishedProductId').val(productId);
    $('#cloneExistingBomId').val('');
    $('#cloneTargetProductName').text(productName || 'Loading...');
    $('#cloneTargetProductCode').text('—');
    $('#cloneTargetCategoryName').text('—');
    $('#cloneTargetUnitName').text('—');
    $('#cloneBomName').val('BOM for ' + (productName || 'Product #' + productId));
    $('#cloneBomDescription').val('');
    $('#cloneSourceBomId').val('');
    $('#cloneSourceType').val('CLONED');
    $('#clonePendingAlertBanner').hide();
    $('#cloneCreateBomModalLabel').text('Create / Clone BOM for Package');
    $('#cloneSubmitApprovalBtn')
        .removeClass('bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200')
        .addClass('bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200')
        .html('<i class="ti ti-send text-sm"></i> Submit for Approval');

    $('#cloneBomItemsTbody').html(`
        <tr id="cloneBomEmptyRow">
            <td colspan="6" class="px-4 py-6 text-center text-slate-400">
                <i class="ti ti-loader-2 animate-spin text-2xl block mb-1"></i>
                Searching for reference packages...
            </td>
        </tr>
    `);

    // Ensure native select has clean state and no select2 wrapping
    const $refSelect = $('#cloneReferenceBomSelect');
    if ($refSelect.hasClass('select2-hidden-accessible') || $refSelect.data('select2')) {
        try { $refSelect.select2('destroy'); } catch(e) {}
    }
    if ($refSelect.parent().hasClass('position-relative') && !$refSelect.parent().is('.md\\:col-span-3')) {
        $refSelect.unwrap();
    }
    $refSelect.html('<option value="">-- Select a Reference Package BOM --</option>').removeAttr('tabindex').removeAttr('aria-hidden').show();

    // Ensure modal element is direct child of body to escape any container stacking context
    if (window.jQuery && $('#cloneCreateBomModal').parent().prop('tagName') !== 'BODY') {
        $('#cloneCreateBomModal').appendTo('body');
    }

    // Clean up any stale backdrops before opening
    $('.modal-backdrop').remove();

    // Show modal safely
    if (window.jQuery) {
        $('#cloneCreateBomModal').modal('show');
    } else if (window.bootstrap && bootstrap.Modal) {
        const modalEl = document.getElementById('cloneCreateBomModal');
        if (modalEl) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        }
    }

    // Fetch target product details and reference BOMs
    $.ajax({
        url: 'ajax.php',
        type: 'POST',
        dataType: 'json',
        data: {
            getReferenceBoms: '1',
            productId: productId
        },
        success: function(res) {
            if (res.status === 'success') {
                const prod = res.target_product || {};
                $('#cloneTargetProductName').text(prod.product_name || productName);
                $('#cloneTargetProductCode').text(prod.product_code || '—');
                $('#cloneTargetCategoryName').text(prod.category_name || '—');
                $('#cloneTargetUnitName').text(prod.unit_name || '—');
                $('#cloneCategoryId').val(prod.category_id || '');
                $('#cloneBomName').val('BOM for ' + (prod.product_name || productName));

                const refBoms = res.reference_boms || [];
                $('#cloneRefCountBadge').text(refBoms.length + ' available');

                let opts = '<option value="">-- Select a Reference Package BOM --</option>';
                let currentGroup = '';
                refBoms.forEach(function(rb) {
                    const grp = rb.group_label || 'Reference Packages';
                    if (grp !== currentGroup) {
                        if (currentGroup !== '') opts += '</optgroup>';
                        opts += `<optgroup label="${escapeHtml(grp)}">`;
                        currentGroup = grp;
                    }
                    opts += `<option value="${rb.id}" data-items-count="${rb.item_count || 0}">BOM #${rb.id} - ${escapeHtml(rb.product_name)} (${rb.item_count || 0} components)</option>`;
                });
                if (currentGroup !== '') opts += '</optgroup>';
                $refSelect.html(opts);

                // CHECK IF AN EXISTING PENDING BOM EXISTS FOR THIS PRODUCT
                if (res.pending_bom) {
                    const pb = res.pending_bom;
                    $('#cloneExistingBomId').val(pb.id);
                    $('#clonePendingAlertMsg').html(`
                        A BOM for this package (<strong>BOM #${pb.id}</strong>) was submitted by <strong>${escapeHtml(pb.creator_name || 'User')}</strong> on <strong>${escapeHtml(pb.created_at || '')}</strong> and is currently awaiting approval.
                        You are in <strong>Revision Mode</strong>. Modifying components below and clicking <strong>"Re-submit for Approval"</strong> will update this existing pending submission without creating duplicate entries.
                    `);
                    $('#clonePendingAlertBanner').slideDown();
                    $('#cloneCreateBomModalLabel').html(`Edit &amp; Revise Pending BOM <span class="badge bg-amber-100 text-amber-800 text-xs ms-2">BOM #${pb.id} (Pending Review)</span>`);
                    $('#cloneSubmitApprovalBtn')
                        .removeClass('bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200')
                        .addClass('bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200')
                        .html('<i class="ti ti-refresh text-sm"></i> Re-submit for Approval');

                    if (pb.name) $('#cloneBomName').val(pb.name);
                    if (pb.bom_type) $('#cloneBomType').val(pb.bom_type);
                    if (pb.descriptions) $('#cloneBomDescription').val(pb.descriptions);
                    if (pb.source_bom_id) {
                        $('#cloneSourceBomId').val(pb.source_bom_id);
                        $refSelect.val(pb.source_bom_id);
                    }
                    if (pb.source_type) $('#cloneSourceType').val(pb.source_type);

                    if (pb.items && pb.items.length > 0) {
                        renderCloneItemRows(pb.items);
                        $('#cloneBomComponentsSubText').html(`
                            <i class="ti ti-clock-check text-amber-600 me-1"></i>
                            Loaded <strong>${pb.items.length}</strong> components from pending submission BOM #${pb.id}. You can edit quantities or add/remove components before re-submitting.
                        `);
                    } else if (refBoms.length > 0) {
                        $refSelect.val(refBoms[0].id);
                        loadReferenceBomItems(refBoms[0].id);
                    }
                } else {
                    // Normal new clone creation flow
                    $('#cloneExistingBomId').val('');
                    $('#clonePendingAlertBanner').hide();
                    $('#cloneCreateBomModalLabel').text('Create / Clone BOM for Package');
                    $('#cloneSubmitApprovalBtn')
                        .removeClass('bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200')
                        .addClass('bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200')
                        .html('<i class="ti ti-send text-sm"></i> Submit for Approval');

                    const isTrueMatch = refBoms.length > 0 && (
                        (refBoms[0].group_label && refBoms[0].group_label.indexOf('Recommended') !== -1) ||
                        (refBoms[0].group_label && refBoms[0].group_label.indexOf('Same Category') !== -1)
                    );
                    if (isTrueMatch) {
                        $refSelect.val(refBoms[0].id);
                        loadReferenceBomItems(refBoms[0].id);
                    } else if (refBoms.length > 0) {
                        // Unrelated category packages available: keep dropdown empty and prompt user
                        $refSelect.val('');
                        $('#cloneBomItemsTbody').html(`
                            <tr id="cloneBomEmptyRow">
                                <td colspan="6" class="px-4 py-8 text-center text-slate-500">
                                    <div class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 mb-2">
                                        <i class="ti ti-layers-linked text-2xl"></i>
                                    </div>
                                    <p class="font-bold text-slate-700 text-sm mb-1">No existing package BOM found for this product</p>
                                    <p class="text-xs text-slate-500 mb-3">You can optionally pick an available formulation from the dropdown above to clone, or click <strong>"+ Add Component"</strong> to build from scratch.</p>
                                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="addCustomCloneItemRow()">
                                        <i class="ti ti-plus me-1"></i> Add Component
                                    </button>
                                </td>
                            </tr>
                        `);
                        $('#cloneSourceType').val('MANUAL');
                    } else {
                        $refSelect.html('<option value="">No reference packages found (Start blank)</option>');
                        $('#cloneBomItemsTbody').html(`
                            <tr id="cloneBomEmptyRow">
                                <td colspan="6" class="px-4 py-6 text-center text-slate-500">
                                    <i class="ti ti-info-circle text-xl text-amber-500 block mb-1"></i>
                                    No existing packages found. Click <strong>"Add Component"</strong> above to manually add raw materials.
                                </td>
                            </tr>
                        `);
                        $('#cloneSourceType').val('MANUAL');
                    }
                }
            } else {
                toastr.error(res.message || 'Failed to fetch product details.');
            }
        },
        error: function() {
            toastr.error('Network error fetching reference BOMs.');
        }
    });
}

/**
 * Loads items from a reference BOM with quantities and reference hints
 */
let _isLoadingRefBom = false;

function loadReferenceBomItems(bomId) {
    bomId = parseInt(bomId, 10);
    if (!bomId || isNaN(bomId) || bomId <= 0) {
        if (typeof toastr !== 'undefined') {
            toastr.warning('Please select a reference package BOM first.');
        }
        return;
    }

    if (_isLoadingRefBom) {
        return;
    }
    _isLoadingRefBom = true;

    const btn = document.getElementById('applyReferenceBomBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="ti ti-loader-2 animate-spin me-1"></i> Loading...';
    }

    $('#cloneSourceBomId').val(bomId);
    $('#cloneSourceType').val('CLONED');
    $('#cloneBomItemsTbody').html(`
        <tr>
            <td colspan="6" class="px-4 py-8 text-center text-slate-500">
                <i class="ti ti-loader-2 animate-spin text-2xl text-indigo-600 block mb-2 mx-auto"></i>
                <span class="font-medium">Cloning raw materials from BOM #${bomId}...</span>
            </td>
        </tr>
    `);

    $.ajax({
        url: 'ajax.php',
        type: 'POST',
        dataType: 'json',
        data: {
            getReferenceBomItems: '1',
            bom_id: bomId
        },
        success: function(res) {
            _isLoadingRefBom = false;
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="ti ti-download"></i> Load Items';
            }
            if (res && res.status === 'success' && Array.isArray(res.items) && res.items.length > 0) {
                renderCloneItemRows(res.items);
                const pkgName = res.reference_bom && res.reference_bom.product_name ? res.reference_bom.product_name : ('BOM #' + bomId);
                $('#cloneBomComponentsSubText').html(`
                    <i class="ti ti-check-circle text-emerald-600 me-1"></i>
                    Cloned <strong>${res.items.length}</strong> raw materials from <strong>${escapeHtml(pkgName)}</strong>. Verify and edit quantities as needed.
                `);
                if (typeof toastr !== 'undefined') {
                    toastr.success(`Loaded ${res.items.length} raw materials from ${pkgName}`);
                }
            } else {
                const msg = (res && res.message) ? res.message : 'No active components found in selected reference BOM.';
                $('#cloneBomItemsTbody').html(`
                    <tr>
                        <td colspan="6" class="px-4 py-6 text-center text-amber-700 bg-amber-50/50">
                            <i class="ti ti-alert-triangle text-xl block mb-1"></i>
                            ${escapeHtml(msg)}
                        </td>
                    </tr>
                `);
                if (typeof toastr !== 'undefined') {
                    toastr.warning(msg);
                }
            }
        },
        error: function(xhr, status, err) {
            _isLoadingRefBom = false;
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="ti ti-download"></i> Load Items';
            }
            console.error('[CloneBOM] Failed to load reference BOM items:', err, xhr.responseText);
            if (typeof toastr !== 'undefined') {
                toastr.error('Failed to load reference BOM items. Check server connection.');
            }
            $('#cloneBomItemsTbody').html(`
                <tr>
                    <td colspan="6" class="px-4 py-6 text-center text-rose-600 bg-rose-50/50">
                        <i class="ti ti-alert-circle text-xl block mb-1"></i>
                        Failed to fetch reference items. Please try again.
                    </td>
                </tr>
            `);
        }
    });
}

/**
 * Render items into the clone table
 */
function renderCloneItemRows(items) {
    if (!Array.isArray(items) || items.length === 0) {
        $('#cloneBomItemsTbody').html(`
            <tr>
                <td colspan="6" class="px-4 py-6 text-center text-slate-400">
                    No components found in the selected BOM. Click "Add Component" to add manually.
                </td>
            </tr>
        `);
        return;
    }

    let unitsList = [];
    if (Array.isArray(window.CLONE_BOM_UNITS) && window.CLONE_BOM_UNITS.length > 0) {
        unitsList = window.CLONE_BOM_UNITS;
    } else if (Array.isArray(window.qtyUnitOptions) && window.qtyUnitOptions.length > 0) {
        unitsList = window.qtyUnitOptions;
    }

    let tbodyHtml = '';
    items.forEach(function(it, idx) {
        const rowNum = idx + 1;
        // Build unit options
        let unitOpts = '<option value="">--Unit--</option>';
        if (unitsList.length > 0) {
            unitsList.forEach(function(u) {
                const uId = u.id || u.value;
                const uName = u.short_name || u.fullname || u.label || u.name || ('Unit #' + uId);
                const sel = (uId == it.qty_unit_id) ? 'selected' : '';
                unitOpts += `<option value="${uId}" ${sel}>${escapeHtml(uName)}</option>`;
            });
        } else {
            const unitName = it.unit_name || ('Unit #' + it.qty_unit_id);
            unitOpts += `<option value="${it.qty_unit_id}" selected>${escapeHtml(unitName)}</option>`;
        }

        const qtyVal = (it.qty_per_unit !== undefined && it.qty_per_unit !== null && it.qty_per_unit !== '') 
            ? it.qty_per_unit 
            : (it.ref_qty_per_unit || '');
        const refBadge = (it.ref_qty_per_unit !== undefined && it.ref_qty_per_unit !== null && it.ref_qty_per_unit !== '')
            ? `<span class="text-[10px] text-slate-500 block mt-0.5">Ref Qty: <strong>${it.ref_qty_per_unit}</strong> ${escapeHtml(it.unit_name || '')}</span>`
            : '';

        tbodyHtml += `
            <tr class="clone-item-row group hover:bg-slate-50/50 transition-colors" data-row-id="${rowNum}">
                <td class="px-4 py-3 text-center text-slate-400 font-semibold row-number">${rowNum}</td>
                <td class="px-4 py-3">
                    <input type="hidden" name="raw_product_id[]" value="${it.raw_product_id}">
                    <input type="hidden" name="raw_product_category_id[]" value="${it.raw_product_category_id}">
                    <span class="font-bold text-slate-900 block">${escapeHtml(it.product_name || '')}</span>
                </td>
                <td class="px-4 py-3 text-slate-600 text-xs">
                    ${escapeHtml(it.category_name || '—')}
                </td>
                <td class="px-4 py-3">
                    <select name="qty_unit_id[]" class="form-select input-theme !py-1 text-xs" data-native-select="true" required>
                        ${unitOpts}
                    </select>
                </td>
                <td class="px-4 py-3 bg-amber-50/40">
                    <input type="number" step="any" min="0.00000001" name="qty_per_unit[]" class="input-theme !py-1 font-bold text-slate-900 border-amber-300 focus:border-indigo-500" placeholder="${it.ref_qty_per_unit ? 'Ref: ' + it.ref_qty_per_unit : 'Required qty'}" value="${qtyVal}" required>
                    ${refBadge}
                </td>
                <td class="px-4 py-3 text-center">
                    <button type="button" onclick="window.removeCloneRow(this)" class="btn btn-icon btn-label-danger btn-sm removeCloneItemBtn" title="Remove item">
                        <i class="ti ti-trash pointer-events-none"></i>
                    </button>
                </td>
            </tr>
        `;
    });

    $('#cloneBomItemsTbody').html(tbodyHtml);
}

/**
 * Remove a clone item row directly and reliably
 */
window.removeCloneRow = function(btn) {
    if (!btn) return;
    const row = btn.closest('tr');
    if (row) {
        row.remove();
    }
    const tbody = document.getElementById('cloneBomItemsTbody');
    if (tbody) {
        const rows = tbody.querySelectorAll('tr.clone-item-row');
        if (rows.length === 0) {
            tbody.innerHTML = `
                <tr id="cloneBomEmptyRow">
                    <td colspan="6" class="px-4 py-6 text-center text-slate-400">
                        <i class="ti ti-box text-2xl block mb-1"></i>
                        No components remaining. Click "Add Component" or select a reference package.
                    </td>
                </tr>
            `;
        } else {
            rows.forEach(function(r, idx) {
                const numEl = r.querySelector('.row-number');
                if (numEl) numEl.textContent = idx + 1;
                r.setAttribute('data-row-id', idx + 1);
            });
        }
    }
};

/**
 * Add a dynamic custom item row
 */
function addCustomCloneItemRow() {
    $('#cloneBomEmptyRow').remove();
    const count = $('#cloneBomItemsTbody tr.clone-item-row').length + 1;

    let prodOpts = '<option value="">--Select Raw Material--</option>';
    if (Array.isArray(window.CLONE_BOM_RAW_PRODUCTS)) {
        window.CLONE_BOM_RAW_PRODUCTS.forEach(function(p) {
            const codeStr = p.product_code ? ` [${p.product_code}]` : '';
            prodOpts += `<option value="${p.id}" data-cat-id="${p.category_id || ''}" data-unit-id="${p.unit_id || ''}">${escapeHtml(p.product_name)}${escapeHtml(codeStr)}</option>`;
        });
    }

    let catOpts = '<option value="">--Category--</option>';
    (window.CLONE_BOM_CATEGORIES || []).forEach(function(c) {
        catOpts += `<option value="${c.id}">${escapeHtml(c.name)}</option>`;
    });

    let unitOpts = '<option value="">--Unit--</option>';
    (window.CLONE_BOM_UNITS || []).forEach(function(u) {
        unitOpts += `<option value="${u.id}">${escapeHtml(u.short_name || u.fullname)}</option>`;
    });

    const rowHtml = `
        <tr class="clone-item-row group hover:bg-slate-50/50 transition-colors" data-row-id="${count}">
            <td class="px-4 py-3 text-center text-slate-400 font-semibold row-number">${count}</td>
            <td class="px-4 py-3">
                <select name="raw_product_id[]" class="input-theme !py-1 text-xs raw-product-picker" style="width: 100%;" required>
                    ${prodOpts}
                </select>
            </td>
            <td class="px-4 py-3 text-slate-600 text-xs">
                <select name="raw_product_category_id[]" class="input-theme !py-1 text-xs raw-cat-picker">
                    ${catOpts}
                </select>
            </td>
            <td class="px-4 py-3">
                <select name="qty_unit_id[]" class="input-theme !py-1 text-xs" required>
                    ${unitOpts}
                </select>
            </td>
            <td class="px-4 py-3 bg-amber-50/40">
                <input type="number" step="any" min="0.00000001" name="qty_per_unit[]" class="input-theme !py-1 font-bold text-slate-900 border-amber-300" placeholder="Required qty" value="" required>
            </td>
            <td class="px-4 py-3 text-center">
                <button type="button" onclick="window.removeCloneRow(this)" class="btn btn-icon btn-label-danger btn-sm removeCloneItemBtn" title="Remove item">
                    <i class="ti ti-trash pointer-events-none"></i>
                </button>
            </td>
        </tr>
    `;

    $('#cloneBomItemsTbody').append(rowHtml);
    renumberCloneRows();
}

function renumberCloneRows() {
    $('#cloneBomItemsTbody tr.clone-item-row').each(function(idx) {
        $(this).find('.row-number').text(idx + 1);
        $(this).attr('data-row-id', idx + 1);
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Global function called by onclick, onchange, and click handlers
window.applyCloneReferenceBom = function() {
    const sel = document.getElementById('cloneReferenceBomSelect');
    const bomId = (sel && sel.value) ? sel.value : ($('#cloneReferenceBomSelect').val() || '');
    if (!bomId) {
        if (typeof toastr !== 'undefined') {
            toastr.warning('Please select a reference package from the dropdown first.');
        } else {
            alert('Please select a reference package from the dropdown first.');
        }
        return;
    }
    loadReferenceBomItems(bomId);
};

// ─── Event Bindings ───────────────────────────────────────────────────────────
function initCloneBomModalBindings() {
    if (typeof jQuery === 'undefined') {
        setTimeout(initCloneBomModalBindings, 50);
        return;
    }
    const $ = jQuery;

    // Reference select changed - delegated listener
    $(document).off('change', '#cloneReferenceBomSelect').on('change', '#cloneReferenceBomSelect', function() {
        window.applyCloneReferenceBom();
    });

    // "Load Items" button clicked
    $(document).off('click', '#applyReferenceBomBtn').on('click', '#applyReferenceBomBtn', function(e) {
        e.preventDefault();
        window.applyCloneReferenceBom();
    });

    // Remove row - delegated backup listener
    $(document).off('click', '.removeCloneItemBtn').on('click', '.removeCloneItemBtn', function(e) {
        e.preventDefault();
        window.removeCloneRow(this);
    });

    // Add component button
    $('#cloneAddCustomItemBtn').off('click').on('click', function() {
        addCustomCloneItemRow();
    });

    // When a raw material is selected, automatically sync its category and default unit
    $(document).on('change', '.raw-product-picker', function() {
        const prodId = $(this).val();
        const $row = $(this).closest('tr');
        if (!prodId) return;

        const $opt = $(this).find('option:selected');
        const catId = $opt.attr('data-cat-id') || $opt.data('cat-id');
        const unitId = $opt.attr('data-unit-id') || $opt.data('unit-id');

        if (catId) {
            $row.find('.raw-cat-picker').val(catId);
        }
        if (unitId) {
            $row.find('[name="qty_unit_id[]"]').val(unitId);
        }
    });

    // When category is changed in custom row -> instantly filter raw material options
    $(document).on('change', '.raw-cat-picker', function() {
        const catId = $(this).val();
        const $row = $(this).closest('tr');
        const $prodSelect = $row.find('.raw-product-picker');
        const currentProdId = $prodSelect.val();

        let prodOpts = '<option value="">--Select Raw Material--</option>';
        (window.CLONE_BOM_RAW_PRODUCTS || []).forEach(function(p) {
            if (!catId || String(p.category_id) === String(catId)) {
                const codeStr = p.product_code ? ` [${p.product_code}]` : '';
                const sel = (String(p.id) === String(currentProdId)) ? 'selected' : '';
                prodOpts += `<option value="${p.id}" data-cat-id="${p.category_id || ''}" data-unit-id="${p.unit_id || ''}" ${sel}>${escapeHtml(p.product_name)}${escapeHtml(codeStr)}</option>`;
            }
        });
        $prodSelect.html(prodOpts);
    });

    // Helper to collect items array
    function getCloneItemsData() {
        const items = [];
        let hasError = false;
        let errorMsg = '';

        $('#cloneBomItemsTbody tr.clone-item-row').each(function(idx) {
            const $row = $(this);
            const rawProdId = Number($row.find('[name="raw_product_id[]"]').val() || 0);
            const rawCatId  = Number($row.find('[name="raw_product_category_id[]"]').val() || 0);
            const unitId    = Number($row.find('[name="qty_unit_id[]"]').val() || 0);
            const qtyVal    = $row.find('[name="qty_per_unit[]"]').val();
            const qty       = parseFloat(qtyVal);

            if (!rawProdId) {
                hasError = true;
                errorMsg = `Row #${idx + 1}: Please select a raw material product.`;
                return false;
            }
            if (!unitId) {
                hasError = true;
                errorMsg = `Row #${idx + 1}: Please select a unit.`;
                return false;
            }

            items.push({
                raw_product_id: rawProdId,
                raw_product_category_id: rawCatId,
                qty_unit_id: unitId,
                qty_per_unit: isNaN(qty) ? '' : qty
            });
        });

        return { items, hasError, errorMsg };
    }

    // Submit / Re-submit for Approval
    $('#cloneSubmitApprovalBtn').on('click', function() {
        const prodId = Number($('#cloneFinishedProductId').val() || 0);
        const existingBomId = Number($('#cloneExistingBomId').val() || 0);
        const isReSubmit = existingBomId > 0;
        const bomName = $.trim($('#cloneBomName').val());

        if (!prodId && !existingBomId) {
            toastr.error('Product is missing.');
            return;
        }
        if (!bomName) {
            toastr.error('Please enter a BOM name.');
            return;
        }

        const data = getCloneItemsData();
        if (data.hasError) {
            toastr.error(data.errorMsg);
            return;
        }

        if (data.items.length === 0) {
            toastr.error('Please add at least one component to the BOM.');
            return;
        }

        // Validate that all items have a filled quantity > 0
        let zeroCount = 0;
        data.items.forEach(function(it) {
            if (!it.qty_per_unit || it.qty_per_unit <= 0) {
                zeroCount++;
            }
        });

        if (zeroCount > 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Missing Quantities',
                text: `${zeroCount} component(s) have empty or zero quantity. Please enter the required quantity for all components before submitting for approval.`,
                customClass: { confirmButton: 'btn btn-warning' },
                buttonsStyling: false
            });
            return;
        }

        const confirmTitle = isReSubmit ? 'Re-submit BOM for Approval?' : 'Submit BOM for Approval?';
        const confirmText = isReSubmit
            ? 'This will update the existing pending BOM with your revised components and keep it under review for management approval.'
            : 'This BOM will be submitted with PENDING APPROVAL status. Once approved by management, it will be ready for production use.';
        const confirmBtnText = isReSubmit ? '<i class="ti ti-refresh me-1"></i> Yes, Re-submit' : '<i class="ti ti-send me-1"></i> Yes, Submit';

        Swal.fire({
            title: confirmTitle,
            text: confirmText,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: confirmBtnText,
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-success waves-effect waves-light me-2',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then((result) => {
            if (!result.isConfirmed) return;

            const payload = {
                submitBomForApproval: '1',
                existing_bom_id: existingBomId,
                finished_product_id: prodId,
                category_id: $('#cloneCategoryId').val(),
                bom_name: bomName,
                bom_type: $('#cloneBomType').val(),
                descriptions: $('#cloneBomDescription').val(),
                source_type: $('#cloneSourceType').val(),
                source_bom_id: $('#cloneSourceBomId').val(),
                items: JSON.stringify(data.items)
            };

            const $btn = $('#cloneSubmitApprovalBtn');
            const origBtnHtml = $btn.html();
            $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin me-1"></i> ' + (isReSubmit ? 'Re-submitting...' : 'Submitting...'));

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: payload,
                success: function(res) {
                    $btn.prop('disabled', false).html(origBtnHtml);
                    if (res.status === 'success') {
                        bootstrap.Modal.getInstance(document.getElementById('cloneCreateBomModal')).hide();
                        Swal.fire({
                            icon: 'success',
                            title: isReSubmit ? 'Pending BOM Updated!' : 'Submitted for Approval!',
                            text: res.message,
                            customClass: { confirmButton: 'btn btn-success' },
                            buttonsStyling: false
                        });
                        if (typeof window._cloneBomSuccessCallback === 'function') {
                            window._cloneBomSuccessCallback(res);
                        }
                        if (typeof loadBomSettingsTable === 'function') {
                            loadBomSettingsTable();
                        }
                    } else {
                        toastr.error(res.message || 'Failed to submit BOM.');
                    }
                },
                error: function() {
                    $btn.prop('disabled', false).html(origBtnHtml);
                    toastr.error('Network error submitting BOM.');
                }
            });
        });
    });
}
function safeInitCloneBomModalBindings() {
    function setup() {
        initCloneBomModalBindings();
        $(document).on('hidden.bs.modal', '#cloneCreateBomModal', function () {
            if ($('.modal.show').length > 0) {
                $('body').addClass('modal-open');
            }
        });
    }
    if (typeof $ !== 'undefined' && typeof $.fn !== 'undefined') {
        setup();
    } else {
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof $ !== 'undefined' && typeof $.fn !== 'undefined') {
                setup();
            }
        });
    }
}
safeInitCloneBomModalBindings();

window.openCloneBomModal = openCloneBomModal;
window.handleApproveBom = handleApproveBom;
window.handleRejectBom = handleRejectBom;
window.handleViewBomHistory = handleViewBomHistory;
window.loadReferenceBomItems = loadReferenceBomItems;
window.applyCloneReferenceBom = applyCloneReferenceBom;
window.removeCloneRow = removeCloneRow;
window.addCustomCloneItemRow = addCustomCloneItemRow;

/**
 * Approve BOM Handler
 */
function handleApproveBom(bomId, bomName = '') {
    Swal.fire({
        title: 'Approve BOM?',
        text: `Are you sure you want to approve "${bomName || 'BOM #' + bomId}"? It will become active for production planning immediately.`,
        icon: 'success',
        showCancelButton: true,
        confirmButtonText: '<i class="ti ti-check me-1"></i> Approve',
        cancelButtonText: 'Cancel',
        customClass: {
            confirmButton: 'btn btn-success waves-effect waves-light me-2',
            cancelButton: 'btn btn-label-secondary waves-effect waves-light'
        },
        buttonsStyling: false
    }).then((result) => {
        if (!result.isConfirmed) return;

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                approveBom: '1',
                bom_id: bomId,
                comments: 'Approved by management'
            },
            success: function(res) {
                if (res.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Approved!',
                        text: res.message,
                        customClass: { confirmButton: 'btn btn-success' },
                        buttonsStyling: false
                    });
                    if (typeof loadBomSettingsTable === 'function') {
                        loadBomSettingsTable();
                    }
                } else {
                    toastr.error(res.message || 'Failed to approve BOM.');
                }
            },
            error: function() {
                toastr.error('Server error approving BOM.');
            }
        });
    });
}

/**
 * Reject BOM Handler
 */
function handleRejectBom(bomId, bomName = '') {
    Swal.fire({
        title: 'Reject BOM',
        text: `Please enter the reason for rejecting "${bomName || 'BOM #' + bomId}":`,
        input: 'textarea',
        inputPlaceholder: 'Reason for rejection (e.g. incorrect material ratio, missing component)...',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: '<i class="ti ti-x me-1"></i> Reject BOM',
        cancelButtonText: 'Cancel',
        inputValidator: (value) => {
            if (!value || !value.trim()) {
                return 'You must provide a rejection reason!';
            }
        },
        customClass: {
            confirmButton: 'btn btn-danger waves-effect waves-light me-2',
            cancelButton: 'btn btn-label-secondary waves-effect waves-light'
        },
        buttonsStyling: false
    }).then((result) => {
        if (!result.isConfirmed) return;

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                rejectBom: '1',
                bom_id: bomId,
                comments: result.value
            },
            success: function(res) {
                if (res.status === 'success') {
                    Swal.fire({
                        icon: 'info',
                        title: 'BOM Rejected',
                        text: res.message,
                        customClass: { confirmButton: 'btn btn-primary' },
                        buttonsStyling: false
                    });
                    if (typeof loadBomSettingsTable === 'function') {
                        loadBomSettingsTable();
                    }
                } else {
                    toastr.error(res.message || 'Failed to reject BOM.');
                }
            },
            error: function() {
                toastr.error('Server error rejecting BOM.');
            }
        });
    });
}

/**
 * Submit an existing Draft BOM for approval
 */
function handleSubmitDraftBom(bomId, bomName = '') {
    Swal.fire({
        title: 'Submit for Approval?',
        text: `Submit "${bomName || 'BOM #' + bomId}" for management approval?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: '<i class="ti ti-send me-1"></i> Submit',
        cancelButtonText: 'Cancel',
        customClass: {
            confirmButton: 'btn btn-primary waves-effect waves-light me-2',
            cancelButton: 'btn btn-label-secondary waves-effect waves-light'
        },
        buttonsStyling: false
    }).then((result) => {
        if (!result.isConfirmed) return;

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                submitBomForApproval: '1',
                bom_id: bomId
            },
            success: function(res) {
                if (res.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Submitted!',
                        text: res.message,
                        customClass: { confirmButton: 'btn btn-success' },
                        buttonsStyling: false
                    });
                    if (typeof loadBomSettingsTable === 'function') {
                        loadBomSettingsTable();
                    }
                } else {
                    toastr.error(res.message || 'Failed to submit BOM.');
                }
            },
            error: function() {
                toastr.error('Server error submitting BOM.');
            }
        });
    });
}

/**
 * View BOM Approval History
 */
function handleViewBomHistory(bomId) {
    $('#bomHistorySubTitle').text('Audit trail for BOM #' + bomId);
    $('#bomHistoryContent').html('<div class="text-center py-6 text-slate-400"><i class="ti ti-loader-2 animate-spin text-2xl block mb-1"></i> Loading audit trail...</div>');

    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('viewBomHistoryModal'));
    modal.show();

    $.ajax({
        url: 'ajax.php',
        type: 'POST',
        dataType: 'json',
        data: {
            getBomApprovalHistory: '1',
            bom_id: bomId
        },
        success: function(res) {
            if (res.status === 'success' && res.history && res.history.length > 0) {
                let timelineHtml = '<div class="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">';
                res.history.forEach(function(h) {
                    let badgeClass = 'bg-slate-100 text-slate-700';
                    let dotColor = 'bg-slate-400';
                    if (h.action === 'APPROVED') {
                        badgeClass = 'bg-emerald-100 text-emerald-800';
                        dotColor = 'bg-emerald-500';
                    } else if (h.action === 'REJECTED') {
                        badgeClass = 'bg-rose-100 text-rose-800';
                        dotColor = 'bg-rose-500';
                    } else if (h.action === 'SUBMITTED') {
                        badgeClass = 'bg-blue-100 text-blue-800';
                        dotColor = 'bg-blue-500';
                    } else if (h.action === 'CREATED') {
                        badgeClass = 'bg-indigo-100 text-indigo-800';
                        dotColor = 'bg-indigo-500';
                    }

                    timelineHtml += `
                        <div class="relative">
                            <span class="absolute -left-6 top-1.5 h-3 w-3 rounded-full ${dotColor} ring-4 ring-white"></span>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3">
                                <div class="flex flex-wrap items-center justify-between gap-2">
                                    <span class="inline-flex items-center rounded-md px-2 py-0.5 text-xs font-bold ${badgeClass}">
                                        ${escapeHtml(h.action)}
                                    </span>
                                    <span class="text-[11px] text-slate-400">
                                        <i class="ti ti-clock me-1"></i>${escapeHtml(h.created_at || '')}
                                    </span>
                                </div>
                                <div class="mt-2 text-xs text-slate-700">
                                    <strong>Performed by:</strong> ${escapeHtml(h.user_name || 'System')}
                                </div>
                                ${h.comments ? `<div class="mt-1 text-xs text-slate-600 bg-white p-2 rounded-lg border border-slate-100"><strong>Note:</strong> ${escapeHtml(h.comments)}</div>` : ''}
                            </div>
                        </div>
                    `;
                });
                timelineHtml += '</div>';
                $('#bomHistoryContent').html(timelineHtml);
            } else {
                $('#bomHistoryContent').html('<div class="text-center py-6 text-slate-400">No audit history found for this BOM.</div>');
            }
        },
        error: function() {
            $('#bomHistoryContent').html('<div class="text-center py-6 text-rose-500">Failed to load history.</div>');
        }
    });
}

// Ensure backdrop is always positioned behind clone modal (z-index 2040 vs 2050)
$(function() {
    $(document).on('show.bs.modal', '#cloneCreateBomModal', function () {
        setTimeout(function () {
            $('.modal-backdrop').not('.clone-bom-backdrop').addClass('clone-bom-backdrop').css('z-index', 2040);
            $('#cloneCreateBomModal').css('z-index', 2050);
        }, 10);
    });

    $(document).on('shown.bs.modal', '#cloneCreateBomModal', function () {
        $('.modal-backdrop').not('.clone-bom-backdrop').addClass('clone-bom-backdrop').css('z-index', 2040);
        $('#cloneCreateBomModal').css('z-index', 2050);
    });

    $(document).on('hidden.bs.modal', '#cloneCreateBomModal', function () {
        $('.clone-bom-backdrop').remove();
        if ($('.modal.show').length === 0) {
            $('.modal-backdrop').remove();
            $('body').removeClass('modal-open').css({ overflow: '', paddingRight: '' });
        }
    });
});
</script>
