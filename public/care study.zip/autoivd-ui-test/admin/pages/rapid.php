<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Review rapid entries and generate PDFs from selected records</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <?php if (roleHasPermission($_SESSION['role_id'], 'generate_rapid_pdf')) { ?>
                        <button id="generatePdfBtn"
                            class="inline-flex h-10 w-full md:w-40 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            onclick="getCheckedValues()">
                            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            <span class="btn-text whitespace-nowrap">Generate PDF</span>
                        </button>
                    <?php } ?>

                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="rapidPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="rapid-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchRapidData"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th
                                class="w-14 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                            </th>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="pe.entry_date">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable d-none px-6 py-3" data-column="pe.month_year">Month/Year</th>
                            <th class="sortable w-24 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="pe.total_man_power">
                                <span class="inline-flex items-center gap-1">TMP <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-24 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="pe.total_working_hours">
                                <span class="inline-flex items-center gap-1">TWH <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable d-none px-6 py-3" data-column="pe.batch_number">Batch Number</th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="u.name">
                                <span class="inline-flex items-center gap-1">Created By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th
                                class="w-36 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="rapidTableBody"></tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer since it's now in the top strip -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewRapiData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Rapid Data</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">View rapid production entry details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div class="modal-body max-h-[75vh] overflow-y-auto bg-slate-50/70 !px-4 !py-3"
                    id="viewRapiDataModalBody"></div>
                <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                    <button type="button"
                        class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                        data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="rapidModalDownloadBtn"
                        class="biogenix-btn-download inline-flex" hidden><i class="ti ti-download text-lg"></i> Download</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php startSection('scripts'); ?>
<script>
    let currentSortColumn = 'recent';
    let currentSortDirection = 'DESC';
    $(document).on('click', '.modalViewDataAnimate', function () {
        $('#viewRapiDataModalBody').html('');
        let id = $(this).attr('data-id');
        if (id) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    fetchRapidData: 'fetchRapidData',
                    id: id
                },
                success: function (res) {
                    try {
                        if (res.status === 'success') {
                            $('#viewRapiDataModalBody').html(res.data);
                            $('#rapidModalDownloadBtn').data('id', id).prop('hidden', false);
                            $('#viewRapiData').modal('show');
                        } else {
                            toastr.error(res.message || 'Something went wrong.');
                        }
                    } catch (e) {
                        console.error('Invalid JSON:', e);
                        toastr.error('Invalid server response.');
                    }
                },
                error: function () {
                    alert('Submission failed.');
                },
                complete: function () { }
            });
        }
    });
    function loadRapidTable(page = 1) {
        currentPage = page;
        const search = $('#searchRapidData').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadRapidData: 'loadRapidData',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#rapidTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const shownThrough = totalRows ? Math.min(page * Number(perPage), totalRows) : 0;

            },
            error: function () {
                $('#rapidTableBody').html('<tr><td colspan="9" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }
    async function getCheckedValues() {
        const selectedIds = $('.row-checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        if (selectedIds.length === 0) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                positionClass: 'toast-top-right',
                timeOut: 3000
            };
            toastr.error('Please select at least one record.');
            return;
        }

        const $btn = $('#generatePdfBtn');
        const $spinner = $btn.find('.spinner-border');
        const $text = $btn.find('.btn-text');

        $btn.prop('disabled', true);
        $spinner.removeClass('d-none');
        $text.text('Generating...');

        try {
            const formData = new FormData();
            formData.append('ids', selectedIds.join(','));
            formData.append('csrf_token', <?= json_encode($_SESSION['csrf_token'] ?? '') ?>);

            const response = await fetch(
                <?= json_encode(asset('admin/pages/daily_report_bulk_template.php')) ?>,
                {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                }
            );

            if (!response.ok) {
                const message = (await response.text()).trim();
                throw new Error(message || 'Unable to generate the selected Daily Production Reports.');
            }

            const contentType = String(response.headers.get('Content-Type') || '').toLowerCase();
            if (!contentType.includes('application/pdf')) {
                throw new Error('The server did not return a valid PDF document.');
            }

            const pdfBlob = await response.blob();
            const contentDisposition = String(response.headers.get('Content-Disposition') || '');
            const fileNameMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
            const fileName = fileNameMatch?.[1] || 'daily_production_reports.pdf';
            const objectUrl = URL.createObjectURL(pdfBlob);
            const downloadLink = document.createElement('a');
            downloadLink.href = objectUrl;
            downloadLink.download = fileName;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            downloadLink.remove();
            window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);

            $('.row-checkbox:checked').prop('checked', false);
            toastr.success('Daily Production Report PDF downloaded successfully.');
        } catch (error) {
            toastr.error(error.message || 'Unable to generate the selected Daily Production Reports.');
        } finally {
            $btn.prop('disabled', false);
            $spinner.addClass('d-none');
            $text.text('Generate PDF');
        }
    }
    $(document).ready(function () {
        loadRapidTable();
        $('#searchRapidData').on('input', function () {
            loadRapidTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadRapidTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.rapid-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#rapidPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });
    });

    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortDirection = currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortDirection = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortDirection.toLowerCase());
        loadRapidTable(1);
    });

    $(document).on('click', '.pdfDailyReportRapidDownloadBtn', function () {
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/daily_report_template.php?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');
            toastr.success('Daily report PDF is being downloaded.');
        }
    });

    $('#viewRapiData').on('hidden.bs.modal', function () {
        $('#rapidModalDownloadBtn').data('id', '').prop('hidden', true);
    });

    $('#rapidModalDownloadBtn').on('click', function () {
        const id = $(this).data('id');
        if (!id) return;
        const url = "<?php echo APP_URL; ?>admin/pages/daily_report_template.php?id=" + id + "&triggerDownload=1";
        window.open(url, '_blank');
        toastr.success('Daily report PDF is being downloaded.');
    });
</script>
<?php endSection(); ?>
