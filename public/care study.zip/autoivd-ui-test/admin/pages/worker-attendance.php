<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage and track worker attendance</p>
        </div>
    </div>

    <?php if (isset($_SESSION['role_id']) && in_array($_SESSION['role_id'], [1, 6, 12])) { ?>
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 mb-6" id="dashboard" style="gap: 15px;">
        </div>
    <?php } ?>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip for this page) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="waPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100">100 items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="1000">1000 items</a></li>
                            <li><a class="wa-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative flex items-center justify-between gap-3 shrink-0 w-full md:w-auto">
                        <label for="fromDate"
                            class="text-sm font-bold text-slate-700 whitespace-nowrap min-w-[40px]">From:</label>
                        <input type="date" id="fromDate" value="<?= date('Y-m-d') ?>"
                            class="h-10 w-full md:w-40 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" />
                    </div>

                    <div class="relative flex items-center justify-between gap-3 shrink-0 w-full md:w-auto">
                        <label for="toDate"
                            class="text-sm font-bold text-slate-700 whitespace-nowrap min-w-[40px]">To:</label>
                        <input type="date" id="toDate" value="<?= date('Y-m-d') ?>"
                            class="h-10 w-full md:w-40 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" />
                    </div>

                    <div class="relative h-10 min-w-[220px] flex-grow hidden md:block"></div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'worker_attendance_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="animationModalBtn" data-bs-toggle="tooltip" data-bs-placement="top"
                            data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable w-40 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="attendance_date" data-order="asc">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-52 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="department_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">Department <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-40 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Total Workers</th>
                            <th class="w-48 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Head Name</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Emp
                                Name</th>
                            <th
                                class="w-32 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="workerAttendanceTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer since it's now in the top strip -->
            <style>
                #footerPerPageSelect+.dropdown {
                    display: none !important;
                }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content bg-white rounded-xl shadow-panel border-0 overflow-hidden">
                <div class="modal-header border-b border-slate-100 p-6 flex justify-between items-center bg-slate-50">
                    <div class="flex items-center gap-3">
                        <span
                            class="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-user-check text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                Worker Attendance</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Record attendance for workers by
                                department</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addWorkerAttendanceForm">
                    <div class="modal-body bg-slate-50/70 p-6">
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 mb-6">
                            <div>
                                <label for="companyType" class="mb-1 block text-sm font-medium text-slate-800">Select
                                    Company</label>
                                <select name="company_type" id="companyType" class="input-theme select2" required>
                                    <option value="">----Company----</option>
                                    <?php foreach (Constant::EMPLOYEES['COMPANY_TYPE'] as $ckey => $cval) { ?>
                                        <option value="<?= $ckey; ?>"><?= $cval; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div>
                                <label for="employmentCategory"
                                    class="mb-1 block text-sm font-medium text-slate-800">Select Type</label>
                                <select name="employment_category" id="employmentCategory" class="input-theme select2"
                                    required>
                                    <option value="">----Category----</option>
                                    <?php foreach (Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE'] as $ectkey => $ectval) { ?>
                                        <option value="<?= $ectkey; ?>"><?= $ectval; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div>
                                <label for="name" class="mb-1 block text-sm font-medium text-slate-800">Select
                                    Department</label>
                                <select name="departmentsList" id="departmentsList" class="input-theme select2"
                                    required></select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="mb-4">
                                <small class="text-slate-800 font-bold text-sm d-block">List</small>
                            </div>
                            <div id="tableLoader" class="text-center py-4 d-none">
                                <div class="inline-block relative w-10 h-10">
                                    <div class="spinner-border text-emerald-700 w-full h-full absolute top-0 left-0"
                                        role="status"></div>
                                </div>
                                <div class="text-slate-500 mt-3 text-sm">
                                    Loading data, please wait.
                                </div>
                            </div>
                            <div id="workerListWrpper"></div>
                        </div>
                    </div>
                    <div class="modal-footer p-4 pt-0 flex justify-end gap-3 border-0 bg-transparent">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editMenusModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="editMenusForm">
                    <div class="modal-body">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="editWorkerAttendanceModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Remove Attendance</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="editWorkerAttendanceForm">
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewAbsentPersonsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewAbsentPersonsTitle"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="viewAbsentPersons">
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let sortColumn = 'attendance_date';
    let sortDirection = 'DESC';

    function loadWorkerAttendanceTable(page = 1) {
        currentPage = page;
        const perPage = $('#perPageSelect').val();
        const fromdate = $('#fromDate').val();
        const todate = $('#toDate').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadWorkerAttendanceTable: 'loadWorkerAttendanceTable',
                page: page,
                per_page: perPage,
                fromDate: fromdate,
                toDate: todate,
                sort_column: sortColumn,
                sort_direction: sortDirection
            },
            success: function (response) {
                $('#workerAttendanceTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const visibleRows = Number(response.visibleRows || 0);
                const totalRows = Number(response.totalRows || 0);
                if (response.visibleRows !== undefined) {
                    $('#workerAttendancePaginationSummary').text(`Showing ${visibleRows} results of ${totalRows}`);
                }
            },
            error: function () {
                $('#workerAttendanceTableBody').html('<tr><td colspan="7" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }


    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function (response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                departmentOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#departmentsList").html(optionsHtml).trigger('change');
            },
            error: function (xhr, status, error) {
                console.error("Failed to load department units:", error);
            }
        });
    }

    function loadWorkerList() {
        $('#tableLoader').removeClass('d-none');
        $("#workerListWrpper").html('');
        let compType = $('#companyType').val();
        let empCat = $('#employmentCategory').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getWorkersList: 'getWorkersList', compType: compType, empCat: empCat
            },
            success: function (response) {
                workerOptions = response;
                let workerOptionsHtml = '<div class="row">';
                workerOptions.forEach(worker => {
                    const isChecked = worker.already_marked > 0 ? 'checked disabled' : '';
                    workerOptionsHtml += `<div class="col-md-4 mb-2">`;
                    workerOptionsHtml += `<div class="form-check">`;
                    workerOptionsHtml += `<input class="form-check-input requisition-checkbox" type="checkbox" name="worker_ids[]" value="${worker.id}" id="worker_${worker.id}" ${isChecked} />`;
                    workerOptionsHtml += `<label class="form-check-label" for="worker_${worker.id}">${worker.first_name} ${worker.last_name ?? ''} (${worker.emp_code})</label>`;
                    workerOptionsHtml += `</div></div>`;
                });

                workerOptionsHtml += '</div>';
                $("#workerListWrpper").html(workerOptionsHtml);
                $('#tableLoader').addClass('d-none');
            },

            error: function (xhr, status, error) {
                console.error("Failed to load worker list:", error);
            }
        });
    }


    $(document).on('click', '.sortable', function () {
        const column = $(this).data('column');

        if (sortColumn === column) {
            // Toggle ASC/DESC if same column clicked
            sortDirection = sortDirection === 'ASC' ? 'DESC' : 'ASC';
        } else {
            // New column clicked → reset to ASC
            sortColumn = column;
            sortDirection = 'ASC';
        }

        // Reset all icons to default
        $('.sortable i')
            .removeClass('fa-sort-asc fa-sort-desc')
            .addClass('fa-sort');

        // Update clicked column icon
        const icon = $(this).find('i');
        icon.removeClass('fa-sort fa-sort-asc fa-sort-desc');
        if (sortDirection === 'ASC') {
            icon.addClass('fa-sort-asc');
        } else {
            icon.addClass('fa-sort-desc');
        }

        // Reload table
        loadWorkerAttendanceTable(1);
    });
    function loadDashboardEmployeesAttendance() {
        // Check if element exists
        if ($('#dashboard').length) {
            $('#dashboard').html(''); // clear first

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadEmployeesDashboardDailyAttendance: 'loadEmployeesDashboardDailyAttendance'
                },
                success: function (response) {
                    $('#dashboard').html(response.data || '');
                },
                error: function () {
                    $('#dashboard').html('');
                }
            });
        }
    }


    $(document).ready(function () {
        loadWorkerAttendanceTable();
        loadDashboardEmployeesAttendance();
        $('#fromDate, #toDate').on('change', function () {
            loadWorkerAttendanceTable(1); // Load data again on change
        });

        $('#perPageSelect').on('change', function () {
            loadWorkerAttendanceTable(1);
        });

        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadWorkerAttendanceTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.wa-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#waPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });



        $(document).on('click', '#animationModalBtn', function () {
            loadDepartmentsList();
            $('#animationModal').modal('show');
            $('#workerListWrpper').html('');
            $('#animationModal .select2').select2({ dropdownParent: $('#animationModal') });
        });

        $(document).on('change', '#companyType', function () {
            loadWorkerList();
        });

        $(document).on('change', '#employmentCategory', function () {
            loadWorkerList();
        });

        $(document).on('change', '#departmentsList', function () {
            loadWorkerList();
        });

        $('#addWorkerAttendanceForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addWorkerAttendanceForm');
            const formData = new FormData(form);

            formData.append('submitWorkerAttendance', 'submitWorkerAttendance');

            const selectedDept = $('#departmentsList').val();
            const checkedWorkers = $('input[name="worker_ids[]"]:checked');

            if (!selectedDept) {
                toastr.error("Please select a department.");
                return;
            }

            if (checkedWorkers.length === 0) {
                toastr.error("Please select at least one worker.");
                return;
            }

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addWorkerAttendanceForm')[0].reset();
                        toastr.success(response.message);
                        loadWorkerAttendanceTable();
                        loadDashboardEmployeesAttendance();
                    } else {
                        toastr.error(response.message || "Something went wrong.");
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });

    $(document).on('click', '.deleteMenuModalBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteMenuRecord: 'deleteMenuRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadWorkerAttendanceTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editMenuModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editMenusForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchMenuRecord: 'fetchMenuRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editMenusModal').modal('show');
                        $('#editMenusForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.workerAttendanceDeleteBtn', function () {
        let createdById = $(this).data('created-by-id');
        let deptId = $(this).data('dept-id');
        let createdDate = $(this).data('created-date');
        if (deptId && createdById && createdDate) {
            $('#editWorkerAttendanceForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchWorkerAttendanceRecord: 'fetchWorkerAttendanceRecord',
                    createdById: createdById,
                    deptId: deptId,
                    createdDate: createdDate

                },
                success: function (response) {
                    if (response.status === 'success') {
                        $('#editWorkerAttendanceModal').modal('show');
                        $('#editWorkerAttendanceForm').find('.modal-body').html(response.data);
                    } else if (response.status === 'error') {
                        toastr.error(response.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editMenusForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editMenusForm');
        const formData = new FormData(form);
        formData.append('updateMenus', 'updateMenus');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editMenusModal').modal('hide');
                    $('#editMenusForm').find('modal-body').html();
                    loadWorkerAttendanceTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });
    $(document).on('click', '.removeSingleWorkerAttendanceBtn', function () {
        let id = $(this).data('id');
        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteWorkerAttendanceRecord: 'deleteWorkerAttendanceRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        $(`.worker-div[data-id="${id}"]`).remove();
                        if (res.status === 'success') {
                            loadWorkerAttendanceTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });
    $(document).on('click', '.absent-data', function () {
        let companyType = $(this).data('company');
        let categoryType = $(this).data('category');
        let attendanceType = $(this).data('attendance-type');
        if (companyType != '' && categoryType != '') {
            // $('#viewAbsentPersons').find('modal-body').html();
            $('#viewAbsentPersons .modal-body').html('<p class="text-center text-muted">Loading...</p>');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchAbsentRecord: 'fetchAbsentRecord',
                    companyType: companyType,
                    categoryType: categoryType,
                    attendanceType: attendanceType
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewAbsentPersonsModal').modal('show');
                        $('#viewAbsentPersonsTitle').html(res.title);
                        $('#viewAbsentPersons').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

</script>
<?php endSection(); ?>
