<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../functions.php";
require_once __DIR__ . "/../document_pdf_helpers.php";

documentPdfRequireAnyPermission($conn, [
    'transfer_ticket_view',
    'transfer_ticket_generate_pdf',
    'transfer_ticket_menu_list',
    'transfer_ticket_add',
    'transfer_ticket_edit',
    'store_goods_received_production_list',
    'production_plan_view',
    'material_requisition_view'
]);
$id = documentPdfEncryptedPositiveId($_GET['id'] ?? '');
$fileName = '';
// Fetch data from DB
$stmt = $conn->prepare("SELECT * FROM `transfer_ticket` WHERE `id` = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    http_response_code(404);
    exit("No transfer ticket found.");
}
$unitMap = [];
$unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
while ($rowUnit = $unitQuery->fetch_assoc()) {
    $unitMap[$rowUnit['id']] = $rowUnit['short_name'];
}
$packSizeUnit = $unitMap[$row['pack_size_unit']] ?? $row['pack_size_unit'];
$sampledQaUnit = $unitMap[$row['sampled_qa_unit']] ?? $row['sampled_qa_unit'];
$quantityTransferredUnit = $unitMap[$row['quantity_transferred_unit']] ?? $row['quantity_transferred_unit'];

// Strip unit suffix from stored values to prevent duplicate units in print
$packSizeVal = stripDuplicateUnitSuffix((string) ($row['pack_size'] ?? ''), (string) $packSizeUnit);
$sampledQaVal = stripDuplicateUnitSuffix((string) ($row['sampled_qa'] ?? ''), (string) $sampledQaUnit);
$quantityTransferredVal = stripDuplicateUnitSuffix((string) ($row['quantity_transferred'] ?? ''), (string) $quantityTransferredUnit);
$rawName = $row['fg_coa_no'].'-'.$row['product_description'];
$fileName = preg_replace('/[^A-Za-z0-9]+/', '_', $rawName);
$fileName = trim($fileName, '_');
$serverSideDownload = (string) ($_GET['triggerDownload'] ?? '') === '1';
$logoSource = documentPdfLocalImageDataUri(dirname(__DIR__, 2) . '/assets/img/logo3.jpeg');
if ($serverSideDownload) {
    ob_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Transfer Ticket</title>
    <style>
        .page {
            width: 100%;
            min-height: 1000px; /* ~A4 height in pixels at 96 DPI */
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }
        .page:last-child {
            page-break-after: auto;
        }
        <?php if ($serverSideDownload) { ?>
        .page {
            min-height: 0;
        }
        <?php } ?>
    </style>
</head>
<body style="margin: 0;">
    <div id="transferTicketContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php
            $footers = ['STORES', 'PRODUCTION', 'QUALITY ASSURANCE', 'ACCOUNTS'];
            foreach ($footers as $index => $footerLabel):
        ?>
        <div class="page" style="page-break-after: <?= ($index < 3) ? 'always' : 'auto' ?>;">
            <div style="border: 2px solid #000; margin-bottom:20px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 30px; ">
                        <td style="width: 35%; border-right: 2px solid #000; border-bottom: 2px solid #000; padding-top:10px; padding-left:10px;">
                            <img src="<?php echo htmlspecialchars($logoSource); ?>" alt="Biogenix Logo" style="height: 50px;">
                        </td>
                        <td rowspan="2" style="width: 30%; border-right: 2px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">TITLE: TRANSFER <br/> TICKET</strong></td>
                        <td rowspan="2" style="width: 20%; border-right: 2px solid #000; text-align:center;"><strong>Document No.</strong></td>
                        <td rowspan="2" style="text-align:center;">BIPL-F-TT-01</td>
                    </tr>
                    <tr>
                        <td style="width: 35%; border-right: 2px solid #000;  padding-left:10px;">
                            B19/A S.I.L Ancillary Estate,<br>
                            Amausi Industrial Area,<br>
                            Nadarganj-226008 (Lucknow)
                        </td>
                    </tr>
                </table>
            </div>
            <div style="border: 2px solid #000; padding: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 0px;">
                    
                    <tr style="line-height: 30px;">
                        <td style="width: 29%;"><strong>Transfer Ticket No.</strong> :</td>
                        <td><?php echo htmlspecialchars($row['ticket_no'] ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 29%;"><strong>Finished Goods COA No.</strong> :</td>
                        <td><?php echo htmlspecialchars($row['fg_coa_no'] ?? ""); ?></td>
                    </tr>                
                    <tr style="line-height: 30px;">
                        <td style="width: 29%;"><strong>Code</strong> :</td>
                        <td style="width: 71%;">
                            <table style="width: 100%; border-collapse: collapse; border: none; margin: 0; padding: 0;">
                                <tr>
                                    <td style="padding: 0; border: none; text-align: left;"><?php echo htmlspecialchars($row['code'] ?? ""); ?></td>
                                    <td style="padding: 0; border: none; text-align: right; white-space: nowrap; width: 40%;"><strong>Date</strong> : <?php echo formatDateDMY(htmlspecialchars($row['date'] ?? "")); ?></td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                </table>
            </div>

            <div style="border-bottom: 2px solid #000; border-left: 2px solid #000; border-right: 2px solid #000; padding: 15px;">
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                    
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Product Description</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo htmlspecialchars($row['product_description'] ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Pack Size</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo htmlspecialchars($packSizeVal).' '.htmlspecialchars($packSizeUnit ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Product Code</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo htmlspecialchars($row['code'] ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Batch No.</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo htmlspecialchars($row['batch_no'] ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Mfg. Date</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo formatDateToMonthYear(htmlspecialchars($row['mfg_date'] ?? "")); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Exp. Date</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo formatDateToMonthYear(htmlspecialchars($row['exp_date'] ?? "")); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Sample Taken by QA</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo htmlspecialchars($sampledQaVal).' '.htmlspecialchars($sampledQaUnit ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="width: 25%;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Quantity Transferred</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;"><?php echo htmlspecialchars($quantityTransferredVal).' '.htmlspecialchars($quantityTransferredUnit ?? ""); ?></td>
                    </tr>
                    <tr style="line-height: 30px;">
                        <td style="vertical-align: top;">
                            <div style="display: flex; justify-content: space-between; width: 100%; font-weight: bold;"><span>Remarks</span><span>:</span></div>
                        </td>
                        <td style="width: 75%;">
                            <?php echo htmlspecialchars($row['remark'] ?? ""); ?>
                        </td>
                    </tr>
                </table>
                <table style="width: 100%; border-collapse: collapse; margin-top: 30px; text-align: center;">
                    <tr>
                        <td style="padding-top: 40px; font-weight:700;">_____________________<br>Sign (Production)</td>
                        <td style="padding-top: 40px; font-weight:700;">_____________________<br>Sign (Quality Assurance)</td>
                        <td style="padding-top: 40px; font-weight:700;">_____________________<br>Sign (Store)</td>
                    </tr>
                </table>
            </div>

            <div style="border-bottom: 2px solid #000; border-left: 2px solid #000; border-right: 2px solid #000; padding: 15px;">       
                <div style="margin-top: 30px; font-weight: bold;"><?php echo htmlspecialchars($footerLabel ?? ""); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
<?php
if ($serverSideDownload) {
    documentPdfStream((string) ob_get_clean(), $fileName ?: 'transfer_ticket_' . $id);
}
?>
