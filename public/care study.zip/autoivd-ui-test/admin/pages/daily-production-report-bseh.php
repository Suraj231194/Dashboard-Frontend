<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage daily production BSEH reports and product detail entries</p>
        </div>
    </div>
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="dprPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                            <li><a class="dpr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'daily_production_bseh_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="addDprModalBtn" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="sortable d-none px-6 py-3" data-column="auto_generated_batch">Auto Batch No</th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="date"><span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable d-none px-6 py-3" data-column="month_year">Month/Year</th>
                            <th class="sortable w-28 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="total_man_power"><span class="inline-flex items-center gap-1">TMP <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-28 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="total_working_hours"><span class="inline-flex items-center gap-1">TWH <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="department"><span class="inline-flex items-center gap-1">Department <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span></th>
                            <th class="w-40 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Created By</th>
                            <th
                                class="w-40 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="orderReceivedTableBody">
                    </tbody>
                </table>
            </div>
            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="addDprModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Daily Production Report
                            </h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create BSEH daily production report
                                entries</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addDprForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
                            <div>
                                <label for="dateDpr" class="mb-1 block text-sm font-medium text-slate-800">Date</label>
                                <input type="date" id="dateDpr" autocomplete="off" name="dateDpr" class="input-theme"
                                    required />
                            </div>
                            <div>
                                <label for="monthYearDpr"
                                    class="mb-1 block text-sm font-medium text-slate-800">Month/Year</label>
                                <input type="text" id="monthYearDpr" autocomplete="off" name="monthYearDpr"
                                    class="input-theme text-slate-500 focus:text-slate-900" placeholder="MM/YYYY"
                                    required />
                            </div>
                            <div>
                                <label for="totalManPower" class="mb-1 block text-sm font-medium text-slate-800">Total
                                    Man Power</label>
                                <input type="number" min="0" id="totalManPower" autocomplete="off" name="totalManPower"
                                    class="input-theme" placeholder="Enter Total Man Power" required />
                            </div>
                            <div>
                                <label for="workingHours" class="mb-1 block text-sm font-medium text-slate-800">Working
                                    Hours</label>
                                <input type="number" min="0" id="workingHours" autocomplete="off" name="workingHours"
                                    class="input-theme" placeholder="Enter Working Hours" required />
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
                            <div>
                                <label for="department"
                                    class="mb-1 block text-sm font-medium text-slate-800">Department</label>
                                <select name="department" id="department" class="input-theme select2" required>
                                    <?php
                                    echo '<option value="">----Select----</option>';
                                    foreach (Constant::DAILY_PROD_BSEH['DEPARTMENT'] as $deptkey => $deptlabel) {
                                        echo '<option value="' . $deptkey . '">' . $deptlabel['label'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Product Details</label>
                            <div id="productsList"></div>
                            <div class="mt-2">
                                <button type="button"
                                    class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addProductCategoryBtn"><i class="ti ti-plus text-lg"></i> Add Product
                                    Category</button>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label for="remark" class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                                <textarea id="remark" autocomplete="off" name="remark" class="input-theme min-h-[80px]"
                                    placeholder="Enter remark"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="viewBESHModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Order Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review daily production report details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="viewBESH">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editdailyProdBESHModal" index="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100"><i
                                class="ti ti-edit text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Order</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update daily production report details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editOrderReceivedForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>

<?php startSection('scripts'); ?>
<script>

    let currentPage = 1;
    let qtyUnitOptions = [];
    let particularsOptions = [];
    let productIndex = 0;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }
    function loadParticularsBSEH() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getParticularsListBSEH: 'getParticularsListBSEH'
            },
            success: function (response) {
                particularsOptions = response;
            },
            error: function (xhr, status, error) {
                console.error("Failed to load particulars list:", error);
            }
        });
    }

    function loadDailyProdBSEHTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadDailyProductionBSEH: 'loadDailyProductionBSEH',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#orderReceivedTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const shownThrough = totalRows ? Math.min(page * Number(perPage), totalRows) : 0;

            },
            error: function () {
                $('#orderReceivedTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');

            }
        });
    }

    $(document).ready(function () {
        initCustomMonthPicker('#monthYearDpr');
        loadDailyProdBSEHTable();
        loadStandardUnit();
        loadParticularsBSEH();
        $('#searchProducts').on('input', function () {
            loadDailyProdBSEHTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadDailyProdBSEHTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadDailyProdBSEHTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.dpr-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#dprPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#addDprModalBtn').on('click', function () {
            $('#addDprModal').modal('show');
            $('#department').select2({ dropdownParent: $('#addDprModal') });
            $('#addProductCategoryBtn').trigger('click');
        });

        $("#orderType").on('change', function () {
            let ddlOrderType = $(this).val();
            const checkConstantDdl = <?php echo Constant::ORDER_RECEIVED['ORDER_TYPE_OPTIONS_LABEL']['Other']; ?>;
            if (ddlOrderType == checkConstantDdl) {
                $("#productTypekWrapper").removeClass('d-none');
                $('#orderTypeDetails').attr('required', true);
            } else {
                $("#productTypekWrapper").addClass('d-none');
                $('#orderTypeDetails').removeAttr('required');
            }
        });


        // Add new product category block
        $('#addProductCategoryBtn').click(function () {
            let particularsOptionsHtml = '<option value="">---Select----</option>';
            particularsOptions.forEach(partis => {
                particularsOptionsHtml += `<option value="${partis.id}">${partis.name}</option>`;
            });

            const blockHtml = `
                <div class="product-category-block relative mb-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm ring-1 ring-slate-900/5" data-index="${productIndex}">
                    <button type="button" class="removeCategoryBlock absolute right-3 top-3 inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none" title="Remove Block">
                        <i class="ti ti-x text-base"></i>
                    </button>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                        <div>
                            <label class="mb-1 block text-sm font-medium text-slate-800">Particular</label>
                            <select name="productParticulars[]" class="input-theme select2 productParticulars" data-index="${productIndex}" required>
                                ${particularsOptionsHtml}
                            </select>
                        </div>
                    </div>

                    <div class="product-items" id="productItems_${productIndex}"></div>
                    <div class="flex justify-end">
                        <button type="button" class="addProductRowBtn inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" data-index="${productIndex}">
                            <i class="ti ti-plus text-base"></i> Add Product
                        </button>
                    </div>
                </div>`;
            const block = $(blockHtml);
            $('#productsList').append(block);
            block.find('.select2').select2({ dropdownParent: $('#addDprModal') });
            block.find('.addProductRowBtn').click();
            productIndex++;
        });


        // Remove entire block
        $('#productsList').on('click', '.removeCategoryBlock', function () {
            $(this).closest('.product-category-block').remove();
        });

        // Remove a row inside the block
        $('#productsList').on('click', '.removeRowBtn', function () {
            $(this).closest('.product-item-row').remove();
        });

        // On particular change: optionally auto-add one row
        $('#productsList').on('change', '.productParticulars', function () {
            let index = $(this).data('index');
            let container = $(`#productItems_${index}`);
            if (container.children().length === 0) {
                container.append(getProductRowHtml(index));
            }
        });

        // Add more product rows inside category
        $('#productsList').on('click', '.addProductRowBtn', function () {
            const index = $(this).data('index');
            const row = $(getProductRowHtml(index));
            $(`#productItems_${index}`).append(row);
            row.find('.select2').select2({ dropdownParent: $('#addDprModal') });
        });

        // Generate HTML for one row
        function getProductRowHtml(index) {
            let optionsHtml = '<option value="">---Select----</option>';
            qtyUnitOptions.forEach(unit => {
                optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });
            return `<div class="product-item-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-3 shadow-sm md:grid-cols-[minmax(220px,1.4fr)_minmax(130px,1fr)_minmax(130px,1fr)_minmax(130px,1fr)_minmax(130px,1fr)_40px]">
                <div>
                    <input type="text" name="productName[${index}][]" class="input-theme" placeholder="Product Name" required />
                </div>
                <div>
                    <input type="text" name="yieldDetails[${index}][]" class="input-theme" placeholder="Yield Details" />
                </div>
                <div>
                    <input type="number" step="0.01" name="totalYield[${index}][]" class="input-theme" placeholder="Total Yield" required />
                </div>
                <div>
                    <select name="totalYieldQtyUnit[${index}][]" class="input-theme select2" required>${optionsHtml}</select>
                </div>
                <div>
                    <input type="number" step="0.01" name="manPower[${index}][]" class="input-theme" placeholder="Man Power" required />
                </div>
                <div class="flex items-start justify-end md:justify-center">
                    <button type="button" class="removeRowBtn mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                        <i class="ti ti-trash text-base"></i>
                    </button>
                </div>
            </div>`;
        }

        $('#addDprModal').on('hidden.bs.modal', function () {
            $('#addDprForm')[0].reset();
            $('#productsList').empty();
            $('#department').val(null).trigger('change');
            productIndex = 0;
        });

        $('#addDprForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addDprForm');
            const formData = new FormData(form);
            formData.append('addDailyProductionBSEH', 'addDailyProductionBSEH'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#addDprModal').modal('hide');
                        $('#addDprForm')[0].reset();
                        loadDailyProdBSEHTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });
    });


    $(document).on('click', '.viewBESHModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewBESH').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    viewBeshRecord: 'viewBeshRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#viewBESHModel').modal('show');
                        $('#viewBESH').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.editdailyProdBESHModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editOrderReceivedForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchBESHRecord: 'fetchBESHRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#editdailyProdBESHModal').modal('show');
                        $('#editOrderReceivedForm').find('.modal-body').html(res.data);
                        $('#editOrderReceivedForm .select2').select2({ dropdownParent: $('#editdailyProdBESHModal') });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '.beshDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'mr-3 inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteBESHRecord: 'deleteBESHRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadDailyProdBSEHTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                            }
                        });
                    }
                });
            }
        });
    });

    const statusOptions = `
        <option value="">---Select----</option>
        <?php foreach (Constant::ORDER_RECEIVED['STATUS_TYPES'] as $skey => $sval): ?>
            <option value="<?= $skey ?>"><?= $sval['label'] ?></option>
        <?php endforeach; ?>
    `;

    $(document).on('click', '#addProductAtEditBtn', function () {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => {
            optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });

        const productRow = `
            <div class="product-row grid grid-cols-1 gap-3 mb-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-3 shadow-sm md:grid-cols-12" data-index="${productIndex}">
                <div class="md:col-span-6">
                    <label class="mb-1 block text-sm font-medium text-slate-800">Product Name</label>
                    <input type="hidden" name="productIdEdit[]" value="" />
                    <input type="text" name="productNameEdit[]" class="input-theme" placeholder="Product Name" required />
                </div>
                <div class="md:col-span-3">
                    <label class="mb-1 block text-sm font-medium text-slate-800">Quantity</label>
                    <input type="number" min="0" name="productQuantityEdit[]" class="input-theme" placeholder="Quantity" required />
                </div>
                <div class="md:col-span-3">
                    <label class="mb-1 block text-sm font-medium text-slate-800">Select Unit</label>
                    <select name="productUnitEdit[]" class="input-theme select2" required>${optionsHtml}</select>
                </div>
                <div class="md:col-span-3">
                    <label class="mb-1 block text-sm font-medium text-slate-800">Status</label>
                    <select name="productStatusEdit[]" class="input-theme select2" required>${statusOptions}</select>
                </div>
                <div class="md:col-span-8">
                    <label class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
                    <textarea name="productRemarkEdit[]" rows="1" class="input-theme min-h-[44px] w-full" placeholder="Enter Remark"></textarea>
                </div>
                <div class="flex items-end justify-end md:col-span-1">
                    <button type="button" class="deleteSubProductFromOrder inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none" data-id="">
                        <span class="ti ti-trash text-base"></span>
                    </button>
                </div>
            </div>`;
        const productRowElement = $(productRow);
        $('#productsListEdit').append(productRowElement);
        productRowElement.find('.select2').select2({ dropdownParent: $('#editdailyProdBESHModal') });
        productIndex++;
    });


    $('#editOrderReceivedForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editOrderReceivedForm');
        const formData = new FormData(form);
        formData.append('updateOrderReceivedRecord', 'updateOrderReceivedRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editdailyProdBESHModal').modal('hide');
                    $('#editOrderReceivedForm').find('modal-body').html();
                    loadDailyProdBSEHTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.deleteSubProductFromOrder', function () {
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid product ID provided.',
                customClass: {
                    container: 'swal2-zindex-fix-custom',
                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'mr-3 inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30',
                cancelButton: 'inline-flex items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteOrderReceivedSubProductRecord: 'deleteOrderReceivedSubProductRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-emerald-700 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30'
                                }
                            });
                            buttonClicked.closest('.product-row').remove();
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'inline-flex items-center justify-center !rounded-xl bg-rose-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        loadDailyProdBSEHTable(1);
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
    });



</script>
<?php endSection(); ?>
