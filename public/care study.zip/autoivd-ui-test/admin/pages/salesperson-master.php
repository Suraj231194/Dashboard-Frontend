<?php
global $conn;
$currentRoleId = (int) ($_SESSION['role_id'] ?? 0);
$canAddSp = roleHasPermission($currentRoleId, 'crm_salesperson_add');
$canEditSp = roleHasPermission($currentRoleId, 'crm_salesperson_edit');

// Preload users and employees for linking
$usersList = [];
$uQ = $conn->query("SELECT id, name, email FROM users WHERE is_active = 1 AND deleted_at IS NULL ORDER BY name ASC");
if ($uQ) {
    while ($u = $uQ->fetch_assoc()) {
        $usersList[] = $u;
    }
}

$employeesList = [];
$eQ = $conn->query("SELECT id, first_name, last_name, emp_code, email, contact_no FROM employees WHERE status = 1 AND deleted_at IS NULL ORDER BY first_name ASC");
if ($eQ) {
    while ($e = $eQ->fetch_assoc()) {
        $employeesList[] = $e;
    }
}

$productsList = [];
$pQ = $conn->query("SELECT id, product_name, product_code FROM products WHERE status = 1 AND deleted_at IS NULL ORDER BY product_name ASC");
if ($pQ) {
    while ($p = $pQ->fetch_assoc()) {
        $productsList[] = $p;
    }
}
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <!-- Page Header -->
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                Salesperson Master
            </h1>
            <p style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Configure sales representatives, territories, product expertise, and product responsibility for smart lead auto-assignment
            </p>
        </div>
    </div>

    <!-- Salesperson List Card -->
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:items-center">
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="spSearchInput" placeholder="Search salesperson..." 
                               class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" 
                               oninput="loadSalespersonList()">
                    </div>
                    <!-- Status Filter Dropdown -->
                    <div class="dropdown w-full shrink-0 md:w-auto">
                        <button class="inline-flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 md:w-44"
                                type="button" data-bs-toggle="dropdown" aria-expanded="false" id="spStatusDropdownBtn">
                            <span id="spStatusLabel" class="truncate">All Statuses</span>
                            <i class="ti ti-chevron-down text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end !rounded-xl border-slate-200 p-1 shadow-lg text-xs">
                            <li><a class="dropdown-item !rounded-lg py-1.5 font-medium cursor-pointer" onclick="applySpFilter('status', 'all', 'All Statuses')">All Statuses</a></li>
                            <li><a class="dropdown-item !rounded-lg py-1.5 font-medium cursor-pointer flex items-center gap-2" onclick="applySpFilter('status', 'active', 'Active Only')"><span class="w-2 h-2 rounded-full bg-emerald-500"></span> Active Only</a></li>
                            <li><a class="dropdown-item !rounded-lg py-1.5 font-medium cursor-pointer flex items-center gap-2" onclick="applySpFilter('status', 'inactive', 'Inactive Only')"><span class="w-2 h-2 rounded-full bg-slate-300"></span> Inactive Only</a></li>
                        </ul>
                    </div>

                    <!-- Reset Button -->
                    <button type="button" onclick="resetSpFilters()" 
                            class="inline-flex h-10 w-full items-center justify-center gap-1.5 !rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 shadow-sm transition-colors hover:bg-slate-50 shrink-0 cursor-pointer md:w-auto"
                            title="Reset Filters">
                        <i class="ti ti-rotate text-sm"></i> Reset
                    </button>
                    <?php if ($canAddSp): ?>
                        <button type="button" onclick="openSalespersonModal('add')" 
                                class="inline-flex h-10 w-full shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 hover:bg-emerald-800 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500/30 cursor-pointer md:w-auto">
                            <i class="ti ti-plus text-lg"></i> Add
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr class="text-nowrap">
                            <th class="px-6 py-3.5">Salesperson</th>
                            <th class="px-6 py-3.5">Contact</th>
                            <th class="px-6 py-3.5">Territories (Mapped)</th>
                            <th class="px-6 py-3.5">Product Expertise</th>
                            <th class="px-6 py-3.5">Product Responsibility</th>
                            <th class="px-6 py-3.5">Status</th>
                            <th class="px-6 py-3.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="salespersonTableBody" class="divide-y divide-slate-100">
                        <!-- Populated via AJAX -->
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-400">
                                <div class="spinner-border text-emerald-600" role="status"></div>
                                <p class="mt-2 text-xs">Loading salespersons...</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ========================================================================= -->
<!-- Modal: Add / Edit Salesperson Modal                                       -->
<!-- ========================================================================= -->
<div class="modal fade" id="salespersonModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <form id="salespersonForm" onsubmit="saveSalespersonForm(event)">
                <input type="hidden" id="spFormId" name="salesperson_id" value="">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                            <i class="ti ti-id-badge-2 text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title font-bold text-slate-800 text-base" id="spModalTitle">Add Salesperson</h5>
                            <p class="text-xs text-slate-500 mt-0.5">Define territories, expertise, and product responsibility for auto-assignment</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 transition hover:bg-rose-100" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <div class="modal-body px-6 py-5 max-h-[75vh] overflow-y-auto space-y-4">
                    <!-- Basic Information -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Salesperson Name <span class="text-rose-500">*</span></label>
                            <input type="text" id="spName" name="salesperson_name" required class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Salesperson Code</label>
                            <input type="text" id="spCode" name="salesperson_code" placeholder="e.g. SP-DEL-01" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Link ERP User Account</label>
                            <select id="spUserId" name="user_id" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm" onchange="fillFromUser(this)">
                                <option value="">-- None / External --</option>
                                <?php foreach ($usersList as $u): ?>
                                    <option value="<?= (int)$u['id'] ?>" data-email="<?= htmlspecialchars($u['email']) ?>"><?= htmlspecialchars($u['name']) ?> (<?= htmlspecialchars($u['email']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Link HR Employee</label>
                            <select id="spEmployeeId" name="employee_id" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm" onchange="fillFromEmployee(this)">
                                <option value="">-- None --</option>
                                <?php foreach ($employeesList as $e): ?>
                                    <option value="<?= (int)$e['id'] ?>" data-email="<?= htmlspecialchars($e['email'] ?? '') ?>" data-mobile="<?= htmlspecialchars($e['contact_no'] ?? '') ?>"><?= htmlspecialchars($e['first_name'] . ' ' . ($e['last_name'] ?? '')) ?> (<?= htmlspecialchars($e['emp_code'] ?? 'N/A') ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Email</label>
                            <input type="email" id="spEmail" name="email" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Mobile</label>
                            <input type="text" id="spMobile" name="mobile" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Sales Team / Region</label>
                            <input type="text" id="spTeam" name="sales_team" placeholder="e.g. North Zone Team A" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                        </div>
                        <div>
                            <label for="spAssignmentPriority" class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Assignment Priority</label>
                            <input type="number" id="spAssignmentPriority" name="assignment_priority" value="100" min="1" step="1" class="form-control !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                            <p class="mt-1 text-[11px] text-slate-400">Lower number wins when assignment scores are tied.</p>
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Status</label>
                            <select id="spStatus" name="status" class="form-select !rounded-xl border-slate-200 text-sm py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 shadow-sm">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <!-- Territory Mapping -->
                    <div class="border-t border-slate-100 pt-4">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Assigned Territories (Territories / Cities / States / Regions)</label>
                        <div id="territoryTagsContainer" class="flex flex-wrap items-center gap-2 mb-3 min-h-[48px] p-3 bg-slate-50 border border-slate-200 rounded-xl">
                            <!-- Dynamic territory tags rendered here -->
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
                            <div class="sm:col-span-4">
                                <select id="newTerritoryType" class="form-select !rounded-xl border-slate-200 text-xs font-bold text-slate-700 py-2.5 px-3 w-full bg-white">
                                    <option value="Territory">Territory</option>
                                    <option value="City">📍 City</option>
                                    <option value="State">🗺️ State</option>
                                    <option value="Region">🌐 Region</option>
                                </select>
                            </div>
                            <div class="sm:col-span-6">
                                <input type="text" id="newTerritoryName" placeholder="e.g. Mumbai, Maharashtra, West Zone..." 
                                       class="form-control !rounded-xl border-slate-200 text-xs py-2.5 px-3.5 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 w-full"
                                       onkeydown="if(event.key==='Enter'){event.preventDefault();addTerritoryTag();}">
                            </div>
                            <div class="sm:col-span-2">
                                <button type="button" onclick="addTerritoryTag()" 
                                        class="inline-flex h-10 w-full items-center justify-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white !rounded-xl text-xs font-bold transition shadow-sm ring-1 ring-emerald-900/10 cursor-pointer">
                                    <i class="ti ti-plus"></i> Add
                                </button>
                            </div>
                        </div>
                        <input type="hidden" id="territoriesJson" name="territories_json" value="[]">
                    </div>

                    <!-- Product Expertise -->
                    <div class="border-t border-slate-100 pt-4">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Product Domain Expertise</label>
                        <div class="max-h-48 overflow-y-auto p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                            <?php foreach ($productsList as $p): ?>
                                <label class="flex items-center gap-2.5 p-1.5 hover:bg-white rounded-lg cursor-pointer transition text-xs font-medium text-slate-700">
                                    <input type="checkbox" name="product_expertise[]" value="<?= (int)$p['id'] ?>" class="form-check-input !rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500/20">
                                    <span><?= htmlspecialchars($p['product_name']) ?> <span class="text-slate-400 font-mono text-[11px]">(<?= htmlspecialchars($p['product_code'] ?? '') ?>)</span></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Product Responsibility -->
                    <div class="border-t border-slate-100 pt-4">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Product Responsibility</label>
                        <p class="mb-2 text-[11px] font-medium text-slate-400">Select the products this salesperson is commercially responsible for.</p>
                        <div class="max-h-48 overflow-y-auto p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                            <?php foreach ($productsList as $p): ?>
                                <label class="flex items-center gap-2.5 p-1.5 hover:bg-white rounded-lg cursor-pointer transition text-xs font-medium text-slate-700">
                                    <input type="checkbox" name="product_responsibility[]" value="<?= (int)$p['id'] ?>" class="form-check-input !rounded-md border-slate-300 text-blue-600 focus:ring-blue-500/20">
                                    <span><?= htmlspecialchars($p['product_name']) ?> <span class="text-slate-400 font-mono text-[11px]">(<?= htmlspecialchars($p['product_code'] ?? '') ?>)</span></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-100 bg-slate-50/50 px-6 py-4 flex items-center justify-end gap-3">
                    <button type="button" class="inline-flex items-center justify-center px-4 py-2.5 border border-slate-200 bg-white text-slate-700 font-bold text-sm !rounded-xl hover:bg-slate-50 transition shadow-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" id="saveSpBtn" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm !rounded-xl transition shadow-sm ring-1 ring-emerald-900/10 cursor-pointer">
                        <i class="ti ti-check text-base"></i> Save Salesperson
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
const crmCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
const crmEscapeHtml = value => $('<div>').text(value == null ? '' : String(value)).html();
$.ajaxPrefilter(function (options) {
    if (String(options.type || 'GET').toUpperCase() !== 'POST' || !crmCsrfToken) return;
    if (options.data instanceof FormData) {
        if (!options.data.has('csrf_token')) options.data.append('csrf_token', crmCsrfToken);
    } else if (typeof options.data === 'string') {
        if (!/(^|&)csrf_token=/.test(options.data)) options.data += (options.data ? '&' : '') + 'csrf_token=' + encodeURIComponent(crmCsrfToken);
    } else {
        options.data = Object.assign({}, options.data || {}, { csrf_token: crmCsrfToken });
    }
});

let currentTerritories = [];
let currentSpFilter = { status: 'all', search: '' };

$(document).ready(function () {
    loadSalespersonList();
});

function applySpFilter(type, value, labelText) {
    if (type === 'status') {
        currentSpFilter.status = value;
        $('#spStatusLabel').text(labelText || 'Status');
    } else if (type === 'search') {
        currentSpFilter.search = value.trim();
    }
    loadSalespersonList();
}

function resetSpFilters() {
    $('#spSearchInput').val('');
    $('#spStatusLabel').text('All Statuses');
    currentSpFilter = { status: 'all', search: '' };
    loadSalespersonList();
}

function loadSalespersonList() {
    const search = $('#spSearchInput').val().trim();
    currentSpFilter.search = search;
    $('#salespersonTableBody').html('<tr><td colspan="7" class="py-12 text-center text-slate-400"><div class="spinner-border text-emerald-600" role="status"></div><p class="mt-2 text-xs">Loading salespersons...</p></td></tr>');

    $.post('ajax.php', { 
        action: 'crm_load_salespersons', 
        search: currentSpFilter.search,
        status: currentSpFilter.status 
    }, function (res) {
        if (res.status === 'success') {
            $('#salespersonTableBody').html(res.html || '<tr><td colspan="7" class="py-12 text-center text-slate-400"><i class="ti ti-mood-empty text-3xl mb-2 block text-slate-300"></i><p class="text-sm font-medium">No salespersons registered yet.</p></td></tr>');
        } else {
            $('#salespersonTableBody').html('<tr><td colspan="7" class="py-8 text-center text-red-500">' + (res.message || 'Error loading salespersons') + '</td></tr>');
        }
    }, 'json');
}

function openSalespersonModal(mode, spId = null) {
    $('#salespersonForm')[0].reset();
    $('#spFormId').val('');
    $('input[name="product_expertise[]"]').prop('checked', false);
    $('input[name="product_responsibility[]"]').prop('checked', false);
    $('#spAssignmentPriority').val(100);
    currentTerritories = [];
    renderTerritoryTags();

    if (mode === 'add') {
        $('#spModalTitle').text('Add Salesperson');
        const modal = new bootstrap.Modal(document.getElementById('salespersonModal'));
        modal.show();
    } else {
        $('#spModalTitle').text('Edit Salesperson');
        $.post('ajax.php', { action: 'crm_get_salesperson_detail', salesperson_id: spId }, function (res) {
            if (res.status === 'success') {
                const sp = res.salesperson;
                $('#spFormId').val(sp.id);
                $('#spName').val(sp.salesperson_name);
                $('#spCode').val(sp.salesperson_code);
                $('#spUserId').val(sp.user_id || '');
                $('#spEmployeeId').val(sp.employee_id || '');
                $('#spEmail').val(sp.email);
                $('#spMobile').val(sp.mobile);
                $('#spTeam').val(sp.sales_team);
                $('#spAssignmentPriority').val(sp.assignment_priority || 100);
                $('#spStatus').val(sp.status);
                if (res.product_ids) {
                    const selectedProducts = res.product_ids.map(String);
                    $('input[name="product_expertise[]"]').each(function () {
                        $(this).prop('checked', selectedProducts.includes(String(this.value)));
                    });
                }
                if (res.responsibility_product_ids) {
                    const responsibleProducts = res.responsibility_product_ids.map(String);
                    $('input[name="product_responsibility[]"]').each(function () {
                        $(this).prop('checked', responsibleProducts.includes(String(this.value)));
                    });
                }
                currentTerritories = res.territories || [];
                renderTerritoryTags();
                const modal = new bootstrap.Modal(document.getElementById('salespersonModal'));
                modal.show();
            } else {
                toastr.error(res.message || 'Failed to load details');
            }
        }, 'json');
    }
}

function addTerritoryTag() {
    const name = $('#newTerritoryName').val().trim();
    const type = $('#newTerritoryType').val();
    if (!name) return;

    // Avoid duplicate
    if (currentTerritories.some(t => t.name.toLowerCase() === name.toLowerCase() && t.type === type)) {
        toastr.warning('Territory already added');
        return;
    }

    currentTerritories.push({ name: name, type: type });
    $('#newTerritoryName').val('');
    renderTerritoryTags();
}

function removeTerritoryTag(index) {
    currentTerritories.splice(index, 1);
    renderTerritoryTags();
}

function renderTerritoryTags() {
    $('#territoriesJson').val(JSON.stringify(currentTerritories));
    if (currentTerritories.length === 0) {
        $('#territoryTagsContainer').html('<span class="text-xs text-slate-400 font-medium italic">No territories assigned yet. Select type, enter name, and click "+ Add".</span>');
        return;
    }
    let html = '';
    currentTerritories.forEach((t, i) => {
        const typeColor = t.type === 'City' ? 'bg-blue-50 text-blue-800 border-blue-200/80' : (t.type === 'State' ? 'bg-emerald-50 text-emerald-800 border-emerald-200/80' : (t.type === 'Territory' ? 'bg-violet-50 text-violet-800 border-violet-200/80' : 'bg-amber-50 text-amber-800 border-amber-200/80'));
        const icon = t.type === 'City' ? '📍' : (t.type === 'State' ? '🗺️' : '🌐');
        html += `<span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border shadow-xs transition-all ${typeColor}">
            <span class="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded-md bg-white/80 tracking-wide text-slate-700">${icon} ${crmEscapeHtml(t.type)}</span>
            <span class="font-bold">${crmEscapeHtml(t.name)}</span>
            <button type="button" class="ml-1 text-slate-400 hover:text-rose-600 cursor-pointer transition p-0.5" title="Remove" onclick="removeTerritoryTag(${i})">
                <i class="ti ti-x text-xs"></i>
            </button>
        </span>`;
    });
    $('#territoryTagsContainer').html(html);
}

function fillFromUser(sel) {
    const email = $(sel).find(':selected').data('email');
    if (email && !$('#spEmail').val()) {
        $('#spEmail').val(email);
    }
}

function fillFromEmployee(sel) {
    const email = $(sel).find(':selected').data('email');
    const mobile = $(sel).find(':selected').data('mobile');
    if (email && !$('#spEmail').val()) $('#spEmail').val(email);
    if (mobile && !$('#spMobile').val()) $('#spMobile').val(mobile);
}

function saveSalespersonForm(e) {
    e.preventDefault();
    const formData = $('#salespersonForm').serialize() + '&action=crm_save_salesperson';
    $('#saveSpBtn').prop('disabled', true).text('Saving...');

    $.post('ajax.php', formData, function (res) {
        $('#saveSpBtn').prop('disabled', false).text('Save Salesperson');
        if (res.status === 'success') {
            toastr.success(res.message || 'Salesperson saved');
            bootstrap.Modal.getInstance(document.getElementById('salespersonModal')).hide();
            loadSalespersonList();
        } else {
            toastr.error(res.message || 'Failed to save');
        }
    }, 'json');
}

function deleteSalesperson(spId) {
    if (!confirm('Are you sure you want to delete this salesperson?')) return;
    $.post('ajax.php', { action: 'crm_delete_salesperson', salesperson_id: spId }, function (res) {
        if (res.status === 'success') {
            toastr.success(res.message || 'Salesperson deleted');
            loadSalespersonList();
        } else {
            toastr.error(res.message || 'Failed to delete');
        }
    }, 'json');
}
</script>
<?php endSection(); ?>
