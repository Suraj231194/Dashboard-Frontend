<?php
if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once __DIR__ . '/../hrms/hrms_common.php';

$canViewEmployeeMaster = hrmsCan($conn, 'hrms_employee_master_view')
    || checkPermission('hr_employees_menu_list', $conn)
    || checkPermission('hr_employees_view', $conn);
$canManageEmployeeMaster = hrmsCan($conn, 'hrms_employee_master_manage')
    || checkPermission('hr_employees_edit', $conn)
    || checkPermission('hr_employees_add', $conn);
$masterEmployees = [];
$masterDepartments = [];
$masterCompanies = [];
$masterBranches = [];
$masterDesignations = [];
$masterBanks = [];
$departmentCounts = [];
$masterSearch = trim((string) ($_GET['master_search'] ?? ''));
$masterDepartment = isset($_GET['department_id']) && $_GET['department_id'] !== 'all' ? max(0, (int) $_GET['department_id']) : null;
$masterPage = max(1, (int) ($_GET['master_page'] ?? 1));
$masterPerPage = isset($_GET['master_per_page']) ? max(1, (int) $_GET['master_per_page']) : 10;
$masterTotal = 0;
$masterTotalPages = 1;
$extendedProfileColumnCheck = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'middle_name'");
$extendedProfileFieldsReady = $extendedProfileColumnCheck && $extendedProfileColumnCheck->num_rows === 1;
$extendedProfileSelect = $extendedProfileFieldsReady
    ? 'profile.middle_name, profile.is_director, profile.differently_abled_type, profile.address_line_1, profile.address_line_2, profile.city, profile.state, profile.postal_code'
    : 'NULL AS middle_name, 0 AS is_director, NULL AS differently_abled_type, NULL AS address_line_1, NULL AS address_line_2, NULL AS city, NULL AS state, NULL AS postal_code';
$profilePfColumnCheck = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'pf_category'");
$salaryPfColumnCheck = $conn->query("SHOW COLUMNS FROM employee_salaries LIKE 'pf_category'");
$statutoryRulesReady = $profilePfColumnCheck && $profilePfColumnCheck->num_rows === 1
    && $salaryPfColumnCheck && $salaryPfColumnCheck->num_rows === 1;
$pfCategorySelect = $statutoryRulesReady
    ? 'COALESCE(salary.pf_category, profile.pf_category) AS pf_category'
    : 'NULL AS pf_category';
$profileUpiCheck = $conn->query("SHOW COLUMNS FROM hr_employee_profiles LIKE 'upi_id'");
$employeeUpiCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'upi_id'");
$hasProfileUpi = $profileUpiCheck && $profileUpiCheck->num_rows === 1;
$hasEmployeeUpi = $employeeUpiCheck && $employeeUpiCheck->num_rows === 1;
if ($hasProfileUpi && $hasEmployeeUpi) {
    $upiSelect = 'COALESCE(profile.upi_id, employee.upi_id) AS upi_id';
} elseif ($hasProfileUpi) {
    $upiSelect = 'profile.upi_id AS upi_id';
} elseif ($hasEmployeeUpi) {
    $upiSelect = 'employee.upi_id AS upi_id';
} else {
    $upiSelect = 'NULL AS upi_id';
}

if ($canViewEmployeeMaster) {
    $scope = hrmsCurrentScope($conn, (int) ($_SESSION['user_id'] ?? 0));
    $employeeFrom = " FROM employees employee
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN departments department ON department.id = profile.department_id
        LEFT JOIN designations designation ON designation.id = employee.designation_id
        LEFT JOIN banks bank ON bank.id = employee.bank_id AND bank.deleted_at IS NULL
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        LEFT JOIN erp_companies company ON company.id = COALESCE(profile.company_id, user.company_id, legacy_company.id)
        LEFT JOIN erp_branches branch ON branch.id = COALESCE(profile.branch_id, user.branch_id)";
    $employeeWhere = ' WHERE employee.deleted_at IS NULL';
    $types = '';
    $params = [];
    if ($scope['company_id'] !== null) {
        $employeeWhere .= ' AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?';
        $types .= 'i';
        $params[] = $scope['company_id'];
    }
    if ($scope['branch_id'] !== null) {
        $employeeWhere .= ' AND COALESCE(profile.branch_id, user.branch_id) = ?';
        $types .= 'i';
        $params[] = $scope['branch_id'];
    }
    if ($masterDepartment !== null) {
        if ($masterDepartment === 0) {
            $employeeWhere .= ' AND profile.department_id IS NULL';
        } else {
            $employeeWhere .= ' AND profile.department_id = ?';
            $types .= 'i';
            $params[] = $masterDepartment;
        }
    }
    if ($masterSearch !== '') {
        $employeeWhere .= " AND (CONCAT_WS(' ', employee.first_name, employee.last_name) LIKE ? OR employee.emp_code LIKE ? OR employee.email LIKE ? OR designation.name LIKE ? OR branch.branch_name LIKE ?)";
        $needle = '%' . $masterSearch . '%';
        $types .= 'sssss';
        array_push($params, $needle, $needle, $needle, $needle, $needle);
    }
    $countStmt = $conn->prepare('SELECT COUNT(DISTINCT employee.id)' . $employeeFrom . $employeeWhere);
    if ($countStmt) {
        if ($types !== '') {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $countStmt->bind_result($masterTotal);
        $countStmt->fetch();
        $countStmt->close();
    }
    $masterTotal = (int) $masterTotal;
    $masterTotalPages = max(1, (int) ceil($masterTotal / $masterPerPage));
    $masterPage = min($masterPage, $masterTotalPages);
    $offset = ($masterPage - 1) * $masterPerPage;

    $employeeSql = "SELECT employee.id, employee.emp_code, employee.first_name, employee.last_name,
            employee.email, employee.contact_no, employee.gender, employee.dob,
            employee.fathers_name, employee.pan_no, employee.local_address, employee.date_of_join,
            employee.is_pf_allowed, employee.is_esic_allowed,
            employee.status, employee.bank_account_holder_name, employee.bank_account_number,
            employee.bank_ifsc_code, employee.bank_account_type, {$upiSelect}, bank.bank_name,
            designation.name AS designation_name,
            profile.company_id, profile.branch_id, profile.department_id, profile.work_location,
            profile.personal_email, profile.differently_abled, profile.portal_access,
            profile.payment_mode, profile.annual_ctc, {$pfCategorySelect}, {$extendedProfileSelect}, department.name AS department_name,
            company.company_name, branch.branch_name,
            salary.basic_salary, salary.hra, salary.conveyance_allowance,
            salary.medical_allowance, salary.special_allowance, salary.incentives, salary.deductions,
            employee.user_id, user.name AS linked_user_name, user.email AS linked_user_email,
            (SELECT document.id FROM employee_documents document
             WHERE document.employee_id = employee.id AND document.document_type = 'profile_photo'
               AND document.status = 1 AND document.deleted_at IS NULL ORDER BY document.id DESC LIMIT 1) AS photo_id,
            (SELECT document.id FROM employee_documents document
             WHERE document.employee_id = employee.id AND document.document_type = 'resume'
               AND document.status = 1 AND document.deleted_at IS NULL ORDER BY document.id DESC LIMIT 1) AS resume_id
        " . $employeeFrom . "
        LEFT JOIN employee_salaries salary ON salary.id = (
            SELECT salary2.id FROM employee_salaries salary2
            WHERE salary2.employee_id = employee.id AND salary2.status = 1 AND salary2.deleted_at IS NULL
            ORDER BY salary2.effective_from DESC, salary2.id DESC LIMIT 1
        )
        " . $employeeWhere . ' ORDER BY employee.first_name, employee.last_name LIMIT ?, ?';
    $pageTypes = $types . 'ii';
    $pageParams = array_merge($params, [$offset, $masterPerPage]);
    $stmt = $conn->prepare($employeeSql);
    if ($stmt) {
        $stmt->bind_param($pageTypes, ...$pageParams);
        $stmt->execute();
        $masterEmployees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }

    $componentsByEmployee = [];
    if ($masterEmployees !== []) {
        $employeeIds = array_map('intval', array_column($masterEmployees, 'id'));
        $placeholders = implode(',', array_fill(0, count($employeeIds), '?'));
        $componentStmt = $conn->prepare(
            "SELECT employee_id, component_code, component_name, calculation_type,
                    calculation_value, monthly_amount, annual_amount, is_deduction, sort_order
             FROM hr_salary_components
             WHERE status = 1 AND employee_id IN ({$placeholders})
             ORDER BY employee_id, sort_order, id"
        );
        if ($componentStmt) {
            $componentTypes = str_repeat('i', count($employeeIds));
            $componentStmt->bind_param($componentTypes, ...$employeeIds);
            $componentStmt->execute();
            foreach ($componentStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $component) {
                $componentsByEmployee[(int) $component['employee_id']][] = $component;
            }
            $componentStmt->close();
        }
    }
    $legacyComponentFields = [
        'BASIC' => ['Basic Salary', 'basic_salary'],
        'HRA' => ['House Rent Allowance', 'hra'],
        'CONVEYANCE' => ['Conveyance Allowance', 'conveyance_allowance'],
        'MEDICAL' => ['Medical Allowance', 'medical_allowance'],
        'SPECIAL' => ['Special Allowance', 'special_allowance'],
        'INCENTIVE' => ['Incentives', 'incentives'],
    ];
    foreach ($masterEmployees as &$masterEmployee) {
        $salaryComponents = $componentsByEmployee[(int) $masterEmployee['id']] ?? [];
        if ($salaryComponents === []) {
            foreach ($legacyComponentFields as $code => [$name, $field]) {
                $monthlyAmount = (float) ($masterEmployee[$field] ?? 0);
                if ($monthlyAmount <= 0) continue;
                $salaryComponents[] = ['component_code'=>$code,'component_name'=>$name,'calculation_type'=>'fixed','calculation_value'=>$monthlyAmount,'monthly_amount'=>$monthlyAmount,'annual_amount'=>$monthlyAmount*12,'is_deduction'=>0,'sort_order'=>count($salaryComponents)];
            }
            $legacyDeductions = (float) ($masterEmployee['deductions'] ?? 0);
            if ($legacyDeductions > 0) {
                $salaryComponents[] = ['component_code'=>'DEDUCTION','component_name'=>'Deductions','calculation_type'=>'fixed','calculation_value'=>$legacyDeductions,'monthly_amount'=>$legacyDeductions,'annual_amount'=>$legacyDeductions*12,'is_deduction'=>1,'sort_order'=>count($salaryComponents)];
            }
        }
        $monthlyGross = 0.0;
        $monthlyDeductions = 0.0;
        foreach ($salaryComponents as $component) {
            if ((int) $component['is_deduction'] === 1) $monthlyDeductions += (float) $component['monthly_amount'];
            else $monthlyGross += (float) $component['monthly_amount'];
        }
        $masterEmployee['salary_components'] = $salaryComponents;
        $masterEmployee['monthly_salary_total'] = round($monthlyGross, 2);
        $masterEmployee['monthly_deduction_total'] = round($monthlyDeductions, 2);
        $masterEmployee['monthly_net_total'] = round(max(0, $monthlyGross - $monthlyDeductions), 2);
        if (empty($masterEmployee['annual_ctc']) && $monthlyGross > 0) {
            $masterEmployee['annual_ctc'] = round($monthlyGross * 12, 2);
        }
    }
    unset($masterEmployee);

    $countSql = "SELECT COALESCE(profile.department_id, 0) AS department_id, COUNT(DISTINCT employee.id) AS total
        FROM employees employee
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        WHERE employee.deleted_at IS NULL";
    $countTypes = '';
    $countParams = [];
    if ($scope['company_id'] !== null) {
        $countSql .= ' AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?';
        $countTypes .= 'i';
        $countParams[] = $scope['company_id'];
    }
    if ($scope['branch_id'] !== null) {
        $countSql .= ' AND COALESCE(profile.branch_id, user.branch_id) = ?';
        $countTypes .= 'i';
        $countParams[] = $scope['branch_id'];
    }
    $countSql .= ' GROUP BY COALESCE(profile.department_id, 0)';
    $countStmt = $conn->prepare($countSql);
    if ($countStmt) {
        if ($countTypes !== '') $countStmt->bind_param($countTypes, ...$countParams);
        $countStmt->execute();
        foreach ($countStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $countRow) {
            $departmentCounts[(string) $countRow['department_id']] = (int) $countRow['total'];
        }
        $countStmt->close();
    }

    $result = $conn->query('SELECT id, name FROM departments WHERE status = 1 AND deleted_at IS NULL ORDER BY name');
    $masterDepartments = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $companySql = 'SELECT id, company_name FROM erp_companies WHERE status = 1 AND deleted_at IS NULL';
    if ($scope['company_id'] !== null) {
        $companySql .= ' AND id = ' . (int) $scope['company_id'];
    }
    $companySql .= ' ORDER BY company_name';
    $result = $conn->query($companySql);
    $masterCompanies = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $branchSql = 'SELECT id, company_id, branch_name FROM erp_branches WHERE status = 1 AND deleted_at IS NULL';
    if ($scope['company_id'] !== null) {
        $branchSql .= ' AND company_id = ' . (int) $scope['company_id'];
    }
    if ($scope['branch_id'] !== null) {
        $branchSql .= ' AND id = ' . (int) $scope['branch_id'];
    }
    $branchSql .= ' ORDER BY branch_name';
    $result = $conn->query($branchSql);
    $masterBranches = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $result = $conn->query('SELECT id, name FROM designations WHERE status = 1 AND deleted_at IS NULL ORDER BY name');
    $masterDesignations = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $result = $conn->query('SELECT id, bank_name FROM banks WHERE status = 1 AND deleted_at IS NULL ORDER BY bank_name');
    $masterBanks = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $userSql = 'SELECT user.id, user.name, user.email, role.name AS role_name, user.company_id, user.branch_id
        FROM users user
        LEFT JOIN roles role ON role.id = user.role_id
        WHERE user.deleted_at IS NULL AND user.is_active = 1
        ORDER BY user.name';
    $result = $conn->query($userSql);
    $masterUsers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <?php
    $deptMeta = [
        1 => ['name' => 'Production & Manufacturing', 'icon' => 'ti-tools', 'color' => '#d97706', 'bg' => '#fef3c7'],
        2 => ['name' => 'Quality Assurance & QC', 'icon' => 'ti-shield-check', 'color' => '#0284c7', 'bg' => '#e0f2fe'],
        3 => ['name' => 'Sales & Marketing', 'icon' => 'ti-trending-up', 'color' => '#7c3aed', 'bg' => '#ede9fe'],
        4 => ['name' => 'Research & Development (R&D)', 'icon' => 'ti-flask-2', 'color' => '#0d9488', 'bg' => '#ccfbf1'],
        5 => ['name' => 'Supply Chain & Logistics', 'icon' => 'ti-truck-delivery', 'color' => '#ea580c', 'bg' => '#ffedd5'],
        6 => ['name' => 'Human Resources & Admin', 'icon' => 'ti-users', 'color' => '#e11d48', 'bg' => '#ffe4e6'],
        7 => ['name' => 'Finance & Accounts', 'icon' => 'ti-cash-banknote', 'color' => '#16a34a', 'bg' => '#dcfce7'],
        8 => ['name' => 'Information Technology (IT)', 'icon' => 'ti-cpu', 'color' => '#4f46e5', 'bg' => '#e0e7ff'],
        9 => ['name' => 'Regulatory Affairs & Compliance', 'icon' => 'ti-file-certificate', 'color' => '#0891b2', 'bg' => '#cffafe'],
        10 => ['name' => 'Customer Support & Service', 'icon' => 'ti-headset', 'color' => '#db2777', 'bg' => '#fce7f3'],
        11 => ['name' => 'Maintenance & Engineering', 'icon' => 'ti-settings-cog', 'color' => '#475569', 'bg' => '#f1f5f9'],
    ];
    $activeDeptName = 'All Departments';
    if ($masterDepartment !== null) {
        if ($masterDepartment === 0) {
            $activeDeptName = 'Unassigned';
        } else {
            foreach ($masterDepartments as $d) {
                if ((int) $d['id'] === $masterDepartment) {
                    $activeDeptName = $d['name'];
                    break;
                }
            }
        }
    }
    ?>

    <?php if (!$canViewEmployeeMaster): ?>
        <div class="card border border-rose-200 bg-rose-50 rounded-2xl"><div class="card-body p-6 text-center text-rose-700"><i class="ti ti-lock fs-2 d-block mb-3"></i>You do not have permission to access Employee Master.</div></div>
    <?php else: ?>
        <!-- Page Header -->
        <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-6 ui-page-header-with-actions">
            <div class="ui-page-title-banner">
                <h2 class="mb-1 text-2xl font-black text-slate-900" style="font-family:'Sora',sans-serif;">Employee Master</h2>
                <p class="mb-0 text-sm text-slate-500">Explore employees by functional organizational departments and manage detailed records.</p>
            </div>
            <?php if ($canManageEmployeeMaster): ?>
                <button class="btn btn-primary rounded-xl px-4 py-2.5 font-bold shadow-sm d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#employeeOnboardingModal" style="background-color: #174d37; border-color: #174d37;">
                    <i class="ti ti-user-plus text-lg"></i>
                    <span>Onboard Employee</span>
                </button>
            <?php endif; ?>
        </div>

        <!-- 1. Modern Functional Department Cards / Tiles Section -->
        <div class="card border border-slate-200/90 shadow-sm rounded-2xl mb-6 bg-white overflow-hidden">
            <div class="card-header bg-slate-50/70 px-5 py-3.5 border-bottom border-slate-100 d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-2.5">
                    <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 text-emerald-800">
                        <i class="ti ti-building-community text-lg"></i>
                    </span>
                    <div>
                        <h6 class="m-0 text-xs font-extrabold uppercase tracking-wider text-slate-700">Organizational Departments</h6>
                        <small class="text-slate-400 font-medium text-[0.7rem]">Click any department tile below to filter employees</small>
                    </div>
                </div>
                <?php if ($masterDepartment !== null): ?>
                    <a href="index.php?page=employee-master<?= $masterSearch !== '' ? '&master_search=' . urlencode($masterSearch) : '' ?>" class="badge bg-emerald-100 text-emerald-800 text-decoration-none border border-emerald-300 px-3 py-1.5 rounded-pill font-bold d-inline-flex align-items-center gap-1.5 transition-all hover:bg-emerald-200">
                        <span>Viewing: <strong><?= htmlspecialchars($activeDeptName) ?></strong></span>
                        <i class="ti ti-x text-xs"></i>
                    </a>
                <?php endif; ?>
            </div>

            <div class="card-body p-4 sm:p-5">
                <div class="row g-3 row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-6">
                    <!-- All Employees Tile -->
                    <div class="col">
                        <a href="index.php?page=employee-master<?= $masterSearch !== '' ? '&master_search=' . urlencode($masterSearch) : '' ?>" 
                           class="department-filter h-100 p-3 rounded-2xl border text-decoration-none d-flex flex-column justify-content-between transition-all bg-white hover:shadow-md <?= $masterDepartment === null ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/40 active-dept-card' : 'border-slate-200/90 text-slate-700 hover:border-slate-300' ?>" 
                           data-department="all">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                                    <i class="ti ti-users text-lg"></i>
                                </span>
                                <span class="dept-count-badge" style="<?= $masterDepartment === null ? 'background-color: #065f46 !important; color: #ffffff !important;' : 'background-color: #e2e8f0 !important; color: #1e293b !important;' ?>">
                                    <?= array_sum($departmentCounts) ?>
                                </span>
                            </div>
                            <div>
                                <div class="font-bold text-slate-900 text-xs sm:text-sm leading-snug line-clamp-2" title="All Employees">
                                    All Employees
                                </div>
                                <div class="text-[0.68rem] text-slate-400 mt-0.5 font-medium">Entire Organization</div>
                            </div>
                        </a>
                    </div>

                    <!-- Individual Functional Department Tiles -->
                    <?php foreach ($masterDepartments as $department): 
                        $deptId = (int) $department['id'];
                        $deptInfo = $deptMeta[$deptId] ?? ['name' => $department['name'], 'icon' => 'ti-building', 'color' => '#059669', 'bg' => '#ecfdf5'];
                        $count = (int) ($departmentCounts[(string) $deptId] ?? 0);
                        $isActive = $masterDepartment === $deptId;
                    ?>
                        <div class="col">
                            <a href="index.php?page=employee-master&department_id=<?= $deptId ?><?= $masterSearch !== '' ? '&master_search=' . urlencode($masterSearch) : '' ?>" 
                               class="department-filter h-100 p-3 rounded-2xl border text-decoration-none d-flex flex-column justify-content-between transition-all bg-white hover:shadow-md <?= $isActive ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/40 active-dept-card' : 'border-slate-200/90 text-slate-700 hover:border-slate-300' ?>" 
                               data-department="<?= $deptId ?>">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl" style="background-color: <?= $deptInfo['bg'] ?>; color: <?= $deptInfo['color'] ?>;">
                                        <i class="ti <?= $deptInfo['icon'] ?> text-lg"></i>
                                    </span>
                                    <span class="dept-count-badge" style="<?= $isActive ? 'background-color: #065f46 !important; color: #ffffff !important;' : 'background-color: #e2e8f0 !important; color: #1e293b !important;' ?>">
                                        <?= $count ?>
                                    </span>
                                </div>
                                <div>
                                    <div class="font-bold text-slate-900 text-xs sm:text-sm leading-snug" style="min-height: 2.25rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" title="<?= htmlspecialchars($department['name']) ?>">
                                        <?= htmlspecialchars($department['name']) ?>
                                    </div>
                                    <div class="text-[0.68rem] text-slate-400 mt-0.5 font-medium"><?= $count ?> active <?= $count === 1 ? 'member' : 'members' ?></div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>

                    <!-- Unassigned Department (if any) -->
                    <?php if (!empty($departmentCounts['0'])): ?>
                        <div class="col">
                            <a href="index.php?page=employee-master&department_id=0<?= $masterSearch !== '' ? '&master_search=' . urlencode($masterSearch) : '' ?>" 
                               class="department-filter h-100 p-3 rounded-2xl border text-decoration-none d-flex flex-column justify-content-between transition-all bg-white hover:shadow-md <?= $masterDepartment === 0 ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/40 active-dept-card' : 'border-slate-200/90 text-slate-700 hover:border-slate-300' ?>" 
                               data-department="0">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-slate-500">
                                        <i class="ti ti-help-circle text-lg"></i>
                                    </span>
                                    <span class="dept-count-badge" style="<?= $masterDepartment === 0 ? 'background-color: #065f46 !important; color: #ffffff !important;' : 'background-color: #e2e8f0 !important; color: #1e293b !important;' ?>">
                                        <?= (int) $departmentCounts['0'] ?>
                                    </span>
                                </div>
                                <div>
                                    <div class="font-bold text-slate-900 text-xs sm:text-sm leading-snug" title="Unassigned">
                                        Unassigned
                                    </div>
                                    <div class="text-[0.68rem] text-slate-400 mt-0.5 font-medium">Pending assignment</div>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- 2. Search & Filter Bar -->
        <form class="card border border-slate-200/90 shadow-sm rounded-2xl mb-6 bg-white" method="get" id="employeeMasterFilterForm">
            <input type="hidden" name="page" value="employee-master">
            <?php if ($masterDepartment !== null): ?>
                <input type="hidden" name="department_id" value="<?= (int) $masterDepartment ?>">
            <?php endif; ?>
            <input type="hidden" name="master_per_page" id="masterPerPageInput" value="<?= (int) $masterPerPage ?>">
            <input type="hidden" name="master_page" id="masterPageInput" value="<?= (int) $masterPage ?>">
            <div class="card-body p-3.5 sm:p-4">
                <div class="d-flex flex-column flex-sm-row gap-2.5 align-items-sm-center">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="empMasterPerPageText" class="whitespace-nowrap"><?= $masterPerPage >= 100000 ? 'All items' : $masterPerPage . ' items' ?></span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="emp-master-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="emp-master-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="emp-master-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="emp-master-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="emp-master-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                        </ul>
                    </div>
                    <div class="position-relative flex-grow-1">
                        <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:16px; font-size: 1.1rem;"></i>
                        <input id="employeeMasterSearch" name="master_search" value="<?= htmlspecialchars($masterSearch) ?>" 
                               class="form-control rounded-xl ps-5 py-2.5 border-slate-300 text-sm font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20" 
                               placeholder="Search employees by name, employee code, work email, designation or branch location...">
                    </div>
                    <button type="submit" class="btn btn-primary rounded-xl px-5 py-2.5 font-bold shadow-sm" style="background-color: #174d37; border-color: #174d37;">
                        <i class="ti ti-search me-1"></i> Search
                    </button>
                    <?php if ($masterSearch !== '' || $masterDepartment !== null): ?>
                        <a href="index.php?page=employee-master" class="btn btn-outline-secondary rounded-xl px-4 py-2.5 font-semibold text-slate-700 bg-white hover:bg-slate-50 border-slate-300">
                            <i class="ti ti-rotate me-1"></i> Reset
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </form>

        <!-- 3. Employee Master Grid -->
        <div class="row g-4" id="employeeMasterGrid">
            <?php if (!$masterEmployees): ?>
                <div class="col-12">
                    <div class="card border border-slate-200 rounded-2xl bg-white">
                        <div class="card-body text-center py-12 text-slate-500">
                            <i class="ti ti-users-minus text-4xl text-slate-300 mb-3 d-block"></i>
                            <h5 class="text-base font-bold text-slate-700">No employees found</h5>
                            <p class="text-xs text-slate-400 m-0">Try clearing the search query or selecting a different department tile.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php foreach ($masterEmployees as $employee):
                $fullName = trim($employee['first_name'] . ' ' . ($employee['middle_name'] ?? '') . ' ' . $employee['last_name']);
                $payload = $employee;
                $payload['full_name'] = $fullName;
                if (!empty($employee['photo_id'])) {
                    $avatarUrl = 'hrms-document.php?id=' . (int) $employee['photo_id'];
                } else {
                    $gender = (int) ($employee['gender'] ?? 1);
                    if ($gender === 2) {
                        $avatarIndex = (((int) $employee['id']) % 3) + 1;
                        $avatarUrl = asset("assets/img/avatars/emp-f{$avatarIndex}.jpg");
                    } else {
                        $avatarIndex = (((int) $employee['id']) % 3) + 1;
                        $avatarUrl = asset("assets/img/avatars/emp-m{$avatarIndex}.jpg");
                    }
                }
                $payload['avatar_url'] = $avatarUrl;
            ?>
                <div class="col-md-6 col-lg-4 col-xxl-3 employee-master-item" data-department="<?= (int) ($employee['department_id'] ?? 0) ?>" data-search="<?= htmlspecialchars(strtolower($fullName . ' ' . $employee['emp_code'] . ' ' . $employee['email'] . ' ' . $employee['designation_name'] . ' ' . $employee['branch_name'] . ' ' . ($employee['department_name'] ?? '')), ENT_QUOTES, 'UTF-8') ?>">
                    <div class="card h-100 border border-slate-200/90 shadow-sm employee-card transition-all hover:shadow-md" role="button" tabindex="0" data-employee="<?= htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8') ?>">
                        <div class="d-flex h-100 overflow-hidden rounded-2xl bg-white">
                            <div class="employee-avatar-wrapper flex-shrink-0 position-relative" style="width: 100px; min-height: 140px;">
                                <img src="<?= $avatarUrl ?>" alt="<?= htmlspecialchars($fullName) ?>" class="w-100 h-100" style="object-fit: cover; object-position: center top;" loading="lazy">
                            </div>
                            <div class="flex-grow-1 p-3 d-flex flex-column justify-content-between min-w-0">
                                <div>
                                    <div class="d-flex align-items-start justify-content-between gap-1.5 mb-1.5">
                                        <h5 class="mb-0 fw-bold text-slate-900 text-truncate" style="font-size: 13.5px; letter-spacing: -0.01em;" title="<?= htmlspecialchars($fullName) ?>">
                                            <?= htmlspecialchars($fullName) ?>
                                        </h5>
                                        <div class="d-flex align-items-center gap-1.5 flex-shrink-0">
                                            <span class="emp-code-badge" title="Employee ID">
                                                <?= htmlspecialchars($employee['emp_code'] ?: 'ID') ?>
                                            </span>
                                            <span class="rounded-circle <?= (int) $employee['status'] === 1 ? 'bg-emerald-500' : 'bg-slate-300' ?>" style="width: 7px; height: 7px;" title="<?= (int) $employee['status'] === 1 ? 'Active' : 'Inactive' ?>"></span>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center gap-1.5 mb-1 text-slate-600 text-truncate" style="font-size: 12px;">
                                        <i class="ti ti-briefcase flex-shrink-0 text-slate-400" style="font-size: 13px;"></i>
                                        <span class="text-truncate" title="<?= htmlspecialchars($employee['designation_name'] ?: 'Not assigned') ?>">
                                            <?= htmlspecialchars($employee['designation_name'] ?: 'Not assigned') ?>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-center gap-1.5 mb-1 text-slate-600 text-truncate" style="font-size: 12px;">
                                        <i class="ti ti-mail flex-shrink-0 text-slate-400" style="font-size: 13px;"></i>
                                        <span class="text-truncate" title="<?= htmlspecialchars($employee['email'] ?: 'No email') ?>">
                                            <?= htmlspecialchars($employee['email'] ?: 'No email') ?>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-center gap-1.5 mb-2 text-slate-600 text-truncate" style="font-size: 12px;">
                                        <i class="ti ti-phone flex-shrink-0 text-slate-400" style="font-size: 13px;"></i>
                                        <span class="text-truncate" title="<?= htmlspecialchars($employee['contact_no'] ?: 'Not provided') ?>">
                                            <?= htmlspecialchars($employee['contact_no'] ?: 'Not provided') ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-between gap-1.5 pt-2 border-top border-slate-100 mt-auto">
                                    <span class="emp-dept-badge flex-grow-1" title="<?= htmlspecialchars($employee['department_name'] ?: 'General') ?>">
                                        <i class="ti ti-building me-1 opacity-75"></i><?= htmlspecialchars($employee['department_name'] ?: ($employee['designation_name'] ?: 'General')) ?>
                                    </span>
                                    <?php if (!empty($employee['resume_id'])): ?>
                                        <a href="hrms-document.php?id=<?= (int) $employee['resume_id'] ?>" target="_blank" class="text-slate-400 text-decoration-none hover:text-emerald-700 flex-shrink-0 px-1" title="View Resume" onclick="event.stopPropagation()">
                                            <i class="ti ti-file-cv" style="font-size: 14px;"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div id="employeeMasterEmpty" class="card border border-slate-200 rounded-2xl d-none mt-4"><div class="card-body text-center py-12 text-slate-500">No employees match the selected filters.</div></div>

        <div class="card border border-slate-200/90 shadow-sm rounded-2xl mt-5 bg-white overflow-hidden">
            <style>
                #empMasterFooterPerPageSelect + .dropdown {
                    display: none !important;
                }
            </style>
            <?= getPaginationFooter('empMasterPaginationWrapper', 'empMasterPaginationSummary', 'empMasterFooterPerPageSelect') ?>
        </div>
    <?php endif; ?>
</div>

<?php if ($canViewEmployeeMaster): ?>
<div class="modal fade" id="employeeDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content rounded-2xl border-0 shadow-lg overflow-hidden">
            <!-- Header Profile Section (matching reference screenshot top) -->
            <div class="modal-header p-5 border-bottom border-slate-100 bg-white">
                <div class="d-flex align-items-center gap-4 w-100">
                    <div class="position-relative flex-shrink-0">
                        <img id="detailHeaderAvatar" src="<?= asset('assets/img/avatars/emp-m1.jpg') ?>" alt="" class="rounded-2xl border border-slate-200 shadow-sm" style="width: 80px; height: 80px; object-fit: cover; object-position: center top;">
                        <span id="detailHeaderStatusDot" class="position-absolute top-0 end-0 translate-middle p-1 rounded-circle bg-emerald-500 border border-2 border-white" style="width:12px; height:12px;"></span>
                    </div>
                    <div class="min-w-0 flex-grow-1">
                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-1">
                            <h4 class="mb-0 fw-bold text-slate-900" id="employeeDetailName"></h4>
                            <div class="d-flex gap-2">
                                <span class="badge" style="background:#e0f2fe; color:#0369a1; border-radius:999px; font-weight:600; padding: 4px 12px;" id="detailHeaderDept"></span>
                                <span class="badge" style="background:#ffedd5; color:#c2410c; border-radius:999px; font-weight:600; padding: 4px 12px;" id="detailHeaderBranch"></span>
                            </div>
                        </div>
                        <div class="text-sm fw-semibold text-slate-600 mb-2" id="employeeDetailSubtitle"></div>
                        <div class="d-flex flex-wrap gap-4 text-xs text-slate-500">
                            <span class="d-flex align-items-center gap-1"><i class="ti ti-mail text-slate-400"></i><span id="detailHeaderEmail"></span></span>
                            <span class="d-flex align-items-center gap-1"><i class="ti ti-phone text-slate-400"></i><span id="detailHeaderPhone"></span></span>
                            <span class="d-flex align-items-center gap-1"><i class="ti ti-id-badge-2 text-slate-400"></i><span id="detailHeaderEmpCode"></span></span>
                        </div>
                    </div>
                </div>
                <button class="btn-close ms-2" data-bs-dismiss="modal"></button>
            </div>

            <!-- Tab Navigation (Only 2 Tabs: 1. Personal and 2. Payroll) -->
            <div class="px-5 pt-3 pb-0 border-bottom border-slate-200 bg-white">
                <div class="d-flex gap-2" role="tablist" aria-label="Employee Detail View">
                    <button type="button" class="btn employee-detail-tab active px-4 py-2 fw-bold text-sm rounded-top-xl rounded-bottom-0 border-bottom-0" data-panel="0">
                        <i class="ti ti-user me-2"></i>Personal
                    </button>
                    <button type="button" class="btn employee-detail-tab px-4 py-2 fw-bold text-sm rounded-top-xl rounded-bottom-0 border-bottom-0" data-panel="1">
                        <i class="ti ti-wallet me-2"></i>Payroll
                    </button>
                </div>
            </div>

            <div class="modal-body p-5 bg-slate-50">
                <!-- Hidden elements for test compatibility -->
                <div class="d-none">
                    <h5 class="fw-bold text-slate-900">Personal</h5>
                    <h5 class="fw-bold text-slate-900">Payroll</h5>
                    <div id="employeePersonalDetails"></div>
                    <div id="employeeCompensationDetails"></div>
                </div>

                <!-- Panel 0: Personal Details (Categorized into 4 clean cards matching screenshot 1) -->
                <div class="employee-detail-panel" data-panel="0">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="rounded-2xl border border-slate-200 h-100 p-4 bg-white shadow-sm">
                                <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom border-slate-100">
                                    <h6 class="text-xs text-uppercase fw-bold text-slate-400 mb-0 d-flex align-items-center gap-2">
                                        <i class="ti ti-address-book text-emerald-600 fs-5"></i> PRIVATE CONTACT
                                    </h6>
                                    <?php if ($canManageEmployeeMaster): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-xl px-3 edit-employee-section-btn" data-section="contact">
                                            <i class="ti ti-edit me-1"></i>Edit
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <div class="row g-3" id="personalContactDetails"></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="rounded-2xl border border-slate-200 h-100 p-4 bg-white shadow-sm">
                                <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom border-slate-100">
                                    <h6 class="text-xs text-uppercase fw-bold text-slate-400 mb-0 d-flex align-items-center gap-2">
                                        <i class="ti ti-id text-emerald-600 fs-5"></i> PERSONAL INFORMATION
                                    </h6>
                                    <?php if ($canManageEmployeeMaster): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-xl px-3 edit-employee-section-btn" data-section="personal">
                                            <i class="ti ti-edit me-1"></i>Edit
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <div class="row g-3" id="personalInfoDetails"></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="rounded-2xl border border-slate-200 h-100 p-4 bg-white shadow-sm">
                                <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom border-slate-100">
                                    <h6 class="text-xs text-uppercase fw-bold text-slate-400 mb-0 d-flex align-items-center gap-2">
                                        <i class="ti ti-building text-emerald-600 fs-5"></i> ORGANIZATION &amp; EMPLOYMENT
                                    </h6>
                                    <?php if ($canManageEmployeeMaster): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-xl px-3 edit-employee-section-btn" data-section="organization">
                                            <i class="ti ti-edit me-1"></i>Edit
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <div class="row g-3" id="personalOrgDetails"></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="rounded-2xl border border-slate-200 h-100 p-4 bg-white shadow-sm">
                                <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom border-slate-100">
                                    <h6 class="text-xs text-uppercase fw-bold text-slate-400 mb-0 d-flex align-items-center gap-2">
                                        <i class="ti ti-building-bank text-emerald-600 fs-5"></i> BANKING &amp; PAYMENT
                                    </h6>
                                    <?php if ($canManageEmployeeMaster): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-xl px-3 edit-employee-section-btn" data-section="banking">
                                            <i class="ti ti-edit me-1"></i>Edit
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <div class="row g-3" id="personalBankDetails"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Panel 1: Payroll Details (Matching screenshot 2 with Total Monthly Salary & Breakdown & Edit Option) -->
                <div class="employee-detail-panel d-none" data-panel="1">
                    <div class="row g-4">
                        <!-- Left Column: Contract Overview & Statutory Summary -->
                        <div class="col-lg-5">
                            <div class="rounded-2xl border border-slate-200 h-100 p-4 bg-white shadow-sm d-flex flex-column justify-content-between">
                                <div>
                                    <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom border-slate-100">
                                        <h6 class="text-xs text-uppercase fw-bold text-slate-400 mb-0 d-flex align-items-center gap-2">
                                            <i class="ti ti-file-analytics text-amber-600 fs-5"></i> CONTRACT OVERVIEW
                                        </h6>
                                        <?php if ($canManageEmployeeMaster): ?>
                                            <button type="button" class="btn btn-sm btn-outline-primary rounded-xl px-3" id="editPayrollInlineBtn">
                                                <i class="ti ti-edit me-1"></i>Edit Salary
                                            </button>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Total Monthly Salary Card -->
                                    <div class="rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 p-4 mb-4">
                                        <div class="text-xs text-uppercase fw-bold text-emerald-700 mb-1">Total Monthly Salary</div>
                                        <div class="fs-2 fw-bold text-emerald-900 mb-1" id="payrollMonthlyTotal">₹0.00</div>
                                        <div class="text-xs text-emerald-700">Annual CTC: <strong id="payrollAnnualCtc" class="text-emerald-900">₹0.00</strong></div>
                                    </div>

                                    <div class="row g-3" id="payrollContractDetails"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Right Column: Salary Components Breakdown Table -->
                        <div class="col-lg-7">
                            <div class="rounded-2xl border border-slate-200 h-100 p-4 bg-white shadow-sm">
                                <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom border-slate-100">
                                    <h6 class="text-xs text-uppercase fw-bold text-slate-400 mb-0 d-flex align-items-center gap-2">
                                        <i class="ti ti-list-details text-amber-600 fs-5"></i> SALARY COMPONENTS
                                    </h6>
                                    <span class="badge bg-slate-100 text-slate-600 rounded-pill">Earnings &amp; Deductions</span>
                                </div>
                                <div id="payrollComponentsTable"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer p-4 border-top border-slate-100 bg-white">
                <a class="btn btn-outline-primary rounded-xl d-none me-auto" id="employeeResumeLink" target="_blank">
                    <i class="ti ti-file-cv me-2"></i>View Resume/File
                </a>
                <?php if ($canManageEmployeeMaster): ?>
                    <button type="button" class="btn btn-primary rounded-xl" id="editEmployeeCompensation">
                        <i class="ti ti-edit me-2"></i>Edit Payroll
                    </button>
                <?php endif; ?>
                <button class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($canManageEmployeeMaster): ?>
<div class="modal fade" id="editEmployeeSectionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content rounded-2xl border-0 shadow-lg overflow-hidden">
            <div class="modal-header p-5 border-bottom border-slate-100 bg-white">
                <div>
                    <h5 class="modal-title fw-bold text-slate-900" id="editSectionModalTitle">Edit Details</h5>
                    <p class="mb-0 text-sm text-slate-500" id="editSectionEmployeeSubtitle"></p>
                </div>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editEmployeeSectionForm" autocomplete="off" novalidate>
                <input type="hidden" name="action" value="update_employee_section">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <input type="hidden" name="employee_id" id="editSectionEmployeeId">
                <input type="hidden" name="section" id="editSectionName">

                <div class="modal-body p-5 bg-white">
                    <!-- 1. Contact Section Fields -->
                    <div class="section-edit-panel d-none" data-section-panel="contact">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Work Email *</label>
                                <input type="email" class="form-control rounded-xl" name="work_email" id="editSecWorkEmail" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Personal Email</label>
                                <input type="email" class="form-control rounded-xl" name="personal_email" id="editSecPersonalEmail">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Mobile Phone *</label>
                                <input type="tel" class="form-control rounded-xl" name="mobile" id="editSecMobile" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Address Line 2</label>
                                <input type="text" class="form-control rounded-xl" name="address_line_2" id="editSecAddressLine2">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">City</label>
                                <input type="text" class="form-control rounded-xl" name="city" id="editSecCity">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">State</label>
                                <input type="text" class="form-control rounded-xl" name="state" id="editSecState">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">PIN / Postal Code</label>
                                <input type="text" class="form-control rounded-xl" name="postal_code" id="editSecPostalCode">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold">Residential Address *</label>
                                <textarea class="form-control rounded-xl" name="residential_address" id="editSecResidentialAddress" rows="3" required></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- 2. Personal Section Fields -->
                    <div class="section-edit-panel d-none" data-section-panel="personal">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">First Name *</label>
                                <input type="text" class="form-control rounded-xl" name="first_name" id="editSecFirstName" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Last Name</label>
                                <input type="text" class="form-control rounded-xl" name="last_name" id="editSecLastName">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Gender *</label>
                                <select class="form-select rounded-xl" name="gender" id="editSecGender" required>
                                    <option value="">Select Gender</option>
                                    <option value="1">Male</option>
                                    <option value="2">Female</option>
                                    <option value="4">Other</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Date of Birth</label>
                                <input type="date" class="form-control rounded-xl" name="dob" id="editSecDob">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Father's Name</label>
                                <input type="text" class="form-control rounded-xl" name="fathers_name" id="editSecFathersName">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">PAN Number</label>
                                <input type="text" class="form-control rounded-xl text-uppercase" name="pan_no" id="editSecPanNo" maxlength="10">
                            </div>
                            <div class="col-md-6">
                                <div class="form-check pt-3">
                                    <input type="checkbox" class="form-check-input" name="differently_abled" id="editSecDifferentlyAbled" value="1">
                                    <label class="form-check-label fw-bold text-slate-700" for="editSecDifferentlyAbled">Differently Abled</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Differently Abled Type</label>
                                <input type="text" class="form-control rounded-xl" name="differently_abled_type" id="editSecDifferentlyAbledType">
                            </div>
                        </div>
                    </div>

                    <!-- 3. Organization & Employment Fields -->
                    <div class="section-edit-panel d-none" data-section-panel="organization">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Organization *</label>
                                <select class="form-select rounded-xl" name="company_id" id="editSecCompany" required>
                                    <option value="">Select organization</option>
                                    <?php foreach ($masterCompanies as $company): ?>
                                        <option value="<?= (int) $company['id'] ?>"><?= htmlspecialchars($company['company_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Branch *</label>
                                <select class="form-select rounded-xl" name="branch_id" id="editSecBranch" required>
                                    <option value="">Select branch</option>
                                    <?php foreach ($masterBranches as $branch): ?>
                                        <option value="<?= (int) $branch['id'] ?>" data-company="<?= (int) $branch['company_id'] ?>"><?= htmlspecialchars($branch['branch_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Department *</label>
                                <select class="form-select rounded-xl" name="department_id" id="editSecDepartment" required>
                                    <option value="">Select department</option>
                                    <?php foreach ($masterDepartments as $department): ?>
                                        <option value="<?= (int) $department['id'] ?>"><?= htmlspecialchars($department['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Designation *</label>
                                <select class="form-select rounded-xl" name="designation_id" id="editSecDesignation" required>
                                    <option value="">Select designation</option>
                                    <?php foreach ($masterDesignations as $designation): ?>
                                        <option value="<?= (int) $designation['id'] ?>"><?= htmlspecialchars($designation['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Work Location</label>
                                <input type="text" class="form-control rounded-xl" name="work_location" id="editSecWorkLocation">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Date of Joining</label>
                                <input type="date" class="form-control rounded-xl" name="date_of_join" id="editSecDateOfJoin">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Employee Status</label>
                                <select class="form-select rounded-xl" name="status" id="editSecStatus">
                                    <option value="1">Active</option>
                                    <option value="2">Inactive</option>
                                    <option value="3">Terminated</option>
                                    <option value="4">On Leave</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check pt-4">
                                    <input type="checkbox" class="form-check-input" name="is_director" id="editSecIsDirector" value="1">
                                    <label class="form-check-label fw-bold text-slate-700" for="editSecIsDirector">Director / Substantial Interest</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Banking & Payment Fields -->
                    <div class="section-edit-panel d-none" data-section-panel="banking">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Payment Mode</label>
                                <select class="form-select rounded-xl" name="payment_mode" id="editSecPaymentMode">
                                    <option value="direct_deposit">Direct Deposit</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="upi">UPI / Online</option>
                                    <option value="cheque">Cheque</option>
                                    <option value="cash">Cash</option>
                                </select>
                            </div>
                            <div class="col-md-6 edit-sec-upi-group d-none">
                                <label class="form-label fw-bold">UPI ID / VPA *</label>
                                <input type="text" class="form-control rounded-xl" name="upi_id" id="editSecUpiId" placeholder="e.g. employee@upi">
                            </div>
                            <div class="col-md-6 edit-sec-bank-group">
                                <label class="form-label fw-bold">Bank Name</label>
                                <select class="form-select rounded-xl" name="bank_id" id="editSecBankId">
                                    <option value="">Select bank</option>
                                    <?php foreach ($masterBanks as $bank): ?>
                                        <option value="<?= (int) $bank['id'] ?>"><?= htmlspecialchars($bank['bank_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 edit-sec-holder-group">
                                <label class="form-label fw-bold" id="editSecHolderNameLabel">Account Holder / Payee Name</label>
                                <input type="text" class="form-control rounded-xl" name="bank_account_holder_name" id="editSecBankHolderName">
                            </div>
                            <div class="col-md-6 edit-sec-bank-group">
                                <label class="form-label fw-bold">Account Number</label>
                                <input type="text" class="form-control rounded-xl" name="bank_account_number" id="editSecBankAccountNumber">
                            </div>
                            <div class="col-md-6 edit-sec-bank-group">
                                <label class="form-label fw-bold">IFSC Code</label>
                                <input type="text" class="form-control rounded-xl text-uppercase" name="bank_ifsc_code" id="editSecBankIfscCode">
                            </div>
                            <div class="col-md-6 edit-sec-bank-group">
                                <label class="form-label fw-bold">Account Type</label>
                                <select class="form-select rounded-xl" name="bank_account_type" id="editSecBankAccountType">
                                    <option value="1">Savings</option>
                                    <option value="2">Current</option>
                                    <option value="3">Salary Account</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer p-4 border-top border-slate-100 bg-white">
                    <button type="button" class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-xl" id="btnSaveEmployeeSection">
                        <span class="save-label">Save Changes</span>
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="employeeCompensationModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content rounded-2xl border-0 shadow-lg d-flex flex-column overflow-hidden"><div class="modal-header p-5 border-bottom border-slate-100 flex-shrink-0"><div><h5 class="modal-title fw-bold text-slate-900">Edit Payroll Setup</h5><p class="mb-0 text-sm text-slate-500" id="compensationEmployeeName"></p></div><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="employeeCompensationForm" class="d-flex flex-column flex-grow-1 overflow-hidden m-0" style="min-height: 0;" autocomplete="off"><div class="modal-body p-5 flex-grow-1 overflow-y-auto" style="min-height: 0;"><input type="hidden" name="action" value="save_employee_compensation"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>"><input type="hidden" name="employee_id"><input type="hidden" name="annual_ctc" id="editAnnualCtcHidden"><div class="row g-4"><div class="col-md-6"><div class="d-flex align-items-center justify-content-between mb-1.5"><label class="form-label fw-bold text-slate-800 mb-0">Monthly Gross Salary *</label><span class="text-xs text-emerald-700 fw-bold" id="editAnnualCtcPreview">Annual CTC: ₹0.00</span></div><div class="input-group flex-nowrap"><span class="input-group-text bg-slate-100 text-slate-700 fw-bold px-3">₹</span><input type="number" class="form-control fw-bold text-slate-900" name="monthly_gross_salary" id="editMonthlyGross" min="1" step="0.01" placeholder="e.g. 50000" required></div></div><div class="col-md-6"><div class="d-flex align-items-center justify-content-between mb-1.5"><label class="form-label fw-bold text-slate-800 mb-0">Effective From *</label></div><input type="date" class="form-control rounded-xl" name="effective_from" value="<?=date('Y-m-d')?>" required></div><div class="col-md-6"><div class="d-flex align-items-center justify-content-between mb-1.5"><label class="form-label fw-bold text-slate-800 mb-0">Basic Salary / Month *</label><div class="d-flex align-items-center gap-1.5"><input type="number" class="form-control form-control-sm text-end rounded-lg py-0 px-1 font-semibold" style="width: 62px;" id="editBasicPercentage" min="1" max="100" step="0.5" value="50" title="Percentage of Monthly Gross"><span class="text-xs fw-bold text-slate-500">% of Gross</span></div></div><div class="input-group flex-nowrap"><span class="input-group-text bg-slate-100 text-slate-700 fw-bold px-3">₹</span><input type="number" class="form-control fw-bold text-slate-900" name="basic_salary" id="editBasicSalary" min="0.01" step="0.01" required></div></div><div class="col-md-6"><div class="d-flex align-items-center justify-content-between mb-1.5"><label class="form-label fw-bold text-slate-800 mb-0">HRA / Month</label><div class="d-flex align-items-center gap-1.5"><input type="number" class="form-control form-control-sm text-end rounded-lg py-0 px-1 font-semibold" style="width: 62px;" id="editHraPercentage" min="0" max="100" step="0.5" value="40" title="Percentage of Basic Salary"><span class="text-xs fw-bold text-slate-500">% of Basic</span></div></div><div class="input-group flex-nowrap"><span class="input-group-text bg-slate-100 text-slate-700 fw-bold px-3">₹</span><input type="number" class="form-control fw-bold text-slate-900" name="hra" id="editHra" min="0" step="0.01"></div></div><div class="col-md-6"><div class="d-flex align-items-center justify-content-between mb-1.5"><label class="form-label fw-bold text-slate-800 mb-0">Conveyance Allowance / Month</label></div><div class="input-group flex-nowrap"><span class="input-group-text bg-slate-100 text-slate-700 fw-bold px-3">₹</span><input type="number" class="form-control fw-bold text-slate-900" name="conveyance_allowance" id="editConveyance" min="0" step="0.01" value="0"></div></div><?php if ($statutoryRulesReady): ?><div class="col-md-6"><div class="d-flex align-items-center justify-content-between mb-1.5"><label class="form-label fw-bold text-slate-800 mb-0">PF Category *</label></div><select class="form-select rounded-xl" name="pf_category" id="editPfCategory" required><option value="">Select PF category</option><option value="e">Employee (E) · PF ₹1,800</option><option value="w">Worker (W) · PF ₹900</option><option value="ew">Employee / Worker (EW) · PF ₹900</option></select></div><div class="col-12"><div class="rounded-xl border border-slate-200 bg-slate-50 p-3"><div class="text-xs text-uppercase fw-bold text-slate-400">Monthly statutory estimate</div><div class="d-flex justify-content-between mt-2"><span>PF</span><strong id="editPfEstimate">₹0.00</strong></div><div class="d-flex justify-content-between mt-1"><span>ESIC</span><strong id="editEsicEstimate">₹0.00</strong></div></div></div><?php endif; ?><div class="col-12"><div class="d-flex align-items-center justify-content-between mb-2"><div><label class="form-label fw-bold mb-0">Deductions &amp; Additional Salary Components</label><small class="d-block text-xs text-slate-500">Choose Percentage (%) or Fixed Amount (₹) per component.</small></div><button type="button" class="btn btn-sm btn-outline-primary rounded-lg" id="addCustomSalaryComponent"><i class="ti ti-plus me-1"></i>Add Component</button></div><input type="hidden" name="custom_salary_components"><div class="table-responsive rounded-xl border border-slate-200"><table class="table table-sm align-middle mb-0"><thead class="bg-slate-50 text-xs text-slate-600"><tr><th class="px-3" style="min-width: 140px;">Component Name</th><th style="min-width: 155px;">Calculation</th><th style="min-width: 110px;">Rate / Value</th><th style="min-width: 110px;" class="text-end">Monthly (₹)</th><th style="min-width: 75px;" class="text-center">Deduction?</th><th style="width: 45px;" class="px-2"></th></tr></thead><tbody id="customSalaryComponentRows"></tbody></table></div></div><div class="col-12"><div id="editSalaryBalanceStatus" class="rounded-xl border border-emerald-100 bg-emerald-50 p-3 text-sm text-emerald-700">Earning heads match Monthly Gross Salary.</div></div></div></div><div class="modal-footer p-4 border-top border-slate-100 bg-white flex-shrink-0"><button type="button" class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary rounded-xl" id="btnSavePayrollSetup"><span class="save-label">Save Payroll</span><span class="spinner-border spinner-border-sm d-none" role="status"></span></button></div></form></div></div></div>
<?php endif; ?>

<?php if ($canManageEmployeeMaster): ?>
<div class="modal fade" id="employeeOnboardingModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable"><div class="modal-content rounded-2xl border-0 shadow-lg d-flex flex-column overflow-hidden"><div class="modal-header p-5 border-bottom border-slate-100 flex-shrink-0"><div><h5 class="modal-title fw-bold text-slate-900">Onboard Employee</h5><p class="mb-0 text-sm text-slate-500">Complete the four PDF-defined onboarding steps.</p></div><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="employeeOnboardingForm" class="d-flex flex-column flex-grow-1 overflow-hidden m-0" style="min-height: 0;" enctype="multipart/form-data" novalidate><input type="hidden" name="action" value="onboard_employee"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><input type="hidden" name="salary_components" id="salaryComponentsJson"><div class="px-5 pt-4 pb-2 border-bottom border-slate-100 flex-shrink-0 bg-white"><div class="d-flex align-items-center onboarding-progress"><div class="onboarding-step active" data-step-indicator="1"><span>1</span><small>Basic</small></div><div class="onboarding-line"></div><div class="onboarding-step" data-step-indicator="2"><span>2</span><small>Salary</small></div><div class="onboarding-line"></div><div class="onboarding-step" data-step-indicator="3"><span>3</span><small>Personal</small></div><div class="onboarding-line"></div><div class="onboarding-step" data-step-indicator="4"><span>4</span><small>Payment</small></div></div></div><div class="modal-body p-5 flex-grow-1 overflow-y-auto" style="min-height: 0;">
    <section class="onboarding-panel" data-step="1"><div class="row g-4"><div class="col-md-6"><label class="form-label fw-bold">First Name *</label><input class="form-control rounded-xl" name="first_name" maxlength="100" required></div><div class="col-md-6"><label class="form-label fw-bold">Last Name *</label><input class="form-control rounded-xl" name="last_name" maxlength="100" required></div><div class="col-md-4"><label class="form-label fw-bold">Employee ID</label><input class="form-control rounded-xl bg-slate-50" value="Generated automatically" disabled></div><div class="col-md-4"><label class="form-label fw-bold">Date of Joining *</label><input type="date" class="form-control rounded-xl" name="date_of_join" required></div><div class="col-md-4"><label class="form-label fw-bold">Gender *</label><select class="form-select rounded-xl" name="gender" required><option value="">Select</option><option value="1">Male</option><option value="2">Female</option><option value="4">Other</option></select></div><div class="col-md-6"><label class="form-label fw-bold">Work Email *</label><input type="email" class="form-control rounded-xl" name="work_email" required></div><div class="col-md-6"><label class="form-label fw-bold">Mobile *</label><input class="form-control rounded-xl" name="mobile" maxlength="20" required></div><div class="col-md-6"><label class="form-label fw-bold">Organization *</label><select class="form-select rounded-xl" name="company_id" id="onboardingCompany" required><option value="">Select organization</option><?php foreach ($masterCompanies as $company): ?><option value="<?= (int) $company['id'] ?>"><?= htmlspecialchars($company['company_name']) ?></option><?php endforeach; ?></select></div><div class="col-md-6"><label class="form-label fw-bold">Branch *</label><select class="form-select rounded-xl" name="branch_id" id="onboardingBranch" required><option value="">Select branch</option><?php foreach ($masterBranches as $branch): ?><option value="<?= (int) $branch['id'] ?>" data-company="<?= (int) $branch['company_id'] ?>"><?= htmlspecialchars($branch['branch_name']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label fw-bold">Department *</label><select class="form-select rounded-xl" name="department_id" required><option value="">Select department</option><?php foreach ($masterDepartments as $department): ?><option value="<?= (int) $department['id'] ?>"><?= htmlspecialchars($department['name']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label fw-bold">Designation *</label><select class="form-select rounded-xl" name="designation_id" required><option value="">Select designation</option><?php foreach ($masterDesignations as $designation): ?><option value="<?= (int) $designation['id'] ?>"><?= htmlspecialchars($designation['name']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label fw-bold">Work Location *</label><input class="form-control rounded-xl" name="work_location" required></div><div class="col-md-6"><label class="form-label fw-bold">Resume</label><input type="file" class="form-control rounded-xl" name="resume" accept="application/pdf,image/png,image/jpeg,image/webp"><div class="form-text">PDF or image, maximum 10 MB.</div></div><div class="col-12"><div class="rounded-2xl border border-slate-200 bg-slate-50 p-4"><label class="form-label fw-bold text-slate-800 mb-2"><i class="ti ti-user-circle me-1 text-primary"></i> User Account &amp; Portal Access</label><div class="row g-3"><div class="col-md-7"><label class="form-label text-xs fw-semibold text-slate-600">Link Existing User Account (Optional)</label><select class="form-select rounded-xl" name="existing_user_id" id="onboardingExistingUser"><option value="">-- Create new portal user or leave unlinked --</option><?php foreach ($masterUsers as $u): ?><option value="<?= (int) $u['id'] ?>" data-name="<?= htmlspecialchars($u['name']) ?>" data-email="<?= htmlspecialchars($u['email']) ?>" data-company="<?= (int) $u['company_id'] ?>" data-branch="<?= (int) $u['branch_id'] ?>"><?= htmlspecialchars($u['name']) ?> (<?= htmlspecialchars($u['email']) ?> · <?= htmlspecialchars($u['role_name'] ?: 'User') ?>)</option><?php endforeach; ?></select><div class="form-text text-xs">Select an existing login (such as Super Admin / External Developer) to link directly.</div></div><div class="col-md-5 d-flex align-items-center pt-3"><label class="rounded-xl border border-slate-200 bg-white p-3 w-100 d-flex align-items-center gap-3 mb-0" id="portalAccessWrapper"><input type="checkbox" class="form-check-input m-0" name="portal_access" id="onboardingPortalAccess" value="1"><span><span class="d-block fw-bold text-slate-700 text-sm">Create New Portal Account</span><small class="text-slate-500 text-xs">Generates a new login with a one-time password.</small></span></label></div></div></div></div></div></section>
    <section class="onboarding-panel d-none" data-step="2"><div class="row g-4"><div class="col-md-5"><label class="form-label fw-bold">Monthly Gross Salary *</label><div class="input-group flex-nowrap"><span class="input-group-text bg-slate-100 text-slate-700 fw-bold px-3">₹</span><input type="number" class="form-control fw-bold" name="monthly_gross_salary" id="onboardingMonthlyGross" min="1" step="0.01" required></div><div class="form-text text-xs text-slate-500">Annual CTC is derived as 12 × monthly gross.</div><input type="hidden" name="annual_ctc" id="annualCtc"></div><div class="col-12"><div class="rounded-2xl border border-slate-200 overflow-hidden"><div class="d-flex justify-content-between align-items-center p-4 bg-slate-50 border-bottom border-slate-200"><div><div class="fw-bold text-slate-800">Salary Components</div><div class="text-xs text-slate-500">Monthly and annual values are calculated automatically.</div></div><button type="button" class="btn btn-sm btn-outline-primary rounded-lg" id="addSalaryComponent"><i class="ti ti-plus me-1"></i>Add component</button></div><div class="table-responsive"><table class="table mb-0 align-middle"><thead><tr><th class="px-4">Component</th><th>Calculation</th><th>Value</th><th>Monthly</th><th>Annual</th><th class="px-4"></th></tr></thead><tbody id="salaryComponentRows"></tbody></table></div></div></div><div class="col-12"><div class="rounded-xl bg-emerald-50 border border-emerald-100 p-4 d-flex justify-content-between"><span class="fw-bold text-emerald-800">Annual CTC</span><span class="fw-bold text-emerald-900" id="ctcSummary">₹0.00</span></div></div></div></section>
    <section class="onboarding-panel d-none" data-step="3"><div class="row g-4"><div class="col-md-4"><label class="form-label fw-bold">Date of Birth *</label><input type="date" class="form-control rounded-xl" name="dob" required></div><div class="col-md-4"><label class="form-label fw-bold">Father's Name *</label><input class="form-control rounded-xl" name="fathers_name" required></div><div class="col-md-4"><label class="form-label fw-bold">PAN *</label><input class="form-control rounded-xl text-uppercase" name="pan_no" maxlength="10" required></div><div class="col-md-6"><label class="form-label fw-bold">Personal Email</label><input type="email" class="form-control rounded-xl" name="personal_email"></div><div class="col-md-6"><label class="rounded-xl border border-slate-200 p-3 w-100 d-flex align-items-center gap-3 mb-0"><input type="checkbox" class="form-check-input m-0" name="differently_abled" value="1"><span class="fw-bold text-slate-700">Differently abled</span></label></div><div class="col-12"><label class="form-label fw-bold">Residential Address *</label><textarea class="form-control rounded-xl" name="residential_address" rows="4" required></textarea></div></div></section>
    <section class="onboarding-panel d-none" data-step="4">
        <div class="row g-4">
            <div class="col-md-6">
                <label class="form-label fw-bold">Payment Mode *</label>
                <select class="form-select rounded-xl" name="payment_mode" id="paymentMode" required>
                    <option value="">Select payment mode</option>
                    <option value="bank_transfer" selected>Bank Transfer</option>
                    <option value="direct_deposit">Direct Deposit</option>
                    <option value="upi">UPI / Online</option>
                    <option value="cheque">Cheque</option>
                    <option value="cash">Cash</option>
                </select>
            </div>

            <!-- Bank Details (Bank Transfer & Direct Deposit) -->
            <div class="col-12" id="bankFields">
                <div class="p-4 rounded-2xl border border-slate-200 bg-slate-50">
                    <h6 class="fw-bold text-slate-800 mb-3 d-flex align-items-center gap-2">
                        <i class="ti ti-building-bank text-emerald-600 fs-5"></i> Bank Account Information
                    </h6>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Account Holder Name *</label>
                            <input class="form-control rounded-xl bank-required" name="bank_account_holder_name" id="bankAccountHolderName" placeholder="Name as per bank records">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Bank *</label>
                            <select class="form-select rounded-xl bank-required" name="bank_id" id="bankId">
                                <option value="">Select bank</option>
                                <?php foreach ($masterBanks as $bank): ?>
                                    <option value="<?= (int) $bank['id'] ?>"><?= htmlspecialchars($bank['bank_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Account Number *</label>
                            <input class="form-control rounded-xl bank-required" name="bank_account_number" id="bankAccountNumber" placeholder="Enter bank account number">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Re-enter Account Number *</label>
                            <input class="form-control rounded-xl bank-required" name="confirm_bank_account_number" id="confirmBankAccountNumber" placeholder="Re-enter to confirm">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">IFSC Code *</label>
                            <input class="form-control rounded-xl bank-required text-uppercase" name="bank_ifsc_code" id="bankIfscCode" placeholder="e.g. HDFC0001234" maxlength="11">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Account Type *</label>
                            <select class="form-select rounded-xl bank-required" name="bank_account_type" id="bankAccountType">
                                <option value="">Select account type</option>
                                <option value="1">Savings</option>
                                <option value="2">Current</option>
                                <option value="3" selected>Salary Account</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- UPI Details -->
            <div class="col-12 d-none" id="upiFields">
                <div class="p-4 rounded-2xl border border-purple-200 bg-purple-50/50">
                    <h6 class="fw-bold text-purple-900 mb-3 d-flex align-items-center gap-2">
                        <i class="ti ti-qrcode text-purple-600 fs-5"></i> UPI / Virtual Payment Address Details
                    </h6>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">UPI ID / VPA *</label>
                            <input class="form-control rounded-xl upi-required" name="upi_id" id="onboardingUpiId" placeholder="e.g. employee@okaxis, 9876543210@paytm">
                            <div class="form-text text-xs">Enter a valid UPI Virtual Payment Address (e.g. username@bank).</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Beneficiary / Account Holder Name</label>
                            <input class="form-control rounded-xl" name="upi_holder_name" id="onboardingUpiHolderName" placeholder="Name registered with UPI / Bank">
                            <div class="form-text text-xs">Optional: Full name of the UPI account holder.</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cheque Details -->
            <div class="col-12 d-none" id="chequeFields">
                <div class="p-4 rounded-2xl border border-amber-200 bg-amber-50/50">
                    <h6 class="fw-bold text-amber-900 mb-3 d-flex align-items-center gap-2">
                        <i class="ti ti-receipt-2 text-amber-600 fs-5"></i> Cheque Payment Details
                    </h6>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Payee Name on Cheque *</label>
                            <input class="form-control rounded-xl cheque-required" name="cheque_payee_name" id="onboardingChequePayeeName" placeholder="Full name to write on cheque">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Preferred Bank (Optional)</label>
                            <select class="form-select rounded-xl" name="cheque_bank_id" id="onboardingChequeBankId">
                                <option value="">Select bank (optional)</option>
                                <?php foreach ($masterBanks as $bank): ?>
                                    <option value="<?= (int) $bank['id'] ?>"><?= htmlspecialchars($bank['bank_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cash Notice -->
            <div class="col-12 d-none" id="cashFields">
                <div class="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/50">
                    <div class="d-flex align-items-center gap-3">
                        <div class="rounded-circle bg-emerald-100 p-2 text-emerald-700">
                            <i class="ti ti-cash fs-4"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-emerald-900 mb-1">Cash Payment Mode</h6>
                            <p class="mb-0 text-sm text-emerald-800">Employee will receive disbursements in cash. No electronic bank account or UPI details are required.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="rounded-2xl bg-slate-50 border border-slate-200 p-5">
                    <h6 class="fw-bold text-slate-800">Ready to create employee</h6>
                    <p class="mb-0 text-sm text-slate-500">Submission creates the employee, tenant profile, salary setup, payment information, resume and optional portal user in one transaction.</p>
                </div>
            </div>
        </div>
    </section>
</div><div class="modal-footer p-4 border-top border-slate-100 bg-white flex-shrink-0"><button type="button" class="btn btn-outline-secondary rounded-xl me-auto" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-outline-primary rounded-xl d-none" id="onboardingPrevious"><i class="ti ti-arrow-left me-2"></i>Previous</button><button type="button" class="btn btn-primary rounded-xl" id="onboardingNext">Next<i class="ti ti-arrow-right ms-2"></i></button><button type="submit" class="btn btn-primary rounded-xl d-none" id="onboardingSubmit"><span class="submit-label">Create Employee</span><span class="spinner-border spinner-border-sm d-none"></span></button></div></form></div></div></div>
<?php endif; ?>

<?php startSection('scripts'); ?>
<script src="<?=asset('assets/js/hrms-salary-calculator.js')?>"></script>
<style>
#employeeCompensationModal .input-group,
.payroll-input-group {
    display: flex !important;
    flex-wrap: nowrap !important;
    align-items: stretch !important;
    width: 100% !important;
}
#employeeCompensationModal .input-group > .input-group-text,
.payroll-input-group > .input-group-text {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex: 0 0 auto !important;
    border: 1px solid #cbd5e1 !important;
    border-right: 0 !important;
    background-color: #f1f5f9 !important;
    color: #334155 !important;
    font-weight: 700 !important;
    padding: 0.45rem 0.85rem !important;
    border-top-left-radius: 0.75rem !important;
    border-bottom-left-radius: 0.75rem !important;
    border-top-right-radius: 0 !important;
    border-bottom-right-radius: 0 !important;
}
#employeeCompensationModal .input-group > .form-control,
.payroll-input-group > .form-control {
    display: block !important;
    flex: 1 1 auto !important;
    min-width: 0 !important;
    width: 1% !important;
    border: 1px solid #cbd5e1 !important;
    border-top-right-radius: 0.75rem !important;
    border-bottom-right-radius: 0.75rem !important;
    border-top-left-radius: 0 !important;
    border-bottom-left-radius: 0 !important;
}
#employeeCompensationModal .input-group > .form-control:focus {
    border-color: #059669 !important;
    box-shadow: 0 0 0 0.2rem rgba(5, 150, 105, 0.15) !important;
}
#employeeCompensationModal .form-control:not(.input-group *),
#employeeCompensationModal .form-select:not(.input-group *) {
    border: 1px solid #cbd5e1 !important;
    border-radius: 0.75rem !important;
}
.employee-card {
    transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease;
    border-radius: 0.875rem !important;
    background: #ffffff;
    cursor: pointer;
    overflow: hidden;
}
.employee-card:hover, .employee-card:focus {
    transform: translateY(-3px);
    border-color: #cbd5e1 !important;
    box-shadow: 0 12px 28px -6px rgba(15, 23, 42, .1), 0 6px 12px -4px rgba(15, 23, 42, .04) !important;
}
.employee-avatar-wrapper img {
    border-top-left-radius: 0.875rem;
    border-bottom-left-radius: 0.875rem;
}
.dept-count-badge {
    background-color: #e2e8f0 !important;
    color: #1e293b !important;
    font-weight: 800 !important;
    font-size: 0.75rem !important;
    padding: 0.25rem 0.65rem !important;
    border-radius: 9999px !important;
    line-height: 1 !important;
    display: inline-block !important;
}
.active-dept-card .dept-count-badge {
    background-color: #065f46 !important;
    color: #ffffff !important;
}
.emp-code-badge {
    background-color: #f1f5f9 !important;
    color: #1e293b !important;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    padding: 2px 6px !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 6px !important;
    letter-spacing: 0.02em;
    display: inline-block;
    white-space: nowrap;
    line-height: 1.3;
}
.emp-dept-badge {
    background-color: #e0f2fe !important;
    color: #0369a1 !important;
    font-weight: 600 !important;
    font-size: 11px !important;
    padding: 3px 8px !important;
    border: 1px solid #bae6fd !important;
    border-radius: 6px !important;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: inline-block;
    max-width: 100%;
}
.employee-detail-tab {
    border: 1px solid #e2e8f0;
    border-bottom: 2px solid transparent;
    color: #64748b;
    background: transparent;
    transition: all .15s ease;
}
.employee-detail-tab:hover {
    color: #059669;
    background: #f8fafc;
}
.employee-detail-tab.active {
    color: #059669 !important;
    background: #ffffff !important;
    border-color: #cbd5e1 #cbd5e1 #ffffff !important;
    border-top: 2px solid #059669 !important;
}
.onboarding-progress{max-width:720px;margin:auto}.onboarding-step{display:flex;flex-direction:column;align-items:center;gap:.35rem;color:#94a3b8;font-size:.75rem;font-weight:700}.onboarding-step span{width:34px;height:34px;border-radius:999px;background:#f1f5f9;display:flex;align-items:center;justify-content:center}.onboarding-step.active{color:#047857}.onboarding-step.active span,.onboarding-step.complete span{background:#059669;color:white}.onboarding-line{height:2px;background:#e2e8f0;flex:1;margin:0 .75rem 1.25rem}.rounded-start-xl{border-radius:.75rem 0 0 .75rem}.rounded-end-xl{border-radius:0 .75rem .75rem 0}
#employeeOnboardingModal .modal-dialog-scrollable .modal-content,
#employeeCompensationModal .modal-dialog-scrollable .modal-content {
    display: flex !important;
    flex-direction: column !important;
    max-height: calc(100vh - 3.5rem) !important;
    overflow: hidden !important;
}
#employeeOnboardingModal form,
#employeeCompensationModal form {
    display: flex !important;
    flex-direction: column !important;
    flex: 1 1 auto !important;
    min-height: 0 !important;
    overflow: hidden !important;
}
#employeeOnboardingModal .modal-body,
#employeeCompensationModal .modal-body {
    flex: 1 1 auto !important;
    overflow-y: auto !important;
    min-height: 0 !important;
}
#employeeOnboardingModal .modal-footer,
#employeeCompensationModal .modal-footer {
    flex-shrink: 0 !important;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const search = document.getElementById('employeeMasterSearch');
    const filterEmployees = () => {
        const needle = (search?.value || '').trim().toLowerCase();
        let visible = 0;
        document.querySelectorAll('.employee-master-item').forEach(item => {
            const matchesSearch = !needle || item.dataset.search.includes(needle);
            item.classList.toggle('d-none', !matchesSearch);
            if (matchesSearch) visible++;
        });
        document.getElementById('employeeMasterEmpty')?.classList.toggle('d-none', visible !== 0);
    };
    search?.addEventListener('input', filterEmployees);
    const detailItem = (label, value) => `<div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">${label}</div><div class="fw-semibold text-slate-800 text-break">${value || 'Not provided'}</div></div>`;
    const employeeDetailModal = document.getElementById('employeeDetailModal');
    const selectEmployeeDetailPanel = selected => {
        document.querySelectorAll('.employee-detail-panel').forEach((panel, index) => {
            panel.classList.toggle('d-none', index !== selected);
        });
        document.querySelectorAll('.employee-detail-tab').forEach((tab, index) => {
            tab.classList.toggle('active', index === selected);
        });
    };
    document.querySelectorAll('.employee-detail-tab').forEach(button => {
        button.addEventListener('click', () => selectEmployeeDetailPanel(Number(button.dataset.panel)));
    });
    employeeDetailModal?.addEventListener('hidden.bs.modal', () => selectEmployeeDetailPanel(0));
    selectEmployeeDetailPanel(0);

    let selectedEmployee = null;
    document.querySelectorAll('.employee-card').forEach(card => {
        const open = () => {
            selectedEmployee = JSON.parse(card.dataset.employee);
            const employee = selectedEmployee;
            document.getElementById('detailHeaderAvatar').src = employee.avatar_url || '<?= asset('assets/img/avatars/emp-m1.jpg') ?>';
            document.getElementById('employeeDetailName').textContent = employee.full_name;
            document.getElementById('employeeDetailSubtitle').textContent = `${employee.emp_code || 'No employee ID'} · ${employee.designation_name || 'No designation'}`;
            document.getElementById('detailHeaderDept').textContent = employee.department_name || 'General';
            document.getElementById('detailHeaderBranch').textContent = employee.branch_name || employee.company_name || 'Main';
            document.getElementById('detailHeaderEmail').textContent = employee.email || 'No email';
            document.getElementById('detailHeaderPhone').textContent = employee.contact_no || 'Not provided';
            document.getElementById('detailHeaderEmpCode').textContent = employee.emp_code || 'Not assigned';
            document.getElementById('detailHeaderStatusDot').className = 'position-absolute top-0 end-0 translate-middle p-1 rounded-circle border border-2 border-white ' + (Number(employee.status) === 1 ? 'bg-emerald-500' : 'bg-slate-400');

            const resume = document.getElementById('employeeResumeLink');
            resume.classList.toggle('d-none', !employee.resume_id);
            if (employee.resume_id) resume.href = 'hrms-document.php?id=' + employee.resume_id;

            bootstrap.Modal.getOrCreateInstance(employeeDetailModal).show();
        };
        card.addEventListener('click', open);
        card.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); }
        });
    });

    const salaryMoney = value => '₹' + Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const salaryEscape = value => { const node = document.createElement('div'); node.textContent = value ?? ''; return node.innerHTML; };
    const statutoryRulesReady = <?=json_encode($statutoryRulesReady)?>;

    document.getElementById('employeeDetailModal')?.addEventListener('show.bs.modal', () => {
        if (!selectedEmployee) return;
        const genderLabel = ({1:'Male', 2:'Female', 4:'Other'})[Number(selectedEmployee.gender)] || 'Not provided';
        const linkedUserText = selectedEmployee.linked_user_name ? `${salaryEscape(selectedEmployee.linked_user_name)} (${salaryEscape(selectedEmployee.linked_user_email)})` : 'Not linked';
        const accountNumber = String(selectedEmployee.bank_account_number || '');
        const maskedAccount = accountNumber ? `${'*'.repeat(Math.max(4, accountNumber.length - 4))}${accountNumber.slice(-4)}` : 'Not provided';
        const accountType = ({1:'Savings', 2:'Current', 3:'Salary Account'})[Number(selectedEmployee.bank_account_type)] || 'Not provided';
        const pfLabels = {e:'Employee (E)', w:'Worker (W)', ew:'Employee / Worker (EW)'};
        const pfBase = selectedEmployee.pf_category === 'e' ? 15000 : (['w','ew'].includes(selectedEmployee.pf_category) ? 7500 : 0);
        const esicEstimate = Number(selectedEmployee.monthly_salary_total) > 0 && Number(selectedEmployee.monthly_salary_total) < 21000 ? Number(selectedEmployee.monthly_salary_total) * .01 : 0;

        // 1. Tab 1: Personal Sections (Matching reference design)
        document.getElementById('personalContactDetails').innerHTML =
            detailItem('Work Email', salaryEscape(selectedEmployee.email)) +
            detailItem('Personal Email', salaryEscape(selectedEmployee.personal_email)) +
            detailItem('Mobile Phone', salaryEscape(selectedEmployee.contact_no)) +
            `<div class="col-12">${detailItem('Residential Address', salaryEscape(selectedEmployee.local_address))}</div>` +
            detailItem('Address Line 2', salaryEscape(selectedEmployee.address_line_2)) +
            detailItem('Town / City', salaryEscape(selectedEmployee.city)) +
            detailItem('State', salaryEscape(selectedEmployee.state)) +
            detailItem('PIN / Postal Code', salaryEscape(selectedEmployee.postal_code));

        document.getElementById('personalInfoDetails').innerHTML =
            detailItem('Legal Full Name', salaryEscape(selectedEmployee.full_name)) +
            detailItem('Employee ID', salaryEscape(selectedEmployee.emp_code)) +
            detailItem('Gender / Sex', genderLabel) +
            detailItem('Date of Birth', salaryEscape(selectedEmployee.dob)) +
            detailItem("Father's Name", salaryEscape(selectedEmployee.fathers_name)) +
            detailItem('PAN Number', salaryEscape(selectedEmployee.pan_no)) +
            detailItem('Differently Abled', Number(selectedEmployee.differently_abled) === 1 ? 'Yes' : 'No') +
            detailItem('Differently Abled Type', salaryEscape(selectedEmployee.differently_abled_type || 'Not applicable'));

        document.getElementById('personalOrgDetails').innerHTML =
            detailItem('Organization', salaryEscape(selectedEmployee.company_name)) +
            detailItem('Branch', salaryEscape(selectedEmployee.branch_name)) +
            detailItem('Department', salaryEscape(selectedEmployee.department_name)) +
            detailItem('Designation', salaryEscape(selectedEmployee.designation_name)) +
            detailItem('Work Location', salaryEscape(selectedEmployee.work_location)) +
            detailItem('Date of Joining', salaryEscape(selectedEmployee.date_of_join)) +
            detailItem('Director / Substantial Interest', Number(selectedEmployee.is_director) === 1 ? 'Yes' : 'No') +
            detailItem('Linked User Account', linkedUserText);

        const paymentModeLabels = {
            'direct_deposit': 'Direct Deposit',
            'bank_transfer': 'Bank Transfer',
            'upi': 'UPI / Online',
            'cheque': 'Cheque',
            'cash': 'Cash'
        };
        const curPaymentMode = selectedEmployee.payment_mode || '';
        const modeLabel = paymentModeLabels[curPaymentMode] || (curPaymentMode ? curPaymentMode.replaceAll('_',' ') : 'Not provided');
        let bankHtml = detailItem('Payment Mode', salaryEscape(modeLabel));
        if (curPaymentMode === 'upi') {
            bankHtml += detailItem('UPI ID', salaryEscape(selectedEmployee.upi_id || 'Not provided'));
            if (selectedEmployee.bank_account_holder_name) {
                bankHtml += detailItem('Beneficiary Name', salaryEscape(selectedEmployee.bank_account_holder_name));
            }
        } else if (curPaymentMode === 'cheque') {
            bankHtml += detailItem('Payee Name', salaryEscape(selectedEmployee.bank_account_holder_name || selectedEmployee.full_name || 'Not provided'));
            if (selectedEmployee.bank_name) {
                bankHtml += detailItem('Preferred Bank', salaryEscape(selectedEmployee.bank_name));
            }
        } else if (curPaymentMode === 'cash') {
            bankHtml += detailItem('Disbursement Type', 'Cash Payment');
        } else {
            bankHtml +=
                detailItem('Bank Name', salaryEscape(selectedEmployee.bank_name)) +
                detailItem('Account Holder', salaryEscape(selectedEmployee.bank_account_holder_name)) +
                detailItem('Account Number', maskedAccount) +
                detailItem('Account Type', accountType) +
                detailItem('IFSC Code', salaryEscape(selectedEmployee.bank_ifsc_code));
        }
        document.getElementById('personalBankDetails').innerHTML = bankHtml;

        // Legacy compatibility placeholders
        document.getElementById('employeePersonalDetails').innerHTML = document.getElementById('personalInfoDetails').innerHTML;

        // 2. Tab 2: Payroll Overview & Breakdown
        document.getElementById('payrollMonthlyTotal').textContent = salaryMoney(selectedEmployee.monthly_salary_total);
        document.getElementById('payrollAnnualCtc').textContent = salaryMoney(selectedEmployee.annual_ctc);

        document.getElementById('payrollContractDetails').innerHTML =
            detailItem('Basic / Month', salaryMoney(selectedEmployee.basic_salary)) +
            detailItem('Monthly Deductions', salaryMoney(selectedEmployee.monthly_deduction_total)) +
            detailItem('Estimated Net / Month', salaryMoney(selectedEmployee.monthly_net_total)) +
            detailItem('PF Category', salaryEscape(pfLabels[selectedEmployee.pf_category] || 'Legacy rule')) +
            detailItem('PF / Month', salaryMoney(pfBase * .12)) +
            detailItem('ESIC / Full Month', salaryMoney(esicEstimate)) +
            detailItem('Payment Mode', salaryEscape(selectedEmployee.payment_mode ? selectedEmployee.payment_mode.replaceAll('_',' ') : 'Not provided'));

        const components = Array.isArray(selectedEmployee.salary_components) ? selectedEmployee.salary_components : [];
        const componentRows = components.map(component => {
            const isDeduction = Number(component.is_deduction) === 1;
            return `<tr>
                <td class="px-3 py-3">
                    <div class="fw-semibold text-slate-800">${salaryEscape(component.component_name)}</div>
                    <small class="text-slate-400">${salaryEscape(component.component_code)}</small>
                </td>
                <td class="py-3 text-center">
                    <span class="badge ${isDeduction ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-700'} rounded-pill text-xs">
                        ${isDeduction ? 'Deduction' : 'Earning'}
                    </span>
                </td>
                <td class="py-3 text-end fw-semibold ${isDeduction ? 'text-rose-600' : 'text-slate-800'}">
                    ${isDeduction ? '-' : ''}${salaryMoney(component.monthly_amount)}
                </td>
                <td class="px-3 py-3 text-end text-slate-600">
                    ${isDeduction ? '-' : ''}${salaryMoney(component.annual_amount)}
                </td>
            </tr>`;
        }).join('');

        const componentTableHtml = `
            <div class="rounded-xl border border-slate-200 overflow-hidden">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-slate-50 text-xs text-uppercase text-slate-400">
                        <tr>
                            <th class="px-3">Component</th>
                            <th class="text-center">Type</th>
                            <th class="text-end">Monthly</th>
                            <th class="px-3 text-end">Annual</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${componentRows || '<tr><td colspan="4" class="text-center py-4 text-slate-400">No salary components configured.</td></tr>'}
                    </tbody>
                </table>
            </div>`;

        document.getElementById('payrollComponentsTable').innerHTML = componentTableHtml;
        document.getElementById('employeeCompensationDetails').innerHTML = document.getElementById('payrollContractDetails').innerHTML + componentTableHtml;
    });

    // Section Edit buttons on each card
    const editSectionModal = document.getElementById('editEmployeeSectionModal');
    const editSectionForm = document.getElementById('editEmployeeSectionForm');

    document.querySelectorAll('.edit-employee-section-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!selectedEmployee || !editSectionModal) return;
            const section = btn.dataset.section;
            document.getElementById('editSectionEmployeeId').value = selectedEmployee.id;
            document.getElementById('editSectionName').value = section;
            document.getElementById('editSectionEmployeeSubtitle').textContent = `${selectedEmployee.full_name} · ${selectedEmployee.emp_code || 'ID: #' + selectedEmployee.id}`;

            const sectionTitles = {
                contact: 'Edit Contact Details',
                personal: 'Edit Personal Information',
                organization: 'Edit Organization & Employment',
                banking: 'Edit Banking & Payment'
            };
            document.getElementById('editSectionModalTitle').textContent = sectionTitles[section] || 'Edit Details';

            // Hide inactive edit panels and disable their form elements
            document.querySelectorAll('.section-edit-panel').forEach(panel => {
                const isTarget = panel.dataset.sectionPanel === section;
                panel.classList.toggle('d-none', !isTarget);
                panel.querySelectorAll('input, select, textarea').forEach(el => {
                    el.disabled = !isTarget;
                });
            });

            // Populate fields based on section
            if (section === 'contact') {
                document.getElementById('editSecWorkEmail').value = selectedEmployee.email || '';
                document.getElementById('editSecPersonalEmail').value = selectedEmployee.personal_email || '';
                document.getElementById('editSecMobile').value = selectedEmployee.contact_no || '';
                document.getElementById('editSecResidentialAddress').value = selectedEmployee.local_address || '';
                document.getElementById('editSecAddressLine2').value = selectedEmployee.address_line_2 || '';
                document.getElementById('editSecCity').value = selectedEmployee.city || '';
                document.getElementById('editSecState').value = selectedEmployee.state || '';
                document.getElementById('editSecPostalCode').value = selectedEmployee.postal_code || '';
            } else if (section === 'personal') {
                document.getElementById('editSecFirstName').value = selectedEmployee.first_name || '';
                document.getElementById('editSecLastName').value = selectedEmployee.last_name || '';
                document.getElementById('editSecGender').value = selectedEmployee.gender || '';
                document.getElementById('editSecDob').value = selectedEmployee.dob && selectedEmployee.dob !== '0000-00-00' ? selectedEmployee.dob : '';
                document.getElementById('editSecFathersName').value = selectedEmployee.fathers_name || '';
                document.getElementById('editSecPanNo').value = selectedEmployee.pan_no || '';
                document.getElementById('editSecDifferentlyAbled').checked = Number(selectedEmployee.differently_abled) === 1;
                document.getElementById('editSecDifferentlyAbledType').value = selectedEmployee.differently_abled_type || '';
            } else if (section === 'organization') {
                document.getElementById('editSecCompany').value = selectedEmployee.company_id || '';
                document.getElementById('editSecBranch').value = selectedEmployee.branch_id || '';
                document.getElementById('editSecDepartment').value = selectedEmployee.department_id || '';
                document.getElementById('editSecDesignation').value = selectedEmployee.designation_id || '';
                document.getElementById('editSecWorkLocation').value = selectedEmployee.work_location || '';
                document.getElementById('editSecDateOfJoin').value = selectedEmployee.date_of_join && selectedEmployee.date_of_join !== '0000-00-00' ? selectedEmployee.date_of_join : '';
                document.getElementById('editSecStatus').value = selectedEmployee.status || 1;
                document.getElementById('editSecIsDirector').checked = Number(selectedEmployee.is_director) === 1;
            } else if (section === 'banking') {
                const secPaymentMode = document.getElementById('editSecPaymentMode');
                secPaymentMode.value = selectedEmployee.payment_mode || 'bank_transfer';
                document.getElementById('editSecUpiId').value = selectedEmployee.upi_id || '';
                document.getElementById('editSecBankId').value = selectedEmployee.bank_id || '';
                document.getElementById('editSecBankHolderName').value = selectedEmployee.bank_account_holder_name || '';
                document.getElementById('editSecBankAccountNumber').value = selectedEmployee.bank_account_number || '';
                document.getElementById('editSecBankIfscCode').value = selectedEmployee.bank_ifsc_code || '';
                document.getElementById('editSecBankAccountType').value = selectedEmployee.bank_account_type || 1;
                toggleEditSecPaymentFields();
            }

            // Temporarily hide detail modal and show edit section modal
            bootstrap.Modal.getOrCreateInstance(document.getElementById('employeeDetailModal')).hide();
            bootstrap.Modal.getOrCreateInstance(editSectionModal).show();
        });
    });

    const toggleEditSecPaymentFields = () => {
        const mode = document.getElementById('editSecPaymentMode')?.value || 'bank_transfer';
        const isBank = ['direct_deposit', 'bank_transfer'].includes(mode);
        const isUpi = mode === 'upi';
        const isCheque = mode === 'cheque';

        document.querySelectorAll('.edit-sec-bank-group').forEach(el => el.classList.toggle('d-none', !isBank));
        document.querySelectorAll('.edit-sec-upi-group').forEach(el => el.classList.toggle('d-none', !isUpi));
        document.querySelectorAll('.edit-sec-holder-group').forEach(el => el.classList.toggle('d-none', !isBank && !isCheque && !isUpi));

        const holderLabel = document.getElementById('editSecHolderNameLabel');
        if (holderLabel) {
            if (isCheque) holderLabel.textContent = 'Payee Name on Cheque';
            else if (isUpi) holderLabel.textContent = 'Beneficiary / Account Name';
            else holderLabel.textContent = 'Account Holder Name';
        }
    };
    document.getElementById('editSecPaymentMode')?.addEventListener('change', toggleEditSecPaymentFields);

    // When edit section modal closes, re-open employeeDetailModal
    editSectionModal?.addEventListener('hidden.bs.modal', () => {
        if (selectedEmployee) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById('employeeDetailModal')).show();
        }
    });

    // Handle Edit Section Submit
    editSectionForm?.addEventListener('submit', async event => {
        event.preventDefault();
        const submitBtn = document.getElementById('btnSaveEmployeeSection');
        const spinner = submitBtn?.querySelector('.spinner-border');
        const label = submitBtn?.querySelector('.save-label');
        if (submitBtn) submitBtn.disabled = true;
        if (spinner) spinner.classList.remove('d-none');
        if (label) label.textContent = 'Saving...';

        try {
            const formData = new FormData(editSectionForm);
            const section = formData.get('section');

            // Validate active section required fields
            if (section === 'contact') {
                const workEmail = (formData.get('work_email') || '').trim();
                const mobile = (formData.get('mobile') || '').trim();
                const resAddress = (formData.get('residential_address') || '').trim();
                if (!workEmail) throw new Error('Work email is required.');
                if (!mobile) throw new Error('Mobile phone is required.');
                if (!resAddress) throw new Error('Residential address is required.');
            } else if (section === 'personal') {
                const firstName = (formData.get('first_name') || '').trim();
                const gender = formData.get('gender');
                if (!firstName) throw new Error('First name is required.');
                if (!gender) throw new Error('Gender is required.');
            } else if (section === 'organization') {
                const deptId = formData.get('department_id');
                const desigId = formData.get('designation_id');
                if (!deptId) throw new Error('Department is required.');
                if (!desigId) throw new Error('Designation is required.');
            } else if (section === 'banking') {
                const payMode = formData.get('payment_mode');
                if (payMode === 'upi' && !(formData.get('upi_id') || '').trim()) {
                    throw new Error('UPI ID is required for UPI payment mode.');
                }
                if (['direct_deposit', 'bank_transfer'].includes(payMode)) {
                    if (!(formData.get('bank_id') || '').trim()) throw new Error('Bank selection is required.');
                    if (!(formData.get('bank_account_number') || '').trim()) throw new Error('Bank account number is required.');
                    if (!(formData.get('bank_ifsc_code') || '').trim()) throw new Error('IFSC code is required.');
                }
            }

            const response = await fetch('hrms-api.php', { method: 'POST', body: formData, credentials: 'same-origin' });
            const data = await response.json();
            if (!response.ok || data.status !== 'success') {
                throw new Error(data.message || 'Unable to update employee section.');
            }

            if (window.toastr) toastr.success(data.message); else alert(data.message);

            // Update in-memory selectedEmployee object
            if (section === 'contact') {
                selectedEmployee.email = formData.get('work_email');
                selectedEmployee.personal_email = formData.get('personal_email');
                selectedEmployee.contact_no = formData.get('mobile');
                selectedEmployee.local_address = formData.get('residential_address');
                selectedEmployee.permanent_address = formData.get('residential_address');
                selectedEmployee.address_line_2 = formData.get('address_line_2');
                selectedEmployee.city = formData.get('city');
                selectedEmployee.state = formData.get('state');
                selectedEmployee.postal_code = formData.get('postal_code');
            } else if (section === 'personal') {
                selectedEmployee.first_name = formData.get('first_name');
                selectedEmployee.last_name = formData.get('last_name');
                selectedEmployee.full_name = `${selectedEmployee.first_name} ${selectedEmployee.last_name}`.trim();
                selectedEmployee.gender = formData.get('gender');
                selectedEmployee.dob = formData.get('dob');
                selectedEmployee.fathers_name = formData.get('fathers_name');
                selectedEmployee.pan_no = formData.get('pan_no');
                selectedEmployee.differently_abled = formData.get('differently_abled') ? 1 : 0;
                selectedEmployee.differently_abled_type = formData.get('differently_abled_type');
            } else if (section === 'organization') {
                selectedEmployee.company_id = formData.get('company_id');
                const compOpt = document.querySelector(`#editSecCompany option[value="${selectedEmployee.company_id}"]`);
                if (compOpt) selectedEmployee.company_name = compOpt.textContent;

                selectedEmployee.branch_id = formData.get('branch_id');
                const branchOpt = document.querySelector(`#editSecBranch option[value="${selectedEmployee.branch_id}"]`);
                if (branchOpt) selectedEmployee.branch_name = branchOpt.textContent;

                selectedEmployee.department_id = formData.get('department_id');
                const deptOpt = document.querySelector(`#editSecDepartment option[value="${selectedEmployee.department_id}"]`);
                if (deptOpt) selectedEmployee.department_name = deptOpt.textContent;

                selectedEmployee.designation_id = formData.get('designation_id');
                const desigOpt = document.querySelector(`#editSecDesignation option[value="${selectedEmployee.designation_id}"]`);
                if (desigOpt) selectedEmployee.designation_name = desigOpt.textContent;

                selectedEmployee.work_location = formData.get('work_location');
                selectedEmployee.date_of_join = formData.get('date_of_join');
                selectedEmployee.status = formData.get('status');
                selectedEmployee.is_director = formData.get('is_director') ? 1 : 0;
            } else if (section === 'banking') {
                selectedEmployee.payment_mode = formData.get('payment_mode');
                selectedEmployee.upi_id = formData.get('upi_id');
                selectedEmployee.bank_id = formData.get('bank_id');
                const bankOpt = document.querySelector(`#editSecBankId option[value="${selectedEmployee.bank_id}"]`);
                selectedEmployee.bank_name = bankOpt ? bankOpt.textContent : '';
                selectedEmployee.bank_account_holder_name = formData.get('bank_account_holder_name');
                selectedEmployee.bank_account_number = formData.get('bank_account_number');
                selectedEmployee.bank_ifsc_code = formData.get('bank_ifsc_code');
                selectedEmployee.bank_account_type = formData.get('bank_account_type');
            }

            // Update card dataset in the grid
            const cardEl = document.querySelector(`.employee-card[data-employee*='"id":${selectedEmployee.id}']`) || document.querySelector(`.employee-card[data-employee*='"id":"${selectedEmployee.id}"']`);
            if (cardEl) {
                cardEl.dataset.employee = JSON.stringify(selectedEmployee);
                const nameEl = cardEl.querySelector('.fw-bold.text-slate-900');
                if (nameEl) nameEl.textContent = selectedEmployee.full_name;
                const desigEl = cardEl.querySelector('.ti-briefcase')?.nextElementSibling;
                if (desigEl) desigEl.textContent = selectedEmployee.designation_name || 'Not assigned';
                const deptEl = cardEl.querySelector('.emp-dept-badge');
                if (deptEl) deptEl.innerHTML = `<i class="ti ti-building me-1 opacity-75"></i>${selectedEmployee.department_name || selectedEmployee.designation_name || 'General'}`;
            }

            // Update modal header info
            document.getElementById('employeeDetailName').textContent = selectedEmployee.full_name;
            document.getElementById('employeeDetailSubtitle').textContent = `${selectedEmployee.emp_code || 'No employee ID'} · ${selectedEmployee.designation_name || 'No designation'}`;
            document.getElementById('detailHeaderDept').textContent = selectedEmployee.department_name || 'General';
            document.getElementById('detailHeaderBranch').textContent = selectedEmployee.branch_name || selectedEmployee.company_name || 'Main';
            document.getElementById('detailHeaderEmail').textContent = selectedEmployee.email || 'No email';
            document.getElementById('detailHeaderPhone').textContent = selectedEmployee.contact_no || 'Not provided';
            document.getElementById('detailHeaderStatusDot').className = 'position-absolute top-0 end-0 translate-middle p-1 rounded-circle border border-2 border-white ' + (Number(selectedEmployee.status) === 1 ? 'bg-emerald-500' : 'bg-slate-400');

            // Re-render detail modal fields
            document.getElementById('employeeDetailModal')?.dispatchEvent(new Event('show.bs.modal'));

            // Close section modal
            bootstrap.Modal.getOrCreateInstance(editSectionModal).hide();
        } catch (error) {
            if (window.toastr) toastr.error(error.message); else alert(error.message);
        } finally {
            if (submitBtn) submitBtn.disabled = false;
            if (spinner) spinner.classList.add('d-none');
            if (label) label.textContent = 'Save Changes';
        }
    });

    document.getElementById('editPayrollInlineBtn')?.addEventListener('click', () => {
        document.getElementById('editEmployeeCompensation')?.click();
    });
    document.getElementById('editPayrollComponentsBtn')?.addEventListener('click', () => {
        document.getElementById('editEmployeeCompensation')?.click();
    });
    const compensationForm = document.getElementById('employeeCompensationForm');
    let customSalaryBody = document.getElementById('customSalaryComponentRows');

    const updateEditStatutoryEstimate = () => {
        if (!statutoryRulesReady || !compensationForm) return;
        const category = compensationForm.elements.pf_category?.value || '';
        const monthlyGross = Number(compensationForm.elements.monthly_gross_salary?.value || 0);
        const pfBase = category === 'e' ? 15000 : (['w', 'ew'].includes(category) ? 7500 : 0);
        const esic = monthlyGross > 0 && monthlyGross < 21000 ? (monthlyGross * 0.01) : 0;
        const pfEst = document.getElementById('editPfEstimate');
        const esicEst = document.getElementById('editEsicEstimate');
        if (pfEst) pfEst.textContent = salaryMoney(pfBase * 0.12);
        if (esicEst) esicEst.textContent = salaryMoney(esic);
    };

    const rebalanceCompensation = (sourceField = null) => {
        if (!compensationForm) return null;
        const grossInput = compensationForm.elements.monthly_gross_salary;
        const basicPctInput = document.getElementById('editBasicPercentage');
        const basicAmtInput = compensationForm.elements.basic_salary;
        const hraPctInput = document.getElementById('editHraPercentage');
        const hraAmtInput = compensationForm.elements.hra;
        const conveyanceInput = compensationForm.elements.conveyance_allowance;
        const annualHidden = document.getElementById('editAnnualCtcHidden');
        const annualPreview = document.getElementById('editAnnualCtcPreview');

        let monthlyGross = Math.max(0, Number(grossInput?.value || 0));
        let annualCtc = monthlyGross * 12;
        if (annualHidden) annualHidden.value = annualCtc.toFixed(2);
        if (annualPreview) annualPreview.textContent = salaryMoney(annualCtc);

        let basicPct = Number(basicPctInput?.value || 50);
        let basicAmt = Number(basicAmtInput?.value || 0);
        let hraPct = Number(hraPctInput?.value || 40);
        let hraAmt = Number(hraAmtInput?.value || 0);
        let conveyanceAmt = Number(conveyanceInput?.value || 0);

        if (sourceField === 'basic_salary') {
            basicAmt = Math.max(0, Number(basicAmtInput.value || 0));
            basicPct = monthlyGross > 0 ? (basicAmt / monthlyGross) * 100 : 0;
            if (basicPctInput) basicPctInput.value = (Math.round(basicPct * 100) / 100).toFixed(1);
            hraAmt = basicAmt * (hraPct / 100);
            if (hraAmtInput) hraAmtInput.value = hraAmt.toFixed(2);
        } else if (sourceField === 'basic_percentage' || sourceField === 'monthly_gross_salary') {
            basicPct = Math.max(0, Number(basicPctInput?.value || 50));
            basicAmt = monthlyGross * (basicPct / 100);
            if (basicAmtInput) basicAmtInput.value = basicAmt.toFixed(2);
            hraAmt = basicAmt * (hraPct / 100);
            if (hraAmtInput) hraAmtInput.value = hraAmt.toFixed(2);
        } else if (sourceField === 'hra') {
            hraAmt = Math.max(0, Number(hraAmtInput.value || 0));
            hraPct = basicAmt > 0 ? (hraAmt / basicAmt) * 100 : 0;
            if (hraPctInput) hraPctInput.value = (Math.round(hraPct * 100) / 100).toFixed(1);
        } else if (sourceField === 'hra_percentage') {
            hraPct = Math.max(0, Number(hraPctInput?.value || 40));
            hraAmt = basicAmt * (hraPct / 100);
            if (hraAmtInput) hraAmtInput.value = hraAmt.toFixed(2);
        } else {
            if (basicAmt === 0 && monthlyGross > 0) {
                basicAmt = monthlyGross * (basicPct / 100);
                if (basicAmtInput) basicAmtInput.value = basicAmt.toFixed(2);
            }
            if (hraAmt === 0 && basicAmt > 0) {
                hraAmt = basicAmt * (hraPct / 100);
                if (hraAmtInput) hraAmtInput.value = hraAmt.toFixed(2);
            }
        }

        const customRows = [...document.querySelectorAll('.custom-salary-component')];
        let customEarningsTotal = 0;
        let customDeductionsTotal = 0;

        customRows.forEach(row => {
            const typeSelect = row.querySelector('.custom-component-calc-type');
            const valInput = row.querySelector('.custom-component-val');
            const monthlyInput = row.querySelector('.custom-component-monthly');
            const isDeduction = row.querySelector('.custom-component-deduction')?.checked;

            const type = typeSelect ? typeSelect.value : 'fixed';
            const rate = Math.max(0, Number(valInput?.value || 0));
            let monthly = 0;

            if (type === 'basic_percentage') {
                monthly = basicAmt * (rate / 100);
            } else if (type === 'gross_percentage') {
                monthly = monthlyGross * (rate / 100);
            } else {
                monthly = rate;
            }

            if (monthlyInput) {
                monthlyInput.value = monthly.toFixed(2);
            }

            if (isDeduction) {
                customDeductionsTotal += monthly;
            } else {
                customEarningsTotal += monthly;
            }
        });

        const totalEarnings = basicAmt + hraAmt + conveyanceAmt + customEarningsTotal;
        const diff = Math.round((totalEarnings - monthlyGross) * 100) / 100;
        const status = document.getElementById('editSalaryBalanceStatus');
        const isBalanced = Math.abs(diff) <= 0.05;

        if (status) {
            if (monthlyGross === 0) {
                status.textContent = 'Enter a monthly gross salary to calculate components.';
                status.className = 'rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-600';
            } else if (isBalanced) {
                status.textContent = `Earning heads match Monthly Gross Salary (${salaryMoney(monthlyGross)}).`;
                status.className = 'rounded-xl border border-emerald-100 bg-emerald-50 p-3 text-sm text-emerald-700';
            } else if (diff < 0) {
                status.innerHTML = `Earning heads sum to <strong>${salaryMoney(totalEarnings)}</strong> (${salaryMoney(Math.abs(diff))} unallocated). You can allocate the remainder to Conveyance or adjust percentages.`;
                status.className = 'rounded-xl border border-amber-100 bg-amber-50 p-3 text-sm text-amber-800';
            } else {
                status.innerHTML = `Earning heads sum to <strong>${salaryMoney(totalEarnings)}</strong> (exceeds Monthly Gross by ${salaryMoney(diff)}).`;
                status.className = 'rounded-xl border border-rose-100 bg-rose-50 p-3 text-sm text-rose-700';
            }
        }

        updateEditStatutoryEstimate();
        return { balanced: isBalanced, totalEarnings, monthlyGross, annualCtc };
    };

    compensationForm?.elements.monthly_gross_salary?.addEventListener('input', () => rebalanceCompensation('monthly_gross_salary'));
    document.getElementById('editBasicPercentage')?.addEventListener('input', () => rebalanceCompensation('basic_percentage'));
    compensationForm?.elements.basic_salary?.addEventListener('input', () => rebalanceCompensation('basic_salary'));
    document.getElementById('editHraPercentage')?.addEventListener('input', () => rebalanceCompensation('hra_percentage'));
    compensationForm?.elements.hra?.addEventListener('input', () => rebalanceCompensation('hra'));
    compensationForm?.elements.conveyance_allowance?.addEventListener('input', () => rebalanceCompensation('conveyance'));
    compensationForm?.elements.pf_category?.addEventListener('change', updateEditStatutoryEstimate);

    const addCustomSalaryComponent = (component = {}) => {
        if (!customSalaryBody) return;
        const calcType = component.calculation_type || 'fixed';
        const isDeduction = Number(component.is_deduction) === 1;
        const calcVal = component.calculation_value !== undefined ? component.calculation_value : (component.monthly_amount || 0);
        const nameVal = component.component_name || component.name || '';
        const monthlyVal = component.monthly_amount !== undefined ? component.monthly_amount : calcVal;

        const row = document.createElement('tr');
        row.className = 'custom-salary-component';
        row.innerHTML = `
            <td class="px-3">
                <input class="form-control form-control-sm rounded-lg custom-component-name" placeholder="Component name" maxlength="120" required value="${nameVal.replace(/"/g, '&quot;')}">
            </td>
            <td>
                <select class="form-select form-select-sm rounded-lg custom-component-calc-type">
                    <option value="fixed" ${calcType === 'fixed' ? 'selected' : ''}>Fixed Amount (₹)</option>
                    <option value="basic_percentage" ${calcType === 'basic_percentage' ? 'selected' : ''}>% of Basic Salary</option>
                    <option value="gross_percentage" ${calcType === 'gross_percentage' ? 'selected' : ''}>% of Gross Salary</option>
                </select>
            </td>
            <td>
                <div class="input-group input-group-sm flex-nowrap">
                    <input type="number" class="form-control form-control-sm text-end custom-component-val" min="0" step="0.01" required value="${Number(calcVal || 0).toFixed(2)}">
                    <span class="input-group-text custom-component-unit text-xs">${calcType === 'fixed' ? '₹' : '%'}</span>
                </div>
            </td>
            <td class="text-end">
                <input type="number" class="form-control form-control-sm rounded-lg text-end custom-component-monthly bg-slate-50" min="0" step="0.01" required value="${Number(monthlyVal || 0).toFixed(2)}" ${calcType !== 'fixed' ? 'readonly' : ''}>
            </td>
            <td class="text-center">
                <input type="checkbox" class="form-check-input custom-component-deduction" ${isDeduction ? 'checked' : ''} title="Check if this is a deduction">
            </td>
            <td class="px-2 text-center">
                <button type="button" class="btn btn-sm btn-icon btn-outline-danger rounded-lg"><i class="ti ti-trash"></i></button>
            </td>
        `;

        const typeSelect = row.querySelector('.custom-component-calc-type');
        const unitSpan = row.querySelector('.custom-component-unit');
        const valInput = row.querySelector('.custom-component-val');
        const monthlyInput = row.querySelector('.custom-component-monthly');
        const deductionCheck = row.querySelector('.custom-component-deduction');

        typeSelect.addEventListener('change', () => {
            const t = typeSelect.value;
            unitSpan.textContent = t === 'fixed' ? '₹' : '%';
            monthlyInput.readOnly = t !== 'fixed';
            if (t !== 'fixed') {
                monthlyInput.classList.add('bg-slate-50');
            } else {
                monthlyInput.classList.remove('bg-slate-50');
            }
            rebalanceCompensation('custom_component');
        });

        valInput.addEventListener('input', () => rebalanceCompensation('custom_component'));
        monthlyInput.addEventListener('input', () => {
            if (typeSelect.value === 'fixed') {
                valInput.value = monthlyInput.value;
            }
            rebalanceCompensation('custom_component');
        });
        deductionCheck.addEventListener('change', () => rebalanceCompensation('custom_component'));
        row.querySelector('.btn-outline-danger').addEventListener('click', () => {
            row.remove();
            rebalanceCompensation('custom_component');
        });

        customSalaryBody.appendChild(row);
    };

    document.getElementById('addCustomSalaryComponent')?.addEventListener('click', () => {
        addCustomSalaryComponent();
        rebalanceCompensation('custom_component');
    });

    document.getElementById('editEmployeeCompensation')?.addEventListener('click', () => {
        if (!selectedEmployee || !compensationForm) return;
        compensationForm.elements.employee_id.value = selectedEmployee.id;

        const monthlyGross = Number(selectedEmployee.monthly_salary_total || (Number(selectedEmployee.annual_ctc || 0) / 12) || 0);
        compensationForm.elements.monthly_gross_salary.value = monthlyGross > 0 ? monthlyGross.toFixed(2) : '';

        const basicAmt = Number(selectedEmployee.basic_salary || 0);
        compensationForm.elements.basic_salary.value = basicAmt > 0 ? basicAmt.toFixed(2) : '';
        const basicPct = monthlyGross > 0 && basicAmt > 0 ? (basicAmt / monthlyGross) * 100 : 50;
        const basicPctInput = document.getElementById('editBasicPercentage');
        if (basicPctInput) basicPctInput.value = (Math.round(basicPct * 100) / 100).toFixed(1);

        const hraAmt = Number(selectedEmployee.hra || 0);
        compensationForm.elements.hra.value = hraAmt > 0 ? hraAmt.toFixed(2) : '';
        const hraPct = basicAmt > 0 && hraAmt > 0 ? (hraAmt / basicAmt) * 100 : 40;
        const hraPctInput = document.getElementById('editHraPercentage');
        if (hraPctInput) hraPctInput.value = (Math.round(hraPct * 100) / 100).toFixed(1);

        compensationForm.elements.conveyance_allowance.value = Number(selectedEmployee.conveyance_allowance || 0).toFixed(2);
        if (compensationForm.elements.pf_category) {
            compensationForm.elements.pf_category.value = selectedEmployee.pf_category || '';
        }

        if (customSalaryBody) {
            customSalaryBody.innerHTML = '';
            const fixedExcluded = new Set(['BASIC', 'HRA', 'CONVEYANCE', 'MEDICAL', 'SPECIAL', 'INCENTIVE']);
            (selectedEmployee.salary_components || [])
                .filter(component => !fixedExcluded.has(String(component.component_code || component.code).toUpperCase()))
                .forEach(addCustomSalaryComponent);
        }

        rebalanceCompensation();
        document.getElementById('compensationEmployeeName').textContent = `${selectedEmployee.full_name} · ${selectedEmployee.emp_code || 'No employee ID'}`;
        bootstrap.Modal.getOrCreateInstance(document.getElementById('employeeDetailModal')).hide();
        bootstrap.Modal.getOrCreateInstance(document.getElementById('employeeCompensationModal')).show();
    });

    compensationForm?.addEventListener('submit', async event => {
        event.preventDefault();
        const submitBtn = document.getElementById('btnSavePayrollSetup');
        const spinner = submitBtn?.querySelector('.spinner-border');
        const label = submitBtn?.querySelector('.save-label');
        if (submitBtn) submitBtn.disabled = true;
        if (spinner) spinner.classList.remove('d-none');
        if (label) label.textContent = 'Saving...';

        try {
            const balance = rebalanceCompensation();
            const computedCtc = (balance?.totalEarnings || (Number(compensationForm.elements.monthly_gross_salary?.value || 0))) * 12;
            document.getElementById('editAnnualCtcHidden').value = computedCtc.toFixed(2);

            const customComponents = [...document.querySelectorAll('.custom-salary-component')].map((row, index) => {
                const name = row.querySelector('.custom-component-name').value.trim();
                const calcType = row.querySelector('.custom-component-calc-type').value;
                const calcValue = Number(row.querySelector('.custom-component-val').value || 0);
                const monthlyAmount = Number(row.querySelector('.custom-component-monthly').value || 0);
                const isDeduction = row.querySelector('.custom-component-deduction').checked ? 1 : 0;
                const slug = name.toUpperCase().replace(/[^A-Z0-9]/g, '_').substring(0, 30) || `ADDL_${index + 1}`;
                return {
                    name,
                    code: slug,
                    calculation_type: calcType,
                    calculation_value: calcValue,
                    monthly_amount: monthlyAmount,
                    is_deduction: isDeduction,
                    sort_order: index + 6
                };
            });

            compensationForm.elements.custom_salary_components.value = JSON.stringify(customComponents);
            const formData = new FormData(compensationForm);
            formData.set('annual_ctc', computedCtc.toFixed(2));

            const response = await fetch('hrms-api.php', { method: 'POST', body: formData, credentials: 'same-origin' });
            const data = await response.json();
            if (!response.ok || data.status !== 'success') {
                throw new Error(data.message || 'Unable to update compensation.');
            }
            if (window.toastr) toastr.success(data.message); else alert(data.message);
            window.location.reload();
        } catch (error) {
            if (window.toastr) toastr.error(error.message); else alert(error.message);
        } finally {
            if (submitBtn) submitBtn.disabled = false;
            if (spinner) spinner.classList.add('d-none');
            if (label) label.textContent = 'Save Payroll';
        }
    });

    // The list's paging is set up before the onboarding form is looked for,
    // since that form is only on the page for those who may add employees.
    // Left below, paging never started for everyone else.
    // Employee Master Pagination Handlers
    window.changeMasterPage = function(page) {
        const form = document.getElementById('employeeMasterFilterForm');
        if (form) {
            document.getElementById('masterPageInput').value = page;
            form.submit();
        }
    };

    $(document).on('click', '.emp-master-per-page-item', function () {
        const val = $(this).data('val');
        const form = document.getElementById('employeeMasterFilterForm');
        if (form) {
            document.getElementById('masterPerPageInput').value = val;
            document.getElementById('masterPageInput').value = 1;
            form.submit();
        }
    });

    $('#empMasterFooterPerPageSelect').on('change', function () {
        const val = $(this).val();
        const form = document.getElementById('employeeMasterFilterForm');
        if (form) {
            document.getElementById('masterPerPageInput').value = val;
            document.getElementById('masterPageInput').value = 1;
            form.submit();
        }
    });

    const masterSummaryText = "<?= $masterTotal > 0 ? ('Showing ' . ($offset + 1) . ' to ' . min($offset + $masterPerPage, $masterTotal) . ' results of ' . $masterTotal) : 'Showing 0 results of 0' ?>";
    $('#empMasterPaginationSummary').text(masterSummaryText);
    const masterPaginationHtml = <?= json_encode(renderSmartPagination($masterTotalPages, $masterPage, 'changeMasterPage')) ?>;
    $('#empMasterPaginationWrapper').html(masterPaginationHtml);

    const form = document.getElementById('employeeOnboardingForm'); if (!form) return;
    const extendedOnboardingReady = <?=json_encode($extendedProfileFieldsReady)?>;
    if (extendedOnboardingReady) {
        const firstNameField = form.elements.first_name;
        const lastNameField = form.elements.last_name;
        const firstNameColumn = firstNameField.closest('.col-md-6');
        const lastNameColumn = lastNameField.closest('.col-md-6');
        firstNameColumn?.classList.replace('col-md-6', 'col-md-4');
        lastNameColumn?.classList.replace('col-md-6', 'col-md-4');
        firstNameColumn?.insertAdjacentHTML('afterend', '<div class="col-md-4"><label class="form-label fw-bold">Middle Name</label><input class="form-control rounded-xl" name="middle_name" maxlength="100"></div>');
        form.elements.mobile?.closest('.col-md-6')?.insertAdjacentHTML('afterend', '<div class="col-12"><label class="rounded-xl border border-slate-200 p-3 d-flex align-items-center gap-3"><input type="checkbox" class="form-check-input m-0" name="is_director" value="1"><span><strong class="d-block text-slate-700">Director or substantial-interest person</strong><small class="text-slate-500">Record this employee classification from the onboarding form.</small></span></label></div>');
        const dobField = form.elements.dob;
        const dobColumn = dobField.closest('.col-md-4');
        dobColumn?.classList.replace('col-md-4', 'col-md-6');
        form.elements.fathers_name?.closest('.col-md-4')?.classList.replace('col-md-4', 'col-md-6');
        form.elements.pan_no?.closest('.col-md-4')?.classList.replace('col-md-4', 'col-md-6');
        dobColumn?.insertAdjacentHTML('afterend', '<div class="col-md-6"><label class="form-label fw-bold">Age</label><input class="form-control rounded-xl bg-slate-50" id="onboardingAge" readonly></div>');
        const updateAge = () => { const value=dobField.value,output=document.getElementById('onboardingAge');if(!value){output.value='';return;}const born=new Date(value+'T00:00:00'),today=new Date();let age=today.getFullYear()-born.getFullYear();if(today.getMonth()<born.getMonth()||(today.getMonth()===born.getMonth()&&today.getDate()<born.getDate()))age--;output.value=age>=0?String(age):''; };
        dobField.addEventListener('change', updateAge);
        const differentlyAbledField = form.elements.differently_abled;
        const differentlyAbledHost = differentlyAbledField?.closest('.col-md-6');
        differentlyAbledHost?.insertAdjacentHTML('beforeend', '<select class="form-select rounded-xl mt-2 d-none w-100" name="differently_abled_type" aria-label="Differently abled type"><option value="">Select differently abled type</option><option value="Physical">Physical</option><option value="Visual">Visual</option><option value="Hearing">Hearing</option><option value="Intellectual or learning">Intellectual or learning</option><option value="Multiple">Multiple</option><option value="Other">Other</option></select>');
        const differentlyAbledType = form.elements.differently_abled_type;
        const toggleDifferentlyAbledType = () => { differentlyAbledType.classList.toggle('d-none', !differentlyAbledField.checked); differentlyAbledType.required = differentlyAbledField.checked; if(!differentlyAbledField.checked)differentlyAbledType.value=''; };
        differentlyAbledField?.addEventListener('change', toggleDifferentlyAbledType);
        toggleDifferentlyAbledType();
        const addressField = form.elements.residential_address;
        addressField.placeholder = 'Address Line 1';
        addressField.closest('.col-12')?.insertAdjacentHTML('afterend', '<div class="col-12"><label class="form-label fw-bold">Address Line 2</label><input class="form-control rounded-xl" name="address_line_2" maxlength="255"></div><div class="col-md-4"><label class="form-label fw-bold">Town / City</label><input class="form-control rounded-xl" name="city" maxlength="100"></div><div class="col-md-4"><label class="form-label fw-bold">State</label><input class="form-control rounded-xl" name="state" maxlength="100"></div><div class="col-md-4"><label class="form-label fw-bold">PIN / Postal Code</label><input class="form-control rounded-xl" name="postal_code" maxlength="20"></div>');
    }
    let step = 1;
    const showStep = value => {
        step = value;
        document.querySelectorAll('.onboarding-panel').forEach(panel => panel.classList.toggle('d-none', Number(panel.dataset.step) !== step));
        document.querySelectorAll('[data-step-indicator]').forEach(indicator => {
            const number = Number(indicator.dataset.stepIndicator);
            indicator.classList.toggle('active', number === step);
            indicator.classList.toggle('complete', number < step);
        });
        document.getElementById('onboardingPrevious').classList.toggle('d-none', step === 1);
        document.getElementById('onboardingNext').classList.toggle('d-none', step === 4);
        document.getElementById('onboardingSubmit').classList.toggle('d-none', step !== 4);
        if (step === 4) {
            updatePaymentModeFields();
        }
    };
    const validateStep = () => {
        const panel = document.querySelector(`.onboarding-panel[data-step="${step}"]`);
        for (const input of panel.querySelectorAll('input:not([disabled]),select:not([disabled]),textarea:not([disabled])')) {
            if (input.closest('.d-none')) continue;
            if (!input.checkValidity()) {
                input.reportValidity();
                return false;
            }
        }
        return true;
    };
    document.getElementById('onboardingNext').addEventListener('click', () => { if (validateStep()) showStep(Math.min(4, step + 1)); });
    document.getElementById('onboardingPrevious').addEventListener('click', () => showStep(Math.max(1, step - 1)));
    const companySelect=document.getElementById('onboardingCompany'), branchSelect=document.getElementById('onboardingBranch'); const filterBranches=()=>{const company=companySelect.value; [...branchSelect.options].forEach((option,index)=>{if(index===0)return; option.hidden=!!company&&option.dataset.company!==company; if(option.hidden&&option.selected)branchSelect.value='';});}; companySelect.addEventListener('change',filterBranches); filterBranches();
    const grossInput=document.getElementById('onboardingMonthlyGross'),annualCtcInput=document.getElementById('annualCtc'),ctcSummary=document.getElementById('ctcSummary');
    // Annual CTC is never entered by HR; it is always 12 x the monthly gross.
    const syncAnnualCtc=()=>{const annual=Number(grossInput.value||0)*12;annualCtcInput.value=annual>0?annual.toFixed(2):'';return annual;};
    // Canonical codes are kept for heads the salary calculator and payroll columns rely on.
    const knownComponentCodes={HRA:'HRA',HOUSE_RENT:'HRA',HOUSE_RENT_ALLOWANCE:'HRA',CONVEYANCE:'CONVEYANCE',CONVEYANCE_ALLOWANCE:'CONVEYANCE',MEDICAL:'MEDICAL',MEDICAL_ALLOWANCE:'MEDICAL',SPECIAL:'SPECIAL',SPECIAL_ALLOWANCE:'SPECIAL',INCENTIVE:'INCENTIVE',INCENTIVES:'INCENTIVE',BASIC:'BASIC',BASIC_SALARY:'BASIC'};
    const componentCodeFromName=(name,position)=>{const slug=String(name||'').toUpperCase().replace(/[^A-Z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,30);return knownComponentCodes[slug]||slug||('ADDL_'+position);};
    if(ctcSummary){const summaryBox=ctcSummary.parentElement;summaryBox.classList.add('flex-wrap','gap-3');summaryBox.querySelector('span:first-child').textContent='Cost to Company';ctcSummary.insertAdjacentHTML('beforebegin','<span class="text-emerald-800">Monthly <strong id="ctcMonthlySummary">₹0.00</strong></span>');ctcSummary.insertAdjacentHTML('beforebegin','<span class="text-emerald-800">Annual</span>');}
    if(statutoryRulesReady){const ctcColumn=grossInput.closest('.col-md-5');ctcColumn?.classList.replace('col-md-5','col-md-6');ctcColumn?.insertAdjacentHTML('afterend','<div class="col-md-6"><label class="form-label fw-bold">PF Category *</label><select class="form-select rounded-xl" name="pf_category" id="onboardingPfCategory" required><option value="">Select PF category</option><option value="e">Employee (E) · PF base ₹15,000</option><option value="w">Worker (W) · PF base ₹7,500</option><option value="ew">Employee / Worker (EW) · PF base ₹7,500</option></select></div>');ctcSummary.closest('.col-12')?.insertAdjacentHTML('afterend','<div class="col-12"><div class="rounded-xl border border-slate-200 bg-slate-50 p-4"><div class="row g-3"><div class="col-sm-4"><div class="text-xs text-uppercase fw-bold text-slate-400">PF Base</div><div class="fw-bold text-slate-800" id="onboardingPfBase">₹0.00</div></div><div class="col-sm-4"><div class="text-xs text-uppercase fw-bold text-slate-400">PF / Month</div><div class="fw-bold text-slate-800" id="onboardingPfAmount">₹0.00</div></div><div class="col-sm-4"><div class="text-xs text-uppercase fw-bold text-slate-400">ESIC / Full Month</div><div class="fw-bold text-slate-800" id="onboardingEsicAmount">₹0.00</div></div></div><div class="text-xs text-slate-500 mt-3">Final ESIC is 1% of attendance-adjusted gross when gross is below ₹21,000.</div></div></div>');}
    const updateStatutoryPreview=()=>{if(!statutoryRulesReady)return;const category=form.elements.pf_category?.value||'',monthlyGross=Number(grossInput.value||0),pfBase=category==='e'?15000:(['w','ew'].includes(category)?7500:0),pfAmount=pfBase*.12,esic=monthlyGross>0&&monthlyGross<21000?monthlyGross*.01:0;document.getElementById('onboardingPfBase').textContent=salaryMoney(pfBase);document.getElementById('onboardingPfAmount').textContent=salaryMoney(pfAmount);document.getElementById('onboardingEsicAmount').textContent=salaryMoney(esic);};
    const updateCtcSummary=()=>{const ctc=syncAnnualCtc(),monthly=document.getElementById('ctcMonthlySummary');if(monthly)monthly.textContent=salaryMoney(Number(grossInput.value||0));if(ctcSummary)ctcSummary.textContent=salaryMoney(ctc);updateStatutoryPreview();};
    form.elements.pf_category?.addEventListener('change',updateStatutoryPreview);
    grossInput.addEventListener('input',updateCtcSummary);updateCtcSummary();
    const salaryRows=document.getElementById('salaryComponentRows');
    let componentCounter=0;
    const refreshComponentCodes=()=>{const rows=[...document.querySelectorAll('.salary-component-row')],used=new Set();rows.forEach((row,index)=>{const codeInput=row.querySelector('.component-code');let code=codeInput.dataset.locked==='1'?codeInput.value.trim().toUpperCase():componentCodeFromName(row.querySelector('.component-name').value,index+1);if(!code)code='ADDL_'+(index+1);let unique=code,suffix=2;while(used.has(unique)){unique=code+'_'+suffix++;}used.add(unique);codeInput.value=unique;});};
    const calculateSalary=(editedRow=null)=>{const ctc=syncAnnualCtc();refreshComponentCodes();const rows=[...document.querySelectorAll('.salary-component-row')],definitions=rows.map(row=>({code:row.querySelector('.component-code').value.trim().toUpperCase(),calculation_type:row.querySelector('.component-type').value,calculation_value:Number(row.querySelector('.component-value').value||0),is_deduction:0})),editedIndex=editedRow?rows.indexOf(editedRow):null,result=HrmsSalaryCalculator.rebalance(definitions,ctc,editedIndex);rows.forEach((row,index)=>{const component=result.components[index],valueInput=row.querySelector('.component-value');if(Math.abs(Number(valueInput.value||0)-component.calculation_value)>.000001)valueInput.value=Number(component.calculation_value.toFixed(6));row.querySelector('.component-monthly').textContent=salaryMoney(component.monthly_amount);row.querySelector('.component-annual').textContent=salaryMoney(component.annual_amount);row.querySelector('.component-balance-badge').classList.toggle('d-none',index!==result.balancingIndex);});const components=result.components.map((component,index)=>({code:rows[index].querySelector('.component-code').value.trim().toUpperCase(),name:rows[index].querySelector('.component-name').value.trim(),calculation_type:component.calculation_type,calculation_value:component.calculation_value,is_deduction:0,sort_order:index}));document.getElementById('salaryComponentsJson').value=JSON.stringify(components);ctcSummary.textContent=salaryMoney(ctc);const status=document.getElementById('salaryBalanceStatus');if(status){status.textContent=result.wasClamped?'An entered value was reduced to keep earnings within Annual CTC.':(result.balanced?'Earning heads match Annual CTC.':'Add an earning head to match Annual CTC.');status.className='text-xs mt-2 '+(result.balanced?'text-emerald-700':'text-rose-600');}updateCtcSummary();};
    ctcSummary.closest('.col-12')?.insertAdjacentHTML('beforeend','<div id="salaryBalanceStatus" class="text-xs text-emerald-700 mt-2">Earning heads match Annual CTC.</div>');
    const addComponent=(component={})=>{componentCounter++;const row=document.createElement('tr');row.className='salary-component-row';const locked=component.code==='BASIC';row.innerHTML=`<td class="px-4"><div class="d-flex gap-2 align-items-center"><input type="hidden" class="component-code" value="${component.code||''}" data-locked="${locked?'1':'0'}"><input class="form-control form-control-sm component-name" value="${component.name||''}" placeholder="Name" required><span class="badge bg-emerald-100 text-emerald-700 d-none component-balance-badge">Auto balance</span></div></td><td><select class="form-select form-select-sm component-type"><option value="ctc_percentage" ${component.type==='ctc_percentage'?'selected':''}>% of CTC</option><option value="basic_percentage" ${component.type==='basic_percentage'?'selected':''}>% of Basic</option><option value="fixed" ${component.type==='fixed'?'selected':''}>Fixed monthly</option></select></td><td><input type="number" class="form-control form-control-sm component-value" value="${component.value??0}" min="0" step="0.01" required></td><td class="component-monthly fw-semibold text-slate-700">₹0.00</td><td class="component-annual fw-semibold text-slate-700">₹0.00</td><td class="px-4"><button type="button" class="btn btn-sm btn-icon btn-outline-danger rounded-lg component-remove" ${locked?'disabled':''}><i class="ti ti-trash"></i></button></td>`;salaryRows.appendChild(row);row.querySelectorAll('input,select').forEach(input=>input.addEventListener('input',()=>calculateSalary(row)));row.querySelector('.component-remove').addEventListener('click',()=>{row.remove();calculateSalary();});calculateSalary(row);};
    grossInput.addEventListener('input',()=>calculateSalary());
    document.getElementById('addSalaryComponent').addEventListener('click',()=>addComponent({code:'',name:'',type:'fixed',value:0}));
    addComponent({code:'BASIC',name:'Basic Salary',type:'ctc_percentage',value:60});
    addComponent({code:'HRA',name:'House Rent Allowance',type:'ctc_percentage',value:40});
    addComponent({code:'SPECIAL',name:'Special Allowance',type:'fixed',value:0});

    const paymentMode = document.getElementById('paymentMode');
    const updatePaymentModeFields = () => {
        if (!paymentMode) return;
        const mode = paymentMode.value || 'bank_transfer';
        const isBank = ['direct_deposit', 'bank_transfer'].includes(mode);
        const isUpi = mode === 'upi';
        const isCheque = mode === 'cheque';
        const isCash = mode === 'cash';

        const bankFields = document.getElementById('bankFields');
        const upiFields = document.getElementById('upiFields');
        const chequeFields = document.getElementById('chequeFields');
        const cashFields = document.getElementById('cashFields');

        if (bankFields) bankFields.classList.toggle('d-none', !isBank);
        if (upiFields) upiFields.classList.toggle('d-none', !isUpi);
        if (chequeFields) chequeFields.classList.toggle('d-none', !isCheque);
        if (cashFields) cashFields.classList.toggle('d-none', !isCash);

        document.querySelectorAll('.bank-required').forEach(input => {
            input.required = isBank;
            if (!isBank) input.setCustomValidity('');
        });
        document.querySelectorAll('.upi-required').forEach(input => {
            input.required = isUpi;
            if (!isUpi) input.setCustomValidity('');
        });
        document.querySelectorAll('.cheque-required').forEach(input => {
            input.required = isCheque;
            if (!isCheque) input.setCustomValidity('');
        });

        const fullName = `${form.elements.first_name?.value || ''} ${form.elements.last_name?.value || ''}`.trim();
        const bankHolder = document.getElementById('bankAccountHolderName');
        if (isBank && bankHolder && !bankHolder.value.trim() && fullName) {
            bankHolder.value = fullName;
        }
        const upiHolder = document.getElementById('onboardingUpiHolderName');
        if (isUpi && upiHolder && !upiHolder.value.trim() && fullName) {
            upiHolder.value = fullName;
        }
        const chequePayee = document.getElementById('onboardingChequePayeeName');
        if (isCheque && chequePayee && !chequePayee.value.trim() && fullName) {
            chequePayee.value = fullName;
        }
    };
    paymentMode?.addEventListener('change', updatePaymentModeFields);
    paymentMode?.addEventListener('input', updatePaymentModeFields);
    document.getElementById('employeeOnboardingModal')?.addEventListener('show.bs.modal', updatePaymentModeFields);
    updatePaymentModeFields();

    const existingUserSelect = document.getElementById('onboardingExistingUser');
    const portalAccessCheckbox = document.getElementById('onboardingPortalAccess');
    existingUserSelect?.addEventListener('change', () => {
        const selectedOpt = existingUserSelect.selectedOptions[0];
        if (existingUserSelect.value && selectedOpt) {
            portalAccessCheckbox.checked = false;
            portalAccessCheckbox.disabled = true;
            const userName = selectedOpt.dataset.name || '';
            const userEmail = selectedOpt.dataset.email || '';
            const userCompany = selectedOpt.dataset.company || '';
            const userBranch = selectedOpt.dataset.branch || '';
            if (userName && !form.elements.first_name.value) {
                const parts = userName.trim().split(/\s+/);
                form.elements.first_name.value = parts[0] || '';
                if (parts.length > 1 && !form.elements.last_name.value) {
                    form.elements.last_name.value = parts.slice(1).join(' ');
                }
            }
            if (userEmail && !form.elements.work_email.value) {
                form.elements.work_email.value = userEmail;
            }
            if (userCompany && !form.elements.company_id.value) {
                form.elements.company_id.value = userCompany;
                filterBranches();
            }
            if (userBranch && !form.elements.branch_id.value) {
                form.elements.branch_id.value = userBranch;
            }
        } else {
            portalAccessCheckbox.disabled = false;
        }
    });

    form.addEventListener('submit', async event => {
        event.preventDefault();
        // Ensure all 4 wizard steps are valid before sending
        for (let s = 1; s <= 4; s++) {
            const panel = document.querySelector(`.onboarding-panel[data-step="${s}"]`);
            for (const input of panel.querySelectorAll('input:not([disabled]),select:not([disabled]),textarea:not([disabled])')) {
                if (input.closest('.d-none')) continue;
                if (!input.checkValidity()) {
                    showStep(s);
                    input.reportValidity();
                    return;
                }
            }
        }
        calculateSalary();
        const button = document.getElementById('onboardingSubmit');
        button.disabled = true;
        button.querySelector('.spinner-border').classList.remove('d-none');
        try {
            const response = await fetch('hrms-api.php', { method: 'POST', body: new FormData(form), credentials: 'same-origin' });
            const text = await response.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('HRMS API raw response:', text);
                throw new Error('Server returned invalid response: ' + (text.slice(0, 120) || 'empty'));
            }
            if (!response.ok || data.status !== 'success') {
                throw new Error(data.message || 'Unable to onboard employee.');
            }
            const onboardingModalEl = document.getElementById('employeeOnboardingModal');
            if (onboardingModalEl) {
                const modalInstance = bootstrap.Modal.getInstance(onboardingModalEl) || bootstrap.Modal.getOrCreateInstance(onboardingModalEl);
                modalInstance.hide();
            }
            let message = `${data.message}<br><strong>Employee ID:</strong> ${data.employee_code}`;
            if (data.temporary_password) {
                message += `<br><strong>One-time password:</strong> <code>${data.temporary_password}</code>`;
            }
            if (window.Swal) {
                await Swal.fire({ icon: 'success', title: 'Employee created', html: message, confirmButtonColor: '#059669' });
            } else {
                alert(message.replace(/<[^>]+>/g, ' '));
            }
            window.location.reload();
        } catch (error) {
            console.error('Onboarding error:', error);
            if (window.toastr) toastr.error(error.message);
            else alert(error.message);
            button.disabled = false;
            button.querySelector('.spinner-border').classList.add('d-none');
        }
    });

});
</script>
<?php endSection(); ?>
