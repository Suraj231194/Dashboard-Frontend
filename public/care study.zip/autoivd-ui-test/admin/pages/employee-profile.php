<?php
if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once __DIR__ . '/../hrms/hrms_common.php';
if (!defined('PAYROLL_CONTEXT')) {
    define('PAYROLL_CONTEXT', true);
}
require_once __DIR__ . '/../payroll/payroll_common.php';

$employeeProfile = hrmsCurrentEmployee($conn, (int) ($_SESSION['user_id'] ?? 0));
$leaveBalances = [];
$recentLeaves = [];
$activeResignation = null;
$profilePhoto = null;
$reimbursementClaims = [];
$reimbursementCategories = payrollReimbursementCategories();

if ($employeeProfile) {
    $leaveBalances = hrmsLeaveBalances($conn, $employeeProfile);
    $employeeId = (int) $employeeProfile['id'];
    $leaveStmt = $conn->prepare(
        "SELECT application.application_no, leave_type.name AS leave_type_name,
                application.start_date, application.end_date, application.total_days,
                application.status, application.submitted_at
         FROM hr_leave_applications application
         INNER JOIN hr_leave_types leave_type ON leave_type.id = application.leave_type_id
         WHERE application.employee_id = ?
         ORDER BY application.submitted_at DESC LIMIT 5"
    );
    $leaveStmt->bind_param('i', $employeeId);
    $leaveStmt->execute();
    $recentLeaves = $leaveStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $leaveStmt->close();

    $resignationStmt = $conn->prepare(
        "SELECT request_no, resignation_date, requested_last_working_date,
                approved_last_working_date, status, submitted_at
         FROM hr_resignation_requests
         WHERE employee_id = ?
         ORDER BY submitted_at DESC LIMIT 1"
    );
    $resignationStmt->bind_param('i', $employeeId);
    $resignationStmt->execute();
    $activeResignation = $resignationStmt->get_result()->fetch_assoc() ?: null;
    $resignationStmt->close();

    $photoStmt = $conn->prepare(
        "SELECT id FROM employee_documents
         WHERE employee_id = ? AND document_type = 'profile_photo'
           AND status = 1 AND deleted_at IS NULL
         ORDER BY id DESC LIMIT 1"
    );
    $photoStmt->bind_param('i', $employeeId);
    $photoStmt->execute();
    $profilePhoto = $photoStmt->get_result()->fetch_assoc() ?: null;
    $photoStmt->close();

    if (payrollSchemaReady($conn)) {
        $claimStmt = $conn->prepare(
            "SELECT id, claim_number, expense_name, expense_date, amount, status, reimbursement_status, submitted_at
             FROM payroll_reimbursements WHERE employee_id = ?
             ORDER BY submitted_at DESC LIMIT 5"
        );
        $claimStmt->bind_param('i', $employeeId);
        $claimStmt->execute();
        $reimbursementClaims = $claimStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $claimStmt->close();
    }
}

$statusLabels = [0 => 'Inactive', 1 => 'Active', 2 => 'Resigned'];
$statusClasses = [0 => 'bg-slate-100 text-slate-600', 1 => 'bg-emerald-100 text-emerald-700', 2 => 'bg-amber-100 text-amber-700'];
$paymentLabels = [
    'direct_deposit' => 'Direct Deposit',
    'bank_transfer' => 'Bank Transfer',
    'cheque' => 'Cheque',
    'cash' => 'Cash',
];
$displayValue = static fn($value, string $fallback = 'Not provided') => trim((string) $value) !== '' ? htmlspecialchars((string) $value) : $fallback;
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-6">
        <div>
            <h2 class="mb-1 text-2xl fw-bold text-slate-900" style="font-family: 'Sora', sans-serif;">Employee Profile</h2>
            <p class="mb-0 text-sm text-slate-500">Your HRMS identity, employment details, leave balance and offboarding access.</p>
        </div>
        <?php if ($employeeProfile): ?>
            <div class="d-flex flex-wrap gap-2">
                <a href="index.php?page=leave-management" class="btn btn-primary rounded-xl px-4 d-inline-flex align-items-center gap-2">
                    <i class="ti ti-calendar-plus"></i> Apply Leave
                </a>
                <?php if (payrollSchemaReady($conn)): ?>
                    <button type="button" class="btn btn-primary rounded-xl px-4 d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#claimReimbursementModal">
                        <i class="ti ti-receipt-refund"></i> Claim Reimbursement
                    </button>
                <?php endif; ?>
                <a href="index.php?page=offboarding&amp;open=resign" class="btn btn-outline-danger rounded-xl px-4 d-inline-flex align-items-center gap-2">
                    <i class="ti ti-logout-2"></i> Resign
                </a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!$employeeProfile): ?>
        <div class="card border border-slate-200 shadow-sm rounded-2xl">
            <div class="card-body py-12 text-center">
                <span class="d-inline-flex align-items-center justify-content-center rounded-circle bg-amber-50 text-amber-600 mb-4" style="width:64px;height:64px;">
                    <i class="ti ti-id-off fs-2"></i>
                </span>
                <h4 class="text-slate-900 fw-bold">Employee profile not linked</h4>
                <p class="text-slate-500 mb-0">Your login is active, but it is not connected to an employee record. Contact Human Resources.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6">
            <div class="card-body p-5 p-lg-6">
                <div class="d-flex flex-column flex-md-row align-items-md-center gap-4">
                    <div class="flex-shrink-0">
                        <?php if ($profilePhoto): ?>
                            <img src="hrms-document.php?id=<?= (int) $profilePhoto['id'] ?>" alt="Employee photo" class="rounded-2xl border border-slate-200 shadow-sm" style="width:96px;height:96px;object-fit:cover;">
                        <?php else: ?>
                            <div class="rounded-2xl bg-emerald-50 text-emerald-700 d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width:96px;height:96px;font-size:2rem;">
                                <?= htmlspecialchars(strtoupper(substr((string) $employeeProfile['first_name'], 0, 1) . substr((string) $employeeProfile['last_name'], 0, 1))) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex-grow-1 min-w-0">
                        <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
                            <h3 class="mb-0 text-slate-900 fw-bold" style="font-family:'Sora',sans-serif;">
                                <?= $displayValue(trim(($employeeProfile['solutation'] ? $employeeProfile['solutation'] . ' ' : '') . $employeeProfile['first_name'] . ' ' . $employeeProfile['last_name'])) ?>
                            </h3>
                            <span class="badge rounded-pill <?= $statusClasses[(int) $employeeProfile['status']] ?? 'bg-slate-100 text-slate-600' ?> px-3 py-2">
                                <?= htmlspecialchars($statusLabels[(int) $employeeProfile['status']] ?? 'Unknown') ?>
                            </span>
                        </div>
                        <p class="text-slate-500 mb-3"><?= $displayValue($employeeProfile['designation_name'], 'Designation not assigned') ?></p>
                        <div class="d-flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-600">
                            <span><i class="ti ti-id me-1 text-emerald-600"></i><?= $displayValue($employeeProfile['emp_code']) ?></span>
                            <span><i class="ti ti-mail me-1 text-emerald-600"></i><?= $displayValue($employeeProfile['work_email']) ?></span>
                            <span><i class="ti ti-phone me-1 text-emerald-600"></i><?= $displayValue($employeeProfile['contact_no']) ?></span>
                        </div>
                    </div>
                    <div class="rounded-2xl bg-slate-50 border border-slate-200 p-4 flex-shrink-0" style="min-width:240px;">
                        <div class="text-xs fw-bold text-uppercase text-slate-400 mb-1">Organization</div>
                        <div class="fw-bold text-slate-800 mb-2"><?= $displayValue($employeeProfile['company_name']) ?></div>
                        <div class="text-sm text-slate-500"><i class="ti ti-building-branch me-1"></i><?= $displayValue($employeeProfile['branch_name'], 'Branch not assigned') ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-6">
            <?php foreach (array_filter($leaveBalances, static fn(array $balance): bool => !empty($balance['eligible'])) as $balance): ?>
                <div class="col-sm-6 col-xl-3">
                    <div class="card h-100 border border-slate-200 shadow-sm rounded-2xl">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-start justify-content-between gap-3 mb-4">
                                <div>
                                    <div class="text-sm fw-bold text-slate-800"><?= htmlspecialchars($balance['name']) ?></div>
                                    <div class="text-xs text-slate-400 mt-1">Available balance</div>
                                </div>
                                <span class="rounded-xl" style="width:12px;height:12px;background:<?= htmlspecialchars($balance['color']) ?>;"></span>
                            </div>
                            <div class="d-flex align-items-end justify-content-between">
                                <div class="text-3xl fw-bold text-slate-900"><?= number_format((float) $balance['remaining'], 1) ?></div>
                                <div class="text-xs text-slate-500 text-end">Booked <?= number_format((float) $balance['current_booking'], 1) ?><br>Allocated <?= number_format((float) $balance['allocated'], 1) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="row g-4 mb-6">
            <div class="col-xl-6">
                <div class="card h-100 border border-slate-200 shadow-sm rounded-2xl">
                    <div class="card-header bg-white border-bottom border-slate-100 p-5">
                        <h5 class="mb-1 fw-bold text-slate-900">Personal Information</h5>
                        <p class="mb-0 text-sm text-slate-500">Employee onboarding and contact details.</p>
                    </div>
                    <div class="card-body p-5">
                        <div class="row g-4">
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Date of Birth</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['dob']) ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Father's Name</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['fathers_name']) ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">PAN</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['pan_no']) ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Personal Email</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['personal_email']) ?></div></div>
                            <div class="col-12"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Residential Address</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['local_address']) ?></div></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card h-100 border border-slate-200 shadow-sm rounded-2xl">
                    <div class="card-header bg-white border-bottom border-slate-100 p-5">
                        <h5 class="mb-1 fw-bold text-slate-900">Employment & Compensation</h5>
                        <p class="mb-0 text-sm text-slate-500">Organization placement and onboarding salary information.</p>
                    </div>
                    <div class="card-body p-5">
                        <div class="row g-4">
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Department</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['department_name']) ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Work Location</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['work_location']) ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Date of Joining</div><div class="text-slate-800 fw-semibold"><?= $displayValue($employeeProfile['date_of_join']) ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Annual CTC</div><div class="text-slate-800 fw-semibold"><?= $employeeProfile['annual_ctc'] !== null ? '₹' . number_format((float) $employeeProfile['annual_ctc'], 2) : 'Not provided' ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Payment Mode</div><div class="text-slate-800 fw-semibold"><?= htmlspecialchars($paymentLabels[$employeeProfile['payment_mode']] ?? 'Not provided') ?></div></div>
                            <div class="col-sm-6"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Portal Access</div><div class="text-slate-800 fw-semibold"><?= (int) $employeeProfile['portal_access'] === 1 ? 'Enabled' : 'Not enabled' ?></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-xl-8">
                <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                    <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex align-items-center justify-content-between">
                        <div><h5 class="mb-1 fw-bold text-slate-900">Recent Leave Applications</h5><p class="mb-0 text-sm text-slate-500">Your five most recent requests.</p></div>
                        <a href="index.php?page=leave-management" class="btn btn-sm btn-outline-primary rounded-lg">View all</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table mb-0 align-middle">
                            <thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Application</th><th class="py-3 text-xs text-uppercase text-slate-500">Leave</th><th class="py-3 text-xs text-uppercase text-slate-500">Dates</th><th class="py-3 text-xs text-uppercase text-slate-500">Days</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Status</th></tr></thead>
                            <tbody>
                            <?php if (!$recentLeaves): ?>
                                <tr><td colspan="5" class="text-center text-slate-500 py-8">No leave applications yet.</td></tr>
                            <?php else: foreach ($recentLeaves as $leave): ?>
                                <tr><td class="px-5 py-4 fw-bold text-slate-800"><?= htmlspecialchars($leave['application_no']) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars($leave['leave_type_name']) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars($leave['start_date']) ?> – <?= htmlspecialchars($leave['end_date']) ?></td><td class="py-4 text-slate-600"><?= number_format((float) $leave['total_days'], 1) ?></td><td class="px-5 py-4"><span class="badge rounded-pill bg-slate-100 text-slate-700"><?= htmlspecialchars(ucfirst($leave['status'])) ?></span></td></tr>
                            <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card h-100 border border-slate-200 shadow-sm rounded-2xl">
                    <div class="card-body p-5 d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <h5 class="fw-bold text-slate-900 mb-0">Resignation &amp; Offboarding</h5>
                                <span class="badge bg-rose-50 text-rose-700 border border-rose-200 rounded-lg px-2 py-1 text-xs fw-bold">Employee Exit</span>
                            </div>
                            <p class="text-sm text-slate-500 mb-4">Submit a formal resignation request to HR and initiate your offboarding clearance process.</p>
                            <?php if ($activeResignation): ?>
                                <div class="rounded-xl bg-slate-50 border border-slate-200 p-4 mb-4">
                                    <div class="text-xs text-uppercase fw-bold text-slate-400 mb-1"><?= htmlspecialchars($activeResignation['request_no']) ?></div>
                                    <div class="fw-bold text-slate-800 mb-1"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $activeResignation['status']))) ?></div>
                                    <div class="text-sm text-slate-500">Requested last day: <?= htmlspecialchars($activeResignation['requested_last_working_date']) ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <a href="index.php?page=offboarding&amp;open=resign" class="btn btn-outline-danger rounded-xl w-100 d-flex align-items-center justify-content-center gap-2">
                            <i class="ti ti-logout-2"></i> <?= $activeResignation ? 'View Resignation Status' : 'Resign' ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <?php if (payrollSchemaReady($conn)): ?>
            <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mt-6">
                <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex align-items-center justify-content-between">
                    <div><h5 class="mb-1 fw-bold text-slate-900">Recent Reimbursement Claims</h5><p class="mb-0 text-sm text-slate-500">Your five most recent expense claims.</p></div>
                    <button type="button" class="btn btn-sm btn-outline-primary rounded-lg" data-bs-toggle="modal" data-bs-target="#claimReimbursementModal">New claim</button>
                </div>
                <div class="table-responsive"><table class="table mb-0 align-middle"><thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Claim</th><th class="py-3 text-xs text-uppercase text-slate-500">Expense</th><th class="py-3 text-xs text-uppercase text-slate-500">Date</th><th class="py-3 text-xs text-uppercase text-slate-500">Amount</th><th class="py-3 text-xs text-uppercase text-slate-500">Approval</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500">To Be Reimbursed</th></tr></thead><tbody>
                    <?php if (!$reimbursementClaims): ?><tr><td colspan="6" class="text-center py-8 text-slate-500">No reimbursement claims submitted yet.</td></tr>
                    <?php else: foreach($reimbursementClaims as $claim):
                        $approvalClass=['pending'=>'bg-amber-100 text-amber-700','approved'=>'bg-emerald-100 text-emerald-700','rejected'=>'bg-rose-100 text-rose-700'][$claim['status']]??'bg-slate-100 text-slate-600';
                        $paymentClass=['pending'=>'bg-amber-100 text-amber-700','paid'=>'bg-emerald-100 text-emerald-700','rejected'=>'bg-rose-100 text-rose-700'][$claim['reimbursement_status']]??'bg-slate-100 text-slate-600'; ?>
                        <tr><td class="px-5 py-4 fw-bold text-slate-800"><?=htmlspecialchars($claim['claim_number'])?></td><td class="py-4 text-slate-600"><?=htmlspecialchars($claim['expense_name'])?></td><td class="py-4 text-slate-600"><?=htmlspecialchars(date('d M Y',strtotime($claim['expense_date'])))?></td><td class="py-4 fw-bold text-slate-800">₹<?=payrollMoney($claim['amount'])?></td><td class="py-4"><span class="badge rounded-pill <?=$approvalClass?>"><?=htmlspecialchars(ucfirst($claim['status']))?></span></td><td class="px-5 py-4"><span class="badge rounded-pill <?=$paymentClass?>"><?=htmlspecialchars(ucfirst($claim['reimbursement_status']))?></span></td></tr>
                    <?php endforeach; endif; ?>
                </tbody></table></div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (hrmsCan($conn, 'hrms_employee_master_view') || hrmsCan($conn, 'hrms_leave_manage') || hrmsCan($conn, 'hrms_offboarding_manage') || hrmsCan($conn, 'hrms_attendance_view') || hrmsCan($conn, 'hrms_shift_manage')): ?>
        <div class="card border border-slate-200 shadow-sm rounded-2xl mt-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-5">
                <h5 class="mb-1 fw-bold text-slate-900">HR Workspace</h5>
                <p class="mb-0 text-sm text-slate-500">HRMS tools available for your assigned role and organization.</p>
            </div>
            <div class="card-body p-5">
                <div class="row g-3">
                    <?php if (hrmsCan($conn, 'hrms_employee_master_view')): ?><div class="col-sm-6 col-xl"><a href="index.php?page=employee-master" class="d-flex align-items-center gap-3 rounded-xl border border-slate-200 p-4 text-decoration-none h-100"><span class="rounded-lg bg-emerald-50 text-emerald-700 d-flex align-items-center justify-content-center" style="width:40px;height:40px"><i class="ti ti-users"></i></span><span><strong class="d-block text-slate-800">Employee Master</strong><small class="text-slate-500">Profiles & onboarding</small></span></a></div><?php endif; ?>
                    <?php if (hrmsCan($conn, 'hrms_leave_manage')): ?><div class="col-sm-6 col-xl"><a href="index.php?page=leave-management" class="d-flex align-items-center gap-3 rounded-xl border border-slate-200 p-4 text-decoration-none h-100"><span class="rounded-lg bg-sky-50 text-sky-700 d-flex align-items-center justify-content-center" style="width:40px;height:40px"><i class="ti ti-calendar-check"></i></span><span><strong class="d-block text-slate-800">Leave</strong><small class="text-slate-500">Review & allocate</small></span></a></div><?php endif; ?>
                    <?php if (hrmsCan($conn, 'hrms_offboarding_manage')): ?><div class="col-sm-6 col-xl"><a href="index.php?page=offboarding" class="d-flex align-items-center gap-3 rounded-xl border border-slate-200 p-4 text-decoration-none h-100"><span class="rounded-lg bg-rose-50 text-rose-700 d-flex align-items-center justify-content-center" style="width:40px;height:40px"><i class="ti ti-door-exit"></i></span><span><strong class="d-block text-slate-800">Offboarding</strong><small class="text-slate-500">Requests & interviews</small></span></a></div><?php endif; ?>
                    <?php if (hrmsCan($conn, 'hrms_attendance_view')): ?><div class="col-sm-6 col-xl"><a href="index.php?page=attendance-management" class="d-flex align-items-center gap-3 rounded-xl border border-slate-200 p-4 text-decoration-none h-100"><span class="rounded-lg bg-amber-50 text-amber-700 d-flex align-items-center justify-content-center" style="width:40px;height:40px"><i class="ti ti-fingerprint"></i></span><span><strong class="d-block text-slate-800">Attendance</strong><small class="text-slate-500">Biometric dashboard</small></span></a></div><?php endif; ?>
                    <?php if (hrmsCan($conn, 'hrms_shift_manage')): ?><div class="col-sm-6 col-xl"><a href="index.php?page=shift-management" class="d-flex align-items-center gap-3 rounded-xl border border-slate-200 p-4 text-decoration-none h-100"><span class="rounded-lg bg-violet-50 text-violet-700 d-flex align-items-center justify-content-center" style="width:40px;height:40px"><i class="ti ti-clock-cog"></i></span><span><strong class="d-block text-slate-800">Shifts</strong><small class="text-slate-500">Hours & rules</small></span></a></div><?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($employeeProfile && payrollSchemaReady($conn)): ?>
        <div class="modal fade animate__animated fadeIn" id="claimReimbursementModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                    <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                        <div class="flex items-center gap-3">
                            <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                                <i class="ti ti-receipt-refund text-xl"></i>
                            </span>
                            <div>
                                <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Claim Reimbursement</h5>
                                <p class="m-0 text-sm font-medium text-slate-500">Add the expense details and attach its receipt.</p>
                            </div>
                        </div>
                        <button type="button"
                            class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                            data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-xl"></i>
                        </button>
                    </div>
                    <form id="claimReimbursementForm" enctype="multipart/form-data" novalidate>
                        <input type="hidden" name="action" value="submit_reimbursement">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                        <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                                <div>
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementExpenseName">Expense Name <strong class="text-rose-500">*</strong></label>
                                    <input class="input-theme" id="reimbursementExpenseName" name="expense_name" placeholder="e.g. Client Travel / Office Supplies" maxlength="255" required>
                                    <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="expenseNameInlineError">Please enter an expense name of at least 3 characters.</div>
                                </div>
                                <div>
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementExpenseDate">Expense Date <strong class="text-rose-500">*</strong></label>
                                    <input class="input-theme" type="date" id="reimbursementExpenseDate" name="expense_date" value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" required>
                                    <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="expenseDateInlineError">Please select a valid expense date.</div>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                                <div>
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementMerchant">Merchant <strong class="text-rose-500">*</strong></label>
                                    <input class="input-theme" id="reimbursementMerchant" name="merchant" placeholder="e.g. Uber / Amazon / Hotel" maxlength="255" required>
                                    <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="merchantInlineError">Please enter a merchant name.</div>
                                </div>
                                <div>
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementCategory">Category <strong class="text-rose-500">*</strong></label>
                                    <select class="input-theme" id="reimbursementCategory" name="category" required>
                                        <option value="">Select expense category</option>
                                        <?php foreach ($reimbursementCategories as $category): ?>
                                            <option value="<?= htmlspecialchars($category) ?>"><?= htmlspecialchars($category) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="categoryInlineError">Please select an expense category.</div>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                                <div>
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementAmount">Amount (₹) <strong class="text-rose-500">*</strong></label>
                                    <input class="input-theme" type="number" id="reimbursementAmount" name="amount" min="0.01" step="0.01" placeholder="Enter amount (₹)" required>
                                    <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="amountInlineError">Please enter a valid amount greater than 0.</div>
                                </div>
                                <div>
                                    <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementReceipt">Attach Receipt <strong class="text-rose-500">*</strong></label>
                                    <input class="input-theme" type="file" id="reimbursementReceipt" name="receipt" accept="application/pdf,image/jpeg,image/png,image/webp" required>
                                    <small class="d-block mt-1 text-slate-400 text-xs">PDF or image, maximum 10 MB.</small>
                                    <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="receiptInlineError">Please attach a receipt file.</div>
                                </div>
                            </div>

                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800" for="reimbursementDescription">Description <strong class="text-rose-500">*</strong></label>
                                <textarea class="input-theme min-h-[90px]" id="reimbursementDescription" name="description" placeholder="Describe the business expense in detail (minimum 5 characters)" maxlength="3000" rows="3" required></textarea>
                                <div class="invalid-feedback text-rose-600 text-xs mt-1 d-none" id="reimbursementDescriptionError">Please provide a description of at least 5 characters.</div>
                            </div>
                        </div>
                        <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                            <button type="button"
                                class="inline-flex h-10 min-w-28 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                                data-bs-dismiss="modal" id="cancelClaimBtn">Cancel</button>
                            <button type="submit"
                                class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                id="submitClaimBtn">
                                <span class="spinner-border spinner-border-sm d-none" id="submitClaimSpinner" role="status" aria-hidden="true"></span>
                                <i class="ti ti-check text-lg" id="submitClaimIcon"></i>
                                <span id="submitClaimText">Submit Claim</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($employeeProfile && payrollSchemaReady($conn)): startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('claimReimbursementForm');
    const modalEl = document.getElementById('claimReimbursementModal');
    const submitBtn = document.getElementById('submitClaimBtn');
    const submitSpinner = document.getElementById('submitClaimSpinner');
    const submitIcon = document.getElementById('submitClaimIcon');
    const submitText = document.getElementById('submitClaimText');
    const cancelBtn = document.getElementById('cancelClaimBtn');
    const descInput = document.getElementById('reimbursementDescription');
    const descError = document.getElementById('reimbursementDescriptionError');
    const notify = (type, message) => window.toastr ? toastr[type](message) : alert(message);

    // Helper: open modal if query parameter present
    if (new URL(window.location.href).searchParams.get('open') === 'claim-reimbursement') {
        if (modalEl) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
            const cleanUrl = new URL(window.location.href);
            cleanUrl.searchParams.delete('open');
            history.replaceState({}, '', cleanUrl);
        }
    }

    // Clear inline error on description input
    descInput?.addEventListener('input', () => {
        if (descInput.value.trim().length >= 5) {
            descInput.classList.remove('is-invalid', '!border-rose-500', 'border-rose-500');
            descError?.classList.add('d-none');
            descError?.classList.remove('d-block');
        }
    });

    // Clear inline error on other inputs
    form?.querySelectorAll('input, select').forEach(input => {
        input.addEventListener('input', () => {
            input.classList.remove('is-invalid', '!border-rose-500', 'border-rose-500');
            const err = input.parentElement.querySelector('.invalid-feedback');
            if (err) {
                err.classList.add('d-none');
                err.classList.remove('d-block');
            }
        });
    });

    // Handle Form Submit
    form?.addEventListener('submit', async event => {
        event.preventDefault();

        // 1. Client-side inline validation
        let hasError = false;

        // Validate Description
        const descValue = (descInput?.value || '').trim();
        if (descValue.length < 5) {
            hasError = true;
            descInput?.classList.add('is-invalid', '!border-rose-500');
            if (descError) {
                descError.textContent = descValue.length === 0 
                    ? 'Description is required. Please provide expense details.' 
                    : 'Please provide a description of at least 5 characters.';
                descError.classList.remove('d-none');
                descError.classList.add('d-block');
            }
        } else {
            descInput?.classList.remove('is-invalid', '!border-rose-500');
            descError?.classList.add('d-none');
            descError?.classList.remove('d-block');
        }

        // Validate Expense Name
        const expName = document.getElementById('reimbursementExpenseName');
        const expNameErr = document.getElementById('expenseNameInlineError');
        if (!expName || expName.value.trim().length < 3) {
            hasError = true;
            expName?.classList.add('is-invalid', '!border-rose-500');
            expNameErr?.classList.remove('d-none');
        }

        // Validate Merchant
        const merchant = document.getElementById('reimbursementMerchant');
        const merchantErr = document.getElementById('merchantInlineError');
        if (!merchant || merchant.value.trim().length < 2) {
            hasError = true;
            merchant?.classList.add('is-invalid', '!border-rose-500');
            merchantErr?.classList.remove('d-none');
        }

        // Validate Category
        const category = document.getElementById('reimbursementCategory');
        const categoryErr = document.getElementById('categoryInlineError');
        if (!category || !category.value) {
            hasError = true;
            category?.classList.add('is-invalid', '!border-rose-500');
            categoryErr?.classList.remove('d-none');
        }

        // Validate Amount
        const amount = document.getElementById('reimbursementAmount');
        const amountErr = document.getElementById('amountInlineError');
        if (!amount || Number(amount.value) <= 0) {
            hasError = true;
            amount?.classList.add('is-invalid', '!border-rose-500');
            amountErr?.classList.remove('d-none');
        }

        // Validate Receipt
        const receipt = document.getElementById('reimbursementReceipt');
        const receiptErr = document.getElementById('receiptInlineError');
        if (!receipt || !receipt.files || !receipt.files.length) {
            hasError = true;
            receipt?.classList.add('is-invalid', '!border-rose-500');
            receiptErr?.classList.remove('d-none');
        }

        if (hasError) {
            if (descValue.length < 5) {
                descInput?.focus();
                notify('error', 'Please provide a description of at least 5 characters.');
            } else {
                notify('error', 'Please fill in all required fields correctly.');
            }
            return;
        }

        // 2. Set Submitting state
        if (submitBtn) submitBtn.disabled = true;
        if (cancelBtn) cancelBtn.disabled = true;
        if (submitSpinner) submitSpinner.classList.remove('d-none');
        if (submitIcon) submitIcon.classList.add('d-none');
        if (submitText) submitText.textContent = 'Submitting...';

        try {
            const response = await fetch('payroll-api.php', {
                method: 'POST',
                body: new FormData(form),
                credentials: 'same-origin'
            });
            const data = await response.json().catch(() => ({ status: 'error', message: 'Invalid response from server.' }));

            if (!response.ok || data.status !== 'success') {
                throw new Error(data.message || 'Unable to submit reimbursement claim.');
            }

            // 3. Success state & Auto close modal
            if (submitText) submitText.textContent = 'Submitted!';
            if (submitSpinner) submitSpinner.classList.add('d-none');
            if (submitIcon) {
                submitIcon.className = 'ti ti-check text-lg';
                submitIcon.classList.remove('d-none');
            }

            notify('success', data.message || 'Reimbursement claim submitted successfully.');

            // Auto close modal
            if (modalEl) {
                const modalInstance = bootstrap.Modal.getInstance(modalEl) || bootstrap.Modal.getOrCreateInstance(modalEl);
                modalInstance.hide();
            }

            form.reset();

            // Refresh view to display new claim
            setTimeout(() => {
                window.location.reload();
            }, 600);

        } catch (error) {
            const errMsg = error.message || 'Unable to submit reimbursement claim.';
            notify('error', errMsg);

            // If error is description related, highlight inline
            if (errMsg.toLowerCase().includes('description')) {
                descInput?.classList.add('is-invalid', '!border-rose-500');
                if (descError) {
                    descError.textContent = errMsg;
                    descError.classList.remove('d-none');
                    descError.classList.add('d-block');
                }
                descInput?.focus();
            }

            // Restore submit button
            if (submitBtn) submitBtn.disabled = false;
            if (cancelBtn) cancelBtn.disabled = false;
            if (submitSpinner) submitSpinner.classList.add('d-none');
            if (submitIcon) {
                submitIcon.className = 'ti ti-check text-lg';
                submitIcon.classList.remove('d-none');
            }
            if (submitText) submitText.textContent = 'Submit Claim';
        }
    });
});
</script>
<?php endSection(); endif; ?>
