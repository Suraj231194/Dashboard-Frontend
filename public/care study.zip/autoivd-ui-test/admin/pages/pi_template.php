<?php
require_once "../db.php";
require_once "../functions.php";
if (!isset($_GET['id']) || empty($_GET['id'])) {
    exit("No ID provided.");
}

$id = (int) base64_decrypt($_GET['id']);
$fileName = '';

// Fetch requisition main record
$stmt = $conn->prepare("SELECT * FROM `proforma_invoices` WHERE `id` = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    exit("No material requisition found.");
}

$stmtItems = $conn->prepare("SELECT * FROM `proforma_invoice_items` WHERE `status` != 3 AND `deleted_at` IS NULL AND `pi_id` = ?");
$stmtItems->bind_param('i', $id);
$stmtItems->execute();
$resultItems = $stmtItems->get_result();
$rowItems = $resultItems->fetch_all(MYSQLI_ASSOC); 
$stmtItems->close();

$rawName = $row['pi_auto_batch']."_".$row['company_name'];
$fileName = preg_replace('/[^A-Za-z0-9]+/', '_', $rawName);
$fileName = trim($fileName, '_');  
$serial = 1;

$totPrc = 0.00;
$totPrcFinal = 0.00;
$totGst = 0.00;
$totQty = 0.00;
$serverSideDownload = isset($_GET['triggerDownload']) && (string) $_GET['triggerDownload'] === '1';
$logoSource = asset('assets/img/logo3.jpeg');
if ($serverSideDownload) {
    $logoPath = dirname(__DIR__, 2) . '/assets/img/logo3.jpeg';
    if (is_readable($logoPath)) {
        $logoSource = 'data:image/jpeg;base64,' . base64_encode((string) file_get_contents($logoPath));
    }
}
if ($serverSideDownload) {
    ob_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Proforma Invoice</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        .page {
            width: 100%;
            min-height: 1000px;
            /* ~A4 height in pixels at 96 DPI */
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }

        .page:last-child {
            page-break-after: auto;
        }
    </style>
</head>

<body style="margin: 0;">
    
    <div id="transferTicketContent" style="max-width: 900px;  padding: 15px !important; margin: auto;">
        <?php
            $rowsPerPage = 18;
            $chunks = array_chunk($rowItems, $rowsPerPage);
            $lastPageIndex = array_key_last($chunks);
            foreach ($chunks as $pageIndex => $pageProducts) {
                $realCount = count($pageProducts);
                $emptyRows = $rowsPerPage - $realCount;
        ?>
        <div class="transfer-copy"  style="page-break-after: <?= ($pageIndex == array_key_last($chunks)) ? 'auto' : 'always' ?>;">
            <div style="margin-bottom:10px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 18px;">
                        <td rowspan="2" style="width: 25%;border-left: 1px solid #000; border-top: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                            <img src="<?php echo htmlspecialchars($logoSource); ?>" alt="Biogenix Logo" style="height: 50px;">
                        </td>
                        <td style="width: 75%; border-right: 1px solid #000; border-top: 1px solid #000; border-bottom: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">PROFORMA INVOICE</strong></td>

                    </tr>
                    <tr style="line-height: 18px; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                        <td style="width: 75%; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">BIOGENIX INC. PVT. LTD.</strong></td>
                    </tr>

                </table>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 15px; font-size:small;">
                        <td colspan="5" style="width: 100%; text-align:center;border-left: 1px solid #000;border-right: 1px solid #000; border-bottom: 1px solid #000; padding-left:10px;">
                            B19/A, S.I.L. Ancillary Estate,<br />
                            Amausi Industrial Area, Nadarganj-226008,<br />
                            Lucknow (U.P.) <b>Mob.:</b> 9889485222, 9616105666<br />
                            <b>E-mail:</b> biogenix2007@yahoo.com, info@biogenixinc.com
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 5%; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px; padding-right:5px; font-weight:600;font-size:13px;">GSTIN</td>
                        <td style="width: 35%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;">09AAGCB6941G1ZJ</td>
                        <td style="width: 26%; padding-left:5px; font-weight:700;"><u>Shipping Address</u> </td>
                        <td style="width: 12%;border-bottom: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;">STATE CODE:</td>
                        <td style="width: 22%;border-right: 1px solid #000; border-bottom: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;">9</td>
                    </tr>
                    <tr>
                        <td style="width: 5%; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;">No. </td>
                        <td style="width: 35%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;"><?php echo htmlspecialchars($row['pi_auto_batch'] ?? ''); ?></td>
                        <td rowspan="3" style="width: 20%; padding-left:5px; padding-left:5px;font-size:small;"> 
                            <strong><?php echo htmlspecialchars($row['ship_company_name'] ?? ''); ?></strong> <br>
                            <?php echo htmlspecialchars($row['ship_company_address'] ?? ''); ?> <br>
                            <strong><?php echo !empty($row['ship_company_gst']) ?  htmlspecialchars('GST.: '.$row['ship_company_gst'] ?? '') : ''; ?></strong>
                        </td>
                        <td style="width: 12%; border-bottom: 1px solid #000;border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;">Date: </td>
                        <td style="width: 22%; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-weight:600;font-size:13px;"><?php echo formatDatePO(htmlspecialchars($row['created_at'] ?? '')); ?></td>
                    </tr>
                    <tr>
                        <td style="width: 5%; font-size:13px; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;">M/s </td>
                        <td style="width: 35%; font-size:13px; border-bottom: 1px solid #000; border-right: 1px solid #000; padding-left:5px;font-size:small;">                            
                            <strong><?php echo htmlspecialchars($row['company_name'] ?? ''); ?></strong> <br>
                                <?php echo htmlspecialchars($row['company_address'] ?? ''); ?> <br>
                                <strong><?php echo htmlspecialchars('GST.: '.$row['company_gst'] ?? ''); ?></strong>
                        </td>
                        <td colspan="2" style="width: 30%;font-size:13px; border-bottom: 1px solid #000; border-right: 1px solid #000; border-left: 1px solid #000; padding-left:5px;"> 
                            <?php if(!empty($row['attendant_person'])){ ?> <strong>Kind Attn:</strong> <?php echo htmlspecialchars($row['attendant_person'] ?? ''); } ?>
                            <?php if(!empty($row['attendant_contact'])){ ?><br> <strong>Attn Contact:</strong> <?php echo htmlspecialchars($row['attendant_contact'] ?? ''); } ?>
                        </td>

                    </tr>
                    <tr>
                        <td colspan="2" style="border-left:1px solid #000; border-right:1px solid #000;padding-left:5px;font-size:13px;"><strong>Your Enquiry No.:</strong> <?php echo htmlspecialchars($row['enquiry_medium'] ?? ''); ?> </td>
                        <td colspan="2" style="border-left:1px solid #000; border-right:1px solid #000;padding-left:5px;font-size:13px;"><strong>Dated:</strong><?php echo formatDateDMY(htmlspecialchars($row['enquiry_date'] ?? '')); ?></td>
                    </tr>
                </table>

                <table style="width: 100%; border-collapse: collapse; text-align:center; font-size:13px;">
                    <tr style="text-align:center; font-weight:bold;font-size:13px; background-color:#d9d9d9;">
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:2px;">S. No.</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Cat. No.</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Product</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Pack Size</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Qty</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Rate</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Value</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">GST</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;">Total Price (Inc. Vat)</td>
                    </tr>
                    <?php if (!empty($pageProducts)): foreach ($pageProducts as $p): ?>
                        <tr>
                            <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:2px;"><?= $serial ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"><?= $p['cat_no'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;text-align:left;background-color:#ffff00;"><?= $p['product'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;background-color:#92d050;"><?= $p['pack_size'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;background-color:#c5d9f1;"><?= $p['qty'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;color:#ff0000;"><?= $p['prod_rate'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"><?= $p['prod_value'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"><?= $p['gst_val'] ?? '' ?></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"><?= $p['total_price'] ?? '' ?></td>
                        </tr>                        
                    <?php
                        $totPrc += $p['total_price'];
                        $totGst += floatval($p['gst_val'] ?? 0.00);
                        $totQty += floatval($p['qty'] ?? 0.00);
                        $serial++;  endforeach;
                    endif; 
                    $totalFreightValue = $row['freight_amount'] + $row['freight_percent_amount'];
                    $totPrc += $totalFreightValue;
                    $actualTotal = floatval($totPrc);
                    $roundedTotal = round($actualTotal);
                    $roundOff = $roundedTotal - $actualTotal;
                    $roundOff = number_format($roundOff, 2, '.', '');
                    if ($roundOff > 0) { $roundOff = "+" . $roundOff; }
                    ?>
                    <?php for ($i = 0; $i < $emptyRows; $i++): ?>                        
                        <tr>
                            <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:2px;">&nbsp;</td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                            <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:2px;"></td>
                        </tr>                        
                    <?php endfor; ?> 
                    <?php if ($pageIndex == $lastPageIndex) { ?>                               
                    <tr>
                        <td style="width:5%; border-right : 1px solid #000; border-top: 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000; padding-left:5px;"> &nbsp;</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;font-weight:800;">FREIGHT</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"><?=  $row['freight_amount']; ?></td>
                    </tr>
                    <tr>
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;font-weight:800;">FREIGHT TAX(<?=  number_format($row['freight_percent'], 0); ?>%)</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"><?=  $row['freight_percent_amount']; ?></td>
                    </tr>
                    <tr>
                        <td style="width:5%; font-size:13px; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;font-weight:800;">ROUND OFF</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"><?= $roundOff; ?></td>
                    </tr>
                    <tr style="font-weight:800;font-size:13px;">
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> &nbsp;</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td colspan="2" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;">TOTAL</td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"><?=  indianCommaFormat($totQty); ?></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"><?=  indianCommaFormat($totGst); ?></td>
                        <td style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;background-color:#ff0000;color:#ffffff;"><?=  indianCommaFormat($roundedTotal); ?></td>
                    </tr>
                    <tr style="font-weight:800; font-size:13px; text-align:left;">
                        <td colspan="2" style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"> Amount in Rupees:</td>
                        <td colspan="7" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"><?= convertNumberToWords($roundedTotal); ?></td>
                    </tr>
                    <?php } ?>
                    <tr style="font-weight:800;">
                        <td colspan="6" style="width:5%; font-size:13px; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;text-align:left;"> TERMS : E.&.O.E. </td>
                        <td colspan="3" rowspan="4" style="border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;font-family: 'Poppins', sans-serif;font-size: 11px;font-style: italic;">Auto-Generated Proforma,
                            <br>
                            <img src="<?php echo htmlspecialchars($logoSource); ?>" alt="Biogenix Logo" style="height: 50px;">
                            <br>
                           Signature not required.
                        </td>
                    </tr>
                    <?php 
                    $bottomLines = [];
                    if (!empty($row['freight_notice'])) {
                        $bottomLines[] = $row['freight_notice'];
                    }
                    if (!empty($row['supply_period'])) {
                        $bottomLines[] = $row['supply_period'];
                    }
                    $bottomLines[] = 'All Disputes are subject to Lucknow Jurisdiction only';
                    foreach ($bottomLines as $bIndex => $bText){ ?>
                    <tr style="font-size:13px;">
                        <td style="width:5%; border-right : 1px solid #000; border-bottom: 1px solid #000; border-left : 1px solid #000;border-top: 1px solid #000;padding-left:5px;"><?php echo ($bIndex + 1); ?></td>
                        <td colspan="5" style="text-align:left; border-right : 1px solid #000; border-bottom: 1px solid #000; border-top : 1px solid #000;padding-left:5px;"> <?php echo htmlspecialchars($bText ?? ''); ?></td>
                    </tr>
                    <?php } ?>                    
                </table>
                <?php if ($pageIndex == $lastPageIndex) { ?>        
                <div style="font-weight: 600; margin-top:5px; color:#ff0000; font-size:13px;">
                    <h6 style="color:#ff0000; font-size:13px;">Bank Details:</h6>
                    <ol type="1" style="line-height:18px;">
                        <li>Bank of Baroda Lucknow, Account No: 00500500000114, IFSC Code: BARB0HAZARA.</li>
                    </ol>
                </div>
                <?php } ?>
            </div>
        </div>
        <?php if ($pageIndex < count($chunks) - 1): ?>
            <div class="html2pdf__page-break"></div>
        <?php endif; ?>
        <?php }?>
    </div>
    <script>
        window.onload = function() {
            const element = document.getElementById("transferTicketContent");
            const opt = {
                margin: [0.2, 0.2, 0.2, 0.2], // top, right, bottom, left
                filename: '<?= !empty($fileName) ? $fileName : "proforma_invoice_$id" ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' },
                pagebreak: { mode: ['css'] }
            };

            html2pdf().set(opt).from(element).save().then(() => {
                console.log("PDF downloaded.");
                window.close();
            });
        };
    </script>
</body>

</html>
<?php
if ($serverSideDownload) {
    $html = ob_get_clean();
    require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
    $options = new \Dompdf\Options();
    $options->set('isRemoteEnabled', false);
    $options->set('isHtml5ParserEnabled', true);
    $dompdf = new \Dompdf\Dompdf($options);
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $downloadName = ($fileName !== '' ? $fileName : "proforma_invoice_$id") . '.pdf';
    $pdfOutput = $dompdf->output();
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $downloadName . '"');
    header('Content-Length: ' . strlen($pdfOutput));
    echo $pdfOutput;
    exit;
}
?>
