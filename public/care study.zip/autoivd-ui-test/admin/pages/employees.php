<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
        </div>
    </div>
    <div class="row col-md-12" id="dashboard">
    </div>
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="employeesPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="employees-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="employees-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="employees-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="employees-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="employees-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="employees-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <div class="flex flex-col md:flex-row items-stretch md:items-center gap-2 shrink-0 w-full md:w-auto">
                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex h-10 w-full md:w-auto items-center justify-between md:justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dropdown-toggle"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span>Company</span> <i class="ti ti-filter"></i>
                            </button>
                            <div class="dropdown-menu min-w-48 !rounded-xl border border-slate-200 p-2 shadow-xl">
                                <?php if (!empty(Constant::EMPLOYEES['COMPANY_TYPE'])) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox"
                                            class="company-filter rounded border-slate-300 accent-emerald-600" value="all">
                                        <span>All</span>
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['COMPANY_TYPE'] as $ctpckey => $ctpcval) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox"
                                                class="company-filter rounded border-slate-300 accent-emerald-600"
                                                value="<?php echo $ctpckey; ?>"> <span><?php echo $ctpcval; ?></span>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>

                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex h-10 w-full md:w-auto items-center justify-between md:justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dropdown-toggle"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span>Status</span> <i class="ti ti-filter"></i>
                            </button>
                            <div class="dropdown-menu min-w-48 !rounded-xl border border-slate-200 p-2 shadow-xl">
                                <?php if (!empty(Constant::EMPLOYEES['STATUS_TYPES'])) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox"
                                            class="status-filter rounded border-slate-300 accent-emerald-600" value="all">
                                        <span>All</span>
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['STATUS_TYPES'] as $sfpckey => $sfpcval) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox"
                                                class="status-filter rounded border-slate-300 accent-emerald-600"
                                                value="<?php echo $sfpckey; ?>"> <span><?php echo $sfpcval['label']; ?></span>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>

                        <div class="dropdown w-full md:w-auto">
                            <button type="button"
                                class="inline-flex h-10 w-full md:w-auto items-center justify-between md:justify-center gap-2 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dropdown-toggle"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span>Category</span> <i class="ti ti-filter"></i>
                            </button>
                            <div class="dropdown-menu min-w-48 !rounded-xl border border-slate-200 p-2 shadow-xl">
                                <?php if (!empty(Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'])) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox"
                                            class="category-filter rounded border-slate-300 accent-emerald-600" value="all">
                                        <span>All</span>
                                    </label>
                                    <?php foreach (Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE_FILTER'] as $sipckey => $sipcval) { ?>
                                        <label
                                            class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox"
                                                class="category-filter rounded border-slate-300 accent-emerald-600"
                                                value="<?php echo $sipckey; ?>"> <span><?php echo $sipcval['label']; ?></span>
                                        </label>
                                    <?php }
                                } ?>
                            </div>
                        </div>
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-full md:w-32 h-10" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'hr_employees_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#animationModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="w-32 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="emp_code">
                                <span class="inline-flex items-center gap-1">EMP-Code <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-48 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="first_name">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-64 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="email">
                                <span class="inline-flex items-center gap-1">Email <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-32 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="emp_categ_type">
                                <span class="inline-flex items-center gap-1">Category <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-32 px-6 py-3">DOB</th>
                            <th class="w-32 px-6 py-3">DOJ</th>
                            <th class="w-32 px-6 py-3">Status</th>
                            <th class="w-48 px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="employeesTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content bg-white rounded-xl shadow-panel border-0 overflow-hidden">
                <div class="modal-header border-b border-slate-100 p-6 flex justify-between items-center bg-slate-50">
                    <div class="flex items-center gap-3">
                        <span
                            class="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-users text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                Employee</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create new employee record</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addEmployeesForm">
                    <div class="modal-body bg-slate-50/70 p-6">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="empCode" class="form-label">Employee Code <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="empCode" autocomplete="off" name="empCode" class="form-control"
                                    placeholder="Enter Employee Code" required />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="solutation" class="form-label">Salutation</label>
                                <select name="solutation" id="solutation" class="form-control">
                                    <?php if (!empty(Constant::EMPLOYEES['SOLUTATION'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['SOLUTATION'] as $skey => $sval) {
                                            echo '<option value="' . $skey . '">' . $sval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="firstName" class="form-label">First Name <strong
                                        class="text-danger">*</strong></label>
                                <input type="text" id="firstName" autocomplete="off" name="firstName"
                                    class="form-control" placeholder="Enter First Name" required />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="lastName" class="form-label">Last Name</label>
                                <input type="text" id="lastName" autocomplete="off" name="lastName" class="form-control"
                                    placeholder="Enter Last Name" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="dob" class="form-label">Date of Birth</label>
                                <input type="date" id="dob" autocomplete="off" name="dob" class="form-control"
                                    placeholder="Enter DOB" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="gender" class="form-label">Gender <strong
                                        class="text-danger">*</strong></label>
                                <select name="gender" id="gender" class="form-control" required>
                                    <?php if (!empty(Constant::EMPLOYEES['GENDER'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['GENDER'] as $gkey => $gval) {
                                            echo '<option value="' . $gkey . '">' . $gval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="userEmail" class="form-label">Email</label>
                                <input type="email" id="userEmail" autocomplete="off" name="userEmail"
                                    class="form-control" placeholder="Enter Email" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="contactNumber" class="form-label">Contact</label>
                                <input type="text" id="contactNumber" autocomplete="off" name="contactNumber"
                                    class="form-control" placeholder="Enter Contact" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="altContactNumberOne" class="form-label">Alt. Contact 1</label>
                                <input type="text" id="altContactNumberOne" autocomplete="off"
                                    name="altContactNumberOne" class="form-control"
                                    placeholder="Enter Alt. Contact 1" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="altContactNumberTwo" class="form-label">Alt. Contact 2</label>
                                <input type="text" id="altContactNumberTwo" autocomplete="off"
                                    name="altContactNumberTwo" class="form-control"
                                    placeholder="Enter Alt. Contact 2" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="fathersName" class="form-label">Father's Name</label>
                                <input type="text" id="fathersName" autocomplete="off" name="fathersName"
                                    class="form-control" placeholder="Enter Father's Name" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="maritalStatus" class="form-label">Marital Status</label>
                                <select id="maritalStatus" name="maritalStatus" class="form-control">
                                    <?php if (!empty(Constant::EMPLOYEES['MARITAL_STATUS'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['MARITAL_STATUS'] as $mskey => $msval) {
                                            echo '<option value="' . $mskey . '">' . $msval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="husbandName" class="form-label">Husband's Name</label>
                                <input type="text" id="husbandName" autocomplete="off" name="husbandName"
                                    class="form-control" placeholder="Enter Husband's Name" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="bloodGroup" class="form-label">Blood Group</label>
                                <select id="bloodGroup" name="bloodGroup" class="form-control">
                                    <?php if (!empty(Constant::EMPLOYEES['BLOOD_GROUP'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['BLOOD_GROUP'] as $bgkey => $bgval) {
                                            echo '<option value="' . $bgkey . '">' . $bgval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="localAddress" class="form-label">Local Address</label>
                                <textarea id="localAddress" autocomplete="off" name="localAddress" class="form-control"
                                    placeholder="Enter Local Address"></textarea>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="permanentAddress" class="form-label">Permanent Address</label>
                                <textarea id="permanentAddress" autocomplete="off" name="permanentAddress"
                                    class="form-control" placeholder="Enter Permanent Address"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="doj" class="form-label">Date of Joining <strong
                                        class="text-danger">*</strong></label>
                                <input type="date" id="doj" autocomplete="off" name="doj" class="form-control"
                                    placeholder="Enter DOJ" required />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="empCompany" class="form-label">Company <strong
                                        class="text-danger">*</strong></label>
                                <select name="empCompany" id="empCompany" class="form-control" required>
                                    <?php if (!empty(Constant::EMPLOYEES['COMPANY_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['COMPANY_TYPE'] as $ctkey => $ctval) {
                                            echo '<option value="' . $ctkey . '">' . $ctval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="employmentCategory" class="form-label">Employment Category <strong
                                        class="text-danger">*</strong></label>
                                <select name="employmentCategory" id="employmentCategory" class="form-control" required>
                                    <?php if (!empty(Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['EMPLOYMENT_CATEGORY_TYPE'] as $ectkey => $ectval) {
                                            echo '<option value="' . $ectkey . '">' . $ectval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="employmentType" class="form-label">Employment Type <strong
                                        class="text-danger">*</strong></label>
                                <select name="employmentType" id="employmentType" class="form-control" required>
                                    <?php if (!empty(Constant::EMPLOYEES['EMPLOYMENT_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::EMPLOYEES['EMPLOYMENT_TYPE'] as $etkey => $etval) {
                                            echo '<option value="' . $etkey . '">' . $etval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="empDesignation" class="form-label">Designation <strong
                                        class="text-danger">*</strong></label>
                                <select id="empDesignation" name="empDesignation" class="form-control"
                                    required></select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <small class="text-dark fw-medium d-block">Status <strong
                                        class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatus" name="userStatus"
                                        value="1" required />
                                    <label class="form-check-label" for="activStatus">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input" type="radio" id="inactiveStatus" name="userStatus"
                                        value="0" />
                                    <label class="form-check-label" for="inactiveStatus">Inactive</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer p-4 pt-0 flex justify-end gap-3 border-0 bg-transparent">
                        <button type="button"
                            class="inline-flex h-10 items-center justify-center rounded-full border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-400/20"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 items-center justify-center rounded-full bg-emerald-700 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editUserModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="editEmployeeForm">
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="changePasswordUserModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="changePasswordForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col mb-3">
                                <label for="userNewPassword" class="form-label">Enter New Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="userNewPassword" class="form-control"
                                        name="userNewPassword" autocomplete="off"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        aria-describedby="password" required />
                                    <span class="input-group-text cursor-pointer seeUserNewPassword"><i
                                            class="ti ti-eye-off"></i></span>
                                </div>
                                <input type="hidden" name="user_id" id="user_id" class="form-control" value="" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="userNewConfirmPassword" class="form-label">Confirm New Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="userNewConfirmPassword" class="form-control"
                                        name="userNewConfirmPassword" autocomplete="off"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        aria-describedby="password" required />
                                    <span class="input-group-text cursor-pointer seeUserNewConfirmPassword"><i
                                            class="ti ti-eye-off"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer p-4 pt-0 flex justify-end gap-3 border-0 bg-transparent">
                        <button type="button"
                            class="inline-flex h-10 items-center justify-center rounded-full border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-400/20"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 items-center justify-center rounded-full bg-emerald-700 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="submitChangePasswordBtn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="employeeAdvancePayModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Advance Pay to Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="employeeAdvancePayForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="entryDate" class="form-label">Date <strong
                                        class="text-danger">*</strong></label>
                                <input type="date" id="entryDate" autocomplete="off" name="entryDate"
                                    class="form-control" required />
                                <input type="hidden" name="employeeId" id="employeeId" value="">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="amount" class="form-label">Amount <strong
                                        class="text-danger">*</strong></label>
                                <input type="number" step="any" min="0" id="amount" autocomplete="off" name="amount"
                                    class="form-control" placeholder="Enter Amount" required />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label" for="deduction_type">Deduction Type <strong
                                        class="text-danger">*</strong></label>
                                <select name="deduction_type" id="deduction_type" class="form-control" required>
                                    <?php if (!empty(Constant::HR_SETTINGS['INSTALLMENT_ADVANCED'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::HR_SETTINGS['INSTALLMENT_ADVANCED'] as $iakey => $iaval) {
                                            echo '<option value="' . $iakey . '">' . $iaval['label'] . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3" id="installment_amount_div">
                                <label for="installment_amount" class="form-label">Installment Amount (if
                                    installment)</label>
                                <input type="number" step="any" min="0" id="installment_amount" autocomplete="off"
                                    name="installment_amount" class="form-control" placeholder="Enter Amount" />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="Remark" class="form-label">Remark <strong
                                        class="text-danger">*</strong></label>
                                <textarea id="Remark" autocomplete="off" name="remark" class="form-control"
                                    placeholder="Enter Remark" required></textarea>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer p-4 pt-0 flex justify-end gap-3 border-0 bg-transparent">
                        <button type="button"
                            class="inline-flex h-10 items-center justify-center rounded-full border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-400/20"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 items-center justify-center rounded-full bg-emerald-700 px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="viewPersonsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewPersonsTitle"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="viewPersons">
                    <div class="modal-body">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="employeeDetailsExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportType" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Sr No" checked />
                                        <span class="text-sm font-medium text-slate-700">Sr No</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Employee Code" checked />
                                        <span class="text-sm font-medium text-slate-700">Employee Code</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Name</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Email" checked />
                                        <span class="text-sm font-medium text-slate-700">Email</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Designation" checked />
                                        <span class="text-sm font-medium text-slate-700">Designation</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Company" checked />
                                        <span class="text-sm font-medium text-slate-700">Company</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Employment Type" checked />
                                        <span class="text-sm font-medium text-slate-700">Employment Type</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Category" checked />
                                        <span class="text-sm font-medium text-slate-700">Category</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="DOB" checked />
                                        <span class="text-sm font-medium text-slate-700">DOB</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="DOJ" checked />
                                        <span class="text-sm font-medium text-slate-700">DOJ</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Gender" checked />
                                        <span class="text-sm font-medium text-slate-700">Gender</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Status</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Marital Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Marital Status</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Father Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Father Name</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Husband Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Husband Name</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Contact" checked />
                                        <span class="text-sm font-medium text-slate-700">Contact</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Alt Contact 1" checked />
                                        <span class="text-sm font-medium text-slate-700">Alt Contact 1</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Alt Contact 2" checked />
                                        <span class="text-sm font-medium text-slate-700">Alt Contact 2</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Local Address" checked />
                                        <span class="text-sm font-medium text-slate-700">Local Address</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Permanant Address" checked />
                                        <span class="text-sm font-medium text-slate-700">Permanant Address</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Aadhar" checked />
                                        <span class="text-sm font-medium text-slate-700">Aadhar</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="PAN" checked />
                                        <span class="text-sm font-medium text-slate-700">PAN</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="UAN" checked />
                                        <span class="text-sm font-medium text-slate-700">UAN</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="ESIC" checked />
                                        <span class="text-sm font-medium text-slate-700">ESIC</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="IFSC Code" checked />
                                        <span class="text-sm font-medium text-slate-700">IFSC Code</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Acc No" checked />
                                        <span class="text-sm font-medium text-slate-700">Acc No</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Bank" checked />
                                        <span class="text-sm font-medium text-slate-700">Bank</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';
    let selectedCategoryType = [];
    let selectedStatusFilters = [];
    let selectedCompanyFilters = [];


    function loadEmployeesTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadEmployees: 'loadEmployees',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder,
                categoryType: selectedCategoryType,
                selectedStatus: selectedStatusFilters,
                selectedCompany: selectedCompanyFilters
            },
            success: function (response) {
                $('#employeesTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function () {
                $('#employeesTableBody').html('<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function loadRolesOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadRolesOptions: 'loadRolesOptions'
            },
            success: function (response) {
                const options = JSON.parse(response); // Step 1: parse JSON
                let html = '<option value="">----Select---</option>';

                options.forEach(function (role) {
                    html += `<option value="${role.key}">${role.value}</option>`;
                });
                $('#userRoleType').html(html);
            }
        });
    }

    function loadDesignationOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadDesignationsOptions: 'loadDesignationsOptions'
            },
            success: function (response) {
                const options = response; // Step 1: parse JSON
                let html = '<option value="">----Select---</option>';

                options.forEach(function (designation) {
                    html += `<option value="${designation.id}">${designation.name} (${designation.short_name})</option>`;
                });
                $('#empDesignation').html(html);
            }
        });
    }

    function loadDashboardEmployees() {
        $('#dashboard').html();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadEmployeesDashboard: 'loadEmployeesDashboard'
            },
            success: function (response) {
                $('#dashboard').html(response.data || '');
            },
            error: function () {
                $('#dashboard').html('');
            }
        });
    }

    $(document).on('click', 'th.sortable', function () {
        const column = $(this).data('column');

        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }

        // Remove all indicators first
        $('th.sortable').removeClass('asc desc');

        // Add indicator to the active column
        $(`th[data-column="${currentSortColumn}"]`).addClass(currentSortOrder.toLowerCase());

        loadEmployeesTable(1);
    });


    $(document).ready(function () {
        $(".category-filter").prop("checked", true);
        $(".status-filter").prop("checked", true);
        $(".company-filter").prop("checked", true);

        selectedCategoryType = [];
        $(".category-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCategoryType.push($(this).val());
            }
        });

        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });
        selectedCompanyFilters = [];
        $(".company-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCompanyFilters.push($(this).val());
            }
        });
        loadEmployeesTable();
        loadRolesOption();
        loadDesignationOption();
        loadDashboardEmployees();
        $('#installment_amount_div').hide();
        $('#searchUsers').on('input', function () {
            loadEmployeesTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadEmployeesTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.employees-per-page-item', function () {
            const val = $(this).data('val');
            $('#employeesPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addEmployeesForm')[0].reset();
        });

        $('#addEmployeesForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addEmployeesForm');
            const formData = new FormData(form);
            formData.append('addEmployees', 'addEmployees');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addEmployeesForm')[0].reset();
                        loadEmployeesTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $(document).on('click', '.absent-data', function () {
            let companyType = $(this).data('company');
            let categoryType = $(this).data('category');
            let statusType = $(this).data('status-type');
            if (companyType != '' && categoryType != '') {
                // $('#viewPersons').find('modal-body').html();
                $('#viewPersons .modal-body').html('<p class="text-center text-muted">Loading...</p>');
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        fetchEmployeeCountRecord: 'fetchEmployeeCountRecord',
                        companyType: companyType,
                        categoryType: categoryType,
                        statusType: statusType
                    },
                    success: function (res) {
                        if (res.status === 'success') {
                            $('#viewPersonsModal').modal('show');
                            $('#viewPersonsTitle').html(res.title);
                            $('#viewPersons').find('.modal-body').html(res.data);
                        } else if (res.status === 'error') {
                            toastr.error(res.message);
                        } else {
                            toastr.error('Unexpected response.');
                        }
                    },
                    error: function () {
                        toastr.error('Server error occurred.');
                    }
                });
            }
        });

        function updateColumnsSelectedText() {
            const checkedCount = $('.column-filter:checked').length;
            const totalCount = $('.column-filter').length;
            if (checkedCount === totalCount) {
                $('#columnsSelectedText').text(totalCount + ' items selected');
            } else if (checkedCount > 2) {
                $('#columnsSelectedText').text(checkedCount + ' items selected');
            } else if (checkedCount > 0) {
                let names = [];
                $('.column-filter:checked').each(function () {
                    names.push($(this).val());
                });
                $('#columnsSelectedText').text(names.join(', '));
            } else {
                $('#columnsSelectedText').text('----Select Columns----');
            }
        }

        $(document).on('change', '.column-filter', function () {
            updateColumnsSelectedText();
        });

        $(document).on('click', '#selectAllColumns', function () {
            $('.column-filter').prop('checked', true);
            updateColumnsSelectedText();
        });

        $(document).on('click', '#deselectAllColumns', function () {
            $('.column-filter').prop('checked', false);
            updateColumnsSelectedText();
        });

        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            $('#exportTypeText').text($(this).text());
            $('#exportType').val(val);
        });
    });

    $(document).on('click', '.employeeEditModal', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editEmployeeForm').find('.modal-body').html('');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchEmployeeRecord: 'fetchEmployeeRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editUserModel').modal('show');
                        $('#editEmployeeForm').find('.modal-body').html(res.data);
                    } else {
                        toastr.error(res.message || 'Unexpected error');
                    }
                },
                error: function (xhr) {
                    toastr.error('Server error occurred.');
                    console.error("Response:", xhr.responseText);
                }
            });
        }
    });

    $(document).on('click', '.userChangePasswordModal', function () {
        let id = $(this).data('id');
        $('#user_id').val('');
        if (id) {
            $('#user_id').val(id);
            $('#changePasswordUserModel').modal('show');
        }
    });

    $(document).on('click', '.employeesDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteEmployeesRecord: 'deleteEmployeesRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadEmployeesTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('submit', '#editPersonalEmployeeDetailsForm', function (e) {
        e.preventDefault();
        const form = document.getElementById('editPersonalEmployeeDetailsForm');
        const formData = new FormData(form);
        formData.append('updatePersonalEmployeeDetails', 'updatePersonalEmployeeDetails');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editUserModel').modal('hide');
                    $('#editPersonalEmployeeDetailsForm').find('modal-body').html();
                    loadEmployeesTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('submit', '#editAccountEmployeeDetailsForm', function (e) {
        e.preventDefault();
        const form = document.getElementById('editAccountEmployeeDetailsForm');
        const formData = new FormData(form);
        formData.append('updateAccountEmployeeDetails', 'updateAccountEmployeeDetails');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editUserModel').modal('hide');
                    $('#editPersonalEmployeeDetailsForm').find('modal-body').html();
                    loadEmployeesTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });


    $(document).on("change", ".employee-status", function () {
        let checkbox = $(this);
        let id = checkbox.data("id");
        let status = checkbox.is(":checked") ? 1 : 0;

        $.ajax({
            url: "ajax.php",
            type: "POST",
            dataType: 'json',
            data: {
                updateEmployeeStatus: 1,
                id: id,
                status: status
            },
            success: function (res) {
                if (res.status === 'success') {
                    loadEmployeesTable();
                    loadDashboardEmployees();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error("Failed to update status.");
                checkbox.prop("checked", !status); // revert if error
            }
        });
    });

    $(document).on('click', '.employeeAdvancePay', function () {
        let id = $(this).data('id');
        $('#employeeId').val('');
        if (id) {
            $('#employeeId').val(id);
            $('#employeeAdvancePayModal').modal('show');
        }
    });

    $('#deduction_type').on('change', function () {
        let selected = $(this).val();
        if (selected === '2') {
            $('#installment_amount').attr('required', true);
            $('#installment_amount_div').show();
        } else {
            $('#installment_amount_div').hide();
            $('#installment_amount').removeAttr('required');
        }
    });

    $(document).on('submit', '#employeeAdvancePayForm', function (e) {
        e.preventDefault();
        const form = document.getElementById('employeeAdvancePayForm');
        const formData = new FormData(form);
        formData.append('addAdvancePaymentToEployee', 'addAdvancePaymentToEployee');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#employeeAdvancePayModal').modal('hide');
                    $('#employeeAdvancePayForm')[0].reset();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });


    $(document).on('click', '.employeeResign', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid employee ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You wanna resign this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, resign it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        resignEmployeesRecord: 'resignEmployeesRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadEmployeesTable();
                            loadDashboardEmployees();
                            Swal.fire({
                                icon: 'success',
                                title: 'Resigned!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('change', '.category-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".category-filter").prop("checked", allChecked);
        }

        selectedCategoryType = [];
        $(".category-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCategoryType.push($(this).val());
            }
        });
        loadEmployeesTable(1);
    });

    $(document).on('change', '.status-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".status-filter").prop("checked", allChecked);
        }

        selectedStatusFilters = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedStatusFilters.push($(this).val());
            }
        });

        loadEmployeesTable(1);
    });
    $(document).on('change', '.company-filter', function () {
        const isAll = $(this).val() === "all";

        if (isAll) {
            // Toggle all on or off based on "All"
            const allChecked = $(this).is(":checked");
            $(".company-filter").prop("checked", allChecked);
        }

        selectedCompanyFilters = [];
        $(".company-filter:checked").each(function () {
            if ($(this).val() !== "all") {
                selectedCompanyFilters.push($(this).val());
            }
        });

        loadEmployeesTable(1);
    });

    $('#employeeDetailsExportForm').on('submit', function (e) {
        e.preventDefault();
        page = 1;
        currentPage = page;

        if (!$('#exportType').val()) {
            toastr.error('Please select an export type.');
            return;
        }

        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const form = document.getElementById('employeeDetailsExportForm');
        const formData = new FormData(form);
        formData.append('exportEmployeeDetails', 'exportEmployeeDetails');
        formData.append('search', search);
        formData.append('per_page', perPage);
        formData.append('page', page);
        formData.append('categoryType', JSON.stringify(selectedCategoryType));
        formData.append('selectedStatus', JSON.stringify(selectedStatusFilters));
        formData.append('selectedCompany', JSON.stringify(selectedCompanyFilters));
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').removeClass('inline-flex').attr('style', 'display: none !important;');
        const $submitBtn = $('#employeeDetailsExportForm button[type="submit"]');
        $submitBtn.showLoader({ size: 'lg', overlay: true, text: 'Please wait...' });

        $.ajax({
            url: 'exportajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportType').val().toUpperCase()).removeClass('hidden d-none').addClass('inline-flex').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            },
            complete: function () {
                $submitBtn.hideLoader();
            }
        });
    });
</script>
<?php endSection(); ?>
