<?php
if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once __DIR__ . '/../hrms/hrms_common.php';

$offboardingUserId = (int) ($_SESSION['user_id'] ?? 0);
$offboardingEmployee = hrmsCurrentEmployee($conn, $offboardingUserId);
$canManageOffboarding = hrmsCan($conn, 'hrms_offboarding_manage');
$employeeResignations = [];
$exitQuestions = [];
$activeExitRequest = null;
$offboardingSettings = null;
$managerResignations = [];
$offboardingUsers = [];
$offboardingApprovers = [];
$offboardingCompanies = [];
$offboardingBranches = [];

if ($offboardingEmployee) {
    $employeeId = (int) $offboardingEmployee['id'];
    $stmt = $conn->prepare("SELECT request.*,
            (SELECT document.id FROM hr_offboarding_documents document WHERE document.resignation_request_id=request.id AND document.document_type='experience_letter' AND document.file_path IS NOT NULL LIMIT 1) AS experience_document_id,
            (SELECT document.id FROM hr_offboarding_documents document WHERE document.resignation_request_id=request.id AND document.document_type='relieving_letter' AND document.file_path IS NOT NULL LIMIT 1) AS relieving_document_id
        FROM hr_resignation_requests request WHERE request.employee_id = ? ORDER BY request.submitted_at DESC");
    $stmt->bind_param('i', $employeeId);
    $stmt->execute();
    $employeeResignations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    foreach ($employeeResignations as $request) {
        if ($request['status'] === 'exit_interview_pending') {
            $activeExitRequest = $request;
            break;
        }
    }
    
    $empCompanyId = !empty($offboardingEmployee['company_id']) ? (int) $offboardingEmployee['company_id'] : (int) ($offboardingEmployee['company'] ?? 0);
    $empBranchId = !empty($offboardingEmployee['branch_id']) ? (int) $offboardingEmployee['branch_id'] : 0;
    $stmt = $conn->prepare('SELECT * FROM hr_offboarding_settings WHERE company_id = ? AND status = 1 AND (branch_id = ? OR branch_id IS NULL) ORDER BY branch_id IS NULL ASC LIMIT 1');
    $stmt->bind_param('ii', $empCompanyId, $empBranchId);
    $stmt->execute();
    $employeeSettings = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if ($employeeSettings) {
        $stmt = $conn->prepare('SELECT * FROM hr_exit_interview_questions WHERE settings_id = ? AND status = 1 ORDER BY sort_order, id');
        $settingsId = (int) $employeeSettings['id'];
        $stmt->bind_param('i', $settingsId);
        $stmt->execute();
        $exitQuestions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
}

if ($canManageOffboarding) {
    $scope = hrmsCurrentScope($conn, $offboardingUserId);
    $companySql = 'SELECT id, company_name FROM erp_companies WHERE status = 1 AND deleted_at IS NULL';
    if ($scope['company_id'] !== null) $companySql .= ' AND id = ' . (int) $scope['company_id'];
    $companySql .= ' ORDER BY company_name';
    $result = $conn->query($companySql);
    $offboardingCompanies = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $branchSql = 'SELECT id, company_id, branch_name FROM erp_branches WHERE status = 1 AND deleted_at IS NULL';
    if ($scope['company_id'] !== null) $branchSql .= ' AND company_id = ' . (int) $scope['company_id'];
    if ($scope['branch_id'] !== null) $branchSql .= ' AND id = ' . (int) $scope['branch_id'];
    $branchSql .= ' ORDER BY branch_name';
    $result = $conn->query($branchSql);
    $offboardingBranches = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $selectedCompany = isset($_GET['company_id']) && (int) $_GET['company_id'] > 0 ? (int) $_GET['company_id'] : ($scope['company_id'] ?? (int) ($offboardingCompanies[0]['id'] ?? 0));
    $selectedBranch = isset($_GET['branch_id']) && $_GET['branch_id'] !== '' ? (int) $_GET['branch_id'] : $scope['branch_id'];
    if ($selectedCompany) {
        $settingsSql = 'SELECT * FROM hr_offboarding_settings WHERE company_id = ? AND ' . ($selectedBranch ? 'branch_id = ?' : 'branch_id IS NULL') . ' LIMIT 1';
        $stmt = $conn->prepare($settingsSql);
        if ($selectedBranch) $stmt->bind_param('ii', $selectedCompany, $selectedBranch); else $stmt->bind_param('i', $selectedCompany);
        $stmt->execute();
        $offboardingSettings = $stmt->get_result()->fetch_assoc() ?: null;
        $stmt->close();

        if (!$offboardingSettings) {
            $defaultNotice = 30;
            $defaultIntro = 'Please complete the exit interview to finish the approved offboarding process.';
            $defaultThankYou = 'Thank you for completing the exit interview.';
            $insStmt = $conn->prepare('INSERT INTO hr_offboarding_settings (company_id, branch_id, notice_period_days, interview_intro, thank_you_message, send_experience_letter, send_relieving_letter, status, created_by) VALUES (?, ?, ?, ?, ?, 1, 1, 1, ?)');
            $insStmt->bind_param('iiissi', $selectedCompany, $selectedBranch, $defaultNotice, $defaultIntro, $defaultThankYou, $offboardingUserId);
            $insStmt->execute();
            $newSettingsId = (int) $insStmt->insert_id;
            $insStmt->close();

            $stmt = $conn->prepare('SELECT * FROM hr_offboarding_settings WHERE id = ?');
            $stmt->bind_param('i', $newSettingsId);
            $stmt->execute();
            $offboardingSettings = $stmt->get_result()->fetch_assoc() ?: null;
            $stmt->close();
        }

        if ($offboardingSettings) {
            $stmt = $conn->prepare('SELECT * FROM hr_exit_interview_questions WHERE settings_id = ? AND status = 1 ORDER BY sort_order, id');
            $settingsId = (int) $offboardingSettings['id'];
            $stmt->bind_param('i', $settingsId);
            $stmt->execute();
            $managerQuestions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } else {
            $managerQuestions = [];
        }
    } else {
        $managerQuestions = [];
    }

    $userSql = 'SELECT id, name, email FROM users WHERE is_active = 1 AND deleted_at IS NULL';
    if ($selectedCompany) $userSql .= ' AND (company_id = ' . (int) $selectedCompany . ' OR company_id IS NULL)';
    $userSql .= ' ORDER BY name';
    $result = $conn->query($userSql);
    $offboardingUsers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

    $offboardingApproverIds = hrmsManagerUserIds($conn, 'hrms_offboarding_manage', $selectedCompany ?: null, $selectedBranch ? (int) $selectedBranch : null);
    if ($offboardingApproverIds !== []) {
        $approverIdsSql = implode(',', array_map('intval', $offboardingApproverIds));
        $result = $conn->query("SELECT id, name, email FROM users WHERE id IN ({$approverIdsSql}) AND is_active = 1 AND deleted_at IS NULL ORDER BY name");
        $offboardingApprovers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    } else {
        $offboardingApprovers = $offboardingUsers;
    }

    $requestSql = "SELECT request.*, employee.emp_code, employee.first_name, employee.last_name,
            company.company_name, branch.branch_name,
                        (SELECT settings.approver_user_id FROM hr_offboarding_settings settings
                         WHERE settings.company_id = request.company_id AND settings.status = 1
                             AND (settings.branch_id = request.branch_id OR settings.branch_id IS NULL)
                         ORDER BY settings.branch_id IS NULL ASC LIMIT 1) AS configured_approver_user_id,
            GROUP_CONCAT(CONCAT(document.id, '|', document.document_type, '|', document.status) SEPARATOR ',') AS documents
        FROM hr_resignation_requests request
        INNER JOIN employees employee ON employee.id = request.employee_id
        LEFT JOIN erp_companies company ON company.id = request.company_id
        LEFT JOIN erp_branches branch ON branch.id = request.branch_id
        LEFT JOIN hr_offboarding_documents document ON document.resignation_request_id = request.id
        WHERE 1=1";
    if ($scope['company_id'] !== null) $requestSql .= ' AND request.company_id = ' . (int) $scope['company_id'];
    if ($scope['branch_id'] !== null) $requestSql .= ' AND request.branch_id = ' . (int) $scope['branch_id'];
    $requestSql .= " GROUP BY request.id ORDER BY FIELD(request.status,'pending','exit_interview_pending','approved','completed','rejected','cancelled'), request.submitted_at DESC LIMIT 200";
    $result = $conn->query($requestSql);
    $managerResignations = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $activeOffboardingUserIds = array_map('intval', array_column($offboardingApprovers, 'id'));
    foreach ($managerResignations as &$managerResignation) {
        $configuredApproverId = (int) ($managerResignation['configured_approver_user_id'] ?? 0);
        $managerResignation['can_review'] = ($configuredApproverId <= 0 || $configuredApproverId === $offboardingUserId || !in_array($configuredApproverId, $activeOffboardingUserIds, true) || $canManageOffboarding) ? 1 : 0;
    }
    unset($managerResignation);
}

$offboardingStatusClass = static fn(string $status): string => match ($status) {
    'completed' => 'bg-emerald-100 text-emerald-700', 'rejected' => 'bg-rose-100 text-rose-700',
    'exit_interview_pending', 'approved' => 'bg-sky-100 text-sky-700', default => 'bg-amber-100 text-amber-700',
};
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-6">
        <div>
            <h2 class="mb-1 text-2xl fw-bold text-slate-900" style="font-family:'Sora',sans-serif;">Offboarding</h2>
            <p class="mb-0 text-sm text-slate-500">Employee resignation workflow covering notice period, approval, exit interview and document delivery.</p>
        </div>
        <?php if ($offboardingEmployee): ?>
            <button class="btn btn-outline-danger rounded-xl px-4 d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#resignationModal" <?= array_filter($employeeResignations, static fn($r) => in_array($r['status'], ['pending','approved','exit_interview_pending'], true)) ? 'disabled' : '' ?>>
                <i class="ti ti-logout-2"></i>Submit Resignation
            </button>
        <?php endif; ?>
    </div>

    <?php if ($offboardingEmployee): ?>
        <?php if ($activeExitRequest): ?>
            <div class="card border border-emerald-200 shadow-sm rounded-2xl mb-6 overflow-hidden">
                <div class="card-header p-5 bg-emerald-50 border-bottom border-emerald-100">
                    <h5 class="mb-1 fw-bold text-emerald-900">Exit Interview</h5>
                    <p class="mb-0 text-sm text-emerald-700"><?= htmlspecialchars($employeeSettings['interview_intro'] ?? 'Please complete the exit interview to finish the approved offboarding process.') ?></p>
                </div>
                <form id="exitInterviewForm">
                    <div class="card-body p-5">
                        <input type="hidden" name="action" value="submit_exit_interview">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                        <input type="hidden" name="request_id" value="<?= (int) $activeExitRequest['id'] ?>">
                        <?php if (!$exitQuestions): ?>
                            <div class="text-slate-500">No questions are configured. Submit to complete the process.</div>
                        <?php endif; ?>
                        <?php foreach ($exitQuestions as $index => $question): $options=json_decode($question['options_json'] ?? '[]',true) ?: []; ?>
                            <div class="mb-5 exit-question" data-question-id="<?= (int) $question['id'] ?>" data-question-type="<?= htmlspecialchars($question['question_type']) ?>">
                                <label class="form-label fw-bold text-slate-800"><?= ($index+1) ?>. <?= htmlspecialchars($question['question_text']) ?><?= (int)$question['is_required']===1?' <span class="text-danger">*</span>':'' ?></label>
                                <?php if ($question['question_type']==='long_text'): ?>
                                    <textarea class="form-control rounded-xl exit-answer" rows="4" <?= (int)$question['is_required']===1?'required':'' ?>></textarea>
                                <?php elseif ($question['question_type']==='short_text'): ?>
                                    <input class="form-control rounded-xl exit-answer" <?= (int)$question['is_required']===1?'required':'' ?>>
                                <?php elseif ($question['question_type']==='rating'): ?>
                                    <select class="form-select rounded-xl exit-answer" <?= (int)$question['is_required']===1?'required':'' ?>>
                                        <option value="">Select rating</option>
                                        <?php for($rating=1;$rating<=5;$rating++):?>
                                            <option value="<?= $rating ?>"><?= $rating ?> / 5</option>
                                        <?php endfor;?>
                                    </select>
                                <?php else: ?>
                                    <div class="d-flex flex-column gap-2">
                                        <?php foreach($options as $option): ?>
                                            <label class="rounded-xl border border-slate-200 p-3">
                                                <input class="form-check-input me-2 exit-choice" type="<?= $question['question_type']==='multiple_choice'?'checkbox':'radio' ?>" name="question_<?= (int)$question['id'] ?><?= $question['question_type']==='multiple_choice'?'[]':'' ?>" value="<?= htmlspecialchars($option) ?>"> <?= htmlspecialchars($option) ?>
                                            </label>
                                        <?php endforeach;?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="card-footer bg-white border-top border-slate-100 p-4 text-end">
                        <button type="submit" class="btn btn-primary rounded-xl">Submit Exit Interview</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                <div>
                    <h5 class="mb-1 fw-bold text-slate-900">My Offboarding Requests</h5>
                    <p class="mb-0 text-sm text-slate-500">Your resignation request and approval history.</p>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <input type="hidden" id="myOffboardingPerPage" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="myOffboardingPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="my-offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="my-offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="my-offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="my-offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="bg-slate-50">
                        <tr>
                            <th class="px-5 py-3 text-xs text-uppercase text-slate-500">Request</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Submitted</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Requested Last Day</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Approved Last Day</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Status</th>
                            <th class="px-5 py-3 text-xs text-uppercase text-slate-500">Documents</th>
                        </tr>
                    </thead>
                    <tbody id="myResignationsTableBody">
                        <?php if(!$employeeResignations):?>
                            <tr><td colspan="6" class="text-center py-10 text-slate-500">No resignation requests.</td></tr>
                        <?php else:foreach($employeeResignations as $request):?>
                            <tr>
                                <td class="px-5 py-4 fw-bold text-slate-800"><?=htmlspecialchars($request['request_no'])?></td>
                                <td class="py-4 text-slate-600"><?=htmlspecialchars(date('d M Y',strtotime($request['submitted_at'])))?></td>
                                <td class="py-4 text-slate-600"><?=htmlspecialchars($request['requested_last_working_date'])?></td>
                                <td class="py-4 text-slate-600"><?=htmlspecialchars($request['approved_last_working_date'] ?: '—')?></td>
                                <td class="py-4"><span class="badge rounded-pill <?=$offboardingStatusClass($request['status'])?>"><?=htmlspecialchars(ucwords(str_replace('_',' ',$request['status'])))?></span></td>
                                <td class="px-5 py-4">
                                    <div class="d-flex gap-1">
                                        <?php if($request['experience_document_id']):?>
                                            <a class="btn btn-sm btn-icon btn-outline-primary rounded-lg" target="_blank" href="hrms-offboarding-document.php?id=<?=(int)$request['experience_document_id']?>" title="Experience Letter"><i class="ti ti-file-certificate"></i></a>
                                        <?php endif;?>
                                        <?php if($request['relieving_document_id']):?>
                                            <a class="btn btn-sm btn-icon btn-outline-primary rounded-lg" target="_blank" href="hrms-offboarding-document.php?id=<?=(int)$request['relieving_document_id']?>" title="Relieving Letter"><i class="ti ti-file-description"></i></a>
                                        <?php endif;?>
                                        <?php if(!$request['experience_document_id']&&!$request['relieving_document_id']):?>
                                            <span class="text-slate-400">—</span>
                                        <?php endif;?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach;endif;?>
                    </tbody>
                </table>
            </div>
            <div class="my-offboarding-pagination-container">
                <style>
                    #myOffboardingFooterPerPageSelect + .dropdown {
                        display: none !important;
                    }
                </style>
                <?= getPaginationFooter('myOffboardingPaginationWrapper', 'myOffboardingPaginationSummary', 'myOffboardingFooterPerPageSelect') ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($canManageOffboarding): ?>
        <!-- Setup Wizard (Matching Screenshot 1 to 5) -->
        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6">
            <div class="card-header bg-slate-50 border-bottom border-slate-200 p-4 px-5 d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-3">
                <div class="d-flex align-items-center gap-3">
                    <span class="rounded-xl bg-primary text-white d-flex align-items-center justify-content-center" style="width:38px;height:38px;">
                        <i class="ti ti-settings fs-5"></i>
                    </span>
                    <div>
                        <h5 class="mb-0 fw-bold text-slate-900">Offboarding Setup</h5>
                        <p class="mb-0 text-xs text-slate-500">Configure notice period, exit interview questions and automated document delivery</p>
                    </div>
                </div>

                <!-- Scope Selectors -->
                <div class="d-flex align-items-center gap-2">
                    <select class="form-select form-select-sm rounded-xl" id="wizardScopeCompany" style="min-width: 160px;">
                        <?php foreach($offboardingCompanies as $company):?>
                            <option value="<?=(int)$company['id']?>" <?=(int)$company['id']===(int)$selectedCompany?'selected':''?>><?=htmlspecialchars($company['company_name'])?></option>
                        <?php endforeach;?>
                    </select>
                    <select class="form-select form-select-sm rounded-xl" id="wizardScopeBranch" style="min-width: 140px;">
                        <option value="">All branches</option>
                        <?php foreach($offboardingBranches as $branch):?>
                            <option value="<?=(int)$branch['id']?>" <?=(int)$branch['id']===(int)$selectedBranch?'selected':''?>><?=htmlspecialchars($branch['branch_name'])?></option>
                        <?php endforeach;?>
                    </select>
                </div>
            </div>

            <div class="card-body p-0">
                <div class="row g-0">
                    <!-- Left Step Navigation (Vertical Stepper) -->
                    <div class="col-lg-3 border-end border-slate-200 bg-slate-50 p-4 p-lg-5">
                        <div class="offboarding-stepper d-flex flex-column gap-4">
                            <!-- Step 1: Preferences -->
                            <div class="offboarding-step-nav active cursor-pointer d-flex align-items-center gap-3" data-step="1">
                                <span class="step-badge rounded-circle d-flex align-items-center justify-content-center fw-bold">1</span>
                                <div class="step-text">
                                    <div class="fw-bold text-slate-800">Preferences</div>
                                    <small class="text-slate-400">Notice period &amp; approval</small>
                                </div>
                            </div>

                            <div class="step-connector"></div>

                            <!-- Step 2: Exit Interview (Skipped Clearances per requirement 2) -->
                            <div class="offboarding-step-nav cursor-pointer d-flex align-items-center gap-3" data-step="2">
                                <span class="step-badge rounded-circle d-flex align-items-center justify-content-center fw-bold">2</span>
                                <div class="step-text">
                                    <div class="fw-bold text-slate-800">Exit Interview</div>
                                    <small class="text-slate-400">Questions &amp; message</small>
                                </div>
                            </div>

                            <div class="step-connector"></div>

                            <!-- Step 3: Documents (Per requirement 4) -->
                            <div class="offboarding-step-nav cursor-pointer d-flex align-items-center gap-3" data-step="3">
                                <span class="step-badge rounded-circle d-flex align-items-center justify-content-center fw-bold">3</span>
                                <div class="step-text">
                                    <div class="fw-bold text-slate-800">Documents</div>
                                    <small class="text-slate-400">Automated dispatch</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Step Content Panels -->
                    <div class="col-lg-9 p-4 p-lg-6 bg-white">
                        <form id="offboardingSettingsForm">
                            <input type="hidden" name="action" value="save_offboarding_settings">
                            <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
                            <input type="hidden" name="company_id" id="hiddenCompanyId" value="<?=(int)$selectedCompany?>">
                            <input type="hidden" name="branch_id" id="hiddenBranchId" value="<?=htmlspecialchars((string)($selectedBranch ?? ''))?>">

                            <!-- Step 1: Preferences Panel (Matching Screenshot 1) -->
                            <div class="offboarding-panel" data-panel="1">
                                <div class="mb-5 pb-3 border-bottom border-slate-100">
                                    <h4 class="fw-bold text-slate-900 mb-1">Preferences</h4>
                                    <p class="text-slate-500 text-sm mb-0">Setup the basics of this offboarding flow</p>
                                </div>

                                <!-- Notice Period Box -->
                                <div class="mb-5">
                                    <div class="form-check form-switch mb-3 ps-0 d-flex align-items-center gap-3">
                                        <input class="form-check-input ms-0" type="checkbox" id="enableNoticePeriodSwitch" checked style="width: 2.75rem; height: 1.5rem;">
                                        <label class="form-check-label fw-bold text-slate-800" for="enableNoticePeriodSwitch">Enable notice period</label>
                                    </div>

                                    <div class="rounded-2xl bg-slate-50 border border-slate-200 p-4 d-flex align-items-center gap-3" style="max-width: 540px;">
                                        <span class="text-sm fw-medium text-slate-600">Standard notice period:</span>
                                        <input type="number" class="form-control rounded-xl text-center fw-bold" name="notice_period_days" min="0" max="365" value="<?=htmlspecialchars((string)($offboardingSettings['notice_period_days']??30))?>" style="max-width: 100px;" required>
                                        <select class="form-select rounded-xl" style="max-width: 110px;" disabled>
                                            <option selected>Days</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- HR Partner Box -->
                                <div class="mb-5">
                                    <label class="form-label fw-bold text-slate-800 mb-2">HR partner</label>
                                    <div class="position-relative" style="max-width: 640px;">
                                        <select class="form-select rounded-xl" name="hr_partner_user_id">
                                            <option value="">-- Select HR Partner --</option>
                                            <?php foreach($offboardingUsers as $user):?>
                                                <option value="<?=(int)$user['id']?>" <?=(int)$user['id']===(int)($offboardingSettings['hr_partner_user_id']??0)?'selected':''?>>
                                                    <?=htmlspecialchars($user['name'])?> (<?=htmlspecialchars($user['email'])?>)
                                                </option>
                                            <?php endforeach;?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Approval Flow Box -->
                                <div class="mb-4">
                                    <label class="form-label fw-bold text-slate-800 mb-2">Approval</label>
                                    <div class="rounded-2xl bg-slate-50 border border-slate-200 p-4 d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3" style="max-width: 640px;">
                                        <div class="d-flex flex-wrap align-items-center gap-2">
                                            <span class="py-2 px-3 rounded-xl fw-semibold text-xs border border-slate-200 shadow-2xs d-inline-flex align-items-center" style="background: #ffffff; color: #1e293b !important;">
                                                1 level(s) of Reporting To
                                            </span>
                                            <i class="ti ti-chevron-right text-slate-400"></i>
                                            <span class="py-2 px-3 rounded-xl fw-semibold text-xs border border-slate-200 shadow-2xs d-inline-flex align-items-center" style="background: #ffffff; color: #1e293b !important;">
                                                HR partner
                                            </span>
                                            <i class="ti ti-chevron-right text-slate-400"></i>
                                            <span class="text-xs fw-bold" style="color: #059669;">
                                                Approved / <span style="color: #e11d48;">Rejected</span>
                                            </span>
                                        </div>
                                    </div>
                                    <div style="max-width: 640px;">
                                        <label class="form-label text-xs fw-semibold text-slate-500">Designated Approver (Overrides to assigned manager)</label>
                                        <select class="form-select rounded-xl" name="approver_user_id">
                                            <option value="">Default (Any authorized HR Manager)</option>
                                            <?php foreach($offboardingUsers as $user):?>
                                                <option value="<?=(int)$user['id']?>" <?=(int)$user['id']===(int)($offboardingSettings['approver_user_id']??0)?'selected':''?>>
                                                    <?=htmlspecialchars($user['name'])?> (<?=htmlspecialchars($user['email'])?>)
                                                </option>
                                            <?php endforeach;?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Step 2: Exit Interview Panel (Matching Screenshots 2, 3, 4, 5) -->
                            <div class="offboarding-panel d-none" data-panel="2">
                                <div class="mb-4 pb-3 border-bottom border-slate-100 d-flex align-items-center justify-content-between">
                                    <div>
                                        <h4 class="fw-bold text-slate-900 mb-1">Exit Interview</h4>
                                        <p class="text-slate-500 text-sm mb-0">Update the exit interview messages and configure questionnaire</p>
                                    </div>
                                    <span class="py-1 px-3 rounded-xl text-xs fw-bold border border-emerald-200 d-inline-flex align-items-center" style="background: #ecfdf5; color: #047857 !important;">
                                        <i class="ti ti-message-2 me-1"></i>Automated on Resignation
                                    </span>
                                </div>

                                <!-- Introduction message -->
                                <div class="mb-5">
                                    <label class="form-label fw-bold text-slate-800 mb-2">Introduction message</label>
                                    <textarea class="form-control rounded-2xl p-3" name="interview_intro" rows="3" placeholder="Enter the exit interview introduction message"><?=htmlspecialchars($offboardingSettings['interview_intro']??'')?></textarea>
                                </div>

                                <!-- Questions Section -->
                                <div class="mb-5">
                                    <div class="d-flex align-items-center justify-content-between mb-3">
                                        <div>
                                            <span class="fw-bold text-slate-800 fs-6">Questions</span>
                                            <span class="text-xs text-slate-500 ms-2">(Total questions: <?=count($managerQuestions ?? [])?>)</span>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-primary rounded-xl px-3" id="addExitQuestion">
                                            <i class="ti ti-plus me-1"></i>Add Questions
                                        </button>
                                    </div>

                                    <div id="exitQuestionList" data-settings-id="<?=(int)($offboardingSettings['id']??0)?>">
                                        <?php if(!$managerQuestions):?>
                                            <div class="rounded-2xl border border-dashed border-slate-200 text-center py-6 text-slate-500">
                                                No exit interview questions configured yet. Click "Add Questions" above to add your first question.
                                            </div>
                                        <?php else:foreach($managerQuestions as $qIndex => $question):
                                            $typeIcon = match($question['question_type']) {
                                                'rating' => 'ti ti-star text-amber-500',
                                                'single_choice' => 'ti ti-circle-dot text-sky-500',
                                                'multiple_choice' => 'ti ti-checkbox text-emerald-500',
                                                default => 'ti ti-message-2 text-slate-500'
                                            };
                                        ?>
                                            <div class="rounded-2xl border border-slate-200 p-3 mb-2 bg-white exit-question-item shadow-2xs" data-question='<?=htmlspecialchars(json_encode($question,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),ENT_QUOTES,'UTF-8')?>'>
                                                <div class="d-flex align-items-center gap-3">
                                                    <span class="drag-handle text-slate-300 cursor-grab"><i class="ti ti-grip-vertical"></i></span>
                                                    <span class="px-2 py-1 rounded-lg text-xs fw-bold border border-slate-200" style="background: #f8fafc; color: #334155 !important;"><?=$qIndex + 1?></span>
                                                    <span class="p-1 rounded-lg bg-slate-50"><i class="<?=$typeIcon?>"></i></span>
                                                    <div class="flex-grow-1 min-w-0">
                                                        <div class="fw-semibold text-slate-800 text-sm text-truncate"><?=htmlspecialchars($question['question_text'])?><?=(int)$question['is_required']===1?' <span class="text-danger">*</span>':''?></div>
                                                    </div>
                                                    <div class="d-flex gap-1">
                                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary rounded-lg move-question-up" title="Move Up"><i class="ti ti-arrow-up"></i></button>
                                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary rounded-lg move-question-down" title="Move Down"><i class="ti ti-arrow-down"></i></button>
                                                        <button type="button" class="btn btn-sm btn-icon btn-outline-primary rounded-lg edit-question" title="Edit"><i class="ti ti-pencil"></i></button>
                                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger rounded-lg delete-question" title="Delete"><i class="ti ti-trash"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach;endif;?>
                                    </div>
                                </div>

                                <!-- Thank you message -->
                                <div class="mb-4">
                                    <label class="form-label fw-bold text-slate-800 mb-2">Thank you message</label>
                                    <textarea class="form-control rounded-2xl p-3" name="thank_you_message" rows="3" placeholder="Enter the exit interview thank you message"><?=htmlspecialchars($offboardingSettings['thank_you_message']??'')?></textarea>
                                    <small class="text-slate-500 mt-1 d-block">Displayed to the employee after successfully completing all exit questions.</small>
                                </div>
                            </div>

                            <!-- Step 3: Documents Panel (Per Requirement 4) -->
                            <div class="offboarding-panel d-none" data-panel="3">
                                <div class="mb-4 pb-3 border-bottom border-slate-100">
                                    <h4 class="fw-bold text-slate-900 mb-1">Documents</h4>
                                    <p class="text-slate-500 text-sm mb-0">Select offboarding-related documents to be generated and emailed automatically upon resignation approval</p>
                                </div>

                                <div class="row g-4 mb-4">
                                    <div class="col-md-6">
                                        <label class="rounded-2xl border border-slate-200 p-4 d-flex align-items-start gap-3 cursor-pointer h-100 bg-slate-50 hover:bg-white transition-all">
                                            <input class="form-check-input mt-1" type="checkbox" name="send_experience_letter" value="1" <?=(int)($offboardingSettings['send_experience_letter']??1)===1?'checked':''?>>
                                            <div>
                                                <div class="d-flex align-items-center gap-2 mb-1">
                                                    <i class="ti ti-file-certificate text-primary fs-5"></i>
                                                    <strong class="text-slate-800">Experience Letter</strong>
                                                </div>
                                                <small class="text-slate-500">Automatically creates and attaches the official Experience Certificate to the approval email.</small>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="rounded-2xl border border-slate-200 p-4 d-flex align-items-start gap-3 cursor-pointer h-100 bg-slate-50 hover:bg-white transition-all">
                                            <input class="form-check-input mt-1" type="checkbox" name="send_relieving_letter" value="1" <?=(int)($offboardingSettings['send_relieving_letter']??1)===1?'checked':''?>>
                                            <div>
                                                <div class="d-flex align-items-center gap-2 mb-1">
                                                    <i class="ti ti-file-description text-primary fs-5"></i>
                                                    <strong class="text-slate-800">Relieving Letter</strong>
                                                </div>
                                                <small class="text-slate-500">Automatically creates and attaches the Relieving Letter with confirmed last working date.</small>
                                            </div>
                                        </label>
                                    </div>
                                </div>

                                <div class="rounded-2xl bg-amber-50 border border-amber-200 p-4 d-flex align-items-center gap-3">
                                    <i class="ti ti-shield-check text-amber-700 fs-4 flex-shrink-0"></i>
                                    <div class="text-xs text-amber-800">
                                        <strong>Dispatch Rule:</strong> Documents are generated and dispatched <em>only</em> if the resignation is <strong>Approved</strong>. If a resignation is <strong>Rejected</strong>, no documents will be sent to the employee.
                                    </div>
                                </div>
                            </div>

                            <!-- Wizard Bottom Navigation -->
                            <div class="pt-4 mt-5 border-top border-slate-100 d-flex align-items-center justify-content-between">
                                <button type="button" class="btn btn-outline-secondary rounded-xl d-none" id="wizardPrevBtn">
                                    <i class="ti ti-arrow-left me-1"></i>Previous
                                </button>
                                <div class="d-flex gap-2 ms-auto">
                                    <button type="submit" class="btn btn-outline-primary rounded-xl px-4">
                                        <i class="ti ti-check me-1"></i>Save All
                                    </button>
                                    <button type="button" class="btn btn-primary rounded-xl px-4" id="wizardNextBtn">
                                        Next<i class="ti ti-arrow-right ms-1"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Manager Resignation Requests Review Table -->
        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-5 d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                <div>
                    <h5 class="mb-1 fw-bold text-slate-900">Resignation Requests</h5>
                    <p class="mb-0 text-sm text-slate-500">Review each employee request in a single approval workflow.</p>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <input type="hidden" id="offboardingPerPage" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="offboardingPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="offboarding-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                        </ul>
                    </div>
                    <div class="position-relative" style="min-width: 220px;">
                        <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:12px;"></i>
                        <input type="text" id="offboardingSearch" class="form-control rounded-xl ps-5 py-2 text-sm border-slate-200" placeholder="Search requests...">
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="bg-slate-50">
                        <tr>
                            <th class="px-5 py-3 text-xs text-uppercase text-slate-500">Employee</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Request</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Resignation</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Last Day</th>
                            <th class="py-3 text-xs text-uppercase text-slate-500">Status</th>
                            <th class="px-5 py-3 text-xs text-uppercase text-slate-500 text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody id="managerResignationsTableBody">
                        <tr><td colspan="6" class="text-center py-10 text-slate-500">Loading requests...</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="offboarding-pagination-container">
                <style>
                    #offboardingFooterPerPageSelect + .dropdown {
                        display: none !important;
                    }
                </style>
                <?= getPaginationFooter('offboardingPaginationWrapper', 'offboardingPaginationSummary', 'offboardingFooterPerPageSelect') ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if($offboardingEmployee):?>
<div class="modal fade" id="resignationModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-2xl border-0 shadow-xl overflow-hidden">
            <!-- Modal Header with Progress Stepper -->
            <div class="modal-header p-4 px-5 border-bottom border-slate-100 bg-slate-50 d-flex align-items-center justify-content-between">
                <div>
                    <h5 class="modal-title fw-bold text-slate-900 mb-0" id="resignationModalTitle">Employee Resignation &amp; Exit Process</h5>
                    <p class="mb-0 text-xs text-slate-500" id="resignationModalSubtitle">Step 1 of 3: Notice Period &amp; Reason</p>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge rounded-pill bg-primary text-white px-3 py-1.5 text-xs fw-bold" id="resignStepBadge">Step 1 of 3</span>
                    <button type="button" class="btn-close ms-2" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>

            <form id="resignationForm">
                <input type="hidden" name="action" value="submit_resignation">
                <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
                <input type="hidden" id="standardNoticeDays" value="<?=(int)($employeeSettings['notice_period_days']??30)?>">

                <div class="modal-body p-5">
                    <!-- Step 1: Resignation Details & Notice Period -->
                    <div id="resignStep1">
                        <div class="rounded-2xl bg-sky-50 border border-sky-200 p-4 mb-4">
                            <div class="d-flex align-items-center gap-2 text-sky-900 fw-bold text-sm mb-1">
                                <i class="ti ti-info-circle fs-5 text-sky-600"></i> Standard Notice Period
                            </div>
                            <div class="text-xs text-sky-800">
                                Your organization specifies a standard notice period of <strong><?=(int)($employeeSettings['notice_period_days']??30)?> days</strong>.
                                Based on your selected resignation date, your requested last working date will be <strong id="calculatedLastWorkingDate" class="text-sky-900">—</strong>.
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold text-slate-800">Resignation Date *</label>
                            <input type="date" class="form-control rounded-xl p-3" id="employeeResignDate" name="resignation_date" value="<?=date('Y-m-d')?>" required>
                        </div>

                        <div class="mb-2">
                            <label class="form-label fw-bold text-slate-800">Reason for Resignation *</label>
                            <textarea class="form-control rounded-xl p-3" id="employeeResignReason" name="reason" rows="4" minlength="10" maxlength="4000" placeholder="Please describe the reason for your resignation..." required></textarea>
                            <small class="text-slate-400 mt-1 d-block">Minimum 10 characters.</small>
                        </div>
                    </div>

                    <!-- Step 2: Exit Interview Questionnaire -->
                    <div id="resignStep2" class="d-none">
                        <!-- Introduction message configured by HR -->
                        <div class="rounded-2xl bg-emerald-50 border border-emerald-200 p-4 mb-4">
                            <div class="d-flex align-items-center gap-2 text-emerald-900 fw-bold text-sm mb-1">
                                <i class="ti ti-message-2 fs-5 text-emerald-600"></i> Exit Interview Introduction
                            </div>
                            <div class="text-xs text-emerald-800" style="white-space: pre-line;">
                                <?= htmlspecialchars($employeeSettings['interview_intro'] ?? 'Please complete this exit interview to help us understand your experience and improve our workplace.') ?>
                            </div>
                        </div>

                        <div class="mb-3">
                            <h6 class="fw-bold text-slate-900 mb-3">Exit Questions (<?=count($exitQuestions ?? [])?>)</h6>
                            <?php if(!$exitQuestions):?>
                                <div class="text-slate-500 text-sm py-4 text-center border border-dashed rounded-xl bg-slate-50">No additional exit interview questions are configured. Click Next to continue.</div>
                            <?php endif;?>
                            <?php foreach ($exitQuestions as $index => $question): $options=json_decode($question['options_json'] ?? '[]',true) ?: []; ?>
                                <div class="mb-4 p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 exit-modal-question" data-question-id="<?=(int)$question['id']?>" data-question-type="<?=htmlspecialchars($question['question_type'])?>">
                                    <label class="form-label fw-bold text-slate-800 mb-2 d-block">
                                        <?=($index+1)?>. <?=htmlspecialchars($question['question_text'])?>
                                        <?=(int)$question['is_required']===1?' <span class="text-danger">*</span>':''?>
                                    </label>
                                    <?php if ($question['question_type']==='long_text'): ?>
                                        <textarea class="form-control rounded-xl exit-answer-input" rows="3" placeholder="Your feedback..." <?=(int)$question['is_required']===1?'required':''?>></textarea>
                                    <?php elseif ($question['question_type']==='short_text'): ?>
                                        <input class="form-control rounded-xl exit-answer-input" placeholder="Your answer..." <?=(int)$question['is_required']===1?'required':''?>>
                                    <?php elseif ($question['question_type']==='rating'): ?>
                                        <select class="form-select rounded-xl exit-answer-input" <?=(int)$question['is_required']===1?'required':''?>>
                                            <option value="">Select rating (1 to 5)</option>
                                            <option value="5">★★★★★ - Excellent (5/5)</option>
                                            <option value="4">★★★★☆ - Very Good (4/5)</option>
                                            <option value="3">★★★☆☆ - Good (3/5)</option>
                                            <option value="2">★★☆☆☆ - Fair (2/5)</option>
                                            <option value="1">★☆☆☆☆ - Poor (1/5)</option>
                                        </select>
                                    <?php else: ?>
                                        <div class="d-flex flex-column gap-2 mt-1">
                                            <?php foreach($options as $option): ?>
                                                <label class="rounded-xl border border-slate-200 bg-white p-2.5 px-3 cursor-pointer d-flex align-items-center gap-2 mb-0">
                                                    <input class="form-check-input exit-choice-input" type="<?=$question['question_type']==='multiple_choice'?'checkbox':'radio'?>" name="modal_exit_q_<?=(int)$question['id']?><?=$question['question_type']==='multiple_choice'?'[]':''?>" value="<?=htmlspecialchars($option)?>">
                                                    <span class="text-sm text-slate-700"><?=htmlspecialchars($option)?></span>
                                                </label>
                                            <?php endforeach;?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Step 3: Review, Thank-You Message & Final Submission (Last Step) -->
                    <div id="resignStep3" class="d-none">
                        <div class="rounded-2xl bg-slate-50 border border-slate-200 p-4 mb-4">
                            <div class="fw-bold text-slate-900 mb-3 text-sm d-flex align-items-center gap-2">
                                <i class="ti ti-file-check fs-5 text-primary"></i> Resignation Summary
                            </div>
                            <div class="row g-3 text-xs">
                                <div class="col-sm-6">
                                    <div class="text-slate-400 text-uppercase fw-bold mb-1">Resignation Date</div>
                                    <div class="fw-bold text-slate-800" id="summaryResignDate">—</div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="text-slate-400 text-uppercase fw-bold mb-1">Requested Last Working Date</div>
                                    <div class="fw-bold text-slate-800" id="summaryLastDay">—</div>
                                </div>
                                <div class="col-12">
                                    <div class="text-slate-400 text-uppercase fw-bold mb-1">Reason</div>
                                    <div class="text-slate-700 fst-italic" id="summaryReason">—</div>
                                </div>
                            </div>
                        </div>

                        <!-- Thank-you message configured by HR -->
                        <div class="rounded-2xl bg-emerald-50/70 border border-emerald-200 p-4 mb-4">
                            <div class="d-flex align-items-center gap-2 text-emerald-900 fw-bold text-sm mb-1">
                                <i class="ti ti-heart-handshake fs-5 text-emerald-600"></i> Message from Human Resources
                            </div>
                            <div class="text-xs text-emerald-800" style="white-space: pre-line;" id="step3ThankYouMsg">
                                <?= htmlspecialchars($employeeSettings['thank_you_message'] ?? 'Thank you for your feedback and contributions. We wish you all the best in your future endeavors.') ?>
                            </div>
                        </div>

                        <div class="alert alert-warning d-flex align-items-center gap-2 rounded-xl text-xs mb-0 py-2.5">
                            <i class="ti ti-alert-triangle fs-5 flex-shrink-0"></i>
                            <span>Clicking <strong>Submit Resignation</strong> below will send your formal resignation and exit answers to your HR Manager.</span>
                        </div>
                    </div>

                    <!-- Step 4 / Success State: Displayed after clicking Submit on Step 3 -->
                    <div id="resignSuccessView" class="d-none text-center py-4">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3 shadow-sm" style="width:72px; height:72px; background: #dcfce7; color: #15803d;">
                            <i class="ti ti-check fs-1 fw-bold"></i>
                        </div>
                        <h4 class="fw-bold mb-2" style="color: #0f172a !important; font-size: 1.4rem;">Resignation Submitted</h4>
                        
                        <div class="mb-4">
                            <div class="d-inline-flex align-items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 shadow-2xs" style="background: #f8fafc;">
                                <i class="ti ti-file-text text-slate-500 fs-5"></i>
                                <span class="text-xs fw-bold text-uppercase" style="color: #475569 !important; letter-spacing: 0.5px;">Request No:</span>
                                <span class="fw-bold fs-6 font-monospace" id="submittedRequestNo" style="color: #0f172a !important;">RES-XXXX</span>
                            </div>
                        </div>

                        <div class="rounded-2xl border border-emerald-200 p-4 mx-auto mb-4 text-sm shadow-2xs text-start" style="max-width: 560px; white-space: pre-line; background: #f0fdf4; color: #065f46 !important; font-size: 0.95rem; line-height: 1.6;" id="submittedThankYouMsg">
                            <?= htmlspecialchars($employeeSettings['thank_you_message'] ?? 'Thank you for your feedback and contributions. We wish you all the best.') ?>
                        </div>

                        <p class="text-xs mb-0" style="color: #64748b !important; max-width: 520px; margin: 0 auto;">An automated notification alert has been sent to the HR Manager. You can track review progress and access approved documents below.</p>
                    </div>
                </div>

                <div class="modal-footer p-4 border-top border-slate-100 d-flex justify-content-between align-items-center" id="resignModalFooter">
                    <div>
                        <button type="button" class="btn btn-outline-secondary rounded-xl d-none" id="resignBackBtn">
                            <i class="ti ti-arrow-left me-1"></i>Back
                        </button>
                        <button type="button" class="btn btn-outline-secondary rounded-xl" id="resignCancelBtn" data-bs-dismiss="modal">
                            Cancel
                        </button>
                    </div>

                    <div class="d-flex gap-2 ms-auto">
                        <button type="button" class="btn btn-primary rounded-xl px-4" id="resignNextBtn">
                            Next<i class="ti ti-arrow-right ms-1"></i>
                        </button>
                        <button type="submit" class="btn btn-danger rounded-xl px-4 d-none" id="resignFinalSubmitBtn">
                            <i class="ti ti-logout-2 me-1"></i>Submit Resignation
                        </button>
                    </div>
                </div>

                <div class="modal-footer p-4 border-top border-slate-100 text-center justify-content-center d-none" id="resignDoneFooter">
                    <button type="button" class="btn btn-primary rounded-xl px-6" onclick="location.reload();">Done</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif;?>

<?php if($canManageOffboarding):?>
<div class="modal fade" id="reviewResignationModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-2xl border-0 shadow-lg">
            <div class="modal-header p-5 border-bottom border-slate-100">
                <div>
                    <h5 class="modal-title fw-bold text-slate-900" id="resignationReviewTitle"></h5>
                    <p class="mb-0 text-sm text-slate-500" id="resignationReviewEmployee"></p>
                </div>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-5">
                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <div class="text-xs text-uppercase fw-bold text-slate-400">Requested last day</div>
                        <div class="fw-bold text-slate-800 fs-6" id="requestedLastDay"></div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Approved last working date</label>
                        <input type="date" class="form-control rounded-xl" id="approvedLastDay">
                    </div>
                </div>
                <div class="mb-4">
                    <div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Reason</div>
                    <div class="text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100" id="resignationReason"></div>
                </div>
                <div id="resignationDecisionFields">
                    <label class="form-label fw-bold">Approval note</label>
                    <textarea class="form-control rounded-xl" id="resignationNote" rows="3" placeholder="Optional notes regarding the approval or last working date..."></textarea>
                </div>
            </div>
            <div class="modal-footer p-4 border-top border-slate-100" id="resignationActions">
                <button class="btn btn-outline-secondary rounded-xl me-auto" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-outline-danger rounded-xl resignation-decision px-4" data-decision="rejected">Reject</button>
                <button class="btn btn-primary rounded-xl resignation-decision px-4" data-decision="approved">Approve</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exitQuestionModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-2xl border-0 shadow-lg">
            <div class="modal-header p-5 border-bottom border-slate-100">
                <h5 class="modal-title fw-bold text-slate-900">Exit Interview Question</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="exitQuestionForm">
                <div class="modal-body p-5">
                    <input type="hidden" name="action" value="save_exit_question">
                    <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
                    <input type="hidden" name="settings_id" value="<?=(int)($offboardingSettings['id']??0)?>">
                    <input type="hidden" name="question_id">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Question *</label>
                        <textarea class="form-control rounded-xl" name="question_text" rows="3" placeholder="Enter question text..." required></textarea>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-bold">Answer Type *</label>
                        <select class="form-select rounded-xl" name="question_type">
                            <option value="short_text">Short Text</option>
                            <option value="long_text">Long Text</option>
                            <option value="single_choice">Single Choice</option>
                            <option value="multiple_choice">Multiple Choice</option>
                            <option value="rating">Rating (1 to 5)</option>
                        </select>
                    </div>
                    <div class="mb-4 d-none" id="questionOptionsField">
                        <label class="form-label fw-bold">Options</label>
                        <textarea class="form-control rounded-xl" name="options" rows="4" placeholder="One option per line"></textarea>
                    </div>
                    <label class="form-check">
                        <input class="form-check-input" type="checkbox" name="is_required" value="1">
                        <span class="form-check-label fw-semibold text-slate-700">Required question</span>
                    </label>
                </div>
                <div class="modal-footer p-4 border-top border-slate-100">
                    <button type="button" class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary rounded-xl px-4">Save Question</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif;?>

<?php startSection('scripts');?>
<style>
.offboarding-step-nav {
    padding: 0.75rem;
    border-radius: 0.75rem;
    transition: all 0.2s ease;
}
.offboarding-step-nav .step-badge {
    width: 34px;
    height: 34px;
    background: #e2e8f0;
    color: #475569 !important;
    font-size: 0.875rem;
    font-weight: 700;
    transition: all 0.2s ease;
}
.offboarding-step-nav.active {
    background: #ffffff;
    box-shadow: 0 4px 12px rgba(15, 23, 42, 0.06);
}
.offboarding-step-nav.active .step-badge {
    background: #0284c7 !important;
    color: #ffffff !important;
}
.step-connector {
    width: 2px;
    height: 24px;
    background: #cbd5e1;
    margin-left: 1.25rem;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const csrf = <?=json_encode($_SESSION['csrf_token'])?>;
    if (new URL(window.location.href).searchParams.get('open') === 'resign' && document.getElementById('resignationModal')) {
        bootstrap.Modal.getOrCreateInstance(document.getElementById('resignationModal')).show();
        const cleanUrl = new URL(window.location.href);
        cleanUrl.searchParams.delete('open');
        history.replaceState({}, '', cleanUrl);
    }
    const post = async form => {
        const response = await fetch('hrms-api.php', { method: 'POST', body: form, credentials: 'same-origin' });
        const data = await response.json().catch(() => ({ status: 'error', message: 'Invalid server response.' }));
        if (!response.ok || data.status !== 'success') throw new Error(data.message || 'Request failed.');
        return data;
    };
    const notify = (type, message) => window.toastr ? toastr[type](message) : alert(message);

    // Stepper Wizard logic
    let currentWizardStep = 1;
    const showWizardStep = step => {
        currentWizardStep = step;
        document.querySelectorAll('.offboarding-panel').forEach(panel => {
            panel.classList.toggle('d-none', Number(panel.dataset.panel) !== step);
        });
        document.querySelectorAll('.offboarding-step-nav').forEach(nav => {
            const navStep = Number(nav.dataset.step);
            nav.classList.toggle('active', navStep === step);
        });
        const prevBtn = document.getElementById('wizardPrevBtn');
        const nextBtn = document.getElementById('wizardNextBtn');
        if (prevBtn) prevBtn.classList.toggle('d-none', step === 1);
        if (nextBtn) {
            if (step === 3) {
                nextBtn.innerHTML = '<i class="ti ti-check me-1"></i>Save All';
                nextBtn.type = 'submit';
            } else {
                nextBtn.innerHTML = 'Next<i class="ti ti-arrow-right ms-1"></i>';
                nextBtn.type = 'button';
            }
        }
    };

    document.querySelectorAll('.offboarding-step-nav').forEach(nav => {
        nav.addEventListener('click', () => showWizardStep(Number(nav.dataset.step)));
    });
    document.getElementById('wizardPrevBtn')?.addEventListener('click', () => {
        showWizardStep(Math.max(1, currentWizardStep - 1));
    });
    document.getElementById('wizardNextBtn')?.addEventListener('click', event => {
        if (currentWizardStep < 3) {
            event.preventDefault();
            showWizardStep(currentWizardStep + 1);
        }
    });

    // Scope change listeners
    const scopeCompany = document.getElementById('wizardScopeCompany');
    const scopeBranch = document.getElementById('wizardScopeBranch');
    const updateScope = () => {
        const url = new URL(window.location.href);
        if (scopeCompany?.value) url.searchParams.set('company_id', scopeCompany.value);
        if (scopeBranch?.value) url.searchParams.set('branch_id', scopeBranch.value);
        else url.searchParams.delete('branch_id');
        window.location.href = url.toString();
    };
    scopeCompany?.addEventListener('change', updateScope);
    scopeBranch?.addEventListener('change', updateScope);

    // Dynamic Notice Period & Tentative Last Working Date calculation
    const resignDateInput = document.getElementById('employeeResignDate');
    const noticeDaysInput = document.getElementById('standardNoticeDays');
    const lastWorkingDateEl = document.getElementById('calculatedLastWorkingDate');
    
    const updateCalculatedLastDay = () => {
        if (!resignDateInput || !lastWorkingDateEl) return;
        const dateVal = resignDateInput.value;
        const days = Number(noticeDaysInput?.value || 30);
        if (!dateVal) {
            lastWorkingDateEl.textContent = '—';
            return;
        }
        const d = new Date(dateVal);
        d.setDate(d.getDate() + days);
        const options = { day: '2-digit', month: 'short', year: 'numeric' };
        lastWorkingDateEl.textContent = d.toLocaleDateString('en-GB', options);
    };
    resignDateInput?.addEventListener('input', updateCalculatedLastDay);
    updateCalculatedLastDay();

    // Employee Resignation 3-Step Wizard Stepper
    let currentEmployeeResignStep = 1;
    const resignStep1 = document.getElementById('resignStep1');
    const resignStep2 = document.getElementById('resignStep2');
    const resignStep3 = document.getElementById('resignStep3');
    const resignSuccessView = document.getElementById('resignSuccessView');
    const resignNextBtn = document.getElementById('resignNextBtn');
    const resignBackBtn = document.getElementById('resignBackBtn');
    const resignCancelBtn = document.getElementById('resignCancelBtn');
    const resignFinalSubmitBtn = document.getElementById('resignFinalSubmitBtn');
    const resignModalFooter = document.getElementById('resignModalFooter');
    const resignDoneFooter = document.getElementById('resignDoneFooter');
    const resignModalTitle = document.getElementById('resignationModalTitle');
    const resignModalSubtitle = document.getElementById('resignationModalSubtitle');
    const resignStepBadge = document.getElementById('resignStepBadge');

    const updateResignWizard = (step) => {
        currentEmployeeResignStep = step;
        resignStep1?.classList.toggle('d-none', step !== 1);
        resignStep2?.classList.toggle('d-none', step !== 2);
        resignStep3?.classList.toggle('d-none', step !== 3);
        resignSuccessView?.classList.add('d-none');

        if (step === 1) {
            if (resignModalTitle) resignModalTitle.textContent = 'Employee Resignation & Exit Process';
            if (resignModalSubtitle) resignModalSubtitle.textContent = 'Step 1 of 3: Notice Period & Reason';
            if (resignStepBadge) resignStepBadge.textContent = 'Step 1 of 3';

            resignBackBtn?.classList.add('d-none');
            resignCancelBtn?.classList.remove('d-none');
            resignNextBtn?.classList.remove('d-none');
            if (resignNextBtn) resignNextBtn.innerHTML = 'Next<i class="ti ti-arrow-right ms-1"></i>';
            resignFinalSubmitBtn?.classList.add('d-none');
        } else if (step === 2) {
            if (resignModalTitle) resignModalTitle.textContent = 'Exit Interview Questionnaire';
            if (resignModalSubtitle) resignModalSubtitle.textContent = 'Step 2 of 3: Employee Feedback';
            if (resignStepBadge) resignStepBadge.textContent = 'Step 2 of 3';

            resignBackBtn?.classList.remove('d-none');
            resignCancelBtn?.classList.add('d-none');
            resignNextBtn?.classList.remove('d-none');
            if (resignNextBtn) resignNextBtn.innerHTML = 'Next<i class="ti ti-arrow-right ms-1"></i>';
            resignFinalSubmitBtn?.classList.add('d-none');
        } else if (step === 3) {
            if (resignModalTitle) resignModalTitle.textContent = 'Review & Final Submission';
            if (resignModalSubtitle) resignModalSubtitle.textContent = 'Step 3 of 3: Final Confirmation';
            if (resignStepBadge) resignStepBadge.textContent = 'Step 3 of 3';
            
            // Populate summary
            const dateVal = resignDateInput?.value || '—';
            const reasonVal = document.getElementById('employeeResignReason')?.value.trim() || '—';
            const lastDayVal = lastWorkingDateEl?.textContent || '—';
            
            const summaryDateEl = document.getElementById('summaryResignDate');
            if (summaryDateEl) summaryDateEl.textContent = dateVal;
            const summaryLastDayEl = document.getElementById('summaryLastDay');
            if (summaryLastDayEl) summaryLastDayEl.textContent = lastDayVal;
            const summaryReasonEl = document.getElementById('summaryReason');
            if (summaryReasonEl) summaryReasonEl.textContent = reasonVal;

            resignBackBtn?.classList.remove('d-none');
            resignCancelBtn?.classList.add('d-none');
            resignNextBtn?.classList.add('d-none');
            resignFinalSubmitBtn?.classList.remove('d-none');
            if (resignFinalSubmitBtn) resignFinalSubmitBtn.innerHTML = '<i class="ti ti-logout-2 me-1"></i>Submit Resignation';
        }
    };

    resignNextBtn?.addEventListener('click', () => {
        if (currentEmployeeResignStep === 1) {
            const reason = document.getElementById('employeeResignReason')?.value.trim() || '';
            const resignDate = resignDateInput?.value.trim() || '';
            if (!resignDate) {
                notify('error', 'Please select a valid resignation date.');
                return;
            }
            if (reason.length < 10) {
                notify('error', 'Please enter a resignation reason of at least 10 characters.');
                document.getElementById('employeeResignReason')?.focus();
                return;
            }
            updateResignWizard(2);
        } else if (currentEmployeeResignStep === 2) {
            let missingRequired = false;
            document.querySelectorAll('.exit-modal-question').forEach(question => {
                const type = question.dataset.questionType;
                let val = '';
                if (['single_choice', 'multiple_choice'].includes(type)) {
                    val = [...question.querySelectorAll('.exit-choice-input:checked')].map(i => i.value);
                    if (type === 'single_choice') val = val[0] || '';
                } else {
                    val = question.querySelector('.exit-answer-input')?.value.trim() || '';
                }
                if (question.querySelector('[required]') && (!val || (Array.isArray(val) && val.length === 0))) {
                    missingRequired = true;
                }
            });
            if (missingRequired) {
                notify('error', 'Please answer all required exit interview questions before proceeding.');
                return;
            }
            updateResignWizard(3);
        }
    });

    resignBackBtn?.addEventListener('click', () => {
        if (currentEmployeeResignStep > 1) {
            updateResignWizard(currentEmployeeResignStep - 1);
        }
    });

    // Reset wizard when modal is reopened
    document.getElementById('resignationModal')?.addEventListener('show.bs.modal', () => {
        updateResignWizard(1);
    });

    // Employee Resignation Form Submission (triggered strictly from Step 3)
    document.getElementById('resignationForm')?.addEventListener('submit', async event => {
        event.preventDefault();
        
        // Collect exit interview answers
        const answers = {};
        document.querySelectorAll('.exit-modal-question').forEach(question => {
            const id = question.dataset.questionId;
            const type = question.dataset.questionType;
            if (['single_choice', 'multiple_choice'].includes(type)) {
                const checked = [...question.querySelectorAll('.exit-choice-input:checked')].map(i => i.value);
                answers[id] = type === 'single_choice' ? (checked[0] || '') : checked;
            } else {
                answers[id] = question.querySelector('.exit-answer-input')?.value.trim() || '';
            }
        });

        const form = new FormData(event.currentTarget);
        form.set('answers', JSON.stringify(answers));

        try {
            if (resignFinalSubmitBtn) {
                resignFinalSubmitBtn.disabled = true;
                resignFinalSubmitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Submitting...';
            }
            const data = await post(form);
            
            // Switch to Completion Confirmation Screen
            resignStep1?.classList.add('d-none');
            resignStep2?.classList.add('d-none');
            resignStep3?.classList.add('d-none');
            resignSuccessView?.classList.remove('d-none');
            
            if (resignModalTitle) resignModalTitle.textContent = 'Resignation Request Processed';
            if (resignModalSubtitle) resignModalSubtitle.textContent = 'Submission Completed';
            if (resignStepBadge) {
                resignStepBadge.textContent = 'Completed';
                resignStepBadge.className = 'badge rounded-pill bg-emerald-600 text-white px-3 py-1.5 text-xs fw-bold';
            }

            const requestNoEl = document.getElementById('submittedRequestNo');
            if (requestNoEl && data.request_no) requestNoEl.textContent = data.request_no;

            const thankYouEl = document.getElementById('submittedThankYouMsg');
            if (thankYouEl && data.thank_you_message) thankYouEl.textContent = data.thank_you_message;

            resignModalFooter?.classList.add('d-none');
            resignDoneFooter?.classList.remove('d-none');
            notify('success', data.message || 'Resignation request submitted successfully.');
        } catch (error) {
            if (resignFinalSubmitBtn) {
                resignFinalSubmitBtn.disabled = false;
                resignFinalSubmitBtn.innerHTML = '<i class="ti ti-logout-2 me-1"></i>Submit Resignation';
            }
            notify('error', error.message);
        }
    });

    // Save Offboarding Settings Form
    document.getElementById('offboardingSettingsForm')?.addEventListener('submit', async event => {
        event.preventDefault();
        try {
            const data = await post(new FormData(event.currentTarget));
            notify('success', data.message);
            location.reload();
        } catch (error) {
            notify('error', error.message);
        }
    });

    // Standalone Exit Interview Form (if applicable)
    document.getElementById('exitInterviewForm')?.addEventListener('submit', async event => {
        event.preventDefault();
        const answers = {};
        document.querySelectorAll('.exit-question').forEach(question => {
            const id = question.dataset.questionId, type = question.dataset.questionType;
            if (['single_choice', 'multiple_choice'].includes(type)) {
                answers[id] = [...question.querySelectorAll('.exit-choice:checked')].map(input => input.value);
                if (type === 'single_choice') answers[id] = answers[id][0] || '';
            } else {
                answers[id] = question.querySelector('.exit-answer')?.value || '';
            }
        });
        const form = new FormData(event.currentTarget);
        form.set('answers', JSON.stringify(answers));
        try {
            const data = await post(form);
            notify('success', data.message);
            location.reload();
        } catch (error) {
            notify('error', error.message);
        }
    });

    // Review Resignation Request Modal
    let reviewRequest = null;
    $(document).on('click', '.review-resignation', function() {
        const button = this;
        const requestDataAttr = button.getAttribute('data-request') || '{}';
        reviewRequest = JSON.parse(requestDataAttr);
        document.getElementById('resignationReviewTitle').textContent = reviewRequest.request_no;
        document.getElementById('resignationReviewEmployee').textContent = `${reviewRequest.first_name} ${reviewRequest.last_name} (${reviewRequest.emp_code||'No ID'})`;
        document.getElementById('requestedLastDay').textContent = reviewRequest.requested_last_working_date;
        document.getElementById('approvedLastDay').value = reviewRequest.approved_last_working_date || reviewRequest.requested_last_working_date;
        document.getElementById('resignationReason').textContent = reviewRequest.reason;
        document.getElementById('resignationNote').value = reviewRequest.action_note || '';
        
        const isPending = reviewRequest.status === 'pending';
        const canReview = Number(reviewRequest.can_review ?? 1) === 1;

        // Ensure fields are properly interactive or disabled based on status
        const approvedDayInput = document.getElementById('approvedLastDay');
        if (approvedDayInput) approvedDayInput.disabled = !isPending;
        const noteInput = document.getElementById('resignationNote');
        if (noteInput) noteInput.disabled = !isPending;

        // Show/hide approve & reject buttons
        document.querySelectorAll('.resignation-decision').forEach(btn => {
            btn.classList.toggle('d-none', !isPending || !canReview);
        });

        // Ensure modal footer is always visible with at least Close button
        const modalFooter = document.getElementById('resignationActions');
        if (modalFooter) modalFooter.classList.remove('d-none');
        
        const decisionFields = document.getElementById('resignationDecisionFields');
        if (decisionFields) decisionFields.classList.remove('d-none');

        let notice = document.getElementById('assignedApproverNotice');
        if (!notice) {
            notice = document.createElement('div');
            notice.id = 'assignedApproverNotice';
            notice.className = 'alert alert-info mx-5 mt-4 mb-0';
            notice.textContent = 'This request is assigned to another configured approver and is available as view-only.';
            document.querySelector('#reviewResignationModal .modal-body')?.before(notice);
        }
        notice.classList.toggle('d-none', isPending && canReview);
        
        bootstrap.Modal.getOrCreateInstance(document.getElementById('reviewResignationModal')).show();
    });

    document.querySelectorAll('.resignation-decision').forEach(button => button.addEventListener('click', async () => {
        if (!reviewRequest) return;
        const form = new FormData();
        form.set('action', 'review_resignation');
        form.set('csrf_token', csrf);
        form.set('request_id', reviewRequest.id);
        form.set('decision', button.dataset.decision);
        form.set('note', document.getElementById('resignationNote').value);
        form.set('approved_last_working_date', document.getElementById('approvedLastDay').value);
        try {
            button.disabled = true;
            const data = await post(form);
            notify('success', data.message);
            location.reload();
        } catch (error) {
            button.disabled = false;
            notify('error', error.message);
        }
    }));

    // Exit Interview Questions CRUD & Reorder
    const questionModal = document.getElementById('exitQuestionModal');
    const questionForm = document.getElementById('exitQuestionForm');
    const toggleOptions = () => document.getElementById('questionOptionsField')?.classList.toggle('d-none', !['single_choice', 'multiple_choice'].includes(questionForm?.elements.question_type.value));
    questionForm?.elements.question_type.addEventListener('change', toggleOptions);

    document.getElementById('addExitQuestion')?.addEventListener('click', () => {
        questionForm.reset();
        questionForm.elements.question_id.value = '';
        questionForm.elements.settings_id.value = document.getElementById('exitQuestionList')?.dataset.settingsId || '';
        toggleOptions();
        bootstrap.Modal.getOrCreateInstance(questionModal).show();
    });

    document.querySelectorAll('.edit-question').forEach(button => button.addEventListener('click', () => {
        const question = JSON.parse(button.closest('.exit-question-item').dataset.question);
        questionForm.elements.question_id.value = question.id;
        questionForm.elements.question_text.value = question.question_text;
        questionForm.elements.question_type.value = question.question_type;
        questionForm.elements.options.value = (JSON.parse(question.options_json || '[]')).join('\n');
        questionForm.elements.is_required.checked = Number(question.is_required) === 1;
        toggleOptions();
        bootstrap.Modal.getOrCreateInstance(questionModal).show();
    }));

    questionForm?.addEventListener('submit', async event => {
        event.preventDefault();
        try {
            const data = await post(new FormData(questionForm));
            notify('success', data.message);
            location.reload();
        } catch (error) {
            notify('error', error.message);
        }
    });

    document.querySelectorAll('.delete-question').forEach(button => button.addEventListener('click', async () => {
        if (!confirm('Remove this exit interview question?')) return;
        const question = JSON.parse(button.closest('.exit-question-item').dataset.question);
        const form = new FormData();
        form.set('action', 'delete_exit_question');
        form.set('csrf_token', csrf);
        form.set('question_id', question.id);
        try {
            const data = await post(form);
            notify('success', data.message);
            location.reload();
        } catch (error) {
            notify('error', error.message);
        }
    }));

    const saveOrder = async () => {
        const list = document.getElementById('exitQuestionList');
        const ids = [...list.querySelectorAll('.exit-question-item')].map(item => JSON.parse(item.dataset.question).id);
        if (!ids.length) return;
        const form = new FormData();
        form.set('action', 'reorder_exit_questions');
        form.set('csrf_token', csrf);
        form.set('settings_id', list.dataset.settingsId);
        form.set('question_ids', JSON.stringify(ids));
        try {
            await post(form);
        } catch (error) {
            notify('error', error.message);
        }
    };

    document.querySelectorAll('.move-question-up, .move-question-down').forEach(button => button.addEventListener('click', () => {
        const item = button.closest('.exit-question-item');
        if (button.classList.contains('move-question-up') && item.previousElementSibling) item.parentNode.insertBefore(item, item.previousElementSibling);
        if (button.classList.contains('move-question-down') && item.nextElementSibling) item.parentNode.insertBefore(item.nextElementSibling, item);
        saveOrder();
    }));

    // Smart Pagination Renderer
    function renderSmartPaginationJs(totalPages, currentPage, callbackName) {
        totalPages = Math.max(1, parseInt(totalPages) || 1);
        currentPage = Math.min(Math.max(1, parseInt(currentPage) || 1), totalPages);

        if (totalPages <= 1) {
            return '';
        }

        let html = '';

        // Previous
        const prev = currentPage - 1;
        const prevDisabled = (currentPage === 1) ? 'disabled' : '';
        const prevOnclick = (currentPage === 1) ? '' : 'onclick="' + callbackName + '(' + prev + ')"';
        html += '<li class="page-item ' + prevDisabled + '"><a class="page-link page-link-label" href="javascript:void(0)" ' + prevOnclick + '>Prev</a></li>';

        let pageCandidates = [1, totalPages];
        for (let p = Math.max(1, currentPage - 2); p <= Math.min(totalPages, currentPage + 2); p++) {
            pageCandidates.push(p);
        }
        pageCandidates = Array.from(new Set(pageCandidates)).sort(function(a, b) { return a - b; });

        let previousRenderedPage = 0;
        pageCandidates.forEach(function(p) {
            if (previousRenderedPage > 0 && p > previousRenderedPage + 1) {
                html += '<li class="page-item disabled"><span class="page-link">&hellip;</span></li>';
            }
            if (p === currentPage) {
                html += '<li class="page-item active" aria-current="page"><span class="page-link">' + p + '</span></li>';
            } else {
                html += '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="' + callbackName + '(' + p + ')">' + p + '</a></li>';
            }
            previousRenderedPage = p;
        });

        // Next
        const next = currentPage + 1;
        const nextDisabled = (currentPage === totalPages) ? 'disabled' : '';
        const nextOnclick = (currentPage === totalPages) ? '' : 'onclick="' + callbackName + '(' + next + ')"';
        html += '<li class="page-item ' + nextDisabled + '"><a class="page-link page-link-label" href="javascript:void(0)" ' + nextOnclick + '>Next</a></li>';

        return html;
    }

    function escapeHtml(str) {
        return String(str || '').replace(/[&<>"']/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
        });
    }

    function getOffboardingStatusBadge(status) {
        status = status || '';
        let cls = 'bg-amber-100 text-amber-700';
        if (status === 'completed') cls = 'bg-emerald-100 text-emerald-700';
        else if (status === 'rejected') cls = 'bg-rose-100 text-rose-700';
        else if (status === 'exit_interview_pending' || status === 'approved') cls = 'bg-sky-100 text-sky-700';
        const label = status.replace(/_/g, ' ').replace(/\b\w/g, function(l) { return l.toUpperCase(); });
        return '<span class="badge rounded-pill ' + cls + '">' + escapeHtml(label) + '</span>';
    }

    // Manager Resignations Table Pagination
    const allManagerResignations = <?= json_encode($managerResignations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    let managerCurrentPage = 1;

    function renderManagerResignationsTable(page) {
        const tableBody = document.getElementById('managerResignationsTableBody');
        if (!tableBody || typeof allManagerResignations === 'undefined') return;

        managerCurrentPage = parseInt(page) || 1;
        const search = (document.getElementById('offboardingSearch')?.value || '').toLowerCase().trim();
        const perPage = parseInt(document.getElementById('offboardingPerPage')?.value || '10');

        const filtered = allManagerResignations.filter(function(r) {
            if (!search) return true;
            const fullName = ((r.first_name || '') + ' ' + (r.last_name || '')).toLowerCase();
            const empCode = (r.emp_code || '').toLowerCase();
            const reqNo = (r.request_no || '').toLowerCase();
            const status = (r.status || '').toLowerCase().replace(/_/g, ' ');
            const resDate = (r.resignation_date || '').toLowerCase();
            return fullName.includes(search) || empCode.includes(search) || reqNo.includes(search) || status.includes(search) || resDate.includes(search);
        });

        const totalRows = filtered.length;
        const totalPages = Math.ceil(totalRows / perPage) || 1;
        if (managerCurrentPage > totalPages) managerCurrentPage = totalPages;
        if (managerCurrentPage < 1) managerCurrentPage = 1;

        const startIndex = (managerCurrentPage - 1) * perPage;
        const pageRows = filtered.slice(startIndex, startIndex + perPage);

        if (totalRows === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center py-10 text-slate-500">No resignation requests found.</td></tr>';
            $('#offboardingPaginationWrapper').html('');
            $('#offboardingPaginationSummary').text('Showing 0 results of 0');
            return;
        }

        let html = '';
        pageRows.forEach(function(request) {
            const fullName = ((request.first_name || '') + ' ' + (request.last_name || '')).trim();
            const empCode = request.emp_code || 'No ID';
            const lastDay = request.approved_last_working_date || request.requested_last_working_date || '—';
            const reqJson = escapeHtml(JSON.stringify(request));

            html += '<tr>';
            html += '<td class="px-5 py-4"><div class="fw-bold text-slate-800">' + escapeHtml(fullName) + '</div><div class="text-xs text-slate-400">' + escapeHtml(empCode) + '</div></td>';
            html += '<td class="py-4 fw-semibold text-slate-700">' + escapeHtml(request.request_no) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(request.resignation_date) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(lastDay) + '</td>';
            html += '<td class="py-4">' + getOffboardingStatusBadge(request.status) + '</td>';
            html += '<td class="px-5 py-4 text-end">';
            html += '<button class="btn btn-sm btn-icon btn-outline-primary rounded-lg review-resignation" data-request="' + reqJson + '"><i class="ti ti-pencil"></i></button>';
            html += '</td>';
            html += '</tr>';
        });

        tableBody.innerHTML = html;
        $('#offboardingPaginationWrapper').html(renderSmartPaginationJs(totalPages, managerCurrentPage, 'changeManagerPage'));
        const startItem = totalRows > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(startIndex + perPage, totalRows);
        $('#offboardingPaginationSummary').text('Showing ' + startItem + ' to ' + endItem + ' results of ' + totalRows);
    }

    window.changeManagerPage = function(p) {
        renderManagerResignationsTable(p);
    };

    $(document).on('click', '.offboarding-per-page-item', function () {
        const val = $(this).data('val');
        const label = $(this).text();
        $('#offboardingPerPageText').text(label);
        $('#offboardingPerPage').val(val);
        $('#offboardingFooterPerPageSelect').val(val);
        renderManagerResignationsTable(1);
    });

    $('#offboardingFooterPerPageSelect').on('change', function () {
        const val = $(this).val();
        $('#offboardingPerPage').val(val);
        renderManagerResignationsTable(1);
    });

    $('#offboardingSearch').on('input', function () {
        renderManagerResignationsTable(1);
    });

    // My Offboarding Requests Table Pagination
    const allEmployeeResignations = <?= json_encode($employeeResignations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    let myCurrentPage = 1;

    function renderMyResignationsTable(page) {
        const tableBody = document.getElementById('myResignationsTableBody');
        if (!tableBody || typeof allEmployeeResignations === 'undefined') return;

        myCurrentPage = parseInt(page) || 1;
        const perPage = parseInt(document.getElementById('myOffboardingPerPage')?.value || '10');

        const totalRows = allEmployeeResignations.length;
        const totalPages = Math.ceil(totalRows / perPage) || 1;
        if (myCurrentPage > totalPages) myCurrentPage = totalPages;
        if (myCurrentPage < 1) myCurrentPage = 1;

        const startIndex = (myCurrentPage - 1) * perPage;
        const pageRows = allEmployeeResignations.slice(startIndex, startIndex + perPage);

        if (totalRows === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center py-10 text-slate-500">No resignation requests.</td></tr>';
            $('#myOffboardingPaginationWrapper').html('');
            $('#myOffboardingPaginationSummary').text('Showing 0 results of 0');
            return;
        }

        let html = '';
        pageRows.forEach(function(request) {
            let submittedDate = request.submitted_at ? request.submitted_at.substring(0, 10) : '—';
            let docHtml = '<div class="d-flex gap-1">';
            if (request.experience_document_id) {
                docHtml += '<a class="btn btn-sm btn-icon btn-outline-primary rounded-lg" target="_blank" href="hrms-offboarding-document.php?id=' + parseInt(request.experience_document_id) + '" title="Experience Letter"><i class="ti ti-file-certificate"></i></a>';
            }
            if (request.relieving_document_id) {
                docHtml += '<a class="btn btn-sm btn-icon btn-outline-primary rounded-lg" target="_blank" href="hrms-offboarding-document.php?id=' + parseInt(request.relieving_document_id) + '" title="Relieving Letter"><i class="ti ti-file-description"></i></a>';
            }
            if (!request.experience_document_id && !request.relieving_document_id) {
                docHtml += '<span class="text-slate-400">—</span>';
            }
            docHtml += '</div>';

            html += '<tr>';
            html += '<td class="px-5 py-4 fw-bold text-slate-800">' + escapeHtml(request.request_no) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(submittedDate) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(request.requested_last_working_date) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(request.approved_last_working_date || '—') + '</td>';
            html += '<td class="py-4">' + getOffboardingStatusBadge(request.status) + '</td>';
            html += '<td class="px-5 py-4">' + docHtml + '</td>';
            html += '</tr>';
        });

        tableBody.innerHTML = html;
        $('#myOffboardingPaginationWrapper').html(renderSmartPaginationJs(totalPages, myCurrentPage, 'changeMyPage'));
        const startItem = totalRows > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(startIndex + perPage, totalRows);
        $('#myOffboardingPaginationSummary').text('Showing ' + startItem + ' to ' + endItem + ' results of ' + totalRows);
    }

    window.changeMyPage = function(p) {
        renderMyResignationsTable(p);
    };

    $(document).on('click', '.my-offboarding-per-page-item', function () {
        const val = $(this).data('val');
        const label = $(this).text();
        $('#myOffboardingPerPageText').text(label);
        $('#myOffboardingPerPage').val(val);
        $('#myOffboardingFooterPerPageSelect').val(val);
        renderMyResignationsTable(1);
    });

    $('#myOffboardingFooterPerPageSelect').on('change', function () {
        const val = $(this).val();
        $('#myOffboardingPerPage').val(val);
        renderMyResignationsTable(1);
    });

    // Initial render
    renderManagerResignationsTable(1);
    renderMyResignationsTable(1);
});
</script>
<?php endSection();?>
