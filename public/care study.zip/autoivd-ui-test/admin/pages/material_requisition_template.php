<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once "../db.php";
require_once "../functions.php";
require_once "../document_pdf_helpers.php";

documentPdfRequireAnyPermission($conn, [
    'production_material_requisition_view',
    'store_material_request_view',
]);
$id = documentPdfEncryptedPositiveId($_GET['id'] ?? '');
$fileName = '';

// Fetch requisition main record
$stmt = $conn->prepare("SELECT * FROM `material_requisition` WHERE `id` = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    http_response_code(404);
    exit('Material Requisition not found.');
}

// Fetch requisition items
$stmtItems = $conn->prepare("SELECT * FROM `material_requisition_items` WHERE `status` != 3 AND `deleted_at` IS NULL AND `mr_id` = ?");
$stmtItems->bind_param('i', $id);
$stmtItems->execute();
$resultItems = $stmtItems->get_result();
$rowItems = $resultItems->fetch_all(MYSQLI_ASSOC); 
$stmtItems->close();

$unitMap = [];
$unitQuery = $conn->query("SELECT `id`, `short_name` FROM `standard_units`");
while ($rowUnit = $unitQuery->fetch_assoc()) {
    $unitMap[$rowUnit['id']] = $rowUnit['short_name'];
}
$batchSizeUnit = $unitMap[$row['batch_size_unit']] ?? $row['batch_size_unit'];
$rawName = $row['auto_generated_batch'].'-'.$row['product_name'];
$fileName = preg_replace('/[^A-Za-z0-9]+/', '_', $rawName);
$fileName = trim($fileName, '_');  
$serial = 1;
$serverSideDownload = (string) ($_GET['triggerDownload'] ?? '') === '1';
$logoSource = documentPdfLocalImageDataUri(dirname(__DIR__, 2) . '/assets/img/logo3.jpeg');
if ($serverSideDownload) {
    ob_start();
}

// for ($i = 1; $i < 25 ;$i++) {
//     $rowItems[] = [
//         "id" => $serial++,
//         "mr_id" => $id,
//         "description"   => 'Item Requested - '.$i,
//         // "description"   => 'Item Requested - '.$i.' '.'Item Requested - '.$i,
//         "required_qty"    => number_format(rand(99,9999),2),
//         "required_qty_unit"  => number_format(rand(1,15),0),
//         "issued_qty"  => number_format(rand(99,9999), 2),
//         "returned_qty"  => number_format(rand(9,999), 2),
//         "rejected_qty"  => number_format(rand(9,999), 2),
//         "ar_coa_number"  => "COA-" . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6))
//         // "ar_coa_number"  => "COA-" . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6)).'/'. "COA-" . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6))
//     ];
// }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Material Requisition</title>
    <style>
        .page {
            width: 100%;
            min-height: 1000px; /* ~A4 height in pixels at 96 DPI */
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }
        .page:last-child {
            page-break-after: auto;
        }
        <?php if ($serverSideDownload) { ?>
        .page { min-height: 0; }
        <?php } ?>
    </style>
</head>
<body style="margin: 0;">
    <div id="materialRequisitionContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php
            $footers = ['PRODUCTION','STORES'];
            foreach ($footers as $index => $footerLabel){
                $rowsPerPage = 22;
                $chunks = array_chunk($rowItems, $rowsPerPage) ?: [[]];
                foreach ($chunks as $pageIndex => $pageProducts) {
                    $realCount = count($pageProducts);
                    // Calculate how many blank rows to add
                    $emptyRows = $rowsPerPage - $realCount;
                    $isLastPage = $index === array_key_last($footers)
                        && $pageIndex === array_key_last($chunks);
                
        ?>
        <div class="page" style="page-break-after: <?= $isLastPage ? 'auto' : 'always' ?>;">
            <div style="border: 1px solid #000;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 18px; ">
                        <td style="width: 35%; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                            <img src="<?php echo htmlspecialchars($logoSource, ENT_QUOTES, 'UTF-8'); ?>" alt="Biogenix Logo" style="height: 50px;">
                        </td>
                        <td rowspan="2" style="width: 30%; border-right: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">TITLE: MATERIAL <br/> REQUISITION FORM</strong></td>
                        <td rowspan="2" style="width: 15%; border-right: 1px solid #000; text-align:center;"><strong>Document No.</strong></td>
                        <td rowspan="2" style="text-align:center;">BIPL-F-MRF-01</td>
                    </tr>
                    <tr>
                        <td style="width: 35%; border-right: 1px solid #000;  padding-left:10px;">
                            B19/A S.I.L Ancillary Estate,<br>
                            Amausi Industrial Area,<br>
                            Nadarganj-226008 (Lucknow)
                        </td>
                    </tr>
                </table>
            </div>
            <div style="border-left: 1px solid #000;border-right: 1px solid #000; font-size:14px;">
                <table style="width: 100%; border-collapse: collapse; ">
                    
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%; border-right: 1px solid #000;">
                            <strong>Requisition For</strong>
                        </td>
                        <td style="padding-left:5px;">
                            <div style="display: flex; justify-content: space-between; width:100%;">
                                <span style="flex:1;">
                                    <?php echo ($row['mr_raw'] == 1 ? "&#x2611;" : "&#x2610;"); ?> Raw material
                                </span>
                                <span style="flex:1;">
                                    <?php echo ($row['mr_packing'] == 1 ? "&#x2611;" : "&#x2610;"); ?> Packing material
                                </span>
                                <span style="flex:1;">
                                    <?php echo ($row['mr_consumable'] == 1 ? "&#x2611;" : "&#x2610;"); ?> Consumables
                                </span>
                            </div>
                        </td>
                    </tr>

                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Date</strong></td>
                        <td style="padding-left:5px;"><?php echo formatDateDMY(htmlspecialchars($row['date'] ?? "")); ?></td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Product Name</strong></td>
                        <td style="padding-left:5px;"><?php echo htmlspecialchars($row['product_name'] ?? ""); ?></td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Lot No./Batch No.</strong></td>
                        <td style="padding-left:5px;"><?php echo htmlspecialchars($row['lot_batch_no'] ?? ""); ?></td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Batch Size</strong></td>
                        <td style="padding-left:5px;"><?php echo htmlspecialchars($row['batch_size'] ?? "")." ".htmlspecialchars($batchSizeUnit ?? ""); ?></td>
                    </tr>  
                    <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                        <td style="padding-left:5px; width: 30%;  border-right: 1px solid #000;"><strong>Slip No.</strong><br/><sub>(dept. code/date/sequence)</sub></td>
                        <td style="padding-left:5px;"><?php echo htmlspecialchars($row['slip_no'] ?? ""); ?></td>
                    </tr>                    
                </table>
            </div>

            <div style="font-size:14px;">
                <table style="width: 100%; border-collapse: collapse;"> 
                    
                    <tr style="line-height: 18px; background-color:#D3D3D3; border-bottom: 1px solid #000;">
                        <td style="width: 27%; border-left: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Description</td>
                        <td style="width: 15%; border-right: 1px solid #000; text-align:center; font-weight: bold;">Required <br> Quantity</td>
                        <td style="width: 15%; border-right: 1px solid #000; text-align:center; font-weight: bold;">Issued <br>Quantity</td>
                        <td style="width: 18%; border-right: 1px solid #000; text-align:center; font-weight: bold;">Returned Quantity/<br>Rejection Quantity</td>
                        <td style="width: 15%; border-right: 1px solid #000; text-align:center; font-weight: bold;">A.R/COA <br> Number</td>                        
                    </tr>
                    <?php if(!empty($pageProducts)): foreach ($pageProducts as $p): ?>
                        <?php $reqMatUnit = $unitMap[$p['required_qty_unit']] ?? $p['required_qty_unit']; ?>
                        <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                            <td style="padding-left:5px; width: 27%; border-left: 1px solid #000;border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['description'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) (($p['required_qty'] ?? 0) . ' ' . $reqMatUnit), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['issued_qty'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['returned_qty'] ?? 0), ENT_QUOTES, 'UTF-8') ?> / <?= htmlspecialchars((string) ($p['rejected_qty'] ?? 0), ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #000;"><?= htmlspecialchars((string) ($p['ar_coa_number'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                            
                        </tr>      
                    <?php endforeach; endif; ?>
                    <?php for ($i = 0; $i < $emptyRows; $i++): ?>
                        <tr style="line-height: 18px; border-bottom: 1px solid #fff;">
                            <td style="padding-left:5px; width: 27%; border-left: 1px solid #fff;border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 15%; border-right: 1px solid #fff;">&nbsp;</td>                           
                        </tr>     
                    <?php endfor; ?>
                </table>
                <table style="width: 100%; border-collapse: collapse; margin-top: 30px; text-align: center;">
                    <tr>
                        <td style="padding-top: 40px; text-align: left;">
                            <strong style="font-weight:700;">Requisition By</strong> (Sign/Date)<br> _____________________
                        </td>
                        <td style="padding-top: 40px; font-weight:700;"></td>
                        <td style="padding-top: 40px;  text-align: right;">
                            <strong style="font-weight:700;">Issued By</strong> (Sign/Date)<br> _____________________
                        </td>
                    </tr>
                </table>
            </div>

            <div style="text-align:right; padding: 15px; font-size:14px;">       
                <div style="margin-top: 30px; font-weight: bold;"><?php echo htmlspecialchars($footerLabel ?? ""); ?> COPY</div>
            </div>
        </div>
        <?php } } ?>
    </div>

</body>
</html>
<?php
if ($serverSideDownload) {
    documentPdfStream((string) ob_get_clean(), $fileName ?: 'material_requisition_' . $id);
}
?>
