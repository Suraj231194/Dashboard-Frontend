<div class="container-xxl flex-grow-1 container-p-y font-sans">
  <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
    <div class="ui-page-title-banner">
      <h1
        style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
        <?= $pageTitle ?></h1>
      <p
        style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
        Create rapid daily production records with department-wise entries</p>
    </div>
  </div>
  <div class="w-full">
    <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div class="border-b border-slate-200 bg-slate-50/80 px-6 py-4">
        <div class="flex items-center gap-3">
          <span
            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
            <i class="ti ti-plus text-xl"></i>
          </span>
          <div>
            <h5 class="m-0 text-lg font-bold text-slate-900">Daily Production Record</h5>
            <p class="m-0 text-sm font-medium text-slate-500">Fill production details without changing the working logic
            </p>
          </div>
        </div>
      </div>
      <form class="bg-slate-50/70 px-6 py-5" id="DailyProductionRecord">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-800" for="date_input">Date <strong
                class="text-rose-500">*</strong></label>
            <input type="date" id="date_input" class="input-theme" placeholder="DD/MM/YYYY" required />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-800" for="month_year">Month /Year <strong
                class="text-rose-500">*</strong></label>
            <input type="text" id="month_year" class="input-theme text-slate-500 focus:text-slate-900"
              placeholder="MM/YYYY" required />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-800" for="total_mam_power">Total Man Power <strong
                class="text-rose-500">*</strong></label>
            <input type="number" id="total_mam_power" min="0" class="input-theme" placeholder="Enter Total Man Power"
              required />
          </div>
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-800" for="total_working_hours">Total Working Hours
              <strong class="text-rose-500">*</strong></label>
            <input type="number" id="total_working_hours" min="0" class="input-theme"
              placeholder="Enter Total Working Hours" required />
          </div>
        </div>
        <div class="border-t border-slate-200 my-4"></div>
        <h6 class="mb-3 text-sm font-bold uppercase tracking-[0.08em] text-slate-500">Product Category</h6>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-800" for="departmentSelect">Select Department
              <strong class="text-rose-500">*</strong></label>
            <select id="departmentSelect" class="input-theme select2" data-minimum-results-for-search="Infinity">
              <option value="">-- Select Department --</option>
              <option value="Rapid Mfg">Rapid Mfg</option>
              <option value="2P10P">2P/ 10P</option>
              <option value="Production">Production</option>
            </select>
          </div>
        </div>
        <hr class="my-4 border-slate-200" />
        <div id="particularRows"></div>
        <div class="flex flex-wrap justify-end gap-3 pt-4">
          <button type="reset"
            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60">Reset</button>
          <button type="submit" id="submitBtn"
            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
            <i class="ti ti-check text-lg" id="submitIcon"></i>
            <span id="submitText">Submit</span>
            <span id="submitLoader" class="spinner-border spinner-border-sm d-none" role="status"
              aria-hidden="true"></span>
          </button>
        </div>

      </form>
    </div>
  </div>
</div>

<?php startSection('scripts'); ?>
<script>
  const departmentParticulars = {
    "Rapid Mfg": [
      "Mfg gold", "Mfg sheet coating", "Laminates preparation",
      "Gold pad preparation", "Sheets assembly Rapid", "Documentation", "Remark"
    ],
    "2P10P": [
      "Membrane Dipping", "Sheet Assembly 2P/10P", "Sheet Cutting 2P/10P", "Documentation", "Remark"
    ],
    "Production": [
      "Printed Pouches", "Printed Cartons", "Printed Labels",
      "Sheet Cutting Rapid", "Cassettes assembly", "Pouching",
      "Packaging", "Buffer Filling", "Transfer details", "Documentation", "Remark"
    ]
  };


  $(document).ready(function () {
    $('#departmentSelect').select2({ minimumResultsForSearch: Infinity });
    initCustomMonthPicker('#month_year');
    let qtyUnitOptions = [];
    $.ajax({
      url: 'ajax.php',
      method: 'POST',
      dataType: 'json',
      data: { getQtyUnits: 'getQtyUnits' },
      success: function (response) {
        qtyUnitOptions = response;
      },
      error: function (xhr, status, error) {
        console.error("Failed to load qty units:", error);
      }
    });


    $('#departmentSelect').on('change', function () {
      $('#particularRows').empty();
      const dept = $(this).val();
      if (!dept) return;

      const blockId = `block-${dept.replace(/\s/g, '')}`;

      const particulars = departmentParticulars[dept];
      if (!particulars) return;
      let html = `<div class="department-block mb-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm ring-1 ring-slate-900/5" id="${blockId}">`;
      html += `
        <div class="flex items-center justify-between mb-4">
          <h4 class="m-0 text-lg font-bold text-slate-900">${dept}</h4>
          <button type="button" class="inline-flex h-9 items-center justify-center gap-2 !rounded-xl bg-rose-50 px-4 text-sm font-bold text-rose-700 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-800 remove-department" data-target="${blockId}"><i class="ti ti-trash text-base"></i> Remove</button>
        </div>
      `;

      particulars.forEach(function (p, index) {
        const safeParticular = p.replace(/[^a-zA-Z0-9]/g, '_') + '_' + index;
        html += `
        <div class="relative mb-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-4 shadow-sm particular-block" data-particular="${safeParticular}">        
      
        <button type="button" class="remove-particular absolute right-3 top-3 inline-flex h-8 w-8 items-center justify-center !rounded-full bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none" aria-label="Close">
            <i class="ti ti-x text-base"></i>
        </button>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
            <div>
            <label class="mb-1 block text-sm font-medium text-slate-800">Particular</label>
            <input class="input-theme" name="particular[]" type="text" readonly value="${p}">
            </div>
            <div>
            <label class="mb-1 block text-sm font-medium text-slate-800">Filled By</label>
            <input class="input-theme" name="filledBy[]" type="text" placeholder="Filled by">
            </div>
        </div>

        <div class="row-set"></div>`;

        html += `<div class="mt-3 flex justify-end">
                    <button type="button" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 add-sub-row" data-department-value ="${dept}" data-particular-type="${p}" data-target="${safeParticular}"><i class="ti ti-plus text-base"></i> Add Product</button>
                  </div>`;

        html += `</div>`;

      });


      html += `</div>`;
      $('#particularRows').append(html);
    });

    $(document).on('click', '.remove-particular', function () {
      $(this).closest('.particular-block').remove();
    });

    $(document).on('click', '.remove-department', function () {
      const targetId = $(this).data('target');
      $('#' + targetId).remove();
      $('#departmentSelect').val('').trigger('change.select2');
    });

    // Add sub-row
    $(document).on('click', '.add-sub-row', function () {
      const target = $(this).data('target');
      const particularType = $(this).data('particular-type');
      const departmentValue = $(this).data('department-value');
      const rowSet = $(`[data-particular="${target}"] .row-set`);
      let optionsHtml = '<option value="">Select</option>';
      qtyUnitOptions.forEach(unit => {
        optionsHtml += `<option value="${unit.value}">${unit.label}</option>`;
      });
      let rowHtml = '';
      if (particularType == 'Documentation') {
        rowHtml += `
          <div class="grid grid-cols-1 gap-3 mb-2 items-end sub-row md:grid-cols-[1fr_40px]">
            <div>
              <label class="mb-1 block text-sm font-medium text-slate-800">Documentation</label>
              <textarea class="input-theme" name="product" required placeholder="Enter Documentation"></textarea>
              <input type="hidden" name="totalYield" value="0" />
              <input type="hidden"  name="qtyUnit" value="" />
              <input type="hidden" name="manPower" value="0" />
              <input type="hidden" name="departmentValue" value="`+ departmentValue + `" />
            </div>
            <div class="flex pb-1">
              <button type="button" class="remove-sub-row inline-flex h-10 w-10 items-center justify-center !rounded-xl bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                <i class="ti ti-trash text-base"></i>
              </button>
            </div>
          </div>
        `;
      }
      else if (particularType == 'Remark') {
        rowHtml += `
          <div class="grid grid-cols-1 gap-3 mb-2 items-end sub-row md:grid-cols-[1fr_40px]">
            <div>
              <label class="mb-1 block text-sm font-medium text-slate-800">Remark</label>
              <textarea class="input-theme" name="product" required placeholder="Enter Remark"></textarea>
              <input type="hidden" name="totalYield" value="0" />
              <input type="hidden"  name="qtyUnit" value="" />
              <input type="hidden" name="manPower" value="0" />
              <input type="hidden" name="departmentValue" value="`+ departmentValue + `" />
            </div>
            <div class="flex pb-1">
              <button type="button" class="remove-sub-row inline-flex h-10 w-10 items-center justify-center !rounded-xl bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                <i class="ti ti-trash text-base"></i>
              </button>
            </div>
          </div>
        `;
      }
      else {
        rowHtml += `
          <div class="grid grid-cols-1 gap-3 mb-2 items-end sub-row md:grid-cols-[minmax(150px,1.5fr)_minmax(120px,1fr)_minmax(120px,1fr)_minmax(120px,1fr)_40px]">
            <div>
              <label class="mb-1 block text-sm font-medium text-slate-800">Product</label>
              <input class="input-theme" type="text" name="product" placeholder="Product" />
              <input type="hidden" name="departmentValue" value="`+ departmentValue + `" />
            </div>
            <div>
              <label class="mb-1 block text-sm font-medium text-slate-800">Total Yield / Qty</label>
              <input class="input-theme" type="number" min="0" name="totalYield" placeholder="Total Yield" />
            </div>
            <div>
              <label class="mb-1 block text-sm font-medium text-slate-800">Qty Unit</label>
              <select name="qtyUnit" class="input-theme">
              `+ optionsHtml + `                
              </select>
            </div>
            <div>
              <label class="mb-1 block text-sm font-medium text-slate-800">Man Power</label>
              <input class="input-theme" type="number" min="0" name="manPower" placeholder="Man Power" />
            </div>
            <div class="flex pb-1">
              <button type="button" class="remove-sub-row inline-flex h-10 w-10 items-center justify-center !rounded-xl bg-rose-50 text-rose-700 transition-colors hover:bg-rose-100 focus:outline-none focus:ring-0 focus:border-none">
                <i class="ti ti-trash text-base"></i>
              </button>
            </div>
          </div>
        `;
      }

      rowSet.append(rowHtml);
    });

    // Remove sub-row
    $(document).on('click', '.remove-sub-row', function () {
      $(this).closest('.sub-row').remove();
    });

    // Submit handler
    $('#DailyProductionRecord').on('submit', function (e) {
      e.preventDefault();

      const $submitBtn = $('#submitBtn');
      const $submitText = $('#submitText');
      const $submitLoader = $('#submitLoader');

      let isValid = true;
      let firstInvalidInput = null;
      const allParticulars = [];

      const department = $('#departmentSelect').val();
      if (!department) {
        alert('Please select a department.');
        $('#departmentSelect').focus();
        return;
      }

      $('.particular-block').each(function () {
        const $block = $(this);
        const particular = ($block.find('input[name="particular[]"]').val() || '').trim();
        const filledBy = ($block.find('input[name="filledBy[]"]').val() || '').trim();

        if (!filledBy && isValid) {
          isValid = false;
          firstInvalidInput = $block.find('input[name="filledBy[]"]');
          return false;
        }

        const $subRows = $block.find('.sub-row');
        if ($subRows.length === 0 && particular.toLowerCase() !== 'documentation' && particular.toLowerCase() !== 'remark' && isValid) {
          isValid = false;
          alert(`Please add at least one product for ${particular}`);
          firstInvalidInput = $block.find('.add-sub-row');
          return false;
        }

        $subRows.each(function () {
          const $row = $(this);
          if (particular.toLowerCase() === 'documentation' || particular.toLowerCase() === 'remark') {
            const product = $row.find('textarea[name="product"]').val()?.trim() || '';
            const departmentValues = ($row.find('input[name="departmentValue"]').val() || '').trim();
            if (product !== '') {
              allParticulars.push({
                particular,
                filledBy,
                product,
                departmentValues,
                totalYield: null,
                qtyUnit: null,
                manPower: null
              });
            }
            return;
          }

          const product = ($row.find('input[name="product"]').val() || '').trim();
          const totalYield = ($row.find('input[name="totalYield"]').val() || '').trim();
          const departmentValues = ($row.find('input[name="departmentValue"]').val() || '').trim();
          const qtyUnit = $row.find('select[name="qtyUnit"]').val() || '';
          const manPower = ($row.find('input[name="manPower"]').val() || '').trim();

          if ((!product || !totalYield || !qtyUnit || !manPower) && isValid) {
            isValid = false;
            if (!product) firstInvalidInput = $row.find('input[name="product"]');
            else if (!totalYield) firstInvalidInput = $row.find('input[name="totalYield"]');
            else if (!departmentValues) firstInvalidInput = $row.find('input[name="departmentValue"]');
            else if (!qtyUnit) firstInvalidInput = $row.find('select[name="qtyUnit"]');
            else if (!manPower) firstInvalidInput = $row.find('input[name="manPower"]');
            return false;
          }

          allParticulars.push({
            particular,
            filledBy,
            product,
            departmentValues,
            totalYield,
            qtyUnit,
            manPower
          });
        });

        if (!isValid) return false;
      });

      if (!isValid) {
        alert('Please fill all required fields.');
        if (firstInvalidInput) firstInvalidInput.focus();
        return;
      }

      // Final data payload
      const data = {
        date: $('#date_input').val(),
        monthYear: $('#month_year').val(),
        totalManPower: $('#total_mam_power').val(),
        totalWorkingHours: $('#total_working_hours').val(),
        department,
        particulars: allParticulars
      };
      console.log(data);

      // Show loader
      $submitBtn.prop('disabled', true);
      $submitText.text('Submitting...');
      $submitLoader.removeClass('d-none');

      $.ajax({
        url: 'ajax.php',
        method: 'POST',
        data: {
          saveRapidProductionForm: 'saveRapidProductionForm',
          data: JSON.stringify(data)
        },
        success: function (response) {
          toastr.success(response.message || 'Report submitted successfully!');
          $('#DailyProductionRecord')[0].reset();
          $('#particularRows').empty();
        },
        error: function (xhr) {
          toastr.error((xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : 'Report submission failed');
        },
        complete: function () {
          $submitBtn.prop('disabled', false);
          $submitText.text('Submit');
          $submitLoader.addClass('d-none');
        }
      });

    });
  });
</script>
<?php endSection(); ?>
