<?php
/**
 * Meeting Requests Page (ERP Lead Management)
 * Matches MANUVERSE v7 document image 9.
 *
 * Location: admin/pages/meeting-requests.php
 */
?>
<style>
    .meeting-page { color: var(--ui-text, #25362e); }
    .meeting-page .meeting-panel { overflow: hidden; border: 1px solid #e1e9e4; border-radius: 14px; background: #fff; box-shadow: 0 6px 22px rgba(0, 0, 0, .07); }
    .meeting-page .meeting-control { height: 38px; border: 1px solid #dce6e0; border-radius: 8px; background: #fff; color: #43534b; font-size: 12px; font-weight: 600; outline: none; }
    .meeting-page .meeting-control:focus { border-color: var(--appearance-accent, #166534); box-shadow: 0 0 0 3px color-mix(in srgb, var(--appearance-accent, #166534) 12%, transparent); }
    .meeting-page .meeting-table { width: 100%; min-width: 930px; border-collapse: collapse; }
    .meeting-page .meeting-table th { padding: 12px 16px; border-bottom: 1px solid #e5ede8; background: #fbfcfb; color: #77837d; font-size: 9px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; white-space: nowrap; }
    .meeting-page .meeting-table td { padding: 16px; border-bottom: 1px solid #edf2ef; color: #3c4c44; font-size: 12px; vertical-align: middle; }
    .meeting-page .meeting-table tbody tr:hover { background: #fbfdfc; }
    .meeting-page .meeting-status { display: inline-flex; align-items: center; border-radius: 999px; padding: 4px 9px; font-size: 9px; font-weight: 900; letter-spacing: .05em; text-transform: uppercase; }
    .meeting-page .meeting-footer { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; padding: 13px 16px; color: #6c7a72; font-size: 12px; }
    .meeting-page .meeting-page-btn { display: inline-flex; min-width: 32px; height: 32px; align-items: center; justify-content: center; border: 1px solid #dce6e0; border-radius: 7px; background: #fff; color: #52625a; font-size: 11px; font-weight: 800; }
    .meeting-page .meeting-page-btn.is-active { border-color: var(--appearance-accent, #166534); background: var(--appearance-accent, #166534); color: #fff; }
    .meeting-page .meeting-page-btn:disabled { cursor: not-allowed; opacity: .45; }
</style>

<div class="meeting-page container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1 class="m-0 text-2xl font-extrabold tracking-tight text-slate-800">Meeting Requests</h1>
            <p class="mb-0 mt-1 text-sm text-slate-500">Manage and track Website meeting sessions in one clean workspace.</p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <button type="button" id="exportMeetings" data-bs-toggle="modal" data-bs-target="#exportModal" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36">
                <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
            </button>
            <button type="button" onclick="triggerManualSync('meetings')" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors focus:outline-none focus:ring-2" style="background: var(--appearance-accent, #166534);">
                <i class="ti ti-refresh text-lg"></i>Sync Website
            </button>
        </div>
    </div>

    <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
            <div class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                <input type="hidden" id="meetingPageSize" value="10">

                <!-- Per-page dropdown -->
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="meetingPerPageText" class="whitespace-nowrap">10 per page</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="meeting-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                        <li><a class="meeting-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 per page</a></li>
                        <li><a class="meeting-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 per page</a></li>
                        <li><a class="meeting-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 per page</a></li>
                        <li><a class="meeting-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 per page</a></li>
                    </ul>
                </div>

                <!-- Search input -->
                <div class="relative h-10 min-w-[160px] max-w-[240px] flex-grow">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="ti ti-search text-lg text-slate-400"></i>
                    </div>
                    <input type="text" id="meetingSearchInput" class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" placeholder="Search meeting requests...">
                </div>

                <!-- Date filter -->
                <input type="date" id="meetingDateFilter" class="h-10 w-auto !rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" aria-label="Preferred date">

                <!-- Status dropdown -->
                <input type="hidden" id="meetingStatusFilter" value="">
                <div class="dropdown shrink-0">
                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                        <span id="meetingStatusText" class="whitespace-nowrap">All statuses</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="meeting-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="">All statuses</a></li>
                        <li><a class="meeting-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="new">New</a></li>
                        <li><a class="meeting-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="scheduled">Scheduled</a></li>
                        <li><a class="meeting-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="completed">Completed</a></li>
                        <li><a class="meeting-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="cancelled">Cancelled</a></li>
                    </ul>
                </div>

                <button type="button" id="clearMeetingFilters" class="inline-flex h-10 items-center justify-center gap-1 !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300/60">
                    <i class="ti ti-filter-off text-base"></i>Clear
                </button>
            </div>
        </div>

        <div class="w-full overflow-x-auto">
            <table class="meeting-table">
                <thead><tr><th>Full name</th><th>Company / Org</th><th>Date & time</th><th>Contact info</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
                <tbody id="meetingsTableBody"><tr><td colspan="6" class="!py-10 text-center !text-slate-400">Loading meeting requests...</td></tr></tbody>
            </table>
        </div>
        <div class="meeting-footer border-t border-slate-200 bg-slate-50/50"><div id="meetingShowingText">Showing 0 meeting requests</div><div id="meetingPagination" class="flex items-center gap-1"></div></div>
    </div>
</div>

<!-- Meeting Details Modal -->
<div class="modal fade" id="meetingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-slate-50 border-bottom">
                <h5 class="modal-title font-bold text-slate-800" id="meetingModalTitle">Meeting Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4" id="meetingModalBody">
                Loading...
            </div>
            <div class="modal-footer bg-slate-50 border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
let meetingRows = [];
let meetingFilteredRows = [];
let meetingCurrentPage = 1;

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('meetingSearchInput').addEventListener('input', resetMeetingPageAndRender);
    document.getElementById('meetingDateFilter').addEventListener('change', resetMeetingPageAndRender);

    // Per-page dropdown items
    document.querySelectorAll('.meeting-per-page-item').forEach(function(item) {
        item.addEventListener('click', function() {
            var val = this.dataset.val;
            document.getElementById('meetingPageSize').value = val;
            document.getElementById('meetingPerPageText').textContent = Number(val) >= 100000000 ? 'All items' : val + ' per page';
            resetMeetingPageAndRender();
        });
    });

    // Status dropdown items
    document.querySelectorAll('.meeting-status-item').forEach(function(item) {
        item.addEventListener('click', function() {
            document.getElementById('meetingStatusFilter').value = this.dataset.val;
            document.getElementById('meetingStatusText').textContent = this.textContent;
            resetMeetingPageAndRender();
        });
    });

    document.getElementById('clearMeetingFilters').addEventListener('click', clearMeetingFilters);
    document.getElementById('meetingPagination').addEventListener('click', function(event) {
        const button = event.target.closest('[data-meeting-page]');
        if (!button || button.disabled) return;
        meetingCurrentPage = Number(button.dataset.meetingPage);
        renderMeetingView();
    });
    loadMeetingsGrid();
});

function loadMeetingsGrid() {
    $('#meetingsTableBody').html('<tr><td colspan="6" class="!py-10 text-center !text-slate-400">Loading meeting requests...</td></tr>');
    $.ajax({
        url: 'ajax.php?action=loadMeetingsGrid',
        type: 'GET',
        dataType: 'json',
        success: function(res) {
            meetingRows = res.status === 'success' && Array.isArray(res.data) ? res.data : [];
            meetingCurrentPage = 1;
            renderMeetingView();
        },
        error: function() {
            $('#meetingsTableBody').html('<tr><td colspan="6" class="!py-10 text-center !text-rose-600">Failed to load meeting requests.</td></tr>');
        }
    });
}

function resetMeetingPageAndRender() {
    meetingCurrentPage = 1;
    renderMeetingView();
}

function clearMeetingFilters() {
    $('#meetingSearchInput, #meetingDateFilter, #meetingStatusFilter').val('');
    $('#meetingStatusText').text('All statuses');
    resetMeetingPageAndRender();
}

function renderMeetingView() {
    const search = String($('#meetingSearchInput').val() || '').trim().toLowerCase();
    const date = String($('#meetingDateFilter').val() || '');
    const status = String($('#meetingStatusFilter').val() || '').toLowerCase();
    const pageSize = Number($('#meetingPageSize').val() || 10);

    meetingFilteredRows = meetingRows.filter(function(row) {
        const haystack = [row.full_name, row.email, row.phone, row.organization_name].join(' ').toLowerCase();
        return (!search || haystack.includes(search)) &&
            (!date || String(row.preferred_date || '') === date) &&
            (!status || String(row.status || '').toLowerCase() === status);
    });

    const totalPages = Math.max(1, Math.ceil(meetingFilteredRows.length / pageSize));
    meetingCurrentPage = Math.min(meetingCurrentPage, totalPages);
    const start = (meetingCurrentPage - 1) * pageSize;
    renderMeetingsTable(meetingFilteredRows.slice(start, start + pageSize));
    renderMeetingPagination(totalPages);
    const first = meetingFilteredRows.length ? start + 1 : 0;
    const last = Math.min(start + pageSize, meetingFilteredRows.length);
    $('#meetingShowingText').text('Showing ' + first + '-' + last + ' of ' + meetingFilteredRows.length + ' meeting requests');
}

function renderMeetingsTable(data) {
    if (!data.length) {
        $('#meetingsTableBody').html('<tr><td colspan="6" class="!py-10 text-center !text-slate-400">No meeting requests match the selected filters.</td></tr>');
        return;
    }

    const statusStyles = {
        new: 'bg-amber-50 text-amber-700',
        scheduled: 'bg-blue-50 text-blue-700',
        completed: 'bg-emerald-50 text-emerald-700',
        cancelled: 'bg-rose-50 text-rose-700'
    };
    let html = '';
    data.forEach(function(item) {
        const status = String(item.status || 'new').toLowerCase();
        const statusClass = statusStyles[status] || 'bg-slate-100 text-slate-600';
        html += `<tr>
            <td><div class="font-extrabold text-slate-800">${escapeHtml(item.full_name)}</div><div class="mt-1 text-[10px] text-slate-400">Request #${escapeHtml(item.id)}</div></td>
            <td><div class="font-semibold text-slate-700">${escapeHtml(item.organization_name || 'N/A')}</div></td>
            <td><div class="font-bold text-slate-700"><i class="ti ti-calendar-event mr-1 text-emerald-700"></i>${escapeHtml(formatMeetingDate(item.preferred_date))}</div><div class="mt-1 text-[10px] text-slate-500"><i class="ti ti-clock mr-1"></i>${escapeHtml(formatMeetingTime(item.start_time))} - ${escapeHtml(formatMeetingTime(item.end_time))}</div></td>
            <td><div><i class="ti ti-mail mr-1 text-emerald-700"></i>${escapeHtml(item.email || '-')}</div><div class="mt-1 text-[10px] text-slate-500"><i class="ti ti-phone mr-1"></i>${escapeHtml(item.phone || '-')}</div></td>
            <td><span class="meeting-status ${statusClass}">${escapeHtml(status)}</span></td>
            <td class="text-right"><button type="button" class="inline-flex h-8 items-center gap-1 rounded-lg border border-emerald-200 px-3 text-[10px] font-extrabold text-emerald-700 hover:bg-emerald-50" onclick="viewMeetingDetails(${Number(item.id)})"><i class="ti ti-eye"></i>View</button></td>
        </tr>`;
    });
    $('#meetingsTableBody').html(html);
}

function renderMeetingPagination(totalPages) {
    let html = '<button class="meeting-page-btn" data-meeting-page="' + Math.max(1, meetingCurrentPage - 1) + '" ' + (meetingCurrentPage === 1 ? 'disabled' : '') + '><i class="ti ti-chevron-left"></i></button>';
    const from = Math.max(1, meetingCurrentPage - 2);
    const to = Math.min(totalPages, from + 4);
    for (let page = from; page <= to; page++) html += '<button class="meeting-page-btn ' + (page === meetingCurrentPage ? 'is-active' : '') + '" data-meeting-page="' + page + '">' + page + '</button>';
    html += '<button class="meeting-page-btn" data-meeting-page="' + Math.min(totalPages, meetingCurrentPage + 1) + '" ' + (meetingCurrentPage === totalPages ? 'disabled' : '') + '><i class="ti ti-chevron-right"></i></button>';
    $('#meetingPagination').html(html);
}

function formatMeetingDate(value) {
    if (!value) return '-';
    const date = new Date(value + 'T00:00:00');
    return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatMeetingTime(value) {
    if (!value) return '-';
    const parts = String(value).split(':');
    const date = new Date();
    date.setHours(Number(parts[0] || 0), Number(parts[1] || 0), 0, 0);
    return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

function exportMeetingsCsv() {
    const rows = [['Full Name','Organization','Preferred Date','Start Time','End Time','Email','Phone','Status']];
    meetingFilteredRows.forEach(item => rows.push([item.full_name || '', item.organization_name || '', item.preferred_date || '', item.start_time || '', item.end_time || '', item.email || '', item.phone || '', item.status || '']));
    const csv = rows.map(row => row.map(value => '"' + String(value == null ? '' : value).replace(/"/g, '""') + '"').join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    link.download = 'meeting-requests.csv';
    document.body.appendChild(link);
    link.click();
    URL.revokeObjectURL(link.href);
    link.remove();
}

function viewMeetingDetails(id) {
    $.ajax({
        url: 'ajax.php?action=getMeetingDetails',
        type: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(res) {
            if (res.status === 'success') {
                const m = res.data;
                const bodyHtml = `
                    <div class="mb-3"><strong>Full Name:</strong> ${escapeHtml(m.full_name)}</div>
                    <div class="mb-3"><strong>Email:</strong> ${escapeHtml(m.email)}</div>
                    <div class="mb-3"><strong>Phone:</strong> ${escapeHtml(m.phone)}</div>
                    <div class="mb-3"><strong>Organization:</strong> ${escapeHtml(m.organization_name || '-')}</div>
                    <div class="mb-3"><strong>Preferred Date:</strong> ${escapeHtml(m.preferred_date)}</div>
                    <div class="mb-3"><strong>Time Slot:</strong> ${escapeHtml(m.start_time)} to ${escapeHtml(m.end_time)}</div>
                    <div class="mb-3"><strong>Status:</strong> ${escapeHtml(m.status)}</div>
                    <div class="mb-0"><strong>Submitted At:</strong> ${escapeHtml(m.submitted_at || m.created_at)}</div>
                `;
                $('#meetingModalBody').html(bodyHtml);
                $('#meetingModal').modal('show');
            }
        }
    });
}

function triggerManualSync(entity) {
    const $button = $('button[onclick="triggerManualSync(\'' + entity + '\')"]');
    $button.prop('disabled', true);
    $.ajax({
        url: 'syncAjax.php',
        type: 'POST',
        data: { action: 'triggerEntitySync', entity: entity, csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '' },
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                if (window.toastr) toastr.success(res.message);
                else alert(res.message);
                loadMeetingsGrid();
            } else {
                if (window.toastr) toastr.error(res.message || 'Website sync failed.');
                else alert(res.message || 'Website sync failed.');
            }
        },
        error: function(xhr) {
            const message = xhr.responseJSON?.message || 'Website sync failed. Please try again.';
            if (window.toastr) toastr.error(message);
            else alert(message);
        },
        complete: function() {
            $button.prop('disabled', false);
        }
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

$(document).on('submit', '#meetingRequestsExportForm', function (e) {
    e.preventDefault();
    const search = $('#meetingSearchInput').val() || '';
    const formData = new FormData(this);
    formData.append('exportMeetingRequests', '1');
    formData.append('search', search);

    $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    const $submitBtn = $('#meetingRequestsExportForm button[type="submit"]');
    $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Exporting...');

    $.ajax({
        url: 'exportajax.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (response) {
            if (response.success === 'success') {
                $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                if (window.toastr) toastr.success(response.message);
                else alert(response.message);
            } else {
                if (window.toastr) toastr.error(response.message);
                else alert(response.message);
            }
        },
        error: function () {
            if (window.toastr) toastr.error('Server error occurred.');
            else alert('Server error occurred.');
        },
        complete: function () {
            $submitBtn.prop('disabled', false).html('<i class="ti ti-download text-base"></i> Export');
        }
    });
});

$(document).on('click', '#meetingRequestsExportForm .export-type-item', function () {
    const val = $(this).data('val');
    $('#exportTypeText').text($(this).text());
    $('#exportTypeSelect').val(val);
});

$(document).on('click', '#meetingDeselectAllColumnsBtn', function () {
    const $columns = $('#meetingRequestsExportForm .column-filter');
    const shouldSelect = $columns.filter(':checked').length === 0;
    $columns.prop('checked', shouldSelect).trigger('change');
});

$(document).on('change', '#meetingRequestsExportForm .column-filter', function () {
    const hasSelectedColumns = $('#meetingRequestsExportForm .column-filter:checked').length > 0;
    $('#meetingDeselectAllColumnsBtn').text(hasSelectedColumns ? 'Deselect All' : 'Select All');
    $('#downloadExortfile').addClass('hidden d-none').removeAttr('href download style');
});
</script>
<?php endSection(); ?>

<!-- Export Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="meetingRequestsExportForm">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                        <div class="dropdown w-full">
                            <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                            <button type="button" id="meetingDeselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2">
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Request ID" checked /><span class="text-sm font-medium text-slate-700">Request ID</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Full Name" checked /><span class="text-sm font-medium text-slate-700">Full Name</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Organization" checked /><span class="text-sm font-medium text-slate-700">Organization</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Preferred Date" checked /><span class="text-sm font-medium text-slate-700">Preferred Date</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Start Time" checked /><span class="text-sm font-medium text-slate-700">Start Time</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="End Time" checked /><span class="text-sm font-medium text-slate-700">End Time</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Email" checked /><span class="text-sm font-medium text-slate-700">Email</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Phone" checked /><span class="text-sm font-medium text-slate-700">Phone</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Status" checked /><span class="text-sm font-medium text-slate-700">Status</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Submitted At" checked /><span class="text-sm font-medium text-slate-700">Submitted At</span></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none !rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="inline-flex h-10 w-28 items-center justify-center gap-2 !rounded-xl text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534);"><i class="ti ti-download text-base"></i> Export</button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="hidden d-none inline-flex h-10 w-auto items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534); display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                </div>
            </form>
        </div>
    </div>
</div>
