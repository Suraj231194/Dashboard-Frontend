<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">View and manage COA generation records</p>
        </div>
    </div>

    <!-- Pending COA Generation Alert Widget -->
    <div id="incomingCoaGenerationWidget"
        class="mb-6 cursor-pointer overflow-hidden rounded-xl border p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md w-full md:w-1/2"
        style="border-color: color-mix(in srgb, var(--appearance-accent, #059669) 24%, #a7f3d0); background-color: color-mix(in srgb, var(--appearance-accent, #059669) 7%, #ecfdf5);"
        role="button" tabindex="0">
        <div class="flex items-center justify-between gap-4">
            <div class="flex min-w-0 items-center gap-3">
                <span class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm ring-1 ring-black/5"
                    style="color: var(--appearance-accent, #059669);">
                    <i class="ti ti-certificate text-2xl"></i>
                </span>
                <div class="min-w-0">
                    <div class="flex flex-wrap items-center gap-2">
                        <h3 class="m-0 text-base font-extrabold text-slate-900">Pending COA Generation Requests</h3>
                        <span id="incomingCoaGenerationCount"
                            class="inline-flex min-w-6 items-center justify-center rounded-full px-2 py-0.5 text-[10px] font-extrabold text-white"
                            style="background-color: var(--appearance-accent, #059669);">0</span>
                    </div>
                    <p class="m-0 mt-1 text-xs font-medium text-slate-600">
                        Click here to review pending COA generation records approved from SA Generation.
                    </p>
                </div>
            </div>
            <i class="ti ti-chevron-right shrink-0 text-xl" style="color: var(--appearance-accent, #059669);"></i>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="coaGenPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="coagen-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="coagen-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="coagen-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="coagen-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="coagen-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="coagen-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchCoa"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto w-full border-t border-slate-200">
                <table class="w-full border-collapse whitespace-nowrap text-left">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="approval_date" data-order="desc">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="coa_number" data-order="desc">
                                <span class="inline-flex items-center gap-1">COA Number <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="name" data-order="desc">
                                <span class="inline-flex items-center gap-1">Product Description <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-44 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="suplier_name" data-order="desc">
                                <span class="inline-flex items-center gap-1">Supplier <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="coa_approval_status" data-order="desc">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3">Created By</th>
                            <th class="w-36 px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="saCoaTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Hide the per-page dropdown in footer -->
            <style>
                #footerPerPageSelect + .dropdown { display: none !important; }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- Inbound Material(s)! Requests Modal -->
    <div class="modal fade animate__animated fadeIn" id="inboundMaterialsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-700 ring-1 ring-rose-100">
                            <i class="ti ti-bell-ringing text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Inbound Material(s)! Requests</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Newly arrived items verified in Goods Received, pending quality COA generation</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body !px-4 !py-4">
                    <div class="overflow-x-auto w-full">
                        <table class="w-full border-collapse whitespace-nowrap text-left text-sm">
                            <thead class="border-b border-slate-100 bg-slate-50 text-[11px] font-bold uppercase tracking-widest text-slate-500">
                                <tr>
                                    <th class="px-4 py-3">Date</th>
                                    <th class="px-4 py-3">Product Name</th>
                                    <th class="px-4 py-3">Quantity</th>
                                    <th class="w-64 min-w-[220px] px-4 py-3">Supplier / Vendor</th>
                                    <th class="px-4 py-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="inboundMaterialsListBody" class="divide-y divide-slate-100">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<style>
    #inboundCoaEntryModal .modal-dialog-scrollable .modal-content,
    #inboundCoaEntryModal .modal-content {
        display: flex !important;
        flex-direction: column !important;
        max-height: calc(100vh - 3.5rem) !important;
        overflow: hidden !important;
    }
    #inboundCoaEntryModal .modal-header,
    #inboundCoaEntryModal .modal-footer {
        flex-shrink: 0 !important;
    }
    #inboundCoaEntryModal .modal-body {
        flex: 1 1 auto !important;
        min-height: 0 !important;
        overflow-y: auto !important;
    }
</style>

    <!-- pre-filled Inbound COA Entry Modal -->
    <div class="modal fade animate__animated fadeIn" id="inboundCoaEntryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="document">
            <form id="inboundCoaEntryForm" class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex-shrink-0 flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Generate COA Record</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Confirm and populate inbound material COA details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>

                <input type="hidden" name="inbound_queue_id" id="inbound_queue_id" />
                <input type="hidden" name="stock_inward_id" id="stock_inward_id" />
                
                <div class="modal-body flex-1 min-h-0 overflow-y-auto bg-slate-50/50 !px-4 !py-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Goods Type</label>
                            <select name="type" id="coa_goods_type" class="input-theme select2" required>
                                <option value="RM">Raw Material (RM)</option>
                                <option value="PM">Packing Material (PM)</option>
                                <option value="FG">Finished Goods (FG)</option>
                            </select>
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">COA Auto Generated #</label>
                            <input type="text" name="coa_number" id="coa_number" class="input-theme bg-slate-100" readonly required />
                            <input type="hidden" name="coa_digit" id="coa_digit" />
                        </div>
                        <div class="md:col-span-2">
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Product Description</label>
                            <input type="text" name="name" id="coa_product_name" class="input-theme bg-slate-100" readonly required />
                        </div>
                        <div class="md:col-span-2">
                            <div class="flex items-center justify-between mb-1">
                                <label class="form-label font-bold text-xs uppercase text-slate-700 m-0">Material Testing Template <span class="text-xs font-normal text-slate-500 lowercase">(optional)</span></label>
                                <a href="index.php?page=coa-templates" target="_blank" class="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline" title="Configure New Template in Company Control Room > COA Templates">
                                    <i class="ti ti-settings-cog"></i> Company Control Room &gt; COA Templates
                                </a>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-12 gap-3">
                                <div class="md:col-span-8">
                                    <select name="coa_template_id" id="inboundCoaTemplateSelect" class="input-theme select2" style="width: 100%;">
                                        <option value="">-- No Template / Optional --</option>
                                    </select>
                                </div>
                                <div class="md:col-span-2">
                                    <button type="button" id="inboundLoadTemplateBtn" class="w-full inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl bg-indigo-600 px-3 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition-colors">
                                        <i class="ti ti-download"></i> Load
                                    </button>
                                </div>
                                <div class="md:col-span-2">
                                    <a href="index.php?page=coa-templates" target="_blank" class="w-full inline-flex h-10 items-center justify-center gap-1.5 !rounded-xl border border-indigo-200 bg-indigo-50/80 px-2 text-xs font-bold text-indigo-700 shadow-sm hover:bg-indigo-100 transition-colors text-center" title="Configure new template in Company Control Room > COA Templates">
                                        <i class="ti ti-plus"></i> Configure
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div id="inboundDynamicCoaFields" class="md:col-span-2"></div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Supplier Name</label>
                            <input type="text" name="suplier_name" id="coa_supplier_name" class="input-theme bg-slate-100" readonly required />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Manufacturer Name</label>
                            <input type="text" name="manufacturer_name" id="coa_manufacturer_name" class="input-theme bg-slate-100" readonly required />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Batch Qty (Initial)</label>
                            <input type="number" step="any" name="batch_qty" id="coa_batch_qty" class="input-theme bg-slate-100" readonly required />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Batch Size / Pack Count</label>
                            <input type="text" name="batch_size" id="coa_batch_size" class="input-theme bg-slate-100" placeholder="e.g. 30500 pcs" readonly required />
                            <input type="hidden" name="batch_unit_id" id="coa_batch_unit_id" />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Batch Number <strong class="text-rose-500">*</strong></label>
                            <input type="text" name="batch_number" id="coa_batch_number" class="input-theme" placeholder="Enter Batch Number" required />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Material Code No</label>
                            <input type="text" name="material_code_no" id="coa_material_code" class="input-theme bg-slate-100" readonly required />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Receipt Date</label>
                            <input type="date" name="receipt_date" id="coa_receipt_date" class="input-theme bg-slate-100" readonly />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Testing Date</label>
                            <input type="date" name="testing_date" id="coa_testing_date" class="input-theme" required />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Mfg Date</label>
                            <input type="date" name="mfg_date" id="coa_mfg_date" class="input-theme" />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Expiry Date</label>
                            <input type="date" name="expiry_date" id="coa_expiry_date" class="input-theme" />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Invoice Number</label>
                            <input type="text" name="invoice_number" id="coa_invoice_number" class="input-theme bg-slate-100" readonly />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Invoice Date</label>
                            <input type="date" name="invoice_date" id="coa_invoice_date" class="input-theme bg-slate-100" readonly />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">No of Container Received</label>
                            <input type="text" name="number_of_container_received" id="coa_containers" class="input-theme" />
                        </div>
                        <div>
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Storage Condition</label>
                            <input type="text" name="storage_condition" id="coa_storage" class="input-theme" placeholder="e.g. 2-8 °C" />
                        </div>
                        <div class="md:col-span-2">
                            <label class="form-label font-bold text-xs uppercase text-slate-700">Remarks</label>
                            <textarea name="remark_one" id="coa_remarks" class="input-theme min-h-[60px]"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer flex-shrink-0 border-t border-slate-200 bg-white !px-4 !py-3 flex items-center justify-end gap-3">
                    <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none">
                        <i class="ti ti-check text-lg"></i> Submit & Generate COA
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View COA Data Modal -->
    <div class="modal fade animate__animated fadeIn" id="viewCoaData" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">COA Generation Data</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">View COA details and approval status</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body bg-slate-50/70 !px-4 !py-3" id="viewCoaDataModalBody">
                </div>
            </div>
        </div>
    </div>

    <!-- Incoming Pending COA Generation Modal -->
    <div class="modal fade animate__animated fadeIn" id="incomingCoaGenerationModal" tabindex="-1" aria-labelledby="incomingCoaGenerationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content overflow-hidden !rounded-2xl border-0 shadow-2xl">
                <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                    <div>
                        <h5 id="incomingCoaGenerationModalLabel" class="modal-title m-0 text-lg font-extrabold text-emerald-700">
                            Pending COA Generation Requests
                        </h5>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-500">
                            Select a record approved from SA Generation to complete its Certificate of Analysis form.
                        </p>
                    </div>
                    <button type="button" class="btn-close mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body bg-white px-6 py-5">
                    <div class="overflow-hidden rounded-xl border border-slate-200">
                        <div class="overflow-x-auto w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                    <tr>
                                        <th class="w-12 border-b border-slate-200 px-4 py-3">S.No</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Date</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Product Description</th>
                                        <th class="border-b border-slate-200 px-4 py-3">COA Number</th>
                                        <th class="border-b border-slate-200 px-4 py-3">Supplier</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="incomingCoaGenerationTableBody" class="divide-y divide-slate-200 bg-white"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal-footer flex-nowrap border-t border-slate-200 bg-slate-50/80 px-6 py-4">
                    <div class="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <span id="incomingCoaGenerationSummary" class="inline-flex items-center gap-2 text-xs font-medium text-slate-500">
                            <i class="ti ti-info-circle text-base"></i>
                            Showing 0 pending COA requests.
                        </span>
                        <div class="flex items-center gap-1">
                            <button id="incomingCoaGenerationPrevious" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Previous page" disabled>
                                <i class="ti ti-chevron-left"></i>
                            </button>
                            <span id="incomingCoaGenerationCurrentPage"
                                class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-xs font-extrabold text-emerald-700">1</span>
                            <button id="incomingCoaGenerationNext" type="button"
                                class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                aria-label="Next page" disabled>
                                <i class="ti ti-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- COA PDF Preview Modal -->
    <div class="modal fade animate__animated fadeIn" id="viewCoaPdfModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-file-text text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">COA Preview</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview the Certificate of Analysis PDF
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body bg-slate-50/70 !px-4 !py-3" id="viewCoaDataPdfModalBody">
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentSortColumn = 'id';
    let currentSortOrder = 'desc';
    let currentStatusFilter = '';

    let incomingCoaGenerationPage = 1;
    const incomingCoaGenerationPerPage = 7;
    let incomingCoaGenerationRecords = [];

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function loadIncomingCoaWorkflow() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadIncomingCoaGenerationWorkflow: 1 },
            success: function (response) {
                if (response.status === 'success' && response.data) {
                    incomingCoaGenerationRecords = response.data.records || [];
                    const total = typeof response.data.total !== 'undefined' ? response.data.total : incomingCoaGenerationRecords.length;
                    $('#incomingCoaGenerationCount').text(total);
                    renderIncomingCoaGenerationRecords();
                }
            },
            error: function () {
                incomingCoaGenerationRecords = [];
                renderIncomingCoaGenerationRecords();
            }
        });
    }

    function renderIncomingCoaGenerationRecords() {
        const totalRows = incomingCoaGenerationRecords.length;
        const totalPages = Math.max(1, Math.ceil(totalRows / incomingCoaGenerationPerPage));
        incomingCoaGenerationPage = Math.min(Math.max(1, incomingCoaGenerationPage), totalPages);
        const offset = (incomingCoaGenerationPage - 1) * incomingCoaGenerationPerPage;
        const visibleRows = incomingCoaGenerationRecords.slice(offset, offset + incomingCoaGenerationPerPage);

        if (visibleRows.length === 0) {
            $('#incomingCoaGenerationTableBody').html(`<tr>
                <td colspan="6" class="px-6 py-10 text-center text-sm font-semibold text-slate-500">
                    No pending COA generation requests available.
                </td>
            </tr>`);
        } else {
            $('#incomingCoaGenerationTableBody').html(visibleRows.map(function (record, index) {
                return `<tr>
                    <td class="px-4 py-3 align-middle whitespace-nowrap text-xs font-semibold text-slate-700">${String(offset + index + 1).padStart(2, '0')}</td>
                    <td class="px-4 py-3 align-middle whitespace-nowrap text-xs text-slate-600">${escapeHtml(record.date_formatted || '')}</td>
                    <td class="px-4 py-3 align-middle text-xs font-bold text-slate-900">${escapeHtml(record.name || '')}</td>
                    <td class="px-4 py-3 align-middle text-xs font-medium text-slate-700">${escapeHtml(record.coa_number || '')}</td>
                    <td class="px-4 py-3 align-middle text-xs text-slate-600">${escapeHtml(record.suplier_name || '-')}</td>
                    <td class="px-4 py-3 align-middle text-center whitespace-nowrap">
                        <button type="button" class="btn btn-sm btn-primary rounded-xl px-3 py-1 font-semibold incoming-coa-review-btn" data-id="${escapeHtml(record.id)}">
                            <i class="ti ti-checklist me-1"></i> Review
                        </button>
                    </td>
                </tr>`;
            }).join(''));
        }

        $('#incomingCoaGenerationSummary').html(
            `<i class="ti ti-info-circle text-base"></i>Showing ${totalRows} pending COA requests.`
        );
        $('#incomingCoaGenerationCurrentPage').text(incomingCoaGenerationPage);
        $('#incomingCoaGenerationPrevious').prop('disabled', incomingCoaGenerationPage <= 1);
        $('#incomingCoaGenerationNext').prop('disabled', incomingCoaGenerationPage >= totalPages);
    }

    function openCoaViewModal(id) {
        $('#viewCoaDataModalBody').html('<div class="p-8 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></div>');
        $('#viewCoaData').modal('show');
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                fetchCoaDataView: 'fetchCoaDataView',
                id: id
            },
            success: function (response) {
                try {
                    const res = typeof response === 'string' ? JSON.parse(response) : response;
                    if (res.status === 'success') {
                        $('#viewCoaDataModalBody').html(res.data);
                        $('#viewCoaData').modal('show');
                        initViewCoaDataSelect2($('#viewCoaDataModalBody .select2'));
                    } else {
                        toastr.error(res.message || 'Something went wrong.');
                    }
                } catch (e) {
                    console.error('Invalid JSON:', e);
                    toastr.error('Invalid server response.');
                }
            },
            error: function () {
                toastr.error('Invalid server response.');
            }
        });
    }

    function initViewCoaDataSelect2($elements) {
        $elements.select2({
            dropdownParent: $('#viewCoaData')
        });
    }

    function bindViewCoaDataSelect2Scroll() {
        setTimeout(function() {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.coaModalScroll')
                .on('wheel.coaModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $('#viewCoaData .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $('#viewCoaData .select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    function loadCoaTable(page = 1) {
        currentPage = page;
        const search = $('#searchCoa').val().trim();
        const perPage = $('#perPageSelect').val();

        $('#saCoaTableBody').html('<tr><td colspan="8" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadCoaData: 'loadCoaData',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder,
                status_filter: currentStatusFilter
            },
            success: function (response) {
                $('#saCoaTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const visibleRows = $('#saCoaTableBody tr').length;
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * parseInt(perPage)) + visibleRows, totalRows) : 0;
                $('#coaPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
                if (typeof response.pending_coa_count !== 'undefined') {
                    $('#incomingCoaGenerationCount').text(response.pending_coa_count);
                }
            },
            error: function () {
                $('#saCoaTableBody').html('<tr><td colspan="8" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#coaPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    $(document).ready(function () {
        loadCoaTable();
        loadIncomingCoaWorkflow();
        const inboundQueueId = Number(new URLSearchParams(window.location.search).get('inbound_queue_id')) || 0;
        if (inboundQueueId > 0) {
            openInboundCoaForm(inboundQueueId);
        }

        $(document).on('click keydown', '#incomingCoaGenerationWidget', function (e) {
            if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
            if (e.type === 'keydown') e.preventDefault();
            incomingCoaGenerationPage = 1;
            loadIncomingCoaWorkflow();
            $('#incomingCoaGenerationModal').modal('show');
        });

        $(document).on('click', '#incomingCoaGenerationPrevious', function () {
            if (incomingCoaGenerationPage > 1) {
                incomingCoaGenerationPage--;
                renderIncomingCoaGenerationRecords();
            }
        });

        $(document).on('click', '#incomingCoaGenerationNext', function () {
            incomingCoaGenerationPage++;
            renderIncomingCoaGenerationRecords();
        });

        $(document).on('click', '.incoming-coa-review-btn', function () {
            const id = $(this).attr('data-id');
            if (id) {
                $('#incomingCoaGenerationModal').modal('hide');
                openCoaViewModal(id);
            }
        });

        $(document).on('click', '.modalViewCoaDataAnimate', function () {
            const id = $(this).attr('data-id');
            if (id) {
                openCoaViewModal(id);
            }
        });

        $(document).on('select2:open', function(e) {
            if (!$(e.target).closest('#viewCoaData').length) return;
            bindViewCoaDataSelect2Scroll();
        });
        $('#viewCoaData .modal-body').on('scroll', function() {
            $('#viewCoaData .select2-hidden-accessible').select2('close');
        });
        $('#searchCoa').on('input', function () {
            loadCoaTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadCoaTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadCoaTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.coagen-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#coaGenPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $(document).on('submit', '#coaApprovalForm', function (e) {
            e.preventDefault();
            const $form = $(this);
            let formData = $form.serialize();
            formData += '&coaApprovalFrom=coaApprovalFrom';
            const $submitBtn = $form.find('#submitCoaApprovalBtn');
            const $loader = $form.find('#submitLoaderCoaApproval');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function () {
                    $submitBtn.prop('disabled', true);
                    $loader.removeClass('d-none').addClass('d-inline-block');
                },
                success: function (response) {
                    if (response.status === 'success') {
                        toastr.success(response.message || 'Submitted successfully');
                        $form[0].reset();
                        $('#viewCoaData').modal('hide');
                        if (typeof loadCoaTable === 'function') {
                            loadCoaTable();
                        }
                        loadIncomingCoaWorkflow();
                    } else {
                        toastr.error(response.message || 'Something went wrong while submitting.');
                    }
                },
                error: function (xhr) {
                    toastr.error('Server error occurred. Please try again.');
                },
                complete: function () {
                    $submitBtn.prop('disabled', false);
                    $loader.removeClass('d-inline-block').addClass('d-none');
                }
            });
        });
    });

    $(document).on('change', 'input[name="approvalCOAStatus"]', function () {
        if ($('#approvalCOAStatusReject').is(':checked')) {
            $('#coaRemarksQc').prop('required', true);
        } else {
            $('#coaRemarksQc').prop('required', false);
        }
    });

    $(document).on('click', 'th.sortable', function () {
        const column = $(this).data('column');
        const order = $(this).data('order');
        currentSortColumn = column;
        currentSortOrder = (order === 'asc') ? 'desc' : 'asc';
        $('th.sortable').removeClass('asc desc');
        $(this).data('order', currentSortOrder);
        $(this).addClass(currentSortOrder);
        loadCoaTable(1);
    });

    $(document).on('change', '#coaTemplateSelect', function () {
        let templateId = $(this).val();
        $('#dynamicCoaFields').html('');
        if (templateId) {
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchTemplateFields: 'fetchTemplateFields',
                    template_id: templateId
                },
                success: function (response) {
                    try {
                        let res = typeof response === 'string' ? JSON.parse(response) : response;
                        if (res.status === 'success') {
                            $('#dynamicCoaFields').html(res.data);
                            initViewCoaDataSelect2($('#dynamicCoaFields .select2'));
                        } else {
                            toastr.error(res.message || 'No fields found for this template');
                            $('#dynamicCoaFields').empty();
                        }
                    } catch (e) {
                        console.error('Invalid JSON:', response);
                        toastr.error('Invalid response from server');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred');
                }
            });
        } else {
            $('#dynamicCoaFields').empty();
        }
    });

    $(document).on('click', '.generateCoaPdfViewBtn', function () {
        let id = $(this).attr('data-id');
        $('#viewCoaDataPdfModalBody').html('');
        if (id) {
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { id: id, generateCoaPdfViewFunction: 'generateCoaPdfViewFunction' },
                success: function (res) {
                    try {
                        if (res.status === 'success') {
                            $('#viewCoaDataPdfModalBody').html(res.data);
                            $('#viewCoaPdfModel').modal('show');
                        } else {
                            toastr.error(res.message || 'Something went wrong');
                        }
                    } catch (err) {
                        toastr.error('Unexpected response format');
                    }
                },
                error: function () {
                    toastr.error("Something went wrong.");
                }
            });
        }
    });



    function loadInboundMaterialsWidget(openModal = false) {
        return $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: { loadInboundMaterialsList: '1' },
            success: function (res) {
                if (res.status === 'success') {
                    let html = '';
                    if (res.data.length > 0) {
                        res.data.forEach(function (row) {
                            html += `<tr class="inboundCoaRequestRow align-middle cursor-pointer transition-colors hover:bg-slate-50/50 focus:bg-slate-50/50 focus:outline-none" data-id="${row.id}" role="button" tabindex="0" aria-label="Open quality review for ${row.product_name}">
                                <td class="px-4 py-3 font-semibold text-slate-700">${row.date_received}</td>
                                <td class="px-4 py-3 font-bold text-slate-900">${row.product_name} (${row.product_code})</td>
                                <td class="px-4 py-3 text-slate-600">${parseFloat(row.quantity)} ${row.unit_name || ''}</td>
                                <td class="px-4 py-3 text-slate-700">${row.supplier_name || '-'}</td>
                                <td class="px-4 py-3 text-center">
                                    <button type="button" class="btn btn-sm btn-icon btn-outline-rose rounded-xl openInboundCoaFormBtn" data-id="${row.id}">
                                        <i class="ti ti-arrow-right"></i>
                                    </button>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = `<tr><td colspan="5" class="text-center py-4 text-slate-400 font-medium">No pending inbound materials.</td></tr>`;
                    }
                    $('#inboundMaterialsListBody').html(html);
                    if (openModal) {
                        $('#inboundMaterialsModal').modal('show');
                    }
                } else {
                    toastr.error(res.message || 'Unable to load inbound materials.');
                }
            },
            error: function () {
                toastr.error('Unable to load inbound materials.');
            }
        });
    }

    $(document).on('click', '#openInboundMaterialsBtn', function () {
        loadInboundMaterialsWidget(true);
    });

    function openInboundCoaForm(id) {
        if (!id) {
            toastr.error('Invalid inbound material request.');
            return;
        }
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { fetchInboundMaterialForCoa: '1', id: id },
            success: function (res) {
                if (res.status === 'success') {
                    let m = res.data;
                    $('#inbound_queue_id').val(m.id);
                    $('#stock_inward_id').val(m.stock_inward_id);
                    $('#coa_goods_type').val(m.goods_type).trigger('change');
                    $('#coa_number').val(res.generated_coa);
                    $('#coa_digit').val(res.generated_digit);
                    $('#coa_product_name').val(m.product_name);
                    $('#coa_supplier_name').val(m.supplier_name);
                    $('#coa_manufacturer_name').val(m.supplier_name); // Default manufacturer to supplier
                    $('#coa_batch_qty').val(parseFloat(m.quantity));
                    $('#coa_batch_size').val(parseFloat(m.quantity) + ' ' + (m.unit_name || 'units'));
                    $('#coa_batch_unit_id').val(m.unit_id);
                    $('#coa_batch_number').val(m.lot_number || '');
                    $('#coa_material_code').val(m.product_code);
                    $('#coa_receipt_date').val(m.date_of_entry);
                    $('#coa_testing_date').val(new Date().toISOString().slice(0, 10)); // Default testing date to today
                    $('#coa_mfg_date').val(m.prod_mfg_date || '');
                    $('#coa_expiry_date').val(m.prod_expiary_date || '');
                    $('#coa_invoice_number').val(m.invoice_number || '');
                    $('#coa_invoice_date').val(m.invoice_date || '');
                    $('#coa_containers').val('');
                    $('#coa_storage').val('Ambient');
                    $('#coa_remarks').val('');

                    const templates = Array.isArray(res.templates) ? res.templates : [];
                    let templateOptions = '<option value="">-- Select a Testing Template --</option>';
                    let currentGroup = '';
                    let firstRecommendedId = null;

                    templates.forEach(function (t) {
                        const grp = t.group_label || '📋 All Available COA Templates';
                        if (grp !== currentGroup) {
                            if (currentGroup !== '') templateOptions += '</optgroup>';
                            templateOptions += `<optgroup label="${escapeHtml(grp)}">`;
                            currentGroup = grp;
                        }
                        const recBadge = t.is_recommended ? ' ⭐' : '';
                        const itemsBadge = t.item_count ? ` (${t.item_count} items)` : '';
                        templateOptions += `<option value="${t.id}" data-recommended="${t.is_recommended ? '1' : '0'}">${escapeHtml(t.name)}${recBadge}${itemsBadge}</option>`;
                        if (t.is_recommended && !firstRecommendedId) {
                            firstRecommendedId = t.id;
                        }
                    });
                    if (currentGroup !== '') templateOptions += '</optgroup>';

                    const $tmplSelect = $('#inboundCoaTemplateSelect');
                    if ($tmplSelect.hasClass('select2-hidden-accessible')) {
                        try { $tmplSelect.select2('destroy'); } catch(e) {}
                    }
                    $tmplSelect.html(templateOptions);
                    $tmplSelect.select2({
                        dropdownParent: $('#inboundCoaEntryModal'),
                        width: '100%'
                    });

                    if (firstRecommendedId) {
                        $tmplSelect.val(firstRecommendedId).trigger('change.select2');
                        loadInboundTemplateFields(firstRecommendedId);
                    } else if (templates.length > 0) {
                        $tmplSelect.val(templates[0].id).trigger('change.select2');
                        loadInboundTemplateFields(templates[0].id);
                    } else {
                        $('#inboundDynamicCoaFields').html(`
                            <div class="rounded-xl border border-dashed border-slate-300 bg-slate-50/80 p-5 text-center text-xs text-slate-600">
                                <i class="ti ti-info-circle text-2xl block mb-1 text-indigo-600"></i>
                                <div class="font-medium text-slate-700 mb-1">No active testing template is configured for this material.</div>
                                <p class="text-slate-500 m-0 mb-3">Testing template is optional. You can proceed with COA generation or configure a template in Company Control Room.</p>
                                <a href="index.php?page=coa-templates" target="_blank" class="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-indigo-700 shadow-sm transition-all">
                                    <i class="ti ti-settings-cog"></i> Configure COA Templates
                                </a>
                            </div>
                        `);
                    }

                    $('#inboundMaterialsModal').modal('hide');
                    $('#inboundCoaEntryModal').modal('show');
                } else {
                    toastr.error(res.message);
                }
            }
        });
    }

    function loadInboundTemplateFields(templateId) {
        if (!templateId) {
            $('#inboundDynamicCoaFields').html(`
                <div class="rounded-xl border border-dashed border-slate-200 bg-slate-50/60 p-4 text-center text-xs text-slate-500">
                    <i class="ti ti-info-circle text-lg block mb-1 text-slate-400"></i>
                    No testing template selected. You can proceed to generate COA without template observations, or select a template above.
                </div>
            `);
            return;
        }
        $('#inboundDynamicCoaFields').html(`
            <div class="py-6 text-center text-slate-400 text-xs">
                <i class="ti ti-loader-2 animate-spin text-2xl block mb-1 text-indigo-600"></i>
                Loading template specifications &amp; test parameters...
            </div>
        `);
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: { fetchTemplateFields: 'fetchTemplateFields', template_id: templateId },
            success: function (res) {
                if (res.status === 'success') {
                    $('#inboundDynamicCoaFields').html(res.data);
                } else {
                    toastr.error(res.message || 'Unable to load the testing template.');
                }
            },
            error: function () {
                toastr.error('Unable to load the testing template.');
            }
        });
    }

    $(document).on('click', '.openInboundCoaFormBtn', function () {
        openInboundCoaForm($(this).data('id'));
    });

    $(document).on('click', '#inboundLoadTemplateBtn', function () {
        const tmplId = $('#inboundCoaTemplateSelect').val();
        if (!tmplId) {
            toastr.warning('Please select a testing template first.');
            return;
        }
        loadInboundTemplateFields(tmplId);
    });

    $(document).on('change', '#inboundCoaTemplateSelect', function () {
        const templateId = $(this).val();
        if (templateId) {
            loadInboundTemplateFields(templateId);
        }
    });

    $(document).on('click keydown', '.inboundCoaRequestRow', function (event) {
        if ($(event.target).closest('button, a').length) {
            return;
        }
        if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') {
            return;
        }
        event.preventDefault();
        openInboundCoaForm($(this).data('id'));
    });

    $('#coa_goods_type').on('change', function () {
        const type = $(this).val();
        if (!type || !$('#inboundCoaEntryModal').hasClass('show')) {
            return;
        }
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { previewInboundCoaNumber: '1', type: type },
            success: function (response) {
                const res = typeof response === 'string' ? JSON.parse(response) : response;
                if (res.status === 'success') {
                    $('#coa_number').val(res.coa_number);
                    $('#coa_digit').val(res.coa_digit);
                }
            }
        });
    });

    $('#inboundCoaEntryForm').on('submit', function (e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&submitInboundCoa=1';
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            success: function (response) {
                try {
                    let res = typeof response === 'string' ? JSON.parse(response) : response;
                    if (res.status === 'success') {
                        $('#inboundCoaEntryModal').modal('hide');
                        toastr.success(res.message);
                        loadInboundMaterialsWidget();
                        loadCoaTable(1);
                    } else {
                        toastr.error(res.message);
                    }
                } catch (e) {
                    toastr.error('Failed to parse response.');
                }
            },
            error: function () {
                toastr.error('Request failed.');
            }
        });
    });

    $(document).on('click', '.pdfCOADownloadBtn', function () {
        let id = $(this).data('id');
        if (id) {
            let url = "<?php echo APP_URL; ?>admin/pages/coa_template_print.php?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');
            toastr.success('COA PDF is being downloaded.');
        }
    });
</script>
<?php endSection(); ?>
