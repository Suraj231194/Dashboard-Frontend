<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="row">
        <p>This is the bpr screen.</p>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    // Write your script here
</script>
<?php endSection(); ?>
