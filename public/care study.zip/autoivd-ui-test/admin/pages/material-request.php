<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage and track material requests</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <!-- Search / Export Strip -->
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">

                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="materialReqPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="material-req-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="material-req-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="material-req-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="material-req-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="material-req-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="material-req-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <!-- Search input -->
                    <div class="relative h-10 min-w-[150px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Material Requests...">
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-full md:w-36 h-11" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                </div>
            </div>

            <!-- Table -->
            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="w-32 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="date">
                                <span class="inline-flex items-center gap-1">Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="lot_batch_no">
                                <span class="inline-flex items-center gap-1">LOT/Batch No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-52 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="product_name">
                                <span class="inline-flex items-center gap-1">Product Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-32 px-6 py-3">Batch Size</th>
                            <th class="w-36 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="requested_by">
                                <span class="inline-flex items-center gap-1">Requested By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-32 px-6 py-3 sortable cursor-pointer transition-colors hover:bg-slate-50/50"
                                data-column="status">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-40 px-6 py-3 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="productsTableBody">
                    </tbody>
                </table>
            </div>

            <!-- Pagination Footer -->
            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- UPDATE STATUS MODAL -->
    <div class="modal fade animate__animated fadeIn" id="materialRequstedStatusModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Update Status</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Change material request status</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="materialRequestStatusChangeForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-28 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-32 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- VIEW MODAL -->
    <div class="modal fade animate__animated fadeIn" id="viewMaterialRequestModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View Material Request</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Review request details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="viewMaterialRequest">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- EDIT MODAL -->
    <div class="modal fade animate__animated fadeIn" id="editMatRequestModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Material Request</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update request details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editMatRequestForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- PDF PREVIEW MODAL -->
    <div class="modal fade animate__animated fadeIn" id="materialRequisitionViewPdfModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-700 ring-1 ring-rose-100">
                            <i class="ti ti-file-text text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Material Requisition Preview
                            </h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview before download</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="materialRequisitionViewPdf">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- EDIT BOM MODAL -->
    <div class="modal fade animate__animated fadeIn" id="editMatRequestBomModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-clipboard-list text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Material Request (BOM)
                            </h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update BOM-based request items</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editMatRequestBomForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="materialRequestExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>

                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">DATE RANGE</label>
                            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                                <label class="block">
                                    <span class="mb-1 block text-xs font-semibold text-slate-600">From</span>
                                    <input type="date" name="fromDate" id="materialRequestExportFromDate" class="input-theme w-full" />
                                </label>
                                <label class="block">
                                    <span class="mb-1 block text-xs font-semibold text-slate-600">To</span>
                                    <input type="date" name="toDate" id="materialRequestExportToDate" class="input-theme w-full" />
                                </label>
                            </div>
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Timestamp" checked />
                                        <span class="text-sm font-medium text-slate-700">Timestamp</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Date" checked />
                                        <span class="text-sm font-medium text-slate-700">Date</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="LOT/Batch No" checked />
                                        <span class="text-sm font-medium text-slate-700">LOT/Batch No</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Product Name</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Batch Size" checked />
                                        <span class="text-sm font-medium text-slate-700">Batch Size</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Request By" checked />
                                        <span class="text-sm font-medium text-slate-700">Request By</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Status</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let qtyUnitOptions = [];
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                qtyUnitOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.label}</option>`;
                });
                $("#productUnit").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadMaterialRequestTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadMaterialRequestTable: 'loadMaterialRequestTable',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_order: currentSortOrder
            },
            success: function (response) {
                $('#productsTableBody').html(response.table);
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                if (response.summary) {

                }
            },
            error: function () {
                $('#productsTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    $(document).ready(function () {
        loadMaterialRequestTable();
        loadStandardUnit();
        $('#searchProducts').on('input', function () {
            loadMaterialRequestTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadMaterialRequestTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadMaterialRequestTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.material-req-per-page-item', function () {
            const val = $(this).data('val');
            $('#materialReqPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            $('#exportTypeSelect').val(val);
            $('#exportTypeText').text($(this).text());
        });

        $(document).on('click', '#deselectAllColumnsBtn', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('.column-filter').prop('checked', false);
                $(this).text('Select All');
            } else {
                $('.column-filter').prop('checked', true);
                $(this).text('Deselect All');
            }
        });

        $(document).on('change', '.column-filter', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('#deselectAllColumnsBtn').text('Deselect All');
            } else {
                $('#deselectAllColumnsBtn').text('Select All');
            }
        });

        function updateColumnsText() {
            const count = $('.column-filter:checked').length;
            $('#columnsSelectedText').text(count > 0 ? count + ' Columns' : 'Columns');
        }
        $(document).on('change', '.column-filter', function () { updateColumnsText(); });
        updateColumnsText();

        $(document).on('select2:open', function(e) {
            const $modal = $(e.target).closest('.modal');
            if (!$modal.length) return;
            bindModalSelect2Scroll('#' + $modal.attr('id'));
        });

        $('#editMatRequestModel .modal-body, #editMatRequestBomModel .modal-body, #materialRequestStatusChangeForm .modal-body').on('scroll', function() {
            $(this).closest('.modal').find('select.select2-hidden-accessible').select2('close');
        });
    });

    function bindModalSelect2Scroll(modalSelector) {
        setTimeout(function() {
            $('.select2-container--open .select2-dropdown')
                .off('wheel.myModalScroll')
                .on('wheel.myModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $(modalSelector + ' .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $(modalSelector + ' select.select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    $(document).on('click', '.materialRequestStatusChangeModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#materialRequestStatusChangeForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: { fetchMaterialRequestStatusRecord: 'fetchMaterialRequestStatusRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#materialRequstedStatusModal').modal('show');
                        $('#materialRequestStatusChangeForm').find('.modal-body').html(res.data);
                        $('#materialRequestStatusChangeForm .select2').select2({ dropdownParent: $('#materialRequstedStatusModal') });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.viewMaterialRequestModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewMaterialRequest').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewMaterialRequestRecord: 'viewMaterialRequestRecord', id: id },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#viewMaterialRequestModel').modal('show');
                        $('#viewMaterialRequest').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#materialRequestStatusChangeForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('materialRequestStatusChangeForm');
        const formData = new FormData(form);
        formData.append('updateMaterialRequestStatusRecord', 'updateMaterialRequestStatusRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#materialRequstedStatusModal').modal('hide');
                    $('#materialRequestStatusChangeForm').find('modal-body').html();
                    loadMaterialRequestTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.materialRequisitionEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editMatRequestForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: { fetchMaterialRequestRecord: 'fetchMaterialRequestRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editMatRequestModel').modal('show');
                        $('#editMatRequestForm').find('.modal-body').html(res.data);
                        $('#editMatRequestModel .select2').select2({
                            dropdownParent: $('#editMatRequestModel')
                        });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('submit', '#editMatRequestForm', function (e) {
        e.preventDefault();

        const form = document.getElementById('editMatRequestForm');
        const formData = new FormData(form);
        formData.append('updateMaterialReqestRecord', 'updateMaterialReqestRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#editMatRequestModel').modal('hide');
                    $('#editMatRequestForm').find('.modal-body').html();
                    loadMaterialRequestTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.previewMaterialRequisitionPdf', function () {
        let id = $(this).data('id');
        if (id) {
            $('#materialRequisitionViewPdf').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    materialRequisionViewPdfRecord: 'materialRequisionViewPdfRecord',
                    id: id
                },
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#materialRequisitionViewPdfModal').modal('show');
                        $('#materialRequisitionViewPdf').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('click', '.pdfPurchaseOrderFinalDownloadBtn', function () {
        let id = $(this).data('id');
        if (id) {
            // Open printable PDF page in a new tab
            let url = "<?php echo APP_URL; ?>admin/pages/material_requisition_template.php?id=" + id + "&triggerDownload=1";
            window.open(url, '_blank');

            // Show success message after triggering
            toastr.success('Material Requisition PDF is being downloaded.');
        }
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
        loadMaterialRequestTable(1);
    });

    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $('#materialRequestExportForm').on('submit', function (e) {
        e.preventDefault();
        page = 1;
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();
        const form = document.getElementById('materialRequestExportForm');
        const fromDate = form.elements.fromDate.value;
        const toDate = form.elements.toDate.value;
        if (fromDate && toDate && fromDate > toDate) {
            toastr.error('From date cannot be after To date.');
            return;
        }
        const formData = new FormData(form);
        formData.append('exportMaterialRequest', 'exportMaterialRequest');
        formData.append('search', search);
        formData.append('perPage', perPage);
        formData.append('page', page);
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');

        $.ajax({
            url: 'exportajax.php', // Change to your handler script
            type: 'POST',
            data: formData,
            contentType: false, // Must for FormData
            processData: false,
            dataType: 'json',
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.materialRequisitionBomEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editMatRequestBomForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: { fetchMaterialRequestBomRecord: 'fetchMaterialRequestBomRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editMatRequestBomModel').modal('show');
                        $('#editMatRequestBomForm').find('.modal-body').html(res.data);
                        $('#editMatRequestBomModel .select2').select2({
                            dropdownParent: $('#editMatRequestBomModel')
                        });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $(document).on('change', '.matRequiProdCategItemFilter', function () {

        let categoryId = $(this).val();
        let row = $(this).closest('.product-row');
        row.find('input[name*="[productCategId]"]').val(categoryId);

        let productSelect = row.find('.matRequiProductsItemsFilter');
        let availableQtyInput = row.find('.availableQty');

        productSelect.html('<option value="">Loading...</option>').trigger('change');
        availableQtyInput.val(0);

        if (!categoryId) return;

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                materialTypeId: categoryId,
                loadProductsCategoryTypeWithQuantity: 'loadProductsCategoryTypeWithQuantity'
            },
            success: function (response) {

                let html = '<option value="">----Select Product----</option>';

                response.forEach(function (p) {
                    html += `<option value="${p.key}" data-quantity="${p.total_quantity}">
                                ${p.value}
                            </option>`;
                });

                productSelect.html(html).trigger('change');
            }
        });
    });

    $(document).on('change', '.matRequiProductsItemsFilter', function () {

        let row = $(this).closest('.product-row');

        let productId = $(this).val();
        let selectedOption = $(this).find('option:selected');

        row.find('input[name*="[productId]"]').val(productId);

        let availableQty = parseFloat(selectedOption.data('quantity')) || 0;
        let requiredQty = parseFloat(row.data('required-qty')) || 0;

        row.find('.availableQty').val(availableQty);

        row.removeClass('border-success border-danger');

        if (requiredQty > 0 && availableQty >= requiredQty) {
            row.addClass('border-success');
        } else {
            row.addClass('border-danger');
        }
    });

    $(document).on('click', '.removeBomMatItem', function () {
        $(this).closest('.product-item-row, .product-row').remove();
    });

    $(document).on('change', '.matRequiProdCategFilter', function () {

        let categoryId = $(this).val();
        let row = $(this).closest('.product-row');
        row.find('input[name*="[productCategId]"]').val(categoryId);

        let productSelect = row.find('.matRequiProductsFilter');
        let availableQtyInput = row.find('.availableQty');

        productSelect.html('<option value="">Loading...</option>').trigger('change');
        availableQtyInput.val(0);

        if (!categoryId) return;

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                materialTypeId: categoryId,
                loadProductsCategoryTypeWithQuantity: 'loadProductsCategoryTypeWithQuantity'
            },
            success: function (response) {

                let html = '<option value="">----Select Product----</option>';

                response.forEach(function (p) {
                    html += `<option value="${p.key}" data-quantity="${p.total_quantity}">
                                ${p.value}
                            </option>`;
                });

                productSelect.html(html).trigger('change');
            }
        });
    });

    $(document).on('change', '.matRequiProductsFilter', function () {

        let row = $(this).closest('.product-row');

        let productId = $(this).val();
        let selectedOption = $(this).find('option:selected');

        row.find('input[name*="[productId]"]').val(productId);

        let availableQty = parseFloat(selectedOption.data('quantity')) || 0;
        let requiredQty = parseFloat(row.data('required-qty')) || 0;

        row.find('.availableQty').val(availableQty);

        row.removeClass('border-success border-danger');

        if (requiredQty > 0 && availableQty >= requiredQty) {
            row.addClass('border-success');
        } else {
            row.addClass('border-danger');
        }
    });



    // $(document).on('input', 'input[name="productIssuedQty[]"]', function () {

    //     let row = $(this).closest('.product-row');
    //     let issued = parseFloat($(this).val()) || 0;
    //     let available = parseFloat(row.find('.availableQty').val()) || 0;

    //     if (issued > available) {
    //         $(this).addClass('is-invalid');
    //     } else {
    //         $(this).removeClass('is-invalid');
    //     }
    // });



    $('#editMatRequestBomForm').on('submit', function (e) {
        e.preventDefault();

        let isValid = true;
        let errorMsg = '';

        $('.product-row').each(function (index) {

            let row = $(this);

            let categorySelect = row.find('.matRequiProdCategFilter');
            let productSelect = row.find('.matRequiProductsFilter');

            // reset previous error UI
            row.removeClass('border-danger');
            categorySelect.removeClass('is-invalid');
            productSelect.removeClass('is-invalid');

            // Category validation
            if (categorySelect.length && !categorySelect.val()) {
                isValid = false;
                errorMsg = 'Please select Product Category for all items.';
                row.addClass('border-danger');
                categorySelect.addClass('is-invalid');
                return false; // break .each loop
            }

            // Product validation
            if (productSelect.length && !productSelect.val()) {
                isValid = false;
                errorMsg = 'Please select Product for all items.';
                row.addClass('border-danger');
                productSelect.addClass('is-invalid');
                return false;
            }
        });

        if (!isValid) {
            toastr.error(errorMsg);
            return;
        }

        /* ---------- IF VALID ? SUBMIT ---------- */
        const form = document.getElementById('editMatRequestBomForm');
        const formData = new FormData(form);
        formData.append('updateMaterialReqestBOMRecord', 'updateMaterialReqestBOMRecord');

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $('#editMatRequestBomModel').modal('hide');
                    loadMaterialRequestTable();
                    toastr.success(res.message);
                } else {
                    toastr.error(res.message || 'Unable to update Material Request.');
                }
            },
            error: function (xhr) {
                toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
            }
        });
    });


</script>
<?php endSection(); ?>
