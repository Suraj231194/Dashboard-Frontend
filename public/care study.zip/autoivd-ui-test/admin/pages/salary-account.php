<div class="p-4 sm:p-6 lg:p-8">
    <div class="mb-8">
        <h2 class="text-3xl font-bold text-slate-900 mb-1">Update Payment Method</h2>
        <p class="text-sm text-slate-500">Update your salary disbursement details. Ensure all information is accurate to avoid payroll delays.</p>
    </div>

    <div class="flex flex-col md:flex-row gap-8">
        <!-- Left Column: Form (50% Width) -->
        <div class="w-full md:w-1/2 flex flex-col">
            <div class="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm">
                <form id="updatePaymentMethodForm">
                    <input type="hidden" name="action" value="update_payment_method">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                    <!-- Select Bank -->
                    <div class="mb-4">
                        <label class="mb-1 block text-sm font-medium text-slate-800" for="bank_id">Select Bank <strong class="text-rose-500">*</strong></label>
                        <select name="bank_id" id="bank_id" class="form-select input-theme select2" required>
                            <option value="" disabled selected>Choose your bank...</option>
                        </select>
                    </div>

                    <!-- New Account Number -->
                    <div class="mb-4">
                        <label class="mb-1 block text-sm font-medium text-slate-800">New Account Number <strong class="text-rose-500">*</strong></label>
                        <input type="text" name="bank_account_number" placeholder="Enter your new account number" class="form-control input-theme" required>
                    </div>

                    <!-- Reconfirm Account Number -->
                    <div class="mb-4">
                        <label class="mb-1 block text-sm font-medium text-slate-800">Reconfirm Account Number <strong class="text-rose-500">*</strong></label>
                        <input type="text" name="reconfirm_account_number" placeholder="Re-enter your account number" class="form-control input-theme" required>
                    </div>

                    <!-- IFSC Code -->
                    <div class="mb-4">
                        <label class="mb-1 block text-sm font-medium text-slate-800">IFSC Code <strong class="text-rose-500">*</strong></label>
                        <input type="text" name="bank_ifsc_code" placeholder="Enter 11-digit IFSC code" class="form-control input-theme uppercase" maxlength="11" required>
                    </div>

                    <!-- Account Holder Name -->
                    <div class="mb-6">
                        <label class="mb-1 block text-sm font-medium text-slate-800">Account Holder Name <strong class="text-rose-500">*</strong></label>
                        <input type="text" name="bank_account_holder_name" placeholder="Enter account holder name" required class="form-control input-theme font-medium">
                        <p class="text-xs text-slate-500 italic mt-2">Payroll accounts must be in the employee's legal name.</p>
                    </div>

                    <!-- Submit Button -->
                    <div class="pt-2">
                        <button type="submit"
                            class="inline-flex h-11 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-send text-lg"></i> Send Request to HR
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Right Column: Info Cards (50% Width) -->
        <div class="w-full md:w-1/2 flex flex-col gap-6">
            
            <!-- Notice Card -->
            <div class="rounded-2xl p-6 border shadow-sm" style="background-color: #eaf5ee; border-color: #c3e2cd;">
                <div class="flex items-center gap-2 mb-3">
                    <i class="ti ti-info-circle text-xl" style="color: #1a4331;"></i>
                    <h3 class="text-sm font-bold" style="color: #1a4331;">Payroll Processing Cycle Notice</h3>
                </div>
                <p class="text-sm leading-relaxed" style="color: #274936;">
                    All bank account updates are subject to <strong class="font-bold">HR Verification and Approval</strong>. Once submitted, a representative will review your request within 2-3 business days. Approved changes will take effect in the <strong class="font-bold">next payroll cycle</strong>. If submitted after the 20th of the month, the update will apply to the following month's disbursement.
                </p>
            </div>

            <!-- Pending Request Card -->
            <div id="pendingRequestCard" class="rounded-2xl p-6 border border-amber-200 shadow-sm bg-amber-50/50 hidden">
                <div class="flex items-center gap-2 mb-3 text-amber-800">
                    <i class="ti ti-clock text-xl"></i>
                    <h3 class="text-sm font-bold">Pending HR Approval</h3>
                </div>
                <div class="bg-white border border-amber-200 rounded-xl p-4">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 border border-amber-100 rounded-lg flex items-center justify-center shrink-0 bg-amber-50">
                            <i class="ti ti-credit-card text-xl text-amber-700"></i>
                        </div>
                        <div class="flex-1">
                            <h4 class="font-bold text-slate-900 text-sm" id="pendingBankName">-</h4>
                            <p class="text-xs text-slate-500 mt-0.5" id="pendingAccountMask">Ending in -</p>
                        </div>
                        <div class="shrink-0">
                            <span class="text-[10px] font-bold uppercase tracking-widest text-amber-700">Under Review</span>
                        </div>
                    </div>
                    <div class="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600">
                        <div class="flex justify-between mb-1">
                            <span>Holder Name:</span>
                            <span class="font-semibold text-slate-800" id="pendingHolderName">-</span>
                        </div>
                        <div class="flex justify-between mb-1">
                            <span>IFSC Code:</span>
                            <span class="font-semibold text-slate-800" id="pendingIfscCode">-</span>
                        </div>
                        <p class="text-[10px] text-amber-600 italic mt-2">You cannot submit a new request until this one is reviewed.</p>
                    </div>
                </div>
            </div>

            <!-- Active Method Card -->
            <div class="rounded-2xl p-6 border border-slate-200 shadow-sm bg-slate-50">
                <label class="mb-4 block text-xs font-bold text-slate-500 uppercase tracking-widest">Currently Active Method</label>
                <div id="activeMethodContainer">
                    <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-center">
                        <p class="text-sm text-slate-500"><i class="ti ti-loader ti-spin text-lg"></i> Loading...</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
$(document).ready(function() {
    function escapeHtml(text) {
        if (!text) return '';
        return $('<div>').text(text).html();
    }

    loadPaymentMethodDetails();

    function loadPaymentMethodDetails() {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { getPaymentMethodDetails: '1' },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    // Populate banks dropdown
                    let bankOptions = '<option value="" disabled selected>Choose your bank...</option>';
                    if (Array.isArray(response.banks)) {
                        response.banks.forEach(function(bank) {
                            bankOptions += `<option value="${bank.id}">${escapeHtml(bank.bank_name)}</option>`;
                        });
                    }
                    const $bankSelect = $('#bank_id');
                    if ($bankSelect.hasClass('select2-hidden-accessible')) {
                        $bankSelect.select2('destroy');
                    }
                    $bankSelect.html(bankOptions);
                    if (window.jQuery && jQuery.fn.select2) {
                        $bankSelect.select2({
                            width: '100%',
                            placeholder: 'Choose your bank...'
                        });
                    }
                    
                    // Populate active method
                    let currentBank = response.currentBank;
                    if (currentBank && (currentBank.bank_id || currentBank.bank_name)) {
                        let accNum = currentBank.bank_account_number || '';
                        let maskedAcc = accNum.length > 4 ? '•••• '.repeat(3) + ' ' + accNum.slice(-4) : (accNum || '—');
                        let bankName = currentBank.bank_name || 'Bank Account';
                        
                        let html = `
                        <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-4">
                            <div class="w-12 h-12 border border-slate-200 rounded-lg flex items-center justify-center shrink-0 bg-slate-50">
                                <i class="ti ti-credit-card text-xl text-slate-700"></i>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-bold text-slate-900 text-sm">${escapeHtml(bankName)}</h4>
                                <p class="text-xs text-slate-500 mt-0.5">Ending in ${escapeHtml(maskedAcc)}</p>
                            </div>
                            <div class="shrink-0">
                                <span class="text-[10px] font-bold uppercase tracking-widest text-emerald-700">Active</span>
                            </div>
                        </div>`;
                        $('#activeMethodContainer').html(html);
                    } else {
                        $('#activeMethodContainer').html(`
                        <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-center">
                            <p class="text-sm text-slate-500">No active payment method found.</p>
                        </div>`);
                    }

                    // Check pending request
                    let pending = response.pendingRequest;
                    if (pending) {
                        $('#pendingBankName').text(pending.bank_name || 'Bank Account');
                        let accNum = pending.bank_account_number || '';
                        let maskedAcc = accNum.length > 4 ? '•••• ' + accNum.slice(-4) : accNum;
                        $('#pendingAccountMask').text('Ending in ' + maskedAcc);
                        $('#pendingHolderName').text(pending.bank_account_holder_name || '—');
                        $('#pendingIfscCode').text(pending.bank_ifsc_code || '—');
                        $('#pendingRequestCard').removeClass('hidden');
                        
                        // Disable form
                        $('#updatePaymentMethodForm input, #updatePaymentMethodForm select').prop('disabled', true);
                        $('#updatePaymentMethodForm button[type="submit"]').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').html('<i class="ti ti-lock text-lg"></i> Verification Pending');
                    } else {
                        $('#pendingRequestCard').addClass('hidden');
                        $('#updatePaymentMethodForm input, #updatePaymentMethodForm select').prop('disabled', false);
                        $('#updatePaymentMethodForm button[type="submit"]').prop('disabled', false).removeClass('opacity-50 cursor-not-allowed').html('<i class="ti ti-send text-lg"></i> Send Request to HR');
                    }
                } else {
                    toastr.error(response.message || 'Failed to load details');
                }
            },
            error: function() {
                toastr.error('Failed to communicate with server');
            }
        });
    }

    $('#updatePaymentMethodForm').on('submit', function(e) {
        e.preventDefault();
        
        let accNumber = $('input[name="bank_account_number"]').val().trim();
        let reconfirm = $('input[name="reconfirm_account_number"]').val().trim();
        
        if (accNumber !== reconfirm) {
            toastr.error("Account numbers do not match");
            return;
        }

        let formData = $(this).serialize();
        let $btn = $(this).find('button[type="submit"]');
        let originalText = $btn.html();
        
        $btn.html('<i class="ti ti-loader ti-spin text-lg"></i> Submitting...').prop('disabled', true);

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                if (response.status === 'success') {
                    toastr.success(response.message);
                    $('#updatePaymentMethodForm')[0].reset();
                    loadPaymentMethodDetails();
                } else {
                    toastr.error(response.message || 'An error occurred');
                }
            },
            error: function(xhr) {
                $btn.html(originalText).prop('disabled', false);
                let msg = 'Failed to communicate with server';
                try {
                    let res = JSON.parse(xhr.responseText);
                    if (res && res.message) msg = res.message;
                } catch(e) {}
                toastr.error(msg);
            }
        });
    });
});
</script>
<?php endSection(); ?>
