<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <style>
        #bomSettingsAddModal .modal-content {
            display: flex;
            flex-direction: column;
            max-height: calc(100dvh - 2rem);
        }

        #bomSettingsAddModal .modal-header,
        #addBomForm > .flex {
            flex: 0 0 auto;
        }

        #addBomForm {
            display: flex;
            flex: 1 1 auto;
            flex-direction: column;
            min-height: 0;
        }

        #bomSettingsAddModal .modal-body {
            min-height: 0;
            overflow-x: hidden;
            overflow-y: auto;
        }

        #bomSettingsAddModal .select2-container--open {
            z-index: 1095;
        }

    </style>
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage BOM settings</p>
        </div>
    </div>

    <div class="w-full mb-6">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageBomSettings" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="bomSettingsPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="bom-settings-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="bom-settings-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="bom-settings-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="bom-settings-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="bom-settings-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="bom-settings-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <!-- Search Bar -->
                    <div class="relative h-10 w-full max-w-[220px]">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchInstitutions"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <div class="flex-grow"></div>

                    <?php if (canDoThis('store_settings_bom_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#bomSettingsAddModal" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="px-6 py-3">BOM Name</th>
                            <th class="px-6 py-3">Product Name</th>
                            <th class="px-6 py-3">Category</th>
                            <th class="px-6 py-3">BOM Type</th>
                            <th class="px-6 py-3">Description</th>
                            <th class="px-6 py-3">Status</th>
                            <th class="px-6 py-3">Approval Status</th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600" id="institutionsTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelectInstitutions + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapperInstitutions', 'paginationSummaryInstitutions', 'footerPerPageSelectInstitutions') ?>
        </div>
    </div>


    <div class="modal fade animate__animated fadeIn" id="bomSettingsAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add BOM</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create new BOM entry</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addBomForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="bomName" class="mb-1 block text-sm font-medium text-slate-800">BOM Name
                                    <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="bomName" autocomplete="off" placeholder="BOM Name" name="bomName"
                                    class="input-theme" required>
                            </div>
                            <div>
                                <label for="productCategory"
                                    class="mb-1 block text-sm font-medium text-slate-800">Product Category <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="productCategory" autocomplete="off" name="productCategoryId"
                                    class="input-theme select2" required></select>
                            </div>
                            <div>
                                <label for="finishedGood" class="mb-1 block text-sm font-medium text-slate-800">Finished
                                    Good <strong class="text-rose-500">*</strong></label>
                                <select id="finishedGood" autocomplete="off" name="finishedGoodId"
                                    class="input-theme select2" required></select>
                            </div>
                        </div>
                        <div class="mb-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                            <label class="mb-2 block text-sm font-bold text-slate-800">Raw Products Details</label>
                            <div id="productsWrapperWhole" class="mb-2"></div>
                            <button type="button"
                                class="inline-flex h-9 items-center justify-center gap-2 !rounded-xl bg-emerald-50 px-4 text-sm font-bold text-emerald-700 shadow-sm ring-1 ring-emerald-600/20 transition-colors hover:bg-emerald-100 hover:text-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                id="addProductBtn">
                                <i class="ti ti-plus text-base"></i> Add Product
                            </button>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                            <div>
                                <label for="bomType" class="mb-1 block text-sm font-medium text-slate-800">Bom Type
                                    <strong class="text-rose-500">*</strong></label>
                                <select id="bomType" autocomplete="off" name="bomType" class="input-theme select2"
                                    required>
                                    <?php
                                    if (!empty(Constant::STOCKS['BOM_TYPES'])) {
                                        echo '<option value="">----Select----</option>';
                                        foreach (Constant::STOCKS['BOM_TYPES'] as $tdkey => $tdval) {
                                            echo '<option value="' . $tdkey . '">' . $tdval['label'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="md:col-span-2">
                                <label for="bomDescription"
                                    class="mb-1 block text-sm font-medium text-slate-800">Description</label>
                                <textarea id="bomDescription" autocomplete="off" name="bomDescription"
                                    class="input-theme" placeholder="Enter Description" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 gap-3">
                            <div>
                                <label class="mb-1 block text-sm font-medium text-slate-800">Status <strong
                                        class="text-rose-500">*</strong></label>
                                <div class="flex gap-4 mt-2">
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="activStatusBom" name="bomStatus" value="1"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                            required />
                                        Active
                                    </label>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                                        <input type="radio" id="inactiveStatusBom" name="bomStatus" value="0"
                                            class="h-4 w-4 border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="editBomSettingsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit BOM</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update BOM entry</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editBomSettingsForm">
                    <div class="modal-body">
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;
    let currentDesignPage = 1;
    let productIndex = 0;
    let qtyUnitOptions = [];
    let categoryOptions = [];

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            },
            success: function (response) {
                qtyUnitOptions = response;
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadProductCategoryList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getProductCategoryList: 'getProductCategoryList'
            },
            success: function (response) {
                categoryOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                categoryOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#productCategory").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadBomSettingsTable(page = 1) {
        currentDesignPage = page;
        const search = $('#searchInstitutions').val().trim();
        const perPage = $('#perPageBomSettings').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadBomTableRecords: 'loadBomTableRecords',
                page: page,
                per_page: perPage,
                search: search
            },
            dataType: 'json',
            success: function (response) {
                $('#institutionsTableBody').html(response.table || '');
                $('#paginationWrapperInstitutions').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryInstitutions', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectInstitutions');

                if (response && response.totalRows !== undefined) {
                    const totalRows = Number(response.totalRows);
                    const perPage = Number($('#perPageBomSettings').val() || 10);
                    const shownThrough = Math.min(currentPage * perPage, totalRows);
                    const startRow = totalRows === 0 ? 0 : ((currentPage - 1) * perPage) + 1;

                } else {

                }
            },
            error: function () {
                $('#institutionsTableBody').html('<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperInstitutions').html('');
            }
        });
    }

    function initBomAddSelect2($element, options = {}) {
        $element.each(function() {
            const $select = $(this);
            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }
            $select.select2($.extend({
                dropdownParent: $('#bomSettingsAddModal'),
                width: '100%'
            }, options));
        });
    }

    function constrainBomAddSelect2Dropdown($select) {
        const $dropdown = $('#bomSettingsAddModal .select2-container--open .select2-dropdown');
        const $results = $dropdown.find('.select2-results__options');
        const $modalContent = $('#bomSettingsAddModal .modal-content');
        const $modalFooter = $('#addBomForm > .flex').last();
        const $selectionContainer = $select.next('.select2-container');

        if (!$dropdown.length || !$results.length || !$modalContent.length || !$selectionContainer.length) return;

        const selectionRect = $selectionContainer[0].getBoundingClientRect();
        const modalRect = $modalContent[0].getBoundingClientRect();
        const footerTop = $modalFooter.length
            ? $modalFooter[0].getBoundingClientRect().top
            : modalRect.bottom;
        const availableBelow = Math.max(0, footerTop - selectionRect.bottom - 8);
        const availableAbove = Math.max(0, selectionRect.top - modalRect.top - 8);
        const openAbove = availableBelow < 190 && availableAbove > availableBelow;
        const availableHeight = openAbove ? availableAbove : availableBelow;
        const dropdownChromeHeight = Math.max(0, $dropdown.outerHeight() - $results.outerHeight());
        const resultsHeight = Math.max(72, Math.min(220, availableHeight - dropdownChromeHeight));

        $results.css('max-height', resultsHeight + 'px');

        const $dropdownContainer = $dropdown.closest('.select2-container--open');
        const dropdownRect = $dropdown[0].getBoundingClientRect();
        const containerTop = parseFloat($dropdownContainer.css('top')) || 0;
        const targetTop = openAbove
            ? selectionRect.top - $dropdown.outerHeight() - 4
            : selectionRect.bottom + 4;

        $dropdownContainer.css('top', (containerTop + targetTop - dropdownRect.top) + 'px');
        $dropdown
            .toggleClass('select2-dropdown--above', openAbove)
            .toggleClass('select2-dropdown--below', !openAbove);
        $selectionContainer
            .toggleClass('select2-container--above', openAbove)
            .toggleClass('select2-container--below', !openAbove);
    }

    function bindBomAddSelect2Scroll($select) {
        setTimeout(function() {
            constrainBomAddSelect2Dropdown($select);
            $('#bomSettingsAddModal .select2-container--open .select2-dropdown')
                .off('wheel.bomAddModalScroll')
                .on('wheel.bomAddModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $('#bomSettingsAddModal .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $('#bomSettingsAddModal .select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    $(document).ready(function () {
        $('#bomSettingsAddModal').on('hidden.bs.modal', function () {
            $('#addBomForm')[0].reset();
            $('#productsWrapperWhole').empty();
            $('#addBomForm .select2').val(null).trigger('change');
            productIndex = 0;
        });
        $('#bomSettingsAddModal').on('show.bs.modal', function () {
            if ($('#productsWrapperWhole .product-entry').length === 0) {
                $('#addProductBtn').trigger('click');
            }
        });
        // Re-initialize select2 with correct dropdownParent to prevent cut-off issues
        initBomAddSelect2($('#bomSettingsAddModal .select2'), {
            placeholder: 'Select Option'
        });
        $(document).on('select2:open', function(e) {
            if (!$(e.target).closest('#bomSettingsAddModal').length) return;
            bindBomAddSelect2Scroll($(e.target));
        });
        $('#bomSettingsAddModal .modal-body').on('scroll', function() {
            $('#bomSettingsAddModal .select2-hidden-accessible').select2('close');
        });

        loadStandardUnit();
        loadProductCategoryList();
        loadBomSettingsTable();
        $('#searchInstitutions').on('input', function () {
            loadBomSettingsTable(1);
        });
        $('#perPageBomSettings').on('change', function () {
            loadBomSettingsTable(1);
        });
        $('#footerPerPageSelectInstitutions').on('change', function () {
            $('#perPageBomSettings').val($(this).val());
            loadBomSettingsTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.bom-settings-per-page-item', function () {
            const val = $(this).data('val');
            $('#bomSettingsPerPageText').text($(this).text());
            $('#footerPerPageSelectInstitutions').val(val).trigger('change');
        });

        $('#productCategory').on('change', function () {
            let categoryId = $(this).val();

            if (!categoryId) {
                $('#finishedGood').html('<option value="">----Select----</option>');
                return;
            }

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    getAllProductListByCategory: 'getAllProductListByCategory',
                    category_id: categoryId
                },
                success: function (response) {
                    let prodHtml = '<option value="">----Select----</option>';
                    response.forEach(prod => {
                        prodHtml += `<option value="${prod.id}">${prod.product_name}</option>`;
                    });
                    $('#finishedGood').html(prodHtml);
                }
            });
        });

        $('#addProductBtn').click(function () {
            let qtyUnitHtml = '<option value="">----Select----</option>';
            qtyUnitOptions.forEach(unit => {
                qtyUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
            });

            const productBlock = `
            <div class="grid grid-cols-1 md:grid-cols-12 gap-3 product-entry mb-3" data-index="${productIndex}">
                <div class="md:col-span-3">
                    <label class="mb-1 block text-xs font-medium text-slate-800">Raw Category <strong class="text-rose-500">*</strong></label>
                    <select name="rawMaterialCategoryList[]" class="select2 input-theme rawMaterialCategoryList" data-allow-clear="true" required>
                        <option value="">----Select Option----</option>
                    </select>
                </div>
                <div class="md:col-span-4">
                    <label class="mb-1 block text-xs font-medium text-slate-800">Raw Product <strong class="text-rose-500">*</strong></label>
                    <input type="text" name="rawProductsList[]" class="input-theme rawProductsInput" placeholder="Enter Raw Product Name" autocomplete="off" required />
                </div>               
                <div class="md:col-span-2">
                    <label class="mb-1 block text-xs font-medium text-slate-800">Quantity <strong class="text-rose-500">*</strong></label>
                    <input type="number" step="any" min="0" name="rawProdQuantity[]" class="input-theme" placeholder="Enter Quantity" required />
                </div>
                <div class="md:col-span-2">
                    <label class="mb-1 block text-xs font-medium text-slate-800">Quantity Unit <strong class="text-rose-500">*</strong></label>
                    <select name="rawProdQuantityUnit[]" class="input-theme select2" required>
                        ${qtyUnitHtml}
                    </select>
                </div>   
                <div class="md:col-span-1 flex items-end">
                    <button type="button" class="inline-flex h-10 w-10 items-center justify-center !rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-600/20 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30 removeProductBtn"><i class="ti ti-trash text-lg"></i></button>               
                </div>
            </div>`;

            $('#productsWrapperWhole').append(productBlock);

            // Initialize Select2 on new fields
            const $newRow = $(`.product-entry[data-index="${productIndex}"]`);
            initBomAddSelect2($newRow.find('.select2'), {
                placeholder: '----Select Option----'
            });

            // Load material types in the new block
            const $newMaterialSelect = $newRow.find('.rawMaterialCategoryList');
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    loadProductCategoryStockOutwardOption: 'loadProductCategoryStockOutwardOption'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (item) {
                        html += `<option value="${item.key}">${item.value}</option>`;
                    });
                    $newMaterialSelect.html(html).trigger('change');
                }
            });

            productIndex++;
        });

        $('#addBomForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addBomForm');
            const formData = new FormData(form);
            formData.append('addBomSettings', 'addBomSettings');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#bomSettingsAddModal').modal('hide');
                        $('#addBomForm')[0].reset();
                        loadBomSettingsTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });


    });

    $(document).on('click', '.removeProductBtn', function () {
        $(this).closest('.product-entry').remove();
    });


    $(document).on('click', '.deleteBomSettingBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteBomSettingRecord: 'deleteBomSettingRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadBomSettingsTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editBomSettingModelBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editBomSettingsForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchBomSettingRecord: 'fetchBomSettingRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editBomSettingsModal').modal('show');
                        $('#editBomSettingsForm').find('.modal-body').html(res.data);
                        $('#editBomSettingsForm .select2').select2({
                            dropdownParent: $('#editBomSettingsModal')
                        });
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '.viewBomItemsBtn', function () {
        let btn = $(this);
        let bomId = btn.data('id');

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'html',
            data: {
                loadBomItemsPopover: 'loadBomItemsPopover',
                bom_id: bomId
            },
            success: function (html) {
                let pop = bootstrap.Popover.getInstance(btn[0]);
                if (pop) pop.dispose();
                new bootstrap.Popover(btn[0], {
                    content: html,
                    html: true,
                    container: 'body',
                    placement: 'right',
                    trigger: 'focus',
                    sanitize: false
                }).show();
            }
        });
    });

    $(document).on('click', '#addProductBtnEdit', function () {
        let qtyUnitHtml = '<option value="">----Select----</option>';
        qtyUnitOptions.forEach(unit => {
            qtyUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });

        const productBlock = `
        <div class="row product-entry mb-2 border rounded p-2" data-index="${productIndex}">
            <div class="col-md-3 mb-2">
                <label class="mb-1 block text-sm font-medium text-slate-800">Raw Category <strong class="text-rose-500">*</strong></label>
                <input type="hidden" name="subItemIdEdit[]" value="" />
                <select name="rawMaterialCategoryListEdit[]" class="select2 input-theme rawMaterialCategoryListEdit" data-allow-clear="true" required>
                    <option value="">----Select Option----</option>
                </select>
            </div>
            <div class="col-md-4 mb-2">
                <label class="mb-1 block text-sm font-medium text-slate-800">Raw Material / Product <strong class="text-rose-500">*</strong></label>
                <input type="text" name="rawProductsListEdit[]" class="input-theme rawProductsInputEdit" placeholder="Enter Raw Material Name" autocomplete="off" required />
            </div>               
            <div class="col-md-2 mb-2">
                <label class="mb-1 block text-sm font-medium text-slate-800">Quantity <strong class="text-rose-500">*</strong></label>
                <input type="number" step="any" min="0" name="rawProdQuantityEdit[]" class="input-theme" placeholder="Enter Quantity" required />
            </div>
            <div class="col-md-2 mb-2">
                <label class="mb-1 block text-sm font-medium text-slate-800">Quantity Unit <strong class="text-rose-500">*</strong></label>
                <select name="rawProdQuantityUnitEdit[]" class="input-theme select2" required>
                    ${qtyUnitHtml}
                </select>
            </div>   
            <div class="col-md-1 mb-2 d-flex align-items-end">
                <button type="button" class="btn btn-icon btn-label-danger removeProductBtnEdit"><span class="ti ti-trash"></span></button>               
            </div>
        </div>`;

        $('#productsWrapperWholeEdit').append(productBlock);

        // Initialize Select2 on new fields
        $('#productsWrapperWholeEdit .select2').select2({
            placeholder: '----Select Option----',
            dropdownParent: $('#editBomSettingsModal')
        });

        // Load material types in the new block
        const $newMaterialSelect = $(`.product-entry[data-index="${productIndex}"] .rawMaterialCategoryListEdit`);
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadProductCategoryStockOutwardOption: 'loadProductCategoryStockOutwardOption'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (item) {
                    html += `<option value="${item.key}">${item.value}</option>`;
                });
                $newMaterialSelect.html(html).trigger('change');
            }
        });

        productIndex++;
    });

    $(document).on('click', '.removeProductBtnEdit', function () {
        let id = $(this).data('id');
        let buttonClicked = $(this);

        if (!id) {
            buttonClicked.closest('.product-entry').remove();
            // Swal.fire({
            //     icon: 'error',
            //     title: 'Invalid ID',
            //     text: 'Invalid user ID provided.',
            //     customClass: {
            //         container: 'swal2-zindex-fix-custom',
            //         confirmButton: 'btn btn-danger waves-effect waves-light'
            //     }
            // });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteSubItemBomSettingRecord: 'deleteSubItemBomSettingRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            buttonClicked.closest('.product-entry').remove();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    container: 'swal2-zindex-fix-custom',
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                container: 'swal2-zindex-fix-custom',
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('change', '#editProductCategory', function () {
        let categoryId = $(this).val();

        if (!categoryId) {
            $('#editFinishedGood').html('<option value="">----Select----</option>');
            return;
        }

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getAllProductListByCategory: 'getAllProductListByCategory',
                category_id: categoryId
            },
            success: function (response) {
                let prodHtml = '<option value="">----Select----</option>';
                response.forEach(prod => {
                    prodHtml += `<option value="${prod.id}">${prod.product_name}</option>`;
                });
                $('#editFinishedGood').html(prodHtml);
            }
        });
    });

    $('#editBomSettingsForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editBomSettingsForm');
        const formData = new FormData(form);
        formData.append('updateBomSettingRecords', 'updateBomSettingRecords');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editBomSettingsModal').modal('hide');
                    $('#editBomSettingsForm').find('modal-body').html();
                    loadBomSettingsTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });




    $(document).on('change', '#perPageSelectInstitutions', function () { loadStandardUnit(1); });
</script>
<?php endSection(); ?>
