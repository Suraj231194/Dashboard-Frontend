<div class="container-xxl flex-grow-1 container-p-y">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?></h1>
        </div>
    </div>

    <div class="flex flex-col md:flex-row gap-4 lg:gap-6 w-full app-calendar-wrapper items-start">
        <!-- Calendar Sidebar -->
        <div class="w-full md:w-56 lg:w-64 shrink-0 app-calendar-sidebar" id="app-calendar-sidebar">
            <div
                class="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden md:sticky md:top-6 h-fit">
                <!-- Add Event Button -->
                <div class="p-4 border-b border-slate-100 bg-slate-50/70">
                    <button
                        class="w-full inline-flex h-11 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 btn-toggle-sidebar"
                        data-bs-toggle="offcanvas" data-bs-target="#addEventSidebar" aria-controls="addEventSidebar">
                        <i class="ti ti-plus text-lg"></i>
                        <span>Add Event</span>
                    </button>
                </div>
                <!-- Filters -->
                <div class="p-5">
                    <h6 class="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">Filter</h6>
                    <label
                        class="flex cursor-pointer items-center gap-3 mb-3 text-sm font-semibold text-slate-700 hover:text-emerald-700 transition-colors">
                        <input
                            class="h-5 w-5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500/30 select-all"
                            type="checkbox" id="selectAll" data-value="all" checked />
                        <span>View All</span>
                    </label>

                    <div class="flex flex-col gap-3 app-calendar-events-filter mt-4">
                        <?php if (!empty(Constant::CALENDER['EVENT_TYPE'])) {
                            foreach (Constant::CALENDER['EVENT_TYPE'] as $calKey => $calVal) {
                                $colorClass = 'text-slate-600';
                                $ringClass = 'focus:ring-slate-500/30';
                                if ($calVal['data-label'] == 'success') {
                                    $colorClass = 'text-emerald-600';
                                    $ringClass = 'focus:ring-emerald-500/30';
                                } else if ($calVal['data-label'] == 'info') {
                                    $colorClass = 'text-cyan-600';
                                    $ringClass = 'focus:ring-cyan-500/30';
                                } else if ($calVal['data-label'] == 'danger') {
                                    $colorClass = 'text-rose-600';
                                    $ringClass = 'focus:ring-rose-500/30';
                                } else if ($calVal['data-label'] == 'warning') {
                                    $colorClass = 'text-amber-500';
                                    $ringClass = 'focus:ring-amber-500/30';
                                }
                                ?>
                                <label
                                    class="flex cursor-pointer items-center gap-3 text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors form-check-<?= $calVal['data-label']; ?>">
                                    <input
                                        class="h-5 w-5 rounded border-slate-300 <?= $colorClass ?> <?= $ringClass ?> input-filter"
                                        type="checkbox" id="select-<?= $calVal['data-value']; ?>"
                                        data-value="<?= $calVal['data-value']; ?>" value="<?= $calKey; ?>" checked />
                                    <span><?= $calVal['label']; ?></span>
                                </label>
                            <?php }
                        } ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Calendar Sidebar -->

        <!-- Calendar Content -->
        <div class="w-full flex-grow app-calendar-content min-w-0">
            <div class="rounded-2xl border border-slate-200 bg-white shadow-sm p-4 w-full min-w-0 h-fit">
                <div id="calendar" class="w-full min-w-0"></div>
            </div>
            <div class="app-overlay"></div>
            <div class="offcanvas offcanvas-end event-sidebar" tabindex="-1" id="addEventSidebar"
                aria-labelledby="addEventSidebarLabel">
                <div class="offcanvas-header my-1 border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-calendar-event text-xl"></i>
                        </span>
                        <div>
                            <h5 class="offcanvas-title m-0 text-lg font-bold text-slate-900" id="addEventSidebarLabel">
                                Event Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Manage calendar event</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="offcanvas" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="offcanvas-body pt-4">
                    <form class="event-form" id="calenderEventForm" onsubmit="return false">
                        <input type="hidden" id="eventId" name="eventId">
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800"
                                for="employeeList">Employee</label>
                            <select class="input-theme select2 select-event-label form-select" id="employeeList"
                                name="employeeList" placeholder="Event Title"></select>
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800" for="eventTitle">Title</label>
                            <input type="text" class="input-theme" id="eventTitle" name="eventTitle"
                                placeholder="Event Title" />
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800" for="eventLabel">Label</label>
                            <select class="input-theme select2 select-event-label form-select" id="eventLabel"
                                name="eventLabel" required>
                                <?php if (!empty(Constant::CALENDER['EVENT_TYPE'])) { ?>
                                    <option data-label="" value="">----Select----</option>
                                    <?php
                                    foreach (Constant::CALENDER['EVENT_TYPE'] as $calKey => $calVal) { ?>
                                        <option data-label="<?= $calVal['data-label']; ?>" value="<?= $calKey; ?>">
                                            <?= $calVal['label']; ?></option>
                                    <?php }
                                } ?>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800" for="eventStartDate">Start
                                Date</label>
                            <input type="date" class="input-theme" id="eventStartDate" name="eventStartDate"
                                placeholder="Start Date" required />
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800" for="eventEndDate">End
                                Date</label>
                            <input type="date" class="input-theme" id="eventEndDate" name="eventEndDate"
                                placeholder="End Date" />
                        </div>
                        <div class="mb-4">
                            <label class="switch flex items-center gap-2 cursor-pointer">
                                <input type="checkbox"
                                    class="h-5 w-5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500/30 switch-input"
                                    id="allDaySwitch" value="1" name="eventAllDay" checked>
                                <span class="text-sm font-medium text-slate-800 switch-label">All Day</span>
                            </label>
                        </div>
                        <div class="mb-4">
                            <label class="switch flex items-center gap-2 cursor-pointer">
                                <input type="checkbox"
                                    class="h-5 w-5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500/30 switch-input"
                                    id="reminderEnable" value="1" name="reminderEnable">
                                <span class="text-sm font-medium text-slate-800 switch-label">Notify me when this event is due</span>
                            </label>
                            <p class="mb-0 mt-1 text-xs text-slate-500">Timed reminders are delivered at the start time; all-day reminders are delivered on the event date.</p>
                        </div>

                        <div class="mb-4 time-fields d-none">
                            <label class="mb-1 block text-sm font-medium text-slate-800">Time</label>
                            <div class="flex gap-2">
                                <input type="time" class="input-theme time-fields-inputs" name="start_time"
                                    id="start_time" />
                                <input type="time" class="input-theme time-fields-inputs" name="end_time"
                                    id="end_time" />
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800"
                                for="eventLocation">Location</label>
                            <input type="text" class="input-theme" id="eventLocation" name="eventLocation"
                                placeholder="Enter Location" />
                        </div>
                        <div class="mb-4">
                            <label class="mb-1 block text-sm font-medium text-slate-800"
                                for="eventDescription">Description</label>
                            <textarea class="input-theme min-h-[100px]" name="eventDescription"
                                id="eventDescription"></textarea>
                        </div>
                        <div
                            class="flex flex-col-reverse sm:flex-row sm:justify-between gap-3 mt-6 pt-4 border-t border-slate-100">
                            <div class="flex gap-2 w-full sm:w-auto">
                                <button type="submit"
                                    class="inline-flex h-11 flex-grow sm:flex-grow-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 btn-add-event">Add</button>
                                <button type="reset"
                                    class="inline-flex h-11 flex-grow sm:flex-grow-0 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60 btn-cancel"
                                    data-bs-dismiss="offcanvas">
                                    Cancel
                                </button>
                            </div>
                            <button
                                class="inline-flex h-11 w-full sm:w-auto items-center justify-center !rounded-xl bg-rose-50 px-5 text-sm font-bold text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30 btn-delete-event d-none">Delete</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- /Calendar & Modal -->
    </div>
</div>

<style>
    /* Make FullCalendar toolbar responsive */
    .fc .fc-toolbar {
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-bottom: 1rem !important;
    }

    .fc .fc-button-group {
        flex-wrap: wrap;
    }

    .fc .fc-toolbar-title {
        font-size: 1.25rem !important;
    }

    @media (max-width: 768px) {
        .fc .fc-toolbar-chunk {
            display: flex;
            justify-content: center;
            width: 100%;
            margin-bottom: 0.5rem;
        }
    }
</style>

<?php startSection('scripts'); ?>
<script src="<?= asset('assets/js/fullCalenderIndex.global.min.js') ?>"></script>
<script>
    let calendar;

    // function loadEmployeesList() {
    //     $.ajax({
    //         url: 'ajax.php',
    //         method: 'POST',
    //         dataType: 'json',
    //         data: {
    //             loadEmployeesListOption: 'loadEmployeesListOption'
    //         },
    //         success: function(response) {
    //             departmentOptions = response;
    //             let optionsHtml = '<option value="">---Select----</option>';
    //             departmentOptions.forEach(emp => {
    //                 optionsHtml += `<option value="${emp.id}">(${emp.emp_code}) ${emp.first_name} ${emp.last_name}</option>`;
    //             });
    //             $("#employeeList").html(optionsHtml);
    //         },
    //         error: function(xhr, status, error) {
    //             console.error("Failed to load employees:", error);
    //         }
    //     });
    // }

    function loadEmployeesList() {
        return $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: { loadEmployeesListOption: 'loadEmployeesListOption' }
        }).then(function (response) {
            let optionsHtml = '<option value="">---Select----</option>';
            response.forEach(emp => {
                optionsHtml += `<option value="${emp.id}">
                (${emp.emp_code}) ${emp.first_name} ${emp.last_name}
                </option>`;
            });
            $("#employeeList").html(optionsHtml);
        });
    }


    function loadEmployeeEvents(startDate, endDate, successCallback, failureCallback) {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                loadCalenderEvents: 'loadCalenderEvents',
                start: startDate,
                end: endDate
            },
            success: function (res) {
                successCallback(res);
            },
            error: function (xhr, status, error) {
                failureCallback(error);
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        const calendarEl = document.getElementById('calendar');
        calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            height: 'auto',
            contentHeight: 'auto',

            headerToolbar: {
                left: 'prev,next',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
            },
            events: function (fetchInfo, successCallback, failureCallback) {
                loadEmployeeEvents(
                    fetchInfo.startStr,
                    fetchInfo.endStr,
                    successCallback,
                    failureCallback
                );
            },
            eventClick: function (info) {
                const event = info.event;
                loadEmployeesList().then(() => {
                    $('#employeeList')
                        .val(event.extendedProps.employee_id)
                        .trigger('change');
                });
                $('#eventId').val(event.id);
                $('#employeeList').val(event.extendedProps.employee_id).trigger('change');
                $('#eventTitle').val(event.title);
                $('#eventLabel').val(event.extendedProps.event_type).trigger('change');

                const isAllDay = event.allDay;

                $('#allDaySwitch').prop('checked', isAllDay).trigger('change');


                if (isAllDay) {
                    // date only
                    $('#eventStartDate').val(event.startStr.substring(0, 10));
                    $('#eventEndDate').val(event.startStr.substring(0, 10));

                } else {
                    // date + time
                    const start = event.start;
                    const end = event.end;

                    $('#eventStartDate').val(start.toISOString().substring(0, 10));
                    $('#eventEndDate').val(end.toISOString().substring(0, 10));

                    $('#start_time').val(start.toTimeString().substring(0, 5));
                    $('#end_time').val(end.toTimeString().substring(0, 5));
                }

                $('#eventLocation').val(event.extendedProps.location);
                $('#eventDescription').val(event.extendedProps.remarks);
                $('#reminderEnable').prop('checked', Number(event.extendedProps.is_reminder_enabled || 0) === 1);

                $('.btn-add-event').text('Update');
                $('.btn-delete-event').removeClass('d-none');

                new bootstrap.Offcanvas('#addEventSidebar').show();
            },
            eventDidMount: function (info) {
                const selectedTypes = getSelectedEventTypes();

                if (!selectedTypes.includes(info.event.extendedProps.event_type)) {
                    info.el.style.display = 'none';
                }
            }

        });
        calendar.render();
    });

    function getSelectedEventTypes() {
        let types = [];
        $('.input-filter:checked').each(function () {
            types.push($(this).val());
        });
        return types;
    }


    $(document).ready(function () {
        loadEmployeesList();

        $('#calenderEventForm').on('submit', function (e) {
            e.preventDefault();

            let eventId = $('#eventId').val();
            let action = eventId ? 'updateCalenderEvent' : 'addCalenderEvent';
            const offcanvasEl = document.getElementById('addEventSidebar');
            allDaySwitch = document.querySelector('.allDay-switch');

            const formData = new FormData(this);
            formData.append(action, action);

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        calendar.refetchEvents();
                        $('#calenderEventForm')[0].reset();
                        $('.select2').val(null).trigger('change');
                        $('#allDaySwitch').prop('checked', true).trigger('change');
                        $('#reminderEnable').prop('checked', false);
                        $('#eventId').val('');
                        $('.btn-add-event').text('Add');
                        $('.btn-delete-event').addClass('d-none');
                        bootstrap.Offcanvas.getInstance(offcanvasEl).hide();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }
            });
        });

        $('.btn-delete-event').on('click', function () {
            let eventId = $('#eventId').val();
            if (!eventId) return;
            const offcanvasEDel = document.getElementById('addEventSidebar');

            if (!confirm('Delete this event?')) return;

            $.post('ajax.php', {
                deleteCalenderEvent: 'deleteCalenderEvent',
                eventId: eventId
            }, function (res) {
                if (res.status === 'success') {
                    calendar.refetchEvents();
                    bootstrap.Offcanvas.getInstance(offcanvasEDel).hide();
                    toastr.success(res.message);
                } else {
                    toastr.error(res.message);
                }
            }, 'json');
        });

        $('#allDaySwitch').on('change', function () {

            if (this.checked) {
                $('.time-fields').addClass('d-none');
                $('#eventEndDate').val($('#eventStartDate').val());
                $('.time-fields-inputs').attr('required', false);
                $('.time-fields-inputs').val('');

            } else {
                $('.time-fields').removeClass('d-none');
                $('.time-fields-inputs').attr('required', true);
            }
        });

        $('.input-filter').on('change', function () {
            calendar.refetchEvents();
        });

        $('#selectAll').on('change', function () {
            $('.input-filter').prop('checked', this.checked);
            calendar.refetchEvents();
        });
    });

</script>
<?php endSection(); ?>
