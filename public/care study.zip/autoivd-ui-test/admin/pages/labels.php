<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage label sizes and designs</p>
        </div>
    </div>
    <div class="w-full mb-6">
        <div class="accordion mt-3 flex flex-col gap-4" id="collapsibleSection">
            <div
                class="accordion-item overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-shadow hover:shadow-md">
                <h2 class="accordion-header m-0">
                    <button type="button"
                        class="group flex w-full items-center justify-between bg-white px-6 py-4 text-left text-[16px] font-bold text-slate-800 transition-colors hover:bg-slate-50 focus:outline-none border-b border-slate-100"
                        onclick="$('#collapseLabelSizesOptions').slideToggle(300); $(this).find('.chevron').toggleClass('rotate-180');">
                        <span>Label Size Configuration</span>
                        <span
                            class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors group-hover:bg-slate-200"><i
                                class="ti ti-chevron-down chevron transition-transform duration-300 text-lg"></i></span>
                    </button>
                </h2>
                <div id="collapseLabelSizesOptions" style="display:none;">
                    <div class="border-t border-slate-200 p-0">
                        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                            <div
                                class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                                <input type="hidden" id="perPageSelect" value="10">
                                <div class="dropdown shrink-0">
                                    <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                                        <span id="labelSizePerPageText" class="whitespace-nowrap">10 items</span>
                                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                    </button>
                                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                        <li><a class="label-size-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                        <li><a class="label-size-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                        <li><a class="label-size-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                        <li><a class="label-size-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                        <li><a class="label-size-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                        <li><a class="label-size-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                    </ul>
                                </div>

                                <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <i class="ti ti-search text-lg text-slate-400"></i>
                                    </div>
                                    <input type="text" id="searchLabelSize"
                                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                                        placeholder="Search Data...">
                                </div>

                                <?php // if (roleHasPermission($_SESSION['role_id'], 'roles_add')) { ?>
                                <button type="button" class="biogenix-nav-btn-dashboard shadow-sm"
                                    data-bs-toggle="modal" data-bs-target="#labelSizeAddModal">
                                    <i class="ti ti-plus text-lg"></i> Add New
                                </button>
                                <?php //} ?>
                            </div>
                        </div>

                        <div class="overflow-x-auto border-t border-slate-200 w-full">
                            <table class="w-full table-auto text-left text-sm text-slate-600">
                                <thead
                                    class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                    <tr>
                                        <th class="w-16 px-6 py-3">#</th>
                                        <th class="sortable w-48 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                            data-column="name" data-order="ASC">
                                            <span class="inline-flex items-center gap-1">Name <i
                                                    class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                                        </th>
                                        <th class="sortable w-40 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                            data-column="size" data-order="ASC">
                                            <span class="inline-flex items-center gap-1">Size (h*w) <i
                                                    class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                                        </th>
                                        <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                            data-column="status" data-order="ASC">
                                            <span class="inline-flex items-center gap-1">Status <i
                                                    class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                                        </th>
                                        <th class="w-36 px-6 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                                    id="labelSizeTableBody">
                                </tbody>
                            </table>
                        </div>
                        <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
                        <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="w-full mb-6">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageDropdown" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="labelDesignPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="label-design-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="label-design-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="label-design-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="label-design-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="label-design-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="label-design-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchLabelsDeisgn"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php // if (roleHasPermission($_SESSION['role_id'], 'roles_add')) { ?>
                    <button type="button" id="designLabelAddModalBtn" class="biogenix-nav-btn-dashboard shadow-sm">
                        <i class="ti ti-plus text-lg"></i> Add New
                    </button>
                    <?php // } ?>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-16 px-6 py-3">#</th>
                            <th class="sortable w-48 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="name" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="status" data-order="ASC">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="labelDesignListTableBody">
                    </tbody>
                </table>
            </div>
            <style>#footerPerPageSelectLableDesignList + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapperLableDesignList', 'paginationSummaryLableDesignList', 'footerPerPageSelectLableDesignList') ?>
        </div>
    </div>

    <div class="modal fade" id="labelSizeAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Label Size</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="addLabelSizeForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="labelSizeName"
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Name
                                    <strong class="text-danger">*</strong></label>
                                <input type="text" id="labelSizeName" autocomplete="off" name="labelSizeName"
                                    class="form-control !rounded-xl border-slate-200" placeholder="Enter Name"
                                    required />
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="widthMm"
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Width
                                    (mm) <strong class="text-danger">*</strong></label>
                                <input type="number" id="widthMm" min="0" autocomplete="off" name="widthMm"
                                    class="form-control !rounded-xl border-slate-200" placeholder="Enter Width (mm)"
                                    required />
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="heightMm"
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Height
                                    (mm) <strong class="text-danger">*</strong></label>
                                <input type="number" id="heightMm" min="0" autocomplete="off" name="heightMm"
                                    class="form-control !rounded-xl border-slate-200" placeholder="Enter Height (mm)"
                                    required />
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col">
                                <div class="form-check form-check-inline mt-1">
                                    <input class="form-check-input" type="checkbox" id="withLogo" name="withLogo"
                                        value="1" />
                                    <label class="form-check-label font-medium text-slate-700" for="withLogo">With Logo
                                        ?</label>
                                </div>
                            </div>
                            <div class="col">
                                <small
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Status
                                    <strong class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatus" name="labelStatus"
                                        value="1" required />
                                    <label class="form-check-label font-medium text-slate-700"
                                        for="activStatus">Active</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="inactiveStatus" name="labelStatus"
                                        value="0" />
                                    <label class="form-check-label font-medium text-slate-700"
                                        for="inactiveStatus">Inactive</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 items-center justify-center gap-2 border border-slate-200 bg-white px-5 text-sm font-bold text-slate-600 transition-colors hover:bg-slate-50"
                            style="border-radius: 0.75rem !important;"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editLabelSizeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Label Size</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="editLabelSizeForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="designLabelAddModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-brush text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">New Label Design</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="designLabelAddForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                        <div class="row border border-slate-200 rounded-xl shadow-sm p-4 mb-4 bg-white mx-0">
                            <div class="col-md-12 d-flex justify-content-center">
                                <div id="labelPreview" class="label-preview-surface shadow-sm border border-slate-200">
                                </div>
                            </div>
                        </div>
                        <div class="row mx-0">
                            <div class="col-md-4 mb-4 px-2">
                                <label for="labelName"
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Name
                                    <strong class="text-danger">*</strong></label>
                                <input type="text" name="labelName" id="labelName" autocomplete="off"
                                    class="form-control !rounded-xl border-slate-200" required />
                            </div>
                            <div class="col-md-4 mb-4 px-2">
                                <label for="labelSizeOption"
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Select
                                    Label Size <strong class="text-danger">*</strong></label>
                                <select id="labelSizeOption" autocomplete="off" name="labelSizeOption"
                                    class="form-select !rounded-xl border-slate-200" required></select>
                            </div>
                            <div class="col-md-4 mb-4 px-2">
                                <small
                                    class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Status
                                    <strong class="text-danger">*</strong></small>
                                <div class="form-check form-check-inline mt-2">
                                    <input class="form-check-input" type="radio" id="activDesignStatus"
                                        name="labelDesignStatus" value="1" required />
                                    <label class="form-check-label font-medium text-slate-700"
                                        for="activDesignStatus">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-2">
                                    <input class="form-check-input" type="radio" id="inactiveDesignStatus"
                                        name="labelDesignStatus" value="0" />
                                    <label class="form-check-label font-medium text-slate-700"
                                        for="inactiveDesignStatus">Inactive</label>
                                </div>
                            </div>
                            <div class="col-md-12 px-2">
                                <div id="toolbar" class="bg-white rounded-t-xl border border-slate-200 border-b-0">
                                    <span class="ql-formats">
                                        <select class="ql-font">
                                            <option value="Arial, sans-serif" selected>Arial</option>
                                            <option value="Times New Roman, serif">Times New Roman</option>
                                            <option value="Courier New, monospace">Courier New</option>
                                            <option value="Georgia, serif">Georgia</option>
                                            <option value="Verdana, sans-serif">Verdana</option>
                                            <option value="Tahoma, sans-serif">Tahoma</option>
                                            <option value="Palatino Linotype, Palatino, serif">Palatino</option>
                                            <option value="Helvetica, sans-serif">Helvetica</option>
                                            <option value="Calibri, sans-serif">Calibri</option>
                                            <option value="Comic Sans MS, cursive">Comic Sans MS</option>
                                        </select>
                                        <select class="ql-size">
                                            <option value="5px">5px</option>
                                            <option value="6px">6px</option>
                                            <option value="7px">7px</option>
                                            <option value="8px" selected>8px</option>
                                            <option value="9px">9px</option>
                                            <option value="10px">10px</option>
                                            <option value="12px">12px</option>
                                            <option value="14px">14px</option>
                                            <option value="16px">16px</option>
                                            <option value="18px">18px</option>
                                            <option value="20px">20px</option>
                                            <option value="24px">24px</option>
                                            <option value="28px">28px</option>
                                            <option value="32px">32px</option>
                                            <option value="36px">36px</option>
                                        </select>
                                    </span>
                                    <span class="ql-formats">
                                        <select class="ql-lineheight">
                                            <option value="0.4">0.4</option>
                                            <option value="0.5">0.5</option>
                                            <option value="0.6">0.6</option>
                                            <option value="0.7">0.7</option>
                                            <option value="0.8">0.8</option>
                                            <option value="0.9">0.9</option>
                                            <option value="1" selected>1</option>
                                            <option value="1.2">1.2</option>
                                            <option value="1.5">1.5</option>
                                            <option value="1.75">1.75</option>
                                            <option value="2">2</option>
                                            <option value="2.5">2.5</option>
                                            <option value="3">3</option>
                                        </select>
                                    </span>

                                    <span class="ql-formats">
                                        <button class="ql-bold"></button>
                                        <button class="ql-italic"></button>
                                        <button class="ql-underline"></button>
                                        <button class="ql-strike"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <select class="ql-color"></select>
                                        <select class="ql-background"></select>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-script" value="sub"></button>
                                        <button class="ql-script" value="super"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-header" value="1"></button>
                                        <button class="ql-header" value="2"></button>
                                        <button class="ql-blockquote"></button>
                                        <button class="ql-code-block"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-list" value="ordered"></button>
                                        <button class="ql-list" value="bullet"></button>
                                        <button class="ql-indent" value="-1"></button>
                                        <button class="ql-indent" value="+1"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-direction" value="rtl"></button>
                                        <select class="ql-align"></select>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-link"></button>
                                        <button class="ql-image"></button>
                                        <button class="ql-video"></button>
                                        <button class="ql-formula"></button>
                                    </span>
                                    <span class="ql-formats">
                                        <button class="ql-clean"></button>
                                    </span>
                                </div>
                                <div id="editor" class="h-px-150 bg-white rounded-b-xl border border-slate-200"></div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 items-center justify-center gap-2 border border-slate-200 bg-white px-5 text-sm font-bold text-slate-600 transition-colors hover:bg-slate-50"
                            style="border-radius: 0.75rem !important;"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewLabelDesignModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-printer text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">View Label & Print</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div id="viewLabelDesignForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-4">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.jsdelivr.net/npm/quill-image-resize-module@3.0.0/image-resize.min.js"></script>
<script>
    let currentPage = 1;
    let currentDesignPage = 1;
    var labelListOption = '';

    function loadLabelSizeTable(page = 1) {
        currentPage = page;
        const search = $('#searchLabelSize').val().trim();
        const perPage = $('#perPageSelect').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadLabelSize: 'loadLabelSize',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#labelSizeTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function () {
                $('#labelSizeTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function loadLabelListOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadLabelSizeList: 'loadLabelSizeList'
            },
            success: function (response) {
                labelListOption = response;
                $('#labelSizeOption').html();
                let options = '<option value="">---Select--</option>'; // default
                $.each(response, function (index, item) {
                    options += `<option value="${item.key}" data-width="${item.width}" data-height="${item.height}">${item.value}</option>`;
                });
                $('#labelSizeOption').html(options);
            }
        });
    }

    function loadLabelDesignTable(page = 1) {
        currentDesignPage = page;
        const search = $('#searchLabelsDeisgn').val().trim();
        const perPage = $('#perPageDropdown').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadLabelDesign: 'loadLabelDesign',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#labelDesignListTableBody').html(response.table || '');
                $('#paginationWrapperLableDesignList').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryLableDesignList', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectLableDesignList');
            },
            error: function () {
                $('#labelDesignListTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperLableDesignList').html('');
            }
        });
    }


    $(document).ready(function () {
        loadLabelSizeTable();
        loadLabelListOption();
        loadLabelDesignTable();
        $('#searchLabelSize').on('input', function () {
            loadLabelSizeTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadLabelSizeTable(1);
        });
        $('#searchLabelsDeisgn').on('input', function () {
            loadLabelDesignTable(1);
        });
        $('#footerPerPageSelectLableDesignList').on('change', function () {
            $('#perPageDropdown').val($(this).val());
            loadLabelDesignTable(1);
        });

        // Top-strip per-page dropdown handlers
        $(document).on('click', '.label-size-per-page-item', function () {
            const val = $(this).data('val');
            $('#labelSizePerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        $(document).on('click', '.label-design-per-page-item', function () {
            const val = $(this).data('val');
            $('#labelDesignPerPageText').text($(this).text());
            $('#footerPerPageSelectLableDesignList').val(val).trigger('change');
        });

        $("#designLabelAddModalBtn").on('click', function () {
            loadLabelListOption();
            $('#designLabelAddModal').modal('show');
        });

        $('#addLabelSizeForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addLabelSizeForm');
            const formData = new FormData(form);
            formData.append('addLabelSizes', 'addLabelSizes');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (res) {
                    if (res.status === 'success') {
                        $('#labelSizeAddModal').modal('hide');
                        $('#addLabelSizeForm')[0].reset();
                        loadLabelSizeTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        const Font = Quill.import('formats/font');
        Font.whitelist = [
            'arial', 'times-new-roman', 'courier-new',
            'georgia', 'verdana', 'tahoma',
            'palatino', 'helvetica', 'calibri', 'comic-sans-ms'
        ];
        Quill.register(Font, true);

        const Size = Quill.import("attributors/style/size");
        // allow px values
        Size.whitelist = [
            '5px', '6px', '7px', '8px', '9px',
            '10px', '12px', '14px', '16px',
            '18px', '20px', '24px', '28px',
            '32px', '36px'
        ];
        Quill.register(Size, true);

        const Parchment = Quill.import('parchment');

        // Create a StyleAttributor for line-height
        let LineHeightStyle = new Parchment.Attributor.Style('lineheight', 'line-height', {
            scope: Parchment.Scope.BLOCK, // applies to block elements like <p>
            whitelist: ['0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1', '1.2', '1.5', '1.75', '2', '2.5', '3'] // allowed values
        });

        // Register the style
        Quill.register(LineHeightStyle, true);

        var quill = new Quill('#editor', {
            theme: 'snow',
            modules: {
                toolbar: '#toolbar'
            },
            formats: [
                'font', 'size', 'bold', 'italic', 'underline', 'strike',
                'color', 'background', 'script', 'header', 'blockquote',
                'code-block', 'list', 'indent', 'direction', 'align',
                'link', 'image', 'video', 'formula',
                'lineheight'
            ]
        });

        var toolbar = quill.getModule('toolbar');

        // 3. Add handler for line-height
        toolbar.addHandler('lineheight', function (value) {
            if (value) {
                quill.format('lineheight', value);
            }
        });

        // Update preview on content change
        quill.on('text-change', function () {
            $('#labelPreview').html(quill.root.innerHTML);
        });
        $('#labelSizeOption').on('change', function () {
            let width = $(this).find(':selected').data('width');
            let height = $(this).find(':selected').data('height');
            $('#labelPreview').css({
                width: width + 'mm',
                height: height + 'mm'
            });
        }).trigger('change');

        $('#designLabelAddForm').on('submit', function (e) {
            e.preventDefault();
            let editorContent = quill.root.innerHTML;
            let selected = $('#labelSizeOption option:selected');
            let width = selected.data('width');
            let height = selected.data('height');
            let labelDesign = {
                html: editorContent,
                width: width + "mm",
                height: height + "mm"
            };

            let formData = $(this).serializeArray();
            formData.push({ name: "labelContent", value: JSON.stringify(labelDesign) });

            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success') {
                        $('#designLabelAddModal').modal('hide');
                        $('#designLabelAddForm')[0].reset();
                        quill.setContents([]);
                        $('#labelSizeOption').val('').trigger('change');
                        loadLabelDesignTable();
                        toastr.success(res.message);
                    }
                    else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

    });

    $(document).on('click', '.deleteLabelSizeBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteLabelSize: 'deleteLabelSize',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadLabelSizeTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.deleteLabelDesignBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteLabelDesign: 'deleteLabelDesign',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadLabelDesignTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.editLabelSizeBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#editLabelSizeForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchLabelSizeRecord: 'fetchLabelSizeRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editLabelSizeModal').modal('show');
                        $('#editLabelSizeForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#editLabelSizeForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editLabelSizeForm');
        const formData = new FormData(form);
        formData.append('updateLabelSize', 'updateLabelSize');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editLabelSizeModal').modal('hide');
                    $('#editLabelSizeForm').find('modal-body').html();
                    loadLabelSizeTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.viewLabelDesignBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewLabelDesignForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { fetchLabelDesignRecord: 'fetchLabelDesignRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewLabelDesignModal').modal('show');
                        $('#viewLabelDesignForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });


    $(document).on('click', '.printLabelBtn', function () {
        let id = $(this).data('id'); // encoded id

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { labelDesignPrint: 'labelDesignPrint', id: id },
            dataType: 'json', // tell jQuery to parse JSON automatically
            success: function (response) {
                if (response.status === 'success') {
                    let data = response.data;

                    let printWindow = window.open('', '', 'width=1000,height=600');
                    printWindow.document.write('<html><head><title>Print Label</title>');

                    // set exact size in mm
                    printWindow.document.write('');

                    printWindow.document.write('</head><body>');
                    printWindow.document.write('<div class="label">' + data.html + '</div>');
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();

                    printWindow.onload = function () {
                        printWindow.focus();
                        printWindow.print();
                        printWindow.close();
                    };
                } else {
                    alert(response.message || 'Error fetching label design');
                }
            },
            error: function () {
                alert('AJAX error: Could not fetch label.');
            }
        });
    });



    $(document).on('change', '#perPageSelectLableDesignList', function () { loadLabelSizeTable(1); });
</script>
<?php endSection(); ?>