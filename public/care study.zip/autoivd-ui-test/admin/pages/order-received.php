<?php
$productOptionsArr = [];
$qtyUnitOptionsArr = [];
$categoriesArr = [];
if (isset($conn) && $conn) {
    // Load categories for Item 7.4
    $catQuery = $conn->query("SELECT id, name FROM product_categories WHERE status = 1 AND deleted_at IS NULL ORDER BY name ASC");
    if ($catQuery && $catQuery->num_rows > 0) {
        while ($cRow = $catQuery->fetch_assoc()) {
            $categoriesArr[] = [
                'id' => (int)$cRow['id'],
                'name' => $cRow['name']
            ];
        }
    }

    // Load latest commercials for Item 7.5 & 10.9
    $commercialsByProduct = [];
    $commQuery = $conn->query("
        SELECT fpc.product_id, fpc.selling_rate, fpc.mrp, fpc.hsn_code, fpc.gst_rate
        FROM finance_product_commercials fpc
        INNER JOIN (
            SELECT product_id, MAX(id) as max_id
            FROM finance_product_commercials
            WHERE status = 1 AND deleted_at IS NULL
            GROUP BY product_id
        ) latest ON latest.max_id = fpc.id
    ");
    if ($commQuery && $commQuery->num_rows > 0) {
        while ($cRow = $commQuery->fetch_assoc()) {
            $commercialsByProduct[(int)$cRow['product_id']] = [
                'b2b_price' => (float)$cRow['selling_rate'],
                'b2c_price' => (float)($cRow['mrp'] > 0 ? $cRow['mrp'] : $cRow['selling_rate']),
                'hsn' => $cRow['hsn_code'] ?? '',
                'gst' => (float)$cRow['gst_rate']
            ];
        }
    }

    $prodQuery = $conn->query("SELECT id, product_name, product_code, unit_id, category_id FROM products WHERE status = 1 AND deleted_at IS NULL AND TRIM(product_name) != '' ORDER BY product_name ASC");
    if ($prodQuery && $prodQuery->num_rows > 0) {
        while ($pRow = $prodQuery->fetch_assoc()) {
            $pId = (int)$pRow['id'];
            $productOptionsArr[] = [
                'id' => $pId,
                'product_name' => $pRow['product_name'],
                'product_code' => $pRow['product_code'] ?? '',
                'unit_id' => !empty($pRow['unit_id']) ? (int)$pRow['unit_id'] : '',
                'category_id' => !empty($pRow['category_id']) ? (int)$pRow['category_id'] : 0,
                'b2b_price' => (float)($commercialsByProduct[$pId]['b2b_price'] ?? 0),
                'b2c_price' => (float)($commercialsByProduct[$pId]['b2c_price'] ?? 0)
            ];
        }
    }

    $unitQuery = $conn->query("SELECT id, fullname, short_name FROM standard_units WHERE status != 3 ORDER BY fullname ASC");
    if ($unitQuery && $unitQuery->num_rows > 0) {
        while ($uRow = $unitQuery->fetch_assoc()) {
            $label = $uRow['fullname'];
            if (!empty($uRow['short_name']) && strtolower(trim($uRow['short_name'])) !== strtolower(trim($uRow['fullname']))) {
                $label .= " (" . $uRow['short_name'] . ")";
            }
            $qtyUnitOptionsArr[] = [
                'id' => (int)$uRow['id'],
                'label' => $label,
                'value' => $uRow['short_name']
            ];
        }
    }
}
?>
<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <!-- Page Title Banner -->
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Track and manage all received orders</p>
        </div>
    </div>

    <!-- Top Widgets: New Orders & Goods Received & Reserved (Screenshot 1) -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <!-- Left Widget: New Orders! -->
        <div id="newOrdersBanner" class="rounded-2xl border p-5 shadow-xs relative cursor-pointer transition-all hover:shadow-md" style="background-color: #fdf2f2; border-color: #fecaca;" onclick="refreshNewIncomingOrdersModal()">
            <div class="flex items-start gap-3.5">
                <div class="mt-0.5 shrink-0 flex items-center justify-center rounded-full text-white shadow-xs" style="height: 1.75rem; width: 1.75rem; background-color: #dc2626;">
                    <i class="ti ti-alert-circle text-base"></i>
                </div>
                <div class="flex flex-col items-start">
                    <h3 class="font-bold leading-tight" style="font-size: 17px; color: #dc2626; margin: 0;">New Orders!</h3>
                    <p class="font-medium text-slate-700 mt-1.5 mb-3" style="font-size: 13px;">
                        <span id="newOrdersCount" class="font-bold">0</span> New Orders are waiting for review and processing.
                    </p>
                    <button type="button" id="verifyStockProcessBtn"
                        class="inline-flex items-center justify-center rounded-xl border bg-white px-4 font-bold text-slate-700 shadow-xs ring-1 ring-slate-900/5 focus:outline-none transition-all hover:bg-slate-50 hover:border-slate-300" style="height: 2.15rem; border-color: #e2e8f0; font-size: 12.5px;" onclick="event.stopPropagation(); refreshNewIncomingOrdersModal();">
                        Review New Orders
                    </button>
                </div>
            </div>
        </div>

        <!-- Right Widget: Goods Received & Reserved -->
        <div id="goodsReceivedReservedBanner" class="rounded-2xl border p-5 shadow-xs relative cursor-pointer transition-all hover:shadow-md group" style="background-color: #ecfdf5; border-color: #a7f3d0;" onclick="openGoodsReceivedReservedModal()">
            <!-- Header Badges & Action -->
            <div class="absolute right-4 top-4 flex items-center gap-2">
                <span class="inline-flex items-center gap-1 rounded-full bg-emerald-100/90 px-3 py-1 text-xs font-bold text-emerald-800 border border-emerald-200">
                    Procure & Produce Synced
                </span>
                <span class="flex h-7 w-7 items-center justify-center rounded-full bg-white border border-emerald-200 text-emerald-700 shadow-xs transition-transform group-hover:translate-x-0.5">
                    <i class="ti ti-chevron-right text-sm"></i>
                </span>
            </div>

            <div class="flex items-start gap-3.5">
                <div class="mt-0.5 shrink-0 flex items-center justify-center rounded-full text-white shadow-xs" style="height: 1.75rem; width: 1.75rem; background-color: #059669;">
                    <i class="ti ti-check text-base"></i>
                </div>
                <div class="flex flex-col items-start pr-32">
                    <h3 class="font-bold leading-tight text-slate-900" style="font-size: 17px; margin: 0;">Goods Received & Reserved</h3>
                    <p class="font-medium text-slate-600 mt-1.5 mb-3" style="font-size: 13px;">
                        All reserved materials from completed Procurement (PO) & Production batches received in inventory.
                    </p>
                    <div class="flex items-center justify-between w-full mt-auto pt-1">
                        <div class="flex items-baseline gap-1.5">
                            <span id="goodsReceivedReservedOrdersCount" class="font-extrabold text-emerald-700 text-lg">0</span>
                            <span class="font-bold text-slate-700 text-xs">Orders Closed & Stock Ready</span>
                        </div>
                        <span class="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 hover:text-emerald-900 transition-colors" onclick="event.stopPropagation(); openGoodsReceivedReservedModal();">
                            View Completed Records &rarr;
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .swal2-container,
        div:where(.swal2-container),
        body .swal2-container,
        .swal2-container.swal2-backdrop-show,
        .swal2-container.swal2-shown,
        .swal2-highest-zindex {
            z-index: 9999999 !important;
        }

        #externalOrderApprovalModal {
            z-index: 1120 !important;
        }

        .modal-backdrop.external-order-approval-backdrop {
            z-index: 1110 !important;
        }

        .order-received-search-control,
        .order-received-date-control {
            width: 100%;
        }

        .order-received-date-control input[type="date"] {
            min-width: 0;
            width: 0;
        }

        .order-received-date-control label {
            display: flex;
            height: 100%;
            margin: 0 !important;
            align-items: center;
            justify-content: center;
            line-height: 1;
        }

        @media (min-width: 768px) {
            .order-received-search-control {
                flex: 1 1 160px;
                max-width: 220px;
            }

            .order-received-date-control {
                flex: 0 0 215px;
                width: 215px;
                min-width: 215px;
                max-width: 215px;
            }
        }
    </style>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <!-- Production Plan-style filter toolbar -->
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:flex-wrap md:items-center">
                    <input type="hidden" id="perPageSelect" value="10">

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-full items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 md:w-auto"
                            type="button" data-bs-toggle="dropdown">
                            <span id="orderReceivedPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <!-- Search -->
                    <div class="order-received-search-control relative h-10 min-w-[160px] flex-grow md:max-w-[220px]">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProducts"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search orders...">
                    </div>

                    <!-- Status Filter -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-full items-center justify-between gap-3 whitespace-nowrap !rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 md:w-auto"
                            type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                <i class="ti ti-filter text-base text-slate-400"></i>
                                Status
                            </span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <div
                            class="dropdown-menu max-h-64 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl">
                            <?php if (!empty(Constant::ORDER_RECEIVED['STATUS_TYPES_List'])) { ?>
                                <label
                                    class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                    <input type="checkbox" class="status-filter rounded border-slate-300 accent-emerald-600"
                                        value="all"> <span>All</span>
                                </label>
                                <?php foreach (Constant::ORDER_RECEIVED['STATUS_TYPES_List'] as $sfpckey => $sfpcval) { ?>
                                    <label
                                        class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="status-filter rounded border-slate-300 accent-emerald-600"
                                            value="<?php echo $sfpckey; ?>"> <span><?php echo $sfpcval['label']; ?></span>
                                    </label>
                                <?php }
                            } ?>
                        </div>
                    </div>

                    <div class="order-received-date-control flex h-10 items-center overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/30">
                        <label for="fromDate"
                            class="flex h-full w-14 shrink-0 items-center justify-center border-r border-slate-200 bg-slate-50 px-2 text-xs font-bold text-slate-600">From</label>
                        <input type="date" id="fromDate" value="<?= date('Y-m-d', strtotime('-7 days')) ?>"
                            class="h-full w-0 min-w-0 flex-1 border-0 bg-white px-3 text-sm font-medium text-slate-700 outline-none" />
                    </div>
                    <div class="order-received-date-control flex h-10 items-center overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/30">
                        <label for="toDate"
                            class="flex h-full w-14 shrink-0 items-center justify-center border-r border-slate-200 bg-slate-50 px-2 text-xs font-bold text-slate-600">To</label>
                        <input type="date" id="toDate" value="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                            class="h-full w-0 min-w-0 flex-1 border-0 bg-white px-3 text-sm font-medium text-slate-700 outline-none" />
                    </div>


                    <button type="button" class="biogenix-nav-btn-dashboard h-10 shrink-0 gap-2 px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_order_received_add')) { ?>
                        <button type="button" id="addOrderReceivedModalBtn"
                            class="inline-flex h-10 w-10 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add Order" title="Add Order" aria-label="Add Order">
                            <i class="ti ti-plus text-xl"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <!-- Table -->
            <div class="w-full overflow-x-auto">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr>
                            <th class="w-12 border-b border-slate-200 px-4 py-3">#</th>
                            <th
                                class="sortable w-32 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors">
                                SOURCE
                            </th>
                            <th class="sortable w-44 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="created_at">
                                <span class="inline-flex items-center gap-1">Timestamp <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-32 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="date_order_received">
                                <span class="inline-flex items-center gap-1">Order Date <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-44 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="order_number">
                                <span class="inline-flex items-center gap-1">Order No <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-28 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="status">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-64 min-w-[220px] cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="client_name">
                                <span class="inline-flex items-center gap-1">Client Name <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-80 min-w-[300px] border-b border-slate-200 px-4 py-3">Products</th>
                            <th class="sortable w-40 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="received_by">
                                <span class="inline-flex items-center gap-1">Received By <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-36 cursor-pointer border-b border-slate-200 px-4 py-3 hover:bg-slate-100 transition-colors"
                                data-column="dispatch_timeline">
                                <span class="inline-flex items-center gap-1">Dispatch Timeline <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="w-36 border-b border-slate-200 px-4 py-3">Location Type</th>
                            <th class="w-36 border-b border-slate-200 px-4 py-3">Order Value</th>
                            <th class="w-36 border-b border-slate-200 px-4 py-3">Payment Terms</th>
                            <th class="w-28 border-b border-slate-200 px-4 py-3">PI</th>
                            <th class="w-40 border-b border-slate-200 px-4 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-200" id="orderReceivedTableBody"></tbody>
                </table>
            </div>

            <!-- Footer -->
            <style>
                #footerPerPageSelect+.dropdown {
                    display: none !important;
                }
            </style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- Goods Received & Reserved - Completed Records Modal (Screenshot 2) -->
    <div class="modal fade animate__animated fadeIn" id="goodsReceivedReservedModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 1280px; width: 95%;">
            <div class="modal-content overflow-hidden !rounded-2xl border-0 bg-white shadow-2xl">
                <!-- Modal Header -->
                <div class="modal-header flex items-center justify-between border-b border-slate-100 bg-white px-6 py-4">
                    <div class="flex items-center gap-3">
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm">
                            <i class="ti ti-clipboard-check text-xl"></i>
                        </div>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Goods Received & Reserved - Completed Records</h5>
                            <p class="m-0 text-xs font-medium text-slate-500">Orders where Procure (PO) and Produce (BMR/BPR) items have arrived and reserved into stock</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>

                <!-- Modal Body -->
                <div class="modal-body p-6 bg-slate-50/50">
                    <!-- Top 3 Stat Summary Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <!-- Card 1: Closed Orders -->
                        <div class="flex items-center gap-3.5 rounded-2xl border border-emerald-200/80 bg-white p-4 shadow-xs transition-all hover:shadow-sm">
                            <div id="grrClosedOrdersBadge" class="flex h-12 min-w-[3.25rem] px-2 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 font-extrabold text-lg border border-emerald-100 shadow-xs">
                                0
                            </div>
                            <div class="min-w-0 flex-1">
                                <span class="block text-[11px] font-bold uppercase tracking-wider text-slate-400">CLOSED ORDERS</span>
                                <div class="text-sm font-extrabold text-slate-800 tracking-tight mt-0.5"><span id="grrClosedOrdersCount">0</span> Orders Ready</div>
                            </div>
                        </div>

                        <!-- Card 2: Procured Items -->
                        <div class="flex items-center gap-3.5 rounded-2xl border border-blue-200/80 bg-white p-4 shadow-xs transition-all hover:shadow-sm">
                            <div id="grrProcuredItemsBadge" class="flex h-12 min-w-[3.25rem] px-2 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-700 font-extrabold text-lg border border-blue-100 shadow-xs">
                                0
                            </div>
                            <div class="min-w-0 flex-1">
                                <span class="block text-[11px] font-bold uppercase tracking-wider text-slate-400">PROCURED ITEMS (PO)</span>
                                <div class="text-sm font-extrabold text-slate-800 tracking-tight mt-0.5"><span id="grrProcuredItemsCount">0</span> Items Inwarded</div>
                            </div>
                        </div>

                        <!-- Card 3: In-House Produced -->
                        <div class="flex items-center gap-3.5 rounded-2xl border border-amber-200/80 bg-white p-4 shadow-xs transition-all hover:shadow-sm">
                            <div id="grrProducedBatchesBadge" class="flex h-12 min-w-[3.25rem] px-2 shrink-0 items-center justify-center rounded-xl bg-amber-50 text-amber-700 font-extrabold text-lg border border-amber-100 shadow-xs">
                                0
                            </div>
                            <div class="min-w-0 flex-1">
                                <span class="block text-[11px] font-bold uppercase tracking-wider text-slate-400 truncate" title="IN-HOUSE PRODUCED (BMR)">IN-HOUSE PRODUCED (BMR)</span>
                                <div class="text-sm font-extrabold text-slate-800 tracking-tight mt-0.5"><span id="grrProducedBatchesCount">0</span> Batches Ready</div>
                            </div>
                        </div>
                    </div>

                    <!-- Filter & Search Toolbar -->
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-3 mb-4">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="text-xs font-bold text-slate-500 mr-1">Filter Source:</span>
                            <button type="button" class="grr-source-pill inline-flex items-center gap-1.5 rounded-xl px-4 py-1.5 text-xs font-bold transition-all bg-emerald-700 text-white shadow-xs" data-source="all">
                                All Sources (<span id="grrFilterAllCount">0</span>)
                            </button>
                            <button type="button" class="grr-source-pill inline-flex items-center gap-1.5 rounded-xl px-4 py-1.5 text-xs font-bold transition-all bg-white text-slate-600 border border-slate-200 hover:bg-slate-50" data-source="procure">
                                Procure (PO) <span id="grrFilterPoCount">0</span>
                            </button>
                            <button type="button" class="grr-source-pill inline-flex items-center gap-1.5 rounded-xl px-4 py-1.5 text-xs font-bold transition-all bg-white text-slate-600 border border-slate-200 hover:bg-slate-50" data-source="produce">
                                Produce (BMR/BPR) <span id="grrFilterBmrCount">0</span>
                            </button>
                        </div>
                        <div class="relative w-full sm:w-72">
                            <i class="ti ti-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
                            <input type="text" id="grrSearchInput" class="w-full rounded-xl border border-slate-200 bg-white py-2 pl-9 pr-4 text-xs font-medium text-slate-700 shadow-xs placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20" placeholder="Search order #, client or item...">
                        </div>
                    </div>

                    <!-- Table -->
                    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
                        <div class="max-h-[480px] overflow-y-auto">
                            <table class="w-full text-left text-xs">
                                <thead class="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-600">
                                    <tr>
                                        <th class="px-4 py-3.5">ORDER #</th>
                                        <th class="px-4 py-3.5">CLIENT NAME</th>
                                        <th class="px-4 py-3.5">ARRIVED ITEM / DESCRIPTION</th>
                                        <th class="px-4 py-3.5">SOURCE</th>
                                        <th class="px-4 py-3.5">ARRIVED QTY / REQ</th>
                                        <th class="px-4 py-3.5">BATCH / PO REF</th>
                                        <th class="px-4 py-3.5">DATE RECEIVED</th>
                                        <th class="px-4 py-3.5">RESERVATION STATUS</th>
                                    </tr>
                                </thead>
                                <tbody id="grrTableBody" class="divide-y divide-slate-100 text-slate-700">
                                    <!-- Dynamic rows loaded via JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer border-t border-slate-100 bg-white px-6 py-3 flex items-center justify-end">
                    <button type="button" class="inline-flex h-9 items-center justify-center rounded-xl bg-slate-900 px-6 text-xs font-bold text-white shadow-xs hover:bg-slate-800 transition-colors focus:outline-none" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Process Order Action Dialog Modal (Screenshot 3) -->
    <div class="modal fade animate__animated fadeIn" id="processOrderActionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 640px; width: 95%;">
            <div class="modal-content overflow-hidden !rounded-2xl border-0 bg-white shadow-2xl">
                <!-- Modal Header -->
                <div class="modal-header flex items-start justify-between border-b border-slate-100 bg-white px-6 py-4">
                    <div class="flex items-start gap-3.5">
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-white shadow-xs">
                            <i class="ti ti-notes text-xl"></i>
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <h5 class="modal-title m-0 text-base font-bold text-slate-900">Process Order: <span id="processOrderNoText">ORD-2026-8941</span></h5>
                                <span class="inline-flex rounded-full bg-amber-50 px-2.5 py-0.5 text-[11px] font-bold text-amber-700 border border-amber-200">Action Dialog</span>
                            </div>
                            <p class="m-0 text-xs font-medium text-slate-500 mt-0.5">Choose an operational action for this reserved record (<span id="processOrderSubtext">Apex Diagnostics Ltd &bull; Plastic Vial Brown 100 mL</span>).</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>

                <!-- Modal Body -->
                <div class="modal-body p-6 bg-slate-50/50">
                    <input type="hidden" id="actionModalOrderId" value="">
                    <input type="hidden" id="actionModalOrderItemId" value="">

                    <!-- SELECTED RECORD SUMMARY Box -->
                    <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs mb-5">
                        <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3">SELECTED RECORD SUMMARY</div>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <div>
                                <span class="block text-[11px] font-medium text-slate-400">ORDER NO</span>
                                <span id="summaryOrderNo" class="text-xs font-extrabold text-slate-900">ORD-2026-8941</span>
                            </div>
                            <div>
                                <span class="block text-[11px] font-medium text-slate-400">CLIENT</span>
                                <span id="summaryClientName" class="text-xs font-bold text-slate-800 truncate block" title="">-</span>
                            </div>
                            <div>
                                <span class="block text-[11px] font-medium text-slate-400">ITEM & QTY</span>
                                <span id="summaryItemQty" class="text-xs font-bold text-slate-800 truncate block" title="">-</span>
                            </div>
                            <div>
                                <span class="block text-[11px] font-medium text-slate-400">STOCK STATUS</span>
                                <span id="summaryStockStatus" class="inline-flex items-center rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 border border-emerald-200">Reserved & Closed</span>
                            </div>
                        </div>
                    </div>

                    <!-- SELECT ACTION TO EXECUTE Section -->
                    <div>
                        <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3">SELECT ACTION TO EXECUTE</div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <!-- Green Action Button: hand off to Goods Dispatch -->
                            <button type="button" id="confirmGoodsDispatchedBtn" class="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 px-4 text-xs shadow-sm transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                                <i class="ti ti-truck-delivery text-base"></i> Send to Goods Dispatch
                            </button>

                            <!-- Red Action Button: Cancel Order -->
                            <button type="button" id="cancelReservedOrderBtn" class="flex items-center justify-center gap-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold py-3.5 px-4 text-xs shadow-sm transition-all focus:outline-none focus:ring-2 focus:ring-rose-500/30">
                                <i class="ti ti-trash text-base"></i> Cancel Order
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer border-t border-slate-100 bg-white px-6 py-3 flex items-center justify-between">
                    <span class="text-xs text-slate-400 font-medium">Order ID: <span id="processOrderFooterId" class="font-bold text-slate-600">-</span> &bull; Biogenix ERP</span>
                    <button type="button" id="backToGrrListBtn" class="inline-flex h-9 items-center justify-center rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 shadow-xs hover:bg-slate-50 transition-colors focus:outline-none">
                        Back to List
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- New Incoming Orders List Modal -->
    <div class="modal fade animate__animated fadeIn" id="newIncomingOrdersModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 1400px; width: 95%;">
            <div class="modal-content overflow-hidden !rounded-lg border-0 bg-white shadow-xl">
                <div class="modal-header flex items-start justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-start gap-3">
                        <span class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 ring-1 ring-blue-100">
                            <i class="ti ti-list-details text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">New Incoming Orders List</h5>
                            <p class="m-0 mt-1 text-xs font-medium text-slate-500 leading-relaxed max-w-lg">
                                Review and verify stock availability for the latest incoming orders.
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body p-0">
                    <div class="overflow-x-auto w-full">
                        <table class="w-full border-collapse whitespace-nowrap text-left text-sm text-slate-600">
                            <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                                <tr>
                                    <th class="w-12 border-b border-slate-200 px-4 py-3 text-center">
                                        <input type="checkbox" id="selectAllIncomingOrders" class="h-4 w-4 rounded border-slate-300 accent-emerald-700" aria-label="Select all dispatch-ready orders">
                                    </th>
                                    <th class="border-b border-slate-200 px-4 py-3">Order Number</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Date</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Source</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Client</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Product(s)</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Quantity</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Delivery Address</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Order Value</th>
                                    <th class="border-b border-slate-200 px-4 py-3">Stock</th>
                                    <th class="border-b border-slate-200 px-4 py-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="newIncomingOrdersListBody" class="divide-y divide-slate-100 bg-white">
                                <!-- Populated dynamically -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-slate-50 px-6 py-4 flex items-center justify-between gap-3">
                    <button type="button" id="sendSelectedIncomingOrdersBtn" class="inline-flex h-10 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-50" disabled>
                        <i class="ti ti-truck-delivery text-lg"></i>
                        Send to Dispatch
                    </button>
                    <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- External Order Approval Modal -->
    <div class="modal fade" id="externalOrderApprovalModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 465px;">
            <div class="modal-content overflow-hidden !rounded-2xl border-0 bg-white shadow-2xl">
                <div class="relative overflow-hidden px-4 py-3 text-white" style="background: linear-gradient(135deg, color-mix(in srgb, var(--appearance-accent, #e7952b) 58%, #1f2937) 0%, var(--appearance-accent, #e7952b) 100%);">
                    <div class="absolute -right-12 -top-16 h-40 w-40 rounded-full" style="background: rgba(255,255,255,.12); filter: blur(28px);"></div>
                    <div class="relative flex items-start justify-between gap-4">
                        <div class="flex items-center gap-3">
                            <span class="inline-flex h-10 w-10 items-center justify-center rounded-xl backdrop-blur" style="background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2);">
                                <i class="ti ti-shield-check text-xl"></i>
                            </span>
                            <div>
                                <p class="mb-1 text-[11px] font-bold uppercase tracking-[0.18em]" style="color: rgba(255,255,255,.75);">External order review</p>
                                <h5 class="m-0 text-lg font-extrabold" id="approvalOrderNumber">Order approval</h5>
                            </div>
                        </div>
                        <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl text-white transition" style="background: rgba(255,255,255,.12);" data-bs-dismiss="modal" aria-label="Close">
                            <i class="ti ti-x text-xl"></i>
                        </button>
                    </div>
                </div>
                <div class="modal-body p-4">
                    <div class="grid grid-cols-2 gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm">
                        <div><span class="block text-xs font-semibold text-slate-400">Source</span><strong id="approvalOrderSource" class="text-slate-800">-</strong></div>
                        <div><span class="block text-xs font-semibold text-slate-400">Client</span><strong id="approvalOrderClient" class="text-slate-800">-</strong></div>
                        <div class="col-span-2"><span class="block text-xs font-semibold text-slate-400">Products</span><strong id="approvalOrderProducts" class="text-slate-800">-</strong></div>
                        <div><span class="block text-xs font-semibold text-slate-400">Ordered quantity</span><strong id="approvalOrderedQuantity" class="text-slate-800">-</strong></div>
                        <div><span class="block text-xs font-semibold text-slate-400">Unreserved stock</span><strong id="approvalUnreservedQuantity" class="text-slate-800">-</strong></div>
                        <div><span class="block text-xs font-semibold text-slate-400">Order value</span><strong id="approvalOrderValue" class="text-slate-800">-</strong></div>
                        <div><span class="block text-xs font-semibold text-slate-400">Stock check</span><strong id="approvalOrderStock" class="text-slate-800">-</strong></div>
                    </div>
                    <label for="approvalReviewReason" class="mt-3 block text-sm font-bold text-slate-800">Review note <span class="font-medium text-slate-400">(required for rejection)</span></label>
                    <textarea id="approvalReviewReason" rows="2" maxlength="500" class="mt-2 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-800 outline-none transition focus:ring-2" placeholder="Add a short reason or instruction..."></textarea>
                    <input type="hidden" id="approvalOrderId" value="">
                </div>
                <div class="modal-footer flex items-center justify-between gap-2 border-t border-slate-100 bg-slate-50/80 px-4 py-3">
                    <button type="button" id="rejectExternalOrderBtn" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-rose-200 bg-white px-4 text-sm font-bold text-rose-600 transition hover:bg-rose-50">
                        <i class="ti ti-x"></i> Reject
                    </button>
                    <button type="button" id="approveExternalOrderBtn" class="inline-flex h-10 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl" style="background: linear-gradient(90deg, var(--appearance-accent, #e7952b), color-mix(in srgb, var(--appearance-accent, #e7952b) 78%, #000)); box-shadow: 0 10px 25px color-mix(in srgb, var(--appearance-accent, #e7952b) 28%, transparent);">
                        <i class="ti ti-check"></i> Approve &amp; Continue
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add New Order Modal -->
    <div class="modal fade animate__animated fadeIn" id="addOrderReceivedModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-start justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-start gap-3">
                        <span
                            class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add New Order</h5>
                            <p class="m-0 mt-1 text-xs font-medium text-slate-500 leading-relaxed max-w-lg">
                                Fill this form <strong>every time an order is received</strong> from a distributor,
                                hospital, government body, or direct client. Log all product names, quantities, client
                                name and location to track orders, dispatches, and payment status efficiently.<br>
                                ✅ Submit even for verbal or WhatsApp orders. 🚫 Don't skip entries.
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addOrderReceivedForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label for="dateOfOrderReceived"
                                    class="mb-1 block text-sm font-medium text-slate-800">Date Of Order Received</label>
                                <input type="date" id="dateOfOrderReceived" autocomplete="off"
                                    name="dateOfOrderReceived" class="input-theme" required />
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="flex items-center justify-between gap-2">
                                    <label for="customerId" class="mb-1 block text-sm font-medium text-slate-800">Customer</label>
                                    <a href="index.php?page=customer-management" target="_blank" class="text-xs font-bold text-emerald-700 hover:underline">Open Customer Master</a>
                                </div>
                                <select id="customerId" name="customerId" class="input-theme" required></select>
                            </div>
                        </div>
                        <div id="orderCustomerDetails" class="hidden mb-3 rounded-xl border border-slate-200 bg-white p-3">
                            <div class="mb-2 flex items-center justify-between">
                                <span class="text-xs font-bold uppercase tracking-wide text-emerald-800">Customer Master details</span>
                                <span id="customerValidationBadge" class="rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-700">VALID</span>
                            </div>
                            <div class="grid grid-cols-1 gap-2 text-xs text-slate-600 md:grid-cols-3">
                                <div><b>Address:</b> <span data-customer-field="address">-</span></div>
                                <div><b>GSTIN:</b> <span data-customer-field="gstin">-</span></div>
                                <div><b>PAN:</b> <span data-customer-field="pan">-</span></div>
                                <div><b>State / Code:</b> <span data-customer-field="state_code_display">-</span></div>
                                <div><b>Contact:</b> <span data-customer-field="contact_display">-</span></div>
                                <div><b>Email:</b> <span data-customer-field="email">-</span></div>
                            </div>
                            <div id="customerMissingFields" class="hidden mt-2 rounded-lg bg-amber-50 p-2 text-xs font-semibold text-amber-800"></div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-2">
                                <label for="orderType" class="mb-1 block text-sm font-medium text-slate-800">Order
                                    Type</label>
                                <select name="orderType" id="orderType" class="input-theme select2" required>
                                    <?php if (!empty(Constant::ORDER_RECEIVED['ORDER_TYPE_OPTIONS'])) {
                                        echo '<option value="">----Select----</option>';
                                        foreach (Constant::ORDER_RECEIVED['ORDER_TYPE_OPTIONS'] as $otpkey => $otplabel) {
                                            echo "<option value=\"$otpkey\">$otplabel</option>";
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label for="locationMap" class="mb-1 block text-sm font-medium text-slate-800">Location
                                    Type</label>
                                <select name="locationMap" id="locationMap" class="input-theme select2" required>
                                    <?php
                                    echo '<option value="">----Select----</option>';
                                    foreach (Constant::ORDER_RECEIVED['LOCATION_MAP'] as $otpkey => $otplabel) {
                                        echo '<option value="' . $otpkey . '">' . $otplabel['label'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label for="areaCity" class="mb-1 block text-sm font-medium text-slate-800">City/Town</label>
                                <input type="text" id="areaCity" autocomplete="off" name="areaCity" class="input-theme" placeholder="Enter City/Town" />
                            </div>
                            <div class="col-md-12 mb-2 d-none" id="orderTypekWrapper">
                                <label for="orderTypeDetails"
                                    class="mb-1 block text-sm font-medium text-slate-800">Order Type Details</label>
                                <textarea id="orderTypeDetails" autocomplete="off" name="orderTypeDetails"
                                    class="input-theme" placeholder="Enter Order Type Details"></textarea>
                            </div>
                        </div>

                        <!-- Multi-Location Dispatch Section (Item 7.3) -->
                        <div id="multiLocationDispatchSection" class="hidden col-12 mb-3 mt-1">
                            <div class="rounded-xl border border-blue-200 bg-blue-50/60 p-3.5 shadow-sm">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="flex items-center gap-2">
                                        <i class="ti ti-map-pin text-lg text-blue-600"></i>
                                        <span class="text-xs font-bold uppercase tracking-wide text-blue-900">Multi-Location Shipping Destinations</span>
                                    </div>
                                    <button type="button" id="addLocationDestinationBtn" class="inline-flex h-8 items-center gap-1.5 rounded-lg border border-blue-300 bg-white px-3 text-xs font-bold text-blue-700 shadow-sm hover:bg-blue-50 focus:outline-none cursor-pointer">
                                        <i class="ti ti-plus"></i> Add Destination
                                    </button>
                                </div>
                                <p class="text-xs text-blue-700/80 mb-2">Specify multiple destination shipping addresses, consignee details, and quantity splits for this order.</p>
                                <div id="locationDestinationsList" class="space-y-2">
                                    <!-- Dynamic destination rows inserted via JS -->
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 mb-2">
                                <label class="mb-1 block text-sm font-medium text-slate-800">Product Details</label>
                                <style>
                                    #productsList, #productsListEdit {
                                        max-height: 280px;
                                        overflow-y: auto;
                                        overflow-x: hidden;
                                    }
                                    #productsList .product-row, #productsListEdit .product-row {
                                        margin-left: 0 !important;
                                        margin-right: 0 !important;
                                    }
                                    #addOrderReceivedModal .modal-body, #editOrderReceivedModal .modal-body {
                                        max-height: calc(100vh - 210px);
                                        overflow-y: auto;
                                        overflow-x: hidden;
                                    }
                                    .select2-container--default .select2-results > .select2-results__options {
                                        max-height: 250px !important;
                                        overflow-y: auto !important;
                                    }
                                    #addOrderReceivedModal .select2-container, #editOrderReceivedModal .select2-container {
                                        width: 100% !important;
                                    }
                                </style>
                                <div id="productsList" class="max-h-[280px] overflow-y-auto overflow-x-hidden space-y-2 mb-2 pr-1"></div>
                                <div class="mb-2">
                                    <button type="button"
                                        class="inline-flex h-9 items-center gap-2 !rounded-xl border border-emerald-200 bg-emerald-50 px-4 text-sm font-semibold text-emerald-700 hover:bg-emerald-100 focus:outline-none"
                                        id="addProductBtn">
                                        <i class="ti ti-plus text-base"></i> Add Product
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label for="orderValue" class="mb-1 block text-sm font-medium text-slate-800">Order
                                    Value</label>
                                <input type="number" min="0" step="any" id="orderValue" autocomplete="off"
                                    name="orderValue" class="input-theme" placeholder="Enter Order Value" />
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="dispatchTimeline"
                                    class="mb-1 block text-sm font-medium text-slate-800">Urgency / Dispatch
                                    Timeline</label>
                                <select name="dispatchTimeline" id="dispatchTimeline" class="input-theme select2">
                                    <?php if (!empty(Constant::ORDER_RECEIVED['DISPATCH_TIMELINE'])) {
                                        echo '<option value="">----Select----</option>';
                                        foreach (Constant::ORDER_RECEIVED['DISPATCH_TIMELINE'] as $key => $label) {
                                            echo "<option value=\"$key\">$label</option>";
                                        }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label for="paymentStatus" class="mb-1 block text-sm font-medium text-slate-800">Payment
                                    Terms / Status</label>
                                <select name="paymentStatus" id="paymentStatus" class="input-theme select2" required>
                                    <?php
                                    echo '<option value="">----Select----</option>';
                                    foreach (Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM'] as $pstkey => $pstlabel) {
                                        echo "<option value=\"$pstkey\">$pstlabel</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-2 d-none" id="paymentRemarkWrapper">
                                <label for="paymentStatusDetails"
                                    class="mb-1 block text-sm font-medium text-slate-800">Payment Details</label>
                                <textarea id="paymentStatusDetails" autocomplete="off" name="paymentStatusDetails"
                                    class="input-theme" placeholder="Enter Payment Details"></textarea>
                            </div>
                            <div class="col-md-6 mb-2 d-none" id="paymentOverrideReasonWrapper">
                                <label for="paymentOverrideReason" class="mb-1 block text-sm font-medium text-slate-800">Override Reason</label>
                                <textarea id="paymentOverrideReason" name="paymentOverrideReason" class="input-theme" placeholder="Why are Customer Master payment terms being changed?"></textarea>
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="proformaInvoice" class="mb-1 block text-sm font-medium text-slate-800">Proforma Invoice (optional)</label>
                                <select id="proformaInvoice" name="proformaInvoice" class="input-theme" disabled></select>
                                <p id="piSelectionDetails" class="m-0 mt-1 text-xs text-slate-500">Select a customer first.</p>
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="receivedBy" class="mb-1 block text-sm font-medium text-slate-800">Received
                                    By</label>
                                <input type="text" id="receivedBy" autocomplete="off" name="receivedBy"
                                    class="input-theme bg-slate-100" value="<?= htmlspecialchars($_SESSION['user_name'] ?? 'Current User') ?>" readonly />
                                <p class="m-0 mt-1 text-xs text-slate-500">Captured from the signed-in user and cannot be edited.</p>
                            </div>
                        </div>
                    </div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Order Modal -->
    <div class="modal fade animate__animated fadeIn" id="viewOrderReceivedModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Order Details</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">View full order information</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="viewOrderReceived">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3"></div>
                    <div
                        class="d-none hidden modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Order Modal -->
    <div class="modal fade animate__animated fadeIn" id="editOrderReceivedModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-edit text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Edit Order</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update order details</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editOrderReceivedForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3"></div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Update Order Status Specific Modal -->
    <div class="modal fade animate__animated fadeIn" id="editOrderReceivedStatusSpecificModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-rotate-360 text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Update Order Status</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Update specific item status</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editOrderReceivedStatusSpecificForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3"></div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Update Status (quick) Modal -->
    <div class="modal fade animate__animated fadeIn" id="updateStatusOrderReceivedModal" tabindex="-1"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-refresh text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Update Status</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:border-none focus:ring-0"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="updateStatusOrderReceivedForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="row">
                            <div class="col-md-12 mb-2">
                                <input type="hidden" name="orderEditId" id="orderEditId" value="">
                                <label for="orderStatus" class="mb-1 block text-sm font-medium text-slate-800">Select
                                    Status</label>
                                <select name="orderStatus" id="orderStatus" class="input-theme select2" required>
                                    <?php
                                    echo '<option value="">----Select----</option>';
                                    foreach (Constant::ORDER_RECEIVED['STATUS_TYPES_ORDER_LIST'] as $otpkey => $otplabel) {
                                        echo "<option value=\"$otpkey\">" . $otplabel['label'] . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div
                        class="modal-footer flex items-center justify-end gap-3 border-t border-slate-200 bg-white !px-4 !py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-10 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="orderManagementExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Timestamp" checked />
                                        <span class="text-sm font-medium text-slate-700">Timestamp</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Order Date" checked />
                                        <span class="text-sm font-medium text-slate-700">Order Date</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Order Number" checked />
                                        <span class="text-sm font-medium text-slate-700">Order Number</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Dispatch Timeline" checked />
                                        <span class="text-sm font-medium text-slate-700">Dispatch Timeline</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Area City" checked />
                                        <span class="text-sm font-medium text-slate-700">Area City</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Status</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Client Name" checked />
                                        <span class="text-sm font-medium text-slate-700">Client Name</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product" checked />
                                        <span class="text-sm font-medium text-slate-700">Product</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Qty" checked />
                                        <span class="text-sm font-medium text-slate-700">Qty</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                        <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Item Status" checked />
                                        <span class="text-sm font-medium text-slate-700">Item Status</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php startSection('scripts'); ?>
<script src="<?= asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js') ?>"></script>
<script>
    let currentPage = 1;
    let qtyUnitOptions = <?= json_encode($qtyUnitOptionsArr) ?>;
    let categoriesList = <?= json_encode($categoriesArr) ?>;
    let selectedStatusType = [];
    let productIndex = 0;
    let destinationIndex = 0;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';
    let productOptionsList = <?= json_encode($productOptionsArr) ?>;
    let currentCustomerUserType = 'b2b';
    let orderCustomerPaymentStatus = '';
    let orderCustomerPaymentDetails = '';

    function initializeOrderCustomerSelects() {
        $('#customerId').select2({
            dropdownParent: $('#addOrderReceivedModal'),
            width: '100%',
            placeholder: 'Search active customer...',
            minimumInputLength: 0,
            ajax: {
                url: 'ajax.php', type: 'POST', dataType: 'json', delay: 200,
                data: params => ({
                    searchActiveCustomersForOrder: '1',
                    term: params.term || '',
                    page: params.page || 1
                }),
                processResults: (response, params) => {
                    params.page = params.page || 1;
                    return {
                        results: Array.isArray(response.results) ? response.results : [],
                        pagination: { more: !!(response.pagination && response.pagination.more) }
                    };
                }
            }
        });
        $('#proformaInvoice').select2({
            dropdownParent: $('#addOrderReceivedModal'),
            width: '100%',
            placeholder: 'No PI / search customer PI...',
            allowClear: true,
            minimumInputLength: 0,
            ajax: {
                url: 'ajax.php', type: 'POST', dataType: 'json', delay: 200,
                data: params => ({
                    searchCustomerProformaInvoices: '1',
                    customer_id: $('#customerId').val() || 0,
                    term: params.term || ''
                }),
                processResults: response => ({ results: Array.isArray(response.results) ? response.results : [] })
            },
            templateResult: function (pi) {
                if (pi.loading) return pi.text;
                const validity = pi.validity_date || 'Not set';
                return $(`<div><div class="font-semibold text-slate-800"></div><div class="text-xs text-slate-500"></div></div>`)
                    .find('div:first').text(`${pi.number || pi.text} (${pi.source || ''})`).end()
                    .find('div:last').text(`Date: ${pi.date || '-'} | Value: ${Number(pi.value || 0).toLocaleString()} | Validity: ${validity} | Status: ${pi.invoice_status || '-'}`).end();
            },
            templateSelection: pi => pi.number || pi.text || ''
        });
    }

    function updatePaymentOverrideVisibility() {
        const changed = String($('#paymentStatus').val() || '') !== String(orderCustomerPaymentStatus)
            || String($('#paymentStatusDetails').val() || '').trim() !== String(orderCustomerPaymentDetails || '').trim();
        $('#paymentOverrideReasonWrapper').toggleClass('d-none', !changed);
        $('#paymentOverrideReason').prop('required', changed);
    }

    $(document).on('change', '#customerId', function () {
        const customerId = Number($(this).val() || 0);
        $('#proformaInvoice').val(null).trigger('change').prop('disabled', !customerId);
        $('#piSelectionDetails').text(customerId ? 'All PIs linked to this customer are selectable.' : 'Select a customer first.');
        if (!customerId) {
            $('#orderCustomerDetails').addClass('hidden');
            return;
        }
        $.ajax({
            url: 'ajax.php', type: 'POST', dataType: 'json',
            data: { getOrderCustomerDetails: '1', customer_id: customerId },
            success: function (response) {
                if (response.status !== 'success') {
                    toastr.error(response.message || 'Unable to load customer details.');
                    return;
                }
                const customer = response.customer || {};
                if (customer.user_type) {
                    currentCustomerUserType = String(customer.user_type).toLowerCase();
                    refreshAllLineItemPrices();
                }
                $('[data-customer-field="address"]').text(customer.address || '-');
                $('[data-customer-field="gstin"]').text(customer.gstin || '-');
                $('[data-customer-field="pan"]').text(customer.pan || '-');
                $('[data-customer-field="state_code_display"]').text([customer.state, customer.state_code].filter(Boolean).join(' / ') || '-');
                $('[data-customer-field="contact_display"]').text([customer.contact_person, customer.phone].filter(Boolean).join(' / ') || '-');
                $('[data-customer-field="email"]').text(customer.email || '-');
                $('#areaCity').val(customer.city || '');
                orderCustomerPaymentStatus = String(customer.payment_status || '');
                orderCustomerPaymentDetails = String(customer.payment_details || '');
                $('#paymentStatus').val(orderCustomerPaymentStatus).trigger('change.select2');
                $('#paymentStatusDetails').val(orderCustomerPaymentDetails);
                $('#paymentRemarkWrapper').removeClass('d-none');
                const missing = Array.isArray(response.missing_fields) ? response.missing_fields : [];
                $('#customerValidationBadge').text(missing.length ? 'INCOMPLETE' : 'VALID')
                    .toggleClass('bg-emerald-50 text-emerald-700', !missing.length)
                    .toggleClass('bg-amber-50 text-amber-700', !!missing.length);
                if (missing.length) {
                    const linkHtml = `<a href="index.php?page=customer-management&edit_customer_id=${customerId}" class="fillCustomerDetailsBtn text-xs font-bold text-amber-900 underline hover:text-amber-950 ms-1.5 inline-flex items-center gap-1 cursor-pointer" data-id="${customerId}"><i class="ti ti-edit text-xs"></i> fill customer details</a>`;
                    $('#customerMissingFields').removeClass('hidden').html(`Complete in Customer Master: ${missing.join(', ')}. ${linkHtml}`);
                } else {
                    $('#customerMissingFields').addClass('hidden').empty();
                }
                $('#orderCustomerDetails').removeClass('hidden');
                updatePaymentOverrideVisibility();
            }
        });
    });

    $(document).on('select2:select', '#proformaInvoice', function (event) {
        const pi = event.params.data || {};
        $('#piSelectionDetails').text(`Date: ${pi.date || '-'} | Value: ${Number(pi.value || 0).toLocaleString()} | Validity: ${pi.validity_date || 'Not set'} | Status: ${pi.invoice_status || '-'}`);
    });
    $(document).on('select2:clear', '#proformaInvoice', function () {
        $('#piSelectionDetails').text('No PI selected; this order will proceed without one.');
    });

    function buildCategorySelectOptions() {
        let catHtml = '<option value="">---Select Category---</option>';
        if (Array.isArray(categoriesList)) {
            categoriesList.forEach(cat => {
                let escapedName = $('<div>').text(cat.name).html();
                catHtml += `<option value="${cat.id}">${escapedName}</option>`;
            });
        }
        return catHtml;
    }

    function buildProductSelectOptionsForCategory(catId) {
        let selectHtml = '<option value="">---Select Product---</option>';
        let filtered = productOptionsList.filter(p => !catId || p.category_id == catId);
        filtered.forEach(prod => {
            let codeStr = prod.product_code ? ` (${prod.product_code})` : '';
            let label = prod.product_name + codeStr;
            let escapedLabel = $('<div>').text(label).html();
            selectHtml += `<option value="${prod.id}" data-unit="${prod.unit_id || ''}" data-b2b="${prod.b2b_price || 0}" data-b2c="${prod.b2c_price || 0}">${escapedLabel}</option>`;
        });
        return selectHtml;
    }

    function buildProductSelectOptions() {
        return buildProductSelectOptionsForCategory('');
    }

    function populateExistingOrderProductSelects() {
        $('#productsListEdit .inventory-product-edit-select').each(function () {
            const $select = $(this);
            const selectedId = String($select.data('selected') || '');
            $select.html(buildProductSelectOptions()).val(selectedId);
        });
    }

    function refreshAllLineItemPrices() {
        $('#productsList .product-row').each(function () {
            const $opt = $(this).find('.product-select option:selected');
            if ($opt.length && $opt.val()) {
                const b2b = parseFloat($opt.data('b2b')) || 0;
                const b2c = parseFloat($opt.data('b2c')) || 0;
                const price = (currentCustomerUserType === 'b2c' && b2c > 0) ? b2c : b2b;
                $(this).find('.product-unit-rate').text(price.toFixed(2));
                $(this).find('.product-rate-input').val(price);
                $(this).find('.product-rate-tier').text(`(${currentCustomerUserType.toUpperCase()})`);
                recalculateRowTotal($(this));
            }
        });
    }

    function recalculateRowTotal($row) {
        const qty = parseFloat($row.find('.product-qty').val()) || 0;
        const rate = parseFloat($row.find('.product-rate-input').val()) || 0;
        const subtotal = qty * rate;
        $row.find('.product-subtotal').text(subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
        recalculateOrderTotal();
    }

    function recalculateOrderTotal() {
        let total = 0;
        let hasPricedItems = false;
        $('#productsList .product-row').each(function () {
            const qty = parseFloat($(this).find('.product-qty').val()) || 0;
            const rate = parseFloat($(this).find('.product-rate-input').val()) || 0;
            if (rate > 0 && qty > 0) {
                total += (qty * rate);
                hasPricedItems = true;
            }
        });
        if (hasPricedItems) {
            $('#orderValue').val(total.toFixed(2));
        }
    }

    function loadStandardUnit() {
        $.ajax({
            url: 'ajax.php', method: 'POST', dataType: 'json',
            data: { getQtyUnits: 'getQtyUnits' },
            success: function (response) { qtyUnitOptions = response; },
            error: function (xhr, status, error) { console.error("Failed to load qty units:", error); }
        });
    }

    function loadOrderReceivedTable(page = 1) {
        currentPage = page;
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#fromDate').val();
        const toDate = $('#toDate').val();

        $('#orderReceivedTableBody').html('<tr><td colspan="11" class="px-6 py-10 text-center"><div class="spinner-border text-emerald-700" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: 'ajax.php', method: 'POST',
            data: {
                loadOrderReceived: 'loadOrderReceived', page: page, per_page: perPage,
                search: search, fromDate: fromDate, toDate: toDate,
                statusType: selectedStatusType, sort_column: currentSortColumn, sort_order: currentSortOrder
            },
            success: function (response) {
                $('#orderReceivedTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                const totalRows = Number(response.total_rows || 0);
                const visibleRows = $('#orderReceivedTableBody tr').length;
                const perPageVal = perPage === 'all' ? totalRows : parseInt(perPage);
                const shownThrough = totalRows > 0 ? Math.min(((currentPage - 1) * perPageVal) + visibleRows, totalRows) : 0;
                $('#orderPaginationSummary').text(`Showing ${shownThrough} results of ${totalRows}`);
            },
            error: function () {
                $('#orderReceivedTableBody').html('<tr><td colspan="11" class="px-6 py-10 text-center text-sm font-semibold text-rose-600">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
                $('#orderPaginationSummary').text('Showing 0 results of 0');
            }
        });
    }

    $(document).ready(function () {
        $(".status-filter").prop("checked", true);
        selectedStatusType = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") selectedStatusType.push($(this).val());
        });
        loadOrderReceivedTable();
        loadStandardUnit();

        $('#searchProducts').on('input', function () { loadOrderReceivedTable(1); });
        $('#perPageSelect').on('change', function () { loadOrderReceivedTable(1); });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadOrderReceivedTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.order-received-per-page-item', function () {
            const val = $(this).data('val');
            $('#orderReceivedPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        $('#fromDate').on('change', function () { loadOrderReceivedTable(1); });
        $('#toDate').on('change', function () { loadOrderReceivedTable(1); });

        $('#addOrderReceivedModal').on('hidden.bs.modal', function () {
            $('#addOrderReceivedForm')[0].reset();
            $('#customerId, #proformaInvoice').val(null).trigger('change');
            $('#proformaInvoice').prop('disabled', true);
            $('#orderCustomerDetails').addClass('hidden');
            orderCustomerPaymentStatus = '';
            orderCustomerPaymentDetails = '';
            $('#productsList').empty();
            $('#orderTypekWrapper').addClass('d-none');
            $('#orderTypeDetails').removeAttr('required');
            $('#paymentRemarkWrapper').addClass('d-none');
            $('#paymentStatusDetails').removeAttr('required');
            $('#paymentOverrideReasonWrapper').addClass('d-none');
            $('#paymentOverrideReason').removeAttr('required');
        });

        $('#addOrderReceivedModalBtn').on('click', function () {
            $('#addOrderReceivedModal').modal('show');
            $('#addProductBtn').trigger('click');
        });

        $("#orderType").on('change', function () {
            const checkConstantDdl = <?php echo Constant::ORDER_RECEIVED['ORDER_TYPE_OPTIONS_LABEL']['Other']; ?>;
            if ($(this).val() == checkConstantDdl) {
                $("#orderTypekWrapper").removeClass('d-none');
                $('#orderTypeDetails').attr('required', true);
            } else {
                $("#orderTypekWrapper").addClass('d-none');
                $('#orderTypeDetails').removeAttr('required');
            }
        });

        $("#paymentStatus").on('change', function () {
            const checkDdl = <?php echo Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM_LABEL']['Other']; ?>;
            if ($(this).val() == checkDdl) {
                $("#paymentRemarkWrapper").removeClass('d-none');
                $('#paymentStatusDetails').attr('required', true);
            } else {
                if (!orderCustomerPaymentDetails) {
                    $("#paymentRemarkWrapper").addClass('d-none');
                }
                $('#paymentStatusDetails').removeAttr('required');
            }
            updatePaymentOverrideVisibility();
        });
        $('#paymentStatusDetails').on('input', updatePaymentOverrideVisibility);

        $('#addProductBtn').click(function () {
            let unitOptionsHtml = '<option value="">---Select Unit---</option>';
            if (Array.isArray(qtyUnitOptions)) {
                qtyUnitOptions.forEach(unit => {
                    let uVal = unit.id || unit.key;
                    let uLabel = unit.label || unit.value;
                    unitOptionsHtml += `<option value="${uVal}">${uLabel}</option>`;
                });
            }
            let categoryOptions = buildCategorySelectOptions();

            const productRow = `
            <div class="row align-items-center mb-2 product-row mx-0 bg-white p-2.5 rounded-xl border border-slate-200/80 shadow-sm" data-index="${productIndex}">
                <div class="col-md-3 mb-1">
                    <label class="text-[11px] font-semibold text-slate-600 mb-1 d-block">Category <strong class="text-rose-500">*</strong></label>
                    <select name="productCategory[]" class="input-theme select2 category-select" required>
                        ${categoryOptions}
                    </select>
                </div>
                <div class="col-md-4 mb-1">
                    <label class="text-[11px] font-semibold text-slate-600 mb-1 d-block">Product <strong class="text-rose-500">*</strong></label>
                    <select name="productName[]" class="input-theme select2 product-select" required disabled>
                        <option value="">--Select Category First--</option>
                    </select>
                </div>
                <div class="col-md-2 mb-1">
                    <label class="text-[11px] font-semibold text-slate-600 mb-1 d-block">Quantity <strong class="text-rose-500">*</strong></label>
                    <input type="number" min="0" step="any" name="productQuantity[]" class="form-control input-theme product-qty" placeholder="Quantity" required />
                </div>
                <div class="col-md-2 mb-1">
                    <label class="text-[11px] font-semibold text-slate-600 mb-1 d-block">Unit <strong class="text-rose-500">*</strong></label>
                    <select name="productUnit[]" class="input-theme select2 unit-select" required>
                        ${unitOptionsHtml}
                    </select>
                </div>
                <div class="col-md-1 mb-1 text-end pt-3">
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 removeProductBtn cursor-pointer" title="Remove Product">
                        <span class="ti ti-trash text-lg"></span>
                    </button>
                </div>
                <div class="col-12 mt-1 pt-1.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <div class="flex items-center gap-2">
                        <span class="inline-flex items-center gap-1 font-medium text-slate-700">
                            Rate: ₹<span class="product-unit-rate">0.00</span>
                            <span class="text-[10px] text-slate-400 product-rate-tier">(${currentCustomerUserType.toUpperCase()})</span>
                        </span>
                        <input type="hidden" name="productRate[]" class="product-rate-input" value="0">
                    </div>
                    <div class="font-semibold text-emerald-700">Subtotal: ₹<span class="product-subtotal">0.00</span></div>
                </div>
            </div>`;
            $('#productsList').append(productRow);
            const $lastRow = $('#productsList').find('.product-row').last();
            $lastRow.find('.select2').select2({ dropdownParent: $('#addOrderReceivedModal') });
            productIndex++;
        });

        $(document).on('change', '.category-select', function () {
            const catId = $(this).val();
            const $row = $(this).closest('.product-row');
            const $prodSelect = $row.find('.product-select');
            if (catId) {
                const prodHtml = buildProductSelectOptionsForCategory(catId);
                $prodSelect.html(prodHtml).prop('disabled', false).trigger('change');
            } else {
                $prodSelect.html('<option value="">--Select Category First--</option>').prop('disabled', true).trigger('change');
            }
        });

        $(document).on('change', '.product-select', function () {
            const $row = $(this).closest('.product-row');
            const selectedOpt = $(this).find('option:selected');
            const unitId = selectedOpt.data('unit');
            if (unitId) {
                const $unitSelect = $row.find('.unit-select');
                if ($unitSelect.length) {
                    $unitSelect.val(unitId).trigger('change');
                }
            }
            const b2b = parseFloat(selectedOpt.data('b2b')) || 0;
            const b2c = parseFloat(selectedOpt.data('b2c')) || 0;
            const price = (currentCustomerUserType === 'b2c' && b2c > 0) ? b2c : b2b;
            $row.find('.product-unit-rate').text(price.toFixed(2));
            $row.find('.product-rate-input').val(price);
            $row.find('.product-rate-tier').text(`(${currentCustomerUserType.toUpperCase()})`);
            recalculateRowTotal($row);
        });

        $(document).on('input change', '.product-qty', function () {
            recalculateRowTotal($(this).closest('.product-row'));
        });

        $('#productsList').on('click', '.removeProductBtn', function () {
            $(this).closest('.product-row').remove();
            recalculateOrderTotal();
        });

        // Multi-Location Dispatch Listeners (Item 7.3)
        $('#locationMap').on('change', function () {
            if ($(this).val() == '2') {
                $('#multiLocationDispatchSection').removeClass('hidden');
                if ($('#locationDestinationsList .destination-row').length === 0) {
                    $('#addLocationDestinationBtn').trigger('click');
                }
            } else {
                $('#multiLocationDispatchSection').addClass('hidden');
            }
        });

        $('#addLocationDestinationBtn').on('click', function () {
            destinationIndex++;
            const currentCount = $('#locationDestinationsList .destination-row').length + 1;
            const destHtml = `
            <div class="destination-row bg-white rounded-xl border border-blue-200 p-3 shadow-xs space-y-2 mb-2" data-index="${destinationIndex}">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                        <span class="inline-flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-800 text-[11px] font-extrabold">${currentCount}</span>
                        Destination Facility / Consignee
                    </span>
                    <button type="button" class="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 removeDestinationBtn cursor-pointer" title="Remove Destination">
                        <i class="ti ti-trash text-sm"></i>
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <div>
                        <label class="text-[11px] font-semibold text-slate-600 mb-0.5 d-block">Facility / Location Name <strong class="text-rose-500">*</strong></label>
                        <input type="text" name="dest_location_name[]" class="form-control input-theme text-xs" placeholder="e.g. North Branch / Main Hospital" required />
                    </div>
                    <div>
                        <label class="text-[11px] font-semibold text-slate-600 mb-0.5 d-block">Contact Person & Phone</label>
                        <input type="text" name="dest_contact[]" class="form-control input-theme text-xs" placeholder="e.g. Dr. Verma - 9876543210" />
                    </div>
                </div>
                <div>
                    <label class="text-[11px] font-semibold text-slate-600 mb-0.5 d-block">Delivery / Shipping Address <strong class="text-rose-500">*</strong></label>
                    <textarea name="dest_address[]" rows="2" class="form-control input-theme text-xs" placeholder="Enter complete destination address, city, state, pin code" required></textarea>
                </div>
                <div>
                    <label class="text-[11px] font-semibold text-slate-600 mb-0.5 d-block">Quantity Allocation / Notes</label>
                    <input type="text" name="dest_notes[]" class="form-control input-theme text-xs" placeholder="e.g. 50 kits Test A, 20 kits Test B" />
                </div>
            </div>`;
            $('#locationDestinationsList').append(destHtml);
        });

        $(document).on('click', '.removeDestinationBtn', function () {
            $(this).closest('.destination-row').remove();
            $('#locationDestinationsList .destination-row').each(function (idx) {
                $(this).find('.rounded-full').text(idx + 1);
            });
        });

        $('#addOrderReceivedForm').on('submit', function (e) {
            e.preventDefault();
            const form = document.getElementById('addOrderReceivedForm');
            const formData = new FormData(form);
            formData.append('addOrderReceived', 'addOrderReceived');
            $.ajax({
                url: 'ajax.php', type: 'POST', data: formData, dataType: 'json', contentType: false, processData: false,
                success: function (response) {
                    let res; try { res = typeof response === 'object' ? response : JSON.parse(response); } catch (e) { toastr.error('Invalid response.'); return; }
                    if (res.status === 'success') {
                        $('#addOrderReceivedModal').modal('hide');
                        $('#addOrderReceivedForm')[0].reset();
                        loadOrderReceivedTable();
                        toastr.success(res.message);
                    } else { toastr.error(res.message || 'Unexpected response.'); }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Unable to submit the order. Please review the form and try again.');
                }
            });
        });

        $(document).on('click', '.export-type-item', function () {
            const val = $(this).data('val');
            $('#exportTypeSelect').val(val);
            $('#exportTypeText').text($(this).text());
        });

        $(document).on('click', '#deselectAllColumnsBtn', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('.column-filter').prop('checked', false);
                $(this).text('Select All');
            } else {
                $('.column-filter').prop('checked', true);
                $(this).text('Deselect All');
            }
        });

        $(document).on('change', '.column-filter', function() {
            const isAllSelected = $('.column-filter:checked').length === $('.column-filter').length;
            if (isAllSelected) {
                $('#deselectAllColumnsBtn').text('Deselect All');
            } else {
                $('#deselectAllColumnsBtn').text('Select All');
            }
        });

        function updateColumnsText() {
            const count = $('.column-filter:checked').length;
            $('#columnsSelectedText').text(count > 0 ? count + ' Columns' : 'Columns');
        }
        $(document).on('change', '.column-filter', function () { updateColumnsText(); });
        updateColumnsText();

        $('#orderType, #locationMap, #dispatchTimeline, #paymentStatus').select2({ dropdownParent: $('#addOrderReceivedModal') });
        initializeOrderCustomerSelects();
        $('#orderStatus').select2({ dropdownParent: $('#updateStatusOrderReceivedModal') });
    });

    $(document).on('change', '#orderTypeEdit', function () {
        const checkConstantDdl = <?php echo Constant::ORDER_RECEIVED['ORDER_TYPE_OPTIONS_LABEL']['Other']; ?>;
        if ($(this).val() == checkConstantDdl) {
            $("#orderTypekWrapperEdit").removeClass('d-none');
            $('#orderTypeDetailsEdit').attr('required', true);
        } else {
            $("#orderTypekWrapperEdit").addClass('d-none');
            $('#orderTypeDetailsEdit').removeAttr('required');
        }
    });

    $(document).on('change', '#paymentStatusEdit', function () {
        const checkDdl = <?php echo Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM_LABEL']['Other']; ?>;
        if ($(this).val() == checkDdl) {
            $("#paymentRemarkWrapperEdit").removeClass('d-none');
            $('#paymentStatusDetailsEdit').attr('required', true);
        } else {
            $("#paymentRemarkWrapperEdit").addClass('d-none');
            $('#paymentStatusDetailsEdit').removeAttr('required');
        }
    });

    function initializeOrderEditPiSelect() {
        const select = $('#proformaInvoiceEdit');
        if (!select.length) return;
        if (select.hasClass('select2-hidden-accessible')) select.select2('destroy');
        select.select2({
            dropdownParent: $('#editOrderReceivedModal'), width: '100%', allowClear: true,
            placeholder: 'No PI / search customer PI...', minimumInputLength: 0,
            ajax: {
                url: 'ajax.php', type: 'POST', dataType: 'json', delay: 200,
                data: params => ({ searchCustomerProformaInvoices: '1', customer_id: $('#customerIdEdit').val() || 0, term: params.term || '' }),
                processResults: response => ({ results: Array.isArray(response.results) ? response.results : [] })
            },
            templateResult: pi => pi.loading ? pi.text : `${pi.number || pi.text} | ${pi.date || '-'} | ${Number(pi.value || 0).toLocaleString()} | ${pi.validity_date || 'No validity'} | ${pi.invoice_status || '-'}`,
            templateSelection: pi => pi.number || pi.text || ''
        });
    }

    $(document).on('change', '#customerIdEdit', function () {
        $('#proformaInvoiceEdit').val(null).trigger('change');
        const customerId = Number($(this).val() || 0);
        if (!customerId) return;
        $.ajax({
            url: 'ajax.php', type: 'POST', dataType: 'json',
            data: { getOrderCustomerDetails: '1', customer_id: customerId },
            success: function (response) {
                if (response.status !== 'success') return;
                const customer = response.customer || {};
                $('#areaCityEdit').val(customer.city || '');
                $('#paymentStatusEdit').val(String(customer.payment_status || '')).trigger('change');
                $('#paymentStatusDetailsEdit').val(customer.payment_details || '');
                $('#paymentOverrideReasonEdit').val('');
                $('#paymentRemarkWrapperEdit').removeClass('d-none');
                const missing = Array.isArray(response.missing_fields) ? response.missing_fields : [];
                if (missing.length) {
                    const linkHtml = `<a href="index.php?page=customer-management&edit_customer_id=${customerId}" class="fillCustomerDetailsBtn text-xs font-bold text-amber-900 underline hover:text-amber-950 ms-1 inline-flex items-center gap-1 cursor-pointer" data-id="${customerId}"><i class="ti ti-edit text-xs"></i> fill customer details</a>`;
                    toastr.warning('Complete in Customer Master: ' + missing.join(', ') + '. ' + linkHtml);
                }
            }
        });
    });

    $(document).on('click', '.fillCustomerDetailsBtn', function (e) {
        e.preventDefault();
        const custId = $(this).data('id') || $('#customerId').val() || $('#customerIdEdit').val() || 0;
        $('.modal').modal('hide');
        window.location.href = `index.php?page=customer-management&edit_customer_id=${custId}`;
    });

    $(document).on('click', '.viewOrderReceivedModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { viewOrderReceivedRecord: 'viewOrderReceivedRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewOrderReceivedModel').modal('show');
                        $('#viewOrderReceived').find('.modal-body').html(res.data);
                    } else { toastr.error(res.message || 'Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });

    $(document).on('click', '.orderReceivedDeleteBtn', function () {
        let id = $(this).data('id');
        if (!id) { Swal.fire({ icon: 'error', title: 'Invalid ID', text: 'Invalid order ID provided.', customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); return; }
        Swal.fire({
            title: 'Are you sure?', text: "You won't be able to revert this!", icon: 'warning',
            showCancelButton: true, confirmButtonText: 'Yes, delete it!', cancelButtonText: 'Cancel',
            customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white', cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700' },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php', type: 'POST',
                    data: { deleteOrderReceivedRecord: 'deleteOrderReceivedRecord', id: id }, dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadOrderReceivedTable();
                            Swal.fire({ icon: 'success', title: 'Deleted!', text: res.message, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white' } });
                        } else {
                            Swal.fire({ icon: 'error', title: 'Failed!', text: res.message, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
                        }
                    },
                    error: function (xhr, status, error) { Swal.fire({ icon: 'error', title: 'Server Error', text: error, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); }
                });
            }
        });
    });

    $(document).on('click', '#addProductAtEditBtn', function () {
        let optionsHtml = '<option value="">---Select----</option>';
        qtyUnitOptions.forEach(unit => { optionsHtml += `<option value="${unit.id}">${unit.label}</option>`; });
        const editProductOptions = buildProductSelectOptions();
        const productRow = `
            <div class="row align-items-end mb-2 product-row border rounded shadow-sm p-2" data-index="${productIndex}">
                <div class="col-md-6 mb-1">
                    <label class="form-label">Product Name</label>
                    <input type="hidden" name="productIdEdit[]" value="" />
                    <select name="inventoryProductIdEdit[]" class="input-theme select2 product-select" required>${editProductOptions}</select>
                </div>
                <div class="col-md-3 mb-1">
                    <label class="form-label">Quantity</label>
                    <input type="number" min="0" name="productQuantityEdit[]" class="form-control" placeholder="Quantity" required />
                </div>
                <div class="col-md-3 mb-1">
                    <label class="form-label">Select Unit</label>
                    <select name="productUnitEdit[]" class="input-theme select2" required>${optionsHtml}</select>
                </div>
                <div class="col-md-3 mb-1">
                    <label class="form-label">Status</label>
                    <input type="hidden" name="productStatusEdit[]" value="0">
                    <input type="text" class="input-theme bg-slate-100" value="Pending (system managed)" readonly>
                </div>
                <div class="col-md-8 mb-1">
                    <label class="form-label">Remark</label>
                    <textarea name="productRemarkEdit[]" rows="1" class="input-theme w-full" placeholder="Enter Remark"></textarea>
                </div>
                <div class="col-md-1 mb-1">
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-rose-50 text-rose-700 hover:bg-rose-100 deleteSubProductFromOrder" data-id="">
                        <span class="ti ti-trash text-base"></span>
                    </button>
                </div>
            </div>`;
        $('#productsListEdit').append(productRow);
        $('#productsListEdit .product-row').last().find('.select2').select2({ dropdownParent: $('#editOrderReceivedModal') });
        productIndex++;
    });

    $('#editOrderReceivedForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editOrderReceivedForm');
        const formData = new FormData(form);
        formData.append('updateOrderReceivedRecord', 'updateOrderReceivedRecord');
        $.ajax({
            url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (response) {
                let res; try { res = typeof response === 'object' ? response : JSON.parse(response); } catch (e) { toastr.error('Invalid response.'); return; }
                if (res.status === 'success') {
                    $('#editOrderReceivedModal').modal('hide');
                    loadOrderReceivedTable();
                    toastr.success(res.message);
                } else { toastr.error(res.message || 'Unexpected response.'); }
            },
            error: function () { toastr.error('Server error occurred.'); }
        });
    });

    $(document).on('click', '.deleteSubProductFromOrder', function () {
        let id = $(this).data('id');
        let buttonClicked = $(this);
        if (!id) {
            Swal.fire({ icon: 'error', title: 'Invalid ID', text: 'Invalid product ID provided.', customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
            return;
        }
        Swal.fire({
            title: 'Are you sure?', text: "You won't be able to revert this!", icon: 'warning',
            showCancelButton: true, confirmButtonText: 'Yes, delete it!', cancelButtonText: 'Cancel',
            customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white', cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700' },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php', type: 'POST',
                    data: { deleteOrderReceivedSubProductRecord: 'deleteOrderReceivedSubProductRecord', id: id }, dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Deleted!', text: res.message, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white' } });
                            buttonClicked.closest('.product-row').remove();
                        } else {
                            Swal.fire({ icon: 'error', title: 'Failed!', text: res.message, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
                        }
                    },
                    error: function (xhr, status, error) { Swal.fire({ icon: 'error', title: 'Server Error', text: error, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } }); }
                });
            }
        });
    });

    $(document).on('click', '.updateStatusOrderReceivedModalBtn', function () {
        let id = $(this).data('id');
        if (id) { $('#orderEditId').val(id); $('#updateStatusOrderReceivedModal').modal('show'); }
    });

    $("#updateStatusOrderReceivedForm").on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('updateStatusOrderReceivedForm');
        const formData = new FormData(form);
        formData.append('updateOrderReceivedStatusRecord', 'updateOrderReceivedStatusRecord');
        $.ajax({
            url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (response) {
                let res; try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response.'); return; }
                if (res.status === 'success') {
                    $('#updateStatusOrderReceivedModal').modal('hide');
                    loadOrderReceivedTable();
                    toastr.success(res.message);
                } else { toastr.error(res.message || 'Unexpected response.'); }
            },
            error: function () { toastr.error('Server error occurred.'); }
        });
    });

    $(document).on('click', '.editOrderReceivedModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { fetchOrderReceivedRecord: 'fetchOrderReceivedRecord', id: id },
                success: function (response) {
                    let res; try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response.'); return; }
                    if (res.status === 'success') {
                        // Reset modal header details
                        $('#editOrderReceivedModal .modal-title').text('Edit Order');
                        $('#editOrderReceivedModal .modal-header p').text('Update order details');
                        // Remove confirmReview hidden input if exists
                        let modalForm = $('#editOrderReceivedForm');
                        modalForm.find('input[name="confirmReview"]').remove();
                        // Reset submit button text/class
                        let submitBtn = modalForm.find('button[type="submit"]');
                        submitBtn.html('<i class="ti ti-check text-lg"></i> Update');
                        submitBtn.removeClass('bg-success hover:bg-success-dark').addClass('bg-emerald-700 hover:bg-emerald-800');

                        $('#editOrderReceivedModal').modal('show');
                        modalForm.find('.modal-body').html(res.data);
                        populateExistingOrderProductSelects();
                        $('#editOrderReceivedForm .select2').select2({ dropdownParent: $('#editOrderReceivedModal') });
                        initializeOrderEditPiSelect();
                    } else { toastr.error(res.message || 'Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });

    $(document).on('click', '.confirmOrderReceivedModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { fetchOrderReceivedRecord: 'fetchOrderReceivedRecord', id: id },
                success: function (response) {
                    let res; try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response.'); return; }
                    if (res.status === 'success') {
                        // Modify modal header details
                        $('#editOrderReceivedModal .modal-title').text('Review & Confirm Order Details');
                        $('#editOrderReceivedModal .modal-header p').text('Verify WhatsApp/Email synced order before approval');
                        // Add hidden confirmReview input
                        let modalForm = $('#editOrderReceivedForm');
                        modalForm.find('input[name="confirmReview"]').remove();
                        modalForm.append('<input type="hidden" name="confirmReview" value="1" />');
                        // Modify submit button text/class
                        let submitBtn = modalForm.find('button[type="submit"]');
                        submitBtn.html('<i class="ti ti-circle-check text-lg"></i> Confirm & Approve Order');
                        submitBtn.removeClass('bg-emerald-700 hover:bg-emerald-800').addClass('bg-success hover:bg-success-dark');

                        $('#editOrderReceivedModal').modal('show');
                        modalForm.find('.modal-body').html(res.data);
                        populateExistingOrderProductSelects();
                        $('#editOrderReceivedForm .select2').select2({ dropdownParent: $('#editOrderReceivedModal') });
                        initializeOrderEditPiSelect();
                    } else { toastr.error(res.message || 'Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });

    $(document).on('click', 'th.sortable', function () {
        const column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        $(this).addClass(currentSortOrder.toLowerCase());
        loadOrderReceivedTable(1);
    });

    $(document).on('change', '.status-filter', function () {
        const isAll = $(this).val() === "all";
        if (isAll) {
            const allChecked = $(this).is(":checked");
            $(".status-filter").prop("checked", allChecked);
        }
        selectedStatusType = [];
        $(".status-filter:checked").each(function () {
            if ($(this).val() !== "all") selectedStatusType.push($(this).val());
        });
        loadOrderReceivedTable();
    });

    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $('#orderManagementExportForm').on('submit', function (e) {
        e.preventDefault();
        const search = $('#searchProducts').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#fromDate').val();
        const toDate = $('#toDate').val();
        const form = document.getElementById('orderManagementExportForm');
        const formData = new FormData(form);
        formData.append('exportOrdMgmtManual', 'exportOrdMgmtManual');
        formData.append('search', search);
        formData.append('perPage', perPage);
        formData.append('page', 1);
        formData.append('fromDate', fromDate);
        formData.append('toDate', toDate);
        selectedStatusType.forEach(function (status) {
            formData.append('statusType[]', status);
        });
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
        $.ajax({
            url: 'exportajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else { toastr.error(response.message); }
            },
            error: function () { toastr.error('Server error occurred.'); }
        });
    });

    $(document).on('click', '.updateStatusOrderReceivedSpecificModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $.ajax({
                url: 'ajax.php', type: 'POST',
                data: { fetchOrderReceivedSpecificStatusRecord: 'fetchOrderReceivedSpecificStatusRecord', id: id },
                success: function (response) {
                    let res; try { res = JSON.parse(response); } catch (e) { toastr.error('Invalid response.'); return; }
                    if (res.status === 'success') {
                        $('#editOrderReceivedStatusSpecificModal').modal('show');
                        $('#editOrderReceivedStatusSpecificForm').find('.modal-body').html(res.data);
                    } else { toastr.error(res.message || 'Unexpected response.'); }
                },
                error: function () { toastr.error('Server error occurred.'); }
            });
        }
    });

    $("#editOrderReceivedStatusSpecificForm").on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('editOrderReceivedStatusSpecificForm');
        const formData = new FormData(form);
        formData.append('updateOrderReceivedStatusSpecificRecord', 'updateOrderReceivedStatusSpecificRecord');
        $.ajax({
            url: 'ajax.php', type: 'POST', data: formData, contentType: false, processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#editOrderReceivedStatusSpecificModal').modal('hide');
                    loadOrderReceivedTable();
                    toastr.success(res.message);
                } else { toastr.error(res.message || 'Unexpected response.'); }
            },
            error: function () { toastr.error('Server error occurred.'); }
        });
    });


    // New Incoming Orders Widget & Banner logic
    let incomingOrdersById = {};
    loadNewOrdersBanner();

    function loadNewOrdersBanner() {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadNewOrdersCount: '1' },
            success: function (res) {
                if (res.status === 'success') {
                    $('#newOrdersCount').text(res.count);
                }
            }
        });
    }

    function syncIncomingOrderSelection() {
        const $eligible = $('.incoming-order-select:not(:disabled)');
        const selectedCount = $eligible.filter(':checked').length;
        $('#sendSelectedIncomingOrdersBtn').prop('disabled', selectedCount === 0);
        $('#selectAllIncomingOrders').prop('checked', $eligible.length > 0 && selectedCount === $eligible.length);
        $('#selectAllIncomingOrders').prop('indeterminate', selectedCount > 0 && selectedCount < $eligible.length);
    }

    $(document).on('click', '#verifyStockProcessBtn', function () {
        refreshNewIncomingOrdersModal();
    });

    function refreshNewIncomingOrdersModal() {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadNewIncomingOrdersList: '1' },
            success: function (res) {
                if (res.status === 'success') {
                    let html = '';
                    incomingOrdersById = {};
                    if (res.data.length > 0) {
                        res.data.forEach(function (row) {
                            incomingOrdersById[String(row.id)] = row;
                            let sourceLabel = '';
                            if (row.source_type == 2) sourceLabel = 'Web';
                            else if (row.source_type == 3) sourceLabel = 'Email';
                            else if (row.source_type == 4) sourceLabel = 'WhatsApp';
                            else sourceLabel = 'ERP';

                            let qtyText = parseFloat(row.total_quantity || 0).toLocaleString() + ' Units';
                            let isReady = row.stock_status === 'In Stock' || row.stock_status === 'Ready for Dispatch';
                            let stockClass = isReady
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border-rose-200';
                            let requiresApproval = [2, 3, 4].includes(Number(row.source_type));
                            let canDispatch = isReady && !requiresApproval;
                            let disabledReason = requiresApproval ? 'Approval is required before dispatch' : 'Stock is not sufficient for dispatch';
                            let approvalButton = requiresApproval
                                ? `<button type="button" class="reviewIncomingOrderBtn inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition" style="color: var(--appearance-accent, #e7952b); border-color: color-mix(in srgb, var(--appearance-accent, #e7952b) 35%, white); background: color-mix(in srgb, var(--appearance-accent, #e7952b) 9%, white);" data-id="${row.id}"><i class="ti ti-shield-check text-base"></i> Approval</button>`
                                : '';

                            html += `<tr class="newIncomingOrderRow align-middle cursor-pointer transition-colors hover:bg-slate-50/50 focus:bg-slate-50/50 focus:outline-none" data-href="index.php?page=order-detail&id=${row.id}" role="link" tabindex="0" aria-label="Open order ${row.order_number}">
                                <td class="px-4 py-4 text-center">
                                    <input type="checkbox" class="incoming-order-select h-4 w-4 rounded border-slate-300 accent-emerald-700 disabled:cursor-not-allowed disabled:opacity-40" data-id="${row.id}" aria-label="Select order ${row.order_number}" ${canDispatch ? '' : `disabled title="${disabledReason}"`}>
                                </td>
                                <td class="px-6 py-4 font-bold text-slate-900">${row.order_number}</td>
                                <td class="px-6 py-4 text-slate-600">${row.order_date}</td>
                                <td class="px-6 py-4 text-slate-600">${sourceLabel}</td>
                                <td class="px-6 py-4 text-slate-800">${row.client_name}</td>
                                <td class="px-6 py-4 text-slate-600 max-w-[200px] truncate" title="${row.products || ''}">${row.products || '-'}</td>
                                <td class="px-6 py-4 text-slate-600">${qtyText}</td>
                                <td class="px-6 py-4 text-slate-600 max-w-[200px] truncate" title="${row.delivery_address || ''}">${row.delivery_address || row.area_city || '-'}</td>
                                <td class="px-6 py-4 font-bold text-slate-900">₹${parseFloat(row.order_value || 0).toLocaleString()}</td>
                                <td class="px-6 py-4"><span class="inline-flex rounded border px-2 py-1 text-xs font-bold ${stockClass}">${row.stock_status}</span></td>
                                <td class="px-6 py-4 text-center flex items-center justify-center gap-4">
                                    ${approvalButton}
                                    <button type="button" class="text-rose-600 hover:text-rose-800 transition-colors focus:outline-none deleteIncomingOrderBtn" data-id="${row.id}">
                                        <i class="ti ti-trash text-lg"></i>
                                    </button>
                                    <a href="index.php?page=order-detail&id=${row.id}" class="text-slate-900 hover:text-emerald-700 transition-colors">
                                        <i class="ti ti-chevron-right text-lg"></i>
                                    </a>
                                </td>
                            </tr>`;
                        });
                    } else {
                        html = `<tr><td colspan="11" class="text-center py-6 text-slate-400 font-medium">No pending incoming orders.</td></tr>`;
                    }
                    $('#newIncomingOrdersListBody').html(html);
                    $('#selectAllIncomingOrders').prop({ checked: false, indeterminate: false });
                    syncIncomingOrderSelection();
                    $('#newIncomingOrdersModal').modal('show');
                }
            }
        });
    }

    $(document).on('change', '#selectAllIncomingOrders', function () {
        $('.incoming-order-select:not(:disabled)').prop('checked', this.checked);
        syncIncomingOrderSelection();
    });

    $(document).on('change', '.incoming-order-select', syncIncomingOrderSelection);

    $(document).on('click', '.reviewIncomingOrderBtn', function () {
        const row = incomingOrdersById[String($(this).data('id'))];
        if (!row) {
            toastr.error('Order details are no longer available. Please refresh the list.');
            return;
        }
        const sources = { 2: 'Website', 3: 'Email', 4: 'WhatsApp' };
        $('#approvalOrderId').val(row.id);
        $('#approvalOrderNumber').text(row.order_number || 'Order approval');
        $('#approvalOrderSource').text(sources[Number(row.source_type)] || 'External');
        $('#approvalOrderClient').text(row.client_name || '-');
        $('#approvalOrderProducts').text(row.products || '-');
        $('#approvalOrderValue').text('₹' + parseFloat(row.order_value || 0).toLocaleString());
        $('#approvalOrderStock').text(row.stock_status || '-');
        const quantityFormat = { maximumFractionDigits: 3 };
        $('#approvalOrderedQuantity').text(Number(row.ordered_quantity || 0).toLocaleString(undefined, quantityFormat) + ' units');
        $('#approvalUnreservedQuantity').text(Number(row.unreserved_stock_quantity || 0).toLocaleString(undefined, quantityFormat) + ' units');
        $('#approvalReviewReason').val('');
        $('#externalOrderApprovalModal').appendTo(document.body).modal('show');
    });

    $('#externalOrderApprovalModal').on('shown.bs.modal', function () {
        $(this).css('z-index', 1120);
        $('.modal-backdrop').last().addClass('external-order-approval-backdrop');
    }).on('hidden.bs.modal', function () {
        $('.modal-backdrop.external-order-approval-backdrop').removeClass('external-order-approval-backdrop');
        if ($('#newIncomingOrdersModal').hasClass('show')) $('body').addClass('modal-open');
    });

    function reviewIncomingExternalOrder(decision) {
        const orderId = Number($('#approvalOrderId').val());
        const reason = $('#approvalReviewReason').val().trim();
        if (!orderId) return;
        if (decision === 'REJECT' && !reason) {
            $('#approvalReviewReason').focus();
            toastr.error('Please enter a reason before rejecting the order.');
            return;
        }
        const $buttons = $('#approveExternalOrderBtn, #rejectExternalOrderBtn');
        $buttons.prop('disabled', true).addClass('opacity-60');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            dataType: 'json',
            data: { reviewIncomingExternalOrder: '1', order_id: orderId, decision: decision, reason: reason },
            success: function (res) {
                if (res.status !== 'success') {
                    toastr.error(res.message || 'Unable to review this order.');
                    return;
                }
                $('#externalOrderApprovalModal').modal('hide');
                toastr.success(res.message);
                loadNewOrdersBanner();
                loadOrderReceivedTable(1);
                refreshNewIncomingOrdersModal();
            },
            error: function (xhr) {
                const message = xhr.responseJSON && xhr.responseJSON.message
                    ? xhr.responseJSON.message
                    : 'The order review could not be completed.';
                toastr.error(message);
            },
            complete: function () {
                $buttons.prop('disabled', false).removeClass('opacity-60');
            }
        });
    }

    $(document).on('click', '#approveExternalOrderBtn', function () { reviewIncomingExternalOrder('APPROVE'); });
    $(document).on('click', '#rejectExternalOrderBtn', function () { reviewIncomingExternalOrder('REJECT'); });

    $(document).on('click', '#sendSelectedIncomingOrdersBtn', function () {
        const orderIds = $('.incoming-order-select:checked').map(function () {
            return $(this).data('id');
        }).get();
        if (!orderIds.length) return;

        Swal.fire({
            title: 'Send to Goods Dispatch?',
            text: `${orderIds.length} selected order(s) will move to the dispatch queue.`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Send to Dispatch',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'inline-flex rounded-xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white mr-2',
                cancelButton: 'inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (!result.isConfirmed) return;
            const $button = $('#sendSelectedIncomingOrdersBtn');
            const originalHtml = $button.html();
            $button.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-lg"></i> Sending...');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    sendOrderToDispatch: '1',
                    order_ids: orderIds.join(','),
                    fulfillment_notes: 'Sent from New Incoming Orders'
                },
                success: function (res) {
                    if (res.status === 'success') {
                        if (Array.isArray(res.failures) && res.failures.length) toastr.warning(res.message);
                        else toastr.success(res.message);
                        loadNewOrdersBanner();
                        loadOrderReceivedTable(1);
                        refreshNewIncomingOrdersModal();
                    } else {
                        toastr.error(res.message || 'Unable to send the selected orders to Dispatch.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred while sending orders to Dispatch.');
                },
                complete: function () {
                    $button.html(originalHtml);
                    syncIncomingOrderSelection();
                }
            });
        });
    });

    $(document).on('click keydown', '.newIncomingOrderRow', function (event) {
        if ($(event.target).closest('a, button, input, label').length) {
            return;
        }

        if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') {
            return;
        }

        event.preventDefault();
        window.location.href = $(this).data('href');
    });

    $(document).on('click', '.deleteIncomingOrderBtn', function () {
        let id = $(this).data('id');
        if (!id) {
            Swal.fire({ icon: 'error', title: 'Invalid ID', text: 'Invalid order ID provided.', customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
            return;
        }
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-zindex-fix-custom',
                confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white',
                cancelButton: 'inline-flex rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: { deleteOrderReceivedRecord: 'deleteOrderReceivedRecord', id: id },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Deleted!', text: res.message, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white' } });
                            loadNewOrdersBanner();
                            refreshNewIncomingOrdersModal();
                            loadOrderReceivedTable();
                        } else {
                            Swal.fire({ icon: 'error', title: 'Failed!', text: res.message, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({ icon: 'error', title: 'Server Error', text: error, customClass: { container: 'swal2-zindex-fix-custom', confirmButton: 'inline-flex rounded-2xl bg-rose-600 px-4 py-2 text-sm font-bold text-white' } });
                    }
                });
            }
        });
    });

    $(document).on('click', '.removeSubProductFromStatusUpdate', function () {
        $(this).closest('.product-row').remove();
    });

    // Goods Received & Reserved Widget & Modals logic (Screenshots 1, 2, 3)
    let grrDataCache = { records: [], stats: {} };
    let currentGrrSourceFilter = 'all';

    loadGoodsReceivedReservedSummary();

    function loadGoodsReceivedReservedSummary(onComplete) {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadGoodsReceivedReservedData: '1' },
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success' && res.data) {
                    grrDataCache = res.data;
                    const stats = res.data.stats || {};
                    const closedOrders = stats.closed_orders_count || 0;
                    const procuredItems = stats.procured_items_count || 0;
                    const producedBatches = stats.produced_batches_count || 0;
                    const totalRecords = stats.total_count || 0;

                    // Update Top Widget
                    $('#goodsReceivedReservedOrdersCount').text(closedOrders);

                    // Update Modal 1 Stat Cards & Badges
                    $('#grrClosedOrdersBadge').text(closedOrders);
                    $('#grrClosedOrdersCount').text(closedOrders);

                    $('#grrProcuredItemsBadge').text(procuredItems);
                    $('#grrProcuredItemsCount').text(procuredItems);

                    $('#grrProducedBatchesBadge').text(producedBatches);
                    $('#grrProducedBatchesCount').text(producedBatches);

                    // Update Filter Pills Badges
                    $('#grrFilterAllCount').text(totalRecords);
                    $('#grrFilterPoCount').text(procuredItems);
                    $('#grrFilterBmrCount').text(producedBatches);

                    renderGrrTable();
                }
                if (typeof onComplete === 'function') onComplete();
            },
            error: function () {
                if (typeof onComplete === 'function') onComplete();
            }
        });
    }

    window.openGoodsReceivedReservedModal = function () {
        loadGoodsReceivedReservedSummary(function () {
            $('#goodsReceivedReservedModal').modal('show');
        });
    };

    function renderGrrTable() {
        const records = grrDataCache.records || [];
        const searchTerm = ($('#grrSearchInput').val() || '').toLowerCase().trim();
        
        const filtered = records.filter(function (row) {
            // Source Category Filter
            if (currentGrrSourceFilter === 'procure' && row.source_category !== 'procure') return false;
            if (currentGrrSourceFilter === 'produce' && row.source_category !== 'produce') return false;

            // Search Term Filter
            if (searchTerm !== '') {
                const matchOrder = (row.order_number || '').toLowerCase().includes(searchTerm);
                const matchClient = (row.client_name || '').toLowerCase().includes(searchTerm);
                const matchItem = (row.item_name || '').toLowerCase().includes(searchTerm);
                const matchRef = (row.source_ref || '').toLowerCase().includes(searchTerm);
                if (!matchOrder && !matchClient && !matchItem && !matchRef) return false;
            }
            return true;
        });

        let html = '';
        if (filtered.length > 0) {
            filtered.forEach(function (row, idx) {
                const isPo = row.source_category === 'procure';
                const sourceBadgeClass = isPo
                    ? 'bg-blue-50 text-blue-700 border-blue-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200';

                html += `<tr class="grr-table-row cursor-pointer transition-colors hover:bg-slate-50" data-idx="${idx}" data-record='${JSON.stringify(row).replace(/'/g, "&#39;")}'>
                    <td class="px-4 py-3.5 font-bold text-slate-900">${row.order_number || '-'}</td>
                    <td class="px-4 py-3.5 font-medium text-slate-800">${row.client_name || '-'}</td>
                    <td class="px-4 py-3.5 font-medium text-slate-700">${row.item_name || '-'}</td>
                    <td class="px-4 py-3.5">
                        <span class="inline-flex items-center rounded-lg border px-2.5 py-1 text-[11px] font-bold ${sourceBadgeClass}">
                            ${row.source_type}
                        </span>
                    </td>
                    <td class="px-4 py-3.5 font-bold text-emerald-700">${row.arrived_qty_text}</td>
                    <td class="px-4 py-3.5 font-mono text-[11px] text-slate-600">${row.source_ref || '-'}</td>
                    <td class="px-4 py-3.5 text-slate-600">${row.date_received}</td>
                    <td class="px-4 py-3.5">
                        <span class="inline-flex items-center rounded-full bg-emerald-50 px-2.5 py-0.5 text-[10px] font-bold text-emerald-700 border border-emerald-200">
                            ${row.reservation_status}
                        </span>
                    </td>
                </tr>`;
            });
        } else {
            html = `<tr><td colspan="8" class="text-center py-8 text-slate-400 font-medium">No completed reserved records found for the selected filter.</td></tr>`;
        }
        $('#grrTableBody').html(html);
    }

    // Source Filter Pills click
    $(document).on('click', '.grr-source-pill', function () {
        $('.grr-source-pill').removeClass('bg-emerald-700 text-white shadow-xs').addClass('bg-white text-slate-600 border border-slate-200');
        $(this).removeClass('bg-white text-slate-600 border border-slate-200').addClass('bg-emerald-700 text-white shadow-xs');
        currentGrrSourceFilter = $(this).data('source') || 'all';
        renderGrrTable();
    });

    // Search Input keyup
    $(document).on('input', '#grrSearchInput', function () {
        renderGrrTable();
    });

    // Row click -> open Action Dialog (Screenshot 3)
    $(document).on('click', '.grr-table-row', function () {
        const rawData = $(this).attr('data-record');
        if (!rawData) return;
        let row;
        try {
            row = JSON.parse(rawData);
        } catch (e) {
            return;
        }

        $('#actionModalOrderId').val(row.order_id);
        $('#actionModalOrderItemId').val(row.order_item_id);

        $('#processOrderNoText').text(row.order_number);
        $('#processOrderFooterId').text(row.order_number);
        $('#processOrderSubtext').text(`${row.client_name} • ${row.item_name}`);

        $('#summaryOrderNo').text(row.order_number);
        $('#summaryClientName').text(row.client_name).attr('title', row.client_name);
        $('#summaryItemQty').text(`${row.item_name} (${row.arrived_qty_text.split('/')[0].trim()} ${row.unit_name || 'pcs'})`).attr('title', row.item_name);
        $('#summaryStockStatus').text(row.reservation_status);

        $('#goodsReceivedReservedModal').modal('hide');
        $('#processOrderActionModal').modal('show');
    });

    // Back to list button
    $(document).on('click', '#backToGrrListBtn', function () {
        $('#processOrderActionModal').modal('hide');
        $('#goodsReceivedReservedModal').modal('show');
    });

    // Action 1: Hand off reserved order to Goods Dispatch
    $(document).on('click', '#confirmGoodsDispatchedBtn', function () {
        const orderId = $('#actionModalOrderId').val();
        const orderItemId = $('#actionModalOrderItemId').val();
        const orderNo = $('#processOrderNoText').text();

        if (!orderId) {
            toastr.error('Invalid order selection.');
            return;
        }

        Swal.fire({
            target: document.body,
            title: 'Send to Goods Dispatch?',
            text: `Order ${orderNo} will move to Goods Dispatch. Reserved stock will remain allocated until dispatch is confirmed there.`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, Send to Dispatch',
            cancelButtonText: 'Cancel',
            customClass: {
                container: 'swal2-highest-zindex',
                confirmButton: 'inline-flex rounded-xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white mr-2',
                cancelButton: 'inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (!result.isConfirmed) return;

            const $btn = $('#confirmGoodsDispatchedBtn');
            const origHtml = $btn.html();
            $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Processing...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    dispatchReservedOrderRecord: '1',
                    order_id: orderId,
                    order_item_id: orderItemId
                },
                success: function (res) {
                    if (res.status === 'success') {
                        toastr.success(res.message || 'Order sent to Goods Dispatch successfully.');
                        $('#processOrderActionModal').modal('hide');
                        loadGoodsReceivedReservedSummary();
                        loadOrderReceivedTable();
                    } else {
                        toastr.error(res.message || 'Failed to send the order to Goods Dispatch.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $btn.prop('disabled', false).html(origHtml);
                }
            });
        });
    });

    // Action 2: Cancel Order
    $(document).on('click', '#cancelReservedOrderBtn', function () {
        const orderId = $('#actionModalOrderId').val();
        const orderItemId = $('#actionModalOrderItemId').val();
        const orderNo = $('#processOrderNoText').text();

        if (!orderId) {
            toastr.error('Invalid order selection.');
            return;
        }

        Swal.fire({
            target: document.body,
            title: 'Cancel this Order?',
            text: `Order ${orderNo} will be cancelled and reserved stock will be released back to inventory.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Cancel Order',
            cancelButtonText: 'Keep Order',
            customClass: {
                container: 'swal2-highest-zindex',
                confirmButton: 'inline-flex rounded-xl bg-rose-600 px-4 py-2 text-sm font-bold text-white mr-2',
                cancelButton: 'inline-flex rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (!result.isConfirmed) return;

            const $btn = $('#cancelReservedOrderBtn');
            const origHtml = $btn.html();
            $btn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin text-base"></i> Cancelling...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    cancelReservedOrderRecord: '1',
                    order_id: orderId,
                    order_item_id: orderItemId
                },
                success: function (res) {
                    if (res.status === 'success') {
                        toastr.success(res.message || 'Order cancelled and stock released.');
                        $('#processOrderActionModal').modal('hide');
                        loadGoodsReceivedReservedSummary();
                        loadOrderReceivedTable();
                    } else {
                        toastr.error(res.message || 'Failed to cancel order.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                },
                complete: function () {
                    $btn.prop('disabled', false).html(origHtml);
                }
            });
        });
    });
</script>
<?php endSection(); ?>
