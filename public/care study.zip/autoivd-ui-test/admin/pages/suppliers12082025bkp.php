<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>  
    <div class="row col-md-12">
        <div class="card">            
            <div class="card-header d-flex flex-column flex-md-row py-2 justify-content-between gap-2">
                <div class="d-flex align-items-center gap-2">
                    <label for="perPageSelect" class="mb-0">Show</label>
                    <select id="perPageSelect" class="form-select form-select-sm w-auto">
                        <option value="5">5</option>
                        <option value="10" selected>10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <input type="text" id="searchSupplier" class="form-control form-control-sm" placeholder="Search Data...">
                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_supplier_add')) { ?>
                        <button type="button" class="btn btn-sm w-50 btn-success" data-bs-toggle="modal" data-bs-target="#animationModal">Add New</button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full table-auto whitespace-nowrap text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <tr class="text-nowrap">
                            <th class="border-b border-slate-200 px-6 py-3">#</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Name"> Name</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="GST No"> GST No</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Contact Details"> Contact Details</th>
                            <th class="border-b border-slate-200 px-6 py-3" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Status"> Status</th>
                            <th class="border-b border-slate-200 px-6 py-3">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 bg-white" id="suppliersTableBody">
                    </tbody>
                </table>
            </div>
            <div class="demo-inline-spacing">
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Add Supplier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="addSupplierForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col mb-3">
                                <label for="supplierName" class="form-label">Name</label>
                                <input type="text" id="supplierName" autocomplete="off" name="supplierName" class="form-control" placeholder="Enter Name" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="supplierGstNo" class="form-label">GST NO</label>
                                <input type="text" id="supplierGstNo" autocomplete="off" name="supplierGstNo" class="form-control" placeholder="Enter GST NO" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="supplierContactDetails" class="form-label">Contact Details</label>
                                <input type="text" id="supplierContactDetails" autocomplete="off" name="supplierContactDetails" class="form-control" placeholder="Enter Contact Details" />
                            </div>
                        </div>
                                              
                        
                        <div class="row">
                            <div class="col">
                                <small class="text-dark fw-medium d-block">Status</small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="activStatus" name="supplierStatus" value="1" required />
                                    <label class="form-check-label" for="activStatus">Active</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input" type="radio" id="inactiveStatus" name="supplierStatus" value="0" />
                                    <label class="form-check-label" for="inactiveStatus">Inactive</label>
                                </div>                                
                            </div>
                        </div>                 
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="modal fade animate__animated fadeIn" id="editSupplierModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Edit Supplier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="editSupplierForm">
                    <div class="modal-body">                                    
                    </div>                  
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="changePasswordUserModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel5">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="changePasswordForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col mb-3">
                                <label for="userNewPassword" class="form-label">Enter New Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="userNewPassword" class="form-control" name="userNewPassword" autocomplete="off" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="password" required />
                                    <span class="input-group-text cursor-pointer seeUserNewPassword"><i class="ti ti-eye-off"></i></span>
                                </div>
                                <input type="hidden" name="user_id" id="user_id"  class="form-control" value="" />
                            </div>
                        </div>   
                        <div class="row">
                            <div class="col mb-3">
                                <label for="userNewConfirmPassword" class="form-label">Confirm New Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="userNewConfirmPassword" class="form-control" name="userNewConfirmPassword" autocomplete="off" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="password" required />
                                    <span class="input-group-text cursor-pointer seeUserNewConfirmPassword"><i class="ti ti-eye-off"></i></span>
                                </div>
                            </div>
                        </div>    
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-danger" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="submitChangePasswordBtn">Submit</button>
                    </div>                  
                </form>
            </div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    let currentPage = 1;

    function loadSuppliersTable(page = 1) {
        currentPage = page;
        const search = $('#searchSupplier').val().trim();
        const perPage = $('#perPageSelect').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadSuppliers: 'loadSuppliers',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function(response) {
                $('#suppliersTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function() {
                $('#suppliersTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    $(document).ready(function() {
        loadSuppliersTable();
        $('#searchSupplier').on('input', function() {
            loadSuppliersTable(1);
        });
        $('#perPageSelect').on('change', function() {
            loadSuppliersTable(1);
        });

        $('#addSupplierForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addSupplierForm');
            const formData = new FormData(form);
            formData.append('addSuppliers', 'addSuppliers'); // Backend handler flag

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {
                    let res;
                    try {
                        res = JSON.parse(response);
                    } catch (e) {
                        toastr.error('Invalid response from server.');
                        return;
                    }

                    if (res.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addSupplierForm')[0].reset();
                        loadSuppliersTable();
                        toastr.success(res.message);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });          
    });
    
    $(document).on('click','.supplierEditModal', function(){
       let id = $(this).data('id');
       if(id)
       {
        $('#editSupplierForm').find('modal-body').html();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: {fetchSupplierRecord:'fetchSupplierRecord', id:id},               
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editSupplierModel').modal('show');
                    $('#editSupplierForm').find('.modal-body').html(res.data);   
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
       }
    });

    $(document).on('click','.userChangePasswordModal', function(){
        let id = $(this).data('id');
        $('#user_id').val('');
        if(id){
            $('#user_id').val(id);
            $('#changePasswordUserModel').modal('show');            
        }
    });

    $(document).on('click', '.suuplierDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteSupplierRecord: 'deleteSupplierRecord',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadSuppliersTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });
    
    $('#editSupplierForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editSupplierForm');
        const formData = new FormData(form);
        formData.append('updateSupplier', 'updateSupplier'); 
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false,
            success: function (response) {
                let res;
                try {
                    res = JSON.parse(response);
                } catch (e) {
                    toastr.error('Invalid response from server.');
                    return;
                }

                if (res.status === 'success') {
                    $('#editSupplierModel').modal('hide');
                    $('#editSupplierForm').find('modal-body').html();
                    loadSuppliersTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });


</script>
<?php endSection(); ?>
