<?php
if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once __DIR__ . '/../hrms/hrms_common.php';

$currentUserId = (int) ($_SESSION['user_id'] ?? 0);
$leaveEmployee = hrmsCurrentEmployee($conn, $currentUserId);
$canManageLeave = hrmsCan($conn, 'hrms_leave_manage');
$leaveBalances = $leaveEmployee ? hrmsLeaveBalances($conn, $leaveEmployee) : [];
$applicableLeaveBalances = array_values(array_filter($leaveBalances, static fn(array $balance): bool => !empty($balance['eligible'])));
$employeeApplications = [];
$managerApplications = [];
$allocationEmployees = [];
$allocationRows = [];
$leaveTypeDefinitions = [];
$leaveTypeCompanies = [];
$leaveScope = null;

if ($leaveEmployee) {
    $stmt = $conn->prepare(
        "SELECT application.*, leave_type.name AS leave_type_name, leave_type.color,
                GROUP_CONCAT(CONCAT(day.leave_date, '|', day.day_portion) ORDER BY day.leave_date SEPARATOR ',') AS leave_days
         FROM hr_leave_applications application
         INNER JOIN hr_leave_types leave_type ON leave_type.id = application.leave_type_id
         LEFT JOIN hr_leave_application_days day ON day.application_id = application.id
         WHERE application.employee_id = ?
         GROUP BY application.id
         ORDER BY application.submitted_at DESC"
    );
    $employeeId = (int) $leaveEmployee['id'];
    $stmt->bind_param('i', $employeeId);
    $stmt->execute();
    $employeeApplications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

if ($canManageLeave) {
    $scope = hrmsCurrentScope($conn, $currentUserId);
    $leaveScope = $scope;
    $leaveTypeSql = "SELECT leave_type.*, company.company_name
        FROM hr_leave_types leave_type
        LEFT JOIN erp_companies company ON company.id = leave_type.company_id
        WHERE 1 = 1";
    if ($scope['company_id'] !== null) {
        $leaveTypeSql .= ' AND (leave_type.company_id IS NULL OR leave_type.company_id = ' . (int) $scope['company_id'] . ')';
    }
    $leaveTypeSql .= ' ORDER BY leave_type.company_id IS NULL DESC, company.company_name, leave_type.name';
    $result = $conn->query($leaveTypeSql);
    $leaveTypeDefinitions = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    if ($scope['company_id'] === null) {
        $result = $conn->query('SELECT id, company_name FROM erp_companies WHERE status = 1 AND deleted_at IS NULL ORDER BY company_name');
        $leaveTypeCompanies = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
    $managerSql = "SELECT application.*, leave_type.name AS leave_type_name, leave_type.color,
            employee.emp_code, employee.first_name, employee.last_name,
            company.company_name, branch.branch_name,
            GROUP_CONCAT(CONCAT(day.leave_date, '|', day.day_portion) ORDER BY day.leave_date SEPARATOR ',') AS leave_days
        FROM hr_leave_applications application
        INNER JOIN hr_leave_types leave_type ON leave_type.id = application.leave_type_id
        INNER JOIN employees employee ON employee.id = application.employee_id
        LEFT JOIN erp_companies company ON company.id = application.company_id
        LEFT JOIN erp_branches branch ON branch.id = application.branch_id
        LEFT JOIN hr_leave_application_days day ON day.application_id = application.id
        WHERE 1 = 1";
    $managerTypes = '';
    $managerParams = [];
    if ($scope['company_id'] !== null) {
        $managerSql .= ' AND application.company_id = ?';
        $managerTypes .= 'i';
        $managerParams[] = $scope['company_id'];
    }
    if ($scope['branch_id'] !== null) {
        $managerSql .= ' AND application.branch_id = ?';
        $managerTypes .= 'i';
        $managerParams[] = $scope['branch_id'];
    }
    $managerSql .= " GROUP BY application.id ORDER BY FIELD(application.status, 'pending','approved','rejected','cancelled'), application.submitted_at DESC LIMIT 200";
    $stmt = $conn->prepare($managerSql);
    if ($managerTypes !== '') {
        $stmt->bind_param($managerTypes, ...$managerParams);
    }
    $stmt->execute();
    $managerApplications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $employeeSql = "SELECT employee.id, employee.emp_code, employee.first_name, employee.last_name, employee.gender
        FROM employees employee
        LEFT JOIN users user ON user.id = employee.user_id
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        WHERE employee.deleted_at IS NULL AND employee.status = 1";
    $employeeTypes = '';
    $employeeParams = [];
    if ($scope['company_id'] !== null) {
        $employeeSql .= ' AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?';
        $employeeTypes .= 'i';
        $employeeParams[] = $scope['company_id'];
    }
    if ($scope['branch_id'] !== null) {
        $employeeSql .= ' AND COALESCE(user.branch_id, profile.branch_id) = ?';
        $employeeTypes .= 'i';
        $employeeParams[] = $scope['branch_id'];
    }
    $employeeSql .= ' ORDER BY employee.first_name, employee.last_name';
    $stmt = $conn->prepare($employeeSql);
    if ($employeeTypes !== '') {
        $stmt->bind_param($employeeTypes, ...$employeeParams);
    }
    $stmt->execute();
    $allocationEmployees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $allocationSql = "SELECT allocation.id, allocation.leave_year, allocation.allocated_days,
            allocation.carried_forward_days, allocation.adjustment_days,
            employee.id AS employee_id, employee.emp_code, employee.first_name, employee.last_name,
            leave_type.id AS leave_type_id, leave_type.name AS leave_type_name,
            company.company_name, branch.branch_name,
            COALESCE(usage_summary.approved_days, 0) AS approved_days,
            COALESCE(usage_summary.pending_days, 0) AS pending_days
        FROM hr_leave_allocations allocation
        INNER JOIN employees employee ON employee.id = allocation.employee_id
        INNER JOIN hr_leave_types leave_type ON leave_type.id = allocation.leave_type_id
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        LEFT JOIN erp_companies company ON company.id = COALESCE(profile.company_id, user.company_id, legacy_company.id)
        LEFT JOIN erp_branches branch ON branch.id = COALESCE(profile.branch_id, user.branch_id)
        LEFT JOIN (
            SELECT employee_id, leave_type_id, YEAR(start_date) AS leave_year,
                SUM(CASE WHEN status = 'approved' THEN total_days ELSE 0 END) AS approved_days,
                SUM(CASE WHEN status = 'pending' THEN total_days ELSE 0 END) AS pending_days
            FROM hr_leave_applications
            WHERE status IN ('approved', 'pending')
            GROUP BY employee_id, leave_type_id, YEAR(start_date)
        ) usage_summary ON usage_summary.employee_id = allocation.employee_id
            AND usage_summary.leave_type_id = allocation.leave_type_id
            AND usage_summary.leave_year = allocation.leave_year
        WHERE employee.deleted_at IS NULL";
    $allocationTypes = '';
    $allocationParams = [];
    if ($scope['company_id'] !== null) {
        $allocationSql .= ' AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?';
        $allocationTypes .= 'i';
        $allocationParams[] = $scope['company_id'];
    }
    if ($scope['branch_id'] !== null) {
        $allocationSql .= ' AND COALESCE(profile.branch_id, user.branch_id) = ?';
        $allocationTypes .= 'i';
        $allocationParams[] = $scope['branch_id'];
    }
    $allocationSql .= ' ORDER BY allocation.leave_year DESC, employee.first_name, employee.last_name, leave_type.name LIMIT 1000';
    $stmt = $conn->prepare($allocationSql);
    if ($allocationTypes !== '') {
        $stmt->bind_param($allocationTypes, ...$allocationParams);
    }
    $stmt->execute();
    $allocationRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$statusClass = static function (string $status): string {
    return match ($status) {
        'approved' => 'bg-emerald-100 text-emerald-700',
        'rejected' => 'bg-rose-100 text-rose-700',
        'cancelled' => 'bg-slate-100 text-slate-600',
        default => 'bg-amber-100 text-amber-700',
    };
};

$targetCompanyId = (int) ($leaveScope['company_id'] ?? ($leaveEmployee['company'] ?? ($leaveEmployee['company_id'] ?? 1)));
$currentCalendarYear = (int) date('Y');
$currentCalendar = function_exists('acGetCalendarForYear') ? acGetCalendarForYear($conn, $targetCompanyId, $currentCalendarYear) : null;
$calendarStatus = $currentCalendar ? ($currentCalendar['lifecycle_status'] ?? 'draft') : 'not_created';
?>

<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <?php if ($calendarStatus !== 'finalized'): ?>
        <div class="alert alert-warning border border-amber-300 bg-amber-50 rounded-2xl p-4 mb-4 d-flex align-items-center justify-content-between flex-wrap gap-3">
            <div class="d-flex align-items-center gap-3">
                <span class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                    <i class="ti ti-calendar-event text-xl"></i>
                </span>
                <div>
                    <div class="fw-bold text-slate-800">
                        Annual Calendar <?= $currentCalendarYear ?>: <?= $calendarStatus === 'draft' ? '<span class="badge bg-label-warning">Draft (Not Finalized)</span>' : '<span class="badge bg-label-danger">Not Created</span>' ?>
                    </div>
                    <div class="text-sm text-slate-600 mt-0.5">
                        HR must finalize the Annual Calendar for <?= $currentCalendarYear ?>. Until finalized, leave applications and attendance calculations may use draft schedule rules.
                    </div>
                </div>
            </div>
            <?php if ($canManageLeave): ?>
                <a href="annual-calendar.php" class="btn btn-sm btn-primary rounded-xl px-4">
                    <i class="ti ti-calendar-check me-1"></i> Go to Annual Calendar
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-6 ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h2 class="mb-1 text-2xl fw-bold text-slate-900" style="font-family:'Sora',sans-serif;">Leave Management</h2>
            <p class="mb-0 text-sm text-slate-500">Review balances, apply for leave and track every approval decision.</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <?php if ($canManageLeave): ?>
                <button class="btn btn-outline-primary rounded-xl px-4" data-bs-toggle="modal" data-bs-target="#leaveTypesModal"><i class="ti ti-list-details me-2"></i>Leave Types</button>
                <button class="btn btn-outline-primary rounded-xl px-4" data-bs-toggle="modal" data-bs-target="#leaveAllocationModal"><i class="ti ti-adjustments me-2"></i>Allocate Leave</button>
            <?php endif; ?>
            <button class="btn btn-primary rounded-xl px-4" data-bs-toggle="modal" data-bs-target="#applyLeaveModal"><i class="ti ti-calendar-plus me-2"></i>Apply Leave</button>
        </div>
    </div>

    <?php if ($leaveEmployee): ?>
        <div class="row g-4 mb-6" id="leaveBalanceCards">
            <?php foreach ($applicableLeaveBalances as $balance): ?>
                <div class="col-sm-6 col-xl-3">
                    <button type="button" class="card h-100 w-100 text-start border border-slate-200 shadow-sm rounded-2xl leave-type-card <?= !$balance['can_apply'] ? 'opacity-50' : '' ?>"
                        data-leave-type-id="<?= (int) $balance['id'] ?>" data-remaining="<?= htmlspecialchars((string) $balance['remaining']) ?>"
                        data-allow-negative="<?= (int) $balance['allow_negative_balance'] ?>" data-can-apply="<?= $balance['can_apply'] ? '1' : '0' ?>">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-start justify-content-between mb-4">
                                <div><div class="fw-bold text-slate-800"><?= htmlspecialchars($balance['name']) ?></div><div class="text-xs text-slate-400 mt-1"><?= $balance['eligible'] ? ($balance['can_apply'] ? 'Available to apply' : 'Balance exhausted') : 'Not eligible' ?></div></div>
                                <span class="rounded-circle" style="width:14px;height:14px;background:<?= htmlspecialchars($balance['color']) ?>;"></span>
                            </div>
                            <div class="text-3xl fw-bold text-slate-900 mb-3"><?= number_format((float) $balance['remaining'], 1) ?><span class="text-sm text-slate-400 fw-medium ms-1">days</span></div>
                            <div class="d-flex justify-content-between text-xs text-slate-500"><span>Allocated <?= number_format((float) $balance['allocated'], 1) ?></span><span>Booking <?= number_format((float) $balance['current_booking'], 1) ?></span></div>
                        </div>
                    </button>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-5">
                <h5 class="mb-1 fw-bold text-slate-900">My Leave Applications</h5>
                <p class="mb-0 text-sm text-slate-500">Submitted applications and current approval status.</p>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Application</th><th class="py-3 text-xs text-uppercase text-slate-500">Leave Type</th><th class="py-3 text-xs text-uppercase text-slate-500">Period</th><th class="py-3 text-xs text-uppercase text-slate-500">Days</th><th class="py-3 text-xs text-uppercase text-slate-500">Submitted</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Status</th></tr></thead>
                    <tbody>
                    <?php if (!$employeeApplications): ?>
                        <tr><td colspan="6" class="text-center text-slate-500 py-10">No leave applications found.</td></tr>
                    <?php else: foreach ($employeeApplications as $application): ?>
                        <tr><td class="px-5 py-4 fw-bold text-slate-800"><?= htmlspecialchars($application['application_no']) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars($application['leave_type_name']) ?></td><td class="py-4 text-slate-600"><?= htmlspecialchars($application['start_date']) ?> – <?= htmlspecialchars($application['end_date']) ?></td><td class="py-4 fw-semibold text-slate-700"><?= number_format((float) $application['total_days'], 1) ?></td><td class="py-4 text-slate-500"><?= htmlspecialchars(date('d M Y', strtotime($application['submitted_at']))) ?></td><td class="px-5 py-4"><span class="badge rounded-pill <?= $statusClass($application['status']) ?>"><?= htmlspecialchars(ucfirst($application['status'])) ?></span></td></tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php elseif (!$canManageLeave): ?>
        <div class="card border border-amber-200 bg-amber-50 rounded-2xl mb-6"><div class="card-body p-5 text-amber-800"><i class="ti ti-alert-triangle me-2"></i>Your login is not linked to an employee record.</div></div>
    <?php endif; ?>

    <?php if ($canManageLeave): ?>
        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden mb-6">
            <div class="card-header bg-white border-bottom border-slate-100 p-4">
                <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3">
                    <div>
                        <h5 class="mb-1 fw-bold text-slate-900">Allocated Leave by Employee</h5>
                        <p class="mb-0 text-sm text-slate-500">Annual entitlement, usage and remaining balance for employees in your scope.</p>
                    </div>
                    <div class="d-flex flex-wrap align-items-center gap-3">
                        <input type="hidden" id="leaveAllocationPerPage" value="10">

                        <div class="dropdown shrink-0">
                            <button
                                class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                type="button" data-bs-toggle="dropdown">
                                <span id="leaveAllocationPerPageText" class="whitespace-nowrap">10 items</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                                <li><a class="leave-allocation-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                            </ul>
                        </div>

                        <div class="position-relative" style="min-width: 200px; max-width: 280px; flex-grow: 1;">
                            <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:14px;"></i>
                            <input type="text" id="leaveAllocationSearch" class="form-control rounded-xl ps-5" placeholder="Search employee or type...">
                        </div>

                        <div class="dropdown shrink-0">
                            <button
                                class="flex h-10 min-w-[130px] w-auto items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                    <i class="ti ti-category text-base text-slate-400"></i>
                                    Leave Types
                                </span>
                                <i class="ti ti-filter text-base text-slate-500"></i>
                            </button>
                            <div class="dropdown-menu max-h-64 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl"
                                id="leaveAllocationTypeFilterOptions">
                                <div class="p-1">
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-allocation-type-filter rounded border-slate-300 accent-emerald-600" value="all" checked />
                                        <span>All Types</span>
                                    </label>
                                    <?php foreach ($leaveTypeDefinitions as $type): ?>
                                        <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox" class="leave-allocation-type-filter rounded border-slate-300 accent-emerald-600" value="<?= htmlspecialchars((string) $type['id']) ?>" checked />
                                            <span><?= htmlspecialchars($type['name']) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0" id="leaveAllocationTable">
                    <thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Employee</th><th class="py-3 text-xs text-uppercase text-slate-500">Organization</th><th class="py-3 text-xs text-uppercase text-slate-500">Leave Type</th><th class="py-3 text-xs text-uppercase text-slate-500">Year</th><th class="py-3 text-xs text-uppercase text-slate-500">Allocated</th><th class="py-3 text-xs text-uppercase text-slate-500">Approved</th><th class="py-3 text-xs text-uppercase text-slate-500">Pending</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Remaining</th></tr></thead>
                    <tbody id="leaveAllocationTableBody">
                    </tbody>
                </table>
            </div>
            <div class="leave-allocation-pagination-container">
                <?= getPaginationFooter('leaveAllocationPaginationWrapper', 'leaveAllocationPaginationSummary', 'leaveAllocationPerPageSelect') ?>
            </div>
        </div>

        <div class="card border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
            <div class="card-header bg-white border-bottom border-slate-100 p-4">
                <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3">
                    <div>
                        <h5 class="mb-1 fw-bold text-slate-900">HR Leave Applications</h5>
                        <p class="mb-0 text-sm text-slate-500">Open an application to review its dates, balance, reason and approval actions.</p>
                    </div>
                    <div class="d-flex flex-wrap align-items-center gap-3">
                        <input type="hidden" id="leaveManagerPerPage" value="10">

                        <div class="dropdown shrink-0">
                            <button
                                class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                type="button" data-bs-toggle="dropdown">
                                <span id="leaveManagerPerPageText" class="whitespace-nowrap">10 items</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="1000">1000 items</a></li>
                                <li><a class="leave-manager-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="3000">3000 items</a></li>
                            </ul>
                        </div>

                        <div class="position-relative" style="min-width: 200px; max-width: 280px; flex-grow: 1;">
                            <i class="ti ti-search position-absolute top-50 translate-middle-y text-slate-400" style="left:14px;"></i>
                            <input type="text" id="leaveManagerSearch" class="form-control rounded-xl ps-5" placeholder="Search employee or app...">
                        </div>

                        <div class="dropdown shrink-0">
                            <button
                                class="flex h-10 min-w-[130px] w-auto items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                    <i class="ti ti-category text-base text-slate-400"></i>
                                    Leave Types
                                </span>
                                <i class="ti ti-filter text-base text-slate-500"></i>
                            </button>
                            <div class="dropdown-menu max-h-64 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl"
                                id="leaveManagerTypeFilterOptions">
                                <div class="p-1">
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-manager-type-filter rounded border-slate-300 accent-emerald-600" value="all" checked />
                                        <span>All Types</span>
                                    </label>
                                    <?php foreach ($leaveTypeDefinitions as $type): ?>
                                        <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                            <input type="checkbox" class="leave-manager-type-filter rounded border-slate-300 accent-emerald-600" value="<?= htmlspecialchars((string) $type['id']) ?>" checked />
                                            <span><?= htmlspecialchars($type['name']) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <div class="dropdown shrink-0">
                            <button
                                class="flex h-10 min-w-[130px] w-auto items-center justify-between gap-3 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                <span class="inline-flex items-center gap-2 whitespace-nowrap">
                                    <i class="ti ti-circle-check text-base text-slate-400"></i>
                                    Statuses
                                </span>
                                <i class="ti ti-filter text-base text-slate-500"></i>
                            </button>
                            <div class="dropdown-menu max-h-64 min-w-56 overflow-y-auto !rounded-xl border border-slate-200 p-2 shadow-xl"
                                id="leaveManagerStatusFilterOptions">
                                <div class="p-1">
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-manager-status-filter rounded border-slate-300 accent-emerald-600" value="all" checked />
                                        <span>All Statuses</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-manager-status-filter rounded border-slate-300 accent-emerald-600" value="pending" checked />
                                        <span>Pending</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-manager-status-filter rounded border-slate-300 accent-emerald-600" value="approved" checked />
                                        <span>Approved</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-manager-status-filter rounded border-slate-300 accent-emerald-600" value="rejected" checked />
                                        <span>Rejected</span>
                                    </label>
                                    <label class="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                                        <input type="checkbox" class="leave-manager-status-filter rounded border-slate-300 accent-emerald-600" value="cancelled" checked />
                                        <span>Cancelled</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0" id="leaveManagerTable">
                    <thead class="bg-slate-50"><tr><th class="px-5 py-3 text-xs text-uppercase text-slate-500">Employee</th><th class="py-3 text-xs text-uppercase text-slate-500">Application</th><th class="py-3 text-xs text-uppercase text-slate-500">Leave</th><th class="py-3 text-xs text-uppercase text-slate-500">Period</th><th class="py-3 text-xs text-uppercase text-slate-500">Days</th><th class="py-3 text-xs text-uppercase text-slate-500">Status</th><th class="px-5 py-3 text-xs text-uppercase text-slate-500 text-end">Action</th></tr></thead>
                    <tbody id="leaveManagerTableBody">
                    </tbody>
                </table>
            </div>
            <div class="leave-manager-pagination-container">
                <?= getPaginationFooter('leaveManagerPaginationWrapper', 'leaveManagerPaginationSummary', 'leaveManagerPerPageSelect') ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content rounded-2xl border-0 shadow-lg">
        <div class="modal-header border-bottom border-slate-100 p-5"><div><h5 class="modal-title fw-bold text-slate-900">Apply Leave</h5><p class="mb-0 text-sm text-slate-500">Select dates and confirm the balance before submitting.</p></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <form id="applyLeaveForm" class="issue3-modal-form"><div class="modal-body p-5 issue3-modal-scroll-body">
            <input type="hidden" name="action" value="submit_leave"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><input type="hidden" name="leave_days" id="leaveDaysJson">
            <div class="row g-4">
                <?php if (!$leaveEmployee && $canManageLeave && !empty($allocationEmployees)): ?>
                    <div class="col-12">
                        <label class="form-label fw-bold text-slate-700">Employee <span class="text-danger">*</span></label>
                        <select class="form-select rounded-xl" name="employee_id" id="leaveApplyEmployeeSelect" required>
                            <option value="">Select employee</option>
                            <?php foreach ($allocationEmployees as $emp): ?>
                                <option value="<?= (int) $emp['id'] ?>"><?= htmlspecialchars(trim($emp['first_name'] . ' ' . $emp['last_name']) . ' (' . ($emp['emp_code'] ?: 'No ID') . ')') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="col-md-6"><label class="form-label fw-bold text-slate-700">Leave Type <span class="text-danger">*</span></label><select class="form-select rounded-xl" name="leave_type_id" id="leaveTypeSelect" required><option value="">Select leave type</option><?php foreach ($applicableLeaveBalances ?: (function () use ($conn) { $r=$conn->query("SELECT id,name FROM hr_leave_types WHERE status=1 ORDER BY name"); return $r?$r->fetch_all(MYSQLI_ASSOC):[]; })() as $balance): ?><option value="<?= (int) $balance['id'] ?>" data-name="<?= htmlspecialchars($balance['name']) ?>" data-available="<?= htmlspecialchars((string) ($balance['available'] ?? 0)) ?>" data-booking="<?= htmlspecialchars((string) ($balance['current_booking'] ?? 0)) ?>" data-remaining="<?= htmlspecialchars((string) ($balance['remaining'] ?? 0)) ?>" data-can-apply="<?= ($balance['can_apply'] ?? true) ? '1' : '0' ?>"><?= htmlspecialchars($balance['name']) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-3"><label class="form-label fw-bold text-slate-700">From <span class="text-danger">*</span></label><input type="date" class="form-control rounded-xl" id="leaveStartDate" required></div>
                <div class="col-md-3"><label class="form-label fw-bold text-slate-700">To <span class="text-danger">*</span></label><input type="date" class="form-control rounded-xl" id="leaveEndDate" required></div>
                <div class="col-12"><div id="leaveDateRows" class="rounded-xl border border-slate-200 overflow-hidden issue3-leave-date-rows"><div class="p-5 text-center text-slate-400">Choose a date range to configure each day.</div></div></div>
                <div class="col-md-6"><label class="form-label fw-bold text-slate-700">Team Email</label><input type="email" class="form-control rounded-xl" name="team_email" placeholder="team@company.com"></div>
                <div class="col-12"><label class="form-label fw-bold text-slate-700">Reason <span class="text-danger">*</span></label><textarea class="form-control rounded-xl" name="reason" rows="4" maxlength="3000" required></textarea></div>
                <div class="col-12"><div class="rounded-2xl bg-emerald-50 border border-emerald-100 p-4"><div class="row g-3 text-center"><div class="col-6 col-sm-3"><div class="text-xs text-emerald-700">Available</div><div class="fw-bold text-emerald-900" id="balanceAvailable">0.0</div></div><div class="col-6 col-sm-3"><div class="text-xs text-emerald-700">Current booking</div><div class="fw-bold text-emerald-900" id="balanceBooking">0.0</div></div><div class="col-6 col-sm-3"><div class="text-xs text-emerald-700">This request</div><div class="fw-bold text-emerald-900" id="balanceRequest">0.0</div></div><div class="col-6 col-sm-3"><div class="text-xs text-emerald-700">Remaining</div><div class="fw-bold text-emerald-900" id="balanceRemaining">0.0</div></div></div></div></div>
            </div>
        </div><div class="modal-footer border-top border-slate-100 p-4 issue3-modal-footer"><button type="button" class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary rounded-xl" id="submitLeaveBtn"><span class="btn-label">Submit Application</span><span class="spinner-border spinner-border-sm d-none" role="status"></span></button></div></form>
    </div></div>
</div>

<?php if ($canManageLeave): ?>
<div class="modal fade" id="reviewLeaveModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content rounded-2xl border-0 shadow-lg"><div class="modal-header border-bottom border-slate-100 p-5"><div><h5 class="modal-title fw-bold text-slate-900">Leave Application</h5><p class="mb-0 text-sm text-slate-500" id="reviewLeaveReference"></p></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body p-5"><div class="row g-4 mb-4"><div class="col-md-6"><div class="text-xs text-uppercase fw-bold text-slate-400">Employee</div><div class="fw-bold text-slate-800" id="reviewLeaveEmployee"></div></div><div class="col-md-3"><div class="text-xs text-uppercase fw-bold text-slate-400">Leave Type</div><div class="fw-bold text-slate-800" id="reviewLeaveType"></div></div><div class="col-md-3"><div class="text-xs text-uppercase fw-bold text-slate-400">Total Days</div><div class="fw-bold text-slate-800" id="reviewLeaveTotal"></div></div></div><div class="rounded-xl border border-slate-200 mb-4" id="reviewLeaveDays"></div><div class="mb-4"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Team Email</div><div class="text-slate-700" id="reviewLeaveTeam"></div></div><div class="mb-4"><div class="text-xs text-uppercase fw-bold text-slate-400 mb-1">Reason</div><div class="text-slate-700" id="reviewLeaveReason"></div></div><div id="reviewLeaveDecision"><label class="form-label fw-bold text-slate-700">Approval note</label><textarea class="form-control rounded-xl" id="reviewLeaveNote" rows="3" maxlength="1000" placeholder="Required when rejecting"></textarea></div></div><div class="modal-footer border-top border-slate-100 p-4" id="reviewLeaveActions"><button type="button" class="btn btn-outline-secondary rounded-xl me-auto" data-bs-dismiss="modal">Close</button><button type="button" class="btn btn-outline-danger rounded-xl leave-decision-btn" data-decision="rejected"><i class="ti ti-x me-2"></i>Reject</button><button type="button" class="btn btn-primary rounded-xl leave-decision-btn" data-decision="approved"><i class="ti ti-check me-2"></i>Approve</button></div></div></div></div>

<div class="modal fade" id="leaveAllocationModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-2xl border-0 shadow-lg"><div class="modal-header p-5 border-bottom border-slate-100"><div><h5 class="modal-title fw-bold text-slate-900">Allocate Leave</h5><p class="mb-0 text-sm text-slate-500">Set the employee's annual leave allowance.</p></div><button class="btn-close" data-bs-dismiss="modal"></button></div><form id="leaveAllocationForm"><div class="modal-body p-5"><input type="hidden" name="action" value="save_leave_allocation"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-4"><label class="form-label fw-bold">Employee</label><select class="form-select rounded-xl" name="employee_id" required><option value="">Select employee</option><?php foreach ($allocationEmployees as $employee): ?><option value="<?= (int) $employee['id'] ?>" data-gender="<?= (int) $employee['gender'] ?>"><?= htmlspecialchars(trim($employee['first_name'].' '.$employee['last_name']) . ' (' . ($employee['emp_code'] ?: 'No ID') . ')') ?></option><?php endforeach; ?></select></div><div class="mb-4"><label class="form-label fw-bold">Leave Type</label><select class="form-select rounded-xl" name="leave_type_id" required><option value="">Select leave type</option><?php foreach ($leaveTypeDefinitions as $type): ?><option value="<?= (int) $type['id'] ?>" data-gender-eligibility="<?= htmlspecialchars($type['gender_eligibility']) ?>"><?= htmlspecialchars($type['name']) ?></option><?php endforeach; ?></select></div><div class="row g-3"><div class="col-4"><label class="form-label fw-bold">Year</label><input type="number" class="form-control rounded-xl" name="leave_year" value="<?= date('Y') ?>" min="2000" max="2100" required></div><div class="col-4"><label class="form-label fw-bold">Allocated</label><input type="number" class="form-control rounded-xl" name="allocated_days" min="0" max="999" step="0.5" required></div><div class="col-4"><label class="form-label fw-bold">Carried</label><input type="number" class="form-control rounded-xl" name="carried_forward_days" value="0" step="0.5"></div></div></div><div class="modal-footer p-4 border-top border-slate-100"><button type="button" class="btn btn-outline-secondary rounded-xl" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary rounded-xl">Save Allocation</button></div></form></div></div></div>
<?php endif; ?>

<?php if ($canManageLeave): ?>
<div class="modal fade" id="leaveTypesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable"><div class="modal-content rounded-2xl border-0 shadow-lg">
        <div class="modal-header p-5 border-bottom border-slate-100"><div><h5 class="modal-title fw-bold text-slate-900">Leave Types</h5><p class="mb-0 text-sm text-slate-500">Define organization leave options, eligibility and balance rules.</p></div><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body p-5"><div class="row g-5">
            <div class="col-lg-7"><div class="table-responsive rounded-xl border border-slate-200"><table class="table align-middle mb-0"><thead class="bg-slate-50"><tr><th class="px-4">Type</th><th>Scope</th><th>Eligibility</th><th>Status</th><th class="px-4 text-end">Action</th></tr></thead><tbody>
            <?php foreach ($leaveTypeDefinitions as $type):
                $canEditType = $leaveScope['company_id'] === null || ($type['company_id'] !== null && (int) $type['company_id'] === (int) $leaveScope['company_id']);
                $typePayload = ['id'=>(int)$type['id'],'company_id'=>$type['company_id'],'code'=>$type['code'],'name'=>$type['name'],'description'=>$type['description'],'color'=>$type['color'],'is_paid'=>(int)$type['is_paid'],'gender_eligibility'=>$type['gender_eligibility'],'allow_negative_balance'=>(int)$type['allow_negative_balance'],'status'=>(int)$type['status']];
            ?><tr><td class="px-4 py-3"><div class="d-flex align-items-center gap-2"><span class="rounded-circle" style="width:12px;height:12px;background:<?=htmlspecialchars($type['color'])?>"></span><div><strong class="d-block text-slate-800"><?=htmlspecialchars($type['name'])?></strong><small class="text-slate-400"><?=htmlspecialchars($type['code'])?> · <?=$type['is_paid']?'Paid':'Unpaid'?></small></div></div></td><td class="text-slate-600"><?=htmlspecialchars($type['company_name']??'System default')?></td><td class="text-slate-600"><?=htmlspecialchars(ucfirst($type['gender_eligibility']))?></td><td><span class="badge rounded-pill <?=$type['status']?'bg-emerald-100 text-emerald-700':'bg-slate-100 text-slate-600'?>"><?=$type['status']?'Active':'Inactive'?></span></td><td class="px-4 text-end"><?php if($canEditType):?><button type="button" class="btn btn-sm btn-icon btn-outline-primary rounded-lg edit-leave-type" data-leave-type="<?=htmlspecialchars(json_encode($typePayload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),ENT_QUOTES,'UTF-8')?>" title="Edit leave type"><i class="ti ti-pencil"></i></button><?php else:?><span class="text-xs text-slate-400">Protected</span><?php endif;?></td></tr><?php endforeach; ?>
            </tbody></table></div></div>
            <div class="col-lg-5"><form id="leaveTypeForm"><input type="hidden" name="action" value="save_leave_type"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>"><input type="hidden" name="leave_type_id"><div class="d-flex align-items-center justify-content-between mb-4"><div class="d-flex align-items-center gap-2"><h6 class="mb-0 fw-bold text-slate-900" id="leaveTypeFormTitle">Add Leave Type</h6><span class="badge rounded-pill bg-primary-100 text-primary text-xs" id="leaveTypeModeBadge">New</span></div><button type="button" class="btn btn-sm btn-outline-primary rounded-lg" id="newLeaveType" title="Reset form and create new leave type"><i class="ti ti-plus me-1"></i>New</button></div>
                <?php if ($leaveScope['company_id'] === null): ?><div class="mb-3"><label class="form-label fw-bold">Organization</label><select class="form-select rounded-xl" name="company_id"><option value="">System default</option><?php foreach($leaveTypeCompanies as $company):?><option value="<?=(int)$company['id']?>"><?=htmlspecialchars($company['company_name'])?></option><?php endforeach;?></select></div><?php else:?><input type="hidden" name="company_id" value="<?=(int)$leaveScope['company_id']?>"><?php endif; ?>
                <div class="row g-3"><div class="col-sm-4"><label class="form-label fw-bold">Code *</label><input class="form-control rounded-xl text-uppercase" name="code" maxlength="40" pattern="[A-Za-z0-9_-]{2,40}" required></div><div class="col-sm-8"><label class="form-label fw-bold">Name *</label><input class="form-control rounded-xl" name="name" maxlength="100" required></div><div class="col-12"><label class="form-label fw-bold">Description</label><textarea class="form-control rounded-xl" name="description" rows="3" maxlength="500"></textarea></div><div class="col-sm-6"><label class="form-label fw-bold">Eligibility *</label><select class="form-select rounded-xl" name="gender_eligibility" required><option value="all">All employees</option><option value="female">Female employees</option><option value="male">Male employees</option></select></div><div class="col-sm-6"><label class="form-label fw-bold">Color *</label><input type="color" class="form-control form-control-color rounded-xl w-100" name="color" value="#10b981" required></div></div>
                <div class="mt-4"><label class="form-label fw-bold text-slate-700 d-block mb-2">Leave Compensation *</label><div class="d-flex gap-4 mb-3"><label class="form-check mb-0"><input class="form-check-input" type="radio" name="is_paid" id="leaveTypePaid" value="1" checked><span class="form-check-label fw-semibold text-slate-700">Paid Leave</span></label><label class="form-check mb-0"><input class="form-check-input" type="radio" name="is_paid" id="leaveTypeUnpaid" value="0"><span class="form-check-label fw-semibold text-slate-700">Unpaid Leave</span></label></div></div>
                <div class="d-flex flex-column gap-3"><label class="form-check"><input class="form-check-input" type="checkbox" name="allow_negative_balance" id="leaveTypeNegativeBalance" value="1"><span class="form-check-label">Allow applications beyond balance</span></label><label class="form-check"><input class="form-check-input" type="checkbox" name="status" id="leaveTypeStatus" value="1" checked><span class="form-check-label">Active</span></label></div><div class="d-flex justify-content-end mt-4"><button class="btn btn-primary rounded-xl px-4" id="saveLeaveTypeBtn"><i class="ti ti-plus me-2"></i>Create Leave Type</button></div>
            </form></div>
        </div></div>
    </div></div>
</div>
<?php endif; ?>

<?php startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const csrfToken = <?= json_encode($_SESSION['csrf_token']) ?>;
    const requestedModal = new URL(window.location.href).searchParams.get('open');
    if (requestedModal === 'apply-leave') {
        const applyModalEl = document.getElementById('applyLeaveModal');
        if (applyModalEl) {
            bootstrap.Modal.getOrCreateInstance(applyModalEl).show();
        }
        const cleanUrl = new URL(window.location.href); cleanUrl.searchParams.delete('open'); history.replaceState({}, '', cleanUrl);
    }
    const postHrms = async (formData) => {
        const response = await fetch('hrms-api.php', { method: 'POST', body: formData, credentials: 'same-origin' });
        const data = await response.json().catch(() => ({ status: 'error', message: 'The server returned an invalid response.' }));
        if (!response.ok || data.status !== 'success') throw new Error(data.message || 'Unable to complete the request.');
        return data;
    };
    const notify = (type, message) => {
        if (window.toastr) toastr[type](message); else alert(message);
    };

    const leaveTypeSelect = document.getElementById('leaveTypeSelect');
    const startInput = document.getElementById('leaveStartDate');
    const endInput = document.getElementById('leaveEndDate');
    const rowsContainer = document.getElementById('leaveDateRows');
    const jsonInput = document.getElementById('leaveDaysJson');
    const requestOutput = document.getElementById('balanceRequest');
    const remainingOutput = document.getElementById('balanceRemaining');
    const updateBalance = () => {
        if (!leaveTypeSelect) return;
        const option = leaveTypeSelect.selectedOptions[0];
        const available = Number(option?.dataset.available || 0);
        const booking = Number(option?.dataset.booking || 0);
        const request = [...document.querySelectorAll('.leave-day-portion')].reduce((sum, select) => sum + (select.value === 'full_day' ? 1 : 0.5), 0);
        document.getElementById('balanceAvailable').textContent = available.toFixed(1);
        document.getElementById('balanceBooking').textContent = booking.toFixed(1);
        requestOutput.textContent = request.toFixed(1);
        remainingOutput.textContent = (available - booking - request).toFixed(1);
        const days = [...document.querySelectorAll('.leave-day-portion')].map(select => ({ date: select.dataset.date, portion: select.value }));
        if (jsonInput) jsonInput.value = JSON.stringify(days);
    };
    const buildDateRows = () => {
        if (!rowsContainer || !startInput.value || !endInput.value || startInput.value > endInput.value) {
            if (rowsContainer) rowsContainer.innerHTML = '<div class="p-5 text-center text-slate-400">Choose a valid date range to configure each day.</div>';
            updateBalance(); return;
        }
        const start = new Date(startInput.value + 'T00:00:00');
        const end = new Date(endInput.value + 'T00:00:00');
        const rows = [];
        for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
            if (rows.length >= 366) break;
            // The date is written out as it reads on the calendar. Converting it
            // to universal time first moved every day one back for anyone ahead
            // of that time, so the days applied for were not the days shown.
            const value = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
            const label = date.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
            rows.push(`<div class="d-flex align-items-center justify-content-between gap-3 px-4 py-3 border-bottom border-slate-100"><div><div class="fw-semibold text-slate-800">${label}</div><div class="text-xs text-slate-400">${value}</div></div><select class="form-select rounded-lg leave-day-portion" style="max-width:180px" data-date="${value}"><option value="full_day">Full Day</option><option value="first_half">First Half</option><option value="second_half">Second Half</option></select></div>`);
        }
        rowsContainer.innerHTML = rows.join('');
        rowsContainer.querySelectorAll('select').forEach(select => select.addEventListener('change', updateBalance));
        updateBalance();
    };
    [startInput, endInput].filter(Boolean).forEach(input => input.addEventListener('change', buildDateRows));
    leaveTypeSelect?.addEventListener('change', updateBalance);
    const applyEmployeeSelect = document.getElementById('leaveApplyEmployeeSelect');
    if (applyEmployeeSelect && leaveTypeSelect) {
        leaveTypeSelect.disabled = true;
        applyEmployeeSelect.addEventListener('change', async () => {
            leaveTypeSelect.innerHTML = '<option value="">Select leave type</option>';
            leaveTypeSelect.disabled = true;
            document.getElementById('balanceAvailable').textContent = '0.0';
            document.getElementById('balanceBooking').textContent = '0.0';
            requestOutput.textContent = '0.0';
            remainingOutput.textContent = '0.0';
            if (!applyEmployeeSelect.value) return;

            const payload = new FormData();
            payload.set('action', 'get_leave_balances');
            payload.set('employee_id', applyEmployeeSelect.value);
            try {
                const data = await postHrms(payload);
                (data.balances || []).filter(balance => balance.eligible).forEach(balance => {
                    const option = document.createElement('option');
                    option.value = balance.id;
                    option.textContent = balance.name;
                    option.dataset.name = balance.name;
                    option.dataset.available = balance.available;
                    option.dataset.booking = balance.current_booking;
                    option.dataset.remaining = balance.remaining;
                    option.dataset.canApply = balance.can_apply ? '1' : '0';
                    option.disabled = !balance.can_apply;
                    leaveTypeSelect.appendChild(option);
                });
                leaveTypeSelect.disabled = false;
                updateBalance();
                if (leaveTypeSelect.options.length === 1) notify('warning', 'No eligible leave balance is configured for this employee.');
            } catch (error) {
                notify('error', error.message);
            }
        });
    }
    document.querySelectorAll('.leave-type-card[data-can-apply="1"]').forEach(card => card.addEventListener('click', () => {
        leaveTypeSelect.value = card.dataset.leaveTypeId; updateBalance(); bootstrap.Modal.getOrCreateInstance(document.getElementById('applyLeaveModal')).show();
    }));
    document.getElementById('applyLeaveForm')?.addEventListener('submit', async event => {
        event.preventDefault(); updateBalance();
        if (!jsonInput.value || jsonInput.value === '[]') { notify('error', 'Select a valid leave date range.'); return; }
        const button = document.getElementById('submitLeaveBtn'); button.disabled = true; button.querySelector('.spinner-border').classList.remove('d-none');
        try { const data = await postHrms(new FormData(event.currentTarget)); notify('success', data.message); window.location.reload(); }
        catch (error) { notify('error', error.message); button.disabled = false; button.querySelector('.spinner-border').classList.add('d-none'); }
    });
    const leaveAllocationForm = document.getElementById('leaveAllocationForm');
    const allocationEmployeeSelect = leaveAllocationForm?.elements.employee_id;
    const allocationTypeSelect = leaveAllocationForm?.elements.leave_type_id;
    const syncAllocationLeaveTypes = () => {
        if (!allocationEmployeeSelect || !allocationTypeSelect) return;
        const gender = Number(allocationEmployeeSelect.selectedOptions[0]?.dataset.gender || 0);
        [...allocationTypeSelect.options].forEach(option => {
            if (!option.value) return;
            const eligibility = option.dataset.genderEligibility || 'all';
            option.disabled = eligibility === 'female' ? gender !== 2 : eligibility === 'male' ? gender !== 1 : false;
        });
        if (allocationTypeSelect.selectedOptions[0]?.disabled) allocationTypeSelect.value = '';
    };
    allocationEmployeeSelect?.addEventListener('change', syncAllocationLeaveTypes);
    leaveAllocationForm?.addEventListener('submit', async event => {
        event.preventDefault(); try { const data = await postHrms(new FormData(event.currentTarget)); notify('success', data.message); window.location.reload(); } catch (error) { notify('error', error.message); }
    });
    const leaveTypeForm = document.getElementById('leaveTypeForm');
    const resetLeaveTypeForm = (silent = false) => {
        if (!leaveTypeForm) return;
        leaveTypeForm.reset();
        leaveTypeForm.elements.leave_type_id.value = '';
        leaveTypeForm.elements.color.value = '#10b981';
        const paidRadio = document.getElementById('leaveTypePaid');
        const unpaidRadio = document.getElementById('leaveTypeUnpaid');
        if (paidRadio) paidRadio.checked = true;
        if (unpaidRadio) unpaidRadio.checked = false;
        const negBal = document.getElementById('leaveTypeNegativeBalance');
        if (negBal) negBal.checked = false;
        const stat = document.getElementById('leaveTypeStatus');
        if (stat) stat.checked = true;
        if (leaveTypeForm.elements.company_id?.tagName === 'SELECT') leaveTypeForm.elements.company_id.disabled = false;
        document.getElementById('leaveTypeFormTitle').textContent = 'Add Leave Type';
        const modeBadge = document.getElementById('leaveTypeModeBadge');
        if (modeBadge) {
            modeBadge.textContent = 'New';
            modeBadge.className = 'badge rounded-pill bg-primary-100 text-primary text-xs';
        }
        const saveBtn = document.getElementById('saveLeaveTypeBtn');
        if (saveBtn) saveBtn.innerHTML = '<i class="ti ti-plus me-2"></i>Create Leave Type';
        if (!silent) {
            leaveTypeForm.elements.code?.focus();
            notify('info', 'Form reset. Ready to add a new leave type.');
        }
    };
    document.getElementById('newLeaveType')?.addEventListener('click', () => resetLeaveTypeForm(false));
    document.getElementById('leaveTypesModal')?.addEventListener('shown.bs.modal', () => {
        if (!leaveTypeForm.elements.leave_type_id.value) resetLeaveTypeForm(true);
    });
    document.querySelectorAll('.edit-leave-type').forEach(button => button.addEventListener('click', () => {
        const type = JSON.parse(button.dataset.leaveType);
        leaveTypeForm.elements.leave_type_id.value = type.id;
        leaveTypeForm.elements.code.value = type.code;
        leaveTypeForm.elements.name.value = type.name;
        leaveTypeForm.elements.description.value = type.description || '';
        leaveTypeForm.elements.color.value = type.color;
        leaveTypeForm.elements.gender_eligibility.value = type.gender_eligibility;
        const isPaid = Number(type.is_paid) === 1;
        const paidRadio = document.getElementById('leaveTypePaid');
        const unpaidRadio = document.getElementById('leaveTypeUnpaid');
        if (paidRadio) paidRadio.checked = isPaid;
        if (unpaidRadio) unpaidRadio.checked = !isPaid;
        const negBal = document.getElementById('leaveTypeNegativeBalance');
        if (negBal) negBal.checked = Number(type.allow_negative_balance) === 1;
        const stat = document.getElementById('leaveTypeStatus');
        if (stat) stat.checked = Number(type.status) === 1;
        if (leaveTypeForm.elements.company_id?.tagName === 'SELECT') {
            leaveTypeForm.elements.company_id.value = type.company_id || '';
            leaveTypeForm.elements.company_id.disabled = true;
        }
        document.getElementById('leaveTypeFormTitle').textContent = 'Edit Leave Type';
        const modeBadge = document.getElementById('leaveTypeModeBadge');
        if (modeBadge) {
            modeBadge.textContent = 'Edit';
            modeBadge.className = 'badge rounded-pill bg-amber-100 text-amber-700 text-xs';
        }
        const saveBtn = document.getElementById('saveLeaveTypeBtn');
        if (saveBtn) saveBtn.innerHTML = '<i class="ti ti-device-floppy me-2"></i>Update Leave Type';
        leaveTypeForm.elements.name?.focus();
    }));
    leaveTypeForm?.addEventListener('submit', async event => { event.preventDefault(); try { const data = await postHrms(new FormData(event.currentTarget)); notify('success', data.message); window.location.reload(); } catch (error) { notify('error', error.message); } });

    function escapeHtml(str) {
        return String(str || '').replace(/[&<>"']/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
        });
    }

    function renderSmartPaginationJs(totalPages, currentPage, callbackName) {
        totalPages = Math.max(1, parseInt(totalPages) || 1);
        currentPage = Math.min(Math.max(1, parseInt(currentPage) || 1), totalPages);

        if (totalPages <= 1) {
            return '';
        }

        let html = '';

        const prev = currentPage - 1;
        const prevDisabled = (currentPage === 1) ? 'disabled' : '';
        const prevOnclick = (currentPage === 1) ? '' : 'onclick="' + callbackName + '(' + prev + ')"';
        html += '<li class="page-item ' + prevDisabled + '"><a class="page-link page-link-label" href="javascript:void(0)" ' + prevOnclick + '>Prev</a></li>';

        let pageCandidates = [1, totalPages];
        for (let p = Math.max(1, currentPage - 2); p <= Math.min(totalPages, currentPage + 2); p++) {
            pageCandidates.push(p);
        }
        pageCandidates = Array.from(new Set(pageCandidates)).sort(function(a, b) { return a - b; });

        let previousRenderedPage = 0;
        pageCandidates.forEach(function(p) {
            if (previousRenderedPage > 0 && p > previousRenderedPage + 1) {
                html += '<li class="page-item disabled"><span class="page-link">&hellip;</span></li>';
            }
            if (p === currentPage) {
                html += '<li class="page-item active" aria-current="page"><span class="page-link">' + p + '</span></li>';
            } else {
                html += '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="' + callbackName + '(' + p + ')">' + p + '</a></li>';
            }
            previousRenderedPage = p;
        });

        const next = currentPage + 1;
        const nextDisabled = (currentPage === totalPages) ? 'disabled' : '';
        const nextOnclick = (currentPage === totalPages) ? '' : 'onclick="' + callbackName + '(' + next + ')"';
        html += '<li class="page-item ' + nextDisabled + '"><a class="page-link page-link-label" href="javascript:void(0)" ' + nextOnclick + '>Next</a></li>';

        return html;
    }

    function getLeaveStatusBadge(status) {
        status = (status || '').toLowerCase();
        let cls = 'bg-amber-100 text-amber-700';
        if (status === 'approved') cls = 'bg-emerald-100 text-emerald-700';
        else if (status === 'rejected') cls = 'bg-rose-100 text-rose-700';
        else if (status === 'cancelled') cls = 'bg-slate-100 text-slate-600';
        const label = status ? status.charAt(0).toUpperCase() + status.slice(1) : '';
        return '<span class="badge rounded-pill ' + cls + '">' + escapeHtml(label) + '</span>';
    }

    <?php if ($canManageLeave): ?>
    const allAllocations = <?= json_encode($allocationRows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?> || [];
    const allManagerApplications = <?= json_encode($managerApplications, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?> || [];
    <?php else: ?>
    const allAllocations = [];
    const allManagerApplications = [];
    <?php endif; ?>

    let selectedAllocationTypes = [];
    let allocationCurrentPage = 1;
    function renderAllocationTable(page) {
        const tableBody = document.getElementById('leaveAllocationTableBody');
        if (!tableBody) return;

        allocationCurrentPage = parseInt(page) || 1;
        const search = (document.getElementById('leaveAllocationSearch')?.value || '').toLowerCase().trim();
        const perPage = parseInt(document.getElementById('leaveAllocationPerPage')?.value || document.getElementById('leaveAllocationPerPageSelect')?.value || '10');

        const filtered = allAllocations.filter(function(allocation) {
            if (selectedAllocationTypes.length > 0) {
                if (!selectedAllocationTypes.includes(String(allocation.leave_type_id))) {
                    return false;
                }
            }
            if (!search) return true;
            const fullName = ((allocation.first_name || '') + ' ' + (allocation.last_name || '')).toLowerCase();
            const empCode = (allocation.emp_code || '').toLowerCase();
            const companyName = (allocation.company_name || '').toLowerCase();
            const branchName = (allocation.branch_name || '').toLowerCase();
            const leaveTypeName = (allocation.leave_type_name || '').toLowerCase();
            const leaveYear = String(allocation.leave_year || '');
            return fullName.includes(search) || empCode.includes(search) || companyName.includes(search) || branchName.includes(search) || leaveTypeName.includes(search) || leaveYear.includes(search);
        });

        const totalRows = filtered.length;
        const totalPages = Math.ceil(totalRows / perPage) || 1;
        if (allocationCurrentPage > totalPages) allocationCurrentPage = totalPages;
        if (allocationCurrentPage < 1) allocationCurrentPage = 1;

        const startIndex = (allocationCurrentPage - 1) * perPage;
        const pageRows = filtered.slice(startIndex, startIndex + perPage);

        if (totalRows === 0) {
            tableBody.innerHTML = '<tr><td colspan="8" class="text-center text-slate-500 py-10">No leave allocations found in your organization scope.</td></tr>';
            const wrapper = document.getElementById('leaveAllocationPaginationWrapper');
            if (wrapper) wrapper.innerHTML = '';
            const summary = document.getElementById('leaveAllocationPaginationSummary');
            if (summary) summary.textContent = 'Showing 0 results of 0';
            return;
        }

        let html = '';
        pageRows.forEach(function(allocation) {
            const allocatedTotal = (parseFloat(allocation.allocated_days) || 0) + (parseFloat(allocation.carried_forward_days) || 0) + (parseFloat(allocation.adjustment_days) || 0);
            const approvedTotal = parseFloat(allocation.approved_days) || 0;
            const pendingTotal = parseFloat(allocation.pending_days) || 0;
            const remainingTotal = allocatedTotal - approvedTotal - pendingTotal;
            const fullName = ((allocation.first_name || '') + ' ' + (allocation.last_name || '')).trim();
            const empCode = allocation.emp_code || 'No employee ID';
            const companyName = allocation.company_name || 'Unassigned';
            const branchName = allocation.branch_name || 'All branches';
            const leaveTypeName = allocation.leave_type_name || '';
            const leaveYear = parseInt(allocation.leave_year) || '';

            html += '<tr class="leave-allocation-row">';
            html += '<td class="px-5 py-4"><div class="fw-bold text-slate-800">' + escapeHtml(fullName) + '</div><div class="text-xs text-slate-400">' + escapeHtml(empCode) + '</div></td>';
            html += '<td class="py-4 text-slate-600"><div>' + escapeHtml(companyName) + '</div><div class="text-xs text-slate-400">' + escapeHtml(branchName) + '</div></td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(leaveTypeName) + '</td>';
            html += '<td class="py-4 text-slate-600">' + leaveYear + '</td>';
            html += '<td class="py-4 fw-semibold text-slate-700">' + allocatedTotal.toFixed(1) + '</td>';
            html += '<td class="py-4 text-slate-600">' + approvedTotal.toFixed(1) + '</td>';
            html += '<td class="py-4 text-slate-600">' + pendingTotal.toFixed(1) + '</td>';
            html += '<td class="px-5 py-4 fw-bold ' + (remainingTotal < 0 ? 'text-rose-600' : 'text-emerald-700') + '">' + remainingTotal.toFixed(1) + '</td>';
            html += '</tr>';
        });

        tableBody.innerHTML = html;
        const wrapper = document.getElementById('leaveAllocationPaginationWrapper');
        if (wrapper) wrapper.innerHTML = renderSmartPaginationJs(totalPages, allocationCurrentPage, 'changeAllocationPage');
        const startItem = totalRows > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(startIndex + perPage, totalRows);
        const summary = document.getElementById('leaveAllocationPaginationSummary');
        if (summary) summary.textContent = 'Showing ' + startItem + ' to ' + endItem + ' results of ' + totalRows;
    }

    window.changeAllocationPage = function(p) {
        renderAllocationTable(p);
    };

    let selectedManagerTypes = [];
    let selectedManagerStatuses = [];
    let managerCurrentPage = 1;
    function renderManagerTable(page) {
        const tableBody = document.getElementById('leaveManagerTableBody');
        if (!tableBody) return;

        managerCurrentPage = parseInt(page) || 1;
        const search = (document.getElementById('leaveManagerSearch')?.value || '').toLowerCase().trim();
        const perPage = parseInt(document.getElementById('leaveManagerPerPage')?.value || document.getElementById('leaveManagerPerPageSelect')?.value || '10');

        const filtered = allManagerApplications.filter(function(application) {
            if (selectedManagerTypes.length > 0) {
                if (!selectedManagerTypes.includes(String(application.leave_type_id))) {
                    return false;
                }
            }
            if (selectedManagerStatuses.length > 0) {
                const st = (application.status || '').toLowerCase();
                if (!selectedManagerStatuses.includes(st)) {
                    return false;
                }
            }
            if (!search) return true;
            const fullName = ((application.first_name || '') + ' ' + (application.last_name || '')).toLowerCase();
            const empCode = (application.emp_code || '').toLowerCase();
            const appNo = (application.application_no || '').toLowerCase();
            const leaveType = (application.leave_type_name || '').toLowerCase();
            const status = (application.status || '').toLowerCase();
            const period = ((application.start_date || '') + ' ' + (application.end_date || '')).toLowerCase();
            return fullName.includes(search) || empCode.includes(search) || appNo.includes(search) || leaveType.includes(search) || status.includes(search) || period.includes(search);
        });

        const totalRows = filtered.length;
        const totalPages = Math.ceil(totalRows / perPage) || 1;
        if (managerCurrentPage > totalPages) managerCurrentPage = totalPages;
        if (managerCurrentPage < 1) managerCurrentPage = 1;

        const startIndex = (managerCurrentPage - 1) * perPage;
        const pageRows = filtered.slice(startIndex, startIndex + perPage);

        if (totalRows === 0) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-slate-500 py-10">No applications in your organization scope.</td></tr>';
            const wrapper = document.getElementById('leaveManagerPaginationWrapper');
            if (wrapper) wrapper.innerHTML = '';
            const summary = document.getElementById('leaveManagerPaginationSummary');
            if (summary) summary.textContent = 'Showing 0 results of 0';
            return;
        }

        let html = '';
        pageRows.forEach(function(application) {
            const fullName = ((application.first_name || '') + ' ' + (application.last_name || '')).trim();
            const empCode = application.emp_code || 'No employee ID';
            const appNo = application.application_no || '';
            const leaveType = application.leave_type_name || '';
            const period = (application.start_date || '') + ' – ' + (application.end_date || '');
            const days = (parseFloat(application.total_days) || 0).toFixed(1);
            const modalPayload = {
                id: parseInt(application.id),
                application_no: appNo,
                employee: fullName,
                emp_code: application.emp_code,
                leave_type: leaveType,
                start_date: application.start_date,
                end_date: application.end_date,
                total_days: application.total_days,
                team_email: application.team_email,
                reason: application.reason,
                status: application.status,
                leave_days: application.leave_days,
                action_note: application.action_note
            };

            html += '<tr>';
            html += '<td class="px-5 py-4"><div class="fw-bold text-slate-800">' + escapeHtml(fullName) + '</div><div class="text-xs text-slate-400">' + escapeHtml(empCode) + '</div></td>';
            html += '<td class="py-4 fw-semibold text-slate-700">' + escapeHtml(appNo) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(leaveType) + '</td>';
            html += '<td class="py-4 text-slate-600">' + escapeHtml(period) + '</td>';
            html += '<td class="py-4 text-slate-700">' + days + '</td>';
            html += '<td class="py-4">' + getLeaveStatusBadge(application.status) + '</td>';
            html += '<td class="px-5 py-4 text-end">';
            html += '<button type="button" class="btn btn-sm btn-icon btn-outline-primary rounded-lg review-leave-btn" data-application="' + escapeHtml(JSON.stringify(modalPayload)) + '" title="Open application"><i class="ti ti-pencil"></i></button>';
            html += '</td>';
            html += '</tr>';
        });

        tableBody.innerHTML = html;
        const wrapper = document.getElementById('leaveManagerPaginationWrapper');
        if (wrapper) wrapper.innerHTML = renderSmartPaginationJs(totalPages, managerCurrentPage, 'changeManagerPage');
        const startItem = totalRows > 0 ? startIndex + 1 : 0;
        const endItem = Math.min(startIndex + perPage, totalRows);
        const summary = document.getElementById('leaveManagerPaginationSummary');
        if (summary) summary.textContent = 'Showing ' + startItem + ' to ' + endItem + ' results of ' + totalRows;
    }

    window.changeManagerPage = function(p) {
        renderManagerTable(p);
    };

    let reviewApplication = null;

    document.addEventListener('click', (e) => {
        // Top Allocation Per Page items
        const allocTopItem = e.target.closest('.leave-allocation-per-page-item');
        if (allocTopItem) {
            e.preventDefault();
            const val = allocTopItem.getAttribute('data-val');
            const label = allocTopItem.textContent.trim();
            const topText = document.getElementById('leaveAllocationPerPageText');
            if (topText) topText.textContent = label;
            const topInput = document.getElementById('leaveAllocationPerPage');
            if (topInput) topInput.value = val;
            const footerSelect = document.getElementById('leaveAllocationPerPageSelect');
            if (footerSelect) footerSelect.value = val;
            const footerText = document.getElementById('perPageText-leaveAllocationPerPageSelect');
            if (footerText) footerText.textContent = label;
            renderAllocationTable(1);
            return;
        }

        // Top Manager Per Page items
        const mgrTopItem = e.target.closest('.leave-manager-per-page-item');
        if (mgrTopItem) {
            e.preventDefault();
            const val = mgrTopItem.getAttribute('data-val');
            const label = mgrTopItem.textContent.trim();
            const topText = document.getElementById('leaveManagerPerPageText');
            if (topText) topText.textContent = label;
            const topInput = document.getElementById('leaveManagerPerPage');
            if (topInput) topInput.value = val;
            const footerSelect = document.getElementById('leaveManagerPerPageSelect');
            if (footerSelect) footerSelect.value = val;
            const footerText = document.getElementById('perPageText-leaveManagerPerPageSelect');
            if (footerText) footerText.textContent = label;
            renderManagerTable(1);
            return;
        }

        // Footer Per Page items
        const item = e.target.closest('.per-page-item');
        if (item) {
            e.preventDefault();
            const selectId = item.getAttribute('data-select-id');
            const val = item.getAttribute('data-val');
            const label = item.textContent.trim();
            if (!selectId) return;

            const selectEl = document.getElementById(selectId);
            if (selectEl) {
                selectEl.value = val;
            }
            const textEl = document.getElementById('perPageText-' + selectId);
            if (textEl) {
                textEl.textContent = label;
            }
            if (selectId === 'leaveAllocationPerPageSelect') {
                const topText = document.getElementById('leaveAllocationPerPageText');
                if (topText) topText.textContent = label;
                const topInput = document.getElementById('leaveAllocationPerPage');
                if (topInput) topInput.value = val;
                renderAllocationTable(1);
            } else if (selectId === 'leaveManagerPerPageSelect') {
                const topText = document.getElementById('leaveManagerPerPageText');
                if (topText) topText.textContent = label;
                const topInput = document.getElementById('leaveManagerPerPage');
                if (topInput) topInput.value = val;
                renderManagerTable(1);
            }
            return;
        }

        const reviewBtn = e.target.closest('.review-leave-btn');
        if (reviewBtn) {
            reviewApplication = JSON.parse(reviewBtn.getAttribute('data-application'));
            document.getElementById('reviewLeaveReference').textContent = reviewApplication.application_no;
            document.getElementById('reviewLeaveEmployee').textContent = `${reviewApplication.employee} (${reviewApplication.emp_code || 'No ID'})`;
            document.getElementById('reviewLeaveType').textContent = reviewApplication.leave_type;
            document.getElementById('reviewLeaveTotal').textContent = Number(reviewApplication.total_days).toFixed(1) + ' days';
            document.getElementById('reviewLeaveTeam').textContent = reviewApplication.team_email || 'Not provided';
            document.getElementById('reviewLeaveReason').textContent = reviewApplication.reason;
            const days = (reviewApplication.leave_days || '').split(',').filter(Boolean).map(item => { const [date, portion] = item.split('|'); return `<div class="d-flex justify-content-between px-4 py-3 border-bottom border-slate-100"><span class="fw-semibold text-slate-700">${escapeHtml(date)}</span><span class="text-slate-500">${escapeHtml(portion.replaceAll('_',' '))}</span></div>`; });
            document.getElementById('reviewLeaveDays').innerHTML = days.join('') || '<div class="p-4 text-slate-400">No day details.</div>';
            document.getElementById('reviewLeaveNote').value = reviewApplication.action_note || '';
            document.getElementById('reviewLeaveActions').classList.toggle('d-none', reviewApplication.status !== 'pending');
            document.getElementById('reviewLeaveDecision').classList.toggle('d-none', reviewApplication.status !== 'pending');
            bootstrap.Modal.getOrCreateInstance(document.getElementById('reviewLeaveModal')).show();
            return;
        }
    });

    // Allocation Filter Checkbox Handling
    document.addEventListener('change', (e) => {
        if (e.target.matches('.leave-allocation-type-filter')) {
            const val = e.target.value;
            const checked = e.target.checked;
            const allBoxes = document.querySelectorAll('.leave-allocation-type-filter');
            const allCheckbox = document.querySelector('.leave-allocation-type-filter[value="all"]');
            const otherCheckboxes = document.querySelectorAll('.leave-allocation-type-filter:not([value="all"])');

            if (val === 'all') {
                allBoxes.forEach(box => box.checked = checked);
            } else {
                const checkedOthers = document.querySelectorAll('.leave-allocation-type-filter:not([value="all"]):checked').length;
                if (allCheckbox) allCheckbox.checked = (checkedOthers === otherCheckboxes.length);
            }

            selectedAllocationTypes = [];
            if (allCheckbox && !allCheckbox.checked) {
                document.querySelectorAll('.leave-allocation-type-filter:checked').forEach(box => {
                    if (box.value !== 'all') selectedAllocationTypes.push(box.value);
                });
            }
            renderAllocationTable(1);
            return;
        }

        if (e.target.matches('.leave-manager-type-filter')) {
            const val = e.target.value;
            const checked = e.target.checked;
            const allBoxes = document.querySelectorAll('.leave-manager-type-filter');
            const allCheckbox = document.querySelector('.leave-manager-type-filter[value="all"]');
            const otherCheckboxes = document.querySelectorAll('.leave-manager-type-filter:not([value="all"])');

            if (val === 'all') {
                allBoxes.forEach(box => box.checked = checked);
            } else {
                const checkedOthers = document.querySelectorAll('.leave-manager-type-filter:not([value="all"]):checked').length;
                if (allCheckbox) allCheckbox.checked = (checkedOthers === otherCheckboxes.length);
            }

            selectedManagerTypes = [];
            if (allCheckbox && !allCheckbox.checked) {
                document.querySelectorAll('.leave-manager-type-filter:checked').forEach(box => {
                    if (box.value !== 'all') selectedManagerTypes.push(box.value);
                });
            }
            renderManagerTable(1);
            return;
        }

        if (e.target.matches('.leave-manager-status-filter')) {
            const val = e.target.value;
            const checked = e.target.checked;
            const allBoxes = document.querySelectorAll('.leave-manager-status-filter');
            const allCheckbox = document.querySelector('.leave-manager-status-filter[value="all"]');
            const otherCheckboxes = document.querySelectorAll('.leave-manager-status-filter:not([value="all"])');

            if (val === 'all') {
                allBoxes.forEach(box => box.checked = checked);
            } else {
                const checkedOthers = document.querySelectorAll('.leave-manager-status-filter:not([value="all"]):checked').length;
                if (allCheckbox) allCheckbox.checked = (checkedOthers === otherCheckboxes.length);
            }

            selectedManagerStatuses = [];
            if (allCheckbox && !allCheckbox.checked) {
                document.querySelectorAll('.leave-manager-status-filter:checked').forEach(box => {
                    if (box.value !== 'all') selectedManagerStatuses.push(box.value);
                });
            }
            renderManagerTable(1);
            return;
        }
    });

    document.querySelectorAll('.leave-decision-btn').forEach(button => button.addEventListener('click', async () => {
        if (!reviewApplication) return;
        const form = new FormData(); form.set('action','review_leave'); form.set('csrf_token',csrfToken); form.set('application_id',reviewApplication.id); form.set('decision',button.dataset.decision); form.set('note',document.getElementById('reviewLeaveNote').value);
        button.disabled = true; try { const data = await postHrms(form); notify('success', data.message); window.location.reload(); } catch(error) { notify('error', error.message); button.disabled = false; }
    }));

    document.getElementById('leaveManagerSearch')?.addEventListener('input', () => {
        renderManagerTable(1);
    });
    document.getElementById('leaveAllocationSearch')?.addEventListener('input', () => {
        renderAllocationTable(1);
    });

    if (document.getElementById('leaveAllocationTableBody')) {
        renderAllocationTable(1);
    }
    if (document.getElementById('leaveManagerTableBody')) {
        renderManagerTable(1);
    }
});
</script>
<?php endSection(); ?>
