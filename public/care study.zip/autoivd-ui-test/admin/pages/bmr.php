<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= $pageTitle ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage BMR templates, headers, footers and section structures</p>
        </div>
    </div>

    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">

                    <!-- Per-page dropdown (moved from footer to top strip) -->
                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            type="button" data-bs-toggle="dropdown">
                            <span id="bmrPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="bmr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="bmr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="bmr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="bmr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="bmr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="bmr-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchData"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>
                    <?php if (roleHasPermission($_SESSION['role_id'], 'hr_advance_salary_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-40 shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            data-bs-toggle="modal" data-bs-target="#employeeAdvancePayModal"><i
                                class="ti ti-plus text-lg"></i><span class="whitespace-nowrap">Add New</span></button>
                    <?php } ?>
                </div>
            </div>

            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left">
                    <thead class="border-b border-slate-100 bg-white whitespace-nowrap">
                        <tr>
                            <th class="w-16 px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">#
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Timestamp</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Product
                                Name</th>
                            <th class="sortable cursor-pointer px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-50/50"
                                data-column="u.name">Template Name</th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Header
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Footer
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Status
                            </th>
                            <th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400"
                                data-column="r.name">Created By</th>
                            <th
                                class="w-36 px-6 py-3 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100" id="advanceSalaryTableBody">
                    </tbody>
                </table>
            </div>

            <div class="demo-inline-spacing">
                <!-- Hide the per-page dropdown in footer -->
                <style>
                    #footerPerPageSelect + .dropdown { display: none !important; }
                </style>
                <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="employeeAdvancePayModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-file-plus text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Add Template</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Create a new BMR template with sections</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <form id="bmrTemplateCreateForm">
                    <div class="modal-body bg-slate-50/70 !px-4 !py-3">
                        <div class="mb-4">
                            <h6 class="mb-3 text-sm font-bold uppercase tracking-wider text-slate-500 flex items-center gap-2"><i class="ti ti-layout-grid text-base text-emerald-600"></i> Template Details</h6>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                                <div>
                                    <label for="product_name"
                                        class="mb-1 block text-sm font-medium text-slate-800">Product Name <strong
                                            class="text-rose-500">*</strong></label>
                                    <input class="input-theme" id="product_name" name="product_name"
                                        placeholder="Enter Product Name" required>
                                </div>
                                <div>
                                    <label for="template_name"
                                        class="mb-1 block text-sm font-medium text-slate-800">Template Name <strong
                                            class="text-rose-500">*</strong></label>
                                    <input type="text" id="template_name" autocomplete="off" name="template_name"
                                        class="input-theme" placeholder="Enter Template Name" required />
                                </div>
                                <div>
                                    <label for="departmentList"
                                        class="mb-1 block text-sm font-medium text-slate-800">Department <strong
                                            class="text-rose-500">*</strong></label>
                                    <select name="department" id="departmentList" class="input-theme select2"
                                        required></select>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                <div>
                                    <label for="headerList"
                                        class="mb-1 block text-sm font-medium text-slate-800">Header <strong
                                            class="text-rose-500">*</strong></label>
                                    <select name="header" id="headerList" class="input-theme select2" required></select>
                                </div>
                                <div>
                                    <label for="footerList"
                                        class="mb-1 block text-sm font-medium text-slate-800">Footer <strong
                                            class="text-rose-500">*</strong></label>
                                    <select name="footer" id="footerList" class="input-theme select2" required></select>
                                </div>
                            </div>
                        </div>
                        <div class="mb-4">
                            <h6 class="mb-3 text-sm font-bold uppercase tracking-wider text-slate-500 flex items-center gap-2"><i class="ti ti-section text-base text-emerald-600"></i> Add Section</h6>
                            <div class="grid grid-cols-1 md:grid-cols-4 items-end gap-3 rounded-xl border border-slate-200 bg-white/90 p-3 shadow-sm">
                                <div>
                                    <label for="section_title"
                                        class="mb-1 block text-sm font-medium text-slate-800">Title</label>
                                    <input class="input-theme" id="section_title" placeholder="Section Title" />
                                </div>
                                <div>
                                    <label for="section_type"
                                        class="mb-1 block text-sm font-medium text-slate-800">Type</label>
                                    <select class="input-theme select2" id="section_type">
                                        <option value="">Select</option>
                                        <?php if (!empty(Constant::BMR_TEMPLATE['SECTION_TYPE'])) {
                                            foreach (Constant::BMR_TEMPLATE['SECTION_TYPE'] as $key => $val) { ?>
                                                <option value="<?= $key ?>"><?= $val['label'] ?></option>
                                            <?php }
                                        } ?>
                                    </select>
                                </div>
                                <div>
                                    <label for="page_no"
                                        class="mb-1 block text-sm font-medium text-slate-800">Page No.</label>
                                    <input type="number" class="input-theme" id="page_no" placeholder="Page No">
                                </div>
                                <div>
                                    <button
                                        class="inline-flex h-10 w-full items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 whitespace-nowrap"
                                        type="button" id="addSectionBtn"><i class="ti ti-plus text-lg"></i> Add Section</button>
                                </div>
                            </div>
                        </div>

                        <div id="sectionList"></div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><i
                                class="ti ti-check text-lg"></i> Save Template</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade animate__animated fadeIn" id="bmrPreviewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3"><span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"><i
                                class="ti ti-eye text-xl"></i></span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">BMR Template Preview</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Preview the generated template layout</p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-xl"></i></button>
                </div>
                <div class="modal-body max-h-[75vh] overflow-y-auto bg-slate-50/70 !px-4 !py-3" id="bmrPreviewBody">
                </div>
                <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                    <button type="button"
                        class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

</div>



<?php startSection('scripts'); ?>
<script src="<?= asset('assets/vendor/libs/sortablejs/sortable.js') ?>"></script>
<script>
    let sectionIndex = 0;
    let currentPage = 1;
    let currentSortColumn = 'bmrtmp.id';
    let currentSortDirection = 'DESC';

    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function (response) {
                let departmentOptions = response || [];
                let optionsHtml = '<option value="">---Select----</option>';
                if (Array.isArray(departmentOptions)) {
                    departmentOptions.forEach(unit => {
                        optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                    });
                }
                $("#departmentList").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadTemplateHeaderList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getTemplateHeaderList: 'getTemplateHeaderList'
            },
            success: function (response) {
                let headerOptions = response || [];
                let optionsHtml = '<option value="">---Select----</option>';
                if (Array.isArray(headerOptions)) {
                    headerOptions.forEach(unit => {
                        optionsHtml += `<option value="${unit.id}">${unit.header_name}</option>`;
                    });
                }
                $("#headerList").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function loadTemplateFooterList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getTemplatFooterList: 'getTemplatFooterList'
            },
            success: function (response) {
                let footerOptions = response || [];
                let optionsHtml = '<option value="">---Select----</option>';
                if (Array.isArray(footerOptions)) {
                    footerOptions.forEach(unit => {
                        optionsHtml += `<option value="${unit.id}">${unit.footer_name}</option>`;
                    });
                }
                $("#footerList").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }


    function loadBmrTemplateTable(page = 1) {
        currentPage = page;
        const search = $('#searchData').val().trim();
        const perPage = $('#perPageSelect').val();
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                loadBmrTemplates: 'loadBmrTemplates',
                page: page,
                per_page: perPage,
                search: search,
                sort_column: currentSortColumn,
                sort_direction: currentSortDirection
            },
            success: function (response) {
                $('#advanceSalaryTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
            },
            error: function () {
                $('#advanceSalaryTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function addSection() {
        let title = $('#section_title').val().trim();
        let type = $('#section_type').val();
        let pageNo = $('#page_no').val();
        let html = ``;
        if (title === '') {
            toastr.error('Section Title Required');
            return;
        }
        if (type === '') {
            toastr.error('Section Type Required');
            return;
        }
        if (pageNo === '' || isNaN(pageNo) || pageNo <= 0) {
            toastr.error('Valid Page Number Required');
            return;
        }
        html = `
            <div class="card p-3 mb-3 section-card" id="section_${sectionIndex}" data-index="${sectionIndex}">
                <input type="hidden" name="sections[${sectionIndex}][type]" value="${type}">
                <input type="hidden" name="sections[${sectionIndex}][page_no]" value="${pageNo}">
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-2">                    
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <span class="ti ti-grip-vertical section-handle-move cursor-move"></span>
                        <input type="text" class="form-control form-control-sm w-auto" name="sections[${sectionIndex}][title]" value="${title}" placeholder="Section Title" />
                        <span>| Page</span>
                        <input type="number" min="1" class="form-control form-control-sm w-auto bmr-page-no-input" name="sections[${sectionIndex}][page_no]" value="${pageNo}" />
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        ${type == APP_CONST.BMR_TEMPLATE.SECTION_TYPE_LABEL.NormalBlock ? `<button type="button" class="btn btn-info btn-sm" onclick="addFieldRow(this)"> Add Field </button>` : ''}
                        ${type == APP_CONST.BMR_TEMPLATE.SECTION_TYPE_LABEL.Table ? `<button type="button" class="btn btn-warning btn-sm" onclick="addTableRow(this)"> Add Row </button>` : ''}
                        ${type == APP_CONST.BMR_TEMPLATE.SECTION_TYPE_LABEL.StaticText ? `<button type="button" class="btn btn-secondary btn-sm" onclick="addStaticParagraph(this)"> Add Para </button>` : ''}  

                        <button type="button" class="btn btn-icon btn-label-danger btn-sm" onclick="removeSection(this)"> <span class="ti ti-trash"></span> </button>
                    </div>
                </div>
                <div id="field_area_${sectionIndex}"></div>
            </div>`;
        $('#sectionList').append(html);
        let newCard = $('#sectionList .section-card').last();
        enableChildDrag(newCard);
        sectionIndex++;
        $('#section_title').val('');
        $('#section_type').val('');
        $('#page_no').val('');
    }

    function addFieldRow(btn) {

        let sectionCard = $(btn).closest('.section-card');
        let sectionId = sectionCard.data('index');
        let fieldArea = sectionCard.find('[id^="field_area_"]');
        let count = fieldArea.find('.field-row').length;
        let html = `
        <div class="row field-row align-items-center mb-2 border rounded p-1" data-index="${count}">            
            <div class="col-md-1 col-6 mb-1">
                <span class="ti ti-grip-vertical cursor-move section-child-move"></span>
                <button type="button" class="btn btn-icon btn-label-danger" onclick="removeFieldRow(this)"> 
                    <span class="ti ti-trash"></span>
                </button>
            </div>
            <div class="col-md-3 col-12 mb-1">
                <input name="sections[${sectionId}][fields][${count}][label]" class="form-control" placeholder="Label">
            </div>
            <div class="col-md-3 col-12 mb-1">
                <input name="sections[${sectionId}][fields][${count}][key]" class="form-control" placeholder="Key">
            </div>
            <div class="col-md-2 col-6 mb-1">
                <select name="sections[${sectionId}][fields][${count}][type]" class="form-control">
                    <option value="1">Text</option>
                    <option value="2">Number</option>
                    <option value="3">Date</option>
                    <option value="4">Time</option>
                    <option value="5">Textarea</option>
                </select>
            </div>
            <div class="col-md-2 col-6 mb-1">
                <select name="sections[${sectionId}][fields][${count}][required]" class="form-control">
                    <option value="0">Optional</option>
                    <option value="1">Required</option>
                </select>
            </div>            
        </div>`;
        fieldArea.append(html);
    }

    function addStaticParagraph(btn) {
        let sectionCard = $(btn).closest('.section-card');
        let sectionId = sectionCard.data('index');
        let fieldArea = sectionCard.find('[id^="field_area_"]');
        let count = fieldArea.find('textarea').length;
        let html = `
        <div class="row field-row align-items-start mb-2 border rounded p-2" data-index="${count}">            
            <div class="col-md-2 col-6 mb-1">
                <span class="ti ti-grip-vertical cursor-move section-child-move"></span>
                <button type="button" class="btn btn-icon btn-label-danger" onclick="removeFieldRow(this)"> 
                    <span class="ti ti-trash"></span>
                </button>
            </div>
            <div class="col-md-10 col-12 mb-1">
                <textarea class="form-control" rows="1" name="sections[${sectionId}][static][${count}][static_text]" placeholder="Static Content"></textarea>
            </div>            
        </div>`;
        fieldArea.append(html);
    }

    function addTableRow(btn) {
        let sectionCard = $(btn).closest('.section-card');
        let sectionId = sectionCard.data('index');
        let fieldArea = sectionCard.find('[id^="field_area_"]');
        let count = fieldArea.find('.table-row').length;
        let html = `
        <div class="table-row border rounded p-2 mb-2" data-row="${count}">
            <input type="hidden" name="sections[${sectionId}][rows][${count}][row_index]" value="${count}" />
            <div class="d-flex mb-2">
                <span class="ti ti-grip-vertical cursor-move section-child-move"></span>
                <button type="button" class="btn btn-icon btn-label-danger ms-2" onclick="removeTableRow(this)">
                    <span class="ti ti-trash"></span>
                </button>
            </div>
            <div class="cell-container" id="cell_area_${sectionId}_${count}"></div>
            <button type="button" class="btn btn-sm btn-primary mt-2" onclick="addCell(this)">Add Cell </button>
        </div>`;
        fieldArea.append(html);
        setTimeout(() => {
            enableCellDrag(sectionId, count);
        }, 100);
    }

    function addCell(btn) {
        let tableRow = $(btn).closest('.table-row');
        let sectionCard = $(btn).closest('.section-card');
        let sectionId = sectionCard.data('index');
        let rowId = tableRow.data('row');
        let count = tableRow.find('.table-cell').length;
        let html = `
        <div class="row table-cell mb-1">
            <div class="col-md-1">
                <span class="ti ti-grip-vertical table-cell-move cursor-move"></span>            
                <button type="button" class="btn btn-sm btn-danger" onclick="removeCell(this,${sectionId})">
                ×
                </button>
            </div>
            <div class="col-md-2">
                <select name="sections[${sectionId}][rows][${rowId}][cells][${count}][type]" class="form-control cell-type">
                    <option value="1">Label</option>
                    <option value="3">Static Value</option>
                    <option value="2">User Input</option>
                </select>
            </div>
            <div class="col-md-3">
                <input class="form-control" name="sections[${sectionId}][rows][${rowId}][cells][${count}][label]" placeholder="Label / Static value">
            </div>
            <div class="col-md-2">
                <input class="form-control cell-key" name="sections[${sectionId}][rows][${rowId}][cells][${count}][key]" placeholder="Field Key">
            </div>
            <div class="col-md-2">
                <input class="form-control" name="sections[${sectionId}][rows][${rowId}][cells][${count}][colspan]" value="1" placeholder="Colspan">
            </div>
            <div class="col-md-2">
                <input class="form-control" name="sections[${sectionId}][rows][${rowId}][cells][${count}][rowspan]" value="1" placeholder="Rowspan">
            </div>
        </div>`;
        tableRow.find('.cell-container').append(html);
    }

    function removeSection(btn) {
        $(btn).closest('.section-card').remove();
        reindexSections();
    }

    function removeCell(btn, sectionId) {
        $(btn).closest('.table-cell').remove();
        reindexFields(sectionId);
    }

    function removeFieldRow(btn) {
        let sectionId = $(btn).closest('.section-card').data('index');
        $(btn).closest('.field-row').remove();
        reindexFields(sectionId);
    }

    function removeTableRow(btn) {
        let sectionId = $(btn).closest('.section-card').data('index');
        $(btn).closest('.table-row').remove();
        reindexFields(sectionId);
    }

    function enableCellDrag(sectionId, rowId) {
        let el = document.getElementById('cell_area_' + sectionId + '_' + rowId);
        if (!el) return;
        if (el._sortable) { el._sortable.destroy(); }
        el._sortable = new Sortable(
            el, {
            animation: 150,
            ghostClass: 'bg-light',
            handle: '.table-cell-move',
            onEnd: function () {
                reindexFields(sectionId);
            }
        }
        );
    }

    function enableChildDrag(sectionCard) {
        let fieldArea = $(sectionCard).find('[id^="field_area_"]')[0];
        if (!fieldArea) return;
        if (fieldArea._sortable) {
            fieldArea._sortable.destroy();
        }

        fieldArea._sortable = new Sortable(fieldArea, {
            animation: 150,
            ghostClass: 'bg-light',
            handle: '.section-child-move',
            onEnd: function () {
                let sectionId = $(sectionCard).data('index');
                reindexFields(sectionId);
            }
        });
    }

    function reindexFields(sectionId) {
        let container = $('#field_area_' + sectionId);
        container.find('.field-row').each(function (index) {
            $(this).attr('data-index', index);
            $(this).find('input, select, textarea').each(function () {
                let name = $(this).attr('name');
                if (name) {
                    name = name.replace(/\[fields\]\[\d+\]/, '[fields][' + index + ']');
                    name = name.replace(/\[static\]\[\d+\]/, '[static][' + index + ']');
                    $(this).attr('name', name);
                }
            });
        });

        container.find('.table-row').each(function (rowIndex) {
            $(this).attr('data-row', rowIndex);
            let cellContainer = $(this).find('.cell-container');
            cellContainer.attr('id', 'cell_area_' + sectionId + '_' + rowIndex);
            enableCellDrag(sectionId, rowIndex);
            $(this).find('.table-cell').each(function (cellIndex) {
                $(this).find('input,select').each(function () {
                    let name = $(this).attr('name');
                    if (name) {
                        name = name.replace(/\[rows\]\[\d+\]/, '[rows][' + rowIndex + ']');
                        name = name.replace(/\[cells\]\[\d+\]/, '[cells][' + cellIndex + ']');
                        $(this).attr('name', name);
                    }
                });
            });
        });
    }

    function reindexSections() {
        $('#sectionList .section-card').each(function (index) {
            $(this).attr('id', 'section_' + index);
            $(this).attr('data-index', index);
            $(this).find('input, textarea, select').each(function () {
                let name = $(this).attr('name');
                if (name) {
                    name = name.replace(/sections\[\d+\]/, 'sections[' + index + ']');
                    $(this).attr('name', name);
                }
            });
            $(this).find('[id^="field_area_"]').attr('id', 'field_area_' + index);
            reindexFields(index);
            enableChildDrag(this);
            $(this).find('.table-row').each(function (rowIndex) {
                enableCellDrag(index, rowIndex);
            });
        });
    }

    $(document).on('click', "#addSectionBtn", function (e) {
        e.preventDefault();
        addSection();
    });

    $(document).ready(function () {
        loadTemplateHeaderList();
        loadTemplateFooterList();
        loadDepartmentsList();
        loadBmrTemplateTable();
        
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadBmrTemplateTable(1);
        });

        $('#searchData').on('input', function () {
            loadBmrTemplateTable(1);
        });

        // Top-strip per-page dropdown handler
        $(document).on('click', '.bmr-per-page-item', function () {
            const val = $(this).data('val');
            const label = $(this).text();
            $('#bmrPerPageText').text(label);
            $('#footerPerPageSelect').val(val).trigger('change');
        });
        
        $('#employeeAdvancePayModal').on('shown.bs.modal', function () {
            $('#employeeAdvancePayModal .select2').select2({
                dropdownParent: $('#employeeAdvancePayModal')
            });
        });

        new Sortable(document.getElementById('sectionList'), {
            animation: 150,
            ghostClass: 'bg-light',
            handle: '.section-handle-move',
            onEnd: function () {
                reindexSections();
            }
        });

        $("#bmrTemplateCreateForm").on('submit', function (e) {
            e.preventDefault();
            let form = document.getElementById('bmrTemplateCreateForm');
            let formData = new FormData(form);
            formData.append('saveBmrTemplate', 'saveBmrTemplate');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        $('#bmrTemplateCreateForm')[0].reset();
                        $('#sectionList').html('');
                        sectionIndex = 0;
                        loadBmrTemplateTable();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('Server Error');
                }
            });
        });
    });

    $(document).on('change', '.cell-type', function () {
        let row = $(this).closest('.table-cell');
        let type = $(this).val();
        if (type == 2) {
            row.find('.cell-key').prop('disabled', false);
        } else {
            row.find('.cell-key').prop('disabled', true);
        }
    });

    function showPreview(template_id) {
        $.post("ajax.php", {
            previewBMRTemplate: 1,
            template_id: template_id
        },
            function (res) {
                $("#bmrPreviewBody").html(res);
                $("#bmrPreviewModal").modal("show");
            });
    }
</script>
<?php endSection(); ?>