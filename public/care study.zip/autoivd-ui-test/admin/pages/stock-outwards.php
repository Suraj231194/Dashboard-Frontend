<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <style>
        #animationModal .modal-content,
        #editOrderReceivedModal .modal-content {
            display: flex;
            flex-direction: column;
            max-height: calc(100dvh - 2rem);
        }

        #animationModal .modal-header,
        #editOrderReceivedModal .modal-header,
        #addStockOutwardForm > .flex {
            flex: 0 0 auto;
        }

        #addStockOutwardForm,
        #editOrderReceivedForm {
            display: flex;
            flex: 1 1 auto;
            flex-direction: column;
            min-height: 0;
        }

        #animationModal .modal-body,
        #editOrderReceivedModal .modal-body {
            min-height: 0;
            overflow-y: auto;
        }

        #animationModal .select2-container--open,
        #editOrderReceivedModal .select2-container--open {
            z-index: 1095;
        }

        #processBulkDispatchBtn {
            background-color: var(--appearance-accent, #7c3aed) !important;
            color: #ffffff !important;
            opacity: 1 !important;
            border: none !important;
        }
        #processBulkDispatchBtn:hover {
            filter: brightness(0.9) !important;
        }
        #processBulkDispatchBtn:disabled {
            background-color: #e2e8f0 !important;
            color: #94a3b8 !important;
            cursor: not-allowed !important;
            opacity: 0.65 !important;
        }
    </style>
    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="ui-page-title-banner">
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight"><?= $pageTitle ?></h1>
            <p class="text-sm text-slate-500 mt-1">Manage dispatched goods and stock outward records</p>
        </div>
    </div>

    <!-- Inbound Dispatch Requests Widget -->
    <div id="inboundDispatchesWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" style="display: none;">
        <div class="overflow-hidden rounded-xl border border-slate-200 p-4 shadow-sm transition-all hover:shadow-md hover:bg-slate-50" style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: var(--appearance-accent-light, #f3e8ff); border-radius: 0.75rem;">
                    <i class="ti ti-truck-delivery" style="font-size: 1.5rem; color: var(--appearance-accent, #7c3aed);"></i>
                    <span id="inboundDispatchesCountBadge" style="position: absolute; top: -0.25rem; right: -0.25rem; display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; background-color: var(--appearance-accent, #7c3aed); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px; border: 2px solid white;">0</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight" style="font-size: 1.125rem; color: var(--appearance-accent, #4c1d95); margin: 0;">Inbound Dispatch Request(s)!</h3>
                    </div>
                    <p class="font-medium  mt-1 mb-0" style="font-size: 0.875rem;">
                        You have <span id="inboundDispatchesCountText" class="font-bold">0</span> dispatch request(s) shared from Order Management. Click here to review and dispatch.
                    </p>
                </div>
            </div>
            <div class="">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>

    <!-- ═══════════ Orders Section ═══════════ -->
    <!--
    <div class="w-full mb-6">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelectOrdRec" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="orderReceivedPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="order-received-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>
                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchProductsOrdRec"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search orders...">
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="px-6 py-3">Timestamp</th>
                            <th class="px-6 py-3">Order Date</th>
                            <th class="px-6 py-3">Order No</th>
                            <th class="px-6 py-3 text-center">Action</th>
                            <th class="px-6 py-3">Client Name</th>
                            <th class="px-6 py-3">Received By</th>
                            <th class="px-6 py-3">Dispatch Timeline</th>
                            <th class="px-6 py-3">Area/City</th>
                            <th class="px-6 py-3">Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="orderReceivedTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelectOrderReceived + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapperOrderReceived', 'paginationSummaryOrderReceived', 'footerPerPageSelectOrderReceived') ?>
        </div>
    </div>
    -->

    <!-- ═══════════ Stock Outwards Section ═══════════ -->
    <div class="w-full">
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col md:flex-row items-stretch md:items-center gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm">
                    <input type="hidden" id="perPageSelect" value="10">
                    <div class="dropdown shrink-0">
                        <button class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" type="button" data-bs-toggle="dropdown">
                            <span id="stockOutwardsPerPageText" class="whitespace-nowrap">10 items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a class="stock-outwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100000000">All items</a></li>
                            <li><a class="stock-outwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="5">5 items</a></li>
                            <li><a class="stock-outwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="10">10 items</a></li>
                            <li><a class="stock-outwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="25">25 items</a></li>
                            <li><a class="stock-outwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="50">50 items</a></li>
                            <li><a class="stock-outwards-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="100">100 items</a></li>
                        </ul>
                    </div>

                    <div class="relative h-10 min-w-[160px] max-w-[220px] flex-grow">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="text" id="searchUsers"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                            placeholder="Search Data...">
                    </div>

                    <?php if (roleHasPermission($_SESSION['role_id'], 'store_stock_outwards_add')) { ?>
                        <button type="button"
                            class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl bg-emerald-700 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="animationModalBtn" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Add New">
                            <i class="ti ti-plus text-lg"></i>
                        </button>
                    <?php } ?>
                </div>
            </div>

            <!-- Export filters -->
            <div class="border-b border-slate-200 bg-white px-6 py-3">
                <div class="flex flex-wrap items-center gap-3">
                    <div class="flex items-center gap-2">
                        <label for="fromDate" class="text-sm font-medium text-slate-700 whitespace-nowrap">From:</label>
                        <input type="date" id="fromDate" value="<?= date('Y-m-d', strtotime('-15 days')) ?>"
                            class="h-9 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" />
                    </div>
                    <div class="flex items-center gap-2">
                        <label for="toDate" class="text-sm font-medium text-slate-700 whitespace-nowrap">To:</label>
                        <input type="date" id="toDate" value="<?= date('Y-m-d') ?>"
                            class="h-9 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30" />
                    </div>

                    <select name="listOfColumns[]" id="listOfColumns" form="goodsDispatchedExportForm" class="selectpicker" multiple
                        data-style="h-9 rounded-xl border border-slate-200 bg-white px-3 py-[6px] text-sm font-medium text-slate-700 shadow-sm outline-none hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                        data-actions-box="true" required>
                        <option value="Timestamp">Timestamp</option>
                        <option value="Product">Product</option>
                        <option value="Quantity">Quantity</option>
                        <option value="Client Name">Client Name</option>
                        <option value="Dispatch Type">Dispatch Type</option>
                        <option value="City Area">City Area</option>
                        <option value="Category">Category</option>
                        <option value="Delivery Mode">Delivery Mode</option>
                        <option value="Dispatched By">Dispatched By</option>
                    </select>

                    <button type="button" data-bs-toggle="modal" data-bs-target="#exportModal"
                        class="inline-flex h-9 items-center gap-2 !rounded-xl bg-emerald-700 px-4 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <i class="ti ti-download text-lg"></i> Export
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto border-t border-slate-200 w-full">
                <table class="w-full table-auto text-left text-sm text-slate-600">
                    <thead
                        class="border-b border-slate-100 bg-white text-[11px] font-bold uppercase tracking-widest text-slate-400">
                        <tr>
                            <th class="w-12 px-6 py-3">#</th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="created_at" data-order="asc">
                                <span class="inline-flex items-center gap-1">DATE <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable w-80 min-w-[300px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="product_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">PRODUCT NAME <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3">QUANTITY</th>
                            <th class="sortable w-64 min-w-[220px] cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="client_name" data-order="asc">
                                <span class="inline-flex items-center gap-1">NAME OF CLIENT <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="type_of_dispatch" data-order="asc">
                                <span class="inline-flex items-center gap-1">ORDER / DISPATCH TYPE <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="sortable cursor-pointer px-6 py-3 transition-colors hover:bg-slate-50/50"
                                data-column="place_of_dispatch" data-order="asc">
                                <span class="inline-flex items-center gap-1">PLACE OF DISPATCH <i
                                        class="ti ti-arrows-sort text-sm text-slate-400"></i></span>
                            </th>
                            <th class="px-6 py-3">CATEGORY</th>
                            <th class="px-6 py-3">DISPATCHED BY</th>
                            <th class="px-6 py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-slate-100 text-sm text-slate-600"
                        id="stockOutwardsTableBody">
                    </tbody>
                </table>
            </div>

            <style>#footerPerPageSelect + .dropdown { display: none !important; }</style>
            <?= getPaginationFooter('paginationWrapper', 'paginationSummary', 'footerPerPageSelect') ?>
        </div>
    </div>

    <!-- ═══════════ Add Stock Outward Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="animationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-plus text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Add
                                Stock Outward</h5>
                            <p class="m-0 mt-1 text-xs font-medium text-slate-500 leading-relaxed max-w-xl">
                                Log every dispatched item accurately. Data is used for stock deduction, delivery
                                tracking, client history, and dispatch auditing.
                            </p>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="addStockOutwardForm">
                    <div class="modal-body bg-slate-50/70 p-6">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <small class="text-sm font-semibold text-slate-700 d-block mb-2">Outward Type <strong
                                        class="text-rose-500">*</strong></small>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input outward-type" type="radio" id="internalManufaturing"
                                        name="outwardType" value="1" required />
                                    <label class="form-check-label" for="internalManufaturing">Internal
                                        Manufacturing</label>
                                </div>
                                <div class="form-check form-check-inline mt-3  me-lg-5">
                                    <input class="form-check-input outward-type" type="radio" id="externalDispatch"
                                        name="outwardType" value="2" />
                                    <label class="form-check-label" for="externalDispatch">External Dispatch</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3 d-none" id="internalDropdownRow">
                                <label class="form-label text-sm font-semibold text-slate-700"
                                    for="manufacturingUnitDepartment">Department<strong
                                        class="text-rose-500">*</strong></label>
                                <select id="manufacturingUnitDepartment" name="manufacturingUnitDepartment"
                                    class="input-theme select2">
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="clientName" class="form-label text-sm font-semibold text-slate-700">Name of
                                    the Client <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="clientName" autocomplete="off" name="clientName"
                                    class="form-control" placeholder="Enter client name" required />
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="placeOfDispatch"
                                    class="form-label text-sm font-semibold text-slate-700">Place of Dispatch
                                    (City/Country) <strong class="text-rose-500">*</strong></label>
                                <input type="text" id="placeOfDispatch" autocomplete="off" name="placeOfDispatch"
                                    class="form-control" placeholder="Enter place of dispatch" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="clientReceiverType"
                                    class="form-label text-sm font-semibold text-slate-700">Client Type (B2B / B2C) <strong
                                        class="text-rose-500">*</strong></label>
                                <select name="clientReceiverType" id="clientReceiverType" class="input-theme select2" required>
                                    <?php if (!empty(Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE'] as $crtkey => $crtval) {
                                            echo '<option value="' . $crtkey . '">' . $crtval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3 d-none" id="clientReceiverTypeDetailsDiv">
                                <label for="clientReceiverTypeDetails"
                                    class="form-label text-sm font-semibold text-slate-700">Client/Receiver Details
                                    <strong class="text-rose-500">*</strong></label>
                                <textarea id="clientReceiverTypeDetails" autocomplete="off"
                                    name="clientReceiverTypeDetails" class="form-control"
                                    placeholder="Enter details"></textarea>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="typeOfDispatch" class="form-label text-sm font-semibold text-slate-700">Type
                                    Of Dispatched <strong class="text-rose-500">*</strong></label>
                                <select id="typeOfDispatch" name="typeOfDispatch" class="input-theme select2">
                                    <?php if (!empty(Constant::STOCKS_OUTWARDS['TYPE_DISPATCH'])) {
                                        echo '<option value="">----Select----</option>';
                                        foreach (Constant::STOCKS_OUTWARDS['TYPE_DISPATCH'] as $tdkey => $tdval) {
                                            echo '<option value="' . $tdkey . '">' . $tdval . '</option>';
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3 d-none" id="typeOfDispatchDetailsDiv">
                                <label for="typeOfDispatchDetails"
                                    class="form-label text-sm font-semibold text-slate-700">Type Of Dispatched <strong
                                        class="text-rose-500">*</strong></label>
                                <textarea id="typeOfDispatchDetails" autocomplete="off" name="typeOfDispatchDetails"
                                    class="form-control" placeholder="Enter details"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mb-2">
                                <label class="form-label text-sm font-semibold text-slate-700">Products Details</label>
                            </div>
                            <div id="productsWrapperWhole" class="d-flex flex-column gap-3"></div>
                            <div class="mt-3 mb-3">
                                <button type="button"
                                    class="inline-flex h-9 items-center gap-2 !rounded-xl bg-emerald-50 px-4 text-sm font-medium text-emerald-700 shadow-sm ring-1 ring-emerald-900/10 hover:bg-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                                    id="addProductBtn">
                                    <i class="ti ti-plus"></i> Add Product
                                </button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="deliveryMode"
                                    class="form-label text-sm font-semibold text-slate-700">Delivery Mode <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="deliveryMode" name="deliveryMode" class="input-theme select2" required>
                                    <?php if (!empty(Constant::STOCKS_OUTWARDS['DELIVERY_MODE'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['DELIVERY_MODE'] as $dmkey => $dmval) {
                                            echo '<option value="' . $dmkey . '">' . $dmval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="courierTransportService"
                                    class="form-label text-sm font-semibold text-slate-700">Name of the
                                    Courier/Transport Service </label>
                                <select id="courierTransportService" name="courierTransportService"
                                    class="input-theme select2">
                                    <?php if (!empty(Constant::STOCKS_OUTWARDS['COURIER_TRANSPORT_TYPE'])) {
                                        echo '<option value="">----Select----</option>';
                                        ?>
                                        <?php foreach (Constant::STOCKS_OUTWARDS['COURIER_TRANSPORT_TYPE'] as $tdkey => $tdval) {
                                            echo '<option value="' . $tdkey . '">' . $tdval . '</option>';
                                            ?>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="trackingId" class="form-label text-sm font-semibold text-slate-700">Tracking
                                    ID</label>
                                <input type="text" id="trackingId" autocomplete="off" name="trackingId"
                                    class="form-control" placeholder="Enter tracking ID" />
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="dispatchedBy"
                                    class="form-label text-sm font-semibold text-slate-700">Dispatched By <strong
                                        class="text-rose-500">*</strong></label>
                                <select id="dispatchedBy" name="dispatchedBy" class="input-theme select2"
                                    data-allow-clear="true" required>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="dispatchedTo" class="form-label text-sm font-semibold text-slate-700">Dispatched To</label>
                                <input type="text" id="dispatchedTo" autocomplete="off" name="dispatchedTo"
                                    class="form-control" placeholder="Enter dispatched to name/details" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="remark"
                                    class="form-label text-sm font-semibold text-slate-700">Remark</label>
                                <textarea id="remark" autocomplete="off" name="remark" class="form-control"
                                    placeholder="Enter Remark"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 border-t border-slate-200 bg-white px-4 py-3">
                        <button type="button"
                            class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-300/60"
                            data-bs-dismiss="modal">Close</button>
                        <button type="submit"
                            class="inline-flex h-11 min-w-36 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-5 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <i class="ti ti-check text-lg"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════ View Stock Outward Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="viewStockOutwardModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Stock
                                Outward Details</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="viewStockOutward">
                    <div class="modal-body bg-slate-50/70 p-6">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════ View Order Received Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="viewOrderReceivedModel" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                            <i class="ti ti-eye text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Order
                                Details</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="viewOrderReceived">
                    <div class="modal-body bg-slate-50/70 p-6">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════ Edit Order Received Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="editOrderReceivedModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Process Inbound Dispatch Request</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="editOrderReceivedForm">
                    <div class="modal-body bg-slate-50/70 p-6">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ═══════════ Inbound Dispatch Requests Modal ═══════════ -->
<style>
    /* Theme accent for checkboxes in the inbound dispatches modal */
    #inboundDispatchesModal .form-check-input:checked {
        background-color: var(--appearance-accent, #7e22ce) !important;
        border-color: var(--appearance-accent, #7e22ce) !important;
    }

    .bs-container {
        z-index: 1085 !important;
    }
</style>
    <div class="modal fade animate__animated fadeIn" id="inboundDispatchesModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-2xl" style="background-color: var(--appearance-accent-light, #f3e8ff); color: var(--appearance-accent, #7e22ce); box-shadow: 0 0 0 1px var(--appearance-accent-light, #f3e8ff);">
                            <i class="ti ti-truck-delivery text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Inbound Dispatch Requests</h5>
                            <p class="m-0 text-sm font-medium text-slate-500">Orders shared from order management pending dispatch</p>
                        </div>
                    </div>
                    <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <div class="modal-body" style="padding: 1.25rem; background-color: #f8fafc;">
                    <!-- Bulk Action Panel -->
                    <div id="bulkDispatchBar" class="mb-3 p-3 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center justify-between" style="display: none;">
                        <span id="bulkDispatchCountText" class="text-sm font-bold text-slate-700">0 items selected</span>
                        <button type="button" id="processBulkDispatchBtn" class="inline-flex h-9 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold text-white shadow-sm focus:outline-none" style="background-color: var(--appearance-accent, #7e22ce); transition: filter 0.2s;" onmouseover="this.style.filter='brightness(0.9)'" onmouseout="this.style.filter='brightness(1)'">
                            <i class="ti ti-truck-delivery"></i> Process Dispatch
                        </button>
                    </div>

                    <div class="overflow-x-auto w-full">
                        <table class="w-full table-auto text-left text-sm text-slate-600 bg-white rounded-xl border border-slate-200 shadow-sm">
                            <thead class="border-b border-slate-200 bg-slate-50/80 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                <tr>
                                    <th class="w-12 px-6 py-3 text-center">
                                        <input type="checkbox" id="selectAllInboundRequests" class="form-check-input" />
                                    </th>
                                    <th class="w-12 px-6 py-3">#</th>
                                    <th class="px-6 py-3">Date Ordered</th>
                                    <th class="px-6 py-3">Order No</th>
                                    <th class="px-6 py-3">Client Name</th>
                                    <th class="px-6 py-3">Area/City</th>
                                    <th class="px-6 py-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100" id="inboundDispatchesTableBody">
                                <tr>
                                    <td colspan="7" class="text-center py-6 text-slate-500 font-medium">
                                        <div class="spinner-border" style="color: var(--appearance-accent, #7e22ce);" role="status"><span class="visually-hidden">Loading...</span></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-4 !py-3 flex items-center justify-end">
                    <button type="button" class="inline-flex h-10 min-w-32 items-center justify-center !rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════ Edit Outward Stocks Modal ═══════════ -->
    <div class="modal fade animate__animated fadeIn" id="outwardStocksEditModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div
                    class="modal-header flex items-center justify-between border-b border-slate-200 bg-slate-50/80 !px-4 !py-3">
                    <div class="flex items-center gap-3">
                        <span
                            class="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                            <i class="ti ti-pencil text-xl"></i>
                        </span>
                        <div>
                            <h5 class="modal-title m-0 text-lg font-bold text-slate-900" id="exampleModalLabel5">Order
                                Details</h5>
                        </div>
                    </div>
                    <button type="button"
                        class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="ti ti-x text-xl"></i>
                    </button>
                </div>
                <form id="outwardStocksEditForm">
                    <div class="modal-body bg-slate-50/70 p-6">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <!-- Export Modal -->
    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="goodsDispatchedExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">File Format</label>
                            <div class="dropdown w-full">
                                <button class="flex h-10 w-full items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="outwardExportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="outward-export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="outward-export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="outward-export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportType" value="excel">
                        </div>

                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">Select Columns</label>
                                <button type="button" id="deselectAllOutwardColumnsBtn" class="text-[11px] font-bold text-slate-500 transition-colors hover:text-emerald-600">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3">
                                <div class="flex flex-col gap-2" id="outwardColumnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Timestamp" checked><span class="text-sm font-medium text-slate-700">Timestamp</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product" checked><span class="text-sm font-medium text-slate-700">Product</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Quantity" checked><span class="text-sm font-medium text-slate-700">Quantity</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Client Name" checked><span class="text-sm font-medium text-slate-700">Client Name</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Dispatch Type" checked><span class="text-sm font-medium text-slate-700">Dispatch Type</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="City Area" checked><span class="text-sm font-medium text-slate-700">City Area</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Category" checked><span class="text-sm font-medium text-slate-700">Category</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Delivery Mode" checked><span class="text-sm font-medium text-slate-700">Delivery Mode</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" class="outward-column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Dispatched By" checked><span class="text-sm font-medium text-slate-700">Dispatched By</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer flex items-center justify-center gap-3 border-t border-slate-200 bg-white !px-5 !py-4">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28"><i class="ti ti-download text-base"></i> Export</button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php startSection('scripts'); ?>
<script>
    let reopenInboundModal = false;
    let currentPage = 1;
    let currentPageOrdRec = 1;
    let qtyUnitOptions = [];
    let qtyUnitRequest = null;
    let productIndex = 0;
    let currentSortColumn = 'recent';
    let currentSortOrder = 'DESC';
    let dispatch_type = APP_CONST.STOCKS_OUTWARDS.DISPATCH_MGMT_LABEL.ExternalDispatch;

    /*
    function loadOrderReceivedAtStockOutwardTable(page = 1) {
        currentPageOrdRec = page;
        const search = $('#searchProductsOrdRec').val().trim();
        const perPage = $('#perPageSelectOrdRec').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadOrderRecAtStockOutward: 'loadOrderRecAtStockOutward',
                page: page,
                per_page: perPage,
                search: search
            },
            success: function (response) {
                $('#orderReceivedTableBody').html(response.table || '');
                $('#paginationWrapperOrderReceived').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummaryOrderReceived', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelectOrderReceived');
                if (response.totalRows !== undefined && response.visibleRows !== undefined) {
                    $('#paginationSummaryOrdRec').text(`Showing ${response.visibleRows} results of ${response.totalRows}`);
                } else {
                    $('#paginationSummaryOrdRec').text('');
                }
            },
            error: function () {
                $('#orderReceivedTableBody').html('<tr><td colspan="3" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapperOrderReceived').html('');
            }
        });
    }
    */

    function loadInboundDispatchesWidget() {
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadInboundDispatchesCount: 'loadInboundDispatchesCount' },
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    let count = parseInt(res.count || 0);
                    if (count > 0) {
                        $('#inboundDispatchesWidget').show();
                        $('#inboundDispatchesCountBadge').text(count);
                        $('#inboundDispatchesCountText').text(count);
                    } else {
                        $('#inboundDispatchesWidget').hide();
                    }
                }
            }
        });
    }

    // A dispatch consignment belongs to one client, so rows are keyed by customer
    // (falling back to the name for legacy orders with no customer_id).
    function inboundClientKey(row) {
        const id = Number(row.customer_id || 0);
        if (id > 0) return 'c' + id;
        return 'n' + String(row.client_name || '').trim().toLowerCase();
    }

    function loadInboundDispatchesList() {        $('#inboundDispatchesTableBody').html('<tr><td colspan="7" class="text-center py-6 text-slate-500 font-medium"><div class="spinner-border" style="color: var(--appearance-accent, #7e22ce);" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
        // Reset header checkboxes & bulk panel
        $('#selectAllInboundRequests').prop('checked', false);
        $('#bulkDispatchBar').hide();
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { loadInboundDispatchesList: 'loadInboundDispatchesList' },
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    let html = '';
                    if (res.data && res.data.length > 0) {
                        res.data.forEach(function (row, idx) {
                            html += '<tr class="transition-colors hover:bg-slate-50/50">';
                            html += '<td class="px-6 py-3 align-middle text-center"><input type="checkbox" class="selectInboundRequestRow form-check-input" data-id="' + row.id + '" data-client-key="' + inboundClientKey(row) + '" /></td>';
                            html += '<td class="px-6 py-3 align-middle text-[13px] font-semibold text-slate-900 whitespace-nowrap">' + (idx + 1) + '</td>';
                            html += '<td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-600 whitespace-nowrap">' + (row.date_ordered || '') + '</td>';
                            html += '<td class="px-6 py-3 align-middle text-[13px] font-semibold text-slate-900 whitespace-nowrap">' + (row.order_number || '') + '</td>';
                            html += '<td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-600">' + (row.client_name || '') + '</td>';
                            html += '<td class="px-6 py-3 align-middle text-[13px] font-medium text-slate-600">' + (row.area_city || '') + '</td>';
                            html += '<td class="px-6 py-3 align-middle text-center whitespace-nowrap">';
                            html += '<button type="button" class="btn btn-icon editOrderReceivedAtStockOutwardModalBtn" style="background-color: var(--appearance-accent-light, #f3e8ff); color: var(--appearance-accent, #7e22ce); border: none;" data-id="' + row.id + '" onmouseover="this.style.filter=\'brightness(0.95)\'" onmouseout="this.style.filter=\'brightness(1)\'"><span class="ti ti-eye"></span></button>';
                            html += '</td>';
                            html += '</tr>';
                        });
                    } else {
                        html = '<tr><td colspan="7" class="text-center py-6 text-sm font-medium text-slate-500">No pending inbound dispatch requests found.</td></tr>';
                    }
                    $('#inboundDispatchesTableBody').html(html);
                } else {
                    $('#inboundDispatchesTableBody').html('<tr><td colspan="7" class="text-center py-6 text-sm font-medium text-rose-600">Error loading data.</td></tr>');
                }
            },
            error: function () {
                $('#inboundDispatchesTableBody').html('<tr><td colspan="7" class="text-center py-6 text-sm font-medium text-rose-600">Error loading data.</td></tr>');
            }
        });
    }

    $(document).on('click', '#inboundDispatchesWidget', function () {
        $('#inboundDispatchesModal').modal('show');
        loadInboundDispatchesList();
    });

    function loadStocksOutwordTable(page = 1) {
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#fromDate').val();
        const toDate = $('#toDate').val();

        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadStocksOutword: 'loadStocksOutword',
                page: page,
                per_page: perPage,
                search: search,
                fromDate: fromDate,
                toDate: toDate,
                dispatch_type: dispatch_type,
                sort_column: currentSortColumn,
            },
            dataType: 'json',
            success: function (response) {
                $('#stockOutwardsTableBody').html(response.table || '');
                $('#paginationWrapper').html(response.pagination || '');
                if (typeof window.updatePaginationSummary === 'function') window.updatePaginationSummary('paginationSummary', response.totalRows, typeof currentPage !== 'undefined' ? currentPage : (typeof page !== 'undefined' ? page : 1), 'footerPerPageSelect');
                if (response && response.totalRows !== undefined) {
                    const totalRows = Number(response.totalRows);
                    const perPage = Number($('#perPageSelect').val() || 10);
                    const shownThrough = Math.min(currentPage * perPage, totalRows);
                    const startRow = totalRows === 0 ? 0 : ((currentPage - 1) * perPage) + 1;

                } else {

                }
            },
            error: function () {
                $('#stockOutwardsTableBody').html('<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>');
                $('#paginationWrapper').html('');
            }
        });
    }

    function getQtyUnitOptionsHtml() {
        let qtyUnitHtml = '<option value="">----Select----</option>';
        qtyUnitOptions.forEach(unit => {
            qtyUnitHtml += `<option value="${unit.id}">${unit.label}</option>`;
        });
        return qtyUnitHtml;
    }

    function ensureStandardUnitsLoaded() {
        if (qtyUnitOptions.length) {
            const deferred = $.Deferred();
            deferred.resolve(qtyUnitOptions);
            return deferred.promise();
        }
        if (qtyUnitRequest) {
            return qtyUnitRequest;
        }
        qtyUnitRequest = $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getQtyUnits: 'getQtyUnits'
            }
        }).done(function (response) {
            qtyUnitOptions = Array.isArray(response) ? response : [];
        }).fail(function (xhr, status, error) {
            console.error("Failed to load qty units:", error);
        }).always(function () {
            qtyUnitRequest = null;
        });
        return qtyUnitRequest;
    }

    function loadStandardUnit() {
        return ensureStandardUnitsLoaded();
    }

    function loadReceiverEmployeeOption() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                loadReceivedByEmpOption: 'loadReceivedByEmpOption'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (prodCateg) {
                    html += `<option value="${prodCateg.key}" ${prodCateg.selected ? 'selected' : ''}>${prodCateg.value}</option>`;
                });
                $('#dispatchedBy').html(html).trigger('change');
            }
        });
    }

    function loadProductsCategoryTypeWithQuantity(materialTypeId) {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            data: {
                materialTypeId: materialTypeId,
                loadProductsCategoryTypeWithQuantity: 'loadProductsCategoryTypeWithQuantity'
            },
            dataType: 'json',
            success: function (response) {
                let html = '<option value="">----Select Option----</option>';
                response.forEach(function (product) {
                    html += `<option value="${product.key}">${product.value}</option>`;
                });
                $('#productsList').html(html).trigger('change');
            }
        });
    }

    function loadDepartmentsList() {
        $.ajax({
            url: 'ajax.php',
            method: 'POST',
            dataType: 'json',
            data: {
                getDepartmentList: 'getDepartmentList'
            },
            success: function (response) {
                departmentOptions = response;
                let optionsHtml = '<option value="">---Select----</option>';
                departmentOptions.forEach(unit => {
                    optionsHtml += `<option value="${unit.id}">${unit.name}</option>`;
                });
                $("#manufacturingUnitDepartment").html(optionsHtml);
            },
            error: function (xhr, status, error) {
                console.error("Failed to load qty units:", error);
            }
        });
    }

    function initModalSelect2($element, modalSelector, options = {}) {
        $element.each(function() {
            const $select = $(this);
            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }
            $select.select2($.extend({
                dropdownParent: $(modalSelector),
                width: '100%'
            }, options));
        });
    }

    function initStockOutwardSelect2($element, options = {}) {
        initModalSelect2($element, '#animationModal', options);
    }

    function constrainStockOutwardSelect2Dropdown(modalSelector) {
        const $dropdown = $('.select2-container--open .select2-dropdown');
        const $results = $dropdown.find('.select2-results__options');
        const $modalContent = $(modalSelector + ' .modal-content');
        const $modalFooter = $(modalSelector + ' form > .flex, ' + modalSelector + ' .modal-footer, ' + modalSelector + ' .modal-body > .flex').last();

        if (!$dropdown.length || !$results.length || !$modalContent.length) return;

        const dropdownTop = $dropdown[0].getBoundingClientRect().top;
        const footerTop = $modalFooter.length
            ? $modalFooter[0].getBoundingClientRect().top
            : $modalContent[0].getBoundingClientRect().bottom;
        const availableHeight = Math.max(120, footerTop - dropdownTop - 12);

        $results.css('max-height', Math.min(260, availableHeight) + 'px');
    }

    function bindStockOutwardSelect2Scroll(modalSelector) {
        setTimeout(function() {
            constrainStockOutwardSelect2Dropdown(modalSelector);
            $('.select2-container--open .select2-dropdown')
                .off('wheel.stockOutwardModalScroll')
                .on('wheel.stockOutwardModalScroll', function(e) {
                    const deltaY = e.originalEvent.deltaY || 0;
                    if (!deltaY) return;

                    const el = $(this).find('.select2-results__options').get(0);
                    if (!el) return;

                    const canScrollUp = el.scrollTop > 0;
                    const canScrollDown = el.scrollTop + el.clientHeight < el.scrollHeight - 1;
                    const isOverResults = $(e.target).closest('.select2-results__options').length > 0;

                    if (!isOverResults && ((deltaY < 0 && canScrollUp) || (deltaY > 0 && canScrollDown))) {
                        e.preventDefault();
                        e.stopPropagation();
                        el.scrollTop += deltaY;
                        return;
                    }

                    if ((deltaY < 0 && !canScrollUp) || (deltaY > 0 && !canScrollDown)) {
                        e.preventDefault();
                        e.stopPropagation();

                        const $modalBody = $(modalSelector + ' .modal-body');
                        $modalBody.scrollTop($modalBody.scrollTop() + deltaY);
                        $(modalSelector + ' .select2-hidden-accessible').select2('close');
                    }
                });
        }, 0);
    }

    $(document).ready(function () {
        loadInboundDispatchesWidget();
        loadStocksOutwordTable();
        loadReceiverEmployeeOption();
        loadStandardUnit();

        // Select All Inbound Requests
        $(document).on('change', '#selectAllInboundRequests', function () {
            const isChecked = $(this).is(':checked');
            if (!isChecked) {
                $('.selectInboundRequestRow').prop('checked', false);
                $('.selectInboundRequestRow').first().trigger('change');
                return;
            }
            const $rows = $('.selectInboundRequestRow');
            if (!$rows.length) return;
            const $already = $rows.filter(':checked').first();
            const key = String(($already.length ? $already : $rows.first()).data('client-key') || '');
            let skipped = 0;
            $rows.each(function () {
                const match = String($(this).data('client-key') || '') === key;
                $(this).prop('checked', match);
                if (!match) skipped++;
            });
            if (skipped > 0) {
                toastr.info('Selected only the orders for this client. A dispatch cannot combine different clients.');
            }
            $rows.first().trigger('change');
        });

        // Individual Request Checkbox
        $(document).on('change', '.selectInboundRequestRow', function () {
            const $row = $(this);
            if ($row.is(':checked')) {
                const key = String($row.data('client-key') || '');
                const $others = $('.selectInboundRequestRow:checked').not($row);
                if ($others.length && String($others.first().data('client-key') || '') !== key) {
                    $row.prop('checked', false);
                    toastr.error('A dispatch can only combine orders for the same client.');
                }
            }
            const total = $('.selectInboundRequestRow').length;
            const checked = $('.selectInboundRequestRow:checked').length;

            // Sync the select-all checkbox state
            $('#selectAllInboundRequests').prop('checked', total === checked && total > 0);

            // Toggle/update bulk action bar
            if (checked > 0) {
                $('#bulkDispatchCountText').text(checked + ' items selected');
                $('#bulkDispatchBar').slideDown(200);
            } else {
                $('#bulkDispatchBar').slideUp(200);
            }
        });

        // Bulk process button click
        $(document).on('click', '#processBulkDispatchBtn', function () {
            let ids = [];
            $('.selectInboundRequestRow:checked').each(function () {
                ids.push($(this).data('id'));
            });
            if (ids.length > 0) {
                openDispatchProcessModal(ids.join(','));
            }
        });

        // Show/hide other courier name field based on selection
        $(document).on('change', '#courierTransportServiceModalSelect', function () {
            if ($(this).val() == '9') { // 9 is 'Other'
                $('#otherCourierNameDiv').slideDown(200);
                $('#otherCourierInput').attr('required', true);
            } else {
                $('#otherCourierNameDiv').slideUp(200);
                $('#otherCourierInput').removeAttr('required').val('');
            }
        });
        // loadOrderReceivedAtStockOutwardTable();
        initStockOutwardSelect2($('#animationModal .select2'), {
            placeholder: 'Select value'
        });
        $(document).on('select2:open', function(e) {
            const $modal = $(e.target).closest('#animationModal, #editOrderReceivedModal');
            if (!$modal.length) return;
            bindStockOutwardSelect2Scroll('#' + $modal.attr('id'));
        });
        $('#animationModal .modal-body, #editOrderReceivedModal .modal-body').on('scroll', function() {
            $(this).closest('.modal').find('.select2-hidden-accessible').select2('close');
        });
        $('#searchUsers').on('input', function () {
            loadStocksOutwordTable(1);
        });
        $('#perPageSelect').on('change', function () {
            loadStocksOutwordTable(1);
        });
        /*
        $('#searchProductsOrdRec').on('input', function () {
            loadOrderReceivedAtStockOutwardTable(1);
        });
        $('#perPageSelectOrdRec').on('change', function () {
            loadOrderReceivedAtStockOutwardTable(1);
        });
        $('#footerPerPageSelectOrderReceived').on('change', function () {
            $('#perPageSelectOrdRec').val($(this).val());
            loadOrderReceivedAtStockOutwardTable(1);
        });
        */
        $('#fromDate').on('change', function () {
            loadStocksOutwordTable(1);
        });
        $('#toDate').on('change', function () {
            loadStocksOutwordTable(1);
        });
        $('#footerPerPageSelect').on('change', function () {
            $('#perPageSelect').val($(this).val());
            loadStocksOutwordTable(1);
        });

        // Top-strip per-page dropdown handlers
        $(document).on('click', '.order-received-per-page-item', function () {
            const val = $(this).data('val');
            $('#orderReceivedPerPageText').text($(this).text());
            $('#footerPerPageSelectOrderReceived').val(val).trigger('change');
        });
        $(document).on('click', '.stock-outwards-per-page-item', function () {
            const val = $(this).data('val');
            $('#stockOutwardsPerPageText').text($(this).text());
            $('#footerPerPageSelect').val(val).trigger('change');
        });

        $('.sortable').on('click', function () {
            const column = $(this).data('column');
            let order = $(this).data('order') || 'asc';
            order = order === 'asc' ? 'desc' : 'asc';

            $('.sortable').data('order', 'asc');
            $('.sortable i').removeClass('ti-sort-ascending ti-sort-descending text-emerald-500').addClass('ti-arrows-sort text-slate-400');

            $(this).data('order', order);
            const icon = $(this).find('i');
            icon.removeClass('ti-arrows-sort text-slate-400');
            if (order === 'asc') {
                icon.addClass('ti-sort-ascending text-emerald-500');
            } else {
                icon.addClass('ti-sort-descending text-emerald-500');
            }

            currentSortColumn = column;
            currentSortOrder = order;
            loadStocksOutwordTable(currentPage);
        });

        $('#animationModalBtn').on('click', function () {
            $('#animationModal').modal('show');
            ensureStandardUnitsLoaded().done(function () {
                if ($('.product-entry').length === 0) {
                    $('#addProductBtn').trigger('click');
                }
            });
        });

        $('#animationModal').on('hidden.bs.modal', function () {
            $('#addStockOutwardForm')[0].reset();
            $('#addStockOutwardForm .select2').val(null).trigger('change');
            $('#productsWrapperWhole').empty();
            productIndex = 0;
            
            $("#internalDropdownRow").addClass("d-none");
            $("#manufacturingUnitDepartment").removeAttr("required").val("");
            $("#clientReceiverTypeDetailsDiv").addClass("d-none");
            $("#clientReceiverTypeDetails").removeAttr("required").val("");
            $("#typeOfDispatchDetailsDiv").addClass("d-none");
            $("#typeOfDispatchDetails").removeAttr("required").val("");
        });

        $(".outward-type").on("change", function () {
            loadDepartmentsList();
            if ($("#internalManufaturing").is(":checked")) {
                $("#internalDropdownRow").removeClass("d-none");
                $("#manufacturingUnitDepartment").attr("required", true);
            } else {
                $("#manufacturingUnitDepartment").html();
                $("#internalDropdownRow").addClass("d-none");
                $("#manufacturingUnitDepartment").removeAttr("required").val("");
            }
        });
        $('#clientReceiverType').on('change', function () {
            let clientRecType = <?php echo Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE_LABEL']['Other']; ?>;
            let selectedOption = $(this).val();
            if (clientRecType == selectedOption) {
                $("#clientReceiverTypeDetailsDiv").removeClass("d-none");
                $("#clientReceiverTypeDetails").attr("required", true);
            } else {
                $("#clientReceiverTypeDetailsDiv").addClass("d-none");
                $("#clientReceiverTypeDetails").removeAttr("required").val("");
            }
        });

        $('#clientName').on('blur change', function () {
            let name = $(this).val().trim();
            if (name.length >= 2) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: { checkClientCustomerType: 1, client_name: name },
                    dataType: 'json',
                    success: function (res) {
                        if (res && res.user_type) {
                            let typeVal = (res.user_type.toLowerCase() === 'b2c') ? 2 : 1;
                            $('#clientReceiverType').val(typeVal).trigger('change');
                        }
                    }
                });
            }
        });

        $('#typeOfDispatch').on('change', function () {
            let clientRecType = <?php echo Constant::STOCKS_OUTWARDS['TYPE_DISPATCH_LABEL']['Other']; ?>;
            let selectedOption = $(this).val();
            if (clientRecType == selectedOption) {
                $("#typeOfDispatchDetailsDiv").removeClass("d-none");
                $("#typeOfDispatchDetails").attr("required", true);
            } else {
                $("#typeOfDispatchDetailsDiv").addClass("d-none");
                $("#typeOfDispatchDetails").removeAttr("required").val("");
            }
        });

        $('#addProductBtn').click(function () {
            ensureStandardUnitsLoaded().done(function () {
                const rowIndex = productIndex;
                const qtyUnitHtml = getQtyUnitOptionsHtml();

                const productBlock = `
            <div class="row g-3 product-entry mt-3 rounded-xl border border-slate-200 bg-slate-50/50 p-4 relative mx-0" data-index="${rowIndex}">
                <div class="col-12 col-md-4">
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Product Category</label>
                    <select name="materialTypeList[]" class="input-theme select2 materialTypeList !rounded-xl !text-sm" data-allow-clear="true" required>
                        <option value="">--Select--</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Product</label>
                    <select name="productsList[]" class="input-theme select2 productsList !rounded-xl !text-sm" data-allow-clear="true" required>
                        <option value="">--Select--</option>
                    </select>
                </div>
                <div class="col-12 col-md-4">
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Available Quantity</label>
                    <input type="number" step="any" min="0" name="availableQuantity[]" class="form-control availableQuantity !rounded-xl !bg-slate-100 !text-sm" placeholder="0.00" readonly />
                </div>
                <div class="col-12 col-md-4">
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Quantity</label>
                    <input type="number" step="any" min="0" name="prodQuantity[]" class="form-control !rounded-xl !text-sm" placeholder="Enter Quantity" required />
                </div>
                <div class="col-12 col-md-4">
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Quantity Unit</label>
                    <select name="prodQuantityUnit[]" class="input-theme select2 !rounded-xl !text-sm" required>
                        ${qtyUnitHtml}
                    </select>
                </div>   
                <div class="col-12 col-md-4">
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Enter LOT No.</label>
                    <input type="text" name="lotNumber[]" class="form-control !rounded-xl !text-sm" placeholder="Enter LOT No." />
                </div>
                <div class="col-12 col-md-11">
                    <label for="itemRemark" class="mb-1 block text-[11px] font-bold uppercase tracking-widest text-slate-500">Remark</label>
                    <textarea id="itemRemark" rows="1" autocomplete="off" name="itemRemark[]" class="form-control !rounded-xl !text-sm" placeholder="Enter Remark"></textarea>
                </div>
                <div class="col-12 col-md-1 flex items-end justify-center">
                    <button type="button" class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-rose-50 text-rose-600 shadow-sm ring-1 ring-rose-100 transition-colors hover:bg-rose-100 hover:text-rose-700 removeProductBtn" title="Remove Item"><i class="ti ti-trash text-lg"></i></button>               
                </div>
            </div>`;

                $('#productsWrapperWhole').append(productBlock);

                const $newRow = $(`.product-entry[data-index="${rowIndex}"]`);
                initStockOutwardSelect2($newRow.find('.select2'), {
                    placeholder: '--Select--'
                });

                const $newMaterialSelect = $newRow.find('.materialTypeList');
                $.ajax({
                    url: 'ajax.php',
                    method: 'POST',
                    data: {
                        loadProductCategoryStockOutwardOption: 'loadProductCategoryStockOutwardOption'
                    },
                    dataType: 'json',
                    success: function (response) {
                        let html = '<option value="">----Select Option----</option>';
                        response.forEach(function (item) {
                            html += `<option value="${item.key}">${item.value}</option>`;
                        });
                        $newMaterialSelect.html(html).trigger('change');
                    }
                });

                productIndex++;
            });
        });

        $('#addStockOutwardForm').on('submit', function (e) {
            e.preventDefault();

            const form = document.getElementById('addStockOutwardForm');
            const formData = new FormData(form);
            formData.append('addStockOutward', 'addStockOutward');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false, // Must for FormData
                processData: false,
                success: function (response) {

                    if (response.status === 'success') {
                        $('#animationModal').modal('hide');
                        $('#addStockOutwardForm')[0].reset();
                        loadStocksOutwordTable();
                        toastr.success(response.message);
                    } else if (response.status === 'error') {
                        toastr.error(response.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        });

        $('#listOfColumns').selectpicker({
            actionsBox: true,
            container: 'body',
            selectedTextFormat: 'count > 2',
            noneSelectedText: '----Select Columns----'
        });
        $('#listOfColumns').selectpicker('selectAll');
        $('#listOfColumns').on('changed.bs.select', function () {
            const selectedColumns = $(this).val() || [];
            $('#outwardColumnsCheckboxList .outward-column-filter').each(function () {
                $(this).prop('checked', selectedColumns.includes($(this).val()));
            });
            $('#deselectAllOutwardColumnsBtn').text(selectedColumns.length === $('#outwardColumnsCheckboxList .outward-column-filter').length ? 'Deselect All' : 'Select All');
        });
        $('#exportModal').on('show.bs.modal', function () {
            $('#listOfColumns').trigger('changed.bs.select');
        });

    });

    $(document).on('click', '.removeProductBtn', function () {
        $(this).closest('.product-entry').remove();
    });

    $(document).on('change', '.materialTypeList', function () {
        const $parentRow = $(this).closest('.product-entry');
        const $productSelect = $parentRow.find('.productsList');
        const materialTypeId = $(this).val();

        if (materialTypeId) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                data: {
                    materialTypeId: materialTypeId,
                    loadProductsCategoryTypeWithQuantity: 'loadProductsCategoryTypeWithQuantity'
                },
                dataType: 'json',
                success: function (response) {
                    let html = '<option value="">----Select Option----</option>';
                    response.forEach(function (product) {
                        html += `<option value="${product.key}" data-quantity="${product.total_quantity}">${product.value}</option>`;
                    });
                    $productSelect.html(html).trigger('change');
                }
            });
        } else {
            $productSelect.html('<option value="">----Select Option----</option>').trigger('change');
        }
    });
    $(document).on('change', '.productsList', function () {
        const $parentRow = $(this).closest('.product-entry');
        const selectedOption = $(this).find(':selected');
        const qty = selectedOption.data('quantity') || 0;
        $parentRow.find('.availableQuantity').val(qty);
    });

    $(document).on('click', '.outwardStocksDeleteBtn', function () {
        let id = $(this).data('id');

        if (!id) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid ID',
                text: 'Invalid user ID provided.',
                customClass: {
                    confirmButton: 'btn btn-danger waves-effect waves-light'
                }
            });
            return;
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-primary me-3 waves-effect waves-light',
                cancelButton: 'btn btn-label-secondary waves-effect waves-light'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: {
                        deleteStockOutward: 'deleteStockOutward',
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            loadStocksOutwordTable();
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-success waves-effect waves-light'
                                }
                            });
                        } else if (res.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: res.message,
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Unexpected',
                                text: 'Unexpected server response.',
                                customClass: {
                                    confirmButton: 'btn btn-danger waves-effect waves-light'
                                }
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Server Error',
                            text: error,
                            customClass: {
                                confirmButton: 'btn btn-danger waves-effect waves-light'
                            }
                        });
                    }
                });
            }
        });
    });

    $(document).on('click', '.outwardStocksViewModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewStockOutward').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { viewStockOutwardRecord: 'viewStockOutwardRecord', id: id },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewStockOutwardModel').modal('show');
                        $('#viewStockOutward').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });
    $(document).on('click', '.viewOrderReceivedModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#viewOrderReceived').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    viewOrderReceivedRecord: 'viewOrderReceivedRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#viewOrderReceivedModel').modal('show');
                        $('#viewOrderReceived').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    function openDispatchProcessModal(ids) {
        if (ids) {
            reopenInboundModal = true;
            $('#inboundDispatchesModal').modal('hide');
            $('#editOrderReceivedForm').find('.modal-body').html('<div class="text-center py-6"><div class="spinner-border" style="color: var(--appearance-accent, #7e22ce);" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: {
                    fetchOrderReceivedAtStockOutwardRecord: 'fetchOrderReceivedAtStockOutwardRecord',
                    id: ids
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#editOrderReceivedModal').modal('show');
                        $('#editOrderReceivedForm').find('.modal-body').html(res.data);
                        initModalSelect2($('#editOrderReceivedModal .select2'), '#editOrderReceivedModal', {
                            placeholder: 'Select value'
                        });
                        bindStockOutwardSelect2Scroll('#editOrderReceivedModal');
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                        reopenInboundModal = false;
                        $('#inboundDispatchesModal').modal('show');
                    } else {
                        toastr.error('Unexpected response.');
                        reopenInboundModal = false;
                        $('#inboundDispatchesModal').modal('show');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                    reopenInboundModal = false;
                    $('#inboundDispatchesModal').modal('show');
                }
            });
        }
    }

    $('#editOrderReceivedModal').on('hidden.bs.modal', function () {
        if (reopenInboundModal) {
            reopenInboundModal = false;
            $('#inboundDispatchesModal').modal('show');
        }
    });

    $(document).on('click', '.editOrderReceivedAtStockOutwardModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            openDispatchProcessModal(id);
        }
    });
    $('#editOrderReceivedForm').on('submit', function (e) {
        e.preventDefault();

        const form = document.getElementById('editOrderReceivedForm');
        const formData = new FormData(form);
        formData.append('addStockOutwardFromOrders', 'addStockOutwardFromOrders');

        const $submitBtn = $(this).find('button[type="submit"]');
        const originalBtnHtml = $submitBtn.html();
        $submitBtn.prop('disabled', true).html('Submitting... <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');

        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    reopenInboundModal = false;
                    $('#editOrderReceivedModal').modal('hide');
                    $('#inboundDispatchesModal').modal('hide');
                    $('#editOrderReceivedForm').find('modal-body').html();
                    loadInboundDispatchesWidget();
                    loadStocksOutwordTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                    $submitBtn.prop('disabled', false).html(originalBtnHtml);
                } else {
                    toastr.error('Unexpected response.');
                    $submitBtn.prop('disabled', false).html(originalBtnHtml);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
                $submitBtn.prop('disabled', false).html(originalBtnHtml);
            }
        });
    });

    $(document).on('click', 'th.sortable', function () {
        let column = $(this).data('column');
        if (currentSortColumn === column) {
            currentSortOrder = (currentSortOrder === 'ASC') ? 'DESC' : 'ASC';
        } else {
            currentSortColumn = column;
            currentSortOrder = 'ASC';
        }
        $('th.sortable').removeClass('asc desc');
        if (currentSortOrder === 'ASC') {
            $(this).addClass('asc');
        } else {
            $(this).addClass('desc');
        }
        loadStocksOutwordTable(1);
    });

    $(document).on('change', '#clientReceiverTypeFromOrder', function () {
        let clientRecType = <?php echo Constant::STOCKS_OUTWARDS['CLIENT_RECEIVER_TYPE_LABEL']['Other']; ?>;
        let selectedOption = $(this).val();
        if (clientRecType == selectedOption) {
            $("#clientReceiverTypeDetailsFromOrderDiv").show();
            $("#clientReceiverTypeDetailsFromOrder").attr("required", true);
        } else {
            $("#clientReceiverTypeDetailsFromOrderDiv").hide();
            $("#clientReceiverTypeDetailsFromOrder").removeAttr("required").val("");
        }
    });

    $(document).on('change', '#typeOfDispatchFromOrder', function () {
        let clientRecType = <?php echo Constant::STOCKS_OUTWARDS['TYPE_DISPATCH_LABEL']['Other']; ?>;
        let selectedOption = $(this).val();
        if (clientRecType == selectedOption) {
            $("#typeOfDispatchDetailsFromOrderDiv").show();
            $("#typeOfDispatchDetailsFromOrder").attr("required", true);
        } else {
            $("#typeOfDispatchDetailsFromOrderDiv").hide();
            $("#typeOfDispatchDetailsFromOrder").removeAttr("required").val("");
        }
    });

    $('#exportModal').on('hidden.bs.modal', function () {
        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    });

    $(document).on('click', '.outward-export-type-item', function () {
        $('#outwardExportTypeText').text($(this).text());
        $('#exportType').val($(this).data('val'));
    });

    $('#deselectAllOutwardColumnsBtn').on('click', function () {
        const $columns = $('#outwardColumnsCheckboxList .outward-column-filter');
        const allChecked = $columns.filter(':checked').length === $columns.length;
        $columns.prop('checked', !allChecked);
        $('#listOfColumns').selectpicker('val', $columns.filter(':checked').map(function () { return $(this).val(); }).get());
        $(this).text(allChecked ? 'Select All' : 'Deselect All');
    });

    $(document).on('change', '.outward-column-filter', function () {
        const selectedColumns = $('#outwardColumnsCheckboxList .outward-column-filter:checked').map(function () { return $(this).val(); }).get();
        $('#listOfColumns').selectpicker('val', selectedColumns);
    });

    $('#goodsDispatchedExportForm').on('submit', function (e) {
        e.preventDefault();
        page = 1;
        currentPage = page;
        const search = $('#searchUsers').val().trim();
        const perPage = $('#perPageSelect').val();
        const fromDate = $('#fromDate').val();
        const toDate = $('#toDate').val();
        const form = document.getElementById('goodsDispatchedExportForm');
        const formData = new FormData(form);
        formData.append('exportGoodsDispatched', 'exportGoodsDispatched');
        formData.append('search', search);
        formData.append('perPage', perPage);
        formData.append('page', page);
        formData.append('fromDate', fromDate);
        formData.append('toDate', toDate);
        formData.append('dispatch_type', 2);
        // formData.append('conditions', JSON.stringify(selectedPhysicalConditionType));
        formData.append('sort_column', currentSortColumn);
        formData.append('sort_order', currentSortOrder);

        $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').removeClass('inline-flex');

        $.ajax({
            url: 'exportajax.php', // Change to your handler script
            type: 'POST',
            data: formData,
            contentType: false, // Must for FormData
            processData: false,
            success: function (response) {
                if (response.success === 'success') {
                    $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportType').val().toUpperCase()).removeClass('hidden d-none').addClass('inline-flex').attr('style', 'display: inline-flex !important;');
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });

    $(document).on('click', '.outwardStocksEditModalBtn', function () {
        let id = $(this).data('id');
        if (id) {
            $('#outwardStocksEditForm').find('modal-body').html();
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    fetchStockOutwardEditRecord: 'fetchStockOutwardEditRecord',
                    id: id
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#outwardStocksEditModal').modal('show');
                        $('#outwardStocksEditForm').find('.modal-body').html(res.data);
                    } else if (res.status === 'error') {
                        toastr.error(res.message);
                    } else {
                        toastr.error('Unexpected response.');
                    }
                },
                error: function () {
                    toastr.error('Server error occurred.');
                }
            });
        }
    });

    $('#outwardStocksEditForm').on('submit', function (e) {
        e.preventDefault();
        const form = document.getElementById('outwardStocksEditForm');
        const formData = new FormData(form);
        formData.append('updateStockOutwardEditRecord', 'updateStockOutwardEditRecord');
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status === 'success') {
                    $('#outwardStocksEditModal').modal('hide');
                    $('#outwardStocksEditForm').find('modal-body').html();
                    loadStocksOutwordTable();
                    toastr.success(res.message);
                } else if (res.status === 'error') {
                    toastr.error(res.message);
                } else {
                    toastr.error('Unexpected response.');
                }
            },
            error: function () {
                toastr.error('Server error occurred.');
            }
        });
    });


    // $(document).on('change', '#perPageSelectOrderReceived', function () { loadOrderReceivedAtStockOutwardTable(1); });
</script>
<?php endSection(); ?>
