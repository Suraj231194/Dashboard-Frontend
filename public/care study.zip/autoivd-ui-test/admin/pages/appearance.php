<main id="appearanceSettingsPage" class="min-h-[calc(100vh-4.5rem)] bg-[#f7f8f8] px-4 py-5 font-['Manrope','Public_Sans',sans-serif] text-[#061f18] sm:px-6 lg:px-10 lg:py-12">
  <div class="mx-auto w-full max-w-[78rem]">
    <header class="mb-6 lg:mb-8">
      <h2 class="m-0 mb-1 text-[1.45rem] font-extrabold leading-tight tracking-normal text-[#061f18] sm:text-3xl">Appearance Settings</h2>
      <p class="m-0 text-base leading-6 text-[#222724]">Customize the visual workspace to match your workflow and preferences.</p>
    </header>

    <section class="!rounded-xl border border-[#bfc5c1] bg-white p-4 shadow-none lg:p-6" aria-labelledby="appearance-color-title">
      <div class="mb-6 flex items-center gap-3">
        <span class="grid h-6 w-6 shrink-0 grid-cols-2 overflow-hidden !rounded-full border-2 border-[#061f18]" aria-hidden="true">
          <span class="bg-[#174d37]"></span>
          <span class="bg-white"></span>
        </span>
        <h3 id="appearance-color-title" class="m-0 text-[1.45rem] font-extrabold leading-tight tracking-normal text-[#061f18] sm:text-[1.625rem]">Color Theme</h3>
      </div>

      <div class="grid grid-cols-1 items-start gap-6 xl:grid-cols-[minmax(21rem,35rem)_1fr] xl:gap-12">
        <div>
          <span class="mb-4 block text-[0.8125rem] font-bold tracking-[0.08em] text-[#5f625f]">System Preference</span>
          <div class="grid grid-cols-1 gap-3 sm:grid-cols-3" role="group" aria-label="System Preference">
            <button type="button" class="appearance-choice flex min-h-[4.75rem] flex-col items-center justify-center gap-2 !rounded-xl border border-[#bfc5c1] bg-[#f9fafb] text-[#111] transition-colors hover:border-[#111]" data-appearance-theme="light" aria-pressed="true">
              <i class="ti ti-sun text-[1.75rem]" aria-hidden="true"></i>
              <span class="text-sm font-medium">Light</span>
            </button>
            <button type="button" class="appearance-choice flex min-h-[4.75rem] flex-col items-center justify-center gap-2 !rounded-xl border border-[#bfc5c1] bg-white text-[#111] transition-colors hover:border-[#111]" data-appearance-theme="dark" aria-pressed="false">
              <i class="ti ti-moon text-[1.75rem]" aria-hidden="true"></i>
              <span class="text-sm font-medium">Dark</span>
            </button>
            <button type="button" class="appearance-choice flex min-h-[4.75rem] flex-col items-center justify-center gap-2 !rounded-xl border border-[#bfc5c1] bg-white text-[#111] transition-colors hover:border-[#111]" data-appearance-theme="auto" aria-pressed="false">
              <i class="ti ti-device-desktop text-[1.75rem]" aria-hidden="true"></i>
              <span class="text-sm font-medium">Auto</span>
            </button>
          </div>
        </div>

        <div>
          <span class="mb-4 block text-[0.8125rem] font-bold tracking-[0.08em] text-[#5f625f]">Brand Accent</span>
          <div class="flex flex-wrap items-center gap-3" role="group" aria-label="Brand Accent">
            <button type="button" class="appearance-choice inline-flex h-12 w-12 items-center justify-center !rounded-full border-0 bg-[#174d37] sm:h-16 sm:w-16" data-appearance-accent="#1A4D2E" aria-label="Green accent" aria-pressed="true"></button>
            <button type="button" class="appearance-choice inline-flex h-12 w-12 items-center justify-center !rounded-full border-0 bg-[#05745d] sm:h-16 sm:w-16" data-appearance-accent="#05745D" aria-label="Teal accent" aria-pressed="false"></button>
            <button type="button" class="appearance-choice inline-flex h-12 w-12 items-center justify-center !rounded-full border-0 bg-[#2b435f] sm:h-16 sm:w-16" data-appearance-accent="#2B435F" aria-label="Blue accent" aria-pressed="false"></button>
            <button type="button" class="appearance-choice inline-flex h-12 w-12 items-center justify-center !rounded-full border-0 bg-[#92318a] sm:h-16 sm:w-16" data-appearance-accent="#92318A" aria-label="Purple accent" aria-pressed="false"></button>
            <button type="button" class="appearance-choice inline-flex h-12 w-12 items-center justify-center !rounded-full border-0 bg-[#df9137] sm:h-16 sm:w-16" data-appearance-accent="#DF9137" aria-label="Orange accent" aria-pressed="false"></button>
            <button type="button" id="customAccentButton" class="inline-flex h-12 w-12 items-center justify-center !rounded-full border-2 border-dashed border-[#c6cbc8] bg-white text-[1.6rem] text-[#727772] transition-colors hover:border-[#727772] sm:h-16 sm:w-16" aria-label="Add accent color">
              <i class="ti ti-plus" aria-hidden="true"></i>
            </button>
            <input id="customAccentColor" class="sr-only" type="color" value="#1A4D2E" aria-label="Custom accent color">
          </div>
        </div>
      </div>
    </section>

    <section class="mt-8 !rounded-xl border border-[#bfc5c1] bg-white p-4 shadow-none lg:p-6" aria-labelledby="appearance-font-title">
      <div class="mb-6 flex items-center gap-3">
        <span class="text-[1.45rem] font-black leading-none tracking-normal text-[#061f18]" aria-hidden="true">Tt</span>
        <h3 id="appearance-font-title" class="m-0 text-[1.45rem] font-extrabold leading-tight tracking-normal text-[#061f18] sm:text-[1.625rem]">Font Settings</h3>
      </div>

      <div class="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(17rem,22.5rem)_1fr] xl:gap-8">
        <div>
          <span class="mb-4 block text-[0.8125rem] font-bold tracking-[0.08em] text-[#5f625f]">Typeface Family</span>
          <div class="flex flex-col gap-3" role="group" aria-label="Typeface Family">
            <button type="button" class="appearance-choice flex min-h-[4.6rem] items-center justify-between gap-4 !rounded-xl border border-[#bfc5c1] bg-[#fbfcfc] px-5 py-3 text-left transition-colors hover:border-[#111]" data-appearance-font="Manrope" aria-pressed="true">
              <span class="block">
                <strong class="block text-base font-bold leading-snug text-[#111]">Manrope</strong>
                <span class="block text-[0.95rem] leading-snug text-[#333834]">Modern geometric sans-serif</span>
              </span>
              <i class="appearance-font-check ti ti-circle-check text-[1.65rem] text-[#111]" aria-hidden="true"></i>
            </button>
            <button type="button" class="appearance-choice flex min-h-[4.6rem] items-center justify-between gap-4 !rounded-xl border border-[#bfc5c1] bg-white px-5 py-3 text-left transition-colors hover:border-[#111]" data-appearance-font="Inter" aria-pressed="false">
              <span class="block">
                <strong class="block text-base font-bold leading-snug text-[#111]">Inter</strong>
              <span class="block text-[0.95rem] leading-snug text-[#333834]">Highly legible for UI</span>
              </span>
              <i class="appearance-font-check ti ti-circle-check text-[1.65rem] text-[#111]" aria-hidden="true"></i>
            </button>
            <button type="button" class="appearance-choice flex min-h-[4.6rem] items-center justify-between gap-4 !rounded-xl border border-[#bfc5c1] bg-white px-5 py-3 text-left transition-colors hover:border-[#111]" data-appearance-font="Roboto" aria-pressed="false">
              <span class="block">
                <strong class="block text-base font-bold leading-snug text-[#111]">Roboto</strong>
              <span class="block text-[0.95rem] leading-snug text-[#333834]">Clean and versatile classic</span>
              </span>
              <i class="appearance-font-check ti ti-circle-check text-[1.65rem] text-[#111]" aria-hidden="true"></i>
            </button>
          </div>
        </div>

        <div>
          <span class="mb-4 block text-[0.8125rem] font-bold tracking-[0.08em] text-[#5f625f]">Typography Preview</span>
          <div class="!rounded-xl border border-[#bfc5c1] bg-[#f8f9fa] p-4 sm:p-6">
            <h4 class="m-0 mb-5 text-[1.35rem] font-extrabold leading-tight tracking-normal text-[#061f18] sm:text-3xl">The quick brown fox jumps over the lazy dog.</h4>
            <p class="m-0 max-w-[44rem] text-base leading-[1.55] text-[#2e342f]">Biogenix Enterprise provides an integrated environment for laboratory management, logistics, and resource planning. This typeface is optimized for long-form data entry and high-density information displays.</p>

            <div class="mt-8 flex flex-col gap-3 border-t border-[#d8dcda] pt-5 sm:flex-row sm:gap-12">
              <div>
                <span class="mb-1 block text-[0.8125rem] font-bold tracking-[0.06em] text-[#6b706c]">Heading 1</span>
                <strong class="block text-[1.4rem] leading-tight text-[#111]">Aa Bb Cc 123</strong>
              </div>
              <div>
                <span class="mb-1 block text-[0.8125rem] font-bold tracking-[0.06em] text-[#6b706c]">Body Regular</span>
                <p class="m-0 text-[0.95rem] leading-tight text-[#111]">Aa Bb Cc 123</p>
              </div>
            </div>
          </div>

          <div class="mt-5">
            <div class="mb-2 flex items-center justify-between gap-4 text-sm text-[#111]">
              <span>Base Font Size</span>
              <strong id="baseFontSizeValue" class="font-extrabold">15px</strong>
            </div>
            <input id="baseFontSize" class="h-2 w-full cursor-pointer appearance-none !rounded-full bg-[#e3e5e6] accent-[#174d37] outline-none" type="range" min="12" max="18" value="15" aria-label="Base font size">
            <button type="button" id="resetAppearanceSettings" class="mt-5 text-sm font-bold text-[#174d37] underline underline-offset-4 hover:text-[#061f18]">Reset to default</button>
          </div>
        </div>
      </div>
    </section>
  </div>
</main>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const root = document.documentElement;
    const defaults = { theme_mode: 'light', accent_color: '#1A4D2E', font_family: 'Manrope', base_font_size: 15 };
    const settings = {
      theme_mode: root.dataset.appearanceTheme || defaults.theme_mode,
      accent_color: (root.style.getPropertyValue('--appearance-accent') || defaults.accent_color).trim().toUpperCase(),
      font_family: root.dataset.appearanceFont || defaults.font_family,
      base_font_size: Number.parseInt(root.style.getPropertyValue('--ui-base-font-size'), 10) || defaults.base_font_size
    };
    const fontSizeInput = document.getElementById('baseFontSize');
    const fontSizeValue = document.getElementById('baseFontSizeValue');
    const customAccentInput = document.getElementById('customAccentColor');

    function notify(message, type) {
      if (window.AdminToast) {
        window.AdminToast.show(message, type);
      }
    }

    function refreshControls() {
      document.querySelectorAll('[data-appearance-theme]').forEach(function (button) {
        button.setAttribute('aria-pressed', String(button.dataset.appearanceTheme === settings.theme_mode));
      });
      document.querySelectorAll('[data-appearance-accent]').forEach(function (button) {
        button.setAttribute('aria-pressed', String(button.dataset.appearanceAccent.toUpperCase() === settings.accent_color));
      });
      document.querySelectorAll('[data-appearance-font]').forEach(function (button) {
        button.setAttribute('aria-pressed', String(button.dataset.appearanceFont === settings.font_family));
      });
      fontSizeInput.value = settings.base_font_size;
      fontSizeValue.textContent = settings.base_font_size + 'px';
      customAccentInput.value = settings.accent_color;
    }

    function applySettings() {
      root.dataset.appearanceTheme = settings.theme_mode;
      root.dataset.appearanceFont = settings.font_family;
      root.style.setProperty('--appearance-accent', settings.accent_color);
      root.style.setProperty('--color-primary-50', 'color-mix(in srgb, ' + settings.accent_color + ' 8%, #ffffff)');
      root.style.setProperty('--color-primary-100', 'color-mix(in srgb, ' + settings.accent_color + ' 18%, #ffffff)');
      root.style.setProperty('--color-primary-200', 'color-mix(in srgb, ' + settings.accent_color + ' 32%, #ffffff)');
      root.style.setProperty('--color-primary-500', 'color-mix(in srgb, ' + settings.accent_color + ' 88%, #ffffff)');
      root.style.setProperty('--color-primary-600', settings.accent_color);
      root.style.setProperty('--color-primary-700', 'color-mix(in srgb, ' + settings.accent_color + ' 78%, #000000)');
      root.style.setProperty('--color-primary-800', 'color-mix(in srgb, ' + settings.accent_color + ' 60%, #000000)');
      root.style.setProperty('--color-primary-900', 'color-mix(in srgb, ' + settings.accent_color + ' 42%, #000000)');
      root.style.setProperty('font-size', settings.base_font_size + 'px', 'important');
      root.style.setProperty('--ui-base-font-size', settings.base_font_size + 'px');
      refreshControls();
    }

    function saveSettings() {
      const formData = new FormData();
      formData.append('saveAppearanceSettings', '1');
      formData.append('theme_mode', settings.theme_mode);
      formData.append('accent_color', settings.accent_color);
      formData.append('font_family', settings.font_family);
      formData.append('base_font_size', String(settings.base_font_size));
      formData.append('csrf_token', document.querySelector('meta[name="csrf-token"]')?.content || '');

      return fetch('ajax.php', { method: 'POST', body: formData })
        .then(function (response) { return response.json(); })
        .then(function (response) {
          if (response.status !== 'success') {
            throw new Error(response.message || 'Unable to save appearance settings.');
          }
          notify('Appearance settings saved.', 'success');
        })
        .catch(function (error) {
          notify(error.message, 'error');
        });
    }

    document.querySelectorAll('[data-appearance-theme]').forEach(function (button) {
      button.addEventListener('click', function () {
        settings.theme_mode = button.dataset.appearanceTheme;
        applySettings();
        saveSettings();
      });
    });

    document.querySelectorAll('[data-appearance-accent]').forEach(function (button) {
      button.addEventListener('click', function () {
        settings.accent_color = button.dataset.appearanceAccent.toUpperCase();
        applySettings();
        saveSettings();
      });
    });

    document.querySelectorAll('[data-appearance-font]').forEach(function (button) {
      button.addEventListener('click', function () {
        settings.font_family = button.dataset.appearanceFont;
        applySettings();
        saveSettings();
      });
    });

    document.getElementById('customAccentButton').addEventListener('click', function () {
      customAccentInput.click();
    });

    customAccentInput.addEventListener('input', function () {
      settings.accent_color = customAccentInput.value.toUpperCase();
      applySettings();
    });
    customAccentInput.addEventListener('change', saveSettings);

    fontSizeInput.addEventListener('input', function () {
      settings.base_font_size = Number.parseInt(fontSizeInput.value, 10);
      applySettings();
    });
    fontSizeInput.addEventListener('change', saveSettings);

    document.getElementById('resetAppearanceSettings').addEventListener('click', function () {
      Object.assign(settings, defaults);
      applySettings();
      saveSettings();
    });

    applySettings();
  });
</script>
