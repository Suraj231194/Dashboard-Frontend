<div class="container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1
                style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;">
                <?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?>
            </h1>
            <p
                style="font-size: 0.875rem; color: var(--ui-text-muted, #6b706b); margin-top: 0.25rem; font-family: 'Manrope', sans-serif;">
                Manage BMR/BPR issuance records efficiently
            </p>
        </div>

        <div class="flex items-center gap-3">
            <div class="flex w-44 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm transition-all hover:border-slate-300">
                <span class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100">
                    <i class="ti ti-check text-lg"></i>
                </span>
                <div class="min-w-0 flex-1">
                    <p class="m-0 text-[10px] font-bold uppercase tracking-wider text-slate-400 truncate">Approved</p>
                    <p id="bmrBprApprovedCount" class="m-0 text-lg font-extrabold leading-tight text-slate-900">0</p>
                </div>
            </div>

            <div class="flex w-44 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm transition-all hover:border-slate-300">
                <span class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-rose-50 text-rose-600 ring-1 ring-rose-100">
                    <i class="ti ti-x text-lg"></i>
                </span>
                <div class="min-w-0 flex-1">
                    <p class="m-0 text-[10px] font-bold uppercase tracking-wider text-slate-400 truncate">Rejected</p>
                    <p id="bmrBprRejectedCount" class="m-0 text-lg font-extrabold leading-tight text-slate-900">0</p>
                </div>
            </div>
        </div>
    </div>

    <!-- BMR/BPR Issuance Requests Widget -->
    <div id="bmrBprIssuanceWidget" class="mb-6 relative cursor-pointer w-full md:w-1/2" role="button" tabindex="0">
        <div class="overflow-hidden rounded-xl border p-4 shadow-sm transition-shadow hover:shadow-md"
            style="display: flex; align-items: center; justify-content: space-between; border-color: color-mix(in srgb, var(--appearance-accent, #db2777) 18%, #e2e8f0); background-color: color-mix(in srgb, var(--appearance-accent, #db2777) 7%, #ffffff);">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <div
                    style="position: relative; display: flex; align-items: center; justify-content: center; width: 3rem; height: 3rem; background-color: color-mix(in srgb, var(--appearance-accent, #db2777) 12%, #ffffff); border-radius: 0.75rem;">
                    <i class="ti ti-clipboard-text"
                        style="font-size: 1.5rem; color: var(--appearance-accent, #db2777);"></i>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h3 class="font-bold leading-tight"
                            style="font-size: 1.125rem; color: var(--appearance-accent, #be185d); margin: 0;">
                            BMR/BPR Issuance Form Requests
                        </h3>
                        <span id="bmrBprIssuanceRequestCount" aria-live="polite"
                            style="display: flex; align-items: center; justify-content: center; min-width: 1.25rem; height: 1.25rem; padding: 0 0.3rem; background-color: var(--appearance-accent, #db2777); color: white; font-weight: bold; font-size: 0.75rem; border-radius: 9999px;">3</span>
                    </div>
                    <p class="font-medium mt-1 mb-0"
                        style="font-size: 0.875rem; color: var(--ui-text-muted, #64748b);">
                        You have <span id="bmrBprIssuanceRequestCountText" class="font-bold" style="color: var(--appearance-accent, #be185d);">0</span>
                        new issuance form request(s) to review.
                    </p>
                </div>
            </div>
            <div style="color: var(--appearance-accent, #db2777);">
                <i class="ti ti-chevron-right" style="font-size: 1.25rem;"></i>
            </div>
        </div>
    </div>



    <!-- BMR/BPR Issuance Records Table -->
    <div class="w-full">
        <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
                <div
                    class="flex flex-col items-stretch gap-3 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm md:flex-row md:items-center">
                    <input type="hidden" id="bmrBprIssuancePerPage" value="10">

                    <div class="dropdown shrink-0">
                        <button
                            class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2"
                            style="--tw-ring-color: var(--appearance-accent, #166534);" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="text-xs font-medium text-slate-400">Show</span>
                            <span id="bmrBprIssuancePerPageText" class="whitespace-nowrap">10</span>
                            <span class="text-xs font-medium text-slate-400">items</span>
                            <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                        </button>
                        <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                            <li><a
                                    class="bmr-bpr-issuance-per-page block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="5">5 items</a></li>
                            <li><a
                                    class="bmr-bpr-issuance-per-page block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="10">10 items</a></li>
                            <li><a
                                    class="bmr-bpr-issuance-per-page block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="25">25 items</a></li>
                            <li><a
                                    class="bmr-bpr-issuance-per-page block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="50">50 items</a></li>
                            <li><a
                                    class="bmr-bpr-issuance-per-page block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                    data-val="100000000">All items</a></li>
                        </ul>
                    </div>

                    <div class="relative ml-auto h-10 min-w-[200px] max-w-[360px] flex-grow md:flex-grow-0 md:w-[300px]">
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                            <i class="ti ti-search text-lg text-slate-400"></i>
                        </div>
                        <input type="search" id="bmrBprIssuanceSearch"
                            class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-4 pr-10 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:ring-2"
                            style="--tw-ring-color: var(--appearance-accent, #166534);"
                            placeholder="Search BMR / BPR..." autocomplete="off">
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-36 h-11" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i>
                        <span>Export</span>
                    </button>
                </div>
            </div>

            <div class="w-full overflow-x-auto">
                <table class="w-full border-collapse text-left">
                    <thead class="whitespace-nowrap border-b border-slate-100 bg-slate-50/60">
                        <tr>
                            <th
                                class="w-24 px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                # / Serial Number
                            </th>
                            <th class="bmr-bpr-issuance-sortable cursor-pointer px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-100/60"
                                data-column="product_name">
                                <span class="inline-flex items-center gap-1">Product Name <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="bmr-bpr-issuance-sortable cursor-pointer px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-100/60"
                                data-column="lot_number">
                                <span class="inline-flex items-center gap-1">Lot Number <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                            <th class="w-28 px-6 py-4 text-center text-[11px] font-bold uppercase tracking-widest text-slate-400">
                                Action
                            </th>
                            <th class="bmr-bpr-issuance-sortable w-40 cursor-pointer px-6 py-4 text-[11px] font-bold uppercase tracking-widest text-slate-400 transition-colors hover:bg-slate-100/60"
                                data-column="status">
                                <span class="inline-flex items-center gap-1">Status <i
                                        class="ti ti-selector text-sm"></i></span>
                            </th>
                        </tr>
                    </thead>
                    <tbody id="bmrBprIssuanceTableBody"
                        class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                        <tr>
                            <td colspan="5" class="px-6 py-10 text-center text-sm font-medium text-slate-500">
                                Loading BMR/BPR issuance records...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div
                class="flex flex-col items-center justify-between gap-3 border-t border-slate-200 bg-white px-6 py-4 md:flex-row">
                <p id="bmrBprIssuanceSummary" class="m-0 text-sm font-medium text-slate-500">
                    Showing 0 to 0 of 0 entries
                </p>
                <div id="bmrBprIssuancePagination" class="flex items-center gap-2"></div>
            </div>
        </div>
    </div>
</div>

<!-- Export Document Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="bmrBprIssuanceExportForm">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                        <div class="dropdown w-full">
                            <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">CSV (Comma Separated Values)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="csv">
                    </div>
                    
                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                            <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="S.No" checked />
                                    <span class="text-sm font-medium text-slate-700">S.No</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Product Name" checked />
                                    <span class="text-sm font-medium text-slate-700">Product Name</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Lot Number" checked />
                                    <span class="text-sm font-medium text-slate-700">Lot Number</span>
                                </label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100">
                                    <input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked />
                                    <span class="text-sm font-medium text-slate-700">Status</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10" id="exportModalSubmitBtn">
                        <i class="ti ti-download text-base"></i> Export
                    </button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-lg"></i> Download CSV</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- BMR/BPR Issuance Form Requests Modal -->
<div class="modal fade animate__animated fadeIn" id="bmrBprIssuanceRequestsModal" tabindex="-1"
    aria-hidden="true" aria-labelledby="bmrBprIssuanceRequestsTitle">
    <div class="modal-dialog modal-lg modal-dialog-centered" style="max-width: 820px;" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div
                class="modal-header relative flex items-center justify-between border-b border-slate-200 bg-white !px-4 !py-3">
                <div class="flex items-center gap-3">
                    <div
                        style="position: relative; display: flex; align-items: center; justify-content: center; width: 2.75rem; height: 2.75rem; background-color: var(--color-primary-50, #f3e8ff); border-radius: 0.65rem;">
                        <i class="ti ti-clipboard-text"
                            style="font-size: 1.4rem; color: var(--appearance-accent, #7e22ce);"></i>
                        <span
                            style="position: absolute; bottom: -0.2rem; right: -0.2rem; display: flex; align-items: center; justify-content: center; width: 1.05rem; height: 1.05rem; background-color: var(--appearance-accent, #7e22ce); color: white; font-weight: bold; font-size: 0.65rem; border-radius: 9999px; border: 1.5px solid white;">!</span>
                    </div>
                    <div>
                        <h5 id="bmrBprIssuanceRequestsTitle"
                            class="modal-title m-0 font-bold leading-tight"
                            style="font-size: 1.05rem; color: var(--ui-text, #1e293b);">
                            BMR/BPR Issuance Form Requests
                        </h5>
                        <p class="m-0 mt-0.5 font-medium"
                            style="font-size: 0.775rem; color: var(--ui-text-muted, #64748b);">
                            Review and approve pending documentation requests for production lots.
                        </p>
                    </div>
                </div>
                <button type="button"
                    class="ml-auto inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 shadow-sm transition-colors hover:bg-slate-50 hover:text-slate-600 focus:outline-none"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x text-base"></i>
                </button>
            </div>

            <div class="modal-body p-0">
                <div class="w-full overflow-x-auto">
                    <table class="w-full border-collapse text-left">
                        <thead class="whitespace-nowrap border-b border-slate-100 bg-white">
                            <tr>
                                <th
                                    class="w-12 px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                    S.No
                                </th>
                                <th
                                    class="min-w-[160px] px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                    Product Name
                                </th>
                                <th
                                    class="min-w-[100px] px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                    Lot No
                                </th>
                                <th
                                    class="w-28 px-3 py-2 text-right text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody id="bmrBprIssuanceRequestsBody"
                            class="divide-y divide-slate-100 bg-white text-sm font-medium text-slate-700">
                            <tr>
                                <td colspan="4" class="px-6 py-10 text-center text-sm font-medium text-slate-500">
                                    Loading issuance form requests...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div
                    class="flex flex-col items-center justify-between border-t border-slate-200 bg-white px-4 py-2.5 md:flex-row">
                    <span id="bmrBprIssuanceRequestsSummary" class="text-xs font-medium text-slate-500">
                        Showing 0 to 0 of 0 requests
                    </span>
                    <div class="flex items-center gap-1">
                        <button id="bmrBprIssuanceRequestsPrev" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Previous page" disabled>
                            <i class="ti ti-arrow-left text-sm"></i>
                        </button>
                        <span id="bmrBprIssuanceRequestsCurrentPage"
                            class="inline-flex h-8 min-w-8 items-center justify-center rounded-lg px-2 text-sm font-bold text-white shadow-sm"
                            style="background-color: var(--appearance-accent, #166534); box-shadow: 0 0 0 1px color-mix(in srgb, var(--appearance-accent, #166534) 10%, transparent);">1</span>
                        <button id="bmrBprIssuanceRequestsNext" type="button"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 text-slate-400 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                            title="Next page" disabled>
                            <i class="ti ti-arrow-right text-sm"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    #bmrBprReviewModal {
        z-index: 1070;
    }

    .modal-backdrop.bmr-bpr-review-backdrop {
        z-index: 1065;
    }

    .bmr-bpr-review-value {
        min-height: 2rem;
        border-bottom: 1px solid #e2e8f0;
    }

    .bmr-bpr-decision-card {
        cursor: pointer;
        transition: border-color 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
    }

    .bmr-bpr-decision-card:hover {
        border-color: color-mix(in srgb, var(--appearance-accent, #166534) 45%, #cbd5e1);
    }
</style>

<!-- BMR/BPR review modal -->
<div class="modal fade" id="bmrBprReviewModal" tabindex="-1" aria-labelledby="bmrBprReviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" style="max-width: 1030px;">
        <div class="modal-content overflow-hidden rounded-2xl border-0 shadow-2xl">
            <div class="modal-header items-start border-b border-slate-200 bg-white px-6 py-4">
                <div class="flex min-w-0 items-start gap-3">
                    <span class="mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                        style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 10%, white); color: var(--appearance-accent, #166534);">
                        <i class="ti ti-clipboard-check text-xl"></i>
                    </span>
                    <div>
                        <h5 class="modal-title m-0 text-base font-bold text-slate-900" id="bmrBprReviewModalLabel">BMR / BPR Review</h5>
                        <p class="m-0 mt-1 text-xs font-medium text-slate-500">Technical specification and issuance validation for batch production.</p>
                    </div>
                </div>
                <button type="button" class="btn-close mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="bmrBprReviewForm" class="flex flex-col overflow-hidden h-full w-full">
                <input type="hidden" id="bmrBprReviewId">
                <div class="modal-body space-y-5 bg-slate-50/60 px-6 py-5 overflow-y-auto" style="max-height: calc(100vh - 140px);">
                    <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <div><span class="block text-xs font-medium text-slate-500">Production Plan</span><strong id="bmrBprReviewPlan" class="break-words text-sm text-slate-900"></strong></div>
                        <div><span class="block text-xs font-medium text-slate-500">Material Requisition</span><strong id="bmrBprReviewRequisition" class="break-words text-sm text-slate-900"></strong></div>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm">
                            <thead><tr class="border-b border-slate-200"><th class="p-2">Material</th><th class="p-2">Required</th><th class="p-2">Issued</th><th class="p-2">Unit</th><th class="p-2">Material Batches</th></tr></thead>
                            <tbody id="bmrBprReviewMaterials"></tbody>
                        </table>
                    </div>
                    <section class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div class="flex flex-wrap items-start justify-between gap-3">
                            <div>
                                <span class="inline-flex rounded-md bg-slate-100 px-2 py-1 font-mono text-[11px] font-bold text-slate-600">
                                    S.No: <span id="bmrBprReviewSerial" class="ml-1">01</span>
                                </span>
                                <h6 class="m-0 mt-2 text-sm font-bold text-slate-800">Batch Manufacturing Record Details</h6>
                            </div>
                            <span id="bmrBprReviewStatus"
                                class="inline-flex items-center rounded-full bg-emerald-100 px-3 py-1 text-[10px] font-extrabold uppercase tracking-wider text-emerald-700">
                                Awaiting QC
                            </span>
                        </div>

                        <div class="my-4 border-t border-slate-200"></div>

                        <div class="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-3">
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Product Name</p>
                                <p id="bmrBprReviewProduct" class="bmr-bpr-review-value m-0 mt-1 pb-2 text-sm font-bold text-slate-900"></p>
                            </div>
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Batch No</p>
                                <p id="bmrBprReviewBatch" class="bmr-bpr-review-value m-0 mt-1 pb-2 font-mono text-sm font-bold text-slate-800"></p>
                            </div>
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Lot No</p>
                                <p id="bmrBprReviewLot" class="bmr-bpr-review-value m-0 mt-1 pb-2 font-mono text-sm font-bold text-slate-800"></p>
                            </div>
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">CAT No</p>
                                <p id="bmrBprReviewCategory" class="bmr-bpr-review-value m-0 mt-1 pb-2 font-mono text-sm font-bold text-slate-800"></p>
                            </div>
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">No. of Forms</p>
                                <p id="bmrBprReviewFormCount" class="bmr-bpr-review-value m-0 mt-1 pb-2 text-sm font-bold text-slate-800"></p>
                            </div>
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Pack Size</p>
                                <p id="bmrBprReviewPackSize" class="bmr-bpr-review-value m-0 mt-1 pb-2 text-sm font-bold text-slate-800"></p>
                            </div>
                        </div>

                        <div class="mt-5 grid grid-cols-1 gap-5 md:grid-cols-3">
                            <div class="md:col-span-2">
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Remarks</p>
                                <p id="bmrBprReviewRemarks" class="m-0 mt-2 text-sm italic leading-6 text-slate-700"></p>
                            </div>
                            <div>
                                <p class="m-0 text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Requested By</p>
                                <div class="mt-2 flex items-center gap-2">
                                    <span class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
                                        style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 12%, white); color: var(--appearance-accent, #166534);">
                                        <i class="ti ti-user text-sm"></i>
                                    </span>
                                    <span id="bmrBprReviewRequestedBy" class="text-sm font-bold text-slate-800"></span>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div class="mb-4 flex items-center gap-2">
                            <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg"
                                style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 10%, white); color: var(--appearance-accent, #166534);">
                                <i class="ti ti-certificate text-lg"></i>
                            </span>
                            <h6 class="m-0 text-sm font-bold text-slate-800">QC Compliance Decision</h6>
                        </div>

                        <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
                            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                                <label class="bmr-bpr-decision-card flex min-h-28 items-center gap-3 rounded-xl border border-slate-200 bg-white p-4"
                                    for="bmrBprDecisionApproved" data-decision="approved">
                                    <input class="sr-only" type="radio" name="bmrBprDecision" id="bmrBprDecisionApproved" value="approved">
                                    <span class="bmr-bpr-decision-icon inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700">
                                        <i class="ti ti-circle-check text-xl"></i>
                                    </span>
                                    <span>
                                        <span class="block text-sm font-bold text-slate-800">Approve</span>
                                        <span class="mt-1 block text-xs font-medium text-slate-500">Quality verified.</span>
                                    </span>
                                </label>

                                <label class="bmr-bpr-decision-card flex min-h-28 items-center gap-3 rounded-xl border border-slate-200 bg-white p-4"
                                    for="bmrBprDecisionRejected" data-decision="rejected">
                                    <input class="sr-only" type="radio" name="bmrBprDecision" id="bmrBprDecisionRejected" value="rejected">
                                    <span class="bmr-bpr-decision-icon inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-rose-200 bg-rose-50 text-rose-700">
                                        <i class="ti ti-circle-x text-xl"></i>
                                    </span>
                                    <span>
                                        <span class="block text-sm font-bold text-slate-800">Reject</span>
                                        <span class="mt-1 block text-xs font-medium text-slate-500">Requires rework.</span>
                                    </span>
                                </label>
                            </div>

                            <div>
                                <label for="bmrBprReviewerComments" class="mb-2 block text-[10px] font-extrabold uppercase tracking-wider text-slate-500">
                                    Final Reviewer Comments
                                </label>
                                <textarea id="bmrBprReviewerComments" rows="4"
                                    class="form-control min-h-28 rounded-xl border-slate-200 text-sm shadow-none focus:border-slate-300 focus:ring-0"
                                    placeholder="Add any specific instructions for the production team..."></textarea>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="modal-footer border-t border-slate-200 bg-white px-6 py-4 shrink-0">
                    <button type="button" id="discardBmrBprReview" class="btn rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50"
                        data-bs-dismiss="modal">
                        Discard Review
                    </button>
                    <button type="submit" id="bmrBprReviewSubmitBtn" class="btn inline-flex items-center gap-2 rounded-xl border-0 px-5 py-2 text-sm font-bold text-white shadow-sm"
                        style="background-color: var(--appearance-accent, #166534);">
                        <i class="ti ti-send text-sm"></i>Submit Final Decision
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    (function () {
        'use strict';

        let issuanceRecords = [];
        let issuanceFormRequests = [];
        const bmrBprIssuanceCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

        let currentPage = 1;
        let sortColumn = 'activity_at';
        let sortDirection = 'desc';
        let currentIssuanceRequestPage = 1;
        const issuanceRequestsPerPage = 5;

        function escapeIssuanceText(value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        }

        function filteredIssuanceRecords() {
            const query = String($('#bmrBprIssuanceSearch').val() || '').trim().toLowerCase();
            const rows = issuanceRecords.filter(function (record) {
                const searchable = [
                    record.serial_number,
                    record.product_name,
                    record.lot_number,
                    record.status
                ].join(' ').toLowerCase();
                return !query || searchable.includes(query);
            });

            rows.sort(function (left, right) {
                const leftValue = left[sortColumn] == null ? '' : left[sortColumn];
                const rightValue = right[sortColumn] == null ? '' : right[sortColumn];
                const comparison = String(leftValue).localeCompare(String(rightValue), undefined, {
                    numeric: true,
                    sensitivity: 'base'
                });
                return sortDirection === 'asc' ? comparison : -comparison;
            });
            return rows;
        }

        function statusBadge(status) {
            const approved = String(status).toLowerCase() === 'approved';
            const classes = approved
                ? 'bg-emerald-50 text-emerald-700 ring-emerald-100'
                : 'bg-rose-50 text-rose-700 ring-rose-100';
            const icon = approved ? 'ti-check' : 'ti-x';
            return `<span class="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold ring-1 ring-inset ${classes}">
                <i class="ti ${icon} text-xs"></i>${escapeIssuanceText(status)}
            </span>`;
        }

        function renderPagination(totalRows, perPage, totalPages) {
            const first = totalRows === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
            const last = totalRows === 0 ? 0 : Math.min(currentPage * perPage, totalRows);
            $('#bmrBprIssuanceSummary').text(`Showing ${first} to ${last} of ${totalRows} entries`);

            const previousDisabled = currentPage <= 1 ? 'disabled' : '';
            const nextDisabled = currentPage >= totalPages ? 'disabled' : '';
            $('#bmrBprIssuancePagination').html(`
                <button type="button" id="bmrBprIssuancePrevious" ${previousDisabled}
                    class="inline-flex h-9 items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40">
                    <i class="ti ti-chevron-left"></i><span class="hidden sm:inline">Previous</span>
                </button>
                <span class="inline-flex h-9 min-w-9 items-center justify-center rounded-xl px-3 text-sm font-bold text-white shadow-sm" style="background-color: var(--appearance-accent, #166534);">${currentPage}</span>
                <button type="button" id="bmrBprIssuanceNext" ${nextDisabled}
                    class="inline-flex h-9 items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-600 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40">
                    <span class="hidden sm:inline">Next</span><i class="ti ti-chevron-right"></i>
                </button>
            `);
        }

        function renderIssuanceRecords() {
            const rows = filteredIssuanceRecords();
            const perPage = Math.max(1, Number($('#bmrBprIssuancePerPage').val() || 10));
            const totalPages = Math.max(1, Math.ceil(rows.length / perPage));
            currentPage = Math.min(Math.max(1, currentPage), totalPages);
            const offset = (currentPage - 1) * perPage;
            const visibleRows = rows.slice(offset, offset + perPage);

            if (visibleRows.length === 0) {
                $('#bmrBprIssuanceTableBody').html(`<tr>
                    <td colspan="5" class="px-6 py-12 text-center">
                        <span class="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-400">
                            <i class="ti ti-file-off text-2xl"></i>
                        </span>
                        <p class="m-0 text-sm font-bold text-slate-700">No BMR/BPR issuance records found.</p>
                    </td>
                </tr>`);
            } else {
                $('#bmrBprIssuanceTableBody').html(visibleRows.map(function (record) {
                    return `<tr class="transition-colors hover:bg-slate-50/50">
                        <td class="px-6 py-4 text-sm font-bold text-slate-900">${escapeIssuanceText(record.serial_number)}</td>
                        <td class="px-6 py-4 text-sm font-bold text-slate-900">${escapeIssuanceText(record.product_name)}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-600">${escapeIssuanceText(record.lot_number)}</td>
                        <td class="px-6 py-4 text-center">
                            <button type="button"
                                class="bmr-bpr-view-record-btn inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-200 bg-white text-slate-700 shadow-sm transition-all hover:bg-slate-50 hover:border-slate-300 hover:text-emerald-700"
                                data-id="${escapeIssuanceText(record.id)}">
                                <i class="ti ti-eye text-base text-emerald-600"></i> View
                            </button>
                        </td>
                        <td class="px-6 py-4">${statusBadge(record.status)}</td>
                    </tr>`;
                }).join(''));
            }

            $('#exportBmrBprIssuance').prop('disabled', rows.length === 0);
            renderPagination(rows.length, perPage, totalPages);
        }

        function notifyIssuanceUiOnly() {
            const message = 'No BMR/BPR issuance record is available for this action.';
            if (window.toastr && typeof window.toastr.info === 'function') {
                window.toastr.info(message);
            }
        }

        function loadBmrBprIssuance(resetPage = true, silent = false) {
            $.ajax({
                url: 'ajax.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    loadBmrBprIssuance: 'loadBmrBprIssuance',
                    csrf_token: bmrBprIssuanceCsrf
                },
                success: function (response) {
                    if (response.status !== 'success') {
                        if (!silent) toastr.error(response.message || 'Unable to load BMR/BPR issuance records.');
                        return;
                    }
                    issuanceRecords = response.data?.records || [];
                    issuanceFormRequests = response.data?.pending || [];
                    const counts = response.data?.counts || {};
                    $('#bmrBprIssuanceRequestCount, #bmrBprIssuanceRequestCountText')
                        .text(Number(counts.pending || 0));
                    $('#bmrBprApprovedCount').text(Number(counts.approved || 0));
                    $('#bmrBprRejectedCount').text(Number(counts.rejected || 0));
                    if (resetPage) {
                        currentPage = 1;
                        currentIssuanceRequestPage = 1;
                    }
                    renderIssuanceRecords();
                    renderIssuanceFormRequests();
                },
                error: function (xhr) {
                    if (silent) return;
                    toastr.error(xhr.responseJSON?.message || 'Unable to load BMR/BPR issuance records.');
                    issuanceRecords = [];
                    issuanceFormRequests = [];
                    $('#bmrBprIssuanceRequestCount, #bmrBprIssuanceRequestCountText, #bmrBprApprovedCount, #bmrBprRejectedCount').text(0);
                    renderIssuanceRecords();
                    renderIssuanceFormRequests();
                }
            });
        }

        function renderIssuanceFormRequests() {
            const totalRows = issuanceFormRequests.length;
            const totalPages = Math.max(1, Math.ceil(totalRows / issuanceRequestsPerPage));
            currentIssuanceRequestPage = Math.min(Math.max(1, currentIssuanceRequestPage), totalPages);
            const offset = (currentIssuanceRequestPage - 1) * issuanceRequestsPerPage;
            const visibleRequests = issuanceFormRequests.slice(offset, offset + issuanceRequestsPerPage);
            const first = totalRows === 0 ? 0 : offset + 1;
            const last = totalRows === 0 ? 0 : Math.min(offset + issuanceRequestsPerPage, totalRows);

            $('#bmrBprIssuanceRequestsSummary').text(`Showing ${first} to ${last} of ${totalRows} requests`);
            $('#bmrBprIssuanceRequestsCurrentPage').text(currentIssuanceRequestPage);
            $('#bmrBprIssuanceRequestsPrev').prop('disabled', currentIssuanceRequestPage <= 1);
            $('#bmrBprIssuanceRequestsNext').prop('disabled', currentIssuanceRequestPage >= totalPages);

            if (visibleRequests.length === 0) {
                $('#bmrBprIssuanceRequestsBody').html(`<tr>
                    <td colspan="4" class="px-6 py-12 text-center text-sm font-semibold text-slate-500">
                        No issuance form requests available.
                    </td>
                </tr>`);
                return;
            }

            $('#bmrBprIssuanceRequestsBody').html(visibleRequests.map(function (request, index) {
                return `<tr class="transition-colors hover:bg-slate-50/50">
                    <td class="px-3 py-2 align-middle text-xs font-bold text-slate-900">${String(offset + index + 1).padStart(2, '0')}</td>
                    <td class="px-3 py-2 align-middle">
                        <p class="m-0 text-xs font-bold text-slate-900">${escapeIssuanceText(request.product_name)}</p>
                        <p class="m-0 mt-0.5 text-[10px] font-medium uppercase tracking-wide text-slate-400">SKU: ${escapeIssuanceText(request.sku)}</p>
                    </td>
                    <td class="px-3 py-2 align-middle">
                        <span class="inline-flex rounded-md px-2 py-0.5 font-mono text-[11px] font-bold"
                            style="background-color: color-mix(in srgb, var(--appearance-accent, #166534) 8%, #f8fafc); color: var(--ui-text, #334155);">
                            ${escapeIssuanceText(request.lot_number)}
                        </span>
                    </td>
                    <td class="px-3 py-2 text-right align-middle">
                        <button type="button"
                            class="bmr-bpr-view-issuance-request biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-1 px-2.5 h-7 text-[10px]"
                            data-id="${escapeIssuanceText(request.id)}">
                            <i class="ti ti-eye text-xs"></i> View Request
                        </button>
                    </td>
                </tr>`;
            }).join(''));
        }

        function updateBmrBprDecisionCards() {
            $('.bmr-bpr-decision-card').each(function () {
                const card = $(this);
                const decision = String(card.data('decision') || '');
                const selected = card.find('input[name="bmrBprDecision"]').prop('checked');
                let borderColor = '#e2e8f0';
                let backgroundColor = '#ffffff';
                let boxShadow = 'none';

                if (selected && decision === 'approved') {
                    borderColor = '#86efac';
                    backgroundColor = '#f0fdf4';
                    boxShadow = '0 0 0 3px rgba(34, 197, 94, 0.10)';
                } else if (selected && decision === 'rejected') {
                    borderColor = '#fda4af';
                    backgroundColor = '#fff1f2';
                    boxShadow = '0 0 0 3px rgba(244, 63, 94, 0.10)';
                }

                card.css({
                    borderColor: borderColor,
                    backgroundColor: backgroundColor,
                    boxShadow: boxShadow
                });
            });
        }

        function openBmrBprReviewModal(button, isReadOnly = false) {
            const requestId = String($(button).data('id') || '');
            let request = issuanceFormRequests.find(function (r) {
                return String(r.id) === requestId;
            });
            let isDecisionRecord = false;
            if (!request) {
                request = issuanceRecords.find(function (r) {
                    return String(r.id) === requestId;
                });
                if (request) {
                    isDecisionRecord = true;
                }
            }

            if (!request) {
                notifyIssuanceUiOnly();
                return;
            }

            $('#bmrBprReviewId').val(request.id);
            $('#bmrBprReviewPlan').text(request.production_plan_no || '-');
            $('#bmrBprReviewRequisition').text(request.material_requisition_no || '-');
            const materials = Array.isArray(request.issued_materials) ? request.issued_materials : [];
            $('#bmrBprReviewMaterials').html(materials.map(function (material) {
                return `<tr class="border-b border-slate-100"><td class="p-2">${escapeIssuanceText(material.material_name || '')}</td><td class="p-2">${escapeIssuanceText(material.required_qty ?? '')}</td><td class="p-2">${escapeIssuanceText(material.issued_qty ?? '')}</td><td class="p-2">${escapeIssuanceText(material.unit_name || '')}</td><td class="p-2">${escapeIssuanceText(material.issued_batches || '-')}</td></tr>`;
            }).join('') || '<tr><td colspan="5" class="p-2 text-slate-500">No issued materials.</td></tr>');
            $('#bmrBprReviewSerial').text(String(request.serial_number || request.id || '01').padStart(2, '0'));
            $('#bmrBprReviewProduct').text(request.product_name);
            $('#bmrBprReviewBatch').text(request.batch_number);
            $('#bmrBprReviewLot').text(request.lot_number);
            $('#bmrBprReviewCategory').text(request.category_code);
            $('#bmrBprReviewFormCount').text(
                `${request.bmr_form_count || 0} BMR / ${request.bpr_form_count || 0} BPR`
            );
            $('#bmrBprReviewPackSize').text(request.pack_size);
            $('#bmrBprReviewRemarks').text(`\u201C${request.remarks || '-'}\u201D`);
            $('#bmrBprReviewRequestedBy').text(request.requested_by);

            const statusCode = String(request.status_code || '').toUpperCase();
            if (statusCode === 'APPROVED') {
                $('#bmrBprReviewStatus')
                    .removeClass('bg-amber-100 text-amber-700 bg-rose-100 text-rose-700')
                    .addClass('bg-emerald-100 text-emerald-700')
                    .text('Approved');
            } else if (statusCode === 'REJECTED') {
                $('#bmrBprReviewStatus')
                    .removeClass('bg-amber-100 text-amber-700 bg-emerald-100 text-emerald-700')
                    .addClass('bg-rose-100 text-rose-700')
                    .text('Rejected');
            } else {
                $('#bmrBprReviewStatus')
                    .removeClass('bg-emerald-100 text-emerald-700 bg-rose-100 text-rose-700')
                    .addClass('bg-amber-100 text-amber-700')
                    .text('Awaiting QC');
            }

            if (isDecisionRecord || isReadOnly) {
                if (statusCode === 'APPROVED') {
                    $('#bmrBprDecisionApproved').prop('checked', true);
                    $('#bmrBprDecisionRejected').prop('checked', false);
                } else if (statusCode === 'REJECTED') {
                    $('#bmrBprDecisionApproved').prop('checked', false);
                    $('#bmrBprDecisionRejected').prop('checked', true);
                } else {
                    $('input[name="bmrBprDecision"]').prop('checked', false);
                }
                $('input[name="bmrBprDecision"]').prop('disabled', true);
                $('.bmr-bpr-decision-card').addClass('pointer-events-none opacity-90');
                $('#bmrBprReviewerComments').val(request.review_comments || '').prop('readonly', true);
                $('#bmrBprReviewModalLabel').text('BMR / BPR Issuance Record Details');
                $('#bmrBprReviewSubmitBtn').hide();
                $('#discardBmrBprReview').text('Close');
            } else {
                $('input[name="bmrBprDecision"]').prop('checked', false).prop('disabled', false);
                $('.bmr-bpr-decision-card').removeClass('pointer-events-none opacity-90');
                $('#bmrBprReviewerComments').val('').prop('readonly', false);
                $('#bmrBprReviewModalLabel').text('BMR / BPR Review');
                $('#bmrBprReviewSubmitBtn').show();
                $('#discardBmrBprReview').text('Discard Review');
            }

            updateBmrBprDecisionCards();
            const isIssuanceOpen = $('#bmrBprIssuanceRequestsModal').hasClass('show');
            $('#bmrBprReviewModal').data('opened-from-issuance', isIssuanceOpen);
            
            if (isIssuanceOpen) {
                $('#bmrBprIssuanceRequestsModal').modal('hide');
                setTimeout(function() {
                    $('#bmrBprReviewModal').modal('show');
                }, 300);
            } else {
                $('#bmrBprReviewModal').modal('show');
            }
        }

        function exportIssuanceRecords() {
            const rows = filteredIssuanceRecords();
            if (rows.length === 0) {
                notifyIssuanceUiOnly();
                return null;
            }

            const selectedCols = [];
            $('#exportModal input[name="listOfColumns[]"]:checked').each(function () {
                selectedCols.push($(this).val());
            });
            const effectiveCols = selectedCols.length > 0 ? selectedCols : [
                'S.No', 'Product Name', 'Lot Number', 'Status'
            ];

            const columnGetters = {
                'S.No': (record, index) => record.serial_number || (index + 1),
                'Product Name': (record) => record.product_name || '',
                'Lot Number': (record) => record.lot_number || '',
                'Status': (record) => record.status || ''
            };

            const headerRow = effectiveCols;
            const dataRows = rows.map(function (record, index) {
                return effectiveCols.map(function (col) {
                    const getter = columnGetters[col];
                    return getter ? getter(record, index) : (record[col] || '');
                });
            });

            const csvRows = [headerRow, ...dataRows];
            const csv = csvRows.map(function (row) {
                return row.map(function (value) {
                    return `"${String(value).replace(/"/g, '""')}"`;
                }).join(',');
            }).join('\r\n');
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            return URL.createObjectURL(blob);
        }

        function refreshBmrBprIssuance() {
            if (!document.hidden) {
                loadBmrBprIssuance(false, true);
            }
        }

        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) refreshBmrBprIssuance();
        });

        $(document).ready(function () {
            loadBmrBprIssuance();
        });

        $(document).on('input search', '#bmrBprIssuanceSearch', function () {
            currentPage = 1;
            renderIssuanceRecords();
        });

        $(document).on('click', '.bmr-bpr-issuance-per-page', function () {
            const value = String($(this).data('val'));
            $('#bmrBprIssuancePerPage').val(value);
            $('#bmrBprIssuancePerPageText').text(value === '100000000' ? 'All' : value);
            currentPage = 1;
            renderIssuanceRecords();
        });

        $(document).on('click', '.bmr-bpr-issuance-sortable', function () {
            const column = String($(this).data('column') || '');
            if (!column) return;
            if (sortColumn === column) {
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                sortColumn = column;
                sortDirection = 'asc';
            }
            renderIssuanceRecords();
        });

        $(document).on('click', '#bmrBprIssuancePrevious', function () {
            if (currentPage > 1) {
                currentPage--;
                renderIssuanceRecords();
            }
        });

        $(document).on('click', '#bmrBprIssuanceNext', function () {
            currentPage++;
            renderIssuanceRecords();
        });

        $(document).on('click keydown', '#bmrBprIssuanceWidget', function (event) {
            if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
            if (event.type === 'keydown') event.preventDefault();
            currentIssuanceRequestPage = 1;
            renderIssuanceFormRequests();
            $('#bmrBprIssuanceRequestsModal').modal('show');
        });

        $(document).on('click', '#bmrBprIssuanceRequestsPrev', function () {
            if (currentIssuanceRequestPage > 1) {
                currentIssuanceRequestPage--;
                renderIssuanceFormRequests();
            }
        });

        $(document).on('click', '#bmrBprIssuanceRequestsNext', function () {
            currentIssuanceRequestPage++;
            renderIssuanceFormRequests();
        });

        $(document).on('click', '.bmr-bpr-view-issuance-request', function (event) {
            event.preventDefault();
            event.stopPropagation();
            openBmrBprReviewModal(this);
        });

        $(document).on('click', '.bmr-bpr-view-record-btn', function (event) {
            event.preventDefault();
            event.stopPropagation();
            openBmrBprReviewModal(this, true);
        });

        $(document).on('change', 'input[name="bmrBprDecision"]', updateBmrBprDecisionCards);

        $(document).on('shown.bs.modal', '#bmrBprReviewModal', function () {
            $('.modal-backdrop').last().addClass('bmr-bpr-review-backdrop');
        });

        $(document).on('hidden.bs.modal', '#bmrBprReviewModal', function () {
            $('.modal-backdrop.bmr-bpr-review-backdrop').removeClass('bmr-bpr-review-backdrop');
            if ($('#bmrBprReviewModal').data('opened-from-issuance')) {
                setTimeout(function() {
                    $('#bmrBprIssuanceRequestsModal').modal('show');
                }, 300);
            }
        });

        $(document).on('submit', '#bmrBprReviewForm', function (event) {
            event.preventDefault();
            const selectedDecision = $('input[name="bmrBprDecision"]:checked').val();
            if (!selectedDecision) {
                const message = 'Select Approve or Reject before submitting the review.';
                if (window.toastr && typeof window.toastr.warning === 'function') {
                    window.toastr.warning(message);
                }
                return;
            }

            const formData = new FormData();
            formData.append('reviewBmrBprIssuance', 'reviewBmrBprIssuance');
            formData.append('csrf_token', bmrBprIssuanceCsrf);
            formData.append('request_id', $('#bmrBprReviewId').val());
            formData.append('decision', selectedDecision);
            formData.append('comments', $('#bmrBprReviewerComments').val());

            const $submitButton = $(this).find('button[type="submit"]');
            const originalHtml = $submitButton.html();
            $submitButton.prop('disabled', true)
                .html('<i class="ti ti-loader-2 animate-spin text-base"></i> Submitting...');

            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $('#bmrBprReviewModal').modal('hide');
                        toastr.success(response.message);
                        loadBmrBprIssuance();
                    } else {
                        toastr.error(response.message || 'Unable to save the issuance decision.');
                    }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred.');
                },
                complete: function () {
                    $submitButton.prop('disabled', false).html(originalHtml);
                }
            });
        });

        $('#bmrBprIssuanceExportForm').on('submit', function (e) {
            e.preventDefault();
            const $submitBtn = $('#exportModalSubmitBtn');
            const originalHtml = $submitBtn.html();
            $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i>');
            
            setTimeout(function() {
                const url = exportIssuanceRecords();
                if (url) {
                    $('#downloadExortfile')
                        .attr('href', url)
                        .attr('download', 'bmr-bpr-issuance-records.csv')
                        .removeClass('hidden d-none')
                        .attr('style', 'display: inline-flex !important;');
                    toastr.success('File exported successfully.');
                    $submitBtn.hide();
                }
                $submitBtn.prop('disabled', false).html(originalHtml);
            }, 300);
        });

        $('#exportModal').on('hidden.bs.modal', function () {
            $('#downloadExortfile').addClass('hidden d-none').attr('style', 'display: none !important;');
            $('#exportModalSubmitBtn').show();
        });
    })();
</script>
<?php endSection(); ?>
