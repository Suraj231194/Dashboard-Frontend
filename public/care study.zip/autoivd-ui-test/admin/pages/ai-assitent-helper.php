<div class="container-xxl flex-grow-1 container-p-y d-none">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <!-- <div class="faq-header-wrapper">
        <div class="faq-header d-flex flex-column justify-content-center align-items-center rounded h-px-300 position-relative">
            <img src="<?= asset('assets/img/pages/header.png') ?>" class="scaleX-n1-rtl faq-banner-img faq-hide-on-search" alt="background image" />
            <h3 class="text-center mb-1 faq-hide-on-search">
                Hello, how can we help?
            </h3>
            <div class="chat-preview "></div>
            <form id="chatSearchForm" class="w-100 d-flex justify-content-center">
                <div class="input-wrapper mb-3 input-group input-group-lg input-group-merge chat-search-box">
                    <input type="text" name="question" id="chatSearch" class="form-control" placeholder="Ask anything..." autocomplete="off" />
                    <span class="input-group-text mic-btn cursor-pointer"><i class="ti ti-microphone"></i></span>
                    <span class="input-group-text send-btn cursor-pointer"><i class="ti ti-send"></i></span>
                </div>
            </form>
            <p class="text-center mb-0 px-3 faq-hide-on-search">
                or choose a category to quickly find the help you need
            </p>
        </div>
    </div> -->
</div>


<div class="container-xxl flex-grow-1 container-p-y">
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--ui-text, #1a1e1a); letter-spacing: -0.025em; line-height: 2rem; margin-bottom: 0; font-family: 'Sora', 'Manrope', sans-serif;"><?= $pageTitle ?></h1>
        </div>
    </div>
    <div class="app-chat card overflow-hidden">
        <div class="row g-0">
            <div class="col app-chat-contacts app-sidebar flex-grow-0 overflow-hidden border-end" id="app-chat-contacts">
                <div class="sidebar-header">                    
                    <i class="ti ti-x cursor-pointer d-lg-none d-block position-absolute mt-2 me-1 top-0 end-0" data-overlay data-bs-toggle="sidebar" data-target="#app-chat-contacts"></i>
                </div>
                <div class="sidebar-body">                    
                    <ul class="list-unstyled chat-contact-list mb-0" id="contact-list">
                        <li class="chat-contact-list-item chat-contact-list-item-title">
                            <h5 class="text-primary mb-0">Contacts</h5>
                        </li>
                        <li class="chat-contact-list-item contact-list-item-0 d-none">
                            <h6 class="text-muted mb-0">No Contacts Found</h6>
                        </li>
                        <li class="chat-contact-list-item">
                            <a class="d-flex align-items-center">
                                <div class="flex-shrink-0 avatar avatar-offline">
                                    <img src="<?= asset('assets/img/avatars/4.png') ?>" alt="Avatar" class="rounded-circle" />
                                </div>
                                <div class="chat-contact-info flex-grow-1 ms-2">
                                    <h6 class="chat-contact-name text-truncate m-0">Natalie Maxwell</h6>
                                    <p class="chat-contact-status text-muted text-truncate mb-0">UI/UX Designer</p>
                                </div>
                            </a>
                        </li>
                        <li class="chat-contact-list-item">
                            <a class="d-flex align-items-center">
                                <div class="flex-shrink-0 avatar avatar-busy">
                                    <img src="<?= asset('assets/img/avatars/5.png') ?>" alt="Avatar" class="rounded-circle" />
                                </div>
                                <div class="chat-contact-info flex-grow-1 ms-2">
                                    <h6 class="chat-contact-name text-truncate m-0">Jess Cook</h6>
                                    <p class="chat-contact-status text-muted text-truncate mb-0">Business Analyst</p>
                                </div>
                            </a>
                        </li>
                        <li class="chat-contact-list-item">
                            <a class="d-flex align-items-center">
                                <div class="avatar d-block flex-shrink-0">
                                    <span class="avatar-initial rounded-circle bg-label-primary">LM</span>
                                </div>
                                <div class="chat-contact-info flex-grow-1 ms-2">
                                    <h6 class="chat-contact-name text-truncate m-0">Louie Mason</h6>
                                    <p class="chat-contact-status text-muted text-truncate mb-0">Resource Manager</p>
                                </div>
                            </a>
                        </li>
                        <li class="chat-contact-list-item">
                            <a class="d-flex align-items-center">
                                <div class="flex-shrink-0 avatar avatar-busy">
                                    <img src="<?= asset('assets/img/avatars/7.png') ?>" alt="Avatar" class="rounded-circle" />
                                </div>
                                <div class="chat-contact-info flex-grow-1 ms-2">
                                    <h6 class="chat-contact-name text-truncate m-0">Krystal Norton</h6>
                                    <p class="chat-contact-status text-muted text-truncate mb-0">Business Executive</p>
                                </div>
                            </a>
                        </li>
                       
                    </ul>
                </div>
            </div>
            <!-- /Chat contacts -->

            <!-- Chat History -->
            <div class="col app-chat-history bg-body">
                <div class="chat-history-wrapper">
                    <div class="chat-history-header border-bottom">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex overflow-hidden align-items-center">
                                <i class="ti ti-menu-2 ti-sm cursor-pointer d-lg-none d-block me-2" data-bs-toggle="sidebar" data-overlay data-target="#app-chat-contacts"></i>                                
                            </div>                            
                        </div>
                    </div>
                    <div class="chat-history-body bg-body">
                        <ul class="list-unstyled chat-history">
                            <li class="chat-message chat-message-right">
                                <div class="d-flex overflow-hidden">
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0">How can we help? We're here for you! 😄</p>
                                        </div>
                                        <div class="text-end text-muted mt-1">
                                            <i class="ti ti-checks ti-xs me-1 text-success"></i>
                                            <small>10:00 AM</small>
                                        </div>
                                    </div>
                                    <div class="user-avatar flex-shrink-0 ms-3">
                                        <div class="avatar avatar-sm">
                                            <img src="../../assets/img/avatars/1.png" alt="Avatar" class="rounded-circle" />
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="chat-message">
                                <div class="d-flex overflow-hidden">
                                    <div class="user-avatar flex-shrink-0 me-3">
                                        <div class="avatar avatar-sm">
                                            <img src="../../assets/img/avatars/2.png" alt="Avatar" class="rounded-circle" />
                                        </div>
                                    </div>
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0">Hey John, I am looking for the best admin template.</p>
                                            <p class="mb-0">Could you please help me to find it out? 🤔</p>
                                        </div>
                                        <div class="chat-message-text mt-2">
                                            <p class="mb-0">It should be Bootstrap 5 compatible.</p>
                                        </div>
                                        <div class="text-muted mt-1">
                                            <small>10:02 AM</small>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="chat-message chat-message-right">
                                <div class="d-flex overflow-hidden">
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0">Vuexy has all the components you'll ever need in a app.</p>
                                        </div>
                                        <div class="text-end text-muted mt-1">
                                            <i class="ti ti-checks ti-xs me-1 text-success"></i>
                                            <small>10:03 AM</small>
                                        </div>
                                    </div>
                                    <div class="user-avatar flex-shrink-0 ms-3">
                                        <div class="avatar avatar-sm">
                                            <img src="../../assets/img/avatars/1.png" alt="Avatar" class="rounded-circle" />
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="chat-message chat-message-right">
                                <div class="d-flex overflow-hidden">
                                    <div class="chat-message-wrapper flex-grow-1 w-50">
                                        <div class="chat-message-text">
                                            <p class="mb-0">
                                                Yes that's correct documentation file, Design files are included with the template.
                                            </p>
                                        </div>
                                        <div class="text-end text-muted mt-1">
                                            <i class="ti ti-checks ti-xs me-1"></i>
                                            <small>10:15 AM</small>
                                        </div>
                                    </div>
                                    <div class="user-avatar flex-shrink-0 ms-3">
                                        <div class="avatar avatar-sm">
                                            <img src="../../assets/img/avatars/1.png" alt="Avatar" class="rounded-circle" />
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        <div class="chat-preview "></div>
                    </div>
                    <!-- Chat message form -->
                    <div class="chat-history-footer shadow-sm">
                        <form class="form-send-message d-flex justify-content-between align-items-center d-none">
                            <input
                                class="form-control message-input border-0 me-3 shadow-none"
                                placeholder="Type your message here" />
                                
                            <div class="message-actions d-flex align-items-center">
                                <i class="speech-to-text ti ti-microphone ti-sm cursor-pointer"></i>
                                <label for="attach-doc" class="form-label mb-0">
                                    <i class="ti ti-photo ti-sm cursor-pointer mx-3"></i>
                                    <input type="file" id="attach-doc" hidden />
                                </label>
                                <button class="btn btn-primary d-flex send-msg-btn">
                                    <i class="ti ti-send me-md-1 me-0"></i>
                                    <span class="align-middle d-md-inline-block d-none">Send</span>
                                </button>
                            </div>
                        </form>                         
                         <form id="chatSearchForm" class="form-send-message d-flex justify-content-between align-items-center w-100 d-flex">
                            <div class="input-wrapper mb-3 input-group input-group-lg input-group-merge chat-search-box d-flex align-items-center">
                                <textarea  name="question" rows="1" id="chatSearch" class="form-control message-input border-0 me-1 shadow-none" placeholder="Ask anything..." autocomplete="off"></textarea>
                                <input type="text" name="question" id="chatSearch1" class="d-none form-control message-input border-0 me-1 shadow-none" placeholder="Ask anything..." autocomplete="off" />
                                <span class="input-group-text mic-btn cursor-pointer"><i class="ti ti-microphone"></i></span>
                                <span class="input-group-text send-btn cursor-pointer"><i class="ti ti-send"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /Chat History -->
            <div class="app-overlay"></div>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>

<script src="<?= asset('assets/js/app-chat.js') ?>"></script>

<script>
    let chatRequest = null;
    let isProcessing = false;
    let currentConversationId = 0;
    $(document).ready(function() {

        let recognition;
        let isListening = false;

        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {

            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();

            // recognition.lang = 'hi-IN'; // ya 'en-IN'
            recognition.lang = 'en-IN'; // ya 'en-IN'
            recognition.interimResults = true; // 🔥 live text
            recognition.continuous = false;

            recognition.onstart = function() {
                isListening = true;
                $('.mic-btn').addClass('listening');
                $('#chatSearch').attr('placeholder', 'Listening...');
            };

            recognition.onend = function() {
                isListening = false;
                $('.mic-btn').removeClass('listening');
                $('#chatSearch').attr('placeholder', 'Ask anything...');
            };

            recognition.onresult = function(event) {
                let transcript = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    transcript += event.results[i][0].transcript;
                }

                // ✅ Sirf textbox me dikhana
                $('#chatSearch').val(transcript);
            };

        } else {
            $('.mic-btn').hide();
        }

        $('.mic-btn').on('click', function() {
            if (!recognition) return;

            if (isListening) {
                recognition.stop();
            } else {
                recognition.start();
            }
        });

        function sendMessage() {

            if (isProcessing) return; 

            let text = $('#chatSearch').val().trim();
            if (text === '') return;

            isProcessing = true;

            $('.faq-header-wrapper').addClass('chat-mode');

            $('.send-btn i')
                .removeClass('ti-send')
                .addClass('ti-loader ti-spin');

            $('.send-btn').css('pointer-events', 'none');

            $('.chat-preview').append(`
                    <div class="user-msg">${text}</div>
                `);

            $('#chatSearch').val('');

            $('.chat-preview').scrollTop($('.chat-preview')[0].scrollHeight);

            chatRequest = $.ajax({
                url: 'curlajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    chatGptInputValData: 'chatGptInputValData',
                    conversation_id: currentConversationId,
                    question: text
                },
                success: function(res) {

                    if (res.status === 'success') {
                        $('.chat-preview').append(`
                                <div class="bot-msg">${res.answer}</div>
                            `);
                    } else {
                        $('.chat-preview').append(`
                                <div class="bot-msg text-warning">
                                    ⚠️ Search request ruk gayi hai
                                </div>
                            `);
                    }
                    currentConversationId = res.conversation_id;
                },
                error: function() {
                    $('.chat-preview').append(`
                            <div class="bot-msg text-warning">
                                ⚠️ Search request ruk gayi hai
                            </div>
                        `);
                },
                complete: function() {
                    isProcessing = false;
                    chatRequest = null;

                    $('.send-btn i')
                        .removeClass('ti-loader ti-spin')
                        .addClass('ti-send');

                    $('.send-btn').css('pointer-events', 'auto');

                    $('.chat-preview').scrollTop($('.chat-preview')[0].scrollHeight);
                }
            });
        }

        function stopChatRequest() {
            if (chatRequest) {
                chatRequest.abort();
                isProcessing = false;

                $('.send-btn i')
                    .removeClass('ti-loader ti-spin')
                    .addClass('ti-send');

                $('.send-btn').css('pointer-events', 'auto');

                $('.chat-preview').append(`
                        <div class="bot-msg text-warning">
                            ⛔ Search manually stopped
                        </div>
                    `);
            }
        }



        $('#chatSearchForm').on('submit', function(e) {
            e.preventDefault();
            sendMessage();
        });

        $('.send-btn').on('click', function() {
            sendMessage();
        });

    });
</script>



<?php endSection(); ?>
