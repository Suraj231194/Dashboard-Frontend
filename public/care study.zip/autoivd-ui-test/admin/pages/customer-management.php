<?php
/**
 * Customer Management Page (ERP)
 * Matches MANUVERSE v7 document images 7 & 8.
 *
 * Location: admin/pages/customer-management.php
 */
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$customerCsrfToken = htmlspecialchars((string) $_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
?>
<style>
    .customer-page { color: var(--ui-text, #24352d); }
    .customer-page .customer-kpi { min-height: 68px; border: 1px solid var(--color-primary-100, #dfe9e3); border-radius: 12px; padding: 10px 12px; box-shadow: 0 4px 16px rgba(0, 0, 0, .06); }
    .customer-page .customer-kpi__icon { display: inline-flex; width: 28px; height: 28px; align-items: center; justify-content: center; border-radius: 7px; background: rgba(255,255,255,.22); font-size: 15px; }
    .customer-page .customer-kpi__label { margin-top: 8px; font-size: 9px; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; }
    .customer-page .customer-kpi__value { margin-top: 2px; font-size: 20px; line-height: 1; font-weight: 900; }
    .customer-page .customer-panel { overflow: hidden; border: 1px solid #e1e9e4; border-radius: 14px; background: #fff; box-shadow: 0 5px 20px rgba(0, 0, 0, .06); }
    .customer-page .customer-toolbar { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; padding: 14px 16px; border-bottom: 1px solid #edf2ef; }
    .customer-page .customer-control { height: 38px; border: 1px solid #dce6e0; border-radius: 8px; background: #fff; color: #43534b; font-size: 12px; font-weight: 600; outline: none; }
    .customer-page .customer-control:focus { border-color: var(--appearance-accent, #166534); box-shadow: 0 0 0 3px color-mix(in srgb, var(--appearance-accent, #166534) 12%, transparent); }
    .customer-page .customer-table { width: 100%; border-collapse: collapse; min-width: 1060px; }
    .customer-page .customer-table th { padding: 11px 13px; border-bottom: 1px solid #e6eee9; background: #f8fbf9; color: #738078; font-size: 9px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; white-space: nowrap; }
    .customer-page .customer-table td { padding: 11px 13px; border-bottom: 1px solid #edf2ef; color: #3d4d45; font-size: 12px; vertical-align: middle; }
    .customer-page .customer-table tbody tr:hover { background: #fbfdfc; }
    .customer-page .customer-pill { display: inline-flex; align-items: center; border-radius: 999px; padding: 3px 8px; font-size: 9px; font-weight: 900; letter-spacing: .04em; text-transform: uppercase; }
    .customer-page .customer-footer { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; padding: 13px 16px; color: #6c7a72; font-size: 12px; }
    .customer-page .customer-page-btn { display: inline-flex; min-width: 32px; height: 32px; align-items: center; justify-content: center; border: 1px solid #dce6e0; border-radius: 7px; background: #fff; color: #52625a; font-size: 11px; font-weight: 800; }
    .customer-page .customer-page-btn.is-active { border-color: var(--appearance-accent, #166534); background: var(--appearance-accent, #166534); color: #fff; }
    .customer-page .customer-page-btn:disabled { cursor: not-allowed; opacity: .45; }
    .customer-profile-modal .modal-dialog { max-width: 1040px; }
    .customer-profile-modal .modal-content { overflow: visible; border: 1px solid #dfe9e3; border-radius: 18px; background: #f8fbf9; box-shadow: 0 24px 70px rgba(0, 0, 0, .18); }
    .customer-profile-modal .modal-body.customer-modal-body { max-height: 70vh; overflow-y: auto; }
    .customer-profile-modal .customer-modal-header { display: flex; align-items: center; justify-content: space-between; gap: 20px; padding: 17px 20px; border-bottom: 1px solid #e2ebe5; background: #fff; }
    .customer-profile-modal .customer-modal-heading { display: flex; min-width: 0; align-items: center; gap: 12px; }
    .customer-profile-modal .customer-modal-icon { display: inline-flex; width: 38px; height: 38px; flex: 0 0 auto; align-items: center; justify-content: center; border-radius: 10px; background: var(--color-primary-50, #e9f7ee); color: var(--appearance-accent, #166534); font-size: 19px; }
    .customer-profile-modal .customer-modal-title { margin: 0; color: #21372b; font-size: 16px; font-weight: 900; }
    .customer-profile-modal .customer-modal-subtitle { margin: 2px 0 0; color: #829087; font-size: 10px; font-weight: 600; }
    .customer-profile-modal .customer-modal-actions { display: flex; flex: 0 0 auto; align-items: center; gap: 8px; }
    .customer-profile-modal .customer-modal-btn { display: inline-flex; height: 36px; align-items: center; justify-content: center; gap: 7px; border-radius: 8px; padding: 0 13px; font-size: 10px; font-weight: 900; }
    .customer-profile-modal .customer-modal-body { padding: 16px; }
    .customer-profile-modal .customer-form-grid { display: grid; grid-template-columns: minmax(0, 1.3fr) minmax(300px, .7fr); gap: 13px; }
    .customer-profile-modal .customer-form-card { border: 1px solid #e0e9e3; border-radius: 12px; background: #fff; box-shadow: 0 3px 12px rgba(0, 0, 0, .04); }
    .customer-profile-modal .customer-form-card__head { display: flex; align-items: center; gap: 8px; padding: 12px 14px 0; color: #32483b; font-size: 11px; font-weight: 900; }
    .customer-profile-modal .customer-form-card__head i { color: var(--appearance-accent, #16824a); font-size: 16px; }
    .customer-profile-modal .customer-form-card__body { padding: 12px 14px 14px; }
    .customer-profile-modal .customer-field-label { display: block; margin-bottom: 5px; color: #4e6156; font-size: 9px; font-weight: 900; }
    .customer-profile-modal .customer-field-label .required { color: #e11d48; }
    .customer-profile-modal .customer-field { min-height: 39px; border-color: #dfe8e2; border-radius: 8px; color: #31443a; font-size: 11px; font-weight: 600; }
    .customer-profile-modal .customer-field:focus { border-color: var(--appearance-accent, #16824a); box-shadow: 0 0 0 3px color-mix(in srgb, var(--appearance-accent, #16824a) 12%, transparent); }
    .customer-profile-modal .customer-field[readonly] { background: #f5f8f6; color: #6f7e75; }
    .customer-profile-modal .customer-phone-group { display: grid; grid-template-columns: 82px 1fr; }
    .customer-profile-modal .customer-phone-group .form-select { border-radius: 8px 0 0 8px; }
    .customer-profile-modal .customer-phone-group .form-control { border-left: 0; border-radius: 0 8px 8px 0; }
    .customer-profile-modal .gst-status { display: flex; min-height: 47px; align-items: center; gap: 10px; margin-top: 10px; border: 1px solid #dbe9e0; border-radius: 9px; padding: 9px 11px; background: #f6faf7; color: #66776d; font-size: 9px; font-weight: 800; }
    .customer-profile-modal .gst-status i { font-size: 17px; }
    .customer-profile-modal .gst-status.is-valid { border-color: #c7ead3; background: #eefaf2; color: var(--appearance-accent, #167043); }
    .customer-profile-modal .gst-status.is-invalid { border-color: #fecdd3; background: #fff4f5; color: #be123c; }
    .customer-profile-modal .customer-location-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .customer-profile-modal .customer-address-row { display: grid; grid-template-columns: minmax(0, 1fr) 150px; gap: 10px; margin-top: 10px; }
    .customer-profile-modal .customer-address { min-height: 88px; resize: vertical; }
    .customer-profile-modal .customer-map-preview { position: relative; display: flex; min-height: 88px; flex-direction: column; align-items: center; justify-content: center; overflow: hidden; border: 1px solid #dfe8e2; border-radius: 9px; background-color: var(--color-primary-50, #f2f7f3); background-size: 32px 54px; color: var(--appearance-accent, #166534); text-align: center; }
    .customer-profile-modal .customer-map-preview i { font-size: 30px; }
    .customer-profile-modal .customer-map-label { max-width: 130px; margin-top: 3px; color: #697a70; font-size: 8px; font-weight: 800; line-height: 1.3; }
    .customer-profile-modal .customer-type-stack { display: grid; gap: 9px; }
    .customer-profile-modal .customer-type-option { position: relative; display: block; cursor: pointer; }
    .customer-profile-modal .customer-type-option input { position: absolute; opacity: 0; pointer-events: none; }
    .customer-profile-modal .customer-type-card { display: flex; min-height: 66px; align-items: flex-start; gap: 10px; border: 1px solid #dfe8e2; border-radius: 10px; padding: 11px; background: #fff; transition: .15s ease; }
    .customer-profile-modal .customer-type-card__dot { display: inline-flex; width: 22px; height: 22px; flex: 0 0 auto; align-items: center; justify-content: center; border-radius: 999px; background: #f1f5f2; color: #789087; font-size: 12px; }
    .customer-profile-modal .customer-type-card strong { display: block; color: #31443a; font-size: 10px; font-weight: 900; }
    .customer-profile-modal .customer-type-card small { display: block; margin-top: 3px; color: #849188; font-size: 8px; font-weight: 600; line-height: 1.35; }
    .customer-profile-modal .customer-type-option input:checked + .customer-type-card { border-color: var(--appearance-accent, #16824a); background: var(--color-primary-50, #f4fbf6); box-shadow: inset 0 0 0 1px var(--appearance-accent, #16824a); }
    .customer-profile-modal .customer-type-option input:checked + .customer-type-card .customer-type-card__dot { background: var(--color-primary-100, #dff5e7); color: var(--appearance-accent, #167043); }
    .customer-profile-modal .customer-account-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; margin-top: 12px; }
    .customer-profile-modal .customer-safe-note { display: flex; align-items: center; justify-content: space-between; gap: 15px; margin-top: 13px; border: 1px solid var(--color-primary-100, #d9eee0); border-radius: 10px; padding: 10px 13px; background: var(--color-primary-50, #f1fbf4); color: #557064; font-size: 9px; font-weight: 700; }
    .customer-profile-modal .customer-safe-note i { color: var(--appearance-accent, #16824a); font-size: 17px; }
    .customer-profile-modal .customer-safe-badge { flex: 0 0 auto; color: var(--appearance-accent, #167043); font-weight: 900; }
    @media (max-width: 767.98px) {
        .customer-profile-modal .customer-modal-header { align-items: flex-start; flex-direction: column; }
        .customer-profile-modal .customer-modal-actions { width: 100%; justify-content: flex-end; }
        .customer-profile-modal .customer-form-grid { grid-template-columns: 1fr; }
        .customer-profile-modal .customer-location-grid { grid-template-columns: 1fr; }
        .customer-profile-modal .customer-address-row { grid-template-columns: 1fr; }
    }
</style>

<div class="customer-page container-xxl flex-grow-1 container-p-y font-sans">
    <div class="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between ui-page-header-with-actions">
        <div class="ui-page-title-banner">
            <h1 class="m-0 text-2xl font-extrabold tracking-tight text-slate-800">Customer Management</h1>
            <p class="mb-0 mt-1 text-sm text-slate-500">Manage B2B and B2C customers synchronized from the Website or created in ERP.</p>
        </div>
        <div class="text-xs font-bold uppercase tracking-widest" style="color: var(--appearance-accent, #166534);"><i class="ti ti-shield-check mr-1"></i>Customer directory</div>
    </div>

    <div class="mb-5 grid grid-cols-2 gap-2 md:grid-cols-5">
        <div class="customer-kpi" style="background: var(--color-primary-900, #14532d); color: #fff;"><span class="customer-kpi__icon" style="color: #fff;"><i class="ti ti-users"></i></span><div class="customer-kpi__label" style="color: rgba(255,255,255,.85);">Total customers</div><div id="customerTotalCount" class="customer-kpi__value" style="color: #fff;">0</div></div>
        <div class="customer-kpi" style="background: var(--appearance-accent, #3b82f6); color: #fff;"><span class="customer-kpi__icon" style="color: #fff;"><i class="ti ti-world"></i></span><div class="customer-kpi__label" style="color: rgba(255,255,255,.85);">Website customers</div><div id="customerWebsiteCount" class="customer-kpi__value" style="color: #fff;">0</div></div>
        <div class="customer-kpi" style="background: var(--color-primary-50, #e0f2fe); color: var(--color-primary-900, #0c4a6e);"><span class="customer-kpi__icon" style="background: rgba(255,255,255,.6); color: var(--color-primary-700, #0369a1);"><i class="ti ti-building-store"></i></span><div class="customer-kpi__label">ERP customers</div><div id="customerErpCount" class="customer-kpi__value">0</div></div>
        <div class="customer-kpi" style="background: var(--color-primary-100, #dcfce7); color: var(--color-primary-900, #14532d);"><span class="customer-kpi__icon" style="background: rgba(255,255,255,.6); color: var(--color-primary-700, #15803d);"><i class="ti ti-building-community"></i></span><div class="customer-kpi__label">B2B customers</div><div id="customerB2bCount" class="customer-kpi__value">0</div></div>
        <div class="customer-kpi" style="background: var(--color-primary-200, #e2e8f0); color: var(--color-primary-900, #1e293b);"><span class="customer-kpi__icon" style="background: rgba(255,255,255,.6); color: var(--color-primary-700, #334155);"><i class="ti ti-user"></i></span><div class="customer-kpi__label">B2C customers</div><div id="customerB2cCount" class="customer-kpi__value">0</div></div>
    </div>

    <div class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50/70 px-6 py-3">
            <div class="flex flex-nowrap items-center gap-2 rounded-xl border border-slate-200 bg-white/90 p-2 shadow-sm issue3-customer-toolbar overflow-x-auto">
                <input type="hidden" id="customerPageSize" value="25">

                <!-- Per-page dropdown (Bootstrap dropdown matching production-plan style) -->
                <div class="dropdown shrink-0">
                    <button
                        class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        type="button" data-bs-toggle="dropdown">
                        <span id="custPerPageText" class="whitespace-nowrap">25 per page</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="cust-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="100000000">All items</a></li>
                        <li><a class="cust-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="10">10 per page</a></li>
                        <li><a class="cust-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="25">25 per page</a></li>
                        <li><a class="cust-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="50">50 per page</a></li>
                        <li><a class="cust-per-page-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="100">100 per page</a></li>
                    </ul>
                </div>

                <!-- Search input (matching production-plan style) -->
                <div class="relative h-10 min-w-[160px] max-w-[260px] flex-grow">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="ti ti-search text-lg text-slate-400"></i>
                    </div>
                    <input type="text" id="userSearchInput"
                        class="h-10 w-full !rounded-xl border border-slate-200 bg-white py-2 pl-10 pr-4 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-900/5 outline-none transition-colors placeholder:text-slate-400 hover:border-slate-300 hover:bg-slate-50 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                        placeholder="Search customer, email or company...">
                </div>

                <!-- Customer type dropdown (Bootstrap dropdown matching production-plan style) -->
                <input type="hidden" id="userTypeFilter" value="">
                <div class="dropdown shrink-0">
                    <button
                        class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        type="button" data-bs-toggle="dropdown">
                        <span id="custTypeText" class="whitespace-nowrap">All customer types</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="cust-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="">All customer types</a></li>
                        <li><a class="cust-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="b2b">B2B</a></li>
                        <li><a class="cust-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="b2c">B2C</a></li>
                    </ul>
                </div>

                <!-- Status dropdown (Bootstrap dropdown matching production-plan style) -->
                <input type="hidden" id="userStatusFilter" value="">
                <div class="dropdown shrink-0">
                    <button
                        class="flex h-10 w-auto items-center justify-between gap-2 !rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm ring-1 ring-slate-900/5 transition-colors hover:border-slate-300 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        type="button" data-bs-toggle="dropdown">
                        <span id="custStatusText" class="whitespace-nowrap">All statuses</span>
                        <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                    </button>
                    <ul class="dropdown-menu !rounded-xl border border-slate-200 p-1 shadow-xl">
                        <li><a class="cust-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="">All statuses</a></li>
                        <li><a class="cust-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="1">Active</a></li>
                        <li><a class="cust-status-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                                data-val="0">Inactive</a></li>
                    </ul>
                </div>

                <div class="ml-auto flex items-center gap-2 shrink-0">
                    <button type="button" id="exportCustomers" data-bs-toggle="modal" data-bs-target="#exportModal"
                        class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                    
                    <button type="button"
                        class="inline-flex h-10 w-12 shrink-0 items-center justify-center !rounded-xl text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        style="background: var(--appearance-accent, #166534);"
                        onclick="openNewCustomerModal()"
                        title="Add New Customer"
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        data-bs-original-title="Add New Customer">
                        <i class="ti ti-plus text-lg"></i>
                    </button>
                </div>
            </div>
        </div>

        <div class="w-full overflow-x-auto">
            <table class="w-full border-collapse text-left customer-table">
                <thead class="border-b border-slate-100 bg-white whitespace-nowrap"><tr><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Source</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Customer</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Phone</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Company / GSTIN</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Email</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Type</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Credit</th><th class="px-6 py-3 text-[11px] font-bold uppercase tracking-widest text-slate-400">Status</th><th class="px-6 py-3 text-right text-[11px] font-bold uppercase tracking-widest text-slate-400">Action</th></tr></thead>
                <tbody id="usersTableBody" class="bg-white divide-y divide-slate-100"><tr><td colspan="9" class="!py-10 text-center !text-slate-400">Loading customers...</td></tr></tbody>
            </table>
        </div>
        <div class="customer-footer border-t border-slate-200 bg-slate-50/50"><div id="customerShowingText" class="text-sm font-medium text-slate-500">Showing 0 customers</div><div id="customerPagination" class="flex items-center gap-1"></div></div>
    </div>
</div>

<!-- Add / Edit Customer Modal -->
<div class="modal fade customer-profile-modal" id="customerModal" tabindex="-1" aria-labelledby="customerModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
        <div class="modal-content">
            <div class="customer-modal-header">
                <div class="customer-modal-heading">
                    <span class="customer-modal-icon"><i class="ti ti-user-plus"></i></span>
                    <div>
                        <h5 class="customer-modal-title" id="customerModalTitle">Add New Customer</h5>
                        <p class="customer-modal-subtitle" id="customerModalSubtitle">Create a customer in ERP while preserving the configured sync direction.</p>
                    </div>
                </div>
                <div class="customer-modal-actions">
                    <button type="button" class="customer-modal-btn border border-slate-200 bg-white text-slate-600 hover:bg-slate-50" data-bs-dismiss="modal"><i class="ti ti-x"></i>Cancel</button>
                    <button type="submit" form="customerForm" id="customerSaveButton" class="customer-modal-btn border-0 text-white" style="background: var(--appearance-accent, #166534);"><i class="ti ti-device-floppy"></i><span id="customerSaveLabel">Create Customer</span></button>
                </div>
            </div>
            <form id="customerForm" onsubmit="saveCustomerForm(event)" novalidate>
                <div class="modal-body customer-modal-body">
                    <input type="hidden" id="customerId" name="id">
                    <input type="hidden" id="customerCsrfToken" name="csrf_token" value="<?= $customerCsrfToken ?>">
                    <input type="hidden" id="custSourceOrigin" name="source_origin" value="erp">

                    <div class="customer-form-grid">
                        <div class="d-grid gap-3">
                            <section class="customer-form-card">
                                <div class="customer-form-card__head"><i class="ti ti-user-circle"></i>Identity</div>
                                <div class="customer-form-card__body">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <label class="customer-field-label" for="custSourceDisplay">Source Origin</label>
                                            <input type="text" id="custSourceDisplay" class="form-control customer-field" value="ERP" readonly>
                                        </div>
                                        <div class="col-md-8">
                                            <label class="customer-field-label" for="custName">Full Name <span class="required">*</span></label>
                                            <input type="text" id="custName" name="name" class="form-control customer-field" required maxlength="255" placeholder="Enter legal entity or individual name">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="customer-field-label" for="custEmail">Email Address <span class="required">*</span></label>
                                            <input type="email" id="custEmail" name="email" class="form-control customer-field" required maxlength="255" placeholder="Enter email address">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="customer-field-label" for="custPhone">Contact Number <span class="required">*</span></label>
                                            <div class="customer-phone-group">
                                                <select id="custCountryCode" name="country_code" class="form-select customer-field" aria-label="Country code">
                                                    <option value="+91">+91</option>
                                                    <option value="+1">+1</option>
                                                    <option value="+44">+44</option>
                                                    <option value="+61">+61</option>
                                                    <option value="+971">+971</option>
                                                </select>
                                                <input type="tel" id="custPhone" name="phone" class="form-control customer-field" required maxlength="30" inputmode="tel" placeholder="Enter contact number">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <label class="customer-field-label" for="custCompanyName">Company / Organization <span id="companyRequiredMark" class="required d-none">*</span></label>
                                            <input type="text" id="custCompanyName" name="company_name" class="form-control customer-field" maxlength="255" placeholder="Company, lab, hospital or organization name">
                                        </div>
                                        <div class="col-12">
                                            <label class="customer-field-label" for="custContactPerson">Contact Person <span class="required">*</span></label>
                                            <input type="text" id="custContactPerson" name="contact_person" class="form-control customer-field" required maxlength="255" placeholder="Primary order contact">
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <section class="customer-form-card">
                                <div class="customer-form-card__head"><i class="ti ti-map-pin"></i>Location &amp; Contact</div>
                                <div class="customer-form-card__body">
                                    <div class="customer-location-grid">
                                        <div>
                                            <label class="customer-field-label" for="custStateProvince">State / Province <span class="required">*</span></label>
                                            <select id="custStateProvince" name="state_province" class="form-select customer-field" required>
                                                <option value="">Select state / province</option>
                                                <option>Andaman and Nicobar Islands</option><option>Andhra Pradesh</option><option>Arunachal Pradesh</option><option>Assam</option><option>Bihar</option><option>Chandigarh</option><option>Chhattisgarh</option><option>Dadra and Nagar Haveli and Daman and Diu</option><option>Delhi</option><option>Goa</option><option>Gujarat</option><option>Haryana</option><option>Himachal Pradesh</option><option>Jammu and Kashmir</option><option>Jharkhand</option><option>Karnataka</option><option>Kerala</option><option>Ladakh</option><option>Lakshadweep</option><option>Madhya Pradesh</option><option>Maharashtra</option><option>Manipur</option><option>Meghalaya</option><option>Mizoram</option><option>Nagaland</option><option>Odisha</option><option>Puducherry</option><option>Punjab</option><option>Rajasthan</option><option>Tamil Nadu</option><option>Telangana</option><option>Tripura</option><option>Uttar Pradesh</option><option>Uttarakhand</option><option>West Bengal</option><option>Other</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="customer-field-label" for="custCity">City <span class="required">*</span></label>
                                            <input type="text" id="custCity" name="city" class="form-control customer-field" required maxlength="100" placeholder="Enter city">
                                        </div>
                                        <div>
                                            <label class="customer-field-label" for="custPostalCode">Pincode / Postal Code <span class="required">*</span></label>
                                            <input type="text" id="custPostalCode" name="postal_code" class="form-control customer-field" required maxlength="20" inputmode="numeric" placeholder="Enter postal code">
                                        </div>
                                    </div>
                                    <div class="customer-address-row">
                                        <div>
                                            <label class="customer-field-label" for="custDetailedAddress">Detailed Address <span class="required">*</span></label>
                                            <textarea id="custDetailedAddress" name="detailed_address" class="form-control customer-field customer-address" required maxlength="1000" placeholder="Enter building name, street, landmark, district, etc."></textarea>
                                        </div>
                                        <div id="customerMapPreview" class="customer-map-preview" aria-label="Entered location preview">
                                            <i class="ti ti-map-pin-filled"></i>
                                            <span id="customerMapLabel" class="customer-map-label">Location preview</span>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>

                        <div class="d-grid gap-3 align-content-start">
                            <section class="customer-form-card">
                                <div class="customer-form-card__head"><i class="ti ti-shield-check"></i>Compliance</div>
                                <div class="customer-form-card__body">
                                    <div class="row g-2">
                                        <div class="col-12">
                                            <label class="customer-field-label" for="custGstin">GST Number <span class="required">*</span></label>
                                            <input type="text" id="custGstin" name="gstin" class="form-control customer-field text-uppercase" required maxlength="15" autocomplete="off" placeholder="e.g. 27AAAAA0000A1Z5">
                                        </div>
                                        <div class="col-12">
                                            <label class="customer-field-label" for="custPan">PAN <span class="required">*</span></label>
                                            <input type="text" id="custPan" name="pan" class="form-control customer-field text-uppercase" required maxlength="10" placeholder="AAAAA0000A">
                                        </div>
                                    </div>
                                    <div id="gstValidationStatus" class="gst-status" role="status" aria-live="polite">
                                        <i class="ti ti-shield-search"></i>
                                        <span>Optional. GSTIN format is checked while you type.</span>
                                    </div>
                                </div>
                            </section>

                            <section class="customer-form-card">
                                <div class="customer-form-card__head"><i class="ti ti-category"></i>Classification</div>
                                <div class="customer-form-card__body">
                                    <div class="customer-type-stack">
                                        <label class="customer-type-option">
                                            <input type="radio" name="user_type" value="b2b">
                                            <span class="customer-type-card"><span class="customer-type-card__dot"><i class="ti ti-building-community"></i></span><span><strong>B2B - Business</strong><small>Wholesale and institutional customer mapping.</small></span></span>
                                        </label>
                                        <label class="customer-type-option">
                                            <input type="radio" name="user_type" value="b2c" checked>
                                            <span class="customer-type-card"><span class="customer-type-card__dot"><i class="ti ti-user"></i></span><span><strong>B2C - Direct</strong><small>Retail and individual customer processing.</small></span></span>
                                        </label>
                                    </div>
                                    <div class="customer-account-grid">
                                        <div>
                                            <label class="customer-field-label" for="custCreditLimit">Credit Limit (INR)</label>
                                            <input type="number" min="0" step="0.01" id="custCreditLimit" name="credit_limit" class="form-control customer-field" value="0">
                                        </div>
                                        <div>
                                            <label class="customer-field-label" for="custCreditDays">Credit Days</label>
                                            <input type="number" min="0" max="3650" id="custCreditDays" name="credit_days" class="form-control customer-field" value="0">
                                        </div>
                                        <div>
                                            <label class="customer-field-label" for="custPaymentTermsStatus">Payment Terms / Status <span class="required">*</span></label>
                                            <select id="custPaymentTermsStatus" name="payment_terms_status" class="form-select customer-field" required>
                                                <?php foreach (Constant::ORDER_RECEIVED['PAYMENT_STATUS_TERM'] as $paymentKey => $paymentLabel): ?>
                                                    <option value="<?= (int) $paymentKey ?>"><?= htmlspecialchars($paymentLabel) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="customer-field-label" for="custPaymentTermsText">Payment Details</label>
                                            <input type="text" id="custPaymentTermsText" name="payment_terms_text" class="form-control customer-field" maxlength="500" placeholder="e.g. Net 30 days">
                                        </div>
                                        <div class="col-span-2" style="grid-column: 1 / -1;">
                                            <label class="customer-field-label" for="custStatus">Customer Status</label>
                                            <select id="custStatus" name="status" class="form-select customer-field"><option value="1">Active</option><option value="0">Inactive</option></select>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>

                    <div class="customer-safe-note">
                        <span class="d-flex align-items-center gap-2"><i class="ti ti-sparkles"></i><span><strong>Work with confidence</strong><br>Required fields and GSTIN format are validated before the ERP record is saved.</span></span>
                        <span class="customer-safe-badge"><i class="ti ti-lock-check me-1"></i>ERP secured</span>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php startSection('scripts'); ?>
<script>
let customerRows = [];
let customerFilteredRows = [];
let customerCurrentPage = 1;

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('userSearchInput').addEventListener('input', resetCustomerPageAndRender);

    // Per-page dropdown items (Bootstrap dropdown → hidden input)
    document.querySelectorAll('.cust-per-page-item').forEach(function(item) {
        item.addEventListener('click', function() {
            var val = this.dataset.val;
            document.getElementById('customerPageSize').value = val;
            document.getElementById('custPerPageText').textContent = Number(val) >= 100000000 ? 'All items' : val + ' per page';
            resetCustomerPageAndRender();
        });
    });

    // Customer type dropdown items (Bootstrap dropdown → hidden input)
    document.querySelectorAll('.cust-type-item').forEach(function(item) {
        item.addEventListener('click', function() {
            document.getElementById('userTypeFilter').value = this.dataset.val;
            document.getElementById('custTypeText').textContent = this.textContent;
            resetCustomerPageAndRender();
        });
    });

    // Status dropdown items (Bootstrap dropdown → hidden input)
    document.querySelectorAll('.cust-status-item').forEach(function(item) {
        item.addEventListener('click', function() {
            document.getElementById('userStatusFilter').value = this.dataset.val;
            document.getElementById('custStatusText').textContent = this.textContent;
            resetCustomerPageAndRender();
        });
    });

    document.getElementById('custGstin').addEventListener('input', validateCustomerGstin);
    document.getElementById('custStateProvince').addEventListener('change', updateCustomerLocationPreview);
    document.getElementById('custCity').addEventListener('input', updateCustomerLocationPreview);
    document.getElementById('custPostalCode').addEventListener('input', updateCustomerLocationPreview);
    document.querySelectorAll('input[name="user_type"]').forEach(function(input) {
        input.addEventListener('change', syncCustomerClassification);
    });
    document.getElementById('customerPagination').addEventListener('click', function(event) {
        const button = event.target.closest('[data-customer-page]');
        if (!button || button.disabled) return;
        customerCurrentPage = Number(button.dataset.customerPage);
        renderCustomerView();
    });
    loadUsersGrid();
});

function loadUsersGrid() {
    $('#usersTableBody').html('<tr><td colspan="9" class="!py-10 text-center !text-slate-400">Loading customers...</td></tr>');
    $.ajax({
        url: 'ajax.php?action=loadCustomersGrid',
        type: 'GET',
        dataType: 'json',
        success: function(res) {
            customerRows = res.status === 'success' && Array.isArray(res.data) ? res.data : [];
            updateCustomerStats();
            customerCurrentPage = 1;
            renderCustomerView();
        },
        error: function() {
            $('#usersTableBody').html('<tr><td colspan="9" class="!py-10 text-center !text-rose-600">Failed to load customers.</td></tr>');
        }
    });
}

function updateCustomerStats() {
    $('#customerTotalCount').text(customerRows.length.toLocaleString('en-IN'));
    $('#customerWebsiteCount').text(customerRows.filter(isWebsiteCustomer).length.toLocaleString('en-IN'));
    $('#customerErpCount').text(customerRows.filter(row => !isWebsiteCustomer(row)).length.toLocaleString('en-IN'));
    $('#customerB2bCount').text(customerRows.filter(row => String(row.user_type).toLowerCase() === 'b2b').length.toLocaleString('en-IN'));
    $('#customerB2cCount').text(customerRows.filter(row => String(row.user_type).toLowerCase() !== 'b2b').length.toLocaleString('en-IN'));
}

function resetCustomerPageAndRender() {
    customerCurrentPage = 1;
    renderCustomerView();
}

function renderCustomerView() {
    const search = String($('#userSearchInput').val() || '').trim().toLowerCase();
    const type = String($('#userTypeFilter').val() || '').toLowerCase();
    const status = String($('#userStatusFilter').val() || '');
    const pageSize = Number($('#customerPageSize').val() || 10);

    customerFilteredRows = customerRows.filter(function(row) {
        const haystack = [row.name, row.email, row.phone, row.company_name, row.gstin, row.state_province, row.city, row.postal_code, row.detailed_address].join(' ').toLowerCase();
        return (!search || haystack.includes(search)) &&
            (!type || String(row.user_type).toLowerCase() === type) &&
            (status === '' || String(row.status) === status);
    });

    const totalPages = Math.max(1, Math.ceil(customerFilteredRows.length / pageSize));
    customerCurrentPage = Math.min(customerCurrentPage, totalPages);
    const start = (customerCurrentPage - 1) * pageSize;
    renderUsersTable(customerFilteredRows.slice(start, start + pageSize));
    renderCustomerPagination(totalPages);
    const first = customerFilteredRows.length ? start + 1 : 0;
    const last = Math.min(start + pageSize, customerFilteredRows.length);
    $('#customerShowingText').text('Showing ' + first + '–' + last + ' of ' + customerFilteredRows.length + ' customers');
}

function renderUsersTable(data) {
    if (!data.length) {
        $('#usersTableBody').html('<tr><td colspan="9" class="!py-10 text-center !text-slate-400">No customers match the selected filters.</td></tr>');
        return;
    }

    let html = '';
    data.forEach(function(item) {
        const isWebsite = isWebsiteCustomer(item);
        const sourceBadge = isWebsite
            ? '<span class="customer-pill bg-blue-50 text-blue-700">Web</span>'
            : '<span class="customer-pill bg-slate-100 text-slate-600">ERP</span>';
        const typeBadge = String(item.user_type).toLowerCase() === 'b2b'
            ? '<span class="customer-pill bg-amber-50 text-amber-700">B2B</span>'
            : '<span class="customer-pill bg-emerald-50 text-emerald-700">B2C</span>';
        const statusBadge = Number(item.status) === 1
            ? '<span class="customer-pill bg-emerald-50 text-emerald-700">Active</span>'
            : '<span class="customer-pill bg-rose-50 text-rose-700">Inactive</span>';
        const credit = Number(item.credit_limit || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        html += `<tr>
            <td>${sourceBadge}<div class="mt-1 text-[9px] text-slate-400">#${isWebsite ? escapeHtml(item.website_user_id) : escapeHtml(item.id)}</div></td>
            <td><div class="font-extrabold text-slate-800">${escapeHtml(item.name)}</div><div class="mt-1 text-[10px] text-slate-400">ERP #${escapeHtml(item.id)}</div></td>
            <td><i class="ti ti-phone mr-1 text-emerald-700"></i>${escapeHtml(item.phone || '—')}</td>
            <td><div class="font-semibold text-slate-700">${escapeHtml(item.company_name || '—')}</div><div class="mt-1 text-[10px] text-slate-400">${escapeHtml(item.gstin || 'No GSTIN')}</div></td>
            <td><i class="ti ti-mail mr-1 text-sky-600"></i>${escapeHtml(item.email || '—')}</td>
            <td>${typeBadge}</td>
            <td><div class="font-bold text-slate-700">₹${credit}</div><div class="text-[10px] text-slate-400">${Number(item.credit_days || 0)} days</div></td>
            <td>${statusBadge}</td>
            <td class="text-right"><button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-200 text-emerald-700 hover:bg-emerald-50" onclick="openEditCustomerModal(${Number(item.id)})" title="Edit customer"><i class="ti ti-pencil"></i></button></td>
        </tr>`;
    });
    $('#usersTableBody').html(html);
}

function renderCustomerPagination(totalPages) {
    let html = '<button class="customer-page-btn" data-customer-page="' + Math.max(1, customerCurrentPage - 1) + '" ' + (customerCurrentPage === 1 ? 'disabled' : '') + '><i class="ti ti-chevron-left"></i></button>';
    const from = Math.max(1, customerCurrentPage - 2);
    const to = Math.min(totalPages, from + 4);
    for (let page = from; page <= to; page++) html += '<button class="customer-page-btn ' + (page === customerCurrentPage ? 'is-active' : '') + '" data-customer-page="' + page + '">' + page + '</button>';
    html += '<button class="customer-page-btn" data-customer-page="' + Math.min(totalPages, customerCurrentPage + 1) + '" ' + (customerCurrentPage === totalPages ? 'disabled' : '') + '><i class="ti ti-chevron-right"></i></button>';
    $('#customerPagination').html(html);
}

function exportCustomersCsv() {
    const rows = [['Source','Customer','Country Code','Phone','Company','GSTIN','GST Format Valid','Email','Type','State / Province','City','Postal Code','Detailed Address','Credit Limit','Credit Days','Status']];
    customerFilteredRows.forEach(item => rows.push([
        isWebsiteCustomer(item) ? 'Website' : 'ERP', item.name || '', item.country_code || '+91', item.phone || '', item.company_name || '', item.gstin || '', Number(item.gst_format_valid || 0) === 1 ? 'Yes' : 'No', item.email || '', item.user_type || '', item.state_province || '', item.city || '', item.postal_code || '', item.detailed_address || '', item.credit_limit || 0, item.credit_days || 0, Number(item.status) === 1 ? 'Active' : 'Inactive'
    ]));
    downloadCsv('customer-management.csv', rows);
}

function downloadCsv(filename, rows) {
    const csv = rows.map(row => row.map(value => '"' + String(value == null ? '' : value).replace(/"/g, '""') + '"').join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    URL.revokeObjectURL(link.href);
    link.remove();
}

function openNewCustomerModal() {
    $('#customerForm')[0].reset();
    $('#customerId').val('');
    $('#custSourceOrigin').val('erp');
    $('#custSourceDisplay').val('ERP');
    $('#custCountryCode').val('+91');
    $('#custCreditLimit').val('0');
    $('#custCreditDays').val('0');
    $('#custPaymentTermsStatus').val('3');
    $('#custPaymentTermsText').val('');
    $('#custStatus').val('1');
    $('input[name="user_type"][value="b2c"]').prop('checked', true);
    $('#customerModalTitle').text('Add New Customer');
    $('#customerModalSubtitle').text('Create a customer in ERP while preserving the configured sync direction.');
    $('#customerSaveLabel').text('Create Customer');
    syncCustomerClassification();
    validateCustomerGstin();
    updateCustomerLocationPreview();
    $('#customerModal').modal('show');
}

function openEditCustomerModal(id) {
    $.ajax({
        url: 'ajax.php?action=getCustomerDetails',
        type: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(res) {
            if (res.status === 'success') {
                const d = res.data;
                $('#customerId').val(d.id);
                const sourceOrigin = isWebsiteCustomer(d) ? 'website' : 'erp';
                $('#custSourceOrigin').val(sourceOrigin);
                $('#custSourceDisplay').val(sourceOrigin === 'website' ? 'Website' : 'ERP');
                $('#custName').val(d.name || '');
                $('#custEmail').val(d.email || '');
                $('#custPhone').val(d.phone || '');
                $('#custCountryCode').val(d.country_code || '+91');
                $('input[name="user_type"][value="' + (String(d.user_type).toLowerCase() === 'b2b' ? 'b2b' : 'b2c') + '"]').prop('checked', true);
                $('#custCompanyName').val(d.company_name || '');
                $('#custContactPerson').val(d.contact_person || '');
                $('#custGstin').val(d.gstin || '');
                $('#custPan').val(d.pan || '');
                setCustomerStateValue(d.state_province || '');
                $('#custCity').val(d.city || '');
                $('#custPostalCode').val(d.postal_code || '');
                $('#custDetailedAddress').val(d.detailed_address || '');
                $('#custCreditLimit').val(d.credit_limit || '0');
                $('#custCreditDays').val(d.credit_days || '0');
                $('#custPaymentTermsStatus').val(String(d.payment_terms_status || '3'));
                $('#custPaymentTermsText').val(d.payment_terms_text || '');
                $('#custStatus').val(String(d.status) === '0' ? '0' : '1');
                $('#customerModalTitle').text('Edit Customer');
                $('#customerModalSubtitle').text('Update ERP customer #' + d.id + ' without changing its source mapping.');
                $('#customerSaveLabel').text('Update Customer');
                syncCustomerClassification();
                validateCustomerGstin();
                updateCustomerLocationPreview();
                $('#customerModal').modal('show');
            } else {
                alert(res.message || 'Customer details could not be loaded.');
            }
        },
        error: function(xhr) {
            alert((xhr.responseJSON && xhr.responseJSON.message) || 'Customer details could not be loaded.');
        }
    });
}

function saveCustomerForm(e) {
    e.preventDefault();
    const form = document.getElementById('customerForm');
    syncCustomerClassification();
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    if ($('#custGstin').val() && !validateCustomerGstin()) {
        $('#custGstin').trigger('focus');
        return;
    }

    const saveButton = document.getElementById('customerSaveButton');
    const originalLabel = document.getElementById('customerSaveLabel').textContent;
    saveButton.disabled = true;
    document.getElementById('customerSaveLabel').textContent = 'Saving...';
    const formData = $('#customerForm').serialize();
    $.ajax({
        url: 'ajax.php?action=saveCustomer',
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function(res) {
            if (res.status === 'success') {
                $('#customerModal').modal('hide');
                loadUsersGrid();
            } else {
                alert('Error: ' + res.message);
            }
        },
        error: function(xhr) {
            alert((xhr.responseJSON && xhr.responseJSON.message) || 'Customer could not be saved. Please try again.');
        },
        complete: function() {
            saveButton.disabled = false;
            document.getElementById('customerSaveLabel').textContent = originalLabel;
        }
    });
}

function isWebsiteCustomer(row) {
    return String(row.source_origin || '').toLowerCase() === 'website' || Number(row.website_user_id || 0) > 0;
}

function syncCustomerClassification() {
    const isB2b = $('input[name="user_type"]:checked').val() === 'b2b';
    $('#custCompanyName').prop('required', isB2b);
    $('#companyRequiredMark').toggleClass('d-none', !isB2b);
}

function validateCustomerGstin() {
    const input = document.getElementById('custGstin');
    const status = document.getElementById('gstValidationStatus');
    const gstin = String(input.value || '').toUpperCase().replace(/\s+/g, '');
    input.value = gstin;
    status.classList.remove('is-valid', 'is-invalid');

    if (!gstin) {
        input.setCustomValidity('');
        status.innerHTML = '<i class="ti ti-shield-search"></i><span>Optional. GSTIN format is checked while you type.</span>';
        return true;
    }

    const valid = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gstin);
    if (valid) {
        $('#custPan').val(gstin.slice(2, 12));
    }
    input.setCustomValidity(valid ? '' : 'Enter a valid 15-character GSTIN.');
    status.classList.add(valid ? 'is-valid' : 'is-invalid');
    status.innerHTML = valid
        ? '<i class="ti ti-circle-check"></i><span>GSTIN format is valid. External GST portal verification is not configured.</span>'
        : '<i class="ti ti-alert-circle"></i><span>Enter a valid 15-character GSTIN, for example 27AAAAA0000A1Z5.</span>';
    return valid;
}

function updateCustomerLocationPreview() {
    const parts = [$('#custCity').val(), $('#custStateProvince').val(), $('#custPostalCode').val()].filter(Boolean);
    $('#customerMapLabel').text(parts.length ? parts.join(', ') : 'Location preview');
}

function setCustomerStateValue(value) {
    const select = document.getElementById('custStateProvince');
    if (value && !Array.from(select.options).some(option => option.value === value)) {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = value;
        select.appendChild(option);
    }
    select.value = value;
}

function triggerManualSync(entity) {
    $.ajax({
        url: 'syncAjax.php',
        type: 'POST',
        data: { action: 'triggerEntitySync', entity: entity, csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '' },
        dataType: 'json',
        success: function(res) {
            alert(res.message || (res.success ? 'Synchronization completed.' : 'Synchronization failed.'));
            if (res.success === true || res.status === 'success') {
                loadUsersGrid();
            }
        },
        error: function(xhr) {
            alert(xhr.responseJSON?.message || 'Synchronization failed.');
        }
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

$(document).on('submit', '#customerManagementExportForm', function (e) {
    e.preventDefault();
    const search = $('#customerSearchInput').val() || '';
    const formData = new FormData(this);
    formData.append('exportCustomerManagement', '1');
    formData.append('search', search);

    $('#downloadExortfile').attr('href', '').attr('download', '').addClass('hidden d-none').attr('style', 'display: none !important;');
    const $submitBtn = $('#customerManagementExportForm button[type="submit"]');
    $submitBtn.prop('disabled', true).html('<i class="ti ti-loader-2 animate-spin"></i> Exporting...');

    $.ajax({
        url: 'exportajax.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (response) {
            if (response.success === 'success') {
                $('#downloadExortfile').attr('href', response.fileurl).attr('download', response.file).html('<i class="ti ti-download text-lg"></i> Download ' + $('#exportTypeSelect').val().toUpperCase()).removeClass('hidden d-none').attr('style', 'display: inline-flex !important;');
                if (window.toastr) toastr.success(response.message);
                else alert(response.message);
            } else {
                if (window.toastr) toastr.error(response.message);
                else alert(response.message);
            }
        },
        error: function () {
            if (window.toastr) toastr.error('Server error occurred.');
            else alert('Server error occurred.');
        },
        complete: function () {
            $submitBtn.prop('disabled', false).html('<i class="ti ti-download text-base"></i> Export');
        }
    });
});

$(document).on('click', '#customerManagementExportForm .export-type-item', function () {
    const val = $(this).data('val');
    $('#exportTypeText').text($(this).text());
    $('#exportTypeSelect').val(val);
});

$(document).on('click', '#customerDeselectAllColumnsBtn', function () {
    const isAllSelected = $('#customerManagementExportForm .column-filter:checked').length === $('#customerManagementExportForm .column-filter').length;
    if (isAllSelected) {
        $('#customerManagementExportForm .column-filter').prop('checked', false);
        $(this).text('Select All');
    } else {
        $('#customerManagementExportForm .column-filter').prop('checked', true);
        $(this).text('Deselect All');
    }
});

$(document).ready(function () {
    const urlParams = new URLSearchParams(window.location.search);
    const editCustId = parseInt(urlParams.get('edit_customer_id') || urlParams.get('edit_id') || 0);
    if (editCustId > 0) {
        setTimeout(function () {
            if (typeof openEditCustomerModal === 'function') {
                openEditCustomerModal(editCustId);
            }
        }, 350);
    }
});
</script>
<?php endSection(); ?>

<!-- Export Modal -->
<div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
            <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                <div>
                    <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                    <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                </div>
                <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
            </div>
            <form id="customerManagementExportForm">
                <div class="modal-body bg-white !px-5 !py-4">
                    <div class="mb-4">
                        <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                        <div class="dropdown w-full">
                            <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                            </button>
                            <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="exportType" id="exportTypeSelect" value="excel">
                    </div>

                    <div>
                        <div class="mb-2 flex items-center justify-between">
                            <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                            <button type="button" id="customerDeselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                            <div class="flex flex-col gap-2">
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Source" checked /><span class="text-sm font-medium text-slate-700">Source</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Customer Name" checked /><span class="text-sm font-medium text-slate-700">Customer Name</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Phone" checked /><span class="text-sm font-medium text-slate-700">Phone</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Company / GSTIN" checked /><span class="text-sm font-medium text-slate-700">Company / GSTIN</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Email" checked /><span class="text-sm font-medium text-slate-700">Email</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Type" checked /><span class="text-sm font-medium text-slate-700">Type</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Credit Limit" checked /><span class="text-sm font-medium text-slate-700">Credit Limit</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Status" checked /><span class="text-sm font-medium text-slate-700">Status</span></label>
                                <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 accent-emerald-600" value="Created At" checked /><span class="text-sm font-medium text-slate-700">Created At</span></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                    <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none !rounded-xl" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="inline-flex h-10 w-28 items-center justify-center gap-2 !rounded-xl text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534);"><i class="ti ti-download text-base"></i> Export</button>
                    <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="hidden d-none inline-flex h-10 w-auto items-center justify-center gap-2 !rounded-xl px-4 text-sm font-bold text-white shadow-sm transition-colors" style="background: var(--appearance-accent, #166534); display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                </div>
            </form>
        </div>
    </div>
</div>
