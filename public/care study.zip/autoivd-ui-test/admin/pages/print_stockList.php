<?php
require_once "../db.php";
require_once "../functions.php";
$sql = "SELECT prod.product_name AS product_name,  
       prodcateg.name AS category_name,
       qtysum.total_quantity,             
       stdunit.short_name AS quantity_unit_name                              
FROM `live_stock` livstk
LEFT JOIN `product_categories` prodcateg 
       ON livstk.product_category_id = prodcateg.id 
LEFT JOIN `products` prod 
       ON livstk.product_id = prod.id 
LEFT JOIN `standard_units` stdunit 
       ON livstk.quantity_unit = stdunit.id
LEFT JOIN (
    SELECT product_id, SUM(quantity_available) AS total_quantity
    FROM live_stock
    WHERE status != 3
    GROUP BY product_id
) qtysum ON livstk.product_id = qtysum.product_id
WHERE livstk.status != 3 AND prodcateg.id IN(9,10,11,12,21,22,26)            
GROUP BY livstk.product_id
ORDER BY prodcateg.name, prod.product_name ASC";

$result = $conn->query($sql);
// $row = $result->fetch_all();
$rows = $result->fetch_all(MYSQLI_ASSOC);
$fileName = '';  
$serial = 1;


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Material Requisition</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        .page {
            width: 100%;
            min-height: 1000px; /* ~A4 height in pixels at 96 DPI */
            padding: 20px;
            box-sizing: border-box;
            page-break-after: always;
            position: relative;
        }
        .page:last-child {
            page-break-after: auto;
        }
    </style>
</head>
<body style="margin: 0;">
    <div id="materialRequisitionContent" style="padding: 15px; max-width: 900px; margin: auto;">
        <?php            
          
            $rowsPerPage = 30;
            $chunks = array_chunk($rows, $rowsPerPage);
            foreach ($chunks as $pageIndex => $pageProducts) {
                $realCount = count($pageProducts);
                $emptyRows = $rowsPerPage - $realCount;                
        ?>
        <div class="page" style="page-break-after: <?= ($pageIndex == array_key_last($chunks)) ? 'always': 'auto' ?>;">
            <div style="border: 1px solid #000;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="line-height: 18px; ">
                        <td style="width: 35%; border-right: 1px solid #000; border-bottom: 1px solid #000; padding-top:10px; padding-left:10px;">
                            <img src="<?php echo asset('assets/img/logo3.jpeg'); ?>" alt="Biogenix Logo" style="height: 50px;">
                        </td>
                        <td rowspan="2" style="width: 30%; border-right: 1px solid #000; text-align:center; line-height: 22px;"><strong style="font-size: 16px;">TITLE: STOCK REPORT</strong></td>
                        <td rowspan="2" style="width: 15%; border-right: 1px solid #000; text-align:center;"><strong>Document No.</strong></td>
                        <td rowspan="2" style="text-align:center;">BIPL-F-SR-01</td>
                    </tr>
                    <tr>
                        <td style="width: 35%; border-right: 1px solid #000;  padding-left:10px;">
                            B19/A S.I.L Ancillary Estate,<br>
                            Amausi Industrial Area,<br>
                            Nadarganj-226008 (Lucknow)
                        </td>
                    </tr>
                </table>
            </div>
            

            <div style="font-size:14px; margin-top:10px;">
                <table style="width: 100%; border-collapse: collapse;">                     
                    <tr style="line-height: 18px; background-color:#D3D3D3; border-bottom: 1px solid #000;">
                        <td style="width: 4%; border-top: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Sr No.</td>
                        <td style="width: 27%; border-top: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Product Description</td>
                        <td style="width: 10%; border-top: 1px solid #000; border-left: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Category</td>
                        <td style="width: 10%; border-top: 1px solid #000; border-right: 1px solid #000; text-align:center; font-weight: bold;">Available Quantity</td>                        
                    </tr>
                    <?php if(!empty($pageProducts)): foreach ($pageProducts as $p): ?>                       
                        <tr style="line-height: 18px; border-bottom: 1px solid #000;">
                            <td style="padding-left:5px; width: 4%; border-left: 1px solid #000;border-right: 1px solid #000;"><?= $serial++ ?></td>
                            <td style="padding-left:5px; width: 27%; border-left: 1px solid #000;border-right: 1px solid #000;"><?= $p['product_name'] ?? '' ?></td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #000;"><?= $p['category_name'] ?? '' ?></td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #000;"><?= $p['total_quantity'] . ' ' . $p['quantity_unit_name'] ?></td>
                        </tr>      
                    <?php endforeach; endif; ?>
                    <?php for ($i = 0; $i < $emptyRows; $i++): ?>
                        <tr style="line-height: 18px; border-bottom: 1px solid #fff;">
                            <td style="padding-left:5px; width: 4%; border-left: 1px solid #fff;border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 27%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #fff;">&nbsp;</td>
                            <td style="padding-left:5px; width: 10%; border-right: 1px solid #fff;">&nbsp;</td>                      
                        </tr>     
                    <?php endfor; ?>
                </table>
                <table style="width: 100%; border-collapse: collapse; margin-top: 30px; text-align: center;">
                    <tr>
                        <td style="padding-top: 40px; text-align: left;">
                            <strong style="font-weight:700;">Requisition By</strong> (Sign/Date)<br> _____________________
                        </td>
                        <td style="padding-top: 40px; font-weight:700;"></td>
                        <td style="padding-top: 40px;  text-align: right;">
                            <strong style="font-weight:700;">Issued By</strong> (Sign/Date)<br> _____________________
                        </td>
                    </tr>
                </table>
            </div>

            <div style="text-align:right; padding: 15px; font-size:14px;">       
                <div style="margin-top: 30px; font-weight: bold;"></div>
            </div>
        </div>
            <?php if ($pageIndex < count($chunks) - 1): ?>
            <div class="html2pdf__page-break"></div>
          <?php endif; ?>
        <?php }  ?>
    </div>

    <script>
        window.onload = function() {
            const element = document.getElementById("materialRequisitionContent");
            const opt = {
                margin: [0.2, 0.2, 0.2, 0.2], // top, right, bottom, left
                filename: '<?= !empty($fileName) ? $fileName : "transfer_ticket_$id" ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' },
                pagebreak: { mode: ['css'] }
            };

            html2pdf().set(opt).from(element).save().then(() => {
                console.log("PDF downloaded.");
                window.close();
            });
        };
    </script>
</body>
</html>
