<?php
$file = 'pages/payroll-manual.php';
$lines = file($file);

$newLines = [];
$skip = false;
foreach ($lines as $i => $line) {
    if (strpos($line, '<form id="payroLLManualExportForm"') !== false) {
        $skip = true;
        // Output the new action bar and buttons
        $newLines[] = <<<EOT
                <div class="flex flex-col md:flex-row flex-wrap items-stretch md:items-center gap-3 justify-between w-full">
                    <div class="flex flex-col md:flex-row flex-wrap items-stretch md:items-center gap-2 w-full md:w-auto">
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl bg-slate-800 px-3 text-sm font-bold text-white shadow-sm ring-1 ring-slate-900/10 transition-colors hover:bg-slate-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-slate-500/30"
                            id="addEmployeeAttendanceFormModalBtn">
                            <i class="ti ti-calendar-plus text-lg"></i> <span class="whitespace-nowrap">Bulk Attendance</span>
                        </button>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl bg-blue-600 px-3 text-sm font-bold text-white shadow-sm ring-1 ring-blue-900/10 transition-colors hover:bg-blue-700 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                            id="addEmployeeHalfdayAttendanceFormModalBtn">
                            <i class="ti ti-clock text-lg"></i> <span class="whitespace-nowrap">Mark Halfday</span>
                        </button>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl bg-emerald-700 px-3 text-sm font-bold text-white shadow-sm ring-1 ring-emerald-900/10 transition-colors hover:bg-emerald-800 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                            id="addEmpSalaryModalBtn">
                            <i class="ti ti-cash text-lg"></i> <span class="whitespace-nowrap">Salary</span>
                        </button>
                        <button type="button"
                            class="inline-flex h-10 w-full md:w-auto shrink-0 items-center justify-center gap-2 !rounded-xl px-3 text-sm font-bold text-white shadow-sm transition-all hover:opacity-90 focus:outline-none"
                            style="background-color: #f97316;"
                            id="reviewAccountUpdateBtn"
                            data-bs-toggle="modal" data-bs-target="#reviewAccountUpdateModal">
                            <i class="ti ti-file-text text-lg"></i> <span class="whitespace-nowrap">Review Account Update</span>
                        </button>
                    </div>

                    <button type="button" class="biogenix-nav-btn-dashboard shadow-sm shrink-0 gap-2 w-full md:w-32 h-10" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="ti ti-download text-lg"></i> <span class="whitespace-nowrap">Export</span>
                    </button>
                </div>

EOT;
        continue;
    }
    
    if ($skip) {
        if (strpos($line, 'id="downloadExortfile"') !== false) {
            $skip = false;
            // Also skip the next line which is the closing tag for downloadExortfile
            continue;
        }
        if (strpos($line, 'class="biogenix-btn-download hidden d-none"') !== false) {
             // skip the line if it continued from downloadExortfile
             $skip = false;
             continue;
        }
        continue;
    }
    
    if (strpos($line, '<?php startSection(\'scripts\'); ?>') !== false) {
        $modal = <<<EOT
    <div class="modal fade animate__animated fadeIn" id="exportModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
            <div class="modal-content overflow-hidden !rounded-xl border border-slate-200 bg-white shadow-xl">
                <div class="modal-header flex items-center justify-between border-b border-slate-200 bg-white !px-5 !py-4">
                    <div>
                        <h5 class="modal-title m-0 text-lg font-bold text-slate-900">Export Document</h5>
                        <p class="m-0 text-sm font-medium text-slate-500">Configure your export settings before downloading.</p>
                    </div>
                    <button type="button" class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none" data-bs-dismiss="modal" aria-label="Close"><i class="ti ti-x text-lg"></i></button>
                </div>
                <form id="payroLLManualExportForm">
                    <div class="modal-body bg-white !px-5 !py-4">
                        <div class="mb-4">
                            <label class="mb-2 block text-[11px] font-bold uppercase tracking-widest text-slate-800">FILE FORMAT</label>
                            <div class="dropdown w-full">
                                <button class="flex w-full h-10 items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 focus:outline-none focus:ring-1 focus:ring-emerald-500" type="button" data-bs-toggle="dropdown">
                                    <span id="exportTypeText">Excel Spreadsheet (.xlsx)</span>
                                    <i class="ti ti-chevron-down text-sm text-slate-400"></i>
                                </button>
                                <ul class="dropdown-menu w-full !rounded-xl border border-slate-200 p-1 shadow-xl">
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="csv">CSV (Comma Separated Values)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="excel">Excel Spreadsheet (.xlsx)</a></li>
                                    <li><a class="export-type-item block cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50" data-val="pdf">PDF Document</a></li>
                                </ul>
                            </div>
                            <input type="hidden" name="exportType" id="exportType" value="excel">
                        </div>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <label class="text-[11px] font-bold uppercase tracking-widest text-slate-800">SELECT COLUMNS</label>
                                <button type="button" id="deselectAllColumnsBtn" class="text-[11px] font-bold text-slate-500 hover:text-emerald-600 transition-colors">Deselect All</button>
                            </div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50/50 p-3 max-h-48 overflow-y-auto">
                                <div class="flex flex-col gap-2" id="columnsCheckboxList">
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Employee Code" checked /> <span class="text-sm font-medium text-slate-700">Employee Code</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Name" checked /> <span class="text-sm font-medium text-slate-700">Name</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Category" checked /> <span class="text-sm font-medium text-slate-700">Category</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Status" checked /> <span class="text-sm font-medium text-slate-700">Status</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Basic Salary" checked /> <span class="text-sm font-medium text-slate-700">Basic Salary</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Day Pay" checked /> <span class="text-sm font-medium text-slate-700">Daily Wage</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Working Days" checked /> <span class="text-sm font-medium text-slate-700">Working Days</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Absents" checked /> <span class="text-sm font-medium text-slate-700">Absents</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Week Off" checked /> <span class="text-sm font-medium text-slate-700">Week Off</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Holidays" checked /> <span class="text-sm font-medium text-slate-700">Holidays</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Gross Earned" checked /> <span class="text-sm font-medium text-slate-700">Gross Earned</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="PF Amount" checked /> <span class="text-sm font-medium text-slate-700">PF Amount</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="ESIC Amount" checked /> <span class="text-sm font-medium text-slate-700">ESIC Amount</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Advance Count" checked /> <span class="text-sm font-medium text-slate-700">Advance Count</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Advance AMT" checked /> <span class="text-sm font-medium text-slate-700">Advance AMT</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Net Salary" checked /> <span class="text-sm font-medium text-slate-700">Net Salary</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="UAN" checked /> <span class="text-sm font-medium text-slate-700">UAN</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="ESIC" checked /> <span class="text-sm font-medium text-slate-700">ESIC</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Acc No" checked /> <span class="text-sm font-medium text-slate-700">Acc No</span></label>
                                    <label class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"><input type="checkbox" name="listOfColumns[]" class="column-filter h-4 w-4 rounded border-slate-300 text-emerald-600 accent-emerald-600 focus:ring-emerald-500" value="Bank" checked /> <span class="text-sm font-medium text-slate-700">Bank</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-t border-slate-200 bg-white !px-5 !py-4 flex items-center justify-center gap-3">
                        <button type="button" class="inline-flex h-10 w-28 items-center justify-center border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-colors hover:bg-slate-50 focus:outline-none" style="border-radius: 0.75rem !important;" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-28 h-10">
                            <i class="ti ti-download text-base"></i> Export
                        </button>
                        <a target="_blank" rel="noopener noreferrer" id="downloadExortfile" class="biogenix-nav-btn-dashboard shadow-sm gap-2 w-auto hidden d-none" style="display: none !important;"><i class="ti ti-download text-base"></i> Download</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

EOT;
        $newLines[] = $modal;
        $newLines[] = $line;
    } else {
        $newLines[] = $line;
    }
}

file_put_contents($file, implode("", $newLines));
echo "Patch applied!\n";
