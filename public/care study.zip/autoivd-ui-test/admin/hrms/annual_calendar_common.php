<?php

declare(strict_types=1);

if (!defined('HRMS_CONTEXT')) {
    http_response_code(404);
    exit;
}

/**
 * Annual Calendar & Working Days domain helpers.
 *
 * Calendar scope is company-wide. Branches inherit the finalized company
 * revision so every downstream component resolves a date identically.
 */

function acTableExists(mysqli $conn, string $table): bool
{
    static $cache = [];
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }
    $escaped = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$escaped}'");
    return $cache[$table] = (bool) ($result && $result->num_rows === 1);
}

function acProductionSchemaReady(mysqli $conn): bool
{
    return acTableExists($conn, 'hr_annual_calendars')
        && acTableExists($conn, 'hr_annual_calendar_days')
        && acTableExists($conn, 'hr_annual_calendar_audit_events');
}

function acHardeningSchemaReady(mysqli $conn): bool
{
    return acTableExists($conn, 'hr_annual_calendar_day_overrides');
}

/**
 * Weekly-off days are stored as a comma separated list of ISO-8601 day numbers
 * (1 = Monday … 7 = Sunday) so companies are not locked to a Sunday week-end.
 */
function acParseWeeklyOffDays(?string $value): array
{
    $days = array_values(array_unique(array_filter(
        array_map('intval', array_filter(array_map('trim', explode(',', (string) $value)), 'strlen')),
        static fn(int $day): bool => $day >= 1 && $day <= 7
    )));
    sort($days);
    return $days === [] ? [7] : $days;
}

function acValidWeeklyOffDays(array $days): array
{
    $normalized = acParseWeeklyOffDays(implode(',', array_map('strval', $days)));
    if (count($normalized) >= 7) {
        throw new InvalidArgumentException('At least one day of the week must remain a working day.');
    }
    return $normalized;
}

function acValidOverrideType(string $value): string
{
    if (!in_array($value, ['working_day', 'weekly_off'], true)) {
        throw new InvalidArgumentException('Select a valid day override type.');
    }
    return $value;
}

/**
 * Parses an HR-supplied holiday CSV into validated rows plus per-row errors so
 * the UI can preview the outcome before anything is written.
 *
 * Expected header: date, name, type[, optional]
 *
 * @return array{rows: array<int, array<string, mixed>>, errors: array<int, string>}
 */
function acParseHolidayCsv(string $csvContent, int $year): array
{
    $csvContent = preg_replace('/^\xEF\xBB\xBF/', '', $csvContent) ?? $csvContent;
    $handle = fopen('php://temp', 'r+b');
    fwrite($handle, $csvContent);
    rewind($handle);

    $header = fgetcsv($handle, 0, ',', '"', '\\');
    if ($header === false || $header === null) {
        fclose($handle);
        throw new InvalidArgumentException('The holiday file is empty.');
    }
    $columns = [];
    foreach ($header as $index => $label) {
        $key = strtolower(trim((string) $label));
        $key = preg_replace('/[^a-z_]/', '', str_replace([' ', '-'], '_', $key)) ?? '';
        $columns[$key] = $index;
    }
    foreach (['date', 'name', 'type'] as $required) {
        if (!array_key_exists($required, $columns)) {
            fclose($handle);
            throw new InvalidArgumentException('The holiday file must contain date, name and type columns.');
        }
    }

    $rows = [];
    $errors = [];
    $seen = [];
    $lineNumber = 1;
    while (($record = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
        $lineNumber++;
        if ($record === [null] || $record === []) {
            continue;
        }
        $rawDate = trim((string) ($record[$columns['date']] ?? ''));
        $rawName = trim((string) ($record[$columns['name']] ?? ''));
        $rawType = strtolower(trim((string) ($record[$columns['type']] ?? '')));
        if ($rawDate === '' && $rawName === '' && $rawType === '') {
            continue;
        }
        if (count($rows) + count($errors) >= 500) {
            $errors[] = "Line {$lineNumber}: the import is limited to 500 rows per file.";
            break;
        }

        try {
            $date = acValidDate($rawDate, $year);
            $name = acValidHolidayName($rawName);
            $type = acValidHolidayType($rawType);
        } catch (InvalidArgumentException $error) {
            $errors[] = "Line {$lineNumber}: " . $error->getMessage();
            continue;
        }

        $key = $date . '|' . mb_strtolower($name);
        if (isset($seen[$key])) {
            $errors[] = "Line {$lineNumber}: duplicate of line {$seen[$key]} ({$date} {$name}).";
            continue;
        }
        $seen[$key] = $lineNumber;

        $optional = $type === 'restricted';
        if (array_key_exists('optional', $columns)) {
            $rawOptional = strtolower(trim((string) ($record[$columns['optional']] ?? '')));
            if ($rawOptional !== '') {
                $optional = in_array($rawOptional, ['1', 'y', 'yes', 'true', 'optional'], true);
            }
        }

        $rows[] = [
            'line' => $lineNumber,
            'date' => $date,
            'name' => $name,
            'type' => $type,
            'is_optional' => $optional ? 1 : 0,
        ];
    }
    fclose($handle);

    if ($rows === [] && $errors === []) {
        throw new InvalidArgumentException('The holiday file contains no rows.');
    }
    usort($rows, static fn(array $a, array $b): int => [$a['date'], $a['name']] <=> [$b['date'], $b['name']]);
    return ['rows' => $rows, 'errors' => $errors];
}

/**
 * @param array<int, array<string, mixed>> $rows
 * @return array{imported: int, skipped: int}
 */
function acImportHolidayRows(mysqli $conn, int $calendarId, array $rows, int $userId, string $sourceName, string $sourceVersion): array
{
    $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_holidays', 'is_optional');
    $insert = $conn->prepare(
        $hasOptionalColumn
            ? 'INSERT IGNORE INTO hr_annual_calendar_holidays
               (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, is_optional, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, NOW())'
            : 'INSERT IGNORE INTO hr_annual_calendar_holidays
               (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
    );
    $imported = 0;
    foreach ($rows as $row) {
        $date = (string) $row['date'];
        $name = (string) $row['name'];
        $type = (string) $row['type'];
        $optional = (int) $row['is_optional'];
        if ($hasOptionalColumn) {
            $insert->bind_param('isssssii', $calendarId, $date, $name, $type, $sourceName, $sourceVersion, $optional, $userId);
        } else {
            $insert->bind_param('isssssi', $calendarId, $date, $name, $type, $sourceName, $sourceVersion, $userId);
        }
        if (!$insert->execute()) {
            $insert->close();
            throw new RuntimeException('Unable to import the holiday list.');
        }
        $imported += max(0, $insert->affected_rows);
    }
    $insert->close();
    return ['imported' => $imported, 'skipped' => count($rows) - $imported];
}

function acValidDate(string $value, ?int $requiredYear = null): string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) {
        throw new InvalidArgumentException('Select a valid date.');
    }
    if ($requiredYear !== null && (int) $date->format('Y') !== $requiredYear) {
        throw new InvalidArgumentException("The date must be within calendar year {$requiredYear}.");
    }
    return $value;
}

function acValidHolidayType(string $value): string
{
    $allowed = ['national', 'company', 'festival', 'restricted', 'other'];
    if (!in_array($value, $allowed, true)) {
        throw new InvalidArgumentException('Select a valid holiday type.');
    }
    return $value;
}

function acValidHolidayName(string $value): string
{
    $value = trim($value);
    $length = mb_strlen($value);
    if ($length < 2 || $length > 150) {
        throw new InvalidArgumentException('Holiday name must be between 2 and 150 characters.');
    }
    return $value;
}

function acValidReason(string $value): string
{
    $value = trim($value);
    if (mb_strlen($value) < 5 || mb_strlen($value) > 1000) {
        throw new InvalidArgumentException('Enter a reason between 5 and 1000 characters.');
    }
    return $value;
}

/**
 * Suggested India holiday seed data. HR remains responsible for confirming
 * state, local, festival, and company holidays before finalization.
 */
function acGetIndianHolidays(int $year): array
{
    if ($year < 2020 || $year > 2100) {
        return [];
    }

    $sourceName = 'Care IO India holiday reference';
    $sourceVersion = '2026.09';
    $holidays = [
        ['date' => "$year-01-01", 'name' => "New Year's Day", 'type' => 'company'],
        ['date' => "$year-01-26", 'name' => 'Republic Day', 'type' => 'national'],
        ['date' => "$year-05-01", 'name' => 'May Day / Labour Day', 'type' => 'company'],
        ['date' => "$year-08-15", 'name' => 'Independence Day', 'type' => 'national'],
        ['date' => "$year-10-02", 'name' => 'Mahatma Gandhi Jayanti', 'type' => 'national'],
        ['date' => "$year-12-25", 'name' => 'Christmas', 'type' => 'festival'],
    ];

    $variableHolidays = [
        2025 => [
            ['date' => '2025-03-14', 'name' => 'Holi', 'type' => 'festival'],
            ['date' => '2025-03-31', 'name' => 'Eid ul-Fitr', 'type' => 'festival'],
            ['date' => '2025-04-06', 'name' => 'Ram Navami', 'type' => 'festival'],
            ['date' => '2025-04-10', 'name' => 'Mahavir Jayanti', 'type' => 'festival'],
            ['date' => '2025-04-14', 'name' => 'Dr. Ambedkar Jayanti', 'type' => 'restricted'],
            ['date' => '2025-04-18', 'name' => 'Good Friday', 'type' => 'restricted'],
            ['date' => '2025-05-12', 'name' => 'Buddha Purnima', 'type' => 'restricted'],
            ['date' => '2025-06-07', 'name' => 'Eid ul-Adha', 'type' => 'festival'],
            ['date' => '2025-07-06', 'name' => 'Muharram', 'type' => 'festival'],
            ['date' => '2025-08-16', 'name' => 'Janmashtami', 'type' => 'festival'],
            ['date' => '2025-10-02', 'name' => 'Dussehra', 'type' => 'festival'],
            ['date' => '2025-10-20', 'name' => 'Diwali', 'type' => 'festival'],
            ['date' => '2025-10-21', 'name' => 'Diwali (Day 2)', 'type' => 'festival'],
            ['date' => '2025-11-05', 'name' => 'Guru Nanak Jayanti', 'type' => 'festival'],
        ],
        2026 => [
            ['date' => '2026-03-04', 'name' => 'Holi', 'type' => 'festival'],
            ['date' => '2026-03-21', 'name' => 'Eid ul-Fitr', 'type' => 'festival'],
            ['date' => '2026-03-26', 'name' => 'Ram Navami', 'type' => 'festival'],
            ['date' => '2026-03-31', 'name' => 'Mahavir Jayanti', 'type' => 'festival'],
            ['date' => '2026-04-03', 'name' => 'Good Friday', 'type' => 'restricted'],
            ['date' => '2026-04-14', 'name' => 'Dr. Ambedkar Jayanti', 'type' => 'restricted'],
            ['date' => '2026-05-01', 'name' => 'Buddha Purnima', 'type' => 'restricted'],
            ['date' => '2026-05-28', 'name' => 'Eid ul-Adha', 'type' => 'festival'],
            ['date' => '2026-06-26', 'name' => 'Muharram', 'type' => 'festival'],
            ['date' => '2026-09-04', 'name' => 'Janmashtami', 'type' => 'festival'],
            ['date' => '2026-10-20', 'name' => 'Dussehra', 'type' => 'festival'],
            ['date' => '2026-11-08', 'name' => 'Diwali', 'type' => 'festival'],
            ['date' => '2026-11-09', 'name' => 'Diwali (Day 2)', 'type' => 'festival'],
            ['date' => '2026-11-24', 'name' => 'Guru Nanak Jayanti', 'type' => 'festival'],
        ],
        2027 => [
            ['date' => '2027-03-10', 'name' => 'Eid ul-Fitr', 'type' => 'festival'],
            ['date' => '2027-03-22', 'name' => 'Holi', 'type' => 'festival'],
            ['date' => '2027-03-26', 'name' => 'Good Friday', 'type' => 'restricted'],
            ['date' => '2027-04-14', 'name' => 'Dr. Ambedkar Jayanti', 'type' => 'restricted'],
            ['date' => '2027-04-15', 'name' => 'Ram Navami', 'type' => 'festival'],
            ['date' => '2027-04-19', 'name' => 'Mahavir Jayanti', 'type' => 'festival'],
            ['date' => '2027-05-17', 'name' => 'Eid ul-Adha', 'type' => 'festival'],
            ['date' => '2027-05-20', 'name' => 'Buddha Purnima', 'type' => 'restricted'],
            ['date' => '2027-06-16', 'name' => 'Muharram', 'type' => 'festival'],
            ['date' => '2027-08-25', 'name' => 'Janmashtami', 'type' => 'festival'],
            ['date' => '2027-10-09', 'name' => 'Dussehra', 'type' => 'festival'],
            ['date' => '2027-10-29', 'name' => 'Diwali', 'type' => 'festival'],
            ['date' => '2027-10-30', 'name' => 'Diwali (Day 2)', 'type' => 'festival'],
            ['date' => '2027-11-14', 'name' => 'Guru Nanak Jayanti', 'type' => 'festival'],
        ],
        2028 => [
            ['date' => '2028-02-28', 'name' => 'Eid ul-Fitr', 'type' => 'festival'],
            ['date' => '2028-03-11', 'name' => 'Holi', 'type' => 'festival'],
            ['date' => '2028-04-03', 'name' => 'Ram Navami', 'type' => 'festival'],
            ['date' => '2028-04-07', 'name' => 'Mahavir Jayanti', 'type' => 'festival'],
            ['date' => '2028-04-14', 'name' => 'Dr. Ambedkar Jayanti', 'type' => 'restricted'],
            ['date' => '2028-04-14', 'name' => 'Good Friday', 'type' => 'restricted'],
            ['date' => '2028-05-06', 'name' => 'Eid ul-Adha', 'type' => 'festival'],
            ['date' => '2028-05-08', 'name' => 'Buddha Purnima', 'type' => 'restricted'],
            ['date' => '2028-06-04', 'name' => 'Muharram', 'type' => 'festival'],
            ['date' => '2028-08-15', 'name' => 'Janmashtami', 'type' => 'festival'],
            ['date' => '2028-09-27', 'name' => 'Dussehra', 'type' => 'festival'],
            ['date' => '2028-10-17', 'name' => 'Diwali', 'type' => 'festival'],
            ['date' => '2028-10-18', 'name' => 'Diwali (Day 2)', 'type' => 'festival'],
            ['date' => '2028-11-03', 'name' => 'Guru Nanak Jayanti', 'type' => 'festival'],
        ],
    ];
    if (isset($variableHolidays[$year])) {
        $holidays = array_merge($holidays, $variableHolidays[$year]);
    }

    $unique = [];
    foreach ($holidays as $holiday) {
        if ((int) substr($holiday['date'], 0, 4) !== $year) {
            continue;
        }
        $holiday['source_name'] = $sourceName;
        $holiday['source_version'] = $sourceVersion;
        $unique[$holiday['date'] . '|' . mb_strtolower($holiday['name'])] = $holiday;
    }
    $result = array_values($unique);
    usort($result, static fn(array $a, array $b): int => [$a['date'], $a['name']] <=> [$b['date'], $b['name']]);
    return $result;
}

function acComputeSaturdayOffs(int $year, string $policy, array $customOffDates = []): array
{
    $validPolicies = ['all_working', 'all_off', '2nd_4th_off', 'alternate_off', 'custom'];
    if (!in_array($policy, $validPolicies, true)) {
        throw new InvalidArgumentException('Invalid weekly-off policy.');
    }
    if ($policy === 'all_working') {
        return [];
    }
    if ($policy === 'custom') {
        $result = [];
        foreach ($customOffDates as $date) {
            try {
                $result[] = acValidDate((string) $date, $year);
            } catch (InvalidArgumentException) {
                continue;
            }
        }
        $result = array_values(array_unique($result));
        sort($result);
        return $result;
    }

    if ($policy === 'alternate_off') {
        $offs = [];
        $date = (new DateTimeImmutable("{$year}-01-01"))->modify('first saturday of this year');
        $end = new DateTimeImmutable("{$year}-12-31");
        $position = 0;
        for (; $date <= $end; $date = $date->modify('+7 days')) {
            $position++;
            if ($position % 2 === 0) {
                $offs[] = $date->format('Y-m-d');
            }
        }
        return $offs;
    }

    $offs = [];
    for ($month = 1; $month <= 12; $month++) {
        $first = new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month));
        $firstSaturday = $first->modify('first saturday of this month');
        $saturdays = [];
        for ($date = $firstSaturday; (int) $date->format('n') === $month; $date = $date->modify('+7 days')) {
            $saturdays[] = $date->format('Y-m-d');
        }
        if ($policy === 'all_off') {
            $offs = array_merge($offs, $saturdays);
        } elseif ($policy === '2nd_4th_off') {
            foreach ([1, 3] as $index) {
                if (isset($saturdays[$index])) {
                    $offs[] = $saturdays[$index];
                }
            }
        }
    }
    sort($offs);
    return $offs;
}

function acCalendarById(mysqli $conn, int $calendarId, bool $forUpdate = false): ?array
{
    $lock = $forUpdate ? ' FOR UPDATE' : '';
    $stmt = $conn->prepare("SELECT * FROM hr_annual_calendars WHERE id = ? AND deleted_at IS NULL LIMIT 1{$lock}");
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $calendar = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $calendar;
}

function acGetCalendarForYear(mysqli $conn, int $companyId, int $year): ?array
{
    $stmt = $conn->prepare(
        "SELECT * FROM hr_annual_calendars
         WHERE company_id = ? AND calendar_year = ? AND status = 1 AND deleted_at IS NULL
           AND lifecycle_status IN ('draft','finalized')
         ORDER BY CASE lifecycle_status WHEN 'draft' THEN 0 ELSE 1 END, revision_no DESC LIMIT 1"
    );
    $stmt->bind_param('ii', $companyId, $year);
    $stmt->execute();
    $calendar = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$calendar) {
        return null;
    }
    return acAttachCalendarChildren($conn, $calendar);
}

function acGetFinalizedCalendarForYear(mysqli $conn, int $companyId, int $year): ?array
{
    if (!acProductionSchemaReady($conn)) {
        return null;
    }
    $stmt = $conn->prepare(
        "SELECT * FROM hr_annual_calendars
         WHERE company_id = ? AND calendar_year = ? AND lifecycle_status = 'finalized'
           AND is_finalized = 1 AND status = 1 AND deleted_at IS NULL
         ORDER BY revision_no DESC LIMIT 1"
    );
    $stmt->bind_param('ii', $companyId, $year);
    $stmt->execute();
    $calendar = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $calendar;
}

function acAttachCalendarChildren(mysqli $conn, array $calendar): array
{
    $calendarId = (int) $calendar['id'];
    $stmt = $conn->prepare(
        'SELECT * FROM hr_annual_calendar_holidays WHERE calendar_id = ? AND deleted_at IS NULL ORDER BY holiday_date, holiday_name'
    );
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $calendar['holidays'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    $calendar['custom_offs'] = acGetCustomOffDates($conn, $calendarId);
    $calendar['day_overrides'] = acGetDayOverrides($conn, $calendarId);
    $calendar['weekly_off_days'] = acParseWeeklyOffDays($calendar['weekly_off_days'] ?? '7');
    return $calendar;
}

function acGetDayOverrides(mysqli $conn, int $calendarId): array
{
    if (!acTableExists($conn, 'hr_annual_calendar_day_overrides')) {
        return [];
    }
    $stmt = $conn->prepare(
        'SELECT id, override_date, override_type, note FROM hr_annual_calendar_day_overrides
         WHERE calendar_id = ? ORDER BY override_date'
    );
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $overrides = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $overrides;
}

function acGetCustomOffDates(mysqli $conn, int $calendarId): array
{
    if (!acTableExists($conn, 'hr_annual_calendar_custom_offs')) {
        return [];
    }
    $stmt = $conn->prepare('SELECT off_date FROM hr_annual_calendar_custom_offs WHERE calendar_id = ? ORDER BY off_date');
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $dates = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'off_date');
    $stmt->close();
    return $dates;
}

function acBuildCalendarDays(mysqli $conn, int $calendarId): array
{
    $calendar = acCalendarById($conn, $calendarId);
    if (!$calendar) {
        throw new InvalidArgumentException('Calendar not found.');
    }
    $calendar = acAttachCalendarChildren($conn, $calendar);
    return acBuildCalendarDaysFromData(
        (int) $calendar['calendar_year'],
        (string) $calendar['saturday_policy'],
        $calendar['holidays'],
        $calendar['custom_offs'],
        $calendar['weekly_off_days'],
        $calendar['day_overrides']
    );
}

function acBuildCalendarDaysFromData(
    int $year,
    string $policy,
    array $holidays,
    array $customOffDates = [],
    array $weeklyOffDays = [7],
    array $dayOverrides = []
): array {
    $weeklyOffDays = acParseWeeklyOffDays(implode(',', array_map('strval', $weeklyOffDays)));
    $weeklyOffDaySet = array_fill_keys($weeklyOffDays, true);
    $weeklyOffSet = array_fill_keys(acComputeSaturdayOffs($year, $policy, $customOffDates), true);

    $overrideMap = [];
    foreach ($dayOverrides as $override) {
        $overrideDate = (string) ($override['override_date'] ?? '');
        if ((int) substr($overrideDate, 0, 4) !== $year) {
            continue;
        }
        $overrideMap[$overrideDate] = (string) ($override['override_type'] ?? 'working_day');
    }

    $holidayMap = [];
    foreach ($holidays as $holiday) {
        if ((int) ($holiday['is_enabled'] ?? 1) !== 1 || !empty($holiday['deleted_at'])) {
            continue;
        }
        $date = (string) ($holiday['holiday_date'] ?? $holiday['date'] ?? '');
        if ((int) substr($date, 0, 4) !== $year) {
            continue;
        }
        $type = (string) ($holiday['holiday_type'] ?? $holiday['type'] ?? 'other');
        $holidayMap[$date][] = [
            'name' => (string) ($holiday['holiday_name'] ?? $holiday['name'] ?? ''),
            'type' => $type,
            'optional' => array_key_exists('is_optional', $holiday)
                ? (int) $holiday['is_optional'] === 1
                : $type === 'restricted',
        ];
    }

    $days = [];
    $date = new DateTimeImmutable("{$year}-01-01");
    $end = new DateTimeImmutable("{$year}-12-31");
    for (; $date <= $end; $date = $date->modify('+1 day')) {
        $dateString = $date->format('Y-m-d');
        $dayOfWeek = (int) $date->format('N');
        $isWeeklyOff = isset($weeklyOffDaySet[$dayOfWeek]) || isset($weeklyOffSet[$dateString]);
        if (isset($overrideMap[$dateString])) {
            $isWeeklyOff = $overrideMap[$dateString] === 'weekly_off';
        }

        $dateHolidays = $holidayMap[$dateString] ?? [];
        $mandatoryHolidays = array_values(array_filter($dateHolidays, static fn(array $item): bool => !$item['optional']));
        // Restricted/optional holidays stay visible but never reduce company working days.
        $isEffectiveHoliday = !$isWeeklyOff && $mandatoryHolidays !== [];
        $isOptionalOnly = !$isWeeklyOff && $mandatoryHolidays === [] && $dateHolidays !== [];
        $dayType = $isWeeklyOff ? 'weekly_off' : ($isEffectiveHoliday ? 'holiday' : 'working_day');

        $days[] = [
            'calendar_date' => $dateString,
            'day_of_week' => $dayOfWeek,
            'day_name' => $date->format('l'),
            'day_type' => $dayType,
            'is_working' => $dayType === 'working_day' ? 1 : 0,
            'is_weekly_off' => $isWeeklyOff ? 1 : 0,
            'is_holiday' => $isEffectiveHoliday ? 1 : 0,
            'is_optional_holiday' => $isOptionalOnly ? 1 : 0,
            'is_declared_holiday' => $dateHolidays !== [] ? 1 : 0,
            'is_overridden' => isset($overrideMap[$dateString]) ? 1 : 0,
            'holiday_names' => $dateHolidays !== [] ? implode(' / ', array_column($dateHolidays, 'name')) : null,
            'holiday_types' => $dateHolidays !== []
                ? implode(',', array_values(array_unique(array_column($dateHolidays, 'type'))))
                : null,
        ];
    }
    return $days;
}

function acTotalsFromDays(array $days): array
{
    $totals = [
        'total_days' => count($days),
        'total_sundays' => 0,
        'total_saturday_offs' => 0,
        'total_holidays' => 0,
        'total_declared_holidays' => 0,
        'total_optional_holidays' => 0,
        'total_working_days' => 0,
    ];
    foreach ($days as $day) {
        if ((int) $day['day_of_week'] === 7) {
            $totals['total_sundays']++;
        }
        if ((int) $day['is_weekly_off'] === 1 && (int) $day['day_of_week'] !== 7) {
            $totals['total_saturday_offs']++;
        }
        if ($day['day_type'] === 'holiday') {
            $totals['total_holidays']++;
        }
        if ((int) ($day['is_declared_holiday'] ?? 0) === 1) {
            $totals['total_declared_holidays']++;
        }
        if ((int) ($day['is_optional_holiday'] ?? 0) === 1) {
            $totals['total_optional_holidays']++;
        }
        if ((int) $day['is_working'] === 1) {
            $totals['total_working_days']++;
        }
    }
    return $totals;
}

function acRecalculateWorkingDays(mysqli $conn, int $calendarId): array
{
    acSyncHolidayOptionalFlags($conn, $calendarId);
    $days = acBuildCalendarDays($conn, $calendarId);
    $totals = acTotalsFromDays($days);
    $hasHardeningColumns = acColumnExists($conn, 'hr_annual_calendars', 'total_declared_holidays');
    $sql = 'UPDATE hr_annual_calendars SET total_days = ?, total_sundays = ?, total_saturday_offs = ?,
         total_holidays = ?, total_working_days = ?';
    if ($hasHardeningColumns) {
        $sql .= ', total_declared_holidays = ?, total_optional_holidays = ?';
    }
    $sql .= ', lock_version = lock_version + 1, updated_at = NOW() WHERE id = ?';
    $stmt = $conn->prepare($sql);
    if ($hasHardeningColumns) {
        $stmt->bind_param(
            'iiiiiiii',
            $totals['total_days'],
            $totals['total_sundays'],
            $totals['total_saturday_offs'],
            $totals['total_holidays'],
            $totals['total_working_days'],
            $totals['total_declared_holidays'],
            $totals['total_optional_holidays'],
            $calendarId
        );
    } else {
        $stmt->bind_param(
            'iiiiii',
            $totals['total_days'],
            $totals['total_sundays'],
            $totals['total_saturday_offs'],
            $totals['total_holidays'],
            $totals['total_working_days'],
            $calendarId
        );
    }
    $stmt->execute();
    $stmt->close();
    return $totals;
}

function acColumnExists(mysqli $conn, string $table, string $column): bool
{
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    if (!acTableExists($conn, $table)) {
        return $cache[$key] = false;
    }
    $escapedColumn = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$escapedColumn}'");
    return $cache[$key] = (bool) ($result && $result->num_rows === 1);
}

function acDropObsoleteIndexes(mysqli $conn): void
{
    static $cleaned = false;
    if ($cleaned) {
        return;
    }
    $cleaned = true;
    if (acTableExists($conn, 'hr_annual_calendars')) {
        $idxRes = $conn->query("SHOW INDEX FROM hr_annual_calendars WHERE Key_name = 'uq_company_year'");
        if ($idxRes && $idxRes->num_rows > 0) {
            $conn->query("ALTER TABLE hr_annual_calendars DROP INDEX uq_company_year");
        }
    }
}

/** Restricted holidays are employee-elective, so they never reduce company working days. */
function acSyncHolidayOptionalFlags(mysqli $conn, int $calendarId): void
{
    if (!acColumnExists($conn, 'hr_annual_calendar_holidays', 'is_optional')) {
        return;
    }
    $stmt = $conn->prepare(
        "UPDATE hr_annual_calendar_holidays SET is_optional = IF(holiday_type = 'restricted', 1, 0)
         WHERE calendar_id = ? AND is_optional <> IF(holiday_type = 'restricted', 1, 0)"
    );
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $stmt->close();
}

function acGetMonthlyBreakdown(int $year, string $saturdayPolicy, array $enabledHolidayDates, array $customOffDates = []): array
{
    $holidays = array_map(
        static fn(string $date): array => ['holiday_date' => $date, 'holiday_name' => 'Holiday', 'holiday_type' => 'other', 'is_enabled' => 1],
        $enabledHolidayDates
    );
    return acMonthlyBreakdownFromDays(acBuildCalendarDaysFromData($year, $saturdayPolicy, $holidays, $customOffDates));
}

function acMonthlyBreakdownFromDays(array $days): array
{
    $months = [];
    for ($month = 1; $month <= 12; $month++) {
        $months[$month] = [
            'month' => $month,
            'month_name' => date('F', mktime(0, 0, 0, $month, 1)),
            'total_days' => 0,
            'sundays' => 0,
            'sat_offs' => 0,
            'weekly_offs' => 0,
            'holidays' => 0,
            'optional_holidays' => 0,
            'working_days' => 0,
        ];
    }
    foreach ($days as $day) {
        $month = (int) substr($day['calendar_date'], 5, 2);
        $months[$month]['total_days']++;
        if ((int) $day['day_of_week'] === 7) {
            $months[$month]['sundays']++;
        }
        if ((int) $day['is_weekly_off'] === 1 && (int) $day['day_of_week'] !== 7) {
            $months[$month]['sat_offs']++;
        }
        if ((int) $day['is_weekly_off'] === 1) {
            $months[$month]['weekly_offs']++;
        }
        if ($day['day_type'] === 'holiday') {
            $months[$month]['holidays']++;
        }
        if ((int) ($day['is_optional_holiday'] ?? 0) === 1) {
            $months[$month]['optional_holidays']++;
        }
        if ((int) $day['is_working'] === 1) {
            $months[$month]['working_days']++;
        }
    }
    return array_values($months);
}

function acCalendarLedgerHash(array $days): string
{
    $hashData = array_map(
        static fn(array $day): array => [
            (string) $day['calendar_date'],
            (string) $day['day_type'],
            (int) $day['is_holiday'],
            (int) ($day['is_optional_holiday'] ?? 0),
            $day['holiday_names'] === null ? null : (string) $day['holiday_names'],
            $day['holiday_types'] === null ? null : (string) $day['holiday_types'],
        ],
        $days
    );
    return hash('sha256', json_encode($hashData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function acPersistCalendarDays(mysqli $conn, array $calendar, array $days): string
{
    $calendarId = (int) $calendar['id'];
    $companyId = (int) $calendar['company_id'];
    $delete = $conn->prepare('DELETE FROM hr_annual_calendar_days WHERE calendar_id = ?');
    $delete->bind_param('i', $calendarId);
    $delete->execute();
    $delete->close();

    $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_days', 'is_optional_holiday');
    $insert = $conn->prepare(
        $hasOptionalColumn
            ? 'INSERT INTO hr_annual_calendar_days
               (calendar_id, company_id, calendar_date, day_of_week, day_type, is_working, is_weekly_off, is_holiday, is_optional_holiday, holiday_names, holiday_types)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            : 'INSERT INTO hr_annual_calendar_days
               (calendar_id, company_id, calendar_date, day_of_week, day_type, is_working, is_weekly_off, is_holiday, holiday_names, holiday_types)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach ($days as $day) {
        $calendarDate = (string) $day['calendar_date'];
        $dayOfWeek = (int) $day['day_of_week'];
        $dayType = (string) $day['day_type'];
        $isWorking = (int) $day['is_working'];
        $isWeeklyOff = (int) $day['is_weekly_off'];
        $isHoliday = (int) $day['is_holiday'];
        $isOptionalHoliday = (int) ($day['is_optional_holiday'] ?? 0);
        $holidayNames = $day['holiday_names'];
        $holidayTypes = $day['holiday_types'];
        if ($hasOptionalColumn) {
            $insert->bind_param(
                'iisisiiiiss',
                $calendarId,
                $companyId,
                $calendarDate,
                $dayOfWeek,
                $dayType,
                $isWorking,
                $isWeeklyOff,
                $isHoliday,
                $isOptionalHoliday,
                $holidayNames,
                $holidayTypes
            );
        } else {
            $insert->bind_param(
                'iisisiiiss',
                $calendarId,
                $companyId,
                $calendarDate,
                $dayOfWeek,
                $dayType,
                $isWorking,
                $isWeeklyOff,
                $isHoliday,
                $holidayNames,
                $holidayTypes
            );
        }
        if (!$insert->execute()) {
            throw new RuntimeException('Unable to materialize the annual calendar.');
        }
    }
    $insert->close();

    return acCalendarLedgerHash($days);
}

function acLogAudit(
    mysqli $conn,
    int $calendarId,
    string $action,
    ?string $field,
    ?string $oldVal,
    ?string $newVal,
    int $userId,
    ?string $reason = null,
    ?array $before = null,
    ?array $after = null
): void {
    $calendar = acCalendarById($conn, $calendarId);
    if (!$calendar || !acTableExists($conn, 'hr_annual_calendar_audit_events')) {
        return;
    }
    $companyId = (int) $calendar['company_id'];
    $year = (int) $calendar['calendar_year'];
    $revision = (int) ($calendar['revision_no'] ?? 1);
    $requestId = bin2hex(random_bytes(16));
    $beforeJson = $before === null ? null : json_encode($before, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $afterJson = $after === null ? null : json_encode($after, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $stmt = $conn->prepare(
        'INSERT INTO hr_annual_calendar_audit_events
         (calendar_id, company_id, calendar_year, revision_no, action, field_changed, old_value, new_value,
          reason, before_json, after_json, request_id, changed_by, changed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
    );
    $stmt->bind_param(
        'iiiissssssssi',
        $calendarId,
        $companyId,
        $year,
        $revision,
        $action,
        $field,
        $oldVal,
        $newVal,
        $reason,
        $beforeJson,
        $afterJson,
        $requestId,
        $userId
    );
    if (!$stmt->execute()) {
        throw new RuntimeException('Unable to record the calendar audit event.');
    }
    $stmt->close();
}

function acGetAuditEvents(mysqli $conn, int $companyId, int $year, int $limit = 100): array
{
    if (!acTableExists($conn, 'hr_annual_calendar_audit_events')) {
        return [];
    }
    $limit = max(1, min(250, $limit));
    $stmt = $conn->prepare(
        "SELECT event.id, event.calendar_id, event.revision_no, event.action, event.field_changed,
                event.old_value, event.new_value, event.reason, event.changed_at,
                COALESCE(user.name, CONCAT('User #', event.changed_by)) changed_by_name
         FROM hr_annual_calendar_audit_events event
         LEFT JOIN users user ON user.id = event.changed_by
         WHERE event.company_id = ? AND event.calendar_year = ?
         ORDER BY event.changed_at DESC, event.id DESC LIMIT {$limit}"
    );
    $stmt->bind_param('ii', $companyId, $year);
    $stmt->execute();
    $events = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $events;
}

function acFinalizeCalendar(mysqli $conn, int $calendarId, int $userId, ?int $expectedLockVersion = null): array
{
    $conn->begin_transaction();
    try {
        $calendar = acCalendarById($conn, $calendarId, true);
        if (!$calendar || $calendar['lifecycle_status'] !== 'draft' || (int) $calendar['status'] !== 1) {
            throw new RuntimeException('Only an active draft calendar can be finalized.');
        }
        if ($expectedLockVersion !== null && (int) ($calendar['lock_version'] ?? 0) !== $expectedLockVersion) {
            throw new RuntimeException('Another user changed this calendar. Reload the page and finalize again.');
        }
        $days = acBuildCalendarDays($conn, $calendarId);
        $expectedDays = ((int) $calendar['calendar_year'] % 4 === 0
            && ((int) $calendar['calendar_year'] % 100 !== 0 || (int) $calendar['calendar_year'] % 400 === 0)) ? 366 : 365;
        if (count($days) !== $expectedDays) {
            throw new RuntimeException('The calendar does not cover the complete year.');
        }
        $totals = acTotalsFromDays($days);
        if ($totals['total_working_days'] <= 0) {
            throw new RuntimeException('The calendar must contain at least one working day.');
        }
        $hash = acPersistCalendarDays($conn, $calendar, $days);
        $companyId = (int) $calendar['company_id'];
        $year = (int) $calendar['calendar_year'];
        $supersede = $conn->prepare(
            "UPDATE hr_annual_calendars SET lifecycle_status = 'superseded', is_finalized = 0, updated_by = ?, updated_at = NOW()
             WHERE company_id = ? AND calendar_year = ? AND lifecycle_status = 'finalized' AND id <> ?"
        );
        $supersede->bind_param('iiii', $userId, $companyId, $year, $calendarId);
        $supersede->execute();
        $supersede->close();

        $hasHardeningColumns = acColumnExists($conn, 'hr_annual_calendars', 'total_declared_holidays');
        $sql = "UPDATE hr_annual_calendars SET lifecycle_status = 'finalized', is_finalized = 1,
             finalized_by = ?, finalized_at = NOW(), content_hash = ?, total_days = ?, total_sundays = ?,
             total_saturday_offs = ?, total_holidays = ?, total_working_days = ?";
        if ($hasHardeningColumns) {
            $sql .= ', total_declared_holidays = ?, total_optional_holidays = ?';
        }
        $sql .= ", updated_by = ?, updated_at = NOW() WHERE id = ? AND lifecycle_status = 'draft'";
        $update = $conn->prepare($sql);
        if ($hasHardeningColumns) {
            $update->bind_param(
                'isiiiiiiiii',
                $userId,
                $hash,
                $totals['total_days'],
                $totals['total_sundays'],
                $totals['total_saturday_offs'],
                $totals['total_holidays'],
                $totals['total_working_days'],
                $totals['total_declared_holidays'],
                $totals['total_optional_holidays'],
                $userId,
                $calendarId
            );
        } else {
            $update->bind_param(
                'isiiiiiii',
                $userId,
                $hash,
                $totals['total_days'],
                $totals['total_sundays'],
                $totals['total_saturday_offs'],
                $totals['total_holidays'],
                $totals['total_working_days'],
                $userId,
                $calendarId
            );
        }
        if (!$update->execute() || $update->affected_rows !== 1) {
            throw new RuntimeException('The calendar changed while it was being finalized. Reload and try again.');
        }
        $update->close();
        acLogAudit($conn, $calendarId, 'finalize', 'lifecycle_status', 'draft', 'finalized', $userId, 'Calendar validated and finalized');
        $conn->commit();
        return ['content_hash' => $hash, 'totals' => $totals, 'days' => $days];
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function acCreateDraftRevision(
    mysqli $conn,
    int $calendarId,
    int $userId,
    string $reason,
    bool $payrollImpactAcknowledged = false
): int {
    $reason = acValidReason($reason);
    $conn->begin_transaction();
    try {
        $source = acCalendarById($conn, $calendarId, true);
        if (!$source || $source['lifecycle_status'] !== 'finalized' || (int) $source['is_finalized'] !== 1) {
            throw new RuntimeException('Only the current finalized calendar can be reopened.');
        }
        $payrollRuns = acCalendarPayrollRuns($conn, $calendarId);
        $usedByPayroll = $payrollRuns !== [];
        if ($usedByPayroll && !$payrollImpactAcknowledged) {
            throw new RuntimeException(
                'This revision is locked to finalized payroll run(s) '
                . implode(', ', array_column($payrollRuns, 'run_number'))
                . '. Confirm the payroll impact acknowledgement to create a corrected revision.'
            );
        }
        $companyId = (int) $source['company_id'];
        $year = (int) $source['calendar_year'];
        $maxStmt = $conn->prepare('SELECT COALESCE(MAX(revision_no), 0) max_revision FROM hr_annual_calendars WHERE company_id = ? AND calendar_year = ? FOR UPDATE');
        $maxStmt->bind_param('ii', $companyId, $year);
        $maxStmt->execute();
        $revision = (int) ($maxStmt->get_result()->fetch_assoc()['max_revision'] ?? 0) + 1;
        $maxStmt->close();

        $existingDraft = $conn->prepare("SELECT id FROM hr_annual_calendars WHERE company_id = ? AND calendar_year = ? AND lifecycle_status = 'draft' AND deleted_at IS NULL LIMIT 1");
        $existingDraft->bind_param('ii', $companyId, $year);
        $existingDraft->execute();
        if ($existingDraft->get_result()->fetch_assoc()) {
            $existingDraft->close();
            throw new RuntimeException('A draft revision already exists for this company and year.');
        }
        $existingDraft->close();

        $newCalendarId = acInsertDraftRevision($conn, $source, $companyId, $year, $revision, $calendarId, $userId);
        acCloneCalendarChildren($conn, $calendarId, $newCalendarId, $userId);
        acRecalculateWorkingDays($conn, $newCalendarId);
        acLogAudit(
            $conn,
            $newCalendarId,
            'create_revision',
            'revision_no',
            (string) $source['revision_no'],
            (string) $revision,
            $userId,
            $reason . ($usedByPayroll
                ? ' (payroll impact acknowledged for run(s): ' . implode(', ', array_column($payrollRuns, 'run_number')) . ')'
                : ''),
            null,
            $usedByPayroll ? ['locked_payroll_runs' => $payrollRuns] : null
        );
        $conn->commit();
        return $newCalendarId;
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function acInsertDraftRevision(
    mysqli $conn,
    array $source,
    int $companyId,
    int $year,
    int $revision,
    ?int $supersedesId,
    int $userId
): int {
    acDropObsoleteIndexes($conn);
    $hasWeeklyOffColumn = acColumnExists($conn, 'hr_annual_calendars', 'weekly_off_days');
    $columns = 'company_id, calendar_year, revision_no, saturday_policy, lifecycle_status, supersedes_id,
                status, created_by, created_at, source_name, source_version';
    $values = "?, ?, ?, ?, 'draft', ?, 1, ?, NOW(), ?, ?";
    $types = 'iiisiiss';
    $saturdayPolicy = (string) $source['saturday_policy'];
    $sourceName = $source['source_name'] ?? null;
    $sourceVersion = $source['source_version'] ?? null;
    $params = [$companyId, $year, $revision, $saturdayPolicy, $supersedesId, $userId, $sourceName, $sourceVersion];
    if ($hasWeeklyOffColumn) {
        $columns .= ', weekly_off_days';
        $values .= ', ?';
        $types .= 's';
        $params[] = implode(',', acParseWeeklyOffDays($source['weekly_off_days'] ?? '7'));
    }
    $insert = $conn->prepare("INSERT INTO hr_annual_calendars ({$columns}) VALUES ({$values})");
    $insert->bind_param($types, ...$params);
    if (!$insert->execute()) {
        throw new RuntimeException('Unable to create a new calendar revision.');
    }
    $newCalendarId = (int) $insert->insert_id;
    $insert->close();
    return $newCalendarId;
}

function acCloneCalendarChildren(mysqli $conn, int $sourceCalendarId, int $targetCalendarId, int $userId): void
{
    $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_holidays', 'is_optional');
    $cloneHolidays = $conn->prepare(
        $hasOptionalColumn
            ? 'INSERT INTO hr_annual_calendar_holidays
               (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, is_optional, created_by, created_at)
               SELECT ?, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, is_optional, ?, NOW()
               FROM hr_annual_calendar_holidays WHERE calendar_id = ? AND deleted_at IS NULL'
            : 'INSERT INTO hr_annual_calendar_holidays
               (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
               SELECT ?, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, ?, NOW()
               FROM hr_annual_calendar_holidays WHERE calendar_id = ? AND deleted_at IS NULL'
    );
    $cloneHolidays->bind_param('iii', $targetCalendarId, $userId, $sourceCalendarId);
    $cloneHolidays->execute();
    $cloneHolidays->close();

    $cloneOffs = $conn->prepare(
        'INSERT INTO hr_annual_calendar_custom_offs (calendar_id, off_date, off_name, created_by, created_at)
         SELECT ?, off_date, off_name, ?, NOW() FROM hr_annual_calendar_custom_offs WHERE calendar_id = ?'
    );
    $cloneOffs->bind_param('iii', $targetCalendarId, $userId, $sourceCalendarId);
    $cloneOffs->execute();
    $cloneOffs->close();

    if (acTableExists($conn, 'hr_annual_calendar_day_overrides')) {
        $cloneOverrides = $conn->prepare(
            'INSERT INTO hr_annual_calendar_day_overrides (calendar_id, override_date, override_type, note, created_by, created_at)
             SELECT ?, override_date, override_type, note, ?, NOW() FROM hr_annual_calendar_day_overrides WHERE calendar_id = ?'
        );
        $cloneOverrides->bind_param('iii', $targetCalendarId, $userId, $sourceCalendarId);
        $cloneOverrides->execute();
        $cloneOverrides->close();
    }
}

/**
 * Copies the newest calendar of a source year into a fresh draft for the target
 * year, shifting fixed-date holidays and dropping dates that do not exist.
 */
function acCopyCalendarFromYear(mysqli $conn, int $companyId, int $sourceYear, int $targetYear, int $userId): int
{
    if ($sourceYear === $targetYear) {
        throw new InvalidArgumentException('Select a different source year.');
    }
    $conn->begin_transaction();
    try {
        if (acGetCalendarForYear($conn, $companyId, $targetYear)) {
            throw new InvalidArgumentException('An active calendar already exists for this company and year.');
        }
        $sourceStmt = $conn->prepare(
            "SELECT * FROM hr_annual_calendars
             WHERE company_id = ? AND calendar_year = ? AND deleted_at IS NULL
             ORDER BY CASE lifecycle_status WHEN 'finalized' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END, revision_no DESC LIMIT 1"
        );
        $sourceStmt->bind_param('ii', $companyId, $sourceYear);
        $sourceStmt->execute();
        $source = $sourceStmt->get_result()->fetch_assoc();
        $sourceStmt->close();
        if (!$source) {
            throw new InvalidArgumentException("No calendar exists for {$sourceYear} to copy from.");
        }

        $sourceCalendarId = (int) $source['id'];
        $newCalendarId = acInsertDraftRevision($conn, $source, $companyId, $targetYear, 1, null, $userId);

        // Custom weekly-off dates and day overrides are year specific, so only holidays carry over.
        $holidayStmt = $conn->prepare(
            'SELECT holiday_date, holiday_name, holiday_type, is_enabled FROM hr_annual_calendar_holidays
             WHERE calendar_id = ? AND deleted_at IS NULL ORDER BY holiday_date'
        );
        $holidayStmt->bind_param('i', $sourceCalendarId);
        $holidayStmt->execute();
        $holidays = $holidayStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $holidayStmt->close();

        $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_holidays', 'is_optional');
        $insert = $conn->prepare(
            $hasOptionalColumn
                ? 'INSERT IGNORE INTO hr_annual_calendar_holidays
                   (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, is_optional, created_by, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
                : 'INSERT IGNORE INTO hr_annual_calendar_holidays
                   (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())'
        );
        $sourceName = "Copied from {$sourceYear}";
        $sourceVersion = date('Y-m-d');
        $copied = 0;
        foreach ($holidays as $holiday) {
            $shifted = $targetYear . substr((string) $holiday['holiday_date'], 4);
            if (!checkdate((int) substr($shifted, 5, 2), (int) substr($shifted, 8, 2), $targetYear)) {
                continue;
            }
            $name = (string) $holiday['holiday_name'];
            $type = (string) $holiday['holiday_type'];
            $enabled = (int) $holiday['is_enabled'];
            $optional = $type === 'restricted' ? 1 : 0;
            if ($hasOptionalColumn) {
                $insert->bind_param('isssssiii', $newCalendarId, $shifted, $name, $type, $sourceName, $sourceVersion, $enabled, $optional, $userId);
            } else {
                $insert->bind_param('isssssii', $newCalendarId, $shifted, $name, $type, $sourceName, $sourceVersion, $enabled, $userId);
            }
            $insert->execute();
            $copied += max(0, $insert->affected_rows);
        }
        $insert->close();

        acRecalculateWorkingDays($conn, $newCalendarId);
        acLogAudit(
            $conn,
            $newCalendarId,
            'copy_from_year',
            'calendar_year',
            (string) $sourceYear,
            (string) $targetYear,
            $userId,
            "Copied {$copied} holiday(s) from {$sourceYear}. Verify every date before finalizing."
        );
        $conn->commit();
        return $newCalendarId;
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function acDiscardDraftRevision(mysqli $conn, int $calendarId, int $userId, string $reason): void
{
    $reason = acValidReason($reason);
    $conn->begin_transaction();
    try {
        $calendar = acCalendarById($conn, $calendarId, true);
        if (!$calendar || $calendar['lifecycle_status'] !== 'draft') {
            throw new RuntimeException('Only a draft revision can be discarded.');
        }
        acLogAudit($conn, $calendarId, 'discard_draft', 'lifecycle_status', 'draft', 'deleted', $userId, $reason);
        $stmt = $conn->prepare(
            'UPDATE hr_annual_calendars SET deleted_at = NOW(), deleted_by = ?, status = 0, updated_by = ?, updated_at = NOW()
             WHERE id = ? AND lifecycle_status = ?'
        );
        $draft = 'draft';
        $stmt->bind_param('iiis', $userId, $userId, $calendarId, $draft);
        if (!$stmt->execute() || $stmt->affected_rows !== 1) {
            throw new RuntimeException('The draft changed while it was being discarded. Reload and try again.');
        }
        $stmt->close();
        $conn->commit();
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function acCalendarUsedByPayroll(mysqli $conn, int $calendarId): bool
{
    return acCalendarPayrollRuns($conn, $calendarId) !== [];
}

/**
 * @return array<int, array{id:int, run_number:string, payroll_month:string}>
 */
function acCalendarPayrollRuns(mysqli $conn, int $calendarId): array
{
    if (!acColumnExists($conn, 'payroll_runs', 'calendar_revision_id')) {
        return [];
    }
    $stmt = $conn->prepare(
        'SELECT id, run_number, payroll_month FROM payroll_runs
         WHERE calendar_revision_id = ? ORDER BY payroll_month LIMIT 50'
    );
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $runs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return array_map(
        static fn(array $run): array => [
            'id' => (int) $run['id'],
            'run_number' => (string) $run['run_number'],
            'payroll_month' => (string) $run['payroll_month'],
        ],
        $runs
    );
}

/**
 * Returns the calendar revision a closed payroll period was calculated against
 * so historical reports never shift when HR publishes a corrected revision.
 */
function acPinnedCalendarIdForPeriod(mysqli $conn, int $companyId, string $firstDate, string $lastDate): ?int
{
    if (!acColumnExists($conn, 'payroll_runs', 'calendar_revision_id')) {
        return null;
    }
    $stmt = $conn->prepare(
        "SELECT run.calendar_revision_id
         FROM payroll_runs run
         INNER JOIN hr_annual_calendars calendar ON calendar.id = run.calendar_revision_id
         WHERE run.company_id = ? AND run.calendar_revision_id IS NOT NULL
           AND CONCAT(run.payroll_month, '-01') <= ?
           AND LAST_DAY(CONCAT(run.payroll_month, '-01')) >= ?
         ORDER BY run.generated_at DESC, run.id DESC LIMIT 1"
    );
    $stmt->bind_param('iss', $companyId, $lastDate, $firstDate);
    $stmt->execute();
    $pinned = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $pinned && !empty($pinned['calendar_revision_id']) ? (int) $pinned['calendar_revision_id'] : null;
}

function acGetFinalizedDaysForRange(mysqli $conn, int $companyId, string $firstDate, string $lastDate): ?array
{
    acValidDate($firstDate);
    acValidDate($lastDate);
    if ($firstDate > $lastDate || substr($firstDate, 0, 4) !== substr($lastDate, 0, 4)) {
        throw new InvalidArgumentException('Calendar range must be within one year.');
    }
    $pinnedCalendarId = acPinnedCalendarIdForPeriod($conn, $companyId, $firstDate, $lastDate);
    $calendar = $pinnedCalendarId !== null
        ? acCalendarById($conn, $pinnedCalendarId)
        : acGetFinalizedCalendarForYear($conn, $companyId, (int) substr($firstDate, 0, 4));
    if (!$calendar || (int) $calendar['company_id'] !== $companyId) {
        $calendar = acGetFinalizedCalendarForYear($conn, $companyId, (int) substr($firstDate, 0, 4));
    }
    if (!$calendar) {
        return null;
    }
    $calendarId = (int) $calendar['id'];
    $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_days', 'is_optional_holiday');
    $optionalSelect = $hasOptionalColumn ? 'is_optional_holiday' : '0 AS is_optional_holiday';
    $stmt = $conn->prepare(
        "SELECT calendar_date, day_of_week, day_type, is_working, is_weekly_off, is_holiday, {$optionalSelect},
                holiday_names, holiday_types
         FROM hr_annual_calendar_days WHERE calendar_id = ? AND calendar_date BETWEEN ? AND ? ORDER BY calendar_date"
    );
    $stmt->bind_param('iss', $calendarId, $firstDate, $lastDate);
    $stmt->execute();
    $days = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    $expected = (int) floor((strtotime($lastDate) - strtotime($firstDate)) / 86400) + 1;
    if (count($days) !== $expected) {
        throw new RuntimeException('The finalized calendar day ledger is incomplete. Ask HR to create a corrected revision.');
    }
    acAssertLedgerIntegrity($conn, $calendar);
    return ['calendar' => $calendar, 'days' => $days, 'is_pinned' => $pinnedCalendarId === $calendarId];
}

/**
 * Recomputes the stored content hash so out-of-band edits to the day ledger are
 * detected before payroll, leave or attendance consume it.
 */
function acAssertLedgerIntegrity(mysqli $conn, array $calendar): void
{
    static $verified = [];
    $calendarId = (int) $calendar['id'];
    if (isset($verified[$calendarId])) {
        return;
    }
    $storedHash = (string) ($calendar['content_hash'] ?? '');
    if ($storedHash === '') {
        $verified[$calendarId] = true;
        return;
    }
    $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_days', 'is_optional_holiday');
    $optionalSelect = $hasOptionalColumn ? 'is_optional_holiday' : '0 AS is_optional_holiday';
    $stmt = $conn->prepare(
        "SELECT calendar_date, day_type, is_holiday, {$optionalSelect}, holiday_names, holiday_types
         FROM hr_annual_calendar_days WHERE calendar_id = ? ORDER BY calendar_date"
    );
    $stmt->bind_param('i', $calendarId);
    $stmt->execute();
    $days = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    if (!hash_equals($storedHash, acCalendarLedgerHash($days))) {
        throw new RuntimeException(
            'The finalized Annual Calendar ledger failed its integrity check. Ask HR to publish a corrected revision.'
        );
    }
    $verified[$calendarId] = true;
}

function acRequireFinalizedDaysForRange(mysqli $conn, int $companyId, string $firstDate, string $lastDate): array
{
    $result = acGetFinalizedDaysForRange($conn, $companyId, $firstDate, $lastDate);
    if ($result === null) {
        throw new RuntimeException(
            'The Annual Calendar for ' . substr($firstDate, 0, 4) . ' has not been finalized yet. '
            . 'Open Annual Calendar & Working Days, then click Finalize — saving a draft is not enough, '
            . 'because leave and payroll read the finalized day ledger.'
        );
    }
    return $result;
}

function acGetHolidayDatesForRange(mysqli $conn, string $firstDate, string $lastDate, ?int $companyId = null): ?array
{
    if ($companyId === null || $companyId <= 0 || !acProductionSchemaReady($conn)) {
        return null;
    }
    $result = acGetFinalizedDaysForRange($conn, $companyId, $firstDate, $lastDate);
    if ($result === null) {
        return null;
    }
    return array_values(array_map(
        static fn(array $day): string => $day['calendar_date'],
        array_filter($result['days'], static fn(array $day): bool => $day['day_type'] === 'holiday')
    ));
}

function acGetSaturdayOffsForRange(mysqli $conn, string $firstDate, string $lastDate, ?int $companyId = null): array
{
    if ($companyId === null || $companyId <= 0 || !acProductionSchemaReady($conn)) {
        return [];
    }
    $result = acGetFinalizedDaysForRange($conn, $companyId, $firstDate, $lastDate);
    if ($result === null) {
        return [];
    }
    return array_values(array_map(
        static fn(array $day): string => $day['calendar_date'],
        array_filter(
            $result['days'],
            static fn(array $day): bool => $day['day_type'] === 'weekly_off' && (int) $day['day_of_week'] === 6
        )
    ));
}

function acGetDayForCompanyDate(mysqli $conn, int $companyId, string $date): ?array
{
    $result = acGetFinalizedDaysForRange($conn, $companyId, $date, $date);
    return $result === null ? null : ($result['days'][0] ?? null);
}

function acFilterChargeableLeaveDays(mysqli $conn, int $companyId, array $days): array
{
    if ($days === []) {
        return [];
    }
    $firstDate = (string) $days[0]['date'];
    $lastDate = (string) $days[count($days) - 1]['date'];
    $calendarResult = acRequireFinalizedDaysForRange($conn, $companyId, $firstDate, $lastDate);
    $dayMap = [];
    foreach ($calendarResult['days'] as $calendarDay) {
        $dayMap[$calendarDay['calendar_date']] = $calendarDay;
    }
    $chargeable = [];
    foreach ($days as $day) {
        $calendarDay = $dayMap[$day['date']] ?? null;
        if ($calendarDay && (int) $calendarDay['is_working'] === 1) {
            $day['calendar_day_type'] = 'working_day';
            $day['is_chargeable'] = 1;
            $chargeable[] = $day;
        }
    }
    return $chargeable;
}
