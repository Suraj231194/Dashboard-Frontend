<?php

declare(strict_types=1);

if (!defined('HRMS_CONTEXT')) {
    http_response_code(404);
    exit;
}

function acApiAssertCompanyAccess(array $scope, int $companyId): void
{
    if ($companyId <= 0 || ($scope['company_id'] !== null && (int) $scope['company_id'] !== $companyId)) {
        hrmsJson(['status' => 'error', 'message' => 'This calendar belongs to another organization.'], 403);
    }
}

function acApiRequireCalendar(mysqli $conn, int $calendarId, array $scope, bool $draftOnly = false, bool $forUpdate = false): array
{
    $calendar = acCalendarById($conn, $calendarId, $forUpdate);
    if (!$calendar) {
        throw new InvalidArgumentException('Calendar not found.');
    }
    acApiAssertCompanyAccess($scope, (int) $calendar['company_id']);
    if ($draftOnly && $calendar['lifecycle_status'] !== 'draft') {
        throw new RuntimeException('Finalized calendar revisions are immutable. Create a new draft revision to make changes.');
    }
    return $calendar;
}

function acApiCompanies(mysqli $conn, array $scope): array
{
    if ($scope['company_id'] !== null) {
        $companyId = (int) $scope['company_id'];
        $stmt = $conn->prepare('SELECT id, company_name FROM erp_companies WHERE id = ? AND status = 1 AND deleted_at IS NULL');
        $stmt->bind_param('i', $companyId);
        $stmt->execute();
        $companies = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $companies;
    }
    $result = $conn->query('SELECT id, company_name FROM erp_companies WHERE status = 1 AND deleted_at IS NULL ORDER BY company_name');
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

function acApiPayload(mysqli $conn, array $calendar): array
{
    $days = acBuildCalendarDays($conn, (int) $calendar['id']);
    if (!array_key_exists('holidays', $calendar)) {
        $calendar = acAttachCalendarChildren($conn, $calendar);
    }
    $payrollRuns = acCalendarPayrollRuns($conn, (int) $calendar['id']);
    $calendar['used_by_payroll'] = $payrollRuns !== [] ? 1 : 0;
    return [
        'calendar' => $calendar,
        'days' => $days,
        'totals' => acTotalsFromDays($days),
        'monthly' => acMonthlyBreakdownFromDays($days),
        'payroll_runs' => $payrollRuns,
        'saturday_offs' => array_values(array_map(
            static fn(array $day): string => $day['calendar_date'],
            array_filter($days, static fn(array $day): bool => (int) $day['is_weekly_off'] === 1 && (int) $day['day_of_week'] === 6)
        )),
        'audit_events' => acGetAuditEvents($conn, (int) $calendar['company_id'], (int) $calendar['calendar_year']),
    ];
}

function acHandleApiAction(mysqli $conn, string $action, int $userId): bool
{
    $actions = [
        'load_annual_calendar', 'initialize_annual_calendar', 'update_saturday_policy',
        'update_weekly_off_days', 'save_custom_weekly_offs', 'add_calendar_holiday',
        'update_calendar_holiday', 'delete_calendar_holiday', 'toggle_calendar_holiday',
        'save_calendar_day_override', 'delete_calendar_day_override',
        'copy_calendar_from_year', 'discard_calendar_draft',
        'finalize_annual_calendar', 'unfinalize_annual_calendar',
        'get_calendar_monthly_summary', 'import_default_holidays', 'import_holiday_csv',
    ];
    if (!in_array($action, $actions, true)) {
        return false;
    }
    if (!acProductionSchemaReady($conn)) {
        throw new RuntimeException('Annual Calendar production migration has not been applied.');
    }

    $scope = hrmsCurrentScope($conn, $userId);

    switch ($action) {
        case 'load_annual_calendar':
            hrmsRequirePermission($conn, 'hrms_calendar_view');
            $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
            $year = filter_var($_POST['year'] ?? null, FILTER_VALIDATE_INT);
            if (!$companyId || !$year || $year < 2020 || $year > 2100) {
                throw new InvalidArgumentException('Select a valid company and year.');
            }
            acApiAssertCompanyAccess($scope, (int) $companyId);
            $calendar = acGetCalendarForYear($conn, (int) $companyId, (int) $year);
            if (!$calendar) {
                hrmsJson([
                    'status' => 'success', 'exists' => false, 'companies' => acApiCompanies($conn, $scope),
                    'year' => (int) $year, 'company_id' => (int) $companyId,
                ]);
            }
            hrmsJson(array_merge(
                ['status' => 'success', 'exists' => true, 'companies' => acApiCompanies($conn, $scope)],
                acApiPayload($conn, $calendar)
            ));

        case 'initialize_annual_calendar':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
            $year = filter_var($_POST['year'] ?? null, FILTER_VALIDATE_INT);
            if (!$companyId || !$year || $year < 2020 || $year > 2100) {
                throw new InvalidArgumentException('Select a valid company and year.');
            }
            acApiAssertCompanyAccess($scope, (int) $companyId);
            if (acGetCalendarForYear($conn, (int) $companyId, (int) $year)) {
                throw new InvalidArgumentException('An active calendar already exists for this company and year.');
            }
            $conn->begin_transaction();
            try {
                $policy = 'all_working';
                $sourceName = 'Care IO India holiday reference';
                $sourceVersion = '2026.09';
                $stmt = $conn->prepare(
                    "INSERT INTO hr_annual_calendars
                     (company_id, calendar_year, revision_no, saturday_policy, lifecycle_status, status,
                      created_by, created_at, source_name, source_version)
                     VALUES (?, ?, 1, ?, 'draft', 1, ?, NOW(), ?, ?)"
                );
                $stmt->bind_param('iisiss', $companyId, $year, $policy, $userId, $sourceName, $sourceVersion);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to initialize the annual calendar.');
                }
                $calendarId = (int) $stmt->insert_id;
                $stmt->close();

                $insertHoliday = $conn->prepare(
                    'INSERT INTO hr_annual_calendar_holidays
                     (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
                );
                foreach (acGetIndianHolidays((int) $year) as $holiday) {
                    $insertHoliday->bind_param(
                        'isssssi', $calendarId, $holiday['date'], $holiday['name'], $holiday['type'],
                        $holiday['source_name'], $holiday['source_version'], $userId
                    );
                    if (!$insertHoliday->execute()) {
                        throw new RuntimeException('Unable to import the suggested holidays.');
                    }
                }
                $insertHoliday->close();
                acRecalculateWorkingDays($conn, $calendarId);
                acLogAudit($conn, $calendarId, 'initialize', null, null, 'draft revision 1', $userId, 'Initial annual calendar creation');
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            $calendar = acGetCalendarForYear($conn, (int) $companyId, (int) $year);
            hrmsJson(array_merge(
                ['status' => 'success', 'message' => 'Draft calendar initialized. Review all suggested holidays before finalization.'],
                acApiPayload($conn, $calendar)
            ));

        case 'update_saturday_policy':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            $policy = trim((string) ($_POST['saturday_policy'] ?? ''));
            if (!$calendarId || !in_array($policy, ['all_working', 'all_off', '2nd_4th_off', 'alternate_off', 'custom'], true)) {
                throw new InvalidArgumentException('Select a valid weekly-off policy.');
            }
            $conn->begin_transaction();
            try {
                $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $oldPolicy = (string) $calendar['saturday_policy'];
                $stmt = $conn->prepare('UPDATE hr_annual_calendars SET saturday_policy = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt->bind_param('sii', $policy, $userId, $calendarId);
                $stmt->execute();
                $stmt->close();
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit($conn, (int) $calendarId, 'update_weekly_off_policy', 'saturday_policy', $oldPolicy, $policy, $userId);
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Weekly-off policy updated.', 'totals' => $totals]);

        case 'update_weekly_off_days':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            if (!acHardeningSchemaReady($conn)) {
                throw new RuntimeException('Annual Calendar hardening migration has not been applied.');
            }
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            $decodedDays = json_decode((string) ($_POST['weekly_off_days'] ?? '[]'), true);
            if (!$calendarId || !is_array($decodedDays)) {
                throw new InvalidArgumentException('Select at least one weekly-off day.');
            }
            $weeklyOffDays = acValidWeeklyOffDays($decodedDays);
            $conn->begin_transaction();
            try {
                $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $oldDays = implode(',', acParseWeeklyOffDays($calendar['weekly_off_days'] ?? '7'));
                $newDays = implode(',', $weeklyOffDays);
                $stmt = $conn->prepare('UPDATE hr_annual_calendars SET weekly_off_days = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                $stmt->bind_param('sii', $newDays, $userId, $calendarId);
                $stmt->execute();
                $stmt->close();
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit($conn, (int) $calendarId, 'update_weekly_off_days', 'weekly_off_days', $oldDays, $newDays, $userId);
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Weekly-off days updated.', 'totals' => $totals]);

        case 'save_calendar_day_override':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            if (!acHardeningSchemaReady($conn)) {
                throw new RuntimeException('Annual Calendar hardening migration has not been applied.');
            }
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true);
            $overrideDate = acValidDate(trim((string) ($_POST['override_date'] ?? '')), (int) $calendar['calendar_year']);
            $overrideType = acValidOverrideType(trim((string) ($_POST['override_type'] ?? '')));
            $note = trim((string) ($_POST['note'] ?? ''));
            if (mb_strlen($note) > 200) {
                throw new InvalidArgumentException('The override note must be 200 characters or fewer.');
            }
            $conn->begin_transaction();
            try {
                acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $stmt = $conn->prepare(
                    'INSERT INTO hr_annual_calendar_day_overrides (calendar_id, override_date, override_type, note, created_by)
                     VALUES (?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE override_type = VALUES(override_type), note = VALUES(note), created_by = VALUES(created_by)'
                );
                $stmt->bind_param('isssi', $calendarId, $overrideDate, $overrideType, $note, $userId);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to save the day override.');
                }
                $stmt->close();
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit(
                    $conn, (int) $calendarId, 'save_day_override', 'day_override', null,
                    "{$overrideDate}: {$overrideType}", $userId, $note !== '' ? $note : null
                );
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Day override saved.', 'totals' => $totals]);

        case 'delete_calendar_day_override':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            if (!acHardeningSchemaReady($conn)) {
                throw new RuntimeException('Annual Calendar hardening migration has not been applied.');
            }
            $overrideId = filter_var($_POST['override_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$overrideId) {
                throw new InvalidArgumentException('Invalid day override.');
            }
            $conn->begin_transaction();
            try {
                $lookup = $conn->prepare(
                    'SELECT override.calendar_id, override.override_date, override.override_type, calendar.company_id, calendar.lifecycle_status
                     FROM hr_annual_calendar_day_overrides override
                     INNER JOIN hr_annual_calendars calendar ON calendar.id = override.calendar_id
                     WHERE override.id = ? AND calendar.deleted_at IS NULL FOR UPDATE'
                );
                $lookup->bind_param('i', $overrideId);
                $lookup->execute();
                $existing = $lookup->get_result()->fetch_assoc();
                $lookup->close();
                if (!$existing) {
                    throw new InvalidArgumentException('Day override not found.');
                }
                acApiAssertCompanyAccess($scope, (int) $existing['company_id']);
                if ($existing['lifecycle_status'] !== 'draft') {
                    throw new RuntimeException('Finalized calendar revisions are immutable. Create a draft revision first.');
                }
                $delete = $conn->prepare('DELETE FROM hr_annual_calendar_day_overrides WHERE id = ?');
                $delete->bind_param('i', $overrideId);
                $delete->execute();
                $delete->close();
                $calendarId = (int) $existing['calendar_id'];
                $totals = acRecalculateWorkingDays($conn, $calendarId);
                acLogAudit(
                    $conn, $calendarId, 'delete_day_override', 'day_override',
                    "{$existing['override_date']}: {$existing['override_type']}", null, $userId
                );
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Day override removed.', 'totals' => $totals]);

        case 'copy_calendar_from_year':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $companyId = filter_var($_POST['company_id'] ?? null, FILTER_VALIDATE_INT);
            $sourceYear = filter_var($_POST['source_year'] ?? null, FILTER_VALIDATE_INT);
            $targetYear = filter_var($_POST['year'] ?? null, FILTER_VALIDATE_INT);
            if (!$companyId || !$sourceYear || !$targetYear
                || $sourceYear < 2020 || $sourceYear > 2100 || $targetYear < 2020 || $targetYear > 2100) {
                throw new InvalidArgumentException('Select a valid company, source year and target year.');
            }
            acApiAssertCompanyAccess($scope, (int) $companyId);
            $newCalendarId = acCopyCalendarFromYear($conn, (int) $companyId, (int) $sourceYear, (int) $targetYear, $userId);
            $calendar = acCalendarById($conn, $newCalendarId);
            hrmsJson(array_merge(
                [
                    'status' => 'success',
                    'message' => "Draft calendar created from {$sourceYear}. Verify every holiday date before finalizing.",
                ],
                acApiPayload($conn, $calendar)
            ));

        case 'discard_calendar_draft':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            $reason = acValidReason((string) ($_POST['reason'] ?? ''));
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            acApiRequireCalendar($conn, (int) $calendarId, $scope, true);
            acDiscardDraftRevision($conn, (int) $calendarId, $userId, $reason);
            hrmsJson(['status' => 'success', 'message' => 'Draft revision discarded.']);

        case 'import_holiday_csv':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true);
            $file = $_FILES['holiday_file'] ?? null;
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                throw new InvalidArgumentException('Select a holiday CSV file to import.');
            }
            if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
                throw new RuntimeException('The holiday file upload did not complete successfully.');
            }
            $fileSize = (int) ($file['size'] ?? 0);
            if ($fileSize <= 0 || $fileSize > 1024 * 1024) {
                throw new InvalidArgumentException('Holiday files must be smaller than 1 MB.');
            }
            $tmpName = (string) ($file['tmp_name'] ?? '');
            if ($tmpName === '' || !is_uploaded_file($tmpName)) {
                throw new RuntimeException('The uploaded file is not valid.');
            }
            if (strtolower(pathinfo(basename((string) ($file['name'] ?? '')), PATHINFO_EXTENSION)) !== 'csv') {
                throw new InvalidArgumentException('The holiday list must be a .csv file.');
            }
            $csvContent = file_get_contents($tmpName);
            if ($csvContent === false) {
                throw new RuntimeException('The holiday file could not be read.');
            }
            $parsed = acParseHolidayCsv($csvContent, (int) $calendar['calendar_year']);

            $jurisdiction = trim((string) ($_POST['jurisdiction'] ?? ''));
            if ($jurisdiction === '' || mb_strlen($jurisdiction) > 60) {
                throw new InvalidArgumentException('Enter the jurisdiction this holiday list applies to (2-60 characters).');
            }
            $datasetVersion = trim((string) ($_POST['dataset_version'] ?? ''));
            if ($datasetVersion === '' || mb_strlen($datasetVersion) > 40) {
                $datasetVersion = date('Y-m-d');
            }

            if ((string) ($_POST['confirm'] ?? '') !== '1') {
                hrmsJson([
                    'status' => 'success',
                    'preview' => true,
                    'rows' => $parsed['rows'],
                    'errors' => $parsed['errors'],
                    'message' => count($parsed['rows']) . ' row(s) ready, ' . count($parsed['errors']) . ' rejected. Confirm to import.',
                ]);
            }
            if ($parsed['rows'] === []) {
                throw new InvalidArgumentException('There are no valid rows to import.');
            }

            $conn->begin_transaction();
            try {
                acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $result = acImportHolidayRows(
                    $conn,
                    (int) $calendarId,
                    $parsed['rows'],
                    $userId,
                    'CSV import: ' . $jurisdiction,
                    $datasetVersion
                );
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit(
                    $conn,
                    (int) $calendarId,
                    'import_holiday_csv',
                    'holidays',
                    null,
                    "Imported {$result['imported']} holiday(s) for {$jurisdiction} (version {$datasetVersion})",
                    $userId,
                    count($parsed['errors']) . ' row(s) were rejected during validation.',
                    null,
                    ['jurisdiction' => $jurisdiction, 'dataset_version' => $datasetVersion, 'rejected' => $parsed['errors']]
                );
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson([
                'status' => 'success',
                'preview' => false,
                'message' => "Imported {$result['imported']} holiday(s); {$result['skipped']} already existed.",
                'errors' => $parsed['errors'],
                'totals' => $totals,
            ]);

        case 'save_custom_weekly_offs':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            $decoded = json_decode((string) ($_POST['off_dates'] ?? '[]'), true);
            if (!$calendarId || !is_array($decoded)) {
                throw new InvalidArgumentException('Provide valid custom weekly-off dates.');
            }
            $conn->begin_transaction();
            try {
                $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $year = (int) $calendar['calendar_year'];
                $dates = [];
                foreach ($decoded as $value) {
                    $dates[] = acValidDate(trim((string) $value), $year);
                }
                $dates = array_values(array_unique($dates));
                sort($dates);
                if (count($dates) > 366) {
                    throw new InvalidArgumentException('Too many custom weekly-off dates were supplied.');
                }
                $oldDates = acGetCustomOffDates($conn, (int) $calendarId);
                $delete = $conn->prepare('DELETE FROM hr_annual_calendar_custom_offs WHERE calendar_id = ?');
                $delete->bind_param('i', $calendarId);
                $delete->execute();
                $delete->close();
                if ($dates !== []) {
                    $insert = $conn->prepare('INSERT INTO hr_annual_calendar_custom_offs (calendar_id, off_date, off_name, created_by) VALUES (?, ?, ?, ?)');
                    $name = 'Custom weekly off';
                    foreach ($dates as $date) {
                        $insert->bind_param('issi', $calendarId, $date, $name, $userId);
                        $insert->execute();
                    }
                    $insert->close();
                }
                $setPolicy = $conn->prepare("UPDATE hr_annual_calendars SET saturday_policy = 'custom', updated_by = ?, updated_at = NOW() WHERE id = ?");
                $setPolicy->bind_param('ii', $userId, $calendarId);
                $setPolicy->execute();
                $setPolicy->close();
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit($conn, (int) $calendarId, 'save_custom_weekly_offs', 'custom_off_dates', json_encode($oldDates), json_encode($dates), $userId);
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => count($dates) . ' custom weekly-off date(s) saved.', 'totals' => $totals]);

        case 'add_calendar_holiday':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true);
            $holidayDate = acValidDate(trim((string) ($_POST['holiday_date'] ?? '')), (int) $calendar['calendar_year']);
            $holidayName = acValidHolidayName((string) ($_POST['holiday_name'] ?? ''));
            $holidayType = acValidHolidayType(trim((string) ($_POST['holiday_type'] ?? '')));
            $conn->begin_transaction();
            try {
                acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $stmt = $conn->prepare(
                    'INSERT INTO hr_annual_calendar_holidays
                     (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
                );
                $sourceName = 'HR manual entry';
                $sourceVersion = date('Y-m-d');
                $stmt->bind_param('isssssi', $calendarId, $holidayDate, $holidayName, $holidayType, $sourceName, $sourceVersion, $userId);
                if (!$stmt->execute()) {
                    throw new RuntimeException('This holiday already exists or could not be saved.');
                }
                $stmt->close();
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit($conn, (int) $calendarId, 'add_holiday', 'holiday', null, "{$holidayDate}: {$holidayName} ({$holidayType})", $userId);
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Holiday added.', 'totals' => $totals]);

        case 'update_calendar_holiday':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $holidayId = filter_var($_POST['holiday_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$holidayId) {
                throw new InvalidArgumentException('Invalid holiday.');
            }
            $stmt = $conn->prepare(
                'SELECT holiday.*, calendar.company_id, calendar.calendar_year, calendar.lifecycle_status
                 FROM hr_annual_calendar_holidays holiday
                 INNER JOIN hr_annual_calendars calendar ON calendar.id = holiday.calendar_id
                 WHERE holiday.id = ? AND holiday.deleted_at IS NULL AND calendar.deleted_at IS NULL'
            );
            $stmt->bind_param('i', $holidayId);
            $stmt->execute();
            $old = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$old) {
                throw new InvalidArgumentException('Holiday not found.');
            }
            acApiAssertCompanyAccess($scope, (int) $old['company_id']);
            if ($old['lifecycle_status'] !== 'draft') {
                throw new RuntimeException('Finalized calendar revisions are immutable. Create a draft revision first.');
            }
            $holidayDate = acValidDate(trim((string) ($_POST['holiday_date'] ?? $old['holiday_date'])), (int) $old['calendar_year']);
            $holidayName = acValidHolidayName((string) ($_POST['holiday_name'] ?? ''));
            $holidayType = acValidHolidayType(trim((string) ($_POST['holiday_type'] ?? '')));
            $calendarId = (int) $old['calendar_id'];
            $conn->begin_transaction();
            try {
                acApiRequireCalendar($conn, $calendarId, $scope, true, true);
                $update = $conn->prepare(
                    'UPDATE hr_annual_calendar_holidays SET holiday_date = ?, holiday_name = ?, holiday_type = ?,
                     source_name = ?, source_version = ?, updated_by = ?, updated_at = NOW() WHERE id = ? AND deleted_at IS NULL'
                );
                $sourceName = 'HR manual entry';
                $sourceVersion = date('Y-m-d');
                $update->bind_param('sssssii', $holidayDate, $holidayName, $holidayType, $sourceName, $sourceVersion, $userId, $holidayId);
                if (!$update->execute()) {
                    throw new RuntimeException('This holiday conflicts with an existing entry or could not be updated.');
                }
                $update->close();
                $totals = acRecalculateWorkingDays($conn, $calendarId);
                acLogAudit(
                    $conn, $calendarId, 'update_holiday', 'holiday',
                    "{$old['holiday_date']}: {$old['holiday_name']} ({$old['holiday_type']})",
                    "{$holidayDate}: {$holidayName} ({$holidayType})", $userId
                );
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => 'Holiday updated.', 'totals' => $totals]);

        case 'delete_calendar_holiday':
        case 'toggle_calendar_holiday':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $holidayId = filter_var($_POST['holiday_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$holidayId) {
                throw new InvalidArgumentException('Invalid holiday.');
            }
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare(
                    'SELECT holiday.*, calendar.company_id, calendar.lifecycle_status
                     FROM hr_annual_calendar_holidays holiday
                     INNER JOIN hr_annual_calendars calendar ON calendar.id = holiday.calendar_id
                     WHERE holiday.id = ? AND holiday.deleted_at IS NULL AND calendar.deleted_at IS NULL FOR UPDATE'
                );
                $stmt->bind_param('i', $holidayId);
                $stmt->execute();
                $old = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if (!$old) {
                    throw new InvalidArgumentException('Holiday not found.');
                }
                acApiAssertCompanyAccess($scope, (int) $old['company_id']);
                if ($old['lifecycle_status'] !== 'draft') {
                    throw new RuntimeException('Finalized calendar revisions are immutable. Create a draft revision first.');
                }
                $calendarId = (int) $old['calendar_id'];
                if ($action === 'delete_calendar_holiday') {
                    $update = $conn->prepare('UPDATE hr_annual_calendar_holidays SET deleted_at = NOW(), deleted_by = ?, updated_by = ? WHERE id = ?');
                    $update->bind_param('iii', $userId, $userId, $holidayId);
                    $message = 'Holiday removed from this draft.';
                    $auditAction = 'delete_holiday';
                    $oldValue = "{$old['holiday_date']}: {$old['holiday_name']} ({$old['holiday_type']})";
                    $newValue = null;
                } else {
                    $newEnabled = (int) $old['is_enabled'] === 1 ? 0 : 1;
                    $update = $conn->prepare('UPDATE hr_annual_calendar_holidays SET is_enabled = ?, updated_by = ?, updated_at = NOW() WHERE id = ?');
                    $update->bind_param('iii', $newEnabled, $userId, $holidayId);
                    $message = $newEnabled ? 'Holiday enabled.' : 'Holiday disabled.';
                    $auditAction = 'toggle_holiday';
                    $oldValue = (string) $old['is_enabled'];
                    $newValue = (string) $newEnabled;
                }
                $update->execute();
                $update->close();
                $totals = acRecalculateWorkingDays($conn, $calendarId);
                acLogAudit($conn, $calendarId, $auditAction, $action === 'delete_calendar_holiday' ? 'holiday' : 'is_enabled', $oldValue, $newValue, $userId);
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson(['status' => 'success', 'message' => $message, 'totals' => $totals]);

        case 'finalize_annual_calendar':
            hrmsRequirePermission($conn, 'hrms_calendar_finalize');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            $lockVersion = filter_var($_POST['lock_version'] ?? null, FILTER_VALIDATE_INT);
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            acApiRequireCalendar($conn, (int) $calendarId, $scope, true);
            $result = acFinalizeCalendar(
                $conn,
                (int) $calendarId,
                $userId,
                $lockVersion === false ? null : (int) $lockVersion
            );
            hrmsJson([
                'status' => 'success', 'message' => 'Calendar finalized and published as the company working-calendar master.',
                'content_hash' => $result['content_hash'], 'totals' => $result['totals'],
            ]);

        case 'unfinalize_annual_calendar':
            hrmsRequirePermission($conn, 'hrms_calendar_reopen');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            $reason = acValidReason((string) ($_POST['reason'] ?? ''));
            $acknowledged = (string) ($_POST['acknowledge_payroll_impact'] ?? '') === '1';
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            acApiRequireCalendar($conn, (int) $calendarId, $scope);
            $payrollRuns = acCalendarPayrollRuns($conn, (int) $calendarId);
            if ($payrollRuns !== [] && !hrmsCan($conn, 'hrms_calendar_override_locked')) {
                hrmsJson([
                    'status' => 'error',
                    'message' => 'This revision is locked to finalized payroll. You need the calendar payroll-lock override permission.',
                    'payroll_runs' => $payrollRuns,
                ], 403);
            }
            $newCalendarId = acCreateDraftRevision($conn, (int) $calendarId, $userId, $reason, $acknowledged);
            hrmsJson([
                'status' => 'success',
                'message' => 'A new draft revision was created. The prior finalized revision remains authoritative until this draft is finalized.',
                'calendar_id' => $newCalendarId,
            ]);

        case 'get_calendar_monthly_summary':
            hrmsRequirePermission($conn, 'hrms_calendar_view');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope);
            $days = acBuildCalendarDays($conn, (int) $calendarId);
            hrmsJson(['status' => 'success', 'monthly' => acMonthlyBreakdownFromDays($days), 'days' => $days]);

        case 'import_default_holidays':
            hrmsRequirePermission($conn, 'hrms_calendar_manage');
            $calendarId = filter_var($_POST['calendar_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$calendarId) {
                throw new InvalidArgumentException('Invalid calendar.');
            }
            $conn->begin_transaction();
            try {
                $calendar = acApiRequireCalendar($conn, (int) $calendarId, $scope, true, true);
                $insert = $conn->prepare(
                    'INSERT IGNORE INTO hr_annual_calendar_holidays
                     (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
                );
                $imported = 0;
                foreach (acGetIndianHolidays((int) $calendar['calendar_year']) as $holiday) {
                    $insert->bind_param(
                        'isssssi', $calendarId, $holiday['date'], $holiday['name'], $holiday['type'],
                        $holiday['source_name'], $holiday['source_version'], $userId
                    );
                    $insert->execute();
                    $imported += max(0, $insert->affected_rows);
                }
                $insert->close();
                $totals = acRecalculateWorkingDays($conn, (int) $calendarId);
                acLogAudit($conn, (int) $calendarId, 'import_reference_holidays', 'holidays', null, "Imported {$imported} suggested holiday(s)", $userId);
                $conn->commit();
            } catch (Throwable $error) {
                $conn->rollback();
                throw $error;
            }
            hrmsJson([
                'status' => 'success',
                'message' => "Imported {$imported} suggested holiday(s). HR must verify jurisdiction and dates before finalization.",
                'totals' => $totals,
            ]);
    }

    return true;
}
