<?php

declare(strict_types=1);

if (!defined('HRMS_CONTEXT')) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/annual_calendar_common.php';

function hrmsJson(array $payload, int $statusCode = 200): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function hrmsRequireLogin(): int
{
    $userId = (int) ($_SESSION['user_id'] ?? 0);
    if ($userId <= 0) {
        hrmsJson(['status' => 'error', 'message' => 'Your session has expired. Please sign in again.'], 401);
    }

    return $userId;
}

function hrmsRequireCsrf(): void
{
    $provided = (string) ($_POST['csrf_token'] ?? '');
    $expected = (string) ($_SESSION['csrf_token'] ?? '');

    if ($expected === '' || !hash_equals($expected, $provided)) {
        hrmsJson(['status' => 'error', 'message' => 'The request token is invalid or expired.'], 419);
    }
}

function hrmsCan(mysqli $conn, string $permission): bool
{
    return checkPermission($permission, $conn);
}

function hrmsRequirePermission(mysqli $conn, string $permission): void
{
    if (!hrmsCan($conn, $permission)) {
        hrmsJson(['status' => 'error', 'message' => 'You do not have permission to perform this action.'], 403);
    }
}

function hrmsCurrentScope(mysqli $conn, int $userId): array
{
    $stmt = $conn->prepare(
        'SELECT company_id, branch_id FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $scope = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    return [
        'company_id' => isset($scope['company_id']) ? (int) $scope['company_id'] : null,
        'branch_id' => isset($scope['branch_id']) ? (int) $scope['branch_id'] : null,
    ];
}

function hrmsCurrentEmployee(mysqli $conn, int $userId, bool $forUpdate = false): ?array
{
    $lock = $forUpdate ? ' FOR UPDATE' : '';
    $sql = "SELECT employee.id, employee.emp_code, employee.solutation, employee.first_name,
            employee.last_name, employee.dob, employee.gender, employee.email AS work_email,
            employee.contact_no, employee.alt_contact_no, employee.fathers_name,
            employee.marital_status, employee.blood_group, employee.local_address,
            employee.permanent_address, employee.pan_no, employee.aadhar_no,
            employee.date_of_join, employee.date_of_resign, employee.last_working_date,
            employee.notice_period_days, employee.status, employee.designation_id,
            employee.employment_type, employee.emp_categ_type, employee.user_id,
            COALESCE(profile.company_id, user.company_id, legacy_company.id) AS company_id,
            COALESCE(profile.branch_id, user.branch_id) AS branch_id, user.email AS login_email,
            company.company_name, branch.branch_name, designation.name AS designation_name,
            profile.department_id, department.name AS department_name, profile.work_location,
            profile.personal_email, profile.differently_abled, profile.portal_access,
            profile.payment_mode, profile.annual_ctc,
            employee.bank_id, employee.bank_account_holder_name, employee.bank_account_number,
            employee.bank_ifsc_code, employee.bank_branch_name, employee.bank_account_type
        FROM employees employee
        INNER JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        LEFT JOIN erp_companies company ON company.id = COALESCE(profile.company_id, user.company_id, legacy_company.id) AND company.deleted_at IS NULL
        LEFT JOIN erp_branches branch ON branch.id = COALESCE(profile.branch_id, user.branch_id) AND branch.deleted_at IS NULL
        LEFT JOIN designations designation ON designation.id = employee.designation_id
        LEFT JOIN departments department ON department.id = profile.department_id AND department.deleted_at IS NULL
        WHERE employee.user_id = ? AND employee.deleted_at IS NULL
        ORDER BY (profile.company_id IS NOT NULL AND profile.company_id > 0) DESC, (employee.company > 0) DESC, employee.id DESC
        LIMIT 1{$lock}";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $employee = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();

    if ($employee && empty($employee['company_id'])) {
        $scope = hrmsCurrentScope($conn, $userId);
        $employee['company_id'] = $scope['company_id'] ?: 1;
    }

    return $employee;
}

function hrmsEmployeeById(mysqli $conn, int $employeeId, bool $forUpdate = false): ?array
{
    $lock = $forUpdate ? ' FOR UPDATE' : '';
    $stmt = $conn->prepare(
        "SELECT employee.*,
            COALESCE(profile.company_id, user.company_id, legacy_company.id) AS company_id,
            COALESCE(profile.branch_id, user.branch_id) AS branch_id, user.email AS login_email,
                profile.department_id, profile.work_location, profile.personal_email,
                profile.differently_abled, profile.portal_access, profile.payment_mode,
                profile.annual_ctc
         FROM employees employee
         LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
         LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
         LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
         WHERE employee.id = ? AND employee.deleted_at IS NULL LIMIT 1{$lock}"
    );
    $stmt->bind_param('i', $employeeId);
    $stmt->execute();
    $employee = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();

    if ($employee && empty($employee['company_id'])) {
        $employee['company_id'] = 1;
    }

    return $employee;
}

function hrmsAssertTenantAccess(array $scope, array $record): void
{
    if ($scope['company_id'] !== null && (int) ($record['company_id'] ?? 0) !== $scope['company_id']) {
        hrmsJson(['status' => 'error', 'message' => 'This record belongs to another organization.'], 403);
    }

    if ($scope['branch_id'] !== null && !empty($record['branch_id']) && (int) $record['branch_id'] !== $scope['branch_id']) {
        hrmsJson(['status' => 'error', 'message' => 'This record belongs to another branch.'], 403);
    }
}

function hrmsLeaveBalances(mysqli $conn, array $employee, ?int $year = null): array
{
    $year ??= (int) date('Y');
    $companyId = !empty($employee['company_id']) ? (int) $employee['company_id'] : 0;
    $gender = (int) ($employee['gender'] ?? 0);
    $stmt = $conn->prepare(
        "SELECT leave_type.id, leave_type.code, leave_type.name, leave_type.description,
                leave_type.color, leave_type.is_paid, leave_type.gender_eligibility,
                leave_type.allow_negative_balance,
                COALESCE(allocation.allocated_days, 0) AS allocated_days,
                COALESCE(allocation.carried_forward_days, 0) AS carried_forward_days,
                COALESCE(allocation.adjustment_days, 0) AS adjustment_days,
                COALESCE(SUM(CASE WHEN application.status = 'approved' THEN application.total_days ELSE 0 END), 0) AS approved_days,
                COALESCE(SUM(CASE WHEN application.status = 'pending' THEN application.total_days ELSE 0 END), 0) AS pending_days
         FROM hr_leave_types leave_type
         LEFT JOIN hr_leave_allocations allocation
           ON allocation.leave_type_id = leave_type.id
          AND allocation.employee_id = ?
          AND allocation.leave_year = ?
         LEFT JOIN hr_leave_applications application
           ON application.leave_type_id = leave_type.id
          AND application.employee_id = ?
          AND YEAR(application.start_date) = ?
          AND application.status IN ('pending','approved')
         WHERE leave_type.status = 1
           AND (leave_type.company_id IS NULL OR leave_type.company_id = ?)
         GROUP BY leave_type.id, leave_type.code, leave_type.name, leave_type.description,
                  leave_type.color, leave_type.is_paid, leave_type.gender_eligibility,
                  leave_type.allow_negative_balance, allocation.allocated_days,
                  allocation.carried_forward_days, allocation.adjustment_days
         ORDER BY FIELD(leave_type.code, 'CASUAL','SICK','LWP','MATERNITY'), leave_type.name"
    );
    $employeeId = (int) $employee['id'];
    $stmt->bind_param('iiiii', $employeeId, $year, $employeeId, $year, $companyId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($rows as &$row) {
        $allocated = (float) $row['allocated_days'] + (float) $row['carried_forward_days'] + (float) $row['adjustment_days'];
        $approved = (float) $row['approved_days'];
        $pending = (float) $row['pending_days'];
        $eligible = $row['gender_eligibility'] === 'all'
            || ($row['gender_eligibility'] === 'female' && $gender === 2)
            || ($row['gender_eligibility'] === 'male' && $gender === 1);
        $available = $allocated - $approved;
        $remaining = $available - $pending;
        $row['allocated'] = round($allocated, 2);
        $row['available'] = round($available, 2);
        $row['current_booking'] = round($pending, 2);
        $row['remaining'] = round($remaining, 2);
        $row['eligible'] = $eligible;
        $row['can_apply'] = $eligible && ((int) $row['allow_negative_balance'] === 1 || $remaining > 0);
    }
    unset($row);

    return $rows;
}

function hrmsLeaveBalanceByType(mysqli $conn, array $employee, int $leaveTypeId, int $year): ?array
{
    foreach (hrmsLeaveBalances($conn, $employee, $year) as $balance) {
        if ((int) $balance['id'] === $leaveTypeId) {
            return $balance;
        }
    }

    return null;
}

function hrmsParseLeaveDays(string $json): array
{
    $decoded = json_decode($json, true);
    if (!is_array($decoded) || $decoded === []) {
        throw new InvalidArgumentException('Select at least one leave date.');
    }

    $allowedPortions = ['full_day' => 1.0, 'first_half' => 0.5, 'second_half' => 0.5];
    $days = [];
    foreach ($decoded as $item) {
        $date = trim((string) ($item['date'] ?? ''));
        $portion = (string) ($item['portion'] ?? 'full_day');
        $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (!$dateObject || $dateObject->format('Y-m-d') !== $date || !isset($allowedPortions[$portion])) {
            throw new InvalidArgumentException('One or more leave dates are invalid.');
        }
        $days[$date] = ['date' => $date, 'portion' => $portion, 'value' => $allowedPortions[$portion]];
    }

    ksort($days);
    return array_values($days);
}

function hrmsReference(string $prefix): string
{
    return sprintf('%s-%s-%s', $prefix, date('Ym'), strtoupper(bin2hex(random_bytes(3))));
}

function hrmsPfCategoryBase(string $category): float
{
    return match (strtolower(trim($category))) {
        'e' => 15000.0,
        'w', 'ew' => 7500.0,
        default => 0.0,
    };
}

function hrmsCalculatePfAmount(string $category): float
{
    return round(hrmsPfCategoryBase($category) * 0.12, 2);
}

function hrmsCalculateEsicAmount(float $grossSalary): float
{
    return $grossSalary > 0 && $grossSalary < 21000
        ? round($grossSalary * 0.01, 2)
        : 0.0;
}

function hrmsManagerUserIds(mysqli $conn, string $permission, ?int $companyId, ?int $branchId): array
{
    $sql = "SELECT DISTINCT user.id
        FROM users user
        INNER JOIN role_permissions role_permission ON role_permission.role_id = user.role_id AND role_permission.status = 1
        INNER JOIN permissions permission ON permission.id = role_permission.permission_id AND permission.slug = ?
        LEFT JOIN user_permissions denied ON denied.user_id = user.id AND denied.permission_id = permission.id AND denied.action = 0
        WHERE user.is_active = 1 AND user.deleted_at IS NULL AND denied.id IS NULL";
    $types = 's';
    $params = [$permission];
    if ($companyId !== null) {
        $sql .= ' AND (user.company_id = ? OR user.company_id IS NULL)';
        $types .= 'i';
        $params[] = $companyId;
    }
    if ($branchId !== null) {
        $sql .= ' AND (user.branch_id = ? OR user.branch_id IS NULL)';
        $types .= 'i';
        $params[] = $branchId;
    }
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $ids = array_map('intval', array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'id'));
    $stmt->close();
    return $ids;
}

function hrmsNotify(mysqli $conn, string $module, string $table, int $recordId, string $title, string $message, int $createdBy, array $userIds): void
{
    if ($userIds === []) {
        return;
    }

    createNotification($conn, [
        'module' => $module,
        'ref_table' => $table,
        'ref_id' => $recordId,
        'title' => $title,
        'message' => $message,
        'notification_type' => 1,
        'severity' => 1,
        'created_by' => $createdBy,
        'user_ids' => array_values(array_unique(array_filter(array_map('intval', $userIds)))),
    ]);
}

function hrmsGenerateEmployeeCode(mysqli $conn, int $companyId): string
{
    $companyStmt = $conn->prepare('SELECT company_code FROM erp_companies WHERE id = ? AND deleted_at IS NULL LIMIT 1');
    $companyStmt->bind_param('i', $companyId);
    $companyStmt->execute();
    $company = $companyStmt->get_result()->fetch_assoc();
    $companyStmt->close();
    if (!$company) {
        throw new RuntimeException('Select a valid organization.');
    }

    $conn->query("INSERT IGNORE INTO hr_employee_sequences (company_id, next_number) VALUES ({$companyId}, 1)");
    $sequenceStmt = $conn->prepare('SELECT next_number FROM hr_employee_sequences WHERE company_id = ? FOR UPDATE');
    $sequenceStmt->bind_param('i', $companyId);
    $sequenceStmt->execute();
    $nextNumber = (int) ($sequenceStmt->get_result()->fetch_assoc()['next_number'] ?? 1);
    $sequenceStmt->close();

    $updateStmt = $conn->prepare('UPDATE hr_employee_sequences SET next_number = ? WHERE company_id = ?');
    $newNextNumber = $nextNumber + 1;
    $updateStmt->bind_param('ii', $newNextNumber, $companyId);
    $updateStmt->execute();
    $updateStmt->close();

    $prefix = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $company['company_code'])) ?: 'EMP';
    return sprintf('%s-%05d', substr($prefix, 0, 10), $nextNumber);
}

function hrmsStoreEmployeeDocument(mysqli $conn, int $employeeId, array $upload, string $documentType, int $userId): ?string
{
    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if (($upload['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The employee document upload did not complete successfully.');
    }
    $size = (int) ($upload['size'] ?? 0);
    if ($size <= 0 || $size > 10 * 1024 * 1024) {
        throw new RuntimeException('Employee documents must be smaller than 10 MB.');
    }
    $temporaryPath = (string) ($upload['tmp_name'] ?? '');
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = (string) $finfo->file($temporaryPath);
    $extensions = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    if (!isset($extensions[$mimeType])) {
        throw new RuntimeException('Upload the resume as a PDF, JPG, PNG or WebP file.');
    }

    $projectRoot = dirname(__DIR__, 2);
    $relativeDirectory = 'uploads/hrms-employees/' . $employeeId;
    $absoluteDirectory = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDirectory);
    if (!is_dir($absoluteDirectory) && !mkdir($absoluteDirectory, 0775, true) && !is_dir($absoluteDirectory)) {
        throw new RuntimeException('Unable to prepare employee document storage.');
    }
    $storedName = $documentType . '-' . bin2hex(random_bytes(8)) . '.' . $extensions[$mimeType];
    $absolutePath = $absoluteDirectory . DIRECTORY_SEPARATOR . $storedName;
    if (!move_uploaded_file($temporaryPath, $absolutePath)) {
        throw new RuntimeException('Unable to store the employee document.');
    }
    $relativePath = $relativeDirectory . '/' . $storedName;
    $originalName = mb_substr(basename((string) ($upload['name'] ?? $storedName)), 0, 255);
    $stmt = $conn->prepare(
        'INSERT INTO employee_documents (employee_id, document_type, original_name, file_path, mime_type, file_size, status, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
    );
    $stmt->bind_param('issssii', $employeeId, $documentType, $originalName, $relativePath, $mimeType, $size, $userId);
    if (!$stmt->execute()) {
        @unlink($absolutePath);
        throw new RuntimeException('Unable to register the employee document.');
    }
    $stmt->close();
    return $absolutePath;
}

function hrmsGenerateOffboardingDocuments(mysqli $conn, int $requestId, int $userId): array
{
    if (!class_exists(\Dompdf\Dompdf::class)) {
        throw new RuntimeException('The PDF generator is unavailable.');
    }
    $stmt = $conn->prepare(
        "SELECT request.request_no, request.resignation_date, request.approved_last_working_date,
                employee.emp_code, employee.first_name, employee.last_name, employee.date_of_join,
                employee.email, company.company_name
         FROM hr_resignation_requests request
         INNER JOIN employees employee ON employee.id = request.employee_id
         LEFT JOIN erp_companies company ON company.id = request.company_id
         WHERE request.id = ? AND request.status IN ('exit_interview_pending','completed') LIMIT 1"
    );
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$request) {
        throw new RuntimeException('Approved offboarding request not found.');
    }

    $documentStmt = $conn->prepare(
        "SELECT id, document_type FROM hr_offboarding_documents
         WHERE resignation_request_id = ? AND status IN ('pending','failed') ORDER BY id"
    );
    $documentStmt->bind_param('i', $requestId);
    $documentStmt->execute();
    $documents = $documentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $documentStmt->close();
    $generated = [];
    $projectRoot = dirname(__DIR__, 2);
    $relativeDirectory = 'uploads/hrms-offboarding/' . $requestId;
    $absoluteDirectory = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativeDirectory);
    if (!is_dir($absoluteDirectory) && !mkdir($absoluteDirectory, 0775, true) && !is_dir($absoluteDirectory)) {
        throw new RuntimeException('Unable to prepare offboarding document storage.');
    }

    $employeeName = trim($request['first_name'] . ' ' . $request['last_name']);
    $companyName = trim((string) ($request['company_name'] ?? '')) ?: 'The Organization';
    $safeEmployeeName = htmlspecialchars($employeeName, ENT_QUOTES, 'UTF-8');
    $safeCompanyName = htmlspecialchars($companyName, ENT_QUOTES, 'UTF-8');
    $safeEmployeeCode = htmlspecialchars((string) $request['emp_code'], ENT_QUOTES, 'UTF-8');
    $lastWorkingDate = date('d F Y', strtotime((string) $request['approved_last_working_date']));
    $dateOfJoin = !empty($request['date_of_join']) ? date('d F Y', strtotime((string) $request['date_of_join'])) : 'the recorded joining date';

    foreach ($documents as $document) {
        $documentType = (string) $document['document_type'];
        $title = $documentType === 'experience_letter' ? 'Experience Letter' : 'Relieving Letter';
        $body = $documentType === 'experience_letter'
            ? "This is to certify that <strong>{$safeEmployeeName}</strong> (Employee ID: {$safeEmployeeCode}) has served with {$safeCompanyName} from {$dateOfJoin} and has an approved last working date of {$lastWorkingDate}. We appreciate the employee's contribution and wish them success in future endeavors."
            : "This is to confirm that <strong>{$safeEmployeeName}</strong> (Employee ID: {$safeEmployeeCode}) will be relieved from duties at {$safeCompanyName} with effect from the close of business on {$lastWorkingDate}, following approval of the offboarding request.";
        $html = '<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:DejaVu Sans,sans-serif;color:#1e293b;font-size:13px;line-height:1.75}.wrap{padding:54px}.brand{color:#047857;font-size:22px;font-weight:700}.title{text-align:center;font-size:20px;font-weight:700;margin:65px 0 42px;text-transform:uppercase;letter-spacing:1px}.reference{color:#64748b;font-size:11px}.body{font-size:14px;text-align:justify}.signature{margin-top:80px}.footer{position:fixed;bottom:25px;left:54px;right:54px;border-top:1px solid #e2e8f0;padding-top:10px;color:#94a3b8;font-size:9px}</style></head><body><div class="wrap"><div class="brand">' . $safeCompanyName . '</div><div class="reference">Reference: ' . htmlspecialchars((string) $request['request_no'], ENT_QUOTES, 'UTF-8') . '<br>Date: ' . date('d F Y') . '</div><div class="title">' . $title . '</div><div class="body"><p>To whom it may concern,</p><p>' . $body . '</p></div><div class="signature"><strong>Authorized Signatory</strong><br>Human Resources<br>' . $safeCompanyName . '</div></div><div class="footer">Generated automatically after HR approval.</div></body></html>';
        $dompdf = new \Dompdf\Dompdf(['isRemoteEnabled' => false]);
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4');
        $dompdf->render();
        $fileName = $documentType . '-' . preg_replace('/[^A-Za-z0-9_-]/', '-', (string) $request['request_no']) . '.pdf';
        $absolutePath = $absoluteDirectory . DIRECTORY_SEPARATOR . $fileName;
        if (file_put_contents($absolutePath, $dompdf->output(), LOCK_EX) === false) {
            throw new RuntimeException('Unable to write an offboarding PDF.');
        }
        $relativePath = $relativeDirectory . '/' . $fileName;
        $update = $conn->prepare(
            "UPDATE hr_offboarding_documents SET file_path = ?, status = 'generated', generated_by = ?, generated_at = NOW(), error_message = NULL WHERE id = ?"
        );
        $documentId = (int) $document['id'];
        $update->bind_param('sii', $relativePath, $userId, $documentId);
        $update->execute();
        $update->close();
        $generated[] = $relativePath;
    }

    return $generated;
}

function hrmsSendOffboardingDocuments(mysqli $conn, int $requestId): bool
{
    if (!class_exists(\PHPMailer\PHPMailer\PHPMailer::class)) {
        return false;
    }
    $env = $GLOBALS['env'] ?? [];
    $host = trim((string) ($env['MAIL_SMTP_HOST'] ?? ''));
    $port = (int) ($env['MAIL_SMTP_PORT'] ?? 0);
    $username = trim((string) ($env['MAIL_SMTP_USERNAME'] ?? ''));
    $password = (string) ($env['MAIL_SMTP_PASSWORD'] ?? '');
    $fromAddress = trim((string) ($env['MAIL_FROM_ADDRESS'] ?? ''));
    $fromName = trim((string) ($env['MAIL_FROM_NAME'] ?? 'Human Resources'));
    $encryption = strtolower(trim((string) ($env['MAIL_SMTP_ENCRYPTION'] ?? 'tls')));
    if ($host === '' || $port <= 0 || $username === '' || $password === '' || !filter_var($fromAddress, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $stmt = $conn->prepare(
        "SELECT request.request_no, employee.email, employee.first_name, employee.last_name
         FROM hr_resignation_requests request
         INNER JOIN employees employee ON employee.id = request.employee_id
         WHERE request.id = ? AND request.status IN ('exit_interview_pending','completed') LIMIT 1"
    );
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$request || !filter_var($request['email'], FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $documentStmt = $conn->prepare(
        "SELECT id, document_type, file_path FROM hr_offboarding_documents
         WHERE resignation_request_id = ? AND status = 'generated' AND file_path IS NOT NULL"
    );
    $documentStmt->bind_param('i', $requestId);
    $documentStmt->execute();
    $documents = $documentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $documentStmt->close();
    if ($documents === []) {
        return false;
    }
    $projectRoot = dirname(__DIR__, 2);
    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->Port = $port;
        $mail->SMTPAuth = true;
        $mail->Username = $username;
        $mail->Password = $password;
        if (in_array($encryption, ['ssl', 'smtps'], true)) {
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($encryption !== 'none') {
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->setFrom($fromAddress, $fromName ?: 'Human Resources');
        $mail->addAddress((string) $request['email'], trim($request['first_name'] . ' ' . $request['last_name']));
        $attachmentCount = 0;
        foreach ($documents as $document) {
            $relativePath = ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, (string) $document['file_path']), DIRECTORY_SEPARATOR);
            $absolutePath = realpath($projectRoot . DIRECTORY_SEPARATOR . $relativePath);
            if ($absolutePath && str_starts_with($absolutePath, rtrim($projectRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) && is_file($absolutePath)) {
                $mail->addAttachment($absolutePath, ucwords(str_replace('_', ' ', (string) $document['document_type'])) . '.pdf');
                $attachmentCount++;
            }
        }
        if ($attachmentCount === 0) {
            return false;
        }
        $mail->isHTML(true);
        $mail->Subject = 'Offboarding documents - ' . $request['request_no'];
        $mail->Body = '<p>Dear ' . htmlspecialchars((string) $request['first_name'], ENT_QUOTES, 'UTF-8') . ',</p><p>Your resignation request has been approved. The selected HR documents are attached.</p><p>Regards,<br>Human Resources</p>';
        $mail->AltBody = 'Your resignation request has been approved. The selected HR documents are attached.';
        $mail->send();
        $update = $conn->prepare("UPDATE hr_offboarding_documents SET status = 'sent', sent_at = NOW(), error_message = NULL WHERE resignation_request_id = ? AND status = 'generated'");
        $update->bind_param('i', $requestId);
        $update->execute();
        $update->close();
        return true;
    } catch (Throwable $exception) {
        $error = mb_substr($exception->getMessage(), 0, 1000);
        $update = $conn->prepare("UPDATE hr_offboarding_documents SET status = 'failed', error_message = ? WHERE resignation_request_id = ? AND status = 'generated'");
        $update->bind_param('si', $error, $requestId);
        $update->execute();
        $update->close();
        error_log('Offboarding email delivery failed: ' . $exception->getMessage());
        return false;
    }
}

function hrmsSendLeaveTeamNotification(mysqli $conn, int $applicationId, string $teamEmail): bool
{
    if (!class_exists(\PHPMailer\PHPMailer\PHPMailer::class) || !filter_var($teamEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $env = $GLOBALS['env'] ?? [];
    $host = trim((string) ($env['MAIL_SMTP_HOST'] ?? ''));
    $port = (int) ($env['MAIL_SMTP_PORT'] ?? 0);
    $username = trim((string) ($env['MAIL_SMTP_USERNAME'] ?? ''));
    $password = (string) ($env['MAIL_SMTP_PASSWORD'] ?? '');
    $fromAddress = trim((string) ($env['MAIL_FROM_ADDRESS'] ?? ''));
    $fromName = trim((string) ($env['MAIL_FROM_NAME'] ?? 'Human Resources'));
    $encryption = strtolower(trim((string) ($env['MAIL_SMTP_ENCRYPTION'] ?? 'tls')));
    if ($host === '' || $port <= 0 || $username === '' || $password === '' || !filter_var($fromAddress, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT app.application_no, app.start_date, app.end_date, app.total_days, app.reason,
                emp.emp_code, emp.first_name, emp.last_name, emp.email AS work_email,
                leave_type.name AS leave_type_name,
                company.company_name
         FROM hr_leave_applications app
         INNER JOIN employees emp ON emp.id = app.employee_id
         LEFT JOIN hr_leave_types leave_type ON leave_type.id = app.leave_type_id
         LEFT JOIN erp_companies company ON company.id = app.company_id
         WHERE app.id = ? LIMIT 1"
    );
    $stmt->bind_param('i', $applicationId);
    $stmt->execute();
    $app = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$app) {
        return false;
    }

    $employeeName = trim($app['first_name'] . ' ' . $app['last_name']);
    $leaveType = (string) ($app['leave_type_name'] ?: 'Leave');
    $startDate = date('d M Y', strtotime((string) $app['start_date']));
    $endDate = date('d M Y', strtotime((string) $app['end_date']));
    $totalDays = (float) $app['total_days'];
    $reason = htmlspecialchars((string) $app['reason'], ENT_QUOTES, 'UTF-8');
    $appNo = htmlspecialchars((string) $app['application_no'], ENT_QUOTES, 'UTF-8');
    $companyName = htmlspecialchars((string) ($app['company_name'] ?: 'HRMS'), ENT_QUOTES, 'UTF-8');

    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->Port = $port;
        $mail->SMTPAuth = true;
        $mail->Username = $username;
        $mail->Password = $password;
        if (in_array($encryption, ['ssl', 'smtps'], true)) {
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($encryption !== 'none') {
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->setFrom($fromAddress, $fromName ?: 'Human Resources');
        $mail->addAddress($teamEmail);
        $mail->isHTML(true);
        $mail->Subject = "Leave Application - {$employeeName} ({$leaveType}, {$startDate} to {$endDate})";
        $mail->Body = "<p>Dear Team,</p>"
            . "<p><strong>" . htmlspecialchars($employeeName, ENT_QUOTES, 'UTF-8') . "</strong> (" . htmlspecialchars((string) $app['emp_code'], ENT_QUOTES, 'UTF-8') . ") has submitted a leave application.</p>"
            . "<table style='border-collapse:collapse;margin:15px 0;font-family:sans-serif;font-size:13px;'>"
            . "<tr><td style='padding:6px 12px;font-weight:bold;color:#475569;border:1px solid #e2e8f0;'>Leave Type:</td><td style='padding:6px 12px;border:1px solid #e2e8f0;'>" . htmlspecialchars($leaveType, ENT_QUOTES, 'UTF-8') . "</td></tr>"
            . "<tr><td style='padding:6px 12px;font-weight:bold;color:#475569;border:1px solid #e2e8f0;'>Period:</td><td style='padding:6px 12px;border:1px solid #e2e8f0;'>{$startDate} to {$endDate} ({$totalDays} day(s))</td></tr>"
            . "<tr><td style='padding:6px 12px;font-weight:bold;color:#475569;border:1px solid #e2e8f0;'>Reason:</td><td style='padding:6px 12px;border:1px solid #e2e8f0;'>{$reason}</td></tr>"
            . "<tr><td style='padding:6px 12px;font-weight:bold;color:#475569;border:1px solid #e2e8f0;'>Reference:</td><td style='padding:6px 12px;border:1px solid #e2e8f0;'>{$appNo}</td></tr>"
            . "</table>"
            . "<p>Regards,<br>{$companyName}</p>";
        $mail->AltBody = "Leave Application: {$employeeName} has applied for {$leaveType} from {$startDate} to {$endDate} ({$totalDays} days). Reason: " . (string) $app['reason'] . " (Ref: {$app['application_no']})";
        $mail->send();
        return true;
    } catch (Throwable $exception) {
        error_log('Leave team email notification failed: ' . $exception->getMessage());
        return false;
    }
}


/**
 * Minutes of the shift's unpaid lunch window that fall inside the punched span.
 */
function hrmsShiftBreakMinutes(string $attendanceDate, ?string $firstPunch, ?string $lastPunch, array $shift): int
{
    $lunchStart = (string) ($shift['lunch_start_time'] ?? '');
    $lunchEnd = (string) ($shift['lunch_end_time'] ?? '');
    if ($firstPunch === null || $lastPunch === null || $lunchStart === '' || $lunchEnd === '') {
        return 0;
    }
    $lunchFrom = strtotime($attendanceDate . ' ' . $lunchStart);
    $lunchTo = strtotime($attendanceDate . ' ' . $lunchEnd);
    if ($lunchFrom === false || $lunchTo === false) {
        return 0;
    }
    if ($lunchTo <= $lunchFrom) {
        $lunchTo = strtotime('+1 day', $lunchTo);
    }
    $overlap = min(strtotime($lastPunch), $lunchTo) - max(strtotime($firstPunch), $lunchFrom);
    return $overlap > 0 ? (int) floor($overlap / 60) : 0;
}

/**
 * Paid minutes for a punch pair, excluding the shift's unpaid lunch window.
 *
 * @return array{worked:int, break:int}
 */
function hrmsShiftWorkedMinutes(string $attendanceDate, ?string $firstPunch, ?string $lastPunch, array $shift): array
{
    if ($firstPunch === null || $lastPunch === null) {
        return ['worked' => 0, 'break' => 0];
    }
    $span = max(0, (int) floor((strtotime($lastPunch) - strtotime($firstPunch)) / 60));
    $break = min($span, hrmsShiftBreakMinutes($attendanceDate, $firstPunch, $lastPunch, $shift));
    return ['worked' => max(0, $span - $break), 'break' => $break];
}

/**
 * Half/full-day thresholds for a shift, falling back to the scheduled span when
 * the shift or policy carries no usable value.
 *
 * @return array{half:int, full:int}
 */
function hrmsShiftThresholds(array $shift): array
{
    $full = (int) ($shift['full_day_minutes'] ?? 0);
    if ($full <= 0) {
        $full = 480;
    }
    $half = (int) ($shift['half_day_minutes'] ?? 0);
    if ($half <= 0) {
        $half = (int) floor($full / 2);
    }
    $half = max(1, min($half, $full));
    return ['half' => $half, 'full' => max($half, $full)];
}

function hrmsRecalculateAttendance(mysqli $conn, string $attendanceDate, ?int $companyId, ?int $branchId): int
{
    $calendarDay = null;
    if ($companyId !== null && $companyId > 0 && acProductionSchemaReady($conn)) {
        $calendarDay = acGetDayForCompanyDate($conn, $companyId, $attendanceDate);
    }
    $employeeSql = "SELECT employee.id
        FROM employees employee
        LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
        LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
        LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
        WHERE employee.deleted_at IS NULL AND employee.status = 1";
    $types = '';
    $params = [];
    if ($companyId !== null) {
        $employeeSql .= ' AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?';
        $types .= 'i';
        $params[] = $companyId;
    }
    if ($branchId !== null) {
        $employeeSql .= ' AND COALESCE(profile.branch_id, user.branch_id) = ?';
        $types .= 'i';
        $params[] = $branchId;
    }
    $stmt = $conn->prepare($employeeSql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $employeeIds = array_map('intval', array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'id'));
    $stmt->close();

    $punchStmt = $conn->prepare(
        'SELECT MIN(punch_time) AS first_punch, MAX(punch_time) AS last_punch, COUNT(*) AS punch_count FROM hr_biometric_punches WHERE employee_id = ? AND DATE(punch_time) = ?'
    );
    $shiftStmt = $conn->prepare(
        "SELECT shift.id, shift.start_time, shift.end_time, shift.lunch_start_time, shift.lunch_end_time,
                shift.late_grace_minutes, shift.early_leave_minutes,
                COALESCE(policy.full_day_minutes,
                    TIMESTAMPDIFF(MINUTE, CONCAT(?, ' ', shift.start_time),
                        CASE WHEN shift.end_time <= shift.start_time
                            THEN DATE_ADD(CONCAT(?, ' ', shift.end_time), INTERVAL 1 DAY)
                            ELSE CONCAT(?, ' ', shift.end_time) END)) AS full_day_minutes,
                COALESCE(policy.half_day_minutes, ROUND(shift.half_day_hours * 60)) AS half_day_minutes
         FROM employee_shift_rosters roster
         INNER JOIN shifts shift ON shift.id = roster.shift_id AND shift.status = 1 AND shift.deleted_at IS NULL
         LEFT JOIN hr_shift_policies policy ON policy.shift_id = shift.id
           AND policy.effective_from <= ? AND (policy.effective_to IS NULL OR policy.effective_to >= ?)
           AND (policy.company_id = 0 OR policy.company_id = COALESCE(?, policy.company_id))
           AND (policy.branch_id = 0 OR policy.branch_id = COALESCE(?, policy.branch_id))
         WHERE roster.employee_id = ? AND roster.deleted_at IS NULL AND roster.status = 1
           AND ((roster.shift_date = ?) OR (? BETWEEN roster.start_date AND roster.end_date))
         ORDER BY roster.shift_date IS NULL ASC, policy.company_id DESC, policy.branch_id DESC,
                  policy.effective_from DESC, roster.id DESC LIMIT 1"
    );
        $defaultShiftStmt = $conn->prepare(
                "SELECT shift.id, shift.start_time, shift.end_time, shift.lunch_start_time, shift.lunch_end_time,
                                shift.late_grace_minutes, shift.early_leave_minutes,
                                COALESCE(policy.full_day_minutes,
                                    TIMESTAMPDIFF(MINUTE, CONCAT(?, ' ', shift.start_time),
                                        CASE WHEN shift.end_time <= shift.start_time
                                            THEN DATE_ADD(CONCAT(?, ' ', shift.end_time), INTERVAL 1 DAY)
                                            ELSE CONCAT(?, ' ', shift.end_time) END)) AS full_day_minutes,
                                COALESCE(policy.half_day_minutes, ROUND(shift.half_day_hours * 60)) AS half_day_minutes
                 FROM shifts shift
                 LEFT JOIN hr_shift_policies policy ON policy.shift_id = shift.id
                     AND policy.effective_from <= ? AND (policy.effective_to IS NULL OR policy.effective_to >= ?)
                     AND (policy.company_id = 0 OR policy.company_id = COALESCE(?, policy.company_id))
                     AND (policy.branch_id = 0 OR policy.branch_id = COALESCE(?, policy.branch_id))
                 WHERE shift.status = 1 AND shift.deleted_at IS NULL
                     AND (shift.company_id = 0 OR shift.company_id = COALESCE(?, shift.company_id))
                     AND (shift.branch_id = 0 OR shift.branch_id = COALESCE(?, shift.branch_id))
                     AND EXISTS (
                             SELECT 1 FROM shift_days day
                             WHERE day.shift_id = shift.id AND day.status = 1 AND day.deleted_at IS NULL
                                 AND day.day_of_week = WEEKDAY(?) + 1
                     )
                 ORDER BY shift.branch_id DESC, shift.company_id DESC, policy.effective_from DESC, shift.id ASC LIMIT 1"
        );
    $upsertStmt = $conn->prepare(
        "INSERT INTO hr_attendance_daily
         (employee_id, company_id, branch_id, attendance_date, shift_id, first_punch_at,
          last_punch_at, worked_minutes, late_minutes, early_minutes, break_minutes, classification, source, calculated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'biometric', NOW())
         ON DUPLICATE KEY UPDATE company_id = VALUES(company_id), branch_id = VALUES(branch_id),
           shift_id = VALUES(shift_id), first_punch_at = VALUES(first_punch_at),
           last_punch_at = VALUES(last_punch_at), worked_minutes = VALUES(worked_minutes),
           late_minutes = VALUES(late_minutes), early_minutes = VALUES(early_minutes),
           break_minutes = VALUES(break_minutes),
           classification = IF(hr_attendance_daily.source = 'manual', hr_attendance_daily.classification, VALUES(classification)),
           source = IF(hr_attendance_daily.source = 'manual', 'manual', 'biometric'), calculated_at = NOW()"
    );
    $processed = 0;
    foreach ($employeeIds as $employeeId) {
        $punchStmt->bind_param('is', $employeeId, $attendanceDate);
        $punchStmt->execute();
        $punch = $punchStmt->get_result()->fetch_assoc() ?: [];
        $firstPunch = $punch['first_punch'] ?: null;
        $lastPunch = $punch['last_punch'] ?: null;
        $punchCount = (int) ($punch['punch_count'] ?? 0);

        $shiftStmt->bind_param(
            'sssssiisss',
            $attendanceDate,
            $attendanceDate,
            $attendanceDate,
            $attendanceDate,
            $attendanceDate,
            $companyId,
            $branchId,
            $employeeId,
            $attendanceDate,
            $attendanceDate
        );
        $shiftStmt->execute();
        $shift = $shiftStmt->get_result()->fetch_assoc() ?: [];
        if ($shift === []) {
            $defaultShiftStmt->bind_param(
                'sssssiiiis',
                $attendanceDate,
                $attendanceDate,
                $attendanceDate,
                $attendanceDate,
                $attendanceDate,
                $companyId,
                $branchId,
                $companyId,
                $branchId,
                $attendanceDate
            );
            $defaultShiftStmt->execute();
            $shift = $defaultShiftStmt->get_result()->fetch_assoc() ?: [];
        }
        $shiftId = !empty($shift['id']) ? (int) $shift['id'] : null;
        $workedMinutes = 0;
        $lateMinutes = 0;
        $earlyMinutes = 0;
        $breakMinutes = 0;
        $classification = 'absent';
        if ($calendarDay !== null && (int) $calendarDay['is_working'] !== 1) {
            if ($firstPunch !== null && $punchCount >= 2 && $lastPunch !== $firstPunch) {
                $minutes = hrmsShiftWorkedMinutes($attendanceDate, $firstPunch, $lastPunch, $shift);
                $workedMinutes = $minutes['worked'];
                $breakMinutes = $minutes['break'];
                $classification = 'off_day_work';
            } elseif ($firstPunch !== null) {
                $classification = 'incomplete';
            } else {
                $classification = $calendarDay['day_type'] === 'holiday' ? 'holiday' : 'weekly_off';
            }
        } elseif ($firstPunch !== null) {
            if ($punchCount < 2 || $lastPunch === $firstPunch) {
                $classification = 'incomplete';
            } else {
                $minutes = hrmsShiftWorkedMinutes($attendanceDate, $firstPunch, $lastPunch, $shift);
                $workedMinutes = $minutes['worked'];
                $breakMinutes = $minutes['break'];
                $thresholds = hrmsShiftThresholds($shift);
                if (!empty($shift['start_time'])) {
                    $scheduledStart = strtotime($attendanceDate . ' ' . $shift['start_time'])
                        + ((int) ($shift['late_grace_minutes'] ?? 0) * 60);
                    $lateMinutes = max(0, (int) floor((strtotime($firstPunch) - $scheduledStart) / 60));
                }
                if (!empty($shift['end_time'])) {
                    $scheduledEnd = strtotime($attendanceDate . ' ' . $shift['end_time']);
                    if (!empty($shift['start_time']) && $shift['end_time'] <= $shift['start_time']) {
                        $scheduledEnd = strtotime('+1 day', $scheduledEnd);
                    }
                    $scheduledEnd -= ((int) ($shift['early_leave_minutes'] ?? 0) * 60);
                    $earlyMinutes = max(0, (int) floor(($scheduledEnd - strtotime($lastPunch)) / 60));
                }
                if ($workedMinutes < $thresholds['half']) {
                    $classification = 'incomplete';
                } elseif ($workedMinutes < $thresholds['full']) {
                    $classification = 'half_day';
                } elseif ($lateMinutes > 0) {
                    $classification = 'late';
                } elseif ($earlyMinutes > 0) {
                    $classification = 'early_leave';
                } else {
                    $classification = 'on_time';
                }
            }
        }
        $upsertStmt->bind_param(
            'iiisissiiiis',
            $employeeId,
            $companyId,
            $branchId,
            $attendanceDate,
            $shiftId,
            $firstPunch,
            $lastPunch,
            $workedMinutes,
            $lateMinutes,
            $earlyMinutes,
            $breakMinutes,
            $classification
        );
        $upsertStmt->execute();
        $processed++;
    }
    $punchStmt->close();
    $shiftStmt->close();
    $defaultShiftStmt->close();
    $upsertStmt->close();
    return $processed;
}

function hrmsRecalculateAttendanceRange(mysqli $conn, int $companyId, ?int $branchId, string $fromDate, ?string $toDate = null): array
{
    $today = date('Y-m-d');
    $lastDate = $toDate !== null && $toDate < $today ? $toDate : $today;
    if ($fromDate > $lastDate) {
        return ['dates' => 0, 'employees' => 0];
    }

    $stmt = $conn->prepare(
        "SELECT DISTINCT source.attendance_date
         FROM (
             SELECT daily.attendance_date
             FROM hr_attendance_daily daily
             WHERE daily.attendance_date BETWEEN ? AND ? AND daily.company_id = ?
               AND (? IS NULL OR daily.branch_id = ?)
             UNION
             SELECT DATE(punch.punch_time) attendance_date
             FROM hr_biometric_punches punch
             INNER JOIN hr_biometric_devices device ON device.id = punch.device_id AND device.status = 1
             WHERE DATE(punch.punch_time) BETWEEN ? AND ? AND device.company_id = ?
               AND (? IS NULL OR device.branch_id = ?)
         ) source
         ORDER BY source.attendance_date"
    );
    $stmt->bind_param(
        'ssiiissiii',
        $fromDate,
        $lastDate,
        $companyId,
        $branchId,
        $branchId,
        $fromDate,
        $lastDate,
        $companyId,
        $branchId,
        $branchId
    );
    $stmt->execute();
    $dates = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'attendance_date');
    $stmt->close();

    $processedEmployees = 0;
    foreach ($dates as $attendanceDate) {
        $processedEmployees += hrmsRecalculateAttendance($conn, (string) $attendanceDate, $companyId, $branchId);
    }

    return ['dates' => count($dates), 'employees' => $processedEmployees];
}
