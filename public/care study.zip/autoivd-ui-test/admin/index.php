<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
date_default_timezone_set('Asia/Kolkata');
require_once 'db.php';
require_once 'constant.php';
require_once 'functions.php';
requireLogin();
$page = $_GET['page'] ?? 'dashboard';
if ($page === 'bom-management') {
    $page = 'store-setting';
}
if ($page === 'pi-generator') {
    header('Location: index.php?page=pi-requests');
    exit;
}

if (!is_string($page) || !preg_match('/^[a-z0-9_-]+$/i', $page)) {
    http_response_code(404);
    render(__DIR__ . "/404.php", ['pageTitle' => '404 - Page Not Found']);
    exit;
}

$pagesRoot = realpath(__DIR__ . '/pages');
$pageFile = realpath(__DIR__ . "/pages/{$page}.php");
if ($pagesRoot === false || $pageFile === false || !str_starts_with($pageFile, $pagesRoot . DIRECTORY_SEPARATOR)) {
    http_response_code(404);
    render(__DIR__ . "/404.php", ['pageTitle' => '404 - Page Not Found']);
    exit;
}

$permissionSlug = getPermissionSlugForPage($conn, $page);
if ($permissionSlug) {
    checkPageAccess($permissionSlug, $conn);
}

$pageTitle = Constant::CUSTOM_TITLES[$page] ?? ucwords(str_replace(['-', '_'], ' ', $page));

render($pageFile, ['pageTitle' => $pageTitle]);
