<?php

declare(strict_types=1);

/**
 * Audited, code-only Biochemistry template catalogue.
 *
 * Source: /2025 Biochemistry (39 complete BMR/BPR product families).
 * The installer materialises these definitions into structured layout_json;
 * no source PDF, DOC/DOCX or page image is used by the runtime workflow.
 */

function bmrBprBiochemistryItems(string $spec, string $defaultGroup = ''): array
{
    $items = [];
    $usedKeys = [];
    foreach (array_filter(array_map('trim', explode(';', $spec))) as $index => $row) {
        $parts = array_map('trim', explode('|', $row));
        $name = (string) ($parts[0] ?? '');
        if ($name === '') {
            continue;
        }
        $key = strtolower($name);
        $key = preg_replace('/[^a-z0-9]+/', '_', $key) ?: 'item_' . ($index + 1);
        $key = trim($key, '_');
        if (isset($usedKeys[$key])) {
            $key .= '_' . ($index + 1);
        }
        $usedKeys[$key] = true;
        $item = [
            'key' => $key,
            'name' => $name,
            'quantity' => (string) ($parts[1] ?? ''),
            'unit' => (string) ($parts[2] ?? ''),
        ];
        if ($defaultGroup !== '') {
            $item['group'] = $defaultGroup;
        }
        if (($parts[3] ?? '') !== '') {
            $item['container'] = (string) $parts[3];
        }
        if (($parts[4] ?? '') !== '') {
            $item['acceptable_range'] = (string) $parts[4];
        }
        $items[] = $item;
    }
    return $items;
}

function bmrBprBiochemistryBmr(
    string $name,
    string $mfr,
    int $pages,
    string $ingredients,
    string $standardBatch = '1.0 Litre',
    bool $preformed = false
): array {
    $items = bmrBprBiochemistryItems($ingredients);
    $steps = $preformed
        ? [
            "Issue the approved {$name} and verify its identity, lot number and required quantity.",
            "Prepare the required quantity without spilling or cross-contamination.",
            'Label the prepared reagent with product name and batch number and submit the sample to QC.',
        ]
        : [
            'Measure approximately 70% of the required de-ionized water in a clean, labelled container.',
            'Add the listed raw materials in the approved order with continuous stirring until dissolved.',
            'Make up to the required final volume with de-ionized water and mix for another 30 minutes.',
            'Label the container and keep the reagent at 2-8°C for the documented stabilization period.',
            'Submit the representative sample to QC for testing and attach the requisition/COA.',
        ];
    return [
        'product_name' => $name,
        'mfr_reference' => $mfr,
        'page_count' => $pages,
        'standard_batch' => $standardBatch,
        'ingredients' => $items,
        'manufacturing_steps' => $steps,
        'page3_step_count' => $pages >= 5 ? 2 : count($steps),
        'show_ipqc' => false,
    ];
}

function bmrBprBiochemistryBpr(
    string $name,
    string $mfr,
    int $pages,
    string $reagents,
    string $packing,
    string $standardBatch = '10 Kits'
): array {
    $reagentItems = bmrBprBiochemistryItems(
        $reagents,
        'In-process material / Raw material'
    );
    $packingItems = bmrBprBiochemistryItems($packing, 'Packing material');
    $reagentQuantities = [];
    foreach ($reagentItems as $item) {
        $reagentQuantities[$item['key']] = $item['quantity'];
    }
    $packingQuantities = [];
    foreach ($packingItems as $item) {
        $packingQuantities[$item['key']] = $item['quantity'];
    }
    return [
        'product_name' => $name,
        'mfr_reference' => $mfr,
        'page_count' => $pages,
        'standard_batch' => $standardBatch,
        'pack_size' => $standardBatch,
        'standard_yield' => 'NLT 98%',
        'reagents' => $reagentItems,
        'packing_materials' => $packingItems,
        'reagent_quantities' => $reagentQuantities,
        'packing_quantities' => $packingQuantities,
        'equipment' => [
            ['name' => 'Pipette'],
            ['name' => 'Measuring Cylinder'],
            ['name' => 'Bottle Top Dispenser'],
            ['name' => 'Dispenser / Filling Machine'],
        ],
    ];
}

function bmrBprBiochemistryCommonPacking(string $kind = 'standard'): string
{
    return match ($kind) {
        'single' => 'HDPE Brown/White Bottles|10|Nos.;Pack Inserts|10|Nos.;Labels of Reagent Bottles|10|Nos.;Labels of Boxes|10|Nos.;Packing Boxes|10|Nos.',
        'two' => 'HDPE Brown/White Bottles|20|Nos.;Pack Inserts|10|Nos.;Labels of Reagent Bottles|20|Nos.;Labels of Boxes|10|Nos.;Packing Boxes|10|Nos.',
        'three' => 'HDPE Brown/White Bottles|20|Nos.;Glass Bottles|10|Nos.;Pack Inserts|10|Nos.;Labels of Reagent/Calibrator Bottles|30|Nos.;Labels of Boxes|10|Nos.;Packing Boxes|10|Nos.',
        'ferritin' => '30 ml HDPE Bottle with cap (R1)|1|Nos.;10 ml HDPE Bottle with cap (R2)|1|Nos.;4 ml Glass Vials with cap (Calibrators)|4|Nos.;Pack Insert|1|Nos.;Packing Box|1|Nos.;Labels of Reagents|6|Nos.;Label of Box|1|Nos.',
        default => 'HDPE Brown/White Bottles|10|Nos.;Glass Bottles|10|Nos.;Pack Inserts|10|Nos.;Labels of Reagent Bottles|10|Nos.;Labels of Standard Bottles|10|Nos.;Labels of Boxes|10|Nos.;Packing Boxes|10|Nos.',
    };
}

function bmrBprBiochemistryCatalog(): array
{
    $approval = [
        'prepared_by' => 'Monika Mishra',
        'checked_by' => 'Shaurabh Kashyap',
        'approved_by' => 'Sanjay Kumar Yadav',
    ];
    $bmrAttachments = [
        'Material requisition note (process order)',
        'Line clearance check lists',
        'IP/RM COA (whatever is applicable)',
        'Requisition to QC for testing of intermediate samples',
        'QA batch manufacturing review record',
    ];
    $bprAttachments = [
        'Material requisition note (process order)',
        'Line clearance checklist',
        'QA batch production review record',
        'Finished-product COA',
    ];
    $family = static function (
        array $ids,
        string $name,
        string $code,
        string $description,
        array $bmrs,
        array $bprs
    ) use ($approval, $bmrAttachments, $bprAttachments): array {
        foreach ($bmrs as &$bmr) {
            $bmr['product_code'] = $code;
            $bmr['description'] = $description;
            $bmr['reagent_contents'] = implode(
                ', ',
                array_column($bmr['ingredients'] ?? [], 'name')
            );
            $bmr['approval_names'] = $approval;
            $bmr['attachment_documents'] = $bmrAttachments;
        }
        unset($bmr);
        foreach ($bprs as &$bpr) {
            $bpr['product_code'] = $code;
            $bpr['description'] = $description;
            $bpr['kit_content'] = implode(
                ', ',
                array_column($bpr['reagents'] ?? [], 'name')
            ) . ', Pack Insert';
            $bpr['approval_names'] = $approval;
            $bpr['attachment_documents'] = $bprAttachments;
        }
        unset($bpr);
        return [
            'product_ids' => $ids,
            'product_name' => $name,
            'product_code' => $code,
            'description' => $description,
            'bmr_documents' => $bmrs,
            'bpr_documents' => $bprs,
        ];
    };

    $families = [];
    $families['ada'] = $family(
        [415, 416, 417, 418, 918, 919, 920, 1954],
        'ADENOSINE DEAMINASE (ADA) REAGENT KIT',
        'BGADA',
        'Enzymatic reagent kit for quantitative estimation of Adenosine Deaminase activity.',
        [
            bmrBprBiochemistryBmr('ADA Reagent R1', 'BIPL-MFRIP-004', 3, 'Adenosine Deaminase Reagent 1 (Enzyme reagent)|600|ml', '900 ml', true),
            bmrBprBiochemistryBmr('ADA Reagent R2', 'BIPL-MFRIP-005', 3, 'Substrate Reagent|300|ml', '300 ml', true),
        ],
        [bmrBprBiochemistryBpr('ADENOSINE DEAMINASE (ADA) REAGENT KIT', 'BIPL-MFRFG-002', 9, 'ADA Reagent R1|20|ml|30 ml HDPE Bottle|±0.5 ml;ADA Reagent R2|10|ml|10 ml HDPE Bottle|±0.2 ml', '30 ml HDPE Bottle with cap|1|Nos.;10 ml HDPE Bottle with cap|1|Nos.;Pack Insert|1|Nos.;Packing Box|1|Nos.;Labels of Reagents|2|Nos.;Label of Box|1|Nos.', '1 Kit (30 ml)')]
    );
    $families['albumin'] = $family(
        [917, 1579, 1857],
        'Albumin',
        'BGALB',
        'Colorimetric reagent kit for quantitative estimation of Albumin.',
        [
            bmrBprBiochemistryBmr('Albumin Reagent', 'BIPL-MFRIP-006', 5, 'Succinic Acid|14.6|g;Sodium Hydroxide|2.1|g;Sodium Azide|1|g;Brij-35|4.4|g;Bromocresol Green|0.142|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Albumin Standard', 'BIPL-MFRIP-007', 4, 'Sodium Chloride|9|g;Sodium Azide|1|g;Bovine Serum Albumin|40|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Albumin', 'BIPL-MFRFG-003', 9, 'Albumin Reagent|1000|ml;Albumin Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['alp'] = $family(
        [915, 916],
        'Alkaline Phosphatase',
        'BGALP',
        'Reagent for quantitative estimation of Alkaline Phosphatase activity.',
        [bmrBprBiochemistryBmr('Alkaline Phosphatase Reagent', 'BIPL-MFRIP-008', 5, 'Magnesium Acetate|2|g;Sodium Azide|260|mg;Zinc Sulphate|20|mg;AMP Buffer|40|ml;Tris Buffer|200|mg;EGTA|100|mg;Charcoal|12.5|g;DTPA|200|mg;PNPP|0.725|g;De-ionized Water|Q.S. 1|litre')],
        [bmrBprBiochemistryBpr('Alkaline Phosphatase', 'BIPL-MFRFG-004', 9, 'Alkaline Phosphatase Reagent|1000|ml', bmrBprBiochemistryCommonPacking('single'))]
    );
    $families['amylase'] = $family(
        [914, 2017],
        'Alpha Amylase',
        'BGAMY',
        'Reagent for quantitative estimation of Alpha Amylase activity.',
        [bmrBprBiochemistryBmr('Alpha Amylase Reagent', 'BIPL-MFRIP-010', 5, 'MES|9.76|g;Sodium Chloride|17.53|g;Calcium Chloride|2.5|g;Potassium Thiocyanate|43.73|mg;Sodium Azide|1|g;CNPG|2.6|g;De-ionized Water|Q.S. 1|litre')],
        [bmrBprBiochemistryBpr('Alpha Amylase', 'BIPL-MFRFG-005', 9, 'Alpha Amylase Reagent|1000|ml', bmrBprBiochemistryCommonPacking('single'))]
    );
    $families['ammonia'] = $family(
        [913, 1773, 1775],
        'Ammonia Reagent',
        'BGAMN',
        'Enzymatic reagent kit for quantitative estimation of Ammonia.',
        [
            bmrBprBiochemistryBmr('Ammonia Reagent R1', 'BIPL-MFRIP-011', 5, 'Tris|12.114|g;Alpha-Ketoglutaric Acid Sodium Salt|1.430|g;EDTA Disodium|0.372|g;Bovine Serum Albumin|0.5|g;Sodium Azide|0.5|g;Potassium Hydroxide|13|g;Sulphuric Acid|8|ml;GLDH|0.95|KU;LDH|1.5|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Ammonia Reagent R2', 'BIPL-MFRIP-012', 4, 'Tris|8|g;Alpha-Ketoglutarate Disodium|18.7|g;NADH|1.05|g;ProClin 300|0.25|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Ammonia Standard', 'BIPL-MFRIP-013', 4, 'Sodium Azide|1.2|g;Ammonium Sulphate|0.098|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Ammonia Reagent', 'BIPL-MFRFG-006', 9, 'Ammonia Reagent|1000|ml;Ammonia Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['aso_turbi'] = $family(
        [1042],
        'ASO Turbilatex',
        'BGASOT',
        'Turbidimetric reagent kit for quantitative estimation of Anti-Streptolysin O.',
        [
            bmrBprBiochemistryBmr('ASO Turbidimetry Reagent R1', 'BIPL-MFRIP-274', 3, 'ASO Turbidimetry Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('ASO Turbidimetry Reagent R2', 'BIPL-MFRIP-274', 3, 'ASO Turbidimetry Reagent R2|200|ml', '200 ml', true),
            bmrBprBiochemistryBmr('ASO Turbidimetry Calibrator', 'BIPL-MFRIP-274', 4, 'ASO Turbidimetry Calibrator|Lyophilized|-;De-ionized Water|1|ml', '1 Calibrator', true),
        ],
        [bmrBprBiochemistryBpr('ASO Turbilatex', 'BIPL-MFRFG-130', 9, 'ASO Turbidimetry Reagent R1|800|ml;ASO Turbidimetry Reagent R2|200|ml;ASO Turbidimetry Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['bilirubin_direct'] = $family(
        [910],
        'Bilirubin Direct',
        'BGDBIL',
        'Reagent kit for quantitative estimation of Direct Bilirubin.',
        [
            bmrBprBiochemistryBmr('Bilirubin Direct D1', 'BIPL-MFRIP-016', 4, 'Sulphanilic Acid|5|g;Hydrochloric Acid|2|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Bilirubin Direct D2', 'BIPL-MFRIP-017', 4, 'Sodium Nitrite|50|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Bilirubin Direct', 'BIPL-MFRFG-007', 9, 'Bilirubin Direct D1|1000|ml;Bilirubin Direct D2|20|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['bilirubin_total'] = $family(
        [909],
        'Bilirubin Total',
        'BGTBIL',
        'Reagent kit for quantitative estimation of Total Bilirubin.',
        [
            bmrBprBiochemistryBmr('Bilirubin Total T1', 'BIPL-MFRIP-014', 4, 'Cetrimide|11|g;Sulphanilic Acid|5.5|g;Hydrochloric Acid|5|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Bilirubin Total T2', 'BIPL-MFRIP-015', 4, 'Sodium Nitrite|50|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Bilirubin Total', 'BIPL-MFRFG-007', 9, 'Bilirubin Total T1|1000|ml;Bilirubin Total T2|20|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['bilirubin_combined'] = $family(
        [908],
        'Total & Direct Bilirubin',
        'BGTDBIL',
        'Combined catalog kit supplied with separate Total and Direct Bilirubin product documents.',
        [
            bmrBprBiochemistryBmr('Bilirubin Total T1', 'BIPL-MFRIP-014', 4, 'Cetrimide|11|g;Sulphanilic Acid|5.5|g;Hydrochloric Acid|5|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Bilirubin Total T2', 'BIPL-MFRIP-015', 4, 'Sodium Nitrite|50|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Bilirubin Direct D1', 'BIPL-MFRIP-016', 4, 'Sulphanilic Acid|5|g;Hydrochloric Acid|2|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Bilirubin Direct D2', 'BIPL-MFRIP-017', 4, 'Sodium Nitrite|50|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [
            bmrBprBiochemistryBpr('Bilirubin Total', 'BIPL-MFRFG-007', 9, 'Bilirubin Total T1|1000|ml;Bilirubin Total T2|20|ml', bmrBprBiochemistryCommonPacking('two')),
            bmrBprBiochemistryBpr('Bilirubin Direct', 'BIPL-MFRFG-007', 9, 'Bilirubin Direct D1|1000|ml;Bilirubin Direct D2|20|ml', bmrBprBiochemistryCommonPacking('two')),
        ]
    );
    $families['calcium'] = $family(
        [903, 1913],
        'Calcium',
        'BGCAL',
        'Colorimetric reagent kit for quantitative estimation of Calcium.',
        [
            bmrBprBiochemistryBmr('Calcium Reagent', 'BIPL-MFRIP-018', 5, 'Hydrochloric Acid|5.5|ml;Arsenazo III|0.13|g;8-Hydroxyquinoline|0.05|g;Imidazole|6.8|g;Brij-35|1|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Calcium Standard', 'BIPL-MFRIP-019', 4, 'Calcium Carbonate|0.25|g;Hydrochloric Acid|8.3|ml;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Calcium', 'BIPL-MFRFG-008', 9, 'Calcium Reagent|1000|ml;Calcium Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['chloride'] = $family(
        [899],
        'Chloride Reagent',
        'BGCHL',
        'Colorimetric reagent kit for quantitative estimation of Chloride.',
        [
            bmrBprBiochemistryBmr('Chloride Reagent', 'BIPL-MFRIP-020', 4, 'Mercuric Thiocyanate|0.320|g;Methanol|50|ml;Ferric Nitrate|15|g;Mercuric Nitrate|0.034|g;Nitric Acid|4|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Chloride Standard', 'BIPL-MFRIP-021', 4, 'Hydrochloric Acid|8.3|ml;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Chloride Reagent', 'BIPL-MFRFG-009', 11, 'Chloride Reagent|1000|ml;Chloride Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['hdl_direct'] = $family(
        [873, 874, 875, 1419],
        'Cholesterol HDL Direct',
        'BGHDLD',
        'Direct homogeneous reagent kit for quantitative estimation of HDL Cholesterol.',
        [
            bmrBprBiochemistryBmr('Cholesterol HDL Direct R1', 'BIPL-MFRIP-024', 5, 'PIPES|15.2|g;TOOS|400|mg;Sodium Azide|500|mg;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Cholesterol HDL Direct R2', 'BIPL-MFRIP-025', 5, 'Potassium Dihydrogen Phosphate|1|g;ProClin|0.06|ml;Bovine Serum Albumin|0.37|g;4-Aminoantipyrine|116.6|mg;A60|28.33|ml;TOOS|42|mg;Cholesterol Oxidase|0.66|KU;Cholesterol Esterase|1.33|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Cholesterol HDL Direct Calibrator', 'BIPL-MFRIP-026', 4, 'HDL Direct Calibrator|Lyophilized|-;De-ionized Water|0.5|ml', '1 Calibrator', true),
        ],
        [bmrBprBiochemistryBpr('Cholesterol HDL Direct', 'BIPL-MFRFG-011', 10, 'Cholesterol HDL Direct R1|750|ml;Cholesterol HDL Direct R2|250|ml;Cholesterol HDL Direct Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['ldl_direct'] = $family(
        [867, 868],
        'Cholesterol LDL Direct',
        'BGCHOLDLD',
        'Direct homogeneous reagent kit for quantitative estimation of LDL Cholesterol.',
        [
            bmrBprBiochemistryBmr('Cholesterol LDL Direct Reagent 1', 'BIPL-MFRIP-029', 5, 'PIPES Disodium|1.66|g;Bovine Serum Albumin|2|g;Potassium Dihydrogen Phosphate|0.6|g;Magnesium Chloride|0.63|g;A60|1|ml;Sodium Azide|100|mg;TOOS|0.66|g;Cholesterol Oxidase|2.33|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Cholesterol LDL Direct Reagent 2', 'BIPL-MFRIP-030', 5, 'PIPES Disodium|4.28|g;Potassium Dihydrogen Phosphate|1|g;Sodium Azide|1.8|g;A60|142.85|ml;4-Aminoantipyrine|214.28|g;Peroxidase|14.28|mg;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Cholesterol LDL Direct Calibrator', 'BIPL-MFRIP-031', 4, 'LDL Direct Calibrator|Lyophilized|-;De-ionized Water|0.5|ml', '1 Calibrator', true),
        ],
        [bmrBprBiochemistryBpr('Cholesterol LDL Direct', 'BIPL-MFRFG-013', 9, 'Cholesterol LDL Direct Reagent 1|750|ml;Cholesterol LDL Direct Reagent 2|250|ml;Cholesterol LDL Direct Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['cholesterol_total'] = $family(
        [898, 1420],
        'Cholesterol Total',
        'BGCHO',
        'Enzymatic reagent kit for quantitative estimation of Total Cholesterol.',
        [
            bmrBprBiochemistryBmr('Cholesterol Total Reagent', 'BIPL-MFRIP-032', 6, 'PIPES|6|g;Tris|5|g;Magnesium Acetate|1|g;Sodium Cholate|3|g;4-Chloro-m-Cresol|0.2|g;p-Hydroxy Benzoic Acid|1.32|g;Sodium Azide|0.5|g;4-Aminoantipyrine|0.07|g;Cholesterol Oxidase|0.8|KU;Cholesterol Esterase|0.8|KU;Peroxidase|1.5|KU;Triton X-100|2|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Cholesterol Total Standard', 'BIPL-MFRIP-033', 4, 'Cholesterol|2|g;Ethanol|50|ml;Sodium Azide|1|g;Triton X-100|250|ml;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Cholesterol Total', 'BIPL-MFRFG-014', 9, 'Cholesterol Total Reagent|1000|ml;Cholesterol Total Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['ckmb'] = $family(
        [896, 897],
        'Creatine Kinase MB',
        'BGCKMB',
        'Kinetic reagent kit for quantitative estimation of CK-MB activity.',
        [
            bmrBprBiochemistryBmr('Creatine Kinase MB Reagent R1', 'BIPL-MFRIP-038', 3, 'Creatine Kinase MB Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('Creatine Kinase MB Reagent R2', 'BIPL-MFRIP-039', 3, 'Creatine Kinase MB Reagent R2|200|ml', '200 ml', true),
        ],
        [bmrBprBiochemistryBpr('Creatine Kinase MB', 'BIPL-MFRFG-017', 9, 'Creatine Kinase MB Reagent R1|800|ml;Creatine Kinase MB Reagent R2|200|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['cknac'] = $family(
        [895],
        'Creatine Kinase NAC',
        'BGCKNAC',
        'Kinetic reagent kit for quantitative estimation of CK-NAC activity.',
        [
            bmrBprBiochemistryBmr('Creatine Kinase NAC Reagent R1', 'BIPL-MFRIP-040', 3, 'Creatine Kinase NAC Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('Creatine Kinase NAC Reagent R2', 'BIPL-MFRIP-041', 3, 'Creatine Kinase NAC Reagent R2|800|ml', '800 ml', true),
        ],
        [bmrBprBiochemistryBpr('Creatine Kinase NAC', 'BIPL-MFRFG-018', 9, 'Creatine Kinase NAC Reagent R1|800|ml;Creatine Kinase NAC Reagent R2|200|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['creatinine'] = $family(
        [894],
        'Creatinine',
        'BGCRE',
        'Jaffe reagent kit for quantitative estimation of Creatinine.',
        [
            bmrBprBiochemistryBmr('Creatinine Reagent R1', 'BIPL-MFRIP-044', 4, 'Sodium Hydroxide|9|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Creatinine Reagent R2', 'BIPL-MFRIP-045', 4, 'Picric Acid|13|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Creatinine Standard', 'BIPL-MFRIP-046', 4, 'Hydrochloric Acid|7|ml;Creatinine|20|mg;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Creatinine', 'BIPL-MFRFG-020', 10, 'Creatinine Reagent R1|500|ml;Creatinine Reagent R2|500|ml;Creatinine Standard|10|ml', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['crp_turbi'] = $family(
        [1036, 1037, 1038],
        'CRP Turbilatex',
        'BGCRPT',
        'Turbidimetric reagent kit for quantitative estimation of C-Reactive Protein.',
        [
            bmrBprBiochemistryBmr('CRP Turbidimetry Reagent R1', 'BIPL-MFRIP-193', 3, 'CRP Turbidimetry Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('CRP Turbidimetry Reagent R2', 'BIPL-MFRIP-193', 3, 'CRP Turbidimetry Reagent R2|200|ml', '200 ml', true),
            bmrBprBiochemistryBmr('CRP Turbidimetry Calibrator', 'BIPL-MFRIP-193', 4, 'CRP Turbidimetry Calibrator|Lyophilized|-;De-ionized Water|1|ml', '1 Calibrator', true),
        ],
        [bmrBprBiochemistryBpr('CRP Turbilatex', 'BIPL-MFRFG-131', 9, 'CRP Turbidimetry Reagent R1|800|ml;CRP Turbidimetry Reagent R2|200|ml;CRP Turbidimetry Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['d_dimer'] = $family(
        [892],
        'D-Dimer Turbilatex',
        'BGDDMRT',
        'Turbidimetric reagent kit for quantitative estimation of D-Dimer.',
        [
            bmrBprBiochemistryBmr('D-Dimer Turbidimetry Reagent R1', 'BIPL-MFRIP-194', 3, 'D-Dimer Turbidimetry Reagent R1|750|ml', '750 ml', true),
            bmrBprBiochemistryBmr('D-Dimer Turbidimetry Reagent R2', 'BIPL-MFRIP-194', 3, 'D-Dimer Turbidimetry Reagent R2|250|ml', '250 ml', true),
            bmrBprBiochemistryBmr('D-Dimer Turbidimetry Calibrator', 'BIPL-MFRIP-194', 4, 'D-Dimer Turbidimetry Calibrator|Lyophilized|-;Calibrator Diluent|1|ml', '1 Calibrator', true),
        ],
        [bmrBprBiochemistryBpr('D-Dimer Turbilatex', 'BIPL-MFRFG-134', 9, 'D-Dimer Turbidimetry Reagent R1|750|ml;D-Dimer Turbidimetry Reagent R2|250|ml;D-Dimer Turbidimetry Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['ferritin'] = $family(
        [890],
        'Ferritin Reagent',
        'BGFER',
        'Latex immunoassay reagent kit for quantitative estimation of Ferritin.',
        [bmrBprBiochemistryBmr('Ferritin Reagent', 'BIPL-MFRIP-196', 4, 'Ferritin Latex Reagent R1|30|ml;Ferritin Reagent R2|10|ml;Calibrator 1|Lyophilized|-;Calibrator 2|Lyophilized|-;Calibrator 3|Lyophilized|-;Calibrator 4|Lyophilized|-;Ferritin Hemolysing Solution Reagent R4|40|ml', '1 Kit (40 ml)', true)],
        [bmrBprBiochemistryBpr('Ferritin Reagent', 'BIPL-MFRFG-135', 11, 'Ferritin Latex Reagent R1|30|ml|30 ml HDPE Bottle|±0.5 ml;Ferritin Reagent R2|10|ml|10 ml HDPE Bottle|±0.2 ml;Calibrator 1|Lyophilized|-|4 ml Glass Vial|-;Calibrator 2|Lyophilized|-|4 ml Glass Vial|-;Calibrator 3|Lyophilized|-|4 ml Glass Vial|-;Calibrator 4|Lyophilized|-|4 ml Glass Vial|-', bmrBprBiochemistryCommonPacking('ferritin'), '1 Kit (40 ml)')]
    );
    $families['g6pd'] = $family(
        [889],
        'G6PD',
        'BGG6PD',
        'Kinetic reagent kit for quantitative estimation of G6PD activity.',
        [
            bmrBprBiochemistryBmr('G6PD Reagent R1', 'BIPL-MFRIP-053', 4, 'G6PD Reagent R1|750|ml', '750 ml', true),
            bmrBprBiochemistryBmr('G6PD Reagent R2', 'BIPL-MFRIP-054', 4, 'G6PD Reagent R2|250|ml', '250 ml', true),
        ],
        [bmrBprBiochemistryBpr('G6PD', 'BIPL-MFRFG-024', 9, 'G6PD Reagent R1|750|ml;G6PD Reagent R2|250|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['gamma_gt'] = $family(
        [886, 887, 888],
        'Gamma GT',
        'BGGGT',
        'Kinetic reagent kit for quantitative estimation of Gamma Glutamyl Transferase.',
        [
            bmrBprBiochemistryBmr('Gamma GT Reagent R1', 'BIPL-MFRIP-049', 3, 'Gamma GT Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('Gamma GT Reagent R2', 'BIPL-MFRIP-050', 3, 'Gamma GT Substrate Reagent|200|ml;Gamma GT Substrate Powder|20|Nos.', '200 ml', true),
        ],
        [bmrBprBiochemistryBpr('Gamma GT', 'BIPL-MFRFG-022', 10, 'Gamma GT Reagent R1|800|ml;Gamma GT Reagent R2|200|ml;Gamma GT Substrate Powder|20|Nos.', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['glucose'] = $family(
        [883, 884, 885],
        'Glucose',
        'BGGLU',
        'GOD-POD reagent kit for quantitative estimation of Glucose.',
        [
            bmrBprBiochemistryBmr('Glucose Reagent', 'BIPL-MFRIP-051', 6, 'Potassium Dihydrogen Phosphate|13.60|g;Tris Base|6.06|g;Ammonium Sulphate|10|g;Propane-1,2-diol|10|ml;Phenol|0.47|g;Sodium Azide|0.50|g;EDTA Disodium|0.50|g;4-Aminoantipyrine|0.063|g;Potassium Hydroxide|1|g;Glucose Oxidase|25|KU;Peroxidase|2|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Glucose Standard', 'BIPL-MFRIP-052', 4, 'Benzoic Acid|1.5|g;Dextrose|1.0|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Glucose', 'BIPL-MFRFG-023', 9, 'Glucose Reagent|1000|ml;Glucose Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['hba1c'] = $family(
        [881],
        'HbA1c',
        'BGHBA1C',
        'Latex reagent kit for quantitative estimation of glycated haemoglobin.',
        [bmrBprBiochemistryBmr('HbA1c Reagent', 'BIPL-MFRIP-055', 4, 'HbA1c Latex Reagent R1|30|ml;HbA1c Reagent R2|10|ml;HbA1c Hemolysing Solution Reagent R4|40|ml', '1 Kit (40 ml)', true)],
        [bmrBprBiochemistryBpr('HbA1c', 'BIPL-MFRFG-025', 11, 'HbA1c Latex Reagent R1|30|ml;HbA1c Reagent R2|10|ml;Calibrator 1|Lyophilized|-;Calibrator 2|Lyophilized|-;Calibrator 3|Lyophilized|-;Calibrator 4|Lyophilized|-;Calibrator 5|Lyophilized|-;HbA1c Hemolysing Solution|40|ml', bmrBprBiochemistryCommonPacking('ferritin'), '1 Kit (40 ml)')]
    );
    $families['hdl_ppt'] = $family(
        [876],
        'HDL Cholesterol PPT',
        'BGHDL',
        'Precipitating reagent kit for quantitative estimation of HDL Cholesterol.',
        [
            bmrBprBiochemistryBmr('HDL Cholesterol PPT Reagent', 'BIPL-MFRIP-022', 4, 'Phosphotungstic Acid|7|g;Magnesium Chloride|9.6|g;Sodium Hydroxide|0.143|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('HDL Cholesterol PPT Standard', 'BIPL-MFRIP-023', 4, 'Triton X-100|150|ml;Cholesterol|0.5|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('HDL Cholesterol PPT', 'BIPL-MFRFG-010', 9, 'HDL Cholesterol PPT Reagent|1000|ml;HDL Cholesterol PPT Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['ldh'] = $family(
        [870],
        'Lactate Dehydrogenase-P',
        'BGLDH',
        'Kinetic reagent kit for quantitative estimation of LDH activity.',
        [
            bmrBprBiochemistryBmr('LDH Reagent R1', 'BIPL-MFRIP-064', 3, 'LDH Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('LDH Reagent R2', 'BIPL-MFRIP-065', 3, 'LDH Reagent R2|200|ml', '200 ml', true),
        ],
        [bmrBprBiochemistryBpr('Lactate Dehydrogenase-P', 'BIPL-MFRFG-028', 9, 'LDH Reagent R1|800|ml;LDH Reagent R2|200|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['lipase'] = $family(
        [865],
        'Lipase',
        'BGLIP',
        'Enzymatic reagent kit for quantitative estimation of Lipase activity.',
        [bmrBprBiochemistryBmr('Lipase Reagent', 'BIPL-MFRIP-066', 4, 'Lipase Reagent R1|750|ml;Lipase Reagent R2|250|ml', '1 Kit', true)],
        [bmrBprBiochemistryBpr('Lipase', 'BIPL-MFRFG-029', 9, 'Lipase Reagent R1|750|ml;Lipase Reagent R2|250|ml;Lipase Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['magnesium'] = $family(
        [863],
        'Magnesium',
        'BGMAG',
        'Colorimetric reagent kit for quantitative estimation of Magnesium.',
        [
            bmrBprBiochemistryBmr('Magnesium Reagent', 'BIPL-MFRIP-068', 4, 'Brij-35|32|g;PEG 4000|5|g;EGTA|1|g;Sodium Hydroxide|15.07|g;ProClin 300|0.1|ml;Xylidyl Blue Dye|0.054|mg;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Magnesium Standard', 'BIPL-MFRIP-069', 4, 'Magnesium Acetate|10.2|g;Sodium Azide|1.44|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Magnesium', 'BIPL-MFRFG-030', 9, 'Magnesium Reagent|1000|ml;Magnesium Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['microprotein'] = $family(
        [858, 859, 860, 1779, 1945],
        'Micro Protein',
        'BGMIC',
        'Pyrogallol red reagent kit for quantitative estimation of Micro Protein.',
        [
            bmrBprBiochemistryBmr('Micro Protein Reagent', 'BIPL-MFRIP-070', 5, 'Succinic Acid|5.9|g;Sodium Benzoate|0.5|g;Pyrogallol Red|0.03|g;Methanol|20|ml;Sodium Oxalate|0.14|g;Sodium Lauryl Sulphate|0.025|g;Sodium Molybdate|0.035|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Micro Protein Standard', 'BIPL-MFRIP-071', 4, 'Sodium Azide|1|g;Sodium Chloride|9|g;Bovine Serum Albumin|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Micro Protein', 'BIPL-MFRFG-031', 9, 'Micro Protein Reagent|1000|ml;Micro Protein Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['phosphorus'] = $family(
        [852],
        'Phosphorus',
        'BGPHO',
        'Molybdate reagent kit for quantitative estimation of inorganic Phosphorus.',
        [
            bmrBprBiochemistryBmr('Phosphorus Reagent', 'BIPL-MFRIP-072', 4, 'Ammonium Heptamolybdate / Tetramolybdate|0.35|g;Triton X-100|1.53|ml;Sulphuric Acid|9|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Phosphorus Standard', 'BIPL-MFRIP-073', 4, 'Disodium Hydrogen Phosphate|0.270|g;Sulphuric Acid|6.5|ml;Sodium Azide|1.116|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Phosphorus', 'BIPL-MFRFG-032', 9, 'Phosphorus Reagent|1000|ml;Phosphorus Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['potassium'] = $family(
        [850, 851],
        'Potassium',
        'BGPOT',
        'Colorimetric reagent kit for quantitative estimation of Potassium.',
        [
            bmrBprBiochemistryBmr('Potassium Reagent', 'BIPL-MFRIP-077', 4, 'Sodium Tetraphenylborate|13|g;EDTA Disodium|10|g;Sodium Hydroxide|3.7|g;Formaldehyde|100|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Potassium Standard', 'BIPL-MFRIP-078', 4, 'Potassium Chloride|405|mg;Sodium Chloride|8.2|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Potassium', 'BIPL-MFRFG-033', 9, 'Potassium Reagent|1000|ml;Potassium Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['rf_turbi'] = $family(
        [1030, 1031],
        'RF Turbilatex',
        'BGRFT',
        'Turbidimetric reagent kit for quantitative estimation of Rheumatoid Factor.',
        [
            bmrBprBiochemistryBmr('RF Turbidimetry Reagent R1', 'BIPL-MFRIP-198', 3, 'RF Turbidimetry Reagent R1|800|ml', '800 ml', true),
            bmrBprBiochemistryBmr('RF Turbidimetry Reagent R2', 'BIPL-MFRIP-198', 3, 'RF Turbidimetry Reagent R2|200|ml', '200 ml', true),
            bmrBprBiochemistryBmr('RF Turbidimetry Calibrator', 'BIPL-MFRIP-198', 4, 'RF Turbidimetry Calibrator|Lyophilized|-;De-ionized Water|2|ml', '1 Calibrator', true),
        ],
        [bmrBprBiochemistryBpr('RF Turbilatex', 'BIPL-MFRFG-132', 10, 'RF Turbidimetry Reagent R1|800|ml;RF Turbidimetry Reagent R2|200|ml;RF Turbidimetry Calibrator|Lyophilized|-', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['sgot'] = $family(
        [848, 849, 1437],
        'SGOT',
        'BGSGOT',
        'Kinetic reagent kit for quantitative estimation of AST/SGOT activity.',
        [
            bmrBprBiochemistryBmr('SGOT Reagent R1', 'BIPL-MFRIP-086', 5, 'Tris|12.114|g;EDTA|1.020|g;L-Aspartate|33|g;Alpha-Ketoglutarate|2.51|g;Sodium Azide|0.5|g;Bovine Serum Albumin|2.5|g;LDH|2|KU;MDH|0.22|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('SGOT Reagent R2', 'BIPL-MFRIP-087', 4, 'Sodium Carbonate|0.9|g;Beta-NADH|1|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('SGOT', 'BIPL-MFRFG-036', 9, 'SGOT Reagent R1|800|ml;SGOT Reagent R2|200|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['sgpt'] = $family(
        [846, 847],
        'SGPT',
        'BGSGPT',
        'Kinetic reagent kit for quantitative estimation of ALT/SGPT activity.',
        [
            bmrBprBiochemistryBmr('SGPT Reagent R1', 'BIPL-MFRIP-084', 5, 'EDTA Disodium|1.020|g;Tris Base|12.114|g;Aminopropionic Acid|31|g;Alpha-Ketoglutarate|2.510|g;Sodium Azide|0.500|g;Bovine Serum Albumin|2.5|g;LDH|3.5|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('SGPT Reagent R2', 'BIPL-MFRIP-085', 4, 'Sodium Carbonate|0.90|g;Sodium Azide|1|g;Beta-NADH|1|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('SGPT', 'BIPL-MFRFG-035', 9, 'SGPT Reagent R1|800|ml;SGPT Reagent R2|200|ml', bmrBprBiochemistryCommonPacking('two'))]
    );
    $families['sodium'] = $family(
        [845, 1776],
        'Sodium',
        'BGSOD',
        'Colorimetric reagent kit for quantitative estimation of Sodium.',
        [
            bmrBprBiochemistryBmr('Sodium Reagent', 'BIPL-MFRIP-082', 5, 'DTPA|250|mg;Triethanolamine|5|ml;Dimethyl Sulfoxide|200|ml;Chlorophosphonazo III|30|mg;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Sodium Standard', 'BIPL-MFRIP-083', 4, 'Potassium Chloride|405|mg;Sodium Chloride|8.2|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Sodium', 'BIPL-MFRFG-034', 9, 'Sodium Reagent|1000|ml;Sodium Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['total_protein'] = $family(
        [842, 1780],
        'Total Protein',
        'BGTP',
        'Biuret reagent kit for quantitative estimation of Total Protein.',
        [
            bmrBprBiochemistryBmr('Total Protein Reagent', 'BIPL-MFRIP-088', 5, 'Copper Sulphate Pentahydrate|3|g;Potassium Sodium Tartrate|9|g;Sodium Hydroxide|8|g;Potassium Iodide|3|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Total Protein Standard', 'BIPL-MFRIP-089', 5, 'Disodium Hydrogen Phosphate|4.080|g;Sodium Dihydrogen Phosphate|2|g;EDTA|1|g;Sodium Azide|1|g;Bovine Serum Albumin|65|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Total Protein', 'BIPL-MFRFG-037', 9, 'Total Protein Reagent|1000|ml;Total Protein Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['triglyceride'] = $family(
        [840, 841, 1568],
        'Triglyceride',
        'BGTGL',
        'Enzymatic reagent kit for quantitative estimation of Triglycerides.',
        [
            bmrBprBiochemistryBmr('Triglyceride Reagent', 'BIPL-MFRIP-091', 6, 'PIPES|10|g;Sodium Hydroxide|2|g;Magnesium Acetate|1|g;DTPA|0.38|g;4-Chloro-m-Cresol|0.2|g;L-Glutamic Acid|25|g;TOOS|0.16|g;4-Aminoantipyrine|0.02|g;ATP|0.4|g;Sodium Azide|0.5|g;Bovine Serum Albumin|0.5|g;Lipoprotein Lipase|5.5|KU;L-Glycerophosphate Oxidase|5|KU;Glycerokinase|2|KU;Peroxidase|3|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Triglyceride Standard', 'BIPL-MFRIP-092', 4, 'Sodium Azide|1|g;Glycerol|0.9|ml;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Triglyceride', 'BIPL-MFRFG-039', 9, 'Triglyceride Reagent|1000|ml;Triglyceride Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );
    $families['urea_berthelot'] = $family(
        [836],
        'Urea Berthelot',
        'BGUREBRT',
        'Berthelot reagent kit for quantitative estimation of Urea.',
        [
            bmrBprBiochemistryBmr('Urea Berthelot Reagent R1', 'BIPL-MFRIP-093', 5, 'Disodium Hydrogen Phosphate|10.55|g;Potassium Dihydrogen Phosphate|0.93|g;Sodium Salicylate|9|g;Sodium Nitroprusside|0.75|g;Sodium Sulphite|0.3|g;EDTA|0.38|g;Sodium Azide|0.5|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Urea Berthelot Reagent R2', 'BIPL-MFRIP-094', 5, 'Disodium Hydrogen Phosphate|10.55|g;Potassium Dihydrogen Phosphate|0.93|g;Sodium Sulphite|0.3|g;EDTA|0.38|g;Sodium Azide|0.5|g;Urease|25|KU;Bovine Serum Albumin|0.5|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Urea Berthelot Reagent R3', 'BIPL-MFRIP-095', 5, 'Disodium Hydrogen Phosphate|13.2|g;Potassium Dihydrogen Phosphate|0.925|g;Sodium Hydroxide|8.3|g;Sodium Hypochlorite 4%|20|ml;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Urea Berthelot Standard', 'BIPL-MFRIP-096', 4, 'Benzoic Acid|2|g;Urea|0.4|g;Bovine Serum Albumin|2|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Urea Berthelot', 'BIPL-MFRFG-040', 10, 'Urea Berthelot Reagent R1|500|ml;Urea Berthelot Reagent R2|500|ml;Urea Berthelot Reagent R3|500|ml;Urea Berthelot Standard|10|ml', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['urea_uv'] = $family(
        [834, 835, 1467],
        'Urea UV',
        'BGURE',
        'UV kinetic reagent kit for quantitative estimation of Urea.',
        [
            bmrBprBiochemistryBmr('Urea UV Reagent R1', 'BIPL-MFRIP-097', 6, 'Tris|12.114|g;Alpha-Ketoglutaric Acid|1.43|g;EDTA|0.372|g;Sodium Azide|0.5|g;Potassium Hydroxide|13|g;Sulphuric Acid|8|ml;GLDH|0.95|KU;Urease|10|KU;Bovine Serum Albumin|0.5|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Urea UV Reagent R2', 'BIPL-MFRIP-098', 5, 'Sodium Carbonate|0.9|g;Beta-NADH|1|g;Sodium Azide|1|g;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Urea UV Standard', 'BIPL-MFRIP-099', 4, 'Benzoic Acid|2|g;Urea|0.5|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Urea UV', 'BIPL-MFRFG-041', 10, 'Urea UV Reagent R1|800|ml;Urea UV Reagent R2|200|ml;Urea UV Standard|10|ml', bmrBprBiochemistryCommonPacking('three'))]
    );
    $families['uric_acid'] = $family(
        [832, 833, 1438],
        'Uric Acid',
        'BGURI',
        'Enzymatic reagent kit for quantitative estimation of Uric Acid.',
        [
            bmrBprBiochemistryBmr('Uric Acid Reagent', 'BIPL-MFRIP-100', 6, 'PIPES|15.08|g;Tris|12.74|g;DTPA|0.38|g;TOOS|0.16|g;4-Aminoantipyrine|0.2|g;Sodium Azide|0.1|g;Bovine Serum Albumin|0.5|g;Triton X-100|0.5|ml;Uricase|0.15|KU;Peroxidase|1|KU;De-ionized Water|Q.S. 1|litre'),
            bmrBprBiochemistryBmr('Uric Acid Standard', 'BIPL-MFRIP-101', 5, 'Disodium Hydrogen Phosphate|4.16|g;Sodium Dihydrogen Phosphate|2.5|g;EDTA|0.374|g;Sodium Azide|1|g;Lithium Carbonate|0.05|g;Uric Acid|0.065|g;De-ionized Water|Q.S. 1|litre'),
        ],
        [bmrBprBiochemistryBpr('Uric Acid', 'BIPL-MFRFG-042', 9, 'Uric Acid Reagent|1000|ml;Uric Acid Standard|10|ml', bmrBprBiochemistryCommonPacking())]
    );

    return $families;
}

function bmrBprBiochemistryApprovedProductIds(): array
{
    $ids = [];
    foreach (bmrBprBiochemistryCatalog() as $family) {
        foreach ($family['product_ids'] as $productId) {
            $ids[] = (int) $productId;
        }
    }
    sort($ids);
    return array_values(array_unique($ids));
}

function bmrBprBiochemistryDocumentCounts(): array
{
    $counts = ['BMR' => 0, 'BPR' => 0];
    foreach (bmrBprBiochemistryCatalog() as $family) {
        $variants = count($family['product_ids']);
        $counts['BMR'] += $variants * count($family['bmr_documents']);
        $counts['BPR'] += $variants * count($family['bpr_documents']);
    }
    return $counts;
}
