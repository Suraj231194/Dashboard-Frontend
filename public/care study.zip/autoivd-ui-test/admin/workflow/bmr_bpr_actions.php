<?php

declare(strict_types=1);

if (!defined('BMR_BPR_WORKFLOW_AJAX_CONTEXT')) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/bmr_bpr_common.php';
require_once __DIR__ . '/coa_templates/common.php';

bmrBprRequireLogin();
bmrBprRequireSchema($conn);
bmrBprValidateCsrf();

$action = trim((string) ($_POST['bmrBprWorkflowAction'] ?? ''));
$userId = (int) ($_SESSION['user_id'] ?? 0);
$inTransaction = false;
$namedLock = null;

function bmrBprRequestRows(mysqli $conn): array
{
    $result = $conn->query(
        "SELECT
            r.*,
            COALESCE(r.updated_at, r.reviewed_at, r.requested_at, r.created_at) AS activity_at,
            source_plan.production_plan_no,
            source_mr.auto_generated_batch AS material_requisition_no,
            su.short_name AS batch_unit,
            COALESCE(document_requirements.bmr_form_count, 0) AS configured_bmr_form_count,
            COALESCE(document_requirements.bpr_form_count, 0) AS configured_bpr_form_count,
            CASE WHEN document_requirements.product_id IS NULL THEN 0 ELSE 1 END AS has_document_configuration,
            COALESCE(requested_user.name, created_user.name, '-') AS requested_by_name,
            COALESCE(reviewer.name, '-') AS reviewed_by_name
         FROM bmr_bpr_requests r
         INNER JOIN material_requisition source_mr
            ON source_mr.id = r.material_requisition_id
           AND source_mr.status = 1
           AND source_mr.deleted_at IS NULL
            INNER JOIN production_plans source_plan
                ON source_plan.id = source_mr.prod_plan_id AND source_plan.deleted_at IS NULL
         LEFT JOIN standard_units su ON su.id = r.batch_size_unit_id
         LEFT JOIN (
            SELECT
                mapping.product_id,
                SUM(CASE WHEN mapping.form_type = 'BMR' THEN mapping.required_quantity ELSE 0 END)
                    AS bmr_form_count,
                SUM(CASE WHEN mapping.form_type = 'BPR' THEN mapping.required_quantity ELSE 0 END)
                    AS bpr_form_count
            FROM bmr_template_product_mappings mapping
            INNER JOIN bmr_templates template
                ON template.id = mapping.template_id
               AND template.form_type = mapping.form_type
               AND template.status = 1
               AND template.deleted_at IS NULL
            WHERE mapping.status = 1
              AND mapping.deleted_at IS NULL
            GROUP BY mapping.product_id
         ) document_requirements ON document_requirements.product_id = source_plan.product_id
         LEFT JOIN users requested_user ON requested_user.id = r.requested_by
         LEFT JOIN users created_user ON created_user.id = r.created_by
         LEFT JOIN users reviewer ON reviewer.id = r.reviewed_by
         WHERE r.deleted_at IS NULL
           AND COALESCE(r.remarks, '') NOT IN (
               'Common structured COA IP banner acceptance record.',
               'Common structured COA FG banner acceptance record.',
               'Common Serology FG COA template banner acceptance record.'
           )
         ORDER BY COALESCE(r.updated_at, r.reviewed_at, r.requested_at, r.created_at) DESC, r.id DESC"
    );
    if (!$result) {
        throw new RuntimeException('Unable to load BMR/BPR requests.');
    }

    $materialsStmt = bmrBprPrepare($conn, "SELECT item.description AS material_name,
            item.required_qty, item.issued_qty, unit.short_name AS unit_name,
            (SELECT GROUP_CONCAT(DISTINCT stock_item.lot_batch_no ORDER BY stock_item.lot_batch_no SEPARATOR ', ')
             FROM stock_outward movement
             INNER JOIN stock_outward_items stock_item ON stock_item.outward_id = movement.id
             WHERE movement.material_req_id = item.mr_id AND movement.deleted_at IS NULL
               AND stock_item.product_id = item.product_id AND stock_item.deleted_at IS NULL) AS issued_batches
        FROM material_requisition_items item
        LEFT JOIN standard_units unit ON unit.id = item.required_qty_unit
        WHERE item.mr_id = ? AND item.status != 3 AND item.deleted_at IS NULL ORDER BY item.id");
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $materialRequisitionId = (int) $row['material_requisition_id'];
        $materialsStmt->bind_param('i', $materialRequisitionId);
        $materialsStmt->execute();
        $materials = $materialsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $status = strtoupper((string) $row['status']);
        $exactTemplateIds = ['BMR' => [], 'BPR' => []];
        if ($status === 'UPCOMING' && (int) ($row['product_id'] ?? 0) > 0) {
            try {
                $requirements = bmrBprResolveProductDocumentRequirements(
                    $conn,
                    (int) $row['product_id'],
                    (string) ($row['pack_size'] ?? '')
                );
                foreach (['BMR', 'BPR'] as $formType) {
                    foreach ($requirements[$formType] ?? [] as $requirement) {
                        $templateId = (int) ($requirement['template_id'] ?? 0);
                        if ($templateId > 0) {
                            $exactTemplateIds[$formType][$templateId] = $templateId;
                        }
                    }
                    $exactTemplateIds[$formType] = array_values($exactTemplateIds[$formType]);
                }
            } catch (Throwable) {
                // Invalid/incomplete mappings must not preselect a template.
            }
        }
        $rows[] = [
            'id' => (string) $row['id'],
            'serial_number' => (int) $row['id'],
            'request_no' => (string) ($row['request_no'] ?? ''),
            'production_plan_no' => (string) ($row['production_plan_no'] ?? ''),
            'material_requisition_no' => (string) ($row['material_requisition_no'] ?? ''),
            'issued_materials' => $materials,
            'date' => $row['request_date'] ? date('d-m-Y', strtotime($row['request_date'])) : '',
            'request_date' => (string) ($row['request_date'] ?? ''),
            'product_id' => isset($row['product_id']) ? (int) $row['product_id'] : null,
            'product_name' => (string) $row['product_name'],
            'sku' => (string) ($row['category_code'] ?? ''),
            'category_code' => (string) ($row['category_code'] ?? ''),
            'lot_number' => (string) ($row['lot_number'] ?? ''),
            'batch_number' => (string) (($row['production_batch_number'] ?? '') ?: ($row['lot_number'] ?? '')),
            'batch_size_value' => $row['batch_size'] === null ? '' : (string) $row['batch_size'],
            'batch_unit_id' => isset($row['batch_size_unit_id']) ? (int) $row['batch_size_unit_id'] : null,
            'batch_unit' => (string) ($row['batch_unit'] ?? ''),
            'batch_size' => bmrBprDisplayBatchSize($row['batch_size'], $row['batch_unit'] ?? ''),
            'form_count' => (int) $row['form_count'],
            'bmr_form_count' => (int) ($row['bmr_form_count'] ?? $row['form_count']),
            'bpr_form_count' => (int) ($row['bpr_form_count'] ?? $row['form_count']),
            'configured_bmr_form_count' => (int) ($row['configured_bmr_form_count'] ?? 0),
            'configured_bpr_form_count' => (int) ($row['configured_bpr_form_count'] ?? 0),
            'has_document_configuration' => (int) ($row['has_document_configuration'] ?? 0),
            'exact_bmr_template_ids' => $exactTemplateIds['BMR'],
            'exact_bpr_template_ids' => $exactTemplateIds['BPR'],
            'total_form_count' => (int) ($row['bmr_form_count'] ?? $row['form_count'])
                + (int) ($row['bpr_form_count'] ?? $row['form_count']),
            'pack_size' => (string) ($row['pack_size'] ?? ''),
            'remarks' => (string) ($row['remarks'] ?? ''),
            'status_code' => $status,
            'status' => bmrBprStatusLabel($status),
            'requested_by' => (string) $row['requested_by_name'],
            'reviewed_by' => (string) $row['reviewed_by_name'],
            'review_comments' => (string) ($row['review_comments'] ?? ''),
            'activity_at' => (string) ($row['activity_at'] ?? ''),
        ];
    }
    $materialsStmt->close();
    return $rows;
}

function bmrBprProductOptions(mysqli $conn): array
{
    $result = $conn->query(
        "SELECT
            p.id,
            p.product_name,
            COALESCE(p.product_code, '') AS category_code,
            COALESCE(requirements.bmr_form_count, 0) AS bmr_form_count,
            COALESCE(requirements.bpr_form_count, 0) AS bpr_form_count,
            CASE WHEN requirements.product_id IS NULL THEN 0 ELSE 1 END AS has_document_configuration,
            COALESCE((
                SELECT TRIM(CONCAT_WS(' ', pps.pack_size, su.short_name))
                FROM product_pack_sizes pps
                LEFT JOIN standard_units su ON su.id = pps.pack_unit_id
                WHERE pps.product_id = p.id
                  AND pps.status != 3
                  AND pps.deleted_at IS NULL
                ORDER BY pps.sort_order ASC, pps.id ASC
                LIMIT 1
            ), '') AS pack_size
         FROM products p
         LEFT JOIN (
            SELECT
                mapping.product_id,
                SUM(CASE WHEN mapping.form_type = 'BMR' THEN mapping.required_quantity ELSE 0 END)
                    AS bmr_form_count,
                SUM(CASE WHEN mapping.form_type = 'BPR' THEN mapping.required_quantity ELSE 0 END)
                    AS bpr_form_count
            FROM bmr_template_product_mappings mapping
            INNER JOIN bmr_templates template
                ON template.id = mapping.template_id
               AND template.form_type = mapping.form_type
               AND template.status = 1
               AND template.deleted_at IS NULL
            WHERE mapping.status = 1
              AND mapping.deleted_at IS NULL
            GROUP BY mapping.product_id
         ) requirements ON requirements.product_id = p.id
         WHERE p.status != 3 AND p.deleted_at IS NULL
         ORDER BY p.product_name ASC"
    );
    if (!$result) {
        throw new RuntimeException('Unable to load products.');
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}



try {
    switch ($action) {
        case 'request_list':
            bmrBprRequirePermission($conn, 'production_bmr_bpr_form_request_view');
            bmrBprJson('success', '', [
                'requests' => bmrBprRequestRows($conn),
                'templates' => bmrBprGetRankedTemplates($conn),
                'mapped_products' => bmrBprGetMappedProductCatalog($conn),
            ]);

        case 'submit_request':
            bmrBprRequirePermission($conn, 'production_bmr_bpr_form_request_manage');
            $requestId = (int) ($_POST['request_id'] ?? 0);
            $productId = (int) ($_POST['product_id'] ?? 0);
            $batchSize = (float) ($_POST['batch_size'] ?? 0);
            $formCount = (int) ($_POST['form_count'] ?? 0);
            $remarks = trim((string) ($_POST['remarks'] ?? ''));
            $bmrTemplateId = isset($_POST['bmr_template_id']) && (int) $_POST['bmr_template_id'] > 0
                ? (int) $_POST['bmr_template_id']
                : null;
            $bprTemplateId = isset($_POST['bpr_template_id']) && (int) $_POST['bpr_template_id'] > 0
                ? (int) $_POST['bpr_template_id']
                : null;
            if ($requestId <= 0 || $productId <= 0 || $batchSize <= 0 || $formCount <= 0 || $formCount > 1000) {
                throw new InvalidArgumentException('Enter a valid product, batch size and number of forms.');
            }
            if ($bmrTemplateId === null || $bprTemplateId === null) {
                throw new InvalidArgumentException('Please select both a BMR and a BPR template specification.');
            }
            if (mb_strlen($remarks) > 5000) {
                throw new InvalidArgumentException('Remarks cannot exceed 5,000 characters.');
            }

            $conn->begin_transaction();
            $inTransaction = true;
            $requestStmt = bmrBprPrepare(
                $conn,
                     'SELECT r.id, r.status, r.form_count,
                                source_plan.product_id AS source_product_id, source_mr.batch_size AS source_batch_size
                 FROM bmr_bpr_requests r
                 INNER JOIN material_requisition source_mr
                    ON source_mr.id = r.material_requisition_id
                   AND source_mr.status = 1
                   AND source_mr.deleted_at IS NULL
                      INNER JOIN production_plans source_plan
                          ON source_plan.id = source_mr.prod_plan_id AND source_plan.deleted_at IS NULL
                 WHERE r.id = ? AND r.deleted_at IS NULL
                 FOR UPDATE'
            );
            $requestStmt->bind_param('i', $requestId);
            $requestStmt->execute();
            $request = $requestStmt->get_result()->fetch_assoc();
            $requestStmt->close();
            if (!$request) {
                throw new RuntimeException('The BMR/BPR request was not found.');
            }
            bmrBprValidateBatchIdentity((int) $request['source_product_id'], (float) $request['source_batch_size'], $productId, $batchSize);
            $productId = (int) $request['source_product_id'];
            $batchSize = (float) $request['source_batch_size'];
            if (strtoupper((string) $request['status']) !== 'UPCOMING') {
                throw new DomainException('Only an upcoming request can be submitted.');
            }

            $productStmt = bmrBprPrepare(
                $conn,
                "SELECT
                    p.product_name,
                    COALESCE(p.product_code, '') AS category_code,
                    COALESCE((
                        SELECT TRIM(CONCAT_WS(' ', pps.pack_size, su.short_name))
                        FROM product_pack_sizes pps
                        LEFT JOIN standard_units su ON su.id = pps.pack_unit_id
                        WHERE pps.product_id = p.id
                          AND pps.status != 3
                          AND pps.deleted_at IS NULL
                        ORDER BY pps.sort_order ASC, pps.id ASC
                        LIMIT 1
                    ), '') AS pack_size
                 FROM products p
                 WHERE p.id = ? AND p.status != 3 AND p.deleted_at IS NULL
                 LIMIT 1"
            );
            $productStmt->bind_param('i', $productId);
            $productStmt->execute();
            $product = $productStmt->get_result()->fetch_assoc();
            $productStmt->close();
            if (!$product) {
                throw new InvalidArgumentException('The selected product is not available.');
            }

            $productName = trim((string) $product['product_name']);
            $categoryCode = trim((string) $product['category_code']);
            $packSize = bmrBprResolveProductPackSize(
                $conn,
                $productId,
                $productName,
                trim((string) $product['pack_size'])
            );

            $templateStmt = bmrBprPrepare(
                $conn,
                'SELECT id FROM bmr_templates
                 WHERE id = ? AND form_type = ? AND status = 1 AND deleted_at IS NULL
                 LIMIT 1'
            );
            foreach (['BMR' => $bmrTemplateId, 'BPR' => $bprTemplateId] as $formType => $templateId) {
                $templateStmt->bind_param('is', $templateId, $formType);
                $templateStmt->execute();
                if (!$templateStmt->get_result()->fetch_assoc()) {
                    $templateStmt->close();
                    throw new InvalidArgumentException("The selected {$formType} template is not available.");
                }
            }
            $templateStmt->close();

            $configuredCounts = bmrBprSnapshotProductDocumentRequirements(
                $conn,
                $requestId,
                $productId,
                $formCount,
                $formCount,
                $userId,
                $packSize,
                $bmrTemplateId,
                $bprTemplateId
            );
            $bmrFormCount = (int) $configuredCounts['BMR'];
            $bprFormCount = (int) $configuredCounts['BPR'];
            $updateStmt = bmrBprPrepare(
                $conn,
                "UPDATE bmr_bpr_requests
                 SET product_id = ?, product_name = ?, category_code = ?, pack_size = ?,
                     batch_size = ?, form_count = ?, bmr_form_count = ?, bpr_form_count = ?,
                     remarks = ?, status = 'SUBMITTED',
                     requested_by = ?, requested_at = NOW(), updated_by = ?, updated_at = NOW()
                 WHERE id = ?"
            );
            $updateStmt->bind_param(
                'isssdiiisiii',
                $productId,
                $productName,
                $categoryCode,
                $packSize,
                $batchSize,
                $formCount,
                $bmrFormCount,
                $bprFormCount,
                $remarks,
                $userId,
                $userId,
                $requestId
            );
            if (!$updateStmt->execute()) {
                $updateStmt->close();
                throw new RuntimeException('Unable to submit the BMR/BPR request.');
            }
            $updateStmt->close();
            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $requestId,
                'SUBMIT_FOR_ISSUANCE',
                'UPCOMING',
                'SUBMITTED',
                $remarks,
                [
                    'product_id' => $productId,
                    'batch_size' => $batchSize,
                    'form_count' => $formCount,
                    'bmr_form_count' => $bmrFormCount,
                    'bpr_form_count' => $bprFormCount,
                ],
                $userId
            );
            $conn->commit();
            $inTransaction = false;
            bmrBprJson('success', 'BMR/BPR Form Request submitted to QA/QC Issuance.');

        case 'issuance_list':
            bmrBprRequirePermission($conn, 'qa_qc_bmr_bpr_issuance_view');
            $allRows = bmrBprRequestRows($conn);
            $pending = array_values(array_filter(
                $allRows,
                static fn(array $row): bool => in_array($row['status_code'], ['SUBMITTED'], true)
            ));
            $decisions = array_values(array_filter(
                $allRows,
                static fn(array $row): bool => in_array($row['status_code'], ['APPROVED', 'REJECTED'], true)
            ));
            $approvedCount = count(array_filter(
                $decisions,
                static fn(array $row): bool => $row['status_code'] === 'APPROVED'
            ));
            $rejectedCount = count(array_filter(
                $decisions,
                static fn(array $row): bool => $row['status_code'] === 'REJECTED'
            ));
            bmrBprJson('success', '', [
                'pending' => $pending,
                'records' => $decisions,
                'counts' => [
                    'pending' => count($pending),
                    'approved' => $approvedCount,
                    'rejected' => $rejectedCount,
                ],
            ]);

        case 'review_request':
            bmrBprRequirePermission($conn, 'qa_qc_bmr_bpr_issuance_review');
            $requestId = (int) ($_POST['request_id'] ?? 0);
            $decision = strtolower(trim((string) ($_POST['decision'] ?? '')));
            $comments = trim((string) ($_POST['comments'] ?? ''));
            if ($requestId <= 0 || !in_array($decision, ['approved', 'rejected'], true)) {
                throw new InvalidArgumentException('Select a valid issuance decision.');
            }
            if (mb_strlen($comments) > 5000) {
                throw new InvalidArgumentException('Reviewer comments cannot exceed 5,000 characters.');
            }

            $conn->begin_transaction();
            $inTransaction = true;
            $requestStmt = bmrBprPrepare(
                $conn,
                'SELECT r.id, r.status, r.form_count, r.bmr_form_count, r.bpr_form_count,
                    r.product_id, r.product_name, r.pack_size, r.batch_size,
                    source_plan.product_id AS source_product_id, source_mr.batch_size AS source_batch_size
                 FROM bmr_bpr_requests r
                 INNER JOIN material_requisition source_mr
                    ON source_mr.id = r.material_requisition_id
                   AND source_mr.status = 1
                   AND source_mr.deleted_at IS NULL
                      INNER JOIN production_plans source_plan
                          ON source_plan.id = source_mr.prod_plan_id AND source_plan.id = r.production_plan_id
                         AND source_plan.deleted_at IS NULL
                 WHERE r.id = ? AND r.deleted_at IS NULL
                 FOR UPDATE'
            );
            $requestStmt->bind_param('i', $requestId);
            $requestStmt->execute();
            $request = $requestStmt->get_result()->fetch_assoc();
            $requestStmt->close();
            if (!$request) {
                throw new RuntimeException('The issuance request was not found.');
            }
            $previousStatus = strtoupper((string) $request['status']);
            if ($previousStatus !== 'SUBMITTED') {
                throw new DomainException('Only a submitted request can be reviewed by QA/QC.');
            }

            $newStatus = $decision === 'approved' ? 'APPROVED' : 'REJECTED';
            $bmrFormCount = (int) ($request['bmr_form_count'] ?? $request['form_count']);
            $bprFormCount = (int) ($request['bpr_form_count'] ?? $request['form_count']);
            if ($newStatus === 'APPROVED') {
                bmrBprValidateBatchIdentity((int) $request['source_product_id'], (float) $request['source_batch_size'],
                    (int) $request['product_id'], (float) $request['batch_size']);
                if ($previousStatus === 'UPCOMING') {
                    $packSize = bmrBprResolveProductPackSize(
                        $conn,
                        (int) $request['product_id'],
                        (string) $request['product_name'],
                        (string) ($request['pack_size'] ?? '')
                    );
                    $counts = bmrBprSnapshotProductDocumentRequirements($conn, $requestId,
                        (int) $request['product_id'], $bmrFormCount, $bprFormCount, $userId, $packSize);
                    $bmrFormCount = $counts['BMR'];
                    $bprFormCount = $counts['BPR'];
                }
            }
            $updateStmt = bmrBprPrepare(
                $conn,
                'UPDATE bmr_bpr_requests
                 SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_comments = ?,
                     updated_by = ?, updated_at = NOW(), bmr_form_count = ?, bpr_form_count = ?, form_count = ?
                 WHERE id = ?'
            );
            $totalFormCount = $bmrFormCount + $bprFormCount;
            $updateStmt->bind_param('sisiiiii', $newStatus, $userId, $comments, $userId, $bmrFormCount, $bprFormCount, $totalFormCount, $requestId);
            if (!$updateStmt->execute()) {
                $updateStmt->close();
                throw new RuntimeException('Unable to save the issuance decision.');
            }
            $updateStmt->close();

            if ($newStatus === 'APPROVED') {
                bmrBprEnsureConfiguredWorkItems(
                    $conn,
                    $requestId,
                    $bmrFormCount,
                    $bprFormCount,
                    $userId
                );
            }

            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $requestId,
                $newStatus === 'APPROVED' ? 'APPROVE_ISSUANCE' : 'REJECT_ISSUANCE',
                $previousStatus,
                $newStatus,
                $comments,
                [
                    'bmr_form_count' => $bmrFormCount,
                    'bpr_form_count' => $bprFormCount,
                ],
                $userId
            );
            $conn->commit();
            $inTransaction = false;
            bmrBprJson('success', 'The BMR/BPR issuance decision was saved.');

        case 'production_list':
            bmrBprRequirePermission($conn, 'production_bmr_bpr_view');
            $rows = bmrBprProductionRows($conn);
            $incoming = ['BMR' => [], 'BPR' => []];
            $records = [];
            foreach ($rows as $row) {
                $records[] = $row;
                $isPendingIncoming = in_array($row['status_code'], ['QUEUED', 'PENDING'], true);
                $isCommonTemplateDemoBmrPreview = !empty($row['is_common_template_demo'])
                    && $row['form_type'] === 'BMR'
                    && $row['status_code'] === 'IN_PROCESS'
                    && (
                        !str_starts_with(
                            (string) ($row['template_code'] ?? ''),
                            'COMMON_BIOCHEMISTRY_BMR_'
                        )
                        || (int) ($row['form_sequence'] ?? 0) === 1
                    );
                if (
                    ($row['form_type'] === 'BMR' && ($isPendingIncoming || $isCommonTemplateDemoBmrPreview) && ($row['can_open'] || $isCommonTemplateDemoBmrPreview))
                    || ($row['form_type'] === 'BPR' && $isPendingIncoming)
                ) {
                    $incoming[$row['form_type']][] = $row;
                }
            }
            bmrBprJson('success', '', [
                'records' => $records,
                'incoming' => $incoming,
                'counts' => [
                    'BMR' => count($incoming['BMR']),
                    'BPR' => count($incoming['BPR']),
                ],
            ]);

        case 'open_work_item':
            bmrBprRequirePermission($conn, 'production_bmr_bpr_manage');
            $workItemId = (int) ($_POST['work_item_id'] ?? 0);
            if ($workItemId <= 0) {
                throw new InvalidArgumentException('A valid BMR/BPR work item is required.');
            }
            $conn->begin_transaction();
            $inTransaction = true;
            $stmt = bmrBprPrepare(
                $conn,
                "SELECT wi.id, wi.request_id, wi.form_type, wi.status, request.bmr_form_count
                 FROM bmr_bpr_work_items wi
                 INNER JOIN bmr_bpr_requests request ON request.id = wi.request_id
                    AND request.deleted_at IS NULL AND request.status = 'APPROVED'
                 WHERE wi.id = ? AND wi.deleted_at IS NULL
                 LIMIT 1 FOR UPDATE"
            );
            $stmt->bind_param('i', $workItemId);
            $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$item) {
                throw new RuntimeException('The BMR/BPR work item was not found.');
            }
            if ((int) ($item['template_snapshot_id'] ?? 0) > 0) {
                $snapshot = templateSnapshotLoad($conn, (int) $item['template_snapshot_id']);
                if ($snapshot === null) {
                    throw new RuntimeException('The controlled BMR/BPR template snapshot was not found.');
                }
                $item['layout_json'] = $snapshot['layout_json'];
            }
            if (strtoupper((string) $item['form_type']) === 'BPR') {
                $bmrStmt = bmrBprPrepare(
                    $conn,
                    "SELECT status FROM bmr_bpr_work_items
                     WHERE request_id = ? AND form_type = 'BMR' AND deleted_at IS NULL
                     ORDER BY id FOR UPDATE"
                );
                $requestId = (int) $item['request_id'];
                $bmrStmt->bind_param('i', $requestId);
                $bmrStmt->execute();
                $bmrStatuses = array_column($bmrStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'status');
                $bmrStmt->close();
                if (!bmrBprBmrStatusesReady($bmrStatuses, (int) $item['bmr_form_count'])) {
                    throw new DomainException('Complete every configured BMR before opening the BPR.');
                }
                if (!bmrBprRequestHasApprovedIpCoa($conn, $requestId)) {
                    throw new DomainException('An approved In-Process COA is required before opening the BPR.');
                }
            }
            $oldStatus = strtoupper((string) $item['status']);
            $newStatus = bmrBprWorkItemTransition($oldStatus, 'GET_FORM');
            if ($newStatus !== $oldStatus) {
                $updateStmt = bmrBprPrepare(
                    $conn,
                    "UPDATE bmr_bpr_work_items
                     SET status = 'PENDING', updated_by = ?, updated_at = NOW()
                     WHERE id = ?"
                );
                $updateStmt->bind_param('ii', $userId, $workItemId);
                $updateStmt->execute();
                $updateStmt->close();
                bmrBprInsertHistory(
                    $conn,
                    'WORK_ITEM',
                    $workItemId,
                    'GET_FORM',
                    $oldStatus,
                    $newStatus,
                    null,
                    ['form_type' => strtoupper((string) $item['form_type'])],
                    $userId
                );
            }
            $conn->commit();
            $inTransaction = false;
            $form = bmrBprLoadWorkItemTemplate($conn, $workItemId);
            bmrBprJson('success', '', [
                'work_item_id' => $workItemId,
                'status_code' => $newStatus,
                'status' => bmrBprStatusLabel($newStatus),
                'form' => $form,
            ]);

        case 'update_work_item':
            bmrBprRequirePermission($conn, 'production_bmr_bpr_manage');
            $workItemId = (int) ($_POST['work_item_id'] ?? 0);
            $recordAction = strtolower(trim((string) ($_POST['record_action'] ?? '')));
            $payloadJson = trim((string) ($_POST['form_payload'] ?? '{}'));
            if ($workItemId <= 0 || !in_array($recordAction, ['draft', 'submit'], true)) {
                throw new InvalidArgumentException('Select a valid BMR/BPR record action.');
            }
            if (strlen($payloadJson) > 5242880) {
                throw new InvalidArgumentException('The form data is too large.');
            }
            $decodedPayload = json_decode($payloadJson, true);
            if (!is_array($decodedPayload)) {
                throw new InvalidArgumentException('The BMR/BPR form data is invalid.');
            }
            $conn->begin_transaction();
            $inTransaction = true;
            $itemStmt = bmrBprPrepare(
                $conn,
                "SELECT wi.id, wi.request_id, wi.form_type, wi.status, wi.template_id,
                        wi.template_snapshot_id,
                        COALESCE(snapshot.layout_json, template.layout_json) AS layout_json,
                        request.product_id, request.bmr_form_count
                 FROM bmr_bpr_work_items wi
                 INNER JOIN bmr_bpr_requests request
                    ON request.id = wi.request_id
                   AND request.deleted_at IS NULL
                   AND request.status = 'APPROVED'
                  LEFT JOIN bmr_templates template
                    ON template.id = wi.template_id
                   AND template.status = 1
                    AND template.deleted_at IS NULL
                  LEFT JOIN template_snapshots snapshot
                    ON snapshot.id = wi.template_snapshot_id
                 WHERE wi.id = ? AND wi.deleted_at IS NULL
                 FOR UPDATE"
            );
            $itemStmt->bind_param('i', $workItemId);
            $itemStmt->execute();
            $item = $itemStmt->get_result()->fetch_assoc();
            $itemStmt->close();
            if (!$item) {
                throw new RuntimeException('The BMR/BPR work item was not found.');
            }
            $templateLayout = [];
            if (!empty($item['layout_json'])) {
                $decodedLayout = json_decode((string) $item['layout_json'], true);
                $templateLayout = is_array($decodedLayout) ? $decodedLayout : [];
            }
            $decodedPayload = bmrBprSanitizeTemplatePayload($templateLayout, $decodedPayload);
            $payloadJson = json_encode(
                $decodedPayload,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
            if ($payloadJson === false) {
                throw new InvalidArgumentException('The BMR/BPR form data could not be saved.');
            }
            $oldStatus = strtoupper((string) $item['status']);
            if (strtoupper((string) $item['form_type']) === 'BPR') {
                $bmrStmt = bmrBprPrepare(
                    $conn,
                    "SELECT status FROM bmr_bpr_work_items
                     WHERE request_id = ? AND form_type = 'BMR' AND deleted_at IS NULL
                     ORDER BY id FOR UPDATE"
                );
                $requestId = (int) $item['request_id'];
                $bmrStmt->bind_param('i', $requestId);
                $bmrStmt->execute();
                $bmrStatuses = array_column($bmrStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'status');
                $bmrStmt->close();
                if (!bmrBprBmrStatusesReady($bmrStatuses, (int) $item['bmr_form_count'])) {
                    throw new DomainException('Complete every configured BMR before updating the BPR.');
                }
                if (!bmrBprRequestHasApprovedIpCoa($conn, $requestId)) {
                    throw new DomainException('An approved In-Process COA is required before updating the BPR.');
                }
            }
            if ($oldStatus === 'COMPLETE') {
                $conn->commit();
                $inTransaction = false;
                bmrBprJson('success', 'This BMR/BPR record is already complete.');
            }

            if ($recordAction === 'submit') {
                if (
                    ((int) ($item['template_snapshot_id'] ?? 0) <= 0 && (int) ($item['template_id'] ?? 0) <= 0)
                    || $templateLayout === []
                ) {
                    throw new DomainException('A controlled BMR/BPR template is required before completion.');
                }
                if (bmrBprIsStructuredLayout($templateLayout)
                    && bmrBprStructuredProfile($templateLayout, (int) $item['product_id']) === []) {
                    throw new DomainException('The approved template has no profile for this production product.');
                }
                bmrBprValidateCompletionPayload($templateLayout, $decodedPayload);
            }
            $newStatus = bmrBprWorkItemTransition($oldStatus, $recordAction);
            if ($newStatus === 'IN_PROCESS') {
                $updateStmt = bmrBprPrepare(
                    $conn,
                    "UPDATE bmr_bpr_work_items
                     SET status = 'IN_PROCESS', form_payload_json = ?,
                         started_by = COALESCE(started_by, ?), started_at = COALESCE(started_at, NOW()),
                         updated_by = ?, updated_at = NOW()
                     WHERE id = ?"
                );
                $updateStmt->bind_param('siii', $payloadJson, $userId, $userId, $workItemId);
            } else {
                $updateStmt = bmrBprPrepare(
                    $conn,
                    "UPDATE bmr_bpr_work_items
                     SET status = 'COMPLETE', form_payload_json = ?,
                         started_by = COALESCE(started_by, ?), started_at = COALESCE(started_at, NOW()),
                         completed_by = ?, completed_at = NOW(), updated_by = ?, updated_at = NOW()
                     WHERE id = ?"
                );
                $updateStmt->bind_param('siiii', $payloadJson, $userId, $userId, $userId, $workItemId);
            }
            if (!$updateStmt->execute()) {
                $updateStmt->close();
                throw new RuntimeException('Unable to update the BMR/BPR work item.');
            }
            $updateStmt->close();
            bmrBprInsertHistory(
                $conn,
                'WORK_ITEM',
                $workItemId,
                $recordAction === 'draft' ? 'SAVE_DRAFT' : 'SUBMIT_RECORD',
                $oldStatus,
                $newStatus,
                null,
                ['form_type' => strtoupper((string) $item['form_type'])],
                $userId
            );
            if (strtoupper((string) $item['form_type']) === 'BPR' && $newStatus === 'COMPLETE') {
                bmrBprEnsurePendingTransferTicketForRequest($conn, (int) $item['request_id'], $userId);
            }
            $conn->commit();
            $inTransaction = false;
            bmrBprJson(
                'success',
                $recordAction === 'draft'
                    ? 'The BMR/BPR draft was saved and is now In-Process.'
                    : 'The BMR/BPR record was submitted and marked Complete.'
            );

        case 'set_coa_quality_status':
            $coaType = strtoupper(trim((string) ($_POST['coa_type'] ?? '')));
            $recordId = (int) ($_POST['record_id'] ?? 0);
            $targetStatus = strtoupper(trim((string) ($_POST['target_status'] ?? '')));
            $reason = trim((string) ($_POST['reason'] ?? ''));
            if (!in_array($coaType, ['IP', 'FG'], true) || $recordId <= 0) {
                throw new InvalidArgumentException('Select a valid controlled COA record.');
            }
            if (!in_array($targetStatus, ['HOLD', 'UNDER_INVESTIGATION', 'DRAFT'], true)) {
                throw new InvalidArgumentException('Select a valid quality status.');
            }
            if ($reason === '') {
                throw new InvalidArgumentException('A reason is required for every quality status change.');
            }
            if (mb_strlen($reason) > 5000) {
                throw new InvalidArgumentException('The quality status reason cannot exceed 5,000 characters.');
            }

            $tableName = $coaType === 'IP' ? 'ip_coa_generation' : 'fg_coa_generation';
            $entityType = $coaType . '_COA';
            $permission = $coaType === 'IP' ? 'ip_coa_generation_edit' : 'fg_coa_generation_edit';
            bmrBprRequirePermission($conn, $permission);

            $conn->begin_transaction();
            $inTransaction = true;
            if ($coaType === 'IP') {
                $recordStmt = bmrBprPrepare(
                    $conn,
                    "SELECT id, workflow_status, source_bmr_work_item_id, source_bmr_bpr_request_id
                     FROM ip_coa_generation
                     WHERE id = ? AND status = 0 AND deleted_at IS NULL
                     LIMIT 1 FOR UPDATE"
                );
            } else {
                $recordStmt = bmrBprPrepare(
                    $conn,
                    "SELECT id, workflow_status, source_ip_coa_id
                     FROM fg_coa_generation
                     WHERE id = ? AND status = 0 AND deleted_at IS NULL
                     LIMIT 1 FOR UPDATE"
                );
            }
            $recordStmt->bind_param('i', $recordId);
            $recordStmt->execute();
            $record = $recordStmt->get_result()->fetch_assoc();
            $recordStmt->close();
            if (!$record) {
                throw new RuntimeException('The controlled COA record was not found.');
            }
            $isControlled = $coaType === 'IP'
                ? !empty($record['source_bmr_work_item_id']) || !empty($record['source_bmr_bpr_request_id'])
                : !empty($record['source_ip_coa_id']);
            if (!$isControlled) {
                throw new DomainException('Quality status transitions are available only for controlled COA records.');
            }

            $currentStatus = strtoupper(trim((string) ($record['workflow_status'] ?? 'DRAFT')));
            bmrBprValidateQualityStatusTransition($currentStatus, $targetStatus);

            if ($coaType === 'IP') {
                $transferStmt = bmrBprPrepare(
                    $conn,
                    "SELECT ticket.id
                     FROM fg_coa_generation fg
                     INNER JOIN transfer_ticket ticket ON ticket.source_fg_coa_id = fg.id
                     WHERE fg.source_ip_coa_id = ?
                       AND fg.deleted_at IS NULL
                       AND ticket.workflow_status IN ('TRANSFERRED', 'RECEIVED')
                     LIMIT 1 FOR UPDATE"
                );
            } else {
                $transferStmt = bmrBprPrepare(
                    $conn,
                    "SELECT ticket.id
                     FROM transfer_ticket ticket
                     WHERE ticket.source_fg_coa_id = ?
                       AND ticket.workflow_status IN ('TRANSFERRED', 'RECEIVED')
                     LIMIT 1 FOR UPDATE"
                );
            }
            $transferStmt->bind_param('i', $recordId);
            $transferStmt->execute();
            $terminalTransfer = $transferStmt->get_result()->fetch_assoc();
            $transferStmt->close();
            if ($terminalTransfer) {
                throw new DomainException('The COA status cannot change after the finished goods have been transferred or received.');
            }

            $updateStmt = bmrBprPrepare(
                $conn,
                "UPDATE {$tableName}
                 SET workflow_status = ?, updated_by = ?, updated_at = NOW()
                 WHERE id = ?"
            );
            $updateStmt->bind_param('sii', $targetStatus, $userId, $recordId);
            if (!$updateStmt->execute() || $updateStmt->affected_rows !== 1) {
                $updateStmt->close();
                throw new RuntimeException('Unable to update the controlled COA quality status.');
            }
            $updateStmt->close();

            $historyAction = match ($targetStatus) {
                'HOLD' => 'PLACE_ON_HOLD',
                'UNDER_INVESTIGATION' => 'START_INVESTIGATION',
                'DRAFT' => 'RETURN_TO_TESTING',
            };
            bmrBprInsertHistory(
                $conn,
                $entityType,
                $recordId,
                $historyAction,
                $currentStatus,
                $targetStatus,
                $reason,
                ['coa_type' => $coaType],
                $userId
            );
            $conn->commit();
            $inTransaction = false;
            bmrBprJson(
                'success',
                $coaType . ' COA moved to ' . bmrBprStatusLabel($targetStatus) . '.',
                [
                    'workflow_status' => $targetStatus,
                    'workflow_label' => bmrBprStatusLabel($targetStatus),
                ]
            );

        case 'ip_queue_list':
            bmrBprRequirePermission($conn, 'ip_coa_generation_menu_list');
            $result = $conn->query(
                "SELECT
                    wi.id,
                    COALESCE(wi.updated_at, wi.created_at) AS queued_at,
                    r.product_id,
                    r.product_name,
                    r.lot_number,
                    r.batch_size,
                    r.batch_size_unit_id,
                    su.short_name AS batch_unit
                 FROM bmr_bpr_work_items wi
                 INNER JOIN bmr_bpr_requests r
                    ON r.id = wi.request_id AND r.deleted_at IS NULL
                 LEFT JOIN standard_units su ON su.id = r.batch_size_unit_id
                 WHERE wi.form_type = 'BMR'
                   AND wi.status IN ('IN_PROCESS', 'COMPLETE')
                   AND wi.deleted_at IS NULL
                   AND wi.id = (
                       SELECT MIN(eligible.id)
                       FROM bmr_bpr_work_items eligible
                       WHERE eligible.request_id = wi.request_id
                         AND eligible.form_type = 'BMR'
                         AND eligible.status IN ('IN_PROCESS', 'COMPLETE')
                         AND eligible.deleted_at IS NULL
                   )
                   AND NOT EXISTS (
                       SELECT 1
                       FROM ip_coa_generation existing_ip
                       LEFT JOIN bmr_bpr_work_items source_work_item
                          ON source_work_item.id = existing_ip.source_bmr_work_item_id
                       WHERE (
                               existing_ip.source_bmr_bpr_request_id = wi.request_id
                               OR (
                                   existing_ip.source_bmr_bpr_request_id IS NULL
                                   AND source_work_item.request_id = wi.request_id
                               )
                           )
                         AND existing_ip.deleted_at IS NULL
                   )
                 ORDER BY wi.id DESC"
            );
            if (!$result) {
                throw new RuntimeException('Unable to load incoming IP COA forms.');
            }
            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $rows[] = [
                    'id' => (string) $row['id'],
                    'timestamp' => $row['queued_at'] ? date('d-m-Y h:i A', strtotime($row['queued_at'])) : '',
                    'product_id' => isset($row['product_id']) ? (int) $row['product_id'] : null,
                    'product_name' => (string) $row['product_name'],
                    'lot_number' => (string) ($row['lot_number'] ?? ''),
                    'batch_size_value' => $row['batch_size'] === null ? '' : (string) $row['batch_size'],
                    'batch_unit_id' => isset($row['batch_size_unit_id']) ? (int) $row['batch_size_unit_id'] : null,
                    'batch_size' => bmrBprDisplayBatchSize($row['batch_size'], $row['batch_unit'] ?? ''),
                ];
            }
            bmrBprJson('success', '', ['records' => $rows]);

        case 'create_ip_coa':
            bmrBprRequirePermission($conn, 'ip_coa_generation_add');
            $workItemId = (int) ($_POST['source_work_item_id'] ?? 0);
            $workflowStatus = strtoupper(trim((string) ($_POST['coa_workflow_action'] ?? 'COMPLETED'))) === 'DRAFT'
                ? 'DRAFT'
                : 'COMPLETED';
            $submittedCoaTemplateId = (int) ($_POST['coa_template_id'] ?? 0);
            $submittedCoaPayload = $_POST['coa_form_payload'] ?? null;
            $submittedCoaFamilyKey = trim((string) ($_POST['coa_family_key'] ?? ''));
            $testDate = trim((string) ($_POST['testingDate'] ?? ''));
            $testedBy = trim((string) ($_POST['testedBy'] ?? ''));
            $reviewedBy = trim((string) ($_POST['reviewAndApproveBy'] ?? ''));
            $remark = trim((string) ($_POST['prodRemark'] ?? ''));
            $departmentId = (int) ($_POST['prodDepartment'] ?? 0);
            if ($workItemId <= 0 || $testDate === '' || $departmentId <= 0) {
                throw new InvalidArgumentException('Complete all required IP COA fields.');
            }

            $conn->begin_transaction();
            $inTransaction = true;
            $sourceStmt = bmrBprPrepare(
                $conn,
                "SELECT
                     wi.id,
                     wi.status,
                     wi.request_id,
                     r.product_id,
                    r.production_plan_id,
                    r.product_name,
                    r.lot_number,
                    r.batch_size,
                    r.batch_size_unit_id
                 FROM bmr_bpr_work_items wi
                 INNER JOIN bmr_bpr_requests r ON r.id = wi.request_id AND r.deleted_at IS NULL
                 WHERE wi.id = ? AND wi.form_type = 'BMR' AND wi.deleted_at IS NULL
                 FOR UPDATE"
            );
            $sourceStmt->bind_param('i', $workItemId);
            $sourceStmt->execute();
            $source = $sourceStmt->get_result()->fetch_assoc();
            $sourceStmt->close();
            if (!$source || !in_array(strtoupper((string) $source['status']), ['IN_PROCESS', 'COMPLETE'], true)) {
                throw new DomainException('The BMR must be In-Process or Complete before creating its IP COA.');
            }
            $productName = trim((string) ($source['product_name'] ?? ''));
            $batchNumber = trim((string) ($source['lot_number'] ?? ''));
            $batchSize = (float) ($source['batch_size'] ?? 0);
            $batchUnitId = (int) ($source['batch_size_unit_id'] ?? 0);
            if ($productName === '' || $batchNumber === '' || $batchSize <= 0 || $batchUnitId <= 0) {
                throw new DomainException('The source BMR does not contain complete product and batch details.');
            }
            $duplicateStmt = bmrBprPrepare(
                $conn,
                'SELECT ip.id
                 FROM ip_coa_generation ip
                 LEFT JOIN bmr_bpr_work_items source_work_item
                    ON source_work_item.id = ip.source_bmr_work_item_id
                 WHERE (
                         ip.source_bmr_bpr_request_id = ?
                         OR (
                             ip.source_bmr_bpr_request_id IS NULL
                             AND source_work_item.request_id = ?
                         )
                     )
                   AND ip.deleted_at IS NULL
                 LIMIT 1 FOR UPDATE'
            );
            $requestId = (int) $source['request_id'];
            $duplicateStmt->bind_param('ii', $requestId, $requestId);
            $duplicateStmt->execute();
            $duplicate = $duplicateStmt->get_result()->fetch_assoc();
            $duplicateStmt->close();
            if ($duplicate) {
                throw new DomainException('An IP COA already exists for this BMR/BPR request.');
            }

            $productId = isset($source['product_id']) ? (int) $source['product_id'] : null;
            $productionPlanId = isset($source['production_plan_id']) ? (int) $source['production_plan_id'] : null;
            $templateSubmission = coaTemplateValidateSubmission(
                $conn,
                (int) $productId,
                'IP',
                $submittedCoaTemplateId,
                $submittedCoaPayload,
                $workflowStatus === 'COMPLETED',
                $submittedCoaFamilyKey
            );
            $coaTemplateId = $templateSubmission === null
                ? null
                : (int) $templateSubmission['template_id'];
            $coaPayloadJson = $templateSubmission === null
                ? null
                : json_encode(
                    $templateSubmission['payload'],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
                );
            $coaFamilyKey = $templateSubmission === null ? '' : (string) ($templateSubmission['template']['profile']['family_key'] ?? '');
            $templateSnapshotId = $templateSubmission === null ? 0 : templateSnapshotCreateCoa(
                $conn,
                'IP',
                $templateSubmission['template'],
                (int) $productId,
                $productName,
                $batchNumber,
                $userId,
                $submittedCoaFamilyKey !== '' ? 'MANUAL_OVERRIDE' : 'PREMAPPED'
            );
            $workflowStatus = bmrBprNormalizeCoaWorkflowStatus(
                $workflowStatus,
                $coaTemplateId,
                $coaPayloadJson,
                'In-Process COA'
            );
            if ($templateSubmission !== null && !empty($templateSubmission['payload']['fields'])) {
                $fields = $templateSubmission['payload']['fields'];
                if ($testedBy === '') {
                    $testedBy = trim((string) ($fields['approval.analysis_by_name'] ?? ''));
                    if ($testedBy === '' && !empty($fields['approval.analysis_by']) && !coaTemplateIsImageValue((string) $fields['approval.analysis_by'])) {
                        $testedBy = trim((string) $fields['approval.analysis_by']);
                    }
                }
                if ($reviewedBy === '') {
                    $reviewedBy = trim((string) ($fields['approval.verified_by_name'] ?? ''));
                    if ($reviewedBy === '' && !empty($fields['approval.verified_by']) && !coaTemplateIsImageValue((string) $fields['approval.verified_by'])) {
                        $reviewedBy = trim((string) $fields['approval.verified_by']);
                    }
                }
                if ($remark === '') {
                    $remark = trim((string) ($fields['approval.comments'] ?? ($fields['results.remarks'] ?? '')));
                }
            }
            $insertStmt = bmrBprPrepare(
                $conn,
                "INSERT INTO ip_coa_generation
                    (source_bmr_work_item_id, source_bmr_bpr_request_id, production_plan_id, product_id,
                     coa_template_id, template_snapshot_id, family_key, form_payload_json, workflow_status, coa_ip, dept_id, product_name,
                     batch_number, batch_size, batch_size_unit, test_date, tested_by,
                     review_approved_by, remark, status, created_by, created_at)
                  VALUES (?, ?, ?, ?, ?, NULLIF(?, 0), NULLIF(?, ''), ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NOW())"
            );
            $insertStmt->bind_param(
                'iiiiiisssissdissssi',
                $workItemId,
                $requestId,
                $productionPlanId,
                $productId,
                $coaTemplateId,
                $templateSnapshotId,
                $coaFamilyKey,
                $coaPayloadJson,
                $workflowStatus,
                $departmentId,
                $productName,
                $batchNumber,
                $batchSize,
                $batchUnitId,
                $testDate,
                $testedBy,
                $reviewedBy,
                $remark,
                $userId
            );
            if (!$insertStmt->execute()) {
                $insertError = (int) $insertStmt->errno;
                $insertStmt->close();
                if ($insertError === 1062) {
                    throw new DomainException('An IP COA already exists for this BMR/BPR request.');
                }
                throw new RuntimeException('Unable to create the IP COA.');
            }
            $ipCoaId = (int) $conn->insert_id;
            $insertStmt->close();
            $ipCoaNo = bmrBprIpCoaNumber($ipCoaId, $testDate);
            $numberStmt = bmrBprPrepare($conn, 'UPDATE ip_coa_generation SET coa_ip = ? WHERE id = ?');
            $numberStmt->bind_param('si', $ipCoaNo, $ipCoaId);
            if (!$numberStmt->execute()) {
                $numberStmt->close();
                throw new RuntimeException('Unable to assign the IP COA number.');
            }
            $numberStmt->close();
            bmrBprInsertHistory(
                $conn,
                'IP_COA',
                $ipCoaId,
                'CREATE_IP_COA',
                null,
                $workflowStatus,
                $remark,
                [
                    'source_bmr_work_item_id' => $workItemId,
                    'source_bmr_bpr_request_id' => $requestId,
                    'coa_ip' => $ipCoaNo,
                    'coa_template_id' => $coaTemplateId,
                ],
                $userId
            );
            $conn->commit();
            $inTransaction = false;
            $ipMessage = $workflowStatus === 'DRAFT'
                ? ' saved as draft.'
                : ($workflowStatus === 'REJECTED' ? ' completed with a Rejected decision.' : ' approved.');
            bmrBprJson('success', 'IP COA ' . $ipCoaNo . $ipMessage, [
                'id' => $ipCoaId,
                'coa_number' => $ipCoaNo,
            ]);

        case 'fg_queue_list':
            bmrBprRequirePermission($conn, 'fg_coa_generation_menu_list');
            $result = $conn->query(
                "SELECT
                    ip.id,
                    ip.created_at AS queued_at,
                    ip.product_id,
                    ip.product_name,
                    ip.batch_number,
                    ip.batch_size,
                    ip.batch_size_unit,
                    ip.test_date,
                    ip.source_bmr_bpr_request_id,
                    ip.source_bmr_work_item_id,
                    ip.coa_template_id,
                    ip.form_payload_json,
                    ip.workflow_status,
                    COALESCE(ip.source_bmr_bpr_request_id, source_item.request_id) AS request_id,
                    su.short_name AS batch_unit
                 FROM ip_coa_generation ip
                 LEFT JOIN bmr_bpr_work_items source_item
                    ON source_item.id = ip.source_bmr_work_item_id
                 LEFT JOIN standard_units su ON su.id = ip.batch_size_unit
                 LEFT JOIN fg_coa_generation fg
                    ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
                 WHERE ip.source_bmr_work_item_id IS NOT NULL
                   AND ip.deleted_at IS NULL
                   AND ip.workflow_status = 'COMPLETED'
                   AND fg.id IS NULL
                 ORDER BY ip.id DESC"
            );
            if (!$result) {
                throw new RuntimeException('Unable to load incoming FG COA forms.');
            }
            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $requestId = (int) ($row['request_id'] ?? 0);
                if (!bmrBprCoaRecordIsApproved($row) || !bmrBprRequestPackingStarted($conn, $requestId)) {
                    continue;
                }
                $batchNo = trim((string) ($row['batch_number'] ?? ''));
                $saStatus = 'APPROVED';
                $saLocked = false;
                if ($batchNo !== '') {
                    $saStmt = $conn->prepare("SELECT id, approval_status FROM coa_rm_pm_table WHERE (batch_number = ? OR auto_generated_batch = ?) AND deleted_at IS NULL ORDER BY id DESC LIMIT 1");
                    if ($saStmt) {
                        $saStmt->bind_param('ss', $batchNo, $batchNo);
                        $saStmt->execute();
                        $saRes = $saStmt->get_result()->fetch_assoc();
                        $saStmt->close();
                        if ($saRes && (int) $saRes['approval_status'] !== 1) {
                            $saStatus = 'PENDING';
                            $saLocked = true;
                        }
                    }
                }

                $rows[] = [
                    'id' => (string) $row['id'],
                    'timestamp' => $row['queued_at'] ? date('d-m-Y h:i A', strtotime($row['queued_at'])) : '',
                    'product_id' => isset($row['product_id']) ? (int) $row['product_id'] : null,
                    'product_name' => (string) ($row['product_name'] ?? ''),
                    'lot_number' => (string) ($row['batch_number'] ?? ''),
                    'batch_size_value' => $row['batch_size'] === null ? '' : (string) $row['batch_size'],
                    'batch_unit_id' => isset($row['batch_size_unit']) ? (int) $row['batch_size_unit'] : null,
                    'batch_size' => bmrBprDisplayBatchSize($row['batch_size'], $row['batch_unit'] ?? ''),
                    'testing_date' => (string) ($row['test_date'] ?? ''),
                    'sa_status' => $saStatus,
                    'is_locked' => $saLocked,
                ];
            }
            bmrBprJson('success', '', ['records' => $rows]);

        case 'create_fg_coa':
            bmrBprRequirePermission($conn, 'fg_coa_generation_add');
            $sourceIpId = (int) ($_POST['source_ip_coa_id'] ?? 0);
            $workflowStatus = strtoupper(trim((string) ($_POST['coa_workflow_action'] ?? 'COMPLETED'))) === 'DRAFT'
                ? 'DRAFT'
                : 'COMPLETED';
            $submittedCoaTemplateId = (int) ($_POST['coa_template_id'] ?? 0);
            $submittedCoaPayload = $_POST['coa_form_payload'] ?? null;
            $submittedCoaFamilyKey = trim((string) ($_POST['coa_family_key'] ?? ''));
            $liveStockId = (int) ($_POST['fgLiveStockId'] ?? 0);
            $departmentId = (int) ($_POST['prodDepartment'] ?? 0);
            $testDate = trim((string) ($_POST['testingDate'] ?? ''));
            $testedBy = trim((string) ($_POST['testedBy'] ?? ''));
            $reviewedBy = trim((string) ($_POST['reviewAndApproveBy'] ?? ''));
            $remark = trim((string) ($_POST['prodRemark'] ?? ''));
            if ($sourceIpId <= 0) {
                throw new InvalidArgumentException('Complete all required FG COA fields.');
            }

            $conn->begin_transaction();
            $inTransaction = true;
            $sourceStmt = bmrBprPrepare(
                $conn,
                'SELECT ip.id, ip.production_plan_id, ip.product_id, ip.product_name, ip.batch_number,
                        ip.batch_size, ip.batch_size_unit, ip.coa_template_id, ip.form_payload_json,
                        ip.workflow_status,
                        COALESCE(ip.source_bmr_bpr_request_id, source_item.request_id) AS request_id,
                        p.product_code
                 FROM ip_coa_generation ip
                 LEFT JOIN bmr_bpr_work_items source_item ON source_item.id = ip.source_bmr_work_item_id
                 LEFT JOIN products p ON p.id = ip.product_id
                 WHERE ip.id = ?
                   AND (ip.source_bmr_work_item_id IS NOT NULL OR ip.source_bmr_bpr_request_id IS NOT NULL)
                   AND ip.workflow_status = \'COMPLETED\' AND ip.deleted_at IS NULL
                 FOR UPDATE'
            );
            $sourceStmt->bind_param('i', $sourceIpId);
            $sourceStmt->execute();
            $source = $sourceStmt->get_result()->fetch_assoc();
            $sourceStmt->close();
            if (!$source || (int) ($source['product_id'] ?? 0) <= 0) {
                throw new DomainException('The source IP COA is not linked to a valid product.');
            }
            $requestId = (int) ($source['request_id'] ?? 0);
            if (!bmrBprCoaRecordIsApproved($source)) {
                throw new DomainException('FG COA generation requires an approved In-Process COA.');
            }
            if (!bmrBprRequestPackingStarted($conn, $requestId)) {
                throw new DomainException('FG COA generation is locked until BPR packing has started.');
            }

            $batchNo = trim((string) ($source['batch_number'] ?? ''));
            if ($batchNo !== '') {
                $saStmt = bmrBprPrepare(
                    $conn,
                    'SELECT id, approval_status FROM coa_rm_pm_table
                     WHERE (batch_number = ? OR auto_generated_batch = ?) AND deleted_at IS NULL
                     ORDER BY id DESC LIMIT 1'
                );
                $saStmt->bind_param('ss', $batchNo, $batchNo);
                $saStmt->execute();
                $saRes = $saStmt->get_result()->fetch_assoc();
                $saStmt->close();
                if ($saRes && (int) $saRes['approval_status'] !== 1) {
                    throw new DomainException('FG COA generation is locked until Sample Advice (SA) is approved by QA.');
                }
            }

            $duplicateStmt = bmrBprPrepare(
                $conn,
                'SELECT id FROM fg_coa_generation
                 WHERE source_ip_coa_id = ? AND deleted_at IS NULL
                 LIMIT 1 FOR UPDATE'
            );
            $duplicateStmt->bind_param('i', $sourceIpId);
            $duplicateStmt->execute();
            $duplicate = $duplicateStmt->get_result()->fetch_assoc();
            $duplicateStmt->close();
            if ($duplicate) {
                throw new DomainException('An FG COA already exists for this IP COA.');
            }

            $productName = trim((string) ($source['product_name'] ?? ''));
            $batchNumber = trim((string) ($source['batch_number'] ?? ''));
            $batchSize = (float) ($source['batch_size'] ?? 0);
            $batchUnitId = (int) ($source['batch_size_unit'] ?? 0);

            if ($liveStockId > 0) {
                $stockStmt = bmrBprPrepare(
                    $conn,
                    "SELECT ls.id, ls.product_id, COALESCE(ls.lot_batch_no, '') AS lot_batch_no,
                            COALESCE(ls.coa_number, '') AS coa_number,
                            COALESCE(ls.quantity_available, 0) AS batch_size,
                            COALESCE(ls.quantity_unit, 0) AS batch_size_unit,
                            p.product_name,
                            COALESCE(p.inventory_group, c.inventory_group, 1) AS inventory_group
                     FROM live_stock ls
                     JOIN products p ON p.id = ls.product_id
                     LEFT JOIN product_categories c ON c.id = p.category_id
                     WHERE ls.id = ? AND ls.status != 3 AND ls.deleted_at IS NULL
                     FOR UPDATE"
                );
                $stockStmt->bind_param('i', $liveStockId);
                $stockStmt->execute();
                $stock = $stockStmt->get_result()->fetch_assoc();
                $stockStmt->close();
                if (
                    !$stock
                    || (int) $stock['product_id'] !== (int) $source['product_id']
                    || (int) $stock['inventory_group'] !== 1
                ) {
                    throw new DomainException('The selected finished-goods inventory batch is invalid.');
                }
                if (trim((string) $stock['coa_number']) !== '') {
                    throw new DomainException('The selected inventory batch already has a COA number.');
                }
                $mappedStmt = bmrBprPrepare(
                    $conn,
                    'SELECT id FROM fg_coa_generation
                     WHERE live_stock_id = ? AND status != 3 AND deleted_at IS NULL
                     LIMIT 1 FOR UPDATE'
                );
                $mappedStmt->bind_param('i', $liveStockId);
                $mappedStmt->execute();
                $alreadyMapped = $mappedStmt->get_result()->fetch_assoc();
                $mappedStmt->close();
                if ($alreadyMapped) {
                    throw new DomainException('The selected inventory batch already has an FG COA.');
                }
                if (strcasecmp(trim((string) $stock['lot_batch_no']), trim((string) $source['batch_number'])) !== 0) {
                    throw new DomainException('Select the inventory batch that matches the source IP COA batch.');
                }
                $productName = trim((string) $stock['product_name']);
                $batchNumber = trim((string) $stock['lot_batch_no']);
                $batchSize = (float) ($stock['batch_size'] ?? 0);
                $batchUnitId = (int) ($stock['batch_size_unit'] ?? 0);
            } else {
                if ($batchSize <= 0 && !empty($_POST['prodBatchSize'])) {
                    $batchSize = (float) $_POST['prodBatchSize'];
                }
                if ($batchUnitId <= 0 && !empty($_POST['prodBatchSizeUnit'])) {
                    $batchUnitId = (int) $_POST['prodBatchSizeUnit'];
                }
            }

            if ($batchSize <= 0 || $batchUnitId <= 0) {
                throw new DomainException('The source manufacturing batch does not contain a valid batch size and unit.');
            }

            $yearPrefix = date('y');
            $sequencePrefix = 'BIPL-COA-FG-' . $yearPrefix;
            $namedLock = 'fg_coa_sequence_' . $yearPrefix;
            $lockStmt = bmrBprPrepare($conn, 'SELECT GET_LOCK(?, 10) AS acquired');
            $lockStmt->bind_param('s', $namedLock);
            $lockStmt->execute();
            $lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0);
            $lockStmt->close();
            if ($lockAcquired !== 1) {
                throw new RuntimeException('Unable to allocate an FG COA number. Please try again.');
            }

            $likePrefix = $sequencePrefix . '%';
            $sequenceStmt = bmrBprPrepare(
                $conn,
                'SELECT coa_fg FROM fg_coa_generation WHERE coa_fg LIKE ? ORDER BY id DESC'
            );
            $sequenceStmt->bind_param('s', $likePrefix);
            $sequenceStmt->execute();
            $sequenceResult = $sequenceStmt->get_result();
            $lastSequence = 0;
            $sequencePattern = '/^' . preg_quote($sequencePrefix, '/') . '(\d{4})$/';
            while ($sequenceRow = $sequenceResult->fetch_assoc()) {
                if (preg_match($sequencePattern, trim((string) $sequenceRow['coa_fg']), $matches)) {
                    $lastSequence = max($lastSequence, (int) $matches[1]);
                }
            }
            $sequenceStmt->close();
            $fgCoaNo = $sequencePrefix . str_pad((string) ($lastSequence + 1), 4, '0', STR_PAD_LEFT);
            $productId = (int) $source['product_id'];
            $productionPlanId = isset($source['production_plan_id']) ? (int) $source['production_plan_id'] : null;
            $productCode = trim((string) ($source['product_code'] ?? ''));
            $templateSubmission = coaTemplateValidateSubmission(
                $conn,
                $productId,
                'FG',
                $submittedCoaTemplateId,
                $submittedCoaPayload,
                $workflowStatus === 'COMPLETED',
                $submittedCoaFamilyKey
            );
            $coaTemplateId = $templateSubmission === null
                ? null
                : (int) $templateSubmission['template_id'];
            $coaPayloadJson = $templateSubmission === null
                ? null
                : json_encode(
                    $templateSubmission['payload'],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
                );
            $coaFamilyKey = $templateSubmission === null ? '' : (string) ($templateSubmission['template']['profile']['family_key'] ?? '');
            $templateSnapshotId = $templateSubmission === null ? 0 : templateSnapshotCreateCoa(
                $conn,
                'FG',
                $templateSubmission['template'],
                $productId,
                $productName,
                $batchNumber,
                $userId,
                $submittedCoaFamilyKey !== '' ? 'MANUAL_OVERRIDE' : 'PREMAPPED'
            );
            $workflowStatus = bmrBprNormalizeCoaWorkflowStatus(
                $workflowStatus,
                $coaTemplateId,
                $coaPayloadJson,
                'Finished-Goods COA'
            );
            if ($templateSubmission !== null && !empty($templateSubmission['payload']['fields'])) {
                $fields = $templateSubmission['payload']['fields'];
                if ($testedBy === '') {
                    $testedBy = trim((string) ($fields['approval.analysis_by_name'] ?? ''));
                    if ($testedBy === '' && !empty($fields['approval.analysis_by']) && !coaTemplateIsImageValue((string) $fields['approval.analysis_by'])) {
                        $testedBy = trim((string) $fields['approval.analysis_by']);
                    }
                }
                if ($reviewedBy === '') {
                    $reviewedBy = trim((string) ($fields['approval.verified_by_name'] ?? ''));
                    if ($reviewedBy === '' && !empty($fields['approval.verified_by']) && !coaTemplateIsImageValue((string) $fields['approval.verified_by'])) {
                        $reviewedBy = trim((string) $fields['approval.verified_by']);
                    }
                }
                if ($remark === '') {
                    $remark = trim((string) ($fields['approval.comments'] ?? ($fields['results.remarks'] ?? '')));
                }
            }

            $insertLiveStockId = $liveStockId > 0 ? $liveStockId : null;

            $insertStmt = bmrBprPrepare(
                $conn,
                "INSERT INTO fg_coa_generation
                    (source_ip_coa_id, production_plan_id, coa_fg, product_id, coa_template_id,
                     template_snapshot_id, family_key, form_payload_json, workflow_status, live_stock_id, dept_id,
                     product_name, batch_number, batch_size, batch_size_unit, test_date,
                     tested_by, review_approved_by, remark, status, created_by, created_at)
                  VALUES (?, ?, ?, ?, ?, NULLIF(?, 0), NULLIF(?, ''), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, NOW())"
            );
            $insertStmt->bind_param(
                'iisiiisssiissdissssi',
                $sourceIpId,
                $productionPlanId,
                $fgCoaNo,
                $productId,
                $coaTemplateId,
                $templateSnapshotId,
                $coaFamilyKey,
                $coaPayloadJson,
                $workflowStatus,
                $insertLiveStockId,
                $departmentId,
                $productName,
                $batchNumber,
                $batchSize,
                $batchUnitId,
                $testDate,
                $testedBy,
                $reviewedBy,
                $remark,
                $userId
            );
            if (!$insertStmt->execute()) {
                $insertStmt->close();
                throw new RuntimeException('Unable to create the FG COA.');
            }
            $fgCoaId = (int) $conn->insert_id;
            $insertStmt->close();

            if ($liveStockId > 0) {
                $mapStmt = bmrBprPrepare(
                    $conn,
                    'UPDATE live_stock SET coa_number = ?, updated_by = ?, updated_at = NOW() WHERE id = ?'
                );
                $mapStmt->bind_param('sii', $fgCoaNo, $userId, $liveStockId);
                if (!$mapStmt->execute()) {
                    $mapStmt->close();
                    throw new RuntimeException('Unable to map the FG COA to inventory.');
                }
                $mapStmt->close();
            }

            bmrBprInsertHistory(
                $conn,
                'FG_COA',
                $fgCoaId,
                'CREATE_FG_COA',
                null,
                $workflowStatus,
                $remark,
                [
                    'source_ip_coa_id' => $sourceIpId,
                    'coa_fg' => $fgCoaNo,
                    'coa_template_id' => $coaTemplateId,
                ],
                $userId
            );
            $queuedTransferId = $workflowStatus === 'COMPLETED'
                ? bmrBprEnsurePendingTransferTicketForRequest($conn, $requestId, $userId)
                : null;
            $conn->commit();
            $inTransaction = false;
            $releaseStmt = bmrBprPrepare($conn, 'SELECT RELEASE_LOCK(?)');
            $releaseStmt->bind_param('s', $namedLock);
            $releaseStmt->execute();
            $releaseStmt->close();
            $namedLock = null;
            if ($workflowStatus === 'DRAFT') {
                $fgMessage = ' saved as draft.';
            } elseif ($workflowStatus === 'REJECTED') {
                $fgMessage = ' completed with a Rejected decision; transfer remains blocked.';
            } elseif ($queuedTransferId !== null) {
                $fgMessage = ' approved and queued for transfer.';
            } else {
                $fgMessage = ' approved; transfer will queue after every BPR is complete.';
            }
            bmrBprJson('success', 'FG COA ' . $fgCoaNo . $fgMessage, [
                'id' => $fgCoaId,
                'coa_number' => $fgCoaNo,
            ]);

        case 'transfer_queue_list':
            bmrBprRequirePermission($conn, 'transfer_ticket_menu_list');
            $result = $conn->query(
                "SELECT
                    fg.id,
                    fg.coa_fg,
                    fg.test_date,
                    fg.product_id,
                    fg.product_name,
                    fg.batch_number,
                    fg.batch_size,
                    fg.batch_size_unit,
                    fg.coa_template_id,
                    fg.form_payload_json,
                    fg.workflow_status,
                    COALESCE(ip.source_bmr_bpr_request_id, source_item.request_id) AS request_id,
                    su.short_name AS batch_unit,
                    COALESCE(tt.mfg_date, ls.mfg_date, fg.test_date) AS mfg_date,
                    COALESCE(tt.exp_date, ls.exp_date) AS exp_date,
                    COALESCE(u.name, '-') AS created_by_name,
                    COALESCE(NULLIF(tt.sampled_qa, ''), fg.tested_by, u.name, '') AS sampled_by_name,
                    tt.id AS pending_transfer_ticket_id,
                    tt.ticket_no AS pending_ticket_no,
                    COALESCE(tt.workflow_status, 'PENDING') AS transfer_workflow_status
                 FROM fg_coa_generation fg
                 LEFT JOIN ip_coa_generation ip ON ip.id = fg.source_ip_coa_id
                 LEFT JOIN bmr_bpr_work_items source_item ON source_item.id = ip.source_bmr_work_item_id
                 LEFT JOIN standard_units su ON su.id = fg.batch_size_unit
                 LEFT JOIN live_stock ls ON ls.id = fg.live_stock_id
                 LEFT JOIN users u ON u.id = fg.created_by
                 LEFT JOIN transfer_ticket tt
                    ON tt.source_fg_coa_id = fg.id AND tt.deleted_at IS NULL
                 WHERE fg.source_ip_coa_id IS NOT NULL
                   AND fg.deleted_at IS NULL
                   AND fg.workflow_status = 'COMPLETED'
                   AND (tt.id IS NULL OR tt.workflow_status = 'PENDING')
                 ORDER BY fg.id DESC"
            );
            if (!$result) {
                throw new RuntimeException('Unable to load incoming Transfer Tickets.');
            }
            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $requestId = (int) ($row['request_id'] ?? 0);
                if (!bmrBprCoaRecordIsApproved($row) || !bmrBprRequestBprComplete($conn, $requestId)) {
                    continue;
                }
                $rows[] = [
                    'id' => (string) $row['id'],
                    'testing_date' => $row['test_date'] ? date('d-m-Y', strtotime($row['test_date'])) : '',
                    'testing_date_value' => (string) ($row['test_date'] ?? ''),
                    'fg_coa_number' => (string) ($row['coa_fg'] ?? ''),
                    'product_id' => isset($row['product_id']) ? (int) $row['product_id'] : null,
                    'product' => (string) ($row['product_name'] ?? ''),
                    'created_by' => (string) $row['created_by_name'],
                    'sampled_by' => (string) ($row['sampled_by_name'] ?? ''),
                    'batch_size_value' => $row['batch_size'] === null ? '' : (string) $row['batch_size'],
                    'batch_size' => bmrBprDisplayBatchSize($row['batch_size'], $row['batch_unit'] ?? ''),
                    'batch_number' => (string) ($row['batch_number'] ?? ''),
                    'mfg_date' => (string) ($row['mfg_date'] ?? ''),
                    'exp_date' => (string) ($row['exp_date'] ?? ''),
                    'quantity' => $row['batch_size'] === null ? '' : (string) $row['batch_size'],
                    'unit' => (string) ($row['batch_unit'] ?? ''),
                    'unit_id' => isset($row['batch_size_unit']) ? (int) $row['batch_size_unit'] : null,
                    'pending_transfer_ticket_id' => isset($row['pending_transfer_ticket_id']) ? (int) $row['pending_transfer_ticket_id'] : null,
                    'pending_ticket_no' => (string) ($row['pending_ticket_no'] ?? ''),
                ];
            }
            bmrBprJson('success', '', ['records' => $rows]);

        case 'create_transfer_ticket':
            bmrBprRequirePermission($conn, 'transfer_ticket_add');
            $sourceFgId = (int) ($_POST['source_fg_coa_id'] ?? 0);
            $mfgDate = trim((string) ($_POST['mfg_date'] ?? ''));
            $expDate = trim((string) ($_POST['exp_date'] ?? ''));
            $sampledBy = trim((string) ($_POST['sampled_by'] ?? ''));
            $quantity = (float) ($_POST['quantity'] ?? 0);
            if ($sourceFgId <= 0 || $mfgDate === '' || $expDate === '' || $sampledBy === '' || $quantity <= 0) {
                throw new InvalidArgumentException('Complete the manufacturing date, expiry date, QC sampler and transferred quantity.');
            }
            if (strtotime($expDate) <= strtotime($mfgDate)) {
                throw new InvalidArgumentException('The expiry date must be after the manufacturing date.');
            }

            $conn->begin_transaction();
            $inTransaction = true;
            $source = bmrBprLoadReleaseSource($conn, $sourceFgId, true);
            $requestId = (int) ($source['request_id'] ?? 0);
            bmrBprValidateTransferQuantity($quantity, (float) $source['batch_size']);

            // Origin check: Live Inventory (linked_order_id <= 0) vs Order Management (linked_order_id > 0)
            $linkedOrderId = (int) ($source['linked_order_id'] ?? 0);
            $isLiveInventoryOrigin = ($linkedOrderId <= 0);
            $ticketWorkflowStatus = $isLiveInventoryOrigin ? 'RECEIVED' : 'TRANSFERRED';

            $existingTtStmt = bmrBprPrepare(
                $conn,
                'SELECT id, ticket_no, workflow_status, quantity_transferred, mfg_date, exp_date, sampled_qa FROM transfer_ticket
                 WHERE source_fg_coa_id = ? AND deleted_at IS NULL
                 LIMIT 1 FOR UPDATE'
            );
            $existingTtStmt->bind_param('i', $sourceFgId);
            $existingTtStmt->execute();
            $existingTt = $existingTtStmt->get_result()->fetch_assoc();
            $existingTtStmt->close();

            $transferId = 0;
            $ticketNo = '';
            $unitId = isset($source['batch_size_unit']) ? (int) $source['batch_size_unit'] : null;

            if ($existingTt) {
                if (($existingTt['workflow_status'] ?? '') !== 'PENDING') {
                    if (in_array($existingTt['workflow_status'], ['TRANSFERRED', 'RECEIVED'], true)
                        && abs((float) $existingTt['quantity_transferred'] - $quantity) <= 0.00000001
                        && $existingTt['mfg_date'] === $mfgDate && $existingTt['exp_date'] === $expDate
                        && $existingTt['sampled_qa'] === $sampledBy) {
                        $conn->commit();
                        $inTransaction = false;
                        bmrBprJson('success', 'This Transfer Ticket has already been confirmed.', ['id' => (int) $existingTt['id']]);
                    }
                    throw new DomainException('A confirmed Transfer Ticket cannot be changed.');
                }
                $transferId = (int) $existingTt['id'];
                $ticketNo = (string) $existingTt['ticket_no'];
                $formattedQty = rtrim(rtrim(number_format($quantity, 8, '.', ''), '0'), '.');
                $updateTtStmt = bmrBprPrepare(
                    $conn,
                    "UPDATE transfer_ticket
                     SET mfg_date = ?, exp_date = ?, sampled_qa = ?, quantity_transferred = ?,
                         quantity_transferred_unit = ?, status = 1, workflow_status = ?,
                         updated_by = ?, updated_at = NOW()
                     WHERE id = ?"
                );
                $updateTtStmt->bind_param('ssssisii', $mfgDate, $expDate, $sampledBy, $formattedQty, $unitId, $ticketWorkflowStatus, $userId, $transferId);
                if (!$updateTtStmt->execute()) {
                    $updateTtStmt->close();
                    throw new RuntimeException('Unable to confirm the Transfer Ticket.');
                }
                $updateTtStmt->close();
            } else {
                $ticketDate = (string) (($source['test_date'] ?? '') ?: date('Y-m-d'));
                $ticketNo = bmrBprTransferTicketNumber($sourceFgId, $ticketDate);
                $autoBatch = generateBatchNumber();
                $batchSize = (float) ($source['batch_size'] ?? 0);
                $data = [
                    'source_fg_coa_id' => $sourceFgId,
                    'prod_plan_id' => isset($source['production_plan_id']) ? (int) $source['production_plan_id'] : null,
                    'ticket_no' => $ticketNo,
                    'fg_coa_no' => (string) ($source['coa_fg'] ?? ''),
                    'code' => (string) ($source['product_code'] ?? ''),
                    'date' => $ticketDate,
                    'product_description' => (string) ($source['product_name'] ?? ''),
                    'pack_size' => (int) round($batchSize),
                    'pack_size_unit' => $unitId,
                    'product_code' => (string) ($source['product_code'] ?? ''),
                    'batch_no' => (string) ($source['batch_number'] ?? ''),
                    'mfg_date' => $mfgDate,
                    'exp_date' => $expDate,
                    'sampled_qa' => $sampledBy,
                    'sampled_qa_unit' => null,
                    'quantity_transferred' => rtrim(rtrim(number_format($quantity, 8, '.', ''), '0'), '.'),
                    'quantity_transferred_unit' => $unitId,
                    'status' => 1,
                    'auto_batch_number' => $autoBatch,
                    'remark' => 'Created from the FG COA incoming workflow.',
                    'workflow_status' => $ticketWorkflowStatus,
                    'created_by' => $userId,
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $insert = insertRecordIntoTable($conn, 'transfer_ticket', $data);
                if (!is_numeric($insert)) {
                    throw new RuntimeException('Unable to create the Transfer Ticket.');
                }
                $transferId = (int) $insert;
            }
            $receiptProductionPlanId = isset($source['production_plan_id']) ? (int) $source['production_plan_id'] : null;
            $receiptProductId = (int) ($source['product_id'] ?? 0);
            $receiptStockId = isset($source['live_stock_id']) ? (int) $source['live_stock_id'] : null;
            $receiptBatchNumber = (string) ($source['batch_number'] ?? '');

            if ($isLiveInventoryOrigin) {
                // =========================================================
                // ROUTE B: Live Inventory Origin
                // Finished goods credited directly to Live Stock inventory.
                // Closes production flow at Step 11 without staging Step 12.
                // =========================================================
                $finalLiveStockId = $receiptProductId > 0
                    ? inventoryAddStock(
                        $conn,
                        $receiptProductId,
                        $quantity,
                        $userId,
                        'production_transfer',
                        $transferId,
                        'production_transfer:' . $transferId,
                        'Finished goods credited directly from Transfer Ticket ' . $ticketNo
                    )
                    : 0;

                if ($finalLiveStockId > 0 && $sourceFgId > 0) {
                    $linkFgStmt = bmrBprPrepare($conn, 'UPDATE fg_coa_generation SET live_stock_id = ? WHERE id = ?');
                    $linkFgStmt->bind_param('ii', $finalLiveStockId, $sourceFgId);
                    $linkFgStmt->execute();
                    $linkFgStmt->close();
                }

                if ($receiptProductionPlanId && $receiptProductionPlanId > 0) {
                    $completeStatus = 2; // ProductionCompleted
                    $planUpStmt = $conn->prepare("UPDATE `production_plans` SET `status` = ?, `updated_by` = ?, `updated_at` = NOW() WHERE `id` = ? AND `status` != 3");
                    if ($planUpStmt) {
                        $planUpStmt->bind_param('iii', $completeStatus, $userId, $receiptProductionPlanId);
                        $planUpStmt->execute();
                        $planUpStmt->close();
                    }
                    insertProductionHistory($conn, [
                        'production_id' => $receiptProductionPlanId,
                        'action_type' => (int) Constant::PRODUCTION['PRODUCTION_ACTION_TYPE_LABEL']['ProductionCompleted'],
                        'related_table' => 'transfer_ticket',
                        'related_record_id' => $transferId,
                        'old_flow_status' => 1,
                        'new_flow_status' => $completeStatus,
                        'update_type' => 1,
                        'changed_fields' => ['status' => $completeStatus, 'transfer_ticket_id' => $transferId, 'live_stock_id' => $finalLiveStockId],
                        'remarks' => 'Production completed and finished goods credited directly to Live Stock inventory via Transfer Ticket.',
                        'action_by' => $userId,
                        'action_at' => date('Y-m-d H:i:s'),
                        'created_by' => $userId
                    ]);
                }

                $productionRoleIds = [];
                $prodPermissionSlug = getPermissionSlugForPage($conn, 'transfer-ticket');
                if ($prodPermissionSlug) {
                    $roleStmt = bmrBprPrepare(
                        $conn,
                        'SELECT DISTINCT role_permission.role_id
                         FROM role_permissions role_permission
                         INNER JOIN permissions permission ON permission.id = role_permission.permission_id
                         WHERE role_permission.status = 1 AND permission.slug = ?'
                    );
                    $roleStmt->bind_param('s', $prodPermissionSlug);
                    $roleStmt->execute();
                    $roleResult = $roleStmt->get_result();
                    while ($role = $roleResult->fetch_assoc()) {
                        $productionRoleIds[] = (int) $role['role_id'];
                    }
                    $roleStmt->close();
                }
                createNotification($conn, [
                    'module' => 'PRODUCTION',
                    'ref_table' => 'transfer_ticket',
                    'ref_id' => $transferId,
                    'title' => 'Transfer Ticket completed',
                    'message' => 'Transfer Ticket ' . $ticketNo . ' completed. Finished goods credited to Live Stock.',
                    'notification_type' => 1,
                    'severity' => 1,
                    'created_by' => $userId,
                    'role_ids' => $productionRoleIds,
                ]);

                bmrBprInsertHistory(
                    $conn,
                    'TRANSFER_TICKET',
                    $transferId,
                    'COMPLETE_TRANSFER_TICKET',
                    'PENDING',
                    'RECEIVED',
                    'Transfer ticket completed and stock credited directly to Live Stock inventory.',
                    ['source_fg_coa_id' => $sourceFgId, 'ticket_no' => $ticketNo, 'live_stock_id' => $finalLiveStockId, 'origin' => 'LIVE_INVENTORY'],
                    $userId
                );
                $conn->commit();
                $inTransaction = false;
                bmrBprJson('success', 'Transfer Ticket ' . $ticketNo . ' completed. Finished goods credited directly to Live Stock inventory.', [
                    'id' => $transferId,
                    'ticket_no' => $ticketNo,
                    'origin' => 'LIVE_INVENTORY',
                    'live_stock_id' => $finalLiveStockId,
                    'linked_order_id' => $linkedOrderId,
                ]);
            } else {
                // =========================================================
                // ROUTE A: Order Management Origin
                // Transfer stages a receipt for Store acknowledgement (Step 12).
                // Output is not credited to free available stock at Step 11.
                // =========================================================
                $finalLiveStockId = $receiptProductId > 0
                    ? inventoryEnsureBalance($conn, $receiptProductId, $userId)
                    : 0;

                if ($finalLiveStockId > 0) {
                    $receiptStockId = $finalLiveStockId;
                    if ($sourceFgId > 0) {
                        $linkFgStmt = bmrBprPrepare($conn, 'UPDATE fg_coa_generation SET live_stock_id = ? WHERE id = ? AND live_stock_id IS NULL');
                        $linkFgStmt->bind_param('ii', $finalLiveStockId, $sourceFgId);
                        $linkFgStmt->execute();
                        $linkFgStmt->close();
                    }
                }

                $receiptStmt = bmrBprPrepare(
                    $conn,
                    "INSERT INTO goods_received_from_production
                        (transfer_ticket_id, production_plan_id, product_id, live_stock_id, ticket_no,
                         lot_batch_no, transferred_quantity, actual_received_quantity, quantity_unit_id, receipt_status, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', NOW())
                     ON DUPLICATE KEY UPDATE transferred_quantity = VALUES(transferred_quantity),
                         actual_received_quantity = VALUES(actual_received_quantity),
                         quantity_unit_id = VALUES(quantity_unit_id),
                         live_stock_id = COALESCE(VALUES(live_stock_id), live_stock_id), updated_at = NOW()"
                );
                $receiptStmt->bind_param('iiiissddi', $transferId, $receiptProductionPlanId, $receiptProductId, $receiptStockId, $ticketNo, $receiptBatchNumber, $quantity, $quantity, $unitId);
                if (!$receiptStmt->execute()) {
                    $receiptStmt->close();
                    throw new RuntimeException('Unable to create the Store receipt acknowledgement.');
                }
                $receiptStmt->close();

                $storeRoleIds = [];
                $storePermissionSlug = getPermissionSlugForPage($conn, 'goods-received-production');
                if ($storePermissionSlug) {
                    $roleStmt = bmrBprPrepare(
                        $conn,
                        'SELECT DISTINCT role_permission.role_id
                         FROM role_permissions role_permission
                         INNER JOIN permissions permission ON permission.id = role_permission.permission_id
                         WHERE role_permission.status = 1 AND permission.slug = ?'
                    );
                    $roleStmt->bind_param('s', $storePermissionSlug);
                    $roleStmt->execute();
                    $roleResult = $roleStmt->get_result();
                    while ($role = $roleResult->fetch_assoc()) {
                        $storeRoleIds[] = (int) $role['role_id'];
                    }
                    $roleStmt->close();
                }
                $notificationId = createNotification($conn, [
                    'module' => 'STORE',
                    'ref_table' => 'transfer_ticket',
                    'ref_id' => $transferId,
                    'title' => 'Production transfer awaiting receipt',
                    'message' => 'Transfer Ticket ' . $ticketNo . ' is ready for Store acknowledgement.',
                    'notification_type' => 1,
                    'severity' => 1,
                    'created_by' => $userId,
                    'role_ids' => $storeRoleIds,
                ]);
                if (!$notificationId) {
                    throw new RuntimeException('Unable to create the Store receipt notification.');
                }
                bmrBprInsertHistory(
                    $conn,
                    'TRANSFER_TICKET',
                    $transferId,
                    'CREATE_TRANSFER_TICKET',
                    'PENDING',
                    'TRANSFERRED',
                    'Transfer ticket created and routed to Store Goods Received.',
                    ['source_fg_coa_id' => $sourceFgId, 'ticket_no' => $ticketNo, 'live_stock_id' => $finalLiveStockId, 'origin' => 'ORDER_MANAGEMENT'],
                    $userId
                );
                $conn->commit();
                $inTransaction = false;
                bmrBprJson('success', 'Transfer Ticket ' . $ticketNo . ' created and routed to Store Goods Received.', [
                    'id' => $transferId,
                    'ticket_no' => $ticketNo,
                    'origin' => 'ORDER_MANAGEMENT',
                ]);
            }

        default:
            bmrBprJson('error', 'Invalid BMR/BPR workflow action.', [], 422);
    }
} catch (InvalidArgumentException|DomainException $exception) {
    if ($inTransaction) {
        $conn->rollback();
    }
    if ($namedLock !== null) {
        $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
        if ($releaseStmt) {
            $releaseStmt->bind_param('s', $namedLock);
            $releaseStmt->execute();
            $releaseStmt->close();
        }
    }
    bmrBprJson('error', $exception->getMessage(), [], 422);
} catch (Throwable $exception) {
    if ($inTransaction) {
        $conn->rollback();
    }
    if ($namedLock !== null) {
        $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
        if ($releaseStmt) {
            $releaseStmt->bind_param('s', $namedLock);
            $releaseStmt->execute();
            $releaseStmt->close();
        }
    }
    error_log('BMR/BPR workflow error: ' . $exception->getMessage());
    bmrBprJson('error', 'The BMR/BPR workflow action could not be completed.', [], 500);
}
