<?php

declare(strict_types=1);

/**
 * Repairs deterministic extraction artefacts found in schema-v1, page-image
 * BMR/BPR layouts. Structured schema-v2 templates are returned unchanged.
 *
 * The legacy importer occasionally treated narrow PDF grid-line fragments as
 * writable cells, treated the logo cell as writable, and selected only a thin
 * fragment of the Product name cell. These rules intentionally target only
 * those known shapes and preserve any field that already contains user data.
 */
function bmrBprNormalizeLegacyLayout(array $layout, array $preserveFieldIds = []): array
{
    if ((int) ($layout['schema_version'] ?? 1) >= 2) {
        return $layout;
    }

    $preserve = [];
    foreach ($preserveFieldIds as $key => $value) {
        $fieldId = is_int($key) ? trim((string) $value) : trim((string) $key);
        if ($fieldId !== '') {
            $preserve[$fieldId] = true;
        }
    }

    $pages = is_array($layout['pages'] ?? null) ? $layout['pages'] : [];
    foreach ($pages as &$page) {
        if (!is_array($page)) {
            continue;
        }
        $pageWidth = max(1.0, (float) ($page['width'] ?? 596));
        $fields = is_array($page['fields'] ?? null) ? $page['fields'] : [];
        $remove = [];

        foreach ($fields as $sourceIndex => &$sourceField) {
            if (!is_array($sourceField) || (string) ($sourceField['source'] ?? '') !== 'product_name') {
                continue;
            }
            $sourceWidthPoints = ((float) ($sourceField['w'] ?? 0) / 100) * $pageWidth;
            if ($sourceWidthPoints >= 12) {
                continue;
            }

            $sourceX = (float) ($sourceField['x'] ?? 0);
            $sourceY = (float) ($sourceField['y'] ?? 0);
            $sourceHeight = (float) ($sourceField['h'] ?? 0);
            $right = $sourceX + (float) ($sourceField['w'] ?? 0);
            $matched = [];
            foreach ($fields as $candidateIndex => $candidate) {
                if (
                    $candidateIndex === $sourceIndex
                    || !is_array($candidate)
                    || empty($candidate['editable'])
                    || !preg_match('/^p\d+_t\d+_r\d+_c\d+$/D', (string) ($candidate['id'] ?? ''))
                ) {
                    continue;
                }
                $candidateX = (float) ($candidate['x'] ?? 0);
                $candidateY = (float) ($candidate['y'] ?? 0);
                $candidateHeight = (float) ($candidate['h'] ?? 0);
                if (
                    $candidateX <= $sourceX
                    || $candidateX - $sourceX > 40
                    || abs($candidateY - $sourceY) > 0.35
                    || abs($candidateHeight - $sourceHeight) > 0.5
                ) {
                    continue;
                }
                $right = max($right, $candidateX + (float) ($candidate['w'] ?? 0));
                $matched[] = $candidateIndex;
            }

            if ($right - $sourceX >= 10) {
                $sourceField['w'] = round(min(100 - $sourceX, $right - $sourceX), 5);
                foreach ($matched as $candidateIndex) {
                    $candidateId = trim((string) ($fields[$candidateIndex]['id'] ?? ''));
                    if ($candidateId === '' || !isset($preserve[$candidateId])) {
                        $remove[$candidateIndex] = true;
                    }
                }
            }
        }
        unset($sourceField);

        foreach ($fields as $index => $field) {
            if (!is_array($field) || empty($field['editable'])) {
                continue;
            }
            $fieldId = trim((string) ($field['id'] ?? ''));
            if ($fieldId !== '' && isset($preserve[$fieldId])) {
                continue;
            }
            $isGeneratedTableCell = preg_match(
                '/^p\d+_t\d+_r\d+_c\d+$/D',
                $fieldId
            ) === 1;
            if (!$isGeneratedTableCell) {
                continue;
            }
            $widthPoints = ((float) ($field['w'] ?? 0) / 100) * $pageWidth;
            $isGridFragment = $widthPoints < 12;
            $isLogoCell = preg_match('/^p\d+_t1_r1_c1$/D', $fieldId) === 1
                && (float) ($field['x'] ?? 100) < 45
                && (float) ($field['y'] ?? 100) < 10;
            if ($isGridFragment || $isLogoCell) {
                $remove[$index] = true;
            }
        }

        $page['fields'] = array_values(array_filter(
            $fields,
            static fn ($field, int $index): bool => !isset($remove[$index]),
            ARRAY_FILTER_USE_BOTH
        ));
    }
    unset($page);

    $repairedProductSources = [];
    foreach ($pages as $page) {
        $pageWidth = max(1.0, (float) ($page['width'] ?? 596));
        foreach ((array) ($page['fields'] ?? []) as $field) {
            if ((string) ($field['source'] ?? '') !== 'product_name') {
                continue;
            }
            if ((((float) ($field['w'] ?? 0) / 100) * $pageWidth) >= 12) {
                $repairedProductSources[] = $field;
            }
        }
    }
    if ($repairedProductSources !== []) {
        foreach ($pages as &$page) {
            $pageWidth = max(1.0, (float) ($page['width'] ?? 596));
            foreach ($page['fields'] as &$field) {
                if (
                    (string) ($field['source'] ?? '') !== 'product_name'
                    || (((float) ($field['w'] ?? 0) / 100) * $pageWidth) >= 12
                ) {
                    continue;
                }
                foreach ($repairedProductSources as $candidate) {
                    if (
                        abs((float) ($candidate['x'] ?? 0) - (float) ($field['x'] ?? 0)) <= 1
                        && abs((float) ($candidate['y'] ?? 0) - (float) ($field['y'] ?? 0)) <= 1
                    ) {
                        $field['w'] = (float) $candidate['w'];
                        break;
                    }
                }
            }
            unset($field);
        }
        unset($page);
    }

    $layout['pages'] = $pages;
    return $layout;
}

function bmrBprLegacyLayoutDefects(array $layout): array
{
    $defects = [
        'tiny_editable_fields' => 0,
        'logo_editable_fields' => 0,
        'tiny_product_sources' => 0,
    ];
    if ((int) ($layout['schema_version'] ?? 1) >= 2) {
        return $defects;
    }
    foreach ((array) ($layout['pages'] ?? []) as $page) {
        $pageWidth = max(1.0, (float) ($page['width'] ?? 596));
        foreach ((array) ($page['fields'] ?? []) as $field) {
            $fieldId = (string) ($field['id'] ?? '');
            if (!empty($field['editable']) && preg_match('/^p\d+_t\d+_r\d+_c\d+$/D', $fieldId)) {
                if ((((float) ($field['w'] ?? 0) / 100) * $pageWidth) < 12) {
                    $defects['tiny_editable_fields']++;
                }
                if (
                    preg_match('/^p\d+_t1_r1_c1$/D', $fieldId)
                    && (float) ($field['x'] ?? 100) < 45
                    && (float) ($field['y'] ?? 100) < 10
                ) {
                    $defects['logo_editable_fields']++;
                }
            }
            if (
                (string) ($field['source'] ?? '') === 'product_name'
                && (((float) ($field['w'] ?? 0) / 100) * $pageWidth) < 12
            ) {
                $defects['tiny_product_sources']++;
            }
        }
    }
    return $defects;
}
