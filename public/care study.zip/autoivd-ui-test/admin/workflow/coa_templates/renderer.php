<?php

declare(strict_types=1);

function coaTemplateEscape(string|int|float|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function coaTemplateFields(array $form): array
{
    $payload = is_array($form['form_payload'] ?? null) ? $form['form_payload'] : [];
    return is_array($payload['fields'] ?? null) ? $payload['fields'] : [];
}

function coaTemplateIsImageValue(string $value): bool
{
    $val = trim($value);
    return str_starts_with($val, 'data:image/')
        || (bool) preg_match('/\.(png|jpe?g|webp|gif|svg)$/i', $val);
}

function coaTemplateIsSignatureKey(string $key): bool
{
    $lower = strtolower(trim($key));
    return str_ends_with($lower, 'signature')
        || str_ends_with($lower, '_signature')
        || str_ends_with($lower, 'analysis_by')
        || str_ends_with($lower, 'verified_by')
        || in_array($lower, ['approval.analysis_by', 'approval.verified_by'], true);
}

function coaTemplateIsDateKey(string $key): bool
{
    $lower = strtolower(trim($key));
    if (str_contains($lower, 'signature')) {
        return false;
    }
    return str_ends_with($lower, 'date')
        || str_ends_with($lower, '_date')
        || str_ends_with($lower, '.date')
        || str_ends_with($lower, 'manufacturing_date')
        || str_ends_with($lower, 'expiry_date')
        || in_array($lower, ['date', 'testing_date', 'metadata.manufacturing_date', 'metadata.expiry_date'], true);
}

function coaTemplateFormatDateForInput(string $value): string
{
    $val = trim($value);
    if ($val === '') {
        return '';
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
        return $val;
    }
    if (preg_match('/^(\d{1,2})[\/\.-](\d{1,2})[\/\.-](\d{4})$/', $val, $m)) {
        return sprintf('%04d-%02d-%02d', (int) $m[3], (int) $m[2], (int) $m[1]);
    }
    $timestamp = strtotime($val);
    if ($timestamp !== false && $timestamp > 0) {
        return date('Y-m-d', $timestamp);
    }
    return $val;
}

function coaTemplateInput(
    string $key,
    array $fields,
    bool $editable,
    string $placeholder = ''
): string {
    $value = trim((string) ($fields[$key] ?? ''));
    $isImage = coaTemplateIsImageValue($value);

    if (!$editable) {
        if (coaTemplateIsSignatureKey($key)) {
            $nameValue = trim((string) ($fields[$key . '_name'] ?? ($isImage ? '' : $value)));
            $html = '';
            if ($isImage) {
                $html .= '<div class="coa-v1-sig-print-wrap"><img src="' . coaTemplateEscape($value) . '" class="coa-v1-sig-print-img" alt="Signature"></div>';
            }
            if ($nameValue !== '') {
                $html .= '<div class="coa-v1-sig-print-name" style="text-align:center;font-weight:bold;margin-top:2px;">' . coaTemplateEscape($nameValue) . '</div>';
            }
            if ($html === '') {
                $html = '&nbsp;';
            }
            return '<span class="coa-v1-print-value">' . $html . '</span>';
        }
        if ($isImage) {
            return '<div class="coa-v1-sig-print-wrap"><img src="' . coaTemplateEscape($value) . '" class="coa-v1-sig-print-img" alt="Signature"></div>';
        }
        return '<span class="coa-v1-print-value">'
            . ($value !== '' ? nl2br(coaTemplateEscape($value)) : '&nbsp;')
            . '</span>';
    }

    if (coaTemplateIsSignatureKey($key)) {
        $nameValue = trim((string) ($fields[$key . '_name'] ?? ($isImage ? '' : $value)));
        $imgStyle = $isImage ? '' : 'display:none;';
        $previewImgTag = $isImage ? '<img src="' . coaTemplateEscape($value) . '" class="coa-v1-sig-preview-img" alt="Signature">' : '';
        return '<div class="coa-v1-sig-widget">'
            . '<input type="hidden" class="coa-v1-sig-value" data-coa-field="' . coaTemplateEscape($key) . '" value="' . coaTemplateEscape($value) . '">'
            . '<div class="coa-v1-sig-preview" style="' . $imgStyle . '">'
            . $previewImgTag
            . '<button type="button" class="coa-v1-sig-clear-btn" title="Remove signature">&times;</button>'
            . '</div>'
            . '<div class="coa-v1-sig-input-group">'
            . '<input type="text" class="coa-v1-field coa-v1-sig-text" data-coa-field="' . coaTemplateEscape($key . '_name') . '"'
            . ' value="' . coaTemplateEscape($nameValue) . '"'
            . ' placeholder="' . coaTemplateEscape($placeholder ?: 'Name') . '" autocomplete="off">'
            . '<label class="coa-v1-sig-upload-btn" title="Upload signed image (max 250 KB)">'
            . '<i class="ti ti-upload"></i>'
            . '<input type="file" class="coa-v1-sig-file-input" accept="image/png,image/jpeg,image/jpg,image/webp" style="display:none;">'
            . '</label>'
            . '</div>'
            . '</div>';
    }

    if (coaTemplateIsDateKey($key)) {
        $dateValue = coaTemplateFormatDateForInput($value);
        return '<input type="date" class="coa-v1-field coa-v1-date-field"'
            . ' data-coa-field="' . coaTemplateEscape($key) . '"'
            . ' data-coa-required="1"'
            . ' value="' . coaTemplateEscape($dateValue) . '" autocomplete="off">';
    }

    return '<input type="text" class="coa-v1-field"'
        . ' data-coa-field="' . coaTemplateEscape($key) . '"'
        . ' data-coa-required="1"'
        . ' value="' . coaTemplateEscape($value) . '"'
        . ' placeholder="' . coaTemplateEscape($placeholder) . '" autocomplete="off">';
}

function coaTemplateTextarea(
    string $key,
    array $fields,
    bool $editable,
    string $placeholder = ''
): string {
    $value = trim((string) ($fields[$key] ?? ''));
    if (!$editable) {
        return '<span class="coa-v1-print-value coa-v1-multiline">'
            . ($value !== '' ? nl2br(coaTemplateEscape($value)) : '&nbsp;')
            . '</span>';
    }

    return '<textarea class="coa-v1-field coa-v1-textarea"'
        . ' data-coa-field="' . coaTemplateEscape($key) . '"'
        . ' placeholder="' . coaTemplateEscape($placeholder) . '">'
        . coaTemplateEscape($value)
        . '</textarea>';
}

function coaTemplateSource(string $key, array $sourceValues): string
{
    $value = trim((string) ($sourceValues[$key] ?? ''));
    return '<span class="coa-v1-source" data-coa-source="' . coaTemplateEscape($key) . '">'
        . ($value !== '' ? coaTemplateEscape($value) : '&nbsp;')
        . '</span>';
}

function coaTemplateStyles(): string
{
    return <<<'CSS'
<style>
    .coa-v1-document {
        width: 210mm;
        margin: 0 auto;
        color: #111;
        background: #fff;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 8.2pt;
        line-height: 1.12;
    }
    .coa-v1-document,
    .coa-v1-document * {
        box-sizing: border-box;
    }
    .coa-v1-page {
        position: relative;
        width: 210mm;
        padding: 0;
        overflow: hidden;
        background: #fff;
    }
    .coa-v1-page-body {
        padding: 8mm 9mm 2mm;
    }
    .coa-v1-page + .coa-v1-page {
        page-break-before: always;
        break-before: page;
    }
    .coa-v1-document table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }
    .coa-v1-document th,
    .coa-v1-document td {
        border: .25mm solid #111827;
        padding: .78mm .95mm;
        vertical-align: middle;
        overflow-wrap: anywhere;
    }
    .coa-v1-header {
        margin-bottom: 2.2mm;
    }
    .coa-v1-header > tbody > tr > td {
        padding: 0;
    }
    .coa-v1-brand-cell {
        width: 34%;
    }
    .coa-v1-title-cell {
        width: 31%;
        padding: 2mm !important;
        text-align: center;
        font-size: 10pt;
        font-weight: 800;
    }
    .coa-v1-control-cell {
        width: 35%;
    }
    .coa-v1-brand {
        min-height: 24mm;
        padding: 1.4mm 1.8mm;
    }
    .coa-v1-brand-logo {
        display: block;
        width: 36mm;
        height: 10mm;
        object-fit: contain;
        object-position: left center;
    }
    .coa-v1-brand-fallback {
        color: #0f6b34;
        font-size: 11pt;
        font-weight: 900;
    }
    .coa-v1-address {
        margin-top: .8mm;
        font-size: 6.4pt;
        line-height: 1.18;
    }
    .coa-v1-control td {
        padding: .48mm .65mm;
        border-top: 0;
        border-right: 0;
        font-size: 6.8pt;
    }
    .coa-v1-control tr:first-child td {
        border-top: 0;
    }
    .coa-v1-control td:first-child {
        width: 48%;
        border-left: 0;
        font-weight: 700;
    }
    .coa-v1-metadata {
        margin-bottom: 2mm;
    }
    .coa-v1-metadata td {
        height: 5.1mm;
    }
    .coa-v1-metadata td:first-child {
        width: 36%;
        font-weight: 700;
    }
    .coa-v1-results th {
        padding: 1mm;
        background: #f1f5f9;
        text-align: center;
        font-weight: 800;
    }
    .coa-v1-results .coa-v1-serial {
        width: 8%;
        text-align: center;
    }
    .coa-v1-results .coa-v1-test {
        width: 31%;
    }
    .coa-v1-results .coa-v1-result {
        width: 22%;
    }
    .coa-v1-results .coa-v1-specification {
        width: 39%;
    }
    .coa-v1-results td {
        min-height: 5mm;
    }
    .coa-v1-section-row td {
        height: 5mm;
        background: #f8fafc;
        font-weight: 800;
    }
    .coa-v1-field {
        display: block;
        width: 100%;
        min-height: 4.2mm;
        margin: 0;
        border: .2mm dashed #d3a400;
        border-radius: .6mm;
        outline: none;
        background: #fffbea;
        color: #111;
        font: inherit;
        line-height: 1.12;
        padding: .4mm .65mm;
    }
    .coa-v1-field:focus {
        border-color: #166534;
        box-shadow: 0 0 0 .4mm rgba(22, 101, 52, .14);
    }
    .coa-v1-field.coa-v1-invalid {
        border-color: #dc2626;
        background: #fff1f2;
    }
    .coa-v1-textarea {
        min-height: 9mm;
        resize: vertical;
    }
    .coa-v1-source,
    .coa-v1-print-value {
        display: block;
        min-height: 4mm;
        white-space: pre-wrap;
    }
    .coa-v1-multiline {
        min-height: 8mm;
    }
    .coa-v1-approval {
        margin-top: 2mm;
    }
    .coa-v1-approval td {
        height: 7.5mm;
    }
    .coa-v1-decision {
        width: 26%;
    }
    .coa-v1-comments {
        width: 38%;
    }
    .coa-v1-signature-label {
        width: 22%;
        font-weight: 700;
    }
    .coa-v1-signature-value {
        width: 14%;
    }
    .coa-v1-radio-wrap {
        display: inline-flex;
        align-items: center;
        gap: 1.2mm;
        margin-right: 3mm;
        font-weight: 700;
    }
    .coa-v1-radio-wrap input {
        accent-color: #166534;
    }
    .coa-v1-footer {
        margin: 3mm 9mm 4mm;
        font-size: 6.5pt;
        white-space: nowrap;
    }
    .coa-v1-footer span {
        display: inline-block;
        width: 38%;
    }
    .coa-v1-footer span:nth-child(2) {
        width: 42%;
    }
    .coa-v1-footer span:last-child {
        width: 19%;
        text-align: right;
    }
    .coa-v1-sig-widget {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 1mm;
        width: 100%;
        min-height: 4.6mm;
    }
    .coa-v1-sig-input-group {
        display: flex;
        width: 100%;
        align-items: center;
        gap: 1mm;
    }
    .coa-v1-sig-text {
        flex: 1 1 auto;
        min-width: 0;
    }
    .coa-v1-sig-upload-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: .5mm;
        padding: .35mm 1mm;
        font-size: 6.5pt;
        font-weight: 700;
        color: #166534;
        background: #f0fdf4;
        border: .2mm solid #86efac;
        border-radius: .6mm;
        cursor: pointer;
        white-space: nowrap;
        user-select: none;
        flex-shrink: 0;
        line-height: 1.1;
    }
    .coa-v1-sig-upload-btn:hover {
        background: #dcfce7;
        border-color: #4ade80;
    }
    .coa-v1-sig-preview {
        display: inline-flex;
        align-items: center;
        gap: 1mm;
        max-width: 100%;
        padding: .25mm .5mm;
        background: #fff;
        border: .2mm solid #cbd5e1;
        border-radius: .6mm;
    }
    .coa-v1-sig-preview-img {
        max-height: 7.5mm;
        max-width: 28mm;
        object-fit: contain;
        display: block;
    }
    .coa-v1-sig-clear-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 3.5mm;
        height: 3.5mm;
        padding: 0;
        font-size: 7pt;
        font-weight: bold;
        line-height: 1;
        color: #ef4444;
        background: #fee2e2;
        border: none;
        border-radius: 50%;
        cursor: pointer;
    }
    .coa-v1-sig-clear-btn:hover {
        background: #fecaca;
    }
    .coa-v1-sig-print-wrap {
        display: block;
        text-align: center;
        vertical-align: middle;
        max-width: 100%;
    }
    .coa-v1-sig-print-img {
        max-height: 10mm;
        max-width: 34mm;
        object-fit: contain;
        display: block;
        margin: 0 auto;
    }
    .coa-v1-date-field {
        font-size: 7.4pt;
        padding: .3mm .5mm;
        min-height: 4.2mm;
    }
    .coa-v1-source-note {
        margin-top: 1.2mm;
        color: #64748b;
        font-size: 6pt;
    }
    @media screen {
        .coa-v1-page {
            min-height: 296mm;
            margin-bottom: 18px;
            box-shadow: 0 10px 30px rgba(15, 23, 42, .14);
        }
        .coa-v1-page-body {
            padding-bottom: 17mm;
        }
        .coa-v1-footer {
            position: absolute;
            right: 9mm;
            bottom: 4mm;
            left: 9mm;
            margin: 0;
        }
    }
    @media print {
        .coa-v1-page {
            margin: 0;
            box-shadow: none;
        }
        .coa-v1-field {
            border-color: transparent;
            background: transparent;
        }
        .coa-v1-source-note {
            display: none;
        }
    }
</style>
CSS;
}

function coaTemplateHeader(array $document, string $logoDataUri): string
{
    $logo = $logoDataUri !== ''
        ? '<img class="coa-v1-brand-logo" src="' . coaTemplateEscape($logoDataUri) . '" alt="Biogenix">'
        : '<span class="coa-v1-brand-fallback">BIOGENIX</span>';

    return '<table class="coa-v1-header"><tr>'
        . '<td class="coa-v1-brand-cell"><div class="coa-v1-brand">' . $logo
        . '<div class="coa-v1-address">'
        . coaTemplateEscape($document['company_address'] ?? '')
        . '</div></div></td>'
        . '<td class="coa-v1-title-cell">TITLE: CERTIFICATE OF ANALYSIS</td>'
        . '<td class="coa-v1-control-cell"><table class="coa-v1-control">'
        . '<tr><td>Document No.</td><td>' . coaTemplateEscape($document['document_no'] ?? '') . '</td></tr>'
        . '<tr><td>Issue No.</td><td>' . coaTemplateEscape($document['issue_no'] ?? '') . '</td></tr>'
        . '<tr><td>Revision No.</td><td>' . coaTemplateEscape($document['revision_no'] ?? '') . '</td></tr>'
        . '<tr><td>Effective Date</td><td>' . coaTemplateEscape($document['effective_date'] ?? '') . '</td></tr>'
        . '<tr><td>Review Date</td><td>' . coaTemplateEscape($document['review_date'] ?? '') . '</td></tr>'
        . '<tr><td>Department</td><td>' . coaTemplateEscape($document['department'] ?? '') . '</td></tr>'
        . '<tr><td>Supersedes</td><td>' . coaTemplateEscape($document['supersedes'] ?? '') . '</td></tr>'
        . '</table></td></tr></table>';
}

function coaTemplateMetadata(
    array $profile,
    array $fields,
    array $sourceValues,
    bool $editable
): string {
    $metadataRowCount = (int) ($profile['metadata_row_count'] ?? 10);
    $productName = ['Product Name', '<span class="coa-v1-source">'
        . coaTemplateEscape($profile['product_name'] ?? '') . '</span>'];
    $brandName = ['Brand Name', '<span class="coa-v1-source">'
        . coaTemplateEscape($profile['brand_name'] ?? 'Biogenix') . '</span>'];
    $productCode = ['Product Code', '<span class="coa-v1-source">'
        . coaTemplateEscape($profile['product_code'] ?? '') . '</span>'];
    $batchNumber = ['Batch/Lot No.', coaTemplateSource('batch_number', $sourceValues)];
    $manufacturingDate = [
        'Mfg. Date',
        coaTemplateInput('metadata.manufacturing_date', $fields, $editable, 'Enter manufacturing date'),
    ];
    $expiryDate = [
        'Exp. Date',
        coaTemplateInput('metadata.expiry_date', $fields, $editable, 'Enter expiry date'),
    ];
    $coaNumber = ['COA/AR No.', coaTemplateSource('coa_number', $sourceValues)];
    $testingDate = ['Testing Date', coaTemplateSource('testing_date', $sourceValues)];
    $batchSize = ['Lot Size/ Batch size', coaTemplateSource('batch_size', $sourceValues)];
    $stpReference = [
        'Reference specification no./STP no.',
        '<span class="coa-v1-source">' . coaTemplateEscape($profile['stp_reference'] ?? '') . '</span>',
    ];

    if ($metadataRowCount >= 10) {
        $rows = [
            $productName,
            $brandName,
            $productCode,
            $batchNumber,
            $manufacturingDate,
            $expiryDate,
        ];
        $rows[] = ['COA/AR No.', coaTemplateSource('coa_number', $sourceValues)];
        $rows[] = ['Testing Date', coaTemplateSource('testing_date', $sourceValues)];
        $rows[] = ['Lot Size/ Batch size', coaTemplateSource('batch_size', $sourceValues)];
        $rows[] = $stpReference;
    } elseif ($metadataRowCount === 9) {
        $rows = [
            $productName,
            $brandName,
            $batchNumber,
            $manufacturingDate,
            $expiryDate,
            $coaNumber,
            $testingDate,
            $batchSize,
            $stpReference,
        ];
    } else {
        $rows = [
            $productName,
            $batchNumber,
            $manufacturingDate,
            $expiryDate,
            $coaNumber,
            $testingDate,
            $batchSize,
            $stpReference,
        ];
    }

    $html = '<table class="coa-v1-metadata"><tbody>';
    foreach ($rows as [$label, $value]) {
        $html .= '<tr><td>' . coaTemplateEscape($label) . '</td><td>' . $value . '</td></tr>';
    }
    return $html . '</tbody></table>';
}

function coaTemplateResults(array $rows, array $fields, bool $editable): string
{
    $html = '<table class="coa-v1-results"><thead><tr>'
        . '<th class="coa-v1-serial">S. No.</th>'
        . '<th class="coa-v1-test">Test</th>'
        . '<th class="coa-v1-result">Result</th>'
        . '<th class="coa-v1-specification">Specifications</th>'
        . '</tr></thead><tbody>';

    foreach ($rows as $row) {
        if (($row['kind'] ?? 'test') === 'section') {
            $html .= '<tr class="coa-v1-section-row"><td>'
                . coaTemplateEscape($row['serial'] ?? '')
                . '</td><td colspan="3">'
                . coaTemplateEscape($row['test'] ?? '')
                . '</td></tr>';
            continue;
        }

        $key = trim((string) ($row['key'] ?? ''));
        $html .= '<tr><td class="coa-v1-serial">' . coaTemplateEscape($row['serial'] ?? '') . '</td>'
            . '<td>' . coaTemplateEscape($row['test'] ?? '') . '</td>'
            . '<td>' . coaTemplateInput('results.' . $key, $fields, $editable, 'Enter result') . '</td>'
            . '<td>' . coaTemplateEscape($row['specification'] ?? '') . '</td></tr>';
    }

    return $html . '</tbody></table>';
}

function coaTemplateApproval(array $fields, bool $editable): string
{
    $decision = strtoupper(trim((string) ($fields['approval.decision'] ?? '')));
    if (!$editable) {
        $approved = $decision === 'APPROVED' ? '☑' : '☐';
        $rejected = $decision === 'REJECTED' ? '☑' : '☐';
        $decisionHtml = $approved . ' Approved&nbsp;&nbsp;&nbsp;' . $rejected . ' Rejected';
    } else {
        $decisionHtml = '<label class="coa-v1-radio-wrap"><input type="radio"'
            . ' name="coa_template_decision" data-coa-field="approval.decision" value="APPROVED"'
            . ($decision === 'APPROVED' ? ' checked' : '') . '> Approved</label>'
            . '<label class="coa-v1-radio-wrap"><input type="radio"'
            . ' name="coa_template_decision" data-coa-field="approval.decision" value="REJECTED"'
            . ($decision === 'REJECTED' ? ' checked' : '') . '> Rejected</label>';
    }

    return '<table class="coa-v1-approval"><tbody>'
        . '<tr><td class="coa-v1-decision" rowspan="2">' . $decisionHtml . '</td>'
        . '<td class="coa-v1-comments" rowspan="2"><strong>Comments/Instructions:</strong>'
        . coaTemplateTextarea('approval.comments', $fields, $editable, 'Enter comments or instructions')
        . '</td><td class="coa-v1-signature-label">Analysis By</td>'
        . '<td class="coa-v1-signature-value">'
        . coaTemplateInput('approval.analysis_by', $fields, $editable, 'Name')
        . '</td></tr>'
        . '<tr><td class="coa-v1-signature-label">Verified and Approved By</td>'
        . '<td class="coa-v1-signature-value">'
        . coaTemplateInput('approval.verified_by', $fields, $editable, 'Name')
        . '</td></tr></tbody></table>';
}

function coaTemplateFooter(int $pageNumber, int $pageCount): string
{
    return '<div class="coa-v1-footer">'
        . '<span>Format Prepared by : MR/QA</span>'
        . '<span>Format Approved by: Head of the organisation</span>'
        . '<span>Page No.: ' . $pageNumber . ' of ' . $pageCount . '</span>'
        . '</div>';
}

function coaTemplateRenderBiochemistry(array $form, bool $editable = false): string
{
    $layout = is_array($form['layout'] ?? null) ? $form['layout'] : [];
    $profile = is_array($form['profile'] ?? null) ? $form['profile'] : [];
    if (
        (int) ($layout['schema_version'] ?? 0) < 1
        || (string) ($layout['renderer'] ?? '') !== 'structured_coa_html'
        || $profile === []
    ) {
        return '';
    }

    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    $fields = coaTemplateFields($form);
    $sourceValues = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $rows = is_array($profile['rows'] ?? null) ? $profile['rows'] : [];
    $pageCount = max(1, (int) ($profile['page_count'] ?? 1));
    $logoDataUri = trim((string) ($form['branding_logo_data_uri'] ?? ''));

    $chunks = [$rows];
    if ($pageCount > 1) {
        $splitAt = null;
        foreach ($rows as $index => $row) {
            if (($row['key'] ?? '') === 'controls') {
                $splitAt = $index;
                break;
            }
        }
        if ($splitAt !== null && $splitAt > 0) {
            $chunks = [array_slice($rows, 0, $splitAt), array_slice($rows, $splitAt)];
        }
    }
    $pageCount = count($chunks);

    $pages = [];
    foreach ($chunks as $index => $pageRows) {
        $pageNumber = $index + 1;
        $body = coaTemplateHeader($document, $logoDataUri);
        if ($pageNumber === 1) {
            $body .= coaTemplateMetadata($profile, $fields, $sourceValues, $editable);
        }
        $body .= coaTemplateResults($pageRows, $fields, $editable);
        if ($pageNumber === $pageCount) {
            $body .= coaTemplateApproval($fields, $editable);
        }
        if ($editable && $pageNumber === 1) {
            $body .= '<div class="coa-v1-source-note">Controlled source: '
                . coaTemplateEscape($profile['source_document'] ?? '')
                . '</div>';
        }
        $pages[] = '<section class="coa-v1-page" data-page="' . $pageNumber . '">'
            . '<div class="coa-v1-page-body">' . $body . '</div>'
            . coaTemplateFooter($pageNumber, $pageCount)
            . '</section>';
    }

    return coaTemplateStyles()
        . '<div class="coa-v1-document" data-coa-template="1" data-coa-type="'
        . coaTemplateEscape($form['coa_type'] ?? '')
        . '">' . implode('', $pages) . '</div>';
}

function coaTemplateRender(array $form, bool $editable = false): string
{
    $layout = is_array($form['layout'] ?? null) ? $form['layout'] : [];
    $variant = (string) ($layout['renderer_variant'] ?? '');

    if ($variant === 'urine_strip') {
        require_once __DIR__ . '/urine_strip/renderer.php';
        return coaTemplateRenderUrineStrip($form, $editable);
    }
    if ($variant === 'rapid_test') {
        require_once __DIR__ . '/rapid_test/renderer.php';
        return coaTemplateRenderRapidTest($form, $editable);
    }
    if ($variant === 'serology') {
        require_once __DIR__ . '/serology/renderer.php';
        return coaTemplateRenderSerology($form, $editable);
    }

    return coaTemplateRenderBiochemistry($form, $editable);
}
