<?php

declare(strict_types=1);

function coaTemplateRenderUrineSections(array $sections, array $fields, bool $editable): string
{
    $html = '';
    foreach ($sections as $section) {
        $title = coaTemplateEscape($section['title'] ?? '');
        if (($section['kind'] ?? '') === 'rows') {
            $html .= '<table class="coa-v1-results coa-urine-table"><thead><tr>'
                . '<th class="coa-v1-serial">S. No.</th><th>Test</th><th>Specification</th>'
                . '<th>Result</th></tr></thead><tbody>';
            foreach (($section['rows'] ?? []) as $row) {
                $html .= '<tr><td class="coa-v1-serial">'
                    . coaTemplateEscape($row['serial'] ?? '') . '</td><td>'
                    . coaTemplateEscape($row['test'] ?? '') . '</td><td>'
                    . coaTemplateEscape($row['specification'] ?? '') . '</td><td>'
                    . coaTemplateInput(
                        'results.' . (string) ($row['key'] ?? ''),
                        $fields,
                        $editable,
                        'Enter result'
                    ) . '</td></tr>';
            }
            $html .= '</tbody></table>';
            continue;
        }

        $analytes = is_array($section['analytes'] ?? null) ? $section['analytes'] : [];
        $html .= '<table class="coa-v1-results coa-urine-matrix"><thead>'
            . '<tr class="coa-v1-section-row"><th colspan="'
            . (1 + (count($analytes) * 2)) . '">' . $title . '</th></tr><tr>'
            . '<th rowspan="2">Level</th>';
        foreach ($analytes as $analyte) {
            $html .= '<th colspan="2">' . coaTemplateEscape($analyte) . '</th>';
        }
        $html .= '</tr><tr>';
        foreach ($analytes as $_) {
            $html .= '<th>Specification</th><th>Result</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach (($section['rows'] ?? []) as $row) {
            $html .= '<tr><td>' . coaTemplateEscape($row['level'] ?? '') . '</td>';
            foreach (($row['cells'] ?? []) as $cell) {
                $specification = (string) ($cell['specification'] ?? '');
                $html .= '<td>' . coaTemplateEscape($specification) . '</td><td>';
                if ($specification !== '') {
                    $html .= coaTemplateInput(
                        'results.' . (string) ($cell['key'] ?? ''),
                        $fields,
                        $editable,
                        'Result'
                    );
                } else {
                    $html .= '&nbsp;';
                }
                $html .= '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
    }
    return $html;
}

function coaTemplateRenderUrineStrip(array $form, bool $editable = false): string
{
    $layout = is_array($form['layout'] ?? null) ? $form['layout'] : [];
    $profile = is_array($form['profile'] ?? null) ? $form['profile'] : [];
    if ($profile === []) {
        return '';
    }
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    if (is_array($profile['document'] ?? null)) {
        $document = array_replace($document, $profile['document']);
    }
    $fields = coaTemplateFields($form);
    $sourceValues = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $logoDataUri = trim((string) ($form['branding_logo_data_uri'] ?? ''));
    $sections = is_array($profile['sections'] ?? null) ? $profile['sections'] : [];

    $first = array_slice($sections, 0, 1);
    $remaining = array_slice($sections, 1);
    if ($remaining === []) {
        $first = $sections;
    }
    $chunks = $remaining === [] ? [$first] : [$first, $remaining];
    $pageCount = count($chunks);
    $pages = [];
    foreach ($chunks as $index => $chunk) {
        $pageNumber = $index + 1;
        $body = coaTemplateHeader($document, $logoDataUri);
        if ($pageNumber === 1) {
            $body .= coaTemplateMetadata($profile, $fields, $sourceValues, $editable);
        }
        $body .= coaTemplateRenderUrineSections($chunk, $fields, $editable);
        if ($pageNumber === $pageCount) {
            $body .= '<div class="coa-urine-conclusion"><strong>Conclusion:</strong> '
                . coaTemplateEscape($profile['conclusion'] ?? '') . '</div>'
                . coaTemplateApproval($fields, $editable);
        }
        if ($editable && $pageNumber === 1) {
            $body .= '<div class="coa-v1-source-note">Controlled source: '
                . coaTemplateEscape($profile['source_document'] ?? '') . '</div>';
        }
        $pages[] = '<section class="coa-v1-page" data-page="' . $pageNumber . '">'
            . '<div class="coa-v1-page-body">' . $body . '</div>'
            . coaTemplateFooter($pageNumber, $pageCount) . '</section>';
    }

    $extraStyles = '<style>'
        . '.coa-urine-table,.coa-urine-matrix{margin-bottom:2mm}'
        . '.coa-urine-matrix{font-size:7pt}'
        . '.coa-urine-matrix th{text-align:center;background:#f1f5f9}'
        . '.coa-urine-matrix td{padding:.55mm .65mm}'
        . '.coa-urine-conclusion{margin-top:2mm;border:.25mm solid #111827;padding:1.4mm}'
        . '</style>';
    return coaTemplateStyles() . $extraStyles
        . '<div class="coa-v1-document" data-coa-template="1" data-coa-type="'
        . coaTemplateEscape($form['coa_type'] ?? '') . '">'
        . implode('', $pages) . '</div>';
}
