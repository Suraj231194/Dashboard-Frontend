<?php

declare(strict_types=1);

/**
 * Controlled Urine Strip COA profiles transcribed from /URINE STRIP.
 * Historical batch results are intentionally excluded; every result cell is
 * completed by QC when the COA is generated.
 */

function coaUrineResultRow(string $key, string $test, string $specification, string $serial = ''): array
{
    return [
        'key' => $key,
        'serial' => $serial,
        'test' => $test,
        'specification' => $specification,
    ];
}

function coaUrineMatrix(
    string $title,
    array $analytes,
    array $levels
): array {
    $rows = [];
    foreach ($levels as $levelIndex => $level) {
        $cells = [];
        foreach ($analytes as $analyteIndex => $analyte) {
            $cells[] = [
                'key' => 'matrix_' . preg_replace('/[^a-z0-9]+/', '_', strtolower($title))
                    . '_' . ($levelIndex + 1) . '_' . ($analyteIndex + 1),
                'specification' => (string) ($level[$analyteIndex] ?? ''),
            ];
        }
        $rows[] = [
            'level' => 'Level ' . ($levelIndex + 1),
            'cells' => $cells,
        ];
    }
    return [
        'kind' => 'matrix',
        'title' => $title,
        'analytes' => array_values($analytes),
        'rows' => $rows,
    ];
}

function coaUrineEditableFieldKeys(array $sections): array
{
    $keys = [];
    foreach ($sections as $section) {
        if (($section['kind'] ?? '') === 'rows') {
            foreach (($section['rows'] ?? []) as $row) {
                $keys[] = 'results.' . (string) $row['key'];
            }
            continue;
        }
        foreach (($section['rows'] ?? []) as $row) {
            foreach (($row['cells'] ?? []) as $cell) {
                if ((string) ($cell['specification'] ?? '') !== '') {
                    $keys[] = 'results.' . (string) $cell['key'];
                }
            }
        }
    }
    return $keys;
}

function coaUrineProfile(
    array $productIds,
    string $productName,
    string $productCode,
    string $stpReference,
    string $sourceDocument,
    array $sections,
    int $metadataRowCount = 10
): array {
    return [
        'product_ids' => array_values(array_map('intval', $productIds)),
        'source_document' => $sourceDocument,
        'source_ip_document' => $sourceDocument,
        'source_fg_document' => $sourceDocument,
        'product_name' => $productName,
        'brand_name' => 'Biogenix',
        'product_code' => $productCode,
        'stp_reference' => $stpReference,
        'metadata_row_count' => $metadataRowCount,
        'page_count' => 2,
        'conclusion' => 'The Above product complies with the standard specification and hence It is released.',
        'sections' => $sections,
        'editable_field_keys' => coaUrineEditableFieldKeys($sections),
    ];
}

function coaUrineStripProfiles(): array
{
    $colourChart = 'For appearance and color sequence refer to the color chart provided With the kit.';
    $profiles = [];

    $twoPSections = [
        [
            'kind' => 'rows',
            'title' => 'Physical and performance checks',
            'rows' => [
                coaUrineResultRow('appearance_glucose_pad', 'Appearance glucose pad', 'Clear Blue color pad', '1.'),
                coaUrineResultRow('appearance_protein_pad', 'Appearance protein pad', 'Clear Yellow color pad', '2.'),
                coaUrineResultRow('glucose_negative', 'Glucose - Level: negative', 'Negative', '3.'),
                coaUrineResultRow('protein_negative', 'Protein - Level: negative', 'Negative', ''),
                coaUrineResultRow('glucose_trace', 'Glucose - Level: Trace', 'Trace', '4.'),
                coaUrineResultRow('protein_trace', 'Protein - Level: Trace', 'Trace', ''),
                coaUrineResultRow('glucose_1_plus', 'Glucose - Level: 1+', '1+', '5.'),
                coaUrineResultRow('protein_1_plus', 'Protein - Level: 1+', '1+', ''),
                coaUrineResultRow('glucose_2_plus', 'Glucose - Level: 2+', '2+', '6.'),
                coaUrineResultRow('protein_2_plus', 'Protein - Level: 2+', '2+', ''),
                coaUrineResultRow('glucose_3_plus', 'Glucose - Level: 3+', '3+', '7.'),
                coaUrineResultRow('protein_3_plus', 'Protein - Level: 3+', '3+', ''),
                coaUrineResultRow('glucose_4_plus', 'Glucose - Level: 4+', '4+', '8.'),
                coaUrineResultRow('protein_4_plus', 'Protein - Level: 4+', '4+', ''),
            ],
        ],
    ];
    $profiles['urine_2p'] = coaUrineProfile(
        [1048],
        'Urine Strips 2P Rapid Test',
        'BGRURI2P',
        'BIPL-FPSTP-012',
        'BIPL-COA-FG-25011R URI2P0125.doc',
        $twoPSections
    );

    $fourPSections = [
        [
            'kind' => 'rows',
            'title' => 'Physical checks',
            'rows' => [
                coaUrineResultRow(
                    'appearance',
                    'Appearance of Protein, Glucose, pH. Specific Gravity',
                    $colourChart,
                    '1.'
                ),
            ],
        ],
        coaUrineMatrix(
            'Performance of reagent strip',
            ['Specific Gravity', 'Glucose', 'Protein'],
            [
                ['1.000', 'Negative', 'Negative'],
                ['1.005', 'Trace(+)', 'Trace'],
                ['1.010', '+ (250)', '+ (30)'],
                ['1.015', '++(500)', '++(100)'],
                ['1.020', '+++(1000)', '+++(300)'],
                ['1.025', '++++(2000)', ''],
                ['1.030', '', ''],
            ]
        ),
        coaUrineMatrix('pH performance', ['pH'], [['5.0'], ['6.0'], ['7.0'], ['8.0'], ['9.0']]),
    ];
    $profiles['urine_4p'] = coaUrineProfile(
        [1047],
        'Urine Strips 4P Rapid Test',
        'BGRURI4P',
        'BIPL-FPSTP-013A',
        'URI4P0624.doc',
        $fourPSections
    );

    $tenPSections = [
        [
            'kind' => 'rows',
            'title' => 'Physical checks',
            'rows' => [
                coaUrineResultRow(
                    'appearance',
                    'Appearance of Urobilinogen, Bilirubin, Ketone, Blood, Protein, Nitrite, Leukocytes, Glucose, SG, pH.',
                    $colourChart,
                    '1.'
                ),
            ],
        ],
        coaUrineMatrix('Urobilinogen and Bilirubin', ['Urobilinogen', 'Bilirubin'], [
            ['Normal', 'Negative'], ['1', '+(1)'], ['4', '++(4)'], ['8', '+++(10)'], ['12', ''],
        ]),
        coaUrineMatrix('Ketone Blood and Protein', ['Ketone', 'Blood', 'Protein'], [
            ['Negative', 'Negative', 'Negative'],
            ['±(5)', 'Trace (10)', 'Trace'],
            ['+(15)', 'Small(25)', '+ (30)'],
            ['++(40)', 'Moderate (80)', '++(100)'],
            ['+++(80)', 'Large(200)', '+++(300)'],
        ]),
        coaUrineMatrix('Nitrite Leukocytes and Glucose', ['Nitrite', 'Leukocytes', 'Glucose'], [
            ['Negative', 'Negative', 'Negative'],
            ['Positive', '(15)', 'Trace(+)'],
            ['', '(70)', '+ (250)'],
            ['', '(125)', '++(500)'],
            ['', '(500)', '+++(1000)'],
            ['', '', '++++(2000)'],
        ]),
        coaUrineMatrix('Specific Gravity and pH', ['Specific Gravity', 'pH'], [
            ['1.000', '5.0'], ['1.005', '6.0'], ['1.010', '7.0'], ['1.015', '8.0'],
            ['1.020', '9.0'], ['1.025', ''], ['1.030', ''],
        ]),
    ];
    $profiles['urine_10p'] = coaUrineProfile(
        [1052],
        'Urine Strips 10P Rapid Test',
        'BGRURI10P',
        'BIPL-FPSTP-014',
        'BIPL-COA-FG-24310R URI10P0924.doc',
        $tenPSections
    );
    $profiles['urine_10p']['source_ip_document'] = 'BIPL-COA-IP-24310R URI10P0924.doc';

    $elevenPSections = [
        [
            'kind' => 'rows',
            'title' => 'Physical checks',
            'rows' => [
                coaUrineResultRow(
                    'appearance',
                    'Appearance of Ascorbic Acid, Urobilinogen, Bilirubin, Ketone, Blood, Protein, Nitrite, Leukocytes, Glucose, Specific Gravity, pH.',
                    $colourChart,
                    '1.'
                ),
            ],
        ],
        coaUrineMatrix('Leukocytes Nitrite and Urobilinogen', ['Leukocytes', 'Nitrite', 'Urobilinogen'], [
            ['Negative', 'Negative', 'Normal'],
            ['(15)', 'Positive', '1'],
            ['(70)', '', '4'],
            ['(125)', '', '8'],
            ['(500)', '', '12'],
        ]),
        coaUrineMatrix('Protein pH and Blood', ['Protein', 'pH', 'Blood'], [
            ['Negative', '5.0', 'Negative'],
            ['Trace', '6.0', 'Trace (10)'],
            ['+ (30)', '7.0', 'Trace'],
            ['++(100)', '8.0', 'Small(25)'],
            ['+++(300)', '9.0', 'Moderate (80)'],
            ['', '', 'Large(200)'],
        ]),
        coaUrineMatrix('Specific Gravity Ascorbic Acid and Ketone', ['Specific Gravity', 'Ascorbic Acid', 'Ketone'], [
            ['1.000', 'Negative', 'Negative'],
            ['1.005', 'Trace ±0.6', '± 5'],
            ['1.010', '+ (1.4)', '+ (15)'],
            ['1.015', '++(2.8)', '++(40)'],
            ['1.020', '+++(5.6)', '+++(80)'],
            ['1.025', '', ''],
            ['1.030', '', ''],
        ]),
        coaUrineMatrix('Bilirubin and Glucose', ['Bilirubin', 'Glucose'], [
            ['Negative', 'Negative'],
            ['+ (1)', 'Trace(±)'],
            ['++(4)', '+ (250)'],
            ['+++(10)', '++(500)'],
            ['', '+++(1000)'],
            ['', '++++(2000)'],
        ]),
    ];
    $profiles['urine_11p'] = coaUrineProfile(
        [1051],
        'Urine 11 Parameter (Ascorbic Acid, Urobilinogen, Bilirubin, Ketone, Blood, Protein, Nitrite, Leukocytes, Glucose, Specific Gravity, pH)',
        '',
        'BIPL-FPSTP-158',
        'BIPL-COA-FG-25154R URI11P0325.doc',
        $elevenPSections,
        9
    );

    return $profiles;
}

function coaUrineStripMappedProductIds(): array
{
    $ids = [];
    foreach (coaUrineStripProfiles() as $profile) {
        array_push($ids, ...($profile['product_ids'] ?? []));
    }
    $ids = array_values(array_unique(array_map('intval', $ids)));
    sort($ids);
    return $ids;
}
