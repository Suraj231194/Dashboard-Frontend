<?php

declare(strict_types=1);

function coaTemplateSerologyMetadata(
    array $profile,
    array $fields,
    array $sourceValues,
    bool $editable
): string {
    $rows = [
        ['Item Description', coaTemplateEscape($profile['item_description'] ?? '')],
        ['Manufacturer/Supplier', coaTemplateEscape($profile['manufacturer_supplier'] ?? '')],
        ['COA/AR No.', coaTemplateSource('coa_number', $sourceValues)],
        ['Item Code No.', coaTemplateEscape($profile['item_code'] ?? '')],
        ['G. R. No.', coaTemplateInput('metadata.gr_number', $fields, $editable, 'Enter G.R. number or NA')],
        ['Testing date', coaTemplateSource('testing_date', $sourceValues)],
        ['Mfg. Date', coaTemplateInput('metadata.manufacturing_date', $fields, $editable, 'Enter manufacturing date')],
        ['Exp. Date.', coaTemplateInput('metadata.expiry_date', $fields, $editable, 'Enter expiry date')],
        ['No. of Packings received', coaTemplateInput('metadata.packings_received', $fields, $editable, 'Enter count')],
        ['No. of Packings sampled', coaTemplateInput('metadata.packings_sampled', $fields, $editable, 'Enter count')],
        ['Reference specification no./STP no.', coaTemplateEscape($profile['stp_reference'] ?? '')],
        ['Lot No./Batch no.', coaTemplateSource('batch_number', $sourceValues)],
        ['Lot Size/ Batch size', coaTemplateSource('batch_size', $sourceValues)],
        ['Sample size', coaTemplateInput('metadata.sample_size', $fields, $editable, 'Enter sample size or NA')],
    ];
    $html = '<table class="coa-v1-metadata coa-serology-metadata"><tbody>';
    foreach ($rows as [$label, $value]) {
        $html .= '<tr><td>' . coaTemplateEscape($label) . '</td><td>' . $value . '</td></tr>';
    }
    return $html . '</tbody></table>';
}

function coaTemplateSerologyPhysical(array $profile, array $fields, bool $editable): string
{
    return '<table class="coa-v1-results coa-serology-physical"><thead><tr>'
        . '<th class="coa-v1-serial">Sr. No.</th><th>Test</th><th>Result</th><th>Specification</th>'
        . '</tr></thead><tbody><tr><td>&nbsp;</td><td>Physical Checks (Visual inspection)</td><td>'
        . coaTemplateInput('results.physical_checks', $fields, $editable, 'Enter result')
        . '</td><td>' . coaTemplateEscape($profile['physical_specification'] ?? '')
        . '</td></tr><tr class="coa-v1-section-row"><td>&nbsp;</td><td colspan="3">'
        . coaTemplateEscape($profile['performance_title'] ?? '') . '</td></tr></tbody></table>';
}

function coaTemplateSerologyGroups(array $groups, array $fields, bool $editable): string
{
    $html = '';
    foreach ($groups as $group) {
        $html .= '<table class="coa-v1-results coa-serology-performance"><thead><tr>'
            . '<th class="coa-v1-serial">' . coaTemplateEscape($group['serial'] ?? '') . '</th>'
            . '<th>' . coaTemplateEscape($group['title'] ?? '') . '</th>';
        foreach (($group['columns'] ?? []) as $column) {
            $html .= '<th>' . coaTemplateEscape($column) . '</th>';
        }
        $html .= '<th>Specification</th></tr></thead><tbody>';
        foreach (($group['rows'] ?? []) as $rowIndex => $row) {
            $html .= '<tr><td>&nbsp;</td><td>' . coaTemplateEscape($row['label'] ?? '') . '</td>';
            foreach (($row['cells'] ?? []) as $cell) {
                $html .= '<td>' . coaTemplateInput(
                    'observations.' . (string) ($cell['key'] ?? ''),
                    $fields,
                    $editable,
                    (string) ($cell['label'] ?? 'Observation')
                ) . '</td>';
            }
            $html .= '<td>' . ($rowIndex === 0
                ? coaTemplateEscape($group['specification'] ?? '')
                : '&nbsp;') . '</td></tr>';
        }
        $html .= '</tbody></table>';
    }
    return $html;
}

function coaTemplateRenderSerology(array $form, bool $editable = false): string
{
    $layout = is_array($form['layout'] ?? null) ? $form['layout'] : [];
    $profile = is_array($form['profile'] ?? null) ? $form['profile'] : [];
    if ($profile === []) {
        return '';
    }
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    if (is_array($profile['document'] ?? null)) {
        $document = array_replace($document, $profile['document']);
    }
    $fields = coaTemplateFields($form);
    $sourceValues = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $logoDataUri = trim((string) ($form['branding_logo_data_uri'] ?? ''));
    $groups = is_array($profile['performance_groups'] ?? null)
        ? $profile['performance_groups']
        : [];
    $groupChunks = [array_slice($groups, 0, 1), array_slice($groups, 1)];
    $pageCount = 2;

    $firstBody = coaTemplateHeader($document, $logoDataUri)
        . coaTemplateSerologyMetadata($profile, $fields, $sourceValues, $editable)
        . coaTemplateSerologyPhysical($profile, $fields, $editable)
        . coaTemplateSerologyGroups($groupChunks[0], $fields, $editable);
    if ($editable) {
        $firstBody .= '<div class="coa-v1-source-note">Controlled source: '
            . coaTemplateEscape($profile['source_document'] ?? '') . '</div>';
    }
    $secondBody = coaTemplateHeader($document, $logoDataUri)
        . coaTemplateSerologyGroups($groupChunks[1], $fields, $editable)
        . coaTemplateApproval($fields, $editable);

    $pages = [
        '<section class="coa-v1-page" data-page="1"><div class="coa-v1-page-body">'
            . $firstBody . '</div>' . coaTemplateFooter(1, $pageCount) . '</section>',
        '<section class="coa-v1-page" data-page="2"><div class="coa-v1-page-body">'
            . $secondBody . '</div>' . coaTemplateFooter(2, $pageCount) . '</section>',
    ];
    $styles = '<style>'
        . '.coa-serology-metadata{font-size:7pt}'
        . '.coa-serology-metadata td{height:4.25mm;padding:.55mm .8mm}'
        . '.coa-serology-physical{margin-bottom:2mm;font-size:7pt}'
        . '.coa-serology-performance{margin-bottom:2mm;font-size:7pt}'
        . '.coa-serology-performance th{text-align:center;background:#f1f5f9}'
        . '.coa-serology-performance th:nth-child(2){width:27%}'
        . '.coa-serology-performance th:last-child{width:18%}'
        . '.coa-serology-performance td{padding:.55mm .65mm}'
        . '</style>';
    return coaTemplateStyles() . $styles
        . '<div class="coa-v1-document" data-coa-template="1" data-coa-type="'
        . coaTemplateEscape($form['coa_type'] ?? '') . '">'
        . implode('', $pages) . '</div>';
}
