<?php

declare(strict_types=1);

/**
 * Controlled Serology COA profiles transcribed from /SEROLOGY COA 2026.
 * The 33 supplied monthly IP/FG reports resolve to four stable layouts.
 * Historical results and batch metadata are intentionally not preloaded.
 */

function coaSerologyGroup(
    string $key,
    string $serial,
    string $title,
    array $sampleLabels,
    string $specification
): array {
    $rows = [];
    foreach ($sampleLabels as $index => $label) {
        $rowKey = $key . '_' . ($index + 1);
        $rows[] = [
            'label' => (string) $label,
            'cells' => [
                ['key' => $rowKey . '_avidity', 'label' => 'Avidity'],
                ['key' => $rowKey . '_pattern', 'label' => 'Pattern'],
                ['key' => $rowKey . '_status', 'label' => 'Status'],
            ],
        ];
    }
    return [
        'key' => $key,
        'serial' => $serial,
        'title' => $title,
        'columns' => ['Avidity', 'Pattern', 'Status'],
        'specification' => $specification,
        'rows' => $rows,
    ];
}

function coaSerologyPerformanceGroups(): array
{
    return [
        coaSerologyGroup(
            'positive_control_titer',
            '2.1',
            'Positive Control Titer',
            ['Neat', '1:2', '1:4', '1:8', '1:16', '1:32', '1:64'],
            'Reactive'
        ),
        coaSerologyGroup(
            'negative_control',
            '2.2',
            'Negative Control',
            ['Negative Control Sample I', 'Negative Control Sample II'],
            'Non-Reactive'
        ),
        coaSerologyGroup(
            'clinical_normal',
            '2.3',
            'Clinical Samples (Normal)',
            ['Normal Clinical Sample I', 'Normal Clinical Sample II'],
            'Non-Reactive'
        ),
        coaSerologyGroup(
            'clinical_abnormal',
            '2.4',
            'Clinical Samples (Abnormal)',
            ['Abnormal Clinical Sample I', 'Abnormal Clinical Sample II'],
            'Reactive'
        ),
    ];
}

function coaSerologyEditableFieldKeys(array $groups): array
{
    $keys = [
        'metadata.gr_number',
        'metadata.packings_received',
        'metadata.packings_sampled',
        'metadata.sample_size',
        'results.physical_checks',
    ];
    foreach ($groups as $group) {
        foreach (($group['rows'] ?? []) as $row) {
            foreach (($row['cells'] ?? []) as $cell) {
                $keys[] = 'observations.' . (string) $cell['key'];
            }
        }
    }
    return $keys;
}

function coaSerologyProfile(
    array $productIds,
    string $sourceFolder,
    string $itemDescription,
    string $itemCode,
    string $ipStpReference,
    string $fgStpReference,
    string $physicalSpecification,
    string $sourceIpDocument,
    string $sourceFgDocument,
    array $sourceIpDocuments,
    array $sourceFgDocuments,
    string $documentNumber
): array {
    $groups = coaSerologyPerformanceGroups();
    return [
        'product_ids' => array_values(array_map('intval', $productIds)),
        'source_folder' => $sourceFolder,
        'source_ip_document' => $sourceIpDocument,
        'source_fg_document' => $sourceFgDocument,
        'source_ip_documents' => array_values($sourceIpDocuments),
        'source_fg_documents' => array_values($sourceFgDocuments),
        'item_description' => $itemDescription,
        'product_name' => $itemDescription,
        'manufacturer_supplier' => 'Biogenix Inc. Pvt. Ltd',
        'item_code' => $itemCode,
        'ip_stp_reference' => $ipStpReference,
        'fg_stp_reference' => $fgStpReference,
        'page_count' => 2,
        'document' => ['document_no' => $documentNumber],
        'physical_specification' => $physicalSpecification,
        'performance_title' => 'Performance check (Strength of reaction at 2 minutes)',
        'performance_groups' => $groups,
        'editable_field_keys' => coaSerologyEditableFieldKeys($groups),
    ];
}

function coaSerologyProfiles(): array
{
    return [
        'aso_latex' => coaSerologyProfile(
            [1043, 1044, 1045],
            'ASO LATEX',
            'ASO LATEX',
            'BGASO',
            'BIPL-IPSTP-126',
            'BIPL-FPSTP-126',
            'The kits should be packed in Box containing 3 vials with ASO Latex reagent, ASO Positive Control reagent, ASO Negative Reagent. The kit also contains latex reaction plates, dropper sets and mixing stick sets and a pack insert.',
            'BIPL-COA-IP-26150-B ASOL0526.doc',
            'BIPL-COA-FG-26149-B ASOL0526.doc',
            [
                'BIPL-COA-IP-26075-B ASOL0126.doc',
                'BIPL-COA-IP-26088-B ASOL0226.doc',
                'BIPL-COA-IP-26114-B ASOL0326.doc',
                'BIPL-COA-IP-26123-B ASOL0426.doc',
                'BIPL-COA-IP-26150-B ASOL0526.doc',
            ],
            [
                'BIPL-COA-FG-26074-B ASOL0126.doc',
                'BIPL-COA-FG-26085-B ASOL0226.doc',
                'BIPL-COA-FG-260112-B ASOL0326.doc',
                'BIPL-COA-FG-26124-B ASOL0426.doc',
                'BIPL-COA-FG-26149-B ASOL0526.doc',
            ],
            'BIPL-F-COA-01'
        ),
        'crp_latex' => coaSerologyProfile(
            [1039, 1040, 1041],
            'CRP LATEX',
            'CRP LATEX',
            'BGCRP',
            'BIPL-IPSTP-124',
            'BIPL-FPSTP-124',
            'The kits should be packed in Box containing 3 vials with CRP Latex reagent, CRP Positive Control reagent, CRP Negative Reagent. The kit also contains latex reaction plates, dropper sets and mixing stick sets and a pack insert.',
            'BIPL-COA-IP-26146-B CRPL0626.doc',
            'BIPL-COA-FG-26144-B CRPL0626.doc',
            [
                'BIPL-COA-IP-26012-B CRPL0126.doc',
                'BIPL-COA-IP-26024-B CRPL0226.doc',
                'BIPL-COA-IP-26058-B CRPL0326.doc',
                'BIPL-COA-IP-26136-B CRPL0526.doc',
                'BIPL-COA-IP-26146-B CRPL0626.doc',
            ],
            [
                'BIPL-COA-FG-26012-B CRPL0126.doc',
                'BIPL-COA-FG-26024-B CRPL0226.doc',
                'BIPL-COA-FG-26060-B CRPL0326.doc',
                'BIPL-COA-FG-26106-B CRPL0426.doc',
                'BIPL-COA-FG-26136-B CRPL0526.doc',
                'BIPL-COA-FG-26144-B CRPL0626.doc',
            ],
            'BIPL-F-STS-14'
        ),
        'rf_latex' => coaSerologyProfile(
            [1032, 1034, 1035, 2014],
            'RF LATEX',
            'RF LATEX',
            'BGRF',
            'BIPL-IPSTP-126',
            'BIPL-FPSTP-126',
            'The kits should be packed in Box containing 3 vials with RF Latex reagent, RF Positive Control reagent, RF Negative Reagent. The kit also contains latex reaction plates, dropper sets and mixing stick sets and a pack insert.',
            'BIPL-COA-IP-26151-B  RFL0526.doc',
            'BIPL-COA-FG-26150-B  RFL0526.doc',
            [
                'BIPL-COA-IP-26022-B  RFL0126.doc',
                'BIPL-COA-IP-26063-B  RFL0226.doc',
                'BIPL-COA-IP-26109-B  RFL0326.doc',
                'BIPL-COA-IP-26129-B  RFL0426.doc',
                'BIPL-COA-IP-26151-B  RFL0526.doc',
            ],
            [
                'BIPL-COA-FG-26022-B  RFL0126.doc',
                'BIPL-COA-FG-26073-B  RFL0226.doc',
                'BIPL-COA-FG-26108-B  RFL0326.doc',
                'BIPL-COA-FG-26127-B  RFL0426.doc',
                'BIPL-COA-FG-26150-B  RFL0526.doc',
            ],
            'BIPL-F-STS-14'
        ),
        'rpr' => coaSerologyProfile(
            [1028, 1029],
            'RPR',
            'RPR ANTIGEN',
            'BGRPR',
            'BIPL-IPSTP-126',
            'BIPL-FPSTP-126',
            'The kits should be packed in Box containing 3 vials with RPR Carbon Antigen, RPR Positive Control reagent, RPR Negative Reagent. The kit also contains reaction slides, dropper sets and mixing stick sets and a pack insert.',
            'BIPL CoA-IP-26050-B RPR0126.doc',
            'BIPL CoA-FG-26052-B RPR0126.doc',
            ['BIPL CoA-IP-26050-B RPR0126.doc'],
            ['BIPL CoA-FG-26052-B RPR0126.doc'],
            'BIPL-F-COA-01'
        ),
    ];
}

function coaSerologyMappedProductIds(): array
{
    $ids = [];
    foreach (coaSerologyProfiles() as $profile) {
        array_push($ids, ...($profile['product_ids'] ?? []));
    }
    $ids = array_values(array_unique(array_map('intval', $ids)));
    sort($ids);
    return $ids;
}

function coaSerologySourceDocumentCount(): int
{
    $documents = [];
    foreach (coaSerologyProfiles() as $profile) {
        foreach (['source_ip_documents', 'source_fg_documents'] as $key) {
            foreach (($profile[$key] ?? []) as $document) {
                $documents[$profile['source_folder'] . '/' . $document] = true;
            }
        }
    }
    return count($documents);
}
