<?php

declare(strict_types=1);

function coaCatalogSeedLayout(
    string $coaType,
    string $rendererVariant,
    array $catalog,
    array $document
): array {
    $type = strtoupper($coaType);
    $families = [];
    $profiles = [];
    foreach ($catalog as $familyKey => $catalogProfile) {
        $profile = $catalogProfile;
        $productIds = array_values(array_map('intval', $profile['product_ids'] ?? []));
        unset($profile['product_ids']);
        $sourceKey = $type === 'FG' ? 'source_fg_document' : 'source_ip_document';
        $profile['source_document'] = (string) (
            $catalogProfile[$sourceKey]
            ?? $catalogProfile['source_document']
            ?? ''
        );
        $stpKey = $type === 'FG' ? 'fg_stp_reference' : 'ip_stp_reference';
        if (array_key_exists($stpKey, $catalogProfile)) {
            $profile['stp_reference'] = (string) ($catalogProfile[$stpKey] ?? '');
        }
        unset($profile['source_ip_document'], $profile['source_fg_document']);
        unset($profile['ip_stp_reference'], $profile['fg_stp_reference']);
        $families[(string) $familyKey] = $profile;
        foreach ($productIds as $productId) {
            $profiles[(string) $productId] = ['family_key' => (string) $familyKey];
        }
    }
    ksort($families);
    uksort($profiles, static fn(string $left, string $right): int => (int) $left <=> (int) $right);
    return [
        'schema_version' => 1,
        'renderer' => 'structured_coa_html',
        'renderer_variant' => $rendererVariant,
        'coa_type' => $type,
        'document' => $document,
        'profile_families' => $families,
        'profiles' => $profiles,
        'editable_fields' => [
            'metadata.manufacturing_date',
            'metadata.expiry_date',
            'results.*',
            'observations.*',
            'approval.decision',
            'approval.comments',
            'approval.analysis_by',
            'approval.verified_by',
        ],
    ];
}

function coaSeedTemplateCatalog(mysqli $conn, array $configuration): array
{
    $catalog = is_array($configuration['catalog'] ?? null) ? $configuration['catalog'] : [];
    $productIds = is_array($configuration['product_ids'] ?? null)
        ? array_values(array_unique(array_map('intval', $configuration['product_ids'])))
        : [];
    $definitions = is_array($configuration['definitions'] ?? null)
        ? $configuration['definitions']
        : [];
    if ($catalog === [] || $productIds === [] || count($definitions) !== 2) {
        throw new InvalidArgumentException('The COA catalog seed configuration is incomplete.');
    }

    $lockName = (string) ($configuration['lock_name'] ?? 'coa_template_catalog_seed');
    $escapedLockName = $conn->real_escape_string($lockName);
    $lockResult = $conn->query("SELECT GET_LOCK('{$escapedLockName}', 15) AS acquired");
    $lockRow = $lockResult ? $lockResult->fetch_assoc() : null;
    if ((int) ($lockRow['acquired'] ?? 0) !== 1) {
        throw new RuntimeException('Unable to acquire the COA template catalog seed lock.');
    }

    try {
        $conn->begin_transaction();
        $upsertTemplate = $conn->prepare(
            "INSERT INTO coa_document_templates
                (template_code, template_name, coa_type, version_no, document_no,
                 issue_no, revision_no, effective_date, review_date, source_directory,
                 source_checksum, page_count, layout_json, status, created_by, created_at)
             VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, NOW())
             ON DUPLICATE KEY UPDATE
                 template_name = VALUES(template_name),
                 coa_type = VALUES(coa_type),
                 version_no = 1,
                 document_no = VALUES(document_no),
                 issue_no = VALUES(issue_no),
                 revision_no = VALUES(revision_no),
                 effective_date = VALUES(effective_date),
                 review_date = VALUES(review_date),
                 source_directory = VALUES(source_directory),
                 source_checksum = VALUES(source_checksum),
                 page_count = VALUES(page_count),
                 layout_json = VALUES(layout_json),
                 status = 1,
                 deleted_by = NULL,
                 deleted_at = NULL,
                 updated_by = 1,
                 updated_at = NOW()"
        );
        $findTemplate = $conn->prepare(
            'SELECT id FROM coa_document_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
        );
        $validateProduct = $conn->prepare(
            'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
        );
        $upsertMapping = $conn->prepare(
            "INSERT INTO coa_template_product_mappings
                (template_id, product_id, coa_type, status, created_by, created_at)
             VALUES (?, ?, ?, 1, 1, NOW())
             ON DUPLICATE KEY UPDATE
                 template_id = VALUES(template_id),
                 status = 1,
                 deleted_by = NULL,
                 deleted_at = NULL,
                 updated_by = 1,
                 updated_at = NOW()"
        );
        if (!$upsertTemplate || !$findTemplate || !$validateProduct || !$upsertMapping) {
            throw new RuntimeException('Unable to prepare the COA catalog seed statements.');
        }

        $document = (array) ($configuration['document'] ?? []);
        $templateCount = 0;
        $mappingCount = 0;
        foreach ($definitions as $definition) {
            $coaType = strtoupper((string) ($definition['coa_type'] ?? ''));
            $layout = coaCatalogSeedLayout(
                $coaType,
                (string) ($configuration['renderer_variant'] ?? ''),
                $catalog,
                $document
            );
            if (count($layout['profiles']) !== count($productIds)) {
                throw new RuntimeException("The {$coaType} COA product profile set is incomplete.");
            }
            $layoutJson = json_encode(
                $layout,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
            );
            $checksum = hash('sha256', $layoutJson);
            $templateCode = (string) ($definition['template_code'] ?? '');
            $templateName = (string) ($definition['template_name'] ?? '');
            $documentNo = (string) ($document['document_no'] ?? 'BIPL-F-COA-01');
            $issueNo = (string) ($document['issue_no'] ?? '01');
            $revisionNo = (string) ($document['revision_no'] ?? '02');
            $effectiveDate = (string) ($configuration['effective_date_sql'] ?? '2025-04-03');
            $reviewDate = (string) ($configuration['review_date_sql'] ?? '2028-04-02');
            $sourceDirectory = (string) ($configuration['source_directory'] ?? '');
            $pageCount = max(1, (int) ($configuration['page_count'] ?? 2));
            $upsertTemplate->bind_param(
                'ssssssssssis',
                $templateCode,
                $templateName,
                $coaType,
                $documentNo,
                $issueNo,
                $revisionNo,
                $effectiveDate,
                $reviewDate,
                $sourceDirectory,
                $checksum,
                $pageCount,
                $layoutJson
            );
            if (!$upsertTemplate->execute()) {
                throw new RuntimeException("Unable to save {$coaType} COA template: {$upsertTemplate->error}");
            }
            $findTemplate->bind_param('s', $templateCode);
            $findTemplate->execute();
            $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
            if ($templateId <= 0) {
                throw new RuntimeException("Unable to resolve {$coaType} COA template.");
            }
            $templateCount++;
            foreach ($productIds as $productId) {
                $validateProduct->bind_param('i', $productId);
                $validateProduct->execute();
                if (!$validateProduct->get_result()->fetch_assoc()) {
                    throw new RuntimeException("Mapped product ID {$productId} is unavailable.");
                }
                $upsertMapping->bind_param('iis', $templateId, $productId, $coaType);
                if (!$upsertMapping->execute()) {
                    throw new RuntimeException(
                        "Unable to map product {$productId} to {$coaType} COA: {$upsertMapping->error}"
                    );
                }
                $mappingCount++;
            }
        }
        $conn->commit();
        return ['templates' => $templateCount, 'mappings' => $mappingCount];
    } catch (Throwable $exception) {
        $conn->rollback();
        throw $exception;
    } finally {
        $conn->query("SELECT RELEASE_LOCK('{$escapedLockName}')");
    }
}
