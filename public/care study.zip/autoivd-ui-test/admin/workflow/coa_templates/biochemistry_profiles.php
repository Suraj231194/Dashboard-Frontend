<?php

declare(strict_types=1);

/**
 * Product profiles transcribed from the controlled documents in:
 *   /BIOCHEMISTRY COA REPORT 2026
 *
 * Historical result values are intentionally not copied into a blank template.
 * Controlled product names, product codes, STP numbers, test names and
 * specifications are retained. IP and FG overrides are kept independently
 * where the supplied source documents differ.
 */

function coaBiochemistryTestRows(
    string $visualSpecification,
    string $leakageSpecification,
    string $blankSpecification,
    array $standards,
    array $controls,
    array $levels,
    array $clinicalSamples
): array {
    $rows = [
        [
            'key' => 'physical_checks',
            'kind' => 'test',
            'serial' => '',
            'test' => 'Physical Checks (Visual inspection)',
            'specification' => $visualSpecification,
        ],
        [
            'key' => 'leakage_test',
            'kind' => 'test',
            'serial' => '',
            'test' => 'Leakage test',
            'specification' => $leakageSpecification,
        ],
        [
            'key' => 'performance_check',
            'kind' => 'section',
            'serial' => '',
            'test' => 'Performance check',
            'specification' => '',
        ],
        [
            'key' => 'blank_initial_absorbance',
            'kind' => 'test',
            'serial' => '',
            'test' => 'Blank/initial absorbance',
            'specification' => $blankSpecification,
        ],
    ];

    foreach ($standards as $index => $standard) {
        $rows[] = [
            'key' => 'standard_' . ($index + 1),
            'kind' => 'test',
            'serial' => '',
            'test' => (string) ($standard[0] ?? 'Standard/calibrators'),
            'specification' => (string) ($standard[1] ?? ''),
        ];
    }

    $rows[] = [
        'key' => 'controls',
        'kind' => 'section',
        'serial' => '',
        'test' => 'Controls',
        'specification' => '',
    ];
    foreach ($controls as $index => $control) {
        $rows[] = [
            'key' => 'control_' . ($index + 1),
            'kind' => 'test',
            'serial' => (string) ($index + 1) . '.',
            'test' => (string) ($control[0] ?? ''),
            'specification' => (string) ($control[1] ?? ''),
        ];
    }

    $rows[] = [
        'key' => 'levels_linearity',
        'kind' => 'section',
        'serial' => '',
        'test' => 'Levels/Linearity',
        'specification' => '',
    ];
    foreach ($levels as $index => $level) {
        $rows[] = [
            'key' => 'linearity_' . ($index + 1),
            'kind' => 'test',
            'serial' => (string) ($index + 1) . '.',
            'test' => (string) ($level[0] ?? ''),
            'specification' => (string) ($level[1] ?? ''),
        ];
    }

    $rows[] = [
        'key' => 'clinical_samples',
        'kind' => 'section',
        'serial' => '',
        'test' => 'Clinical samples normal/abnormal',
        'specification' => '',
    ];
    foreach ($clinicalSamples as $index => $sample) {
        $rows[] = [
            'key' => 'clinical_' . ($index + 1),
            'kind' => 'test',
            'serial' => (string) ($index + 1),
            'test' => (string) ($sample[0] ?? ''),
            'specification' => (string) ($sample[1] ?? ''),
        ];
    }

    return $rows;
}

function coaBiochemistryOverrideSpecifications(array $rows, array $specifications): array
{
    foreach ($rows as &$row) {
        $key = (string) ($row['key'] ?? '');
        if (array_key_exists($key, $specifications)) {
            $row['specification'] = (string) $specifications[$key];
        }
    }
    unset($row);
    return $rows;
}

function coaBiochemistryProfile(
    array $productIds,
    string $folder,
    string $productName,
    string $productCode,
    string $stpNumber,
    string $ipSource,
    string $fgSource,
    array $rows,
    ?array $fgRows = null,
    int $pageCount = 1,
    int $metadataRowCount = 10,
    ?string $ipStpReference = null,
    ?string $fgStpReference = null
): array {
    return [
        'product_ids' => array_values(array_map('intval', $productIds)),
        'source_folder' => $folder,
        'source_ip_document' => $ipSource,
        'source_fg_document' => $fgSource,
        'product_name' => $productName,
        'brand_name' => 'Biogenix',
        'product_code' => $productCode,
        'stp_number' => $stpNumber,
        'ip_stp_reference' => $ipStpReference,
        'fg_stp_reference' => $fgStpReference,
        'page_count' => max(1, $pageCount),
        'metadata_row_count' => $metadataRowCount,
        'rows' => $rows,
        'fg_rows' => $fgRows ?? $rows,
    ];
}

function coaBiochemistryProfiles(): array
{
    $twoBottleVisual = 'The kits should be packed in a box contains reagent 1 and reagent 2 in separate glass bottle along with pack insert.';
    $twoBottleLeakage = 'No leakage should be observed in reagent 1 and reagent 2 bottles.';
    $threeBottleVisual = 'The kits should be packed in a box containing reagent 1, reagent 2 in plastic bottle & reagent 3 in glass vial along with pack insert.';
    $threeBottleLeakage = 'No leakage should be observed in reagent 1, reagent 2 and reagent 3 bottles.';
    $singleBottleVisual = 'The kits should be packed in a box contains reagent 1 in plastic bottle along with pack insert.';
    $singleBottleLeakage = 'No leakage should be observed in reagent 1 bottles.';

    $profiles = [];

    $albuminRows = coaBiochemistryTestRows(
        $twoBottleVisual,
        $twoBottleLeakage,
        'NA',
        [['Standard/calibrators', '4.0 gm/dl (± 0.2 gm/dl)']],
        [['Control 1', '4.10(3.48-.4.15) gm/dl'], ['Control 2', '2.66(2.38-2.94) m/dl']],
        [['2 gm /dl', '1.8-2.2 gm/dl'], ['8 gm /dl', '7.2-8.8 gm/dl']],
        [['Normal serum Sample', '3.8-5.4 gm /dl'], ['Abnormal serum sample', 'Above 5.4 gm /dl']]
    );
    $profiles['albumin'] = coaBiochemistryProfile(
        [917, 1579, 1857],
        'ALBUMIN',
        'ALBUMIN Reagent',
        'BGALB',
        '017',
        'BIPL-COA-IP-26157-B ALB1026.doc',
        'BIPL-COA-FG-26154-B ALB1026- Copy.doc',
        $albuminRows,
        coaBiochemistryOverrideSpecifications(
            $albuminRows,
            ['control_1' => '3.82(3.48-4.15) gm/dl']
        )
    );

    $profiles['alp'] = coaBiochemistryProfile(
        [915, 916],
        'ALP',
        'Alkaline Phosphatase',
        'BGALP',
        '018',
        'BIPL-COA-IP-26133-B ALP0526.doc',
        'BIPL-COA-FG-26131-B ALP0526.doc',
        coaBiochemistryTestRows(
            $singleBottleVisual,
            $singleBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 1', '87-160 U/L'], ['Control 2', '334-603 U/L']],
            [['100 U/L', '90-110 U/L'], ['1000 U/L', '900-1100 U/L']],
            [['Normal serum Sample', '53-165 U/L'], ['Abnormal serum sample', 'Above 165 U/L']]
        )
    );

    $profiles['ammonia'] = coaBiochemistryProfile(
        [913, 1773, 1775],
        'AMMONIA',
        'AMMONIA Reagent',
        'BGAMN',
        '020',
        'BIPL-COA-IP-26006-B AMN0126.doc',
        'BIPL-COA-FG-26005-B AMN0126.doc',
        coaBiochemistryTestRows(
            $threeBottleVisual,
            $threeBottleLeakage,
            'NA',
            [['Standard/calibrators', '500.0 µg/dl (± 10.0 µg/dl)']],
            [['Control 1', '33.2-88.5 µg/dl'], ['Control 2', '119-189 µg/dl']],
            [['50 µg/dl', '45-55 µg/dl'], ['1200 µg/dl', '1080-1320 µg/dl']],
            [['Normal serum Sample', '17-90 µg/dl'], ['Abnormal serum sample', 'Above 90 µg/dl']]
        )
    );

    $profiles['amylase'] = coaBiochemistryProfile(
        [914, 2017],
        'AMYLASE',
        'ALPHA AMYLASE',
        'BGAMY',
        '019',
        'BIPL-COA-IP-26140-B AMY0426.doc',
        'BIPL-COA-FG-26138-B AMY0426.doc',
        coaBiochemistryTestRows(
            $singleBottleVisual,
            $singleBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 1', '56 (34.6-77.5) U/L'], ['Control 2', '341 (262-420) U/L']],
            [['100 U/L', '90-110 U/L'], ['1500 U/L', '1350-1650 U/L']],
            [['Normal serum Sample', '00-90 U/L'], ['Abnormal serum sample', 'Above 90 U/L']]
        )
    );

    $profiles['bilirubin_direct'] = coaBiochemistryProfile(
        [910],
        'BILIRUBIN DIRECT',
        'Bilirubin Direct Reagent',
        'BGDBIL',
        '021',
        'BIPL-COA-IP-26160-B DBIL0326.doc',
        'BIPL-COA-FG-26157-B DBIL0326.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box contains reagent 1 in plastic bottle and reagent 2 in glass bottle along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 2', '1.01(0.79-1.22) mg/dl'], ['Control 3', '1.96(1.55-2.37) mg/dl']],
            [['02 mg/dl', '1.8-2.2 mg/dl'], ['20 mg/dl', '19-21 mg/dl']],
            [['Normal serum Sample', 'Less than 0.2 mg/dl'], ['Abnormal serum sample', 'Above 0.2 mg/dl']]
        )
    );

    $profiles['bilirubin_total'] = coaBiochemistryProfile(
        [909],
        'BILIRUBIN TOTAL',
        'Bilirubin Total Reagent',
        'BGTBIL',
        '021',
        'BIPL-COA-IP-26112-B TBIL0326.doc',
        'BIPL-COA-FG-26110-B TBIL0326.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box contains reagent 1 in plastic bottle and reagent 2 in glass bottle along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 2', '1.60-2.46 mg/dl'], ['Control 3', '4.67-7.15 mg/dl']],
            [['2 mg/dl', '1.8-2.2 mg/dl'], ['20 mg/dl', '19-21 mg/dl']],
            [['Normal serum Sample', '0.3-1.2 mg/dl'], ['Abnormal serum sample', 'Above 1.2 mg/dl']]
        )
    );

    $profiles['calcium'] = coaBiochemistryProfile(
        [903, 1913],
        'CALCIUM',
        'CALCIUM Reagent',
        'BGCAL',
        '022',
        'BIPL-COA-IP-26105-B CAL0426.doc',
        'BIPL-COA-FG-26104-B CAL0426.doc',
        coaBiochemistryTestRows(
            $twoBottleVisual,
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '10.0 mg/dl (± 1 mg/dl)']],
            [['Control 1', '8.61-10.00 mg/dl'], ['Control 2', '11.1-12.80 mg/dl']],
            [['10 mg/dl', '9-11 mg/dl'], ['18 mg/dl', '16.2-19.8 mg/dl']],
            [['Normal serum Sample', '8.8-10.5 mg/dl'], ['Abnormal serum sample', 'Above 10.5 mg/dl']]
        )
    );

    $profiles['cholesterol'] = coaBiochemistryProfile(
        [898, 1420],
        'CHOLESTEROL',
        'CHOLESTEROL Reagent',
        'BGCHO',
        '028',
        'BIPL-COA-IP-26161-B-CHO0826.doc',
        'BIPL-COA-FG-26158-B-CHO0826.doc',
        coaBiochemistryTestRows(
            $twoBottleVisual,
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '200 mg/dl (±5 mg/dl)']],
            [['Control 1', '225(197-252) mg/dl'], ['Control 2', '90.9(78.3-103) mg/dl']],
            [['200 mg/dl', '180-220 mg/dl'], ['1000 mg/dl', '900-1100 mg/dl']],
            [['Normal serum Sample', '109-202 mg/dl'], ['Abnormal serum sample', 'Above 202 mg/dl']]
        )
    );

    $profiles['ck_mb'] = coaBiochemistryProfile(
        [896, 897],
        'CK MB',
        'CK MB',
        'BGCKMB',
        '031',
        'BIPL-COA-IP-26132-BCKMB0326.doc',
        'BIPL-COA-FG-26134-BCKMB0326.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1 and reagent 2 in separate glass bottle, along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 1', '118-178 U/L'], ['Control 2', '68-128 U/L']],
            [['20U/L', '18-22 U/L'], ['1000U/L', '900-1100U/L']],
            [['Normal serum Sample', '0-24 U/L'], ['Abnormal serum sample', 'Above 24 U/L']]
        )
    );

    $profiles['creatinine'] = coaBiochemistryProfile(
        [894],
        'CREATININE',
        'CREATININE Reagent',
        'BGCRE',
        '034',
        'BIPL-COA-IP-26158-B CRE0326 - Copy.doc',
        'BIPL-COA-FG-26155-B CRE0326 - Copy.doc',
        coaBiochemistryTestRows(
            $threeBottleVisual,
            $threeBottleLeakage,
            'NA',
            [['Standard/calibrators', '2.0 mg/dl (± 0.5 mg/dl)']],
            [['Control 1', '2.09(1.82-2.32) mg/dl'], ['Control 2', '6.05(5.40-6.70) mg/dl']],
            [['2 mg/dl', '1.8-2.2 mg/dl'], ['20 mg/dl', '18-22 mg/dl']],
            [['Normal serum Sample', '0.5-1.3 mg/dl'], ['Abnormal serum sample', 'Above 1.3 mg/dl']]
        ),
        ipStpReference: 'BIL-IPSTP-034',
        fgStpReference: 'BIL-FPSTP-034'
    );

    $profiles['crp_turbi'] = coaBiochemistryProfile(
        [1036, 1037, 1038],
        'CRP TURBI',
        'CRP TURBI Reagent',
        'BGCRPT',
        '129',
        'BIPL-COA-IP-26125-B CRPT0526.doc',
        'BIPL-COA-FG-26127-B CRPT0526.doc',
        coaBiochemistryTestRows(
            $threeBottleVisual,
            $threeBottleLeakage,
            'NA',
            [['Standard/calibrators', '90.0 mg/L (± 2.0 mg/L)']],
            [['Control 1', '1.60-2.40 mg/L'], ['Control 2', '96-144 mg/L']],
            [['150 mg/dl', '145-165 mg/L']],
            [['Normal serum Sample', '0-6.0 mg/L'], ['Abnormal serum sample', 'Above 6.0 mg/L']]
        )
    );

    $profiles['glucose'] = coaBiochemistryProfile(
        [883, 884, 885],
        'GLUCOSE',
        'GLUCOSE Reagent',
        'BGGLU',
        '037',
        'BIPL-COA-IP-26162-B GLU0326.doc',
        'BIPL-COA-FG-26159-B GLU0326.doc',
        coaBiochemistryTestRows(
            $twoBottleVisual,
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '100 mg/dl (± 5mg/dl)']],
            [['Control 2', '108(91.8-124) mg/dl'], ['Control 3', '235(277-319) mg/dl']],
            [['100 mg/dl', '90-110 mg/dl'], ['500 mg/dl', '450-550 mg/dl']],
            [['Normal serum Sample', '60-110 mg/dl'], ['Abnormal serum sample', 'Above 110 mg/dl']]
        )
    );

    $profiles['hba1c'] = coaBiochemistryProfile(
        [881],
        'HbA1C',
        'HbA1C Reagent',
        'BGHbA1C',
        '39',
        'BIPL-COA-IP-26033-B-HbA1C0126.doc',
        'BIPL-COA-FG-26033-B-HbA1C0126.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1, reagent 2 in plastic bottle and five calibrators of different concentrations in separate vials along with pack insert.',
            'No leakage should be observed in reagent 1, reagent 2 and reagent 3, 4, 5, 6, 7 bottles.',
            'NA',
            [
                ['Standard/calibrators 1', '0 (±0.15 %)'],
                ['Standard/calibrators 2', '5 (±0.15 %)'],
                ['Standard/calibrators 3', '7.54 (±0.15 %)'],
                ['Standard/calibrators 4', '10.32 (±0.15 %)'],
                ['Standard/calibrators 5', '15.9 (±0.15 %)'],
            ],
            [['Control 1', '8.4-11.76 %'], ['Control 2', '13.0-18.2 %']],
            [['2%', '1.8-2.2 %'], ['15%', '13.5-16.5 %']],
            [['Normal serum Sample', '4.2-6.5 %'], ['Abnormal sample serum', 'Above 6.5 %']]
        ),
        null,
        2
    );

    $profiles['hdl_cholesterol_ppt'] = coaBiochemistryProfile(
        [876],
        'HDL CHOLESTEROL PPT',
        'HDL cholesterol precipitate Reagent',
        'BGHDL',
        '024',
        'BIPL-COA-IP-26007-B HDL0126.doc',
        'BIPL-COA-FG-26006-B HDL0126.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1 and reagent 2 in separate glass bottle, along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '50 mg/dl (± 2 mg/dl)']],
            [['Control 1', '24-34 mg/dl'], ['Control 2', '48-60 mg/dl']],
            [['100 mg/dl', '90-110 mg/dl'], ['125 mg/dl', '112.5-137.5 mg/dl']],
            [['Normal serum Sample', '45-60 mg/dl'], ['Abnormal serum sample', 'Above 60 mg/dl']]
        )
    );

    $hdlDirectIpRows = coaBiochemistryTestRows(
        $threeBottleVisual,
        $threeBottleLeakage,
        'NA',
        [['Standard/calibrators', '59.58 mg/dl ( ±1.0 mg/dl )']],
        [['Control 1', '65.7-92.6 mg/dl'], ['Control 2', '20.2-29.6 mg/dl']],
        [['20 mg/dl', '18-22 mg/dl'], ['180 mg/dl', '162-198 mg/dl']],
        [['Normal serum Sample', '30-85 mg/dl'], ['Abnormal serum sample', 'Above 85 mg/dl']]
    );
    $hdlDirectFgRows = coaBiochemistryTestRows(
        $threeBottleVisual,
        $threeBottleLeakage,
        'NA',
        [['Standard/calibrators', '59.58 mg/dl ( ±1.0 mg/dl )']],
        [['Control 1', '59.5-89.2 mg/dl'], ['Control 2', '17.3-31.8 mg/dl']],
        [['20 mg/dl', '18-22 mg/dl'], ['180 mg/dl', '162-198 mg/dl']],
        [['Normal serum Sample', '30-85 mg/dl'], ['Abnormal serum sample', 'Above 85 mg/dl']]
    );
    $profiles['hdl_direct'] = coaBiochemistryProfile(
        [873, 874, 875, 1419],
        'HDL DIRECT',
        'HDL DIRECT',
        'BGHDLD',
        '025',
        'BIPL-COA-IP-26144-B HDLD0426- Copy.doc',
        'BIPL-COA-FG-26142-B HDLD0426.doc',
        $hdlDirectIpRows,
        $hdlDirectFgRows
    );

    $profiles['homocysteine'] = coaBiochemistryProfile(
        [411, 1785],
        'HOMOCYSTEIN',
        'Homocysteine Reagent',
        'BGHCY',
        '',
        'HCY0126.doc',
        'HCY0126.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1, reagent 2 in plastic bottle and four calibrators of different concentrations in separate vials along with pack insert.',
            'No leakage should be observed in reagent 1, reagent 2 and calibrators bottles',
            'NA',
            [
                ['Standard/calibrators 1', '0.00 umol/L'],
                ['Standard/calibrators 2', '28.0 ± 2 umol/L'],
            ],
            [
                ['Control 1', '16.0 (14.40-17.60) umol/L'],
                ['Control 2', '12.0 (10.80-13.20) umol/L'],
                ['Control 3', '29.0 (26.10-31.90) umol/L'],
            ],
            [['50 umol/L', '40-55 umol/L'], ['100 umol/L', '90-110 umol/L']],
            [['Normal serum Sample', '1.5-50 umol/L'], ['Abnormal sample serum', 'Up to 55 umol/L']]
        ),
        null,
        1,
        7
    );

    $profiles['ldl_direct'] = coaBiochemistryProfile(
        [867, 868],
        'LDL DIRECT',
        'LDL DIRECT',
        'BGLDLD',
        '027',
        'BIPL-COA-IP-26122-B LDLD0326.doc',
        'BIPL-COA-FG-26123-B LDLD0326.doc',
        coaBiochemistryTestRows(
            $threeBottleVisual,
            $threeBottleLeakage,
            'NA',
            [['Standard/calibrators', '106.10 mg/dl ( ±5.0 mg/dl )']],
            [['Control 1', '74.8-171 mg/dl'], ['Control 2', '33.6-80.9 mg/dl']],
            [['106 mg/dl', '95.4-116.6 mg/dl'], ['200 mg/dl', '180-220 mg/dl']],
            [['Normal serum Sample', '105-140 mg/dl'], ['Abnormal serum sample', 'Above 140 mg/dl']]
        )
    );

    $profiles['magnesium'] = coaBiochemistryProfile(
        [863],
        'MAGNESSIUM',
        'MAGNESIUM Reagent',
        'BGMAG',
        '044',
        'BIPL-COA-IP-26116-B MAG0326.doc',
        'BIPL-COA-FG-26114-B MAG0326.doc',
        coaBiochemistryTestRows(
            $twoBottleVisual,
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '2mg/dl (± 0.2 mg/dl)']],
            [['Control 2', '1.94-2.46 mg/dl'], ['Control 3', '3.69-4.72 mg/dl']],
            [['2 mg/dl', '1.8-2.2 mg/dl'], ['5 mg/dl', '4.5-5.5 mg/dl']],
            [['Normal serum Sample', '1.9-2.5 mg/dl'], ['Abnormal serum sample', 'Above 2.5 mg/dl']]
        )
    );

    $profiles['microprotein'] = coaBiochemistryProfile(
        [858, 859, 860, 1779, 1945],
        'MICROPROTEIN',
        'Micro-protein',
        'BGMIC',
        '045',
        'BIPL-COA-IP-26016-MIC0126.doc',
        'BIPL-COA-FG-26016-MIC0126.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1 and reagent 2 in separate glass bottle, along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '100.0 mg/dl ( ±5.0 mg/dl )']],
            [['CSF', '98 mg/dl'], ['CSF', '98 mg/dl']],
            [['100 mg/dl', '90-110 mg/dl'], ['200 mg/dl', '180-220 mg/dl']],
            [['Normal serum Sample', '10-50 mg/dl'], ['Abnormal serum sample', 'Above 50 mg/dl']]
        )
    );

    $profiles['phosphorus'] = coaBiochemistryProfile(
        [852],
        'PHOSPHORUS',
        'PHOSPHORUS Reagent',
        'BGPHO',
        '046',
        'BIPL-COA-IP-26115-B PHO0226.doc',
        'BIPL-COA-FG-26113-B PHO0226.doc',
        coaBiochemistryTestRows(
            $twoBottleVisual,
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '5 mg/dl (±0.5mg/dl)']],
            [['Control 1', '2.85-3.74 mg/dl'], ['Control 2', '6.16-7.78 mg/dl']],
            [['2 mg/dl', '1.8-2.2 mg/dl'], ['20 mg/dl', '18-22 mg/dl']],
            [['Normal serum Sample', '2.5-6.5 mg/dl'], ['Abnormal serum sample', 'Above 6.5 mg/dl']]
        )
    );

    $profiles['rf_turbi'] = coaBiochemistryProfile(
        [1030, 1031],
        'RF TURBI',
        'RF TURBI Reagent',
        'BGRFT',
        '130',
        'BIPL-COA-IP-26120-B RFT0126.doc',
        'BIPL-COA-FG-26118-B RFT0126.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1, reagent 2 in plastic bottle & calibrator in glass vial along with pack insert.',
            'No leakage should be observed in reagent 1, reagent 2 and calibrator bottles.',
            '<1.500',
            [['Standard/calibrators', '132 ( ±2 IU/ml )']],
            [['Control 1', '4.8 -7.2 IU/ml'], ['Control 2', '64-96 IU/ml']],
            [['160 IU/ml', '144-174 IU/ml']],
            [['Normal serum Sample', '00-20 IU/ml'], ['Abnormal serum sample', 'Above 20 IU/ml']]
        )
    );

    $profiles['sgot'] = coaBiochemistryProfile(
        [848, 849, 1437],
        'SGOT',
        'SGOT Reagent',
        'BGSGOT',
        '050',
        'BIPL-COA-IP-26155-B SGOT0826.doc',
        'BIPL-COA-FG-26152-B SGOT0826.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1 and reagent 2 in separate plastic bottles along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 1', '26-47.2 U/L'], ['Control 2', '128-229 U/L']],
            [['20 U/L', '18-22 U/L'], ['300 U/L', '270-330 U/L']],
            [['Normal serum Sample', '0-35 U/L'], ['Abnormal serum sample', 'Above 35 U/L']]
        )
    );

    $profiles['sgpt'] = coaBiochemistryProfile(
        [846, 847],
        'SGPT',
        'SGPT Reagent',
        'BGSGPT',
        '049',
        'BIPL-COA-IP-26137-B SGPT0726.doc',
        'BIPL-COA-FG-26139-B SGPT0726.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1 and reagent 2 in separate plastic bottles along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', 'NA']],
            [['Control 1', '17.5-30.8 U/L'], ['Control 2', '70.3-109 U/L']],
            [['20 U/L', '18-22 U/L'], ['300 U/L', '270-330 U/L']],
            [['Normal serum Sample', '0-40 U/L'], ['Abnormal serum sample', 'Above 40 U/L']]
        )
    );

    $sodiumIpRows = coaBiochemistryTestRows(
        'The kits should be packed in a box contains reagent 1 and reagent 2 in separate bottle along with pack insert.',
        $twoBottleLeakage,
        'NA',
        [['Standard/calibrators', '150.0 mmol/l (± 5.0 mmol/l)']],
        [['Control 1', '131-145 mmol/l'], ['Control 2', '149-165 mmol/l']],
        [['20 gm /dl', '18-22 mmol/l'], ['180 gm /dl', '162-198 mmol/l']],
        [['Normal serum Sample', '135-155 mmol/l'], ['Abnormal serum sample', 'Above 155 mmol/l']]
    );
    $sodiumFgRows = coaBiochemistryTestRows(
        'The kits should be packed in a box contains reagent 1 and reagent 2 in separate bottle along with pack insert.',
        $twoBottleLeakage,
        'NA',
        [['Standard/calibrators', '150.0 mmol/l (± 5.0 mmol/l)']],
        [['Control 1', '137-151 mmol/l'], ['Control 2', '154-170 mmol/l']],
        [['20 gm /dl', '18-22 mmol/l'], ['180 gm /dl', '162-198 mmol/l']],
        [['Normal serum Sample', '135-155 mmol/l'], ['Abnormal serum sample', 'Above 155 mmol/l']]
    );
    $profiles['sodium'] = coaBiochemistryProfile(
        [845, 1776],
        'SODIUM',
        'SODIUM Reagent',
        'BGSOD',
        '048',
        'BIPL-COA-IP-26117-B SOD0226.doc',
        'BIPL-COA-FG-26115-B SOD0226.doc',
        $sodiumIpRows,
        $sodiumFgRows
    );

    $profiles['total_protein'] = coaBiochemistryProfile(
        [842, 1780],
        'TOTAL PROTEIN',
        'TOTAL PROTEIN',
        'BGTP',
        '045',
        'BIPL-COA-IP-26156-B TP0726.doc',
        'BIPL-COA-FG-26153-B TP0726.doc',
        coaBiochemistryTestRows(
            $singleBottleVisual,
            $singleBottleLeakage,
            'NA',
            [['Standard/calibrators', '6 gm/dl (±0.2 mg/dl)']],
            [['Control 1', '5.97-7.17 gm/dl'], ['Control 2', '3.75 -4.57 gm/dl']],
            [['3 gm/dl', '2.7-3.3 mg/dl'], ['12 gm/dl', '10.8-13.2 mg/dl']],
            [['Normal serum Sample', '6.2-8.0 gm/dl'], ['Abnormal serum sample', 'Above 8.0 gm/dl']]
        )
    );

    $triglycerideRows = coaBiochemistryTestRows(
        'The kits should be packed in a box containing reagent 1 and reagent 2 in separate glass bottle, along with pack insert.',
        $twoBottleLeakage,
        'NA',
        [['Standard/calibrators', '200 mg/dl (±5 mg/dl)']],
        [['Control 2', '82.5-114 mg/dl'], ['Control 3', '223-307 mg/dl']],
        [['200 mg/dl', '180-220 mg/dl'], ['1000 mg/dl', '900-1100 mg/dl']],
        [['Normal serum Sample', '40-165 mg/dl'], ['Abnormal serum sample', 'Above 165 mg/dl']]
    );
    $profiles['triglyceride'] = coaBiochemistryProfile(
        [840, 841, 1568],
        'TRIGLYCERIDE',
        'Triglyceride Reagent',
        'BGTGL',
        '053',
        'BIPL-COA-IP-26149-B TGL0526 - Copy.doc',
        'BIPL-COA-FG-26148-B-TGL0526.doc',
        $triglycerideRows,
        coaBiochemistryOverrideSpecifications(
            $triglycerideRows,
            ['standard_1' => '200 mg/dl (± 5mg/dl)']
        )
    );

    $profiles['urea_berthelot'] = coaBiochemistryProfile(
        [836],
        'UREA BERTHELOT',
        'Urea Berthelot Reagent',
        'BGUREBRT',
        '054',
        'BIPL-COA-IP-26011-B-UREBRT0126.doc',
        'BIPL-COA-FG-26011-B-UREBRT0126.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box contains reagent 1, 2, 3 in separate plastic bottles and reagent 4 along with pack insert.',
            'No leakage should be observed in reagent 1, 2, 3 and reagent 4 bottles.',
            'NA',
            [['Standard/calibrators', '40 mg/dl (± 2 mg/dl)']],
            [['Control 2', '39.3-53.1 mg/dl'], ['Control 3', '101-137 mg/dl']],
            [['40 mg/dl', '36-44 mg/dl'], ['250 mg/dl', '225-275 mg/dl']],
            [['Normal serum Sample', '10-45 mg/dl'], ['Abnormal serum sample', 'Above 45 mg/dl']]
        )
    );

    $profiles['urea_uv'] = coaBiochemistryProfile(
        [834, 835, 1467],
        'UREA U.V',
        'UREA U.V. Reagent',
        'BGURE',
        '055',
        'BIPL-COA-IP-26148-B URE1026 - Copy.doc',
        'BIPL-COA-FG-26151-B URE1026.doc',
        coaBiochemistryTestRows(
            $threeBottleVisual,
            $threeBottleLeakage,
            'NA',
            [['Standard/calibrators', '50.0 mg/dl (± 2.0 mg/dl)']],
            [['Control 2', '40.2-54.4 mg/dl'], ['Control 3', '105-143 mg/dl']],
            [['50 mg/dl', '45-55 mg/dl'], ['250 mg/dl', '225-275 mg/dl']],
            [['Normal serum Sample', '15-45 mg/dl'], ['Abnormal serum sample', 'Above 45 mg/dl']]
        )
    );

    $profiles['uric_acid'] = coaBiochemistryProfile(
        [832, 833, 1438],
        'URIC ACID',
        'Uric Acid',
        'BGURI',
        '056',
        'BIPL-COA-IP-26145-B URI0926.doc',
        'BIPL-COA-FG-26147-B URI0926.doc',
        coaBiochemistryTestRows(
            'The kits should be packed in a box containing reagent 1 and reagent 2 in separate glass bottle, along with pack insert.',
            $twoBottleLeakage,
            'NA',
            [['Standard/calibrators', '6.0 mg/dl ( ±1.0 mg/dl )']],
            [['Control 2', '4.94-6.42 mg/dl'], ['Control 3', '7.91-10.3 mg/dl']],
            [['10 mg/dl', '9-11 mg/dl'], ['20 mg/dl', '18-22 mg/dl']],
            [['Normal serum Sample', '2.5-7.0 mg/dl'], ['Abnormal serum sample', 'Above 7.0 mg/dl']]
        )
    );

    return $profiles;
}

function coaBiochemistryMappedProductIds(): array
{
    $ids = [];
    foreach (coaBiochemistryProfiles() as $profile) {
        foreach ($profile['product_ids'] as $productId) {
            $ids[] = (int) $productId;
        }
    }
    sort($ids);
    return array_values(array_unique($ids));
}
