<?php

declare(strict_types=1);

require_once __DIR__ . '/renderer.php';
require_once dirname(__DIR__) . '/template_snapshot_common.php';

function coaTemplateNormalizeType(string $coaType): string
{
    $type = strtoupper(trim($coaType));
    if (!in_array($type, ['IP', 'FG'], true)) {
        throw new InvalidArgumentException('Invalid COA document type.');
    }
    return $type;
}

function coaTemplateSchemaReady(mysqli $conn): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $required = [
        ['coa_document_templates', 'layout_json'],
        ['coa_template_product_mappings', 'coa_type'],
        ['ip_coa_generation', 'coa_template_id'],
        ['ip_coa_generation', 'form_payload_json'],
        ['ip_coa_generation', 'template_snapshot_id'],
        ['fg_coa_generation', 'coa_template_id'],
        ['fg_coa_generation', 'form_payload_json'],
        ['fg_coa_generation', 'template_snapshot_id'],
    ];
    $stmt = $conn->prepare(
        'SELECT COUNT(*) AS found
         FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    if (!$stmt) {
        return $ready = false;
    }

    foreach ($required as [$table, $column]) {
        $stmt->bind_param('ss', $table, $column);
        $stmt->execute();
        if ((int) ($stmt->get_result()->fetch_assoc()['found'] ?? 0) !== 1) {
            $stmt->close();
            return $ready = false;
        }
    }
    $stmt->close();
    return $ready = true;
}

function coaTemplateRequireSchema(mysqli $conn): void
{
    if (!coaTemplateSchemaReady($conn)) {
        throw new RuntimeException(
            'The IP/FG COA template schema is not installed. Run the Biochemistry COA migration first.'
        );
    }
}

function coaTemplateDecodeLayout(string $layoutJson): array
{
    $layout = json_decode($layoutJson, true);
    $variant = is_array($layout) ? (string) ($layout['renderer_variant'] ?? '') : '';
    if (
        !is_array($layout)
        || (int) ($layout['schema_version'] ?? 0) < 1
        || (string) ($layout['renderer'] ?? '') !== 'structured_coa_html'
        || !in_array($variant, ['biochemistry', 'urine_strip', 'rapid_test', 'serology'], true)
        || !is_array($layout['profiles'] ?? null)
        || !is_array($layout['profile_families'] ?? null)
    ) {
        throw new RuntimeException('The mapped COA template definition is invalid.');
    }
    return $layout;
}

function coaTemplateResolveProfile(array $layout, int $productId, string $explicitFamilyKey = ''): array
{
    $reference = $layout['profiles'][(string) $productId] ?? null;
    $familyKey = is_array($reference) ? trim((string) ($reference['family_key'] ?? '')) : '';

    // Fall back to an explicitly provided family key (manual template selection or persisted mapping)
    if ($familyKey === '' && trim($explicitFamilyKey) !== '') {
        $familyKey = trim($explicitFamilyKey);
    }

    // If still no familyKey, but there is only 1 family in the layout, default to it
    if ($familyKey === '' && is_array($layout['profile_families'] ?? null) && count($layout['profile_families']) === 1) {
        $familyKey = (string) array_key_first($layout['profile_families']);
    }

    $profile = $familyKey !== '' ? ($layout['profile_families'][$familyKey] ?? null) : null;
    if (
        !is_array($profile)
        || (
            !is_array($profile['rows'] ?? null)
            && !is_array($profile['editable_field_keys'] ?? null)
        )
    ) {
        throw new RuntimeException('The selected product does not have a valid COA profile.');
    }
    $profile['family_key'] = $familyKey;
    return $profile;
}

function coaTemplateLoadById(mysqli $conn, int $templateId, int $productId, string $coaType, string $explicitFamilyKey = ''): array
{
    $type = coaTemplateNormalizeType($coaType);
    $stmt = $conn->prepare(
        'SELECT id, template_code, template_name, coa_type, version_no, document_no,
                source_directory, source_checksum, layout_json
         FROM coa_document_templates
         WHERE id = ? AND coa_type = ? AND status = 1 AND deleted_at IS NULL
         LIMIT 1'
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the COA template lookup.');
    }
    $stmt->bind_param('is', $templateId, $type);
    $stmt->execute();
    $template = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$template) {
        throw new DomainException('The saved COA template is no longer available.');
    }

    $layout = coaTemplateDecodeLayout((string) $template['layout_json']);
    if (strtoupper((string) ($layout['coa_type'] ?? '')) !== $type) {
        throw new RuntimeException('The COA template type does not match the requested document.');
    }
    $template['layout'] = $layout;
    $template['profile'] = coaTemplateResolveProfile($layout, $productId, $explicitFamilyKey);
    unset($template['layout_json']);
    return $template;
}

function coaTemplateResolveMappedTemplate(
    mysqli $conn,
    int $productId,
    string $coaType
): ?array {
    if ($productId <= 0 || !coaTemplateSchemaReady($conn)) {
        return null;
    }
    $type = coaTemplateNormalizeType($coaType);
    $stmt = $conn->prepare(
        'SELECT template.id, mapping.family_key
         FROM coa_template_product_mappings mapping
         INNER JOIN coa_document_templates template
            ON template.id = mapping.template_id
           AND template.coa_type = mapping.coa_type
           AND template.status = 1
           AND template.deleted_at IS NULL
         WHERE mapping.product_id = ?
           AND mapping.coa_type = ?
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         LIMIT 1'
    );
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('is', $productId, $type);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    $templateId = (int) ($row['id'] ?? 0);
    $familyKey = (string) ($row['family_key'] ?? '');
    if ($templateId <= 0) {
        return null;
    }

    try {
        return coaTemplateLoadById($conn, $templateId, $productId, $type, $familyKey);
    } catch (Throwable $exception) {
        // If template loading fails (e.g. unrecognised product profile), return null so manual template selection can be shown
        error_log('coaTemplateResolveMappedTemplate failed: ' . $exception->getMessage());
        return null;
    }
}

function coaTemplateDecodePayload(string|array|null $payload): array
{
    if (is_array($payload)) {
        return $payload;
    }
    $json = trim((string) $payload);
    if ($json === '') {
        return [];
    }
    if (strlen($json) > 1000000) {
        throw new InvalidArgumentException('The COA form payload is too large.');
    }
    $decoded = json_decode($json, true);
    if (!is_array($decoded)) {
        throw new InvalidArgumentException('The COA form payload is invalid.');
    }
    return $decoded;
}

function coaTemplateSanitizePayload(
    array $profile,
    string|array|null $payload,
    bool $requireComplete = true
): array
{
    $decoded = coaTemplateDecodePayload($payload);
    $submittedFields = is_array($decoded['fields'] ?? null) ? $decoded['fields'] : [];
    $allowed = [
        'metadata.manufacturing_date' => 100,
        'metadata.expiry_date' => 100,
        'approval.decision' => 20,
        'approval.comments' => 3000,
        // A 250 KB image becomes roughly 342 KB when encoded as a data URI.
        'approval.analysis_by' => 350000,
        'approval.analysis_by_name' => 200,
        'approval.verified_by' => 350000,
        'approval.verified_by_name' => 200,
    ];
    $required = [
        'metadata.manufacturing_date',
        'metadata.expiry_date',
        'approval.decision',
        'approval.analysis_by',
        'approval.verified_by',
    ];

    $profileFieldKeys = is_array($profile['editable_field_keys'] ?? null)
        ? $profile['editable_field_keys']
        : [];
    if ($profileFieldKeys === []) {
        foreach (($profile['rows'] ?? []) as $row) {
            if (($row['kind'] ?? 'test') === 'section') {
                continue;
            }
            $rowKey = trim((string) ($row['key'] ?? ''));
            if ($rowKey === '') {
                throw new RuntimeException('The mapped COA template contains an invalid test row.');
            }
            $profileFieldKeys[] = 'results.' . $rowKey;
        }
    }

    foreach ($profileFieldKeys as $profileFieldKey) {
        $fieldKey = trim((string) $profileFieldKey);
        if (
            $fieldKey === ''
            || !preg_match('/^(metadata|results|observations)\.[a-z0-9_.-]+$/', $fieldKey)
        ) {
            throw new RuntimeException('The mapped COA template contains an invalid editable field.');
        }
        $allowed[$fieldKey] = 2000;
        $required[] = $fieldKey;
    }

    $fields = [];
    foreach ($allowed as $fieldKey => $maximumLength) {
        $value = trim((string) ($submittedFields[$fieldKey] ?? ''));
        if (mb_strlen($value) > $maximumLength) {
            throw new InvalidArgumentException("The COA field {$fieldKey} is too long.");
        }
        $fields[$fieldKey] = $value;
    }

    // Fallback: If signature value is empty but signature name is provided, populate signature value
    if ($fields['approval.analysis_by'] === '' && !empty($fields['approval.analysis_by_name'])) {
        $fields['approval.analysis_by'] = $fields['approval.analysis_by_name'];
    }
    if ($fields['approval.verified_by'] === '' && !empty($fields['approval.verified_by_name'])) {
        $fields['approval.verified_by'] = $fields['approval.verified_by_name'];
    }

    $decision = strtoupper($fields['approval.decision']);
    if ($decision !== '' && !in_array($decision, ['APPROVED', 'REJECTED'], true)) {
        throw new InvalidArgumentException('Select Approved or Rejected in the COA document.');
    }
    $fields['approval.decision'] = $decision;

    if ($requireComplete) {
        foreach ($required as $fieldKey) {
            if (trim((string) ($fields[$fieldKey] ?? '')) === '') {
                throw new InvalidArgumentException('Complete every required field in the COA document.');
            }
        }
    }

    return [
        'schema_version' => 1,
        'fields' => $fields,
    ];
}

function coaTemplateValidateSubmission(
    mysqli $conn,
    int $productId,
    string $coaType,
    int $submittedTemplateId,
    string|array|null $submittedPayload,
    bool $requireComplete = true,
    string $submittedFamilyKey = ''
): ?array {
    $mapped = coaTemplateResolveMappedTemplate($conn, $productId, $coaType);
    if ($mapped === null) {
        $hasPayload = is_array($submittedPayload)
            ? $submittedPayload !== []
            : trim((string) $submittedPayload) !== '';
        if ($submittedTemplateId <= 0 && !$hasPayload) {
            return null;
        }
        // The user manually selected a template — load and persist the mapping
        if ($submittedTemplateId > 0 && trim($submittedFamilyKey) !== '') {
            $mapped = coaTemplateLoadById($conn, $submittedTemplateId, $productId, $coaType, $submittedFamilyKey);
            coaTemplatePersistProductMapping($conn, $submittedTemplateId, $productId, $coaType, $submittedFamilyKey);
        } else {
            throw new DomainException('This product is not mapped to an active COA template.');
        }
    }
    if ($submittedTemplateId <= 0 || $submittedTemplateId !== (int) $mapped['id']) {
        throw new DomainException('Open the mapped product COA template and complete it before submitting.');
    }

    return [
        'template_id' => (int) $mapped['id'],
        'payload' => coaTemplateSanitizePayload($mapped['profile'], $submittedPayload, $requireComplete),
        'template' => $mapped,
    ];
}

function coaTemplateValidateSnapshotSubmission(
    mysqli $conn,
    int $snapshotId,
    string $coaType,
    int $submittedTemplateId,
    string|array|null $submittedPayload,
    bool $requireComplete = true
): array {
    $type = coaTemplateNormalizeType($coaType);
    $snapshot = templateSnapshotLoad($conn, $snapshotId);
    if ($snapshot === null || (string) $snapshot['document_type'] !== $type . '_COA') {
        throw new DomainException('The saved COA template snapshot is unavailable.');
    }
    if ($submittedTemplateId !== (int) $snapshot['source_template_id']) {
        throw new DomainException('The submitted COA template does not match the saved controlled document.');
    }
    $template = [
        'id' => (int) $snapshot['source_template_id'],
        'template_code' => (string) $snapshot['template_code'],
        'template_name' => (string) $snapshot['template_name'],
        'document_no' => $snapshot['document_no'],
        'version_no' => $snapshot['version_no'],
        'layout' => $snapshot['layout'],
        'profile' => $snapshot['profile'],
    ];
    return [
        'template_id' => (int) $template['id'],
        'payload' => coaTemplateSanitizePayload($template['profile'], $submittedPayload, $requireComplete),
        'template' => $template,
    ];
}

function coaTemplatePrepareForm(
    array $template,
    string $coaType,
    array $sourceValues,
    array $payload = [],
    string $brandingLogoDataUri = ''
): array {
    return [
        'template_id' => (int) $template['id'],
        'template_code' => (string) $template['template_code'],
        'template_name' => (string) $template['template_name'],
        'coa_type' => coaTemplateNormalizeType($coaType),
        'layout' => $template['layout'] ?? [],
        'profile' => $template['profile'] ?? [],
        'source_values' => $sourceValues,
        'form_payload' => $payload,
        'branding_logo_data_uri' => $brandingLogoDataUri,
    ];
}

function coaTemplateDisplayBatchSize(mixed $size, mixed $unit): string
{
    $value = trim((string) $size);
    $unitValue = trim((string) $unit);
    return trim($value . ($unitValue !== '' ? ' ' . $unitValue : ''));
}

function coaTemplateLoadSavedForm(mysqli $conn, string $coaType, int $recordId): array
{
    $type = coaTemplateNormalizeType($coaType);
    $table = $type === 'IP' ? 'ip_coa_generation' : 'fg_coa_generation';
    $codeCol = $type === 'IP' ? 'coa_ip' : 'coa_fg';
    $sourceCol = $type === 'IP' ? 'source_bmr_work_item_id' : 'source_ip_coa_id';

    $stmt = $conn->prepare(
        "SELECT rec.id, rec.coa_template_id, rec.template_snapshot_id, rec.family_key,
                rec.product_name, rec.{$codeCol} AS coa_number,
                rec.batch_number, rec.batch_size, rec.test_date, rec.form_payload_json,
                u.short_name AS batch_unit,
                IFNULL(rec.product_id, 0) AS product_id
         FROM {$table} rec
         LEFT JOIN standard_units u ON u.id = rec.batch_size_unit
         WHERE rec.id = ? AND rec.deleted_at IS NULL
         LIMIT 1"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the saved COA lookup.');
    }
    $stmt->bind_param('i', $recordId);
    $stmt->execute();
    $record = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$record) {
        throw new DomainException('The saved COA record was not found.');
    }

    $templateId = (int) ($record['coa_template_id'] ?? 0);
    $payload = coaTemplateDecodePayload((string) ($record['form_payload_json'] ?? ''));
    $snapshotId = (int) ($record['template_snapshot_id'] ?? 0);
    $snapshot = null;
    if ($snapshotId > 0) {
        try {
            $snapshot = templateSnapshotLoad($conn, $snapshotId);
        } catch (Throwable $e) {
            error_log("Failed loading template snapshot {$snapshotId} for {$type} COA record {$recordId}: " . $e->getMessage());
        }
    }
    if ($snapshot !== null) {
        if ((string) $snapshot['document_type'] !== $type . '_COA') {
            throw new RuntimeException('The saved COA snapshot type is invalid.');
        }
        $template = [
            'id' => (int) $snapshot['source_template_id'],
            'template_code' => (string) $snapshot['template_code'],
            'template_name' => (string) $snapshot['template_name'],
            'document_no' => $snapshot['document_no'],
            'version_no' => $snapshot['version_no'],
            'layout' => $snapshot['layout'],
            'profile' => $snapshot['profile'],
        ];
    } else {
        $template = $templateId > 0
            ? coaTemplateLoadById($conn, $templateId, (int) $record['product_id'], $type, (string) ($record['family_key'] ?? ''))
            : coaTemplateResolveMappedTemplate($conn, (int) $record['product_id'], $type);
    }
    if (!$template) {
        throw new DomainException('The COA template used for this record is no longer available.');
    }

    $sourceValues = [
        'coa_number' => (string) ($record['coa_number'] ?? ''),
        'batch_number' => (string) ($record['batch_number'] ?? ''),
        'batch_size' => coaTemplateDisplayBatchSize(
            $record['batch_size'] ?? '',
            $record['batch_unit'] ?? ''
        ),
        'testing_date' => (string) ($record['test_date'] ?? ''),
    ];

    return coaTemplatePrepareForm($template, $type, $sourceValues, $payload);
}

/**
 * Persist a product-to-template mapping so future batches are automatically recognised.
 */
function coaTemplatePersistProductMapping(
    mysqli $conn,
    int $templateId,
    int $productId,
    string $coaType,
    string $familyKey = ''
): void {
    if ($templateId <= 0 || $productId <= 0) {
        return;
    }
    $type = coaTemplateNormalizeType($coaType);
    $family = trim($familyKey);
    $stmt = $conn->prepare(
        "INSERT INTO coa_template_product_mappings
            (template_id, product_id, coa_type, family_key, status, created_by, created_at)
         VALUES (?, ?, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             family_key = VALUES(family_key),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$stmt) {
        return;
    }
    $stmt->bind_param('iiss', $templateId, $productId, $type, $family);
    $stmt->execute();
    $stmt->close();
}

/**
 * List all active COA templates with their profile families for a given COA type.
 * Returns an array of templates, each with template info and available family keys.
 */
function coaTemplateListAvailable(mysqli $conn, string $coaType): array
{
    if (!coaTemplateSchemaReady($conn)) {
        return [];
    }
    $type = coaTemplateNormalizeType($coaType);
    $stmt = $conn->prepare(
        'SELECT id, template_code, template_name, coa_type, layout_json
         FROM coa_document_templates
         WHERE coa_type = ? AND status = 1 AND deleted_at IS NULL
         ORDER BY template_name ASC'
    );
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('s', $type);
    $stmt->execute();
    $result = $stmt->get_result();
    $templates = [];
    while ($row = $result->fetch_assoc()) {
        $layoutJson = (string) ($row['layout_json'] ?? '');
        try {
            $layout = coaTemplateDecodeLayout($layoutJson);
        } catch (Throwable) {
            continue;
        }
        $families = [];
        foreach (($layout['profile_families'] ?? []) as $familyKey => $familyProfile) {
            $families[] = [
                'family_key' => (string) $familyKey,
                'product_name' => (string) ($familyProfile['product_name'] ?? $familyKey),
                'source_document' => (string) ($familyProfile['source_document'] ?? ''),
            ];
        }
        if ($families === []) {
            continue;
        }
        $templates[] = [
            'id' => (int) $row['id'],
            'template_code' => (string) $row['template_code'],
            'template_name' => (string) $row['template_name'],
            'renderer_variant' => (string) ($layout['renderer_variant'] ?? ''),
            'families' => $families,
        ];
    }
    $stmt->close();
    return $templates;
}
