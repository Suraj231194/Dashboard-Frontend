<?php

declare(strict_types=1);

/**
 * Controlled Rapid Test COA profiles transcribed from /Rapid Test.
 * Source batch observations are excluded so the generated COA is a blank,
 * product-correct QC form.
 */

function coaRapidQualityRows(
    string $specimenType,
    string $specimenVolume,
    string $bufferVolume = '',
    string $assayTime = '15 Minutes',
    string $movement = '3-5 minutes',
    string $controlIntensity = '3+ - 4+'
): array {
    $rows = [
        ['key' => 'movement', 'serial' => '1.1', 'test' => 'Movement of sample', 'specification' => $movement],
        ['key' => 'control_intensity', 'serial' => '1.2', 'test' => 'Intensity of control line', 'specification' => $controlIntensity],
        ['key' => 'ghost_lines', 'serial' => '1.3', 'test' => 'Ghost lines', 'specification' => 'NA'],
        ['key' => 'background', 'serial' => '1.4', 'test' => 'Background', 'specification' => 'Should be Clear'],
        ['key' => 'specimen_type', 'serial' => '1.5', 'test' => 'Specimen Type', 'specification' => $specimenType],
        ['key' => 'specimen_volume', 'serial' => '1.6', 'test' => 'Specimen Volume', 'specification' => $specimenVolume],
    ];
    if ($bufferVolume !== '') {
        $rows[] = [
            'key' => 'buffer_volume',
            'serial' => '1.7',
            'test' => 'Buffer Volume',
            'specification' => $bufferVolume,
        ];
    }
    $rows[] = [
        'key' => 'assay_time',
        'serial' => $bufferVolume !== '' ? '1.8' : '1.7',
        'test' => 'Assay Time',
        'specification' => $assayTime,
    ];
    return $rows;
}

function coaRapidSampleGroup(
    string $key,
    string $title,
    int $sampleCount,
    array $observationColumns,
    string $specification,
    array $labels = []
): array {
    $rows = [];
    for ($index = 1; $index <= $sampleCount; $index++) {
        $cells = [];
        foreach ($observationColumns as $columnIndex => $_column) {
            $cells[] = [
                'key' => $key . '_sample_' . $index . '_observation_' . ($columnIndex + 1),
            ];
        }
        $rows[] = [
            'label' => (string) ($labels[$index - 1] ?? ('Sample ' . $index)),
            'cells' => $cells,
        ];
    }
    return [
        'key' => $key,
        'title' => $title,
        'observation_columns' => array_values($observationColumns),
        'specification' => $specification,
        'rows' => $rows,
    ];
}

function coaRapidCommonPerformance(
    int $nonReactiveCount = 8,
    int $reactiveCount = 5,
    string $readingTime = '15 minutes'
): array {
    return [
        coaRapidSampleGroup(
            'non_reactive',
            'Non-Reactive Samples',
            $nonReactiveCount,
            ['Appearance of Control Line', 'Appearance of Test Line'],
            "Reading should be within {$readingTime}; Only Control Line (C) should appear for a Negative Specimen."
        ),
        coaRapidSampleGroup(
            'reactive',
            'Reactive Samples',
            $reactiveCount,
            ['Appearance of Control & Test Line'],
            "Reading should be within {$readingTime}; Control Line (C) and Test Line (T) both should appear for a Positive Specimen."
        ),
    ];
}

function coaRapidEditableFieldKeys(array $qualityRows, array $performanceGroups, array $summaryRows): array
{
    $keys = [];
    foreach ($qualityRows as $row) {
        foreach (($row['result_keys'] ?? [(string) ($row['key'] ?? '')]) as $key) {
            if ((string) $key !== '') {
                $keys[] = 'results.' . (string) $key;
            }
        }
    }
    foreach ($performanceGroups as $group) {
        foreach (($group['rows'] ?? []) as $row) {
            foreach (($row['cells'] ?? []) as $cell) {
                $keys[] = 'observations.' . (string) $cell['key'];
            }
        }
    }
    foreach ($summaryRows as $row) {
        $keys[] = 'results.' . (string) $row['key'];
    }
    return $keys;
}

function coaRapidProfile(
    array $productIds,
    string $productName,
    string $productCode,
    string $stpReference,
    string $sourceDocument,
    string $physicalDescription,
    string $specimenType,
    string $specimenVolume,
    string $bufferVolume = '',
    string $assayTime = '15 Minutes',
    int $metadataRowCount = 10,
    int $nonReactiveCount = 8,
    int $reactiveCount = 5,
    array $document = [],
    ?array $performanceGroups = null,
    ?array $qualityRows = null,
    ?array $summaryRows = null
): array {
    $quality = $qualityRows ?? coaRapidQualityRows(
        $specimenType,
        $specimenVolume,
        $bufferVolume,
        $assayTime
    );
    $performance = $performanceGroups ?? coaRapidCommonPerformance(
        $nonReactiveCount,
        $reactiveCount,
        strtolower($assayTime)
    );
    $summary = $summaryRows ?? [
        ['key' => 'sensitivity', 'label' => 'Sensitivity', 'specification' => 'Report observed sensitivity'],
        ['key' => 'specificity', 'label' => 'Specificity', 'specification' => 'Report observed specificity'],
        [
            'key' => 'remarks',
            'label' => 'Remarks',
            'specification' => 'The product under report complies as per our standard specification.',
        ],
    ];
    return [
        'product_ids' => array_values(array_map('intval', $productIds)),
        'source_document' => $sourceDocument,
        'source_ip_document' => $sourceDocument,
        'source_fg_document' => $sourceDocument,
        'product_name' => $productName,
        'brand_name' => $metadataRowCount >= 10 ? 'Biogenix' : '',
        'product_code' => $productCode,
        'stp_reference' => $stpReference,
        'metadata_row_count' => $metadataRowCount,
        'page_count' => 2,
        'document' => $document,
        'physical_description' => $physicalDescription,
        'quality_rows' => $quality,
        'performance_groups' => $performance,
        'summary_rows' => $summary,
        'editable_field_keys' => coaRapidEditableFieldKeys($quality, $performance, $summary),
    ];
}

function coaRapidTestProfiles(): array
{
    $oldDocument = [
        'effective_date' => '03/04/2023',
        'review_date' => '03/04/2025',
    ];
    $newDocument = [
        'effective_date' => '03/04/2025',
        'review_date' => '02/04/2028',
    ];
    $profiles = [];

    $profiles['chikungunya_igm'] = coaRapidProfile(
        [1017, 2031], 'Chikungunya IgM Rapid Test', 'BGRCHIK', 'BIPL-FPSTP-007',
        'BIPL-COA-25161R-CHIK0325.doc',
        'Physical Checks (Visual inspection): Chikungunya IgM Rapid Test devices should be packed in Box contains 50 Pouches, 5ml buffer bottle along with Pack Insert.',
        'Serum/Plasma', '1 Drop (20-25ul)', '1 drops (30- 35 μl)', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['filariasis'] = coaRapidProfile(
        [1007], 'Filariasis IgG/IgM Rapid Test', 'BGRFIL', 'BIPL-FPSTP-103',
        'BIPL-COA-FG- 25175R FIL0425.doc',
        'Physical Checks (Visual inspection): Filariasis IgG/IgM Rapid Test devices should be packed in Box contains Pouches, 1 buffer bottle along with Pack Insert.',
        'Serum/Plasma/Whole blood', '1 Drop (25-30 μl)', '2 drops (50- 60 μl)', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['leishmania'] = coaRapidProfile(
        [980], 'Leishmania IgG/IgM Rapid Test', 'BGRLSM', 'BIPL-FPSTP-111',
        'BIPL-COA-FG-24144R LSM0124.doc',
        'Physical Checks (Visual inspection): Leishmania IgG/ IgM Rapid Test Kits should be packed in Box contains Pouches with 1 buffer bottle along with Pack Insert inside.',
        'Serum/Plasma', '1 drop', '2 drops (50- 60 μl)', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['toxoplasma'] = coaRapidProfile(
        [958], 'Toxoplasma IgG/IgM Rapid Test', 'BGRTOX', 'BIPL-FPSTP-116',
        'BIPL-COA-FG-24235R TOX0624.doc',
        'Physical Checks (Visual inspection): Toxoplasma IgG/IgM Rapid Test devices should be packed in Box contains Pouches,1 buffer bottle along with Pack Insert.',
        'Serum/Plasma', '10UL', '2 drops (50- 60 μl)', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['scrub_typhus'] = coaRapidProfile(
        [963, 964, 965], 'Scrub Typhus IgG/IgM Rapid Test', 'BGSTYM-UN', '',
        'BIPL-COA-FG-24270AR STYM0124.doc',
        'Physical Checks (Visual inspection): Sheet contains nitrocellulose membrane, Conjugate pad, sample pad,and absorbent pad pasted on PVC Laminate. Sheet should be sealed in Aluminum foil containing silica gel..',
        'Serum/Plasma', '1 Drop (20-25ul)', '1 drops (30- 35 μl)', '15 Minutes', 9, 8, 5, $oldDocument
    );
    $profiles['h_pylori_ab'] = coaRapidProfile(
        [1003], 'H. Pylori Ab Rapid Test', 'BGRHPAB', 'BIPL-FPSTP-106',
        'BIPL-COA-FG-24296R HPAB0324.doc',
        'Physical Checks (Visual inspection): H.Pylori AB Rapid Test devices should be packed in Box containing Pouches, 1 buffer bottle along with Pack Insert.',
        'Serum/Plasma', '1drop (20-25 μl)', '2-3 drops (50 - 60 μl)', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['h_pylori_ag'] = coaRapidProfile(
        [1002], 'H. Pylori Ag Rapid Test', 'BGRHPAG', 'BIPL-FPSTP-107',
        'BIPL-COA-FG-24297R HPAG0224.doc',
        'Physical Checks (Visual inspection): The H.pylori Ag Rapid kits should be packed in Box contains 25 Pouches, 25 buffer bottles of 1 ml each along with Pack insert.',
        'Fecal', '2 drop (60μl)', '', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['leptospira'] = coaRapidProfile(
        [979, 1646], 'Leptospira IgG/ IgM Rapid Test', 'BGRLEP', 'BIPL-FPSTP-112',
        'BIPL-COA-FG-24310R LEP0624.doc',
        'Physical Checks (Visual inspection): Leptospira IgG/ IgM Rapid Test Kits should be packed in Box contains 50 Pouches with 5ml buffer bottle along with Pack Insert inside.',
        'Serum/Plasma', '1 drops (20-25μl)', '2Drops (50-60ul)', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['fob'] = coaRapidProfile(
        [1006], 'FOB (Fecal Ocult Blood) Rapid Test', 'BGRFOB', 'BIPL-FPSTP-104',
        'BIPL-COA-FG-25008R-FOB0125.doc',
        'Physical Checks (Visual inspection): The FOB Rapid kits should be packed in Box contains 25 Pouches, 25 buffer bottles of 1 ml each along with Pack insert.',
        'Fecal', '2 drop (60μl)', '', '15 Minutes', 10, 8, 5, $oldDocument
    );
    $profiles['malaria_pf_pv'] = coaRapidProfile(
        [975, 976, 2000], 'Malaria Pf/Pv Ag Rapid Test', 'BGRMPV', 'BIPL-FPSTP-010',
        'BIPL-COA-FG-25090R MPV0925.docx',
        'Physical Checks (Visual inspection): Malaria PF/PV Rapid Test devices should be packed in Box contains Pouches, 1 buffer bottle along with Pack Insert.',
        'Whole blood', '5µl', '3 drops (50 - 60 μl)', '20 Minutes', 10, 6, 5, $newDocument
    );
    $profiles['troponin_i'] = coaRapidProfile(
        [956, 957], 'Troponin I Rapid Test', 'BGRTPI', 'BIPL-FPSTP-118',
        'BIPL-COA-FG-25092R TPNI0125.doc',
        'Physical Checks (Visual inspection): Troponin I Rapid Test devices should be packed in Box contains Pouches, 1 buffer bottle along with Pack Insert.',
        'Serum/Plasma/Whole blood', '1 Drop (20-25ul)', '1-2 drops (30- 60 μl)', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['hav_igm'] = coaRapidProfile(
        [1001], 'HAV IgM Rapid Test', '', 'BIPL-FPSTP-108',
        'BIPL-COA-FG-25097R HAV0125.doc',
        'Physical Checks (Visual inspection): HAV Rapid Test Kits should be packed in Box contains Pouches with 1 buffer bottle along with Pack Insert inside.',
        'Serum/Plasma', '10 µl', '2Drops (50-60 µl)', '15 Minutes', 8, 8, 5, $newDocument
    );
    $profiles['dengue_igg_igm'] = coaRapidProfile(
        [1010], 'Dengue IgG/IgM Rapid Test', 'BGRDGM', 'BIPL-FPSTP-004',
        'BIPL-COA-FG-25117R DGM0125.doc',
        'Physical Checks (Visual inspection): Dengue IgG/IgM Rapid Test devices should be packed in Box contains Pouches,1l buffer bottle along with Pack Insert.',
        'Serum/Plasma', '5UL', '2 drops (50- 60 μl)', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['syphilis_sp'] = coaRapidProfile(
        [960], 'Syphilis S/P Rapid Test', 'BGRSYPS', 'BIPL-FPSTP-006',
        'BIPL-COA-FG-25124R SYPS0425.doc',
        'Physical Checks (Visual inspection): The Syphilis S/P Rapid Test kits should be packed in Box contains Pouches, along with Pack Insert.',
        'Serum/plasma', '2-3drop (60-70 μl)', '', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['dengue_ns1'] = coaRapidProfile(
        [1009], 'Dengue NS1 Rapid Test', '', 'BIPL-FPSTP-002',
        'BIPL-COA-FG-25136R DNS0325.doc',
        'Physical Checks (Visual inspection): The Dengue NS1 Rapid Test kits should be packed in Box contains 50 Pouches, along with Pack Insert.',
        'Serum/Plasma', '2-3drop (60-70 μl)', '', '15 Minutes', 8, 8, 5, $newDocument
    );

    $dengueComboQuality = [
        [
            'serial' => '1.1', 'test' => 'Movement of sample',
            'result_keys' => ['movement_ns1', 'movement_igg_igm'],
            'result_labels' => ['Dengue NS1', 'Dengue IgG/IgM'], 'specification' => '< 2 minutes',
        ],
        [
            'serial' => '1.2', 'test' => 'Intensity of control line',
            'result_keys' => ['control_intensity_ns1', 'control_intensity_igg_igm'],
            'result_labels' => ['Dengue NS1', 'Dengue IgG/IgM'], 'specification' => '4+',
        ],
        [
            'serial' => '1.3', 'test' => 'Ghost lines',
            'result_keys' => ['ghost_lines_ns1', 'ghost_lines_igg_igm'],
            'result_labels' => ['Dengue NS1', 'Dengue IgG/IgM'], 'specification' => 'NA',
        ],
        [
            'serial' => '1.4', 'test' => 'Background',
            'result_keys' => ['background_ns1', 'background_igg_igm'],
            'result_labels' => ['Dengue NS1', 'Dengue IgG/IgM'], 'specification' => 'Should be Clear',
        ],
    ];
    $dengueColumns = ['Control Line', 'Test Line I', 'Test Line II', 'Test Line III'];
    $dengueGroups = [
        coaRapidSampleGroup('dcm_ns1_controls', 'Controls (Dengue NS1)', 2, $dengueColumns,
            'Reading time - 15 min; Only control line should appear for a negative Specimen; Control Line and test lines both should appear for a positive Specimen.',
            ['Positive', 'Negative']),
        coaRapidSampleGroup('dcm_igg_igm_controls', 'Controls (Dengue IgG IgM)', 3, $dengueColumns,
            'Reading time - 15 min; respective control and test lines should appear for positive specimens; only the Control line should appear for a Negative Specimen.',
            ['Positive IgG', 'Positive IgM', 'Negative']),
        coaRapidSampleGroup('dcm_ns1_normal', 'Clinical Samples (Dengue NS1 Normal)', 5, $dengueColumns,
            'Reading time - 15 min; Only Control line should appear for a Negative Specimen.'),
        coaRapidSampleGroup('dcm_ns1_abnormal', 'Clinical Samples (Dengue NS1 Abnormal)', 2, $dengueColumns,
            'Reading time - 15 min; Control Line and test both should appear for a positive Specimen.'),
        coaRapidSampleGroup('dcm_igg_igm_normal', 'Clinical Samples (Dengue IgG/IgM Normal)', 5, $dengueColumns,
            'Reading time - 15 min; Only Control line should appear for a Negative Specimen.'),
        coaRapidSampleGroup('dcm_igg_igm_abnormal', 'Clinical Samples (Dengue IgG/IgM Abnormal)', 3, $dengueColumns,
            'Reading time - 15 min; Control Line and respective test lines should appear for a positive Specimen.'),
    ];
    $profiles['dengue_combo'] = coaRapidProfile(
        [1011, 1012], 'Dengue Combo Rapid Test', 'BGRDCM', 'BIPL-FPSTP-005',
        'BIPL-COA-FG-25162R DCM0425.doc',
        'Physical Checks (Visual inspection): The Dengue Combo Test kits should be packed in a rectangular Box containing 10 Pouches; 1 ml buffer Bottle along with pack insert.',
        '', '', '', '', 10, 0, 0, $newDocument, $dengueGroups, $dengueComboQuality,
        [
            ['key' => 'sensitivity', 'label' => 'Sensitivity', 'specification' => 'NLT 98%'],
            ['key' => 'specificity', 'label' => 'Specificity', 'specification' => 'NLT 98%'],
            ['key' => 'remarks', 'label' => 'Remarks', 'specification' => 'The product under report complies as per our standard specification.'],
        ]
    );
    $profiles['dengue_combo']['page_count'] = 3;

    $profiles['hev_igm'] = coaRapidProfile(
        [988], 'HEV IgM Rapid Test', 'BGRHEVM', 'BIPL-FPSTP-109',
        'BIPL-COA-FG-25164R HEV0325.doc',
        'Physical Checks (Visual inspection): HEV Rapid Test Kits should be packed in Box contains Pouches with 1 buffer bottle along with Pack Insert inside.',
        'Serum/Plasma', '10 µl', '2Drops (50-60 µl)', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['hiv_1_2'] = coaRapidProfile(
        [985, 986, 1858, 1885], 'HIV ½ Rapid Test', 'BGRHIV', 'BIPL-FPSTP-009',
        'BIPL-COA-FG-25172R HIV1525.doc',
        'Physical Checks (Visual inspection): The kits should be packed in Box contains Pouches with HIV 1/2 Rapid Test devices and 1 Buffer bottle along with pack insert.',
        'Serum/Plasma/whole blood', '1 Drop (25 μl)', '2 Drops (60 μl)', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['hbsag'] = coaRapidProfile(
        [997, 998, 1884], 'HBsAg Rapid Test', 'BGRHBS', 'BIPL-FPSTP-011',
        'BIPL-COA-FG-25174R HBS1025.doc',
        'Physical Checks (Visual inspection): The HBsAg Rapid Test kits should be packed in Box contains Pouches, along with Pack Insert.',
        'Serum/ Plasma', '2-3drop (60-70 μl)', '', '15 Minutes', 10, 8, 5,
        array_replace($newDocument, ['revision_no' => '01'])
    );
    $profiles['hcv_wb'] = coaRapidProfile(
        [989], 'HCV Rapid Test (WB)', 'BGRHCVW', 'BIPL-FPSTP-010',
        'BIPL-COA-FG-25186R HCVW1725.docx',
        'Physical Checks (Visual inspection): The HCV Rapid Test kits should be packed in Box contains 50 Pouches, along with 5ml buffer bottle and Pack Insert.',
        'Serum/ Plasma/whole Blood', '1drop (20-25 μl)', '2-3 drops (50-60 μl)', '15 Minutes', 10, 7, 5, $newDocument
    );

    $hcgGroups = [
        coaRapidSampleGroup(
            'hcg_controls',
            'Controls',
            4,
            ['Result (Time of appearance of Control & Test Line)'],
            'Positive controls: Control Line (C) and Test Line (T) should appear within 5 minutes. Negative control: only Control Line (C) should appear.',
            ['100 mIU/ml Positive', '50 mIU/ml Positive', '25 mIU/ml Positive', 'Negative']
        ),
        coaRapidSampleGroup(
            'hcg_negative',
            'Negative Samples',
            8,
            ['Appearance of Control Line', 'Appearance of Test Line'],
            'Reading should be within 5 minutes; Only Control Line (C) should appear for a Negative Specimen.'
        ),
        coaRapidSampleGroup(
            'hcg_positive',
            'Positive Samples',
            3,
            ['Appearance of Control & Test Line'],
            'Reading should be within 5 minutes; Control Line (C) and Test Line (T) both should appear for a Positive Specimen.',
            ['Neat Positive', 'Sample 1', 'Sample 2']
        ),
    ];
    $profiles['hcg_mini'] = coaRapidProfile(
        [995, 1576], 'hCG Rapid Test - Mini', 'BGRHCGM', 'BIPL-FPSTP-114',
        'BIPL-COA-FG-25227R HCGM0825.doc',
        'Physical Checks (Visual inspection): HCG Rapid kits should be packed in Box contains 50 Pouches along with Pack Insert.',
        'Urine Sample', '2-3 drops', '', '5 Minutes', 10, 0, 0, $newDocument, $hcgGroups,
        coaRapidQualityRows('Urine Sample', '2-3 drops', '', '5 Minutes', '<1 minute'),
        [
            ['key' => 'sensitivity', 'label' => 'Sensitivity of color display (25 mIU/ml)', 'specification' => '3-5 min'],
            ['key' => 'specificity', 'label' => 'Specificity', 'specification' => 'Pass'],
            ['key' => 'remarks', 'label' => 'Remarks', 'specification' => 'The product under report complies as per our standard specification.'],
        ]
    );
    $profiles['hcg_mini']['page_count'] = 3;

    $profiles['typhoid'] = coaRapidProfile(
        [953], 'Typhoid IgG/IgM Rapid Test', 'BGRTYP', 'BIPL-FPSTP-008',
        'BIPL-COA-FG-25228R TYP0625.doc',
        'Physical Checks (Visual inspection): Typhoid IgG/IgM Rapid Test devices should be packed in Box contains 50/30 Pouches, 5ml buffer bottle along with Pack Insert.',
        'Serum/Plasma/Whole blood', '1 Drop (20-25ul)', '1 drops (30- 35 μl)', '15 Minutes', 10, 8, 5, $newDocument
    );
    $profiles['hcv_sp'] = coaRapidProfile(
        [990, 1883], 'HCV Rapid Test', 'BGRHCV', 'BIPL-FPSTP-010',
        'HCV0325.doc',
        'Physical Checks (Visual inspection): The HCV Rapid Test kits should be packed in Box contains Pouches, along Pack Insert.',
        'Serum/ Plasma', '2-3drop (60-70 μl)', '', '15 Minutes', 10, 8, 5,
        array_replace($newDocument, ['review_date' => '03/04/2028', 'supersedes' => 'Revision:01'])
    );
    $profiles['syphilis_wb'] = coaRapidProfile(
        [959], 'Syphilis W/B Rapid Test', 'BGRSYPW', 'BIPL-FPSTP-006',
        'SYPW0225.doc',
        'Physical Checks (Visual inspection): The Syphilis WB Rapid Test kits should be packed in Box contains Pouches, 1 buffer bottle along with Pack Insert.',
        'whole blood', '1drop (20-25 μl)', '2-3 drops (50 - 60 μl)', '15 Minutes', 10, 8, 5,
        array_replace($newDocument, ['supersedes' => 'Revision:01'])
    );

    return $profiles;
}

function coaRapidTestMappedProductIds(): array
{
    $ids = [];
    foreach (coaRapidTestProfiles() as $profile) {
        array_push($ids, ...($profile['product_ids'] ?? []));
    }
    $ids = array_values(array_unique(array_map('intval', $ids)));
    sort($ids);
    return $ids;
}
