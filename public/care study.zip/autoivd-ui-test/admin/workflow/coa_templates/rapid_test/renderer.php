<?php

declare(strict_types=1);

function coaTemplateRenderRapidQuality(array $profile, array $fields, bool $editable): string
{
    $rows = is_array($profile['quality_rows'] ?? null) ? $profile['quality_rows'] : [];
    $html = '<table class="coa-v1-results coa-rapid-quality"><thead><tr>'
        . '<th class="coa-v1-serial">Sr. No.</th><th>Test</th><th>Result</th>'
        . '<th>Specification</th></tr></thead><tbody>'
        . '<tr class="coa-v1-section-row"><td>1.</td><td colspan="3">'
        . coaTemplateEscape($profile['physical_description'] ?? '') . '</td></tr>';
    foreach ($rows as $row) {
        $keys = is_array($row['result_keys'] ?? null)
            ? $row['result_keys']
            : [(string) ($row['key'] ?? '')];
        $labels = is_array($row['result_labels'] ?? null) ? $row['result_labels'] : [];
        $resultHtml = '';
        foreach ($keys as $index => $key) {
            if (isset($labels[$index])) {
                $resultHtml .= '<div class="coa-rapid-result-label">'
                    . coaTemplateEscape($labels[$index]) . '</div>';
            }
            $resultHtml .= coaTemplateInput(
                'results.' . (string) $key,
                $fields,
                $editable,
                'Enter result'
            );
        }
        $html .= '<tr><td class="coa-v1-serial">' . coaTemplateEscape($row['serial'] ?? '')
            . '</td><td>' . coaTemplateEscape($row['test'] ?? '') . '</td><td>'
            . $resultHtml . '</td><td>'
            . coaTemplateEscape($row['specification'] ?? '') . '</td></tr>';
    }
    return $html . '</tbody></table>';
}

function coaTemplateRenderRapidGroups(array $groups, array $fields, bool $editable): string
{
    $html = '';
    foreach ($groups as $group) {
        $columns = is_array($group['observation_columns'] ?? null)
            ? $group['observation_columns']
            : [];
        $html .= '<table class="coa-v1-results coa-rapid-performance"><thead><tr>'
            . '<th>' . coaTemplateEscape($group['title'] ?? '') . '</th>';
        foreach ($columns as $column) {
            $html .= '<th>' . coaTemplateEscape($column) . '</th>';
        }
        $html .= '<th>Specification</th></tr></thead><tbody>';
        foreach (($group['rows'] ?? []) as $rowIndex => $row) {
            $html .= '<tr><td>' . coaTemplateEscape($row['label'] ?? '') . '</td>';
            foreach (($row['cells'] ?? []) as $cell) {
                $html .= '<td>' . coaTemplateInput(
                    'observations.' . (string) ($cell['key'] ?? ''),
                    $fields,
                    $editable,
                    'Observation'
                ) . '</td>';
            }
            $html .= '<td>'
                . ($rowIndex === 0 ? coaTemplateEscape($group['specification'] ?? '') : '&nbsp;')
                . '</td></tr>';
        }
        $html .= '</tbody></table>';
    }
    return $html;
}

function coaTemplateRenderRapidSummary(array $rows, array $fields, bool $editable): string
{
    $html = '<table class="coa-v1-results coa-rapid-summary"><tbody>';
    foreach ($rows as $row) {
        $key = 'results.' . (string) ($row['key'] ?? '');
        $html .= '<tr><td><strong>' . coaTemplateEscape($row['label'] ?? '')
            . '</strong></td><td>' . coaTemplateInput($key, $fields, $editable, 'Enter result')
            . '</td><td>' . coaTemplateEscape($row['specification'] ?? '') . '</td></tr>';
    }
    return $html . '</tbody></table>';
}

function coaTemplateRenderRapidTest(array $form, bool $editable = false): string
{
    $layout = is_array($form['layout'] ?? null) ? $form['layout'] : [];
    $profile = is_array($form['profile'] ?? null) ? $form['profile'] : [];
    if ($profile === []) {
        return '';
    }
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    if (is_array($profile['document'] ?? null)) {
        $document = array_replace($document, $profile['document']);
    }
    $fields = coaTemplateFields($form);
    $sourceValues = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $logoDataUri = trim((string) ($form['branding_logo_data_uri'] ?? ''));
    $groups = is_array($profile['performance_groups'] ?? null)
        ? $profile['performance_groups']
        : [];
    $requestedPages = max(2, (int) ($profile['page_count'] ?? 2));

    $groupChunks = [$groups];
    if ($requestedPages >= 3 && count($groups) > 1) {
        $splitAt = (int) ceil(count($groups) / 2);
        $groupChunks = [array_slice($groups, 0, $splitAt), array_slice($groups, $splitAt)];
    }
    $pageCount = 1 + count($groupChunks);
    $pages = [];

    $firstBody = coaTemplateHeader($document, $logoDataUri)
        . coaTemplateMetadata($profile, $fields, $sourceValues, $editable)
        . coaTemplateRenderRapidQuality($profile, $fields, $editable);
    if ($editable) {
        $firstBody .= '<div class="coa-v1-source-note">Controlled source: '
            . coaTemplateEscape($profile['source_document'] ?? '') . '</div>';
    }
    $pages[] = '<section class="coa-v1-page" data-page="1"><div class="coa-v1-page-body">'
        . $firstBody . '</div>' . coaTemplateFooter(1, $pageCount) . '</section>';

    foreach ($groupChunks as $chunkIndex => $chunk) {
        $pageNumber = $chunkIndex + 2;
        $body = coaTemplateHeader($document, $logoDataUri)
            . coaTemplateRenderRapidGroups($chunk, $fields, $editable);
        if ($pageNumber === $pageCount) {
            $body .= coaTemplateRenderRapidSummary(
                is_array($profile['summary_rows'] ?? null) ? $profile['summary_rows'] : [],
                $fields,
                $editable
            );
            $body .= coaTemplateApproval($fields, $editable);
        }
        $pages[] = '<section class="coa-v1-page" data-page="' . $pageNumber
            . '"><div class="coa-v1-page-body">' . $body . '</div>'
            . coaTemplateFooter($pageNumber, $pageCount) . '</section>';
    }

    $extraStyles = '<style>'
        . '.coa-rapid-quality,.coa-rapid-performance,.coa-rapid-summary{margin-bottom:2mm}'
        . '.coa-rapid-performance{font-size:7pt}'
        . '.coa-rapid-performance th{text-align:center;background:#f1f5f9}'
        . '.coa-rapid-performance td{padding:.55mm .65mm}'
        . '.coa-rapid-performance th:first-child{width:18%}'
        . '.coa-rapid-performance th:last-child{width:28%}'
        . '.coa-rapid-result-label{font-size:6.5pt;font-weight:700;margin:.4mm 0}'
        . '.coa-rapid-summary td:first-child{width:24%}'
        . '.coa-rapid-summary td:nth-child(2){width:25%}'
        . '</style>';
    return coaTemplateStyles() . $extraStyles
        . '<div class="coa-v1-document" data-coa-template="1" data-coa-type="'
        . coaTemplateEscape($form['coa_type'] ?? '') . '">'
        . implode('', $pages) . '</div>';
}
