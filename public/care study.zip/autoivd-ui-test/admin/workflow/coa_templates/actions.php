<?php

declare(strict_types=1);

if (!defined('COA_TEMPLATE_AJAX_CONTEXT')) {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/bmr_bpr_common.php';
require_once __DIR__ . '/common.php';

bmrBprRequireLogin();
bmrBprValidateCsrf();

$action = trim((string) ($_POST['coaTemplateAction'] ?? ''));

try {
    switch ($action) {
        case 'open_mapped_template':
            coaTemplateRequireSchema($conn);
            $coaType = coaTemplateNormalizeType((string) ($_POST['coa_type'] ?? ''));
            $sourceId = (int) ($_POST['source_id'] ?? 0);
            if ($sourceId <= 0) {
                throw new InvalidArgumentException('Invalid source record.');
            }

            if ($coaType === 'IP') {
                bmrBprRequirePermission($conn, 'ip_coa_generation_add');
                $stmt = bmrBprPrepare(
                    $conn,
                    "SELECT wi.id, wi.status, request.product_id, request.product_name,
                            request.lot_number AS batch_number, request.batch_size,
                            unit.short_name AS batch_unit
                     FROM bmr_bpr_work_items wi
                     INNER JOIN bmr_bpr_requests request
                        ON request.id = wi.request_id AND request.deleted_at IS NULL
                     LEFT JOIN standard_units unit ON unit.id = request.batch_size_unit_id
                     WHERE wi.id = ? AND wi.form_type = 'BMR' AND wi.deleted_at IS NULL
                     LIMIT 1"
                );
                $stmt->bind_param('i', $sourceId);
                $stmt->execute();
                $source = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if (
                    !$source
                    || !in_array(strtoupper((string) $source['status']), ['IN_PROCESS', 'COMPLETE'], true)
                ) {
                    throw new DomainException('The BMR must be In-Process or Complete before opening its IP COA.');
                }
                $initialPayload = [];
            } else {
                bmrBprRequirePermission($conn, 'fg_coa_generation_add');
                $stmt = bmrBprPrepare(
                    $conn,
                    "SELECT ip.id, ip.product_id, ip.product_name,
                            ip.batch_number, ip.batch_size, ip.test_date,
                            ip.form_payload_json, unit.short_name AS batch_unit
                     FROM ip_coa_generation ip
                     LEFT JOIN standard_units unit ON unit.id = ip.batch_size_unit
                     LEFT JOIN fg_coa_generation fg
                        ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
                     WHERE ip.id = ?
                       AND ip.source_bmr_work_item_id IS NOT NULL
                       AND ip.workflow_status = 'COMPLETED'
                       AND ip.deleted_at IS NULL
                       AND fg.id IS NULL
                     LIMIT 1"
                );
                $stmt->bind_param('i', $sourceId);
                $stmt->execute();
                $source = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if (!$source) {
                    throw new DomainException('The source IP COA is unavailable or already has an FG COA.');
                }
                $sourcePayload = coaTemplateDecodePayload((string) ($source['form_payload_json'] ?? ''));
                $sourceFields = is_array($sourcePayload['fields'] ?? null)
                    ? $sourcePayload['fields']
                    : [];
                $initialPayload = [
                    'schema_version' => 1,
                    'fields' => array_filter([
                        'metadata.manufacturing_date' => (string) (
                            $sourceFields['metadata.manufacturing_date'] ?? ''
                        ),
                        'metadata.expiry_date' => (string) (
                            $sourceFields['metadata.expiry_date'] ?? ''
                        ),
                    ], static fn(string $value): bool => trim($value) !== ''),
                ];
            }

            $productId = (int) ($source['product_id'] ?? 0);

            // Check for manual template selection via POST
            $manualTemplateId = (int) ($_POST['template_id'] ?? 0);
            $manualFamilyKey = trim((string) ($_POST['family_key'] ?? ''));
            $saveMappingFlag = (string) ($_POST['save_mapping'] ?? '1');

            $template = null;
            if ($manualTemplateId > 0 && $manualFamilyKey !== '') {
                // User manually selected a template — load it with the explicit family key
                $template = coaTemplateLoadById($conn, $manualTemplateId, $productId, $coaType, $manualFamilyKey);
                // Persist the mapping so future batches auto-resolve
                if ($saveMappingFlag !== '0' && $productId > 0) {
                    coaTemplatePersistProductMapping($conn, $manualTemplateId, $productId, $coaType, $manualFamilyKey);
                }
            } else {
                $template = coaTemplateResolveMappedTemplate($conn, $productId, $coaType);
            }
            $availableTemplates = coaTemplateListAvailable($conn, $coaType);
            if ($template === null) {
                // Return available templates so the frontend can show the template picker
                bmrBprJson('success', '', [
                    'has_template' => false,
                    'needs_selection' => true,
                    'product_id' => $productId,
                    'product_name' => (string) ($source['product_name'] ?? ''),
                    'available_templates' => $availableTemplates,
                    'message' => "Select a {$coaType} COA template for this product to continue.",
                ]);
            }

            $sourceValues = [
                'coa_number' => 'Assigned automatically on save',
                'batch_number' => (string) ($source['batch_number'] ?? ''),
                'batch_size' => coaTemplateDisplayBatchSize(
                    $source['batch_size'] ?? '',
                    $source['batch_unit'] ?? ''
                ),
                'testing_date' => trim((string) ($_POST['testing_date'] ?? ''))
                    ?: (string) (($source['test_date'] ?? '') ?: date('Y-m-d')),
            ];
            $logoDataUri = function_exists('bmrBprBrandingLogoDataUri')
                ? bmrBprBrandingLogoDataUri($conn)
                : '';
            $form = coaTemplatePrepareForm(
                $template,
                $coaType,
                $sourceValues,
                $initialPayload,
                $logoDataUri
            );
            bmrBprJson('success', '', [
                'has_template' => true,
                'template_id' => (int) $template['id'],
                'template_code' => (string) $template['template_code'],
                'template_name' => (string) $template['template_name'],
                'family_key' => (string) ($template['profile']['family_key'] ?? ''),
                'product_name' => (string) ($template['profile']['product_name'] ?? ''),
                'source_document' => (string) ($template['profile']['source_document'] ?? ''),
                'rendered_html' => coaTemplateRender($form, true),
                'available_templates' => $availableTemplates,
            ]);

        case 'open_saved_template':
            coaTemplateRequireSchema($conn);
            $coaType = coaTemplateNormalizeType((string) ($_POST['coa_type'] ?? ''));
            $recordId = (int) ($_POST['record_id'] ?? 0);
            if ($recordId <= 0) {
                throw new InvalidArgumentException('Invalid COA draft record.');
            }
            if ($coaType === 'IP') {
                bmrBprRequirePermission($conn, 'ip_coa_generation_edit');
                $sql = "SELECT id, source_bmr_work_item_id AS source_id, coa_ip AS coa_number,
                               dept_id, product_name, batch_number, batch_size, batch_size_unit,
                               test_date, tested_by, review_approved_by, remark, workflow_status
                        FROM ip_coa_generation
                        WHERE id = ? AND deleted_at IS NULL LIMIT 1";
            } else {
                bmrBprRequirePermission($conn, 'fg_coa_generation_edit');
                $sql = "SELECT id, source_ip_coa_id AS source_id, coa_fg AS coa_number,
                               product_id, live_stock_id, dept_id, product_name, batch_number,
                               batch_size, batch_size_unit, test_date, tested_by,
                               review_approved_by, remark, workflow_status
                        FROM fg_coa_generation
                        WHERE id = ? AND deleted_at IS NULL LIMIT 1";
            }
            $recordStmt = bmrBprPrepare($conn, $sql);
            $recordStmt->bind_param('i', $recordId);
            $recordStmt->execute();
            $record = $recordStmt->get_result()->fetch_assoc();
            $recordStmt->close();
            if (!$record) {
                throw new DomainException('The COA draft is no longer available.');
            }
            if (strtoupper((string) ($record['workflow_status'] ?? '')) !== 'DRAFT') {
                throw new DomainException('Only draft COA documents can be resumed.');
            }

            $form = coaTemplateLoadSavedForm($conn, $coaType, $recordId);
            $form['branding_logo_data_uri'] = function_exists('bmrBprBrandingLogoDataUri')
                ? bmrBprBrandingLogoDataUri($conn)
                : '';
            $fields = is_array($form['fields'] ?? null) ? $form['fields'] : [];
            if (empty($record['tested_by'])) {
                $record['tested_by'] = trim((string) ($fields['approval.analysis_by_name'] ?? ''));
                if ($record['tested_by'] === '' && !empty($fields['approval.analysis_by']) && !coaTemplateIsImageValue((string) $fields['approval.analysis_by'])) {
                    $record['tested_by'] = trim((string) $fields['approval.analysis_by']);
                }
            }
            if (empty($record['review_approved_by'])) {
                $record['review_approved_by'] = trim((string) ($fields['approval.verified_by_name'] ?? ''));
                if ($record['review_approved_by'] === '' && !empty($fields['approval.verified_by']) && !coaTemplateIsImageValue((string) $fields['approval.verified_by'])) {
                    $record['review_approved_by'] = trim((string) $fields['approval.verified_by']);
                }
            }
            if (empty($record['remark'])) {
                $record['remark'] = trim((string) ($fields['approval.comments'] ?? ($fields['results.remarks'] ?? '')));
            }
            bmrBprJson('success', '', [
                'has_template' => true,
                'template_id' => (int) $form['template_id'],
                'template_code' => (string) $form['template_code'],
                'template_name' => (string) $form['template_name'],
                'family_key' => (string) ($form['profile']['family_key'] ?? ''),
                'product_name' => (string) ($form['profile']['product_name'] ?? $record['product_name']),
                'source_document' => (string) ($form['profile']['source_document'] ?? ''),
                'rendered_html' => coaTemplateRender($form, true),
                'record' => $record,
            ]);

        case 'get_available_templates':
            coaTemplateRequireSchema($conn);
            $coaType = coaTemplateNormalizeType((string) ($_POST['coa_type'] ?? ''));
            $availableTemplates = coaTemplateListAvailable($conn, $coaType);
            bmrBprJson('success', '', [
                'templates' => $availableTemplates,
            ]);

        default:
            bmrBprJson('error', 'Unsupported COA template action.', [], 400);
    }
} catch (InvalidArgumentException|DomainException $exception) {
    bmrBprJson('error', $exception->getMessage(), [], 422);
} catch (Throwable $exception) {
    error_log('COA template action failed: ' . $exception->getMessage());
    bmrBprJson('error', 'Unable to load the product COA template.', [], 500);
}
