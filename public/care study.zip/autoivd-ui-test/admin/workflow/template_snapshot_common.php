<?php

declare(strict_types=1);

require_once __DIR__ . '/bmr_bpr_legacy_layout.php';

function templateSnapshotUser(mysqli $conn, int $userId): array
{
    $name = trim((string) ($_SESSION['user_name'] ?? $_SESSION['username'] ?? $_SESSION['name'] ?? ''));
    $email = trim((string) ($_SESSION['user_email'] ?? $_SESSION['email'] ?? ''));
    if ($userId > 0 && ($name === '' || $email === '')) {
        $stmt = $conn->prepare('SELECT name, email FROM users WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc() ?: [];
        $stmt->close();
        $name = $name ?: trim((string) ($row['name'] ?? ''));
        $email = $email ?: trim((string) ($row['email'] ?? ''));
    }
    return [
        'id' => max(0, $userId),
        'name' => $name ?: 'System Authorized Operator',
        'email' => $email !== '' ? $email : null,
    ];
}

function templateSnapshotChecksum(array $values): string
{
    return hash('sha256', json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
}

function templateSnapshotInsert(mysqli $conn, array $data, int $userId): int
{
    $layoutJson = json_encode($data['layout'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $profileJson = json_encode($data['profile'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $metadataJson = json_encode($data['metadata'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $documentType = (string) $data['document_type'];
    $sourceTemplateId = (int) $data['source_template_id'];
    $productId = (int) ($data['product_id'] ?? 0);
    $familyKey = trim((string) ($data['family_key'] ?? ''));
    $uuid = sprintf(
        '%08s-%04s-4%03s-%04x-%012s',
        bin2hex(random_bytes(4)),
        bin2hex(random_bytes(2)),
        substr(bin2hex(random_bytes(2)), 1, 3),
        (hexdec(bin2hex(random_bytes(2))) & 0x3fff) | 0x8000,
        bin2hex(random_bytes(6))
    );
    $user = templateSnapshotUser($conn, $userId);
    $ist = new DateTimeImmutable('now', new DateTimeZone('Asia/Kolkata'));
    $createdAtIst = $ist->format('Y-m-d H:i:s') . ' IST';
    $stmt = $conn->prepare(
        'INSERT INTO template_snapshots
         (snapshot_uuid, document_type, source_template_id, template_code, template_name,
          document_no, version_no, issue_no, effective_date, product_id, product_name,
          batch_number, lot_number, pack_size, family_key, profile_name, selection_source,
          renderer, renderer_variant, schema_version, layout_json, profile_json, metadata_json,
          checksum, created_by_user_id, created_by_user_name, created_by_user_email, created_at_ist)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, 0), ?, ?, ?, ?, NULLIF(?, \'\'),
                 ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $templateCode = (string) ($data['template_code'] ?? '');
    $templateName = (string) ($data['template_name'] ?? '');
    $documentNo = isset($data['document_no']) && trim((string) $data['document_no']) !== '' ? trim((string) $data['document_no']) : null;
    $versionNo = isset($data['version_no']) && trim((string) $data['version_no']) !== '' ? trim((string) $data['version_no']) : null;
    $issueNo = isset($data['issue_no']) && trim((string) $data['issue_no']) !== '' ? trim((string) $data['issue_no']) : null;
    $effectiveDate = trim((string) ($data['effective_date'] ?? '')) ?: null;
    $productName = (string) ($data['product_name'] ?? '');
    $batchNumber = isset($data['batch_number']) && trim((string) $data['batch_number']) !== '' ? trim((string) $data['batch_number']) : null;
    $lotNumber = isset($data['lot_number']) && trim((string) $data['lot_number']) !== '' ? trim((string) $data['lot_number']) : null;
    $packSize = isset($data['pack_size']) && trim((string) $data['pack_size']) !== '' ? trim((string) $data['pack_size']) : null;
    $profileName = isset($data['profile_name']) && trim((string) $data['profile_name']) !== '' ? trim((string) $data['profile_name']) : null;
    $selectionSource = (string) ($data['selection_source'] ?? 'PREMAPPED');
    $renderer = (string) ($data['renderer'] ?? 'structured_html');
    $rendererVariant = isset($data['renderer_variant']) && trim((string) $data['renderer_variant']) !== '' ? trim((string) $data['renderer_variant']) : null;
    $schemaVersion = max(1, (int) ($data['schema_version'] ?? 1));
    $creatorId = (int) $user['id'];
    $creatorName = (string) $user['name'];
    $creatorEmail = $user['email'];
    $checksum = templateSnapshotChecksum([
        'snapshot_uuid' => $uuid,
        'document_type' => $documentType,
        'source_template_id' => $sourceTemplateId,
        'template_code' => $templateCode,
        'template_name' => $templateName,
        'document_no' => $documentNo,
        'version_no' => $versionNo,
        'issue_no' => $issueNo,
        'effective_date' => $effectiveDate,
        'product_id' => $productId > 0 ? $productId : null,
        'product_name' => $productName,
        'batch_number' => $batchNumber,
        'lot_number' => $lotNumber,
        'pack_size' => $packSize,
        'family_key' => $familyKey !== '' ? $familyKey : null,
        'profile_name' => $profileName,
        'selection_source' => $selectionSource,
        'renderer' => $renderer,
        'renderer_variant' => $rendererVariant,
        'schema_version' => $schemaVersion,
        'layout_json' => $layoutJson,
        'profile_json' => $profileJson,
        'metadata_json' => $metadataJson,
        'created_by_user_id' => $creatorId,
        'created_by_user_name' => $creatorName,
        'created_by_user_email' => $creatorEmail !== null && $creatorEmail !== '' ? $creatorEmail : null,
        'created_at_ist' => $createdAtIst,
    ]);
    $stmt->bind_param(
        'ssissssssisssssssssissssisss',
        $uuid, $documentType, $sourceTemplateId, $templateCode, $templateName,
        $documentNo, $versionNo, $issueNo, $effectiveDate, $productId, $productName,
        $batchNumber, $lotNumber, $packSize, $familyKey, $profileName, $selectionSource,
        $renderer, $rendererVariant, $schemaVersion, $layoutJson, $profileJson, $metadataJson,
        $checksum, $creatorId, $creatorName, $creatorEmail, $createdAtIst
    );
    $stmt->execute();
    $id = (int) $conn->insert_id;
    $stmt->close();
    return $id;
}

function templateSnapshotLoad(mysqli $conn, int $snapshotId): ?array
{
    if ($snapshotId <= 0) return null;
    $stmt = $conn->prepare('SELECT * FROM template_snapshots WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $snapshotId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$row) return null;
    $row['layout'] = json_decode((string) $row['layout_json'], true) ?: [];
    $row['profile'] = json_decode((string) $row['profile_json'], true) ?: [];
    $row['metadata'] = json_decode((string) ($row['metadata_json'] ?? ''), true) ?: [];

    $canonicalValues = [
        'snapshot_uuid' => (string) $row['snapshot_uuid'],
        'document_type' => (string) $row['document_type'],
        'source_template_id' => (int) $row['source_template_id'],
        'template_code' => (string) $row['template_code'],
        'template_name' => (string) $row['template_name'],
        'document_no' => $row['document_no'] !== null && $row['document_no'] !== '' ? (string) $row['document_no'] : null,
        'version_no' => $row['version_no'] !== null && $row['version_no'] !== '' ? (string) $row['version_no'] : null,
        'issue_no' => $row['issue_no'] !== null && $row['issue_no'] !== '' ? (string) $row['issue_no'] : null,
        'effective_date' => $row['effective_date'] !== null && $row['effective_date'] !== '' ? (string) $row['effective_date'] : null,
        'product_id' => isset($row['product_id']) && (int) $row['product_id'] > 0 ? (int) $row['product_id'] : null,
        'product_name' => (string) $row['product_name'],
        'batch_number' => $row['batch_number'] !== null && $row['batch_number'] !== '' ? (string) $row['batch_number'] : null,
        'lot_number' => $row['lot_number'] !== null && $row['lot_number'] !== '' ? (string) $row['lot_number'] : null,
        'pack_size' => $row['pack_size'] !== null && $row['pack_size'] !== '' ? (string) $row['pack_size'] : null,
        'family_key' => $row['family_key'] !== null && $row['family_key'] !== '' ? (string) $row['family_key'] : null,
        'profile_name' => $row['profile_name'] !== null && $row['profile_name'] !== '' ? (string) $row['profile_name'] : null,
        'selection_source' => (string) $row['selection_source'],
        'renderer' => (string) $row['renderer'],
        'renderer_variant' => $row['renderer_variant'] !== null && $row['renderer_variant'] !== '' ? (string) $row['renderer_variant'] : null,
        'schema_version' => (int) $row['schema_version'],
        'layout_json' => (string) $row['layout_json'],
        'profile_json' => (string) $row['profile_json'],
        'metadata_json' => (string) $row['metadata_json'],
        'created_by_user_id' => (int) $row['created_by_user_id'],
        'created_by_user_name' => (string) $row['created_by_user_name'],
        'created_by_user_email' => $row['created_by_user_email'] !== null && $row['created_by_user_email'] !== '' ? (string) $row['created_by_user_email'] : null,
        'created_at_ist' => (string) $row['created_at_ist'],
    ];

    $storedChecksum = (string) ($row['checksum'] ?? '');
    if (hash_equals($storedChecksum, templateSnapshotChecksum($canonicalValues))) {
        return $row;
    }

    // Candidate checks for legacy snapshots created prior to type normalization
    $legacyCandidates = [];

    // Legacy candidate 1: version_no as integer (when version_no was stored as int in templates)
    if (isset($canonicalValues['version_no']) && is_numeric($canonicalValues['version_no'])) {
        $c = $canonicalValues;
        $c['version_no'] = (int) $canonicalValues['version_no'];
        $legacyCandidates[] = $c;
        if (isset($canonicalValues['document_no']) && is_numeric($canonicalValues['document_no'])) {
            $c2 = $c;
            $c2['document_no'] = (int) $canonicalValues['document_no'];
            $legacyCandidates[] = $c2;
        }
    }

    // Legacy candidate 2: document_no as integer
    if (isset($canonicalValues['document_no']) && is_numeric($canonicalValues['document_no'])) {
        $c = $canonicalValues;
        $c['document_no'] = (int) $canonicalValues['document_no'];
        $legacyCandidates[] = $c;
    }

    // Legacy candidate 3: raw row values exactly as retrieved from database
    $rawValues = [
        'snapshot_uuid' => (string) $row['snapshot_uuid'],
        'document_type' => (string) $row['document_type'],
        'source_template_id' => (int) $row['source_template_id'],
        'template_code' => (string) $row['template_code'],
        'template_name' => (string) $row['template_name'],
        'document_no' => $row['document_no'],
        'version_no' => $row['version_no'],
        'issue_no' => $row['issue_no'],
        'effective_date' => $row['effective_date'],
        'product_id' => isset($row['product_id']) ? (int) $row['product_id'] : null,
        'product_name' => (string) $row['product_name'],
        'batch_number' => $row['batch_number'],
        'lot_number' => $row['lot_number'],
        'pack_size' => $row['pack_size'],
        'family_key' => $row['family_key'],
        'profile_name' => $row['profile_name'],
        'selection_source' => (string) $row['selection_source'],
        'renderer' => (string) $row['renderer'],
        'renderer_variant' => $row['renderer_variant'],
        'schema_version' => (int) $row['schema_version'],
        'layout_json' => (string) $row['layout_json'],
        'profile_json' => (string) $row['profile_json'],
        'metadata_json' => (string) $row['metadata_json'],
        'created_by_user_id' => (int) $row['created_by_user_id'],
        'created_by_user_name' => (string) $row['created_by_user_name'],
        'created_by_user_email' => $row['created_by_user_email'],
        'created_at_ist' => (string) $row['created_at_ist'],
    ];
    $legacyCandidates[] = $rawValues;
    if (isset($rawValues['version_no']) && is_numeric($rawValues['version_no'])) {
        $c = $rawValues;
        $c['version_no'] = (int) $rawValues['version_no'];
        $legacyCandidates[] = $c;
    }

    foreach ($legacyCandidates as $candidate) {
        if (hash_equals($storedChecksum, templateSnapshotChecksum($candidate))) {
            return $row;
        }
    }

    throw new RuntimeException('The controlled template snapshot failed its integrity check.');
}

function templateSnapshotCreateBmrBpr(
    mysqli $conn,
    string $formType,
    int $templateId,
    int $productId,
    string $productName,
    string $packSize,
    int $userId,
    string $selectionSource = 'PREMAPPED'
): int {
    $type = strtoupper($formType);
    $stmt = $conn->prepare('SELECT * FROM bmr_templates WHERE id = ? AND form_type = ? LIMIT 1');
    $stmt->bind_param('is', $templateId, $type);
    $stmt->execute();
    $template = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$template) throw new DomainException("The selected {$type} template is unavailable.");
    $layout = json_decode((string) $template['layout_json'], true) ?: [];
    $layout = bmrBprNormalizeLegacyLayout($layout);
    $profile = function_exists('bmrBprStructuredProfile') ? bmrBprStructuredProfile($layout, $productId) : [];
    if (function_exists('bmrBprIsStructuredLayout') && bmrBprIsStructuredLayout($layout) && $profile === []) {
        $families = is_array($layout['profile_families'] ?? null) ? $layout['profile_families'] : [];
        $profiles = is_array($layout['profiles'] ?? null) ? $layout['profiles'] : [];
        $familyKey = $families !== [] ? (string) array_key_first($families) : '';
        $fallback = $familyKey !== '' ? (array) $families[$familyKey] : (array) reset($profiles);
        if ($fallback === []) throw new DomainException("The selected {$type} template has no usable profile.");
        $fallback['product_name'] = $productName;
        $fallback['pack_size'] = $packSize;
        if ($familyKey !== '') {
            $layout['profiles'][(string) $productId] = [
                'family_key' => $familyKey,
                'product_name' => $productName,
                'pack_size' => $packSize,
            ];
        } else {
            $layout['profiles'][(string) $productId] = $fallback;
        }
        $profile = bmrBprStructuredProfile($layout, $productId);
    }
    return templateSnapshotInsert($conn, [
        'document_type' => $type, 'source_template_id' => $templateId,
        'template_code' => $template['template_code'] ?? '', 'template_name' => $template['template_name'] ?? '',
        'document_no' => $template['document_no'] ?? null, 'version_no' => $template['revision_no'] ?? null,
        'issue_no' => $template['issue_no'] ?? null, 'effective_date' => $template['effective_date'] ?? null,
        'product_id' => $productId, 'product_name' => $productName, 'pack_size' => $packSize,
        'selection_source' => $selectionSource, 'renderer' => $layout['renderer'] ?? 'legacy_pages',
        'renderer_variant' => $layout['renderer_variant'] ?? null, 'schema_version' => $layout['schema_version'] ?? 1,
        'layout' => $layout, 'profile' => $profile,
        'metadata' => [
            'source_pdf_path' => $template['source_pdf_path'] ?? null,
            'page_asset_path' => $template['page_asset_path'] ?? null,
            'mfr_reference' => $template['mfr_reference'] ?? null,
            'page_count' => $template['page_count'] ?? null,
        ],
    ], $userId);
}

function templateSnapshotCreateCoa(
    mysqli $conn,
    string $coaType,
    array $template,
    int $productId,
    string $productName,
    string $batchNumber,
    int $userId,
    string $selectionSource = 'PREMAPPED'
): int {
    $type = strtoupper($coaType) . '_COA';
    $layout = (array) ($template['layout'] ?? []);
    $profile = (array) ($template['profile'] ?? []);
    $familyKey = (string) ($profile['family_key'] ?? '');
    return templateSnapshotInsert($conn, [
        'document_type' => $type, 'source_template_id' => (int) $template['id'],
        'template_code' => $template['template_code'] ?? '', 'template_name' => $template['template_name'] ?? '',
        'document_no' => $template['document_no'] ?? null, 'version_no' => $template['version_no'] ?? null,
        'product_id' => $productId, 'product_name' => $productName, 'batch_number' => $batchNumber,
        'family_key' => $familyKey, 'profile_name' => $profile['product_name'] ?? null,
        'selection_source' => $selectionSource, 'renderer' => $layout['renderer'] ?? 'structured_coa_html',
        'renderer_variant' => $layout['renderer_variant'] ?? null, 'schema_version' => $layout['schema_version'] ?? 1,
        'layout' => $layout, 'profile' => $profile,
    ], $userId);
}
