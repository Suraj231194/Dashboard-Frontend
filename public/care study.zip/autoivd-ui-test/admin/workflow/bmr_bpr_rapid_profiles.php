<?php

declare(strict_types=1);

/**
 * Audited, code-only Rapid Test BMR/BPR catalogue.
 *
 * Source: /rapid (finished rapid tests, uncut sheets and under-process
 * documents). Source files are used for the catalogue audit only; the live
 * form renderer has no PDF, DOC/DOCX or page-image dependency.
 */

function bmrBprRapidItems(array $rows, string $group = ''): array
{
    $items = [];
    foreach ($rows as $index => $row) {
        [$name, $quantity, $unit] = array_pad($row, 3, '');
        $key = strtolower((string) preg_replace('/[^a-z0-9]+/i', '_', (string) $name));
        $key = trim($key, '_') ?: 'item_' . ($index + 1);
        $item = [
            'key' => $key,
            'name' => (string) $name,
            'quantity' => (string) $quantity,
            'unit' => (string) $unit,
        ];
        if ($group !== '') {
            $item['group'] = $group;
        }
        $items[] = $item;
    }
    return $items;
}

function bmrBprRapidFinishedBmr(
    string $name,
    string $code,
    string $description,
    string $source,
    string $buffer = 'Assay Buffer'
): array {
    $ingredients = bmrBprRapidItems([
        [$name . ' Uncut Sheet / Laminate', '10', 'Nos.'],
        [$buffer, '125', 'ml'],
        ['HDPE Cassette (Top & Bottom)', '1000', 'Nos.'],
        ['Printed Aluminium Pouch', '1000', 'Nos.'],
        ['Silica Gel (0.5 gm)', '1000', 'Nos.'],
        ['Buffer Bottle with Cap and Stopper', '25', 'Nos.'],
        ['Buffer Bottle Label', '25', 'Nos.'],
        ['Packing Box', '25', 'Nos.'],
        ['Packing Box Label', '25', 'Nos.'],
        ['Pack Insert', '25', 'Nos.'],
    ]);
    return [
        'product_name' => $name,
        'product_code' => $code,
        'description' => $description,
        'mfr_reference' => 'BIPL-MFRIP-RAPID',
        'source_document' => $source,
        'source_group' => 'rapid/rapidtest',
        'page_count' => 6,
        'standard_batch' => '1000 Tests',
        'ingredients' => $ingredients,
        'reagent_contents' => $name . ' laminate, ' . $buffer,
        'manufacturing_steps' => [
            'Verify line clearance, environmental conditions and the approved status of all dispensed materials.',
            'Cut the coated laminate into 3 mm strips under controlled temperature and humidity.',
            'Fix each strip in the lower cassette, close with the upper cassette and verify proper pressing.',
            'Place each test device with activated silica gel and the applicable dropper, swab or sample applicator in the printed pouch.',
            'Seal the filled pouches at the validated sealing temperature and inspect every seal.',
            'Fill the approved buffer into clean bottles, close, label and submit the representative sample to QC.',
            'Reconcile all in-process and packing materials and transfer the accepted bulk devices for packing.',
        ],
        'page3_step_count' => 4,
    ];
}

function bmrBprRapidFinishedBpr(
    string $name,
    string $code,
    string $description,
    string $source,
    string $buffer = 'Assay Buffer'
): array {
    $reagents = bmrBprRapidItems([
        [$name . ' Uncut Sheet / Laminate', '10', 'Nos.'],
        [$buffer, '125', 'ml'],
    ], 'In-process material / Raw material');
    $packing = bmrBprRapidItems([
        ['Packing Box', '25', 'Nos.'],
        ['Packing Box Label', '25', 'Nos.'],
        ['HDPE Cassette (Top & Bottom)', '1000', 'Nos.'],
        ['Silica Gel (0.5 gm)', '1000', 'Nos.'],
        ['Printed Aluminium Pouch', '1000', 'Nos.'],
        ['Buffer Bottle with Cap and Stopper', '25', 'Nos.'],
        ['Buffer Bottle Label', '25', 'Nos.'],
        ['Pack Insert', '25', 'Nos.'],
    ], 'Packing material');
    $reagentQuantities = array_column($reagents, 'quantity', 'key');
    $packingQuantities = array_column($packing, 'quantity', 'key');
    return [
        'product_name' => $name,
        'product_code' => $code,
        'description' => $description,
        'mfr_reference' => 'BIPL-MFRFG-RAPID',
        'source_document' => $source,
        'source_group' => 'rapid/rapidtest',
        'page_count' => 12,
        'standard_batch' => '1000 Tests',
        'pack_size' => '25 Kits x 40 Tests',
        'standard_yield' => 'NLT 98%',
        'kit_content' => 'Test device, ' . $buffer . ', Pack Insert',
        'reagents' => $reagents,
        'packing_materials' => $packing,
        'reagent_quantities' => $reagentQuantities,
        'packing_quantities' => $packingQuantities,
        'equipment' => [
            ['name' => 'Cutter Machine'],
            ['name' => 'Cassette Pressing Machine'],
            ['name' => 'Pouch Sealing Machine'],
            ['name' => 'Domino Printing Machine'],
        ],
        'page3_material_count' => 6,
    ];
}

function bmrBprRapidUncutBmr(
    string $name,
    string $code,
    string $description,
    string $source
): array {
    $ingredients = bmrBprRapidItems([
        ['Nitrocellulose Membrane', '320', 'mtr'],
        ['Blank Laminates', '1000', 'Nos.'],
        ['Sample Pad', '1000', 'Nos.'],
        ['Conjugate Pad', '1000', 'Nos.'],
        ['Approved Antigen / Antibody', 'As per MFR', 'mg'],
        ['Colloidal Gold Conjugate', 'As per MFR', 'ml'],
        ['Phosphate / Tris Buffer Salts', 'As per MFR', 'g'],
        ['Sucrose', '50', 'g'],
        ['Sodium Azide', '1', 'g'],
        ['De-ionized Water', 'Q.S.', 'ml'],
    ]);
    return [
        'product_name' => $name,
        'product_code' => $code,
        'description' => $description,
        'mfr_reference' => 'BIPL-MFRIP-UNCUT',
        'source_document' => $source,
        'source_group' => 'rapid/Uncut Sheet',
        'page_count' => 6,
        'standard_batch' => '1000 Sheets',
        'ingredients' => $ingredients,
        'reagent_contents' => 'Coated membrane, gold conjugate, sample and conjugate pads, laminate',
        'manufacturing_steps' => [
            'Prepare and verify the phosphate or Tris working buffer at the specified pH.',
            'Prepare the test-line and control-line coating solutions using approved antigen or antibody stocks.',
            'Coat the nitrocellulose membrane at the approved dispensing rate and dry under controlled conditions.',
            'Prepare the colloidal-gold conjugate, block it and verify its optical density before use.',
            'Treat the conjugate and sample pads with the approved buffer, then dry completely.',
            'Assemble membrane, conjugate pad, sample pad and absorbent pad on the laminate without gaps or overlaps.',
            'Cut and inspect representative strips, run in-process controls and attach the QC requisition.',
            'Pack accepted uncut sheets with desiccant, identify the lot and transfer them to the packing stage.',
        ],
        'page3_step_count' => 4,
    ];
}

function bmrBprRapidUncutBpr(
    string $name,
    string $code,
    string $description,
    string $source
): array {
    $reagents = bmrBprRapidItems([
        [$name, '1000', 'Sheets'],
        ['Applicable Assay / Running Buffer', 'As per MFR', 'ml'],
    ], 'In-process material / Raw material');
    $packing = bmrBprRapidItems([
        ['Packing / Shipper Box', '1', 'Nos.'],
        ['Packing Box Label', '10', 'Nos.'],
        ['Aluminium Bag', '20', 'Nos.'],
        ['Butter Paper', '20', 'Nos.'],
        ['Silica Gel (0.5 gm)', '500', 'Nos.'],
    ], 'Packing material');
    return [
        'product_name' => $name,
        'product_code' => $code,
        'description' => $description,
        'mfr_reference' => 'BIPL-MFRFG-UNCUT',
        'source_document' => $source,
        'source_group' => 'rapid/Uncut Sheet',
        'page_count' => 10,
        'standard_batch' => '1000 Sheets',
        'pack_size' => '10 Packs x 100 Sheets',
        'standard_yield' => 'NLT 98%',
        'kit_content' => 'Uncut Sheets',
        'reagents' => $reagents,
        'packing_materials' => $packing,
        'reagent_quantities' => array_column($reagents, 'quantity', 'key'),
        'packing_quantities' => array_column($packing, 'quantity', 'key'),
        'equipment' => [
            ['name' => 'Hot Air Oven'],
            ['name' => 'Pouch Sealing Machine'],
            ['name' => 'Domino Printing Machine'],
        ],
        'page3_material_count' => 5,
    ];
}

function bmrBprRapidCatalog(): array
{
    $approval = [
        'prepared_by' => 'Durgesh Singh Pal',
        'checked_by' => 'Brijesh Pandey',
        'approved_by' => 'Sanjay Kumar Yadav',
    ];
    $bmrAttachments = [
        'Material requisition note (process order)',
        'Line clearance check lists',
        'IP/RM COA (whatever is applicable)',
        'Requisition to QC for testing of intermediate samples',
        'QA batch manufacturing review record',
    ];
    $bprAttachments = [
        'Material requisition note (process order)',
        'QA batch production review record',
        'Final product COA',
        'Batch Release certificate',
    ];
    // IDs below are the active FIN.RAPID catalogue rows in the configured ERP
    // database. Variants sharing one supplied master form deliberately reuse
    // the same source profile while remaining independently selectable.
    $finished = [
        'typhoid' => [[1222, 1223], 'Typhoid IgG/IgM Rapid Test', 'BGRTYP', 'Qualitative detection of IgG and IgM antibodies to Salmonella typhi.', 'Typhoid IgG IgM'],
        'troponin' => [[1218, 1219, 1220], 'Troponin I Rapid Test', 'BGRTNI', 'Qualitative detection of cardiac Troponin I.', 'Troponin I'],
        'toxoplasma' => [[1217], 'Toxoplasma IgG/IgM Rapid Test', 'BGRTXO', 'Qualitative detection of IgG and IgM antibodies to Toxoplasma gondii.', 'Toxoplasma IgG IgM Rapid Test'],
        'syphilis' => [[1215, 1216], 'Syphilis Rapid Test', 'BGRSYP', 'Qualitative detection of antibodies to Treponema pallidum.', 'Syphilis Rapid Test'],
        'sickle' => [[1212, 1213, 1214], 'Sickle Cell Rapid Test', 'BGRSIC', 'Rapid screening test for sickle haemoglobin.', 'Sickle cell Rapid'],
        'scrub' => [[1209, 1210], 'Scrub Typhus IgG/IgM Rapid Test', 'BGRSCR', 'Qualitative detection of IgG and IgM antibodies to Orientia tsutsugamushi.', 'Scrub typhus IgG IgM'],
        'malaria_pfpv' => [[1193, 1194, 1195], 'Malaria Pf/Pv Ag Rapid Test', 'BGRMPV', 'Qualitative detection and differentiation of Plasmodium falciparum and P. vivax antigens.', 'Malaria Pf Pv Ag'],
        'malaria_pfpan' => [[1192], 'Malaria Pf/PAN Rapid Test', 'BGRMPN', 'Qualitative detection and differentiation of P. falciparum and pan-malarial antigens.', 'Malaria Pf PAN'],
        'leptospira' => [[1188], 'Leptospira IgG/IgM Rapid Test', 'BGRLEP', 'Qualitative detection of IgG and IgM antibodies to Leptospira.', 'Leptospira IgG IgM'],
        'leishmania' => [[1186, 1187], 'Leishmania IgG/IgM Rapid Test', 'BGRLEI', 'Qualitative detection of antibodies to Leishmania.', 'Leishmania IgG IgM'],
        'hiv' => [[1176, 1177, 1178, 1179], 'HIV 1/2 Rapid Test', 'BGRHIV', 'Qualitative detection of antibodies to HIV-1 and HIV-2.', 'HIV 1 2'],
        'hev' => [[1175], 'HEV IgM Rapid Test', 'BGRHEV', 'Qualitative detection of IgM antibodies to Hepatitis E virus.', 'HEV IgM'],
        'hcv' => [[1172, 1173, 1174], 'HCV Rapid Test', 'BGRHCV', 'Qualitative detection of antibodies to Hepatitis C virus.', 'HCV Rapid Test'],
        'hcg' => [[1168, 1169, 1170, 1171, 1184], 'hCG Rapid Test', 'BGRHCG', 'Qualitative detection of human chorionic gonadotropin.', 'HCG'],
        'hbsag' => [[1165, 1166], 'HBsAg Rapid Test', 'BGRHBS', 'Qualitative detection of Hepatitis B surface antigen.', 'HbsAg Rapid Test'],
        'hav' => [[1163], 'HAV IgM Rapid Test', 'BGRHAV', 'Qualitative detection of IgM antibodies to Hepatitis A virus.', 'HAV IgM'],
        'hpylori_ag' => [[1162], 'H. pylori Ag Rapid Test', 'BGRHPA', 'Qualitative detection of Helicobacter pylori antigen.', 'H Pylori Ag Rapid Test'],
        'hpylori_ab' => [[1161], 'H. pylori Ab Rapid Test', 'BGRHPB', 'Qualitative detection of antibodies to Helicobacter pylori.', 'H Pylori Ab Rapid Test'],
        'fob' => [[1155], 'FOB Rapid Test', 'BGRFOB', 'Qualitative detection of human occult blood in faecal specimens.', 'FOB Rapid Test'],
        'filaria' => [[1157], 'Filariasis IgG/IgM Rapid Test', 'BGRFIL', 'Qualitative detection of IgG and IgM antibodies to filarial parasites.', 'Filariasis IgG IgM Rapid Test'],
        'dengue_ns1' => [[1151], 'Dengue NS1 Rapid Test', 'BGRDNS', 'Qualitative detection of Dengue virus NS1 antigen.', 'Dengue NS1'],
        'dengue_igg_igm' => [[1149, 1150], 'Dengue IgG/IgM Rapid Test', 'BGRDGM', 'Qualitative detection of IgG and IgM antibodies to Dengue virus.', 'Dengue IgG IgM'],
        'dengue_combo' => [[1147, 1148], 'Dengue Combo Rapid Test', 'BGRDCO', 'Combined qualitative detection of Dengue NS1 antigen and IgG/IgM antibodies.', 'Dengue Combo'],
        'chlamydia' => [[1139], 'Chlamydia Trachomatis Ag Rapid Test', 'BGRCLA', 'Qualitative detection of Chlamydia trachomatis antigen.', 'Chlamydia Trachomatis Ag Rapid Test'],
        'chikungunya' => [[1137], 'Chikungunya IgM Rapid Test', 'BGRCHIK', 'Qualitative detection of IgM antibodies to Chikungunya virus.', 'Chikungunya IgM Rapid Test'],
        'neisseria' => [[1197], 'Neisseria Gonorrhoea Rapid Test', 'BGRGNO', 'Qualitative detection of Neisseria gonorrhoeae antigen.', 'Neisseria Gonorrhoea Rapid test'],
    ];
    $uncut = [
        'troponin' => [[3171], 'Troponin-I Uncut Sheet', 'BGRTNI-UN', 'Troponin I coated lateral-flow uncut sheets.', 'Troponin I Uncut Sheet'],
        'toxoplasma' => [[3169], 'Toxoplasma IgG/IgM Uncut Sheet', 'BGRTXO-UN', 'Toxoplasma IgG/IgM coated lateral-flow uncut sheets.', 'TOXOPLASMA IGG IGM'],
        'syphilis' => [[3160, 3161], 'Syphilis Uncut Sheet', 'BGRSYP-UN', 'Syphilis coated lateral-flow uncut sheets.', 'Syphilis-Uncut Sheet'],
        'sickle' => [[3158, 3159], 'Sickle Cell Uncut Sheet', 'BGRSIC-UN', 'Sickle-cell rapid-test uncut sheets.', 'Sickle Cell UN'],
        'scrub' => [[3156, 3157], 'Scrub Typhus IgG/IgM Uncut Sheet', 'BGRSCR-UN', 'Scrub Typhus IgG/IgM coated lateral-flow uncut sheets.', 'S.typhus - Uncut Sheet'],
        'malaria_pfpv' => [[3142], 'Malaria Pf/Pv Ag Uncut Sheet', 'BGRMPV-UN', 'Malaria Pf/Pv antigen coated uncut sheets.', 'Malaria Pf Pv Ag UN'],
        'malaria_pfpan' => [[3141], 'Malaria Pf/PAN Ag Uncut Sheet', 'BGRMPN-UN', 'Malaria Pf/PAN antigen coated uncut sheets.', 'Malaria Pf PAN Ag UN'],
        'lh' => [[3136], 'LH Uncut Sheet', 'BGRLH-UN', 'Luteinising hormone coated lateral-flow uncut sheets.', 'LH-Uncut Sheet'],
        'leishmania' => [[3134], 'Leishmania IgG/IgM Uncut Sheet', 'BGRLEI-UN', 'Leishmania antibody coated lateral-flow uncut sheets.', 'Leishmania IgG IgM- Uncut Sheet'],
        'hiv' => [[3124], 'HIV 1/2 Uncut Sheet', 'BGRHIV-UN', 'HIV 1/2 antibody coated lateral-flow uncut sheets.', 'HIV 1&2 UN'],
        'hev' => [[3122, 3123], 'HEV IgM Uncut Sheet', 'BGRHEV-UN', 'HEV IgM coated lateral-flow uncut sheets.', 'HEV - Uncut Sheet'],
        'hcv' => [[3119, 3120, 3121], 'HCV Uncut Sheet', 'BGRHCV-UN', 'HCV antibody coated lateral-flow uncut sheets.', 'HCV - Uncut Sheet'],
        'hcg' => [[3116, 3117, 3118], 'hCG Uncut Sheet', 'BGRHCG-UN', 'hCG coated lateral-flow uncut sheets.', 'HCG- Uncut Sheet'],
        'hbsag' => [[3114, 3115], 'HBsAg Uncut Sheet', 'BGRHBS-UN', 'HBsAg coated lateral-flow uncut sheets.', 'HBsAg'],
        'hav' => [[3110], 'HAV IgM Uncut Sheet', 'BGRHAV-UN', 'HAV IgM coated lateral-flow uncut sheets.', 'HAV - Uncut Sheet'],
        'hpylori_ab' => [[3108], 'H. pylori Ab Uncut Sheet', 'BGRHPB-UN', 'H. pylori antibody coated lateral-flow uncut sheets.', 'H Pylori Ab - Uncut Sheet'],
        'fob' => [[3102], 'FOB Uncut Sheet', 'BGRFOB-UN', 'Faecal occult blood coated lateral-flow uncut sheets.', 'FOB- Uncut Sheet'],
        'filaria' => [[3100], 'Filaria IgG/IgM Uncut Sheet', 'BGRFIL-UN', 'Filaria IgG/IgM coated lateral-flow uncut sheets.', 'Filaria IgG IgM - Uncut Sheet'],
        'dengue_ns1' => [[3098], 'Dengue NS1 Ag Uncut Sheet', 'BGRDNS-UN', 'Dengue NS1 antigen coated lateral-flow uncut sheets.', 'DENGUE NS1 Ag UN'],
        'dengue_igg_igm' => [[3096], 'Dengue IgG/IgM Uncut Sheet', 'BGRDGM-UN', 'Dengue IgG/IgM coated lateral-flow uncut sheets.', 'Dengue IgG IgM - Uncut Sheet'],
        'chikungunya' => [[3082], 'Chikungunya IgM Uncut Sheet', 'BGRCHIK-UN', 'Chikungunya IgM coated lateral-flow uncut sheets.', 'Chikunguniya IgM - Uncut Sheet'],
    ];

    $families = [];
    foreach ($finished as $key => [$ids, $name, $code, $description, $sourceBase]) {
        $buffer = in_array($key, ['fob', 'hpylori_ag', 'neisseria'], true)
            ? 'Specimen Extraction Buffer'
            : 'Assay Buffer';
        $families['finished_' . $key] = [
            'product_ids' => $ids,
            'product_name' => $name,
            'bmr_documents' => [
                bmrBprRapidFinishedBmr(
                    $name,
                    $code,
                    $description,
                    $sourceBase . ' BMR.pdf',
                    $buffer
                ),
            ],
            'bpr_documents' => [
                bmrBprRapidFinishedBpr(
                    $name,
                    $code,
                    $description,
                    $sourceBase . ' BPR.pdf',
                    $buffer
                ),
            ],
        ];
    }
    // The supplied Dengue Combo source contains two separately manufactured
    // devices. Keep them as two BMR documents; only the final kit packing is
    // represented by the shared BPR.
    $families['finished_dengue_combo']['bmr_documents'] = [
        bmrBprRapidFinishedBmr(
            'Dengue Combo - NS1 Device',
            'BGRDCO-NS1',
            'NS1 antigen device manufactured for the Dengue Combo kit.',
            'Dengue Combo BMR.pdf'
        ),
        bmrBprRapidFinishedBmr(
            'Dengue Combo - IgG/IgM Device',
            'BGRDCO-AB',
            'IgG/IgM antibody device manufactured for the Dengue Combo kit.',
            'Dengue Combo BMR.pdf'
        ),
    ];
    // Two supplied master files are intentionally single-document mappings.
    $families['finished_hiv_4th_gen'] = [
        'product_ids' => [1180],
        'product_name' => 'HIV 4th Generation Rapid Test',
        'bmr_documents' => [
            bmrBprRapidFinishedBmr(
                'HIV 4th Generation Rapid Test',
                'BGRHIV4',
                'Qualitative detection of HIV p24 antigen and antibodies to HIV-1/HIV-2.',
                'HIV 4th Gen BMR.doc'
            ),
        ],
        'bpr_documents' => [],
    ];
    $families['finished_lh'] = [
        'product_ids' => [1190],
        'product_name' => 'LH Rapid Test',
        'bmr_documents' => [],
        'bpr_documents' => [
            bmrBprRapidFinishedBpr(
                'LH Rapid Test',
                'BGRLH',
                'Qualitative detection of luteinising hormone in urine.',
                'BPR-LH -Master copy.doc'
            ),
        ],
    ];
    foreach ($uncut as $key => [$ids, $name, $code, $description, $sourceBase]) {
        $families['uncut_' . $key] = [
            'product_ids' => $ids,
            'product_name' => $name,
            'bmr_documents' => [
                bmrBprRapidUncutBmr($name, $code, $description, $sourceBase . ' BMR.pdf'),
            ],
            'bpr_documents' => [
                bmrBprRapidUncutBpr($name, $code, $description, $sourceBase . ' BPR.pdf'),
            ],
        ];
    }
    $families['uncut_leptospira'] = [
        'product_ids' => [3135],
        'product_name' => 'Leptospira IgG/IgM Uncut Sheet',
        'bmr_documents' => [
            bmrBprRapidUncutBmr(
                'Leptospira IgG/IgM Uncut Sheet',
                'BGRLEP-UN',
                'Leptospira IgG/IgM coated lateral-flow uncut sheets.',
                'Leptospira  IgG IgM- Uncut Sheet BMR.pdf'
            ),
        ],
        'bpr_documents' => [
            bmrBprRapidUncutBpr(
                'Leptospira IgG/IgM Uncut Sheet',
                'BGRLEP-UN',
                'Leptospira IgG/IgM coated lateral-flow uncut sheets.',
                'Leptospira IgG IgM - Uncut Sheet BPR.docx'
            ),
        ],
    ];
    $families['uncut_leptospira']['bmr_documents'][0]['source_alternates'] = [
        'Leptospira  IgG IgM- Uncut Sheet BMR.docx',
    ];

    // Keep the audit trail tied to the exact filenames in the supplied
    // 2026-09-24 folder, including the Word-only master forms and irregular
    // legacy naming. Runtime rendering remains code-only.
    $sourceDocumentOverrides = [
        'finished_hev' => [
            'BMR' => 'HEV IgM BMR 1.pdf',
            'BPR' => 'HEV IgM BPR 1.pdf',
        ],
        'uncut_hbsag' => [
            'BMR' => 'HBsAg BMR - Uncut Sheet.pdf',
            'BPR' => 'HBsAg BPR - Uncut Sheet.pdf',
        ],
        'uncut_hev' => [
            'BMR' => 'HEV - Uncut Sheet BMR.docx',
            'BPR' => 'HEV - Uncut Sheet BPR.docx',
        ],
        'uncut_leishmania' => [
            'BMR' => 'Leishmania  IgG IgM- Uncut Sheet BMR.docx',
            'BPR' => 'Leishmania Igg igm - Uncut Sheet BPR.docx',
        ],
        'uncut_scrub' => [
            'BMR' => 'S.typhus - Uncut Sheet BMR.docx',
            'BPR' => 'S.typhus - Uncut Sheet BPR.docx',
        ],
        'uncut_sickle' => [
            'BMR' => 'Sickle Cell UN  BMR (1).pdf',
            'BPR' => 'Sickle Cell UN  BPR (2).pdf',
        ],
        'uncut_toxoplasma' => [
            'BMR' => 'TOXOPLASMA IGG IGM BMR-Uncut sheet.pdf',
            'BPR' => 'TOXOPLASMA IGG IGM BPR-uncut sheet.pdf',
        ],
    ];
    foreach ($sourceDocumentOverrides as $familyKey => $documents) {
        if (isset($families[$familyKey]['bmr_documents'][0])) {
            $families[$familyKey]['bmr_documents'][0]['source_document'] = $documents['BMR'];
        }
        if (isset($families[$familyKey]['bpr_documents'][0])) {
            $families[$familyKey]['bpr_documents'][0]['source_document'] = $documents['BPR'];
        }
    }

    foreach ($families as &$family) {
        foreach ($family['bmr_documents'] as &$profile) {
            $profile['approval_names'] = $approval;
            $profile['attachment_documents'] = $bmrAttachments;
        }
        unset($profile);
        foreach ($family['bpr_documents'] as &$profile) {
            $profile['approval_names'] = $approval;
            $profile['attachment_documents'] = $bprAttachments;
        }
        unset($profile);
    }
    unset($family);
    return $families;
}

function bmrBprRapidApprovedProductIds(): array
{
    $ids = [];
    foreach (bmrBprRapidCatalog() as $family) {
        foreach ($family['product_ids'] as $productId) {
            $ids[(int) $productId] = true;
        }
    }
    $ids = array_keys($ids);
    sort($ids);
    return $ids;
}

function bmrBprRapidDocumentCounts(): array
{
    $counts = ['BMR' => 0, 'BPR' => 0];
    foreach (bmrBprRapidCatalog() as $family) {
        $products = count($family['product_ids']);
        $counts['BMR'] += $products * count($family['bmr_documents']);
        $counts['BPR'] += $products * count($family['bpr_documents']);
    }
    return $counts;
}
