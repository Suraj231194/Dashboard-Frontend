<?php

declare(strict_types=1);

/**
 * Native, template-artwork-free renderer for schema-version-2 BMR/BPR
 * templates. It may embed the shared company logo supplied at runtime, but
 * never depends on product PDF pages or product-specific page images.
 *
 * The same markup is used by the Production editor and the PDF endpoint so
 * field placement, page breaks and printed output cannot drift apart.
 */

function bmrBprIsStructuredLayout(array $layout): bool
{
    return (int) ($layout['schema_version'] ?? 0) >= 2
        && (string) ($layout['renderer'] ?? '') === 'structured_html';
}

function bmrBprStructuredProfile(array $layout, int $productId): array
{
    $profiles = is_array($layout['profiles'] ?? null) ? $layout['profiles'] : [];
    $profile = $profiles[(string) $productId] ?? null;
    if (!is_array($profile)) {
        return [];
    }

    $familyKey = trim((string) ($profile['family_key'] ?? ''));
    $families = is_array($layout['profile_families'] ?? null)
        ? $layout['profile_families']
        : [];
    $family = $familyKey !== '' && is_array($families[$familyKey] ?? null)
        ? $families[$familyKey]
        : [];
    unset($profile['family_key']);
    return array_replace($family, $profile);
}

function bmrBprStructuredEscape(string|int|float|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function bmrBprStructuredFields(array $form): array
{
    $payload = is_array($form['form_payload'] ?? null) ? $form['form_payload'] : [];
    return is_array($payload['fields'] ?? null) ? $payload['fields'] : [];
}

function bmrBprIsImageValue(string $value): bool
{
    $val = trim($value);
    return str_starts_with($val, 'data:image/')
        || (bool) preg_match('/\.(png|jpe?g|webp|gif|svg)$/i', $val);
}

function bmrBprIsSignatureKey(string $key): bool
{
    $lower = strtolower(trim($key));
    return str_ends_with($lower, 'signature')
        || str_ends_with($lower, '_signature')
        || str_ends_with($lower, '.signature')
        || str_contains($lower, 'signature')
        || preg_match(
            '/(?:^|[._])(completed_by|checked_by|carried_by|done_by|verified_by|issued_by|issued_to|transferred_by|production|qa|qc|store|received_store)$/',
            $lower
        ) === 1
        || $lower === 'qa_signature';
}

function bmrBprIsDateKey(string $key): bool
{
    $lower = strtolower(trim($key));
    if (str_contains($lower, 'signature') || bmrBprIsSignatureKey($key)) {
        return false;
    }
    return str_ends_with($lower, 'date')
        || str_ends_with($lower, '_date')
        || str_ends_with($lower, '.date')
        || str_ends_with($lower, 'started_on')
        || str_ends_with($lower, 'completed_on')
        || str_ends_with($lower, 'mfg_date')
        || str_ends_with($lower, 'exp_date')
        || in_array($lower, [
            'date',
            'testing_date',
            'initial_date',
            'completed_date',
            'checked_date',
            'issued_to_date',
            'issued_by_date',
            'production_review_date',
            'qa_review_date',
            'cover.prepared_date',
            'cover.checked_date',
            'cover.approved_date',
            'cover.mfg_date',
            'cover.exp_date',
            'cover.started_on',
            'cover.completed_on',
        ], true);
}

function bmrBprFormatDateForInput(string $value): string
{
    $val = trim($value);
    if ($val === '') {
        return '';
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
        return $val;
    }
    if (preg_match('/^(\d{1,2})[\/\.-](\d{1,2})[\/\.-](\d{4})$/', $val, $m)) {
        return sprintf('%04d-%02d-%02d', (int) $m[3], (int) $m[2], (int) $m[1]);
    }
    $timestamp = strtotime($val);
    if ($timestamp !== false && $timestamp > 0) {
        return date('Y-m-d', $timestamp);
    }
    return $val;
}

function bmrBprFormatDateForDisplay(string $value): string
{
    $val = trim($value);
    if ($val === '') {
        return '';
    }
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $val, $m)) {
        return sprintf('%02d/%02d/%04d', (int) $m[3], (int) $m[2], (int) $m[1]);
    }
    if (preg_match('/^(\d{1,2})[\/\.-](\d{1,2})[\/\.-](\d{4})$/', $val, $m)) {
        return sprintf('%02d/%02d/%04d', (int) $m[1], (int) $m[2], (int) $m[3]);
    }
    $timestamp = strtotime($val);
    if ($timestamp !== false && $timestamp > 0) {
        return date('d/m/Y', $timestamp);
    }
    return $val;
}

function bmrBprStructuredField(
    string $key,
    array $fields,
    bool $editable,
    string $class = '',
    string $placeholder = ''
): string {
    $value = (string) ($fields[$key] ?? '');
    $isImage = bmrBprIsImageValue($value);

    if (!$editable) {
        if ($isImage) {
            return '<div class="bmr-v2-sig-print-wrap"><img src="' . bmrBprStructuredEscape($value) . '" class="bmr-v2-sig-print-img" alt="Signature"></div>';
        }
        $displayVal = $value;
        if (bmrBprIsDateKey($key) && $value !== '') {
            $displayVal = bmrBprFormatDateForDisplay($value);
        }
        return '<span class="bmr-v2-print-value ' . bmrBprStructuredEscape($class) . '">'
            . ($displayVal !== '' ? nl2br(bmrBprStructuredEscape($displayVal)) : '&nbsp;')
            . '</span>';
    }

    if (bmrBprIsSignatureKey($key)) {
        $imgStyle = $isImage ? '' : 'display:none;';
        $inputGroupStyle = $isImage ? 'display:none;' : '';
        $previewImgTag = $isImage ? '<img src="' . bmrBprStructuredEscape($value) . '" class="bmr-v2-sig-preview-img" alt="Signature">' : '';
        return '<div class="bmr-v2-sig-widget">'
            . '<input type="hidden" class="bmr-v2-sig-value" data-bmr-field="' . bmrBprStructuredEscape($key) . '" value="' . bmrBprStructuredEscape($value) . '">'
            . '<div class="bmr-v2-sig-preview" style="' . $imgStyle . '">'
            . $previewImgTag
            . '<button type="button" class="bmr-v2-sig-clear-btn" title="Remove signature">&times;</button>'
            . '</div>'
            . '<div class="bmr-v2-sig-input-group" style="' . $inputGroupStyle . '">'
            . '<input type="text" class="bmr-v2-field bmr-v2-sig-text ' . bmrBprStructuredEscape($class) . '"'
            . ' value="' . ($isImage ? '' : bmrBprStructuredEscape($value)) . '"'
            . ' placeholder="' . bmrBprStructuredEscape($placeholder ?: 'Sign / Type') . '" autocomplete="off">'
            . '<label class="bmr-v2-sig-upload-btn" title="Upload signed image (max 250 KB)">'
            . '<i class="ti ti-upload"></i>'
            . '<input type="file" class="bmr-v2-sig-file-input" accept="image/png,image/jpeg,image/jpg,image/webp" style="display:none;">'
            . '</label>'
            . '</div>'
            . '</div>';
    }

    if (bmrBprIsDateKey($key)) {
        $dateValue = bmrBprFormatDateForInput($value);
        return '<input type="date" class="bmr-v2-field bmr-v2-date ' . bmrBprStructuredEscape($class) . '"'
            . ' data-bmr-field="' . bmrBprStructuredEscape($key) . '"'
            . ' value="' . bmrBprStructuredEscape($dateValue) . '" autocomplete="off">';
    }

    $className = trim('bmr-v2-field ' . $class);
    return '<input type="text" class="' . bmrBprStructuredEscape($className) . '"'
        . ' data-bmr-field="' . bmrBprStructuredEscape($key) . '"'
        . ' value="' . bmrBprStructuredEscape($value) . '"'
        . ' placeholder="' . bmrBprStructuredEscape($placeholder) . '" autocomplete="off">';
}

function bmrBprStructuredTextarea(
    string $key,
    array $fields,
    bool $editable,
    string $class = '',
    string $placeholder = ''
): string {
    $value = (string) ($fields[$key] ?? '');
    if (!$editable) {
        return '<span class="bmr-v2-print-value bmr-v2-multiline ' . bmrBprStructuredEscape($class) . '">'
            . ($value !== '' ? nl2br(bmrBprStructuredEscape($value)) : '&nbsp;')
            . '</span>';
    }

    return '<textarea class="bmr-v2-field bmr-v2-textarea ' . bmrBprStructuredEscape($class) . '"'
        . ' data-bmr-field="' . bmrBprStructuredEscape($key) . '"'
        . ' placeholder="' . bmrBprStructuredEscape($placeholder) . '">'
        . bmrBprStructuredEscape($value)
        . '</textarea>';
}

function bmrBprStructuredSignatureAndDate(
    string $prefix,
    array $fields,
    bool $editable,
    string $legacyCombinedKey = ''
): string {
    $signatureKey = $prefix . '.signature';
    $dateKey = $prefix . '.date';
    $compatibleFields = $fields;
    if (
        $legacyCombinedKey !== ''
        && trim((string) ($compatibleFields[$signatureKey] ?? '')) === ''
        && trim((string) ($compatibleFields[$legacyCombinedKey] ?? '')) !== ''
    ) {
        $compatibleFields[$signatureKey] = (string) $compatibleFields[$legacyCombinedKey];
    }

    return '<div class="bmr-v2-sign-date-pair">'
        . '<div><span class="bmr-v2-field-caption">Signature</span>'
        . bmrBprStructuredField($signatureKey, $compatibleFields, $editable)
        . '</div><div><span class="bmr-v2-field-caption">Date</span>'
        . bmrBprStructuredField($dateKey, $compatibleFields, $editable)
        . '</div></div>';
}

function bmrBprStructuredRowIndexes(array $fields, string $prefix, int $minimum): array
{
    $indexes = [];
    $quoted = preg_quote($prefix, '/');
    foreach (array_keys($fields) as $key) {
        if (preg_match('/^' . $quoted . '\.(\d+)\./', (string) $key, $matches)) {
            $indexes[(int) $matches[1]] = true;
        }
    }
    for ($index = 0; $index < $minimum; $index++) {
        $indexes[$index] = true;
    }
    ksort($indexes);
    return array_keys($indexes);
}

function bmrBprStructuredStyles(): string
{
    return <<<'CSS'
<style>
    .bmr-v2-document {
        --bmr-border: #111;
        width: 210mm;
        margin: 0 auto;
        color: #111;
        background: #fff;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 9pt;
        line-height: 1.16;
    }
    .bmr-v2-document,
    .bmr-v2-document * {
        box-sizing: border-box;
    }
    .bmr-v2-page {
        position: relative;
        width: 210mm;
        min-height: 296mm;
        padding: 0;
        overflow: hidden;
        background: #fff;
        page-break-after: auto;
        break-after: auto;
    }
    .bmr-v2-page-body {
        padding: 12mm 12.5mm 16mm;
    }
    .bmr-v2-page + .bmr-v2-page {
        page-break-before: always;
        break-before: page;
    }
    .bmr-v2-document table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }
    .bmr-v2-document th,
    .bmr-v2-document td {
        border: .25mm solid var(--bmr-border);
        padding: 1.05mm 1.15mm;
        vertical-align: middle;
        overflow-wrap: anywhere;
    }
    .bmr-v2-document th {
        font-weight: 700;
        text-align: left;
        background: #f2f2f2;
    }
    .bmr-v2-header td {
        padding: .72mm 1mm;
    }
    .bmr-v2-brand {
        display: block;
        min-height: 12mm;
        color: #0d5c22;
    }
    .bmr-v2-brand-logo {
        display: block;
        width: 37mm;
        max-width: 100%;
        height: 12mm;
        object-fit: contain;
        object-position: left center;
    }
    .bmr-v2-brand-fallback {
        display: block;
        padding-top: 2.8mm;
        font-size: 10.5pt;
        font-weight: 900;
    }
    .bmr-v2-title {
        font-size: 10.2pt;
        font-weight: 800;
        line-height: 1.2;
        text-align: center;
    }
    .bmr-v2-doc-meta {
        font-size: 8.5pt;
    }
    .bmr-v2-doc-meta td:first-child {
        width: 47%;
        font-weight: 700;
    }
    .bmr-v2-section-title {
        margin: 2.7mm 0 1.2mm;
        font-size: 9.2pt;
        font-weight: 800;
    }
    .bmr-v2-subtitle {
        margin: 1.5mm 0 .8mm;
        font-weight: 800;
    }
    .bmr-v2-field {
        display: block;
        width: 100%;
        min-height: 4.2mm;
        margin: 0;
        border: .2mm dashed #c59f00;
        border-radius: .6mm;
        outline: none;
        background: #fffbe8;
        color: #111;
        font: inherit;
        line-height: 1.15;
        padding: .45mm .7mm;
    }
    .bmr-v2-field:focus {
        border-color: #166534;
        box-shadow: 0 0 0 .4mm rgba(22, 101, 52, .14);
    }
    .bmr-v2-textarea {
        min-height: 6mm;
        resize: vertical;
    }
    .bmr-v2-print-value {
        display: block;
        min-height: 4.8mm;
        white-space: pre-wrap;
    }
    .bmr-v2-multiline {
        min-height: 6mm;
    }
    .bmr-v2-static {
        background: #fff;
    }
    .bmr-v2-center {
        text-align: center;
    }
    .bmr-v2-right {
        text-align: right;
    }
    .bmr-v2-small {
        font-size: 7pt;
    }
    .bmr-v2-tight th,
    .bmr-v2-tight td {
        padding: .8mm .95mm;
    }
    .bmr-v2-blank-box {
        min-height: 22mm;
        border: .25mm solid #111;
    }
    .bmr-v2-note {
        margin-top: 1.2mm;
        font-size: 7pt;
    }
    .bmr-v2-sign-grid td {
        height: 8mm;
    }
    .bmr-v2-qa-box {
        margin-top: 2mm;
        padding: 2mm;
        border: .25mm solid #111;
        min-height: 22mm;
    }
    .bmr-v2-footer {
        position: absolute;
        right: 12.5mm;
        bottom: 4mm;
        left: 12.5mm;
        width: 185mm;
        height: 10mm;
        font-size: 7.5pt;
    }
    .bmr-v2-footer > span {
        position: absolute;
        bottom: 0;
    }
    .bmr-v2-footer .bmr-v2-page-label {
        left: 0;
    }
    .bmr-v2-footer .bmr-v2-master-copy {
        left: 80mm;
    }
    .bmr-v2-footer .bmr-v2-qa-signature {
        right: 0;
    }
    .bmr-v2-master-copy {
        border: .55mm solid #111;
        padding: .6mm 2mm;
        font-size: 11pt;
        font-weight: 900;
    }
    .bmr-v2-qa-signature {
        width: 46mm;
        min-height: 10mm;
        padding: 2.5mm;
        border: .25mm solid #111;
        text-align: center;
    }
    .bmr-v2-list {
        margin: .8mm 0 .8mm 4mm;
        padding: 0;
    }
    .bmr-v2-list li {
        margin-bottom: .45mm;
    }
    .bmr-v2-step-table td {
        height: 5.5mm;
    }
    .bmr-v2-input-cell {
        padding: .5mm !important;
    }
    .bmr-v2-urology-materials {
        font-size: 6.8pt;
        line-height: 1.02;
    }
    .bmr-v2-urology-materials .bmr-v2-section-title {
        margin: 1.4mm 0 .7mm;
        font-size: 8.3pt;
    }
    .bmr-v2-urology-materials .bmr-v2-tight th,
    .bmr-v2-urology-materials .bmr-v2-tight td {
        padding: .28mm .5mm;
    }
    .bmr-v2-urology-materials .bmr-v2-field,
    .bmr-v2-urology-materials .bmr-v2-print-value {
        min-height: 2.6mm;
        padding: .15mm .35mm;
    }
    .bmr-v2-urology-materials .bmr-v2-list {
        margin-top: .4mm;
        margin-bottom: .4mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] {
        font-size: 7pt;
        line-height: 1;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-page-body {
        padding-top: 5mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] th,
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] td {
        padding: .35mm .52mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-section-title {
        margin: .65mm 0 .35mm;
        font-size: 7.7pt;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-field,
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-print-value {
        min-height: 2.8mm;
        padding: .18mm .4mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-approval-cell {
        height: 5.2mm;
        padding: .32mm .5mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-cover-approval {
        margin-top: .65mm !important;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-brand {
        min-height: 8mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-brand-logo {
        height: 8mm;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-title {
        font-size: 8pt;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-doc-meta {
        font-size: 7pt;
    }
    .bmr-v2-page.bmr-v2-urology-cover-page[data-page="1"] .bmr-v2-cover-review {
        display: none;
    }
    .bmr-v2-page[data-page="1"] {
        font-size: 8.4pt;
        line-height: 1.12;
    }
    .bmr-v2-page[data-page="1"] th,
    .bmr-v2-page[data-page="1"] td {
        padding: .95mm 1mm;
    }
    .bmr-v2-page[data-page="1"] .bmr-v2-section-title {
        margin: 2.5mm 0 1mm;
        font-size: 8.8pt;
    }
    .bmr-v2-page[data-page="1"] .bmr-v2-field,
    .bmr-v2-page[data-page="1"] .bmr-v2-print-value {
        min-height: 5.2mm;
        padding: .45mm .6mm;
    }
    .bmr-v2-page[data-page="1"] .bmr-v2-sign-grid td {
        height: 4.5mm;
    }
    .bmr-v2-document[data-form-type="BMR"] .bmr-v2-page[data-page="4"] {
        font-size: 8.2pt;
        line-height: 1.08;
    }
    .bmr-v2-document[data-form-type="BMR"] .bmr-v2-page[data-page="4"] th,
    .bmr-v2-document[data-form-type="BMR"] .bmr-v2-page[data-page="4"] td {
        padding: .68mm .8mm;
    }
    .bmr-v2-document[data-form-type="BMR"] .bmr-v2-page[data-page="4"] .bmr-v2-section-title {
        margin: 1.6mm 0 .7mm;
        font-size: 8.5pt;
    }
    .bmr-v2-cover-approval {
        display: table;
        position: static;
        width: 100%;
        margin: 2mm 0 0 !important;
        border-collapse: collapse;
        table-layout: fixed;
    }
    .bmr-v2-approval-row {
        display: table-row;
    }
    .bmr-v2-approval-cell {
        display: table-cell;
        height: 9mm;
        padding: 1mm .9mm;
        border: .25mm solid #111;
        vertical-align: middle;
    }
    .bmr-v2-approval-label {
        width: 13%;
        font-weight: 700;
    }
    .bmr-v2-approval-heading {
        font-weight: 700;
        text-align: center;
    }
    .bmr-v2-page-label {
        font-weight: 700;
    }
    .bmr-v2-sig-widget {
        position: relative;
        display: block;
        width: 100%;
        min-height: 4.6mm;
    }
    .bmr-v2-sig-input-group {
        display: flex;
        width: 100%;
        align-items: center;
        gap: 1mm;
    }
    .bmr-v2-sign-date-pair {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 31mm;
        gap: 1.5mm;
        align-items: end;
    }
    .bmr-v2-field-caption {
        display: block;
        margin-bottom: .45mm;
        color: #475569;
        font-size: 6.4pt;
        font-weight: 700;
        text-transform: uppercase;
    }
    .bmr-v2-sig-text {
        flex: 1 1 auto;
        min-width: 0;
    }
    .bmr-v2-sig-upload-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: .5mm;
        padding: .4mm 1.2mm;
        font-size: 6.8pt;
        font-weight: 700;
        color: #166534;
        background: #f0fdf4;
        border: .2mm solid #86efac;
        border-radius: .6mm;
        cursor: pointer;
        white-space: nowrap;
        user-select: none;
        flex-shrink: 0;
        line-height: 1.1;
    }
    .bmr-v2-sig-upload-btn:hover {
        background: #dcfce7;
        border-color: #4ade80;
    }
    .bmr-v2-sig-preview {
        display: inline-flex;
        align-items: center;
        gap: 1.2mm;
        max-width: 100%;
        padding: .3mm .6mm;
        background: #fff;
        border: .2mm solid #cbd5e1;
        border-radius: .6mm;
    }
    .bmr-v2-sig-preview-img {
        max-height: 8mm;
        max-width: 32mm;
        object-fit: contain;
        display: block;
    }
    .bmr-v2-sig-clear-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 3.6mm;
        height: 3.6mm;
        padding: 0;
        font-size: 7.5pt;
        font-weight: bold;
        line-height: 1;
        color: #ef4444;
        background: #fee2e2;
        border: none;
        border-radius: 50%;
        cursor: pointer;
    }
    .bmr-v2-sig-clear-btn:hover {
        background: #fecaca;
    }
    .bmr-v2-sig-print-wrap {
        display: block;
        text-align: center;
        vertical-align: middle;
        max-width: 100%;
    }
    .bmr-v2-sig-print-img {
        max-height: 11mm;
        max-width: 36mm;
        object-fit: contain;
        display: block;
        margin: 0 auto;
    }
    .bmr-v2-field:disabled {
        border-color: transparent !important;
        background: transparent !important;
        color: #111 !important;
        cursor: default !important;
        opacity: 1 !important;
        -webkit-text-fill-color: #111 !important;
    }
    .bmr-v2-document input:disabled ~ .bmr-v2-sig-upload-btn,
    .bmr-v2-document input:disabled ~ label,
    .bmr-v2-document .is-disabled .bmr-v2-sig-upload-btn,
    .bmr-v2-document .is-disabled .bmr-v2-sig-clear-btn {
        display: none !important;
    }
    @media print {
        .bmr-v2-document {
            margin: 0;
        }
        .bmr-v2-page {
            margin: 0;
            box-shadow: none;
        }
        .bmr-v2-sig-upload-btn,
        .bmr-v2-sig-clear-btn {
            display: none !important;
        }
    }
</style>
CSS;
}

function bmrBprStructuredHeader(
    array $document,
    array $profile,
    array $sourceValues,
    string $formType
): string {
    $productName = (string) ($profile['product_name'] ?? $sourceValues['product_name'] ?? '');
    $batchSize = (string) ($sourceValues['batch_size'] ?? '');
    if ($batchSize === '') {
        $batchSize = (string) ($profile['standard_batch'] ?? '');
    }
    $packSize = (string) ($sourceValues['pack_size'] ?? '');
    if ($packSize === '') {
        $packSize = (string) ($profile['pack_size'] ?? '');
    }
    $recordLabel = $formType === 'BPR' ? 'BPR No.' : 'BMR No.';
    $mfrLabel = $formType === 'BPR' ? 'MFR FG No.' : 'MFR No.';
    $logoDataUri = trim((string) ($document['branding_logo_data_uri'] ?? ''));
    $brandHtml = $logoDataUri !== ''
        ? '<img class="bmr-v2-brand-logo" src="' . bmrBprStructuredEscape($logoDataUri)
            . '" alt="Biogenix">'
        : '<span class="bmr-v2-brand-fallback">'
            . bmrBprStructuredEscape($document['company_name'] ?? 'BIOGENIX')
            . '</span>';
    $companyAddress = nl2br(
        bmrBprStructuredEscape($document['company_address'] ?? ''),
        false
    );

    return '<table class="bmr-v2-header">'
        . '<tr>'
        . '<td colspan="4"><div class="bmr-v2-brand">' . $brandHtml . '</div></td>'
        . '<td colspan="2" rowspan="2" class="bmr-v2-title">TITLE:'
        . bmrBprStructuredEscape($document['title'] ?? '')
        . '</td>'
        . '<td colspan="3" rowspan="2" class="bmr-v2-doc-meta">'
        . '<table><tr><td>Document No.</td><td>' . bmrBprStructuredEscape($document['document_no'] ?? '') . '</td></tr>'
        . '<tr><td>Issue No.</td><td>' . bmrBprStructuredEscape($document['issue_no'] ?? '') . '</td></tr>'
        . '<tr><td>Revision No.</td><td>' . bmrBprStructuredEscape($document['revision_no'] ?? '') . '</td></tr>'
        . '<tr><td>Effective Date</td><td>' . bmrBprStructuredEscape($document['effective_date'] ?? '') . '</td></tr></table>'
        . '</td>'
        . '</tr>'
        . '<tr><td colspan="4">' . $companyAddress . '</td></tr>'
        . '<tr><th>Product name</th><td colspan="5">' . bmrBprStructuredEscape($productName) . '</td>'
        . '<th>Batch size</th><td colspan="2">' . bmrBprStructuredEscape($batchSize) . '</td></tr>'
        . '<tr><th>Batch number</th><td colspan="3">' . bmrBprStructuredEscape($sourceValues['batch_number'] ?? '') . '</td>'
        . '<th>Department</th><td>' . bmrBprStructuredEscape($document['department'] ?? 'Production') . '</td>'
        . '<th>' . bmrBprStructuredEscape($recordLabel) . '</th><td colspan="2">'
        . bmrBprStructuredEscape($sourceValues['record_number'] ?? '') . '</td></tr>'
        . '<tr><th>Mfg. Lic. No.</th><td colspan="3">' . bmrBprStructuredEscape($document['license_no'] ?? '') . '</td>'
        . '<th>Pack size</th><td>' . bmrBprStructuredEscape($packSize) . '</td>'
        . '<th>' . bmrBprStructuredEscape($mfrLabel) . '</th><td colspan="2">'
        . bmrBprStructuredEscape($profile['mfr_reference'] ?? '') . '</td></tr>'
        . '</table>';
}

function bmrBprStructuredFooter(int $page, int $total): string
{
    return '<div class="bmr-v2-footer">'
        . '<span class="bmr-v2-page-label">Page No.: ' . $page . ' of ' . $total . '</span>'
        . '<span class="bmr-v2-master-copy">MASTER COPY</span>'
        . '<span class="bmr-v2-qa-signature">QA Signature</span>'
        . '</div>';
}

function bmrBprStructuredPage(
    int $page,
    int $total,
    array $document,
    array $profile,
    array $sourceValues,
    string $formType,
    string $content,
    string $pageClass = ''
): string {
    $className = trim('bmr-v2-page ' . $pageClass);
    return '<section class="' . bmrBprStructuredEscape($className)
        . '" data-page="' . $page . '">'
        . bmrBprStructuredFooter($page, $total)
        . '<div class="bmr-v2-page-body">'
        . bmrBprStructuredHeader($document, $profile, $sourceValues, $formType)
        . $content
        . '</div>'
        . '</section>';
}

function bmrBprStructuredCover(
    array $profile,
    array $fields,
    bool $editable,
    string $formType
): string {
    $isBpr = $formType === 'BPR';
    $contentsLabel = $isBpr ? 'Kit content' : 'Reagent contents';
    $contentsValue = $isBpr
        ? (string) ($profile['kit_content'] ?? '')
        : (string) ($profile['reagent_contents'] ?? '');
    $startedLabel = $isBpr ? 'Production started on date' : 'Manufacturing started on date';
    $completedLabel = $isBpr ? 'Production completed on date' : 'Manufacturing completed on date';
    $recordPrefix = strtolower($formType);
    $approvalNames = is_array($profile['approval_names'] ?? null)
        ? $profile['approval_names']
        : [];
    $preparedName = (string) ($approvalNames['prepared_by'] ?? 'Ashish Kumar Maurya');
    $checkedName = (string) ($approvalNames['checked_by'] ?? 'Durgesh Singh Pal');
    $approvedName = (string) ($approvalNames['approved_by'] ?? 'Sanjay Kumar Yadav');

    $coverFields = $fields;
    if (!isset($coverFields['cover.prepared_name']) || trim((string) $coverFields['cover.prepared_name']) === '') {
        $coverFields['cover.prepared_name'] = (string) ($fields['cover.prepared_by_name'] ?? $fields['cover.prepared_by'] ?? $preparedName);
    }
    if (!isset($coverFields['cover.checked_name']) || trim((string) $coverFields['cover.checked_name']) === '') {
        $coverFields['cover.checked_name'] = (string) ($fields['cover.checked_by_name'] ?? $fields['cover.checked_by'] ?? $checkedName);
    }
    if (!isset($coverFields['cover.approved_name']) || trim((string) $coverFields['cover.approved_name']) === '') {
        $coverFields['cover.approved_name'] = (string) ($fields['cover.approved_by_name'] ?? $fields['cover.approved_by'] ?? $approvedName);
    }

    $approvalHtml = '<div class="bmr-v2-cover-approval">'
        . '<div class="bmr-v2-approval-row">'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-label">&nbsp;</div>'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-heading">Prepared by<br>(Conc. Dept.)</div>'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-heading">Checked and verified by<br>(Section Head)</div>'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-heading">Approved by<br>(Head QA)</div></div>'
        . '<div class="bmr-v2-approval-row">'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-label">Name</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.prepared_name', $coverFields, $editable) . '</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.checked_name', $coverFields, $editable) . '</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.approved_name', $coverFields, $editable) . '</div></div>'
        . '<div class="bmr-v2-approval-row">'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-label">Signature</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.prepared_signature', $fields, $editable) . '</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.checked_signature', $fields, $editable) . '</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.approved_signature', $fields, $editable) . '</div></div>'
        . '<div class="bmr-v2-approval-row">'
        . '<div class="bmr-v2-approval-cell bmr-v2-approval-label">Date</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.prepared_date', $fields, $editable) . '</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.checked_date', $fields, $editable) . '</div>'
        . '<div class="bmr-v2-approval-cell">' . bmrBprStructuredField('cover.approved_date', $fields, $editable) . '</div></div>'
        . '</div>';

    $contentsRow = array_key_exists('show_contents', $profile) && !$profile['show_contents']
        ? ''
        : '<tr><th style="width:24%">' . bmrBprStructuredEscape($contentsLabel) . '</th><td>'
            . bmrBprStructuredEscape($contentsValue) . '</td></tr>';

    return '<h3 class="bmr-v2-section-title">Product / Batch details</h3>'
        . '<table>'
        . $contentsRow
        . '<tr><th>Description</th><td>' . bmrBprStructuredEscape($profile['description'] ?? '') . '</td></tr>'
        . '<tr><th>Product code</th><td>' . bmrBprStructuredEscape($profile['product_code'] ?? '') . '</td></tr>'
        . '</table>'
        . '<table style="margin-top:1.5mm">'
        . '<tr><th>Mfg. date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.mfg_date', $fields, $editable)
        . '</td><th>Exp. date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.exp_date', $fields, $editable) . '</td></tr>'
        . '<tr><th>' . bmrBprStructuredEscape($startedLabel) . '</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.started_on', $fields, $editable)
        . '</td><th>' . bmrBprStructuredEscape($completedLabel) . '</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.completed_on', $fields, $editable) . '</td></tr>'
        . '</table>'
        . '<h3 class="bmr-v2-section-title">' . $formType . ' issuance record</h3>'
        . '<table><tr><th>' . $formType . ' issued to</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.' . $recordPrefix . '_issued_to', $fields, $editable)
        . '</td><th>Issued by</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.issued_by', $fields, $editable) . '</td></tr>'
        . '<tr><th>Date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.issued_to_date', $fields, $editable)
        . '</td><th>Date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.issued_by_date', $fields, $editable) . '</td></tr></table>'
        . '<div class="bmr-v2-cover-review">'
        . '<h3 class="bmr-v2-section-title">Review completion record</h3>'
        . '<table class="bmr-v2-tight">'
        . '<tr><th colspan="4">Production review completed</th></tr>'
        . '<tr><th>Name</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.production_review_name', $fields, $editable)
        . '</td><th>Signature</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.production_review_signature', $fields, $editable) . '</td></tr>'
        . '<tr><th>Designation</th><td>Head Production</td><th>Date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.production_review_date', $fields, $editable) . '</td></tr>'
        . '<tr><th colspan="4">QA review completed</th></tr>'
        . '<tr><th>Name</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.qa_review_name', $fields, $editable)
        . '</td><th>Signature</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.qa_review_signature', $fields, $editable) . '</td></tr>'
        . '<tr><th>Designation</th><td>Head QC/QA</td><th>Date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.qa_review_date', $fields, $editable) . '</td></tr>'
        . '<tr><th>Released</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.released', $fields, $editable)
        . '</td><th>Not released</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('cover.not_released', $fields, $editable) . '</td></tr>'
        . '</table></div>'
        . $approvalHtml;
}

function bmrBprStructuredAttachments(array $fields, bool $editable, array $profile = []): string
{
    $defaultDocuments = [
        'Material requisition note (process order)',
        'Line clearance check lists',
        'IP/RM COA (whatever is applicable)',
        'Requisition to QC for testing of intermediate samples',
        'QA batch review record',
    ];
    $documents = is_array($profile['attachment_documents'] ?? null)
        && $profile['attachment_documents'] !== []
        ? array_values($profile['attachment_documents'])
        : $defaultDocuments;
    $rows = '';
    foreach ($documents as $index => $name) {
        $base = 'attachments.' . $index;
        $rows .= '<tr><td class="bmr-v2-center">' . ($index + 1) . '</td>'
            . '<td>' . bmrBprStructuredEscape($name) . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.pages', $fields, $editable) . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.status', $fields, $editable) . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.initial_date', $fields, $editable) . '</td></tr>';
    }
    return '<h3 class="bmr-v2-section-title">1.0 List of attachments</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:9%">Sr. No.</th><th>Document name</th>'
        . '<th style="width:13%">No. of pages</th><th style="width:12%">Status</th>'
        . '<th style="width:17%">Initial/date</th></tr>' . $rows . '</table>'
        . '<p class="bmr-v2-note">Put ✓ if attached, X if not attached and NA if not applicable.</p>';
}

function bmrBprStructuredApprovalRows(array $fields, bool $editable, string $prefix): string
{
    return '<table class="bmr-v2-sign-grid" style="margin-top:2mm"><tr>'
        . '<th>Completed by</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField($prefix . '.completed_by', $fields, $editable)
        . '</td><th>Checked by</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField($prefix . '.checked_by', $fields, $editable)
        . '</td></tr><tr><th>Date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField($prefix . '.completed_date', $fields, $editable)
        . '</td><th>Date</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField($prefix . '.checked_date', $fields, $editable)
        . '</td></tr></table>';
}

function bmrBprRenderStructuredBmr(array $form, array $layout, array $profile, bool $editable): string
{
    $fields = bmrBprStructuredFields($form);
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    $document['branding_logo_data_uri'] = (string) ($form['branding_logo_data_uri'] ?? '');
    $source = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $total = max(3, min(6, (int) ($profile['page_count'] ?? 4)));
    $ingredients = is_array($profile['ingredients'] ?? null) ? $profile['ingredients'] : [];
    $steps = is_array($profile['manufacturing_steps'] ?? null) ? $profile['manufacturing_steps'] : [];
    $splitAt = max(0, min(count($steps), (int) ($profile['page3_step_count'] ?? count($steps))));
    $page3Steps = array_slice($steps, 0, $splitAt);
    $laterSteps = array_slice($steps, $splitAt);

    $contents = '<h3 class="bmr-v2-section-title">CONTENTS</h3>'
        . '<table><tr><th style="width:12%">Sr. no.</th><th>Contents</th></tr>'
        . '<tr><td>1.0</td><td>List of attachments</td></tr>'
        . '<tr><td>2.0</td><td>List of ingredients</td></tr>'
        . '<tr><td>3.0</td><td>Manufacturing stage A – Fabrication of reagents</td></tr></table>'
        . bmrBprStructuredAttachments($fields, $editable, $profile)
        . '<h3 class="bmr-v2-section-title">2.0 List of ingredients</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Item</th><th style="width:24%">Std. batch Qty. ('
        . bmrBprStructuredEscape($profile['standard_batch'] ?? '') . ')</th><th style="width:12%">Unit</th></tr>';
    foreach ($ingredients as $ingredient) {
        $contents .= '<tr><td>' . bmrBprStructuredEscape($ingredient['name'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($ingredient['quantity'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($ingredient['unit'] ?? '') . '</td></tr>';
    }
    $contents .= '</table>';

    $rmReferenceLabel = trim((string) ($profile['rm_reference_label'] ?? 'CAT No.'));
    $rmReferenceField = trim((string) ($profile['rm_reference_field'] ?? 'cat_no'));
    if ($rmReferenceField === '' || preg_match('/^[a-z][a-z0-9_]*$/', $rmReferenceField) !== 1) {
        $rmReferenceField = 'cat_no';
    }
    $rm = '<h3 class="bmr-v2-section-title">2.1 RM data sheet as per batch size</h3>'
        . '<p>Fill the data sheet during dispensing of each raw material.</p>'
        . '<table class="bmr-v2-tight"><tr><th style="width:31%">Item</th><th style="width:14%">'
        . bmrBprStructuredEscape($rmReferenceLabel) . '</th>'
        . '<th style="width:14%">Qty. as per batch size</th><th style="width:9%">Unit</th>'
        . '<th style="width:17%">Actual qty.</th><th style="width:9%">Unit</th></tr>';
    foreach ($ingredients as $ingredient) {
        $key = (string) ($ingredient['key'] ?? 'item');
        $rm .= '<tr><td>' . bmrBprStructuredEscape($ingredient['name'] ?? '') . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.' . $key . '.' . $rmReferenceField, $fields, $editable) . '</td>'
            . '<td>' . bmrBprStructuredEscape($ingredient['quantity'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($ingredient['unit'] ?? '') . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.' . $key . '.actual_qty', $fields, $editable) . '</td>'
            . '<td>' . bmrBprStructuredEscape($ingredient['unit'] ?? '') . '</td></tr>';
    }
    $rm .= '</table>'
        . '<table class="bmr-v2-sign-grid" style="margin-top:2mm"><tr>'
        . '<th>Dispensed by (Store)</th><th>Verified by (Production)</th><th>Checked by (QA)</th></tr><tr>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.dispensed_by', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.verified_by', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.checked_by', $fields, $editable) . '</td></tr></table>';

    $renderSteps = static function (array $items, int $offset, array $fields, bool $editable): string {
        if ($items === []) {
            return '';
        }
        $html = '<h3 class="bmr-v2-section-title">3.0 Manufacturing stage A - Fabrication of reagents</h3>'
            . '<p><strong>3.1 Line clearance of dispensing area</strong><br>3.1.1 Attach line clearance checklist</p>'
            . '<p><strong>3.2 Manufacturing instructions</strong></p>'
            . '<table class="bmr-v2-tight bmr-v2-step-table"><tr><th style="width:7%">Sr.</th>'
            . '<th>Manufacturing instructions</th><th style="width:14%">Carried out by (PDN)</th>'
            . '<th style="width:13%">Checked by (QA)</th></tr>';
        foreach ($items as $localIndex => $instruction) {
            $index = $offset + $localIndex;
            $html .= '<tr><td class="bmr-v2-center">' . ($index + 1) . '</td>'
                . '<td>' . bmrBprStructuredEscape($instruction) . '</td>'
                . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('manufacturing.steps.' . $index . '.carried_by', $fields, $editable) . '</td>'
                . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('manufacturing.steps.' . $index . '.checked_by', $fields, $editable) . '</td></tr>';
        }
        return $html . '</table>';
    };

    $ipqc = static function (array $profile, array $fields, bool $editable): string {
        $html = '<h3 class="bmr-v2-section-title">Mixing and IPQC</h3>'
            . '<table><tr><th>Mixing Start Time</th><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('manufacturing.mixing_start', $fields, $editable)
            . '</td><th>Mixing Stop Time</th><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('manufacturing.mixing_stop', $fields, $editable) . '</td></tr></table>'
            . '<p><strong>Intimate QC Personnel for IPQC Testing</strong></p><table>';
        foreach (($profile['ipqc_parameters'] ?? []) as $parameter) {
            $key = (string) ($parameter['key'] ?? 'parameter');
            $html .= '<tr><th style="width:26%">' . bmrBprStructuredEscape($parameter['label'] ?? '') . '</th>'
                . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('ipqc.' . $key . '.observed', $fields, $editable) . '</td>'
                . '<th style="width:28%">Specification</th><td>'
                . bmrBprStructuredEscape($parameter['specification'] ?? '') . '</td></tr>';
        }
        return $html . '</table>';
    };

    $notes = '<p class="bmr-v2-note"><strong>Caution:</strong> Wear gloves, mask and goggles during weighing of chemicals. Refer MSDS for detail.</p>'
        . '<ul class="bmr-v2-list"><li>Check calibration of all instruments used for fabrication.</li>'
        . '<li>Attach COA of IP reagents and QC testing requisition slip.</li></ul>';
    $completion = bmrBprStructuredApprovalRows($fields, $editable, 'completion');
    $qa = '<div class="bmr-v2-qa-box"><h3 class="bmr-v2-section-title">Quality Assurance Department</h3>'
        . '<p>On the basis of review, it is found satisfactory / not satisfactory. Therefore, product is released / not released for filling and packing.</p>'
        . '<table><tr><th>Decision / Remarks</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('qa.decision_remarks', $fields, $editable) . '</td></tr>'
        . '<tr><th>In charge Quality Assurance</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredSignatureAndDate('qa.incharge', $fields, $editable, 'qa.incharge_signature_date')
        . '</td></tr></table></div>';

    $pages = [];
    $pages[] = bmrBprStructuredPage(1, $total, $document, $profile, $source, 'BMR', bmrBprStructuredCover($profile, $fields, $editable, 'BMR'));
    $pages[] = bmrBprStructuredPage(2, $total, $document, $profile, $source, 'BMR', $contents);
    $showIpqc = !array_key_exists('show_ipqc', $profile) || !empty($profile['show_ipqc']);
    if ($total === 3) {
        $page3 = $rm . $renderSteps($steps, 0, $fields, $editable);
        if ($showIpqc) {
            $page3 .= $ipqc($profile, $fields, $editable);
        }
        $page3 .= $notes . $completion . $qa;
        $pages[] = bmrBprStructuredPage(3, $total, $document, $profile, $source, 'BMR', $page3);
        return implode('', $pages);
    }

    $page3 = $rm . $renderSteps($page3Steps, 0, $fields, $editable);
    if ($showIpqc && (int) ($profile['ipqc_page'] ?? 4) === 3) {
        $page3 .= $ipqc($profile, $fields, $editable) . $notes;
    } elseif (!$showIpqc) {
        $page3 .= $notes;
    }
    $pages[] = bmrBprStructuredPage(3, $total, $document, $profile, $source, 'BMR', $page3);
    $page4 = $renderSteps($laterSteps, $splitAt, $fields, $editable);
    if ($showIpqc && (int) ($profile['ipqc_page'] ?? 4) === 4) {
        $page4 .= $ipqc($profile, $fields, $editable) . $notes;
    }
    if ($total <= 5) {
        $page4 .= $completion;
    }
    if ($total === 4 && (int) ($profile['qa_page'] ?? 4) === 4) {
        $page4 .= $qa;
    }
    $pages[] = bmrBprStructuredPage(4, $total, $document, $profile, $source, 'BMR', $page4);
    if ($total === 5) {
        $pages[] = bmrBprStructuredPage(5, $total, $document, $profile, $source, 'BMR', $qa);
    } elseif ($total === 6) {
        $page5 = '<h3 class="bmr-v2-section-title">Manufacturing completion record</h3>'
            . '<p>Record the final batch observations and complete the production/QA verification.</p>'
            . '<table><tr><th style="width:28%">Final batch observations</th>'
            . '<td class="bmr-v2-input-cell">'
            . bmrBprStructuredTextarea('completion.batch_observations', $fields, $editable)
            . '</td></tr><tr><th>Deviation / remarks</th>'
            . '<td class="bmr-v2-input-cell">'
            . bmrBprStructuredTextarea('completion.deviation_remarks', $fields, $editable)
            . '</td></tr></table>'
            . $completion;
        $pages[] = bmrBprStructuredPage(5, $total, $document, $profile, $source, 'BMR', $page5);
        $pages[] = bmrBprStructuredPage(6, $total, $document, $profile, $source, 'BMR', $qa);
    }

    return implode('', $pages);
}

function bmrBprRenderStructuredBpr(array $form, array $layout, array $profile, bool $editable): string
{
    $fields = bmrBprStructuredFields($form);
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    $document['branding_logo_data_uri'] = (string) ($form['branding_logo_data_uri'] ?? '');
    $source = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $total = 8;
    $materials = is_array($profile['materials'] ?? null) ? $profile['materials'] : [];
    $equipment = is_array($profile['equipment'] ?? null) ? $profile['equipment'] : [];
    $hasSealing = !empty($profile['has_induction_sealing']);

    $page2 = '<h3 class="bmr-v2-section-title">CONTENTS</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:12%">Sr. no.</th><th>Contents</th></tr>';
    $contentRows = [
        'List of attachments',
        'List of ingredients',
        'Packing stage A - Dispensing of in-process / packing material',
        'Packing stage B - Washing & drying',
        $hasSealing ? 'Packing stage C - Dispensing & Sealing' : 'Packing stage C - Dispensing / filling',
        'Packing stage D - Coding',
        'Packing stage E - Labeling',
        'Packing stage F - Packing',
        'Packing stage G - Product transfer detail',
        'Production stage H - Yield detail',
    ];
    foreach ($contentRows as $index => $label) {
        $page2 .= '<tr><td>' . ($index + 1) . '.0</td><td>' . bmrBprStructuredEscape($label) . '</td></tr>';
    }
    $page2 .= '</table>' . bmrBprStructuredAttachments($fields, $editable, $profile);

    $page3 = '<h3 class="bmr-v2-section-title">2.0 List of ingredients</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Item</th><th style="width:20%">Std. batch Qty. ('
        . bmrBprStructuredEscape($profile['standard_batch'] ?? '') . ')</th><th style="width:12%">Unit</th></tr>';
    $currentGroup = '';
    foreach ($materials as $material) {
        $group = (string) ($material['group'] ?? '');
        if ($group !== $currentGroup) {
            $currentGroup = $group;
            $page3 .= '<tr><th colspan="3">' . bmrBprStructuredEscape($group) . '</th></tr>';
        }
        $page3 .= '<tr><td>' . bmrBprStructuredEscape($material['name'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($material['quantity'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($material['unit'] ?? '') . '</td></tr>';
    }
    $page3 .= '</table><h3 class="bmr-v2-section-title">3.0 Production stage A - Dispensing of materials</h3>'
        . '<p>Dispense all approved in-process and packing materials from stores after making the process order.</p>'
        . '<table class="bmr-v2-tight"><tr><th>Item</th><th style="width:17%">Batch/Lot no.</th>'
        . '<th style="width:15%">Qty. as per batch</th><th style="width:15%">Actual qty.</th>'
        . '<th style="width:9%">Unit</th></tr>';
    foreach ($materials as $material) {
        $key = (string) ($material['key'] ?? 'item');
        $page3 .= '<tr><td>' . bmrBprStructuredEscape($material['name'] ?? '') . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('materials.' . $key . '.lot_no', $fields, $editable) . '</td>'
            . '<td>' . bmrBprStructuredEscape($material['quantity'] ?? '') . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('materials.' . $key . '.actual_qty', $fields, $editable) . '</td>'
            . '<td>' . bmrBprStructuredEscape($material['unit'] ?? '') . '</td></tr>';
    }
    $page3 .= '</table>' . bmrBprStructuredApprovalRows($fields, $editable, 'materials');

    $stageC = $hasSealing ? 'Dispensing & Sealing' : 'Dispensing / filling';
    $page4 = '<h3 class="bmr-v2-section-title">4.0 Production stage B - Washing & drying</h3>'
        . '<p><strong>4.1 Line clearance:</strong> Attach line clearance checklist.</p>'
        . '<p><strong>4.2 Washing:</strong> Wash the tank after every subsequent batch / product change.</p>'
        . '<p><strong>4.3 Drying:</strong> Not applicable.</p>'
        . '<h3 class="bmr-v2-section-title">5.0 Production stage C - ' . bmrBprStructuredEscape($stageC) . '</h3>'
        . '<ol class="bmr-v2-list"><li>Use only dried containers for reagent dispensing/filling.</li>'
        . '<li>Dispensing and weighing machines must be cleaned and calibrated.</li>'
        . '<li>Keep containers closed and open only at filling to avoid contamination.</li>'
        . '<li>Dispense at 25 to 27°C.</li></ol>'
        . '<h3 class="bmr-v2-section-title">5.3 Equipment used and status</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Name of equipment</th><th style="width:26%">Equipment No/ID</th>'
        . '<th style="width:22%">Checked by</th></tr>';
    foreach ($equipment as $index => $item) {
        $page4 .= '<tr><td>' . bmrBprStructuredEscape($item['name'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($item['id'] ?? '') . '</td>'
            . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('washing.equipment.' . $index . '.checked_by', $fields, $editable) . '</td></tr>';
    }
    $page4 .= '</table><h3 class="bmr-v2-section-title">5.4 Standard volume for reagent</h3>'
        . '<table><tr><th>Name of reagent</th><th>Packing material used</th>'
        . '<th style="width:18%">Set up volume</th><th style="width:20%">Acceptable range</th></tr>'
        . '<tr><td>' . bmrBprStructuredEscape($profile['product_name'] ?? '') . '</td>'
        . '<td>' . bmrBprStructuredEscape($profile['packing_material'] ?? '') . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('filling.setup_volume', $fields, $editable) . '</td>'
        . '<td>' . bmrBprStructuredEscape($profile['acceptable_range'] ?? '') . '</td></tr></table>';

    $page5 = '<h3 class="bmr-v2-section-title">5.5 Dispensing / filling detail of reagents</h3>'
        . '<ul class="bmr-v2-list"><li>Assemble the filtering apparatus with 0.45μm and 0.22μm cartridge filters.</li>'
        . ($hasSealing
            ? '<li>After QC approval, fill the bottles with the specified accurate volume.</li>'
            : '<li>Set the filtration unit to the accurate dispensing volume.</li>')
        . '<li>Start dispensing and record the details below.</li></ul>'
        . '<table class="bmr-v2-tight"><tr><th>Date</th><th>Lot No.</th><th>Time</th><th>Volume</th>'
        . '<th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'filling.rows', 3) as $index) {
        $base = 'filling.rows.' . $index;
        $page5 .= '<tr>';
        foreach (['date', 'lot_no', 'time', 'volume', 'done_by', 'production', 'qa'] as $column) {
            $page5 .= '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $page5 .= '</tr>';
    }
    $page5 .= '</table><p class="bmr-v2-note"><strong>Caution:</strong> Wear gloves and mask during dispensing.</p>';
    if ($hasSealing) {
        $page5 .= '<h3 class="bmr-v2-section-title">5.6 Sealing details of reagents</h3>'
            . '<p>Close bottles with caps and induction wads, then seal using the Electro-Magnetic Induction Sealing machine.</p>'
            . '<table class="bmr-v2-tight"><tr><th>S. No.</th><th>Date</th><th>No. of kits sealed</th>'
            . '<th>Done by</th><th>Production</th><th>QA</th></tr>';
        foreach (bmrBprStructuredRowIndexes($fields, 'sealing.rows', 3) as $index) {
            $base = 'sealing.rows.' . $index;
            $page5 .= '<tr><td>' . ($index + 1) . '</td>';
            foreach (['date', 'quantity', 'done_by', 'production', 'qa'] as $column) {
                $page5 .= '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
            }
            $page5 .= '</tr>';
        }
        $page5 .= '</table>';
    }
    $page5 .= '<h3 class="bmr-v2-section-title">6.0 Production stage D - Coding</h3>'
        . '<p>Attach the line clearance checklist and print the approved details on all labels.</p>';

    $page6 = '<h3 class="bmr-v2-section-title">6.3 Detail of coding</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Date</th><th>Batch No.</th><th>Mfg. date</th>'
        . '<th>Exp. date</th><th>MRP</th><th>Qty.</th><th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'coding.rows', 2) as $index) {
        $base = 'coding.rows.' . $index;
        $page6 .= '<tr>';
        foreach (['date', 'batch_no', 'mfg_date', 'exp_date', 'mrp', 'quantity', 'done_by', 'production', 'qa'] as $column) {
            $page6 .= '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $page6 .= '</tr>';
    }
    $page6 .= '</table><h3 class="bmr-v2-section-title">6.4 Label proof</h3>'
        . '<p>Paste one coded and approved label of each reagent as a reference below.</p>'
        . '<div class="bmr-v2-blank-box">' . bmrBprStructuredTextarea('coding.label_proof_reference', $fields, $editable) . '</div>'
        . '<h3 class="bmr-v2-section-title">7.0 Production stage E - Labeling</h3>'
        . '<ol class="bmr-v2-list"><li>Ensure the label belongs to the reagent being labeled.</li>'
        . '<li>Apply the label straight, completely adhered and centered on the container.</li>'
        . '<li>Record the labeling details on the next page.</li></ol>';

    $packingText = $hasSealing
        ? 'Pack the bottles in corrugated boxes.'
        : 'Tape the box with white tape and strap it through the strapping machine.';
    $page7 = '<h3 class="bmr-v2-section-title">7.2 Labeling details</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Date</th><th>Name of reagent / label</th>'
        . '<th>Labeled Qty.</th><th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'labeling.rows', 2) as $index) {
        $base = 'labeling.rows.' . $index;
        $page7 .= '<tr><td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.date', $fields, $editable) . '</td>'
            . '<td>' . bmrBprStructuredEscape($profile['product_name'] ?? '') . '</td>';
        foreach (['quantity', 'done_by', 'production', 'qa'] as $column) {
            $page7 .= '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $page7 .= '</tr>';
    }
    $page7 .= '</table><p class="bmr-v2-note">Destroy remaining printed labels after completion and record them below.</p>'
        . '<h3 class="bmr-v2-section-title">8.0 Production stage F - Packing</h3>'
        . '<p>' . bmrBprStructuredEscape($packingText) . '</p>'
        . '<table class="bmr-v2-tight"><tr><th>S. No.</th><th>Date</th><th>No. of kits packed</th>'
        . '<th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'packing.rows', 2) as $index) {
        $base = 'packing.rows.' . $index;
        $page7 .= '<tr><td>' . ($index + 1) . '</td>';
        foreach (['date', 'quantity', 'done_by', 'production', 'qa'] as $column) {
            $page7 .= '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $page7 .= '</tr>';
    }
    $page7 .= '</table><h3 class="bmr-v2-section-title">8.3 Destruction table of coded packing material</h3>'
        . '<table><tr><th>Date</th><th>Name of reagent/label</th><th>Quantity</th>'
        . '<th>Done by</th><th>Production</th><th>QA</th></tr><tr>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('packing.destruction.date', $fields, $editable) . '</td>'
        . '<td>' . bmrBprStructuredEscape($profile['product_name'] ?? '') . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('packing.destruction.quantity', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('packing.destruction.done_by', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('packing.destruction.production', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('packing.destruction.qa', $fields, $editable) . '</td></tr></table>'
        . '<h3 class="bmr-v2-section-title">9.0 Production stage G - Product transfer detail</h3>'
        . '<p>Send the BPR to QA for final approval and release before transfer to the finished-goods store.</p>';

    $page8 = '<h3 class="bmr-v2-section-title">9.3 Product transfer record</h3>'
        . '<table class="bmr-v2-tight"><tr><th>TT date</th><th>TT number</th><th>Total quantity produced</th>'
        . '<th>Transferred by</th><th>Store</th><th>QC</th><th>Production</th><th>QA</th><th>Received Store</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'transfer.rows', 2) as $index) {
        $base = 'transfer.rows.' . $index;
        $page8 .= '<tr>';
        foreach (['date', 'number', 'quantity', 'transferred_by', 'store', 'qc', 'production', 'qa', 'received_store'] as $column) {
            $page8 .= '<td class="bmr-v2-input-cell">' . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $page8 .= '</tr>';
    }
    $page8 .= '</table><h3 class="bmr-v2-section-title">10.0 Production stage H - Yield detail</h3>'
        . '<p>Calculate the yield and record it below.</p>'
        . '<table><tr><th>Actual quantity produced</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.actual_quantity', $fields, $editable)
        . '</td><th>Batch size</th><td>' . bmrBprStructuredEscape($source['batch_size'] ?? $profile['standard_batch'] ?? '') . '</td></tr>'
        . '<tr><th>Standard yield</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.standard', $fields, $editable)
        . '</td><th>Yield achieved</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.achieved', $fields, $editable) . '</td></tr>'
        . '<tr><th>Remarks</th><td colspan="3" class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('yield.remarks', $fields, $editable) . '</td></tr></table>'
        . bmrBprStructuredApprovalRows($fields, $editable, 'yield')
        . '<div class="bmr-v2-qa-box"><h3 class="bmr-v2-section-title">Quality Assurance Department</h3>'
        . '<p>On the basis of review, the BPR is found satisfactory / not satisfactory.</p>'
        . '<table><tr><th>Decision / Remarks</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('qa.decision_remarks', $fields, $editable) . '</td></tr>'
        . '<tr><th>In charge Quality Assurance</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredSignatureAndDate('qa.incharge', $fields, $editable, 'qa.incharge_signature_date')
        . '</td></tr></table></div>';

    $pages = [
        bmrBprStructuredPage(1, $total, $document, $profile, $source, 'BPR', bmrBprStructuredCover($profile, $fields, $editable, 'BPR')),
        bmrBprStructuredPage(2, $total, $document, $profile, $source, 'BPR', $page2),
        bmrBprStructuredPage(3, $total, $document, $profile, $source, 'BPR', $page3),
        bmrBprStructuredPage(4, $total, $document, $profile, $source, 'BPR', $page4),
        bmrBprStructuredPage(5, $total, $document, $profile, $source, 'BPR', $page5),
        bmrBprStructuredPage(6, $total, $document, $profile, $source, 'BPR', $page6),
        bmrBprStructuredPage(7, $total, $document, $profile, $source, 'BPR', $page7),
        bmrBprStructuredPage(8, $total, $document, $profile, $source, 'BPR', $page8),
    ];
    return implode('', $pages);
}

function bmrBprRenderStructuredProfiledBpr(
    array $form,
    array $layout,
    array $profile,
    bool $editable
): string {
    $fields = bmrBprStructuredFields($form);
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    $document['branding_logo_data_uri'] = (string) ($form['branding_logo_data_uri'] ?? '');
    $source = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $configuredPageCount = (int) ($profile['page_count'] ?? 12);
    $total = in_array($configuredPageCount, [8, 9, 10, 11, 12], true)
        ? $configuredPageCount
        : 12;
    $reagents = is_array($profile['reagents'] ?? null) ? array_values($profile['reagents']) : [];
    $packingMaterials = is_array($profile['packing_materials'] ?? null)
        ? array_values($profile['packing_materials'])
        : [];
    $reagentQuantities = is_array($profile['reagent_quantities'] ?? null)
        ? $profile['reagent_quantities']
        : [];
    $packingQuantities = is_array($profile['packing_quantities'] ?? null)
        ? $profile['packing_quantities']
        : [];
    $equipment = is_array($profile['equipment'] ?? null) ? $profile['equipment'] : [];
    $packSize = (string) ($profile['pack_size'] ?? $profile['standard_batch'] ?? '');

    $safeKey = static function (mixed $value, string $fallback): string {
        $key = strtolower(trim((string) $value));
        $key = preg_replace('/[^a-z0-9_]+/', '_', $key) ?? '';
        $key = trim($key, '_');
        return $key !== '' ? $key : $fallback;
    };
    $materials = [];
    foreach ($reagents as $index => $reagent) {
        $key = $safeKey($reagent['key'] ?? null, 'reagent_' . ($index + 1));
        $materials[] = [
            'key' => $key,
            'group' => 'In-process material / Raw material',
            'name' => (string) ($reagent['name'] ?? ''),
            'quantity' => (string) ($reagentQuantities[$key] ?? ''),
            'unit' => (string) ($reagent['unit'] ?? 'ml'),
        ];
    }
    foreach ($packingMaterials as $index => $material) {
        $key = $safeKey($material['key'] ?? null, 'packing_' . ($index + 1));
        $materials[] = [
            'key' => $key,
            'group' => 'Packing material',
            'name' => (string) ($material['name'] ?? ''),
            'quantity' => (string) ($packingQuantities[$key] ?? ''),
            'unit' => (string) ($material['unit'] ?? 'Nos.'),
        ];
    }

    $contents = '<h3 class="bmr-v2-section-title">CONTENTS</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:12%">Sr. no.</th><th>Contents</th></tr>';
    $contentRows = [
        'List of attachments',
        'List of ingredients',
        'Production stage A - Dispensing of in-process / packing material',
        'Production stage B - Washing & drying',
        'Production stage C - Dispensing / filling',
        'Production stage D - Printing',
        'Production stage E - Labeling',
        'Production stage F - Packing',
        'Production stage G - Product transfer detail',
        'Production stage H - Yield detail',
    ];
    foreach ($contentRows as $index => $label) {
        $contents .= '<tr><td>' . ($index + 1) . '.0</td><td>'
            . bmrBprStructuredEscape($label) . '</td></tr>';
    }
    $contents .= '</table>' . bmrBprStructuredAttachments($fields, $editable, $profile);

    $ingredientTable = '<h3 class="bmr-v2-section-title">2.0 List of ingredients</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Item</th><th style="width:21%">Std. batch Qty. ('
        . bmrBprStructuredEscape($profile['standard_batch'] ?? $packSize)
        . ')</th><th style="width:12%">Unit</th></tr>';
    $currentGroup = '';
    foreach ($materials as $material) {
        if ($material['group'] !== $currentGroup) {
            $currentGroup = $material['group'];
            $ingredientTable .= '<tr><th colspan="3">'
                . bmrBprStructuredEscape($currentGroup) . '</th></tr>';
        }
        $ingredientTable .= '<tr><td>' . bmrBprStructuredEscape($material['name'])
            . '</td><td>' . bmrBprStructuredEscape($material['quantity'])
            . '</td><td>' . bmrBprStructuredEscape($material['unit']) . '</td></tr>';
    }
    $ingredientTable .= '</table>';

    $dispensingRows = static function (
        array $items,
        array $fields,
        bool $editable,
        string $heading,
        bool $includeHeading
    ): string {
        $html = $includeHeading
            ? '<h3 class="bmr-v2-section-title">3.0 Production stage A - Dispensing of materials</h3>'
                . '<p>Dispense all approved in-process and packing materials from stores after making the process order.</p>'
            : '';
        $html .= '<h4 class="bmr-v2-subtitle">' . bmrBprStructuredEscape($heading) . '</h4>'
            . '<table class="bmr-v2-tight"><tr><th>Item</th><th style="width:18%">Batch/Lot no.</th>'
            . '<th style="width:15%">Qty. as per batch</th><th style="width:15%">Actual qty.</th>'
            . '<th style="width:9%">Unit</th></tr>';
        foreach ($items as $material) {
            $base = 'dispensing.' . (string) $material['key'];
            $html .= '<tr><td>' . bmrBprStructuredEscape($material['name']) . '</td>'
                . '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.lot_no', $fields, $editable) . '</td>'
                . '<td>' . bmrBprStructuredEscape($material['quantity']) . '</td>'
                . '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.actual_qty', $fields, $editable) . '</td>'
                . '<td>' . bmrBprStructuredEscape($material['unit']) . '</td></tr>';
        }
        return $html . '</table>';
    };
    $splitAt = max(1, min(count($materials), (int) ($profile['page3_material_count'] ?? 6)));
    $firstMaterials = array_slice($materials, 0, $splitAt);
    $laterMaterials = array_slice($materials, $splitAt);
    $page3 = $ingredientTable
        . $dispensingRows($firstMaterials, $fields, $editable, 'Dispensing record - Part 1', true);
    $page4 = $dispensingRows($laterMaterials, $fields, $editable, 'Dispensing record - Part 2', false)
        . bmrBprStructuredApprovalRows($fields, $editable, 'dispensing')
        . '<h3 class="bmr-v2-section-title">4.0 Production stage B - Washing & drying</h3>'
        . '<p>Line clearance, washing and drying are not applicable for this kit. Record any deviation in the batch remarks.</p>'
        . '<h3 class="bmr-v2-section-title">5.0 Production stage C - Dispensing / filling</h3>'
        . '<p>Attach the dispensing/filling-area line clearance checklist before starting work.</p>';

    $fillingSetup = '<h3 class="bmr-v2-section-title">5.2 Dispensing / filling instructions</h3>'
        . '<ol class="bmr-v2-list"><li>Use only dried containers for reagent dispensing/filling.</li>'
        . '<li>Dispensing and weighing machines must be cleaned and calibrated.</li>'
        . '<li>Keep containers closed and open them only during filling to avoid contamination.</li>'
        . '<li>Dispense at 25 to 27°C and record the approved setup volume.</li></ol>'
        . '<h3 class="bmr-v2-section-title">5.3 Equipment used and status</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Name of equipment</th><th style="width:27%">Equipment No/ID</th>'
        . '<th style="width:22%">Checked by</th></tr>';
    foreach ($equipment as $index => $item) {
        $fillingSetup .= '<tr><td>' . bmrBprStructuredEscape($item['name'] ?? '') . '</td>'
            . '<td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('washing.equipment.' . $index . '.equipment_id', $fields, $editable)
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('washing.equipment.' . $index . '.checked_by', $fields, $editable)
            . '</td></tr>';
    }
    $fillingSetup .= '</table><p class="bmr-v2-note">Put NA where an equipment item is not applicable.</p>'
        . '<h3 class="bmr-v2-section-title">5.4 Standard volume for reagent</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Name of reagent</th><th>Packing material used</th>'
        . '<th style="width:18%">Set up volume</th><th style="width:18%">Acceptable range</th></tr>';
    foreach ($reagents as $index => $reagent) {
        $key = $safeKey($reagent['key'] ?? null, 'reagent_' . ($index + 1));
        $fillingSetup .= '<tr><td>' . bmrBprStructuredEscape($reagent['name'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($reagent['container'] ?? '4 ml Glass Vials') . '</td>'
            . '<td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('filling.' . $key . '.setup_volume', $fields, $editable) . '</td>'
            . '<td>' . bmrBprStructuredEscape($reagent['acceptable_range'] ?? '') . '</td></tr>';
    }
    $fillingSetup .= '</table>';

    $fillingDetail = '<h3 class="bmr-v2-section-title">5.5 Dispensing / filling detail of reagents</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Name of reagent</th><th>Pack size</th><th>Time</th>'
        . '<th>Volume</th><th>Lot No.</th><th>Exp. date</th><th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach ($reagents as $index => $reagent) {
        $key = $safeKey($reagent['key'] ?? null, 'reagent_' . ($index + 1));
        $base = 'filling.' . $key;
        $fillingDetail .= '<tr><td>' . bmrBprStructuredEscape($reagent['name'] ?? '') . '</td>'
            . '<td>' . bmrBprStructuredEscape($packSize) . '</td>';
        foreach (['time', 'volume', 'lot_no', 'exp_date', 'done_by', 'production', 'qa'] as $column) {
            $fillingDetail .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $fillingDetail .= '</tr>';
    }
    $fillingDetail .= '</table><p class="bmr-v2-note"><strong>Caution:</strong> Wear gloves and a mask during dispensing.</p>';

    $labelItems = [];
    foreach ($reagents as $index => $reagent) {
        $labelItems[] = [
            'key' => $safeKey($reagent['key'] ?? null, 'reagent_' . ($index + 1)),
            'name' => (string) ($reagent['name'] ?? ''),
        ];
    }
    $labelItems[] = ['key' => 'box_labels', 'name' => 'Box Labels'];

    $printing = '<h3 class="bmr-v2-section-title">6.0 Production stage D - Printing</h3>'
        . '<p>Attach the printing-area line clearance checklist. Print the approved details on all labels and record them below.</p>'
        . '<table class="bmr-v2-tight"><tr><th>Date</th><th>Name of reagent/label</th><th>Batch No.</th>'
        . '<th>Mfg. date</th><th>Exp. date</th><th>MRP</th><th>Qty.</th><th>Done by</th>'
        . '<th>Production</th><th>QA</th></tr>';
    foreach ($labelItems as $item) {
        $base = 'coding.' . $item['key'];
        $printing .= '<tr><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.date', $fields, $editable) . '</td><td>'
            . bmrBprStructuredEscape($item['name']) . '</td>';
        foreach (['batch_no', 'mfg_date', 'exp_date', 'mrp', 'quantity', 'done_by', 'production', 'qa'] as $column) {
            $printing .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $printing .= '</tr>';
    }
    $printing .= '</table><p class="bmr-v2-note">Avoid skin or eye contact and inhalation of printing chemicals.</p>';

    $labelProof = '<h3 class="bmr-v2-section-title">6.4 Label proof</h3>'
        . '<p>Paste or reference one printed and approved label of each reagent below.</p>'
        . '<div class="bmr-v2-blank-box">'
        . bmrBprStructuredTextarea('coding.label_proof_reference', $fields, $editable)
        . '</div>';
    $labelingIntro = '<h3 class="bmr-v2-section-title">7.0 Production stage E - Labeling</h3>'
        . '<ol class="bmr-v2-list"><li>Attach the labeling-area line clearance checklist.</li>'
        . '<li>Confirm each label belongs to the reagent being labeled.</li>'
        . '<li>Apply labels straight, fully adhered and centered on the container.</li></ol>';
    $labelingTable = '<h3 class="bmr-v2-section-title">7.2 Labeling details</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Date</th><th>Name of reagent/label</th>'
        . '<th>Labeled Qty.</th><th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach ($labelItems as $item) {
        $base = 'labeling.' . $item['key'];
        $labelingTable .= '<tr><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.date', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($item['name']) . '</td>';
        foreach (['quantity', 'done_by', 'production', 'qa'] as $column) {
            $labelingTable .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $labelingTable .= '</tr>';
    }
    $labelingTable .= '</table>';

    $packing = '<p class="bmr-v2-note">Destroy remaining printed labels after completion and record them in the destruction table.</p>'
        . '<h3 class="bmr-v2-section-title">8.0 Production stage F - Packing</h3>'
        . '<p>Attach the packing-area line clearance checklist and record completed kits below.</p>'
        . '<table class="bmr-v2-tight"><tr><th>S. No.</th><th>Date</th><th>Pack size</th>'
        . '<th>No. of kits packed</th><th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'packing.rows', 4) as $index) {
        $base = 'packing.rows.' . $index;
        $packing .= '<tr><td>' . ($index + 1) . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.date', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($packSize) . '</td>';
        foreach (['quantity', 'done_by', 'production', 'qa'] as $column) {
            $packing .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $packing .= '</tr>';
    }
    $packing .= '</table>';

    $destruction = '<h3 class="bmr-v2-section-title">8.3 Destruction table of printed packing material</h3>'
        . '<table class="bmr-v2-tight"><tr><th>Date</th><th>Name of reagent/label</th>'
        . '<th>Quantity</th><th>Done by</th><th>Production</th><th>QA</th></tr>';
    foreach ($labelItems as $item) {
        $base = 'packing.destruction.' . $item['key'];
        $destruction .= '<tr><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.date', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($item['name']) . '</td>';
        foreach (['quantity', 'done_by', 'production', 'qa'] as $column) {
            $destruction .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $destruction .= '</tr>';
    }
    $destruction .= '</table>';

    $transfer = '<h3 class="bmr-v2-section-title">9.0 Production stage G - Product transfer detail</h3>'
        . '<p>After QA release, hand over the material to the finished-goods store with the signed transfer ticket.</p>'
        . '<table class="bmr-v2-tight"><tr><th>TT date</th><th>TT number</th><th>Pack size</th>'
        . '<th>Total quantity produced</th><th>Transferred by</th><th>Store</th><th>QC</th>'
        . '<th>Production</th><th>QA</th><th>Received Store</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'transfer.rows', 3) as $index) {
        $base = 'transfer.rows.' . $index;
        $transfer .= '<tr>';
        foreach (['date', 'number'] as $column) {
            $transfer .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $transfer .= '<td>' . bmrBprStructuredEscape($packSize) . '</td>';
        foreach (['quantity', 'transferred_by', 'store', 'qc', 'production', 'qa', 'received_store'] as $column) {
            $transfer .= '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField($base . '.' . $column, $fields, $editable) . '</td>';
        }
        $transfer .= '</tr>';
    }
    $transfer .= '</table>';

    $yield = '<h3 class="bmr-v2-section-title">10.0 Production stage H - Yield detail</h3>'
        . '<p>Calculate the yield as (quantity produced ÷ batch size) × 100 and record it below.</p>'
        . '<table><tr><th>Batch size</th><td>'
        . bmrBprStructuredEscape($source['batch_size'] ?? $profile['standard_batch'] ?? '')
        . '</td><th>Quantity produced</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.actual_quantity', $fields, $editable) . '</td></tr>'
        . '<tr><th>Standard yield</th><td>'
        . bmrBprStructuredEscape($profile['standard_yield'] ?? '')
        . '</td><th>Yield achieved</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.achieved', $fields, $editable) . '</td></tr>'
        . '<tr><th>Remarks</th><td colspan="3" class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('yield.remarks', $fields, $editable) . '</td></tr></table>'
        . bmrBprStructuredApprovalRows($fields, $editable, 'yield')
        . '<div class="bmr-v2-qa-box"><h3 class="bmr-v2-section-title">Quality Assurance Department</h3>'
        . '<p>On the basis of review, the BPR is found satisfactory / not satisfactory.</p>'
        . '<table><tr><th>Decision / Remarks</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('qa.decision_remarks', $fields, $editable) . '</td></tr>'
        . '<tr><th>In charge Quality Assurance</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredSignatureAndDate('qa.incharge', $fields, $editable, 'qa.incharge_signature_date')
        . '</td></tr></table></div>';

    if ($total === 8) {
        $pageContents = [
            bmrBprStructuredCover($profile, $fields, $editable, 'BPR'),
            $contents,
            $page3,
            $page4 . $fillingSetup,
            $fillingDetail . $printing,
            $labelProof . $labelingIntro . $labelingTable,
            $packing . $destruction,
            $transfer . $yield,
        ];
    } elseif ($total === 9) {
        $pageContents = [
            bmrBprStructuredCover($profile, $fields, $editable, 'BPR'),
            $contents,
            $page3,
            $page4,
            $fillingSetup . $fillingDetail,
            $printing,
            $labelProof . $labelingIntro . $labelingTable,
            $packing . $destruction,
            $transfer . $yield,
        ];
    } elseif ($total === 10) {
        $pageContents = [
            bmrBprStructuredCover($profile, $fields, $editable, 'BPR'),
            $contents,
            $page3,
            $page4,
            $fillingSetup . $fillingDetail,
            $printing,
            $labelProof . $labelingIntro,
            $labelingTable . $packing,
            $destruction . $transfer,
            $yield,
        ];
    } elseif ($total === 11) {
        $pageContents = [
            bmrBprStructuredCover($profile, $fields, $editable, 'BPR'),
            $contents,
            $page3,
            $page4,
            $fillingSetup,
            $fillingDetail,
            $printing,
            $labelProof,
            $labelingIntro . $labelingTable,
            $packing . $destruction,
            $transfer . $yield,
        ];
    } else {
        $pageContents = [
            bmrBprStructuredCover($profile, $fields, $editable, 'BPR'),
            $contents,
            $page3,
            $page4,
            $fillingSetup,
            $fillingDetail,
            $printing,
            $labelProof,
            $labelingIntro . $labelingTable,
            $packing . $destruction,
            $transfer,
            $yield,
        ];
    }

    $pages = [];
    foreach ($pageContents as $index => $content) {
        $pages[] = bmrBprStructuredPage(
            $index + 1,
            $total,
            $document,
            $profile,
            $source,
            'BPR',
            $content
        );
    }
    return implode('', $pages);
}

function bmrBprRenderStructuredUrologyBmr(
    array $form,
    array $layout,
    array $profile,
    bool $editable
): string {
    $fields = bmrBprStructuredFields($form);
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    $document['branding_logo_data_uri'] = (string) ($form['branding_logo_data_uri'] ?? '');
    $source = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $configuredPageCount = (int) ($profile['page_count'] ?? 4);
    $total = in_array($configuredPageCount, [4, 5, 6, 7], true)
        ? $configuredPageCount
        : 4;
    $ingredients = is_array($profile['ingredients'] ?? null)
        ? array_values($profile['ingredients'])
        : [];
    $steps = is_array($profile['manufacturing_steps'] ?? null)
        ? array_values($profile['manufacturing_steps'])
        : [];

    $contents = '<div class="bmr-v2-urology-materials">'
        . '<p class="bmr-v2-note"><strong>CONTENTS:</strong> '
        . '1.0 List of attachments; 2.0 List of ingredients; '
        . '3.0 Manufacturing stage A - Fabrication and assembly of urine reagent strips.</p>'
        . bmrBprStructuredAttachments($fields, $editable, $profile)
        . '<h3 class="bmr-v2-section-title">2.0 List of ingredients</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:18%">Material type</th><th>Item</th>'
        . '<th style="width:18%">Std. batch Qty. ('
        . bmrBprStructuredEscape($profile['standard_batch'] ?? '')
        . ')</th><th style="width:10%">Unit</th></tr>';
    foreach ($ingredients as $ingredient) {
        $contents .= '<tr><td>'
            . bmrBprStructuredEscape($ingredient['group'] ?? 'Raw material / in-process material')
            . '</td><td>' . bmrBprStructuredEscape($ingredient['name'] ?? '')
            . '</td><td>' . bmrBprStructuredEscape($ingredient['quantity'] ?? '')
            . '</td><td>' . bmrBprStructuredEscape($ingredient['unit'] ?? '')
            . '</td></tr>';
    }
    $contents .= '</table></div>';

    $dispensing = '<div class="bmr-v2-urology-materials">'
        . '<h3 class="bmr-v2-section-title">2.1 RM/PM data sheet as per batch size</h3>'
        . '<p>Fill the data sheet while dispensing every approved raw, in-process and packing material.</p>'
        . '<table class="bmr-v2-tight"><tr><th style="width:30%">Item</th>'
        . '<th style="width:17%">Batch/Lot no.</th><th style="width:15%">Qty. as per batch</th>'
        . '<th style="width:15%">Actual qty.</th><th style="width:9%">Unit</th></tr>';
    foreach ($ingredients as $index => $ingredient) {
        $key = strtolower(trim((string) ($ingredient['key'] ?? 'item_' . ($index + 1))));
        $key = preg_replace('/[^a-z0-9_]+/', '_', $key) ?: 'item_' . ($index + 1);
        $dispensing .= '<tr><td>' . bmrBprStructuredEscape($ingredient['name'] ?? '')
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('rm.' . $key . '.lot_no', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($ingredient['quantity'] ?? '')
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('rm.' . $key . '.actual_qty', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($ingredient['unit'] ?? '')
            . '</td></tr>';
    }
    $dispensing .= '</table>'
        . '<table class="bmr-v2-sign-grid" style="margin-top:2mm"><tr>'
        . '<th>Dispensed by (Store)</th><th>Verified by (Production)</th><th>Checked by (QA)</th></tr><tr>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.dispensed_by', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.verified_by', $fields, $editable) . '</td>'
        . '<td class="bmr-v2-input-cell">' . bmrBprStructuredField('rm.checked_by', $fields, $editable) . '</td>'
        . '</tr></table></div>';

    $renderSteps = static function (
        array $pageSteps,
        int $offset,
        array $fields,
        bool $editable
    ): string {
        if ($pageSteps === []) {
            return '';
        }
        $html = '<h3 class="bmr-v2-section-title">3.0 Manufacturing stage A - Fabrication and assembly</h3>'
            . '<p><strong>Line clearance:</strong> Attach the approved dispensing/manufacturing-area checklist.</p>'
            . '<table class="bmr-v2-tight bmr-v2-step-table"><tr><th style="width:7%">Sr.</th>'
            . '<th>Manufacturing instruction</th><th style="width:14%">Carried out by</th>'
            . '<th style="width:13%">Production</th><th style="width:11%">QA</th></tr>';
        foreach ($pageSteps as $localIndex => $instruction) {
            $index = $offset + $localIndex;
            $html .= '<tr><td class="bmr-v2-center">' . ($index + 1) . '</td><td>'
                . bmrBprStructuredEscape($instruction) . '</td>'
                . '<td class="bmr-v2-input-cell">'
                . bmrBprStructuredField('manufacturing.steps.' . $index . '.carried_by', $fields, $editable)
                . '</td><td class="bmr-v2-input-cell">'
                . bmrBprStructuredField('manufacturing.steps.' . $index . '.production', $fields, $editable)
                . '</td><td class="bmr-v2-input-cell">'
                . bmrBprStructuredField('manufacturing.steps.' . $index . '.qa', $fields, $editable)
                . '</td></tr>';
        }
        return $html . '</table>';
    };

    $completion = '<p class="bmr-v2-note"><strong>Caution:</strong> Wear gloves and a mask. Maintain the source-specified temperature and humidity and verify instrument calibration.</p>'
        . bmrBprStructuredApprovalRows($fields, $editable, 'completion')
        . '<div class="bmr-v2-qa-box"><h3 class="bmr-v2-section-title">Quality Assurance Department</h3>'
        . '<p>On review, the BMR is satisfactory / not satisfactory and the product is released / not released for the next stage.</p>'
        . '<table><tr><th>Decision / Remarks</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('qa.decision_remarks', $fields, $editable) . '</td></tr>'
        . '<tr><th>Head Quality Assurance</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredSignatureAndDate('qa.incharge', $fields, $editable, 'qa.incharge_signature_date')
        . '</td></tr></table></div>';

    $pages = [
        bmrBprStructuredPage(
            1,
            $total,
            $document,
            $profile,
            $source,
            'BMR',
            bmrBprStructuredCover($profile, $fields, $editable, 'BMR'),
            'bmr-v2-urology-cover-page'
        ),
        bmrBprStructuredPage(2, $total, $document, $profile, $source, 'BMR', $contents),
        bmrBprStructuredPage(3, $total, $document, $profile, $source, 'BMR', $dispensing),
    ];

    if ($total === 4) {
        $pages[] = bmrBprStructuredPage(
            4,
            $total,
            $document,
            $profile,
            $source,
            'BMR',
            $renderSteps($steps, 0, $fields, $editable) . $completion
        );
        return implode('', $pages);
    }

    $stagePageCount = $total - 4;
    $stepOffset = 0;
    for ($slot = 0; $slot < $stagePageCount; $slot++) {
        $remainingSteps = count($steps) - $stepOffset;
        $remainingPages = $stagePageCount - $slot;
        $take = $remainingPages > 0
            ? (int) ceil(max(0, $remainingSteps) / $remainingPages)
            : 0;
        $pageSteps = array_slice($steps, $stepOffset, $take);
        $pages[] = bmrBprStructuredPage(
            4 + $slot,
            $total,
            $document,
            $profile,
            $source,
            'BMR',
            $renderSteps($pageSteps, $stepOffset, $fields, $editable)
        );
        $stepOffset += $take;
    }
    $remainingSteps = array_slice($steps, $stepOffset);
    $pages[] = bmrBprStructuredPage(
        $total,
        $total,
        $document,
        $profile,
        $source,
        'BMR',
        $renderSteps($remainingSteps, $stepOffset, $fields, $editable) . $completion
    );
    return implode('', $pages);
}

function bmrBprRenderStructuredUrologyBpr(
    array $form,
    array $layout,
    array $profile,
    bool $editable
): string {
    $fields = bmrBprStructuredFields($form);
    $document = is_array($layout['document'] ?? null) ? $layout['document'] : [];
    $document['branding_logo_data_uri'] = (string) ($form['branding_logo_data_uri'] ?? '');
    $source = is_array($form['source_values'] ?? null) ? $form['source_values'] : [];
    $configuredPageCount = (int) ($profile['page_count'] ?? 8);
    $total = in_array($configuredPageCount, [6, 7, 8], true)
        ? $configuredPageCount
        : 8;
    $materials = is_array($profile['materials'] ?? null)
        ? array_values($profile['materials'])
        : [];
    $stages = is_array($profile['production_stages'] ?? null)
        ? array_values($profile['production_stages'])
        : [];

    $contents = '<h3 class="bmr-v2-section-title">CONTENTS</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:12%">Sr. no.</th><th>Contents</th></tr>'
        . '<tr><td>1.0</td><td>List of attachments</td></tr>'
        . '<tr><td>2.0</td><td>List of ingredients</td></tr>'
        . '<tr><td>3.0</td><td>Dispensing of in-process / packing material</td></tr>';
    foreach ($stages as $index => $stage) {
        $contents .= '<tr><td>' . ($index + 4) . '.0</td><td>'
            . bmrBprStructuredEscape($stage['title'] ?? '') . '</td></tr>';
    }
    $contents .= '</table>' . bmrBprStructuredAttachments($fields, $editable, $profile);

    $materialsPage = '<h3 class="bmr-v2-section-title">2.0 List of ingredients</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:18%">Material type</th><th>Item</th>'
        . '<th style="width:18%">Std. batch Qty. ('
        . bmrBprStructuredEscape($profile['standard_batch'] ?? '')
        . ')</th><th style="width:10%">Unit</th></tr>';
    foreach ($materials as $material) {
        $materialsPage .= '<tr><td>'
            . bmrBprStructuredEscape($material['group'] ?? 'Packing material')
            . '</td><td>' . bmrBprStructuredEscape($material['name'] ?? '')
            . '</td><td>' . bmrBprStructuredEscape($material['quantity'] ?? '')
            . '</td><td>' . bmrBprStructuredEscape($material['unit'] ?? '')
            . '</td></tr>';
    }
    $materialsPage .= '</table>'
        . '<h3 class="bmr-v2-section-title">3.0 Dispensing of in-process / packing material</h3>'
        . '<table class="bmr-v2-tight"><tr><th style="width:30%">Item</th><th style="width:17%">Batch/Lot no.</th>'
        . '<th style="width:15%">Qty. as per batch</th><th style="width:15%">Actual qty.</th>'
        . '<th style="width:9%">Unit</th></tr>';
    foreach ($materials as $index => $material) {
        $key = strtolower(trim((string) ($material['key'] ?? 'item_' . ($index + 1))));
        $key = preg_replace('/[^a-z0-9_]+/', '_', $key) ?: 'item_' . ($index + 1);
        $materialsPage .= '<tr><td>' . bmrBprStructuredEscape($material['name'] ?? '')
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('materials.' . $key . '.lot_no', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($material['quantity'] ?? '')
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField('materials.' . $key . '.actual_qty', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($material['unit'] ?? '')
            . '</td></tr>';
    }
    $materialsPage .= '</table>'
        . bmrBprStructuredApprovalRows($fields, $editable, 'materials');

    $renderStages = static function (
        array $pageStages,
        int $offset,
        array $fields,
        bool $editable
    ): string {
        $html = '';
        foreach ($pageStages as $localIndex => $stage) {
            $stageIndex = $offset + $localIndex;
            $key = strtolower(trim((string) ($stage['key'] ?? 'stage_' . ($stageIndex + 1))));
            $key = preg_replace('/[^a-z0-9_]+/', '_', $key) ?: 'stage_' . ($stageIndex + 1);
            $html .= '<h3 class="bmr-v2-section-title">'
                . ($stageIndex + 4) . '.0 '
                . bmrBprStructuredEscape($stage['title'] ?? '')
                . '</h3><ol class="bmr-v2-list">';
            $instructions = is_array($stage['instructions'] ?? null)
                ? $stage['instructions']
                : [];
            foreach ($instructions as $instruction) {
                $html .= '<li>' . bmrBprStructuredEscape($instruction) . '</li>';
            }
            $html .= '</ol><table class="bmr-v2-tight"><tr><th>Date</th><th>Quantity / Result</th>'
                . '<th>Done by</th><th>Production</th><th>QA</th></tr><tr>';
            foreach (['date', 'result', 'done_by', 'production', 'qa'] as $column) {
                $html .= '<td class="bmr-v2-input-cell">'
                    . bmrBprStructuredField('stages.' . $key . '.' . $column, $fields, $editable)
                    . '</td>';
            }
            $html .= '</tr></table>';
        }
        return $html;
    };

    $finalPage = '<h3 class="bmr-v2-section-title">Product transfer detail</h3>'
        . '<p>After QA release, transfer the approved product to the finished-goods store with the signed transfer ticket.</p>'
        . '<table class="bmr-v2-tight"><tr><th>TT date</th><th>TT number</th><th>Pack size</th>'
        . '<th>Total quantity</th><th>Transferred by</th><th>Store</th><th>QA</th></tr>';
    foreach (bmrBprStructuredRowIndexes($fields, 'transfer.rows', 2) as $index) {
        $base = 'transfer.rows.' . $index;
        $finalPage .= '<tr><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.date', $fields, $editable)
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.number', $fields, $editable)
            . '</td><td>' . bmrBprStructuredEscape($profile['pack_size'] ?? '')
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.quantity', $fields, $editable)
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.transferred_by', $fields, $editable)
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.store', $fields, $editable)
            . '</td><td class="bmr-v2-input-cell">'
            . bmrBprStructuredField($base . '.qa', $fields, $editable)
            . '</td></tr>';
    }
    $finalPage .= '</table><h3 class="bmr-v2-section-title">Yield detail</h3>'
        . '<table><tr><th>Batch size</th><td>'
        . bmrBprStructuredEscape($source['batch_size'] ?? $profile['standard_batch'] ?? '')
        . '</td><th>Quantity produced</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.actual_quantity', $fields, $editable) . '</td></tr>'
        . '<tr><th>Standard yield</th><td>'
        . bmrBprStructuredEscape($profile['standard_yield'] ?? 'NLT 98%')
        . '</td><th>Yield achieved</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredField('yield.achieved', $fields, $editable) . '</td></tr>'
        . '<tr><th>Remarks</th><td colspan="3" class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('yield.remarks', $fields, $editable) . '</td></tr></table>'
        . bmrBprStructuredApprovalRows($fields, $editable, 'yield')
        . '<div class="bmr-v2-qa-box"><h3 class="bmr-v2-section-title">Quality Assurance Department</h3>'
        . '<p>On review, the BPR is satisfactory / not satisfactory and the batch is released / not released.</p>'
        . '<table><tr><th>Decision / Remarks</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredTextarea('qa.decision_remarks', $fields, $editable) . '</td></tr>'
        . '<tr><th>Head Quality Assurance</th><td class="bmr-v2-input-cell">'
        . bmrBprStructuredSignatureAndDate('qa.incharge', $fields, $editable, 'qa.incharge_signature_date')
        . '</td></tr></table></div>';

    $pages = [
        bmrBprStructuredPage(
            1,
            $total,
            $document,
            $profile,
            $source,
            'BPR',
            bmrBprStructuredCover($profile, $fields, $editable, 'BPR'),
            'bmr-v2-urology-cover-page'
        ),
        bmrBprStructuredPage(2, $total, $document, $profile, $source, 'BPR', $contents),
        bmrBprStructuredPage(3, $total, $document, $profile, $source, 'BPR', $materialsPage),
    ];

    $stagePageCount = $total - 4;
    $stageOffset = 0;
    for ($slot = 0; $slot < $stagePageCount; $slot++) {
        $remainingStages = count($stages) - $stageOffset;
        $remainingPages = $stagePageCount - $slot;
        $take = $remainingPages > 0
            ? (int) ceil(max(0, $remainingStages) / $remainingPages)
            : 0;
        $pageStages = array_slice($stages, $stageOffset, $take);
        $pages[] = bmrBprStructuredPage(
            4 + $slot,
            $total,
            $document,
            $profile,
            $source,
            'BPR',
            $renderStages($pageStages, $stageOffset, $fields, $editable)
        );
        $stageOffset += $take;
    }
    $remainingStages = array_slice($stages, $stageOffset);
    $pages[] = bmrBprStructuredPage(
        $total,
        $total,
        $document,
        $profile,
        $source,
        'BPR',
        $renderStages($remainingStages, $stageOffset, $fields, $editable) . $finalPage
    );
    return implode('', $pages);
}

function bmrBprRenderStructuredTemplate(array $form, bool $editable = false): string
{
    $layout = is_array($form['layout'] ?? null) ? $form['layout'] : [];
    $profile = is_array($form['profile'] ?? null) ? $form['profile'] : [];
    if (!bmrBprIsStructuredLayout($layout) || $profile === []) {
        return '';
    }
    $formType = strtoupper((string) ($form['form_type'] ?? $layout['form_type'] ?? 'BMR'));
    $rendererVariant = strtolower(trim((string) ($layout['renderer_variant'] ?? '')));
    if ($rendererVariant === 'urology') {
        $pages = $formType === 'BPR'
            ? bmrBprRenderStructuredUrologyBpr($form, $layout, $profile, $editable)
            : bmrBprRenderStructuredUrologyBmr($form, $layout, $profile, $editable);
    } elseif (
        $formType === 'BPR'
        && in_array($rendererVariant, ['serology', 'microbiology', 'biochemistry', 'rapid'], true)
    ) {
        $pages = bmrBprRenderStructuredProfiledBpr($form, $layout, $profile, $editable);
    } else {
        $pages = $formType === 'BPR'
            ? bmrBprRenderStructuredBpr($form, $layout, $profile, $editable)
            : bmrBprRenderStructuredBmr($form, $layout, $profile, $editable);
    }

    return bmrBprStructuredStyles()
        . '<div class="bmr-v2-document" data-schema-version="2" data-form-type="'
        . bmrBprStructuredEscape($formType) . '">' . $pages . '</div>';
}
