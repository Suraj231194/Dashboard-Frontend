<?php

declare(strict_types=1);

require_once __DIR__ . '/bmr_bpr_structured_renderer.php';
require_once __DIR__ . '/bmr_bpr_legacy_layout.php';
require_once __DIR__ . '/template_snapshot_common.php';

function bmrBprJson(string $status, string $message = '', array $data = [], int $httpCode = 200): never
{
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bmrBprRequireLogin(): void
{
    if (!isset($_SESSION['user_id']) || (int) $_SESSION['user_id'] <= 0) {
        bmrBprJson('error', 'Your session has expired. Please sign in again.', [], 401);
    }
}

function bmrBprRequirePermission(mysqli $conn, string $slug): void
{
    bmrBprRequireLogin();
    if (!checkPermission($slug, $conn)) {
        bmrBprJson('error', 'You do not have permission to perform this action.', [], 403);
    }
}

function bmrBprValidateCsrf(): void
{
    $sessionToken = (string) ($_SESSION['csrf_token'] ?? '');
    $requestToken = (string) ($_POST['csrf_token'] ?? '');
    if ($sessionToken === '' || !hash_equals($sessionToken, $requestToken)) {
        bmrBprJson('error', 'Your session token is invalid. Refresh the page and try again.', [], 419);
    }
}

function bmrBprPrepare(mysqli $conn, string $sql): mysqli_stmt
{
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare the workflow database operation: ' . $conn->error);
    }
    return $stmt;
}

function bmrBprLegacyWriteActions(): array
{
    return [
        'addTransferTicket', 'updateTransferTicket', 'updateTransferTicket1',
        'deleteTransfetTicketRecord', 'createManualBomIssuance',
        'addMaterialRequisitionForm', 'addMaterialRequisitionFormBKP31012026',
        'updateMaterialReqestRecord', 'updateMaterialReqestBOMRecord',
        'updateMaterialRequestStatusRecord', 'materialRequisitionFinalQtyUpdate',
        'materialRequisitionEditQtyFinal',
    ];
}

function bmrBprProductionWritePermissions(): array
{
    return [
        'sendOrderToProduction' => 'store_order_received_edit',
        'addProductionPlan' => 'operations_admin_production_plan_add',
        'addProductionPlanBom' => 'operations_admin_production_plan_add',
        'completeProductionPlan' => 'operations_admin_production_plan_edit',
        'updateProductionPlan' => 'operations_admin_production_plan_edit',
        'deleteProductionPlanRecord' => 'operations_admin_production_plan_delete',
        'acceptProductionPlan' => 'operations_admin_production_plan_edit',
        'addMaterialRequisitionForm' => 'production_material_requisition_add',
        'generateBomFromPlan' => 'production_material_requisition_add',
        'deleteMaterialRequisitionRecord' => 'production_material_requisition_delete',
        'issueBomItems' => 'store_stock_issuance_menu_list',
        'acknowledgeGoodsReceivedProduction' => 'store_goods_received_production_manage',
        'updateIpCoaRecord' => 'ip_coa_generation_edit',
        'deleteIpCoaRecord' => 'ip_coa_generation_delete',
        'updateFGCoaRecord' => 'fg_coa_generation_edit',
        'deleteFgCoaRecord' => 'fg_coa_generation_delete',
    ];
}

function bmrBprSchemaReady(mysqli $conn): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $requiredTables = [
        'bmr_bpr_requests',
        'bmr_bpr_work_items',
        'bmr_bpr_workflow_history',
        'bmr_templates',
        'bmr_template_product_mappings',
        'bmr_bpr_request_documents',
    ];
    $requiredColumns = [
        ['bmr_bpr_requests', 'bmr_form_count'],
        ['bmr_bpr_requests', 'bpr_form_count'],
        ['bmr_bpr_work_items', 'form_sequence'],
        ['bmr_templates', 'form_type'],
        ['bmr_templates', 'template_code'],
        ['bmr_templates', 'layout_json'],
        ['bmr_template_product_mappings', 'document_sequence'],
        ['bmr_template_product_mappings', 'required_quantity'],
        ['ip_coa_generation', 'source_bmr_work_item_id'],
        ['ip_coa_generation', 'source_bmr_bpr_request_id'],
        ['ip_coa_generation', 'product_id'],
        ['fg_coa_generation', 'source_ip_coa_id'],
        ['transfer_ticket', 'source_fg_coa_id'],
    ];

    $quotedTables = implode(
        ', ',
        array_map(
            static fn (string $table): string => "'" . $conn->real_escape_string($table) . "'",
            $requiredTables
        )
    );
    $quotedColumns = implode(
        ', ',
        array_map(
            static fn (array $column): string => "'"
                . $conn->real_escape_string($column[0] . '.' . $column[1])
                . "'",
            $requiredColumns
        )
    );
    $result = $conn->query(
        "SELECT
            (
                SELECT COUNT(DISTINCT table_name)
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
                  AND table_name IN ({$quotedTables})
            ) AS table_count,
            (
                SELECT COUNT(*)
                FROM information_schema.columns
                WHERE table_schema = DATABASE()
                  AND CONCAT(table_name, '.', column_name) IN ({$quotedColumns})
            ) AS column_count"
    );
    if (!$result) {
        $ready = false;
        return false;
    }
    $counts = $result->fetch_assoc();
    $ready = (int) ($counts['table_count'] ?? 0) === count($requiredTables)
        && (int) ($counts['column_count'] ?? 0) === count($requiredColumns);
    return $ready;
}

function bmrBprRequireSchema(mysqli $conn): void
{
    if (!bmrBprSchemaReady($conn)) {
        bmrBprJson(
            'error',
            'The BMR/BPR workflow migration has not been applied.',
            ['migration' => 'admin/migrations/2026_07_27_bmr_bpr_product_document_requirements.sql'],
            503
        );
    }
}

function bmrBprFiscalYearLabel(?string $date = null): string
{
    $timestamp = $date ? strtotime($date) : false;
    if ($timestamp === false) {
        $timestamp = time();
    }
    $year = (int) date('Y', $timestamp);
    $month = (int) date('n', $timestamp);
    $startYear = $month >= 4 ? $year : $year - 1;
    return sprintf('%02d-%02d', $startYear % 100, ($startYear + 1) % 100);
}

function bmrBprRequestNumber(int $id, ?string $date = null): string
{
    return 'BMRBPR/FY' . bmrBprFiscalYearLabel($date) . '/' . str_pad((string) $id, 6, '0', STR_PAD_LEFT);
}

function bmrBprIpCoaNumber(int $id, ?string $date = null): string
{
    $timestamp = $date ? strtotime($date) : false;
    $year = $timestamp === false ? date('y') : date('y', $timestamp);
    return 'BIPL-COA-IP-' . $year . str_pad((string) $id, 6, '0', STR_PAD_LEFT);
}

function bmrBprTransferTicketNumber(int $fgCoaId, ?string $date = null): string
{
    return 'BIPL-TT/FY' . bmrBprFiscalYearLabel($date) . '/' . str_pad((string) $fgCoaId, 6, '0', STR_PAD_LEFT);
}

function bmrBprInsertHistory(
    mysqli $conn,
    string $entityType,
    int $entityId,
    string $action,
    ?string $fromStatus,
    ?string $toStatus,
    ?string $remarks,
    array $payload,
    int $userId
): void {
    $payloadJson = $payload === []
        ? null
        : json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $stmt = bmrBprPrepare(
        $conn,
        'INSERT INTO bmr_bpr_workflow_history
            (entity_type, entity_id, action_name, from_status, to_status, remarks, payload_json, action_by, action_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())'
    );
    $stmt->bind_param(
        'sisssssi',
        $entityType,
        $entityId,
        $action,
        $fromStatus,
        $toStatus,
        $remarks,
        $payloadJson,
        $userId
    );
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Unable to record the workflow history.');
    }
    $stmt->close();
}

function bmrBprConfiguredWorkItemDefinitions(int $bmrFormCount, ?int $bprFormCount = null): array
{
    $bprFormCount ??= $bmrFormCount;
    if (
        $bmrFormCount <= 0 || $bmrFormCount > 1000
        || $bprFormCount <= 0 || $bprFormCount > 1000
    ) {
        throw new InvalidArgumentException('The configured BMR/BPR form count must be between 1 and 1,000.');
    }

    $definitions = [];
    foreach (['BMR' => $bmrFormCount, 'BPR' => $bprFormCount] as $formType => $formCount) {
        for ($sequence = 1; $sequence <= $formCount; $sequence++) {
            $definitions[] = [
                'form_type' => $formType,
                'form_sequence' => $sequence,
            ];
        }
    }
    return $definitions;
}

function bmrBprProductDocumentRequirements(mysqli $conn, int $productId): array
{
    $requirements = ['BMR' => [], 'BPR' => []];
    if ($productId <= 0) {
        return $requirements;
    }

    $stmt = bmrBprPrepare(
        $conn,
        "SELECT
            mapping.id AS mapping_id,
            mapping.form_type,
            mapping.document_sequence,
            mapping.required_quantity,
            mapping.template_id,
            template.template_code,
            template.template_name
         FROM bmr_template_product_mappings mapping
         INNER JOIN bmr_templates template
            ON template.id = mapping.template_id
           AND template.form_type = mapping.form_type
           AND template.status = 1
           AND template.deleted_at IS NULL
         WHERE mapping.product_id = ?
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         ORDER BY mapping.form_type, mapping.document_sequence, mapping.id"
    );
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $formType = strtoupper((string) ($row['form_type'] ?? ''));
        if (!isset($requirements[$formType])) {
            continue;
        }
        $requiredQuantity = (int) ($row['required_quantity'] ?? 0);
        $documentSequence = (int) ($row['document_sequence'] ?? 0);
        if ($requiredQuantity <= 0 || $requiredQuantity > 1000 || $documentSequence <= 0) {
            $stmt->close();
            throw new DomainException('The product BMR/BPR document configuration is invalid.');
        }
        $requirements[$formType][] = [
            'mapping_id' => (int) $row['mapping_id'],
            'form_type' => $formType,
            'document_sequence' => $documentSequence,
            'required_quantity' => $requiredQuantity,
            'template_id' => (int) $row['template_id'],
            'template_code' => (string) ($row['template_code'] ?? ''),
            'template_name' => (string) ($row['template_name'] ?? ''),
        ];
    }
    $stmt->close();
    return $requirements;
}

function bmrBprNormalizePackSizeKey(string $packSize): string
{
    $packSize = strtolower(trim($packSize));
    if ($packSize === '') {
        return '';
    }
    if (preg_match('/\b(\d+(?:\.\d+)?)\s*(ml|l|litre|liter|g|kg|mg|tests?|kits?|pcs)\b/i', $packSize, $matches) === 1) {
        $quantity = str_contains($matches[1], '.')
            ? rtrim(rtrim($matches[1], '0'), '.')
            : $matches[1];
        return $quantity . strtolower($matches[2]);
    }
    return preg_replace('/[^a-z0-9.]+/', '', $packSize) ?? '';
}

function bmrBprPackSizeDocumentRequirements(
    mysqli $conn,
    int $productId,
    string $packSize
): array {
    static $tableAvailable = null;
    $requirements = ['BMR' => [], 'BPR' => []];
    $packSizeKey = bmrBprNormalizePackSizeKey($packSize);
    if ($productId <= 0 || $packSizeKey === '') {
        return $requirements;
    }

    if ($tableAvailable === null) {
        $tableResult = $conn->query(
            "SELECT COUNT(*) AS total
             FROM information_schema.tables
             WHERE table_schema = DATABASE()
               AND table_name = 'bmr_template_pack_size_mappings'"
        );
        $tableAvailable = $tableResult
            && (int) ($tableResult->fetch_assoc()['total'] ?? 0) === 1;
    }
    if (!$tableAvailable) {
        return $requirements;
    }

    $stmt = bmrBprPrepare(
        $conn,
        "SELECT
            mapping.id AS mapping_id,
            mapping.form_type,
            mapping.document_sequence,
            mapping.required_quantity,
            mapping.template_id,
            template.template_code,
            template.template_name
         FROM bmr_template_pack_size_mappings mapping
         INNER JOIN bmr_templates template
            ON template.id = mapping.template_id
           AND template.form_type = mapping.form_type
           AND template.status = 1
           AND template.deleted_at IS NULL
         WHERE mapping.product_id = ?
           AND mapping.pack_size_key = ?
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         ORDER BY mapping.form_type, mapping.document_sequence, mapping.id"
    );
    $stmt->bind_param('is', $productId, $packSizeKey);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $formType = strtoupper((string) ($row['form_type'] ?? ''));
        if (!isset($requirements[$formType])) {
            continue;
        }
        $requirements[$formType][] = [
            'mapping_id' => (int) $row['mapping_id'],
            'form_type' => $formType,
            'document_sequence' => (int) $row['document_sequence'],
            'required_quantity' => (int) $row['required_quantity'],
            'template_id' => (int) $row['template_id'],
            'template_code' => (string) ($row['template_code'] ?? ''),
            'template_name' => (string) ($row['template_name'] ?? ''),
        ];
    }
    $stmt->close();
    return $requirements;
}

function bmrBprResolveProductDocumentRequirements(
    mysqli $conn,
    int $productId,
    string $packSize = ''
): array {
    $packRequirements = bmrBprPackSizeDocumentRequirements($conn, $productId, $packSize);
    if (!empty($packRequirements['BMR']) || !empty($packRequirements['BPR'])) {
        if (empty($packRequirements['BMR']) || empty($packRequirements['BPR'])) {
            throw new DomainException(
                'The pack-size document configuration must include at least one BMR and one BPR.'
            );
        }
        return $packRequirements;
    }
    return bmrBprProductDocumentRequirements($conn, $productId);
}

function bmrBprNormalizeDocumentRequirements(
    array $requirements,
    int $fallbackBmrCount,
    int $fallbackBprCount
): array {
    $fallbackCounts = ['BMR' => $fallbackBmrCount, 'BPR' => $fallbackBprCount];
    $hasProductConfiguration = !empty($requirements['BMR']) || !empty($requirements['BPR']);
    $normalized = [];
    foreach (['BMR', 'BPR'] as $formType) {
        $configured = is_array($requirements[$formType] ?? null)
            ? array_values($requirements[$formType])
            : [];
        if ($configured === []) {
            if ($hasProductConfiguration) {
                throw new DomainException(
                    "The product document configuration must include at least one {$formType} document."
                );
            }
            $fallbackCount = $fallbackCounts[$formType];
            if ($fallbackCount <= 0 || $fallbackCount > 1000) {
                throw new InvalidArgumentException(
                    'The configured BMR/BPR form count must be between 1 and 1,000.'
                );
            }
            $configured[] = [
                'mapping_id' => null,
                'form_type' => $formType,
                'document_sequence' => 1,
                'required_quantity' => $fallbackCount,
                'template_id' => null,
                'template_code' => '',
                'template_name' => '',
            ];
        }

        $total = 0;
        foreach ($configured as $requirement) {
            $quantity = (int) ($requirement['required_quantity'] ?? 0);
            $sequence = (int) ($requirement['document_sequence'] ?? 0);
            if ($quantity <= 0 || $quantity > 1000 || $sequence <= 0) {
                throw new DomainException('The product BMR/BPR document configuration is invalid.');
            }
            $total += $quantity;
            if ($total > 1000) {
                throw new DomainException(
                    "The configured {$formType} document quantity cannot exceed 1,000."
                );
            }
            $requirement['form_type'] = $formType;
            $requirement['required_quantity'] = $quantity;
            $requirement['document_sequence'] = $sequence;
            $requirement['template_id'] = !empty($requirement['template_id'])
                ? (int) $requirement['template_id']
                : null;
            $normalized[] = $requirement;
        }
    }
    return $normalized;
}

function bmrBprDocumentRequirementCounts(array $requirements): array
{
    $counts = ['BMR' => 0, 'BPR' => 0];
    foreach ($requirements as $requirement) {
        $formType = strtoupper((string) ($requirement['form_type'] ?? ''));
        if (isset($counts[$formType])) {
            $counts[$formType] += (int) ($requirement['required_quantity'] ?? 0);
        }
    }
    return $counts;
}

function bmrBprResolveProductPackSize(
    mysqli $conn,
    int $productId,
    string $productName = '',
    string $fallbackPackSize = ''
): string {
    if ($productId > 0) {
        $stmt = bmrBprPrepare(
            $conn,
            "SELECT TRIM(pps.pack_size) AS pack_size, TRIM(COALESCE(su.short_name, '')) AS unit_name
             FROM product_pack_sizes pps
             LEFT JOIN standard_units su ON su.id = pps.pack_unit_id
             WHERE pps.product_id = ? AND pps.status != 3 AND pps.deleted_at IS NULL
             ORDER BY pps.sort_order ASC, pps.id ASC
             LIMIT 1"
        );
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $packSize = trim((string) ($row['pack_size'] ?? ''));
            $unitName = trim((string) ($row['unit_name'] ?? ''));
            if ($packSize !== '') {
                if ($unitName !== '' && preg_match('/(?:^|\s)' . preg_quote($unitName, '/') . '$/i', $packSize) !== 1) {
                    $packSize .= ' ' . $unitName;
                }
                return $packSize;
            }
        }
    }

    foreach ([$fallbackPackSize, $productName] as $candidate) {
        if (preg_match('/\b(\d+(?:\.\d+)?)\s*(ml|l|litre|liter|g|kg|mg|tests?|kits?|pcs)\b/i', $candidate, $matches) === 1) {
            return trim($matches[1] . ' ' . $matches[2]);
        }
    }
    return trim($fallbackPackSize);
}

function bmrBprGetRankedTemplates(
    mysqli $conn,
    int $productId = 0,
    string $packSize = '',
    string $productName = ''
): array {
    $allTemplates = [];
    $stmt = $conn->query(
        "SELECT id, form_type, template_code, template_name
         FROM bmr_templates
         WHERE status = 1 AND deleted_at IS NULL
         ORDER BY template_name ASC, id ASC"
    );
    if ($stmt) {
        while ($row = $stmt->fetch_assoc()) {
            $row['id'] = (int) $row['id'];
            $row['form_type'] = strtoupper((string) $row['form_type']);
            $allTemplates[] = $row;
        }
    }

    $exactMappingIds = ['BMR' => [], 'BPR' => []];
    if ($productId > 0) {
        try {
            $resolvedReqs = bmrBprResolveProductDocumentRequirements($conn, $productId, $packSize);
            foreach (['BMR', 'BPR'] as $fType) {
                if (!empty($resolvedReqs[$fType])) {
                    foreach ($resolvedReqs[$fType] as $r) {
                        if (!empty($r['template_id'])) {
                            $exactMappingIds[$fType][] = (int) $r['template_id'];
                        }
                    }
                }
            }
        } catch (Throwable) {
            // Ignore mapping lookup failures for ranking fallback
        }
    }

    $tokens = [];
    $searchTarget = strtolower(trim($productName . ' ' . $packSize));
    if (preg_match_all('/[a-z0-9]+/i', $searchTarget, $m) && !empty($m[0])) {
        $stopWords = ['and', 'for', 'the', 'kit', 'test', 'tests', 'with', 'set', 'of', 'in', 'pack'];
        foreach ($m[0] as $token) {
            $tok = strtolower($token);
            if (strlen($tok) >= 3 && !in_array($tok, $stopWords, true)) {
                $tokens[] = $tok;
            }
        }
    }

    $result = [
        'BMR' => [],
        'BPR' => [],
        'exact_bmr_id' => !empty($exactMappingIds['BMR']) ? $exactMappingIds['BMR'][0] : null,
        'exact_bpr_id' => !empty($exactMappingIds['BPR']) ? $exactMappingIds['BPR'][0] : null,
    ];

    foreach ($allTemplates as $tpl) {
        $fType = $tpl['form_type'];
        if (!isset($result[$fType])) {
            continue;
        }
        $tplId = $tpl['id'];
        $isExact = in_array($tplId, $exactMappingIds[$fType], true);

        $tplText = strtolower($tpl['template_name'] . ' ' . $tpl['template_code']);
        $isRecommended = false;
        if (!$isExact && !empty($tokens)) {
            foreach ($tokens as $token) {
                if (str_contains($tplText, $token)) {
                    $isRecommended = true;
                    break;
                }
            }
        }

        $result[$fType][] = [
            'id' => $tplId,
            'template_code' => $tpl['template_code'],
            'template_name' => $tpl['template_name'],
            'form_type' => $fType,
            'is_exact_match' => $isExact,
            'is_recommended' => $isRecommended,
        ];
    }

    return $result;
}

function bmrBprGetMappedProductCatalog(mysqli $conn): array
{
    $catalog = [
        'BMR' => [],
        'BPR' => [],
        'all_products' => [],
        'template_products' => ['BMR' => [], 'BPR' => []],
    ];

    foreach (['BMR', 'BPR'] as $formType) {
        $safeFormType = $conn->real_escape_string($formType);
        $templateCatalogStmt = $conn->query(
            "SELECT
                m.id AS mapping_id,
                p.id AS product_id,
                p.product_name,
                p.product_code,
                m.template_id,
                template.template_name,
                template.template_code,
                m.document_sequence
            FROM bmr_template_product_mappings m
            INNER JOIN bmr_templates template
                ON template.id = m.template_id
               AND template.form_type = '{$safeFormType}'
               AND template.status = 1
               AND template.deleted_at IS NULL
            INNER JOIN products p ON p.id = m.product_id
            WHERE m.form_type = '{$safeFormType}'
              AND m.status = 1
              AND m.deleted_at IS NULL
            ORDER BY template.template_name ASC, p.product_name ASC, p.product_code ASC, m.id ASC"
        );
        $templateCatalog = $templateCatalogStmt ? $templateCatalogStmt->fetch_all(MYSQLI_ASSOC) : [];

        // The PDF retains both catalog numbers for this duplicate product name.
        // Product Master cleanup retired one record, so keep it display-only here.
        $pdfCatalogAdditions = [
            'BMR' => [
                'product_code' => 'BGX/FIN.ELISA/2026/000287',
                'template_code' => 'COMMON_MICROBIOLOGY_BMR_V03',
            ],
            'BPR' => [
                'product_code' => 'BGX/FIN.ELISA/2026/000287',
                'template_code' => 'COMMON_MICROBIOLOGY_BPR_V03',
            ],
        ];
        $pdfAddition = $pdfCatalogAdditions[$formType];
        $hasPdfAddition = array_filter(
            $templateCatalog,
            static fn(array $item): bool => (string) ($item['product_code'] ?? '') === $pdfAddition['product_code']
                && (string) ($item['template_code'] ?? '') === $pdfAddition['template_code']
        );
        if (!$hasPdfAddition) {
            $productCode = $conn->real_escape_string($pdfAddition['product_code']);
            $templateCode = $conn->real_escape_string($pdfAddition['template_code']);
            $pdfAdditionStmt = $conn->query(
                "SELECT
                    CONCAT('pdf-', p.id) AS mapping_id,
                    p.id AS product_id,
                    p.product_name,
                    p.product_code,
                    template.id AS template_id,
                    template.template_name,
                    template.template_code,
                    1 AS document_sequence
                FROM products p
                INNER JOIN bmr_templates template
                    ON template.template_code = '{$templateCode}'
                   AND template.form_type = '{$safeFormType}'
                   AND template.status = 1
                   AND template.deleted_at IS NULL
                WHERE p.product_code = '{$productCode}'
                LIMIT 1"
            );
            if ($pdfAdditionStmt && ($pdfAdditionRow = $pdfAdditionStmt->fetch_assoc())) {
                $templateCatalog[] = $pdfAdditionRow;
            }
        }

        foreach ($templateCatalog as &$templateProduct) {
            $templateProduct['product_name'] = preg_replace(
                '/(?:\?|\x{FFFD})(?=[Lg]\b)/u',
                "\u{00B5}",
                (string) $templateProduct['product_name']
            ) ?? (string) $templateProduct['product_name'];
        }
        unset($templateProduct);
        usort($templateCatalog, static function (array $left, array $right): int {
            foreach (['template_name', 'product_name', 'product_code'] as $column) {
                $comparison = strcasecmp((string) ($left[$column] ?? ''), (string) ($right[$column] ?? ''));
                if ($comparison !== 0) {
                    return $comparison;
                }
            }
            return strcasecmp((string) ($left['mapping_id'] ?? ''), (string) ($right['mapping_id'] ?? ''));
        });
        $catalog['template_products'][$formType] = $templateCatalog;

        $regularStmt = $conn->query(
            "SELECT 
                m.id AS mapping_id,
                p.id AS product_id,
                p.product_name,
                COALESCE(p.product_code, '') AS category_code,
                m.template_id,
                template.template_name,
                template.template_code,
                m.document_sequence,
                m.required_quantity,
                COALESCE((
                    SELECT TRIM(CONCAT_WS(' ', pps.pack_size, su.short_name))
                    FROM product_pack_sizes pps
                    LEFT JOIN standard_units su ON su.id = pps.pack_unit_id
                    WHERE pps.product_id = p.id AND pps.status != 3 AND pps.deleted_at IS NULL
                    ORDER BY pps.sort_order ASC, pps.id ASC
                    LIMIT 1
                ), '') AS pack_size,
                0 AS is_pack_specific,
                '' AS pack_size_key
            FROM bmr_template_product_mappings m
            INNER JOIN bmr_templates template
                ON template.id = m.template_id
               AND template.form_type = '{$safeFormType}'
               AND template.status = 1
               AND template.deleted_at IS NULL
            INNER JOIN products p
                ON p.id = m.product_id
               AND p.status != 3
               AND p.deleted_at IS NULL
            WHERE m.form_type = '{$safeFormType}'
              AND m.status = 1
              AND m.deleted_at IS NULL
            ORDER BY p.product_name ASC, m.document_sequence ASC"
        );
        $regular = $regularStmt ? $regularStmt->fetch_all(MYSQLI_ASSOC) : [];

        $packStmt = $conn->query(
            "SELECT 
                pm.id AS mapping_id,
                p.id AS product_id,
                CONCAT(p.product_name, ' (', pm.pack_size_label, ')') AS product_name,
                COALESCE(p.product_code, '') AS category_code,
                pm.template_id,
                template.template_name,
                template.template_code,
                pm.document_sequence,
                pm.required_quantity,
                pm.pack_size_label AS pack_size,
                1 AS is_pack_specific,
                pm.pack_size_key
            FROM bmr_template_pack_size_mappings pm
            INNER JOIN bmr_templates template
                ON template.id = pm.template_id
               AND template.form_type = '{$safeFormType}'
               AND template.status = 1
               AND template.deleted_at IS NULL
            INNER JOIN products p
                ON p.id = pm.product_id
               AND p.status != 3
               AND p.deleted_at IS NULL
            WHERE pm.form_type = '{$safeFormType}'
              AND pm.status = 1
              AND pm.deleted_at IS NULL
            ORDER BY p.product_name ASC, pm.pack_size_label ASC"
        );
        $packSpecific = $packStmt ? $packStmt->fetch_all(MYSQLI_ASSOC) : [];

        $merged = array_merge($regular, $packSpecific);
        usort($merged, static fn(array $a, array $b): int => strcasecmp((string)$a['product_name'], (string)$b['product_name']));
        $catalog[$formType] = $merged;
    }

    $productMap = [];
    foreach (['BMR', 'BPR'] as $formType) {
        foreach ($catalog[$formType] as $item) {
            $key = $item['product_id'] . '_' . ($item['pack_size_key'] ?? '');
            if (!isset($productMap[$key])) {
                $productMap[$key] = [
                    'product_id' => (int) $item['product_id'],
                    'product_name' => (string) $item['product_name'],
                    'category_code' => (string) $item['category_code'],
                    'pack_size' => (string) $item['pack_size'],
                    'pack_size_key' => (string) ($item['pack_size_key'] ?? ''),
                    'is_pack_specific' => (int) $item['is_pack_specific'],
                    'bmr_template_ids' => [],
                    'bpr_template_ids' => [],
                    'bmr_template_codes' => [],
                    'bpr_template_codes' => [],
                    'bmr_template_names' => [],
                    'bpr_template_names' => [],
                ];
            }
            if ($formType === 'BMR') {
                $productMap[$key]['bmr_template_ids'][] = (int) $item['template_id'];
                $productMap[$key]['bmr_template_codes'][] = (string) $item['template_code'];
                $productMap[$key]['bmr_template_names'][] = (string) $item['template_name'];
            } else {
                $productMap[$key]['bpr_template_ids'][] = (int) $item['template_id'];
                $productMap[$key]['bpr_template_codes'][] = (string) $item['template_code'];
                $productMap[$key]['bpr_template_names'][] = (string) $item['template_name'];
            }
        }
    }
    $catalog['all_products'] = array_values($productMap);
    usort($catalog['all_products'], static fn(array $a, array $b): int => strcasecmp((string)$a['product_name'], (string)$b['product_name']));

    return $catalog;
}

function bmrBprApplySelectedTemplate(array $requirements, string $formType, ?int $selectedTemplateId): array
{
    $formType = strtoupper(trim($formType));
    if (!in_array($formType, ['BMR', 'BPR'], true) || $selectedTemplateId === null || $selectedTemplateId <= 0) {
        return $requirements;
    }

    $firstMatchingIndex = null;
    $firstEmptyIndex = null;
    foreach ($requirements as $index => $requirement) {
        if (strtoupper((string) ($requirement['form_type'] ?? '')) !== $formType) {
            continue;
        }
        if ($firstMatchingIndex === null) {
            $firstMatchingIndex = $index;
        }
        $templateId = (int) ($requirement['template_id'] ?? 0);
        if ($templateId === $selectedTemplateId) {
            return $requirements;
        }
        if ($firstEmptyIndex === null && $templateId <= 0) {
            $firstEmptyIndex = $index;
        }
    }

    $targetIndex = $firstEmptyIndex ?? $firstMatchingIndex;
    if ($targetIndex !== null) {
        $requirements[$targetIndex]['template_id'] = $selectedTemplateId;
    }

    return $requirements;
}

function bmrBprSnapshotProductDocumentRequirements(
    mysqli $conn,
    int $requestId,
    int $productId,
    int $fallbackBmrCount,
    int $fallbackBprCount,
    int $userId,
    string $packSize = '',
    ?int $selectedBmrTemplateId = null,
    ?int $selectedBprTemplateId = null
): array {
    if ($requestId <= 0) {
        throw new InvalidArgumentException('A valid BMR/BPR request is required.');
    }

    $requirements = bmrBprNormalizeDocumentRequirements(
        bmrBprResolveProductDocumentRequirements($conn, $productId, $packSize),
        $fallbackBmrCount,
        $fallbackBprCount
    );

    $requirements = bmrBprApplySelectedTemplate($requirements, 'BMR', $selectedBmrTemplateId);
    $requirements = bmrBprApplySelectedTemplate($requirements, 'BPR', $selectedBprTemplateId);

    $productName = '';
    $productStmt = bmrBprPrepare($conn, 'SELECT product_name FROM products WHERE id = ? LIMIT 1');
    $productStmt->bind_param('i', $productId);
    $productStmt->execute();
    $productName = (string) ($productStmt->get_result()->fetch_assoc()['product_name'] ?? '');
    $productStmt->close();

    $stmt = bmrBprPrepare(
        $conn,
        "INSERT INTO bmr_bpr_request_documents
            (request_id, form_type, document_sequence, template_id, template_snapshot_id, required_quantity,
             created_by, created_at)
         VALUES (?, ?, ?, ?, NULLIF(?, 0), ?, ?, NOW())
         ON DUPLICATE KEY UPDATE
            template_id = VALUES(template_id),
            template_snapshot_id = VALUES(template_snapshot_id),
            required_quantity = VALUES(required_quantity),
            updated_by = VALUES(created_by),
            updated_at = NOW()"
    );
    foreach ($requirements as $requirement) {
        $formType = (string) $requirement['form_type'];
        $documentSequence = (int) $requirement['document_sequence'];
        $templateId = $requirement['template_id'];
        $templateSnapshotId = $templateId
            ? templateSnapshotCreateBmrBpr(
                $conn, $formType, (int) $templateId, $productId, $productName, $packSize, $userId,
                (($formType === 'BMR' && (int) $selectedBmrTemplateId === (int) $templateId)
                    || ($formType === 'BPR' && (int) $selectedBprTemplateId === (int) $templateId))
                    ? 'MANUAL_OVERRIDE' : 'PREMAPPED'
            )
            : 0;
        $requiredQuantity = (int) $requirement['required_quantity'];
        $stmt->bind_param(
            'isiiiii',
            $requestId,
            $formType,
            $documentSequence,
            $templateId,
            $templateSnapshotId,
            $requiredQuantity,
            $userId
        );
        if (!$stmt->execute()) {
            $stmt->close();
            throw new RuntimeException('Unable to snapshot the product BMR/BPR requirements.');
        }
    }
    $stmt->close();
    return bmrBprDocumentRequirementCounts($requirements);
}

function bmrBprRequestWorkItemDefinitions(
    mysqli $conn,
    int $requestId,
    int $productId,
    int $fallbackBmrCount,
    int $fallbackBprCount
): array {
    $requirements = [];
    $stmt = bmrBprPrepare(
        $conn,
        "SELECT form_type, document_sequence, template_id, template_snapshot_id, required_quantity
         FROM bmr_bpr_request_documents
         WHERE request_id = ?
         ORDER BY form_type, document_sequence, id"
    );
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $requirements[] = [
            'form_type' => strtoupper((string) $row['form_type']),
            'document_sequence' => (int) $row['document_sequence'],
            'template_id' => isset($row['template_id']) ? (int) $row['template_id'] : null,
            'template_snapshot_id' => isset($row['template_snapshot_id']) ? (int) $row['template_snapshot_id'] : null,
            'required_quantity' => (int) $row['required_quantity'],
        ];
    }
    $stmt->close();

    if ($requirements === []) {
        $requirements = bmrBprNormalizeDocumentRequirements(
            bmrBprProductDocumentRequirements($conn, $productId),
            $fallbackBmrCount,
            $fallbackBprCount
        );
    } else {
        $grouped = ['BMR' => [], 'BPR' => []];
        foreach ($requirements as $requirement) {
            $grouped[$requirement['form_type']][] = $requirement;
        }
        $requirements = bmrBprNormalizeDocumentRequirements(
            $grouped,
            $fallbackBmrCount,
            $fallbackBprCount
        );
    }

    $definitions = [];
    $formSequences = ['BMR' => 0, 'BPR' => 0];
    foreach ($requirements as $requirement) {
        $formType = (string) $requirement['form_type'];
        for ($copy = 1; $copy <= (int) $requirement['required_quantity']; $copy++) {
            $formSequences[$formType]++;
            $definitions[] = [
                'form_type' => $formType,
                'form_sequence' => $formSequences[$formType],
                'document_sequence' => (int) $requirement['document_sequence'],
                'document_copy' => $copy,
                'template_id' => $requirement['template_id'],
                'template_snapshot_id' => $requirement['template_snapshot_id'] ?? null,
            ];
        }
    }
    return $definitions;
}

function bmrBprEnsureConfiguredWorkItems(
    mysqli $conn,
    int $requestId,
    int $bmrFormCount,
    int $bprFormCount,
    int $userId
): void {
    if ($requestId <= 0) {
        throw new InvalidArgumentException('A valid BMR/BPR request is required.');
    }

    $productStmt = bmrBprPrepare(
        $conn,
        'SELECT product_id
         FROM bmr_bpr_requests
         WHERE id = ? AND deleted_at IS NULL
         LIMIT 1'
    );
    $productStmt->bind_param('i', $requestId);
    $productStmt->execute();
    $productId = (int) ($productStmt->get_result()->fetch_assoc()['product_id'] ?? 0);
    $productStmt->close();

    $stmt = bmrBprPrepare(
        $conn,
        "INSERT INTO bmr_bpr_work_items
            (request_id, form_type, form_sequence, status, template_id, template_snapshot_id, created_by, created_at)
         VALUES (?, ?, ?, 'QUEUED', ?, NULLIF(?, 0), ?, NOW())
         ON DUPLICATE KEY UPDATE
            template_id = COALESCE(template_id, VALUES(template_id)),
            template_snapshot_id = COALESCE(template_snapshot_id, VALUES(template_snapshot_id))"
    );
    $definitions = bmrBprRequestWorkItemDefinitions(
        $conn,
        $requestId,
        $productId,
        $bmrFormCount,
        $bprFormCount
    );
    foreach ($definitions as $definition) {
        $formType = $definition['form_type'];
        $formSequence = (int) $definition['form_sequence'];
        $templateId = $definition['template_id'];
        $templateSnapshotId = (int) ($definition['template_snapshot_id'] ?? 0);
        $stmt->bind_param('isiiii', $requestId, $formType, $formSequence, $templateId, $templateSnapshotId, $userId);
        if (!$stmt->execute()) {
            $stmt->close();
            throw new RuntimeException('Unable to create the configured Production BMR/BPR work items.');
        }
    }
    $stmt->close();
}

function bmrBprBmrStatusesReady(array $statuses, ?int $requiredCount = null): bool
{
    if ($statuses === [] || ($requiredCount !== null && count($statuses) !== $requiredCount)) {
        return false;
    }
    foreach ($statuses as $status) {
        if (strtoupper((string) $status) !== 'COMPLETE') {
            return false;
        }
    }
    return true;
}

function bmrBprCoaApprovalDecision(?string $payloadJson): string
{
    if ($payloadJson === null || trim($payloadJson) === '') {
        return '';
    }

    $payload = json_decode($payloadJson, true);
    if (!is_array($payload) || !is_array($payload['fields'] ?? null)) {
        return '';
    }

    $decision = strtoupper(trim((string) ($payload['fields']['approval.decision'] ?? '')));
    return in_array($decision, ['APPROVED', 'REJECTED'], true) ? $decision : '';
}

function bmrBprNormalizeCoaWorkflowStatus(
    string $requestedStatus,
    ?int $templateId,
    ?string $payloadJson,
    string $coaLabel
): string {
    if (strtoupper(trim($requestedStatus)) !== 'COMPLETED') {
        return 'DRAFT';
    }

    if (($templateId ?? 0) <= 0) {
        throw new DomainException(
            "An active {$coaLabel} template must be mapped to this product before Quality can complete the COA."
        );
    }

    $decision = bmrBprCoaApprovalDecision($payloadJson);
    if ($decision === '') {
        throw new DomainException("Quality must record an Approved or Rejected decision before completing the {$coaLabel}.");
    }

    return $decision === 'APPROVED' ? 'COMPLETED' : 'REJECTED';
}

function bmrBprCoaRecordIsApproved(array $record): bool
{
    return strtoupper(trim((string) ($record['workflow_status'] ?? ''))) === 'COMPLETED'
        && (int) ($record['coa_template_id'] ?? 0) > 0
        && bmrBprCoaApprovalDecision((string) ($record['form_payload_json'] ?? '')) === 'APPROVED';
}

function bmrBprQualityStatusTransitions(string $currentStatus): array
{
    return match (strtoupper(trim($currentStatus))) {
        'DRAFT', 'COMPLETED', 'REJECTED' => ['HOLD'],
        'HOLD' => ['UNDER_INVESTIGATION', 'DRAFT'],
        'UNDER_INVESTIGATION' => ['HOLD', 'DRAFT'],
        default => [],
    };
}

function bmrBprValidateQualityStatusTransition(string $currentStatus, string $targetStatus): void
{
    $currentStatus = strtoupper(trim($currentStatus));
    $targetStatus = strtoupper(trim($targetStatus));
    if (!in_array($targetStatus, bmrBprQualityStatusTransitions($currentStatus), true)) {
        throw new DomainException(
            'The COA cannot move from '
            . bmrBprStatusLabel($currentStatus)
            . ' to '
            . bmrBprStatusLabel($targetStatus)
            . '.'
        );
    }
}

function bmrBprValidateTransferQuantity(float $quantity, float $batchSize): void
{
    if (!is_finite($quantity) || round($quantity, 8) <= 0 || !is_finite($batchSize) || $batchSize <= 0) {
        throw new InvalidArgumentException('A valid transferred quantity and approved batch size are required.');
    }
    if ($quantity > $batchSize + 0.00000001) {
        throw new DomainException('Transferred quantity cannot exceed the approved finished-goods batch size.');
    }
}

function bmrBprValidateReleaseRecord(array $record, array $bprStatuses): void
{
    if ((int) ($record['request_id'] ?? 0) <= 0 || ($record['request_status'] ?? '') !== 'APPROVED') {
        throw new DomainException('A valid approved manufacturing request is required for release.');
    }
    if (!bmrBprCoaRecordIsApproved($record)) {
        throw new DomainException('Transfer is blocked until the Finished-Goods COA is approved.');
    }
    if (!bmrBprCoaRecordIsApproved([
        'workflow_status' => $record['ip_workflow_status'] ?? '',
        'coa_template_id' => $record['ip_coa_template_id'] ?? null,
        'form_payload_json' => $record['ip_form_payload_json'] ?? null,
    ])) {
        throw new DomainException('Release is blocked because the In-Process COA is no longer approved.');
    }
    if (!bmrBprBmrStatusesReady($bprStatuses)
        || count($bprStatuses) !== (int) ($record['required_bpr_count'] ?? 0)) {
        throw new DomainException('Transfer is blocked until every configured BPR is complete.');
    }
}

function bmrBprRequireApprovedSampleAdvice(mysqli $conn, string $batchNumber, bool $forUpdate = false): void
{
    $sql = 'SELECT approval_status FROM coa_rm_pm_table
        WHERE (batch_number = ? OR auto_generated_batch = ?) AND deleted_at IS NULL
        ORDER BY id DESC LIMIT 1';
    if ($forUpdate) {
        $sql .= ' FOR UPDATE';
    }
    $stmt = bmrBprPrepare($conn, $sql);
    $stmt->bind_param('ss', $batchNumber, $batchNumber);
    $stmt->execute();
    $advice = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($advice && (int) $advice['approval_status'] !== 1) {
        throw new DomainException('FG COA release is locked until Sample Advice (SA) is approved by QA.');
    }
}

function bmrBprLoadReleaseSource(mysqli $conn, int $fgCoaId, bool $forUpdate = false): array
{
    if ($fgCoaId <= 0) {
        throw new DomainException('A controlled Finished-Goods COA is required for release.');
    }
    $sql = "SELECT fg.*, product.product_code,
                COALESCE(fg.production_plan_id, request.production_plan_id) AS production_plan_id,
                request.id AS request_id, request.status AS request_status,
                request.bmr_form_count AS required_bmr_count,
                request.bpr_form_count AS required_bpr_count,
                ip.workflow_status AS ip_workflow_status,
                ip.coa_template_id AS ip_coa_template_id,
                ip.form_payload_json AS ip_form_payload_json,
                plan.order_id AS linked_order_id
            FROM fg_coa_generation fg
            INNER JOIN ip_coa_generation ip ON ip.id = fg.source_ip_coa_id AND ip.deleted_at IS NULL
            LEFT JOIN bmr_bpr_work_items source_item ON source_item.id = ip.source_bmr_work_item_id
            INNER JOIN bmr_bpr_requests request
                ON request.id = COALESCE(ip.source_bmr_bpr_request_id, source_item.request_id)
                AND request.deleted_at IS NULL AND request.product_id = fg.product_id
            INNER JOIN material_requisition requisition
                ON requisition.id = request.material_requisition_id
                AND requisition.status = 1 AND requisition.deleted_at IS NULL
            INNER JOIN production_plans plan
                ON plan.id = requisition.prod_plan_id AND plan.id = request.production_plan_id
                AND plan.product_id = fg.product_id AND plan.deleted_at IS NULL
            INNER JOIN products product ON product.id = fg.product_id
            WHERE fg.id = ? AND fg.deleted_at IS NULL
                AND BINARY TRIM(fg.batch_number) = BINARY TRIM(requisition.lot_batch_no)
                AND BINARY TRIM(fg.batch_number) = BINARY TRIM(plan.lo_batch_no)
            LIMIT 1";
    if ($forUpdate) {
        $sql .= ' FOR UPDATE';
    }
    $stmt = bmrBprPrepare($conn, $sql);
    $stmt->bind_param('i', $fgCoaId);
    $stmt->execute();
    $record = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$record) {
        throw new DomainException('The released batch is not linked to a valid production plan and material issuance.');
    }
    $requestId = (int) $record['request_id'];
    bmrBprValidateReleaseRecord($record, bmrBprRequestBprStatuses($conn, $requestId, $forUpdate));
    bmrBprRequireApprovedSampleAdvice($conn, (string) $record['batch_number'], $forUpdate);
    $bmrSql = "SELECT status FROM bmr_bpr_work_items
        WHERE request_id = ? AND form_type = 'BMR' AND deleted_at IS NULL ORDER BY id";
    if ($forUpdate) {
        $bmrSql .= ' FOR UPDATE';
    }
    $bmrStmt = bmrBprPrepare($conn, $bmrSql);
    $bmrStmt->bind_param('i', $requestId);
    $bmrStmt->execute();
    $bmrStatuses = array_column($bmrStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'status');
    $bmrStmt->close();
    if (!bmrBprBmrStatusesReady($bmrStatuses) || count($bmrStatuses) !== (int) $record['required_bmr_count']) {
        throw new DomainException('Release is blocked until every configured BMR is complete.');
    }
    return $record;
}

function bmrBprRequestHasApprovedIpCoa(mysqli $conn, int $requestId): bool
{
    if ($requestId <= 0) {
        return false;
    }

    $stmt = bmrBprPrepare(
        $conn,
        "SELECT ip.workflow_status, ip.coa_template_id, ip.form_payload_json
         FROM ip_coa_generation ip
         LEFT JOIN bmr_bpr_work_items source_item
            ON source_item.id = ip.source_bmr_work_item_id
         WHERE (
                ip.source_bmr_bpr_request_id = ?
                OR (ip.source_bmr_bpr_request_id IS NULL AND source_item.request_id = ?)
            )
           AND ip.deleted_at IS NULL
         ORDER BY ip.id DESC"
    );
    $stmt->bind_param('ii', $requestId, $requestId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($record = $result->fetch_assoc()) {
        if (bmrBprCoaRecordIsApproved($record)) {
            $stmt->close();
            return true;
        }
    }
    $stmt->close();
    return false;
}

function bmrBprRequestBprStatuses(mysqli $conn, int $requestId, bool $forUpdate = false): array
{
    if ($requestId <= 0) {
        return [];
    }

    $sql = "SELECT status
            FROM bmr_bpr_work_items
            WHERE request_id = ? AND form_type = 'BPR' AND deleted_at IS NULL
            ORDER BY id";
    if ($forUpdate) {
        $sql .= ' FOR UPDATE';
    }
    $stmt = bmrBprPrepare($conn, $sql);
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $statuses = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'status');
    $stmt->close();
    return $statuses;
}

function bmrBprRequestPackingStarted(mysqli $conn, int $requestId): bool
{
    foreach (bmrBprRequestBprStatuses($conn, $requestId) as $status) {
        if (in_array(strtoupper((string) $status), ['PENDING', 'IN_PROCESS', 'COMPLETE'], true)) {
            return true;
        }
    }
    return false;
}

function bmrBprRequestBprComplete(mysqli $conn, int $requestId, bool $forUpdate = false): bool
{
    $statuses = bmrBprRequestBprStatuses($conn, $requestId, $forUpdate);
    if ($statuses === []) {
        return false;
    }
    foreach ($statuses as $status) {
        if (strtoupper((string) $status) !== 'COMPLETE') {
            return false;
        }
    }
    return true;
}

function bmrBprEnsurePendingTransferTicketForRequest(
    mysqli $conn,
    int $requestId,
    int $userId
): ?int {
    if ($requestId <= 0 || !bmrBprRequestBprComplete($conn, $requestId, true)) {
        return null;
    }

    $fgStmt = bmrBprPrepare(
        $conn,
        "SELECT fg.id, fg.production_plan_id, fg.coa_fg, fg.product_id,
                fg.coa_template_id, fg.form_payload_json, fg.workflow_status,
                fg.product_name, fg.batch_number, fg.batch_size, fg.batch_size_unit,
                fg.test_date, fg.tested_by, product.product_code
         FROM fg_coa_generation fg
         INNER JOIN ip_coa_generation ip
            ON ip.id = fg.source_ip_coa_id AND ip.deleted_at IS NULL
         LEFT JOIN bmr_bpr_work_items source_item
            ON source_item.id = ip.source_bmr_work_item_id
         LEFT JOIN products product ON product.id = fg.product_id
         WHERE (
                ip.source_bmr_bpr_request_id = ?
                OR (ip.source_bmr_bpr_request_id IS NULL AND source_item.request_id = ?)
            )
           AND fg.deleted_at IS NULL
         ORDER BY fg.id DESC"
    );
    $fgStmt->bind_param('ii', $requestId, $requestId);
    $fgStmt->execute();
    $result = $fgStmt->get_result();
    $fg = null;
    while ($candidate = $result->fetch_assoc()) {
        if (bmrBprCoaRecordIsApproved($candidate)) {
            $fg = $candidate;
            break;
        }
    }
    $fgStmt->close();
    if ($fg === null) {
        return null;
    }

    $fgCoaId = (int) $fg['id'];
    $existingStmt = bmrBprPrepare(
        $conn,
        'SELECT id FROM transfer_ticket WHERE source_fg_coa_id = ? AND deleted_at IS NULL LIMIT 1'
    );
    $existingStmt->bind_param('i', $fgCoaId);
    $existingStmt->execute();
    $existing = $existingStmt->get_result()->fetch_assoc();
    $existingStmt->close();
    if ($existing) {
        return (int) $existing['id'];
    }

    $ticketDate = (string) (($fg['test_date'] ?? '') ?: date('Y-m-d'));
    $ticketNo = bmrBprTransferTicketNumber($fgCoaId, $ticketDate);
    $batchSize = (float) ($fg['batch_size'] ?? 0);
    $batchUnitId = (int) ($fg['batch_size_unit'] ?? 0);
    $productCode = trim((string) ($fg['product_code'] ?? ''));
    $autoBatchNumber = generateBatchNumber();
    $quantity = rtrim(rtrim(number_format($batchSize, 8, '.', ''), '0'), '.');
    $mfgDate = $ticketDate;
    $expDate = date('Y-m-d', strtotime('+2 years', strtotime($ticketDate)));
    $sampledBy = trim((string) ($fg['tested_by'] ?? '')) ?: 'QC Analyst';

    $ticketStmt = bmrBprPrepare(
        $conn,
        "INSERT INTO transfer_ticket
            (source_fg_coa_id, prod_plan_id, ticket_no, fg_coa_no, code, date,
             product_description, pack_size, pack_size_unit, product_code, batch_no,
             mfg_date, exp_date, sampled_qa, sampled_qa_unit, quantity_transferred,
             quantity_transferred_unit, status, auto_batch_number, remark,
             workflow_status, created_by, created_at)
         VALUES (?, NULLIF(?, 0), ?, ?, ?, ?, ?, ?, NULLIF(?, 0), ?, ?, ?, ?, ?, NULL,
                 ?, NULLIF(?, 0), 0, ?, ?, 'PENDING', ?, NOW())"
    );
    $productionPlanId = (int) ($fg['production_plan_id'] ?? 0);
    $productName = trim((string) ($fg['product_name'] ?? ''));
    $batchNumber = trim((string) ($fg['batch_number'] ?? ''));
    $packSize = (int) round($batchSize);
    $remark = 'Automatically queued after BPR completion and FG COA approval. Pending Production confirmation.';
    $ticketStmt->bind_param(
        'iisssssiissssssissi',
        $fgCoaId,
        $productionPlanId,
        $ticketNo,
        $fg['coa_fg'],
        $productCode,
        $ticketDate,
        $productName,
        $packSize,
        $batchUnitId,
        $productCode,
        $batchNumber,
        $mfgDate,
        $expDate,
        $sampledBy,
        $quantity,
        $batchUnitId,
        $autoBatchNumber,
        $remark,
        $userId
    );
    if (!$ticketStmt->execute()) {
        $errorNumber = (int) $ticketStmt->errno;
        $errorMessage = $ticketStmt->error;
        $ticketStmt->close();
        if ($errorNumber === 1062) {
            $retryStmt = bmrBprPrepare(
                $conn,
                'SELECT id FROM transfer_ticket WHERE source_fg_coa_id = ? AND deleted_at IS NULL LIMIT 1'
            );
            $retryStmt->bind_param('i', $fgCoaId);
            $retryStmt->execute();
            $retry = $retryStmt->get_result()->fetch_assoc();
            $retryStmt->close();
            if ($retry) {
                return (int) $retry['id'];
            }
        }
        throw new RuntimeException('Unable to automatically queue the Transfer Ticket: ' . $errorMessage);
    }
    $ticketId = (int) $conn->insert_id;
    $ticketStmt->close();

    bmrBprInsertHistory(
        $conn,
        'TRANSFER_TICKET',
        $ticketId,
        'AUTO_QUEUE_TRANSFER_TICKET',
        null,
        'PENDING',
        $remark,
        ['source_fg_coa_id' => $fgCoaId, 'request_id' => $requestId, 'ticket_no' => $ticketNo],
        $userId
    );

    return $ticketId;
}

function bmrBprWorkItemTransition(string $currentStatus, string $event): string
{
    $currentStatus = strtoupper($currentStatus);
    $event = strtoupper($event);

    if ($event === 'GET_FORM') {
        if ($currentStatus === 'QUEUED') {
            return 'PENDING';
        }
        if (in_array($currentStatus, ['PENDING', 'IN_PROCESS', 'COMPLETE'], true)) {
            return $currentStatus;
        }
    }

    if ($event === 'DRAFT' && in_array($currentStatus, ['PENDING', 'IN_PROCESS'], true)) {
        return 'IN_PROCESS';
    }
    if ($event === 'SUBMIT' && in_array($currentStatus, ['PENDING', 'IN_PROCESS'], true)) {
        return 'COMPLETE';
    }
    if ($currentStatus === 'COMPLETE' && in_array($event, ['DRAFT', 'SUBMIT'], true)) {
        return 'COMPLETE';
    }

    throw new DomainException('This BMR/BPR status transition is not allowed.');
}

function bmrBprValidateBatchIdentity(int $sourceProductId, float $sourceBatchSize, int $productId, float $batchSize): void
{
    if ($sourceProductId <= 0 || $sourceProductId !== $productId
        || !is_finite($sourceBatchSize) || $sourceBatchSize <= 0
        || !is_finite($batchSize) || abs($sourceBatchSize - $batchSize) > 0.00000001) {
        throw new DomainException('Product and batch size must match the linked production record.');
    }
}

function bmrBprEnsureRequestForMaterialRequisition(mysqli $conn, int $materialRequisitionId, int $userId): int
{
    if ($materialRequisitionId <= 0) {
        throw new InvalidArgumentException('A valid Material Requisition is required.');
    }

    $existingStmt = bmrBprPrepare(
        $conn,
        'SELECT id
         FROM bmr_bpr_requests
         WHERE material_requisition_id = ? AND deleted_at IS NULL
         LIMIT 1'
    );
    $existingStmt->bind_param('i', $materialRequisitionId);
    $existingStmt->execute();
    $existing = $existingStmt->get_result()->fetch_assoc();
    $existingStmt->close();
    if ($existing) {
        return (int) $existing['id'];
    }

    $sourceStmt = bmrBprPrepare(
        $conn,
        "SELECT
            mr.id,
            mr.prod_plan_id,
            mr.bom_master_id,
            mr.date AS request_date,
            mr.product_name AS mr_product_name,
            mr.lot_batch_no,
            mr.batch_size,
            mr.batch_size_unit,
            COALESCE(pp.product_id, bm.finished_product_id) AS product_id,
            pp.document_batch_no,
            COALESCE(p.product_name, bmp.product_name) AS product_name,
            COALESCE(p.product_code, bmp.product_code) AS product_code,
            (
                SELECT TRIM(CONCAT_WS(' ', pps.pack_size, su.short_name))
                FROM product_pack_sizes pps
                LEFT JOIN standard_units su ON su.id = pps.pack_unit_id
                WHERE pps.product_id = COALESCE(pp.product_id, bm.finished_product_id)
                  AND pps.status != 3
                  AND pps.deleted_at IS NULL
                ORDER BY pps.sort_order ASC, pps.id ASC
                LIMIT 1
            ) AS pack_size
         FROM material_requisition mr
            INNER JOIN production_plans pp
            ON pp.id = mr.prod_plan_id AND pp.deleted_at IS NULL
         LEFT JOIN products p
            ON p.id = pp.product_id AND p.deleted_at IS NULL
         LEFT JOIN bom_master bm
            ON bm.id = mr.bom_master_id AND bm.deleted_at IS NULL
         LEFT JOIN products bmp
            ON bmp.id = bm.finished_product_id AND bmp.deleted_at IS NULL
         WHERE mr.id = ? AND mr.status = 1 AND mr.deleted_at IS NULL
                     AND EXISTS (SELECT 1 FROM material_requisition_items issued_item
                                             WHERE issued_item.mr_id = mr.id AND issued_item.status != 3 AND issued_item.deleted_at IS NULL)
                     AND NOT EXISTS (SELECT 1 FROM material_requisition_items pending_item
                                                     WHERE pending_item.mr_id = mr.id AND pending_item.status != 3
                                                         AND pending_item.deleted_at IS NULL
                                                         AND pending_item.required_qty > COALESCE(pending_item.issued_qty, 0) + 0.000001)
         LIMIT 1"
    );
    $sourceStmt->bind_param('i', $materialRequisitionId);
    $sourceStmt->execute();
    $source = $sourceStmt->get_result()->fetch_assoc();
    $sourceStmt->close();
    if (!$source) {
        throw new RuntimeException('The Material Requisition could not be found.');
    }

    $productId = isset($source['product_id']) ? (int) $source['product_id'] : 0;
    $productName = trim((string) ($source['product_name'] ?: $source['mr_product_name']));
    $categoryCode = trim((string) ($source['product_code'] ?? ''));

    if ($productId <= 0 && $productName !== '') {
        $productStmt = bmrBprPrepare(
            $conn,
            'SELECT id, product_name, product_code
             FROM products
             WHERE product_name = ? AND status != 3 AND deleted_at IS NULL
             ORDER BY id DESC LIMIT 1'
        );
        $productStmt->bind_param('s', $productName);
        $productStmt->execute();
        $product = $productStmt->get_result()->fetch_assoc();
        $productStmt->close();
        if ($product) {
            $productId = (int) $product['id'];
            $productName = trim((string) $product['product_name']);
            $categoryCode = trim((string) ($product['product_code'] ?? ''));
        }
    }

    if ($productName === '') {
        throw new RuntimeException('The Material Requisition does not contain a product name.');
    }

    $productionPlanId = (!empty($source['prod_plan_id']) && (int) $source['prod_plan_id'] > 0) ? (int) $source['prod_plan_id'] : 0;
    $requestDate = (string) ($source['request_date'] ?: date('Y-m-d'));
    $lotNumber = trim((string) ($source['lot_batch_no'] ?? ''));
    $productionBatchNumber = trim((string) ($source['document_batch_no'] ?? ''));
    $batchSize = isset($source['batch_size']) ? (float) $source['batch_size'] : null;
    $batchSizeUnitId = (!empty($source['batch_size_unit']) && (int) $source['batch_size_unit'] > 0) ? (int) $source['batch_size_unit'] : 0;
    $packSize = bmrBprResolveProductPackSize(
        $conn,
        $productId,
        $productName,
        trim((string) ($source['pack_size'] ?? ''))
    );

    $mapStmt = bmrBprPrepare(
        $conn,
        'SELECT form_type, COUNT(*) AS cnt
         FROM bmr_template_product_mappings
         WHERE product_id = ? AND status = 1 AND deleted_at IS NULL
         GROUP BY form_type'
    );
    $mapStmt->bind_param('i', $productId);
    $mapStmt->execute();
    $mapRes = $mapStmt->get_result();
    $configuredBmr = 0;
    $configuredBpr = 0;
    while ($mRow = $mapRes->fetch_assoc()) {
        $fType = strtoupper(trim((string) $mRow['form_type']));
        if ($fType === 'BMR') {
            $configuredBmr = (int) $mRow['cnt'];
        } elseif ($fType === 'BPR') {
            $configuredBpr = (int) $mRow['cnt'];
        }
    }
    $mapStmt->close();

    $bmrFormCount = $configuredBmr > 0 ? $configuredBmr : 1;
    $bprFormCount = $configuredBpr > 0 ? $configuredBpr : 1;
    $formCount = $bmrFormCount + $bprFormCount;

    $insertStmt = bmrBprPrepare(
        $conn,
        'INSERT INTO bmr_bpr_requests
            (material_requisition_id, production_plan_id, product_id, request_date,
             product_name, category_code, lot_number, production_batch_number,
             batch_size, batch_size_unit_id, pack_size, form_count, bmr_form_count, bpr_form_count,
             status, created_by, created_at)
         VALUES (?, NULLIF(?, 0), NULLIF(?, 0), ?, ?, ?, ?, ?, ?, NULLIF(?, 0), ?, ?, ?, ?, "UPCOMING", ?, NOW())'
    );
    $insertStmt->bind_param(
        'iiisssssdisiiii',
        $materialRequisitionId,
        $productionPlanId,
        $productId,
        $requestDate,
        $productName,
        $categoryCode,
        $lotNumber,
        $productionBatchNumber,
        $batchSize,
        $batchSizeUnitId,
        $packSize,
        $formCount,
        $bmrFormCount,
        $bprFormCount,
        $userId
    );
    if (!$insertStmt->execute()) {
        $insertError = $insertStmt->error;
        if ((int) $insertStmt->errno === 1062) {
            $insertStmt->close();
            $retryStmt = bmrBprPrepare(
                $conn,
                'SELECT id FROM bmr_bpr_requests
                 WHERE material_requisition_id = ? AND deleted_at IS NULL LIMIT 1'
            );
            $retryStmt->bind_param('i', $materialRequisitionId);
            $retryStmt->execute();
            $retry = $retryStmt->get_result()->fetch_assoc();
            $retryStmt->close();
            if ($retry) {
                return (int) $retry['id'];
            }
        }
        $insertStmt->close();
        throw new RuntimeException('Unable to create the BMR/BPR Form Request' . ($insertError ? ': ' . $insertError : '.'));
    }
    $requestId = (int) $conn->insert_id;
    $insertStmt->close();

    $configuredCounts = bmrBprSnapshotProductDocumentRequirements(
        $conn, $requestId, $productId, $bmrFormCount, $bprFormCount, $userId, $packSize
    );
    $bmrFormCount = $configuredCounts['BMR'];
    $bprFormCount = $configuredCounts['BPR'];
    $formCount = $bmrFormCount + $bprFormCount;
    $requestNo = bmrBprRequestNumber($requestId, $requestDate);
    $numberStmt = bmrBprPrepare(
        $conn,
        "UPDATE bmr_bpr_requests SET request_no = ?, bmr_form_count = ?, bpr_form_count = ?, form_count = ?,
             status = 'UPCOMING' WHERE id = ?"
    );
    $numberStmt->bind_param('siiii', $requestNo, $bmrFormCount, $bprFormCount, $formCount, $requestId);
    if (!$numberStmt->execute()) {
        $numberStmt->close();
        throw new RuntimeException('Unable to assign the BMR/BPR request number.');
    }
    $numberStmt->close();

    bmrBprInsertHistory(
        $conn,
        'REQUEST',
        $requestId,
        'AUTO_QUEUED_FROM_MATERIAL_REQUISITION',
        null,
        'UPCOMING',
        'Automatically queued after all Material Requisition items were issued. Pending form request selection in Step 5.',
        ['material_requisition_id' => $materialRequisitionId],
        $userId
    );

    return $requestId;
}

function bmrBprStatusLabel(string $status): string
{
    return match (strtoupper($status)) {
        'QUEUED' => 'Queued',
        'IN_PROCESS' => 'In-Process',
        'COMPLETE' => 'Complete',
        'PENDING' => 'Pending',
        'UPCOMING' => 'Upcoming',
        'SUBMITTED' => 'Submitted',
        'APPROVED' => 'Approved',
        'REJECTED' => 'Rejected',
        default => ucwords(strtolower(str_replace('_', ' ', $status))),
    };
}

function bmrBprDisplayBatchSize(float|string|null $size, ?string $unit): string
{
    if ($size === null || $size === '') {
        return trim((string) $unit);
    }
    $number = (float) $size;
    $formatted = abs($number - round($number)) < 0.000001
        ? number_format($number, 0)
        : rtrim(rtrim(number_format($number, 3, '.', ','), '0'), '.');
    return trim($formatted . ' ' . trim((string) $unit));
}

function bmrBprResolveTemplateId(mysqli $conn, int $productId, string $formType): ?int
{
    $formType = strtoupper(trim($formType));
    if ($productId <= 0 || !in_array($formType, ['BMR', 'BPR'], true)) {
        return null;
    }

    $stmt = bmrBprPrepare(
        $conn,
        "SELECT mapping.template_id
         FROM bmr_template_product_mappings mapping
         INNER JOIN bmr_templates template
            ON template.id = mapping.template_id
           AND template.form_type = mapping.form_type
           AND template.status = 1
           AND template.deleted_at IS NULL
         WHERE mapping.product_id = ?
           AND mapping.form_type = ?
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         ORDER BY mapping.document_sequence, mapping.id
         LIMIT 1"
    );
    $stmt->bind_param('is', $productId, $formType);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ? (int) $row['template_id'] : null;
}

function bmrBprWorkItemRecordNumber(array $row): string
{
    $formType = strtoupper((string) ($row['form_type'] ?? 'BMR'));
    $workItemId = (int) ($row['id'] ?? 0);
    $sequence = max(1, (int) ($row['form_sequence'] ?? 1));
    $requestDate = (string) ($row['request_date'] ?? date('Y-m-d'));
    return sprintf(
        '%s/FY%s/%06d-%02d',
        $formType,
        bmrBprFiscalYearLabel($requestDate),
        $workItemId,
        $sequence
    );
}

function bmrBprBrandingLogoDataUri(mysqli $conn): string
{
    static $dataUri = null;
    if ($dataUri !== null) {
        return $dataUri;
    }

    $branding = function_exists('mvGetCompanyBranding')
        ? mvGetCompanyBranding($conn)
        : [];
    $configuredPaths = [
        'assets/img/logo3.jpeg',
        $branding['letterhead_logo'] ?? null,
        $branding['logo'] ?? null,
    ];
    $projectRoot = dirname(__DIR__, 2);
    foreach ($configuredPaths as $configuredPath) {
        $configuredPath = trim((string) $configuredPath);
        if ($configuredPath === '' || preg_match('#^https?://#i', $configuredPath)) {
            continue;
        }
        $isAbsolute = preg_match('#^[A-Za-z]:[\\\\/]#', $configuredPath) === 1
            || str_starts_with($configuredPath, '/');
        $candidate = $isAbsolute
            ? $configuredPath
            : $projectRoot . '/' . ltrim(str_replace('\\', '/', $configuredPath), '/');
        if (!is_file($candidate) || !is_readable($candidate)) {
            continue;
        }
        $contents = file_get_contents($candidate);
        if ($contents === false || $contents === '') {
            continue;
        }
        $mimeType = function_exists('mime_content_type')
            ? (string) mime_content_type($candidate)
            : '';
        if (!str_starts_with($mimeType, 'image/')) {
            $extension = strtolower((string) pathinfo($candidate, PATHINFO_EXTENSION));
            $mimeType = match ($extension) {
                'png' => 'image/png',
                'svg' => 'image/svg+xml',
                'webp' => 'image/webp',
                default => 'image/jpeg',
            };
        }
        $dataUri = 'data:' . $mimeType . ';base64,' . base64_encode($contents);
        return $dataUri;
    }

    $dataUri = '';
    return $dataUri;
}

function bmrBprLoadWorkItemTemplate(mysqli $conn, int $workItemId): array
{
    $stmt = bmrBprPrepare(
        $conn,
        "SELECT
            wi.id,
            wi.request_id,
            wi.form_type,
            wi.form_sequence,
            wi.status,
            wi.template_id,
            wi.template_snapshot_id,
            wi.form_payload_json,
            wi.created_at,
            wi.updated_at,
            r.request_no,
            r.request_date,
            r.production_plan_id,
            r.product_id,
            r.product_name,
            r.category_code,
            r.lot_number,
            r.production_batch_number,
            r.batch_size,
            r.pack_size,
            su.short_name AS batch_unit,
            pp.production_plan_no,
            template.template_code,
            template.template_name,
            template.document_no,
            template.issue_no,
            template.revision_no,
            template.effective_date,
            template.mfr_reference,
            template.source_pdf_path,
            template.page_asset_path,
            template.page_count,
            template.layout_json,
            COALESCE(creator.name, creator.email, 'System Admin') AS created_by_name
         FROM bmr_bpr_work_items wi
         INNER JOIN bmr_bpr_requests r
            ON r.id = wi.request_id AND r.deleted_at IS NULL
         LEFT JOIN standard_units su ON su.id = r.batch_size_unit_id
         LEFT JOIN production_plans pp
            ON pp.id = r.production_plan_id AND pp.deleted_at IS NULL
         LEFT JOIN bmr_templates template
            ON template.id = wi.template_id
           AND template.status = 1
           AND template.deleted_at IS NULL
         LEFT JOIN users creator ON creator.id = wi.created_by
         WHERE wi.id = ? AND wi.deleted_at IS NULL
         LIMIT 1"
    );
    $stmt->bind_param('i', $workItemId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) {
        throw new RuntimeException('The BMR/BPR work item was not found.');
    }

    $snapshot = templateSnapshotLoad($conn, (int) ($row['template_snapshot_id'] ?? 0));
    $snapshotProfile = [];
    if ($snapshot !== null) {
        $snapshotLayout = json_decode((string) ($snapshot['layout_json'] ?? ''), true) ?: [];
        $isSnapshotStructured = bmrBprIsStructuredLayout($snapshotLayout);
        if ($isSnapshotStructured) {
            $row['template_code'] = $snapshot['template_code'];
            $row['template_name'] = $snapshot['template_name'];
            $row['document_no'] = $snapshot['document_no'];
            $row['issue_no'] = $snapshot['issue_no'];
            $row['revision_no'] = $snapshot['version_no'];
            $row['effective_date'] = $snapshot['effective_date'];
            $row['layout_json'] = $snapshot['layout_json'];
            $row['source_pdf_path'] = $snapshot['metadata']['source_pdf_path'] ?? null;
            $row['page_asset_path'] = $snapshot['metadata']['page_asset_path'] ?? null;
            $row['mfr_reference'] = $snapshot['metadata']['mfr_reference'] ?? null;
            $row['page_count'] = $snapshot['metadata']['page_count'] ?? null;
            if (!empty($snapshot['profile_json'])) {
                $snapshotProfile = json_decode((string) $snapshot['profile_json'], true) ?: [];
            }
        }
    }

    $layout = [];
    if (!empty($row['layout_json'])) {
        $decoded = json_decode((string) $row['layout_json'], true);
        $layout = is_array($decoded) ? $decoded : [];
    }

    $payload = [];
    if (!empty($row['form_payload_json'])) {
        $decoded = json_decode((string) $row['form_payload_json'], true);
        $payload = is_array($decoded) ? $decoded : [];
    }
    $preserveLegacyFieldIds = [];
    foreach ((array) ($payload['fields'] ?? []) as $fieldId => $value) {
        if (trim((string) $value) !== '') {
            $preserveLegacyFieldIds[(string) $fieldId] = true;
        }
    }
    $layout = bmrBprNormalizeLegacyLayout($layout, $preserveLegacyFieldIds);

    $isStructured = bmrBprIsStructuredLayout($layout);
    $profile = [];
    if ($isStructured) {
        $profile = bmrBprStructuredProfile($layout, (int) ($row['product_id'] ?? 0));
        if ($profile === [] && !empty($snapshotProfile)) {
            $profile = $snapshotProfile;
        }
        if ($profile === []) {
            $families = is_array($layout['profile_families'] ?? null) ? $layout['profile_families'] : [];
            $profiles = is_array($layout['profiles'] ?? null) ? $layout['profiles'] : [];
            $familyKey = $families !== [] ? (string) array_key_first($families) : '';
            $fallback = $familyKey !== '' ? (array) $families[$familyKey] : (array) reset($profiles);
            if ($fallback !== []) {
                $fallback['product_name'] = (string) ($row['product_name'] ?? '');
                $fallback['pack_size'] = (string) ($row['pack_size'] ?? '');
                $profile = $fallback;
            }
        }
    }
    $assetDirectory = trim((string) ($row['page_asset_path'] ?? ''), '/');
    if (!$isStructured && !empty($layout['pages']) && is_array($layout['pages'])) {
        foreach ($layout['pages'] as &$page) {
            $image = basename((string) ($page['image'] ?? ''));
            $page['image_url'] = $image === '' ? '' : (function_exists('asset') ? asset($assetDirectory . '/' . $image) : '/' . $assetDirectory . '/' . $image);
        }
        unset($page);
    }

    $batchNumber = trim((string) ($row['production_batch_number'] ?? ''));
    if ($batchNumber === '') {
        $batchNumber = trim((string) ($row['lot_number'] ?? ''));
    }
    $sourceValues = [
        'product_name' => (string) ($row['product_name'] ?? ''),
        'batch_number' => $batchNumber,
        'batch_size' => bmrBprDisplayBatchSize($row['batch_size'], $row['batch_unit'] ?? ''),
        'pack_size' => (string) ($row['pack_size'] ?? ''),
        'record_number' => bmrBprWorkItemRecordNumber($row),
        'lot_number' => (string) ($row['lot_number'] ?? ''),
        'request_date' => !empty($row['request_date'])
            ? date('d/m/Y', strtotime((string) $row['request_date']))
            : '',
    ];

    $clientLayout = $layout;
    if ($isStructured) {
        unset($clientLayout['profiles'], $clientLayout['profile_families']);
    }
    $hasTemplate = $isStructured
        ? $profile !== []
        : !empty($layout['pages']);
    $pageCount = $isStructured
        ? (int) ($profile['page_count'] ?? 0)
        : (int) ($row['page_count'] ?? 0);

    $form = [
        'work_item_id' => (string) $row['id'],
        'request_id' => (string) $row['request_id'],
        'form_type' => strtoupper((string) $row['form_type']),
        'form_sequence' => (int) $row['form_sequence'],
        'status_code' => strtoupper((string) $row['status']),
        'template_id' => isset($row['template_id']) ? (int) $row['template_id'] : null,
        'template_snapshot_id' => isset($row['template_snapshot_id']) ? (int) $row['template_snapshot_id'] : null,
        'template_code' => (string) ($row['template_code'] ?? ''),
        'template_name' => (string) ($row['template_name'] ?? ''),
        'document_no' => (string) ($row['document_no'] ?? ''),
        'issue_no' => (string) ($row['issue_no'] ?? ''),
        'revision_no' => (string) ($row['revision_no'] ?? ''),
        'effective_date' => (string) ($row['effective_date'] ?? ''),
        'mfr_reference' => (string) ($row['mfr_reference'] ?? ''),
        'page_count' => $pageCount,
        'created_by' => (string) ($row['created_by_name'] ?? 'System Admin'),
        'last_saved' => (string) (($row['updated_at'] ?? '') ?: ($row['created_at'] ?? '')),
        'has_template' => (!empty($row['template_snapshot_id']) || !empty($row['template_id'])) && $hasTemplate,
        'schema_version' => (int) ($layout['schema_version'] ?? 1),
        'layout' => $clientLayout,
        'profile' => $profile,
        'branding_logo_data_uri' => bmrBprBrandingLogoDataUri($conn),
        'source_values' => $sourceValues,
        'form_payload' => $payload,
        'download_url' => (function_exists('asset') ? asset('admin/pages/bmr_bpr_record_template.php?id=' . urlencode(function_exists('base64_encrypt') ? base64_encrypt((string) $row['id']) : base64_encode((string) $row['id'])) . '&triggerDownload=1') : ('/admin/pages/bmr_bpr_record_template.php?id=' . urlencode(function_exists('base64_encrypt') ? base64_encrypt((string) $row['id']) : base64_encode((string) $row['id'])) . '&triggerDownload=1')),
    ];

    if ($isStructured && $profile !== []) {
        $rendererForm = $form;
        $rendererForm['layout'] = $layout;
        $form['rendered_html'] = bmrBprRenderStructuredTemplate(
            $rendererForm,
            strtoupper((string) $row['status']) !== 'COMPLETE'
        );
    }

    return $form;
}

function bmrBprValidateCompletionPayload(array $layout, array $payload): void
{
    $fields = is_array($payload['fields'] ?? null) ? $payload['fields'] : [];
    $populated = array_filter($fields, static fn($value): bool => is_scalar($value) && trim((string) $value) !== '');
    if ($layout === [] || $populated === []) {
        throw new DomainException('Complete the approved BMR/BPR form before submitting it. Empty forms cannot be completed.');
    }
    $required = [];
    foreach (($layout['required_fields'] ?? []) as $fieldId) {
        if (is_string($fieldId)) {
            $required[$fieldId] = $fieldId;
        }
    }
    foreach (($layout['pages'] ?? []) as $page) {
        foreach (($page['fields'] ?? []) as $field) {
            if (!empty($field['required']) && !empty($field['editable']) && empty($field['source']) && !empty($field['id'])) {
                $required[$field['id']] = $field['label'] ?? $field['id'];
            }
        }
    }
    $missing = [];
    foreach ($required as $fieldId => $label) {
        if (!array_key_exists($fieldId, $populated)) {
            $missing[] = (string) $label;
        }
    }
    if ($missing !== []) {
        throw new DomainException('Complete the required BMR/BPR fields: ' . implode(', ', array_slice($missing, 0, 8)) . '.');
    }
}

function bmrBprSanitizeTemplatePayload(array $layout, array $payload): array
{
    $preserveLegacyFieldIds = [];
    foreach ((array) ($payload['fields'] ?? []) as $fieldId => $value) {
        if (is_string($fieldId) && is_scalar($value) && trim((string) $value) !== '') {
            $preserveLegacyFieldIds[$fieldId] = true;
        }
    }
    $layout = bmrBprNormalizeLegacyLayout($layout, $preserveLegacyFieldIds);

    if (bmrBprIsStructuredLayout($layout)) {
        $allowedPrefixes = array_values(array_filter(
            array_map(
                static fn ($prefix): string => trim((string) $prefix),
                is_array($layout['editable_prefixes'] ?? null) ? $layout['editable_prefixes'] : []
            ),
            static fn (string $prefix): bool => $prefix !== ''
        ));
        $cleanFields = [];
        foreach (($payload['fields'] ?? []) as $fieldKey => $value) {
            if (
                !is_string($fieldKey)
                || !preg_match('/^[a-z][a-z0-9_.-]{1,159}$/', $fieldKey)
                || !is_scalar($value)
            ) {
                continue;
            }
            $allowed = false;
            foreach ($allowedPrefixes as $prefix) {
                if (str_starts_with($fieldKey, $prefix)) {
                    $allowed = true;
                    break;
                }
            }
            if (!$allowed) {
                continue;
            }
            $trimmedValue = trim((string) $value);
            $isSigImage = bmrBprIsImageValue($trimmedValue);
            $cleanValue = $isSigImage
                ? mb_substr($trimmedValue, 0, 500000)
                : mb_substr($trimmedValue, 0, 4000);
            if ($cleanValue !== '') {
                $cleanFields[$fieldKey] = $cleanValue;
            }
        }
        ksort($cleanFields);
        return [
            'schema_version' => 2,
            'fields' => $cleanFields,
        ];
    }

    if (empty($layout['pages']) || !is_array($layout['pages'])) {
        $legacy = [];
        foreach ($payload as $key => $value) {
            if (is_string($key) && is_scalar($value)) {
                $legacy[$key] = mb_substr(trim((string) $value), 0, 2000);
            }
        }
        return $legacy;
    }

    $allowedFields = [];
    $pageNumbers = [];
    foreach ($layout['pages'] as $page) {
        $pageNumber = (int) ($page['page'] ?? 0);
        if ($pageNumber > 0) {
            $pageNumbers[$pageNumber] = true;
        }
        foreach (($page['fields'] ?? []) as $field) {
            if (
                !empty($field['editable'])
                && empty($field['source'])
                && is_string($field['id'] ?? null)
            ) {
                $allowedFields[$field['id']] = true;
            }
        }
    }

    $cleanFields = [];
    foreach (($payload['fields'] ?? []) as $fieldId => $value) {
        if (!isset($allowedFields[$fieldId]) || !is_scalar($value)) {
            continue;
        }
        $cleanValue = mb_substr(trim((string) $value), 0, 2000);
        if ($cleanValue !== '') {
            $cleanFields[$fieldId] = $cleanValue;
        }
    }

    $cleanCustom = [];
    if (!empty($layout['allow_custom_fields']) && is_array($payload['custom_fields'] ?? null)) {
        foreach (array_slice($payload['custom_fields'], 0, 500) as $index => $field) {
            if (!is_array($field)) {
                continue;
            }
            $page = (int) ($field['page'] ?? 0);
            $x = (float) ($field['x'] ?? -1);
            $y = (float) ($field['y'] ?? -1);
            $w = (float) ($field['w'] ?? 0);
            $h = (float) ($field['h'] ?? 0);
            $value = mb_substr(trim((string) ($field['value'] ?? '')), 0, 2000);
            if (
                !isset($pageNumbers[$page])
                || $x < 0 || $x > 99
                || $y < 0 || $y > 99
                || $w <= 0 || $w > 100
                || $h <= 0 || $h > 100
                || $x + $w > 100.001
                || $y + $h > 100.001
                || $value === ''
            ) {
                continue;
            }
            $cleanCustom[] = [
                'id' => 'custom_' . ($index + 1),
                'page' => $page,
                'x' => round($x, 5),
                'y' => round($y, 5),
                'w' => round($w, 5),
                'h' => round($h, 5),
                'value' => $value,
            ];
        }
    }

    return [
        'schema_version' => 1,
        'fields' => $cleanFields,
        'custom_fields' => $cleanCustom,
    ];
}

function bmrBprProductionRows(mysqli $conn): array
{
    $result = $conn->query(
        "SELECT
            wi.id,
            wi.request_id,
            wi.form_type,
            wi.form_sequence,
            wi.status,
            wi.template_id,
            wi.form_payload_json,
            wi.created_at,
            wi.updated_at,
            GREATEST(
                COALESCE(wi.updated_at, wi.created_at, '1000-01-01 00:00:00'),
                COALESCE(r.updated_at, r.reviewed_at, r.requested_at, r.created_at, '1000-01-01 00:00:00')
            ) AS activity_at,
            r.request_date,
            r.production_plan_id,
            r.product_id,
            r.product_name,
            r.category_code,
            r.lot_number,
            r.production_batch_number,
            r.batch_size,
            r.batch_size_unit_id,
            r.pack_size,
            r.form_count,
            pp.production_plan_no,
            su.short_name AS batch_unit,
            CASE WHEN bmr_gate.bmr_count = r.bmr_form_count
                THEN bmr_gate.bmr_status ELSE 'PENDING' END AS bmr_status,
            template.template_code,
            template.page_count,
            CASE
                WHEN source_mr.slip_no LIKE 'BMR-COMMON-SEROLOGY-DEMO-%'
                  OR source_mr.slip_no LIKE 'BMR-COMMON-MICROBIOLOGY-DEMO-%'
                  OR source_mr.slip_no LIKE 'BMR-COMMON-UROLOGY-DEMO-%'
                  OR source_mr.slip_no LIKE 'BMR-COMMON-BIOCHEMISTRY-DEMO-%'
                THEN 1
                ELSE 0
            END AS is_common_template_demo
         FROM bmr_bpr_work_items wi
         INNER JOIN bmr_bpr_requests r
            ON r.id = wi.request_id AND r.deleted_at IS NULL
         LEFT JOIN material_requisition source_mr
            ON source_mr.id = r.material_requisition_id
           AND source_mr.deleted_at IS NULL
         LEFT JOIN production_plans pp
            ON pp.id = r.production_plan_id
           AND pp.deleted_at IS NULL
         LEFT JOIN standard_units su ON su.id = r.batch_size_unit_id
         LEFT JOIN bmr_templates template
            ON template.id = wi.template_id
           AND template.status = 1
           AND template.deleted_at IS NULL
         LEFT JOIN (
            SELECT
                request_id,
                COUNT(*) AS bmr_count,
                CASE
                    WHEN SUM(status NOT IN ('IN_PROCESS', 'COMPLETE')) > 0 THEN 'PENDING'
                    WHEN SUM(status = 'IN_PROCESS') > 0 THEN 'IN_PROCESS'
                    ELSE 'COMPLETE'
                END AS bmr_status
            FROM bmr_bpr_work_items
            WHERE form_type = 'BMR' AND deleted_at IS NULL
            GROUP BY request_id
         ) bmr_gate ON bmr_gate.request_id = wi.request_id
         WHERE wi.deleted_at IS NULL
                     AND r.status = 'APPROVED'
           AND source_mr.status = 1
           AND COALESCE(r.remarks, '') NOT IN (
               'Common structured COA IP banner acceptance record.',
               'Common structured COA FG banner acceptance record.',
               'Common Serology FG COA template banner acceptance record.'
           )
         ORDER BY activity_at DESC, wi.id DESC"
    );
    if (!$result) {
        throw new RuntimeException('Unable to load Production BMR/BPR records.');
    }

    $rows = [];
    $approvedIpByRequest = [];
    while ($row = $result->fetch_assoc()) {
        $status = strtoupper((string) $row['status']);
        $formType = strtoupper((string) $row['form_type']);
        $bmrStatus = strtoupper((string) ($row['bmr_status'] ?? ''));
        $requestId = (int) $row['request_id'];
        if (!array_key_exists($requestId, $approvedIpByRequest)) {
            $approvedIpByRequest[$requestId] = bmrBprRequestHasApprovedIpCoa($conn, $requestId);
        }
        $ipCoaApproved = $approvedIpByRequest[$requestId];
        $payload = [];
        if (!empty($row['form_payload_json'])) {
            $decoded = json_decode((string) $row['form_payload_json'], true);
            $payload = is_array($decoded) ? $decoded : [];
        }
        $rows[] = [
            'id' => (string) $row['id'],
            'serial_number' => (int) $row['id'],
            'request_id' => (string) $row['request_id'],
            'production_plan_id' => isset($row['production_plan_id']) ? (int) $row['production_plan_id'] : null,
            'production_plan_no' => (string) ($row['production_plan_no'] ?? ''),
            'date' => (string) $row['request_date'],
            'activity_at' => (string) ($row['activity_at'] ?? ''),
            'product_id' => isset($row['product_id']) ? (int) $row['product_id'] : null,
            'product_name' => (string) $row['product_name'],
            'item_name' => (string) $row['product_name'],
            'category_code' => (string) ($row['category_code'] ?? ''),
            'form_type' => $formType,
            'form_sequence' => (int) $row['form_sequence'],
            'form_label' => $formType . ' #' . (int) $row['form_sequence'],
            'template_id' => isset($row['template_id']) ? (int) $row['template_id'] : null,
            'template_code' => (string) ($row['template_code'] ?? ''),
            'page_count' => (int) ($row['page_count'] ?? 0),
            'has_template' => !empty($row['template_id']) && !empty($row['template_code']),
            'lot_number' => (string) ($row['lot_number'] ?? ''),
            'batch_number' => (string) (($row['production_batch_number'] ?? '') ?: ($row['lot_number'] ?? '')),
            'batch_size_value' => $row['batch_size'] === null ? '' : (string) $row['batch_size'],
            'batch_unit_id' => isset($row['batch_size_unit_id']) ? (int) $row['batch_size_unit_id'] : null,
            'batch_unit' => (string) ($row['batch_unit'] ?? ''),
            'batch_size' => bmrBprDisplayBatchSize($row['batch_size'], $row['batch_unit'] ?? ''),
            'pack_size' => (string) ($row['pack_size'] ?? ''),
            'form_count' => (int) $row['form_count'],
            'status_code' => $status,
            'status' => bmrBprStatusLabel($status),
            'bmr_status_code' => $bmrStatus,
            'ip_coa_approved' => $ipCoaApproved,
            'can_open' => $formType === 'BMR' || ($bmrStatus === 'COMPLETE' && $ipCoaApproved),
            'is_common_template_demo' => (int) ($row['is_common_template_demo'] ?? 0) === 1,
            'form_payload' => $payload,
        ];
    }
    return $rows;
}
