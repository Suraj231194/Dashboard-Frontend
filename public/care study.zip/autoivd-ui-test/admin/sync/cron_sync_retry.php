<?php

/**
 * Automatic Sync Retry Worker — Background cron script.
 *
 *   Every 5 minutes: php /path/to/admin/sync/cron_sync_retry.php

 *
 * It picks up all failed sync_logs entries with attempts < 5,
 * checks if enough time has passed since the last attempt (increasing delay),
 * and re-executes the sync call.
 *
 * Location: admin/sync/cron_sync_retry.php
 */

// Bootstrap the ERP database connection.
require_once(__DIR__ . '/../db.php');
require_once(__DIR__ . '/../constant.php');
require_once(__DIR__ . '/../functions.php');
require_once(__DIR__ . '/SyncManager.php');
require_once(__DIR__ . '/SyncLogManager.php');
require_once(__DIR__ . '/SyncSettingsManager.php');
require_once(__DIR__ . '/OrderSyncHandler.php');
require_once(__DIR__ . '/InventorySyncHandler.php');
require_once(__DIR__ . '/CronLock.php');

$cronLock = CronLock::acquire('sync-retry');
if ($cronLock === null) {
    exit(0);
}

$settingsManager = new SyncSettingsManager($conn);
if (! $settingsManager->isReady()) {
    echo "[" . date('Y-m-d H:i:s') . "] Sync migrations are not ready. Retry cycle skipped.\n";
    exit(0);
}

$logManager = new SyncLogManager($conn);
$maxRetries = SyncManager::getMaxRetries();

// Fetch all retryable failed logs.
$failedLogs = $logManager->getRetryableFailedLogs($maxRetries);

if (empty($failedLogs)) {
    echo "[" . date('Y-m-d H:i:s') . "] No failed sync logs to retry.\n";
    exit(0);
}

echo "[" . date('Y-m-d H:i:s') . "] Found " . count($failedLogs) . " failed sync log(s) to retry.\n";

foreach ($failedLogs as $log) {
    $logId = (int) $log['id'];
    $attempts = (int) $log['attempts'];
    $lastAttempt = $log['last_attempt_at'] ? strtotime($log['last_attempt_at']) : 0;

    // Check if enough time has elapsed since the last attempt (increasing backoff).
    $requiredDelay = SyncManager::getRetryDelay($attempts);
    $elapsed = time() - $lastAttempt;

    if ($elapsed < $requiredDelay) {
        echo "  [Log #{$logId}] Skipping — only {$elapsed}s elapsed, need {$requiredDelay}s.\n";
        continue;
    }

    echo "  [Log #{$logId}] Retrying {$log['entity_type']} (attempt #{$attempts} + 1)...\n";

    // Route to the appropriate handler based on entity_type.
    $result = ['success' => false, 'message' => 'Unknown entity type'];

    switch ($log['entity_type']) {
        case 'orders':
            $handler = new OrderSyncHandler($conn);
            $result = $handler->retryFromLog($logId);
            break;

        case 'inventory':
            $handler = new InventorySyncHandler($conn);
            $result = $handler->retryFromLog($logId);
            break;

        // Future entity handlers will be added here:
        // case 'inventory':
        //     $handler = new InventorySyncHandler($conn);
        //     $result = $handler->retryFromLog($logId);
        //     break;

        default:
            echo "  [Log #{$logId}] Unknown entity type: {$log['entity_type']}\n";
            continue 2;
    }

    $status = $result['success'] ? 'SUCCESS' : 'FAILED';
    echo "  [Log #{$logId}] Result: {$status} — {$result['message']}\n";
}

echo "[" . date('Y-m-d H:i:s') . "] Retry cycle complete.\n";
