<?php

/**
 * SyncLogManager — Central logger for the ERP sync_logs database table.
 *
 * Provides methods to create, update, query, and manage sync log entries.
 * Used by all sync handlers and the Sync Settings UI page.
 *
 * Location: admin/sync/SyncLogManager.php
 */
class SyncLogManager
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    /**
     * Insert a new sync log entry with status 'pending'.
     */
    public function createLog(string $entityType, string $entityId, string $direction, array $requestPayload): int
    {
        $stmt = $this->conn->prepare(
            "INSERT INTO `sync_logs` (`entity_type`, `entity_id`, `direction`, `status`, `request_payload`, `attempts`, `created_at`)
             VALUES (?, ?, ?, 'pending', ?, 0, NOW())"
        );
        $payloadJson = json_encode($requestPayload, JSON_UNESCAPED_UNICODE);
        $stmt->bind_param('ssss', $entityType, $entityId, $direction, $payloadJson);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();

        return (int) $id;
    }

    /**
     * Mark a sync log entry as successful.
     */
    public function markSuccess(int $logId, string $responseBody = ''): void
    {
        $stmt = $this->conn->prepare(
            "UPDATE `sync_logs`
             SET `status` = 'success', `response_body` = ?, `error_message` = NULL,
                 `last_attempt_at` = NOW(), `updated_at` = NOW()
             WHERE `id` = ?"
        );
        $stmt->bind_param('si', $responseBody, $logId);
        $stmt->execute();
        $stmt->close();
    }

    /**
     * Mark a sync log entry as failed and increment attempts.
     */
    public function markFailed(int $logId, string $errorMessage, int $httpCode = 0): void
    {
        $stmt = $this->conn->prepare(
            "UPDATE `sync_logs`
             SET `status` = 'failed', `error_message` = ?, `http_code` = ?,
                 `attempts` = `attempts` + 1, `last_attempt_at` = NOW(), `updated_at` = NOW()
             WHERE `id` = ?"
        );
        $stmt->bind_param('sii', $errorMessage, $httpCode, $logId);
        $stmt->execute();
        $stmt->close();
    }

    /**
     * Fetch all failed sync logs that are eligible for automatic retry (attempts < maxRetries).
     */
    public function getRetryableFailedLogs(int $maxRetries = 5): array
    {
        $stmt = $this->conn->prepare(
            "SELECT * FROM `sync_logs`
             WHERE `status` IN ('pending', 'failed')
               AND `direction` = 'outbound' AND `attempts` < ?
             ORDER BY `created_at` ASC
             LIMIT 50"
        );
        $stmt->bind_param('i', $maxRetries);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $stmt->close();

        return $rows;
    }

    /**
     * Fetch a single sync log by ID.
     */
    public function getLogById(int $logId): ?array
    {
        $stmt = $this->conn->prepare("SELECT * FROM `sync_logs` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $logId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $row ?: null;
    }

    /**
     * Fetch paginated sync logs for the Sync Settings UI grid.
     */
    public function getLogsForDashboard(int $limit = 50, int $offset = 0, string $statusFilter = '', string $entityFilter = ''): array
    {
        $where = "1=1";
        $params = [];
        $types = '';

        if ($statusFilter !== '') {
            $where .= " AND `status` = ?";
            $params[] = $statusFilter;
            $types .= 's';
        }

        if ($entityFilter !== '') {
            $where .= " AND `entity_type` = ?";
            $params[] = $entityFilter;
            $types .= 's';
        }

        // Count total matching records.
        $countStmt = $this->conn->prepare("SELECT COUNT(*) AS `total` FROM `sync_logs` WHERE {$where}");
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $total = (int) $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();

        // Fetch page of results.
        $sql = "SELECT * FROM `sync_logs` WHERE {$where} ORDER BY `created_at` DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $stmt->close();

        return [
            'total' => $total,
            'data' => $rows,
        ];
    }

    /**
     * Get summary counts for the dashboard header cards.
     */
    public function getDashboardSummary(): array
    {
        $result = $this->conn->query(
            "SELECT `status`, COUNT(*) AS `count`
             FROM `sync_logs`
             GROUP BY `status`"
        );

        $summary = ['pending' => 0, 'success' => 0, 'failed' => 0];
        while ($row = $result->fetch_assoc()) {
            $summary[$row['status']] = (int) $row['count'];
        }

        return $summary;
    }
}
