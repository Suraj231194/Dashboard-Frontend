<?php

/**
 * InventorySyncHandler — Isolated handler for Inventory & Stock sync operations.
 *
 * Handles:
 * - Checking category & product website_sync flags (website_sync = 1)
 * - Calculating available live stock from live_stock table
 * - Fetching active batch details (COA number, Lot/Batch, Mfg/Exp dates)
 * - Pushing stock updates to Website API (/api/erp-sync/inventory/update)
 * - Bulk category stock push when an admin enables category website_sync
 * - Retry from log for failed inventory sync entries
 *
 * Location: admin/sync/InventorySyncHandler.php
 */

require_once(__DIR__ . '/SyncManager.php');
require_once(__DIR__ . '/SyncLogManager.php');
require_once(__DIR__ . '/SyncSettingsManager.php');
require_once(__DIR__ . '/SyncLogger.php');

class InventorySyncHandler
{
    private $conn;
    private SyncLogManager $logManager;
    private SyncSettingsManager $settingsManager;

    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->logManager = new SyncLogManager($conn);
        $this->settingsManager = new SyncSettingsManager($conn);
    }

    /**
     * Push current stock quantity and batch details for a product to the Website API.
     *
     * MUST satisfy filtering rule: category.website_sync = 1 AND product.website_sync = 1.
     *
     * @param int $productId  ERP product.id
     * @return array  ['success' => bool, 'message' => string, 'skipped' => bool]
     */
    public function pushProductStockToWebsite(int $productId): array
    {
        if (! $this->settingsManager->isEnabled('inventory')) {
            return ['success' => false, 'message' => 'Inventory sync is disabled.', 'skipped' => true, 'disabled' => true];
        }

        // Step 1: Fetch product details and check website_sync flags on category & product.
        $stmt = $this->conn->prepare(
            "SELECT p.`id`, p.`product_name`, p.`erp_sku_web`, p.`product_code`, p.`category_id`,
                    p.`website_sync` AS product_sync,
                    c.`website_sync` AS category_sync
             FROM `products` p
             LEFT JOIN `product_categories` c ON c.`id` = p.`category_id`
             WHERE p.`id` = ? AND p.`deleted_at` IS NULL
             LIMIT 1"
        );
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$product) {
            return ['success' => false, 'message' => 'Product not found.', 'skipped' => false];
        }

        // Category-level and Product-level Filtering Gatekeeper
        $categorySyncEnabled = (int) ($product['category_sync'] ?? 0) === 1;
        $productSyncEnabled = (int) ($product['product_sync'] ?? 0) === 1;

        if (!$categorySyncEnabled || !$productSyncEnabled) {
            return [
                'success' => true,
                'message' => "Stock sync skipped: category_sync=" . ($categorySyncEnabled ? '1' : '0')
                           . ", product_sync=" . ($productSyncEnabled ? '1' : '0'),
                'skipped' => true,
            ];
        }

        $sku = trim((string) ($product['erp_sku_web'] ?? $product['product_code'] ?? ''));

        if (empty($sku)) {
            return ['success' => false, 'message' => 'Product has no erp_sku_web or product_code for SKU matching.', 'skipped' => false];
        }

        if (! $this->hasColumn('live_stock', 'sync_change_version')) {
            return [
                'success' => false,
                'message' => 'Inventory sync hardening migration is not applied.',
                'skipped' => false,
            ];
        }

        // Step 2: Read quantity, metadata and the mutation version from the
        // same stock snapshot. Only ERP mutations allocate this version.
        $stockStmt = $this->conn->prepare(
            "SELECT COALESCE(`unreserved_qty`, 0) AS total_stock,
                    `sync_change_version`, `coa_number`, `lot_batch_no`,
                    `mfg_date`, `exp_date`
             FROM `live_stock`
             WHERE `product_id` = ? AND `deleted_at` IS NULL
             ORDER BY `id` ASC
             LIMIT 1"
        );
        $stockStmt->bind_param('i', $productId);
        $stockStmt->execute();
        $stockRow = $stockStmt->get_result()->fetch_assoc();
        $stockStmt->close();

        $totalStock = (float) ($stockRow['total_stock'] ?? 0);
        $stockVersion = max(1, (int) ($stockRow['sync_change_version'] ?? 1));
        $batch = $stockRow ?: [];

        // Step 4: Build normalized payload for Website API.
        $payload = [
            'sku' => $sku,
            'product_name' => $product['product_name'],
            'stock_quantity' => round($totalStock, 3),
            'stock_version' => $stockVersion,
        ];

        if (!empty($batch['coa_number'])) {
            $payload['coa_no'] = $batch['coa_number'];
        }
        if (!empty($batch['lot_batch_no'])) {
            $payload['batch_no'] = $batch['lot_batch_no'];
        }
        if (!empty($batch['mfg_date'])) {
            $payload['mfg_date'] = $batch['mfg_date'];
        }
        if (!empty($batch['exp_date'])) {
            $payload['expiry_date'] = $batch['exp_date'];
        }

        // Step 5: Log the outbound inventory sync attempt.
        $logId = $this->logManager->createLog('inventory', (string) $productId, 'outbound', $payload);

        // Step 6: Execute non-blocking HTTP POST to Website API.
        $result = SyncManager::postToWebsite('/api/erp-sync/inventory/update', $payload);

        // Step 7: Update log & product timestamp.
        if ($result['success']) {
            $this->logManager->markSuccess($logId, $result['body']);

            // Update last_stock_sync_at on product
            $upStmt = $this->conn->prepare("UPDATE `products` SET `last_stock_sync_at` = NOW() WHERE `id` = ?");
            $upStmt->bind_param('i', $productId);
            $upStmt->execute();
            $upStmt->close();

            $this->acknowledgeStockVersion($productId, $stockVersion);

            return ['success' => true, 'message' => "Stock synced for SKU {$sku}: {$totalStock} units.", 'skipped' => false];
        } else {
            $this->logManager->markFailed($logId, $result['error'] ?? 'Stock sync failed', $result['http_code']);
            return ['success' => false, 'message' => "Stock sync failed for SKU {$sku}: " . ($result['error'] ?? ''), 'skipped' => false];
        }
    }

    /**
     * Bulk push stock for all enabled products in a specific category.
     * Called when an ERP admin turns ON website_sync for a category.
     */
    public function pushCategoryStockToWebsite(int $categoryId): array
    {
        $stmt = $this->conn->prepare(
            "SELECT `id` FROM `products`
             WHERE `category_id` = ? AND `website_sync` = 1 AND `deleted_at` IS NULL"
        );
        $stmt->bind_param('i', $categoryId);
        $stmt->execute();
        $result = $stmt->get_result();

        $syncedCount = 0;
        $skippedCount = 0;
        $failedCount = 0;

        while ($row = $result->fetch_assoc()) {
            $res = $this->pushProductStockToWebsite((int) $row['id']);
            if (!empty($res['skipped'])) {
                $skippedCount++;
            } elseif ($res['success']) {
                $syncedCount++;
            } else {
                $failedCount++;
            }
        }
        $stmt->close();

        return [
            'success' => true,
            'synced' => $syncedCount,
            'skipped' => $skippedCount,
            'failed' => $failedCount,
            'message' => "Category sync complete: {$syncedCount} synced, {$skippedCount} skipped, {$failedCount} failed.",
        ];
    }

    /**
     * Retry a previously failed inventory sync log entry.
     * Called by the cron retry worker or manual "Retry Now" button.
     */
    public function retryFromLog(int $logId): array
    {
        if (! $this->settingsManager->isEnabled('inventory')) {
            return ['success' => false, 'message' => 'Inventory sync is disabled.', 'disabled' => true];
        }

        $log = $this->logManager->getLogById($logId);

        if (!$log) {
            return ['success' => false, 'message' => 'Sync log not found.'];
        }

        if ($log['status'] === 'success') {
            return ['success' => true, 'message' => 'Already synced successfully.'];
        }

        if ($log['entity_type'] !== 'inventory') {
            return ['success' => false, 'message' => 'This handler only retries inventory sync logs.'];
        }
        if ($log['direction'] !== 'outbound') {
            return ['success' => false, 'message' => 'Inbound inventory failures require a new Website push.'];
        }

        $payload = json_decode($log['request_payload'], true);
        if (!$payload) {
            return ['success' => false, 'message' => 'Cannot decode stored request payload.'];
        }

        $result = SyncManager::postToWebsite('/api/erp-sync/inventory/update', $payload);

        if ($result['success']) {
            $this->logManager->markSuccess($logId, $result['body']);
            $productId = (int) ($log['entity_id'] ?? 0);
            $stockVersion = (int) ($payload['stock_version'] ?? 0);
            if ($productId > 0 && $stockVersion > 0) {
                $this->acknowledgeStockVersion($productId, $stockVersion);
            }
            return ['success' => true, 'message' => 'Inventory retry successful.'];
        } else {
            $this->logManager->markFailed($logId, $result['error'] ?? 'Retry failed', $result['http_code']);
            return ['success' => false, 'message' => 'Inventory retry failed: ' . ($result['error'] ?? '')];
        }
    }

    private function acknowledgeStockVersion(int $productId, int $stockVersion): void
    {
        $stmt = $this->conn->prepare(
            "UPDATE `live_stock`
             SET `sync_pending` = 0, `last_sync_at` = NOW()
             WHERE `product_id` = ? AND `sync_pending` = 1
               AND `sync_change_version` = ?"
        );
        if (! $stmt) {
            return;
        }
        $stmt->bind_param('ii', $productId, $stockVersion);
        $stmt->execute();
        $stmt->close();
    }

    private function hasColumn(string $table, string $column): bool
    {
        $stmt = $this->conn->prepare(
            'SELECT 1 FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1'
        );
        if (! $stmt) {
            return false;
        }
        $stmt->bind_param('ss', $table, $column);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        return $exists;
    }
}
