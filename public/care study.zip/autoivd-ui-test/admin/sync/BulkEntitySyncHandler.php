<?php

/**
 * BulkEntitySyncHandler — Core Pull + ACK Sync Handler for the remaining 5 website entities:
 * 1. User Management (users -> customers)
 * 2. Meeting Requests (meeting_requests -> meeting_requests)
 * 3. Quiz Management / Lead Activity Feed (diagnostic_quiz_responses -> quiz_leads)
 * 4. PI Requests (proforma_invoices -> pi_requests + pi_request_items)
 * 5. Quotation Requests (quotations -> quotation_requests + quotation_request_items)
 *
 * Pattern:
 * 1. GET /api/erp-sync/unsynced?entity={entity}&limit=100 from Website API
 * 2. Insert/Update into ERP database tables using UNIQUE (website_id)
 * 3. Collect successfully inserted website IDs
 * 4. POST /api/erp-sync/acknowledge with synced_ids back to Website API
 * 5. Log operation in ERP sync_logs table
 *
 * Location: admin/sync/BulkEntitySyncHandler.php
 */

require_once(__DIR__ . '/SyncManager.php');
require_once(__DIR__ . '/SyncLogManager.php');
require_once(__DIR__ . '/SyncSettingsManager.php');
require_once(__DIR__ . '/SyncLogger.php');

class BulkEntitySyncHandler
{
    private $conn;
    private SyncLogManager $logManager;
    private SyncSettingsManager $settingsManager;
    private string $lastSaveError = '';

    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->logManager = new SyncLogManager($conn);
        $this->settingsManager = new SyncSettingsManager($conn);
    }

    /**
     * Pull unsynced records for a specific entity, save to ERP DB, and send ACK.
     *
     * @param string $entity  'users', 'meetings', 'quiz', 'pi', 'quotations'
     * @return array  ['success' => bool, 'message' => string, 'synced_count' => int]
     */
    public function pullAndSyncEntity(string $entity): array
    {
        if (! isset(SyncSettingsManager::definitions()[$entity])) {
            return ['success' => false, 'message' => 'Unknown sync entity.', 'synced_count' => 0];
        }
        if (! $this->settingsManager->isEnabled($entity)) {
            return ['success' => false, 'message' => "Sync is disabled for {$entity}.", 'synced_count' => 0, 'disabled' => true];
        }

        $this->settingsManager->markStarted($entity);
        $baseUrl = SyncManager::getWebsiteBaseUrl();
        $token = SyncManager::getWebsiteSyncToken();

        if (empty($baseUrl) || empty($token)) {
            $message = 'Website sync URL or token not configured.';
            $this->settingsManager->markCompleted($entity, false, $message);
            return ['success' => false, 'message' => $message, 'synced_count' => 0];
        }

        // Step 1: GET unsynced records from Website API
        $url = rtrim($baseUrl, '/') . "/api/erp-sync/unsynced?entity=" . urlencode($entity) . "&limit=100";
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Authorization: Bearer ' . $token,
            ],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        $responseBody = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr = curl_error($ch);
        curl_close($ch);

        SyncLogger::write($entity, 'PULL_START', "Starting sync pull for {$entity}");

        if ($curlErr || $httpCode !== 200) {
            $errMsg = "GET unsynced failed for {$entity} (HTTP {$httpCode}): " . ($curlErr ?: substr((string)$responseBody, 0, 300));
            SyncLogger::write($entity, 'HTTP_ERROR', $errMsg, ['response_body' => $responseBody]);
            $this->settingsManager->markCompleted($entity, false, $errMsg);
            return ['success' => false, 'message' => $errMsg, 'synced_count' => 0];
        }

        $resData = json_decode($responseBody, true);
        if (! is_array($resData) || ($resData['status'] ?? '') !== 'success') {
            $message = "Website returned an invalid sync response for {$entity}.";
            SyncLogger::write($entity, 'INVALID_RESPONSE', $message, ['raw_response' => $responseBody]);
            $this->settingsManager->markCompleted($entity, false, $message);
            return ['success' => false, 'message' => $message, 'synced_count' => 0];
        }
        if (empty($resData['data'])) {
            $message = "No pending unsynced records found for {$entity}.";
            SyncLogger::write($entity, 'PULL_EMPTY', $message);
            $this->settingsManager->markCompleted($entity, true, $message);
            return ['success' => true, 'message' => $message, 'synced_count' => 0];
        }

        $items = $resData['data'];
        SyncLogger::write($entity, 'PULL_FETCHED', "Fetched " . count($items) . " record(s) for {$entity}", ['item_ids' => array_column($items, 'id')]);
        $successfulWebIds = [];
        $successfulRecords = [];

        // Step 2: Process and save each record into ERP database based on entity type
        foreach ($items as $item) {
            $webId = (int) ($item['id'] ?? 0);
            if ($webId <= 0) continue;

            $saved = match ($entity) {
                'users' => $this->saveCustomer($item),
                'meetings' => $this->saveMeetingRequest($item),
                'quiz' => $this->saveQuizLead($item),
                'pi' => $this->saveProformaInvoice($item),
                'quotations' => $this->saveQuotation($item),
                default => false,
            };

            if ($saved) {
                $successfulWebIds[] = $webId;
                $successfulRecords[] = [
                    'id' => $webId,
                    'sync_version' => (int) ($item['sync_version'] ?? 0),
                ];
                SyncLogger::write($entity, 'RECORD_SAVED', "Successfully saved {$entity} record (web ID #{$webId})");
            }
        }

        if (empty($successfulWebIds)) {
            $detail = $this->lastSaveError !== '' ? " Details: {$this->lastSaveError}" : "";
            $message = "Fetched records for {$entity}, but none were saved.{$detail}";
            SyncLogger::write($entity, 'PULL_SAVE_FAILED', $message, ['fetched_count' => count($items), 'last_error' => $this->lastSaveError]);
            $this->settingsManager->markCompleted($entity, false, $message);
            return ['success' => false, 'message' => $message, 'synced_count' => 0];
        }

        // Step 3: Send ACK back to Website API for successfully saved IDs
        $ackPayload = [
            'entity' => $entity,
            'synced_ids' => $successfulWebIds,
            'synced_records' => $successfulRecords,
        ];

        $ackResult = SyncManager::postToWebsite('/api/erp-sync/acknowledge', $ackPayload);

        // Step 4: Record sync log in ERP sync_logs table
        $logId = $this->logManager->createLog($entity, "batch-" . count($successfulWebIds), 'inbound', $ackPayload);

        if ($ackResult['success']) {
            $ackBody = json_decode((string) $ackResult['body'], true);
            if (! is_array($ackBody) || ($ackBody['status'] ?? '') !== 'success') {
                $this->logManager->markFailed($logId, 'ACK returned an invalid response.', $ackResult['http_code']);
                $message = "Saved records in ERP, but Website ACK response was invalid for {$entity}.";
                $this->settingsManager->markCompleted($entity, false, $message);
                return ['success' => false, 'message' => $message, 'synced_count' => 0];
            }
            $acknowledgedCount = max(0, (int) ($ackBody['acknowledged_count'] ?? 0));
            $this->logManager->markSuccess($logId, $ackResult['body']);
            $message = "Saved " . count($successfulWebIds) . " and acknowledged {$acknowledgedCount} record(s) for {$entity}.";
            SyncLogger::write($entity, 'SYNC_COMPLETE', $message, ['synced_count' => $acknowledgedCount, 'synced_ids' => $successfulWebIds]);
            $this->settingsManager->markCompleted($entity, true, $message);
            return [
                'success' => true,
                'message' => $message,
                'synced_count' => $acknowledgedCount,
            ];
        } else {
            $this->logManager->markFailed($logId, "ACK failed: " . ($ackResult['error'] ?? ''), $ackResult['http_code']);
            $message = "Saved records in ERP, but ACK failed for {$entity}: " . ($ackResult['error'] ?? '');
            SyncLogger::write($entity, 'ACK_FAILED', $message, ['ack_result' => $ackResult]);
            $this->settingsManager->markCompleted($entity, false, $message);
            return [
                'success' => false,
                'message' => $message,
                'synced_count' => count($successfulWebIds),
            ];
        }
    }

    private function saveCustomer(array $item): bool
    {
        $webId = (int) $item['id'];
        $sourceVersion = max(0, (int) ($item['sync_version'] ?? 0));
        if ($this->sourceVersionIsStale('customers', 'website_user_id', $webId, $sourceVersion)) {
            return true;
        }
        $name = trim((string) ($item['name'] ?? ''));
        $email = trim((string) ($item['email'] ?? ''));
        $phone = trim((string) ($item['phone'] ?? ''));
        $userType = in_array(($item['user_type'] ?? ''), ['b2b', 'b2c']) ? $item['user_type'] : 'b2c';
        $companyName = trim((string) ($item['company_name'] ?? ''));
        $gstin = strtoupper(preg_replace('/\s+/', '', trim((string) ($item['gstin'] ?? ''))));
        $gstFormatValid = $gstin !== '' && preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/', $gstin) === 1 ? 1 : 0;
        $creditLimit = (float) ($item['credit_limit'] ?? 0);
        $creditDays = (int) ($item['credit_days'] ?? 0);
        $websiteStatus = strtolower(trim((string) ($item['status'] ?? 'active')));
        $status = in_array($websiteStatus, ['active', 'approved', '1'], true) ? 1 : 0;

        $stmt = $this->conn->prepare(
            "INSERT INTO `customers`
             (`website_user_id`, `source_sync_version`, `name`, `email`, `phone`, `user_type`, `company_name`, `gstin`, `gst_format_valid`, `source_origin`, `credit_limit`, `credit_days`, `status`, `created_at`)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'website', ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
             `name` = VALUES(`name`), `email` = VALUES(`email`), `phone` = VALUES(`phone`),
             `user_type` = VALUES(`user_type`), `company_name` = VALUES(`company_name`),
             `gstin` = VALUES(`gstin`), `gst_format_valid` = VALUES(`gst_format_valid`),
             `source_origin` = 'website',
             `credit_limit` = VALUES(`credit_limit`), `credit_days` = VALUES(`credit_days`),
             `status` = VALUES(`status`), `source_sync_version` = VALUES(`source_sync_version`),
             `updated_at` = NOW()"
        );
        if (! $stmt) {
            return false;
        }
        $stmt->bind_param('iissssssidii', $webId, $sourceVersion, $name, $email, $phone, $userType, $companyName, $gstin, $gstFormatValid, $creditLimit, $creditDays, $status);
        $res = $stmt->execute();
        $stmt->close();
        return $res;
    }

    private function saveMeetingRequest(array $item): bool
    {
        $webId = (int) $item['id'];
        $sourceVersion = max(0, (int) ($item['sync_version'] ?? 0));
        if ($this->sourceVersionIsStale('meeting_requests', 'website_meeting_id', $webId, $sourceVersion)) {
            return true;
        }
        $name = trim((string) ($item['full_name'] ?? ''));
        $email = trim((string) ($item['email'] ?? ''));
        $phone = trim((string) ($item['phone'] ?? ''));
        $orgName = trim((string) ($item['organization_name'] ?? ''));
        $prefDate = trim((string) ($item['preferred_date'] ?? date('Y-m-d')));
        $startTime = trim((string) ($item['start_time'] ?? '09:00:00'));
        $endTime = trim((string) ($item['end_time'] ?? '10:00:00'));
        $status = trim((string) ($item['status'] ?? 'new'));

        $stmt = $this->conn->prepare(
            "INSERT INTO `meeting_requests`
             (`website_meeting_id`, `source_sync_version`, `full_name`, `email`, `phone`, `organization_name`, `preferred_date`, `start_time`, `end_time`, `status`, `created_at`)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
             `full_name` = VALUES(`full_name`), `email` = VALUES(`email`), `phone` = VALUES(`phone`),
             `organization_name` = VALUES(`organization_name`),
             `preferred_date` = VALUES(`preferred_date`), `start_time` = VALUES(`start_time`),
             `end_time` = VALUES(`end_time`), `status` = VALUES(`status`),
             `source_sync_version` = VALUES(`source_sync_version`), `updated_at` = NOW()"
        );
        if (! $stmt) {
            return false;
        }
        $stmt->bind_param('iissssssss', $webId, $sourceVersion, $name, $email, $phone, $orgName, $prefDate, $startTime, $endTime, $status);
        $res = $stmt->execute();
        $stmt->close();
        return $res;
    }

    private function saveQuizLead(array $item): bool
    {
        $webId = (int) $item['id'];
        $sourceVersion = max(0, (int) ($item['sync_version'] ?? 0));
        if ($this->sourceVersionIsStale('quiz_leads', 'website_quiz_response_id', $webId, $sourceVersion)) {
            return true;
        }
        $userType = trim((string) ($item['user_type'] ?? 'common'));
        $firstName = trim((string) ($item['participant_first_name'] ?? ''));
        $lastName = trim((string) ($item['participant_last_name'] ?? ''));
        $email = trim((string) ($item['participant_email'] ?? ''));
        $phone = trim((string) ($item['participant_phone'] ?? ''));
        $profilingData = $item['profiling_data'] ?? null;
        $profilingJson = is_array($profilingData) || is_object($profilingData)
            ? json_encode($profilingData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : trim((string) ($profilingData ?? ''));
        if ($profilingJson === '') {
            $profilingJson = null;
        }
        $totalQ = (int) ($item['total_questions'] ?? 0);
        $totalCorrect = (int) ($item['total_correct_answers'] ?? 0);
        $score = (int) ($item['score_percentage'] ?? 0);
        $coupon = trim((string) ($item['reward_coupon_code'] ?? ''));
        $leadStatus = trim((string) ($item['lead_status'] ?? 'submitted'));
        $submittedRaw = trim((string) ($item['submitted_at'] ?? $item['created_at'] ?? ''));
        $submittedTimestamp = $submittedRaw !== '' ? strtotime($submittedRaw) : false;
        $submittedAt = $submittedTimestamp !== false ? date('Y-m-d H:i:s', $submittedTimestamp) : date('Y-m-d H:i:s');

        $this->conn->begin_transaction();
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO `quiz_leads`
                 (`website_quiz_response_id`, `source_sync_version`, `user_type`, `participant_first_name`, `participant_last_name`,
                  `participant_email`, `participant_phone`, `profiling_data`, `total_questions`, `total_correct_answers`,
                  `score_percentage`, `reward_coupon_code`, `lead_status`, `submitted_at`, `created_at`)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                 ON DUPLICATE KEY UPDATE
                 `user_type` = VALUES(`user_type`),
                 `participant_first_name` = VALUES(`participant_first_name`),
                 `participant_last_name` = VALUES(`participant_last_name`),
                 `participant_email` = VALUES(`participant_email`),
                 `participant_phone` = VALUES(`participant_phone`),
                 `profiling_data` = VALUES(`profiling_data`),
                 `total_questions` = VALUES(`total_questions`),
                 `total_correct_answers` = VALUES(`total_correct_answers`),
                 `score_percentage` = VALUES(`score_percentage`),
                 `reward_coupon_code` = VALUES(`reward_coupon_code`),
                 `lead_status` = VALUES(`lead_status`),
                  `submitted_at` = VALUES(`submitted_at`),
                  `source_sync_version` = VALUES(`source_sync_version`),
                 `updated_at` = NOW()"
            );
            if (!$stmt) {
                throw new RuntimeException('Quiz lead statement could not be prepared.');
            }
            $stmt->bind_param('iissssssiiisss', $webId, $sourceVersion, $userType, $firstName, $lastName, $email, $phone, $profilingJson, $totalQ, $totalCorrect, $score, $coupon, $leadStatus, $submittedAt);
            if (!$stmt->execute()) {
                throw new RuntimeException('Quiz lead could not be saved.');
            }
            $quizLeadId = $stmt->insert_id ?: $this->getExistingQuizLeadIdByWebId($webId);
            $stmt->close();

            if ($quizLeadId > 0 && array_key_exists('answers', $item)) {
                $deleteStmt = $this->conn->prepare("DELETE FROM `quiz_lead_answers` WHERE `quiz_lead_id` = ?");
                if (!$deleteStmt) {
                    throw new RuntimeException('Quiz answer cleanup statement could not be prepared.');
                }
                $deleteStmt->bind_param('i', $quizLeadId);
                $deleteStmt->execute();
                $deleteStmt->close();

                $answers = is_array($item['answers']) ? $item['answers'] : [];
                if ($answers) {
                    $answerStmt = $this->conn->prepare(
                        "INSERT INTO `quiz_lead_answers`
                         (`quiz_lead_id`, `answer_order`, `question_text`, `phase_title`, `question_type`,
                          `selected_option`, `selected_label`, `is_correct`, `created_at`)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"
                    );
                    if (!$answerStmt) {
                        throw new RuntimeException('Quiz answer statement could not be prepared.');
                    }
                    foreach (array_values($answers) as $index => $answer) {
                        $answerOrder = $index + 1;
                        $questionText = trim((string) ($answer['question_text'] ?? 'Question unavailable'));
                        $phaseTitle = trim((string) ($answer['phase_title'] ?? ''));
                        $questionType = trim((string) ($answer['question_type'] ?? ''));
                        $selectedOption = trim((string) ($answer['selected_option'] ?? ''));
                        $selectedLabel = trim((string) ($answer['selected_label'] ?? ''));
                        $isCorrect = !empty($answer['is_correct']) ? 1 : 0;
                        $answerStmt->bind_param('iisssssi', $quizLeadId, $answerOrder, $questionText, $phaseTitle, $questionType, $selectedOption, $selectedLabel, $isCorrect);
                        if (!$answerStmt->execute()) {
                            throw new RuntimeException('Quiz answer could not be saved.');
                        }
                    }
                    $answerStmt->close();
                }
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            $this->conn->rollback();
            return false;
        }
    }

    private function saveProformaInvoice(array $item): bool
    {
        $this->conn->begin_transaction();
        try {
            $webId = (int) ($item['id'] ?? 0);
            $header = $this->documentHeaderValues($item, 'pi');
            $savedHeader = $this->upsertDocumentHeader('pi_requests', 'website_pi_id', $webId, $header);
            if ($savedHeader['applied'] && array_key_exists('items', $item)) {
                $this->replaceDocumentItems(
                    'pi_request_items',
                    'pi_request_id',
                    (int) $savedHeader['id'],
                    is_array($item['items']) ? $item['items'] : []
                );
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            $this->conn->rollback();
            $this->lastSaveError = $e->getMessage();
            SyncLogger::write('pi', 'SAVE_ERROR', "Failed to save PI record (web ID #" . ($item['id'] ?? 0) . "): " . $e->getMessage(), ['item' => $item, 'error' => $e->getMessage()]);
            error_log("Failed to save PI record (web ID " . ($item['id'] ?? 0) . "): " . $e->getMessage());
            return false;
        }
    }

    private function saveQuotation(array $item): bool
    {
        $this->conn->begin_transaction();
        try {
            $webId = (int) ($item['id'] ?? 0);
            $header = $this->documentHeaderValues($item, 'quotation');
            $savedHeader = $this->upsertDocumentHeader('quotation_requests', 'website_quotation_id', $webId, $header);
            if ($savedHeader['applied'] && array_key_exists('items', $item)) {
                $this->replaceDocumentItems(
                    'quotation_request_items',
                    'quotation_request_id',
                    (int) $savedHeader['id'],
                    is_array($item['items']) ? $item['items'] : []
                );
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            $this->conn->rollback();
            $this->lastSaveError = $e->getMessage();
            SyncLogger::write('quotations', 'SAVE_ERROR', "Failed to save Quotation record (web ID #" . ($item['id'] ?? 0) . "): " . $e->getMessage(), ['item' => $item, 'error' => $e->getMessage()]);
            error_log("Failed to save Quotation record (web ID " . ($item['id'] ?? 0) . "): " . $e->getMessage());
            return false;
        }
    }

    /**
     * Build a complete, immutable Website document snapshot without changing
     * ownership: these values can only enter ERP through the pull handler.
     */
    private function documentHeaderValues(array $item, string $documentType): array
    {
        $webId = (int) ($item['id'] ?? 0);
        $values = [
            'source_sync_version' => ['i', (int) ($item['sync_version'] ?? 0)],
            'requester_type' => ['s', trim((string) ($item['requester_type'] ?? 'guest'))],
            'created_by_user_id' => ['i', $this->nullableInteger($item['created_by_user_id'] ?? null)],
            'created_by_name' => ['s', $this->nullableString($item['created_by_name'] ?? null)],
            'created_by_email' => ['s', $this->nullableString($item['created_by_email'] ?? null)],
            'owner_user_id' => ['i', $this->nullableInteger($item['owner_user_id'] ?? null)],
            'owner_user_name' => ['s', $this->nullableString($item['owner_user_name'] ?? null)],
            'owner_user_email' => ['s', $this->nullableString($item['owner_user_email'] ?? null)],
            'owner_company_id' => ['i', $this->nullableInteger($item['owner_company_id'] ?? null)],
            'owner_company_name' => ['s', $this->nullableString($item['owner_company_name'] ?? null)],
            'owner_company_gstin' => ['s', $this->nullableString($item['owner_company_gstin'] ?? null)],
            'target_type' => ['s', $this->nullableString($item['target_type'] ?? null)],
            'target_name' => ['s', $this->nullableString($item['target_name'] ?? null)],
            'target_email' => ['s', $this->nullableString($item['target_email'] ?? null)],
            'target_phone' => ['s', $this->nullableString($item['target_phone'] ?? null)],
            'target_company_id' => ['i', $this->nullableInteger($item['target_company_id'] ?? null)],
            'target_company_name' => ['s', $this->nullableString($item['target_company_name'] ?? null)],
            'target_company_gstin' => ['s', $this->nullableString($item['target_company_gstin'] ?? null)],
            'billing_address' => ['s', $this->nullableString($item['billing_address'] ?? null)],
            'shipping_address' => ['s', $this->nullableString($item['shipping_address'] ?? null)],
            'status' => ['s', trim((string) ($item['status'] ?? ($documentType === 'pi' ? 'draft' : 'generated')))],
            'currency' => ['s', trim((string) ($item['currency'] ?? 'INR'))],
            'subtotal' => ['d', (float) ($item['subtotal'] ?? 0)],
            'tax_amount' => ['d', (float) ($item['tax_amount'] ?? 0)],
            'discount_amount' => ['d', (float) ($item['discount_amount'] ?? 0)],
            'price_after_gst' => ['d', (float) ($item['price_after_gst'] ?? 0)],
            'total_amount' => ['d', (float) ($item['total_amount'] ?? 0)],
            'customer_gstin' => ['s', $this->nullableString($item['customer_gstin'] ?? null)],
            'seller_state_code' => ['s', $this->nullableString($item['seller_state_code'] ?? null)],
            'seller_gstin' => ['s', $this->nullableString($item['seller_gstin'] ?? null)],
            'freight_charges' => ['d', (float) ($item['freight_charges'] ?? 0)],
            'freight_tax_amount' => ['d', (float) ($item['freight_tax_amount'] ?? 0)],
            'rounding_amount' => ['d', (float) ($item['rounding_amount'] ?? 0)],
            'notes' => ['s', $this->nullableString($item['notes'] ?? null)],
            'guest_session_id' => ['s', $this->nullableString($item['guest_session_id'] ?? null)],
            'source_created_at' => ['s', $this->databaseDateTime($item['created_at'] ?? null)],
            'source_updated_at' => ['s', $this->databaseDateTime($item['updated_at'] ?? null)],
            'snapshot_payload' => ['s', json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
        ];

        if ($documentType === 'pi') {
            return array_merge([
                'website_pi_id' => ['i', $webId],
                'pi_number' => ['s', trim((string) ($item['pi_number'] ?? 'PI-WEB-' . $webId))],
                'pi_date' => ['s', $this->nullableString($item['pi_date'] ?? null)],
            ], $values, [
                'terms' => ['s', $this->nullableString($item['terms'] ?? null)],
            ]);
        }

        return array_merge([
            'website_quotation_id' => ['i', $webId],
            'quotation_number' => ['s', trim((string) ($item['quotation_number'] ?? 'QT-WEB-' . $webId))],
        ], $values, [
            'terms' => ['s', $this->nullableString($item['terms'] ?? null)],
        ]);
    }

    /** @return array{id:int,applied:bool} */
    private function upsertDocumentHeader(string $table, string $websiteColumn, int $webId, array $values): array
    {
        $existingStmt = $this->conn->prepare(
            "SELECT `id`, `source_sync_version` FROM `{$table}` WHERE `{$websiteColumn}` = ? LIMIT 1 FOR UPDATE"
        );
        if (! $existingStmt) {
            throw new RuntimeException('Document snapshot lookup could not be prepared. Apply the completeness migration first.');
        }
        $existingStmt->bind_param('i', $webId);
        $existingStmt->execute();
        $existing = $existingStmt->get_result()->fetch_assoc();
        $existingStmt->close();

        $incomingVersion = (int) ($values['source_sync_version'][1] ?? 0);
        if ($existing && $incomingVersion < (int) ($existing['source_sync_version'] ?? 0)) {
            return ['id' => (int) $existing['id'], 'applied' => false];
        }

        $columns = array_keys($values);
        $quotedColumns = array_map(static fn (string $column): string => "`{$column}`", $columns);
        $placeholders = implode(', ', array_fill(0, count($columns), '?'));
        $updates = array_map(
            static fn (string $column): string => "`{$column}` = VALUES(`{$column}`)",
            array_values(array_filter($columns, static fn (string $column): bool => $column !== $websiteColumn))
        );
        $sql = "INSERT INTO `{$table}` (" . implode(', ', $quotedColumns) . ", `created_at`)
            VALUES ({$placeholders}, NOW())
            ON DUPLICATE KEY UPDATE " . implode(', ', $updates) . ", `updated_at` = NOW()";
        $stmt = $this->conn->prepare($sql);
        if (! $stmt) {
            throw new RuntimeException('Document snapshot statement could not be prepared: ' . $this->conn->error);
        }
        $types = implode('', array_map(static fn (array $value): string => $value[0], $values));
        $bindValues = array_values(array_map(static fn (array $value) => $value[1], $values));
        $stmt->bind_param($types, ...$bindValues);
        if (! $stmt->execute()) {
            throw new RuntimeException('Document snapshot could not be saved: ' . $stmt->error);
        }
        $documentId = (int) ($stmt->insert_id ?: ($existing['id'] ?? 0));
        $stmt->close();
        if ($documentId <= 0) {
            throw new RuntimeException('Document snapshot identifier could not be resolved.');
        }

        return ['id' => $documentId, 'applied' => true];
    }

    private function replaceDocumentItems(string $table, string $parentColumn, int $documentId, array $items): void
    {
        $deleteStmt = $this->conn->prepare("DELETE FROM `{$table}` WHERE `{$parentColumn}` = ?");
        if (! $deleteStmt) {
            throw new RuntimeException('Document item cleanup statement could not be prepared.');
        }
        $deleteStmt->bind_param('i', $documentId);
        if (! $deleteStmt->execute()) {
            throw new RuntimeException('Document items could not be replaced.');
        }
        $deleteStmt->close();

        foreach ($items as $item) {
            if (! is_array($item)) {
                continue;
            }
            $quantity = max(1, (int) ($item['quantity'] ?? 1));
            $unitPrice = (float) ($item['unit_price'] ?? 0);
            $values = [
                $parentColumn => ['i', $documentId],
                'website_item_id' => ['i', $this->nullableInteger($item['id'] ?? null)],
                'product_id' => ['i', $this->nullableInteger($item['product_id'] ?? null)],
                'product_variant_id' => ['i', $this->nullableInteger($item['product_variant_id'] ?? null)],
                'product_name' => ['s', trim((string) ($item['product_name'] ?? 'Item'))],
                'sku' => ['s', $this->nullableString($item['sku'] ?? null)],
                'variant_name' => ['s', $this->nullableString($item['variant_name'] ?? null)],
                'price_type' => ['s', $this->nullableString($item['price_type'] ?? null)],
                'currency' => ['s', $this->nullableString($item['currency'] ?? null)],
                'quantity' => ['i', $quantity],
                'unit_price' => ['d', $unitPrice],
                'gst_rate' => ['d', (float) ($item['gst_rate'] ?? 0)],
                'unit_tax_amount' => ['d', (float) ($item['unit_tax_amount'] ?? 0)],
                'unit_price_after_gst' => ['d', (float) ($item['unit_price_after_gst'] ?? 0)],
                'discount_percent' => ['d', (float) ($item['discount_percent'] ?? 0)],
                'unit_discount_amount' => ['d', (float) ($item['unit_discount_amount'] ?? 0)],
                'line_subtotal' => ['d', (float) ($item['line_subtotal'] ?? ($quantity * $unitPrice))],
                'line_tax_amount' => ['d', (float) ($item['line_tax_amount'] ?? 0)],
                'line_price_after_gst' => ['d', (float) ($item['line_price_after_gst'] ?? 0)],
                'line_discount_amount' => ['d', (float) ($item['line_discount_amount'] ?? 0)],
                'line_total' => ['d', (float) ($item['line_total'] ?? ($quantity * $unitPrice))],
            ];
            $columns = array_keys($values);
            $sql = "INSERT INTO `{$table}` (" . implode(', ', array_map(static fn (string $column): string => "`{$column}`", $columns)) . ", `created_at`)
                VALUES (" . implode(', ', array_fill(0, count($columns), '?')) . ", NOW())";
            $stmt = $this->conn->prepare($sql);
            if (! $stmt) {
                throw new RuntimeException('Document item statement could not be prepared.');
            }
            $types = implode('', array_map(static fn (array $value): string => $value[0], $values));
            $bindValues = array_values(array_map(static fn (array $value) => $value[1], $values));
            $stmt->bind_param($types, ...$bindValues);
            if (! $stmt->execute()) {
                throw new RuntimeException('Document item could not be saved: ' . $stmt->error);
            }
            $stmt->close();
        }
    }

    private function nullableInteger($value): ?int
    {
        return $value === null || $value === '' ? null : (int) $value;
    }

    private function nullableString($value): ?string
    {
        if ($value === null) {
            return null;
        }
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }

    private function databaseDateTime($value): ?string
    {
        $value = $this->nullableString($value);
        if ($value === null) {
            return null;
        }
        try {
            return (new DateTimeImmutable($value))->format('Y-m-d H:i:s');
        } catch (Throwable $e) {
            return null;
        }
    }

    private function getExistingQuizLeadIdByWebId(int $webId): int
    {
        $stmt = $this->conn->prepare("SELECT `id` FROM `quiz_leads` WHERE `website_quiz_response_id` = ? LIMIT 1");
        $stmt->bind_param('i', $webId);
        $stmt->execute();
        $id = (int) ($stmt->get_result()->fetch_assoc()['id'] ?? 0);
        $stmt->close();
        return $id;
    }

    private function sourceVersionIsStale(
        string $table,
        string $websiteIdColumn,
        int $websiteId,
        int $incomingVersion
    ): bool {
        $stmt = $this->conn->prepare(
            "SELECT `source_sync_version` FROM `{$table}`
             WHERE `{$websiteIdColumn}` = ? LIMIT 1"
        );
        if (! $stmt) {
            return false;
        }
        $stmt->bind_param('i', $websiteId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row && (int) ($row['source_sync_version'] ?? 0) > $incomingVersion;
    }

    private function getExistingPiIdByWebId(int $webId): int
    {
        $stmt = $this->conn->prepare("SELECT `id` FROM `pi_requests` WHERE `website_pi_id` = ? LIMIT 1");
        $stmt->bind_param('i', $webId);
        $stmt->execute();
        $id = (int) ($stmt->get_result()->fetch_assoc()['id'] ?? 0);
        $stmt->close();
        return $id;
    }

    private function getExistingQuoteIdByWebId(int $webId): int
    {
        $stmt = $this->conn->prepare("SELECT `id` FROM `quotation_requests` WHERE `website_quotation_id` = ? LIMIT 1");
        $stmt->bind_param('i', $webId);
        $stmt->execute();
        $id = (int) ($stmt->get_result()->fetch_assoc()['id'] ?? 0);
        $stmt->close();
        return $id;
    }
}
