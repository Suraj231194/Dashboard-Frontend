<?php

/**
 * Processes ERP stock rows marked pending by the additive live_stock triggers.
 *
 * Suggested schedule:
 *   * * * * * php /path/to/admin/sync/cron_sync_inventory.php
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../constant.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/SyncSettingsManager.php';
require_once __DIR__ . '/InventorySyncHandler.php';
require_once __DIR__ . '/CronLock.php';

$cronLock = CronLock::acquire('sync-inventory');
if ($cronLock === null) {
    exit(0);
}

$settingsManager = new SyncSettingsManager($conn);
if (! $settingsManager->isReady()) {
    echo '[' . date('Y-m-d H:i:s') . "] Sync migrations are not ready. Inventory cycle skipped.\n";
    exit(0);
}
if (! $settingsManager->isEnabled('inventory')) {
    echo '[' . date('Y-m-d H:i:s') . "] Inventory sync is disabled. Cycle skipped.\n";
    exit(0);
}

$result = $conn->query(
    "SELECT DISTINCT ls.`product_id`
     FROM `live_stock` ls
     INNER JOIN `products` p
       ON p.`id` = ls.`product_id`
      AND p.`website_sync` = 1
      AND p.`deleted_at` IS NULL
     INNER JOIN `product_categories` c
       ON c.`id` = p.`category_id`
      AND c.`website_sync` = 1
     WHERE ls.`sync_pending` = 1 AND ls.`deleted_at` IS NULL
     ORDER BY ls.`product_id` ASC
     LIMIT 100"
);

if (! $result || $result->num_rows === 0) {
    echo '[' . date('Y-m-d H:i:s') . "] No pending ERP inventory changes.\n";
    exit(0);
}

$handler = new InventorySyncHandler($conn);
$processed = 0;
$failed = 0;

while ($row = $result->fetch_assoc()) {
    $productId = (int) $row['product_id'];
    $syncResult = $handler->pushProductStockToWebsite($productId);
    if (! empty($syncResult['success'])) {
        $processed++;
    } else {
        $failed++;
    }
    echo "[Product {$productId}] " . ($syncResult['message'] ?? 'No result message.') . "\n";
}
$result->free();

echo '[' . date('Y-m-d H:i:s') . "] Inventory cycle complete: {$processed} processed, {$failed} failed.\n";
