<?php

declare(strict_types=1);

/**
 * SyncLogger — Daily File Logging Engine for ERP Sync System
 *
 * Generates per-day, per-functionality log files inside the admin/syncLogs directory.
 * Example file paths:
 *   - admin/syncLogs/quotations_2026-08-09.log
 *   - admin/syncLogs/pi_2026-08-09.log
 *   - admin/syncLogs/orders_2026-08-09.log
 *   - admin/syncLogs/inventory_2026-08-09.log
 *   - admin/syncLogs/users_2026-08-09.log
 *   - admin/syncLogs/meetings_2026-08-09.log
 *   - admin/syncLogs/quiz_2026-08-09.log
 *   - admin/syncLogs/system_2026-08-09.log
 */
class SyncLogger
{
    /**
     * Write an entry into daily per-functionality sync log file.
     *
     * @param string $functionality e.g. 'quotations', 'pi', 'orders', 'inventory', 'users', 'meetings', 'quiz', 'system'
     * @param string $eventType     e.g. 'PULL_START', 'RECORD_SAVE_SUCCESS', 'RECORD_SAVE_ERROR', 'HTTP_ERROR', 'ACK_SUCCESS'
     * @param string $message       Human-readable summary
     * @param mixed  $extraDetails  Optional payload, item data, or error exception details
     */
    public static function write(string $functionality, string $eventType, string $message, $extraDetails = null): void
    {
        $logFolder = dirname(__DIR__) . '/syncLogs';
        if (!is_dir($logFolder)) {
            @mkdir($logFolder, 0777, true);
        }

        $cleanFunctionality = strtolower(trim((string) preg_replace('/[^a-zA-Z0-9_-]/', '', $functionality)));
        if ($cleanFunctionality === '') {
            $cleanFunctionality = 'system';
        }

        $dateStr = date('Y-m-d');
        $logFile = $logFolder . '/' . $cleanFunctionality . '_' . $dateStr . '.log';
        $currentTime = date('Y-m-d H:i:s');

        $entry = "[" . $currentTime . "] [" . strtoupper($eventType) . "] " . $message . PHP_EOL;

        if ($extraDetails !== null) {
            if (is_array($extraDetails) || is_object($extraDetails)) {
                $entry .= json_encode($extraDetails, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL;
            } else {
                $entry .= (string) $extraDetails . PHP_EOL;
            }
        }

        @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    }
}

if (!function_exists('writeSyncLog')) {
    function writeSyncLog(string $functionality, string $eventType, string $message, $extraDetails = null): void
    {
        SyncLogger::write($functionality, $eventType, $message, $extraDetails);
    }
}
