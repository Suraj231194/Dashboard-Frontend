<?php

/**
 * Background Cron Pull Worker for Remaining Sync Entities.
 *
 *   Every 5 minutes: php /path/to/admin/sync/cron_sync_pull.php

 *
 * Executes Pull + ACK logic for enabled entities:
 * 1. users
 * 2. meetings
 * 3. quiz
 * 4. pi
 * 5. quotations
 *
 * Location: admin/sync/cron_sync_pull.php
 */

require_once(__DIR__ . '/../db.php');
require_once(__DIR__ . '/../constant.php');
require_once(__DIR__ . '/../functions.php');
require_once(__DIR__ . '/SyncManager.php');
require_once(__DIR__ . '/SyncLogManager.php');
require_once(__DIR__ . '/BulkEntitySyncHandler.php');
require_once(__DIR__ . '/CronLock.php');

$cronLock = CronLock::acquire('sync-pull');
if ($cronLock === null) {
    exit(0);
}

$handler = new BulkEntitySyncHandler($conn);
$entities = ['users', 'meetings', 'quiz', 'pi', 'quotations'];

echo "[" . date('Y-m-d H:i:s') . "] Starting background Pull + ACK sync cycle for " . count($entities) . " entities...\n";

foreach ($entities as $entity) {
    $batchCount = 100;
    for ($batch = 1; $batch <= 10 && $batchCount === 100; $batch++) {
        echo "  [Entity: {$entity}] Executing Pull + ACK batch {$batch}...\n";
        $result = $handler->pullAndSyncEntity($entity);
        $status = $result['success'] ? 'SUCCESS' : 'FAILED';
        $batchCount = $result['success'] ? (int) ($result['synced_count'] ?? 0) : 0;
        echo "  [Entity: {$entity}] Result: {$status} — {$result['message']}\n";
    }
}

echo "[" . date('Y-m-d H:i:s') . "] Pull + ACK sync cycle complete.\n";
