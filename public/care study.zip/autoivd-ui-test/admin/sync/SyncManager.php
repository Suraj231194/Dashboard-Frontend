<?php

/**
 * SyncManager — Central sync HTTP client & utility for the ERP sync module.
 *
 * Provides reusable static methods for sending HTTP requests to the
 * Biogenix Website API, handling authentication, timeouts, and error wrapping.
 *
 * This class is shared across all sync handlers (Orders, Inventory, Users, etc.).
 *
 * Location: admin/sync/SyncManager.php
 */
require_once(__DIR__ . '/SyncLogger.php');

class SyncManager
{
    /**
     * Send an authenticated GET request to a Bio sync endpoint.
     */
    public static function getFromWebsite(string $endpoint): array
    {
        $baseUrl = self::getWebsiteBaseUrl();
        $token = self::getWebsiteSyncToken();

        if (empty($baseUrl) || empty($token)) {
            return [
                'success' => false,
                'http_code' => 0,
                'body' => '',
                'error' => 'Website sync URL or token not configured in .env',
            ];
        }

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => rtrim($baseUrl, '/') . $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Authorization: Bearer ' . $token,
            ],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $responseBody = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return [
                'success' => false,
                'http_code' => $httpCode,
                'body' => (string) $responseBody,
                'error' => 'cURL error: ' . $curlError,
            ];
        }

        $isSuccess = $httpCode >= 200 && $httpCode < 300;
        return [
            'success' => $isSuccess,
            'http_code' => $httpCode,
            'body' => (string) $responseBody,
            'error' => $isSuccess ? null : "HTTP {$httpCode}: " . substr((string) $responseBody, 0, 500),
        ];
    }

    /**
     * Send an HTTP POST request to the Biogenix Website API.
     *
     * @param string $endpoint  Relative endpoint path (e.g. '/api/erp-sync/orders/status-update')
     * @param array  $payload   JSON body data
     * @return array  ['success' => bool, 'http_code' => int, 'body' => string, 'error' => string|null]
     */
    public static function postToWebsite(string $endpoint, array $payload): array
    {
        $baseUrl = self::getWebsiteBaseUrl();
        $token = self::getWebsiteSyncToken();

        if (empty($baseUrl) || empty($token)) {
            return [
                'success' => false,
                'http_code' => 0,
                'body' => '',
                'error' => 'Website sync URL or token not configured in .env',
            ];
        }

        $url = rtrim($baseUrl, '/') . $endpoint;
        $jsonPayload = json_encode($payload, JSON_UNESCAPED_UNICODE);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $jsonPayload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,         // 15-second timeout to avoid blocking ERP UI
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: Bearer ' . $token,
            ],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        $responseBody = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return [
                'success' => false,
                'http_code' => $httpCode,
                'body' => (string) $responseBody,
                'error' => 'cURL error: ' . $curlError,
            ];
        }

        $isSuccess = $httpCode >= 200 && $httpCode < 300;

        return [
            'success' => $isSuccess,
            'http_code' => $httpCode,
            'body' => (string) $responseBody,
            'error' => $isSuccess ? null : "HTTP {$httpCode}: " . substr((string) $responseBody, 0, 500),
        ];
    }

    /**
     * Get the Biogenix website base URL from .env configuration.
     */
    public static function getWebsiteBaseUrl(): string
    {
        return self::getConfigurationValue('WEBSITE_SYNC_BASE_URL');
    }

    /**
     * Get the shared sync token used when ERP calls the Website API.
     */
    public static function getWebsiteSyncToken(): string
    {
        return self::getConfigurationValue('WEBSITE_SYNC_TOKEN');
    }

    /**
     * The ERP bootstrap loads .env into constants and $GLOBALS['env'] rather
     * than populating $_ENV. Check every supported source without logging the
     * secret value.
     */
    private static function getConfigurationValue(string $key): string
    {
        if (defined($key)) {
            return trim((string) constant($key));
        }

        if (isset($GLOBALS['env']) && is_array($GLOBALS['env']) && array_key_exists($key, $GLOBALS['env'])) {
            return trim((string) $GLOBALS['env'][$key]);
        }

        if (array_key_exists($key, $_ENV)) {
            return trim((string) $_ENV[$key]);
        }

        if (array_key_exists($key, $_SERVER)) {
            return trim((string) $_SERVER[$key]);
        }

        $value = getenv($key);
        return $value === false ? '' : trim((string) $value);
    }



    /**
     * Calculate the next retry delay (in seconds) based on the current attempt number.
     * Schedule: 60s, 120s, 240s, 480s, 960s (1m, 2m, 4m, 8m, 16m)
     */
    public static function getRetryDelay(int $attemptNumber): int
    {
        $delays = [60, 120, 240, 480, 960];
        $index = min($attemptNumber - 1, count($delays) - 1);
        return $delays[max(0, $index)];
    }

    /**
     * Maximum number of automatic retry attempts before escalating to manual retry.
     */
    public static function getMaxRetries(): int
    {
        return 5;
    }
}
