<?php

declare(strict_types=1);

/**
 * Optional append-only inventory audit plug-in.
 *
 * It deliberately contains every failure so audit storage can never roll back
 * or block the inventory operation which called it.
 */
final class InventoryTransactionAudit
{
    private static ?bool $tableAvailable = null;

    public static function record(mysqli $conn, float $quantity, array $context = []): bool
    {
        try {
            if (! is_finite($quantity) || ! self::tableExists($conn)) {
                return false;
            }

            $metadata = $context['metadata'] ?? null;
            if (is_array($metadata) || is_object($metadata)) {
                $metadata = json_encode(
                    $metadata,
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR
                );
            } elseif ($metadata !== null) {
                $metadata = (string) $metadata;
            }

            $quantityValue = $quantity;
            $actionName = self::nullableString($context['action_name'] ?? null, 100);
            $productId = self::nullableInt($context['product_id'] ?? null);
            $liveStockId = self::nullableInt($context['live_stock_id'] ?? null);
            $warehouseId = self::nullableInt($context['warehouse_id'] ?? null);
            $availableAfter = self::nullableFloat($context['quantity_available_after'] ?? null);
            $reservedAfter = self::nullableFloat($context['reserved_quantity_after'] ?? null);
            $unreservedAfter = self::nullableFloat($context['unreserved_quantity_after'] ?? null);
            $sourceType = self::nullableString($context['source_type'] ?? null, 100);
            $sourceId = self::nullableInt($context['source_id'] ?? null);
            $referenceKey = self::nullableString($context['reference_key'] ?? null, 255);
            $coaNumber = self::nullableString($context['coa_number'] ?? null, 255);
            $batchNumber = self::nullableString($context['batch_number'] ?? null, 255);
            $mfgDate = self::nullableDate($context['mfg_date'] ?? null);
            $expiryDate = self::nullableDate($context['expiry_date'] ?? null);
            $performedBy = self::nullableInt($context['performed_by'] ?? null);
            $requestId = self::nullableString($context['request_id'] ?? null, 100);
            $notes = self::nullableString($context['notes'] ?? null);
            $metadataJson = self::nullableString($metadata);
            $occurredAt = self::nullableDateTime($context['occurred_at'] ?? null) ?? date('Y-m-d H:i:s');

            $stmt = $conn->prepare(
                'INSERT INTO inventory_transaction_audit
                 (quantity, action_name, product_id, live_stock_id, warehouse_id,
                  quantity_available_after, reserved_quantity_after, unreserved_quantity_after,
                  source_type, source_id, reference_key, coa_number, batch_number,
                  mfg_date, expiry_date, performed_by, request_id, notes, metadata_json, occurred_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            if (! $stmt) {
                return false;
            }

            $stmt->bind_param(
                'dsiiidddsisssssissss',
                $quantityValue,
                $actionName,
                $productId,
                $liveStockId,
                $warehouseId,
                $availableAfter,
                $reservedAfter,
                $unreservedAfter,
                $sourceType,
                $sourceId,
                $referenceKey,
                $coaNumber,
                $batchNumber,
                $mfgDate,
                $expiryDate,
                $performedBy,
                $requestId,
                $notes,
                $metadataJson,
                $occurredAt
            );
            $success = $stmt->execute();
            $stmt->close();
            return $success;
        } catch (Throwable $exception) {
            error_log('Optional inventory transaction audit failed: ' . $exception->getMessage());
            return false;
        }
    }

    private static function tableExists(mysqli $conn): bool
    {
        if (self::$tableAvailable !== null) {
            return self::$tableAvailable;
        }
        $result = $conn->query("SHOW TABLES LIKE 'inventory_transaction_audit'");
        self::$tableAvailable = $result instanceof mysqli_result && $result->num_rows > 0;
        if ($result instanceof mysqli_result) {
            $result->free();
        }
        return self::$tableAvailable;
    }

    private static function nullableInt(mixed $value): ?int
    {
        return is_numeric($value) ? (int) $value : null;
    }

    private static function nullableFloat(mixed $value): ?float
    {
        if (! is_numeric($value)) {
            return null;
        }
        $number = (float) $value;
        return is_finite($number) ? $number : null;
    }

    private static function nullableString(mixed $value, ?int $maxLength = null): ?string
    {
        if ($value === null || is_array($value) || is_object($value)) {
            return null;
        }
        $text = trim((string) $value);
        if ($text === '') {
            return null;
        }
        return $maxLength === null ? $text : mb_substr($text, 0, $maxLength);
    }

    private static function nullableDate(mixed $value): ?string
    {
        $timestamp = $value ? strtotime((string) $value) : false;
        return $timestamp === false ? null : date('Y-m-d', $timestamp);
    }

    private static function nullableDateTime(mixed $value): ?string
    {
        $timestamp = $value ? strtotime((string) $value) : false;
        return $timestamp === false ? null : date('Y-m-d H:i:s', $timestamp);
    }
}
