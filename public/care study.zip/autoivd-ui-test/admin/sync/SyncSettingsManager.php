<?php

/**
 * Read/write access to the ERP sync control plane.
 *
 * The manager deliberately fails closed: until the additive sync migration is
 * applied and a module is explicitly enabled, no new sync traffic is allowed.
 */
class SyncSettingsManager
{
    private $conn;
    private array $tableCache = [];

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public static function definitions(): array
    {
        return [
            'orders' => ['display_name' => 'Orders', 'direction' => 'bidirectional'],
            'inventory' => ['display_name' => 'Inventory', 'direction' => 'erp_to_website'],
            'users' => ['display_name' => 'Customer Management', 'direction' => 'website_to_erp'],
            'meetings' => ['display_name' => 'Meeting Requests', 'direction' => 'website_to_erp'],
            'quiz' => ['display_name' => 'Quiz Activity Feed', 'direction' => 'website_to_erp'],
            'pi' => ['display_name' => 'PI Requests', 'direction' => 'website_to_erp'],
            'quotations' => ['display_name' => 'Quotation Requests', 'direction' => 'website_to_erp'],
        ];
    }

    public function hasTable(string $table): bool
    {
        if (array_key_exists($table, $this->tableCache)) {
            return $this->tableCache[$table];
        }

        $stmt = $this->conn->prepare(
            "SELECT 1
             FROM `information_schema`.`tables`
             WHERE `table_schema` = DATABASE() AND `table_name` = ?
             LIMIT 1"
        );
        if (! $stmt) {
            $this->tableCache[$table] = false;
            return false;
        }
        $stmt->bind_param('s', $table);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        $this->tableCache[$table] = $exists;

        return $exists;
    }

    public function isReady(): bool
    {
        return $this->hasTable('sync_settings') && $this->hasTable('sync_logs');
    }

    public function isEnabled(string $entityType): bool
    {
        if (! isset(self::definitions()[$entityType]) || ! $this->hasTable('sync_settings')) {
            return false;
        }

        $stmt = $this->conn->prepare(
            "SELECT `is_enabled` FROM `sync_settings` WHERE `entity_type` = ? LIMIT 1"
        );
        if (! $stmt) {
            return false;
        }
        $stmt->bind_param('s', $entityType);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return (int) ($row['is_enabled'] ?? 0) === 1;
    }

    public function setEnabled(string $entityType, bool $enabled, ?int $updatedBy = null): array
    {
        $definition = self::definitions()[$entityType] ?? null;
        if (! $definition) {
            return ['success' => false, 'message' => 'Unknown sync module.'];
        }
        if (! $this->hasTable('sync_settings')) {
            return ['success' => false, 'message' => 'Sync migrations have not been applied.'];
        }

        $enabledValue = $enabled ? 1 : 0;
        $stmt = $this->conn->prepare(
            "INSERT INTO `sync_settings`
                (`entity_type`, `display_name`, `direction`, `is_enabled`, `updated_by`, `created_at`)
             VALUES (?, ?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
                `display_name` = VALUES(`display_name`),
                `direction` = VALUES(`direction`),
                `is_enabled` = VALUES(`is_enabled`),
                `updated_by` = VALUES(`updated_by`),
                `updated_at` = NOW()"
        );
        if (! $stmt) {
            return ['success' => false, 'message' => 'Unable to prepare the sync setting update.'];
        }
        $displayName = $definition['display_name'];
        $direction = $definition['direction'];
        $stmt->bind_param(
            'sssii',
            $entityType,
            $displayName,
            $direction,
            $enabledValue,
            $updatedBy
        );
        $success = $stmt->execute();
        $message = $success
            ? $definition['display_name'] . ' sync ' . ($enabled ? 'enabled.' : 'disabled.')
            : 'Unable to update the sync module.';
        $stmt->close();

        return ['success' => $success, 'message' => $message];
    }

    public function markStarted(string $entityType): void
    {
        if (! $this->hasTable('sync_settings')) {
            return;
        }
        $stmt = $this->conn->prepare(
            "UPDATE `sync_settings`
             SET `last_started_at` = NOW(), `last_status` = 'running', `last_message` = NULL
             WHERE `entity_type` = ?"
        );
        if ($stmt) {
            $stmt->bind_param('s', $entityType);
            $stmt->execute();
            $stmt->close();
        }
    }

    public function markCompleted(string $entityType, bool $success, string $message): void
    {
        if (! $this->hasTable('sync_settings')) {
            return;
        }
        $status = $success ? 'success' : 'failed';
        $message = substr($message, 0, 500);
        $stmt = $this->conn->prepare(
            "UPDATE `sync_settings`
             SET `last_completed_at` = NOW(), `last_status` = ?, `last_message` = ?
             WHERE `entity_type` = ?"
        );
        if ($stmt) {
            $stmt->bind_param('sss', $status, $message, $entityType);
            $stmt->execute();
            $stmt->close();
        }
    }

    public function getModules(): array
    {
        $modules = [];
        foreach (self::definitions() as $entityType => $definition) {
            $modules[$entityType] = [
                'entity_type' => $entityType,
                'display_name' => $definition['display_name'],
                'direction' => $definition['direction'],
                'is_enabled' => 0,
                'last_started_at' => null,
                'last_completed_at' => null,
                'last_status' => null,
                'last_message' => null,
                'success_count' => 0,
                'failed_count' => 0,
                'pending_count' => 0,
            ];
        }

        if ($this->hasTable('sync_settings')) {
            $result = $this->conn->query("SELECT * FROM `sync_settings`");
            if ($result instanceof mysqli_result) {
                while ($row = $result->fetch_assoc()) {
                    $entityType = $row['entity_type'];
                    if (isset($modules[$entityType])) {
                        $modules[$entityType] = array_merge($modules[$entityType], $row);
                    }
                }
                $result->free();
            }
        }

        if ($this->hasTable('sync_logs')) {
            $result = $this->conn->query(
                "SELECT `entity_type`,
                        SUM(`status` = 'success') AS `success_count`,
                        SUM(`status` = 'failed') AS `failed_count`,
                        SUM(`status` = 'pending') AS `pending_count`
                 FROM `sync_logs`
                 GROUP BY `entity_type`"
            );
            if ($result instanceof mysqli_result) {
                while ($row = $result->fetch_assoc()) {
                    $entityType = $row['entity_type'];
                    if (isset($modules[$entityType])) {
                        $modules[$entityType]['success_count'] = (int) $row['success_count'];
                        $modules[$entityType]['failed_count'] = (int) $row['failed_count'];
                        $modules[$entityType]['pending_count'] = (int) $row['pending_count'];
                    }
                }
                $result->free();
            }
        }

        return array_values($modules);
    }

    public function getDashboardSummary(): array
    {
        $summary = ['pending' => 0, 'success' => 0, 'failed' => 0];
        if (! $this->hasTable('sync_logs')) {
            return $summary;
        }

        $result = $this->conn->query(
            "SELECT `status`, COUNT(*) AS `count` FROM `sync_logs` GROUP BY `status`"
        );
        if ($result instanceof mysqli_result) {
            while ($row = $result->fetch_assoc()) {
                if (array_key_exists($row['status'], $summary)) {
                    $summary[$row['status']] = (int) $row['count'];
                }
            }
            $result->free();
        }

        return $summary;
    }
}
