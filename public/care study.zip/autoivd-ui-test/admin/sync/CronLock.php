<?php

declare(strict_types=1);

final class CronLock
{
    /** @return resource|null */
    public static function acquire(string $name)
    {
        $safeName = preg_replace('/[^a-z0-9_-]+/i', '-', $name) ?: 'sync';
        $handle = @fopen(sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'autoivd-' . $safeName . '.lock', 'c');
        if (! is_resource($handle) || ! @flock($handle, LOCK_EX | LOCK_NB)) {
            if (is_resource($handle)) {
                fclose($handle);
            }
            return null;
        }
        ftruncate($handle, 0);
        fwrite($handle, (string) getmypid());
        register_shutdown_function(static function () use ($handle): void {
            @flock($handle, LOCK_UN);
            @fclose($handle);
        });
        return $handle;
    }
}
