<?php

/**
 * OrderSyncHandler — Isolated handler for Order sync operations.
 *
 * Handles:
 * - Outbound: Push order status changes from ERP → Website API
 * - Inbound:  Process incoming website orders (delegated from OrderApiController)
 *
 * Location: admin/sync/OrderSyncHandler.php
 */

require_once(__DIR__ . '/SyncManager.php');
require_once(__DIR__ . '/SyncLogManager.php');
require_once(__DIR__ . '/SyncSettingsManager.php');
require_once(__DIR__ . '/SyncLogger.php');

class OrderSyncHandler
{
    private $conn;
    private SyncLogManager $logManager;
    private SyncSettingsManager $settingsManager;

    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->logManager = new SyncLogManager($conn);
        $this->settingsManager = new SyncSettingsManager($conn);
    }

    /**
     * Push an order status change from ERP to the Biogenix Website.
     *
     * Called from ajax.php when an ERP admin changes the status of a website-sourced order.
     * This method is NON-BLOCKING — it writes to sync_logs and attempts the HTTP call
     * with a short timeout. If the call fails, it is logged for automatic retry.
     *
     * @param int    $orderId    The ERP order_received.id
     * @param int    $newStatus  The new ERP status code
     * @param array  $trackingData  Optional tracking info ['tracking_number', 'carrier', 'tracking_url']
     * @return array Result with 'success' and 'message' keys
     */
    public function pushOrderStatusToWebsite(int $orderId, int $newStatus, array $trackingData = []): array
    {
        if (! $this->settingsManager->isEnabled('orders')) {
            return ['success' => false, 'message' => 'Order sync is disabled.', 'disabled' => true];
        }

        // Step 1: Verify this is a website-sourced order (source_type = 2).
        $stmt = $this->conn->prepare(
            "SELECT `id`, `source_type`, `external_reference`, `order_number`,
                    `status`, `sync_status_version`
             FROM `order_received`
             WHERE `id` = ? AND `source_type` = 2 AND `deleted_at` IS NULL
             LIMIT 1"
        );
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$order) {
            // Not a website order — no sync needed.
            return ['success' => true, 'message' => 'Not a website order, sync skipped.'];
        }

        if (empty($order['external_reference'])) {
            return ['success' => false, 'message' => 'Order has no external_reference, cannot sync.'];
        }

        // Step 1b: Verify the order contains items belonging to website-enabled categories (website_sync = 1).
        $catCheckStmt = $this->conn->prepare(
            "SELECT COUNT(*) AS synced_item_count
             FROM `order_received_items` ori
             JOIN `products` p ON p.`id` = ori.`product_id`
             JOIN `product_categories` c ON c.`id` = p.`category_id`
             WHERE ori.`order_id` = ?
               AND (c.`website_sync` = 1 OR p.`website_sync` = 1)
               AND ori.`deleted_at` IS NULL"
        );
        $catCheckStmt->bind_param('i', $orderId);
        $catCheckStmt->execute();
        $catRow = $catCheckStmt->get_result()->fetch_assoc();
        $catCheckStmt->close();

        $syncedItemCount = (int) ($catRow['synced_item_count'] ?? 0);

        if ($syncedItemCount === 0) {
            return [
                'success' => true,
                'message' => 'Order contains no products with category website_sync = 1. Sync skipped.',
                'skipped' => true,
            ];
        }

        // Step 2: Build the payload for the Website's reverse-sync API.
        $payload = [
            'external_reference' => $order['external_reference'],
            'erp_status' => (int) $order['status'],
            'erp_status_version' => max(1, (int) ($order['sync_status_version'] ?? 0)),
            'erp_order_number' => $order['order_number'],
            'remarks' => $this->getStatusLabel((int) $order['status']) . ' — synced from ERP.',
        ];

        // Merge tracking data if provided.
        if (!empty($trackingData['tracking_number'])) {
            $payload['tracking_number'] = $trackingData['tracking_number'];
        }
        if (!empty($trackingData['carrier'])) {
            $payload['carrier'] = $trackingData['carrier'];
        }
        if (!empty($trackingData['tracking_url'])) {
            $payload['tracking_url'] = $trackingData['tracking_url'];
        }

        // Step 3: Log the outbound sync attempt.
        $logId = $this->logManager->createLog('orders', (string) $orderId, 'outbound', $payload);

        // Network delivery is intentionally delegated to cron_sync_retry.php.
        // ERP business requests never wait for, or fail because of, Website IO.
        return [
            'success' => true,
            'message' => 'Order status queued for background Website sync.',
            'queued' => true,
            'log_id' => $logId,
        ];
    }

    /**
     * Retry a previously failed sync log entry.
     *
     * Called by the cron retry worker or the manual "Retry Now" button in Sync Settings UI.
     */
    public function retryFromLog(int $logId): array
    {
        if (! $this->settingsManager->isEnabled('orders')) {
            return ['success' => false, 'message' => 'Order sync is disabled.', 'disabled' => true];
        }

        $log = $this->logManager->getLogById($logId);

        if (!$log) {
            return ['success' => false, 'message' => 'Sync log not found.'];
        }

        if ($log['status'] === 'success') {
            return ['success' => true, 'message' => 'Already synced successfully.'];
        }

        if ($log['entity_type'] !== 'orders') {
            return ['success' => false, 'message' => 'This handler only retries order sync logs.'];
        }

        $payload = json_decode($log['request_payload'], true);
        if (!$payload) {
            return ['success' => false, 'message' => 'Cannot decode stored request payload.'];
        }

        // Determine endpoint based on direction.
        if ($log['direction'] === 'outbound') {
            $result = SyncManager::postToWebsite('/api/erp-sync/orders/status-update', $payload);
        } else {
            // Inbound retries would re-process the order — not typically needed.
            return ['success' => false, 'message' => 'Inbound order retry not supported via this handler.'];
        }

        if ($result['success']) {
            $this->logManager->markSuccess($logId, $result['body']);
            return ['success' => true, 'message' => 'Retry successful. Order status synced.'];
        } else {
            $this->logManager->markFailed($logId, $result['error'] ?? 'Retry failed', $result['http_code']);
            return ['success' => false, 'message' => 'Retry failed: ' . ($result['error'] ?? '')];
        }
    }

    /**
     * Get human-readable label for an ERP order status code.
     */
    private function getStatusLabel(int $statusCode): string
    {
        $labels = [
            0  => 'Pending',
            1  => 'Inprocess',
            2  => 'Hold',
            4  => 'Hold by Client',
            5  => 'Complete',
            6  => 'Cancelled',
            7  => 'Cancelled by Client',
            8  => 'Dispatched',
            9  => 'Not In Stock',
            10 => 'Forcefully Complete',
            11 => 'Partial Dispatched',
            12 => 'Pending Review',
            13 => 'Ready for Dispatch',
            14 => 'Partially Available',
            15 => 'Stock Unavailable',
            16 => 'Sent to Production',
            17 => 'Sent to Procurement',
            18 => 'Production in Progress',
            19 => 'Procurement in Progress',
        ];

        return $labels[$statusCode] ?? 'Unknown Status';
    }
}
