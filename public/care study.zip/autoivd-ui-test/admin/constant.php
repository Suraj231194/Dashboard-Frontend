<?php 
class Constant
{
    public const CUSTOM_TITLES = [
        'dashboard' => 'Dashboard',
        'coa-generation' => 'COA Generation',
        'coa-templates' => 'COA Templates',
        'sa-generation' => 'SA Generation',
        'daily-production-report-bseh' => 'Daily Production Report BSEH',
        'stocks' => 'Live Inventory',
        'stock-inwards' => 'Goods Recieved',
        'stock-outwards' => 'Goods Dispatched',
        'pi-generator' =>'PI Generator',
        'ip-coa-generation' =>'IP COA Generation',
        'fg-coa-generation' =>'FG COA Generation',
        'order-received' =>'Order Management',
        'ai-assistance' =>'AI Assistance',
        'bmr' =>'BMR',
        'bpr' =>'BPR',
        'production-bmr-bpr' => 'BMR/BPR',
        'goods-received-production' => 'Goods Received from Production',
        'bmr-bpr-form-request' => 'BMR/BPR Form Request',
        'bmr-bpr-issuance' => 'BMR/BPR Issuance',
        'order-detail' => 'Order Detail',
        'customer-management' => 'Customer Management',
        'meeting-requests' => 'Meeting Requests',
        'quiz-activity-feed' => 'Quiz Activity Feed',
        'pi-requests' => 'PI Requests',
        'quotation-requests' => 'Quotation Requests',
        'lead-management' => 'Lead Management',
        'salesperson-master' => 'Salesperson Master',
        'crm-quote-management' => 'CRM Quote Management',
        'payroll-pay-runs' => 'Pay Runs',
        'payroll-advances' => 'Advance Salary',
        'payroll-reimbursements' => 'Reimbursements',
        'finance-reimbursement-claims' => 'Reimbursement Claims',
        'annual-calendar' => 'Annual Calendar & Working Days',
    ];

    public const NOTIFIACTION_TYPE = [
        1 => ['label' => 'Low Stock Alert'],
        2 => ['label' => 'Stock Finished'],
        3 => ['label' => 'User'],
        4 => ['label' => 'Role'],
        5 => ['label' => 'Broadcast'],
        6 => ['label' => 'System']
    ];
    public const NOTIFIACTION_TYPE_LABEL = [
        'LowStockAlert' => 1,
        'StockFinished' => 2,
        'User' => 3,
        'Role' => 4,
        'Broadcast' => 5,
        'System' => 6
    ];
    public const NOTIFIACTION_MODULE = [
        1 => ['label' => 'Stock'],
        2 => ['label' => 'Purchase'],
        3 => ['label' => 'System'],
        4 => ['label' => 'HR'],
        5 => ['label' => 'Custom'] 
    ];
    public const NOTIFIACTION_MODULE_LABEL = [
        'Stock' => 1,
        'Purchase' => 2,
        'System' => 3,
        'HR' => 4,
        'Custom' => 5   
    ];
    public const NOTIFIACTION_SEVERITY = [
        1 => ['label' => 'Info', 'text-class' =>'info'],
        2 => ['label' => 'Warning', 'text-class' =>'warning'],
        3 => ['label' => 'Critical', 'text-class' =>'danger']
    ];

    public const STATUS_KEY = [
        0 => 'Inactive',
        1 => 'Active'
    ];

    public const STATUS_LABEL = [
        'INACTIVE' => 0,
        'ACTIVE' => 1
    ];

    public const INVENTORY_GROUPS = [
        1 => ['label' => 'Finished Goods', 'shortname' => 'FG'],
        2 => ['label' => 'Packing Material', 'shortname' => 'PM'],
        3 => ['label' => 'Raw Material', 'shortname' => 'RM'],
        4 => ['label' => 'Consumables', 'shortname' => 'CON']
    ];

    public const ORDER_RECEIVED =[
        'SOURCE_TYPES' => [
            1 => ['label' => 'ERP', 'class' => 'bg-label-primary'],
            2 => ['label' => 'Website', 'class' => 'bg-label-info'],
            3 => ['label' => 'Email', 'class' => 'bg-label-warning'],
            4 => ['label' => 'WhatsApp', 'class' => 'bg-label-success']
        ],
        'PAYMENT_STATUS_TERM' => [
            1 => 'Advance (Paid)',
            2 => 'Credit',
            3 => 'Payment Pending',
            4 => 'Other'
        ],
        'PAYMENT_STATUS_TERM_LABEL' => [
            'Paid_in_Advanced' => 1,
            'Credit_Order' => 2,
            'Payment_Pending' => 3 ,
            'Other' => 4
        ],
        'ORDER_TYPE_OPTIONS' =>[
            1 => 'Product Order',
            2 => 'Sample Request',
            3 => 'Tender Supply',
            4 => 'Instrument Dispatched',
            5 => 'AMC/CMC/Service',
            6 => 'Other'
        ],
        'ORDER_TYPE_OPTIONS_LABEL' => [
            'Product_Order' => 1,
            'Sample_Request' => 2,
            'Tender_Supply' => 3,
            'Instrument_Dispatched' => 4,
            'AMC_CMC_Service' => 5,
            'Other' => 6
        ],
        'DISPATCH_TIMELINE' => [
            1 => 'Immediate',
            2 => '1 Week',
            3 => 'Next Week',
            4 => 'Flexible'
        ],
        'STATUS_TYPES' => [
            0  => ['label' => 'Pending',               'class' => 'bg-label-warning'],      // Yellow
            1  => ['label' => 'Inprocess',             'class' => 'bg-label-primary'],      // Blue
            2  => ['label' => 'Hold',                  'class' => 'bg-label-secondary'],    // Gray
            4  => ['label' => 'Hold by Client',        'class' => 'bg-label-dark'],         // Dark Gray
            5  => ['label' => 'Complete',              'class' => 'bg-label-success'],      // Green
            6  => ['label' => 'Cancelled',             'class' => 'bg-label-danger'],       // Red
            7  => ['label' => 'Cancelled by Client',   'class' => 'bg-label-danger'],       // Red
            8  => ['label' => 'Dispatched',            'class' => 'bg-label-info'],         // Light Blue
            9  => ['label' => 'Not In Stock',          'class' => 'bg-label-warning'],      // Yellow
            10 => ['label' => 'Forcefully Complete',   'class' => 'bg-label-success'],       // Green
            11 => ['label' => 'Partial Dispatched',       'class' => 'bg-label-primary'],       // Blue
            12 => ['label' => 'Pending Review',        'class' => 'bg-label-warning'],       // Yellow/Warning
            13 => ['label' => 'Ready for Dispatch',    'class' => 'bg-label-success'],
            14 => ['label' => 'Partially Available',   'class' => 'bg-label-primary'],
            15 => ['label' => 'Stock Unavailable',     'class' => 'bg-label-danger'],
            16 => ['label' => 'Sent to Production',    'class' => 'bg-label-info'],
            17 => ['label' => 'Sent to Procurement',   'class' => 'bg-label-info'],
            18 => ['label' => 'Production in Progress','class' => 'bg-label-primary'],
            19 => ['label' => 'Procurement in Progress','class' => 'bg-label-primary']
        ],
        'STATUS_TYPES_LABEL' => [
            'Pending' => 0,
            'Inprocess' => 1,
            'Hold' => 2,
            'Hold_by_Client' => 4,
            'Complete' => 5,
            'Cancelled' => 6,
            'Cancelled_by_Client' => 7,
            'Dispatched' => 8,
            'Not_In_Stock' => 9,
            'Forcefully_Complete' => 10,
            'Partial_Delivered' => 11,
            'Pending_Review' => 12,
            'Ready_for_Dispatch' => 13,
            'Partially_Available' => 14,
            'Stock_Unavailable' => 15,
            'Sent_to_Production' => 16,
            'Sent_to_Procurement' => 17,
            'Production_in_Progress' => 18,
            'Procurement_in_Progress' => 19
        ],
        'STATUS_TYPES_ORDER_LIST' => [ 
            2  => ['label' => 'Hold',                  'class' => 'bg-label-secondary'],    // Gray
            4  => ['label' => 'Hold by Client',        'class' => 'bg-label-dark'],         // Dark Gray
            6  => ['label' => 'Cancelled',             'class' => 'bg-label-danger'],       // Red
            7  => ['label' => 'Cancelled by Client',   'class' => 'bg-label-danger'],       // Red
        ],
        'STATUS_TYPES_LABEL_ORDER_LIST' => [
            'Hold' => 2,
            'Hold_by_Client' => 4,
            'Cancelled' => 6,
            'Cancelled_by_Client' => 7
        ],
        'STATUS_TYPES_List' => [
            0  => ['label' => 'Pending',               'class' => 'bg-label-warning'],      // Yellow
            1  => ['label' => 'Inprocess',             'class' => 'bg-label-primary'],      // Blue
            2  => ['label' => 'Hold',                  'class' => 'bg-label-secondary'],    // Gray
            4  => ['label' => 'Hold by Client',        'class' => 'bg-label-dark'],         // Dark Gray
            5  => ['label' => 'Complete',              'class' => 'bg-label-success'],      // Green
            6  => ['label' => 'Cancelled',             'class' => 'bg-label-danger'],       // Red
            7  => ['label' => 'Cancelled by Client',   'class' => 'bg-label-danger'],      // Red
            8  => ['label' => 'Dispatched',            'class' => 'bg-label-info'],
            9  => ['label' => 'Not In Stock',          'class' => 'bg-label-warning'],
            11 => ['label' => 'Partial Dispatched',    'class' => 'bg-label-primary'],
            12 => ['label' => 'Pending Review',        'class' => 'bg-label-warning'],
            13 => ['label' => 'Ready for Dispatch',    'class' => 'bg-label-success'],
            14 => ['label' => 'Partially Available',   'class' => 'bg-label-primary'],
            15 => ['label' => 'Stock Unavailable',     'class' => 'bg-label-danger'],
            16 => ['label' => 'Sent to Production',    'class' => 'bg-label-info'],
            17 => ['label' => 'Sent to Procurement',   'class' => 'bg-label-info'],
            18 => ['label' => 'Production in Progress','class' => 'bg-label-primary'],
            19 => ['label' => 'Procurement in Progress','class' => 'bg-label-primary']
        ],
        'STATUS_TYPES_LIST_LABEL' => [
            'Pending' => 0, 
            'Inprocess' => 1,
            'Hold' => 2,
            'HoldByClient' => 4,
            'Complete' => 5,
            'Cancelled' => 6,
            'CancelledByClient' => 7,
            'NotInStock' => 9,
            'PendingReview' => 12,
            'ReadyForDispatch' => 13,
            'PartiallyAvailable' => 14,
            'StockUnavailable' => 15,
            'SentToProduction' => 16,
            'SentToProcurement' => 17,
            'ProductionInProgress' => 18,
            'ProcurementInProgress' => 19
        ],
        'LOCATION_MAP' => [
            1  => ['label' => 'Single',             'class' => 'bg-label-primary'],      // Blue
            2  => ['label' => 'Multiple',                  'class' => 'bg-label-secondary']
        ],
        'STOCK_STATUS' => [
            'SUFFICIENT' => 'SUFFICIENT',
            'PARTIAL' => 'PARTIAL',
            'UNAVAILABLE' => 'UNAVAILABLE',
            'LOW' => 'LOW',
            'UNCHECKED' => 'UNCHECKED'
        ],
        'FULFILLMENT_ACTION' => [
            'DISPATCH' => 'dispatch',
            'PROCUREMENT' => 'procurement',
            'PRODUCTION' => 'production'
        ]
    ];

    public const COA_INBOUND_QUEUE = [
        'STATUS_TYPES' => [
            0 => ['label' => 'Pending',       'class' => 'bg-label-warning'],
            1 => ['label' => 'COA Generated', 'class' => 'bg-label-success'],
            2 => ['label' => 'Dismissed',     'class' => 'bg-label-secondary']
        ],
        'STATUS_TYPES_LABEL' => [
            'Pending' => 0,
            'COAGenerated' => 1,
            'Dismissed' => 2
        ]
    ];
    
    public const MATERIAL_REQUISITION = [
        'STATUS_TYPES' => [
            0  => ['label' => 'Pending',      'badge' => 'bg-label-warning',  'btn' => 'btn-warning',  'class' => 'warning'],
            1  => ['label' => 'Inprocess',    'badge' => 'bg-label-primary',  'btn' => 'btn-primary',  'class' => 'primary'],
            2  => ['label' => 'Hold',         'badge' => 'bg-label-secondary', 'btn' => 'btn-secondary', 'class' => 'secondary'],
            5  => ['label' => 'Complete',     'badge' => 'bg-label-success',  'btn' => 'btn-success',  'class' => 'success'],
            6  => ['label' => 'Cancelled',    'badge' => 'bg-label-danger',   'btn' => 'btn-danger',   'class' => 'danger'],
            9  => ['label' => 'Not In Stock', 'badge' => 'bg-label-warning',  'btn' => 'btn-warning',  'class' => 'warning']
        ],
        'STATUS_TYPES_LABEL' => [
            'Pending' => 0,
            'Inprocess' => 1,
            'Hold' => 2,
            'Complete' => 5,
            'Cancelled' => 6,
            'Not_In_Stock' => 9
        ]
    ];
    
    public const DAILY_PROD_BSEH = [
        'DEPARTMENT' => [
            1 => ['label' => 'Biochemistry',    'shortname' => 'BIO'],
            2 => ['label' => 'Serology',        'shortname' => 'SER'],
            3 => ['label' => 'Elisa',           'shortname' => 'ELI'],
            4 => ['label' => 'Hematology',      'shortname' => 'HEM']
        ],
        'DEPARTMENT_LABEL' => [
            'Biochemistry' => 1,
            'Serology' => 2,
            'Elisa' => 3,
            'Hematology' => 4
        ]
    ];

    public const RMPM = [
        'STATUS_TYPES' => [
            0  => ['label' => 'Pending',    'badge' => 'bg-label-warning',   'btn' => 'btn-warning',   'class' => 'warning'],
            1  => ['label' => 'Approved',     'badge' => 'bg-label-success',  'btn' => 'btn-success',  'class' => 'success'],
            2  => ['label' => 'Rejected',    'badge' => 'bg-label-danger',   'btn' => 'btn-danger',   'class' => 'danger']
        ],
        'STATUS_TYPES_LABEL' => [
            'Pending' => 0,
            'Approved' => 1,
            'Rejected' => 2,
        ]
    ];
    
    public const EMPLOYEES = [
        'STATUS_TYPES' => [
            0  => ['label' => 'Inactive',    'badge' => 'bg-label-danger',   'btn' => 'btn-danger',   'class' => 'danger'],
            1  => ['label' => 'Active',     'badge' => 'bg-label-success',  'btn' => 'btn-success',  'class' => 'success'],
            2  => ['label' => 'Resigned',    'badge' => 'bg-label-secondary',   'btn' => 'btn-secondary',   'class' => 'secondary']
        ],
        'STATUS_TYPES_LABEL' => [
            'Inactive' => 0,
            'Active' => 1,
            'Resigned' => 2,
        ],
        'SOLUTATION' => [
            'Mr' => 'Mr',
            'Mrs' => 'Mrs',
            'Miss' => 'Miss',
            'Shree' => 'Shree'
        ],
        'GENDER' => [
            1 => 'Male',
            2 => 'Female',
            4 => 'Other'
        ],
        'COMPANY_TYPE' => [
            1 => 'BIO',
            2 => 'LAB'
        ],
        'COMPANY_TYPE_LABEL' => [
            'BIO' => 1,
            'LAB' => 2
        ],
        'COMPANY_TYPE_LIST' => [
            1  => ['label' => 'BIO',     'badge' => 'bg-label-success',  'btn' => 'btn-success',  'class' => 'success'],
            2  => ['label' => 'LAB',    'badge' => 'bg-label-secondary',   'btn' => 'btn-secondary',   'class' => 'secondary']
        ],
        'MARITAL_STATUS' => [
            1 => 'Married',
            2 => 'Unmarried',
            4 => 'Divorced',
            5 => 'Widowed'
        ],
        'EMPLOYMENT_CATEGORY_TYPE' => [
            '1' => 'Worker',
            '2' => 'Employee',
            '3' => 'House Keeping',
            '4' => 'Store'
        ],
        'EMPLOYMENT_CATEGORY_SHORT_TYPE' => [
            'W' => '1',
            'E' => '2',
            'HK' => '3',
            'STR' => '4'
        ],
        'EMPLOYMENT_CATEGORY_TYPE_FILTER' => [
            1 => ['label' => 'Worker', 'shortKey' => 'W'],
            2 => ['label' => 'Employee', 'shortKey' => 'E'],
            3 => ['label' => 'House Keeping', 'shortKey' => 'HK'],          
            4 => ['label' => 'Store', 'shortKey' => 'STR']            
        ],
        'EMPLOYMENT_TYPE' => [
            1 => 'Permanent',
            2 => 'Temporary',
            3 => 'Trainee'
        ],
        'BLOOD_GROUP' => [
            'A+' => 'A+',
            'A-' => 'A-',
            'B+' => 'B+',
            'B-' => 'B-',
            'AB+' => 'AB+',
            'AB-' => 'AB-',
            'O+' => 'O+',
            'O-' => 'O-'
        ]
    ];
    
    public const STOCKS = [
        'STATUS_TYPES' => [
            0 => ['label' => 'Out of Stock', 'badge' => 'bg-label-danger'],
            1 => ['label' => 'Available', 'badge' => 'bg-label-success'],
            2 => ['label' => 'Low Stock', 'badge' => 'bg-label-warning']
        ],
        'STATUS_TYPES_LABEL' => [
            'Out_Of_Stock' => 0,
            'Available' => 1,
            'Low_Stock' => 2
        ],
        'BOM_TYPES' => [
            1 => ['label' => 'SEMI (Raw to Semi)',          'listText' => 'Semi'],
            2 => ['label' => 'INTERMEDIATE (Semi to Semi)', 'listText' => 'Intermediate'],
            4 => ['label' => 'FINISHED (Final Product)',    'listText' => 'Finished']
        ],
        'BOM_TYPES_LABEL' => [
            'SEMI' => 1,
            'INTERMEDIATE' => 2,
            'FINISHED' => 4
        ],
        'BOM_STATUS' => [
            'DRAFT'            => ['label' => 'Draft',            'badge' => 'bg-label-secondary'],
            'PENDING_APPROVAL' => ['label' => 'Pending Approval', 'badge' => 'bg-label-info'],
            'APPROVED'         => ['label' => 'Approved',         'badge' => 'bg-label-success'],
            'REJECTED'         => ['label' => 'Rejected',         'badge' => 'bg-label-danger'],
        ],
        'BOM_SOURCE_TYPES' => [
            'ORIGINAL' => ['label' => 'Original'],
            'CLONED'   => ['label' => 'Cloned'],
            'MANUAL'   => ['label' => 'Manual'],
        ],
    ];
    
    public const STOCKS_INWARDS = [
        'PHYSICAL_CONDITION' => [
            1 => ['label' => 'Intact', 'badge' => 'bg-label-success'],
            2 => ['label' => 'Damaged', 'badge' => 'bg-label-danger'],
            4 => ['label' => 'Short Quantity', 'badge' => 'bg-label-warning'],
            5 => ['label' => 'Expired', 'badge' => 'bg-label-danger'],
            6 => ['label' => 'Mislabelled', 'badge' => 'bg-label-info'],
            7 => ['label' => 'Other', 'badge' => 'bg-label-danger'],
        ],
        'PHYSICAL_CONDITION_LABEL' => [
            'Intact' => 1,
            'Damaged' => 2,
            'Short_Quantity' => 4,
            'Expired' => 5,
            'Mislabelled' => 6,
            'Other' => 7,
        ],
        'RECEIPT_STATUS' => [
            1 => ['label' => 'Complete', 'badge' => 'bg-label-success'],
            2 => ['label' => 'Partially Received', 'badge' => 'bg-label-warning'],
            3 => ['label' => 'Excess Received', 'badge' => 'bg-label-info'],
            4 => ['label' => 'Half Received', 'badge' => 'bg-label-primary'],
        ],
        'RECEIPT_STATUS_LABEL' => [
            'Complete' => 1,
            'Partially_Received' => 2,
            'Excess_Received' => 3,
            'Half_Received' => 4,
        ]
    ];
    
    public const STOCKS_OUTWARDS = [
        'CLIENT_RECEIVER_TYPE' => [
            1 => 'B2B (Dealer/Distributor)',
            2 => 'B2C (Diagnostic Lab/Direct)',
            3 => 'Govt Institute',
            4 => 'Hospital',
            5 => 'Labkem',
            7 => 'In-House Production',
            6 => 'Other'
        ],
        'CLIENT_RECEIVER_TYPE_LABEL' => [
            'B2B' => 1,
            'B2C' => 2,
            'DealerDistributor' => 1,
            'DiagnosticLab' => 2,
            'GovtInstitute' => 3,
            'Hospital' => 4,
            'Labkem' => 5,
            'InHouseProduction' => 7,
            'Other' => 6
        ],
        'TYPE_DISPATCH' => [
            1 => 'Product Order',
            2 => 'Sample Dispatch',
            3 => 'Replacement',
            4 => 'Tender Supply',
            5 => 'Other',
            6 => 'In-House Production'
        ],
        'TYPE_DISPATCH_LABEL' => [
            'ProductOrder' => 1 ,
            'SampleDispatch' => 2,
            'Replacement' => 3,
            'TenderSupply' => 4,
            'Other' => 5,
            'InHouseProduction' => 6
        ],
        'DELIVERY_MODE' => [
            1 => 'Self Pickup',
            2 => 'By Delivery Boy',
            4 => 'Transport/Courier'
        ],
        'DELIVERY_MODE_LABEL' => [
            'SelfPickup' => 1,
            'ByDeliveryBoy' => 2,
            'TransportCourier' => 4
        ],
        'COURIER_TRANSPORT_TYPE' => [
            1 => 'DTDC',
            2 => 'TCI',
            3 => 'Bluedart',
            4 => 'Reliable',
            5 => 'Jetline',
            6 => 'Fedex',
            7 => 'DP World',
            8 => 'TrackOn',
            10 => 'Safe Express',
            11 => 'Porter',
            12 => 'Tirupati',
            9 => 'Other'
        ],
        'COURIER_TRANSPORT_TYPE_LABEL' => [
            'DTDC' => 1,
            'TCI' => 2,
            'Bluedart' => 3,
            'Reliable' => 4,
            'Jetline' => 5,
            'Fedex' => 6,
            'DP World' => 7,
            'TrackOn' => 8,
            'SafeExpress' => 10,
            'Porter' => 11,
            'Tirupati' => 12,
            'Other' => 9
        ],
        'DISPATCH_MGMT' => [
            1 => 'Internal Manufacturing',
            2 => 'External Dispatch',
            3 => 'New Order Received'
        ],
        'DISPATCH_MGMT_LABEL' => [
            'InternalManufacturing' => 1,
            'ExternalDispatch' => 2,
            'NewOrderReceived' => 3
        ],
        'STATUS_TYPES' => [
            0  => ['label' => 'Pending',               'class' => 'bg-label-warning'],      // Yellow
            1  => ['label' => 'Completed',              'class' => 'bg-label-success'],      // Green
        ]
    ];
    
    public const PRODUCTION_PLAN = [
        'TIMELINE' => [
            1 => ['label' => 'Urgently', 'badge' => 'bg-label-danger'],
            2 => ['label' => 'Flexible', 'badge' => 'bg-label-warning']
        ],
        'STATUS' => [
            0 => ['label' => 'Pending', 'badge' => 'bg-label-warning'],
            1 => ['label' => 'In-Process', 'badge' => 'bg-label-primary'],
            2 => ['label' => 'Completed', 'badge' => 'bg-label-success']
        ]
    ];
    
    public const LOW_STOCK = [
        'CRITICAL_STATUS' => [
            1 => ['label' => 'Yes, Urgent', 'badge' => 'bg-label-danger'],
            2 => ['label' => 'No, Routine', 'badge' => 'bg-label-info'],
            3 => ['label' => 'I don\'t know', 'badge' => 'bg-label-warning']
        ],
        'STATUS' => [
            0 => ['label' => 'Pending', 'badge' => 'bg-label-warning'],
            1 => ['label' => 'In-Process', 'badge' => 'bg-label-primary'],
            2 => ['label' => 'Completed', 'badge' => 'bg-label-success'],
            4 => ['label' => 'Order Placed', 'badge' => 'bg-label-success'],
            5 => ['label' => 'Order Cancelled', 'badge' => 'bg-label-danger']
        ],
        'STATUS_LABEL' => [
            'Pending' => 0,
            'InProcess' => 1,
            'Completed' => 2,
            'OrderPlaced' => 4,
            'OrderCancelled' => 5
        ]
    ];
    
    public const PURCHASE_MANAGEMENT = [
        'CURRENCY' => [
            1 => ['label' => 'INR',  'badge' => 'bg-label-warning', 'symbol' => '₹'],
            2 => ['label' => 'USD',  'badge' => 'bg-label-primary', 'symbol' => '$'],
            3 => ['label' => 'EURO', 'badge' => 'bg-label-success', 'symbol' => '€'],
            4 => ['label' => 'RUBLE','badge' => 'bg-label-info',    'symbol' => '₽'],
        ]
    ];

    public const HR_SETTINGS = [
        'HOLIDAYS_TYPE' => [
            1 => ['label' => 'National'],
            2 => ['label' => 'Company'],
            3 => ['label' => 'Festival'],
            4 => ['label' => 'Restricted'],
            5 => ['label' => 'Other'],
        ],
        'SATURDAY_POLICY' => [
            'all_working'  => ['label' => 'All Saturdays Working (6-day week)'],
            'all_off'      => ['label' => 'All Saturdays Off (5-day week)'],
            '2nd_4th_off'  => ['label' => '2nd & 4th Saturday Off'],
            'alternate_off' => ['label' => 'Alternate Saturdays Off'],
            'custom'       => ['label' => 'Custom Weekly-Off Dates'],
        ],
        'ANNUAL_CALENDAR_HOLIDAY_TYPE' => [
            'national'   => ['label' => 'National Holiday',  'badge' => 'bg-label-danger',  'color' => '#ef4444'],
            'company'    => ['label' => 'Company Holiday',   'badge' => 'bg-label-primary', 'color' => '#3b82f6'],
            'festival'   => ['label' => 'Festival Holiday',  'badge' => 'bg-label-warning', 'color' => '#f59e0b'],
            'restricted' => ['label' => 'Restricted Holiday','badge' => 'bg-label-info',    'color' => '#8b5cf6'],
            'other'      => ['label' => 'Other Holiday',     'badge' => 'bg-label-secondary','color' => '#64748b'],
        ],
        'ACCOUNT_TYPE' => [
            1 => ['label' => 'Savings'],
            2 => ['label' => 'Current'],
            3 => ['label' => 'Salary Account']
        ],
        'INSTALLMENT_ADVANCED' => [
            1 => ['label' => 'Full Deduction'],
            2 => ['label' => 'Installments']
        ],
        'INSTALLMENT_ADVANCED_LABEL' => [
            'Full_Deduction' => 1,
            'Installments' => 2       
        ],
        'WORKING_DAYS' => [
            1 => ['label' => 'Mon'],
            2 => ['label' => 'Tue'],
            3 => ['label' => 'Wed'],
            4 => ['label' => 'Thu'],
            5 => ['label' => 'Fri'],
            6 => ['label' => 'Sat'],
            7 => ['label' => 'Sun']
        ],
        'SHIFT_ROASTER_TYPE' => [
            1 => ['label' => 'Weekly'],
            2 => ['label' => 'Custom Day']
        ],
        'SHIFT_ROASTER_TYPE_LABEL' => [
            'Weekly' => 1,
            'CustomDay' => 2       
        ],
        'SHIFT_ROASTER_STATUS' => [
            1 => ['label' => 'Active', 'class' => 'success'],
            2 => ['label' => 'Inactive', 'class' => 'secondary'],
            4 => ['label' => 'Locked', 'class' => 'danger'],
        ],
        'SHIFT_ROASTER_STATUS_LABEL' => [
            'Active' => 1,
            'Inactive' => 2,       
            'Locked' => 4
        ],
    ];
    
    public const CALENDER = [
        'EVENT_TYPE' => [
            1  => ['label' => 'Birthday', 'data-label' => 'success', 'data-value' => 'birthday'],
            2  => ['label' => 'Work Anniversary', 'data-label' => 'info', 'data-value' => 'workAnniversary'],
            3  => ['label' => 'Marriage Anniversary', 'data-label' => 'danger', 'data-value' => 'marriageAnniversary'],
            // 5  => ['label' => 'Personal', 'data-label' => 'danger', 'data-value' => 'personal'],
            // 6  => ['label' => 'Business', 'data-label' => 'primary', 'data-value' => 'business'],
            // 7  => ['label' => 'Family', 'data-label' => 'warning', 'data-value' => 'family'],
            // 8  => ['label' => 'Holiday', 'data-label' => 'success', 'data-value' => 'holiday'],
            4  => ['label' => 'Other', 'data-label' => 'warning', 'data-value' => 'other'],
        ],
        'EVENT_TYPE_LABEL' => [
            'Birthday' => 1,
            'WorkAnniversary' => 2,    
            'MarriageAnniversary' => 3    
        ]
    ];

     /* ---------- Tender Status ---------- */
    public const TENDERS = [
        'BASE_STATUS_TYPE' => [
            0  => ['label' => 'Pending',                 'badge' => 'bg-label-warning',   'text-class' => 'warning'],
            1  => ['label' => 'Participated',            'badge' => 'bg-label-info',      'text-class' => 'info'],
            2  => ['label' => 'Not Participated',                'badge' => 'bg-label-danger',    'text-class' => 'danger'],
            4  => ['label' => 'Technical Opening',       'badge' => 'bg-label-primary',   'text-class' => 'primary'],
            5  => ['label' => 'Technical Evaluated',     'badge' => 'bg-label-secondary', 'text-class' => 'secondary'],
            6  => ['label' => 'Technical Qualified',     'badge' => 'bg-label-success',   'text-class' => 'success'],
            7  => ['label' => 'Technical Disqualified',  'badge' => 'bg-label-danger',    'text-class' => 'danger'],
            8  => ['label' => 'Financial Opening',       'badge' => 'bg-label-info',      'text-class' => 'info'],
            9  => ['label' => 'Financial Evaluated',     'badge' => 'bg-label-dark',     'text-class' => 'dark'],
            10 => ['label' => 'Financial Qualified',     'badge' => 'bg-label-success',   'text-class' => 'success'],
            11 => ['label' => 'Financial Disqualified',  'badge' => 'bg-label-danger',    'text-class' => 'danger'],
            12 => ['label' => 'AOC',                     'badge' => 'bg-label-success',   'text-class' => 'success'],
        ],

        'BASE_STATUS_TYPE_LABEL' => [
            'Pending'                => 0,
            'Participated'           => 1,
            'Rejected'               => 2,
            'TechnicalOpening'       => 4,
            'TechnicalEvaluated'     => 5,
            'TechnicalQualified'     => 6,
            'TechnicalDisqualified'  => 7,
            'FinancialOpening'       => 8,
            'FinancialEvaluated'     => 9,
            'FinancialQualified'     => 10,
            'FinancialDisqualified'  => 11,
            'AOC'                    => 12,
        ],

        'STATUS_TYPE' => [
            1 => ['label' => 'Draft',    'text-class' => 'secondary'],
            2 => ['label' => 'Active',   'text-class' => 'success'],
            4 => ['label' => 'Closed',   'text-class' => 'dark'],
            5 => ['label' => 'Archived', 'text-class' => 'muted']
        ],
        'TENDER_AUTHORITY_TYPE' => [
            1 => ['label' => 'Govt',    'text-class' => 'secondary'],
            2 => ['label' => 'Private',   'text-class' => 'success']
        ],
        'TENDER_TYPE' => [
            1 => ['label' => 'Open',    'text-class' => 'secondary'],
            2 => ['label' => 'Limited',   'text-class' => 'success'],
            3 => ['label' => 'Rate Contract',   'text-class' => 'dark']
        ],               
        'TENDER_CATEGORY' => [
            1 => ['label' => 'IVD Kits',      'text-class' => 'primary'],  
            2 => ['label' => 'Instruments',   'text-class' => 'info'],  
            3 => ['label' => 'Reagents',      'text-class' => 'warning'],  
            4 => ['label' => 'IVD Kits + Reagents', 'text-class' => 'success'],
            5 => ['label' => 'Consumables',   'text-class' => 'secondary'], 
        ],

        'TENDER_EMD_TYPE' => [
            1 => ['label' => 'Fixed',    'text-class' => 'secondary'],
            2 => ['label' => 'ItemWise',   'text-class' => 'success'],
            4 => ['label' => 'Exempted',  'text-class' => 'warning'],
        ],
        'TENDER_EMD_TYPE_LABEL' => [
            'Fixed' => 1,
            'ItemWise' => 2,
            'Exempted'  => 4,
        ],
        'TENDER_EMD_CALCULATION_TYPE' => [
            // 1 => ['label' => 'Fixed',    'text-class' => 'secondary'],
            2 => ['label' => 'EachItem',   'text-class' => 'success'],
            3 => ['label' => 'Upto N Items',   'text-class' => 'success']
        ],
        'TENDER_EMD_CALCULATION_TYPE_LABEL' => [
            'EachItem' => 2,
            'UptoNItems' => 3
        ],        
        'TENDER_APPLICATION_STATUS' => [
            1 => ['label' => 'Submitted', 'text-class' => 'primary'],
            2 => ['label' => 'Rejected',  'text-class' => 'danger'],
            4 => ['label' => 'Qualified', 'text-class' => 'success'],
            5 => ['label' => 'L1',        'text-class' => 'info'],
            6 => ['label' => 'L2',        'text-class' => 'warning']
        ],
        'TENDER_RESULT_STATUS' => [
            1 => ['label' => 'Awarded',     'text-class' => 'success'],
            2 => ['label' => 'Not Awarded', 'text-class' => 'danger']
        ],
        'TENDER_DELIVERY_STATUS' => [
            1 => ['label' => 'Pending',   'text-class' => 'warning'],
            2 => ['label' => 'Partial',   'text-class' => 'info'],
            4 => ['label' => 'Completed', 'text-class' => 'success']
        ],
        'TENDER_PAYMENT_TYPE' => [
            1 => ['label' => 'EMD',              'text-class' => 'warning'],
            2 => ['label' => 'Tender Fee',       'text-class' => 'primary'],
            4 => ['label' => 'Security Deposit', 'text-class' => 'info'],
            5 => ['label' => 'Bank Guarantee',   'text-class' => 'secondary']
        ],
        'TENDER_PAYMENT_TYPE_LABEL' => [
            'EMD'     => 1,
            'TenderFee' => 2,
            'SecurityDeposit'   => 4,
            'BankGuarantee'  => 5
        ],
        'TENDER_FEASIBILITY_STATUS' => [
            1 => ['label' => 'Apply',     'text-class' => 'success'],
            2 => ['label' => 'Not Apply', 'text-class' => 'danger']
        ],
        'TENDER_PAYMENT_MODE' => [
            1 => ['label' => 'Online',        'text-class' => 'success'],
            2 => ['label' => 'Demand Draft',  'text-class' => 'warning'],
            3 => ['label' => 'Bank Guarantee','text-class' => 'info'],
        ],
        'TENDER_PAYMENT_STATUS' => [
            0 => ['label' => 'Pending',   'badge' => 'bg-label-warning', 'text-class' => 'warning'],
            1 => ['label' => 'Paid',      'badge' => 'bg-label-success', 'text-class' => 'success'],
            2 => ['label' => 'Refunded',  'badge' => 'bg-label-info',    'text-class' => 'info'],
            3 => ['label' => 'Failed',    'badge' => 'bg-label-danger',  'text-class' => 'danger'],
        ],
        'TENDER_PAYMENT_STATUS_LABEL' => [
            'Pending'  => 0,
            'Paid'     => 1,
            'Refunded' => 2,
            'Failed'   => 3,
        ],
        'TENDER_RANKS' => [
            1 => ['label' => 'L1',      'badge' => 'bg-label-success', 'text-class' => 'success'],
            2 => ['label' => 'L2',  'badge' => 'bg-label-info',    'text-class' => 'info'],
            3 => ['label' => 'L3',    'badge' => 'bg-label-danger',  'text-class' => 'danger'],
        ],
        'TENDER_EVALUATION_STATUS' => [
            0 => ['label' => 'Evaluated',      'badge' => 'bg-label-success', 'text-class' => 'success'],
            1 => ['label' => 'Recommended',  'badge' => 'bg-label-info',    'text-class' => 'info'],
            2 => ['label' => 'Rejected',    'badge' => 'bg-label-danger',  'text-class' => 'danger'],
        ],
        'TENDER_PBG_STATUS' => [
            0 => ['label' => 'Pending',  'badge' => 'bg-label-warning',    'text-class' => 'warning'],
            1 => ['label' => 'Paid',      'badge' => 'bg-label-success', 'text-class' => 'success'],
            2 => ['label' => 'Released',    'badge' => 'bg-label-success',  'text-class' => 'success'],
        ],
        'TENDER_PBG_STATUS_LABEL' => [
            'Pending'  => 0,
            'Paid'     => 1,
            'Released' => 2
        ],
        'TENDER_CONTRACTS' => [
            1 => ['label' => 'Active',  'badge' => 'bg-label-info',    'text-class' => 'info'],
            2 => ['label' => 'Completes',      'badge' => 'bg-label-success', 'text-class' => 'success'],
            4 => ['label' => 'Terminated',    'badge' => 'bg-label-danger',  'text-class' => 'danger'],
        ],
    ];

    public const PRODUCTION = [
        'PRODUCTION_FLOW_STATUS' => [
            0 => ['label' => 'Not Started', 'badge' => 'bg-label-secondary'],
            1 => ['label' => 'Material Requested', 'badge' => 'bg-label-warning'],
            2 => ['label' => 'Material Issued', 'badge' => 'bg-label-primary'],
            4 => ['label' => 'Production Started', 'badge' => 'bg-label-info'],
            5 => ['label' => 'On Hold', 'badge' => 'bg-label-danger'],
            6 => ['label' => 'Production Resumed', 'badge' => 'bg-label-primary'],
            7 => ['label' => 'Production Completed', 'badge' => 'bg-label-success'],
            8 => ['label' => 'FG Transferred', 'badge' => 'bg-label-success'],
            9 => ['label' => 'Closed', 'badge' => 'bg-label-dark'],
            10 => ['label' => 'Cancelled', 'badge' => 'bg-label-dark']
        ],

        'PRODUCTION_STOP_REASON' => [
            1 => ['label' => 'Machine Breakdown'],
            2 => ['label' => 'Raw Material Issue'],
            4 => ['label' => 'Manpower Issue'],
            5 => ['label' => 'Quality Issue'],
            6 => ['label' => 'Power Failure'],
            7 => ['label' => 'Management Decision'],
            8 => ['label' => 'Other']
        ],
        'PRODUCTION_ACTION_TYPE' => [
            1 => 'Plan Created',
            2 => 'Material Requested',
            3 => 'Plan Accepted',
            4 => 'Material Issued',
            5 => 'Production Started',
            6 => 'Production Stopped',
            7 => 'Production Resumed',
            8 => 'Production Completed',
            9 => 'FG Transferred',
            10 => 'Production Closed',
            11 => 'Production Cancelled'
        ],
        'PRODUCTION_ACTION_TYPE_LABEL' => [
            'PlanCreated' => 1,
            'MaterialRequested' => 2,
            'PlanAccepted' => 3,
            'MaterialIssued' => 4,
            'ProductionStarted' => 5,
            'ProductionStopped' => 6,
            'ProductionResumed' => 7,
            'ProductionCompleted' => 8,
            'FGTransferred' => 9,
            'ProductionClosed' => 10,
            'ProductionCancelled' => 11
        ],
        'PRODUCTION_PROCESS_STATE' => [
            0 => ['label' => 'Inactive'],
            1 => ['label' => 'Active'],
            2 => ['label' => 'Paused'],
            4 => ['label' => 'Stopped']
        ],
        'PRODUCTION_UPDATE_TYPE' => [
            1 => 'Minor Update',
            2 => 'Major Update'
        ]

    ];

    public const BMR_TEMPLATE = [
        'SECTION_TYPE' => [
            1 => ['label' => 'Normal Block', 'badge' => 'bg-label-secondary'],
            2 => ['label' => 'Table', 'badge' => 'bg-label-warning'],
            3 => ['label' => 'Static Text', 'badge' => 'bg-label-primary']
        ],
        'SECTION_TYPE_LABEL' => [
            'NormalBlock' => 1,
            'Table' => 2,
            'StaticText' => 3
        ],

        'FIELD_TYPE' => [
            1 => ['label' => 'Text'],
            2 => ['label' => 'Number'],
            3 => ['label' => 'Date'],
            4 => ['label' => 'Time'],
            5 => ['label' => 'Textarea']
        ],
        'FIELD_TYPE_LABEL' => [
            'Text' => 1,
            'Number' => 2,
            'Date' => 3,
            'Time' => 4,
            'Textarea' => 5
        ],

        'FIELD_REQUIRED' => [
            0 => 'Optional',
            1 => 'Required'
        ],

        'CELL_TYPE' => [
            1 => ['label' => 'Label'],
            2 => ['label' => 'User Input'],
            3 => ['label' => 'Static Value']
        ],
        'CELL_TYPE_LABEL' => [
            'Label' => 1,
            'UserInput' => 2,
            'StaticValue' => 3
        ]
    ];

    public const CRM_LEAD = [
        'STATUS' => [
            'New' => ['label' => 'New', 'badge' => 'bg-label-info'],
            'Contacted' => ['label' => 'Contacted', 'badge' => 'bg-label-primary'],
            'Qualified' => ['label' => 'Qualified', 'badge' => 'bg-label-warning'],
            'Unqualified' => ['label' => 'Unqualified', 'badge' => 'bg-label-secondary'],
            'Converted' => ['label' => 'Converted', 'badge' => 'bg-label-success'],
            'Lost' => ['label' => 'Lost', 'badge' => 'bg-label-danger']
        ],
        'ACCEPTANCE_STATUS' => [
            'Pending' => ['label' => 'Pending', 'badge' => 'bg-label-warning'],
            'Accepted' => ['label' => 'Accepted', 'badge' => 'bg-label-success'],
            'Rejected' => ['label' => 'Rejected', 'badge' => 'bg-label-danger']
        ],
        'PRIORITY' => [
            'Low' => ['label' => 'Low', 'badge' => 'bg-label-secondary'],
            'Medium' => ['label' => 'Medium', 'badge' => 'bg-label-warning'],
            'High' => ['label' => 'High', 'badge' => 'bg-label-danger']
        ],
        'CUSTOMER_TYPES' => [
            'Distributor', 'Dealer', 'Hospital', 'Lab', 'Institution', 'Other'
        ],
        'SOURCES' => [
            'quiz' => ['label' => 'Quiz Lead', 'badge' => 'bg-label-info'],
            'whatsapp' => ['label' => 'WhatsApp', 'badge' => 'bg-label-success'],
            'email' => ['label' => 'Email', 'badge' => 'bg-label-warning'],
            'generate_code' => ['label' => 'Generate Code', 'badge' => 'bg-label-primary'],
            'request_api' => ['label' => 'Request API', 'badge' => 'bg-label-primary'],
            'become_partner' => ['label' => 'Become Partner', 'badge' => 'bg-label-primary'],
            'website_form' => ['label' => 'Website Form', 'badge' => 'bg-label-primary'],
            'meeting' => ['label' => 'Meeting Request', 'badge' => 'bg-label-info'],
            'manual' => ['label' => 'Manual Entry', 'badge' => 'bg-label-secondary']
        ]
    ];

    public const CRM_QUOTE = [
        'STATUS' => [
            'draft' => ['label' => 'Draft', 'badge' => 'bg-label-secondary'],
            'generated' => ['label' => 'Generated', 'badge' => 'bg-label-info'],
            'sent' => ['label' => 'Sent', 'badge' => 'bg-label-primary'],
            'accepted' => ['label' => 'Accepted', 'badge' => 'bg-label-success'],
            'rejected' => ['label' => 'Rejected', 'badge' => 'bg-label-danger'],
            'expired' => ['label' => 'Expired', 'badge' => 'bg-label-dark']
        ]
    ];

}
?>
