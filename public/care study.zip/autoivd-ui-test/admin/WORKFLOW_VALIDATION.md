# Production Workflow Validation

## Preserved Rules

- Keep product-configured BMR/BPR document counts and mappings.
- Keep the existing Sample Advice approval dependency, including checks at controlled FG completion and release.
- Do not add Hold or Under Investigation states.

## Controlled Flow

1. Route an insufficient-stock order to Production, review its pre-filled plan, and submit it; or create a manual Production Plan.
2. Open the accepted plan in Material Requisition and generate its approved BOM.
3. Stores issues the required materials against that requisition. Partial issuance does not queue Quality documents.
4. Complete issuance automatically submits the linked BMR/BPR request to QA, with configured document counts snapshotted.
5. QA reviews the plan, requisition, material quantities and material batch references before issuing documents.
6. Complete every BMR and approve the IP COA before opening a BPR. Empty forms, missing template profiles and declared required fields block document submission.
7. Complete every configured BPR and approve the FG COA before transfer. Transfer quantity cannot exceed the approved batch.
8. Stores receipt rechecks current approval, documentation, batch identity and quantity before adding available stock.

Standalone legacy requisition, issuance and transfer writes are disabled. Historical records remain available for viewing. Product and batch values are locked to their source records, and production plan edits are blocked after requisition starts. Production screens no longer link to commercial orders.

The controlled runtime flow does not auto-migrate or rewrite historical business records. Template installers are listed below and must be run explicitly.

## Local Checks

```text
php admin/tests/careio_production_quality_flow_contract_test.php
php admin/tests/ada_careio_workflow_smoke.php
php admin/tests/procurement_flow_contract_test.php
php admin/tests/erp_submission_bindings_test.php
php admin/tests/order_product_identity_contract_test.php
node admin/tests/production_workflow_client_test.js --check-fixtures
```

The PHP contract tests use pure functions and source checks; they do not submit business records. The client test also renders nine pages using stub permissions and a mock connection, including Production BMR/BPR and both COA screens. It exercises both COA template loaders for loading, missing mappings, failed requests and stale responses. Its fixture checks fail if the database bootstrap is included.

## ADA Template Installation

```text
php admin/migrations/seed_common_structured_biochemistry_bmr_bpr.php
php admin/migrations/seed_ada_pack_size_bmr_bpr_templates.php
php admin/migrations/seed_ada_careio_coa_templates.php
```

The installers are transactional and idempotent. The ADA pack-size installer preserves the existing product-level mappings as fallback. Approved 15 mL, 30 mL and 100 mL variants resolve two distinct manufacturing records (R1 and R2) and one pack-specific BPR. Packs without an override retain the original configured BMR/BPR behavior. The ADA COA installer records the applicable approved-specification results required by the supplied workflow without introducing unsupported numeric limits.

Optional isolated browser server:

```text
node admin/tests/production_workflow_client_test.js --serve
```

The server listens on localhost port 8096 (override with `WORKFLOW_PREVIEW_PORT`). It is a test preview, not the deployed application. Browser automation supplies synthetic AJAX responses; unmocked writes return a fixture-only error.

## Verification Boundary

The changed screens were checked at desktop and mobile sizes using synthetic data. Read helpers and permission names were checked against the installed schema in a read-only transaction. The database refuses preparation of write/locking statements in read-only mode, so actual write transactions still need a staging database and authorized end-to-end testing. Do not run the existing record-creating smoke tests against production to fill this gap.

Template completeness checks enforce non-empty content and fields declared as required by the template layout. They do not infer additional product-specific mandatory fields that are not defined in the template configuration.

## September 16 Read-Only Findings

The supplied six-page production/quality workflow was reviewed. No database records, approval decisions, inventory quantities or template mappings were changed during this audit. No credentials are recorded here.

- Both manufacturing and COA schema readiness checks pass.
- There are no active manufacturing work items or issued requisitions available to enter the controlled workflow. The one non-deleted request is Upcoming and references a deleted requisition. Empty incoming queues therefore do not demonstrate a queue-loading failure.
- Existing IP/FG records are legacy records without controlled manufacturing links or saved structured templates. They cannot substitute for approved certificates in a new controlled batch.
- All inspected active mapping profiles are valid: 304 BMR document mappings, 200 BPR document mappings, 126 IP mappings and 126 FG mappings. These are mapping counts, not unique product counts.
- Coverage is incomplete: 76 non-deleted manufacturing products with BMR mappings lack IP mappings, and 75 with BPR mappings lack FG mappings. A valid profile in one stage does not establish readiness for the entire flow.

### Local Fixes

- Packing actions and the production queue now check the configured BMR count as well as completion status. Requests without approved issuance cannot open or update work items. The missing-document regression was reproduced before the fix; no existing approved request currently exhibits that defect.
- Both COA screens disable submission while their mapped template is loading or unavailable. Missing mappings now display a persistent, type-specific error instead of closing the IP form or falling back to an unusable basic FG form. Initial incoming counters no longer show a fabricated count.
- Regression checks cover configured document counts and both COA template loaders. All nine isolated pages render and their scripts compile. The production, product-template, procurement and submission-binding contract checks pass.

### Remaining Verification

1. Quality must supply or confirm approved IP/FG specifications and mappings for the uncovered products. Do not copy unrelated product limits or fabricate approval decisions to unblock a batch.
2. Use an isolated staging database for a new batch: reviewed plan, BOM generation, complete material issuance, QA document issuance, BMR and IP approval, BPR and FG approval, automatic pending transfer, then Stores receipt. Test both completion orders for the parallel BPR/FG gate, rejection, duplicate submission and quantity limits.
3. Repeat authenticated browser interaction checks. Isolated page-load checks completed without JavaScript errors once reference-data mocks used the real response shapes; the interactive modal handoff remained stuck in a Bootstrap transition in the integrated browser and was not verified.
4. Deploy the local code changes through the normal release process after staging acceptance. This audit did not deploy the application or certify live write transactions.
