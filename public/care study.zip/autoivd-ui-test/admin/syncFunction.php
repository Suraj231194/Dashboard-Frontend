<?php
require_once __DIR__ . '/common/Time.php';
mvConfigurePhpTimezone();
require_once 'constant.php';
require_once "functions.php";
require_once "syncRealtime.php";

function syncCategories()
{
    global $conn, $webConn;

    $insertedERP = 0;
    $updatedERP  = 0;
    $insertedWEB = 0;
    $updatedWEB  = 0;

    // Website -> ERP
    $webResult = $webConn->query("SELECT * FROM `categories`");
    while ($cat = $webResult->fetch_assoc()) { 
        $result = syncCategoryWebsiteToERPData($cat);
        if($result=='insert'){
            $insertedERP++;
        }
        if($result=='update'){
            $updatedERP++;
        }
    }

    // ERP -> Website
    $erpResult = $conn->query("SELECT * FROM `product_categories` WHERE `website_sync` = 1");
    while ($cat = $erpResult->fetch_assoc()) {
        $result = syncCategoryERPToWebsiteData($cat);
        if($result=='insert'){
            $insertedWEB++;
        }
        if($result=='update'){
            $updatedWEB++;
        }
    }

    return [
        'status' => true,
        'website_to_erp' => [
            'insert' => $insertedERP,
            'update' => $updatedERP
        ],
        'erp_to_website' => [
            'insert' => $insertedWEB,
            'update' => $updatedWEB
        ]
    ];
}


function syncSubCategories()
{
    global $conn, $webConn;
    $insertedERP = 0;
    $updatedERP  = 0;
    $insertedWEB = 0;
    $updatedWEB  = 0;

    // Website Categories Mapping slug => id   
    $webCategoryMap = [];
    $result = $webConn->query("SELECT `id`, `slug` FROM `categories`");
    while ($row = $result->fetch_assoc()) {
        $webCategoryMap[$row['slug']] = (int)$row['id'];
    }

    // ERP Categories Mapping slug => id
    $erpCategoryMap = [];
    $result = $conn->query("SELECT `id`, `slug` FROM `product_categories`");
    while ($row = $result->fetch_assoc()) {
        $erpCategoryMap[$row['slug']] = (int)$row['id'];
    }

    // WEBSITE -> ERP    
    $webResult = $webConn->query("SELECT * FROM `subcategories`");

    while ($sub = $webResult->fetch_assoc()) {
        $result = syncSubCategoryWebsiteToERPData($sub);
        if($result == 'insert') $insertedERP++;
        if($result == 'update') $updatedERP++;
    }
    
    // ERP -> WEBSITE    
    $erpResult = $conn->query("SELECT * FROM `product_subcategories` WHERE `website_sync` = 1");
    while ($sub = $erpResult->fetch_assoc()) {
        $result = syncSubCategoryERPToWebsiteData($sub);
        if($result == 'insert') $insertedWEB++;
        if($result == 'update') $updatedWEB++;
        
    }

    return [
        'status' => true,
        'website_to_erp' => [
            'insert' => $insertedERP,
            'update' => $updatedERP
        ],
        'erp_to_website' => [
            'insert' => $insertedWEB,
            'update' => $updatedWEB
        ]
    ];
}


function syncSubCategoriesBkp()
{
    global $conn, $webConn;

    $insertedERP = 0;
    $updatedERP  = 0;
    $insertedWEB = 0;
    $updatedWEB  = 0;

    // Website Categories Mapping slug => id
    $webCategoryMap = [];
    $result = $webConn->query("SELECT `id`, `slug` FROM `categories`");
    while ($row = $result->fetch_assoc()) {
        $webCategoryMap[$row['slug']] = (int)$row['id'];
    }

    // ERP Categories Mapping slug => id
    $erpCategoryMap = [];
    $result = $conn->query("SELECT id, slug FROM product_categories");
    while ($row = $result->fetch_assoc()) {
        $erpCategoryMap[$row['slug']] = (int)$row['id'];
    }
    
    // WEBSITE -> ERP
    $webResult = $webConn->query("SELECT * FROM subcategories");

    while ($sub = $webResult->fetch_assoc()) {

        // Website category slug
        $categorySlug = array_search((int)$sub['category_id'], $webCategoryMap);

        if (!$categorySlug || !isset($erpCategoryMap[$categorySlug])) {
            continue;
        }

        $erpCategoryId = $erpCategoryMap[$categorySlug];
        $slug = $conn->real_escape_string($sub['slug']);

        $check = $conn->query("SELECT `id` FROM `product_subcategories`
            WHERE `category_id` = '$erpCategoryId'
            AND `slug` = '$slug'
        ");

        if ($check->num_rows > 0) {

                    // default_image_path=".$($sub['default_image_path']
                    //         ? "'".$conn->real_escape_string($sub['default_image_path'])."'"
                    //         : "NULL"
                    // ).",

            $conn->query("UPDATE `product_subcategories` SET
                    `name` = '".$conn->real_escape_string($sub['name'])."',
                    
                    `sort_order`='".(int)$sub['sort_order']."',
                    `updated_at` = NOW()
                WHERE `category_id` = '$erpCategoryId'
                AND `slug` = '$slug'
            ");

            $updatedERP++;

        } else {

            $conn->query("
                INSERT INTO product_subcategories
                (
                    category_id,
                    name,
                    slug,
                    default_image_path,
                    sort_order,
                    website_sync,
                    created_at
                )
                VALUES
                (
                    '$erpCategoryId',
                    '".$conn->real_escape_string($sub['name'])."',
                    '$slug',
                    ".(
                        $sub['default_image_path']
                            ? "'".$conn->real_escape_string($sub['default_image_path'])."'"
                            : "NULL"
                    ).",
                    '".(int)$sub['sort_order']."',
                    '1',
                    NOW()
                )
            ");

            $insertedERP++;
        }
    }

    
    // ERP -> WEBSITE    
    // $erpResult = $conn->query("SELECT * FROM product_subcategories WHERE website_sync=1");

    // while ($sub = $erpResult->fetch_assoc()) {

    //     // ERP category slug
    //     $categorySlug = array_search((int)$sub['category_id'], $erpCategoryMap);

    //     if (!$categorySlug || !isset($webCategoryMap[$categorySlug])) {
    //         continue;
    //     }

    //     $webCategoryId = $webCategoryMap[$categorySlug];
    //     $slug = $webConn->real_escape_string($sub['slug']);

    //     $check = $webConn->query("
    //         SELECT id
    //         FROM subcategories
    //         WHERE category_id='$webCategoryId'
    //         AND slug='$slug'
    //     ");

    //     if ($check->num_rows > 0) {

    //         $webConn->query("
    //             UPDATE subcategories SET
    //                 name='".$webConn->real_escape_string($sub['name'])."',
    //                 default_image_path=".$(
    //                     $sub['default_image_path']
    //                         ? "'".$webConn->real_escape_string($sub['default_image_path'])."'"
    //                         : "NULL"
    //                 ).",
    //                 sort_order='".(int)$sub['sort_order']."',
    //                 updated_at=NOW()
    //             WHERE category_id='$webCategoryId'
    //             AND slug='$slug'
    //         ");

    //         $updatedWEB++;

    //     } else {

    //         $webConn->query("
    //             INSERT INTO subcategories
    //             (
    //                 category_id,
    //                 name,
    //                 slug,
    //                 default_image_path,
    //                 sort_order,
    //                 created_at,
    //                 updated_at
    //             )
    //             VALUES
    //             (
    //                 '$webCategoryId',
    //                 '".$webConn->real_escape_string($sub['name'])."',
    //                 '$slug',
    //                 ".(
    //                     $sub['default_image_path']
    //                         ? "'".$webConn->real_escape_string($sub['default_image_path'])."'"
    //                         : "NULL"
    //                 ).",
    //                 '".(int)$sub['sort_order']."',
    //                 NOW(),
    //                 NOW()
    //             )
    //         ");

    //         $insertedWEB++;
    //     }
    // }

    return [
        'status' => true,
        'website_to_erp' => [
            'insert' => $insertedERP,
            'update' => $updatedERP
        ],
        'erp_to_website' => [
            'insert' => $insertedWEB,
            'update' => $updatedWEB
        ]
    ];
}

function syncCategoriesBkp()
{
    global $conn, $webConn;

    $insertedERP = 0;
    $updatedERP  = 0;
    $insertedWEB = 0;
    $updatedWEB  = 0;

    // Website -> ERP
    $webResult = $webConn->query("SELECT * FROM categories");

    while ($cat = $webResult->fetch_assoc()) {
        

        $slug = $conn->real_escape_string($cat['slug']);

        $check = $conn->query("SELECT `id` FROM `product_categories` WHERE `slug` = '$slug'");

        if ($check->num_rows) {
            $conn->query("UPDATE `product_categories` SET
                `name`='".$conn->real_escape_string($cat['name'])."',
                `sort_order`='".(int)$cat['sort_order']."',
                `status`='1',
                `updated_at` = NOW()
                WHERE `slug` = '$slug'");
            $updatedERP++;
        } else {
            $conn->query("INSERT INTO `product_categories`
                (`name`, `slug`, `sort_order`, `status`, `website_sync`, `created_at`)
                VALUES
                (
                    '".$conn->real_escape_string($cat['name'])."',
                    '$slug',
                    '".(int)$cat['sort_order']."',
                    '1',
                    '1',
                    NOW()
                )");
            $insertedERP++;
        }
    }

    // ERP -> Website
    $erpResult = $conn->query("SELECT * FROM `product_categories` WHERE `website_sync` = 1");

    while ($cat = $erpResult->fetch_assoc()) {

        $slug = $webConn->real_escape_string($cat['slug'] ?? '');

        $check = $webConn->query("SELECT id FROM categories WHERE slug='$slug'");

        if ($check->num_rows) {

            $webConn->query("UPDATE categories SET
                name='".$webConn->real_escape_string($cat['name'])."',
                sort_order='".(int)$cat['sort_order']."',
                updated_at=NOW()
                WHERE slug='$slug'");

            $updatedWEB++;

        } else {

            $webConn->query("INSERT INTO categories
                (name, slug, sort_order, gst_rate, IsDisplayedOnHomePage, created_at)
                VALUES
                (
                    '".$webConn->real_escape_string($cat['name'])."',
                    '$slug',
                    '".(int)$cat['sort_order']."',
                    '18',
                    '0',
                    NOW()
                )");

            $insertedWEB++;
        }

    }

    return [
        'status' => true,
        'website_to_erp' => [
            'insert' => $insertedERP,
            'update' => $updatedERP
        ],
        'erp_to_website' => [
            'insert' => $insertedWEB,
            'update' => $updatedWEB
        ]
    ];
}
?>
