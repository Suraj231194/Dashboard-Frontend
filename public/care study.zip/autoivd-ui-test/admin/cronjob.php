<?php
session_start();
require_once "db.php";
include "functions.php";

if (isset($_GET['rapidpdf'])) {

    $query = 'SELECT * FROM `production_entries` WHERE DATE(created_at) = CURDATE()';
    $result = $conn->query($query);

    if (!$result) {
        http_response_code(500);
        echo json_encode(['error' => 'Database query failed']);
        exit;
    }

    $entryIds = [];
    $totalManPower = 0;
    $totalWorkingHours = 0;
    $data = ["action" => "generatePdf"];

    while ($row = $result->fetch_assoc()) {
        $entryIds[] = (int)$row['id']; // typecast to prevent injection
        $totalManPower += (int)$row['total_man_power'];
        $totalWorkingHours += (int)$row['total_working_hours'];

        // Assuming all entries are for the same date/month
        $data['date'] = $row['entry_date'];
        $data['monthYear'] = $row['month_year'];
    }

    if (!empty($entryIds)) {
        $data['totalManPower'] = $totalManPower;
        $data['totalWorkingHours'] = $totalWorkingHours;

        // Get all related particulars
        $idList = implode(',', $entryIds);
        $particularsQuery = "SELECT * FROM `production_particulars` WHERE production_entry_id IN ($idList) ORDER BY id";
        $particularsResult = $conn->query($particularsQuery);

        if (!$particularsResult) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to fetch particulars']);
            exit;
        }

        $particulars = [];
        while ($p = $particularsResult->fetch_assoc()) {
            $particulars[] = [
                'particular'       => $p['particular'],
                'filledBy'         => $p['filled_by'],
                'product'          => $p['product'],
                'departmentValues' => $p['department'],
                'totalYield'       => $p['total_yield'],
                'qtyUnit'          => $p['qty_unit'],
                'manPower'         => $p['man_power'],
            ];
        }
        $data['particulars'] = $particulars;

        $endpoint = 'https://script.google.com/a/macros/biogenix.in/s/AKfycbwcQhjaEh9mbL8hE11f82yLKsr7ovMlkJm7vrrboqqSYacf5Ye2BCq5FTaRPVsCFbek/exec';

        $ch = curl_init($endpoint);

        // Configure cURL options
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);

        // Handle errors
        if (curl_errno($ch)) {
            echo 'Error: ' . curl_error($ch);
        }

        curl_close($ch);
        echo json_encode(['message' => 'Pdf Generated Successfully.']);
    } else {
        echo json_encode(['message' => 'No production entries found for today.']);
    }
}

if (isset($_GET['cronProductReorderAlert'])) {
    cronProductReorder($conn);
    exit();
}

if (isset($_GET['calendarReminders'])) {
    header('Content-Type: application/json');
    $created = cronCalendarReminders($conn);
    $created += cronFinanceDueDateReminders($conn);
    $created += cronTenderDueDateReminders($conn);
    echo json_encode([
        'status' => 'success',
        'notifications_created' => $created,
    ]);
    exit();
}

// ── Email Order Processing ──
// Trigger: ?processEmailOrders (optional: &test, &dryrun)
if (isset($_GET['processEmailOrders'])) {
    require_once __DIR__ . '/cron_email_orders.php';
    exit();
}
