<div class="container-xxl flex-grow-1 container-p-y flex flex-col justify-center min-h-[calc(100vh-10rem)]">
    <div class="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16 w-full max-w-4xl mx-auto py-10 px-4">
        
        <!-- Image Side -->
        <div class="flex-shrink-0 relative animate__animated animate__zoomIn">
            <div class="absolute inset-0 bg-emerald-100/50 rounded-full blur-3xl transform scale-110 -z-10"></div>
            <img src="<?= asset('assets/img/illustrations/page-misc-error.png'); ?>" alt="page-misc-error" class="w-56 md:w-80 object-contain drop-shadow-2xl" style="animation: bounce 3s infinite;" />
        </div>
        
        <!-- Text Side -->
        <div class="flex flex-col items-center md:items-start text-center md:text-left">
            <h4 class="text-rose-500 font-bold tracking-widest uppercase mb-2 text-sm"><?= $pageTitle ?></h4>
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-800 mb-4 font-['Sora'] tracking-tight">
                Page Not Found :(
            </h2>
            <p class="text-lg text-slate-500 mb-8 max-w-sm leading-relaxed">
                Oops! 😖 The requested URL was not found on this server.
            </p>
            <a href="index.php" class="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-14 min-w-[240px] text-base font-bold text-white shadow-lg shadow-emerald-600/30 transition-all hover:-translate-y-1 hover:bg-emerald-700 hover:shadow-xl focus:outline-none">
                <i class="ti ti-arrow-left text-lg"></i>
                Back to Dashboard
            </a>
        </div>

    </div>
</div>

<?php startSection('scripts'); ?>
<script>
    // Write your script here
</script>
<?php endSection(); ?>
