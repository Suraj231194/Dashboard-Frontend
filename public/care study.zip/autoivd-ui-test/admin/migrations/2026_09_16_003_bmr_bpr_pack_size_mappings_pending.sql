-- Optional pack-size override for BMR/BPR document requirements.
-- Product-level mappings remain the fallback when no active pack rule exists.

CREATE TABLE IF NOT EXISTS `bmr_template_pack_size_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` bigint(20) NOT NULL,
  `product_id` int(11) NOT NULL,
  `pack_size_key` varchar(64) NOT NULL,
  `pack_size_label` varchar(191) NOT NULL,
  `form_type` enum('BMR','BPR') NOT NULL,
  `document_sequence` int(11) NOT NULL DEFAULT 1,
  `required_quantity` int(11) NOT NULL DEFAULT 1,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bmr_pack_document` (`product_id`,`pack_size_key`,`form_type`,`document_sequence`),
  KEY `idx_bmr_pack_template` (`template_id`),
  KEY `idx_bmr_pack_lookup` (`product_id`,`pack_size_key`,`status`,`deleted_at`),
  CONSTRAINT `fk_bmr_pack_template` FOREIGN KEY (`template_id`) REFERENCES `bmr_templates` (`id`),
  CONSTRAINT `fk_bmr_pack_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
