CREATE TABLE IF NOT EXISTS `user_appearance_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `theme_mode` enum('light', 'dark', 'auto') NOT NULL DEFAULT 'light',
  `accent_color` char(7) NOT NULL DEFAULT '#1A4D2E',
  `font_family` enum('Manrope', 'Inter', 'Roboto') NOT NULL DEFAULT 'Manrope',
  `base_font_size` tinyint(3) unsigned NOT NULL DEFAULT 15,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_appearance_settings_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
