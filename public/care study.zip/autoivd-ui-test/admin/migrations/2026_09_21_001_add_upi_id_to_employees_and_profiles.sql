-- Migration: 2026_09_21_001_add_upi_id_to_employees_and_profiles.sql
-- Description: Add upi_id column to employees and hr_employee_profiles for UPI payment mode support

ALTER TABLE `employees`
ADD COLUMN IF NOT EXISTS `upi_id` VARCHAR(100) NULL AFTER `bank_account_type`;

ALTER TABLE `hr_employee_profiles`
ADD COLUMN IF NOT EXISTS `upi_id` VARCHAR(100) NULL AFTER `payment_mode`;
