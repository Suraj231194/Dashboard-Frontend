-- Keep every procurement inventory group on the unified inbound-quality flow.
ALTER TABLE `coa_inbound_queue`
    MODIFY COLUMN `goods_type` ENUM('RM','PM','FG','CON') NOT NULL DEFAULT 'RM' COMMENT 'Auto-filled from product inventory group; editable';

ALTER TABLE `coa_rm_pm_table`
    MODIFY COLUMN `type` ENUM('RM','PM','FG','CON') NOT NULL DEFAULT 'RM';

UPDATE `coa_inbound_queue` queue_item
INNER JOIN `products` product ON product.`id` = queue_item.`product_id`
LEFT JOIN `product_categories` category ON category.`id` = product.`category_id`
SET queue_item.`goods_type` = CASE COALESCE(product.`inventory_group`, category.`inventory_group`, 3)
    WHEN 1 THEN 'FG'
    WHEN 2 THEN 'PM'
    WHEN 4 THEN 'CON'
    ELSE 'RM'
END
WHERE queue_item.`status` = 0;

-- Existing pending-QC receipts are quarantined. Approved receipts remain available.
UPDATE `live_stock` stock
INNER JOIN `coa_inbound_queue` queue_item ON queue_item.`stock_inward_id` = stock.`stock_inward_id`
SET stock.`quantity_available` = 0,
    stock.`status` = 0,
    stock.`updated_at` = NOW()
WHERE queue_item.`status` = 0
  AND stock.`deleted_at` IS NULL;

UPDATE `live_stock` stock
INNER JOIN `coa_rm_pm_table` coa ON coa.`stock_inward_id` = stock.`stock_inward_id`
SET stock.`quantity_available` = stock.`quantity_initial`,
    stock.`status` = 1,
    stock.`updated_at` = NOW()
WHERE coa.`coa_approval_status` = 1
  AND coa.`deleted_at` IS NULL
  AND stock.`deleted_at` IS NULL;

-- Close procurement requests whose linked PO item is already completely received.
UPDATE `low_stocks` request
INNER JOIN `purchase_order_final` item ON item.`low_stock_id` = request.`id`
SET request.`status` = 2,
    request.`updated_at` = NOW()
WHERE item.`status` IN (2, 4)
  AND item.`deleted_at` IS NULL
  AND request.`deleted_at` IS NULL;

UPDATE `low_stocks` request
INNER JOIN `purchase_order_raw_items` item ON item.`low_stock_id` = request.`id`
SET request.`status` = 2,
    request.`updated_at` = NOW()
WHERE item.`status` IN (2, 4)
  AND item.`deleted_at` IS NULL
  AND request.`deleted_at` IS NULL;
