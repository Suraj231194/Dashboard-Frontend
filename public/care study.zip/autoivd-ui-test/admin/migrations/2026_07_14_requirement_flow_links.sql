ALTER TABLE `stock_inwards` ADD COLUMN `invoice_file` varchar(255) DEFAULT NULL AFTER `remark`;
ALTER TABLE `stock_inwards` ADD COLUMN `po_id` int(11) DEFAULT NULL AFTER `invoice_file`;
ALTER TABLE `stock_inwards` ADD COLUMN `po_type` enum('RM','PM') DEFAULT NULL AFTER `po_id`;

ALTER TABLE `purchase_order_raw_items` ADD COLUMN `low_stock_id` int(11) DEFAULT NULL AFTER `created_by`;
ALTER TABLE `low_stocks` ADD COLUMN `order_id` int(11) DEFAULT NULL AFTER `procurement_source`;
ALTER TABLE `coa_rm_pm_table` ADD COLUMN `stock_inward_id` int(11) DEFAULT NULL AFTER `id`;

CREATE INDEX `idx_low_stocks_order_id` ON `low_stocks` (`order_id`);
CREATE INDEX `idx_coa_rm_pm_stock_inward_id` ON `coa_rm_pm_table` (`stock_inward_id`);