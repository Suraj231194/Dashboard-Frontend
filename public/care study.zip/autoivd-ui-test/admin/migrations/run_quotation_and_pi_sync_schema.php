<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_08_09_quotation_and_pi_sync_schema_pending.sql';
$sql = file_get_contents($migrationPath);

if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "The Quotation & PI sync schema migration file is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

do {
    if ($result = $conn->store_result()) {
        $result->free();
    }

    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
} while ($conn->more_results() && $conn->next_result());

if ($conn->errno !== 0) {
    fwrite(STDERR, 'Migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

echo "Quotation & PI sync schema expansion successfully applied to database.\n";
