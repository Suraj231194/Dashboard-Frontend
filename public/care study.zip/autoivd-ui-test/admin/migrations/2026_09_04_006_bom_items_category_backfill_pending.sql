-- =============================================================================
-- Migration: 2026_09_04_006_bom_items_category_backfill_pending.sql
-- Purpose: BOM component category backfill from product master
-- Standard: Idempotent, non-destructive
-- =============================================================================

UPDATE `bom_items` AS `item`
INNER JOIN `products` AS `component`
        ON `component`.`id` = `item`.`raw_product_id`
SET `item`.`raw_product_category_id` = `component`.`category_id`,
    `item`.`updated_at` = NOW()
WHERE (`item`.`raw_product_category_id` IS NULL OR `item`.`raw_product_category_id` = 0)
  AND COALESCE(`component`.`category_id`, 0) > 0
  AND `item`.`deleted_at` IS NULL;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_006_bom_items_category_backfill_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_006_bom_items_category_backfill_pending.sql', '2026_09_04_006_bom_items_category_backfill.sql')
);
