-- Production hardening for Annual Calendar & Working Days.
-- Company is the authoritative calendar scope; branches inherit their company calendar.

ALTER TABLE `hr_annual_calendars`
    MODIFY COLUMN `saturday_policy` ENUM('all_working','all_off','2nd_4th_off','alternate_off','custom') NOT NULL DEFAULT 'all_working',
    ADD COLUMN IF NOT EXISTS `revision_no` SMALLINT UNSIGNED NOT NULL DEFAULT 1 AFTER `calendar_year`,
    ADD COLUMN IF NOT EXISTS `lifecycle_status` ENUM('draft','finalized','superseded') NOT NULL DEFAULT 'draft' AFTER `saturday_policy`,
    ADD COLUMN IF NOT EXISTS `supersedes_id` INT DEFAULT NULL AFTER `lifecycle_status`,
    ADD COLUMN IF NOT EXISTS `content_hash` CHAR(64) DEFAULT NULL AFTER `supersedes_id`,
    ADD COLUMN IF NOT EXISTS `lock_version` INT UNSIGNED NOT NULL DEFAULT 1 AFTER `content_hash`,
    ADD COLUMN IF NOT EXISTS `source_name` VARCHAR(120) DEFAULT NULL AFTER `lock_version`,
    ADD COLUMN IF NOT EXISTS `source_version` VARCHAR(60) DEFAULT NULL AFTER `source_name`;

UPDATE `hr_annual_calendars`
SET `lifecycle_status` = CASE WHEN `is_finalized` = 1 THEN 'finalized' ELSE 'draft' END
WHERE `lifecycle_status` IS NULL
   OR (`is_finalized` = 1 AND `lifecycle_status` = 'draft');

ALTER TABLE `hr_annual_calendars`
    DROP INDEX IF EXISTS `uq_company_year`,
    ADD UNIQUE INDEX IF NOT EXISTS `uq_ac_company_year_revision` (`company_id`, `calendar_year`, `revision_no`),
    ADD INDEX IF NOT EXISTS `idx_ac_authoritative` (`company_id`, `calendar_year`, `lifecycle_status`, `is_finalized`, `status`),
    ADD INDEX IF NOT EXISTS `idx_ac_supersedes` (`supersedes_id`);

ALTER TABLE `hr_annual_calendar_holidays`
    ADD COLUMN IF NOT EXISTS `source_name` VARCHAR(120) DEFAULT NULL AFTER `holiday_type`,
    ADD COLUMN IF NOT EXISTS `source_version` VARCHAR(60) DEFAULT NULL AFTER `source_name`,
    ADD COLUMN IF NOT EXISTS `deleted_at` DATETIME DEFAULT NULL AFTER `updated_at`,
    ADD COLUMN IF NOT EXISTS `deleted_by` INT DEFAULT NULL AFTER `deleted_at`,
    DROP INDEX IF EXISTS `uq_calendar_date`,
    ADD UNIQUE INDEX IF NOT EXISTS `uq_ac_holiday_identity` (`calendar_id`, `holiday_date`, `holiday_name`),
    ADD INDEX IF NOT EXISTS `idx_ac_holiday_active` (`calendar_id`, `is_enabled`, `deleted_at`, `holiday_date`);

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_custom_offs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `calendar_id` INT NOT NULL,
    `off_date` DATE NOT NULL,
    `off_name` VARCHAR(150) NOT NULL DEFAULT 'Custom weekly off',
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ac_custom_off` (`calendar_id`, `off_date`),
    KEY `idx_ac_custom_off_date` (`off_date`),
    CONSTRAINT `fk_ac_custom_off_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_days` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `calendar_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `calendar_date` DATE NOT NULL,
    `day_of_week` TINYINT UNSIGNED NOT NULL,
    `day_type` ENUM('working_day','weekly_off','holiday') NOT NULL,
    `is_working` TINYINT(1) NOT NULL,
    `is_weekly_off` TINYINT(1) NOT NULL DEFAULT 0,
    `is_holiday` TINYINT(1) NOT NULL DEFAULT 0,
    `holiday_names` VARCHAR(500) DEFAULT NULL,
    `holiday_types` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ac_day_calendar_date` (`calendar_id`, `calendar_date`),
    KEY `idx_ac_day_company_date` (`company_id`, `calendar_date`, `day_type`),
    CONSTRAINT `fk_ac_day_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_audit_events` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `calendar_id` INT DEFAULT NULL,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `calendar_year` SMALLINT UNSIGNED NOT NULL,
    `revision_no` SMALLINT UNSIGNED NOT NULL,
    `action` VARCHAR(50) NOT NULL,
    `field_changed` VARCHAR(100) DEFAULT NULL,
    `old_value` TEXT DEFAULT NULL,
    `new_value` TEXT DEFAULT NULL,
    `reason` VARCHAR(1000) DEFAULT NULL,
    `before_json` LONGTEXT DEFAULT NULL,
    `after_json` LONGTEXT DEFAULT NULL,
    `request_id` CHAR(32) NOT NULL,
    `changed_by` INT NOT NULL,
    `changed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ac_audit_scope` (`company_id`, `calendar_year`, `revision_no`, `changed_at`),
    KEY `idx_ac_audit_calendar` (`calendar_id`, `changed_at`),
    KEY `idx_ac_audit_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `payroll_runs`
    ADD COLUMN IF NOT EXISTS `calendar_revision_id` INT DEFAULT NULL AFTER `payroll_month`,
    ADD COLUMN IF NOT EXISTS `calendar_hash` CHAR(64) DEFAULT NULL AFTER `calendar_revision_id`,
    ADD COLUMN IF NOT EXISTS `calendar_working_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `calendar_hash`,
    ADD COLUMN IF NOT EXISTS `calendar_weekly_off_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `calendar_working_days`,
    ADD COLUMN IF NOT EXISTS `calendar_holiday_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `calendar_weekly_off_days`,
    ADD INDEX IF NOT EXISTS `idx_payroll_calendar_revision` (`calendar_revision_id`);

ALTER TABLE `payroll_run_items`
    ADD COLUMN IF NOT EXISTS `calendar_working_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `month_days`,
    ADD COLUMN IF NOT EXISTS `eligible_working_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `calendar_working_days`,
    ADD COLUMN IF NOT EXISTS `present_working_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `eligible_working_days`,
    ADD COLUMN IF NOT EXISTS `paid_leave_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `present_working_days`,
    ADD COLUMN IF NOT EXISTS `unpaid_leave_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `paid_leave_days`,
    ADD COLUMN IF NOT EXISTS `lop_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `unpaid_leave_days`,
    ADD COLUMN IF NOT EXISTS `weekly_off_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `lop_days`,
    ADD COLUMN IF NOT EXISTS `holiday_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `weekly_off_days`,
    ADD COLUMN IF NOT EXISTS `off_day_worked_days` DECIMAL(7,2) NOT NULL DEFAULT 0 AFTER `holiday_days`;

ALTER TABLE `hr_leave_application_days`
    ADD COLUMN IF NOT EXISTS `calendar_day_type` ENUM('working_day','weekly_off','holiday') NOT NULL DEFAULT 'working_day' AFTER `leave_date`,
    ADD COLUMN IF NOT EXISTS `is_chargeable` TINYINT(1) NOT NULL DEFAULT 1 AFTER `calendar_day_type`;

ALTER TABLE `hr_attendance_daily`
    MODIFY COLUMN `classification` ENUM('on_time','late','half_day','full_day','absent','incomplete','holiday','weekly_off','off_day_work') NOT NULL DEFAULT 'incomplete';

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT seed.name, seed.slug, 1, 1
FROM (
    SELECT 'HRMS Annual Calendar View' AS name, 'hrms_calendar_view' AS slug
    UNION ALL SELECT 'HRMS Annual Calendar Manage', 'hrms_calendar_manage'
    UNION ALL SELECT 'HRMS Annual Calendar Finalize', 'hrms_calendar_finalize'
    UNION ALL SELECT 'HRMS Annual Calendar Reopen', 'hrms_calendar_reopen'
    UNION ALL SELECT 'HRMS Annual Calendar Export', 'hrms_calendar_export'
) seed
WHERE NOT EXISTS (SELECT 1 FROM `permissions` permission WHERE permission.slug = seed.slug);

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND LOWER(role.name) IN ('human resources','administrator','senior administrator','super administrator')
  AND permission.slug IN ('hrms_calendar_view','hrms_calendar_manage','hrms_calendar_finalize','hrms_calendar_reopen','hrms_calendar_export')
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 1
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND LOWER(role.name) IN ('human resources','administrator','senior administrator','super administrator')
  AND permission.slug IN ('hrms_calendar_view','hrms_calendar_manage','hrms_calendar_finalize','hrms_calendar_reopen','hrms_calendar_export');

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT 'Annual Calendar & Working Days', 'index.php?page=annual-calendar', 'ti ti-calendar-stats', parent.id, 35,
       'hrms_calendar_view', 1, 1, 1, CURRENT_TIMESTAMP
FROM `menus` parent
WHERE parent.deleted_at IS NULL
  AND COALESCE(parent.parent_id, 0) = 0
  AND (parent.permission_slug = 'hr_menu' OR parent.name = 'Human Resources')
  AND NOT EXISTS (
      SELECT 1 FROM `menus` existing
      WHERE existing.route = 'index.php?page=annual-calendar' AND existing.deleted_at IS NULL
  )
ORDER BY parent.id
LIMIT 1;

UPDATE `menus`
SET `permission_slug` = 'hrms_calendar_view', `icon` = 'ti ti-calendar-stats', `showmenu` = 1,
    `status` = 1, `updated_by` = 1, `updated_at` = NOW()
WHERE `route` = 'index.php?page=annual-calendar' AND `deleted_at` IS NULL;
