<?php

declare(strict_types=1);

/**
 * Adds ADA pack-size-specific BMR/BPR templates without replacing the existing
 * product-level mappings. Runtime uses these rules when the pack matches and
 * falls back to the original mappings for every other product/pack.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_biochemistry_profiles.php';

$products = [
    415 => [
        'code' => 'BGX/FIN.BIOC/2026/000001',
        'name' => 'ADA 100 mL',
        'pack_key' => '100ml',
        'pack_label' => '100 mL',
        'formula_date' => '01/07/2022',
        'packing' => 'Plastic Vial Brown 100 mL|1|Nos.;Plastic Vial Brown 30 mL|1|Nos.;'
            . 'Boxes Green 100 mL|1|Nos.;Pack Insert ADA|1|Nos.',
    ],
    417 => [
        'code' => 'BGX/FIN.BIOC/2026/000003',
        'name' => 'ADA 15 mL',
        'pack_key' => '15ml',
        'pack_label' => '15 mL',
        'formula_date' => '01/12/2021',
        'packing' => 'Plastic Vial Brown 10 mL|1|Nos.;Plastic Vial Brown 30 mL|1|Nos.;'
            . 'Boxes Green 50 mL|1|Nos.;Pack Insert ADA|1|Nos.',
    ],
    418 => [
        'code' => 'BGX/FIN.BIOC/2026/000004',
        'name' => 'ADA 30 mL',
        'pack_key' => '30ml',
        'pack_label' => '30 mL',
        'formula_date' => '01/08/2021',
        'packing' => 'Plastic Vial Brown 10 mL|1|Nos.;Plastic Vial Brown 30 mL|1|Nos.;'
            . 'Boxes Green 50 mL|1|Nos.;Pack Insert ADA|1|Nos.',
    ],
];

$description = 'Enzymatic reagent kit for quantitative estimation of Adenosine Deaminase activity.';
$approval = [
    'prepared_by' => 'Monika Mishra',
    'checked_by' => 'Shaurabh Kashyap',
    'approved_by' => 'Sanjay Kumar Yadav',
];
$bmrAttachments = [
    'Material requisition note (process order)',
    'Line clearance check lists',
    'IP/RM COA (whatever is applicable)',
    'Requisition to QC for testing of intermediate samples',
    'QA batch manufacturing review record',
];
$bprAttachments = [
    'Material requisition note (process order)',
    'Line clearance checklist',
    'QA batch production review record',
    'Finished-product COA',
];

$bmrR1 = bmrBprBiochemistryBmr(
    'ADA Reagent R1',
    'BIPL-MFRIP-004',
    3,
    'Adenosine Deaminase Reagent 1 (Enzyme reagent)|600|ml',
    '900 ml',
    true
);
$bmrR2 = bmrBprBiochemistryBmr(
    'ADA Reagent R2',
    'BIPL-MFRIP-005',
    3,
    'Substrate Reagent|300|ml',
    '300 ml',
    true
);
$decorateBmr = static function (array $bmrProfile) use ($description, $approval, $bmrAttachments): array {
    $bmrProfile['product_code'] = 'BGADA';
    $bmrProfile['description'] = $description;
    $bmrProfile['reagent_contents'] = implode(', ', array_column($bmrProfile['ingredients'], 'name'));
    $bmrProfile['approval_names'] = $approval;
    $bmrProfile['attachment_documents'] = $bmrAttachments;
    return $bmrProfile;
};
$bmrR1 = $decorateBmr($bmrR1);
$bmrR2 = $decorateBmr($bmrR2);

$bmrR1Profiles = [];
$bmrR2Profiles = [];
$bprProfiles = [];
foreach ($products as $productId => $product) {
    $bmrR1Profiles[(string) $productId] = $bmrR1;
    $bmrR2Profiles[(string) $productId] = $bmrR2;
    $bpr = bmrBprBiochemistryBpr(
        $product['name'],
        'Formula dated ' . $product['formula_date'],
        9,
        'Adenosine Deaminase (Bulk Reagent)|'
            . preg_replace('/[^0-9.]/', '', $product['pack_label']) . '|ml',
        $product['packing'],
        '1 Kit (' . $product['pack_label'] . ')'
    );
    $bpr['product_code'] = $product['code'];
    $bpr['description'] = $description;
    $bpr['kit_content'] = implode(', ', array_column($bpr['reagents'], 'name')) . ', Pack Insert';
    $bpr['approval_names'] = $approval;
    $bpr['attachment_documents'] = $bprAttachments;
    $bprProfiles[(string) $productId] = $bpr;
}

$document = [
    'document_no' => 'BIPL-BMR-01',
    'issue_no' => '01',
    'revision_no' => '02',
    'effective_date' => '03/04/2025',
    'license_no' => 'MFG/IVD/2020/000082',
    'department' => 'Production',
    'company_name' => 'BIOGENIX INC. PVT. LTD.',
    'company_address' => "B19/A S.I.L. Ancillary Estate,\nAmausi Industrial Area, Nadarganj-\n226008 (Lucknow)",
    'title' => 'BATCH MANUFACTURING RECORD',
];
$definitions = [
    [
        'form_type' => 'BMR',
        'document_sequence' => 1,
        'template_code' => 'ADA_PACK_SIZE_BMR_01_V01',
        'template_name' => 'ADA Pack-Resolved BMR #1 - R1',
        'page_count' => 3,
        'profiles' => $bmrR1Profiles,
        'editable_prefixes' => ['cover.', 'attachments.', 'rm.', 'manufacturing.', 'completion.', 'qa.'],
    ],
    [
        'form_type' => 'BMR',
        'document_sequence' => 2,
        'template_code' => 'ADA_PACK_SIZE_BMR_02_V01',
        'template_name' => 'ADA Pack-Resolved BMR #2 - R2',
        'page_count' => 3,
        'profiles' => $bmrR2Profiles,
        'editable_prefixes' => ['cover.', 'attachments.', 'rm.', 'manufacturing.', 'completion.', 'qa.'],
    ],
    [
        'form_type' => 'BPR',
        'document_sequence' => 1,
        'template_code' => 'ADA_PACK_SIZE_BPR_V01',
        'template_name' => 'ADA Pack-Resolved BPR',
        'page_count' => 9,
        'profiles' => $bprProfiles,
        'editable_prefixes' => ['cover.', 'attachments.', 'dispensing.', 'washing.', 'filling.', 'coding.', 'labeling.', 'packing.', 'transfer.', 'yield.', 'qa.'],
    ],
];

$lockName = 'ada_pack_size_bmr_bpr_v1';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the ADA pack-size template seed lock.\n");
    exit(1);
}

try {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'bmr_template_pack_size_mappings'");
    if (!$tableCheck || $tableCheck->num_rows !== 1) {
        throw new RuntimeException(
            'Apply 2026_09_16_003_bmr_bpr_pack_size_mappings_pending.sql before running this seeder.'
        );
    }

    $conn->begin_transaction();
    $validateProduct = $conn->prepare(
        "SELECT p.id
         FROM products p
         WHERE p.id = ? AND p.product_code = ? AND p.status != 3 AND p.deleted_at IS NULL
           AND EXISTS (
               SELECT 1 FROM bom_master bom
               WHERE bom.finished_product_id = p.id
                 AND bom.status = 1 AND bom.bom_status = 'APPROVED' AND bom.deleted_at IS NULL
           )
         LIMIT 1"
    );
    foreach ($products as $productId => $product) {
        $productCode = (string) $product['code'];
        $validateProduct->bind_param('is', $productId, $productCode);
        $validateProduct->execute();
        if (!$validateProduct->get_result()->fetch_assoc()) {
            throw new RuntimeException(
                "ADA product {$productId} does not match {$productCode} or has no approved pack-size BOM."
            );
        }
    }
    $validateProduct->close();

    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (415, 'ADA Pack-Resolved', ?, ?, ?, 1, ?, '01', '02', '2025-04-03',
                 'PACK-SIZE-BOM', NULL, NULL, NULL, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_name = VALUES(template_name), form_type = VALUES(form_type),
             document_no = VALUES(document_no), page_count = VALUES(page_count),
             layout_json = VALUES(layout_json), status = 1, deleted_by = NULL,
             deleted_at = NULL, updated_by = 1, updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_pack_size_mappings
            (template_id, product_id, pack_size_key, pack_size_label, form_type,
             document_sequence, required_quantity, status, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE template_id = VALUES(template_id),
             pack_size_label = VALUES(pack_size_label), required_quantity = 1,
             status = 1, deleted_by = NULL, deleted_at = NULL,
             updated_by = 1, updated_at = NOW()"
    );
    if (!$upsertTemplate || !$findTemplate || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare ADA pack-size template statements.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        $formType = (string) $definition['form_type'];
        $documentSequence = (int) $definition['document_sequence'];
        $layoutDocument = $document;
        if ($formType === 'BPR') {
            $layoutDocument['document_no'] = 'BIPL-BPR-01';
            $layoutDocument['title'] = 'BATCH PACKING RECORD';
        }
        $layout = [
            'schema_version' => 2,
            'renderer' => 'structured_html',
            'renderer_variant' => 'biochemistry',
            'form_type' => $formType,
            'document' => $layoutDocument,
            'editable_prefixes' => $definition['editable_prefixes'],
            'profiles' => $definition['profiles'],
        ];
        $layoutJson = json_encode(
            $layout,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );
        $templateName = (string) $definition['template_name'];
        $templateCode = (string) $definition['template_code'];
        $documentNo = $formType === 'BPR' ? 'BIPL-BPR-01' : 'BIPL-BMR-01';
        $pageCount = (int) $definition['page_count'];
        $upsertTemplate->bind_param(
            'ssssis',
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException("Unable to save {$templateCode}: {$upsertTemplate->error}");
        }
        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException("Unable to resolve {$templateCode}.");
        }
        $templateCount++;

        foreach ($products as $productId => $product) {
            $packKey = (string) $product['pack_key'];
            $packLabel = (string) $product['pack_label'];
            $upsertMapping->bind_param(
                'iisssi',
                $templateId,
                $productId,
                $packKey,
                $packLabel,
                $formType,
                $documentSequence
            );
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map ADA {$packLabel} {$formType}: {$upsertMapping->error}"
                );
            }
            $mappingCount++;
        }
    }

    $upsertTemplate->close();
    $findTemplate->close();
    $upsertMapping->close();
    $conn->commit();
    echo "ADA pack-size templates saved: {$templateCount}\n";
    echo "ADA pack-size document mappings updated: {$mappingCount}\n";
    echo "Existing product-level BMR/BPR mappings were preserved as fallback.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
