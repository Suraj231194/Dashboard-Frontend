<?php
/**
 * Rebuild the seeded BOM catalogue from the approved Care IO workbooks.
 *
 * Dry-run (default):
 *   php admin/migrations/repair_bom_workbook_alignment.php "C:\\path\\to\\carre io"
 * Apply after a clean dry-run:
 *   php admin/migrations/repair_bom_workbook_alignment.php "C:\\path\\to\\carre io" --apply
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$sourceDir = isset($argv[1]) ? rtrim((string) $argv[1], "\\/") : '';
$apply = in_array('--apply', $argv, true);
if ($sourceDir === '' || !is_dir($sourceDir)) {
    fwrite(STDERR, "Usage: php " . basename(__FILE__) . " <workbook-directory> [--apply]\n");
    exit(2);
}

$workbooks = [
    'BOMs - Biochemistry (Finished Kit) - (Packaging BOM).xlsx' => 4,
    'BOMs - Biochemistry (Reagent Manufacturing) (Semi Finished).xlsx' => 1,
    'BOMs - Hematology.xlsx' => 4,
    'BOMs - Rapid Tests.xlsx' => 4,
    'BOMs - Serology & Turbi.xlsx' => 4,
    'BOMs - Uncut Sheets (Semi Finished Goods for Rapid Tests & Urinalysis).xlsx' => 2,
];

// The source contains nine sheets without a catalogue number and six Hematology
// footer codes that point to Accessories instead of the matching Finished item.
$targetOverrides = [
    'Phosphorus 100ML' => 'BGX/FIN.BIOC/2026/000106',
    'Protein 100ML' => 'BGX/FIN.BIOC/2026/000130',
    'HCG Rapid Big 50Test' => 'BGX/FIN.RAPID/2026/000042',
    'LH BIO' => 'BGX/FIN.RAPID/2026/000063',
    'Scrub Typhus IgM' => 'BGX/FIN.RAPID/2026/000084',
    'Sickle 30T' => 'BGX/FIN.RAPID/2026/000086',
    'TROP I25T' => 'BGX/FIN.RAPID/2026/000091',
    'VIT D' => 'BGX/FIN.POCT/2026/000056',
    'Protein Urine' => 'BGX/SF.US.URIN/2026/000021',
    'Diluent Biogenix 20 L' => 'BGX/FIN.HEMA/2026/000006',
    'Diluent 5PART 20 L' => 'BGX/FIN.HEMA/2026/000005',
    'EZ Cleaner 100 mL' => 'BGX/FIN.HEMA/2026/000001',
    'Lyse for VH50 500 mL Nos' => 'BGX/FIN.HEMA/2026/000009',
    'Probe Cleaner Biogenix 100 mL' => 'BGX/FIN.HEMA/2026/000019',
    'Rinse Reagent 20 L' => 'BGX/FIN.HEMA/2026/000021',
];

function normaliseBomText(string $value): string
{
    $value = mb_strtolower(trim($value), 'UTF-8');
    $value = str_replace(['µ', 'μ', '×', '&'], ['u', 'u', 'x', ' and '], $value);
    $replacements = [
        'pottasium' => 'potassium', 'cholestrol' => 'cholesterol',
        'bilurbin' => 'bilirubin', 'membrance' => 'membrane',
        'matrial' => 'material', 'genration' => 'generation',
        'posphorus' => 'phosphorus', 'bo x' => 'box', 'bora x' => 'borax',
        'o x alate' => 'oxalate', 'deca.' => 'deca',
    ];
    $value = strtr($value, $replacements);
    $value = preg_replace('/\b(nos?|pieces?)\b/u', 'pcs', $value) ?? $value;
    $value = preg_replace('/\b(gms?|grams?)\b/u', 'g', $value) ?? $value;
    $value = preg_replace('/\b(ltrs?|litres?|liters?)\b/u', 'ltr', $value) ?? $value;
    $value = preg_replace('/\btests\b/u', 'test', $value) ?? $value;
    $value = preg_replace('/[^a-z0-9@%]+/u', ' ', $value) ?? $value;
    return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
}

function bomTaxMarker(string $value): string
{
    if (preg_match('/@\s*(12|18)\s*%?/i', $value, $match)) {
        return $match[1];
    }
    return '';
}

function bomSimilarity(string $left, string $right): float
{
    $left = normaliseBomText($left);
    $right = normaliseBomText($right);
    if ($left === $right) {
        return 1.0;
    }
    similar_text($left, $right, $percent);
    $leftTokens = array_values(array_unique(array_filter(explode(' ', $left))));
    $rightTokens = array_values(array_unique(array_filter(explode(' ', $right))));
    $common = count(array_intersect($leftTokens, $rightTokens));
    $union = count(array_unique(array_merge($leftTokens, $rightTokens)));
    $containment = $common / max(1, min(count($leftTokens), count($rightTokens)));
    $jaccard = $common / max(1, $union);
    return (($percent / 100) * 0.50) + ($containment * 0.30) + ($jaccard * 0.20);
}

function bomUnitKey(string $overage): string
{
    $unit = strtoupper(trim((string) preg_replace('/[0-9.].*$/', '', trim($overage))));
    return match ($unit) {
        'GM', 'G', 'GRAM' => 'g',
        'MG' => 'mg',
        'KG' => 'kg',
        'LTR', 'L', 'LITRE' => 'ltr',
        'ML' => 'ml',
        'UL', 'ΜL', 'µL' => 'µl',
        'KU' => 'KU',
        'MU' => 'MU',
        'MTR', 'METER', 'METRE' => 'm',
        'SHEET', 'SHEETS' => 'sheets',
        'TEST', 'TESTS' => 'test',
        'KIT', 'KITS' => 'kit',
        default => 'pcs',
    };
}

function fetchAllRows(mysqli $conn, string $sql): array
{
    $result = $conn->query($sql);
    if (!$result) {
        throw new RuntimeException($conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

function prepareBomStatement(mysqli $conn, string $sql): mysqli_stmt
{
    $statement = $conn->prepare($sql);
    if (!$statement) {
        throw new RuntimeException('Unable to prepare BOM repair statement: ' . $conn->error);
    }
    return $statement;
}

$products = fetchAllRows($conn, "SELECT p.id, p.product_code, p.product_name, p.category_id, p.unit_id,
        category.name AS category_name
    FROM products p
    LEFT JOIN product_categories category ON category.id = p.category_id
    WHERE p.status = 1 AND p.deleted_at IS NULL
    ORDER BY p.id");
$productsByCode = [];
foreach ($products as $product) {
    $productsByCode[strtoupper((string) $product['product_code'])] = $product;
}
$units = fetchAllRows($conn, "SELECT id, short_name FROM standard_units WHERE status = 1 ORDER BY id");
$unitIds = [];
foreach ($units as $unit) {
    $unitIds[(string) $unit['short_name']] = (int) $unit['id'];
}

$formulae = [];
$sourceRows = 0;
$explicitComponentCodes = [];
foreach ($workbooks as $fileName => $bomType) {
    $path = $sourceDir . DIRECTORY_SEPARATOR . $fileName;
    if (!is_file($path)) {
        throw new RuntimeException("Required workbook missing: {$path}");
    }
    $spreadsheet = IOFactory::load($path);
    foreach ($spreadsheet->getWorksheetIterator() as $sheet) {
        $rows = $sheet->toArray(null, true, true, false);
        $headerIndex = null;
        $descriptionColumn = null;
        $quantityColumn = null;
        foreach ($rows as $rowIndex => $row) {
            foreach ($row as $columnIndex => $cell) {
                $heading = strtoupper(trim((string) $cell));
                if ($heading === 'ITEM DESCRIPTION') {
                    $headerIndex = $rowIndex;
                    $descriptionColumn = $columnIndex;
                } elseif ($heading === 'QUANTITY') {
                    $quantityColumn = $columnIndex;
                }
            }
            if ($headerIndex !== null && $quantityColumn !== null) {
                break;
            }
        }
        if ($headerIndex === null || $descriptionColumn === null || $quantityColumn === null) {
            throw new RuntimeException("No BOM header in {$fileName} / {$sheet->getTitle()}");
        }

        $catalogueCodes = [];
        foreach ($rows as $row) {
            foreach ($row as $cell) {
                if (preg_match_all('/BGX\/[A-Z0-9.]+\/[0-9]{4}\/[0-9]{6}/i', (string) $cell, $matches)) {
                    foreach ($matches[0] as $code) {
                        $catalogueCodes[] = strtoupper($code);
                    }
                }
            }
        }
        $sheetName = trim($sheet->getTitle());
        $targetCode = $targetOverrides[$sheetName] ?? (empty($catalogueCodes) ? '' : end($catalogueCodes));
        if ($targetCode === '' || !isset($productsByCode[$targetCode])) {
            throw new RuntimeException("Unresolved target product in {$fileName} / {$sheetName}: {$targetCode}");
        }

        $components = [];
        for ($rowIndex = $headerIndex + 1; $rowIndex < count($rows); $rowIndex++) {
            $row = $rows[$rowIndex];
            $description = trim((string) ($row[$descriptionColumn] ?? ''));
            $quantity = $row[$quantityColumn] ?? null;
            if ($description === '' || !is_numeric($quantity)) {
                continue;
            }
            $explicitCode = '';
            foreach ($row as $cell) {
                if (preg_match('/BGX\/[A-Z0-9.]+\/[0-9]{4}\/[0-9]{6}/i', (string) $cell, $match)) {
                    $explicitCode = strtoupper($match[0]);
                    break;
                }
            }
            $overage = (string) ($row[$quantityColumn + 1] ?? '');
            $components[] = [
                'description' => $description,
                'quantity' => round((float) $quantity, 6),
                'unit' => bomUnitKey($overage),
                'explicit_code' => $explicitCode,
            ];
            if ($explicitCode !== '') {
                $explicitComponentCodes[normaliseBomText($description)] = $explicitCode;
            }
            $sourceRows++;
        }

        $signature = json_encode($components, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (isset($formulae[$targetCode])) {
            if ($formulae[$targetCode]['signature'] !== $signature) {
                throw new RuntimeException("Conflicting duplicate formula for {$targetCode}");
            }
            continue;
        }
        $formulae[$targetCode] = [
            'file' => $fileName,
            'sheet' => $sheetName,
            'bom_type' => $bomType,
            'target' => $productsByCode[$targetCode],
            'components' => $components,
            'signature' => $signature,
        ];
    }
    $spreadsheet->disconnectWorksheets();
}

// BOM outputs are valid component candidates for packaging/intermediate formulas.
$outputAliases = [];
foreach ($formulae as $code => $formula) {
    $outputAliases[normaliseBomText((string) $formula['target']['product_name'])] = $code;
    $outputAliases[normaliseBomText((string) $formula['sheet'])] = $code;
}

$manualAliases = [
    'hydrochloric acid hcl' => 'BGX/PROD.AC/2026/000217',
    'hcl' => 'BGX/PROD.AC/2026/000217',
    'ethanol' => 'BGX/PROD.AC/2026/000145',
    'sodium caseinate extrapure 250 g' => 'BGX/PROD.AC/2026/000491',
    'membrane multistix sg' => 'BGX/SF.US.URIN/2026/000012',
    'membrane multistix uro sheet' => 'BGX/SF.US.URIN/2026/000013',
    'membrane multistix leuko sheet' => 'BGX/SF.US.URIN/2026/000009',
    'membrane multistix nitrate sheet' => 'BGX/SF.US.URIN/2026/000010',
    'membrane multistix ph' => 'BGX/SF.US.URIN/2026/000011',
    'membrane multistix blood sheet' => 'BGX/SF.US.URIN/2026/000007',
    'membrane multistix bilurbin sheet' => 'BGX/SF.US.URIN/2026/000006',
    'membrane multistix ketone sheet' => 'BGX/SF.US.URIN/2026/000008',
    'albumine reagent ltr' => 'BGX/SF.BR.BIOC/2026/000003',
    '2ml glass vial' => 'BGX/PP.CON/2026/000002',
    'hdl ldl ppt reagent' => 'BGX/SF.BR.BIOC/2026/000026',
    'lipase reagent ltr' => 'BGX/SF.BR.BIOC/2026/000032',
    'xod' => 'BGX/PP.CON/2026/000175',
    'probe cleaner' => 'BGX/FIN.HEMA/2026/000018',
    'gonorrhoea uncut sheet' => 'BGX/SF.US.RAPID/2026/000042',
    'transport swab bulk pack pcs' => 'BGX/PP.CON/2026/000158',
    'hcv uncut sheet s p' => 'BGX/SF.US.RAPID/2026/000055',
    'hcv uncut sheet w b' => 'BGX/SF.US.RAPID/2026/000056',
    'aso latex reagent with control' => 'BGX/FIN.SERO/2026/000006',
    'aso latex reagent with control@' => 'BGX/FIN.SERO/2026/000006',
    'h pylori ab uncut sheet sheet' => 'BGX/SF.US.RAPID/2026/000043',
    'rota uncut sheet' => 'BGX/SF.US.RAPID/2026/000089',
    'syphilis s p uncut sheet' => 'BGX/SF.US.RAPID/2026/000095',
    'syphilis wb uncut sheet' => 'BGX/SF.US.RAPID/2026/000096',
    'crp turbilatex in ltr r1 r2 biosino' => 'BGX/SF.BR.BIOC/2026/000018',
    'ferritin turbi reagent ltr' => 'BGX/SF.BR.SERO/2026/000002',
    'micro albumin r1 and r2 ml' => 'BGX/SF.BR.SERO/2026/000003',
    'rf latex reagent bulk @12%' => 'BGX/SF.BR.SERO/2026/000004',
    'rf turbilatex reagent biosino' => 'BGX/SF.BR.SERO/2026/000008',
    'rf turbilatex calibrator pcs' => 'BGX/CAL.SERO/2026/000006',
    'widal typhi b h reagent in lt ml' => 'BGX/SF.BR.SERO/2026/000019',
];

$unresolved = [];
$resolvedRows = 0;
foreach ($formulae as &$formula) {
    foreach ($formula['components'] as &$component) {
        $description = (string) $component['description'];
        $normalised = normaliseBomText($description);
        $code = (string) $component['explicit_code'];
        $method = 'explicit-code';
        if ($code !== '' && !isset($productsByCode[$code])) {
            $code = '';
            $method = 'invalid-workbook-code';
        }
        if ($code === '' && isset($manualAliases[$normalised])) {
            $code = $manualAliases[$normalised];
            $method = 'approved-alias';
        }
        if ($code === '' && isset($explicitComponentCodes[$normalised])) {
            $code = $explicitComponentCodes[$normalised];
            $method = 'cross-workbook-code';
        }
        if ($code === '' && isset($outputAliases[$normalised])) {
            $code = $outputAliases[$normalised];
            $method = 'bom-output-name';
        }
        if ($code === '') {
            $ranked = [];
            $sourceTax = bomTaxMarker($description);
            foreach ($products as $product) {
                if (str_starts_with(strtolower((string) $product['category_name']), 'finished')) {
                    continue;
                }
                $score = bomSimilarity($description, (string) $product['product_name']);
                $candidateTax = bomTaxMarker((string) $product['product_name']);
                if ($sourceTax !== '') {
                    $score += $candidateTax === $sourceTax ? 0.12 : -0.12;
                } elseif ($candidateTax !== '') {
                    $score -= 0.04;
                }
                $ranked[] = ['score' => $score, 'product' => $product];
            }
            usort($ranked, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
            $best = $ranked[0];
            $second = $ranked[1];
            $gap = $best['score'] - $second['score'];
            if ($best['score'] >= 0.75 || ($best['score'] >= 0.60 && $gap >= 0.03)) {
                $code = strtoupper((string) $best['product']['product_code']);
                $method = 'unique-name-match';
            } else {
                $unresolved[] = [
                    'file' => $formula['file'], 'sheet' => $formula['sheet'],
                    'description' => $description,
                    'best' => $best['product']['product_code'] . ' ' . $best['product']['product_name'],
                    'score' => round($best['score'], 3), 'gap' => round($gap, 3),
                ];
                continue;
            }
        }
        if (!isset($productsByCode[$code])) {
            $unresolved[] = ['file' => $formula['file'], 'sheet' => $formula['sheet'], 'description' => $description, 'best' => $code, 'score' => 0, 'gap' => 0];
            continue;
        }
        $component['product'] = $productsByCode[$code];
        $component['match_method'] = $method;
        $resolvedRows++;
    }
    unset($component);
}
unset($formula);

echo "Mode: " . ($apply ? 'APPLY' : 'DRY RUN') . PHP_EOL;
echo "Workbook sheets: 218" . PHP_EOL;
echo "Unique BOM products: " . count($formulae) . PHP_EOL;
echo "Workbook component rows: {$sourceRows}" . PHP_EOL;
echo "Resolved component rows: {$resolvedRows}" . PHP_EOL;
echo "Unresolved component rows: " . count($unresolved) . PHP_EOL;
foreach (array_slice($unresolved, 0, 100) as $row) {
    echo "UNRESOLVED | {$row['sheet']} | {$row['description']} | {$row['best']} | score={$row['score']} gap={$row['gap']}" . PHP_EOL;
}
if ($unresolved) {
    fwrite(STDERR, "Repair aborted: every component must resolve uniquely.\n");
    exit(1);
}
if (!$apply) {
    echo "Dry-run passed. Re-run with --apply to write the repair.\n";
    exit(0);
}

// Workbook parsing can exceed a development server's very small wait_timeout.
// Reconnect immediately before opening the write transaction.
$conn->close();
$conn = new mysqli(
    $env['DB_HOST'],
    $env['DB_USERNAME'],
    $env['DB_PASSWORD'],
    $env['DB_DATABASE'],
    (int) $env['DB_PORT']
);
if ($conn->connect_errno !== 0 || !$conn->set_charset('utf8mb4')) {
    throw new RuntimeException('Unable to reconnect for BOM repair transaction.');
}

$conn->begin_transaction();
try {
    $desiredProductIds = [];
    $selectBom = prepareBomStatement($conn, "SELECT id FROM bom_master WHERE finished_product_id = ? AND status = 1 AND deleted_at IS NULL ORDER BY (source_type = 'ORIGINAL') DESC, id LIMIT 1 FOR UPDATE");
    $insertBom = prepareBomStatement($conn, "INSERT INTO bom_master (name, category_id, finished_product_id, bom_type, descriptions, status, bom_status, source_type, created_by, created_at) VALUES (?, ?, ?, ?, ?, 1, 'APPROVED', 'ORIGINAL', 1, NOW())");
    $updateBom = prepareBomStatement($conn, "UPDATE bom_master SET name=?, category_id=?, bom_type=?, descriptions=?, status=1, bom_status='APPROVED', deleted_at=NULL, deleted_by=NULL WHERE id=?");
    $deleteItems = prepareBomStatement($conn, "DELETE FROM bom_items WHERE bom_id=?");
    $insertItem = prepareBomStatement($conn, "INSERT INTO bom_items (bom_id, raw_product_category_id, raw_product_id, qty_unit_id, qty_per_unit, status, created_by, created_at) VALUES (?, ?, ?, ?, ?, 1, 1, NOW())");

    foreach ($formulae as $formula) {
        $target = $formula['target'];
        $productId = (int) $target['id'];
        $desiredProductIds[] = $productId;
        $selectBom->bind_param('i', $productId);
        $selectBom->execute();
        $existing = $selectBom->get_result()->fetch_assoc();
        $name = (string) $target['product_name'];
        $categoryId = (int) $target['category_id'];
        $bomType = (int) $formula['bom_type'];
        $description = 'BOM for ' . $name;
        if ($existing) {
            $bomId = (int) $existing['id'];
            $updateBom->bind_param('siisi', $name, $categoryId, $bomType, $description, $bomId);
            $updateBom->execute();
        } else {
            $insertBom->bind_param('siiis', $name, $categoryId, $productId, $bomType, $description);
            $insertBom->execute();
            $bomId = (int) $conn->insert_id;
        }
        $deleteItems->bind_param('i', $bomId);
        $deleteItems->execute();
        foreach ($formula['components'] as $component) {
            $raw = $component['product'];
            $rawCategoryId = (int) $raw['category_id'];
            $rawProductId = (int) $raw['id'];
            $unitId = $unitIds[$component['unit']] ?? (int) ($raw['unit_id'] ?: ($unitIds['pcs'] ?? 10));
            $quantity = (float) $component['quantity'];
            $insertItem->bind_param('iiiid', $bomId, $rawCategoryId, $rawProductId, $unitId, $quantity);
            $insertItem->execute();
        }
    }

    $idList = implode(',', array_map('intval', array_unique($desiredProductIds)));
    $staleSql = "UPDATE bom_master SET status=3, deleted_at=NOW(), deleted_by=1
        WHERE source_type='ORIGINAL' AND status=1 AND deleted_at IS NULL
          AND finished_product_id NOT IN ({$idList})";
    if (!$conn->query($staleSql)) {
        throw new RuntimeException($conn->error);
    }
    $staleCount = $conn->affected_rows;
    $conn->commit();
    echo "Repair committed. Stale original BOMs disabled: {$staleCount}" . PHP_EOL;
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, "Repair rolled back: {$exception->getMessage()}\n");
    exit(1);
}
