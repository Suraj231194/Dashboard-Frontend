-- Additive QA/QC navigation registration for the BMR/BPR Form Request page.
-- Existing menus, permissions, and role assignments are not changed.

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
SELECT
    'QA/QC BMR/BPR Form Request View',
    'qa_qc_bmr_bpr_form_request_view',
    1,
    1,
    NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `permissions`
    WHERE `slug` = 'qa_qc_bmr_bpr_form_request_view'
);

INSERT INTO `menus`
    (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`,
     `showmenu`, `status`, `created_by`, `created_at`)
SELECT
    'BMR/BPR Form Request',
    'index.php?page=bmr-bpr-form-request',
    'ti ti-file-description',
    qa_menu.id,
    8,
    'qa_qc_bmr_bpr_form_request_view',
    1,
    1,
    1,
    NOW()
FROM `menus` qa_menu
WHERE qa_menu.id = 72
  AND qa_menu.name = 'QA & QC'
  AND qa_menu.status = 1
  AND qa_menu.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM `menus` existing_menu
      WHERE existing_menu.route = 'index.php?page=bmr-bpr-form-request'
        AND existing_menu.deleted_at IS NULL
  );

-- Make the submenu available to every role that can already access the QA/QC
-- parent menu. Explicit per-user deny rules continue to take precedence.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT
    qa_role.role_id,
    request_permission.id,
    1
FROM `role_permissions` qa_role
INNER JOIN `permissions` qa_permission
    ON qa_permission.id = qa_role.permission_id
   AND qa_permission.slug = 'qa_qc_menu'
INNER JOIN `permissions` request_permission
    ON request_permission.slug = 'qa_qc_bmr_bpr_form_request_view'
WHERE qa_role.status = 1
  AND NOT EXISTS (
      SELECT 1
      FROM `role_permissions` existing_assignment
      WHERE existing_assignment.role_id = qa_role.role_id
        AND existing_assignment.permission_id = request_permission.id
  );
