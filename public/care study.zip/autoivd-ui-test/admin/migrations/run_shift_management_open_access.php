<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if (!isset($conn) || !$conn instanceof mysqli) {
    require_once dirname(__DIR__) . '/db.php';
}

$migrationPath = __DIR__ . '/2026_09_02_004_shift_management_open_access.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Shift Management open-access migration SQL is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Shift Management open-access migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while ($conn->more_results() && $conn->next_result()) {
    if ($result = $conn->store_result()) {
        $result->free();
    }
}
if ($conn->errno !== 0) {
    fwrite(STDERR, 'Shift Management open-access migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

$stmt = $conn->prepare(
    "SELECT permission_slug FROM menus
     WHERE route = 'index.php?page=shift-management' AND deleted_at IS NULL
     LIMIT 1"
);
$stmt->execute();
$menu = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$menu || $menu['permission_slug'] !== null) {
    fwrite(STDERR, "Shift Management menu verification failed.\n");
    exit(1);
}

echo "Shift Management is available to every authenticated user.\n";
