<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('HRMS_CONTEXT', true);

if (!isset($conn) || !$conn instanceof mysqli) {
    require_once dirname(__DIR__) . '/db.php';
}
require_once dirname(__DIR__) . '/hrms/annual_calendar_common.php';

$migrationPath = __DIR__ . '/2026_09_05_003_fix_annual_calendar_holiday_dates_pending.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Holiday dates fix migration SQL is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Holiday dates fix migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) {
        $result->free();
    }
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Holiday dates fix migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) {
        break;
    }
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Holiday dates fix migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

// Now sync materialized days and totals for all 2026 calendars
$calRes = $conn->query("SELECT id, company_id, calendar_year, is_finalized, lifecycle_status FROM hr_annual_calendars WHERE calendar_year = 2026 AND deleted_at IS NULL");
if ($calRes) {
    while ($cal = $calRes->fetch_assoc()) {
        $calId = (int) $cal['id'];
        $fullCal = acCalendarById($conn, $calId);
        $days = acBuildCalendarDays($conn, $calId);
        $hash = acPersistCalendarDays($conn, $fullCal, $days);
        $totals = acRecalculateWorkingDays($conn, $calId);

        if ((int) $cal['is_finalized'] === 1 || $cal['lifecycle_status'] === 'finalized') {
            $stmt = $conn->prepare("UPDATE hr_annual_calendars SET content_hash = ? WHERE id = ?");
            $stmt->bind_param('si', $hash, $calId);
            $stmt->execute();
            $stmt->close();
        }

        echo "Synchronized calendar {$calId} (Company {$cal['company_id']}, Year {$cal['calendar_year']}):\n";
        echo "  - Total days: {$totals['total_days']}\n";
        echo "  - Sundays: {$totals['total_sundays']}\n";
        echo "  - Holidays: {$totals['total_holidays']}\n";
        echo "  - Working days: {$totals['total_working_days']}\n";
        echo "  - Content hash: {$hash}\n";
    }
}

echo "Holiday dates migration applied and calendars synchronized successfully.\n";
