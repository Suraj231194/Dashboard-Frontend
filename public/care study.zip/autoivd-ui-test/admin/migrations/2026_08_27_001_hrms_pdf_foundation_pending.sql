-- HRMS features specified in "HRMS Final Doc (without Payroll).pdf".
-- All objects are additive. Existing employee, profile, attendance and sidebar
-- structures are intentionally left unchanged.

CREATE TABLE IF NOT EXISTS `hr_employee_profiles` (
    `employee_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `department_id` INT DEFAULT NULL,
    `work_location` VARCHAR(255) DEFAULT NULL,
    `personal_email` VARCHAR(255) DEFAULT NULL,
    `differently_abled` TINYINT(1) NOT NULL DEFAULT 0,
    `portal_access` TINYINT(1) NOT NULL DEFAULT 0,
    `payment_mode` ENUM('direct_deposit','bank_transfer','cheque','cash') DEFAULT NULL,
    `annual_ctc` DECIMAL(14,2) DEFAULT NULL,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`employee_id`),
    KEY `idx_hr_employee_profile_tenant` (`company_id`, `branch_id`),
    KEY `idx_hr_employee_profile_department` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_employee_sequences` (
    `company_id` BIGINT UNSIGNED NOT NULL,
    `next_number` INT UNSIGNED NOT NULL DEFAULT 1,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_salary_components` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id` INT NOT NULL,
    `component_code` VARCHAR(50) NOT NULL,
    `component_name` VARCHAR(120) NOT NULL,
    `calculation_type` ENUM('ctc_percentage','basic_percentage','fixed') NOT NULL,
    `calculation_value` DECIMAL(12,4) NOT NULL DEFAULT 0,
    `monthly_amount` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `annual_amount` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `is_deduction` TINYINT(1) NOT NULL DEFAULT 0,
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT NOT NULL DEFAULT 1,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_salary_employee_component` (`employee_id`, `component_code`),
    KEY `idx_hr_salary_employee` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_leave_types` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `code` VARCHAR(40) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `description` VARCHAR(500) DEFAULT NULL,
    `color` VARCHAR(20) NOT NULL DEFAULT '#10b981',
    `is_paid` TINYINT(1) NOT NULL DEFAULT 1,
    `gender_eligibility` ENUM('all','female','male') NOT NULL DEFAULT 'all',
    `allow_negative_balance` TINYINT(1) NOT NULL DEFAULT 0,
    `status` TINYINT NOT NULL DEFAULT 1,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_hr_leave_type_company` (`company_id`, `status`),
    KEY `idx_hr_leave_type_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_leave_allocations` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id` INT NOT NULL,
    `leave_type_id` INT UNSIGNED NOT NULL,
    `leave_year` YEAR NOT NULL,
    `allocated_days` DECIMAL(7,2) NOT NULL DEFAULT 0,
    `carried_forward_days` DECIMAL(7,2) NOT NULL DEFAULT 0,
    `adjustment_days` DECIMAL(7,2) NOT NULL DEFAULT 0,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_leave_allocation` (`employee_id`, `leave_type_id`, `leave_year`),
    KEY `idx_hr_leave_allocation_year` (`leave_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_leave_applications` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `application_no` VARCHAR(50) NOT NULL,
    `employee_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `leave_type_id` INT UNSIGNED NOT NULL,
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL,
    `total_days` DECIMAL(7,2) NOT NULL,
    `team_email` VARCHAR(255) DEFAULT NULL,
    `reason` TEXT NOT NULL,
    `status` ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    `submitted_at` DATETIME NOT NULL,
    `action_by` INT DEFAULT NULL,
    `action_at` DATETIME DEFAULT NULL,
    `action_note` VARCHAR(1000) DEFAULT NULL,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_leave_application_no` (`application_no`),
    KEY `idx_hr_leave_employee_status` (`employee_id`, `status`),
    KEY `idx_hr_leave_tenant_dates` (`company_id`, `branch_id`, `start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_leave_application_days` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `application_id` BIGINT UNSIGNED NOT NULL,
    `leave_date` DATE NOT NULL,
    `day_portion` ENUM('full_day','first_half','second_half') NOT NULL DEFAULT 'full_day',
    `day_value` DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_leave_application_date` (`application_id`, `leave_date`),
    KEY `idx_hr_leave_day_date` (`leave_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_leave_status_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `application_id` BIGINT UNSIGNED NOT NULL,
    `from_status` VARCHAR(30) DEFAULT NULL,
    `to_status` VARCHAR(30) NOT NULL,
    `note` VARCHAR(1000) DEFAULT NULL,
    `changed_by` INT NOT NULL,
    `changed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_hr_leave_history_application` (`application_id`, `changed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_offboarding_settings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `notice_period_days` INT UNSIGNED NOT NULL DEFAULT 30,
    `approver_user_id` INT DEFAULT NULL,
    `hr_partner_user_id` INT DEFAULT NULL,
    `interview_intro` TEXT DEFAULT NULL,
    `thank_you_message` TEXT DEFAULT NULL,
    `send_experience_letter` TINYINT(1) NOT NULL DEFAULT 1,
    `send_relieving_letter` TINYINT(1) NOT NULL DEFAULT 1,
    `status` TINYINT NOT NULL DEFAULT 1,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_offboarding_scope` (`company_id`, `branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_exit_interview_questions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `settings_id` BIGINT UNSIGNED NOT NULL,
    `question_text` VARCHAR(1000) NOT NULL,
    `question_type` ENUM('short_text','long_text','single_choice','multiple_choice','rating') NOT NULL DEFAULT 'long_text',
    `options_json` LONGTEXT DEFAULT NULL,
    `is_required` TINYINT(1) NOT NULL DEFAULT 0,
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT NOT NULL DEFAULT 1,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_hr_exit_questions_settings` (`settings_id`, `status`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_resignation_requests` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `request_no` VARCHAR(50) NOT NULL,
    `employee_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `resignation_date` DATE NOT NULL,
    `requested_last_working_date` DATE NOT NULL,
    `approved_last_working_date` DATE DEFAULT NULL,
    `reason` TEXT NOT NULL,
    `status` ENUM('pending','approved','rejected','cancelled','exit_interview_pending','completed') NOT NULL DEFAULT 'pending',
    `submitted_at` DATETIME NOT NULL,
    `action_by` INT DEFAULT NULL,
    `action_at` DATETIME DEFAULT NULL,
    `action_note` VARCHAR(1000) DEFAULT NULL,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_resignation_request_no` (`request_no`),
    KEY `idx_hr_resignation_employee` (`employee_id`, `status`),
    KEY `idx_hr_resignation_tenant` (`company_id`, `branch_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_exit_interview_answers` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `resignation_request_id` BIGINT UNSIGNED NOT NULL,
    `question_id` BIGINT UNSIGNED NOT NULL,
    `answer_text` LONGTEXT DEFAULT NULL,
    `submitted_by` INT NOT NULL,
    `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_exit_answer` (`resignation_request_id`, `question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_offboarding_documents` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `resignation_request_id` BIGINT UNSIGNED NOT NULL,
    `document_type` ENUM('experience_letter','relieving_letter') NOT NULL,
    `file_path` VARCHAR(500) DEFAULT NULL,
    `status` ENUM('pending','generated','sent','failed') NOT NULL DEFAULT 'pending',
    `generated_by` INT DEFAULT NULL,
    `generated_at` DATETIME DEFAULT NULL,
    `sent_at` DATETIME DEFAULT NULL,
    `error_message` VARCHAR(1000) DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_offboarding_document` (`resignation_request_id`, `document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_biometric_devices` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `device_code` VARCHAR(100) NOT NULL,
    `device_name` VARCHAR(150) NOT NULL,
    `vendor` VARCHAR(100) DEFAULT NULL,
    `timezone` VARCHAR(100) NOT NULL DEFAULT 'Asia/Kolkata',
    `status` TINYINT NOT NULL DEFAULT 1,
    `last_synced_at` DATETIME DEFAULT NULL,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_biometric_device` (`company_id`, `device_code`),
    KEY `idx_hr_biometric_device_branch` (`branch_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_biometric_punches` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `device_id` BIGINT UNSIGNED NOT NULL,
    `external_event_id` VARCHAR(150) NOT NULL,
    `employee_code` VARCHAR(100) NOT NULL,
    `employee_id` INT DEFAULT NULL,
    `punch_time` DATETIME NOT NULL,
    `punch_type` ENUM('in','out','unknown') NOT NULL DEFAULT 'unknown',
    `raw_payload` LONGTEXT DEFAULT NULL,
    `imported_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_biometric_event` (`device_id`, `external_event_id`),
    KEY `idx_hr_biometric_employee_time` (`employee_id`, `punch_time`),
    KEY `idx_hr_biometric_code_time` (`employee_code`, `punch_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_attendance_daily` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `attendance_date` DATE NOT NULL,
    `shift_id` INT DEFAULT NULL,
    `first_punch_at` DATETIME DEFAULT NULL,
    `last_punch_at` DATETIME DEFAULT NULL,
    `worked_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
    `late_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
    `classification` ENUM('on_time','late','half_day','full_day','absent','incomplete') NOT NULL DEFAULT 'incomplete',
    `source` ENUM('biometric','manual') NOT NULL DEFAULT 'biometric',
    `calculated_at` DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_attendance_employee_date` (`employee_id`, `attendance_date`),
    KEY `idx_hr_attendance_scope_date` (`company_id`, `branch_id`, `attendance_date`, `classification`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_shift_policies` (
    `shift_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `full_day_minutes` INT UNSIGNED NOT NULL DEFAULT 480,
    `half_day_minutes` INT UNSIGNED NOT NULL DEFAULT 240,
    `effective_from` DATE NOT NULL,
    `effective_to` DATE DEFAULT NULL,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`shift_id`, `effective_from`),
    KEY `idx_hr_shift_policy_scope` (`company_id`, `branch_id`, `effective_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `hr_leave_types` (`company_id`, `code`, `name`, `description`, `color`, `is_paid`, `gender_eligibility`, `allow_negative_balance`, `status`, `created_by`)
SELECT NULL, 'CASUAL', 'Casual Leave', 'Planned or personal leave allocated by HR.', '#10b981', 1, 'all', 0, 1, 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `hr_leave_types` WHERE `company_id` IS NULL AND `code` = 'CASUAL');

INSERT INTO `hr_leave_types` (`company_id`, `code`, `name`, `description`, `color`, `is_paid`, `gender_eligibility`, `allow_negative_balance`, `status`, `created_by`)
SELECT NULL, 'SICK', 'Sick Leave', 'Leave for illness or medical recovery.', '#0ea5e9', 1, 'all', 0, 1, 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `hr_leave_types` WHERE `company_id` IS NULL AND `code` = 'SICK');

INSERT INTO `hr_leave_types` (`company_id`, `code`, `name`, `description`, `color`, `is_paid`, `gender_eligibility`, `allow_negative_balance`, `status`, `created_by`)
SELECT NULL, 'LWP', 'Leave Without Pay', 'Unpaid leave when paid leave is unavailable.', '#f59e0b', 0, 'all', 1, 1, 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `hr_leave_types` WHERE `company_id` IS NULL AND `code` = 'LWP');

INSERT INTO `hr_leave_types` (`company_id`, `code`, `name`, `description`, `color`, `is_paid`, `gender_eligibility`, `allow_negative_balance`, `status`, `created_by`)
SELECT NULL, 'MATERNITY', 'Maternity Leave', 'Maternity leave available to eligible female employees.', '#ec4899', 1, 'female', 0, 1, 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `hr_leave_types` WHERE `company_id` IS NULL AND `code` = 'MATERNITY');

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT seed.name, seed.slug, 1, 1
FROM (
    SELECT 'HRMS Employee Master View' AS name, 'hrms_employee_master_view' AS slug
    UNION ALL SELECT 'HRMS Employee Master Manage', 'hrms_employee_master_manage'
    UNION ALL SELECT 'HRMS Leave Management', 'hrms_leave_manage'
    UNION ALL SELECT 'HRMS Offboarding Management', 'hrms_offboarding_manage'
    UNION ALL SELECT 'HRMS Attendance Management', 'hrms_attendance_manage'
    UNION ALL SELECT 'HRMS Shift Management', 'hrms_shift_manage'
) seed
WHERE NOT EXISTS (SELECT 1 FROM `permissions` p WHERE p.slug = seed.slug);

INSERT INTO `roles` (`name`, `description`, `status`, `created_by`)
SELECT 'Employee', 'Employee self-service access for HRMS profile, leave and offboarding.', 1, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `roles` WHERE LOWER(`name`) = 'employee' AND `deleted_at` IS NULL);

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT source.role_id, target.id, 1
FROM (
    SELECT rp.role_id
    FROM `role_permissions` rp
    INNER JOIN `permissions` p ON p.id = rp.permission_id
    WHERE rp.status = 1 AND p.slug = 'hr_employees_menu_list'
) source
CROSS JOIN `permissions` target
WHERE target.slug IN ('hrms_employee_master_view','hrms_employee_master_manage','hrms_leave_manage','hrms_offboarding_manage','hrms_shift_manage')
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = source.role_id AND existing.permission_id = target.id
  );

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT source.role_id, target.id, 1
FROM (
    SELECT rp.role_id
    FROM `role_permissions` rp
    INNER JOIN `permissions` p ON p.id = rp.permission_id
    WHERE rp.status = 1 AND p.slug IN ('worker_attendance_menu_list','hr_attendance_summary_menu_list')
) source
CROSS JOIN `permissions` target
WHERE target.slug = 'hrms_attendance_manage'
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = source.role_id AND existing.permission_id = target.id
  );

UPDATE `role_permissions` rp
INNER JOIN `permissions` p ON p.id = rp.permission_id
SET rp.status = 1
WHERE p.slug IN (
    'hrms_employee_master_view',
    'hrms_employee_master_manage',
    'hrms_leave_manage',
    'hrms_offboarding_manage',
    'hrms_attendance_manage',
    'hrms_shift_manage'
);
