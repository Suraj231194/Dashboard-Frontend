<?php

declare(strict_types=1);

/**
 * Repairs legacy page-image BMR/BPR field geometry.
 *
 * Dry run:
 *   php admin/migrations/repair_legacy_bmr_bpr_layouts.php
 * Apply database and checked-in layout repairs:
 *   php admin/migrations/repair_legacy_bmr_bpr_layouts.php --apply
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../workflow/bmr_bpr_legacy_layout.php';

$apply = in_array('--apply', $argv, true);
$projectRoot = dirname(__DIR__, 2);
$catalogPath = $projectRoot . '/assets/bmr-bpr-templates/catalog.json';
$catalog = json_decode((string) file_get_contents($catalogPath), true);
if (!is_array($catalog)) {
    throw new RuntimeException('The BMR/BPR template catalog is invalid.');
}

$assetChanged = 0;
$assetDefectsBefore = 0;
$assetDefectsAfter = 0;
$templates = array_merge(
    (array) ($catalog['templates'] ?? []),
    (array) ($catalog['unmapped_templates'] ?? [])
);
foreach ($templates as $template) {
    $layoutPath = $projectRoot . '/' . ltrim((string) ($template['layout_path'] ?? ''), '/');
    if (!is_file($layoutPath)) {
        continue;
    }
    $layout = json_decode((string) file_get_contents($layoutPath), true);
    if (!is_array($layout)) {
        throw new RuntimeException('Invalid layout JSON: ' . $layoutPath);
    }
    $before = bmrBprLegacyLayoutDefects($layout);
    $normalized = bmrBprNormalizeLegacyLayout($layout);
    $after = bmrBprLegacyLayoutDefects($normalized);
    $assetDefectsBefore += array_sum($before);
    $assetDefectsAfter += array_sum($after);
    if ($normalized === $layout) {
        continue;
    }
    $assetChanged++;
    if ($apply) {
        $encoded = json_encode(
            $normalized,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
        if (file_put_contents($layoutPath, $encoded . PHP_EOL) === false) {
            throw new RuntimeException('Unable to update layout: ' . $layoutPath);
        }
    }
}

$rows = $conn->query(
    "SELECT id, template_code, layout_json
     FROM bmr_templates
     WHERE status = 1 AND deleted_at IS NULL"
);
if (!$rows) {
    throw new RuntimeException('Unable to load active BMR/BPR templates.');
}

$databaseChanged = 0;
$databaseDefectsBefore = 0;
$databaseDefectsAfter = 0;
$databaseUpdates = [];
while ($row = $rows->fetch_assoc()) {
    $layout = json_decode((string) ($row['layout_json'] ?? ''), true);
    if (!is_array($layout) || (int) ($layout['schema_version'] ?? 1) >= 2) {
        continue;
    }
    $before = bmrBprLegacyLayoutDefects($layout);
    $normalized = bmrBprNormalizeLegacyLayout($layout);
    $after = bmrBprLegacyLayoutDefects($normalized);
    $databaseDefectsBefore += array_sum($before);
    $databaseDefectsAfter += array_sum($after);
    if ($normalized === $layout) {
        continue;
    }
    $databaseChanged++;
    $databaseUpdates[] = [
        'id' => (int) $row['id'],
        'template_code' => (string) $row['template_code'],
        'layout_json' => json_encode(
            $normalized,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        ),
    ];
}

if ($apply && $databaseUpdates !== []) {
    $conn->begin_transaction();
    try {
        $update = $conn->prepare(
            'UPDATE bmr_templates
             SET layout_json = ?, updated_by = 1, updated_at = NOW()
             WHERE id = ? AND status = 1 AND deleted_at IS NULL'
        );
        if (!$update) {
            throw new RuntimeException('Unable to prepare the legacy layout repair.');
        }
        foreach ($databaseUpdates as $item) {
            $update->bind_param('si', $item['layout_json'], $item['id']);
            if (!$update->execute() || $update->affected_rows !== 1) {
                throw new RuntimeException(
                    'Unable to repair template ' . $item['template_code'] . '.'
                );
            }
        }
        $update->close();
        $conn->commit();
    } catch (Throwable $exception) {
        $conn->rollback();
        throw $exception;
    }
}

echo ($apply ? 'Applied' : 'Dry run') . ' legacy BMR/BPR layout repair.' . PHP_EOL;
echo "Asset layouts changed: {$assetChanged}; defects {$assetDefectsBefore} -> {$assetDefectsAfter}." . PHP_EOL;
echo "Database templates changed: {$databaseChanged}; defects {$databaseDefectsBefore} -> {$databaseDefectsAfter}." . PHP_EOL;
echo 'Controlled snapshots and completed records were not modified.' . PHP_EOL;
