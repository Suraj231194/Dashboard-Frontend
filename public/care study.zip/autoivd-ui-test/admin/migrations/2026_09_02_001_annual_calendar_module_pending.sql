-- =====================================================
-- Migration: Annual Calendar & Working Days Module
-- Date: 2026-09-02
-- Description: Creates tables for the HRMS Annual Calendar
--              configuration module.
-- =====================================================

-- 1. Calendar metadata per company per year
CREATE TABLE IF NOT EXISTS `hr_annual_calendars` (
    `id`                  INT AUTO_INCREMENT PRIMARY KEY,
    `company_id`          BIGINT UNSIGNED NOT NULL,
    `calendar_year`       SMALLINT UNSIGNED NOT NULL,
    `saturday_policy`     ENUM('all_working','all_off','2nd_4th_off','alternate_off')
                          NOT NULL DEFAULT 'all_working',
    `total_days`          SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_sundays`       SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_saturday_offs` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_holidays`      SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `total_working_days`  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `is_finalized`        TINYINT(1) NOT NULL DEFAULT 0,
    `finalized_by`        INT DEFAULT NULL,
    `finalized_at`        DATETIME DEFAULT NULL,
    `status`              TINYINT NOT NULL DEFAULT 1,
    `created_by`          INT DEFAULT NULL,
    `created_at`          DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_by`          INT DEFAULT NULL,
    `updated_at`          DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at`          DATETIME DEFAULT NULL,
    `deleted_by`          INT DEFAULT NULL,
    UNIQUE KEY `uq_company_year` (`company_id`, `calendar_year`),
    KEY `idx_year` (`calendar_year`),
    CONSTRAINT `fk_ac_company` FOREIGN KEY (`company_id`)
        REFERENCES `erp_companies`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Holiday entries linked to a specific calendar year
CREATE TABLE IF NOT EXISTS `hr_annual_calendar_holidays` (
    `id`              INT AUTO_INCREMENT PRIMARY KEY,
    `calendar_id`     INT NOT NULL,
    `holiday_date`    DATE NOT NULL,
    `holiday_name`    VARCHAR(150) NOT NULL,
    `holiday_type`    ENUM('national','company','festival','restricted','other')
                      NOT NULL DEFAULT 'national',
    `is_enabled`      TINYINT(1) NOT NULL DEFAULT 1,
    `created_by`      INT DEFAULT NULL,
    `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_by`      INT DEFAULT NULL,
    `updated_at`      DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_calendar_date` (`calendar_id`, `holiday_date`),
    KEY `idx_holiday_date` (`holiday_date`),
    CONSTRAINT `fk_ach_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Audit log for post-finalization edits
CREATE TABLE IF NOT EXISTS `hr_annual_calendar_audit_log` (
    `id`              INT AUTO_INCREMENT PRIMARY KEY,
    `calendar_id`     INT NOT NULL,
    `action`          VARCHAR(50) NOT NULL,
    `field_changed`   VARCHAR(100) DEFAULT NULL,
    `old_value`       TEXT DEFAULT NULL,
    `new_value`       TEXT DEFAULT NULL,
    `changed_by`      INT NOT NULL,
    `changed_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_audit_calendar` (`calendar_id`),
    CONSTRAINT `fk_acal_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rollback (if required):
-- DROP TABLE IF EXISTS `hr_annual_calendar_audit_log`;
-- DROP TABLE IF EXISTS `hr_annual_calendar_holidays`;
-- DROP TABLE IF EXISTS `hr_annual_calendars`;
