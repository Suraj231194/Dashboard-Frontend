<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$apply = in_array('--apply', $argv, true);
$actorId = 1;
$backfillLockName = 'manuverse_transfer_ticket_trace_backfill';
$backfillLockAcquired = false;

function normalizeTransferTraceValue(?string $value): string
{
    $value = mb_strtolower(trim((string) $value));
    return preg_replace('/\s+/u', ' ', $value) ?: $value;
}

function appendTransferTraceIndex(array &$index, string $key, int $id): void
{
    if ($key === '') {
        return;
    }
    $index[$key] ??= [];
    if (!in_array($id, $index[$key], true)) {
        $index[$key][] = $id;
    }
}

function verifiedTransferTicketCandidates(mysqli $conn): array
{
    $plansById = [];
    $plansByLot = [];
    $plansByLotProduct = [];
    $planResult = $conn->query(
        "SELECT id, production_plan_no, name, lo_batch_no
         FROM production_plans
         WHERE status != 3 AND deleted_at IS NULL"
    );
    if (!$planResult) {
        throw new RuntimeException('Unable to load Production Plans: ' . $conn->error);
    }
    while ($plan = $planResult->fetch_assoc()) {
        $planId = (int) $plan['id'];
        $lotKey = normalizeTransferTraceValue($plan['lo_batch_no'] ?? '');
        $productKey = normalizeTransferTraceValue($plan['name'] ?? '');
        $plansById[$planId] = $plan;
        appendTransferTraceIndex($plansByLot, $lotKey, $planId);
        appendTransferTraceIndex($plansByLotProduct, $lotKey . '|' . $productKey, $planId);
    }

    $fgById = [];
    $fgByCoa = [];
    $fgByBatchProduct = [];
    $assignedFgIds = [];
    $fgResult = $conn->query(
        "SELECT id, production_plan_id, coa_fg, product_name, batch_number
         FROM fg_coa_generation
         WHERE status != 3 AND deleted_at IS NULL"
    );
    if (!$fgResult) {
        throw new RuntimeException('Unable to load FG COAs: ' . $conn->error);
    }
    while ($fg = $fgResult->fetch_assoc()) {
        $fgId = (int) $fg['id'];
        $coaKey = normalizeTransferTraceValue($fg['coa_fg'] ?? '');
        $batchKey = normalizeTransferTraceValue($fg['batch_number'] ?? '');
        $productKey = normalizeTransferTraceValue($fg['product_name'] ?? '');
        $fgById[$fgId] = $fg;
        appendTransferTraceIndex($fgByCoa, $coaKey, $fgId);
        appendTransferTraceIndex($fgByBatchProduct, $batchKey . '|' . $productKey, $fgId);
    }

    $assignedResult = $conn->query(
        "SELECT source_fg_coa_id
         FROM transfer_ticket
         WHERE status != 3 AND deleted_at IS NULL
           AND source_fg_coa_id IS NOT NULL AND source_fg_coa_id > 0"
    );
    if (!$assignedResult) {
        throw new RuntimeException('Unable to inspect existing FG COA trace links: ' . $conn->error);
    }
    while ($assigned = $assignedResult->fetch_assoc()) {
        $assignedFgIds[(int) $assigned['source_fg_coa_id']] = true;
    }

    $ticketResult = $conn->query(
        "SELECT id, ticket_no, fg_coa_no, product_description, batch_no,
                source_fg_coa_id, prod_plan_id, updated_by, updated_at
         FROM transfer_ticket
         WHERE status != 3 AND deleted_at IS NULL
           AND (source_fg_coa_id IS NULL OR source_fg_coa_id = 0
                OR prod_plan_id IS NULL OR prod_plan_id = 0)
         ORDER BY id ASC"
    );
    if (!$ticketResult) {
        throw new RuntimeException('Unable to load Transfer Tickets: ' . $conn->error);
    }

    $candidates = [];
    $unresolved = ['source_fg_coa' => 0, 'production_plan' => 0];
    $inspected = 0;
    while ($ticket = $ticketResult->fetch_assoc()) {
        $inspected++;
        $oldFgId = (int) ($ticket['source_fg_coa_id'] ?? 0);
        $oldPlanId = (int) ($ticket['prod_plan_id'] ?? 0);
        $newFgId = $oldFgId;
        $newPlanId = $oldPlanId;
        $fgMethod = $oldFgId > 0 ? 'existing_source_fg_coa' : '';
        $planMethod = $oldPlanId > 0 ? 'existing_production_plan' : '';

        $coaKey = normalizeTransferTraceValue($ticket['fg_coa_no'] ?? '');
        $batchKey = normalizeTransferTraceValue($ticket['batch_no'] ?? '');
        $productKey = normalizeTransferTraceValue($ticket['product_description'] ?? '');

        if ($newFgId <= 0) {
            $coaMatches = $fgByCoa[$coaKey] ?? [];
            if ($coaKey !== '' && count($coaMatches) === 1) {
                $newFgId = (int) $coaMatches[0];
                $fgMethod = 'unique_fg_coa_number';
            } else {
                $batchProductMatches = $fgByBatchProduct[$batchKey . '|' . $productKey] ?? [];
                if ($batchKey !== '' && $productKey !== '' && count($batchProductMatches) === 1) {
                    $newFgId = (int) $batchProductMatches[0];
                    $fgMethod = 'unique_batch_and_product';
                }
            }
        }

        if ($newPlanId <= 0 && $newFgId > 0) {
            $fgPlanId = (int) ($fgById[$newFgId]['production_plan_id'] ?? 0);
            if ($fgPlanId > 0 && isset($plansById[$fgPlanId])) {
                $newPlanId = $fgPlanId;
                $planMethod = 'source_fg_coa_production_plan';
            }
        }
        if ($newPlanId <= 0) {
            $batchProductMatches = $plansByLotProduct[$batchKey . '|' . $productKey] ?? [];
            if ($batchKey !== '' && $productKey !== '' && count($batchProductMatches) === 1) {
                $newPlanId = (int) $batchProductMatches[0];
                $planMethod = 'unique_batch_and_product';
            } else {
                $batchMatches = $plansByLot[$batchKey] ?? [];
                if ($batchKey !== '' && count($batchMatches) === 1) {
                    $newPlanId = (int) $batchMatches[0];
                    $planMethod = 'unique_batch_number';
                }
            }
        }

        if ($newFgId <= 0) {
            $unresolved['source_fg_coa']++;
        }
        if ($newPlanId <= 0) {
            $unresolved['production_plan']++;
        }
        if ($newFgId === $oldFgId && $newPlanId === $oldPlanId) {
            continue;
        }

        $candidates[] = [
            'transfer_ticket_id' => (int) $ticket['id'],
            'ticket_no' => (string) ($ticket['ticket_no'] ?? ''),
            'old_source_fg_coa_id' => $oldFgId ?: null,
            'new_source_fg_coa_id' => $newFgId ?: null,
            'old_production_plan_id' => $oldPlanId ?: null,
            'new_production_plan_id' => $newPlanId ?: null,
            'fg_match_method' => $fgMethod,
            'plan_match_method' => $planMethod,
            'old_updated_by' => isset($ticket['updated_by']) ? (int) $ticket['updated_by'] : null,
            'old_updated_at' => $ticket['updated_at'] ?? null,
        ];
    }

    // transfer_ticket enforces one ticket per source FG COA. A legacy FG match
    // is safe only when it is not already assigned and exactly one unlinked
    // ticket resolves to it; otherwise no ticket is selected arbitrarily.
    $candidateFgCounts = [];
    foreach ($candidates as $candidate) {
        if ($candidate['old_source_fg_coa_id'] === null && $candidate['new_source_fg_coa_id'] !== null) {
            $fgId = (int) $candidate['new_source_fg_coa_id'];
            $candidateFgCounts[$fgId] = ($candidateFgCounts[$fgId] ?? 0) + 1;
        }
    }
    foreach ($candidates as &$candidate) {
        if ($candidate['old_source_fg_coa_id'] !== null || $candidate['new_source_fg_coa_id'] === null) {
            continue;
        }
        $fgId = (int) $candidate['new_source_fg_coa_id'];
        if (isset($assignedFgIds[$fgId]) || ($candidateFgCounts[$fgId] ?? 0) !== 1) {
            $candidate['new_source_fg_coa_id'] = null;
            $candidate['fg_match_method'] = '';
            $unresolved['source_fg_coa']++;
        }
    }
    unset($candidate);
    $candidates = array_values(array_filter(
        $candidates,
        static fn (array $candidate): bool =>
            $candidate['new_source_fg_coa_id'] !== $candidate['old_source_fg_coa_id']
            || $candidate['new_production_plan_id'] !== $candidate['old_production_plan_id']
    ));

    return ['inspected' => $inspected, 'candidates' => $candidates, 'unresolved' => $unresolved];
}

try {
    if ($apply) {
        $lockStmt = $conn->prepare('SELECT GET_LOCK(?, 30) AS acquired');
        if (!$lockStmt) {
            throw new RuntimeException('Unable to prepare the Transfer Ticket backfill lock.');
        }
        $lockStmt->bind_param('s', $backfillLockName);
        $lockStmt->execute();
        $backfillLockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
        $lockStmt->close();
        if (!$backfillLockAcquired) {
            throw new RuntimeException('Another Transfer Ticket trace backfill is already running.');
        }
    }

    $analysis = verifiedTransferTicketCandidates($conn);
    if (!$apply) {
        echo json_encode([
            'mode' => 'preview',
            'inspected' => $analysis['inspected'],
            'eligible' => count($analysis['candidates']),
            'unresolved' => $analysis['unresolved'],
            'candidates' => $analysis['candidates'],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), PHP_EOL;
        exit;
    }

    $createAudit = $conn->query(
        "CREATE TABLE IF NOT EXISTS transfer_ticket_trace_backfill_audit (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            transfer_ticket_id int(11) NOT NULL,
            ticket_no varchar(255) DEFAULT NULL,
            old_source_fg_coa_id int(11) DEFAULT NULL,
            new_source_fg_coa_id int(11) DEFAULT NULL,
            old_production_plan_id int(11) DEFAULT NULL,
            new_production_plan_id int(11) DEFAULT NULL,
            fg_match_method varchar(80) DEFAULT NULL,
            plan_match_method varchar(80) DEFAULT NULL,
            old_updated_by int(11) DEFAULT NULL,
            old_updated_at datetime DEFAULT NULL,
            applied_by int(11) NOT NULL,
            applied_at datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (id),
            KEY idx_transfer_trace_ticket (transfer_ticket_id),
            KEY idx_transfer_trace_applied (applied_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
    if (!$createAudit) {
        throw new RuntimeException('Unable to create the Transfer Ticket trace audit: ' . $conn->error);
    }

    // Retain one immutable audit record if an earlier interrupted shell left
    // two concurrent processes applying the exact same verified transition.
    $deduplicateAudit = $conn->query(
        "DELETE duplicate_row
         FROM transfer_ticket_trace_backfill_audit duplicate_row
         INNER JOIN transfer_ticket_trace_backfill_audit retained_row
           ON retained_row.id < duplicate_row.id
          AND retained_row.transfer_ticket_id = duplicate_row.transfer_ticket_id
          AND retained_row.old_source_fg_coa_id <=> duplicate_row.old_source_fg_coa_id
          AND retained_row.new_source_fg_coa_id <=> duplicate_row.new_source_fg_coa_id
          AND retained_row.old_production_plan_id <=> duplicate_row.old_production_plan_id
          AND retained_row.new_production_plan_id <=> duplicate_row.new_production_plan_id
          AND retained_row.fg_match_method <=> duplicate_row.fg_match_method
          AND retained_row.plan_match_method <=> duplicate_row.plan_match_method"
    );
    if (!$deduplicateAudit) {
        throw new RuntimeException('Unable to reconcile duplicate Transfer Ticket trace audits: ' . $conn->error);
    }

    $auditStmt = $conn->prepare(
        "INSERT INTO transfer_ticket_trace_backfill_audit
            (transfer_ticket_id, ticket_no, old_source_fg_coa_id, new_source_fg_coa_id,
             old_production_plan_id, new_production_plan_id, fg_match_method,
             plan_match_method, old_updated_by, old_updated_at, applied_by, applied_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
    );
    $updateStmt = $conn->prepare(
        "UPDATE transfer_ticket
         SET source_fg_coa_id = ?, prod_plan_id = ?, updated_by = ?, updated_at = NOW()
         WHERE id = ?"
    );
    $verifyStmt = $conn->prepare(
        "SELECT source_fg_coa_id, prod_plan_id FROM transfer_ticket WHERE id = ?"
    );
    if (!$auditStmt || !$updateStmt || !$verifyStmt) {
        throw new RuntimeException('Unable to prepare Transfer Ticket trace updates: ' . $conn->error);
    }

    $conn->begin_transaction();
    $updated = 0;
    foreach ($analysis['candidates'] as $candidate) {
        $ticketId = (int) $candidate['transfer_ticket_id'];
        $ticketNo = (string) $candidate['ticket_no'];
        $oldFgId = $candidate['old_source_fg_coa_id'];
        $newFgId = $candidate['new_source_fg_coa_id'];
        $oldPlanId = $candidate['old_production_plan_id'];
        $newPlanId = $candidate['new_production_plan_id'];
        $fgMethod = (string) $candidate['fg_match_method'];
        $planMethod = (string) $candidate['plan_match_method'];
        $oldUpdatedBy = $candidate['old_updated_by'];
        $oldUpdatedAt = $candidate['old_updated_at'];

        $auditStmt->bind_param(
            'isiiiissisi',
            $ticketId,
            $ticketNo,
            $oldFgId,
            $newFgId,
            $oldPlanId,
            $newPlanId,
            $fgMethod,
            $planMethod,
            $oldUpdatedBy,
            $oldUpdatedAt,
            $actorId
        );
        if (!$auditStmt->execute()) {
            throw new RuntimeException('Unable to audit Transfer Ticket ' . $ticketId . ': ' . $auditStmt->error);
        }

        $updateStmt->bind_param('iiii', $newFgId, $newPlanId, $actorId, $ticketId);
        if (!$updateStmt->execute()) {
            throw new RuntimeException('Unable to update Transfer Ticket ' . $ticketId . ': ' . $updateStmt->error);
        }
        if ($updateStmt->affected_rows !== 1) {
            throw new RuntimeException('Transfer Ticket ' . $ticketId . ' changed after preview; the audited backfill was stopped.');
        }

        $verifyStmt->bind_param('i', $ticketId);
        $verifyStmt->execute();
        $verified = $verifyStmt->get_result()->fetch_assoc();
        if ((int) ($verified['source_fg_coa_id'] ?? 0) !== (int) $newFgId
            || (int) ($verified['prod_plan_id'] ?? 0) !== (int) $newPlanId) {
            throw new RuntimeException('Verification failed for Transfer Ticket ' . $ticketId . '.');
        }
        $updated++;
    }
    $conn->commit();

    if ($backfillLockAcquired) {
        $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
        if ($releaseStmt) {
            $releaseStmt->bind_param('s', $backfillLockName);
            $releaseStmt->execute();
            $releaseStmt->close();
        }
        $backfillLockAcquired = false;
    }

    echo json_encode([
        'mode' => 'applied',
        'inspected' => $analysis['inspected'],
        'updated' => $updated,
        'unresolved' => $analysis['unresolved'],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), PHP_EOL;
} catch (Throwable $exception) {
    try {
        $conn->rollback();
    } catch (Throwable) {
    }
    if ($backfillLockAcquired) {
        try {
            $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
            if ($releaseStmt) {
                $releaseStmt->bind_param('s', $backfillLockName);
                $releaseStmt->execute();
                $releaseStmt->close();
            }
        } catch (Throwable) {
        }
    }
    fwrite(STDERR, 'Transfer Ticket trace backfill failed: ' . $exception->getMessage() . PHP_EOL);
    exit(1);
}
