<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_09_02_002_annual_calendar_production_ready.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Annual calendar production migration SQL is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Annual calendar production migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) {
        $result->free();
    }
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Annual calendar production migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) {
        break;
    }
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Annual calendar production migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$requiredTables = [
    'hr_annual_calendars',
    'hr_annual_calendar_holidays',
    'hr_annual_calendar_custom_offs',
    'hr_annual_calendar_days',
    'hr_annual_calendar_audit_events',
];
foreach ($requiredTables as $tableName) {
    $escaped = $conn->real_escape_string($tableName);
    $tableCheck = $conn->query("SHOW TABLES LIKE '{$escaped}'");
    if (!$tableCheck || $tableCheck->num_rows !== 1) {
        fwrite(STDERR, "Annual calendar production migration verification failed: table {$tableName} not found.\n");
        exit(1);
    }
}

$requiredColumns = [
    'hr_annual_calendars' => ['revision_no','lifecycle_status','content_hash','lock_version'],
    'payroll_runs' => ['calendar_revision_id','calendar_hash','calendar_working_days'],
    'payroll_run_items' => ['eligible_working_days','paid_leave_days','unpaid_leave_days','lop_days'],
    'hr_leave_application_days' => ['calendar_day_type','is_chargeable'],
];
foreach ($requiredColumns as $tableName => $columns) {
    foreach ($columns as $columnName) {
        $result = $conn->query("SHOW COLUMNS FROM `{$tableName}` LIKE '{$columnName}'");
        if (!$result || $result->num_rows !== 1) {
            fwrite(STDERR, "Migration verification failed: {$tableName}.{$columnName} not found.\n");
            exit(1);
        }
    }
}

echo "Annual Calendar production migration applied and verified successfully.\n";
