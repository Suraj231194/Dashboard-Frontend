UPDATE `order_received`
SET `source_type` = 1
WHERE `source_type` = 0;

ALTER TABLE `order_received`
    MODIFY COLUMN `source_type` INT(10) NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS `order_number_sequences` (
    `sequence_date` DATE NOT NULL,
    `last_sequence` INT UNSIGNED NOT NULL DEFAULT 0,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`sequence_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `order_number_sequences` (`sequence_date`, `last_sequence`)
SELECT `sequence_date`, MAX(`sequence_number`)
FROM (
    SELECT
        STR_TO_DATE(SUBSTRING(`order_number`, 10, 10), '%d-%m-%Y') AS `sequence_date`,
        CAST(SUBSTRING_INDEX(`order_number`, '-', -1) AS UNSIGNED) AS `sequence_number`
    FROM `order_received`
    WHERE `order_number` REGEXP '^BIPL-ORD-[0-9]{2}-[0-9]{2}-[0-9]{4}-[0-9]+$'
) AS `existing_sequences`
WHERE `sequence_date` IS NOT NULL
GROUP BY `sequence_date`
ON DUPLICATE KEY UPDATE
    `last_sequence` = GREATEST(`order_number_sequences`.`last_sequence`, VALUES(`last_sequence`));

CREATE TEMPORARY TABLE `order_number_repair_candidates` AS
SELECT
    `ranked_orders`.`id`,
    COALESCE(`ranked_orders`.`date_order_received`, DATE(`ranked_orders`.`created_at`), CURRENT_DATE()) AS `sequence_date`
FROM (
    SELECT
        `id`,
        `order_number`,
        `date_order_received`,
        `created_at`,
        ROW_NUMBER() OVER (PARTITION BY `order_number` ORDER BY `id`) AS `duplicate_rank`
    FROM `order_received`
    WHERE `order_number` IS NOT NULL AND TRIM(`order_number`) != ''
) AS `ranked_orders`
WHERE `ranked_orders`.`duplicate_rank` > 1
UNION ALL
SELECT
    `id`,
    COALESCE(`date_order_received`, DATE(`created_at`), CURRENT_DATE()) AS `sequence_date`
FROM `order_received`
WHERE `order_number` IS NULL OR TRIM(`order_number`) = '';

ALTER TABLE `order_number_repair_candidates`
    ADD PRIMARY KEY (`id`),
    ADD INDEX `idx_order_number_repair_date` (`sequence_date`);

INSERT INTO `order_number_sequences` (`sequence_date`, `last_sequence`)
SELECT DISTINCT `sequence_date`, 0
FROM `order_number_repair_candidates`
ON DUPLICATE KEY UPDATE `last_sequence` = `order_number_sequences`.`last_sequence`;

CREATE TEMPORARY TABLE `order_number_reassignments` AS
SELECT
    `candidates`.`id`,
    `candidates`.`sequence_date`,
    `sequences`.`last_sequence`
        + ROW_NUMBER() OVER (PARTITION BY `candidates`.`sequence_date` ORDER BY `candidates`.`id`) AS `new_sequence`
FROM `order_number_repair_candidates` AS `candidates`
INNER JOIN `order_number_sequences` AS `sequences`
    ON `sequences`.`sequence_date` = `candidates`.`sequence_date`;

ALTER TABLE `order_number_reassignments`
    ADD PRIMARY KEY (`id`),
    ADD INDEX `idx_order_number_reassignment_date` (`sequence_date`);

UPDATE `order_received` AS `orders`
INNER JOIN `order_number_reassignments` AS `reassignments`
    ON `reassignments`.`id` = `orders`.`id`
SET `orders`.`order_number` = CONCAT(
    'BIPL-ORD-',
    DATE_FORMAT(`reassignments`.`sequence_date`, '%d-%m-%Y'),
    '-',
    LPAD(`reassignments`.`new_sequence`, 2, '0')
);

UPDATE `order_number_sequences` AS `sequences`
INNER JOIN (
    SELECT `sequence_date`, COUNT(*) AS `assigned_count`
    FROM `order_number_repair_candidates`
    GROUP BY `sequence_date`
) AS `repairs`
    ON `repairs`.`sequence_date` = `sequences`.`sequence_date`
SET `sequences`.`last_sequence` = `sequences`.`last_sequence` + `repairs`.`assigned_count`;

DROP TEMPORARY TABLE `order_number_reassignments`;
DROP TEMPORARY TABLE `order_number_repair_candidates`;

CREATE UNIQUE INDEX `uq_order_received_order_number`
    ON `order_received` (`order_number`);
