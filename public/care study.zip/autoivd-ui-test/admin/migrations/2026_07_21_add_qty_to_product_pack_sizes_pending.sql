-- ============================================================
-- Migration: Add qty column to product_pack_sizes table
-- Date: 2026-07-21
-- Description: Adds qty (initial stock quantity) column to
--              product_pack_sizes for tracking pack-level stock.
-- ============================================================

ALTER TABLE `product_pack_sizes` ADD COLUMN `qty` DECIMAL(12,3) DEFAULT 0.000 AFTER `pack_unit_id`;
