-- Add repeatable email addresses to each Company Setup location.
-- The original location email remains populated with the primary address for compatibility.

CREATE TABLE IF NOT EXISTS `company_profile_location_emails` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `location_id` BIGINT UNSIGNED NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_company_profile_location_email` (`location_id`, `email`),
    KEY `idx_company_profile_location_emails_location` (`location_id`),
    CONSTRAINT `fk_company_profile_location_emails_location`
        FOREIGN KEY (`location_id`) REFERENCES `company_profile_locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `company_profile_location_emails`
    (`location_id`, `email`, `is_primary`, `sort_order`)
SELECT `id`, TRIM(`email`), 1, 0
FROM `company_profile_locations` locations
WHERE locations.`email` IS NOT NULL
  AND TRIM(locations.`email`) != ''
  AND NOT EXISTS (
      SELECT 1
      FROM `company_profile_location_emails` existing
      WHERE existing.`location_id` = locations.`id`
        AND existing.`email` = TRIM(locations.`email`)
  );
