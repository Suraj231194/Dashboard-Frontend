-- Rollback for 2026_09_04_004_whatsapp_processing_status_compatibility.sql
--
-- Restores the original enum definition. Rows still holding 'received' are
-- mapped back to 'parse_error' first, because that value cannot survive the
-- narrower definition and would otherwise be truncated to ''.

SET @whatsapp_processing_status_is_enum := (
    SELECT COUNT(*)
    FROM `information_schema`.`COLUMNS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'whatsapp_order_log'
      AND `COLUMN_NAME` = 'processing_status'
      AND `DATA_TYPE` = 'enum'
);

SET @whatsapp_processing_status_demote_sql := IF(
    @whatsapp_processing_status_is_enum = 0,
    'SELECT ''whatsapp_order_log.processing_status is not an enum; nothing to roll back'' AS migration_status',
    'UPDATE `whatsapp_order_log` SET `processing_status` = ''parse_error'' WHERE `processing_status` = ''received'''
);

PREPARE whatsapp_processing_status_demote_stmt FROM @whatsapp_processing_status_demote_sql;
EXECUTE whatsapp_processing_status_demote_stmt;
DEALLOCATE PREPARE whatsapp_processing_status_demote_stmt;

SET @whatsapp_processing_status_revert_sql := IF(
    @whatsapp_processing_status_is_enum = 0,
    'SELECT ''skipped'' AS migration_status',
    'ALTER TABLE `whatsapp_order_log` MODIFY COLUMN `processing_status` ENUM(''success'',''parse_error'',''validation_error'',''system_error'',''duplicate'') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''parse_error'''
);

PREPARE whatsapp_processing_status_revert_stmt FROM @whatsapp_processing_status_revert_sql;
EXECUTE whatsapp_processing_status_revert_stmt;
DEALLOCATE PREPARE whatsapp_processing_status_revert_stmt;

DELETE FROM `_schema_migrations_applied`
WHERE `migration` = '2026_09_04_004_whatsapp_processing_status_compatibility.sql';
