-- Align existing Goods Receipts with the documented Quality workflow.
-- New receipts are queued by application code; this backfills older RM/PM
-- receipts that were not queued because of their physical-condition value.

INSERT IGNORE INTO `coa_inbound_queue` (
    `stock_inward_id`,
    `product_id`,
    `product_category_id`,
    `supplier_id`,
    `quantity`,
    `quantity_unit`,
    `goods_type`,
    `status`,
    `created_by`
)
SELECT
    inward.`id`,
    inward.`product_id`,
    inward.`materialtype_prodcateg_id`,
    inward.`supplier_id`,
    inward.`prod_quantity`,
    inward.`prod_quantity_unit`,
    CASE
        WHEN COALESCE(product.`inventory_group`, category.`inventory_group`, 3) = 2 THEN 'PM'
        ELSE 'RM'
    END,
    0,
    inward.`created_by`
FROM `stock_inwards` inward
INNER JOIN `products` product
    ON product.`id` = inward.`product_id`
   AND product.`status` = 1
   AND product.`deleted_at` IS NULL
LEFT JOIN `product_categories` category
    ON category.`id` = product.`category_id`
WHERE inward.`deleted_at` IS NULL
  AND inward.`product_id` IS NOT NULL
  AND COALESCE(inward.`prod_quantity`, 0) > 0
  AND COALESCE(product.`inventory_group`, category.`inventory_group`, 3) IN (2, 3)
  AND NOT EXISTS (
      SELECT 1
      FROM `coa_inbound_queue` existing
      WHERE existing.`stock_inward_id` = inward.`id`
  )
  AND NOT EXISTS (
      SELECT 1
      FROM `coa_rm_pm_table` existing_coa
      WHERE existing_coa.`stock_inward_id` = inward.`id`
        AND existing_coa.`deleted_at` IS NULL
  );
