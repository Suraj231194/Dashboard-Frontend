ALTER TABLE `order_received` ADD COLUMN `raw_content` TEXT DEFAULT NULL AFTER `payment_details`;
