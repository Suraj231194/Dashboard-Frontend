<?php

declare(strict_types=1);

/**
 * Installs the image-free common Serology BMR/BPR templates and maps every
 * approved ASO, CRP, RF and RPR test-pack product to its own profile.
 *
 * Completed, in-process and populated work items keep their current template.
 * Blank queued/pending Serology work items are switched to the code renderer.
 *
 * Usage:
 *   php admin/migrations/seed_common_structured_serology_bmr_bpr.php
 */

require_once dirname(__DIR__) . '/db.php';

$schemaRoot = dirname(__DIR__, 2) . '/assets/bmr-bpr-schemas';
$definitions = [
    [
        'path' => $schemaRoot . '/common-serology-bmr-v3.json',
        'template_code' => 'COMMON_SEROLOGY_BMR_V03',
        'template_name' => 'Common Serology BMR',
        'form_type' => 'BMR',
        'page_count' => 4,
        'document_no' => 'BIPL-BMR-01',
    ],
    [
        'path' => $schemaRoot . '/common-serology-bpr-v3.json',
        'template_code' => 'COMMON_SEROLOGY_BPR_V03',
        'template_name' => 'Common Serology BPR',
        'form_type' => 'BPR',
        'page_count' => 12,
        'document_no' => 'BIPL-BPR-01',
    ],
];
$profileProductCodes = [
    1043 => 'BGX/FIN.SERO/2026/000009', // ASO Latex 50 Tests
    1044 => 'BGX/FIN.SERO/2026/000008', // ASO Latex 25 Tests
    1045 => 'BGX/FIN.SERO/2026/000007', // ASO Latex 100 Tests
    1039 => 'BGX/FIN.SERO/2026/000013', // CRP Latex 50 Tests
    1040 => 'BGX/FIN.SERO/2026/000012', // CRP Latex 25 Tests
    1041 => 'BGX/FIN.SERO/2026/000011', // CRP Latex 100 Tests
    1034 => 'BGX/FIN.SERO/2026/000029', // RF Latex 25 Tests
    1035 => 'BGX/FIN.SERO/2026/000028', // RF Latex 100 Tests
    2014 => 'BGX/FIN.SERO/2026/000030', // RF Latex 50 Tests
    1028 => 'BGX/FIN.SERO/2026/000033', // RPR Latex 50 Tests
    1029 => 'BGX/FIN.SERO/2026/000032', // RPR Latex 100 Tests
];

$escapedProductCodes = array_map(
    static fn (string $code): string => "'" . $conn->real_escape_string($code) . "'",
    array_values($profileProductCodes)
);
$productResult = $conn->query(
    'SELECT id, product_code FROM products WHERE product_code IN ('
    . implode(',', $escapedProductCodes)
    . ') AND status != 3 AND deleted_at IS NULL'
);
if (!$productResult) {
    throw new RuntimeException('Unable to resolve the approved Serology products.');
}
$productIdsByCode = [];
while ($productRow = $productResult->fetch_assoc()) {
    $productIdsByCode[(string) $productRow['product_code']] = (int) $productRow['id'];
}
$profileProductIds = [];
foreach ($profileProductCodes as $legacyProductId => $productCode) {
    $liveProductId = (int) ($productIdsByCode[$productCode] ?? 0);
    if ($liveProductId <= 0) {
        throw new RuntimeException("Approved Serology product {$productCode} is unavailable.");
    }
    $profileProductIds[$legacyProductId] = $liveProductId;
}
$approvedProductIds = array_values($profileProductIds);
$approvedProductSql = implode(',', $approvedProductIds);

$lockName = 'common_structured_serology_bmr_bpr_v3';
$lockResult = $conn->query(
    "SELECT GET_LOCK('" . $conn->real_escape_string($lockName) . "', 15) AS acquired"
);
$lockRow = $lockResult ? $lockResult->fetch_assoc() : null;
if ((int) ($lockRow['acquired'] ?? 0) !== 1) {
    fwrite(STDERR, "Unable to acquire the Serology template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (?, 'Serology Common', ?, ?, ?, 3, ?, '01', '02', '2025-04-03',
                 'PROFILE-DRIVEN', NULL, NULL, NULL, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             product_id = VALUES(product_id),
             product_name = VALUES(product_name),
             template_name = VALUES(template_name),
             form_type = VALUES(form_type),
             version_no = 3,
             document_no = VALUES(document_no),
             issue_no = '01',
             revision_no = '02',
             effective_date = '2025-04-03',
             mfr_reference = 'PROFILE-DRIVEN',
             source_pdf_path = NULL,
             page_asset_path = NULL,
             source_checksum = NULL,
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $validateProduct = $conn->prepare(
        'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_product_mappings
            (template_id, product_id, form_type, document_sequence, required_quantity,
             status, created_by, created_at)
         VALUES (?, ?, ?, 1, 1, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             document_sequence = 1,
             required_quantity = 1,
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$upsertTemplate || !$findTemplate || !$validateProduct || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare Serology template database statements.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        if (!is_file($definition['path'])) {
            throw new RuntimeException('Serology template schema is missing: ' . $definition['path']);
        }
        $layoutJson = (string) file_get_contents($definition['path']);
        $layout = json_decode($layoutJson, true);
        if (
            !is_array($layout)
            || (int) ($layout['schema_version'] ?? 0) !== 2
            || (string) ($layout['renderer'] ?? '') !== 'structured_html'
            || (string) ($layout['renderer_variant'] ?? '') !== 'serology'
            || strtoupper((string) ($layout['form_type'] ?? '')) !== $definition['form_type']
            || !is_array($layout['profiles'] ?? null)
        ) {
            throw new RuntimeException('Serology template schema is invalid: ' . $definition['path']);
        }

        $remappedProfiles = [];
        foreach ($profileProductIds as $legacyProductId => $liveProductId) {
            $profile = $layout['profiles'][(string) $legacyProductId] ?? null;
            if (!is_array($profile)) {
                throw new RuntimeException("Serology profile {$legacyProductId} is missing.");
            }
            $remappedProfiles[(string) $liveProductId] = $profile;
        }
        $layout['profiles'] = $remappedProfiles;
        $layoutJson = json_encode(
            $layout,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );

        $productIds = array_values(array_map('intval', array_keys($remappedProfiles)));
        sort($productIds);
        $expectedProductIds = $approvedProductIds;
        sort($expectedProductIds);
        if ($productIds !== $expectedProductIds) {
            throw new RuntimeException(
                'Serology template profiles do not match the approved product set: '
                . $definition['path']
            );
        }

        $canonicalProductId = $productIds[0];
        $templateName = $definition['template_name'];
        $formType = $definition['form_type'];
        $templateCode = $definition['template_code'];
        $documentNo = $definition['document_no'];
        $pageCount = (int) $definition['page_count'];
        $upsertTemplate->bind_param(
            'issssis',
            $canonicalProductId,
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException(
                'Unable to save Serology template ' . $templateCode . ': ' . $upsertTemplate->error
            );
        }

        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException('Unable to resolve Serology template ' . $templateCode);
        }
        $templateCount++;

        foreach ($productIds as $productId) {
            $validateProduct->bind_param('i', $productId);
            $validateProduct->execute();
            if (!$validateProduct->get_result()->fetch_assoc()) {
                throw new RuntimeException("Mapped Serology product ID {$productId} is unavailable.");
            }
            $upsertMapping->bind_param('iis', $templateId, $productId, $formType);
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map Serology product {$productId} to {$templateCode}: "
                    . $upsertMapping->error
                );
            }
            $mappingCount++;
        }
    }

    $safeRequestSnapshots = $conn->query(
        "UPDATE bmr_bpr_request_documents request_document
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = request_document.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = request_document.form_type
           AND mapping.document_sequence = request_document.document_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET request_document.template_id = mapping.template_id,
             request_document.updated_by = 1,
             request_document.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_work_items started_item
               WHERE started_item.request_id = request_document.request_id
                 AND started_item.form_type = request_document.form_type
                 AND started_item.deleted_at IS NULL
                 AND (
                     started_item.status IN ('IN_PROCESS', 'COMPLETE')
                     OR (
                         started_item.form_payload_json IS NOT NULL
                         AND started_item.form_payload_json NOT IN ('', '{}')
                     )
                 )
           )"
    );
    if ($safeRequestSnapshots === false) {
        throw new RuntimeException('Unable to update safe Serology request template snapshots.');
    }
    $snapshotCount = $conn->affected_rows;

    $safeIncoming = $conn->query(
        "UPDATE bmr_bpr_work_items work_item
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = work_item.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = work_item.form_type
           AND mapping.document_sequence = 1
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET work_item.template_id = mapping.template_id,
             work_item.updated_by = 1,
             work_item.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND work_item.status IN ('QUEUED', 'PENDING')
           AND (
               work_item.form_payload_json IS NULL
               OR work_item.form_payload_json IN ('', '{}')
           )"
    );
    if ($safeIncoming === false) {
        throw new RuntimeException('Unable to map safe incoming Serology BMR/BPR work items.');
    }
    $incomingCount = $conn->affected_rows;

    $retireLegacy = $conn->query(
        "UPDATE bmr_templates legacy_template
         SET legacy_template.status = 0,
             legacy_template.source_pdf_path = NULL,
             legacy_template.page_asset_path = NULL,
             legacy_template.source_checksum = NULL,
             legacy_template.updated_by = 1,
             legacy_template.updated_at = NOW()
         WHERE legacy_template.template_code IN (
             'ASO_BMR_V02',
             'ASO_BPR_V02',
             'CRP_BMR_V02',
             'CRP_BPR_V02',
             'RF_BMR_V02',
             'RF_BPR_V02',
             'RPR_LATEX_BMR_V02',
             'RPR_LATEX_BPR_V02'
         )
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_work_items legacy_work_item
               WHERE legacy_work_item.template_id = legacy_template.id
                 AND legacy_work_item.deleted_at IS NULL
           )
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_request_documents legacy_request_document
               WHERE legacy_request_document.template_id = legacy_template.id
           )"
    );
    if ($retireLegacy === false) {
        throw new RuntimeException('Unable to retire unused Serology image-backed templates.');
    }
    $retiredTemplateCount = $conn->affected_rows;

    $upsertTemplate->close();
    $findTemplate->close();
    $validateProduct->close();
    $upsertMapping->close();
    $conn->commit();

    echo "Common Serology structured templates saved: {$templateCount}\n";
    echo "Distinct Serology product mappings updated: {$mappingCount}\n";
    echo "Safe Serology request snapshots updated: {$snapshotCount}\n";
    echo "Blank queued/pending Serology work items mapped: {$incomingCount}\n";
    echo "Unused image-backed Serology templates retired: {$retiredTemplateCount}\n";
    echo "In-process, completed and populated legacy records were not reassigned.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . "\n");
    $conn->query("SELECT RELEASE_LOCK('" . $conn->real_escape_string($lockName) . "')");
    exit(1);
}

$conn->query("SELECT RELEASE_LOCK('" . $conn->real_escape_string($lockName) . "')");
