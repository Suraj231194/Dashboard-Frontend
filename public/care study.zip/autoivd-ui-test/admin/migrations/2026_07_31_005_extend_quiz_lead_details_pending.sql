-- Additive Quiz lead detail storage for Website -> ERP response snapshots.
-- Question Mapping remains Website-only; ERP stores submitted answer text only.

ALTER TABLE `quiz_leads`
  ADD COLUMN IF NOT EXISTS `profiling_data` longtext DEFAULT NULL AFTER `participant_phone`,
  ADD COLUMN IF NOT EXISTS `submitted_at` datetime DEFAULT NULL AFTER `lead_status`;

CREATE TABLE IF NOT EXISTS `quiz_lead_answers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quiz_lead_id` bigint(20) unsigned NOT NULL,
  `answer_order` int(11) unsigned NOT NULL DEFAULT 1,
  `question_text` text NOT NULL,
  `phase_title` varchar(150) DEFAULT NULL,
  `question_type` varchar(50) DEFAULT NULL,
  `selected_option` text DEFAULT NULL,
  `selected_label` varchar(10) DEFAULT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_quiz_lead_answers_order` (`quiz_lead_id`, `answer_order`),
  KEY `idx_quiz_lead_answers_lead` (`quiz_lead_id`),
  CONSTRAINT `fk_quiz_lead_answers_lead`
    FOREIGN KEY (`quiz_lead_id`) REFERENCES `quiz_leads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
