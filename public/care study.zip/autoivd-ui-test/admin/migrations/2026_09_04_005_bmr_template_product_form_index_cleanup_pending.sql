-- =============================================================================
-- Migration: 2026_09_04_005_bmr_template_product_form_index_cleanup_pending.sql
-- Purpose: BMR/BPR product mapping index cleanup for multi-document batch records
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @mapping_form_index_exists := (
    SELECT COUNT(DISTINCT `INDEX_NAME`)
    FROM `information_schema`.`STATISTICS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'bmr_template_product_mappings'
      AND `INDEX_NAME` = 'uq_bmr_template_product_form'
);

SET @mapping_document_index_exists := (
    SELECT COUNT(*)
    FROM `information_schema`.`STATISTICS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'bmr_template_product_mappings'
      AND `INDEX_NAME` = 'uq_bmr_template_product_document'
      AND `NON_UNIQUE` = 0
);

SET @mapping_form_index_sql := IF(
    @mapping_form_index_exists = 1 AND @mapping_document_index_exists = 3,
    'ALTER TABLE `bmr_template_product_mappings` DROP INDEX `uq_bmr_template_product_form`',
    'SELECT ''bmr_template_product_mappings index already correct, or replacement key missing; no change'' AS migration_status'
);

PREPARE mapping_form_index_stmt FROM @mapping_form_index_sql;
EXECUTE mapping_form_index_stmt;
DEALLOCATE PREPARE mapping_form_index_stmt;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_005_bmr_template_product_form_index_cleanup_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_005_bmr_template_product_form_index_cleanup_pending.sql', '2026_09_04_005_bmr_template_product_form_index_cleanup.sql')
);
