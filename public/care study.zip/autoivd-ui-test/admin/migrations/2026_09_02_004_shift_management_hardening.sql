-- =====================================================
-- Migration: Shift Management hardening
-- Date: 2026-09-02
-- Fixes tenant isolation on shift policies, scopes shifts to a company/branch,
-- and adds the attendance fields needed for lunch deduction and early-leave
-- detection.
-- =====================================================

-- Shifts were global; scope them so one company cannot see another's roster options.
ALTER TABLE `shifts`
    ADD COLUMN IF NOT EXISTS `company_id` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `name`,
    ADD COLUMN IF NOT EXISTS `branch_id` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `company_id`,
    ADD INDEX IF NOT EXISTS `idx_shift_scope` (`company_id`, `branch_id`, `status`);

-- A half-day threshold of zero classifies a one-minute punch as a half day.
UPDATE `shifts`
SET `half_day_hours` = ROUND(
        TIMESTAMPDIFF(
            MINUTE,
            CONCAT('2000-01-01 ', `start_time`),
            CASE WHEN `end_time` <= `start_time`
                THEN DATE_ADD(CONCAT('2000-01-01 ', `end_time`), INTERVAL 1 DAY)
                ELSE CONCAT('2000-01-01 ', `end_time`) END
        ) / 120, 2)
WHERE `half_day_hours` IS NULL OR `half_day_hours` <= 0;

-- 0 is the "applies to every company / branch" sentinel so the unique key can hold.
ALTER TABLE `hr_shift_policies`
    ADD COLUMN IF NOT EXISTS `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT FIRST,
    DROP PRIMARY KEY,
    ADD PRIMARY KEY (`id`);

UPDATE `hr_shift_policies` SET `company_id` = 0 WHERE `company_id` IS NULL;
UPDATE `hr_shift_policies` SET `branch_id` = 0 WHERE `branch_id` IS NULL;

ALTER TABLE `hr_shift_policies`
    MODIFY COLUMN `company_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    MODIFY COLUMN `branch_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    ADD UNIQUE INDEX IF NOT EXISTS `uq_shift_policy_scope` (`shift_id`, `company_id`, `branch_id`, `effective_from`),
    ADD INDEX IF NOT EXISTS `idx_shift_policy_lookup` (`company_id`, `branch_id`, `effective_from`, `effective_to`);

ALTER TABLE `hr_shift_policies`
    ADD CONSTRAINT `fk_shift_policy_shift` FOREIGN KEY IF NOT EXISTS (`shift_id`)
        REFERENCES `shifts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `hr_attendance_daily`
    ADD COLUMN IF NOT EXISTS `early_minutes` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `late_minutes`,
    ADD COLUMN IF NOT EXISTS `break_minutes` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `early_minutes`,
    MODIFY COLUMN `classification` ENUM('on_time','late','early_leave','half_day','full_day','absent','incomplete','holiday','weekly_off','off_day_work') NOT NULL DEFAULT 'incomplete';
