<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/catalog_seeder.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/urine_strip/profiles.php';

try {
    $result = coaSeedTemplateCatalog($conn, [
        'catalog' => coaUrineStripProfiles(),
        'product_ids' => coaUrineStripMappedProductIds(),
        'renderer_variant' => 'urine_strip',
        'source_directory' => 'URINE STRIP',
        'lock_name' => 'common_urine_strip_ip_fg_coa_v1',
        'page_count' => 2,
        'document' => [
            'title' => 'CERTIFICATE OF ANALYSIS',
            'document_no' => 'BIPL-F-COA-01',
            'issue_no' => '01',
            'revision_no' => '02',
            'effective_date' => '03/04/2023',
            'review_date' => '03/04/2025',
            'department' => 'Quality Control',
            'supersedes' => 'Nil',
            'company_address' => 'B19/A S.I.L. Ancillary Estate, Amausi Industrial Area, Nadarganj-226008 (Lucknow)',
        ],
        'effective_date_sql' => '2023-04-03',
        'review_date_sql' => '2025-04-03',
        'definitions' => [
            [
                'coa_type' => 'IP',
                'template_code' => 'COMMON_URINE_STRIP_IP_COA_V01',
                'template_name' => 'Common Urine Strip IP COA',
            ],
            [
                'coa_type' => 'FG',
                'template_code' => 'COMMON_URINE_STRIP_FG_COA_V01',
                'template_name' => 'Common Urine Strip FG COA',
            ],
        ],
    ]);
    echo "Installed {$result['templates']} Urine Strip COA templates and "
        . "{$result['mappings']} product mappings.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
