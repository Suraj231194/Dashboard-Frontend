<?php

declare(strict_types=1);

/**
 * Installs the image-free common Hematology BMR/BPR templates and maps the
 * five approved products to them.
 *
 * Completed, in-process and populated work items keep their current template.
 * Blank queued/pending Hematology work items are safely switched so the common
 * form is available immediately in the Production BMR/BPR submenu.
 *
 * Usage:
 *   php admin/migrations/seed_common_structured_bmr_bpr.php
 */

require_once dirname(__DIR__) . '/db.php';

$schemaRoot = dirname(__DIR__, 2) . '/assets/bmr-bpr-schemas';
$definitions = [
    [
        'path' => $schemaRoot . '/common-hematology-bmr-v3.json',
        'template_code' => 'COMMON_HEMATOLOGY_BMR_V03',
        'template_name' => 'Common Hematology BMR',
        'form_type' => 'BMR',
        'page_count' => 5,
        'document_no' => 'BIPL-BMR-01',
    ],
    [
        'path' => $schemaRoot . '/common-hematology-bpr-v3.json',
        'template_code' => 'COMMON_HEMATOLOGY_BPR_V03',
        'template_name' => 'Common Hematology BPR',
        'form_type' => 'BPR',
        'page_count' => 8,
        'document_no' => 'BIPL-BPR-01',
    ],
];

$lockName = 'common_structured_hematology_bmr_bpr_v3';
$lockResult = $conn->query("SELECT GET_LOCK('" . $conn->real_escape_string($lockName) . "', 15) AS acquired");
$lockRow = $lockResult ? $lockResult->fetch_assoc() : null;
if ((int) ($lockRow['acquired'] ?? 0) !== 1) {
    fwrite(STDERR, "Unable to acquire the common-template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (?, 'Hematology Common', ?, ?, ?, 3, ?, '01', '02', '2025-04-03',
                 'PROFILE-DRIVEN', NULL, NULL, NULL, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             product_id = VALUES(product_id),
             product_name = VALUES(product_name),
             template_name = VALUES(template_name),
             form_type = VALUES(form_type),
             version_no = 3,
             document_no = VALUES(document_no),
             issue_no = '01',
             revision_no = '02',
             effective_date = '2025-04-03',
             mfr_reference = 'PROFILE-DRIVEN',
             source_pdf_path = NULL,
             page_asset_path = NULL,
             source_checksum = NULL,
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $validateProduct = $conn->prepare(
        'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_product_mappings
            (template_id, product_id, form_type, document_sequence, required_quantity,
             status, created_by, created_at)
         VALUES (?, ?, ?, 1, 1, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             document_sequence = 1,
             required_quantity = 1,
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$upsertTemplate || !$findTemplate || !$validateProduct || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare common-template database statements.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        if (!is_file($definition['path'])) {
            throw new RuntimeException('Common template schema is missing: ' . $definition['path']);
        }
        $layoutJson = (string) file_get_contents($definition['path']);
        $layout = json_decode($layoutJson, true);
        if (
            !is_array($layout)
            || (int) ($layout['schema_version'] ?? 0) !== 2
            || (string) ($layout['renderer'] ?? '') !== 'structured_html'
            || strtoupper((string) ($layout['form_type'] ?? '')) !== $definition['form_type']
            || !is_array($layout['profiles'] ?? null)
            || count($layout['profiles']) !== 5
        ) {
            throw new RuntimeException('Common template schema is invalid: ' . $definition['path']);
        }

        $productIds = array_values(array_map('intval', array_keys($layout['profiles'])));
        $canonicalProductId = $productIds[0];
        $templateName = $definition['template_name'];
        $formType = $definition['form_type'];
        $templateCode = $definition['template_code'];
        $documentNo = $definition['document_no'];
        $pageCount = (int) $definition['page_count'];
        $upsertTemplate->bind_param(
            'issssis',
            $canonicalProductId,
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException('Unable to save common template ' . $templateCode . ': ' . $upsertTemplate->error);
        }

        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException('Unable to resolve common template ' . $templateCode);
        }
        $templateCount++;

        foreach ($productIds as $productId) {
            $validateProduct->bind_param('i', $productId);
            $validateProduct->execute();
            if (!$validateProduct->get_result()->fetch_assoc()) {
                throw new RuntimeException("Mapped product ID {$productId} is unavailable.");
            }
            $upsertMapping->bind_param('iis', $templateId, $productId, $formType);
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map product {$productId} to {$templateCode}: {$upsertMapping->error}"
                );
            }
            $mappingCount++;
        }
    }

    $safeRequestSnapshots = $conn->query(
        "UPDATE bmr_bpr_request_documents request_document
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = request_document.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = request_document.form_type
           AND mapping.document_sequence = request_document.document_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET request_document.template_id = mapping.template_id,
             request_document.updated_by = 1,
             request_document.updated_at = NOW()
         WHERE request_row.product_id IN (1071, 1067, 1064, 1055, 1053)
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_work_items started_item
               WHERE started_item.request_id = request_document.request_id
                 AND started_item.form_type = request_document.form_type
                 AND started_item.deleted_at IS NULL
                 AND (
                     started_item.status IN ('IN_PROCESS', 'COMPLETE')
                     OR (
                         started_item.form_payload_json IS NOT NULL
                         AND started_item.form_payload_json NOT IN ('', '{}')
                     )
                 )
           )"
    );
    if ($safeRequestSnapshots === false) {
        throw new RuntimeException('Unable to update safe incoming request template snapshots.');
    }
    $snapshotCount = $conn->affected_rows;

    $safeIncoming = $conn->query(
        "UPDATE bmr_bpr_work_items work_item
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = work_item.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = work_item.form_type
           AND mapping.document_sequence = 1
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET work_item.template_id = mapping.template_id,
             work_item.updated_by = 1,
             work_item.updated_at = NOW()
         WHERE request_row.product_id IN (1071, 1067, 1064, 1055, 1053)
           AND work_item.status IN ('QUEUED', 'PENDING')
           AND (
               work_item.form_payload_json IS NULL
               OR work_item.form_payload_json IN ('', '{}')
           )"
    );
    if ($safeIncoming === false) {
        throw new RuntimeException('Unable to map safe incoming BMR/BPR work items.');
    }
    $incomingCount = $conn->affected_rows;

    $retireLegacy = $conn->query(
        "UPDATE bmr_templates legacy_template
         SET legacy_template.status = 0,
             legacy_template.source_pdf_path = NULL,
             legacy_template.page_asset_path = NULL,
             legacy_template.source_checksum = NULL,
             legacy_template.updated_by = 1,
             legacy_template.updated_at = NOW()
         WHERE legacy_template.template_code IN (
             'BLOOD_CELL_DILUENT_BMR_V02',
             'BLOOD_CELL_DILUENT_BPR_V02',
             'ENZYMATIC_CLEANER_BMR_V02',
             'ENZYMATIC_CLEANER_BPR_V02',
             'LYSE_500ML_BMR_V02',
             'LYSE_500ML_BPR_V02',
             'PROBE_CLEANER_BMR_V02',
             'PROBE_CLEANER_BPR_V02',
             'RINSE_20LTR_BMR_V02',
             'RINSE_20LTR_BPR_V02'
         )
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_work_items legacy_work_item
               WHERE legacy_work_item.template_id = legacy_template.id
                 AND legacy_work_item.deleted_at IS NULL
           )
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_request_documents legacy_request_document
               WHERE legacy_request_document.template_id = legacy_template.id
           )"
    );
    if ($retireLegacy === false) {
        throw new RuntimeException('Unable to retire unused Hematology image-backed templates.');
    }
    $retiredTemplateCount = $conn->affected_rows;

    $upsertTemplate->close();
    $findTemplate->close();
    $validateProduct->close();
    $upsertMapping->close();
    $conn->commit();

    echo "Common structured templates saved: {$templateCount}\n";
    echo "Hematology product mappings updated: {$mappingCount}\n";
    echo "Safe request snapshots updated: {$snapshotCount}\n";
    echo "Blank queued/pending work items mapped: {$incomingCount}\n";
    echo "Unused image-backed Hematology templates retired: {$retiredTemplateCount}\n";
    echo "In-process, completed and populated legacy records were not reassigned.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . "\n");
    $conn->query("SELECT RELEASE_LOCK('" . $conn->real_escape_string($lockName) . "')");
    exit(1);
}

$conn->query("SELECT RELEASE_LOCK('" . $conn->real_escape_string($lockName) . "')");
