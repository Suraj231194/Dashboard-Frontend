-- Archive table used by cleanup_inconsistent_transactions.php.
CREATE TABLE IF NOT EXISTS transaction_cleanup_archive (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  cleanup_run_id CHAR(36) NOT NULL,
  source_table VARCHAR(80) NOT NULL,
  source_id BIGINT NOT NULL,
  row_json LONGTEXT NOT NULL,
  deleted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_transaction_cleanup_run (cleanup_run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;