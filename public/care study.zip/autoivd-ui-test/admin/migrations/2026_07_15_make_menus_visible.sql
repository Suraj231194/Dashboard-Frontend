-- ============================================================
-- Migration: Add missing menus, permissions, and role assignments
-- Date: 2026-07-15
-- Description: Makes Order Management, COA Generation, COA Templates,
--              IP COA Generation, and FG COA Generation visible.
--              Uses INSERT IGNORE as an "IF NOT EXISTS" check to prevent duplicates.
-- ============================================================

-- 1. Insert permissions (ignored if they already exist due to unique slug index)
INSERT IGNORE INTO `permissions` (`name`, `slug`, `status`, `created_by`) VALUES
('COA Generation Menu List', 'coa_generation_menu_list', 1, 1),
('Store Order Received Menu List', 'store_order_received_menu_list', 1, 1),
('IP COA Generation Menu List', 'ip_coa_generation_menu_list', 1, 1),
('FG COA Generation Menu List', 'fg_coa_generation_menu_list', 1, 1),
('COA Templates Menu List', 'coa_templates_menu_list', 1, 1);


-- 2. Insert menus (ignored if they already exist due to primary key id index)
INSERT IGNORE INTO `menus` (`id`, `name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`) VALUES
(29, 'C.O.A Generation', 'index.php?page=coa-generation', '', 26, 2, 'coa_generation_menu_list', 1, 1, 1),
(33, 'C.O.A Templates', 'index.php?page=coa-templates', '', 21, 7, 'coa_templates_menu_list', 1, 1, 1),
(35, 'Order Management', 'index.php?page=order-received', '', 30, 3, 'store_order_received_menu_list', 1, 1, 1),
(57, 'IP COA Generation', 'index.php?page=ip-coa-generation', '', 15, 6, 'ip_coa_generation_menu_list', 1, 1, 22),
(58, 'FG COA Generation', 'index.php?page=fg-coa-generation', '', 15, 7, 'fg_coa_generation_menu_list', 1, 1, 22);


-- 3. Assign permissions to respective roles (ignored if assignment already exists due to unique role_id + permission_id index)
-- 3a. COA Generation (roles: Super Admin, QA/QC, Quality Assurance, Admin, Senior Admin, Plant Head, Technical Reviewer)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.id, p.id, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE p.slug = 'coa_generation_menu_list'
  AND r.id IN (1, 7, 8, 9, 11, 12, 19);

-- 3b. COA Templates (roles: Super Admin, Quality Assurance, Plant Head, QA/QC, Admin, Senior Admin, Technical Reviewer)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.id, p.id, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE p.slug = 'coa_templates_menu_list'
  AND r.id IN (1, 7, 8, 9, 11, 12, 19);

-- 3c. Order Management (roles: Super Admin, Store/SCM, Admin, Senior Admin, Sales, Sales & Marketing, Technical Reviewer)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.id, p.id, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE p.slug = 'store_order_received_menu_list'
  AND r.id IN (1, 3, 11, 12, 13, 15, 18, 19);

-- 3d. IP COA Generation (roles: Super Admin, Production, QA/QC, Production/Billing, Technical Reviewer)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.id, p.id, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE p.slug = 'ip_coa_generation_menu_list'
  AND r.id IN (1, 4, 9, 17, 19);

-- 3e. FG COA Generation (roles: Super Admin, Production, QA/QC, Production/Billing, Technical Reviewer)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.id, p.id, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE p.slug = 'fg_coa_generation_menu_list'
  AND r.id IN (1, 4, 9, 17, 19);
