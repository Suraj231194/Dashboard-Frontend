ALTER TABLE `stock_inwards` ADD COLUMN `warehouse_id` INT(11) DEFAULT NULL AFTER `supplier_id`;
ALTER TABLE `live_stock` ADD COLUMN `warehouse_id` INT(11) DEFAULT NULL AFTER `product_category_id`;
