-- Additive Production navigation registration for the BMR/BPR landing page.
-- Existing menus, permissions, records, and role assignments are not changed.

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
SELECT
    'Production BMR/BPR View',
    'production_bmr_bpr_view',
    1,
    1,
    NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `permissions`
    WHERE `slug` = 'production_bmr_bpr_view'
);

INSERT INTO `menus`
    (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`,
     `showmenu`, `status`, `created_by`, `created_at`)
SELECT
    'BMR/BPR',
    'index.php?page=production-bmr-bpr',
    'ti ti-file-waveform',
    production_menu.id,
    8,
    'production_bmr_bpr_view',
    1,
    1,
    1,
    NOW()
FROM `menus` production_menu
WHERE production_menu.id = 15
  AND production_menu.name = 'Production'
  AND production_menu.status = 1
  AND production_menu.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM `menus` existing_menu
      WHERE existing_menu.route = 'index.php?page=production-bmr-bpr'
        AND existing_menu.deleted_at IS NULL
  );

-- Inherit access from the Production parent menu. Explicit per-user deny rules
-- continue to take precedence in the existing menu access implementation.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT
    production_role.role_id,
    bmr_bpr_permission.id,
    1
FROM `role_permissions` production_role
INNER JOIN `permissions` production_permission
    ON production_permission.id = production_role.permission_id
   AND production_permission.slug = 'production_menu'
INNER JOIN `permissions` bmr_bpr_permission
    ON bmr_bpr_permission.slug = 'production_bmr_bpr_view'
WHERE production_role.status = 1
  AND NOT EXISTS (
      SELECT 1
      FROM `role_permissions` existing_assignment
      WHERE existing_assignment.role_id = production_role.role_id
        AND existing_assignment.permission_id = bmr_bpr_permission.id
  );
