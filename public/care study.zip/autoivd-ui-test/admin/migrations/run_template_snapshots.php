<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$constraintNames = [
    'fk_bmr_request_document_snapshot',
    'fk_bmr_work_item_snapshot',
    'fk_ip_coa_snapshot',
    'fk_fg_coa_snapshot',
];
$quotedNames = implode(',', array_fill(0, count($constraintNames), '?'));
$check = $conn->prepare(
    "SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME IN ({$quotedNames})"
);
$check->bind_param('ssss', ...$constraintNames);
$check->execute();
$constraintCount = (int) ($check->get_result()->fetch_row()[0] ?? 0);
$check->close();
if ($constraintCount === count($constraintNames)) {
    echo "Template snapshot schema is ready.\n";
    exit(0);
}

$path = __DIR__ . '/2026_09_23_002_template_snapshots_pending.sql';
$sql = file_get_contents($path);
if ($sql === false || trim($sql) === '') {
    throw new RuntimeException('Template snapshot migration SQL is unavailable.');
}

$conn->multi_query($sql);
do {
    if ($result = $conn->store_result()) {
        $result->free();
    }
} while ($conn->more_results() && $conn->next_result());

echo "Template snapshot schema is ready.\n";
