-- =====================================================
-- Migration: Annual Calendar & Working Days hardening
-- Date: 2026-09-02
-- Adds configurable weekly-off days, optional (restricted) holidays,
-- per-date overrides, declared/effective holiday totals and referential
-- integrity between payroll runs and the calendar revision they consumed.
-- =====================================================

ALTER TABLE `hr_annual_calendars`
    ADD COLUMN IF NOT EXISTS `weekly_off_days` VARCHAR(20) NOT NULL DEFAULT '7' AFTER `saturday_policy`,
    ADD COLUMN IF NOT EXISTS `total_declared_holidays` SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER `total_holidays`,
    ADD COLUMN IF NOT EXISTS `total_optional_holidays` SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER `total_declared_holidays`;

UPDATE `hr_annual_calendars`
SET `weekly_off_days` = '7'
WHERE `weekly_off_days` IS NULL OR TRIM(`weekly_off_days`) = '';

ALTER TABLE `hr_annual_calendar_holidays`
    ADD COLUMN IF NOT EXISTS `is_optional` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_enabled`;

-- Restricted holidays are employee-elective and must not reduce company working days.
UPDATE `hr_annual_calendar_holidays`
SET `is_optional` = 1
WHERE `holiday_type` = 'restricted';

ALTER TABLE `hr_annual_calendar_days`
    ADD COLUMN IF NOT EXISTS `is_optional_holiday` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_holiday`;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_day_overrides` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `calendar_id` INT NOT NULL,
    `override_date` DATE NOT NULL,
    `override_type` ENUM('working_day','weekly_off') NOT NULL,
    `note` VARCHAR(200) NOT NULL DEFAULT '',
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ac_day_override` (`calendar_id`, `override_date`),
    KEY `idx_ac_day_override_date` (`override_date`),
    CONSTRAINT `fk_ac_day_override_calendar` FOREIGN KEY (`calendar_id`)
        REFERENCES `hr_annual_calendars` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `payroll_runs`
    ADD CONSTRAINT `fk_payroll_run_calendar_revision` FOREIGN KEY IF NOT EXISTS (`calendar_revision_id`)
        REFERENCES `hr_annual_calendars` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT seed.name, seed.slug, 1, 1
FROM (SELECT 'HRMS Annual Calendar Override Payroll Lock' AS name, 'hrms_calendar_override_locked' AS slug) seed
WHERE NOT EXISTS (SELECT 1 FROM `permissions` permission WHERE permission.slug = seed.slug);

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND LOWER(role.name) IN ('human resources','administrator','senior administrator','super administrator')
  AND permission.slug = 'hrms_calendar_override_locked'
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );
