<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/catalog_seeder.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/serology/profiles.php';

try {
    $catalog = coaSerologyProfiles();
    if (count($catalog) !== 4 || coaSerologySourceDocumentCount() !== 33) {
        throw new RuntimeException('The Serology COA source catalog is incomplete.');
    }
    $result = coaSeedTemplateCatalog($conn, [
        'catalog' => $catalog,
        'product_ids' => coaSerologyMappedProductIds(),
        'renderer_variant' => 'serology',
        'source_directory' => 'SEROLOGY COA 2026',
        'lock_name' => 'common_serology_ip_fg_coa_v1',
        'page_count' => 2,
        'document' => [
            'title' => 'CERTIFICATE OF ANALYSIS',
            'document_no' => 'BIPL-F-COA-01',
            'issue_no' => '01',
            'revision_no' => '02',
            'effective_date' => '03/04/2025',
            'review_date' => '02/04/2028',
            'department' => 'Quality Control',
            'supersedes' => 'Nil',
            'company_address' => 'B19/A S.I.L. Ancillary Estate, Amausi Industrial Area, Nadarganj-226008 (Lucknow)',
        ],
        'effective_date_sql' => '2025-04-03',
        'review_date_sql' => '2028-04-02',
        'definitions' => [
            [
                'coa_type' => 'IP',
                'template_code' => 'COMMON_SEROLOGY_IP_COA_V01',
                'template_name' => 'Common Serology IP COA',
            ],
            [
                'coa_type' => 'FG',
                'template_code' => 'COMMON_SEROLOGY_FG_COA_V01',
                'template_name' => 'Common Serology FG COA',
            ],
        ],
    ]);
    echo "Installed {$result['templates']} Serology COA templates and "
        . "{$result['mappings']} product mappings.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
