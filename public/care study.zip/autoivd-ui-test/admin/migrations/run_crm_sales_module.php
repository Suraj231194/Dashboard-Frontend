<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationFiles = [
    __DIR__ . '/2026_08_16_001_crm_sales_module_pending.sql',
    __DIR__ . '/2026_08_16_002_crm_menus_and_permissions_pending.sql',
    __DIR__ . '/2026_08_17_001_crm_sales_completion_pending.sql',
];

foreach ($migrationFiles as $migrationPath) {
    $sql = file_get_contents($migrationPath);

    if ($sql === false || trim($sql) === '') {
        fwrite(STDERR, 'Migration file is unavailable: ' . basename($migrationPath) . PHP_EOL);
        exit(1);
    }

    if (!$conn->multi_query($sql)) {
        fwrite(STDERR, basename($migrationPath) . ' failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }

    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }

        if ($conn->errno !== 0) {
            fwrite(STDERR, basename($migrationPath) . ' failed: ' . $conn->error . PHP_EOL);
            exit(1);
        }
    } while ($conn->more_results() && $conn->next_result());

    if ($conn->errno !== 0) {
        fwrite(STDERR, basename($migrationPath) . ' failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }

    echo basename($migrationPath) . " applied successfully.\n";
}

$requiredTables = [
    'crm_leads',
    'crm_lead_products',
    'crm_lead_activity_log',
    'salesperson_masters',
    'salesperson_territories',
    'salesperson_product_expertise',
    'salesperson_product_responsibility',
];

foreach ($requiredTables as $tableName) {
    $stmt = $conn->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
    );
    $stmt->bind_param('s', $tableName);
    $stmt->execute();
    $stmt->bind_result($tableCount);
    $stmt->fetch();
    $stmt->close();

    if ((int) $tableCount !== 1) {
        fwrite(STDERR, "CRM schema verification failed for {$tableName}.\n");
        exit(1);
    }
}

echo "Sales & CRM schema verification completed successfully.\n";
