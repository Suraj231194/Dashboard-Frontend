-- Migration: Expand email_order_log ENUMs for draft and confirmation flow
-- Date: 2026-09-07

ALTER TABLE `email_order_log` 
    MODIFY `processing_status` ENUM('success','parse_error','validation_error','system_error','duplicate','draft_created','confirmed') NOT NULL DEFAULT 'parse_error',
    MODIFY `response_type` ENUM('success','failure','duplicate','draft','confirmation') DEFAULT NULL;
