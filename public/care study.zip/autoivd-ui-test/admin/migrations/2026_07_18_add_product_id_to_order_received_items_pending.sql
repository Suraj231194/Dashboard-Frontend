-- ============================================================
-- Migration: Add product_id to order_received_items table
-- Date: 2026-07-18
-- Description: Adds product_id column, populates it from products,
--              and adds index for joins.
-- ============================================================

ALTER TABLE `order_received_items` ADD COLUMN `product_id` INT(11) DEFAULT NULL AFTER `order_id`;

UPDATE `order_received_items` ori 
JOIN `products` p ON p.product_name = ori.product_name 
SET ori.product_id = p.id;

ALTER TABLE `order_received_items` ADD INDEX `idx_order_received_items_product` (`product_id`);
