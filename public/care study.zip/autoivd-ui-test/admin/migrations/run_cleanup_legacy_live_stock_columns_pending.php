<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/db.php';

function columnExists(mysqli $conn, string $table, string $column): bool
{
    $stmt = $conn->prepare(
        "SELECT 1 FROM information_schema.COLUMNS 
         WHERE TABLE_SCHEMA = DATABASE() 
           AND TABLE_NAME = ? 
           AND COLUMN_NAME = ? 
         LIMIT 1"
    );
    $stmt->bind_param('ss', $table, $column);
    $stmt->execute();
    $res = $stmt->get_result();
    $exists = $res && $res->num_rows > 0;
    $stmt->close();
    return $exists;
}

function triggerExists(mysqli $conn, string $triggerName): bool
{
    $stmt = $conn->prepare(
        "SELECT 1 FROM information_schema.TRIGGERS 
         WHERE TRIGGER_SCHEMA = DATABASE() 
           AND TRIGGER_NAME = ? 
         LIMIT 1"
    );
    $stmt->bind_param('s', $triggerName);
    $stmt->execute();
    $res = $stmt->get_result();
    $exists = $res && $res->num_rows > 0;
    $stmt->close();
    return $exists;
}

echo "=== Starting Legacy Columns Cleanup for live_stock ===\n";

// 1. Drop compatibility triggers for reserved_quantity if they exist
$triggersToDrop = [
    'trg_live_stock_reserved_compat_bi',
    'trg_live_stock_reserved_compat_bu'
];

foreach ($triggersToDrop as $trg) {
    if (triggerExists($conn, $trg)) {
        $conn->query("DROP TRIGGER IF EXISTS `{$trg}`");
        echo "Dropped trigger: {$trg}\n";
    } else {
        echo "Trigger does not exist (skipped): {$trg}\n";
    }
}

// 2. Drop columns if they exist
$columnsToDrop = [
    'quantity_initial',
    'reserved_quantity',
    'quantity_in_base',
    'unit_factor'
];

foreach ($columnsToDrop as $col) {
    if (columnExists($conn, 'live_stock', $col)) {
        $conn->query("ALTER TABLE `live_stock` DROP COLUMN `{$col}`");
        echo "Dropped column: live_stock.{$col}\n";
    } else {
        echo "Column does not exist (skipped): live_stock.{$col}\n";
    }
}

// 3. Verify reserved_qty is kept
if (columnExists($conn, 'live_stock', 'reserved_qty')) {
    echo "VERIFIED: 'reserved_qty' column is present and active (KEPT).\n";
} else {
    echo "WARNING: 'reserved_qty' column was not found!\n";
}

echo "=== Cleanup completed successfully ===\n";
