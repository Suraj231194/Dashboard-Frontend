-- Product-mapped, structured IP/FG COA documents for Biochemistry.
-- Additive only: existing IP/FG records and the BMR/BPR template workflow are preserved.

CREATE TABLE IF NOT EXISTS `coa_document_templates` (
    `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
    `template_code` VARCHAR(120) NOT NULL,
    `template_name` VARCHAR(255) NOT NULL,
    `coa_type` ENUM('IP','FG') NOT NULL,
    `version_no` INT(11) NOT NULL DEFAULT 1,
    `document_no` VARCHAR(100) DEFAULT NULL,
    `issue_no` VARCHAR(30) DEFAULT NULL,
    `revision_no` VARCHAR(30) DEFAULT NULL,
    `effective_date` DATE DEFAULT NULL,
    `review_date` DATE DEFAULT NULL,
    `source_directory` VARCHAR(500) DEFAULT NULL,
    `source_checksum` CHAR(64) DEFAULT NULL,
    `page_count` SMALLINT UNSIGNED DEFAULT NULL,
    `layout_json` LONGTEXT NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_coa_document_template_code` (`template_code`),
    KEY `idx_coa_document_template_type_status` (`coa_type`, `status`, `deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `coa_template_product_mappings` (
    `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
    `template_id` BIGINT(20) NOT NULL,
    `product_id` INT(11) NOT NULL,
    `coa_type` ENUM('IP','FG') NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_coa_template_product_type` (`product_id`, `coa_type`),
    KEY `idx_coa_template_product_template` (`template_id`, `status`, `deleted_at`),
    CONSTRAINT `fk_coa_template_product_template`
        FOREIGN KEY (`template_id`) REFERENCES `coa_document_templates` (`id`),
    CONSTRAINT `fk_coa_template_product_product`
        FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `ip_coa_generation`
    ADD COLUMN IF NOT EXISTS `coa_template_id` BIGINT(20) DEFAULT NULL AFTER `product_id`,
    ADD COLUMN IF NOT EXISTS `form_payload_json` LONGTEXT DEFAULT NULL AFTER `coa_template_id`;

CREATE INDEX IF NOT EXISTS `idx_ip_coa_document_template`
    ON `ip_coa_generation` (`coa_template_id`, `deleted_at`);

ALTER TABLE `fg_coa_generation`
    ADD COLUMN IF NOT EXISTS `coa_template_id` BIGINT(20) DEFAULT NULL AFTER `product_id`,
    ADD COLUMN IF NOT EXISTS `form_payload_json` LONGTEXT DEFAULT NULL AFTER `coa_template_id`;

CREATE INDEX IF NOT EXISTS `idx_fg_coa_document_template`
    ON `fg_coa_generation` (`coa_template_id`, `deleted_at`);
