-- =====================================================
-- Migration: Email Order Drafts
-- Table to store verified email order drafts awaiting customer 'YES' confirmation
-- Date: 2026-09-07
-- =====================================================

CREATE TABLE IF NOT EXISTS `email_order_drafts` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `draft_code` VARCHAR(32) NOT NULL COMMENT 'Unique draft identifier e.g. DRF-A1B2C3',
    `from_email` VARCHAR(255) NOT NULL,
    `from_name` VARCHAR(255) DEFAULT NULL,
    `subject` VARCHAR(512) DEFAULT NULL,
    `draft_payload` JSON NOT NULL COMMENT 'Full verified order data including resolved items and customer info',
    `status` ENUM('pending_confirmation', 'confirmed', 'expired', 'cancelled') NOT NULL DEFAULT 'pending_confirmation',
    `initial_message_id` VARCHAR(512) DEFAULT NULL,
    `confirmation_message_id` VARCHAR(512) DEFAULT NULL,
    `order_id` INT DEFAULT NULL COMMENT 'FK to order_received.id upon confirmation',
    `order_number` VARCHAR(255) DEFAULT NULL COMMENT 'Generated order number upon confirmation',
    `expires_at` DATETIME NOT NULL,
    `confirmed_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_draft_code` (`draft_code`),
    KEY `idx_draft_email_status` (`from_email`, `status`),
    KEY `idx_draft_expires` (`expires_at`),
    KEY `idx_draft_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
