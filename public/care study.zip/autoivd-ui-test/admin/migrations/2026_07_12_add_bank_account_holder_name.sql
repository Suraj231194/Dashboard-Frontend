-- Add bank_account_holder_name to employees table
ALTER TABLE `employees` ADD COLUMN `bank_account_holder_name` varchar(255) DEFAULT NULL AFTER `bank_ifsc_code`;
