<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_08_27_001_hrms_pdf_foundation_pending.sql';
$sql = file_get_contents($migrationPath);

if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "HRMS migration file is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'HRMS migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

do {
    if ($result = $conn->store_result()) {
        $result->free();
    }

    if ($conn->errno !== 0) {
        fwrite(STDERR, 'HRMS migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
} while ($conn->more_results() && $conn->next_result());

$requiredTables = [
    'hr_employee_profiles',
    'hr_employee_sequences',
    'hr_salary_components',
    'hr_leave_types',
    'hr_leave_allocations',
    'hr_leave_applications',
    'hr_leave_application_days',
    'hr_leave_status_history',
    'hr_offboarding_settings',
    'hr_exit_interview_questions',
    'hr_resignation_requests',
    'hr_exit_interview_answers',
    'hr_offboarding_documents',
    'hr_biometric_devices',
    'hr_biometric_punches',
    'hr_attendance_daily',
    'hr_shift_policies',
];

$check = $conn->prepare(
    'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
);

foreach ($requiredTables as $tableName) {
    $check->bind_param('s', $tableName);
    $check->execute();
    $check->bind_result($count);
    $check->fetch();
    $check->free_result();

    if ((int) $count !== 1) {
        fwrite(STDERR, "HRMS schema verification failed for {$tableName}.\n");
        exit(1);
    }
}

$check->close();
echo "HRMS PDF foundation applied and verified successfully.\n";
