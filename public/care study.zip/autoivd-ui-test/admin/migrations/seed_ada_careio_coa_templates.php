<?php

declare(strict_types=1);

/**
 * Installs the ADA IP/FG COA profiles required by the care io.pdf workflow.
 *
 * The supplied workflow document defines the controlled quality gates but does
 * not provide product-specific numeric specifications. These profiles therefore
 * require QA/QC to record the applicable approved-specification results without
 * inventing limits that are not present in the controlled source.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$productIds = [415, 416, 417, 418, 918, 919, 920, 1954];
$familyKey = 'ada_careio';
$sourceDocument = 'care io.pdf - Production and Quality Compliance Engine';
$document = [
    'title' => 'CERTIFICATE OF ANALYSIS',
    'document_no' => 'BIPL-F-COA-01',
    'issue_no' => '01',
    'revision_no' => '02',
    'effective_date' => '03/04/2025',
    'review_date' => '02/04/2028',
    'department' => 'Quality Control',
    'supersedes' => 'Nil',
    'company_address' => 'B19/A, S.I.L. Ancillary Estate, Amausi Industrial Area, Nadarganj-226008 (Lucknow)',
];

$definitions = [
    [
        'coa_type' => 'IP',
        'template_code' => 'ADA_CAREIO_IP_COA_V01',
        'template_name' => 'ADA In-Process COA',
        'rows' => [
            [
                'key' => 'physical_checks',
                'kind' => 'test',
                'serial' => '1',
                'test' => 'Physical checks / visual inspection',
                'specification' => 'Conforms to the approved in-process specification.',
            ],
            [
                'key' => 'in_process_test_results',
                'kind' => 'test',
                'serial' => '2',
                'test' => 'Applicable in-process quality-control test results',
                'specification' => 'All applicable parameters conform to the approved product specification.',
            ],
            [
                'key' => 'manufacturing_observations',
                'kind' => 'test',
                'serial' => '3',
                'test' => 'Manufacturing observations / deviations',
                'specification' => 'No unapproved deviation.',
            ],
        ],
    ],
    [
        'coa_type' => 'FG',
        'template_code' => 'ADA_CAREIO_FG_COA_V01',
        'template_name' => 'ADA Finished-Goods COA',
        'rows' => [
            [
                'key' => 'physical_checks',
                'kind' => 'test',
                'serial' => '1',
                'test' => 'Physical checks / visual inspection',
                'specification' => 'Conforms to the approved finished-product specification.',
            ],
            [
                'key' => 'final_product_test_results',
                'kind' => 'test',
                'serial' => '2',
                'test' => 'Applicable final-product test results',
                'specification' => 'All applicable parameters conform to the approved product specification.',
            ],
            [
                'key' => 'packing_quality_checks',
                'kind' => 'test',
                'serial' => '3',
                'test' => 'Packing-related quality checks',
                'specification' => 'Conforms to the approved packing specification.',
            ],
        ],
    ],
];

$lockName = 'ada_careio_coa_templates_v1';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();

if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the ADA COA template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $validateProduct = $conn->prepare(
        'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertTemplate = $conn->prepare(
        "INSERT INTO coa_document_templates
            (template_code, template_name, coa_type, version_no, document_no,
             issue_no, revision_no, effective_date, review_date, source_directory,
             source_checksum, page_count, layout_json, status, created_by, created_at)
         VALUES (?, ?, ?, 1, 'BIPL-F-COA-01', '01', '02', '2025-04-03',
                 '2028-04-02', ?, ?, 1, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_name = VALUES(template_name),
             coa_type = VALUES(coa_type),
             version_no = 1,
             document_no = VALUES(document_no),
             issue_no = VALUES(issue_no),
             revision_no = VALUES(revision_no),
             effective_date = VALUES(effective_date),
             review_date = VALUES(review_date),
             source_directory = VALUES(source_directory),
             source_checksum = VALUES(source_checksum),
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM coa_document_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO coa_template_product_mappings
            (template_id, product_id, coa_type, status, created_by, created_at)
         VALUES (?, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$validateProduct || !$upsertTemplate || !$findTemplate || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare the ADA COA template statements.');
    }

    foreach ($productIds as $productId) {
        $validateProduct->bind_param('i', $productId);
        $validateProduct->execute();
        if (!$validateProduct->get_result()->fetch_assoc()) {
            throw new RuntimeException("Mapped ADA product {$productId} is unavailable.");
        }
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        $coaType = (string) $definition['coa_type'];
        $profiles = [];
        foreach ($productIds as $productId) {
            $profiles[(string) $productId] = ['family_key' => $familyKey];
        }
        $layout = [
            'schema_version' => 1,
            'renderer' => 'structured_coa_html',
            'renderer_variant' => 'biochemistry',
            'coa_type' => $coaType,
            'document' => $document,
            'profile_families' => [
                $familyKey => [
                    'source_document' => $sourceDocument,
                    'product_name' => 'ADENOSINE DEAMINASE (ADA) REAGENT KIT',
                    'brand_name' => 'Biogenix',
                    'product_code' => 'BGADA',
                    'stp_reference' => '',
                    'page_count' => 1,
                    'metadata_row_count' => 10,
                    'rows' => $definition['rows'],
                ],
            ],
            'profiles' => $profiles,
            'editable_fields' => [
                'metadata.manufacturing_date',
                'metadata.expiry_date',
                'results.*',
                'approval.decision',
                'approval.comments',
                'approval.analysis_by',
                'approval.verified_by',
            ],
        ];
        $layoutJson = json_encode(
            $layout,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
        $checksum = hash('sha256', $layoutJson);
        $templateCode = (string) $definition['template_code'];
        $templateName = (string) $definition['template_name'];
        $upsertTemplate->bind_param(
            'ssssss',
            $templateCode,
            $templateName,
            $coaType,
            $sourceDocument,
            $checksum,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException("Unable to save ADA {$coaType} COA template.");
        }

        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException("Unable to resolve ADA {$coaType} COA template.");
        }
        $templateCount++;

        foreach ($productIds as $productId) {
            $upsertMapping->bind_param('iis', $templateId, $productId, $coaType);
            if (!$upsertMapping->execute()) {
                throw new RuntimeException("Unable to map ADA product {$productId} to {$coaType} COA.");
            }
            $mappingCount++;
        }
    }

    $validateProduct->close();
    $upsertTemplate->close();
    $findTemplate->close();
    $upsertMapping->close();
    $conn->commit();

    echo "ADA CareIO COA templates saved: {$templateCount}\n";
    echo "ADA CareIO COA product mappings updated: {$mappingCount}\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
