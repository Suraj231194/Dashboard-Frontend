-- Payroll Management features specified on pages 14-17 of
-- "HRMS & Payroll Final Doc.pdf". All objects are additive; the existing
-- Payroll Manual, Advance Salary, Finance documents, and My Profile flows
-- remain unchanged.

CREATE TABLE IF NOT EXISTS `payroll_settings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `salary_day` TINYINT UNSIGNED NOT NULL DEFAULT 7,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_payroll_settings_scope` (`company_id`, `branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payroll_runs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `run_number` VARCHAR(50) NOT NULL,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `branch_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `payroll_month` CHAR(7) NOT NULL,
    `payment_date` DATE NOT NULL,
    `employee_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `monthly_salary_total` DECIMAL(18,2) NOT NULL DEFAULT 0,
    `actual_salary_total` DECIMAL(18,2) NOT NULL DEFAULT 0,
    `pf_total` DECIMAL(18,2) NOT NULL DEFAULT 0,
    `esic_total` DECIMAL(18,2) NOT NULL DEFAULT 0,
    `advance_total` DECIMAL(18,2) NOT NULL DEFAULT 0,
    `status` ENUM('generated') NOT NULL DEFAULT 'generated',
    `pdf_path` VARCHAR(500) DEFAULT NULL,
    `generated_by` INT NOT NULL,
    `generated_at` DATETIME NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_payroll_run_number` (`run_number`),
    UNIQUE KEY `uq_payroll_run_scope_month` (`company_id`, `branch_id`, `payroll_month`),
    KEY `idx_payroll_run_month` (`payroll_month`, `generated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payroll_run_items` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `payroll_run_id` BIGINT UNSIGNED NOT NULL,
    `employee_id` INT NOT NULL,
    `serial_number` INT UNSIGNED NOT NULL,
    `employee_code` VARCHAR(100) DEFAULT NULL,
    `employee_name` VARCHAR(255) NOT NULL,
    `monthly_salary` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `gross_earned` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `actual_salary` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `present_days` DECIMAL(7,2) NOT NULL DEFAULT 0,
    `month_days` TINYINT UNSIGNED NOT NULL,
    `pf_amount` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `esic_amount` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `advance_taken` DECIMAL(14,2) NOT NULL DEFAULT 0,
    `bank_account_number` VARCHAR(100) DEFAULT NULL,
    `bank_name` VARCHAR(255) DEFAULT NULL,
    `attendance_source` ENUM('biometric','legacy') NOT NULL DEFAULT 'legacy',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_payroll_run_employee` (`payroll_run_id`, `employee_id`),
    KEY `idx_payroll_item_employee` (`employee_id`),
    CONSTRAINT `fk_payroll_item_run` FOREIGN KEY (`payroll_run_id`)
        REFERENCES `payroll_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `employee_advances`
    ADD COLUMN IF NOT EXISTS `payroll_party_type` ENUM('worker','employee') DEFAULT NULL AFTER `employee_id`,
    ADD COLUMN IF NOT EXISTS `payment_mode` ENUM('cash','bank_transfer','cheque','upi','other') DEFAULT NULL AFTER `amount`,
    ADD COLUMN IF NOT EXISTS `company_id` BIGINT UNSIGNED DEFAULT NULL AFTER `payment_mode`,
    ADD COLUMN IF NOT EXISTS `branch_id` BIGINT UNSIGNED DEFAULT NULL AFTER `company_id`;

CREATE TABLE IF NOT EXISTS `payroll_reimbursements` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `claim_number` VARCHAR(50) NOT NULL,
    `employee_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `expense_name` VARCHAR(255) NOT NULL,
    `expense_date` DATE NOT NULL,
    `merchant` VARCHAR(255) NOT NULL,
    `category` VARCHAR(120) NOT NULL,
    `amount` DECIMAL(14,2) NOT NULL,
    `description` TEXT NOT NULL,
    `receipt_path` VARCHAR(500) NOT NULL,
    `receipt_original_name` VARCHAR(255) NOT NULL,
    `receipt_mime_type` VARCHAR(100) NOT NULL,
    `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    `submitted_at` DATETIME NOT NULL,
    `action_by` INT DEFAULT NULL,
    `action_at` DATETIME DEFAULT NULL,
    `action_note` VARCHAR(1000) DEFAULT NULL,
    `approved_date` DATE DEFAULT NULL,
    `reimbursement_status` ENUM('pending','paid','rejected') NOT NULL DEFAULT 'pending',
    `paid_by` INT DEFAULT NULL,
    `paid_at` DATETIME DEFAULT NULL,
    `payment_mode` ENUM('cash','bank_transfer','cheque','upi','other') DEFAULT NULL,
    `payment_reference` VARCHAR(255) DEFAULT NULL,
    `created_by` INT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_payroll_reimbursement_number` (`claim_number`),
    KEY `idx_payroll_reimbursement_employee` (`employee_id`, `submitted_at`),
    KEY `idx_payroll_reimbursement_scope` (`company_id`, `branch_id`, `status`, `reimbursement_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payroll_reimbursement_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `reimbursement_id` BIGINT UNSIGNED NOT NULL,
    `from_status` VARCHAR(30) DEFAULT NULL,
    `to_status` VARCHAR(30) NOT NULL,
    `note` VARCHAR(1000) DEFAULT NULL,
    `changed_by` INT NOT NULL,
    `changed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_payroll_reimbursement_history` (`reimbursement_id`, `changed_at`),
    CONSTRAINT `fk_payroll_reimbursement_history` FOREIGN KEY (`reimbursement_id`)
        REFERENCES `payroll_reimbursements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT seed.name, seed.slug, 1, 1
FROM (
    SELECT 'Payroll Pay Runs View' AS name, 'payroll_pay_runs_view' AS slug
    UNION ALL SELECT 'Payroll Pay Runs Manage', 'payroll_pay_runs_manage'
    UNION ALL SELECT 'Payroll Advances View', 'payroll_advances_view'
    UNION ALL SELECT 'Payroll Advances Manage', 'payroll_advances_manage'
    UNION ALL SELECT 'Payroll Reimbursements View', 'payroll_reimbursements_view'
    UNION ALL SELECT 'Payroll Reimbursements Manage', 'payroll_reimbursements_manage'
    UNION ALL SELECT 'Finance Reimbursement Claims View', 'finance_reimbursement_claims_view'
    UNION ALL SELECT 'Finance Reimbursement Claims Manage', 'finance_reimbursement_claims_manage'
) seed
WHERE NOT EXISTS (SELECT 1 FROM `permissions` permission WHERE permission.slug = seed.slug);

-- HR/payroll users receive the new Payroll permissions without altering their
-- existing permissions or legacy menu access.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT source.role_id, target.id, 1
FROM (
    SELECT rp.role_id
    FROM `role_permissions` rp
    INNER JOIN `permissions` source_permission ON source_permission.id = rp.permission_id
    WHERE rp.status = 1
      AND source_permission.slug IN ('hr_payroll_manual_menu_list','hr_advance_salary_menu_list')
    UNION SELECT id FROM `roles`
      WHERE name IN ('Super Administrator','Administrator','Senior Administrator','Human Resources')
        AND status = 1 AND deleted_at IS NULL
) source
CROSS JOIN `permissions` target
WHERE target.slug IN (
    'payroll_pay_runs_view','payroll_pay_runs_manage',
    'payroll_advances_view','payroll_advances_manage',
    'payroll_reimbursements_view','payroll_reimbursements_manage'
)
AND NOT EXISTS (
    SELECT 1 FROM `role_permissions` existing
    WHERE existing.role_id = source.role_id AND existing.permission_id = target.id
);

-- Existing Finance payment users receive the reimbursement claims view/manage
-- permissions according to their current view/manage access.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT rp.role_id, target.id, 1
FROM `role_permissions` rp
INNER JOIN `permissions` source_permission ON source_permission.id = rp.permission_id
CROSS JOIN `permissions` target
WHERE rp.status = 1
  AND source_permission.slug = 'finance_payment_made_view'
  AND target.slug = 'finance_reimbursement_claims_view'
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = rp.role_id AND existing.permission_id = target.id
  );

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT rp.role_id, target.id, 1
FROM `role_permissions` rp
INNER JOIN `permissions` source_permission ON source_permission.id = rp.permission_id
CROSS JOIN `permissions` target
WHERE rp.status = 1
  AND source_permission.slug = 'finance_payment_made_manage'
  AND target.slug = 'finance_reimbursement_claims_manage'
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = rp.role_id AND existing.permission_id = target.id
  );

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_at`)
SELECT 'Payroll Management', NULL, 'ti ti-cash-banknote', 0, 85, NULL, 1, 1, CURRENT_TIMESTAMP
FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `menus` WHERE name = 'Payroll Management' AND COALESCE(parent_id, 0) = 0 AND deleted_at IS NULL
);

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_at`)
SELECT seed.name, seed.route, seed.icon, parent.id, seed.sort_order, seed.permission_slug, 1, 1, CURRENT_TIMESTAMP
FROM (
    SELECT 'Pay Runs' AS name, 'index.php?page=payroll-pay-runs' AS route, 'ti ti-file-dollar' AS icon, 1 AS sort_order, 'payroll_pay_runs_view' AS permission_slug
    UNION ALL SELECT 'Advance Salary', 'index.php?page=payroll-advances', 'ti ti-cash', 2, 'payroll_advances_view'
    UNION ALL SELECT 'Reimbursements', 'index.php?page=payroll-reimbursements', 'ti ti-receipt-refund', 3, 'payroll_reimbursements_view'
) seed
INNER JOIN `menus` parent ON parent.name = 'Payroll Management' AND COALESCE(parent.parent_id, 0) = 0 AND parent.deleted_at IS NULL
WHERE NOT EXISTS (SELECT 1 FROM `menus` existing WHERE existing.route = seed.route AND existing.deleted_at IS NULL);

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_at`)
SELECT 'Expenses', NULL, 'ti ti-receipt-rupee', finance.id, 3, NULL, 1, 1, CURRENT_TIMESTAMP
FROM `menus` finance
WHERE finance.name = 'Finance' AND COALESCE(finance.parent_id, 0) = 0 AND finance.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM `menus` existing
      WHERE existing.name = 'Expenses' AND existing.parent_id = finance.id AND existing.deleted_at IS NULL
  );

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_at`)
SELECT 'Reimbursement Claims', 'index.php?page=finance-reimbursement-claims', 'ti ti-receipt-refund', expenses.id, 1,
       'finance_reimbursement_claims_view', 1, 1, CURRENT_TIMESTAMP
FROM `menus` expenses
INNER JOIN `menus` finance ON finance.id = expenses.parent_id AND finance.name = 'Finance' AND finance.deleted_at IS NULL
WHERE expenses.name = 'Expenses' AND expenses.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM `menus` existing
      WHERE existing.route = 'index.php?page=finance-reimbursement-claims' AND existing.deleted_at IS NULL
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
SET role_permission.status = 1
WHERE permission.slug IN (
    'payroll_pay_runs_view','payroll_pay_runs_manage','payroll_advances_view','payroll_advances_manage',
    'payroll_reimbursements_view','payroll_reimbursements_manage',
    'finance_reimbursement_claims_view','finance_reimbursement_claims_manage'
);
