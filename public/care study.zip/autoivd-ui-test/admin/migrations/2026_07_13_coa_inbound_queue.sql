CREATE TABLE IF NOT EXISTS `coa_inbound_queue` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `stock_inward_id` INT(11) NOT NULL,
  `product_id` INT(11) NOT NULL,
  `product_category_id` INT(11) DEFAULT NULL,
  `supplier_id` INT(11) DEFAULT NULL,
  `quantity` DECIMAL(12,3) DEFAULT NULL,
  `quantity_unit` INT(11) DEFAULT NULL,
  `goods_type` ENUM('RM','PM') NOT NULL DEFAULT 'RM' COMMENT 'Auto-filled from product category; editable',
  `status` INT(11) NOT NULL DEFAULT 0 COMMENT '0=Pending, 1=COA Generated, 2=Dismissed',
  `coa_id` INT(11) DEFAULT NULL COMMENT 'FK to coa_rm_pm_table.id once generated',
  `created_by` INT(11) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` INT(11) DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_stock_inward_id` (`stock_inward_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
