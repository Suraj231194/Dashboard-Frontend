<?php

declare(strict_types=1);

/**
 * Adds one independent IP COA source record per Serology product so the
 * incoming FG COA banner stays populated without consuming the existing
 * twelve BMR-backed incoming IP COA banner records.
 *
 * The seed is additive and idempotent. It never updates normal production,
 * IP COA or FG COA records.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/serology/profiles.php';

$records = [
    ['product_id' => 1043, 'batch_size' => 50, 'unit_id' => 11, 'pack_size' => '50 Test'],
    ['product_id' => 1044, 'batch_size' => 25, 'unit_id' => 11, 'pack_size' => '25 Test'],
    ['product_id' => 1045, 'batch_size' => 100, 'unit_id' => 11, 'pack_size' => '100 Test'],
    ['product_id' => 1039, 'batch_size' => 50, 'unit_id' => 11, 'pack_size' => '50 Test'],
    ['product_id' => 1040, 'batch_size' => 25, 'unit_id' => 11, 'pack_size' => '25 Test'],
    ['product_id' => 1041, 'batch_size' => 100, 'unit_id' => 11, 'pack_size' => '100 Test'],
    ['product_id' => 1032, 'batch_size' => 50, 'unit_id' => 11, 'pack_size' => '50 Test - Tamil Nadu Govt.'],
    ['product_id' => 1034, 'batch_size' => 25, 'unit_id' => 11, 'pack_size' => '25 Test'],
    ['product_id' => 1035, 'batch_size' => 100, 'unit_id' => 11, 'pack_size' => '100 Test'],
    ['product_id' => 2014, 'batch_size' => 50, 'unit_id' => 11, 'pack_size' => '50 Test'],
    ['product_id' => 1028, 'batch_size' => 50, 'unit_id' => 11, 'pack_size' => '50 Test'],
    ['product_id' => 1029, 'batch_size' => 100, 'unit_id' => 11, 'pack_size' => '100 Test'],
];

$seedUserId = 1;
$seedDate = date('Y-m-d');
$fiscalYear = bmrBprFiscalYearLabel($seedDate);
$marker = 'Common Serology FG COA template banner acceptance record.';
$lockName = 'common_serology_coa_banner_seed_v1';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the Serology COA banner seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $maxSequenceStmt = $conn->prepare(
        "SELECT COALESCE(MAX(CAST(RIGHT(document_batch_no, 6) AS UNSIGNED)), 0) AS max_sequence
         FROM production_plans
         WHERE document_batch_no LIKE ? AND deleted_at IS NULL"
    );
    $batchPrefixLike = 'BIO/PROD/FY' . $fiscalYear . '/%';
    $maxSequenceStmt->bind_param('s', $batchPrefixLike);
    $maxSequenceStmt->execute();
    $nextSequence = (int) ($maxSequenceStmt->get_result()->fetch_assoc()['max_sequence'] ?? 0) + 1;
    $maxSequenceStmt->close();

    $findProduct = $conn->prepare(
        "SELECT id, product_name, COALESCE(product_code, '') AS product_code
         FROM products
         WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1"
    );
    $findExistingMr = $conn->prepare(
        "SELECT id, prod_plan_id, lot_batch_no
         FROM material_requisition
         WHERE slip_no = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
    );
    $insertPlan = $conn->prepare(
        "INSERT INTO production_plans
            (date, name, lo_batch_no, document_batch_no, batch_size, batch_size_unit,
             timeline, status, prodplan_remark, is_locked, bom_master_id, product_id,
             created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, 0, ?, 0, 0, ?, ?, NOW())"
    );
    $insertMr = $conn->prepare(
        "INSERT INTO material_requisition
            (mr_raw, mr_packing, mr_consumable, date, product_name, lot_batch_no,
             batch_size, batch_size_unit, slip_no, department, requested_by,
             status, auto_generated_batch, prod_plan_id, bom_master_id, created_by, created_at)
         VALUES (1, 1, 1, ?, ?, ?, ?, ?, ?, 1, 'Template Acceptance',
                 0, ?, ?, 0, ?, NOW())"
    );
    $findRequest = $conn->prepare(
        "SELECT id FROM bmr_bpr_requests
         WHERE material_requisition_id = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
    );
    $insertRequest = $conn->prepare(
        "INSERT INTO bmr_bpr_requests
            (material_requisition_id, production_plan_id, product_id, request_date,
             product_name, category_code, lot_number, production_batch_number,
             batch_size, batch_size_unit_id, pack_size, form_count, bmr_form_count,
             bpr_form_count, remarks, status, requested_by, requested_at,
             reviewed_by, reviewed_at, review_comments, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 1, ?,
                 'APPROVED', ?, NOW(), ?, NOW(),
                 'Approved for Serology FG COA template banner acceptance testing.',
                 ?, NOW())"
    );
    $updateRequestNumber = $conn->prepare(
        'UPDATE bmr_bpr_requests SET request_no = ? WHERE id = ?'
    );
    $updateSeedWorkItems = $conn->prepare(
        "UPDATE bmr_bpr_work_items
         SET status = CASE WHEN form_type = 'BMR' THEN 'COMPLETE' ELSE 'PENDING' END,
             started_by = CASE WHEN form_type = 'BMR' THEN ? ELSE started_by END,
             started_at = CASE WHEN form_type = 'BMR' THEN COALESCE(started_at, NOW()) ELSE started_at END,
             completed_by = CASE WHEN form_type = 'BMR' THEN ? ELSE completed_by END,
             completed_at = CASE WHEN form_type = 'BMR' THEN COALESCE(completed_at, NOW()) ELSE completed_at END,
             updated_by = ?, updated_at = NOW()
         WHERE request_id = ? AND deleted_at IS NULL
           AND form_payload_json IS NULL
           AND status IN ('QUEUED', 'PENDING', 'IN_PROCESS', 'COMPLETE')"
    );
    $findBmr = $conn->prepare(
        "SELECT id FROM bmr_bpr_work_items
         WHERE request_id = ? AND form_type = 'BMR' AND deleted_at IS NULL
         ORDER BY form_sequence, id LIMIT 1"
    );
    $findIp = $conn->prepare(
        "SELECT id, coa_ip, coa_template_id
         FROM ip_coa_generation
         WHERE source_bmr_bpr_request_id = ? AND deleted_at IS NULL
         LIMIT 1 FOR UPDATE"
    );
    $insertIp = $conn->prepare(
        "INSERT INTO ip_coa_generation
            (source_bmr_work_item_id, source_bmr_bpr_request_id, product_id,
             coa_template_id, form_payload_json, coa_ip, dept_id, product_name,
             batch_number, batch_size, batch_size_unit, test_date, tested_by,
             review_approved_by, remark, status, created_by, created_at)
         VALUES (?, ?, ?, ?, NULL, NULL, 1, ?, ?, ?, ?, ?,
                 'Template Acceptance', 'QC Head', ?, 0, ?, NOW())"
    );
    $updateIpNumber = $conn->prepare(
        'UPDATE ip_coa_generation SET coa_ip = ? WHERE id = ?'
    );
    if (
        !$findProduct || !$findExistingMr || !$insertPlan || !$insertMr || !$findRequest
        || !$insertRequest || !$updateRequestNumber || !$updateSeedWorkItems
        || !$findBmr || !$findIp || !$insertIp || !$updateIpNumber
    ) {
        throw new RuntimeException('Unable to prepare the Serology COA banner seed statements.');
    }

    $createdIpRows = 0;
    $verifiedRows = 0;
    foreach ($records as $definition) {
        $productId = (int) $definition['product_id'];
        $batchSize = (float) $definition['batch_size'];
        $unitId = (int) $definition['unit_id'];
        $packSize = (string) $definition['pack_size'];
        $seedKey = 'COA-COMMON-SEROLOGY-FG-BANNER-' . $productId;

        $findProduct->bind_param('i', $productId);
        $findProduct->execute();
        $product = $findProduct->get_result()->fetch_assoc();
        if (!$product) {
            throw new RuntimeException("Mapped Serology product {$productId} is unavailable.");
        }
        $productName = trim((string) $product['product_name']);
        $productCode = trim((string) $product['product_code']);

        $findExistingMr->bind_param('s', $seedKey);
        $findExistingMr->execute();
        $existingMr = $findExistingMr->get_result()->fetch_assoc();
        if ($existingMr) {
            $materialRequisitionId = (int) $existingMr['id'];
            $productionPlanId = (int) $existingMr['prod_plan_id'];
            $batchNumber = (string) $existingMr['lot_batch_no'];
        } else {
            $sequence = $nextSequence++;
            $batchNumber = 'BIO/PROD/FY' . $fiscalYear . '/' . str_pad(
                (string) $sequence,
                6,
                '0',
                STR_PAD_LEFT
            );
            $insertPlan->bind_param(
                'ssssdissi',
                $seedDate,
                $productName,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $marker,
                $productId,
                $seedUserId
            );
            if (!$insertPlan->execute()) {
                throw new RuntimeException("Unable to create the FG-banner production plan for {$productName}.");
            }
            $productionPlanId = (int) $conn->insert_id;
            $autoBatch = 'BIPL-MR-' . date('d-m-Y') . '-' . $sequence;
            $insertMr->bind_param(
                'sssdissii',
                $seedDate,
                $productName,
                $batchNumber,
                $batchSize,
                $unitId,
                $seedKey,
                $autoBatch,
                $productionPlanId,
                $seedUserId
            );
            if (!$insertMr->execute()) {
                throw new RuntimeException("Unable to create the FG-banner material request for {$productName}.");
            }
            $materialRequisitionId = (int) $conn->insert_id;
        }

        $findRequest->bind_param('i', $materialRequisitionId);
        $findRequest->execute();
        $existingRequest = $findRequest->get_result()->fetch_assoc();
        if ($existingRequest) {
            $requestId = (int) $existingRequest['id'];
        } else {
            $insertRequest->bind_param(
                'iiisssssdissiii',
                $materialRequisitionId,
                $productionPlanId,
                $productId,
                $seedDate,
                $productName,
                $productCode,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $packSize,
                $marker,
                $seedUserId,
                $seedUserId,
                $seedUserId
            );
            if (!$insertRequest->execute()) {
                throw new RuntimeException("Unable to create the FG-banner workflow request for {$productName}.");
            }
            $requestId = (int) $conn->insert_id;
            $requestNumber = bmrBprRequestNumber($requestId, $seedDate);
            $updateRequestNumber->bind_param('si', $requestNumber, $requestId);
            if (!$updateRequestNumber->execute()) {
                throw new RuntimeException("Unable to number the FG-banner request for {$productName}.");
            }
            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $requestId,
                'SEROLOGY_COA_BANNER_RECORD_CREATED',
                null,
                'APPROVED',
                $marker,
                ['product_id' => $productId],
                $seedUserId
            );
        }

        bmrBprEnsureConfiguredWorkItems($conn, $requestId, 1, 1, $seedUserId);
        $updateSeedWorkItems->bind_param(
            'iiii',
            $seedUserId,
            $seedUserId,
            $seedUserId,
            $requestId
        );
        if (!$updateSeedWorkItems->execute()) {
            throw new RuntimeException("Unable to prepare the FG-banner work item for {$productName}.");
        }
        $findBmr->bind_param('i', $requestId);
        $findBmr->execute();
        $bmrWorkItemId = (int) ($findBmr->get_result()->fetch_assoc()['id'] ?? 0);
        if ($bmrWorkItemId <= 0) {
            throw new RuntimeException("The FG-banner BMR source is missing for {$productName}.");
        }

        $template = coaTemplateResolveMappedTemplate($conn, $productId, 'IP');
        if (!$template || ($template['layout']['renderer_variant'] ?? '') !== 'serology') {
            throw new RuntimeException("The Serology IP COA template is not mapped for {$productName}.");
        }
        $templateId = (int) $template['id'];
        $findIp->bind_param('i', $requestId);
        $findIp->execute();
        $existingIp = $findIp->get_result()->fetch_assoc();
        if ($existingIp) {
            if ((int) $existingIp['coa_template_id'] !== $templateId) {
                throw new RuntimeException("The existing FG-banner IP source has the wrong template for {$productName}.");
            }
            $ipCoaId = (int) $existingIp['id'];
            $ipCoaNo = (string) $existingIp['coa_ip'];
        } else {
            $insertIp->bind_param(
                'iiiissdissi',
                $bmrWorkItemId,
                $requestId,
                $productId,
                $templateId,
                $productName,
                $batchNumber,
                $batchSize,
                $unitId,
                $seedDate,
                $marker,
                $seedUserId
            );
            if (!$insertIp->execute()) {
                throw new RuntimeException("Unable to create the FG-banner IP source for {$productName}: {$insertIp->error}");
            }
            $ipCoaId = (int) $conn->insert_id;
            $ipCoaNo = bmrBprIpCoaNumber($ipCoaId, $seedDate);
            $updateIpNumber->bind_param('si', $ipCoaNo, $ipCoaId);
            if (!$updateIpNumber->execute()) {
                throw new RuntimeException("Unable to number the FG-banner IP source for {$productName}.");
            }
            bmrBprInsertHistory(
                $conn,
                'IP_COA',
                $ipCoaId,
                'CREATE_IP_COA_BANNER_SOURCE',
                null,
                'CREATED',
                $marker,
                [
                    'source_bmr_work_item_id' => $bmrWorkItemId,
                    'source_bmr_bpr_request_id' => $requestId,
                    'coa_ip' => $ipCoaNo,
                    'coa_template_id' => $templateId,
                ],
                $seedUserId
            );
            $createdIpRows++;
        }
        $verifiedRows++;
        echo "{$productId} | {$productName} | {$ipCoaNo} | FG banner source\n";
    }

    $conn->commit();
    echo "Created {$createdIpRows} new Serology IP sources; verified {$verifiedRows} FG banner records.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
