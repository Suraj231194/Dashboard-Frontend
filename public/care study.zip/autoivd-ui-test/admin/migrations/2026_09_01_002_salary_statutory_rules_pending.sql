-- Salary balancing and statutory deduction rules requested for Employee Master.

ALTER TABLE `hr_employee_profiles`
    ADD COLUMN IF NOT EXISTS `pf_category` ENUM('e','w','ew') DEFAULT NULL AFTER `annual_ctc`;

ALTER TABLE `employee_salaries`
    ADD COLUMN IF NOT EXISTS `pf_category` ENUM('e','w','ew') DEFAULT NULL AFTER `base_salary_pf_esi`,
    ADD COLUMN IF NOT EXISTS `pf` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `deductions`,
    ADD COLUMN IF NOT EXISTS `esi` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `pf`;

-- Rollback, if required after restoring affected data:
-- ALTER TABLE `employee_salaries` DROP COLUMN IF EXISTS `pf_category`;
-- ALTER TABLE `hr_employee_profiles` DROP COLUMN IF EXISTS `pf_category`;