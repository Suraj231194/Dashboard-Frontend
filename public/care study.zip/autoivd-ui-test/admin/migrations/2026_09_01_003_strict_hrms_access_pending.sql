-- Separate attendance dashboard visibility from attendance marking.

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT seed.name, seed.slug, 1, 1
FROM (
    SELECT 'HRMS Attendance View' AS name, 'hrms_attendance_view' AS slug
    UNION ALL SELECT 'HRMS Attendance Mark', 'hrms_attendance_mark'
  UNION ALL SELECT 'HRMS Biometric Administration', 'hrms_biometric_manage'
) seed
WHERE NOT EXISTS (
    SELECT 1 FROM `permissions` permission WHERE permission.slug = seed.slug
);

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND (
      (permission.slug = 'hrms_attendance_view'
       AND LOWER(role.name) IN ('production', 'human resources', 'administrator', 'senior administrator', 'super administrator'))
      OR
      (permission.slug = 'hrms_attendance_mark'
       AND LOWER(role.name) IN ('production', 'human resources'))
      OR
      (permission.slug = 'hrms_biometric_manage'
       AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator'))
  )
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = CASE
    WHEN permission.slug = 'hrms_attendance_view'
      AND LOWER(role.name) IN ('production', 'human resources', 'administrator', 'senior administrator', 'super administrator') THEN 1
    WHEN permission.slug = 'hrms_attendance_mark'
      AND LOWER(role.name) IN ('production', 'human resources') THEN 1
    WHEN permission.slug = 'hrms_biometric_manage'
      AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator') THEN 1
    ELSE 0
END
WHERE permission.slug IN ('hrms_attendance_view', 'hrms_attendance_mark', 'hrms_biometric_manage');

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
SET role_permission.status = 0
WHERE permission.slug = 'hrms_attendance_manage';

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = CASE WHEN LOWER(role.name) = 'human resources' THEN 1 ELSE 0 END
WHERE permission.slug = 'hrms_shift_manage';

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND LOWER(role.name) = 'human resources'
  AND permission.slug = 'hrms_shift_manage'
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `menus`
SET permission_slug = 'hrms_attendance_view', updated_by = 1, updated_at = NOW()
WHERE route = 'index.php?page=attendance-management' AND deleted_at IS NULL;

-- The old combined permission is retained only for compatibility and has no role grants.