-- ============================================================
-- Migration: Sync missing columns on DEV database
-- Date: 2026-07-15
-- Description: Adds missing columns to suppliers, product_categories,
--              erp_branches, erp_companies, and erp_warehouses.
-- ============================================================

ALTER TABLE `suppliers` ADD COLUMN IF NOT EXISTS `email` varchar(255) ;

ALTER TABLE `product_categories` ADD COLUMN IF NOT EXISTS `category_prefix` varchar(150) ;

ALTER TABLE `erp_branches` ADD COLUMN IF NOT EXISTS `deleted_by` bigint(20) unsigned DEFAULT NULL AFTER `deleted_at`;
ALTER TABLE `erp_companies` ADD COLUMN IF NOT EXISTS `deleted_by` bigint(20) unsigned DEFAULT NULL AFTER `deleted_at`;
ALTER TABLE `erp_warehouses` ADD COLUMN IF NOT EXISTS `deleted_by` bigint(20) unsigned DEFAULT NULL AFTER `deleted_at`;
